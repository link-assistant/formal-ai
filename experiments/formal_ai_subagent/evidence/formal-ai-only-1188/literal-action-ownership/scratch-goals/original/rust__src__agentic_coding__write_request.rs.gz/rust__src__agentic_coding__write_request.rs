//! Recover write-request targets and literal payloads from seeded prose cues.
//!
//! The general planner and request inspection share this parse (issues #654, #1066).
mod lowercase_spans;
use super::file_path_shape::{is_dotted_number, peel_sentence_punctuation};
use super::shell_command_policy::{prose_sentences, sentences};
use crate::seed::{self, Slot};
pub(super) use lowercase_spans::{
    first_raw_content_lead_end, first_raw_prefix_lead_end, raw_content_lead_close,
};
/// The seeded articles and other function words (`the`, `el`).
const FUNCTION_WORD_ROLE: &str = "request_function_word";
/// One whitespace token together with its byte span in the original request.
pub(super) struct Token<'a> {
    pub(super) text: &'a str,
    pub(super) start: usize,
    pub(super) end: usize,
    pub(super) request: &'a str,
}
/// Split whitespace and ideographic punctuation while retaining byte spans.
/// Without punctuation boundaries, an unspaced clause can become one path token.
pub(super) fn tokens(request: &str) -> Vec<Token<'_>> {
    let mut out = Vec::new();
    let mut start: Option<usize> = None;
    for (index, character) in request.char_indices() {
        if character.is_whitespace() || is_ideographic_punctuation(character) {
            if let Some(from) = start.take() {
                out.push(Token {
                    text: &request[from..index],
                    start: from,
                    end: index,
                    request,
                });
            }
            continue;
        }
        if start.is_none() {
            start = Some(index);
        }
    }
    if let Some(from) = start {
        out.push(Token {
            text: &request[from..],
            start: from,
            end: request.len(),
            request,
        });
    }
    out
}

/// Whether a character is one of the ideographic punctuation marks that
/// separate words and clauses in a script written without spaces.
const fn is_ideographic_punctuation(character: char) -> bool {
    matches!(character,
        '\u{3001}'..='\u{3003}'
            | '\u{3008}'..='\u{3011}'
            | '\u{3014}'..='\u{301f}'
            | '\u{ff01}'
            | '\u{ff08}'
            | '\u{ff09}'
            | '\u{ff0c}'
            | '\u{ff1a}'
            | '\u{ff1b}'
            | '\u{ff1f}')
}
/// The bare (whole-word) surface forms for a role, lowercased for token matching.
pub(super) fn bare_surfaces(role: &str) -> Vec<String> {
    seed::lexicon()
        .role_word_forms(role)
        .iter()
        .filter(|form| form.slot() == Slot::Bare)
        .map(|form| form.text.to_lowercase())
        .collect()
}
/// Trim the quoting/edge punctuation from a token that may be a file path,
/// preserving the interior dots that make it look like a file. Trailing sentence
/// punctuation is stripped too, so a plain word that merely *ends a sentence*
/// ("… add the plural to томат.") is not mistaken for a file whose only dot is the
/// terminal period — a real filename never ends in a bare `.`/`!`/`?`.
pub(super) fn clean_path_token(word: &str) -> &str {
    peel_sentence_punctuation(word, |token| {
        token
            .trim_matches(|c: char| matches!(c, '`' | '"' | '\'' | ',' | ':' | ';'))
            .trim_end_matches(['!', '?'])
    })
}
/// Whether a safe-looking token names a file rather than merely using the
/// conventional `./` prefix for a directory.
///
/// Checking the whole token for a dot made policy prose such as "keep examples
/// in ./examples" file-shaped. When a later sentence contained a write-content
/// marker, the generic planner consequently tried to overwrite that directory.
/// File shape belongs to the final path component; dots in parent components or
/// in the relative-path prefix do not make the target a file. A component that
/// is nothing but dots (`.`, `..`) names a directory, never a file: the full
/// stop after a closing quote (`… with ''.`) is not a file to read (issue #715).
pub(super) fn looks_like_file_path(path: &str) -> bool {
    !path.contains("://")
        && !is_dotted_number(path)
        && path.rsplit('/').next().is_some_and(|file_name| {
            file_name.contains('.') && file_name.chars().any(|character| character != '.')
        })
}
/// Lowercase a token stripped of edge punctuation, for cue/action comparison.
///
/// The Devanagari full stop `।` ends a Hindi sentence exactly as `.` ends an
/// English one, so a cue that closes a clause — `लिखो।` — is the same cue as
/// `लिखो`. Without it the verb of every sentence-final Hindi request went
/// unrecognised.
pub(super) fn clean_cue_token(word: &str) -> String {
    word.trim_matches(|c: char| {
        matches!(
            c,
            '`' | '"' | '\'' | ',' | ':' | ';' | '.' | '!' | '?' | '\u{0964}' | '\u{0965}'
        )
    })
    .to_lowercase()
}
/// The byte span just past the leftmost `file_write_content_lead` marker in the
/// lowercased request, honouring whole-word boundaries for space-delimited
/// scripts and substring matches for CJK (which has no inter-word spaces).
pub(super) fn first_content_lead_end(lowered: &str) -> Option<(usize, usize)> {
    first_prefix_lead_end(lowered, seed::ROLE_FILE_WRITE_CONTENT_LEAD)
}
/// Where the payload a circumfix content marker opened has to stop.
///
/// "जिसमें Gemfile.lock हो" states its content between two literals, and so does
/// "把 Gemfile.lock 写入": the closing literal is a grammatical boundary, not
/// part of the bytes. Returns [`None`] when the marker that ended at `from` was
/// not a circumfix one, which is every marker in the languages that put their
/// content last.
pub(super) fn content_lead_close(lowered: &str, from: usize) -> Option<usize> {
    seed::lexicon()
        .role_word_forms(seed::ROLE_FILE_WRITE_CONTENT_LEAD)
        .iter()
        .filter(|form| form.slot() == Slot::Circumfix)
        .filter_map(|form| {
            let opener = form.before_slot().trim().to_lowercase();
            let closer = form.after_slot().trim().to_lowercase();
            if opener.is_empty()
                || closer.is_empty()
                || !lowered.get(..from)?.trim_end().ends_with(&opener)
            {
                return None;
            }
            lowered
                .get(from..)?
                .find(&closer)
                .map(|relative| from + relative)
        })
        .min()
}
pub(super) fn first_prefix_lead_end(lowered: &str, role: &str) -> Option<(usize, usize)> {
    let markers: Vec<(String, String)> = seed::lexicon()
        .role_word_forms(role)
        .iter()
        .filter(|form| matches!(form.slot(), Slot::Prefix | Slot::Circumfix))
        .map(|form| {
            (
                form.before_slot().trim().to_lowercase(),
                form.after_slot().trim().to_lowercase(),
            )
        })
        .filter(|(marker, _)| !marker.is_empty())
        .collect();
    let mut best: Option<(usize, usize)> = None;
    for (marker, closer) in &markers {
        let mut from = 0;
        while let Some(relative) = lowered[from..].find(marker.as_str()) {
            let start = from + relative;
            let end = start + marker.len();
            let cjk = !marker.contains(' ') && !marker.is_ascii();
            let before_ok = cjk
                || start == 0
                || lowered[..start]
                    .chars()
                    .next_back()
                    .is_some_and(char::is_whitespace);
            let after_ok = cjk
                || end == lowered.len()
                || lowered[end..]
                    .chars()
                    .next()
                    .is_some_and(|c| c.is_whitespace() || c.is_ascii_punctuation());
            // A circumfix form holds its subject *between* two literals, so its
            // opener means nothing on its own: "把" opens a Chinese object
            // phrase only when the verb that closes it follows. Requiring the
            // closer keeps a one-character opener from claiming every sentence
            // that happens to contain it.
            let closed = closer.is_empty() || lowered[end..].contains(closer.as_str());
            if before_ok && after_ok && closed {
                if best.is_none_or(|(best_start, best_end)| {
                    start < best_start || (start == best_start && end > best_end)
                }) {
                    best = Some((start, end));
                }
                break;
            }
            from = end;
        }
    }
    best
}
/// Which family of cue named a path, which decides what the rest of the
/// sentence is allowed to mean.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum CueFamily {
    /// A `file_write_target_cue` — the file the work is about.
    Target,
    /// A `file_write_destination_cue` — somewhere to deliver bytes.
    Destination,
    /// A bare `file_write_action_cue`, which names a file only incidentally.
    Action,
}

/// One path a sentence names, together with the cue that named it.
#[derive(Debug, Clone)]
pub(super) struct WriteBinding {
    /// Token index of the path.
    pub(super) index: usize,
    /// The cleaned, safe relative path.
    pub(super) path: String,
    /// Byte offset at which the binding cue begins.
    pub(super) cue_start: usize,
    /// Byte offset just past the binding cue.
    pub(super) cue_end: usize,
    /// Which family of cue bound it.
    pub(super) family: CueFamily,
    /// Whether the cue stands *before* the path. A postposition stands after it.
    pub(super) cue_precedes: bool,
}

/// The target file of a write, as `(token index, path)`.
///
/// A sentence can offer more than one file-shaped token behind a cue, and which
/// one it *delivers to* is not the leftmost: "Write Gemfile.lock into
/// notes/attribution.md" names the content first, behind the bare action cue
/// *Write*, and the destination second, behind *into*. Binding the leftmost
/// bound the content as the target, the destination-led branch below then failed
/// its `action_end <= clause_start` test, and the whole clause composed to
/// nothing — in all five languages.
///
/// So the candidates are ranked by what named them rather than by where they
/// stand: a path a *target* or *destination* cue points at outranks one only an
/// action cue stands beside, and a cue that follows its path (a postposition)
/// ranks last. A sentence that offers exactly one candidate is unaffected, which
/// is every sentence the earlier rule read correctly.
pub(super) fn cued_write_target(toks: &[Token<'_>]) -> Option<(usize, String)> {
    preferred_binding(toks).map(|binding| (binding.index, binding.path))
}

/// Every candidate binding, best first.
///
/// A cue that stands *between* two file-shaped tokens could belong to either of
/// them, and no ranking settles that on its own: `notes/attribution.md में
/// Gemfile.lock लिखो` puts the destination postposition after the path it marks,
/// so the same rule that reads `into notes/attribution.md` correctly reads the
/// Hindi sentence backwards. The reading is settled by the rest of the sentence
/// instead — the caller takes these in order and keeps the first that yields a
/// payload — so the ranking only has to decide which reading is *tried* first.
pub(super) fn ranked_bindings(toks: &[Token<'_>]) -> Vec<WriteBinding> {
    let mut bindings = write_bindings(toks);
    bindings.sort_by_key(binding_rank);
    bindings
}

/// The binding a write request is read through: the highest-ranked candidate.
pub(super) fn preferred_binding(toks: &[Token<'_>]) -> Option<WriteBinding> {
    ranked_bindings(toks).into_iter().next()
}

/// Lower ranks are preferred. Token order breaks a tie, which `min_by_key`
/// preserves because the bindings are produced in token order.
const fn binding_rank(binding: &WriteBinding) -> u8 {
    match (binding.cue_precedes, binding.family) {
        (true, CueFamily::Target | CueFamily::Destination) => 0,
        (true, CueFamily::Action) => 1,
        (false, _) => 2,
    }
}

/// Every cued target in token order, so a caller that has a further question to
/// ask about a candidate can go on to the next one instead of losing the
/// sentence with it.
pub(super) fn cued_write_targets(toks: &[Token<'_>]) -> Vec<(usize, String)> {
    write_bindings(toks)
        .into_iter()
        .filter(|binding| binding.cue_precedes)
        .map(|binding| (binding.index, binding.path))
        .collect()
}

/// Every path a cue binds, in token order.
///
/// A cue stands before its path in the languages that put it there and after it
/// in the languages that do not: Hindi writes `notes/attribution.md फ़ाइल` and
/// `notes/attribution.md में`, so a reader that only ever looks one token back
/// finds no target in a Hindi request at all. A postposition is therefore read
/// too, but only for the target and destination families — an action cue after a
/// path closes the clause rather than naming the file — and only when the path
/// has no cue in front of it.
fn write_bindings(toks: &[Token<'_>]) -> Vec<WriteBinding> {
    let target_cues = bare_surfaces(seed::ROLE_FILE_WRITE_TARGET_CUE);
    let dest_cues = bare_surfaces(seed::ROLE_FILE_WRITE_DESTINATION_CUE);
    let action_cues = bare_surfaces(seed::ROLE_FILE_WRITE_ACTION_CUE);
    // The fused reading is for the nouns and particles that a script without
    // spaces writes against their neighbour — `创建文件` is "create" and "file",
    // `文件` is the cue. A verb is not read that way: `输出内容 sample.txt` opens
    // with the write verb `输出` and means "output the contents of", a read, and
    // reading the verb out of the fused token claimed the file the request asked
    // to be shown.
    let families = [
        (CueFamily::Destination, &dest_cues, true),
        (CueFamily::Target, &target_cues, true),
        (CueFamily::Action, &action_cues, false),
    ];
    let quoted =
        crate::normal_markov::quoted_segment_spans(toks.first().map_or("", |token| token.request));
    toks.iter()
        .enumerate()
        .filter_map(|(index, token)| {
            let cleaned = clean_path_token(token.text);
            if !looks_like_file_path(cleaned) || !safe_relative_path(cleaned) {
                return None;
            }
            let path = cleaned.to_owned();
            if let Some(previous) = index.checked_sub(1).map(|before| &toks[before])
                && let Some((family, cue_start, cue_end)) =
                    families.iter().find_map(|(family, cues, fused)| {
                        trailing_cue(previous, cues, *fused).map(|span| (*family, span.0, span.1))
                    })
            {
                return Some(WriteBinding {
                    index,
                    path,
                    cue_start,
                    cue_end,
                    family,
                    cue_precedes: true,
                });
            }
            let next = toks.get(index + 1)?;
            families
                .iter()
                .take(2)
                .find_map(|(family, cues, fused)| {
                    leading_cue(next, cues, *fused).map(|span| (*family, span.0, span.1))
                })
                .map(|(family, cue_start, cue_end)| WriteBinding {
                    index,
                    path,
                    cue_start,
                    cue_end,
                    family,
                    cue_precedes: false,
                })
        })
        .filter(|binding| {
            !quoted
                .iter()
                .any(|segment| binding.cue_start < segment.end && binding.cue_end > segment.start)
        })
        .collect()
}

/// The span of a cue standing at the *end* of `token`, if one does.
///
/// An unspaced script writes the cue and the word before it as one token —
/// `创建文件` is "create" and "file" with nothing between them — so for a cue in
/// such a script the token's tail is the boundary the language actually has.
fn trailing_cue(token: &Token<'_>, cues: &[String], fused: bool) -> Option<(usize, usize)> {
    let cleaned = clean_cue_token(token.text);
    cues.iter().find_map(|cue| {
        if cleaned == *cue {
            return Some((token.start, token.end));
        }
        (fused && is_unspaced_surface(cue) && cleaned.ends_with(cue.as_str()))
            .then(|| (token.end.saturating_sub(cue.len()), token.end))
    })
}

/// The span of a cue standing at the *start* of `token`, if one does.
fn leading_cue(token: &Token<'_>, cues: &[String], fused: bool) -> Option<(usize, usize)> {
    let cleaned = clean_cue_token(token.text);
    cues.iter().find_map(|cue| {
        if cleaned == *cue {
            return Some((token.start, token.end));
        }
        (fused && is_unspaced_surface(cue) && cleaned.starts_with(cue.as_str()))
            .then(|| (token.start, token.start + cue.len()))
    })
}

/// Whether a surface belongs to a script that does not separate its words with
/// spaces, so a token boundary is not where the word ends.
fn is_unspaced_surface(surface: &str) -> bool {
    crate::coding::catalog::contains_cjk(surface)
}

/// Whether a token is written as a double-quoted literal.
///
/// A path is *mentioned* -- bare, or set in the backticks this repository's
/// prose uses for code -- whereas a double-quoted token is a *value* the
/// sentence is handing to something else: the member "add \"bun.lock\" to the
/// `IGNORE_FILES` list" inserts, the marker the ladder asks a record to contain.
/// Both can be file-shaped, and `clean_path_token` peels either quoting away, so
/// the distinction has to be read before the peeling.
fn quoted_as_value(word: &str) -> bool {
    let bare = peel_sentence_punctuation(word, |token| token.trim_end_matches([',', ':', ';']));
    bare.len() >= 2 && bare.starts_with('"') && bare.ends_with('"')
}
/// The path a request names as the destination of a write, whether or not it
/// also spells the bytes out.
///
/// [`parse_write_request`] answers a narrower question — it recovers a write it
/// can execute verbatim — and deliberately declines a request whose payload has
/// still to be *composed*. The evidence-record route needs the target of
/// exactly that declined shape ("record what you find in FILE"), so the target
/// half of the parse is exposed on its own rather than duplicated (issue #1066).
pub(super) fn stated_write_target(request: &str) -> Option<String> {
    cued_write_target(&tokens(request)).map(|(_, target)| target)
}
/// Bind a source destination using the ordinary cue/path safety rules, with
/// the language's artifact type as a further constraint. Output operands and
/// workflow paths do not become source destinations by appearing first.
pub fn typed_write_target(request: &str, extension: &str) -> Option<String> {
    cued_write_targets(&tokens(request))
        .into_iter()
        .map(|(_, path)| path)
        .find(|path| {
            std::path::Path::new(path)
                .extension()
                .and_then(|value| value.to_str())
                == Some(extension)
        })
}
/// Whether the request applies a seed-defined write action to anything.
///
/// Used with [`stated_write_target`] to tell "record it in FILE" (a write whose
/// content is composed) from "read the first line in FILE" (a read that merely
/// mentions a file after a positional cue).
pub(super) fn states_write_action(request: &str) -> bool {
    first_action_cue_end(&tokens(request)).is_some()
}

/// The path a sentence names as the *destination* of a write it states.
///
/// [`stated_write_target`] answers a weaker question -- which path a cue points
/// at -- and a sentence can point a cue at a path it is not delivering to,
/// because the same cues introduce the file the work is done *in*. Both of these
/// name a path after a target cue and state a write action:
///
/// > In the file `src/solver_handlers/document_request.rs`, add "toward " to the
/// > TARGET_MARKERS list.
///
/// > Then create `agent-ladder-effects/node-1.1.2.2.1.lino` recording what you
/// > changed.
///
/// Only the second is somewhere to put an answer. In the first the thing being
/// added goes into a list *inside* the file, and reading it as a delivery
/// destroys the file it was asked to edit -- the planner writes its own status
/// line over the source and the write reports success.
///
/// What separates them is order, the same adjacency principle
/// [`cued_write_target`] already uses to bind a cue to a path. A delivery
/// composes something and then says where to put it, so its path *follows* the
/// action; a sentence that says where the work happens states the place first
/// and the action afterwards.
///
/// Measured over the 1 118 request sentences this repository records that name a
/// file and carry a cue (`experiments/issue_1069_paths_in_prose/cue-order-survey.py`),
/// the path follows the action in 21.56% of them, precedes it in 65.74%, and in
/// the remaining 12.70% there is no write cue at all -- an edit, which is never a
/// delivery. So this reads roughly a fifth of them as destinations, where the
/// weaker "cues a path and states a write" test reads all 1 118.
///
/// The rule that suggests itself first is the cue family: the seed declares a
/// second family for edits, so a sentence mentioning one could be doing work
/// rather than delivering. That fails on this corpus. Thirty of the sentences
/// carry both families, and the ladder's own delivery sentence is one of them --
/// "Then create `agent-ladder-effects/node-1.1.2.2.1.lino` … followed by at
/// least four words that state the **change** you made" -- so the family rule
/// discards the record the node exists to produce. Position separates what
/// mention cannot.
///
/// Position alone still admits a value that merely *looks* like a path, because
/// the operand of an insertion follows the action too: "Edit `scripts/metric.rs`:
/// add \"bun.lock\" to the `IGNORE_FILES` list" names the file before the action
/// and the member after it. So the candidates are taken in order and a
/// double-quoted one is skipped rather than accepted -- see [`quoted_as_value`].
/// The same survey measures what that costs: of the 241 sentences the position
/// rule admits, 2 (0.83%) quote their path, and both are member insertions of
/// exactly this shape. No delivery destination in the corpus is double-quoted.
pub(super) fn delivered_write_target(sentence: &str) -> Option<String> {
    let toks = tokens(sentence);
    let action = first_action_cue_start(&toks)?;
    cued_write_targets(&toks)
        .into_iter()
        .find(|(index, _)| toks[*index].start > action && !quoted_as_value(toks[*index].text))
        .map(|(_, path)| path)
}

/// Whether `request` names `path` as the destination of a write it states.
///
/// The read routes need this to keep from opening the file they were asked to
/// create. "Leave observable evidence in `.agent-ladder/node-1.2-proof.md`. The
/// first line must be exactly `node_path=1.2`" names one path and one read cue
/// -- *first line* -- and the two belong to different obligations: the path is
/// where the answer goes, the cue describes how it has to open. Read the prompt
/// as a whole and the cue captures the path, and the run opens the file it was
/// supposed to write.
///
/// Scoped to a sentence, for the same reason [`super::evidence_record`] scopes
/// its own split: "Read the file `Cargo.toml`. Record what you find in
/// `notes/report.md`." states a write of the second path only, and the first
/// must stay readable.
pub(super) fn is_stated_write_target(request: &str, path: &str) -> bool {
    sentences(request).into_iter().any(|sentence| {
        states_write_action(sentence.text)
            && stated_write_target(sentence.text).is_some_and(|target| target == path)
    })
}

/// Recover the seeded opening-line constraint through original UTF-8 boundaries.
/// Lowercase cue matching never changes the bytes of the recovered line.
pub(super) fn pinned_first_line(sentence: &str) -> Option<String> {
    let (_, end) =
        first_raw_prefix_lead_end(sentence, seed::ROLE_FILE_LEADING_LINE_CONSTRAINT_LEAD)?;
    let raw = sentence
        .get(end..)?
        .trim()
        .trim_start_matches([':', '-', '\u{2014}', '\u{2013}'])
        .trim();
    let line = delimited_first_line(raw)
        .or_else(|| unquoted_machine_first_line(raw))
        .unwrap_or(raw)
        .trim_matches(['`', '"', '\'']);
    (!line.is_empty()).then(|| line.to_owned())
}

/// An explicitly delimited opening line, without the presentation delimiters.
///
/// The closing delimiter is also a grammatical boundary: in "exactly `id=7`
/// and the body ...", the coordinated body constraint is not part of the
/// machine-readable header.
fn delimited_first_line(raw: &str) -> Option<&str> {
    let delimiter = raw.chars().next()?;
    if !matches!(delimiter, '`' | '"' | '\'') {
        return None;
    }
    let after_open = raw.get(delimiter.len_utf8()..)?;
    let close = after_open.find(delimiter)?;
    after_open.get(..close)
}

/// Stop an unquoted machine header before a coordinated second requirement.
///
/// Natural-language lines such as "ready and waiting" remain whole. A compact
/// assignment/header token (`name=value`, `name:value`) followed by a
/// seed-defined procedure separator is unambiguous: the separator begins the
/// next clause, as it did in the live Agent ladder prompt.
fn unquoted_machine_first_line(raw: &str) -> Option<&str> {
    let lowered = raw.to_lowercase();
    bare_surfaces(seed::ROLE_SKILL_PROCEDURE_CLAUSE_SEPARATOR)
        .into_iter()
        .filter_map(|separator| {
            let marker = format!(" {separator} ");
            lowered.find(&marker).and_then(|boundary| {
                let candidate = raw.get(..boundary)?.trim();
                (!candidate.contains(char::is_whitespace) && candidate.contains(['=', ':']))
                    .then_some(candidate)
            })
        })
        .min_by_key(|candidate| candidate.len())
}
/// The opening line the request pins, wherever in the request it pins it.
///
/// A pinned first line constrains the finished file, not the sentence that
/// happens to state it. [`super::evidence_record`] reads the constraint one
/// sentence at a time because it is separating delivery from work; a route that
/// only has to *obey* the constraint needs nothing more than its text.
pub(super) fn pinned_first_line_of_request(request: &str) -> Option<String> {
    sentences(request)
        .into_iter()
        .find_map(|sentence| pinned_first_line(sentence.text))
}
/// The same content, rewritten to open with the line `request` pinned.
///
/// A literal write is only literal when it satisfies every stated constraint on
/// the file it writes, and a request can state two: what the file contains, and
/// how it begins. "Write `notes/x.md` containing alpha, beta and gamma. The
/// first line must be exactly `id=7`" reads as a literal write to the broad
/// content parser -- *containing* cues content -- and the bytes it recovers are
/// the prose that followed the cue, which neither open with the pinned line nor
/// leave the pinning sentence out. Writing them satisfies the sentence that was
/// parsed and violates the one that was not.
///
/// Both corrections come out of a parse that has already happened -- the pinned
/// line, and which sentence pinned it -- so the plan is repaired rather than
/// dropped. Dropping it was the earlier fix, and it moved the failure instead of
/// removing it: a request that states every byte it wants and no work to do has
/// no other route to reach, so declining sent the plainest write there is to the
/// open-web routers.
///
/// The pinning sentence leaves the body with it. It was recovered only because
/// the content lead swept up the rest of the prose; the caller stated it as a
/// constraint on the file, never as something to put inside the file.
///
/// Returns `None` when there is nothing to repair -- `request` pins no line, or
/// `content` already opens with it (issue #1066).
pub(super) fn honouring_pinned_first_line(request: &str, content: &str) -> Option<String> {
    let line = pinned_first_line_of_request(request)?;
    if content.starts_with(&line) {
        return None;
    }
    let body = without_pinning_sentences(content);
    Some(if body.is_empty() {
        format!("{line}\n")
    } else {
        format!("{line}\n\n{body}\n")
    })
}

/// `content` without any sentence that is itself a leading-line constraint.
fn without_pinning_sentences(content: &str) -> String {
    sentences(content)
        .into_iter()
        .filter(|sentence| pinned_first_line(sentence.text).is_none())
        .map(|sentence| content[sentence.span].trim())
        .filter(|kept| !kept.is_empty())
        .collect::<Vec<_>>()
        .join(" ")
}
/// The span of the first `file_write_action_cue` in the request.
fn first_action_cue(toks: &[Token<'_>]) -> Option<(usize, usize)> {
    let actions = bare_surfaces(seed::ROLE_FILE_WRITE_ACTION_CUE);
    toks.iter()
        .find_map(|token| leading_cue(token, &actions, false))
}
/// The byte offset just past the first `file_write_action_cue` token.
pub(super) fn first_action_cue_end(toks: &[Token<'_>]) -> Option<usize> {
    first_action_cue(toks).map(|(_, end)| end)
}
/// Where the first `file_write_action_cue` at or after `from` begins.
///
/// A language that closes its clause with the verb states the action *after* the
/// destination it was given, so the payload is what stands between them. The
/// prepositional shape reads the same span from the other side — see
/// `parse_write_request`.
pub(super) fn action_cue_start_after(toks: &[Token<'_>], from: usize) -> Option<usize> {
    let actions = bare_surfaces(seed::ROLE_FILE_WRITE_ACTION_CUE);
    toks.iter()
        .filter(|token| token.start >= from)
        .find_map(|token| leading_cue(token, &actions, false))
        .map(|(start, _)| start)
}
/// The byte offset at which the first `file_write_action_cue` begins.
///
/// [`first_action_cue_end`] answers where a payload may start; this answers
/// where the delivery clause does, and the two questions have different callers.
/// A sentence can carry both halves of a request -- "Break the customer import
/// rewrite into sub-tasks and record what you work out in `import-split.md`"
/// states the work and then, mid-sentence, says where its result goes -- so a
/// reader that hands the whole sentence to delivery throws the work away with
/// it (issue #1066).
pub(super) fn first_action_cue_start(toks: &[Token<'_>]) -> Option<usize> {
    first_action_cue(toks).map(|(start, _)| start)
}
/// Recover literal bytes from a seeded clause, preserving unmatched delimiters.
pub(super) fn clean_content(raw: &str) -> Option<String> {
    let led = strip_clause_lead(raw);
    let fence_length = led.bytes().take_while(|byte| *byte == b'`').count();
    if fence_length >= 3 && led.len() >= fence_length * 2 && led.ends_with(&led[..fence_length]) {
        let body =
            super::markdown_section::fenced_body(&led[fence_length..led.len() - fence_length]);
        return (!body.is_empty()).then(|| body.to_owned());
    }
    let closed = led
        .strip_suffix([
            '.', '!', '?', '\u{0964}', '\u{3002}', '\u{ff01}', '\u{ff1f}',
        ])
        .map_or(led, str::trim);
    if let [only] = crate::normal_markov::quoted_segment_spans(closed).as_slice()
        && only.start == 0
        && only.end == closed.len()
    {
        let text = &only.text;
        return (!text.is_empty()).then(|| text.to_owned());
    }
    let bytes = led.as_bytes();
    let quoted = led.len() >= 2
        && bytes[0] == bytes[led.len() - 1]
        && matches!(bytes[0], b'`' | b'"' | b'\'');
    let result = if quoted {
        led[1..led.len() - 1].trim()
    } else {
        led
    };
    (!result.is_empty()).then(|| result.to_owned())
}
/// Strip seeded qualifiers and content leads only before a clause separator.
fn strip_clause_lead(raw: &str) -> &str {
    let modifiers = bare_surfaces(seed::ROLE_FILE_WRITE_CONTENT_QUALIFIER);
    let mut qualifiers = modifiers.clone();
    for role in [
        seed::ROLE_FILE_WRITE_CONTENT_LEAD,
        "file_write_authoritative_content_lead",
    ] {
        for form in seed::lexicon()
            .role_word_forms(role)
            .into_iter()
            .filter(|form| form.slot() == Slot::Prefix)
        {
            let lead = form.before_slot().trim().to_lowercase();
            qualifiers.extend(modifiers.iter().filter_map(|modifier| {
                let (before, _) = lead.split_once(modifier.as_str())?;
                (before.is_empty() || before.chars().next_back().is_some_and(char::is_whitespace))
                    .then(|| lead[before.len()..].to_owned())
            }));
            qualifiers.push(lead);
        }
    }
    let mut led = raw.trim();
    loop {
        let separated = led.trim_start_matches([':', '-', '—', '–']).trim();
        let shortened = strip_leading_qualifier(separated, &qualifiers);
        if shortened.len() == led.len() {
            return led;
        }
        led = shortened;
    }
}
fn strip_leading_qualifier<'a>(text: &'a str, qualifiers: &[String]) -> &'a str {
    let lowered = text.to_lowercase();
    qualifiers
        .iter()
        .filter(|qualifier| lowered.starts_with(qualifier.as_str()))
        .filter_map(|qualifier| {
            let rest = text.get(qualifier.len()..)?.trim_start();
            rest.starts_with([':', '-', '—', '–']).then_some(rest)
        })
        .min_by_key(|rest| rest.len())
        .unwrap_or(text)
}
pub(super) fn safe_relative_path(path: &str) -> bool {
    !path.starts_with('/')
        && !path.starts_with('-')
        && !path.split('/').any(|part| part == ".." || part.is_empty())
        && path
            .chars()
            .all(|c| c.is_alphanumeric() || matches!(c, '/' | '.' | '_' | '-'))
}

/// Recover the `(target, old, new)` of a file-edit request from its wording.
///
/// Every cue comes from the seed lexicon. A target may be a safe relative path
/// or an unambiguous self-AST census reference; ambiguous spans fail closed.
#[must_use]
pub fn compose_edit_request(request: &str) -> Option<(String, String, String)> {
    compose_edit_clauses(request).map(|clauses| clauses.edit)
}

/// The `(target, old, new)` of an edit request and the spans its clauses take.
pub(super) struct EditClauses {
    /// What [`compose_edit_request`] returns.
    pub(super) edit: (String, String, String),
    /// The file clause, then the action through the new text, in bytes.
    ///
    /// `None` for a positional insert or lines under the request.
    pub(super) spans: Option<[(usize, usize); 2]>,
}

/// [`compose_edit_request`] with the spans of its clauses.
///
/// Mirrors `composeEditClauses`.
pub(super) fn compose_edit_clauses(raw: &str) -> Option<EditClauses> {
    // `everywhere`, `all occurrences`: no part of the old or new text (G84).
    let blanked = super::edit_scope::without_all_occurrence_cues(raw);
    let request = blanked.as_str();
    if let Some(edit) = super::positional_edit::compose_positional_insert(request) {
        return Some(EditClauses { edit, spans: None });
    }
    // `Replace the line 'x' with these three lines in f:` followed by lines: a
    // new clause that only describes lines (the seeded `line` meaning,
    // unquoted) stands for the lines under the request (PR #1188 G22).
    if let Some(block) = super::positional_edit::introduced_block(request)
        && let Some((target, old, new)) = compose_edit_request(block.head)
        && describes_lines(block.head, &new)
    {
        return Some(EditClauses {
            edit: (target, old, block.text),
            spans: None,
        });
    }
    let toks = tokens(request);
    let action_cues = bare_surfaces(seed::ROLE_FILE_EDIT_ACTION_CUE);
    let new_leads = bare_surfaces(seed::ROLE_FILE_EDIT_NEW_LEAD_CUE);
    let target_cues = bare_surfaces(seed::ROLE_FILE_EDIT_TARGET_CUE);
    let is_target_cue = |index: usize| target_cues.contains(&clean_cue_token(toks[index].text));
    let is_action_cue = |index: usize| action_cues.contains(&clean_cue_token(toks[index].text));
    let unquoted: Vec<usize> = super::positional_edit::unquoted_path_tokens(request)
        .iter()
        .map(|token| token.start)
        .collect();
    // A path the request leaves unquoted names the file before a literal that
    // is exactly a path does: in "Replace 'a' with 'data/x.lino' in f.mjs" the
    // quoted path is the new text, and the cue after it does not make it the
    // target.
    let segments = crate::normal_markov::quoted_segment_spans(request);
    let is_quoted = |token: &Token<'_>| {
        segments
            .iter()
            .any(|segment| token.start >= segment.start && token.end <= segment.end)
    };
    let is_path_candidate = |token: &Token<'_>| {
        let cleaned = clean_path_token(token.text);
        unquoted.contains(&token.start)
            && (super::general_planner::resolve_census_target(cleaned).is_some()
                || (looks_like_file_path(cleaned) && safe_relative_path(cleaned)))
    };
    let candidate = |quoted_pass: bool| {
        toks.iter().enumerate().find_map(|(index, token)| {
            let cleaned = clean_path_token(token.text);
            if !unquoted.contains(&token.start) || is_quoted(token) != quoted_pass {
                return None;
            }
            let resolved = super::general_planner::resolve_census_target(cleaned);
            if resolved.is_none()
                && (!looks_like_file_path(cleaned) || !safe_relative_path(cleaned))
            {
                return None;
            }
            let prev_is_cue = index
                .checked_sub(1)
                .is_some_and(|previous| is_target_cue(previous) || is_action_cue(previous));
            let next_is_cue =
                (index + 1 < toks.len()) && (is_target_cue(index + 1) || is_action_cue(index + 1));
            // A cue between two paths introduces the later one: in "…`p.lino``
            // in req.md" the payload's last span is no target (PR #1188 G63).
            let cue_introduces_next =
                !prev_is_cue && next_is_cue && toks.get(index + 2).is_some_and(is_path_candidate);
            let target = resolved.map_or_else(|| cleaned.to_owned(), |census| census.module_path);
            ((prev_is_cue || next_is_cue) && !cue_introduces_next).then_some((index, target))
        })
    };
    let (file_index, target) = candidate(false).or_else(|| candidate(true))?;
    // The file clause runs back over target cues and the seeded function words
    // between them (`in the file f.txt`) to its first cue (PR #1188 G98); a cue
    // word inside a quoted literal is payload ("… the named file.'").
    let function_words = bare_surfaces(FUNCTION_WORD_ROLE);
    let joins_clause = |index: usize| {
        !is_quoted(&toks[index])
            && (is_target_cue(index) || function_words.contains(&clean_cue_token(toks[index].text)))
    };
    let mut clause_start_index = file_index;
    for index in (0..file_index)
        .rev()
        .take_while(|&index| joins_clause(index))
    {
        if is_target_cue(index) {
            clause_start_index = index;
        }
    }
    let file_clause_start = toks[clause_start_index].start;
    // A cue word quoted whole is payload too: `replace 'with' with ','`.
    let is_cue = |token: &Token<'_>, cues: &[String]| {
        unquoted.contains(&token.start)
            && !is_quoted(token)
            && cues.contains(&clean_cue_token(token.text))
    };
    let action = toks
        .iter()
        .filter(|token| is_cue(token, &action_cues))
        .find(|token| token.start > toks[file_index].end)
        .or_else(|| toks.iter().find(|token| is_cue(token, &action_cues)))?;
    let action_end = action.end;
    let new_lead = toks
        .iter()
        .find(|token| token.start >= action_end && is_cue(token, &new_leads))?;
    // `Bump the version in package.json to 1.1.0`: a file clause right before
    // the new lead ends the old text; anything else between them is no edit.
    let file_between = file_clause_start >= action_end && file_clause_start < new_lead.start;
    if file_between
        && !request
            .get(toks[file_index].end..new_lead.start)?
            .trim()
            .is_empty()
    {
        return None;
    }
    let old_end = if file_between {
        file_clause_start
    } else {
        new_lead.start
    };
    let old_span = request.get(action_end..old_end)?;
    let sentence_end = prose_sentences(request)
        .into_iter()
        .find(|sentence| sentence.span.contains(&new_lead.end))
        .map_or_else(
            || request.len(),
            |sentence| {
                let raw = &request[sentence.span.clone()];
                sentence.span.start + (raw.len() - raw.trim_start().len()) + sentence.text.len()
            },
        );
    // A sentence boundary inside a quoted literal is payload: extend to its end.
    // When that literal ends early, because the backtick spans inside the
    // payload paired among themselves, a payload quoted whole up to the file
    // clause runs to it (PR #1188 G63), else to its own close (G107).
    let sentence_end = crate::normal_markov::quoted_segment_spans(request)
        .into_iter()
        .find(|segment| segment.start < sentence_end && sentence_end < segment.end)
        .map_or(sentence_end, |segment| {
            let whole = file_clause_start > segment.end
                && request
                    .get(new_lead.end..file_clause_start)
                    .is_some_and(crate::normal_markov::wrapped_in_quote_pair);
            if whole {
                file_clause_start
            } else {
                segment.end
            }
        });
    let new_end = if file_clause_start > new_lead.end {
        file_clause_start.min(sentence_end)
    } else {
        super::quote_nesting::whole_payload_end(request, new_lead.end, sentence_end)
    };
    let new_span = request.get(new_lead.end..new_end)?;
    let old = super::positional_edit::literal_text(old_span)?;
    let new = super::positional_edit::literal_text(new_span)?;
    // `Rename the file m.py to math_utils.py`: an unquoted new name that is a
    // workspace path renames the file itself, which is no edit of its bytes
    // (PR #1188 G24); the shell intents carry it.
    // Quoted, the new path renames the file too when the old clause quotes
    // nothing (`Rename the file 'a.txt' to 'b.txt'`, G37).
    let renamed_file = (crate::normal_markov::quoted_segment_spans(new_span).is_empty()
        || crate::normal_markov::quoted_segment_spans(old_span).is_empty())
        && looks_like_file_path(clean_path_token(new_span.trim()))
        && seed::lexicon().mentions_role(
            seed::ROLE_CODING_IDENTIFIER_RENAME_ACTION,
            &request.to_lowercase(),
        );
    (!renamed_file).then(|| EditClauses {
        edit: (target, old, new),
        spans: Some([
            (file_clause_start, toks[file_index].end),
            (action.start, new_end),
        ]),
    })
}

/// Whether a clause `text` of `head` is no quoted literal but words naming
/// lines (`these three lines`, `the following lines`, `эти строки`).
fn describes_lines(head: &str, text: &str) -> bool {
    !crate::normal_markov::quoted_segment_spans(head)
        .iter()
        .any(|segment| segment.text == text)
        && seed::lexicon().meaning("line").is_some_and(|meaning| {
            meaning.evidenced_in(&crate::engine::normalize_prompt(text).to_lowercase())
        })
}

/// Whether the payload starting at `from` is a block that outlives its first line.
///
/// A marker alone on its line already introduces the whole block below it, and
/// that is the shape this route was built for. The same request written with the
/// payload starting on the marker's own line -- "with exactly this content: #
/// Title\n\nbody..." -- means exactly the same thing, but the sentence bound cut
/// it at the first line and delivered a 58-byte file for a 1478-byte document.
///
/// That is not a bound the author of the request can see. It made every
/// multi-line literal write silently lossy: `alpha\nbeta\ngamma` was written as
/// `alpha`, and the self-authoring loop produced a one-line stub of the document
/// it was handed, which is how it looked broken while reporting success.
///
/// A payload whose first line ends but whose block continues is therefore read
/// to `limit`, exactly as the marker-only spelling always was. The sentence bound
/// still governs a payload that stays on one line, so "write the following: hello
/// to `x.txt`" is unaffected -- there is no continuation to find.
pub(super) fn payload_continues_past_its_first_line(
    request: &str,
    from: usize,
    sentence_end: usize,
) -> bool {
    let Some(tail) = request.get(from..) else {
        return false;
    };
    let Some(break_at) = tail.find('\n') else {
        return false;
    };
    // Only a payload the sentence bound would actually truncate qualifies: the
    // newline has to fall inside the sentence being cut, and real content has to
    // follow it. Otherwise the sentence bound is already returning the whole
    // payload and there is nothing to widen.
    from + break_at < sentence_end && tail[break_at..].chars().any(char::is_alphanumeric)
}
