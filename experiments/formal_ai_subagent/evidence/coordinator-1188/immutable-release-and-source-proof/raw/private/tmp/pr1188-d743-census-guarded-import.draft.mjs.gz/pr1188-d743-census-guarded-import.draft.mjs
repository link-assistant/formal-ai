import fs from 'node:fs';
import path from 'node:path';
import cp from 'node:child_process';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';

const root = '/Users/konard/Code/Archive/link-assistant/formal-ai';
const producerHead = 'd7437d4bcfc6d94823ebeba634de016f25561b41';
const producerPreview = '3f2fa833bea3451d33009323bcfd4f5f00d0c7f3';
const artifactRoot = '/private/tmp/pr1188-native-artifacts-d7437d4bc/37914168403/self-ast-census';
const expectedDigest = 'sha256:9ea925af617b342a0d55c8e81b2c626d8518ab3bba5248e7613b985c5bef7d48';
const apply = process.argv.includes('--apply');
const git = (...args) => cp.execFileSync('git', args, { cwd: root, maxBuffer: 16 * 1024 * 1024 });
const json = (filename) => JSON.parse(fs.readFileSync(filename, 'utf8'));
const sha256 = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');
const initialHead = git('rev-parse', 'HEAD').toString().trim();
const selectionPath = artifactRoot + '-artifact-selection.json';
const downloadPath = artifactRoot + '-download-complete.json';
const run = json('/private/tmp/pr1188-d743-native-census-run-api.json');
const officialArtifact = json('/private/tmp/pr1188-d743-native-census-artifact-api.json');
const preview = json('/private/tmp/pr1188-d743-census-merge-preview-source.json');
for (const receipt of [json(selectionPath), json(downloadPath)]) {
  assert.equal(receipt.head, producerHead);
  assert.equal(receipt.run, 37914168403);
  assert.equal(receipt.artifact, 11608916852);
  assert.equal(receipt.digest, expectedDigest);
}
// The original download happened while the workflow was still in progress.
// Preserve that receipt; the independent official completed-run API certifies success.
assert.equal(run.id, 37914168403);
assert.equal(run.head_sha, producerHead);
assert.equal(run.status, 'completed');
assert.equal(run.conclusion, 'success');
assert.equal(officialArtifact.id, 11608916852);
assert.equal(officialArtifact.name, 'self-ast-census');
assert.equal(officialArtifact.digest, expectedDigest);
assert.equal(officialArtifact.expired, false);
assert.equal(preview.sha, producerPreview);
assert.deepEqual(preview.parents, ['d209aac6461b355f1a527831202af3423135f7e6', producerHead]);
assert.equal(preview.tree, git('rev-parse', producerHead + '^{tree}').toString().trim());
const producerLog = fs.readFileSync('/private/tmp/pr1188-d743-native-census-job-113766201704.log', 'utf8');
assert.match(producerLog, new RegExp('git log -1 --format=%H\\r?\\n[^\\n]*' + producerPreview));
const { stableId } = await import(pathToFileURL(root + '/js/agentic/crate/engine_stable_identifier.mjs').href);
function walk(folder) {
  return fs.readdirSync(folder, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))
    .flatMap((entry) => entry.isDirectory() ? walk(path.join(folder, entry.name)) : [path.join(folder, entry.name)]);
}
const moduleFiles = walk(artifactRoot + '/data/meta/self-ast').filter((file) => file.endsWith('.lino'));
const producerSources = git('ls-tree', '-r', '--name-only', producerHead, '--', 'rust/src')
  .toString().trim().split('\n').filter((file) => file.endsWith('.rs')).sort();
const seen = new Set();
const records = [];
const observations = new Map();
for (const file of moduleFiles) {
  const bytes = fs.readFileSync(file);
  const document = bytes.toString('utf8');
  const target = document.match(/^  target (src\/[^\n]+\.rs)$/m)?.[1];
  assert.ok(target && !target.split('/').includes('..'), file);
  const source = 'rust/' + target;
  assert.ok(!seen.has(source), source);
  seen.add(source);
  const sourceBytes = git('show', producerHead + ':' + source);
  assert.equal(Number(document.match(/^  byte_len (\d+)$/m)?.[1]), sourceBytes.length, source);
  assert.equal(document.match(/^  content_id (\S+)$/m)?.[1], stableId('source_module', sourceBytes.toString('utf8')), source);
  const currentBytes = fs.readFileSync(path.join(root, source));
  const fresh = currentBytes.equals(sourceBytes);
  observations.set(source, { producer: sourceBytes, current: currentBytes });
  const relative = path.relative(artifactRoot, file);
  const destination = path.join(root, relative);
  records.push({ path: relative, source, producerSourceSha256: sha256(sourceBytes), currentSourceSha256: sha256(currentBytes), artifactSha256: sha256(bytes), artifactBytes: bytes.length, changed: !fs.existsSync(destination) || !fs.readFileSync(destination).equals(bytes), status: fresh ? 'EligibleExactProducerAndCurrentSource' : 'RefusedCurrentSourceFreshnessMismatch' });
}
assert.deepEqual([...seen].sort(), producerSources, 'Every producer Rust source must have exactly one genuine native module census');
const plannerSource = 'rust/src/agentic_coding/planner.rs';
const plannerFresh = observations.get(plannerSource).current.equals(observations.get(plannerSource).producer);
for (const relative of ['data/meta/self-ast/README.md', 'data/meta/self-ast.lino', 'data/meta/self-healing-case.lino', 'docs/case-studies/issue-538/agent-cli-session-self-ast.json']) {
  const bytes = fs.readFileSync(path.join(artifactRoot, relative));
  const destination = path.join(root, relative);
  const source = relative.endsWith('/README.md') ? null : plannerSource;
  records.push({ path: relative, source, artifactSha256: sha256(bytes), artifactBytes: bytes.length, changed: !fs.existsSync(destination) || !fs.readFileSync(destination).equals(bytes), status: !source || plannerFresh ? 'EligibleExactProducerAndCurrentSource' : 'RefusedCurrentSourceFreshnessMismatch' });
}
assert.equal(git('rev-parse', 'HEAD').toString().trim(), initialHead, 'HEAD changed during source audit');
if (apply) {
  // Root invokes --apply only through a Formal AI Bash tool after reviewing this draft.
  for (const record of records) {
    if (record.status.startsWith('Refused')) continue;
    if (record.source && !fs.readFileSync(path.join(root, record.source)).equals(observations.get(record.source).producer)) {
      record.status = 'RefusedSourceChangedAfterAudit';
      continue;
    }
    if (record.changed) {
      const destination = path.join(root, record.path);
      fs.mkdirSync(path.dirname(destination), { recursive: true });
      const temporary = destination + '.native-census-import';
      fs.copyFileSync(path.join(artifactRoot, record.path), temporary);
      fs.renameSync(temporary, destination);
      assert.equal(sha256(fs.readFileSync(destination)), record.artifactSha256, record.path);
    }
    record.status = 'ImportedExactArtifactWithCurrentSourceGuard';
  }
  assert.equal(git('rev-parse', 'HEAD').toString().trim(), initialHead, 'HEAD changed during guarded import');
  for (const record of records.filter((item) => item.source && item.status.startsWith('Imported'))) {
    assert.ok(fs.readFileSync(path.join(root, record.source)).equals(observations.get(record.source).producer), 'Source changed during import: ' + record.source);
  }
}
const refused = records.filter((record) => record.status.startsWith('Refused'));
const header = { producerHead, actualProducerCheckout: producerPreview, producerTree: preview.tree, run: 37914168403, job: 113766201704, artifact: 11608916852, artifactDigest: expectedDigest, mode: apply ? 'FormalAIOnlyGuardedApply' : 'ReadOnlyAuditNoRepositoryMutation', currentHeadAtAudit: initialHead, modules: moduleFiles.length, refusedCurrentSources: refused.map((record) => record.source).filter(Boolean), currentWholeCensusFresh: refused.length === 0, scope: 'All artifact module identities validated against git show d743. Current-source mismatches are explicitly refused and never relabeled as current; unchanged source documents may be imported byte-exact. Original merge-preview and in-progress download receipts remain preserved.' };
const destination = apply ? path.join(root, 'experiments/formal_ai_subagent/evidence/coordinator-1188/native-census-d7437d4bc-copy-manifest.json') : '/private/tmp/pr1188-d743-census-source-guard-audit.json';
if (apply) fs.mkdirSync(path.dirname(destination), { recursive: true });
fs.writeFileSync(destination, JSON.stringify(header, null, 2).slice(0, -2) + ',\n  "files": [\n' + records.map((record) => '    ' + JSON.stringify(record)).join(',\n') + '\n  ]\n}\n');
console.log(JSON.stringify({ mode: header.mode, modules: moduleFiles.length, selectedFiles: records.length, changedEligible: records.filter((record) => record.changed && !record.status.startsWith('Refused')).length, refusedCurrentSources: header.refusedCurrentSources, manifest: destination }));
