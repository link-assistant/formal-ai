# Agent CLI binary-tree ladder run

Joined from 16 exact planned leg(s).

- requested depth: 5
- node filter: none
- authored rules enabled: true
- source commit: 3f2fa833bea3451d33009323bcfd4f5f00d0c7f3
- source tree: 9b30e015a5666699cc8663476f650e6988c12672
- tree sha256: b94ba79a97ac470afd8ec8fb01306dc6301ed19b85b81e0736acc95952a3b80d
- leaves sha256: 2d21038e7c16de397357f69786424060a6233adf0db796e276843d1af1300920
- selected nodes: 32
- failures: 32
- deepest passing level: none
- leaf nodes selected: 32
- leaf nodes passing: 0

| node | verdict | detail |
| --- | --- | --- |
| 1.1.1.1.1 | FAIL | missing_proof |
| 1.1.1.1.2 | FAIL | missing_proof |
| 1.1.1.2.1 | FAIL | missing_proof |
| 1.1.1.2.2 | FAIL | missing_effect |
| 1.1.2.1.1 | FAIL | missing_proof |
| 1.1.2.1.2 | FAIL | missing_proof |
| 1.1.2.2.1 | FAIL | missing_effect |
| 1.1.2.2.2 | FAIL | missing_proof |
| 1.2.1.1.1 | FAIL | missing_proof |
| 1.2.1.1.2 | FAIL | missing_proof |
| 1.2.1.2.1 | FAIL | missing_proof |
| 1.2.1.2.2 | FAIL | missing_effect |
| 1.2.2.1.1 | FAIL | missing_proof |
| 1.2.2.1.2 | FAIL | missing_effect |
| 1.2.2.2.1 | FAIL | missing_effect |
| 1.2.2.2.2 | FAIL | missing_effect |
| 2.1.1.1.1 | FAIL | missing_effect |
| 2.1.1.1.2 | FAIL | missing_effect |
| 2.1.1.2.1 | FAIL | missing_effect |
| 2.1.1.2.2 | FAIL | missing_effect |
| 2.1.2.1.1 | FAIL | missing_effect |
| 2.1.2.1.2 | FAIL | missing_effect |
| 2.1.2.2.1 | FAIL | missing_effect |
| 2.1.2.2.2 | FAIL | missing_effect |
| 2.2.1.1.1 | FAIL | missing_effect |
| 2.2.1.1.2 | FAIL | missing_effect |
| 2.2.1.2.1 | FAIL | missing_effect |
| 2.2.1.2.2 | FAIL | missing_effect |
| 2.2.2.1.1 | FAIL | missing_effect |
| 2.2.2.1.2 | FAIL | missing_effect |
| 2.2.2.2.1 | FAIL | missing_effect |
| 2.2.2.2.2 | FAIL | missing_effect |
