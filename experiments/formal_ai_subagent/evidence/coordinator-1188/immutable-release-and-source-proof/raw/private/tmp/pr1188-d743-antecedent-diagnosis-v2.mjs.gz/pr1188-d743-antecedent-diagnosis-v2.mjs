import {WorkerHost} from '/Users/konard/Code/Archive/link-assistant/formal-ai/js/server/worker-host.mjs';
import {writeFileSync} from 'node:fs';
const host=new WorkerHost();const first=await host.solve('What is Rust?');const history=[{role:'user',content:'What is Rust?'},{role:'assistant',content:first.content}];
const data={first,matching:await host.run('({bounded:surfacePresent("what is rust?","rust"),antecedent:nearestCoreferenceAntecedent(__turns),contexts:matchingCoreferencePronoun(normalizePrompt("Who created it?"))})',{__turns:history}),bounded:await host.solve('Who created it?',history)};
await host.run('matchingCoreferenceAntecedent=function(previous){return COREFERENCE_SEEDS.antecedents.find(antecedent=>antecedent.aliases.some(alias=>alias&&previous.includes(alias)))||null;}; true');data.raw=await host.solve('Who created it?',history);
writeFileSync('/private/tmp/pr1188-d743-antecedent-boundary-diagnosis.json',JSON.stringify(data,null,2));console.log(JSON.stringify({bounded:data.bounded.intent,raw:data.raw.intent,matching:data.matching}));
