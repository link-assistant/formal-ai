import {readFile} from 'node:fs/promises';
const selected=['js/agentic/requirement_resolution.mjs','rust/tests/web/requirement-seed-target-binding.test.mjs','rust/tests/web/worker-native-handler-parity.test.mjs'];
export async function load(url,context,nextLoad){
 const selectedPath=selected.find(path=>url.endsWith('/'+path));
 if(selectedPath)return{format:'module',source:await readFile('/private/tmp/pr1188-d743-runtime-binding-candidates/'+selectedPath,'utf8'),shortCircuit:true};
 if(url.endsWith('/js/server/worker-host.mjs')){
  const result=await nextLoad(url,context);let source=Buffer.from(result.source).toString();
  source=source.replace('const source = readFileSync(absolute, "utf8");','const source = readFileSync(["formal_ai_worker_coreference.js", "formal_ai_worker_solve.js"].includes(path.basename(absolute)) ? "/private/tmp/pr1188-d743-runtime-binding-candidates/js/worker/" + path.basename(absolute) : absolute, "utf8");');
  return {...result,source};
 }
 return nextLoad(url,context);
}
