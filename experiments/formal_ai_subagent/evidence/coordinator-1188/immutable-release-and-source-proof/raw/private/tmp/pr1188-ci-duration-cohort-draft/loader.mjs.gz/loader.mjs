import { readFileSync } from 'node:fs';
export async function load(url, context, nextLoad) {
  if (url.endsWith('/scripts/lib/ci-speed-durations.mjs')) return {
    format: 'module', shortCircuit: true,
    source: readFileSync('/private/tmp/pr1188-ci-duration-cohort-draft/ci-speed-durations.mjs', 'utf8'),
  };
  return nextLoad(url, context);
}
