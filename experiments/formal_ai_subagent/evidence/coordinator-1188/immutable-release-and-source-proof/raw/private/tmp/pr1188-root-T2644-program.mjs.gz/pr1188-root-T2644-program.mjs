import fs from 'node:fs';import path from 'node:path';import {pathToFileURL} from 'node:url';import {execFileSync} from 'node:child_process';
const root='/Users/konard/Code/Archive/link-assistant/formal-ai';process.chdir(root);
const command=args=>execFileSync(process.execPath,args,{encoding:'utf8',maxBuffer:16*1024*1024,timeout:180000});
const {measureCodingRun}=await import(pathToFileURL(path.join(root,'experiments/formal_ai_subagent/coding-amplification.mjs')).href);
const original=JSON.parse(fs.readFileSync('/private/tmp/pr1188-root-T2639.json','utf8'));
const observed=original.result.transcript.map(item=>typeof item.result==='string'?item.result:JSON.stringify(item.result));
const measured=await measureCodingRun({taskKind:'self-coding',origin:'autonomous',task:original.prompt,attemptInputs:[original.prompt],repositoryContext:[observed[0]],reviewedPatches:[],toolReceipts:observed.slice(1),changes:[]},async()=>({passed:false,bindings:[],checks:[]}));
if(measured.taskInputBytes!==482||measured.totalObservedInputBytes!==6707||measured.accepted||measured.autonomousNetCodeBytes!==0)throw new Error('actual compact task accounting');
fs.writeFileSync('/private/tmp/pr1188-root-T2639-amplification.json',JSON.stringify({task:'T2639',raw_record:'/private/tmp/pr1188-root-T2639.json',observed_repo_writes:0,measurement:measured},null,2)+'\n');
const output=command(['--test','rust/tests/web/coding-amplification.test.mjs','rust/tests/web/source-qualified-definition.test.mjs','rust/tests/web/arithmetic-source-registry.test.mjs']);fs.writeFileSync('/private/tmp/pr1188-root-T2644-nearest.log',output);
const boundary=command(['scripts/check-minimal-core-boundary.mjs']);fs.writeFileSync('/private/tmp/pr1188-root-T2644-boundary.log',boundary);
const rows=[
 ['T2639r','Original compact-input coding/self-coding measurement requirement, actual JavaScript planner.','**Fail**: two Reads, absent target, zero writes;482 original task bytes and6707 total observed input bytes.','Open G112 autonomous synthesis; reviewed instrumentation does not close the original; zero validated autonomous output.'],
 ['T2640r','Reviewed measurement/requirement/guideline through Formal AI Bash.','**Fail after source writes and ten nearest checks passed**: invalid absolute import from a data URL.','**Fixed T2644** with file URLs/raw receipts; all failed runner requests/results retained; reviewed source is not autonomous synthesis.'],
 ['T2641r','Recover measurement runner import URL.','**Fail after unchanged ten checks passed**: unnecessary transport normalizer required an uninstalled worker host.','**Fixed T2644** by counting exact observed raw receipts; original failure retained.'],
 ['T2642r','Count raw observed inputs without planner transport normalization.','**Fail after ten checks and actual measurement passed**: extracted operational script omitted its source local declaration.','**Fixed T2644** with explicit declarations and unchanged checks; measurement remains482/6707/0 bytes; original failure retained.'],
 ['T2643r','Guarded actual CI capture syntax/public API/test placement/docs/category/count repair through Formal AI.','**Fail after physical changes, exact three body SHA/time identities, affected JS checks and core boundary passed**: ledger identifier collided with historical CI task.','**Fixed T2644** using coordinator-suffixed ledger IDs. Exact capture bytes retained; native canonical0.23/API execution still pending next CI.'],
 ['T2644r','Finalize truthful compact-input measurement and retained integration failures with unique ledger identities.','Before: source changes and nearest checks passed; runner and ledger operational failures retained.','**Pass**: unchanged coding-amplification/source-qualified-definition/arithmetic-source-registry suites and core88/18602 pass; exact original input/context/receipt bytes measured; original broad task and cost/representative self-coding baseline remain Open.']
];
const ledger='docs/case-studies/pull-request-1188/formal-ai-dogfood.md';let source=fs.readFileSync(ledger,'utf8');
for(const row of rows){if(source.includes('| '+row[0]+' |'))throw new Error('duplicate coordinator ledger');source+='\n| '+row.join(' | ')+' |';}
fs.writeFileSync(ledger,source+'\n');
command(['scripts/tally-formal-ai-dogfood.mjs','--write']);const tally=command(['scripts/tally-formal-ai-dogfood.mjs','--check']);fs.writeFileSync('/private/tmp/pr1188-root-T2644-tally.log',tally);
console.log(output.slice(-1100));console.log(boundary.trim());console.log(JSON.stringify({taskInputBytes:measured.taskInputBytes,totalObservedInputBytes:measured.totalObservedInputBytes,validatedAutonomousBytes:0}));console.log('COMPACT_INPUT_AND_CAPTURE_FINALIZATION_PASS');
