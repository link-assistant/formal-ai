| T3600 | Implement a generic browser conversation-summary detail view in the selected scratch directory, based on the actual source in js/app/message-view.jsx, | FAIL source missing; no Write | Open G112; selected-precondition retry T3609 still source echo/no implementation |
| T3601 | Set the contents of history-ui-draft/setup.mjs to exactly this content: ````````````text import {mkdirSync,copyFileSync,writeFileSync,symlinkSync,exis | PASS FA writes reviewed selected-source setup | Pass byte-equal reviewed source |
| T3602 | Run node history-ui-draft/setup.mjs | FAIL setup EISDIR neutral reviewed mkdir defect | Fixed reviewed setup T3604; exact command T3605 PASS |
| T3603 | Run node setup.mjs | FAIL same setup EISDIR | Fixed T3604; exact command T3607 PASS |
| T3604 | Set the contents of history-ui-draft/setup.mjs to exactly this content: ````````````text import {mkdirSync,copyFileSync,writeFileSync,symlinkSync,exis | PASS corrected reviewed fixture setup via FA | Pass exact setup retries3605/3607 |
| T3605 | Run node history-ui-draft/setup.mjs | PASS exact T3602 setup request | Pass five genuine selected source snapshots |
| T3606 | Set the contents of history-ui-draft/js/app/conversation-summary-details.js to exactly this content: ````````````text // UI details over actual preced | PASS reviewed helper applied via FA | Pass byte-equal authored helper |
| T3607 | Run node setup.mjs | PASS exact T3603 setup request | Pass actual selected source preconditions |
| T3608 | Set the contents of history-ui-draft/prepare-ui.mjs to exactly this content: ````````````text import {readFileSync,writeFileSync} from 'node:fs'; impo | PASS reviewed contextual patcher applied | Pass byte-equal source guard patcher |
| T3609 | Implement a generic browser conversation-summary detail view in the selected scratch directory, based on the actual source in js/app/message-view.jsx, | FAIL exact broad T3600 retry; source echo/read only | Open G112; supplied reviewed literal patches are separate |
| T3610 | Set the contents of history-ui-draft/js/app/conversation-summary-details.js to exactly this content: ````````````text // UI details over actual preced | PASS helper rejects malformed evidence | Pass byte-equal reviewed guard |
| T3611 | Run node prepare-ui.mjs | PASS eight source-SHA guarded scratch hunks | Pass production untouched |
| T3612 | Set the contents of history-ui-draft/history-ui.test.mjs to exactly this content: ````````````text import test from 'node:test'; import assert from 'n | PASS focused fixture applied via FA | Pass byte-equal fixture |
| T3613 | Run node --test history-ui.test.mjs | FAIL actual7/8; locale fixture API misuse | Fixed T3614 actual third-argument locale options; exact command T3616 PASS8/8 |
| T3614 | Set the contents of history-ui.test.mjs to exactly this content: ````````````text import test from 'node:test'; import assert from 'node:assert/strict | PASS reviewed fixture uses actual i18n options API | Pass exact8/8 replay T3616 |
| T3615 | Set the contents of browser-check.mjs to exactly this content: ````````````text import {readFileSync,writeFileSync,statSync} from 'node:fs'; import {c | PASS scratch-only Browser build/server fixture applied | Pass byte-equal fixture |
| T3616 | Run node --test history-ui.test.mjs | PASS exact T3613 focused command8/8 | Pass real3language canonical WorkerHost answers +4UIlocales +negative controls |
| T3617 | Run bun browser-check.mjs | FAIL local listener restricted; command timed out | Fixed execution permission only; exact command T3618 PASS4/4 original Browser assertions |
| T3618 | Run bun browser-check.mjs | PASS exact T3617 command in approved local listener context | Pass4/4 unchanged original Browser programs7.3s |
