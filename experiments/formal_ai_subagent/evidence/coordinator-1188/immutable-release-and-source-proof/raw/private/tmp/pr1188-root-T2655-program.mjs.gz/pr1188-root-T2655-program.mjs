import fs from 'node:fs';import{execFileSync}from'node:child_process';process.chdir('/Users/konard/Code/Archive/link-assistant/formal-ai');
const files=JSON.parse(fs.readFileSync('/private/tmp/pr1188-root-T2655-authored-files.json','utf8'));
for(const [file,text]of Object.entries(files)){if(fs.existsSync(file))throw Error('new authored path exists: '+file);fs.writeFileSync(file,text);}
const replace=(file,old,next)=>{const source=fs.readFileSync(file,'utf8');if(source.split(old).length!==2)throw Error('unique doc preimage: '+file);fs.writeFileSync(file,source.replace(old,()=>next));};
replace('docs/requirements/issue-1188-coding-amplification.md','| R1188-U31 | For coding and self-coding, Formal AI should usually turn','| R1188-U31 | For expansion-suitable coding and self-coding, Formal AI should usually turn');
fs.appendFileSync('docs/requirements/issue-1188-coding-amplification.md','| R1188-U35 | Declare each task category and expected input/output size relation before execution. Aim for almost-always expansion for feature/test construction and detailed explanations/proofs; track compression for decisions, numeric calculations, extraction and summaries, and unrestricted repair/refactoring/deletion/translation. Validate usefulness independently, retain failed attempts and exceptions, and never pad outputs or reclassify the cohort after observing outcomes. | Partial: `experiments/formal_ai_subagent/task-relations.mjs` binds original tasks and saved category declarations to exact source/response acceptance and complete cohorts; `rust/tests/web/task-relations.test.mjs` checks real calculation/decision outputs, useful deletion, expansion, source drift, reclassification and failures. The recorded objective is at least95% accepted matching tasks over at least20 declared tasks per category. These are instrumentation fixtures, not a representative Formal AI performance baseline. |\n');
replace('docs/case-studies/pull-request-1188/coding-amplification.md','This is R1188-U31 through R1188-U34 in','This is R1188-U31 through R1188-U35 in');
fs.appendFileSync('docs/case-studies/pull-request-1188/coding-amplification.md',`
## Expected relation by task category

Classify the task before executing it and save the original task/category declaration
with the attempt receipt. Input size alone never establishes output quality.
A large repository-aware change can follow a concise request; an excellent repair
may delete code, reuse a function or change one character. A calculation's numeric
result compresses the problem, whereas a requested proof expands its explanation.
The classification follows the requested deliverable, rather than its broad subject.

| Task category | Expected useful output versus original task | Conditions and exceptions |
| --- | --- | --- |
| Feature implementation; independent test construction | Larger | New behavior and meaningful tests; exclude supplied patches and generated mirrors from autonomous net code. A feature completed mainly by reuse may be a valuable recorded exception. |
| Detailed explanation; mathematical proof | Larger | Only independently accepted content counts. A short proof or familiar explanation can be a valid exception. |
| Yes/no decision; numeric calculation | Smaller | Check the actual decision or value; a requested explanation/proof belongs to its separately declared category. |
| Extraction; summarization | Smaller | Preserve required source facts and scope. Tiny inputs or requested detail can be valid exceptions. |
| Repair; refactoring; deletion | Unrestricted | Check resulting behavior and removed code without requiring positive net growth. |
| Translation | Unrestricted | Source/target languages and preservation constraints determine size; no universal direction. |

`experiments/formal_ai_subagent/task-relations.mjs` binds declarations to the
original task, stable identity, category and expected relation. A complete saved
cohort rejects changed categories, duplicate runs and omitted failures. For code,
it retains the independently validated autonomous net lexical proxy. For other
tasks, it requires independent checks bound to the exact UTF-8 response SHA-256.
Response length still needs content review; expanding prose does not prove usefulness.
The original-task ratio and ratio against every observed input are both reported.
These ratios cannot be compared across code proxies and response bytes as one metric.

“Almost always” is an improvement objective of at least95% accepted matching tasks
over at least20 declared attempts in each eligible category. Every failed attempt
counts against this share; unrestricted categories have no size-performance target.
CI currently checks this accounting and independent acceptance with fixtures. It does
not enforce an unobserved performance baseline. Record actual representative Formal AI
runs and exceptions before adopting a reviewed performance ratchet. This objective
never makes a correct small answer or focused repair unacceptable.
`);
replace('docs/case-studies/pull-request-1188/handoff.md','R1188-U31 through R1188-U34','R1188-U31 through R1188-U35');
replace('experiments/formal_ai_subagent/requirement-coverage.lino','  rows R1188-U31 R1188-U32 R1188-U33 R1188-U34','  rows R1188-U31 R1188-U32 R1188-U33 R1188-U34 R1188-U35');
replace('docs/case-studies/pull-request-1188/multi-agent-workflow.md','The initial CI checks verify accounting, not a claimed autonomous success baseline.','Declare the task category before execution: feature/test construction and detailed proof/explanation target expansion; decisions/calculations/extraction/summaries target compression; repair/refactoring/deletion/translation have unrestricted size. Report exceptions and a complete cohort; the near-universal improvement objective is95% accepted matching tasks over at least20 attempts per category. The initial CI checks verify accounting, not a claimed autonomous success baseline.');
const output=execFileSync(process.execPath,['--test','rust/tests/web/coding-amplification.test.mjs','rust/tests/web/task-relations.test.mjs'],{encoding:'utf8',maxBuffer:16*1024*1024,timeout:180000});fs.writeFileSync('/private/tmp/pr1188-root-T2655-nearest.log',output);
const ledger='docs/case-studies/pull-request-1188/formal-ai-dogfood.md';let rows=fs.readFileSync(ledger,'utf8');if(rows.includes('| T2654r |')||rows.includes('| T2655r |'))throw Error('duplicate IDs');rows+='\n| T2654r | Ask real JavaScript Formal AI to implement task-category expansion/compression measurement from the unchanged concise behavior request. | Original task retained; advertised tools available. | **Fail no-plan**: zero tool calls or writes. No autonomous category implementation claimed. General reviewed instrumentation repair T2655r; unchanged retry remains separately measured. |\n| T2655r | Apply reviewed general task-category measurement through Formal AI, including predeclared identity, response binding, full cohort and independent acceptance. | Expansion/compression/unrestricted taxonomy records the owner request; 95% objective requires20 declared tasks, no unobserved hard performance gate. Supplied source is explicitly reviewed work. | **Pass18 accounting/behavior controls**: original12 controls plus six category controls execute arithmetic, primality and code, reject false answers/source drift/reclassification/missing runs, retain failures and useful deletion. Fixtures are not representative Formal AI task success or token savings. |\n';fs.writeFileSync(ledger,rows);execFileSync(process.execPath,['scripts/tally-formal-ai-dogfood.mjs','--write']);console.log(output.slice(-1100));console.log('TASK_CATEGORY_RELATION_INSTRUMENTATION_PASS');
