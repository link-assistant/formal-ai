import fs from 'node:fs';import {execFileSync} from 'node:child_process';import {pathToFileURL} from 'node:url';import {createHash} from 'node:crypto';
const root='/Users/konard/Code/Archive/link-assistant/formal-ai';process.chdir(root);
const draft=JSON.parse(fs.readFileSync('/private/tmp/pr1188-amplification-integrity-reviewed.json','utf8'));
const module=await import(pathToFileURL(root+'/experiments/formal_ai_subagent/coding-amplification.mjs').href);
const baseline={runId:'baseline',taskKind:'coding',origin:'autonomous',task:'Add sum.',attemptInputs:['Add sum.'],repositoryContext:[],reviewedPatches:[],toolReceipts:[],changes:[]};
let thrown=null;try{await module.measureCodingRun(baseline,async()=>{throw new SyntaxError('held-out verifier failure');});}catch(error){thrown={name:error.name,message:error.message};}
const duplicated=module.summarizeCodingRuns(Array(3).fill({taskKind:'coding',accepted:true,taskAmplification:2}));
fs.writeFileSync('/private/tmp/pr1188-root-T2645-before.json',JSON.stringify({thrown,duplicated},null,2)+'\n');
if(!thrown||!duplicated.coding.usuallyAmplifies)throw new Error('original integrity defects no longer reproduced');
const sources=new Map(),next=new Map();
for(const op of draft.operations){if(!sources.has(op.path)){const source=fs.readFileSync(op.path,'utf8');sources.set(op.path,source);next.set(op.path,source);}
 if(createHash('sha256').update(sources.get(op.path)).digest('hex')!==op.source_sha256)throw new Error('source drift');
 const source=next.get(op.path);if(source.split(op.old).length!==2)throw new Error('unique preimage');next.set(op.path,source.replace(op.old,()=>op.new));}
for(const [file,source]of next)fs.writeFileSync(file,source);
const output=execFileSync(process.execPath,['--test','rust/tests/web/coding-amplification.test.mjs'],{encoding:'utf8',maxBuffer:16*1024*1024,timeout:180000});fs.writeFileSync('/private/tmp/pr1188-root-T2645-nearest.log',output);
const ledger='docs/case-studies/pull-request-1188/formal-ai-dogfood.md';let source=fs.readFileSync(ledger,'utf8');if(source.includes('| T2645r |'))throw new Error('duplicate ID');
source+='\n| T2645r | Reproduce and repair measurement integrity classes through Formal AI. | **Fail before repair**: thrown verifier discarded the measurement; repeated passing measurement falsely reported three amplified tasks. | **Pass**: coding-amplification.test.mjs original checks plus thrown-verifier retention and declared/unique/complete cohort controls pass. Source/context bytes remain separate; representative actual self-coding and cost baselines remain Open. |\n';fs.writeFileSync(ledger,source);
execFileSync(process.execPath,['scripts/tally-formal-ai-dogfood.mjs','--write'],{encoding:'utf8',maxBuffer:16*1024*1024,timeout:180000});console.log(output.slice(-1200));console.log('AMPLIFICATION_FAILURE_AND_COHORT_INTEGRITY_PASS');
