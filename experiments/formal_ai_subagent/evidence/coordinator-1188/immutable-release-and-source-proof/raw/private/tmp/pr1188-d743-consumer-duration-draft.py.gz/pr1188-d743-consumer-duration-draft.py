import json,re,hashlib,math
from pathlib import Path
from datetime import datetime
root=Path.cwd();src=root/'data/meta/ci-durations.lino';text=src.read_text();api_path=Path('/private/tmp/pr1188-d743-desktop-consumer-jobs-api-latest.json');api=json.loads(api_path.read_text()); jobs=api['jobs']; final=json.loads(Path('/private/tmp/pr1188-d743-last-desktop-linux-job-api-progress4.json').read_text()); jobs=[final if j['id']==final['id'] else j for j in jobs]; parse=lambda x:datetime.fromisoformat(x.replace('Z','+00:00'))
rows=[];ops=[]
for j in jobs:
 name=j['name']
 if not(name.startswith('Build CLI ') or (name.startswith('Build ') and not name.startswith('Build native '))):continue
 assert j['conclusion']=='success',name
 starts=[s['started_at'] for s in j['steps'] if s.get('started_at')]; actual_start=min(starts); sec=(parse(j['completed_at'])-parse(actual_start)).total_seconds(); minutes=math.ceil(sec/6)/10; key='cli' if name.startswith('Build CLI ') else 'build'
 pattern=r'    job '+re.escape(json.dumps(name))+r'\n      key '+key+r'\n      median [^\n]+\n      maximum [^\n]+\n      samples [^\n]+\n'
 found=re.findall(pattern,text);assert len(found)==1,(name,len(found))
 old=found[0];new=f'    job {json.dumps(name)}\n      key {key}\n      median {minutes:g}\n      maximum {minutes:g}\n      samples 1\n      execution-cohort same-run-native-reuse\n      source-head {j["head_sha"]}\n      run {j["run_id"]}\n      job-id {j["id"]}\n      runner-start {actual_start}\n      job-completed {j["completed_at"]}\n'
 ops.append({'path':'data/meta/ci-durations.lino','source_sha256':hashlib.sha256(text.encode()).hexdigest(),'old':old,'new':new})
 rows.append({'name':name,'key':key,'job':j['id'],'run':j['run_id'],'source_head':j['head_sha'],'runner_start':actual_start,'api_started_at':j['started_at'],'job_completed':j['completed_at'],'seconds':sec,'minutes':minutes,'conclusion':j['conclusion'],'native_verification':next(s for s in j['steps'] if s['name']=='Verify native receipt, bytes and startup before packaging')})
assert len(rows)==11,len(rows)
# Selected immutable archive preserves the complete previous file, not just discarded aggregates.
archive=Path('/private/tmp/pr1188-d743-ci-durations-before-native-reuse.lino');archive.write_bytes(src.read_bytes())
Path('/private/tmp/pr1188-d743-consumer-duration-cohort-audit.json').write_text(json.dumps({'head':'d7437d4bcfc6d94823ebeba634de016f25561b41','run':37914168811,'official_sources':[str(api_path),'/private/tmp/pr1188-d743-last-desktop-linux-job-api-progress4.json'],'historical_archive':str(archive),'historical_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'cohort':'same-run-native-reuse','queue_excluded':True,'rows':rows,'regeneration_limitation':'Existing generic ten-run generator matches display names only and would blend the obsolete cold-compile graph; this bounded official API collector selects exact source/run and records actual first runner step. No future graph-independent timing attribution is claimed.'},indent=2)+'\n')
Path('/private/tmp/pr1188-d743-consumer-duration-cohort-replacements.json').write_text(json.dumps(ops,indent=2)+'\n')
print(json.dumps({'rows':len(rows),'desktop_max_minutes':max(r['minutes'] for r in rows if r['key']=='build'),'cli_max_minutes':max(r['minutes'] for r in rows if r['key']=='cli')}))
