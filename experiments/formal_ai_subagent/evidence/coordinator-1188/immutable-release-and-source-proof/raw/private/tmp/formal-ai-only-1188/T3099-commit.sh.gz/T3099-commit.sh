#!/bin/sh
set -eu
commit_lock=/private/tmp/formal-ai-pr1188-commit.lock
attempt=0
while ! mkdir "$commit_lock" 2>/dev/null; do
  attempt=$((attempt + 1))
  if [ "$attempt" -ge 30 ]; then echo 'Shared commit lock unavailable'; exit 1; fi
  sleep 1
done
private_index_dir=$(mktemp -d /private/tmp/formal-ai-literal-routing-index-XXXXXX)
trap 'rm -rf "$private_index_dir"; rmdir "$commit_lock"' EXIT HUP INT TERM
captured_head=$(git rev-parse HEAD)
export GIT_INDEX_FILE="$private_index_dir/index"
git read-tree "$captured_head"
git add -- js/agentic/capability_router.mjs rust/src/agentic_coding/capability_router.rs rust/tests/web/literal-write-request-scope.test.mjs rust/tests/fixtures/literal-obligation-transaction.rs changelog.d/20261009_234000_literal-routing-original-operands.md
git add -f -- experiments/formal_ai_subagent/evidence/formal-ai-only-1188/literal-routing-ownership
git diff --cached --check
current_head=$(git rev-parse HEAD)
[ "$current_head" = "$captured_head" ]
new_tree=$(git write-tree)
cat > "$private_index_dir/message" <<'MSG'
Keep original literal ownership through capability routing

Separate classification text from the original operand-bearing request block.
Fallback Write calls require the shared statement-bound literal contract and
retain its exact target/content instead of independently guessing both.
Preserve original native cross-statement negatives and positive bytes.

Closest full-planner and routing checks pass 52/52; standalone native format,
planner twins, debt/core/abbreviation ceilings pass. Actual unchanged unsafe
negative now emits no tool calls, while broad implementation remains Open.
Native execution remains for CI; preserve original/repair/retry evidence.
MSG
new_commit=$(git commit-tree "$new_tree" -p "$captured_head" -F "$private_index_dir/message")
git update-ref HEAD "$new_commit" "$captured_head"
unset GIT_INDEX_FILE
git read-tree "$new_commit"
printf '%s\n' "$new_commit"
