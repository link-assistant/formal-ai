from pathlib import Path
import json,hashlib
root=Path('/Users/konard/Code/Archive/link-assistant/formal-ai'); folder=Path('/private/tmp/pr1188-coverage-queue-draft-v2'); audit=json.load(open('/private/tmp/pr1188-d743-coverage-warning-order-weight-audit.json'))
observed={}
for row in audit['warning_observations']:
 name=row['name']; bound=row.get('instrumented_seconds_lower_bound',60.0); observed[name]=max(observed.get(name,0),bound)
seed=['# Instrumented coverage priority lower bounds; these are not exact test timings.','# Source d7437d4bcfc6d94823ebeba634de016f25561b41, run 37914168616.','# Stable libtest warns after 60 seconds; completed_at minus warning_at plus 60','# is a lower bound. Uncompleted warnings retain only that 60-second bound.','# Native test-durations.lino remains unchanged; use the maximum of its exact','# name weight and these observed instrumented lower bounds for scheduling.','coverage-test-weights','  source-head d7437d4bcfc6d94823ebeba634de016f25561b41','  source-run 37914168616','  observation-kind warning-lower-bound','  default-seconds 0.092']
for name,seconds in sorted(observed.items()):
 seed.extend([f'  test "{name}"',f'    seconds {seconds:.6f}'])
(folder/'coverage-test-weights.lino').write_text('\n'.join(seed)+'\n')
replacements=[]
def hunk(path,old,new):
 content=(root/path).read_text(); assert content.count(old)==1,(path,content.count(old)); replacements.append({'path':path,'sourceSha256':hashlib.sha256((root/path).read_bytes()).hexdigest(),'old':old,'new':new})
path='scripts/run-coverage-shard.sh'; content=(root/path).read_text(); start=content.index('selected_total=0\n'); old=content[start:]
hunk(path,old,'''# A libtest harness orders its own cases, regardless of filter argument order.
# The bounded queue dispatches equal-weight target batches in actual priority
# order, records wall timing and requires every selected case to complete.
node scripts/run-coverage-plan.mjs "$manifest" "$listing" "$plan" \\
  "${COVERAGE_EXECUTION_RESULT:-coverage-execution-result.json}" || status=1
exit "$status"
''')
hunk(path,'node scripts/plan-test-shards.mjs --of "$SHARD_TOTAL" --check < "$listing"','node scripts/plan-test-shards.mjs --of "$SHARD_TOTAL" --durations data/meta/coverage-test-weights.lino --native-floor --check < "$listing"')
hunk(path,'node scripts/plan-test-shards.mjs --shard "$SHARD_INDEX" --of "$SHARD_TOTAL" < "$listing" > "$plan"','node scripts/plan-test-shards.mjs --shard "$SHARD_INDEX" --of "$SHARD_TOTAL" --durations data/meta/coverage-test-weights.lino --native-floor < "$listing" > "$plan"')
p='scripts/plan-test-shards.mjs'; hunk(p,'  const secondsOf = durationLookup(readTestDurations(durationsPath), defaultSeconds(durationsPath));','''  const selectedSeconds = durationLookup(readTestDurations(durationsPath), defaultSeconds(durationsPath));
  const nativeSeconds = durationLookup(readTestDurations(join(ROOT, 'data/meta/test-durations.lino')), defaultSeconds(durationsPath));
  const secondsOf = argv.includes('--native-floor')
    ? (item) => Math.max(selectedSeconds(item), nativeSeconds(item)) : selectedSeconds;''')
hunk('.github/workflows/coverage.yml','        shard: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]','        shard: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]')
(folder/'coverage-execution.repo.test.mjs').write_text((folder/'coverage-execution.test.mjs').read_text().replace("from './coverage-execution.mjs'", "from '../../../scripts/lib/coverage-execution.mjs'"))
(folder/'proposal.v2.json').write_text(json.dumps({'sourceHead':'d7437d4bcfc6d94823ebeba634de016f25561b41','kind':'scratch-only-unapplied','replacements':replacements,'newFiles':[{'path':p,'scratch':str(folder/n),'sha256':hashlib.sha256((folder/n).read_bytes()).hexdigest()} for p,n in [('scripts/lib/coverage-execution.mjs','coverage-execution.mjs'),('scripts/run-coverage-plan.mjs','run-coverage-plan.mjs'),('data/meta/coverage-test-weights.lino','coverage-test-weights.lino'),('rust/tests/web/coverage-execution.test.mjs','coverage-execution.repo.test.mjs')]],'gatesUnchanged':['1200-second body','30-minute job','runtime list exact-once partition','merge every successful leg; fail on missing/failed leg'],'timingCertification':'Native instrumented cold execution remains required; fake harness tests only certify dispatch/completion contracts.','incompleteLogInventory':{'known':6104,'listed':6242,'missingNames':138},'instrumentedWeightCount':len(observed)},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'weightCount':len(observed),'hunks':len(replacements),'folder':str(folder)}))
