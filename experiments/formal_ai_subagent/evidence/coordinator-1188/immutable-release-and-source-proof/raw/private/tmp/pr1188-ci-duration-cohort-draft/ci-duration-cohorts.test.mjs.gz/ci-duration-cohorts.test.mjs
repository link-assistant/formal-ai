import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parseCiDurations, renderCiDurations } from './ci-speed-durations.mjs';

const root = '/Users/konard/Code/Archive/link-assistant/formal-ai';
const plain = (name, samples = 3) => `    job "${name}"\n      key build\n      median 1\n      maximum 2\n      samples ${samples}\n`;
const shared = (name, head, job) => `    cohort ${name}\n      samples 1\n      source-head ${head}\n      run 123\n      job "${job}"\n        key cli\n        median 1.4\n        maximum 1.4\n        job-identifier 789\n        runner-start 2026-10-09T10:41:11Z\n        job-completed 2026-10-09T10:42:30Z\n`;

test('explicit nested cohort inherits only its own jobs and preserves adjacent historical jobs', () => {
  const text = 'ci-durations\n  workflow "a.yml"\n    name "A"\n' + plain('Before')
    + shared('fresh', 'a'.repeat(40), 'Fresh') + plain('After', 8)
    + '  workflow "b.yml"\n    name "B"\n' + plain('Other', 7);
  const parsed = parseCiDurations(text);
  assert.deepEqual(parsed.workflows[0].jobs.map((job) => [job.display, job.samples]), [['Before', 3], ['Fresh', 1], ['After', 8]]);
  assert.equal(parsed.workflows[0].jobs[1].executionCohort, 'fresh');
  for (const job of [parsed.workflows[0].jobs[0], parsed.workflows[0].jobs[2], parsed.workflows[1].jobs[0]]) {
    assert.equal(job.executionCohort, undefined);
    assert.equal(job.sourceHead, undefined);
    assert.equal(job.run, undefined);
  }
  const rendered = renderCiDurations(parsed);
  assert.ok(rendered.indexOf('job "Before"') < rendered.indexOf('cohort "fresh"'));
  assert.ok(rendered.indexOf('cohort "fresh"') < rendered.indexOf('job "After"'));
  assert.deepEqual(parseCiDurations(rendered), parsed);
});

test('distinct cohorts and a local override preserve exact observed sample counts', () => {
  const text = 'ci-durations\n  workflow "a.yml"\n' + shared('one', 'a'.repeat(40), 'One')
    + '        samples 4\n' + shared('two', 'b'.repeat(40), 'Two');
  const parsed = parseCiDurations(text);
  assert.deepEqual(parsed.workflows[0].jobs.map((job) => [job.executionCohort, job.sourceHead, job.samples]),
    [['one', 'a'.repeat(40), 4], ['two', 'b'.repeat(40), 1]]);
  assert.deepEqual(parseCiDurations(renderCiDurations(parsed)), parsed);
});

test('shared values declared after members are inherited without changing explicit observations', () => {
  const parsed = parseCiDurations('ci-durations\n  workflow "a"\n    cohort "c"\n      job "J"\n        maximum 7.8\n        samples 2\n      samples 1\n      source-head ' + '1'.repeat(40) + '\n');
  assert.equal(parsed.workflows[0].jobs[0].samples, 2);
  assert.equal(parsed.workflows[0].jobs[0].maximum, 7.8);
  assert.equal(parsed.workflows[0].jobs[0].sourceHead, '1'.repeat(40));
});

test('generic render preserves job identifiers, runner times, provenance and additional observed fields', () => {
  const parsed = parseCiDurations('ci-durations\n  workflow "a"\n' + shared('c', 'b'.repeat(40), 'J') + '        feature-profile "all-features-release"\n');
  const job = parsed.workflows[0].jobs[0];
  assert.equal(job.jobIdentifier, 789);
  assert.equal(job.runnerStart, '2026-10-09T10:41:11Z');
  assert.equal(job.jobCompleted, '2026-10-09T10:42:30Z');
  assert.equal(job.featureProfile, 'all-features-release');
  assert.deepEqual(parseCiDurations(renderCiDurations(parsed)), parsed);
});

test('actual eleven consumer records keep all values and every unrelated historic job', async () => {
  const { parseCiDurations: oldParse } = await import(root + '/scripts/lib/ci-speed-durations.mjs');
  const old = oldParse(readFileSync(root + '/data/meta/ci-durations.lino', 'utf8'));
  const next = parseCiDurations(readFileSync('/private/tmp/pr1188-ci-duration-cohort-draft/ci-durations.lino', 'utf8'));
  const normalize = (job) => {
    const normalized = { ...job };
    if ('jobId' in normalized) { normalized.jobIdentifier = normalized.jobId; delete normalized.jobId; }
    return normalized;
  };
  assert.deepEqual(next.header, old.header);
  assert.equal(next.workflows.length, old.workflows.length);
  for (let index = 0; index < old.workflows.length; index++) {
    assert.equal(next.workflows[index].path, old.workflows[index].path);
    assert.deepEqual(next.workflows[index].jobs, old.workflows[index].jobs.map(normalize));
  }
  const cohort = next.workflows.find((workflow) => workflow.path.endsWith('desktop-release.yml')).cohorts[0];
  assert.equal(cohort.jobs.length, 11);
  assert.deepEqual(cohort.shared, { executionCohort: 'same-run-native-reuse', samples: 1,
    sourceHead: 'd7437d4bcfc6d94823ebeba634de016f25561b41', run: 37914168811 });
  assert.deepEqual(parseCiDurations(renderCiDurations(next)), next);
});

test('legacy flat rendering still preserves existing contract and custom job observation fields', () => {
  const input = { header: { branch: 'b' }, workflows: [{ path: 'x.yml', name: 'X', runs: 3, wallMedian: 12.5,
    wallMaximum: 20, jobs: [{ display: 'Test', key: 'test', median: 9.5, maximum: 11, samples: 3, runnerStart: '2026-10-09T00:00:00Z' }] }] };
  const result = parseCiDurations(renderCiDurations(input));
  assert.deepEqual(result, input);
});
