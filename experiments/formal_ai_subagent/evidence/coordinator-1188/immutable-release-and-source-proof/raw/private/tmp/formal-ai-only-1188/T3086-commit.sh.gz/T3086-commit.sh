#!/bin/sh
set -eu
commit_lock=/private/tmp/formal-ai-pr1188-commit.lock
attempt=0
while ! mkdir "$commit_lock" 2>/dev/null; do
  attempt=$((attempt + 1))
  if [ "$attempt" -ge 30 ]; then echo 'Shared commit lock unavailable'; exit 1; fi
  sleep 1
done
private_index_dir=$(mktemp -d /private/tmp/formal-ai-module-observation-index-XXXXXX)
trap 'rm -rf "$private_index_dir"; rmdir "$commit_lock"' EXIT HUP INT TERM
captured_head=$(git rev-parse HEAD)
export GIT_INDEX_FILE="$private_index_dir/index"
git read-tree "$captured_head"
git add -- js/agentic/module_function/callable_catalog.mjs js/agentic/module_function/source_contract.mjs rust/src/agentic_coding/module_function/callable_catalog.rs rust/src/agentic_coding/module_function/source_contract.rs rust/tests/web/observed-callable-contracts.test.mjs rust/tests/fixtures/observed-callable-contracts.rs changelog.d/20261009_230000_observed-module-contracts.md
git add -f -- experiments/formal_ai_subagent/evidence/formal-ai-only-1188/module-observation
git diff --cached --check
current_head=$(git rev-parse HEAD)
[ "$current_head" = "$captured_head" ]
new_tree=$(git write-tree)
cat > "$private_index_dir/message" <<'MSG'
Separate observed module initialization from unproved callable contracts

Retain exact import/initialization and structural-access byte witnesses.
Keep missing schemas, getters, calls and nested scopes unproved; an independent
syntax obligation prevents unsupported bodies from certifying module imports.
Preserve the coordinator's existing native assertion projection hunk.

Closest JavaScript checks pass 44/44 and standalone native formatting and
planner twins pass. Original composition remains a typed MissingContract;
its unchanged acceptance is 3/10. Preserve raw original and repair evidence.
MSG
new_commit=$(git commit-tree "$new_tree" -p "$captured_head" -F "$private_index_dir/message")
git update-ref HEAD "$new_commit" "$captured_head"
unset GIT_INDEX_FILE
git read-tree "$new_commit"
printf '%s\n' "$new_commit"
