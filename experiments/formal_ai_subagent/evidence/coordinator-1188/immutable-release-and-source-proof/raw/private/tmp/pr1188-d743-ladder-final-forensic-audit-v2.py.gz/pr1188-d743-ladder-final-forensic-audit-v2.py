from pathlib import Path
import json,hashlib,collections,re
root=Path('/private/tmp/pr1188-d743-final-ladder-actual');outcomes={}
for line in (root/'run.log').read_text().splitlines():
 fields=line.split('\t')
 if len(fields)==3:outcomes[fields[0]]={'verdict':fields[1],'detail':fields[2]}
rows=[]
for folder in sorted(p for p in root.iterdir() if p.is_dir()):
 requests=[]
 for line in (folder/'formal-ai.log').read_text().splitlines():
  if not line.startswith('{'):continue
  try:obj=json.loads(line)
  except json.JSONDecodeError:continue
  if 'messages' in obj:requests.append(obj)
 if not requests:rows.append({'node':folder.name,'outcome':outcomes.get(folder.name),'requests':0});continue
 messages=requests[-1]['messages'];calls={};results={}
 for message in messages:
  if message.get('role')=='assistant':
   for call in message.get('tool_calls',[]):calls[call['id']]=call
  if message.get('role')=='tool':results[message['tool_call_id']]=message
 trace=[];written=None
 for identifier,call in calls.items():
  function=call['function'];args=json.loads(function['arguments']);receipt=results.get(identifier);payload=receipt.get('content') if receipt else None
  item={'name':function['name'],'path':args.get('filePath',args.get('path')),'command':args.get('command'),'receipt_keys':list(receipt) if receipt else [],'explicit_is_error':receipt.get('is_error') if receipt else None}
  if isinstance(payload,str):item.update(receipt_bytes=len(payload.encode()),receipt_sha256=hashlib.sha256(payload.encode()).hexdigest())
  if function['name']=='write' and isinstance(args.get('content'),str):written=args['content'];item.update(written_bytes=len(written.encode()),written_sha256=hashlib.sha256(written.encode()).hexdigest())
  if function['name']=='bash' and isinstance(payload,str) and written is not None:item.update(equals_preceding_write_bytes=payload==written,preceding_write_bytes=len(written.encode()),explicit_exit_status_present=bool(re.fullmatch(r'(?:Command: [^\n]*\n)?Output: [\s\S]*\nExit Code: -?[0-9]+',payload)))
  trace.append(item)
 finals=[]
 for line in (folder/'agent-stream.jsonl').read_text().splitlines():
  try:obj=json.loads(line)
  except json.JSONDecodeError:continue
  if obj.get('type')=='message' and obj.get('role')=='assistant':
   for content in obj.get('content',[]):
    if content.get('type')=='text':finals.append(content['text'])
 rows.append({'node':folder.name,'outcome':outcomes.get(folder.name),'requests':len(requests),'calls':trace,'final_answer':finals[-1][:1800] if finals else None,'final_answer_truncated_in_audit':bool(finals and len(finals[-1])>1800),'stderr_bytes':(folder/'agent-stderr.log').stat().st_size})
files=[]
for p in sorted(root.rglob('*')):
 if p.is_file():b=p.read_bytes();files.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
assert len(files)==103,len(files)
equal=[r['node'] for r in rows if any(c.get('equals_preceding_write_bytes') for c in r.get('calls',[]))];truncated=[r['node'] for r in rows if any(c.get('name')=='bash' and c.get('preceding_write_bytes',0)>30000 and not c.get('equals_preceding_write_bytes',True) for c in r.get('calls',[]))]
audit={'source_head':'d7437d4bcfc6d94823ebeba634de016f25561b41','preview_source_commit':'3f2fa833bea3451d33009323bcfd4f5f00d0c7f3','source_tree':'9b30e015a5666699cc8663476f650e6988c12672','run':37914168507,'compare_job':113806588799,'artifact':11614905563,'artifact_sha256':'aa386b8cce61f73deb28eeab2ab2f2d88fe6a65ca11f2aa5a8a2c28d61654e56','actual_leaf_outcomes':dict(collections.Counter(v['detail'] for v in outcomes.values())),'passing_leaves':0,'original_baseline':16,'byte_equal_shell_observations':equal,'truncated_30000_observations':truncated,'not_certified':'Absence of reported error is not explicit process exit0; byte equality alone does not certify an unreported shell status. Current local repairs do not certify this native d743 cohort.','nodes':rows}
Path('/private/tmp/pr1188-d743-ladder-final-forensic-audit.v2.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n');Path('/private/tmp/pr1188-d743-ladder-final-artifact-files.v2.json').write_text(json.dumps({'head':audit['source_head'],'artifact':audit['artifact'],'files':files},indent=2)+'\n')
print(json.dumps({'files':len(files),'nodes':len(rows),'outcomes':audit['actual_leaf_outcomes'],'byte_equal_shell_observations':equal,'truncated_30000':truncated}))
