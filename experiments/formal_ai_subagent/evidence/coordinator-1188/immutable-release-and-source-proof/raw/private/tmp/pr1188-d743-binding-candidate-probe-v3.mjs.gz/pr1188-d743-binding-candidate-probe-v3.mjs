import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolveSeedTarget} from '/Users/konard/Code/Archive/link-assistant/formal-ai/js/agentic/requirement_resolution.mjs';
import {WorkerHost} from '/Users/konard/Code/Archive/link-assistant/formal-ai/js/server/worker-host.mjs';
import {installNodeHost} from '/Users/konard/Code/Archive/link-assistant/formal-ai/js/agentic/node-host.mjs';
const host=new WorkerHost();await installNodeHost(host);
const census={modules:[{path:'src/a.rs',symbols:[{kind:'const',name:'ALPHA_LINO'}]}]};
const expected={module_path:'src/a.rs',symbol:'ALPHA_LINO',kind:'const'};
const checks=[];
for(const [surface,request,bound]of [
 ['signal','Improve signal.',false],['signal','Change request surface from signal.',true],
 ['signal','Change signal surface from signal.',true],['code','Improve the code.',false],
 ['code','Change artifact surface from code.',true],['azure dawn','Change signal surface from azure dawn.',true],['azure dawn','Change unrelated surface from azure dawn.',false],
 ['request signal','Improve request signal.',false],['request signal','Change signal surface from request signal.',true],
 ['signal','Change signalish.',false],['返回结果','Change request surface from 返回结果.',true]
]){
 const source=`meanings\n  arbitrary\n    role ${surface==='code'?'script_or_code_artifact':'request_signal'}\n    lexeme en "${surface}"\n`;
 const result=resolveSeedTarget(census,request,[['data/seed/alpha.lino',source]]);assert.deepEqual(result,bound?expected:null,request);checks.push({surface,request,bound});
}
for(const file of ['formal_ai_worker_coreference.js','formal_ai_worker_solve.js']){ let source=readFileSync('/private/tmp/pr1188-d743-runtime-binding-candidates/js/worker/'+file,'utf8'); if(file.endsWith('solve.js'))source=source.slice(0,source.indexOf('const WORKER_HANDLER_REGISTRY')); await host.run(source); }
const original='Write me a Rust program that lists the files in the current directory';
const first=await host.solve(original);const history=[{role:'user',content:original},{role:'assistant',content:first.content}];
const observations=[];
for(const prompt of ['Explain the program?','Объясни результаты?','Объясни программу.','इन परिणामों?','यह प्रोग्राम?','解释结果。','解释程序？']){
 const answer=await host.solve(prompt,history);assert.equal(answer.intent,'coreference_program_artifact',prompt);assert.ok(answer.solverEvents.some(e=>e.kind==='coreference:resolved'),prompt);observations.push({prompt,intent:answer.intent,events:answer.solverEvents});
}
for(const [prompt,turns]of [
 ['Explain the program?',[]],['Explain the program?',[{role:'user',content:'I enjoy fresh apples.'}]],
 ['Explain programming?',history],['itself',history],['Summarize: Explain the program? It has three steps.',history],
 ['Rewrite "Explain the program? It has three steps."',history],['xрезультатыx',history],['xपरिणामोंx',history]
]){
 const answer=await host.solve(prompt,turns);assert.ok(!answer.solverEvents.some(e=>e.kind==='coreference:resolved'),prompt);observations.push({prompt,intent:answer.intent,events:answer.solverEvents});
}
writeFileSync('/private/tmp/pr1188-d743-runtime-binding-candidate-observation.json',JSON.stringify({scratchOnly:true,requirementChecks:checks,coreferenceObservations:observations},null,2));
console.log(JSON.stringify({requirementChecks:checks.length,coreferenceChecks:observations.length,status:'PASS',scratchOnly:true}));
