| T3200 | Record actual computed follow-up substitution plan as native typed event | JavaScript Formal AI | PASS | /tmp/pr1188-T3200.log; exact requested outcome verified |
| T3201 | Retain actual JavaScript permission refusal for typed gate event | JavaScript Formal AI | PASS | /tmp/pr1188-T3201.log; exact requested outcome verified |
| T3202 | Record actual agent-mode denial using unchanged native policy event schema | JavaScript Formal AI | PASS | /tmp/pr1188-T3202.log; exact requested outcome verified |
| T3203 | Normalize seeded pronoun surfaces with existing Unicode-aware bounded matcher | JavaScript Formal AI | PASS | /tmp/pr1188-T3203.log; exact requested outcome verified |
| T3204 | Match native normalized seeded coreference contexts on existing surface boundaries | JavaScript Formal AI | PASS | /tmp/pr1188-T3204.log; exact requested outcome verified |
| T3205 | Preserve seeded prefix constraint after native surface normalization | JavaScript Formal AI | PASS | /tmp/pr1188-T3205.log; exact requested outcome verified |
| T3206 | Record real coreference resolution and rewritten fact request without dropping fact events | JavaScript Formal AI | PASS | /tmp/pr1188-T3206.log; exact requested outcome verified |
| T3207 | Retain typed resolution and source identity when actual seeded antecedent body answers | JavaScript Formal AI | PASS | /tmp/pr1188-T3207.log; exact requested outcome verified |
| T3208 | Preserve actual resolved antecedent Wikidata event before its rewritten fact lookup | JavaScript Formal AI | PASS | /tmp/pr1188-T3208.log; exact requested outcome verified |
| T3209 | Return actual permission refusal with its typed event directly | JavaScript Formal AI | PASS | /tmp/pr1188-T3209.log; exact requested outcome verified |
| T3210 | Retain typed policy event without growing original permission wrapper budget | JavaScript Formal AI | FAIL | /tmp/pr1188-T3210.log; unchanged retry or correction required |
| T3211 | Repair incomplete policy constructor through FA using in-memory known-correct boot source | JavaScript Formal AI | FAIL | /tmp/pr1188-T3211.log; unchanged retry or correction required |
| T3212 | Repair incomplete policy constructor through FA using in-memory known-correct boot source | JavaScript Formal AI | PASS | /tmp/pr1188-T3212.log; exact requested outcome verified |
| T3213 | Keep exact native substitution citation without redundant description | JavaScript Formal AI | PASS | /tmp/pr1188-T3213.log; exact requested outcome verified |
| T3214 | Create bounded js/worker/formal_ai_worker_coreference.js through copied template | JavaScript Formal AI | PASS | /tmp/pr1188-T3214.log; exact requested outcome verified |
| T3215 | Set reviewed js/worker/formal_ai_worker_coreference.js content | JavaScript Formal AI | PASS | /tmp/pr1188-T3215.log; exact requested outcome verified |
| T3216 | Move coherent actual coreference handler into its own worker module | JavaScript Formal AI | PASS | /tmp/pr1188-T3216.log; exact requested outcome verified |
| T3217 | Describe remaining translation and recall module after coherent extraction | JavaScript Formal AI | FAIL | /tmp/pr1188-T3217.log; unchanged retry or correction required |
| T3218 | Regenerate sorted worker inventory through FA with in-memory real directory boot list | JavaScript Formal AI | FAIL | /tmp/pr1188-T3218.log; unchanged retry or correction required |
| T3219 | Regenerate sorted worker inventory through FA with in-memory real directory boot list | JavaScript Formal AI | FAIL | /tmp/pr1188-T3219.log; unchanged retry or correction required |
| T3220 | Describe remaining translation and recall module after coherent extraction | JavaScript Formal AI | PASS | /tmp/pr1188-T3220.log; exact requested outcome verified |
| T3221 | Create bounded data/meta/worker-line-budget/formal_ai_worker_coreference.lino through copied template | JavaScript Formal AI | PASS | /tmp/pr1188-T3221.log; exact requested outcome verified |
| T3222 | Set reviewed data/meta/worker-line-budget/formal_ai_worker_coreference.lino content | JavaScript Formal AI | PASS | /tmp/pr1188-T3222.log; exact requested outcome verified |
| T3223 | Lower original worker ceiling to actual coherent extraction size | JavaScript Formal AI | PASS | /tmp/pr1188-T3223.log; exact requested outcome verified |
| T3224 | Regenerate exact sorted worker directory inventory and verify actual fresh coreference helper | JavaScript Formal AI | PASS | /tmp/pr1188-T3224.log; exact requested outcome verified |
| T3225 | Create bounded rust/tests/web/worker-native-handler-parity.test.mjs through copied template | JavaScript Formal AI | PASS | /tmp/pr1188-T3225.log; exact requested outcome verified |
| T3226 | Set reviewed rust/tests/web/worker-native-handler-parity.test.mjs content | JavaScript Formal AI | PASS | /tmp/pr1188-T3226.log; exact requested outcome verified |
| T3227 | Regenerate owned checked TypeScript twins, standalone native format, and whole native-handler closest checks | JavaScript Formal AI | FAIL | /tmp/pr1188-T3227.log; unchanged retry or correction required |
| T3228 | Regenerate owned checked TypeScript twins, standalone native format, and whole native-handler closest checks | JavaScript Formal AI | FAIL | /tmp/pr1188-T3228.log; unchanged retry or correction required |
| T3229 | Use actual public WorkerHost typed event field for negative resolution guard | JavaScript Formal AI | PASS | /tmp/pr1188-T3229.log; exact requested outcome verified |
| T3230 | Describe remaining worker functions without duplicated lookup wording | JavaScript Formal AI | PASS | /tmp/pr1188-T3230.log; exact requested outcome verified |
| T3231 | Add public native seeded terminal Unicode and embedded-word heldouts preserving all original assertions | JavaScript Formal AI | PASS | /tmp/pr1188-T3231.log; exact requested outcome verified |
| T3232 | Regenerate checked owned twins, format only native owned modules, verify unchanged whole native cases and nearest16checks | JavaScript Formal AI | PASS | /tmp/pr1188-T3232.log; exact requested outcome verified |
| T3233 | Replay every original production reader assertion plus appended native heldouts without recordwrite | JavaScript Formal AI | PASS | /tmp/pr1188-T3233.log; exact requested outcome verified |
| T3234 | Remove extraction separator after new worker module EOF | JavaScript Formal AI | PASS | /tmp/pr1188-T3234.log; exact requested outcome verified |
| T3235 | Lower new module ceiling after removing copied inter-function separator | JavaScript Formal AI | PASS | /tmp/pr1188-T3235.log; exact requested outcome verified |
| T3236 | Regenerate exact checked new module twin after separator cleanup | JavaScript Formal AI | PASS | /tmp/pr1188-T3236.log; exact requested outcome verified |
| T3237 | Create selected immutable parity evidence directory through FA | JavaScript Formal AI | PASS | /tmp/pr1188-T3237.log; exact requested outcome verified |
| T3238 | Preserve37 complete FA raw transcripts and four actual parity observations byte-exact | JavaScript Formal AI | FAIL | /tmp/pr1188-T3238.log; unchanged retry or correction required |
| T3239 | Preserve37 complete FA raw transcripts and four actual parity observations byte-exact | JavaScript Formal AI | PASS | /tmp/pr1188-T3239.log; exact requested outcome verified |
