# Finite native producer reuse draft (read-only, current source inspection)

No workflow or source edits were made for this draft. Existing desktop41.3m/CLI34.4m exceptions remain open until complete cold producer and consumer jobs actually satisfy30 minutes. Local packet157s is separate working-tree performance, not final-head CI evidence.

## Exact targets and sharing

| Producer target | Runner | Desktop consumer | CLI consumer |
|---|---|---|---|
| x86_64-unknown-linux-gnu | ubuntu-latest | linux-x64 | none |
| aarch64-unknown-linux-gnu | ubuntu-24.04-arm | linux-arm64 | none |
| x86_64-unknown-linux-musl | ubuntu-latest + pinned musl cross tools | none | cli-linux-x64 |
| aarch64-unknown-linux-musl | ubuntu-24.04-arm + pinned musl cross tools | none | cli-linux-arm64 |
| x86_64-apple-darwin | macos-15-intel | macos-x64 | cli-macos-x64 |
| aarch64-apple-darwin | macos-14 | macos-arm64 | cli-macos-arm64 |
| x86_64-pc-windows-msvc | windows-latest | windows-x64 | cli-windows-x64 |
| aarch64-pc-windows-msvc | windows-11-arm | windows-arm64 | none |

Eight distinct producers replace eleven builds: only the two Darwin and Windows x64 targets share executable contracts today. Linux GNU and MUSL must remain separate; no missing Windows ARM64 CLI consumer is invented.

All producers use one selected source commit/tree, Cargo.lock, release profile, `--locked --bin formal-ai --target <explicit target>`, default features resolved from Cargo.toml (currently doublets-native/equality-saturation/meta-language), and RUSTFLAGS=-Dwarnings. Pin the actual installed rustc version/commit/host (not only the moving word stable), linker/cross-tool versions and effective Cargo profile/flags. RUSTC_WRAPPER differs by Windows response-file constraint; record it honestly. Same source identity alone is insufficient.

## One source contract before any producer

Existing build/cli legs check out a merge preview and independently run simulate-fresh-merge.sh against needs.base.outputs.commit. It pins the base tree, but a newly created merge commit can differ by timestamp across jobs. Receipts requiring equal commits cannot assume those synthetic commits are equal.

A single read-only-permission source job should select the resolved release tag or prepare the pinned fresh PR merge once. Emit source commit, source tree, selected PR head, pinned base and event/release identity. If the fresh merge creates an otherwise unreachable commit, export only its new Git objects in a thin bundle with checked preview/base prerequisites; consumers import that bundle into their existing checkout, checkout the exact emitted commit and verify tree/parent ancestry. Do not upload a full repository checkout or weaken commit equality to a loose tree comparison. Release consumers resolve the actual tag commit normally.

## Standalone executable receipt and consumer boundary

Existing scripts/native-test-artifact.mjs has useful strict identity/hash checks but requires all three unit/integration/source harnesses plus binary. Existing release build-artifacts produces --all-features, not these default-feature cross-platform binaries. Neither artifact can be claimed as the standalone default-feature producer.

Factor a common identity schema while retaining the test-harness receipt contract. A new standalone executable receipt records version, source commit/tree, Cargo.lock and owned native input digest (rust/src, rust/embedded, build.rs and embedded api-cache), target triple, host architecture/platform, actual compiler/toolchain/linker identity, release profile/effective settings, resolved features, RUSTFLAGS, executable basename/size/SHA256, producer run/job and source-selection identity. Producer smoke-tests the actual executable --version and a small existing public command against a selected tiny sandbox before upload. No local native execution is proposed.

Every consumer downloads only its exact same-run target artifact; it verifies the complete receipt and executable SHA against its requested identity before executing or copying. No restore-prefix cache, unverified OS-only artifact or fallback rebuild counts as a successful reuse. If a cache is later added, its key must include target/toolchain/profile/features/flags/native inputs and its receipt must preserve actual producer provenance; it cannot relabel a different source commit as compiled current source.

Desktop preparation receives FORMAL_AI_DESKTOP_BINARY as the verified absolute downloaded executable path. It checks desktop/bin copy bytes and startup, then retains actual packaged artifact checks. CLI archives copy the same verified target executable, then preserve existing extract-and-start smoke tests and hashes/attestations.

## Actual present packaging path defect

Desktop workflow builds with --manifest-path rust/Cargo.toml at line303, without target-dir override. prepare-resources.mjs85-90 searches configured path or repository-root target/release and target/debug. There is no FORMAL_AI_DESKTOP_BINARY/CARGO_TARGET_DIR in desktop-release.yml and no root/rust .cargo/config.toml. Therefore the current resource step can warn/fall back instead of bundling rust/target/release/formal-ai. Explicit verified path plus required copied-binary check is a separate narrow correctness repair before producer sharing.

## Measurement and retirement sequence

1. Repair verified desktop binary path first, preserving real target resource and package checks.
2. Introduce exact standalone receipt/tests and source selection, without lowering historical cold caps yet.
3. Add eight bounded producers and convert eleven consumers to exact receipt-checked downloads. Packaging/dependency/browser/signing work stays in consumers; producer failure or unavailable source is a real failure.
4. Dispatch complete cold current-source producer+desktop+CLI cycles. Collect all started_at/completed_at job durations, setup/upload steps, compiler body timing and actual published archive bytes. Retire consumer exceptions only if each full consumer job/step is below30.
5. If cold producer compilation itself exceeds30, keep that defect explicit. Sharing removes duplicate work but does not solve an overlong producer. Measure compiler dependency work and native architecture limits before selecting honest feature-preserving dependency artifact stages; do not simply move the50-minute exception to a renamed producer or raise timeouts.

Closest future tests should refuse changed target/features/profile/RUSTFLAGS/compiler/lock/source/tree/bytes, missing/wrong producer artifacts and unavailable startup. Existing six desktop/five CLI target sets, release permissions/events, original archive smoke tests and package signatures remain asserted.
