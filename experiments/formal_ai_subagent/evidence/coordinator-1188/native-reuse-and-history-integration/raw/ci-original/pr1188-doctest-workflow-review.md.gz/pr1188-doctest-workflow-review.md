Default-feature doc preparation draft, based on exact2ef failing job113743363410.

No local Cargo/rustc invocation. Preserve original defaultfeatures+profiletest+RUSTFLAGS=-Dwarnings, compiler/setup helpers and complete doctest command under120s. Preparation only builds the lib dependency at exact test profile; it does not execute or skip a doctest. The producer and real doctest consumer share one job/source/workspace/flags, avoiding unverifiable cross-profile reuse.

Meaningful future native CI verification: preparation command succeeds; unchanged cargo --doc actually runs all examples within120s; fresh job <=30min including checkout/toolchain/setup, with real outcomes retained. Existing release/all-feature test artifacts do not establish those measurements.

Nearest assertions may require docstep-location updates preserving original command/defaultflags/deadline, new prep exactprofile, all five full-native shard memberships, and absence of any exemption. Root should actionlint and check CI/DAG/job-budget identities after FA application; no source gate/budget weakening.
