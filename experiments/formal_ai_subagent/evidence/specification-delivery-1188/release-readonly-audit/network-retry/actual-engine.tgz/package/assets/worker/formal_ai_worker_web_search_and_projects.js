// Reciprocal rank fusion and the web-search handler, promoted projects and
// GitHub repository lookups, response-language follow-ups and formalization
// matching.
// Loaded by ../formal_ai_worker.js.
function reciprocalRankFusion(perProviderResults, k, evidence) {
  const componentFused = self.FormalAIWebSearchComponent.fuseResults(perProviderResults, k, evidence); if (componentFused !== null) return componentFused;
  const wasmFused = wasmReciprocalRankFusion(perProviderResults);
  if (wasmFused !== null) return wasmFused;
  // Cormack, Clarke, Buettcher 2009: score(d) = Σ 1 / (k + rank_i(d)).
  const fused = new Map();
  for (const provider of perProviderResults) {
    (Array.isArray(provider.results) ? provider.results : []).forEach((item, index) => {
      if (!item || !item.url) return;
      const rank = index + 1;
      const score = 1 / (k + rank);
      const existing = fused.get(item.url);
      if (existing) {
        existing.score += score;
        existing.providers.push({ id: provider.id, rank });
        if (!existing.title && item.title) existing.title = item.title;
        if (!existing.excerpt && item.excerpt) existing.excerpt = item.excerpt;
      } else {
        fused.set(item.url, {
          url: item.url, title: item.title || item.url,
          excerpt: item.excerpt || "", score,
          providers: [{ id: provider.id, rank }],
          sourceTier: item.sourceTier || "",
          sourceLanguage: item.sourceLanguage || provider.language || "",
        });
      }
    });
  }
  return Array.from(fused.values()).sort((a, b) =>
    (b.score - a.score) || (b.providers.length - a.providers.length));
}

// Cross-provider identifiers let one entity absorb alternate result URLs.
function canonicalEntityKeys(meta) {
  if (!meta) return [];
  const keys = [];
  if (meta.qid && /^Q\d+$/.test(meta.qid)) keys.push(`Q:${meta.qid}`);
  for (const [prefix, key, language] of [
    ["WP", meta.wikipediaKey, meta.wikipediaLanguage],
    ["WT", meta.wiktionaryKey, meta.wiktionaryLanguage],
    ["WN", meta.wikinewsKey, meta.wikinewsLanguage],
  ]) {
    if (key) keys.push(`${prefix}:${language || "en"}:${key}`);
  }
  return keys;
}

function buildItemMetadataIndex(perProvider) {
  const byUrl = new Map();
  const rank = (item) => (item && item.qid ? 2 : 1);
  const record = (url, item) => {
    if (!url || !item) return;
    const existing = byUrl.get(url);
    if (!existing || rank(item) > rank(existing)) byUrl.set(url, item);
  };
  for (const provider of perProvider) {
    if (!provider || !Array.isArray(provider.results)) continue;
    for (const item of provider.results) {
      if (!item || !item.url) continue;
      record(item.url, item);
      if (item.wikipediaUrl) record(item.wikipediaUrl, item);
    }
  }
  return byUrl;
}

function dedupeFusedEntries(fused, metaByUrl, evidence) {
  const groupsByKey = new Map();
  const allGroups = [];
  const standalone = [];

  const alreadyHasProvider = (target, candidate) => target.providers.some(
    (existing) => existing.id === candidate.id && existing.rank === candidate.rank,
  );

  fused.forEach((entry, index) => {
    const meta = metaByUrl.get(entry.url) || null;
    const keys = canonicalEntityKeys(meta);
    const enriched = Object.assign({}, entry, {
      qid: (meta && meta.qid) || "",
      wikipediaKey: (meta && meta.wikipediaKey) || "", wikipediaLanguage: (meta && meta.wikipediaLanguage) || "",
      wiktionaryKey: (meta && meta.wiktionaryKey) || "", wiktionaryLanguage: (meta && meta.wiktionaryLanguage) || "",
      wikinewsKey: (meta && meta.wikinewsKey) || "", wikinewsLanguage: (meta && meta.wikinewsLanguage) || "",
      sourceKind: (meta && meta.sourceKind) || "",
      sourceTier: entry.sourceTier || (meta && meta.sourceTier) || "",
      sourceLanguage: entry.sourceLanguage || (meta && meta.sourceLanguage) || "",
      virtualId: (meta && meta.virtualId) || (meta && meta.qid) ||
        (meta && meta.wikipediaKey ? `WP:${meta.wikipediaKey}` : ""),
      alternateUrls: [], keys: keys.slice(), originalRank: index,
    });

    if (keys.length === 0) {
      standalone.push(enriched);
      return;
    }
    const head = keys.map((key) => groupsByKey.get(key)).find(Boolean) || null;
    if (!head) {
      allGroups.push(enriched);
      for (const key of keys) if (!groupsByKey.has(key)) groupsByKey.set(key, enriched);
      return;
    }
    head.score += enriched.score;
    head.alternateUrls.push({
      url: enriched.url, title: enriched.title,
      providers: enriched.providers, sourceKind: enriched.sourceKind,
      excerpt: enriched.excerpt, sourceTier: enriched.sourceTier,
      sourceLanguage: enriched.sourceLanguage,
    });
    for (const p of enriched.providers) if (!alreadyHasProvider(head, p)) head.providers.push(p);
    for (const key of keys) if (!groupsByKey.has(key)) groupsByKey.set(key, head);
    if (!head.virtualId && enriched.virtualId) head.virtualId = enriched.virtualId;
    if (!head.qid && enriched.qid) head.qid = enriched.qid;
    for (const [key, language] of [
      ["wikipediaKey", "wikipediaLanguage"],
      ["wiktionaryKey", "wiktionaryLanguage"],
      ["wikinewsKey", "wikinewsLanguage"],
    ]) {
      if (!head[key] && enriched[key]) [head[key], head[language]] = [enriched[key], enriched[language]];
    }
    if (Array.isArray(evidence)) evidence.push(`web_search:dedupe:${keys[0]}:absorbed:${enriched.url}`);
  });
  const merged = [...allGroups, ...standalone];
  merged.sort((a, b) => {
    const primary = (b.score - a.score) || (b.providers.length - a.providers.length);
    if (primary) return primary;
    const ap = providerPriorityScore(a.providers);
    const bp = providerPriorityScore(b.providers);
    return (ap - bp) || (a.originalRank - b.originalRank);
  });
  return merged;
}

function providerPriorityScore(providers) {
  if (!Array.isArray(providers) || providers.length === 0) return 999;
  return Math.min(...providers.map((p) => WEB_SEARCH_PROVIDER_PRIORITY[p && p.id] || 999));
}

// Localized search templates are the seeded web_search_* responses
// (data/seed/multilingual-responses-synthesis.lino); English is the fallback
// (issue #918).
function webSearchTexts(language) {
  const code = String(language || "").toLowerCase().slice(0, 2);
  const text = (intent, values = {}) => {
    let out = answerFor(intent, code);
    for (const [name, value] of Object.entries(values)) out = out.split(`{${name}}`).join(String(value));
    return out;
  };
  return {
    header: (query, top, k) => text("web_search_results_header", { top, k, query }),
    otherSources: text("web_search_other_sources"),
    via: text("web_search_via"),
    readMore: text("web_search_read_more"),
    noResults: (query, providers) => text("web_search_no_results", { providers, query }),
    allDisabled: (providers) => text("web_search_all_disabled", { providers }),
  };
}

function normalizeBareTermResultLabel(value) {
  let text = cleanBareTermSearchFocus(value);
  if (!text) return "";
  if (typeof text.normalize === "function") {
    text = text.normalize("NFKC");
  }
  text = text
    .replace(/\s*\([^)]*\)\s*$/gu, "")
    .replace(/\s*（[^）]*）\s*$/gu, "")
    .replace(/\s+[-–—]\s+(?:wikipedia|wiktionary)\s*$/iu, "")
    .trim();
  return normalizePrompt(text).replace(/\s+/gu, " ").trim();
}

function unresolvedBareTermResultLabels(entry) {
  if (!entry) return [];
  const labels = [entry.title, entry.wikipediaKey, entry.wiktionaryKey];
  if (Array.isArray(entry.alternateUrls)) {
    for (const alternate of entry.alternateUrls) {
      labels.push(alternate && alternate.title);
    }
  }
  return labels.filter(Boolean);
}

function hasGroundedUnresolvedBareTermResult(query, results) {
  const normalizedQuery = normalizeBareTermResultLabel(query);
  if (!normalizedQuery || !Array.isArray(results)) return false;
  return results.some((entry) =>
    unresolvedBareTermResultLabels(entry).some(
      (label) => normalizeBareTermResultLabel(label) === normalizedQuery,
    ),
  );
}

async function tryWebSearch(prompt, language) {
  const normalized = normalizePrompt(prompt);
  const request = extractWebSearchRequest(prompt, normalized);
  if (!request || !request.query) return null;
  return runWebSearchQuery(request.query, language, request.kind);
}

const UNKNOWN_RESEARCH_STOPWORDS = new Set([
  "are", "how", "is", "was", "were", "what", "who",
  "как", "кто", "такое", "что", "это", "क्या", "कैसे", "कौन", "है", "什么", "怎么", "是", "谁",
]);

function unknownResearchResultIsRelevant(query, entry) {
  const normalizedQuery = normalizePrompt(query);
  const normalizedResult = normalizePrompt(`${(entry && entry.title) || ""} ${(entry && entry.excerpt) || ""}`);
  if (!normalizedQuery || !normalizedResult) return false;
  const formalization = exactFormalizationMatch(query, normalizedQuery);
  const subject = formalization && formalization.objectText !== null
    ? normalizePrompt(formalization.objectText) : normalizedQuery;
  const tokens = [...new Set((subject.match(/[\p{L}\p{N}]+/gu) || [])
    .filter((token) => Array.from(token).length >= 3 && !UNKNOWN_RESEARCH_STOPWORDS.has(token) && !LOOKUP_STEM_STOPWORDS.has(token)))];
  if (tokens.length === 0) return false;
  const resultTokens = new Set(normalizedResult.match(/[\p{L}\p{N}]+/gu) || []);
  return tokens.filter((token) => resultTokens.has(token)).length >= Math.min(2, tokens.length);
}

async function runWebSearchQuery(query, language, queryKind, preferences = {}) {
  query = String(query || "").trim();
  if (!query) return null;
  const rrfK = webSearchRrfK();
  const concurrency = webSearchConcurrency();
  const providerLimit = webSearchProviderLimit();
  const texts = webSearchTexts(language);
  // Probe providers once per session and cache CORS failures.
  await ensureWebSearchProviderProbes();

  const isUnknownResearch = queryKind === "unknown_intent_research";
  const enabledResearchProviders = isUnknownResearch ? UNKNOWN_INTENT_RESEARCH_PROVIDERS
    .filter((provider) => externalServiceEnabled(preferences, provider.settingsKey)) : [];
  const providerCatalog = isUnknownResearch
    ? self.FormalAIWebSearchComponent.orderProviders(WEB_SEARCH_PROVIDERS).concat(enabledResearchProviders)
    : self.FormalAIWebSearchComponent.orderProviders(WEB_SEARCH_PROVIDERS);
  const optedOutResearchProviders = isUnknownResearch
    ? UNKNOWN_INTENT_RESEARCH_PROVIDERS.filter((provider) => !enabledResearchProviders.includes(provider)) : [];

  // Use WASM evidence when available, with an equivalent JS fallback.
  const evidence = [];
  const wasmEvidence = wasmWebSearchRequestEvidence(query, language || "");
  if (Array.isArray(wasmEvidence) && wasmEvidence.length > 0) {
    for (const line of wasmEvidence) {
      if (line) evidence.push(line);
    }
  } else {
    evidence.push(`web_search:request:${query}`);
    if (language) {
      evidence.push(`web_search:language:${language}`);
    }
    for (const provider of providerCatalog) {
      evidence.push(`web_search:provider:${provider.id}`);
    }
    evidence.push(`web_search:combined:rrf:k=${rrfK}`);
  }
  if (queryKind) {
    evidence.push(`web_search:query_kind:${queryKind}`);
  }
  if (isUnknownResearch) {
    for (const provider of providerCatalog) {
      const marker = `web_search:provider:${provider.id}`;
      if (!evidence.includes(marker)) evidence.push(marker);
    }
  }
  for (const provider of optedOutResearchProviders) evidence.push(`web_search:service_disabled:${provider.id}`);

  // Keep declared provider priority for tied scores and diagnostics.
  const ordered = providerCatalog.slice().sort((a, b) => {
    const pa = typeof a.priority === "number" ? a.priority : 999;
    const pb = typeof b.priority === "number" ? b.priority : 999;
    return pa - pb;
  });
  const active = ordered.filter((provider) => !webSearchIsDisabled(provider.id));
  for (const provider of ordered) {
    if (webSearchIsDisabled(provider.id)) {
      evidence.push(`web_search:disabled:${provider.id}`);
    } else if (WEB_SEARCH_AVAILABLE.has(provider.id)) {
      evidence.push(`web_search:available:${provider.id}`);
    }
  }

  if (active.length === 0) {
    if (queryKind === "unresolved_bare_term") return null;
    return {
      intent: "web_search",
      content: texts.allDisabled(providerCatalog.map((p) => p.id).join(", ")),
      confidence: 0.3, query, evidence,
      diagnostics: { providers: [], httpExchanges: consumeWebSearchDiagnostics() },
    };
  }

  const tasks = active.map((provider) => async () => {
    const startedAt = Date.now();
    const outcome = await provider.run(query, language, providerLimit);
    return Object.assign({ id: provider.id, label: provider.label, elapsedMs: Date.now() - startedAt }, outcome);
  });
  const perProvider = await runWithConcurrencyLimit(tasks, concurrency);

  for (const provider of perProvider) {
    if (!provider.ok) {
      evidence.push(`web_search:provider:${provider.id}:error:${provider.error || "no_results"}`);
      continue;
    }
    evidence.push(`web_search:provider:${provider.id}:count:${provider.results.length}`);
    if (provider.language) {
      evidence.push(`web_search:provider:${provider.id}:language:${provider.language}`);
    }
    provider.results.forEach((item, index) => {
      evidence.push(`web_search:rank:${provider.id}:${index + 1}:${item.url}`);
    });
  }

  const fused = reciprocalRankFusion(perProvider, rrfK, evidence);
  const metaByUrl = buildItemMetadataIndex(perProvider);
  const deduped = dedupeFusedEntries(fused, metaByUrl, evidence);
  const relevant = isUnknownResearch
    ? deduped.filter((entry) => unknownResearchResultIsRelevant(query, entry)) : deduped;
  if (isUnknownResearch) {
    evidence.push(`web_search:relevance:accepted:${relevant.length}`);
    evidence.push(`web_search:relevance:rejected:${deduped.length - relevant.length}`);
  }
  const top = relevant.slice(0, providerLimit);
  top.forEach((entry, index) => {
    evidence.push(`web_search:fused:${index + 1}:${entry.providers.map((p) => p.id).join("+")}:${entry.url}`);
    if (entry.virtualId) {
      evidence.push(`web_search:formal:${index + 1}:${entry.virtualId}`);
    }
  });

  const diagnostics = {
    query,
    language: language || "",
    providers: perProvider.map((p) => ({
      id: p.id,
      label: p.label,
      ok: !!p.ok,
      count: Array.isArray(p.results) ? p.results.length : 0,
      elapsedMs: p.elapsedMs || 0,
      finalUrl: p.finalUrl || "",
      error: p.error || "",
    })),
    httpExchanges: consumeWebSearchDiagnostics(),
    fused: top.map((entry, index) => ({
      rank: index + 1,
      url: entry.url,
      title: entry.title,
      score: entry.score,
      providers: entry.providers,
      alternateUrls: entry.alternateUrls,
      virtualId: entry.virtualId || "",
      keys: entry.keys || [],
    })),
  };

  if (
    queryKind === "unresolved_bare_term" &&
    !hasGroundedUnresolvedBareTermResult(query, top)
  ) {
    return null;
  }

  if (top.length === 0) {
    return {
      intent: "web_search",
      content: texts.noResults(query, active.map((p) => p.label).join(", ")),
      confidence: 0.35, query, evidence,
      diagnostics,
    };
  }

  const statementFusion = fuseBrowserSearchStatements(
    top, query, language, texts, evidence, rrfK,
  );
  let lines = statementFusion.lines;
  diagnostics.statements = statementFusion.statements;
  if (statementFusion.statements.length === 0) {
    // Captured, ranked snippets remain source data when statement
    // formalization is unavailable; do not describe them as formalized claims.
    const results = top.map((entry) =>
      `- [${entry.title || entry.url}](${entry.url})${entry.excerpt ? ` — ${entry.excerpt}` : ""}`).join("\n");
    lines = handlerRulesFillOnce(answerFor("web_search_live_results", language || "en"), {
      query, count: top.length, results,
    }).split("\n");
    evidence.push("web_search:rendering:retrieved_source_snippets");
  }

  // Resolve the formalization tuple now that we know the top-ranked entity.
  // Prefer a real Wikidata Q-id; fall back to the WP virtual id, then to the
  // bare normalised query. We scan the whole `top` slice instead of just
  // `top[0]` so that a DuckDuckGo result without an id at rank 1 still lets
  // us fold a Wikidata Q-id from rank 2+ into the resolved tuple.
  let formalizedObject = "";
  for (const entry of top) {
    if (entry && entry.virtualId) {
      formalizedObject = entry.virtualId;
      if (/^Q\d+$/.test(entry.virtualId)) break;
    }
  }

  return {
    intent: "web_search",
    content: lines.join("\n"),
    confidence: 0.85,
    evidence,
    formalizedObject,
    query,
    diagnostics,
  };
}

const PROMOTED_PROJECT_ORGS = ["link-assistant", "link-foundation", "linksplatform"];

function projectPromotionEnabled(preferences) {
  const value = preferences && preferences.associativeProjectPromotion;
  if (value === undefined || value === null || value === "") return true;
  if (value === true) return true;
  if (value === false) return false;
  const normalized = String(value).trim().toLowerCase();
  if (["0", "false", "no", "off", "disabled"].includes(normalized)) return false;
  if (["1", "true", "yes", "on", "enabled"].includes(normalized)) return true;
  return true;
}

function normalizeProjectTerm(value) {
  let term = normalizePrompt(value)
    .replace(/[-_]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  for (const prefix of ["the ", "a ", "an "]) {
    if (term.startsWith(prefix)) {
      term = term.slice(prefix.length).trim();
      break;
    }
  }
  return term;
}

function projectRepoSlug(project) {
  return `${project.org}/${project.name}`;
}

function localizedProject(project, language) {
  if (!project || !Array.isArray(project.localized)) return null;
  return (
    project.localized.find((loc) => loc && loc.language === language) ||
    project.localized.find((loc) => loc && loc.language === "en") ||
    null
  );
}

function projectDisplayName(project, language) {
  const localized = localizedProject(project, language);
  return (localized && localized.displayName) || project.displayName || project.name || "";
}

function projectStatementsFor(project, language) {
  const localized = localizedProject(project, language);
  if (
    localized &&
    Array.isArray(localized.statements) &&
    localized.statements.length > 0
  ) {
    return localized.statements;
  }
  return Array.isArray(project && project.statements) ? project.statements : [];
}

function projectMatchesAlias(project, normalizedTerm) {
  if (!project || !normalizedTerm) return false;
  const aliases = Array.isArray(project.aliases) ? project.aliases : [];
  return (
    normalizeProjectTerm(project.displayName) === normalizedTerm ||
    normalizeProjectTerm(project.name) === normalizedTerm ||
    normalizeProjectTerm(projectRepoSlug(project)) === normalizedTerm ||
    aliases.some((alias) => normalizeProjectTerm(alias) === normalizedTerm)
  );
}

function projectByAlias(term) {
  const normalizedTerm = normalizeProjectTerm(term);
  if (!normalizedTerm) return null;
  return PROJECTS.find((project) => projectMatchesAlias(project, normalizedTerm)) || null;
}

function isPromotedProject(project) {
  return PROMOTED_PROJECT_ORGS.some(
    (org) => String(project && project.org).toLowerCase() === org,
  );
}

function promotedProjectByRepo(owner, name) {
  const ownerLower = String(owner || "").toLowerCase();
  const nameLower = String(name || "").toLowerCase();
  return (
    PROJECTS.find(
      (project) =>
        isPromotedProject(project) &&
        String(project.org || "").toLowerCase() === ownerLower &&
        String(project.name || "").toLowerCase() === nameLower,
    ) || null
  );
}

function cleanRepositorySegment(segment) {
  const trimmed = String(segment || "").trim().replace(/\.git$/i, "");
  if (!trimmed || !/^[A-Za-z0-9._-]+$/.test(trimmed)) return "";
  return trimmed;
}

function isTextUrlExtractionPrompt(prompt) {
  const normalized = normalizePrompt(prompt).trimStart().toLowerCase();
  return (
    (normalized.startsWith("extract url ") ||
      normalized.startsWith("extract urls ")) &&
    normalized.includes(" from ")
  );
}

function repositoryFromUrl(url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch (_error) {
    return null;
  }
  const host = parsed.hostname.toLowerCase().replace(/^www\./, "");
  const platform =
    host === "github.com"
      ? { slug: "github", label: "GitHub", host: "github.com" }
      : host === "gitlab.com"
        ? { slug: "gitlab", label: "GitLab", host: "gitlab.com" }
        : host === "bitbucket.org"
          ? { slug: "bitbucket", label: "Bitbucket", host: "bitbucket.org" }
          : null;
  if (!platform) return null;
  const segments = parsed.pathname.split("/").filter(Boolean);
  const owner = cleanRepositorySegment(segments[0]);
  const name = cleanRepositorySegment(segments[1]);
  if (!owner || !name) return null;
  return {
    platform,
    owner,
    name,
    url: `https://${platform.host}/${owner}/${name}`,
  };
}

function repositoryFromSlug(term) {
  const parts = String(term || "").trim().split("/");
  if (parts.length !== 2) return null;
  const owner = cleanRepositorySegment(parts[0]);
  const name = cleanRepositorySegment(parts[1]);
  if (!owner || !name) return null;
  if (/^\d+$/.test(owner) && /^\d+$/.test(name)) return null;
  return {
    platform: { slug: "github", label: "GitHub", host: "github.com" },
    owner,
    name,
    url: `https://github.com/${owner}/${name}`,
  };
}

function repositoryFromPrompt(prompt) {
  const urlCandidate = firstUrlCandidate(prompt);
  if (urlCandidate) {
    const repo = repositoryFromUrl(urlCandidate.url);
    if (repo) return repo;
  }
  const query = extractConceptQuery(prompt);
  if (!query) return null;
  const term = String(query.termOriginal || query.term || "").trim();
  if (!term) return null;
  if (term.includes("://") || looksLikeHostname(term)) {
    const url = normalizeUrlCandidate(term);
    return url ? repositoryFromUrl(url) : null;
  }
  if (term.includes("/") && !/\s/.test(term)) {
    return repositoryFromSlug(term);
  }
  return null;
}

function repositorySlug(repo) {
  return `${repo.owner}/${repo.name}`;
}

const GITHUB_README_KNOWN_TOOLS = [
  "http_fetch",
  "url_navigate",
  "web_search",
  "wikipedia_lookup",
  "calculator",
  "eval_js",
  "read_local_file",
  "append_memory",
  "export_memory",
  "import_memory",
  "conversation_recall",
  "concept_lookup",
  "write_program",
  "intent_routing",
  "fact_lookup",
  "summarize_conversation",
  "brainstorm",
  "coreference",
  "roleplay",
];

// Issue #497: GitHub repository traffic visibility is a platform-policy answer,
// not a live repository-info fetch: the github_repository_traffic rules of
// data/seed/handler-rules.lino, run as the native interpreter runs them. Since
// #1175 R3 the answer names the repository the prompt names (an owner/name
// slug, or the assistant's own for "your repository"), and a question about an
// unnamed repository answers for any repository through the refusal lane.
function tryGithubRepositoryTraffic(prompt) {
  return runHandlerRuleSet("github_repository_traffic", prompt, String(prompt || "").toLowerCase(), []);
}

function githubRepositoryInfoRequest(prompt, normalized) {
  const repo = repositoryFromPrompt(prompt);
  if (!repo || !repo.platform || repo.platform.slug !== "github") return null;
  const markers = [
    "extract information",
    "main programming language",
    "programming language",
    "number of stars",
    "star count",
    "stars",
    "last commit",
    "readme",
  ];
  if (!containsAny(normalized, markers)) return null;
  return repo;
}

function githubApiRepositoryUrl(repo, suffix) {
  const owner = encodeURIComponent(repo.owner);
  const name = encodeURIComponent(repo.name);
  return `https://api.github.com/repos/${owner}/${name}${suffix || ""}`;
}

async function fetchGithubJson(url, label, diagnostics) {
  if (typeof fetch !== "function") {
    throw new Error("fetch unavailable");
  }
  const startedAt = Date.now();
  const headers = { Accept: "application/vnd.github+json" };
  const response = await fetch(url, { headers });
  const text = await response.text();
  const entry = {
    providerId: "github",
    url,
    method: "GET",
    requestHeaders: headers,
    ok: Boolean(response && response.ok),
    status: response ? response.status : 0,
    statusText: response ? response.statusText : "",
    elapsedMs: Date.now() - startedAt,
    responseSnippet: text.slice(0, 1024),
    unified: `github_api ${label}`,
  };
  if (Array.isArray(diagnostics)) diagnostics.push(entry);
  if (!response || !response.ok) {
    throw new Error(`HTTP ${entry.status} ${entry.statusText}`.trim());
  }
  try {
    return text ? JSON.parse(text) : null;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    throw new Error(`JSON parse failed: ${message}`);
  }
}

function decodeGithubReadmeContent(readme) {
  if (!readme || typeof readme !== "object") return "";
  if (typeof readme.content === "string" && readme.encoding === "base64") {
    const encoded = readme.content.replace(/\s+/g, "");
    if (typeof atob !== "function") return "";
    try {
      const binary = atob(encoded);
      const bytes = new Uint8Array(binary.length);
      for (let index = 0; index < binary.length; index += 1) {
        bytes[index] = binary.charCodeAt(index);
      }
      if (typeof TextDecoder === "function") {
        return new TextDecoder("utf-8").decode(bytes);
      }
      let decoded = "";
      for (let index = 0; index < binary.length; index += 1) {
        decoded += String.fromCharCode(bytes[index]);
      }
      return decoded;
    } catch (_error) {
      return "";
    }
  }
  return "";
}

function pushUniqueToolName(out, seen, name) {
  const cleaned = String(name || "")
    .trim()
    .replace(/^[@#]+/u, "")
    .replace(/[.,:;!?]+$/u, "");
  if (!cleaned || cleaned.length > 48) return;
  if (!/^[a-z][a-z0-9_-]*$/i.test(cleaned)) return;
  const key = cleaned.toLowerCase();
  if (seen.has(key)) return;
  seen.add(key);
  out.push(cleaned);
}

function pushUniqueToolDisplayName(out, seen, name) {
  const cleaned = String(name || "")
    .replace(/`+/gu, "")
    .replace(/\*\*/gu, "")
    .trim()
    .replace(/[.,:;!?]+$/u, "")
    .replace(/\s+/gu, " ");
  if (!cleaned || cleaned.length > 80 || !/[A-Za-z]/u.test(cleaned)) return;
  if (/\b(?:agentic|available|supported|search|execution|utility)\s+tools?\b/i.test(cleaned)) {
    return;
  }
  const key = cleaned.toLowerCase();
  if (seen.has(key)) return;
  seen.add(key);
  out.push(cleaned);
}

function extractReadmeTools(markdown) {
  const text = String(markdown || "");
  const lower = text.toLowerCase();
  const out = [];
  const seen = new Set();
  for (const tool of GITHUB_README_KNOWN_TOOLS) {
    if (lower.includes(tool.toLowerCase())) {
      pushUniqueToolName(out, seen, tool);
    }
  }
  const lines = text.split(/\r?\n/);
  let inToolsSection = false;
  let toolsSectionLevel = 0;
  for (const line of lines) {
    const heading = /^(\s{0,3})(#{1,6})\s+(.+?)\s*#*\s*$/u.exec(line);
    if (heading) {
      const level = heading[2].length;
      const headingText = heading[3].trim();
      if (/\btools?\b/i.test(headingText)) {
        inToolsSection = true;
        toolsSectionLevel = level;
      } else if (inToolsSection && level > toolsSectionLevel) {
        pushUniqueToolDisplayName(out, seen, headingText);
      } else {
        inToolsSection = false;
        toolsSectionLevel = 0;
      }
      continue;
    }
    if (!inToolsSection) continue;
    const bullet = /^\s*[-*+]\s+(?:`([^`]+)`|([A-Za-z][A-Za-z0-9_-]*))/u.exec(line);
    if (bullet) {
      pushUniqueToolName(out, seen, bullet[1] || bullet[2]);
    }
    const codeMatches = line.matchAll(/`([A-Za-z][A-Za-z0-9_-]*)`/gu);
    for (const match of codeMatches) {
      pushUniqueToolName(out, seen, match[1]);
    }
  }
  return out;
}

function githubCommitDate(commits) {
  if (!Array.isArray(commits) || commits.length === 0) return null;
  const commit = commits[0] && commits[0].commit ? commits[0].commit : null;
  return (
    (commit && commit.committer && commit.committer.date) ||
    (commit && commit.author && commit.author.date) ||
    null
  );
}

async function tryGithubRepositoryInfo(repo, language, preferences = {}) {
  const diagnostics = [];
  const errors = [];
  let repoData = null;
  let commits = null;
  let readme = null;

  // Issue #444: honor the GitHub opt-out. When disabled we skip every live
  // api.github.com fetch and report that the trusted service was turned off in
  // settings instead of contacting it.
  const githubEnabled = externalServiceEnabled(preferences, "externalServiceGithub");
  if (githubEnabled) {
    try {
      repoData = await fetchGithubJson(githubApiRepositoryUrl(repo), "repository", diagnostics);
    } catch (error) {
      errors.push(`repository: ${error instanceof Error ? error.message : String(error)}`);
    }
    try {
      commits = await fetchGithubJson(
        githubApiRepositoryUrl(repo, "/commits?per_page=1"),
        "commits",
        diagnostics,
      );
    } catch (error) {
      errors.push(`commits: ${error instanceof Error ? error.message : String(error)}`);
    }
    try {
      readme = await fetchGithubJson(githubApiRepositoryUrl(repo, "/readme"), "readme", diagnostics);
    } catch (error) {
      errors.push(`readme: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  const slug = repositorySlug(repo);
  const readmeMarkdown = decodeGithubReadmeContent(readme);
  const payload = {
    repository: (repoData && repoData.full_name) || slug,
    mainProgrammingLanguage: (repoData && repoData.language) || null,
    stars:
      repoData && Number.isFinite(Number(repoData.stargazers_count))
        ? Number(repoData.stargazers_count)
        : null,
    lastCommitDate: githubCommitDate(commits) || null,
    readmeTools: extractReadmeTools(readmeMarkdown),
  };
  if (errors.length > 0) {
    payload.errors = errors;
  }
  if (!githubEnabled) {
    payload.note = "GitHub is disabled in settings; no live data was fetched.";
  }
  const content = `\`\`\`json\n${JSON.stringify(payload, null, 2)}\n\`\`\``;
  return {
    intent: "github_repo_info",
    content,
    confidence: !githubEnabled ? 0.4 : errors.length === 0 ? 0.92 : 0.55,
    evidence: [
      `github_repo_info:repository:${slug}`,
      ...(githubEnabled
        ? [`source:${repo.url}`, "source:https://api.github.com"]
        : ["github_repo_info:service_disabled:github"]),
      `language:${language}`,
      ...(errors.length > 0 ? errors.map((error) => `github_repo_info:error:${error}`) : []),
    ],
    diagnostics: {
      providers: [],
      httpExchanges: diagnostics,
    },
  };
}

function genericProjectLookupAnswer(prompt, language, repo, promotionEnabled) {
  const evidence = [];
  if (!promotionEnabled) evidence.push("project_lookup:promotion:disabled");
  if (repo) {
    const slug = repositorySlug(repo);
    evidence.push(`project_lookup:repository:${repo.platform.slug}:${slug}`);
    evidence.push(`source:${repo.url}`);
    let content;
    if (language === "ru") {
      content = `Это запрос о репозитории [${slug}](${repo.url}) на ${repo.platform.label}.\n\nОбычный путь project_lookup ищет и резюмирует README или описание проекта на GitHub, GitLab и Bitbucket без особого правила для отдельного названия. Если репозиторий находится в продвигаемых организациях и продвижение включено, он будет показан первым.`;
    } else if (language === "hi") {
      content = `यह ${repo.platform.label} पर रिपॉजिटरी [${slug}](${repo.url}) के लिए lookup है.\n\nGeneric project_lookup path GitHub, GitLab, और Bitbucket पर README या project descriptions summarize कर सकता है, किसी single name के लिए special case के बिना. अगर repository promoted organizations में है और promotion enabled है, तो वह पहले दिखाई जाएगी.`;
    } else if (language === "zh") {
      content = `这是 ${repo.platform.label} 上的仓库查询： [${slug}](${repo.url})。\n\n通用 project_lookup 路径可以汇总 GitHub、GitLab 和 Bitbucket 上的 README 或项目描述，不需要为单个名称写特殊规则。如果该仓库属于 promoted organizations 且 promotion 已开启，它会优先显示。`;
    } else {
      content = `This is a repository lookup for [${slug}](${repo.url}) on ${repo.platform.label}.\n\nThe generic project_lookup path can summarize README or project descriptions from GitHub, GitLab, and Bitbucket without a special case for any single name. If the repository belongs to a promoted organization and promotion is enabled, that repository is listed first.`;
    }
    return { intent: "project_lookup", content, confidence: 0.82, evidence };
  }
  evidence.push("project_lookup:repository_hosts:GitHub,GitLab,Bitbucket");
  let content;
  if (language === "ru") {
    content = "Это обычный запрос project_lookup о проекте или репозитории.\n\nЯ не выделяю специальный репозиторий, потому что продвижение ассоциативных репозиториев отключено. Дальше следует искать и резюмировать подходящие проекты на GitHub, GitLab и Bitbucket и похожих хостингах.";
  } else if (language === "hi") {
    content = "यह project या repository के लिए generic project_lookup request है.\n\nमैं किसी specific repository को प्राथमिकता नहीं दे रहा हूँ क्योंकि associative repository promotion disabled है. अगला step GitHub, GitLab, Bitbucket और similar hosts पर matching projects खोजना और summarize करना है.";
  } else if (language === "zh") {
    content = "这是一个关于项目或仓库的通用 project_lookup 请求。\n\n我不会优先选择某个特定仓库，因为 associative repository promotion 已关闭。下一步是在 GitHub、GitLab、Bitbucket 和类似托管平台中搜索并汇总匹配项目。";
  } else {
    content = "This is a generic project_lookup request for a project or repository.\n\nI am not privileging a specific repository because associative repository promotion is disabled. The next step is to search and summarize matching projects across GitHub, GitLab, Bitbucket, and similar hosts.";
  }
  return { intent: "project_lookup", content, confidence: 0.72, evidence };
}

async function renderPromotedProjectLookup(prompt, language, project) {
  const displayName = projectDisplayName(project, language);
  const repository = projectRepoSlug(project);
  const url = project.url || `https://github.com/${repository}`;
  const description = describeProjectRecord(project, language, "short");
  const providers = WEB_SEARCH_PROVIDERS.map((provider) => provider.id);
  const fusionConstant = webSearchRrfK();
  const body = projectSummaryResponse("project-lookup-promoted", language, {
    "promoted-orgs": PROMOTED_PROJECT_ORGS.join(", "),
    "display-name": displayName,
    "repo-slug": repository,
    "project-url": url,
    description,
    "provider-summary": providers.join(", "),
    "reciprocal-rank-constant": fusionConstant,
  });
  const search = await runWebSearchQuery(displayName, language);
  const evidence = [
    `project:promoted:${repository}`, `source:${url}`,
    "summarization:mode:short", `summarization:language:${language}`,
    `web_search:request:${displayName}`,
    ...providers.map((provider) => `web_search:provider_planned:${provider}`),
    `web_search:fusion_planned:rrf:k=${fusionConstant}`,
    ...(search && Array.isArray(search.evidence) ? search.evidence : []),
  ];
  const grounded = search && search.diagnostics &&
    Array.isArray(search.diagnostics.fused) && search.diagnostics.fused.length > 0;
  return {
    intent: "project_lookup",
    content: grounded ? `${body}\n\n${search.content}` : body,
    confidence: 0.9, evidence,
    ...(search && search.diagnostics ? { diagnostics: search.diagnostics } : {}),
  };
}

async function tryProjectLookup(prompt, language, preferences) {
  // A guide being converted quotes its repository as content; Rust asks installation_conversion first.
  if (tryInstallationConversion(prompt, normalizePrompt(prompt))) return null;
  if (!projectLookupPhaseAdmits(prompt)) return null;
  return tryProjectLookupForPrompt(prompt, prompt, language, preferences);
}

const PROJECT_LOOKUP_EXECUTION_FILE = "method-execution.lino";
const PROJECT_LOOKUP_ATTRIBUTE = "project_lookup";
const PROJECT_LOOKUP_FALLBACK_PHASE = "fallback";
const PROJECT_LOOKUP_IDENTITY_ROUTE = "identity";

// The worker functions of the methods a name lookup is the fallback of
// (`project_lookup fallback` in data/seed/method-execution.lino).
function projectLookupFallbackHandlers() {
  const text = typeof SEED_RAW === "object" ? seedRawText(SEED_RAW, PROJECT_LOOKUP_EXECUTION_FILE) : "";
  const methods = (parseLinoTree(text).children[0]?.children || [])
    .filter((node) => node.children.some((child) =>
      child.name === PROJECT_LOOKUP_ATTRIBUTE && child.value === PROJECT_LOOKUP_FALLBACK_PHASE))
    .map((node) => node.value);
  const bindings = typeof WORKER_HANDLER_REGISTRY === "object" ? WORKER_HANDLER_REGISTRY.workerHandlers : {};
  return methods.map((slug) => self[bindings[slug]]).filter((handler) => typeof handler === "function");
}

// The two phases rust/src/meta_method_dispatch.rs runs project lookup in
// (R1188-U29): an explicit repository reference before the runtime methods,
// unless a fetch or navigation URL claims it (`try_explicit_repository_lookup`);
// a name lookup only as the fallback of the methods above, once their own
// handler declines, and never on the identity route.
function projectLookupPhaseAdmits(prompt) {
  const normalized = normalizePrompt(prompt);
  if (repositoryFromPrompt(prompt)) {
    return extractHttpFetchUrl(prompt, normalized) === null && extractUrlNavigateUrl(prompt, normalized) === null;
  }
  if (solverIntentRoute(prompt) === PROJECT_LOOKUP_IDENTITY_ROUTE) return false;
  return !projectLookupFallbackHandlers().some((handler) => handler(prompt));
}

async function tryProjectLookupForPrompt(prompt, lookupPrompt, language, preferences) {
  if (isTextUrlExtractionPrompt(lookupPrompt)) return null;
  if (githubRepositoryInfoRequest(lookupPrompt, String(lookupPrompt || "").toLowerCase())) {
    return null;
  }
  const promotionEnabled = projectPromotionEnabled(preferences);
  const repo = repositoryFromPrompt(lookupPrompt);
  if (repo) {
    const promoted = promotionEnabled
      ? promotedProjectByRepo(repo.owner, repo.name)
      : null;
    if (promoted) {
      return renderPromotedProjectLookup(prompt, language, promoted);
    }
    return genericProjectLookupAnswer(prompt, language, repo, promotionEnabled);
  }

  const query = extractConceptQuery(lookupPrompt);
  if (!query) return null;
  const project = projectByAlias(query.termOriginal || query.term);
  if (!project) return null;
  if (promotionEnabled && isPromotedProject(project)) {
    return renderPromotedProjectLookup(prompt, language, project);
  }
  return genericProjectLookupAnswer(prompt, language, null, promotionEnabled);
}

// A follow-up fires when the user reports they cannot understand the prior
// answer (seed-grounded detectComprehensionFailure) or when the prompt is a
// terse language-switch request. In the terse case the caller has already
// confirmed a seed-grounded response-language marker is present, so a short
// prompt with no fresh subject of its own is treated as a retarget of the
// previous turn. Mirrors is_language_reanswer_followup in
// src/solver_handlers/response_language_followup.rs — the whole phrase table
// lives in data/seed/meanings-translation.lino, not here (issue #556).
function isLanguageReanswerFollowup(normalized) {
  const text = String(normalized || "").trim().toLowerCase();
  if (!text) return false;
  if (detectComprehensionFailure(text)) return true;
  // CJK markers carry no inter-word spaces, so a bare "用中文" counts as one
  // word here — still terse, still a switch. How short is the
  // terse-word-limit policy of data/seed/handler-rules.lino.
  const wordCount = text.split(/\s+/u).filter(Boolean).length;
  return wordCount <= Number(handlerRulesPolicy("response_language_followup", "terse-word-limit") || 0);
}

// Intents that mean the replay never reached a concrete answer, so the
// retarget is not a useful re-answer and we fall through to the normal
// handlers. Mirrors is_inconclusive in
// src/solver_handlers/response_language_followup.rs.
function isInconclusiveReplayIntent(intent) {
  const value = String(intent || "");
  return (
    value === "unknown" ||
    value === "ill_formed" ||
    value === "punctuation_only_prompt" ||
    value === "concept_lookup_unresolved" ||
    value.startsWith("clarify")
  );
}

// Issue #556: a response-language follow-up ("I do not understand English,
// write in Russian") is not a new question. It replays the previous request
// through the *whole* solver with the requested language forced onto every
// localizable handler, so the retarget covers the entire answerable class —
// not just project lookups. Mirrors try_response_language_followup in
// src/solver_handlers/response_language_followup.rs.
async function tryResponseLanguageFollowup(prompt, normalized, history, preferences) {
  // A directive against a language ("never answer in Russian") is not a request to re-answer in it.
  if (responseLanguageForbidden(prompt)) return null;
  const targetLanguage = detectResponseLanguage(normalized);
  if (!targetLanguage) return null;
  if (!isLanguageReanswerFollowup(normalized)) return null;

  // Recover the most recent user request and the history that preceded it, so
  // the replay sees the same context the original answer did.
  if (!Array.isArray(history)) return null;
  let previousIndex = -1;
  for (let index = history.length - 1; index >= 0; index -= 1) {
    const turn = history[index];
    if (turn && turn.role === "user" && turn.content) {
      previousIndex = index;
      break;
    }
  }
  if (previousIndex < 0) return null;
  const previousUser = String(history[previousIndex].content || "").trim();
  if (!previousUser) return null;
  const priorHistory = history.slice(0, previousIndex);

  // Replay through the whole solver with the requested language forced. The
  // forced language doubles as the recursion guard inside solve().
  const replay = await solve(previousUser, priorHistory, preferences, {}, [], {
    forcedResponseLanguage: targetLanguage,
  });
  if (!replay || isInconclusiveReplayIntent(replay.intent)) return null;

  // Splice the follow-up provenance onto the replayed answer; the answer's own
  // evidence (repository slug, sources, language_to:<code>) already comes from
  // the replay, so these markers only name *why* it was produced.
  const followupEvidence = [
    `response_language_followup:target:${targetLanguage}`,
    `language_to:${targetLanguage}`,
    `response_language_followup:handler:${replay.intent}`,
  ];
  const existing = Array.isArray(replay.evidence) ? replay.evidence : [];
  const merged = existing.slice();
  for (const marker of followupEvidence) {
    if (!merged.includes(marker)) merged.push(marker);
  }
  return { ...replay, evidence: merged };
}

function pickPrimaryProviderId(providers, sourceKind) {
  if (sourceKind === "wikidata") return "wikidata";
  if (sourceKind === "wikipedia") return "wikipedia";
  if (sourceKind === "wiktionary") return "wiktionary";
  if (sourceKind === "internet-archive") return "internet-archive";
  if (Array.isArray(providers) && providers.length > 0) {
    const sorted = providers.slice().sort(
      (a, b) => (WEB_SEARCH_PROVIDER_PRIORITY[a.id] || 999) - (WEB_SEARCH_PROVIDER_PRIORITY[b.id] || 999),
    );
    return sorted[0].id;
  }
  return "";
}

function cleanContextValue(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function evidenceFromUserContext(userContext) {
  if (!userContext || typeof userContext !== "object") return [];
  const evidence = [];
  const fields = [
    ["uiLanguage", "ui_language"],
    ["browserLanguage", "browser_language"],
    ["colorScheme", "color_scheme"],
    ["timeZone", "time_zone"],
    ["locationInference", "location_inference"],
  ];
  for (const [key, label] of fields) {
    const value = cleanContextValue(userContext[key]);
    if (value) evidence.push(`user_context:${label}:${value}`);
  }
  return evidence;
}

function attachUserContext(answer, userContext) {
  if (!answer || typeof answer !== "object") return answer;
  const evidence = evidenceFromUserContext(userContext);
  if (evidence.length === 0) return answer;
  const steps = Array.isArray(answer.steps) ? answer.steps.slice() : [];
  const detail = evidence
    .map((item) => item.replace(/^user_context:/, ""))
    .join(", ");
  steps.push({ step: "user_context", detail });
  return Object.assign({}, answer, {
    evidence: [
      ...(Array.isArray(answer.evidence) ? answer.evidence : []),
      ...evidence,
    ],
    steps: withThinkingLevels(steps),
  });
}

// Issue #153: every prompt should be formalized as a Subject-Verb-Object tuple
// regardless of source language. We emit a deterministic, offline formalization
// here (so the trace is stable even when no APIs are reachable) and, when a
// downstream handler resolves the object to a Wikidata/Wikipedia/Wiktionary
// item, we emit a second `formalize_resolved` step with the real ids. Ids use
// canonical prefixes: `Q<n>` / `P<n>` for Wikidata, `WP:<title>` for
// Wikipedia-only items, `WT:<word>` for Wiktionary-only items, `OP:<verb>` for
// the symbolic operation, and `@USER` for the implicit user subject.
const FORMALIZATION_VERBS = [
  // English
  { verb: "what are the steps to", op: "OP:procedure" },
  { verb: "show me how to", op: "OP:procedure" },
  { verb: "tell me how to", op: "OP:procedure" },
  { verb: "how should i", op: "OP:procedure" },
  { verb: "how could i", op: "OP:procedure" },
  { verb: "how would i", op: "OP:procedure" },
  { verb: "how can i", op: "OP:procedure" },
  { verb: "how do i", op: "OP:procedure" },
  { verb: "how to", op: "OP:procedure" },
  { verb: "search", op: "OP:search" },
  { verb: "find", op: "OP:search" },
  { verb: "lookup", op: "OP:lookup" },
  { verb: "look up", op: "OP:lookup" },
  { verb: "define", op: "OP:define" },
  { verb: "what is", op: "OP:define" },
  { verb: "who is", op: "OP:identify" },
  { verb: "explain", op: "OP:define" },
  { verb: "compute", op: "OP:compute" },
  { verb: "calculate", op: "OP:compute" },
  { verb: "hello", op: "OP:greet" },
  { verb: "hi", op: "OP:greet" },
  { verb: "goodbye", op: "OP:farewell" },
  { verb: "bye", op: "OP:farewell" },
  // Russian
  { verb: "найди", op: "OP:search" },
  { verb: "поищи", op: "OP:search" },
  { verb: "поиск", op: "OP:search" },
  { verb: "что такое", op: "OP:define" },
  { verb: "кто такой", op: "OP:identify" },
  { verb: "объясни", op: "OP:define" },
  { verb: "посчитай", op: "OP:compute" },
  { verb: "вычисли", op: "OP:compute" },
  { verb: "привет", op: "OP:greet" },
  { verb: "здравствуй", op: "OP:greet" },
  { verb: "пока", op: "OP:farewell" },
  { verb: "до свидания", op: "OP:farewell" },
  // Hindi
  { verb: "खोज", op: "OP:search" },
  { verb: "ढूंढ", op: "OP:search" },
  { verb: "क्या है", op: "OP:define" },
  { verb: "कौन है", op: "OP:identify" },
  { verb: "नमस्ते", op: "OP:greet" },
  { verb: "अलविदा", op: "OP:farewell" },
  // Chinese
  { verb: "搜索", op: "OP:search" },
  { verb: "查找", op: "OP:search" },
  { verb: "什么是", op: "OP:define" },
  { verb: "是谁", op: "OP:identify" },
  { verb: "你好", op: "OP:greet" },
  { verb: "再见", op: "OP:farewell" },
];

function exactFormalizationMatch(prompt, normalized) {
  const haystack = String(normalized || "").toLowerCase();
  const raw = String(prompt || "");
  const rawLower = String(prompt || "").toLowerCase();
  for (const { verb, op } of FORMALIZATION_VERBS) {
    if (haystack.startsWith(verb + " ") || haystack === verb) {
      return {
        op,
        verb,
        objectText: haystack === verb ? "" : normalized.slice(verb.length),
        interpretations: [],
      };
    }
    if (rawLower.startsWith(verb + " ") || rawLower === verb) {
      return {
        op,
        verb,
        objectText: rawLower === verb ? "" : raw.slice(verb.length),
        interpretations: [],
      };
    }
    if (haystack.includes(" " + verb + " ")) {
      return { op, verb, objectText: null, interpretations: [] };
    }
  }
  return null;
}

function fuzzyFormalizationMatch(prompt) {
  const matches = FORMALIZATION_VERBS
    .map((entry) => {
      const match = fuzzyPrefixMatch(prompt, entry.verb);
      return match ? Object.assign({ entry }, match) : null;
    })
    .filter(Boolean)
    .sort((left, right) =>
      left.typoCount - right.typoCount || right.end - left.end,
    );
  const best = matches[0];
  if (!best) return null;
  const peers = matches.filter(
    (match) => match.typoCount === best.typoCount && match.end === best.end,
  );
  if (peers.length > 1) {
    return {
      ambiguous: true,
      suggestions: peers.map((match) => match.entry.verb),
      interpretations: [],
    };
  }
  return {
    op: best.entry.op,
    verb: best.entry.verb,
    objectText: String(prompt || "").slice(best.end),
    interpretations: [best.interpretation],
  };
}

function detectFormalizationMatch(prompt, normalized) {
  return exactFormalizationMatch(prompt, normalized) || fuzzyFormalizationMatch(prompt);
}
