// Trusted-source recurrence discovery for the browser worker.
//
// This module consumes a rebuildable cache generated from captured
// Wikifunctions abstract definitions, testers, and Wikidata aliases. The cache
// is procedure memory rather than semantic seed knowledge: deleting it and
// running `cargo run --example generate_recurrence_source_cache -- --write`
// reconstructs it byte-for-byte.

let cachedRecurrenceSourceRecords;

async function hydrateLinoSeedAndSourceCaches(raw) {
  hydrateLinoSeedText(raw);
  self.FORMAL_AI_RECURRENCE_SOURCE_CACHE_LINO = "";
  try {
    const response = await fetch(
      withAssetVersion("source-cache/wikifunctions-recurrences.lino"),
    );
    if (response && response.ok) {
      self.FORMAL_AI_RECURRENCE_SOURCE_CACHE_LINO = await response.text();
    }
  } catch (_error) {
    self.FORMAL_AI_RECURRENCE_SOURCE_CACHE_LINO = "";
  }
  cachedRecurrenceSourceRecords = undefined;
}

function recurrenceSourceRecords() {
  if (cachedRecurrenceSourceRecords !== undefined) {
    return cachedRecurrenceSourceRecords;
  }
  const root = parseLinoTree(
    String(self.FORMAL_AI_RECURRENCE_SOURCE_CACHE_LINO || ""),
  );
  const catalog = root.children.find(
    (node) => node.name === "recurrence_source_cache",
  );
  cachedRecurrenceSourceRecords = catalog
    ? catalog.children.filter((node) => node.name === "recurrence")
    : [];
  return cachedRecurrenceSourceRecords;
}

function recurrenceFold(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .replace(/[^\p{L}\p{N}!]+/gu, " ")
    .trim();
}

function recurrenceSourceMatch(prompt) {
  const folded = recurrenceFold(prompt);
  let best = null;
  for (const record of recurrenceSourceRecords()) {
    const forms = [codingChildValue(record, "label")].concat(
      record.children
        .filter((child) => child.name === "alias")
        .map((alias) => codingChildValue(alias, "text")),
    );
    const matched = forms
      .map(recurrenceFold)
      .filter((form) => form.length >= 3 && folded.includes(form))
      .sort((left, right) => right.length - left.length)[0];
    if (matched && (!best || matched.length > best.length)) {
      best = { record, length: matched.length };
    }
  }
  return best ? best.record : null;
}

function recurrenceExpressionNode(record) {
  const container = codingFindChild(record, "expression");
  return container && container.children.length === 1
    ? container.children[0]
    : null;
}

function renderRecurrenceExpression(node, functionName) {
  if (!node) return null;
  const rendered = node.children.map((child) =>
    renderRecurrenceExpression(child, functionName),
  );
  if (rendered.some((value) => value === null)) return null;
  if (node.name === "parameter") return node.value;
  if (node.name === "literal") return node.value;
  if (node.name === "recur" && rendered.length === 1) {
    const argument =
      rendered[0].startsWith("(") && rendered[0].endsWith(")")
        ? rendered[0].slice(1, -1)
        : rendered[0];
    return `${functionName}(${argument})`;
  }
  if (node.name === "conditional" && rendered.length === 3) {
    return `${rendered[1]} if ${rendered[0]} else ${rendered[2]}`;
  }
  const binary = {
    less_equal: "<=",
    equal: "==",
    add: "+",
    multiply: "*",
    subtract: "-",
  }[node.name];
  if (binary && rendered.length === 2) {
    return `(${rendered[0]} ${binary} ${rendered[1]})`;
  }
  if (node.name === "subtract_one" && rendered.length === 1) {
    return `${rendered[0]} - 1`;
  }
  return null;
}

function evaluateRecurrenceExpression(node, root, parameter, value, depth) {
  if (!node || depth > 10000) return null;
  if (node.name === "parameter") return node.value === parameter ? value : null;
  if (node.name === "literal") {
    const literal = Number(node.value);
    return Number.isFinite(literal) ? literal : null;
  }
  if (node.name === "recur" && node.children.length === 1) {
    const argument = evaluateRecurrenceExpression(
      node.children[0],
      root,
      parameter,
      value,
      depth + 1,
    );
    if (!Number.isInteger(argument) || argument < 0) return null;
    return evaluateRecurrenceExpression(
      root,
      root,
      parameter,
      argument,
      depth + 1,
    );
  }
  if (node.name === "conditional" && node.children.length === 3) {
    const condition = evaluateRecurrenceExpression(
      node.children[0],
      root,
      parameter,
      value,
      depth + 1,
    );
    if (condition === null) return null;
    return evaluateRecurrenceExpression(
      condition ? node.children[1] : node.children[2],
      root,
      parameter,
      value,
      depth + 1,
    );
  }
  const operands = node.children.map((child) =>
    evaluateRecurrenceExpression(child, root, parameter, value, depth + 1),
  );
  if (operands.some((operand) => operand === null)) return null;
  if (node.name === "less_equal" && operands.length === 2) {
    return operands[0] <= operands[1];
  }
  if (node.name === "equal" && operands.length === 2) {
    return operands[0] === operands[1];
  }
  if (node.name === "add" && operands.length === 2) {
    return operands[0] + operands[1];
  }
  if (node.name === "multiply" && operands.length === 2) {
    return operands[0] * operands[1];
  }
  if (node.name === "subtract" && operands.length === 2) {
    return operands[0] - operands[1];
  }
  if (node.name === "subtract_one" && operands.length === 1) {
    return operands[0] - 1;
  }
  return null;
}

function verifiedRecurrenceRecord(record) {
  const root = recurrenceExpressionNode(record);
  const parameter = codingChildValue(record, "parameter");
  const tests = record.children.filter((child) => child.name === "source_test");
  return (
    root &&
    parameter &&
    tests.length > 0 &&
    tests.every((test) => {
      const argument = Number(codingChildValue(test, "argument"));
      const expected = Number(codingChildValue(test, "expected"));
      return (
        Number.isFinite(argument) &&
        Number.isFinite(expected) &&
        evaluateRecurrenceExpression(root, root, parameter, argument, 0) === expected
      );
    })
  );
}

function recurrenceObservation(prompt) {
  const match = String(prompt || "").match(/\b(\d+)(?:st|nd|rd|th)?\b/i);
  // Shared policy for a bounded demonstration when no observation was asked.
  return match ? Number(match[1]) : 10;
}
