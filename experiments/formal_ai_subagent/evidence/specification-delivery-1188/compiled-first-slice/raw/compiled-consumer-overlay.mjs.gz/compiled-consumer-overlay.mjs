// Selected in-memory first-slice preparation; repository sources stay unchanged.
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import vm from 'node:vm';
import {compileSkill} from './compiled-skill-prototype.mjs';
import {installScratchCompiledReplay} from './compiled-skill-worker-overlay.mjs';
import {formatLinoValue} from '/Users/konard/Code/Archive/link-assistant/formal-ai/js/agentic/crate/links_format.mjs';
export async function installScratchCompiledConsumers(worker){
 const replay=await installScratchCompiledReplay(worker);const context=await worker.boot();
 context.__scratchCompilePackage=text=>{const p=compileSkill(String(text));return p.status==='compiled'?{...p,answer:p.response}:null;};
 context.__scratchFormatValue=formatLinoValue;
 const changed=[];function install(name,body){new vm.Script(body,{filename:'selected-scratch-'+name+'.js'}).runInContext(context);changed.push(name);}
 install('runtimeRuleFromText','function runtimeRuleFromText(text){return __scratchCompilePackage(text);}');
 const handler=vm.runInContext('tryBehaviorRules.toString()',context);
 const teaching='      evidence: ["behavior_rule:update", updateRule.id],';
 if(handler.split(teaching).length!==2)throw new Error('actual teaching branch absent or ambiguous');
 const nativeTeaching='      evidence: [],\n      solverEvents: [{kind:"skill_compile:package",payload:updateRule.id},{kind:"behavior_rule:update",payload:updateRule.legacy_behavior_rule_id}],';
 const count='      content: renderBehaviorRuleCount(runtimeRules, language),';
 if(handler.split(count).length!==2)throw new Error('actual count branch absent or ambiguous');
 const nativeCount=count+'\n      solverEvents: [{kind:"behavior_rules:count",payload:String(counts.total)},{kind:"behavior_rules:built_in_count",payload:String(counts.builtIn)},{kind:"behavior_rules:runtime_count",payload:String(counts.runtime)},{kind:"reasoning:operation",payload:"count_behavior_rules_catalog_plus_dialog_local_rules"},{kind:"reasoning:result",payload:`built_in=${counts.builtIn};runtime=${counts.runtime};total=${counts.total}`}],';
 install('tryBehaviorRules',handler.replace(teaching,nativeTeaching).replace(count,nativeCount));
 const list=vm.runInContext('renderBehaviorRuleList.toString()',context);
 const quoted=String.fromCharCode(92,96);
 const oldLine='lines.push(`- '+quoted+'${rule.id}'+quoted+' -> ${runtimeRuleWhenThen(rule, language)}`);';
 const newLine='lines.push(`- '+quoted+'${rule.id}'+quoted+' ('+quoted+'${rule.legacy_behavior_rule_id}'+quoted+') -> ${runtimeRuleWhenThen(rule, language)}`);';
 if(list.split(oldLine).length!==2)throw new Error('actual runtime list line absent or ambiguous');
 install('renderBehaviorRuleList',list.replace(oldLine,newLine));
 context.__scratchOriginalCount=vm.runInContext('renderBehaviorRuleCount',context);
 install('renderBehaviorRuleCount','function renderBehaviorRuleCount(runtimeRules,language="en"){return __scratchOriginalCount(runtimeRules,language)+"\\n";}');
 install('renderRuntimeRuleUpdate',`function renderRuntimeRuleUpdate(rule,language="en"){
  const whenThen=runtimeRuleWhenThen(rule,language);const title=behaviorRuleText("update_title",language);const hint=behaviorRuleText("update_send_hint",language,{trigger:rule.trigger});
  const fence=String.fromCharCode(96).repeat(3);return [title,"",whenThen,"",fence+"links",rule.id,'  type "compiled_skill_package"','  legacy_behavior_rule_id '+__scratchFormatValue(rule.legacy_behavior_rule_id),'  match_prompt '+__scratchFormatValue(rule.trigger),'  answer '+__scratchFormatValue(rule.response),'  when_then '+__scratchFormatValue(whenThen),'  compiled_handler '+__scratchFormatValue(rule.handler_id),'  replay_mode "exact_normalized_prompt"','  source "user_message"',fence,"",hint].join("\\n");
 }`);
 const path='/Users/konard/Code/Archive/link-assistant/formal-ai/js/worker/formal_ai_worker_behavior_rules_and_self_facts.js';
 return{replay,rendererSource:path,rendererSha256:createHash('sha256').update(readFileSync(path)).digest('hex'),changed,repositoryMutations:0};
}
