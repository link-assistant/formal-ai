import {WorkerHost} from '/Users/konard/Code/Archive/link-assistant/formal-ai/js/server/worker-host.mjs';
import {readFileSync,writeFileSync} from 'node:fs';import {createHash} from 'node:crypto';import {execFileSync} from 'node:child_process';
const root='/Users/konard/Code/Archive/link-assistant/formal-ai';
const host=new WorkerHost();const history=[];const turns=[];
for(const[phase,prompt]of[['teach','When the user says `checksum status`, answer `checksum cache is valid.`'],['count','How many behavior rules are there?'],['list','Show rules'],['replay','checksum status']]){
 const answer=await host.solve(prompt,history);turns.push({phase,prompt,history:structuredClone(history),answer});history.push({role:'user',content:prompt},{role:'assistant',content:answer.content});
}
const files=['js/agentic/crate/skill_compiler.mjs','js/worker/formal_ai_worker_capabilities_and_runtime_rules.js','js/worker/formal_ai_worker_behavior_rules_and_self_facts.js','js/worker/formal_ai_worker_crate_skill_compiler.js','js/worker-modules.js','rust/tests/unit/specification/natural_language_skill_compilation.rs','rust/tests/unit/specification/behavior_rules.rs'];
const source=files.map(file=>({file,sha256:createHash('sha256').update(readFileSync(root+'/'+file)).digest('hex')}));
const result={scope:'actual production WorkerHost user/assistant history; no overlays or mocked package cache',head:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),source,turns,authoritativeCarriedMetric:{total:1173,carried:136,passed:136,scope:'last root production checker; not remeasured or changed by this session'}};
writeFileSync('/private/tmp/spec-recurrence-1188/compiled-production-session.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({turns:turns.map(t=>({phase:t.phase,intent:t.answer.intent,compiledKinds:t.answer.solverEvents.filter(e=>['skill_compile:package','behavior_rule:update','compiled_skill:package','compiled_skill:replay','cache_hit'].includes(e.kind)).map(e=>e.kind)})),sourceCount:source.length,overlays:0}));
