import {readFileSync,writeFileSync} from 'node:fs';
const root=process.cwd();const dir='/private/tmp/spec-recurrence-1188';
const old=readFileSync(root+'/js/agentic/crate/skill_compiler.mjs','utf8');
let proto=readFileSync(dir+'/typed-reader-next/compiled-skill-prototype.mjs','utf8');
proto=proto.slice(proto.indexOf('const structuredLabels='),proto.indexOf('\nexport function collectPackages'));
proto=proto.replaceAll('compileSkill(', 'compileNaturalLanguageSkill(').replaceAll('schemaVersion', 'KNOWLEDGE_SCHEMA_VERSION');
proto=proto.replace("description.split(/\\r?\\n/u)","String(description).split(/\\r?\\n/u)");
const imports="\nimport { normalizePrompt } from './engine.mjs';\nimport { stableId } from './engine_stable_identifier.mjs';\nimport { pushLinoNode } from './links_format.mjs';\nimport { KNOWLEDGE_SCHEMA_VERSION } from './skill_procedure.mjs';\n";
const insertion=old.indexOf('\n/** Mirrors');
const compiler=old.slice(0,insertion)+imports+old.slice(insertion)+"\n// The trigger/response subset of CompiledSkillPackage. Structured IR remains\n// explicitly unsupported here until its permission and effect contracts carry.\n"+proto+'\n';
writeFileSync(dir+'/compiled-production-compiler.draft.mjs',compiler);
let runtime=readFileSync(root+'/js/worker/formal_ai_worker_capabilities_and_runtime_rules.js','utf8');
const begin=runtime.indexOf('function codeSpans(');const end=runtime.indexOf('\nfunction runtimeRuleForPrompt(',begin);
const shared=`const directRoleSurfacePresent = (role, lower) => roleWordForms(role).some((form) => form.text && lower.includes(form.text));

// All teaching, catalog and history replay consumers use the same package.
function runtimeRuleFromText(text) {
  const result = crateModule("crate/skill_compiler.mjs").compileNaturalLanguageSkill(String(text || ""));
  return result.status === "compiled" ? result : null;
}
`;
runtime=runtime.slice(0,begin)+shared+runtime.slice(end);
runtime=runtime.replace('  const normalizedPrompt = normalizePrompt(prompt);\n','').replace('if (rule && normalizePrompt(rule.trigger) === normalizedPrompt)', 'if (rule && rule.replay(prompt))');
runtime=runtime.replace('      evidence: ["behavior_rule:update", updateRule.id],','      evidence: [],\n      solverEvents: [solverEvent("skill_compile:package", updateRule.id),\n        solverEvent("behavior_rule:update", updateRule.legacy_behavior_rule_id)],');
const count='      content: renderBehaviorRuleCount(runtimeRules, language),';
runtime=runtime.replace(count,count+`\n      solverEvents: [solverEvent("behavior_rules:count", String(counts.total)),
        solverEvent("behavior_rules:built_in_count", String(counts.builtIn)),
        solverEvent("behavior_rules:runtime_count", String(counts.runtime)),
        solverEvent("reasoning:operation", "count_behavior_rules_catalog_plus_dialog_local_rules"),
        solverEvent("reasoning:result", \`built_in=\${counts.builtIn};runtime=\${counts.runtime};total=\${counts.total}\`)],`);
const before=`      content: runtimeRule.answer,
      confidence: 1.0,
      evidence: ["behavior_rule:match", runtimeRule.id],`;
const after=`      content: runtimeRule.response,
      confidence: 1.0,
      responseLink: \`response:\${runtimeRule.id}\`,
      evidence: [],
      solverEvents: [solverEvent("compiled_skill:package", runtimeRule.linksNotation()),
        solverEvent("compiled_skill:replay", runtimeRule.rule_id),
        solverEvent("cache_hit", runtimeRule.id)],`;
if(!runtime.includes(before))throw Error('replay branch missing');runtime=runtime.replace(before,after);
writeFileSync(dir+'/compiled-production-runtime.draft.js',runtime);
let renderer=readFileSync(root+'/js/worker/formal_ai_worker_behavior_rules_and_self_facts.js','utf8');
const countStart=renderer.indexOf('function renderBehaviorRuleCount(');const countEnd=renderer.indexOf('\nfunction renderBehaviorRulesBrief(',countStart);
const countBody=renderer.slice(countStart,countEnd).replace('  ].join("\\n");','  ].join("\\n") + "\\n";');
renderer=renderer.slice(0,countStart)+countBody+renderer.slice(countEnd);
renderer=renderer.replace('response: rule.answer','response: rule.response');
const oldList='lines.push(`- \\`${rule.id}\\` -> ${runtimeRuleWhenThen(rule, language)}`);';
const newList='lines.push(`- \\`${rule.id}\\` (\\`${rule.legacy_behavior_rule_id}\\`) -> ${runtimeRuleWhenThen(rule, language)}`);';
if(!renderer.includes(oldList))throw Error('runtime list missing');renderer=renderer.replace(oldList,newList);
const renderStart=renderer.indexOf('function renderRuntimeRuleUpdate(');const renderEnd=renderer.indexOf('\n// Issue #386:',renderStart);
let renderBody=renderer.slice(renderStart,renderEnd);
renderBody=renderBody.replace('  const whenThenText', '  const formatValue = crateModule("crate/links_format.mjs").formatLinoValue;\n  const whenThenText');
renderBody=renderBody.replace("    '  type \"behavior_rule_runtime\"',","    '  type \"compiled_skill_package\"',\n    `  legacy_behavior_rule_id ${formatValue(rule.legacy_behavior_rule_id)}`,");
renderBody=renderBody.replace('`  match_prompt "${escapeBehaviorRuleValue(rule.trigger)}"`','`  match_prompt ${formatValue(rule.trigger)}`').replace('`  answer "${escapeBehaviorRuleValue(rule.answer)}"`','`  answer ${formatValue(rule.response)}`').replace('`  when_then "${escapeBehaviorRuleValue(whenThenText)}"`','`  when_then ${formatValue(whenThenText)}`');
renderBody=renderBody.replace("    '  source \"user_message\"',","    `  compiled_handler ${formatValue(rule.handler_id)}`,\n    '  replay_mode \"exact_normalized_prompt\"',\n    '  source \"user_message\"',");
renderer=renderer.slice(0,renderStart)+renderBody+renderer.slice(renderEnd);
writeFileSync(dir+'/compiled-production-renderer.draft.js',renderer);
