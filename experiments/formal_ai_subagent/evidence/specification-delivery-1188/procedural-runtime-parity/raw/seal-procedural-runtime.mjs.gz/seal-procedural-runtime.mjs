import {readFileSync,writeFileSync,mkdirSync,readdirSync} from 'node:fs';
import {gzipSync,gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const scratch='/private/tmp/spec-recurrence-1188',root=process.cwd();
const relative='experiments/formal_ai_subagent/evidence/specification-delivery-1188/procedural-runtime-parity',base=root+'/'+relative;
mkdirSync(base+'/raw',{recursive:true});
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const tasks=Array.from({length:18},(_,i)=>'T'+(3141+i));
const names=readdirSync(scratch).filter(name=>tasks.some(task=>name.startsWith(task+'-')||name===task+'.log'));
names.push('procedural-worker.preimage.js','procedural-worker.draft.js','procedural-runtime-parity.test.mjs.draft','procedural-tests-correct-fields.draft','procedural-cases-retry-report.json','retry-procedural-cases.mjs','seal-procedural-runtime.mjs');
const artifacts=[];
for(const name of names){const bytes=readFileSync(scratch+'/'+name),compressed=gzipSync(bytes);if(!gunzipSync(compressed).equals(bytes))throw Error('loss');const artifact='raw/'+name+'.gz';writeFileSync(base+'/'+artifact,compressed);artifacts.push({artifact,origin:scratch+'/'+name,bytes:bytes.length,sha256:sha(bytes)});}
const counts={},calls=[];
for(const task of tasks){const item=JSON.parse(readFileSync(scratch+'/'+task+'-observation.json'));for(const call of item.calls){counts[call]=(counts[call]||0)+1;calls.push({task,call});}}
const sourcePaths=['js/worker/formal_ai_worker_search_queries_and_how_to.js','rust/tests/web/procedural-runtime-parity.test.mjs'];
const source=sourcePaths.map(file=>{const bytes=readFileSync(root+'/'+file);return{file,bytes:bytes.length,sha256:sha(bytes),lines:bytes.toString().split('\n').length-1};});
writeFileSync(base+'/artifacts.json',JSON.stringify({sourceHead:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),artifacts,source},null,2)+'\n');
writeFileSync(base+'/physical-calls.json',JSON.stringify({cutoff:'T3158',total:calls.length,counts,calls,scope:'Physical delegated calls, not measured token or financial cost; T3159 sealing call retained externally.'},null,2)+'\n');
const descriptions=[
 ['T3141','Ask broad general procedural repair','Fail: zero-tool memory compilation refusal','Open G112; unchanged T3157 likewise refuses'],
 ['T3142','Apply reviewed general seeded plan and typed producer mechanisms','Pass: exact source bytes','Pass: original semantic assertions verified T3156/T3158'],
 ['T3143','Retry unchanged three native procedural bodies','Fail: first exact-answer mismatch; two followups pass','Fixed:T3156/T3158 alloriginal assertions pass; full T3143 transcript retains summary, its report path was later overwritten'],
 ['T3144','Distinguish genuine fused content from non-null no-result answer','Pass: exact general fragment edit','Pass: no-source canonical render and real capture preservation checked T3156'],
 ['T3145','Retry unchanged native bodies','Fail: URL encoding exact-answer mismatch; followups pass','Fixed:T3146/T3147 display/transport separation and T3156/T3158 unchanged assertions'],
 ['T3146','Retain transport encoding and allow raw candidate display URL','Pass: exact general helper edit','Pass:T3156 real requestedURL remains encoded'],
 ['T3147','Use native display URL in canonical seeded plan','Pass: exact generic renderer edit','Pass:T3156 unchanged fullRussian answer'],
 ['T3148','Request quoted explicit shell probe','Fail: shell prefix misparsed, exit127','Open command-form gap; changed invocation T3149 is recovery, not unchanged retry'],
 ['T3149','Execute existing probe via plain Run command','Fail: last child-method trace obligation absent','Fixed:T3150 real registry snapshot and T3156/T3158 unchanged assertions'],
 ['T3150','Record actual child method registry before selection','Pass: exact general producer edit','Pass:T3156 actual serialized registry retained'],
 ['T3151','Author source-derived procedural and genuine-source controls','Pass: exact authored test bytes','Pass: fixture API/status field correction T3152 and T3156'],
 ['T3152','Correct newly authored tests to actual typed-result and guide schemas','Pass: exact authored test bytes','Pass:T3156 all source and capture assertions'],
 ['T3153','Run closest procedural and existing captured guide tests','Fail:14/15; new optout assertion used wrong existing key','Fixed:T3155 canonical disabled outcome assertion; T3156 15/15'],
 ['T3154','Emit producer-owned disabled-service outcome','Pass: exact generic producer edit','Pass:T3156 absent wikiHow request and actual disabled outcome'],
 ['T3155','Assert existing canonical disabled outcome and typed event','Pass: exact test fragment','Pass:T3156 requests and events observed'],
 ['T3156','Run all15 closest original and heldout checks','Pass:15/15','Pass:11/6/16 unchanged native runtime assertions; original8 synthesis checks and4 heldouts'],
 ['T3157','Retry exact unchanged broad original request','Fail: zero-tool memory compilation refusal','Open G112: autonomous broad implementation remains undelivered'],
 ['T3158','Capture unchanged native retries with full responses','Pass: all3 source-derived cases','Pass:11/6/16 original assertions; full responses archived'],
];
writeFileSync(base+'/rows.md','| Task | Request | Before | After | Calls | Evidence |\n| --- | --- | --- | --- | --- | --- |\n'+descriptions.map(([task,request,before,after])=>{const list=JSON.parse(readFileSync(scratch+'/'+task+'-observation.json')).calls;return`| ${task} | ${request} | ${before} | ${after} | ${list.join(',')||'none'} | [request](raw/${task}-request.json.gz), [full transcript](raw/${task}.log.gz) |`;}).join('\n')+'\n');
writeFileSync(base+'/README.md',`# Procedural runtime parity\n\nReal source-backed imported-history execution originally exposed three worker failures (initial full observations retained in the source-backed-history-reader packet). The finite repair uses canonical native seed rendering only when no actual source content was obtained, retains captured guide bodies and disabled services, separates display URLs from encoded transport requests, and emits producer-owned typed records for actual child selection, requests, stages and followups.\n\nT3156 passed15/15 closest checks: three unchanged native bodies (11/6/16 executed assertions), four heldouts and eight existing genuine multi-source capture checks. Every capture SHA and accepted step provenance is checked. The worker is${source[0].lines} lines beneath the unchanged1221 ceiling. No native test expectations changed and no native compilation ran locally.\n\nT3143,T3145,T3149 reused one scratch report path; their complete driver transcripts preserve their observed failures. The final report archived here is specifically T3158. Earlier full original failing responses remain in the committed reader packet. G112 broad implementation asks T3141/T3157 remain Open. T3148 quoted command-form failure remains Open; T3149 used a changed invocation.\n\nCarried-count records remain coordinator-owned; this phase does not infer full201 success from three cases. There remain977 unsupported native declarations under the preceding whole-inventory observation. All raw bytes are losslessly gzip archived with lengths/hashes in artifacts.json. Physical call counts are recorded separately; actual token/financial costs were not measured.\n`);
writeFileSync(root+'/experiments/formal_ai_subagent/tasks/procedural-runtime-parity.md','# Procedural runtime parity\n\nUse the native seeded discovery plan when no actual fetched content was obtained; preserve live source results and service optouts. Record actual child formalization/registry, procedure stages and prior-dialogue rebinding as typed solver events. Preserve encoded transport URLs while rendering canonical candidate URLs.\n\nValidation:15/15 closest checks, including alloriginal assertions of three native procedural bodies and actual SHA-verified multi-source captures. No native assertions or worker ceiling raised. Broad G112 synthesis and the observed quoted command form remain open. Evidence: `'+relative+'`.\n');
console.log(JSON.stringify({archived:artifacts.length,physicalCalls:calls.length,counts,source},null,2));
