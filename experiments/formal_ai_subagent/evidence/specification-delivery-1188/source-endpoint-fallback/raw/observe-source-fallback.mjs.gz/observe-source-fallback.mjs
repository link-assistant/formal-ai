// Issue #1138, plan 01 L13: the browser must resolve a word the seed does not
// contain through the *same* bounded registry walk the Rust path uses, and must
// label anything it composes from that meaning unverified.
//
// These tests boot the real worker (`js/worker/formal_ai_worker.js`, which loads
// `js/worker/formal_ai_worker_source_walk.js` and
// `…_concept_lookup.js`) with the real seed registry and replay the same
// committed captures under `tests/fixtures/issue-1138-b1/` that
// `tests/unit/issue_1138_concept_lookup.rs` replays. Nothing here is a
// hand-written gloss: every byte came from a real service through the
// production fetch path and its sha256 is recorded in `capture-manifest.lino`.

import { readdirSync, readFileSync } from "node:fs";
import path from "node:path";
import test from "node:test";
import assert from "node:assert/strict";

import { createWorkerContext, evaluate, plain } from "/Users/konard/Code/Archive/link-assistant/formal-ai/rust/tests/web/support/browser-runtime.mjs";

const REPO_ROOT = "/Users/konard/Code/Archive/link-assistant/formal-ai";
const FIXTURE_DIR = path.join(REPO_ROOT, "rust/tests/fixtures/issue-1138-b1");
const CACHE_DIR = path.join(FIXTURE_DIR, "source-cache");

/** The held-out word; it appears in no seed file. */
const HELD_OUT_WORD = "isogram";

/** The committed captures as a `url → { body, sha256 }` map. */
function loadCaptures() {
  const captures = new Map();
  for (const name of readdirSync(CACHE_DIR).filter((entry) => entry.endsWith(".meta"))) {
    const meta = readFileSync(path.join(CACHE_DIR, name), "utf8");
    const field = (key) => {
      const line = meta.split("\n").find((entry) => entry.startsWith(`${key}=`));
      return line ? line.slice(key.length + 1) : "";
    };
    const url = field("url");
    const sha256 = field("sha256");
    if (!url || !sha256) continue;
    const body = readFileSync(path.join(CACHE_DIR, "objects", `${sha256}.body`), "utf8");
    captures.set(url, { body, sha256, fetchedAt: field("fetched_at") });
  }
  return captures;
}

/**
 * A worker whose `fetch` serves the seed files and the committed captures, and
 * refuses everything else, so a test can never silently reach the network.
 */
async function bootWorker(captures, requested) {
  const context = createWorkerContext({
    fetch: (url) => {
      const target = String(url);
      const parsed = new URL(target, "http://localhost/");
      const relative = parsed.pathname.replace(/^\/+/, "");
      if (parsed.origin === "http://localhost" || !target.startsWith("http")) {
        const onDisk = relative.startsWith("seed/")
          ? path.join(REPO_ROOT, "data", relative)
          : path.join(REPO_ROOT, "js", relative);
        try {
          const text = readFileSync(onDisk, "utf8");
          return Promise.resolve({ ok: true, status: 200, text: () => Promise.resolve(text) });
        } catch {
          return Promise.resolve({ ok: false, status: 404, text: () => Promise.resolve("") });
        }
      }
      if (requested) requested.push(target);
      const capture = captures.get(target);
      if (!capture) {
        return Promise.resolve({ ok: false, status: 404, text: () => Promise.resolve("") });
      }
      return Promise.resolve({ ok: true, status: 200, text: () => Promise.resolve(capture.body) });
    },
  });
  await evaluate(context, "loadSeed()");
  return context;
}

/** Resolve one surface inside the worker realm and copy the senses out. */
async function lookup(context, surface, language = "en", preferences = {}) {
  context.__lookupSurface = surface;
  context.__lookupLanguage = language;
  context.__lookupPreferences = preferences;
  return plain(
    await evaluate(context, "lookupConceptSurface(__lookupSurface, __lookupLanguage, __lookupPreferences)"),
  );
}


const requested = [], captures = loadCaptures();
const context = await bootWorker(captures, requested);
const outcome = await lookup(context, "isograma", "es");
const crypto = await import("node:crypto");
const hash = data => crypto.createHash("sha256").update(data).digest("hex");
const captured = outcome.items.map(sense => ({ url: sense.sourceUrl, declaredSha256: sense.sha256, actualSha256: hash(captures.get(sense.sourceUrl).body), fetchedAt: captures.get(sense.sourceUrl).fetchedAt }));
assert.ok(captured.every(item => item.declaredSha256 === item.actualSha256));
const source = ["js/worker/formal_ai_worker_source_walk.js","js/worker/formal_ai_worker_source_endpoints.js","rust/src/source_walk.rs","rust/src/seed/sources.rs","rust/src/concept_lookup.rs","data/seed/sources-registry.lino"].map(file => ({file,sha256:hash(readFileSync(path.join(REPO_ROOT,file)))}));
const report = { scope:"actual production walk with genuine unchanged B1 capture bytes; no source or fixture overlays", language:"es", subject:"isograma", requested, captured, source, outcome };
const fs = await import("node:fs");
fs.writeFileSync("/private/tmp/spec-recurrence-1188/source-fallback-actual-report.json",JSON.stringify(report,null,2)+"\n");
console.log(JSON.stringify({requested,captured,sourceOutcome:outcome.outcomes.find(item=>item.sourceId==="wikipedia")}));
