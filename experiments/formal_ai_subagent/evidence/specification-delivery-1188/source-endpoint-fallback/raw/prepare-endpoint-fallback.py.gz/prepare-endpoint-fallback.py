from pathlib import Path
base=Path('/private/tmp/spec-recurrence-1188')
paths=['js/worker/formal_ai_worker_source_walk.js','rust/src/source_walk.rs','rust/src/seed/sources.rs','rust/src/concept_lookup.rs','data/seed/sources-registry.lino','rust/tests/web/test-area-renames.test.mjs']
for path in paths:
 (base/('fallback-preimage-'+path.replace('/','--'))).write_bytes(Path(path).read_bytes())
s=Path(paths[0]).read_text()
a=s.index('function sourceWalkPageTitle(');b=s.index('\nfunction sourceWalkServiceAllowed',a)
helpers=s[a:b]
endpoint='// Bind registry endpoint templates and their explicitly declared resource fallback.\n'+helpers+'\n\nfunction sourceWalkFallbackEntryUrl(record, subject, language = "") {\n  if (!record.apiFallback) return null;\n  return sourceWalkEntryUrl({ ...record, api: record.apiFallback, languageApi: "" }, subject, language);\n}\n'
(base/'source_endpoints.draft.js').write_text(endpoint)
s=s[:a]+s[b:]
s=s.replace('      api: value("api"),','      api: value("api"),\n      apiFallback: value("api-fallback"),')
s=s.replace('    const sourceItems = [];','    const sourceItems = [];\n    const failedAttempts = [];')
s=s.replace('        break;\n      }\n      outcome.pages += 1;', '''        const fallback = missing && url === firstUrl
          ? sourceWalkFallbackEntryUrl(record, subject, language) : null;
        if (fallback && !visited.includes(fallback)) {
          failedAttempts.push(outcome.detail);
          queue.unshift({ url: fallback, depth });
          continue;
        }
        break;
      }
      outcome.pages += 1;
      if (failedAttempts.length) outcome.detail = `fallback_capture url=${url}`;''')
s=s.replace('    if (sourceItems.length > 0) outcome.status = "contributed";', '''    if (failedAttempts.length) outcome.detail = `source_attempts failed-attempts=${JSON.stringify(failedAttempts)} result=${JSON.stringify(outcome.detail)}`;
    if (sourceItems.length > 0) outcome.status = "contributed";''')
(base/'source_walk.fallback.draft.js').write_text(s)
s=Path(paths[2]).read_text().replace('    pub api: String,','    pub api: String,\n    /// Declared alternate endpoint, consulted only after a missing resource.\n    pub api_fallback: String,')
s=s.replace('                api: entry.find_child_value("api").to_owned(),','                api: entry.find_child_value("api").to_owned(),\n                api_fallback: entry.find_child_value("api-fallback").to_owned(),')
(base/'sources.fallback.unformatted.rs').write_text(s)
s=Path(paths[1]).read_text().replace('    fn entry_url(&self, record: &SourceRecord, subject: &str) -> Option<String>;','''    fn entry_url(&self, record: &SourceRecord, subject: &str) -> Option<String>;
    /// A declared alternative; an absent capture never authorizes a guessed URL.
    fn fallback_entry_url(&self, _record: &SourceRecord) -> Option<String> { None }''')
at=s.index('\n/// The sources a need kind may consult,')
s=s[:at]+'''
/// Bind the registry-declared missing-resource alternative in the same language.
#[must_use]
pub fn fallback_entry_url_in(record: &SourceRecord, subject: &str, language: &str) -> Option<String> {
    if record.api_fallback.is_empty() { return None; }
    let mut alternate = record.clone();
    alternate.api.clone_from(&record.api_fallback);
    alternate.language_api.clear();
    entry_url_in(&alternate, subject, language)
}
'''+s[at:]
s=s.replace('    let mut items: Vec<E::Item> = Vec::new();','    let mut items: Vec<E::Item> = Vec::new();\n    let mut failed_attempts = Vec::new();')
needle='''                    url == entry_url,
                );
                break;'''
s=s.replace(needle,'''                    url == entry_url,
                );
                if url == entry_url && !error.speaks_for_the_service() {
                    if let Some(fallback) = extractor.fallback_entry_url(record) {
                        if !visited.contains(&fallback) {
                            failed_attempts.push(outcome.detail.clone());
                            queue.push_front((fallback, depth));
                            continue;
                        }
                    }
                }
                break;''')
s=s.replace('        outcome.pages += 1;','''        outcome.pages += 1;
        if !failed_attempts.is_empty() {
            outcome.detail = trace_record::line("fallback_capture", &[("url", url.clone())]);
        }''')
s=s.replace('    items\n}\n\n/// Walk every source','''    if !failed_attempts.is_empty() {
        outcome.detail = trace_record::line("source_attempts", &[("failed-attempts", failed_attempts.join("\\n")), ("result", outcome.detail.clone())]);
    }
    items
}

/// Walk every source''')
(base/'source_walk.fallback.unformatted.rs').write_text(s)
s=Path(paths[3]).read_text().replace('    entry_url_in, walk_sources,','    entry_url_in, fallback_entry_url_in, walk_sources,')
needle='''        entry_url_in(record, subject, &self.language)
    }
'''
s=s.replace(needle,needle+'''    fn fallback_entry_url(&self, record: &SourceRecord) -> Option<String> {
        fallback_entry_url_in(record, &self.surface, &self.language)
    }
''')
(base/'concept_lookup.fallback.unformatted.rs').write_text(s)
s=Path(paths[4]).read_text().replace('    api "https://{language}.wikipedia.org/api/rest_v1/page/summary/{lemma}"','    api "https://{language}.wikipedia.org/api/rest_v1/page/summary/{lemma}"\n    api-fallback "https://{language}.wikipedia.org/api/rest_v1/page/summary/{title}"')
(base/'sources-registry.fallback.draft.lino').write_text(s)
