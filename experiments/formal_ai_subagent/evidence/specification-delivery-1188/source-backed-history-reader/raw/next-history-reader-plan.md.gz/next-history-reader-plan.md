# Finite source-backed history reader phase

Scope: scratch proposal during the coordinated source hold. No production source or recorded carry count changes are authorized by this draft.

## Current observations

- Current production record: 1178 native specification tests, 180 carried, 180 passing. This is separate from the raw candidate inventory below.
- T3124 broad drafting request wrote only the sentence describing the desired design, without reading either requested source. Calls: Bash, Write, Bash. The actual wrong draft and transcript remain preserved. General synthesis remains Open G112.
- T3125 ran a read-only inventory over the actual current native bodies: 19 direct free-function history candidates, 57 static assertion macros. Eighteen currently reject at the unregistered imported function; one rejects at a lifetime-bearing local struct declaration. Three of the eighteen also call a local evidence predicate (13 macros across those three). No candidate has been promoted or executed by this audit.
- Real source paths and SHA256 identities are recorded in history-reader-readonly-audit.json. Canonical implementation is rust/src/solver.rs:873, publicly re-exported by rust/src/lib.rs:478. It forwards the actual prompt and history through UniversalSolver::default().solve_with_history(prompt, history).

## Smallest meaningful implementation

1. Register the canonical imported formal_ai::solve_with_history as a typed operation with parameters string and vec:turn and return type response. Reuse the actual WorkerHost.solve(prompt, history) call and symbolicFromWorker projection. Resolve grouped imports and aliases using the existing import reader. Do not choose an operation from the local spelling alone.
2. Add a source contract validator for that public operation. Read the real crate export and solver implementation; structurally validate its typed signature and default-solver forwarding body with the original parameter references. Capture these source identities as program fixtures and check them again before execution. A changed body, missing export, substituted argument, or custom configuration must reject the whole case.
3. Extend local helper binding using a closed pure expression body IR. Parse each declared parameter type and return type, and bind arbitrary local parameter names to the actual argument values. Reuse field access, iter/any and string predicates already present in the typed expression reader. For the first slice, allow a single pure return expression and no statements, assertions, effects, recursion, or guessed engine forwarding. Every local declaration must shadow an imported name even when unsupported.
4. This interprets the actual has_evidence body in the two native source files: response.evidence_links.iter().any(|link| link.starts_with(expected)). It must also work with unrelated helper names and parameter names; no dispatch on has_evidence or a test ID.
5. Evaluate call arguments sequentially in native left-to-right order. Earlier observed answers may enter subsequent history constructors. Preserve original turn roles, order, newest-user semantics, duplicates, terminal LF and actual event/evidence projection.
6. Keep FormalAiEngine helpers, custom UniversalSolver::new profiles, offline contexts, arbitrary fixture parsers, probability stores and unknown methods unsupported. The lifetime-bearing RecallCase declaration is a separate typed primitive and remains unsupported in this bounded phase.

## Intended owned paths after explicit release

- scripts/lib/rust-specification-programs.mjs: import contracts, local helper registration and fixture attachment.
- scripts/lib/rust-specification-values.mjs: explicit typed signatures, pure helper execution and ordered arguments.
- A small shared reader-contract module only if needed to keep the responsibilities bounded.
- rust/tests/web/rust-specification-programs.test.mjs: real original-source execution and arbitrary held-out controls.
- No native assertion, native expected response, WorkerHost engine route, specification record, common generated mirror or source-profile change.

## Acceptance checks

- Execute every original assertion in each newly supported native function from conversation_history.rs and reasoning_paths.rs. Preserve diagnostic arguments and stop at a real assertion failure; never skip a failed case.
- Verify English/Russian/Hindi/Chinese term recall, no-match behavior, prior-question filtering, exact earlier-answer history and summary/follow-up assertions through the real WorkerHost. The inventory identifies possible cases, not promised passes.
- Native helper tests: arbitrary imported alias and pure helper names; parameter renaming; two same-typed parameters used in reversed order; unsupported effectful helper; wrong helper return type; local shadow of a recognized import; recursive helper refusal; unknown offline/profile refusal.
- Producer identity tests: stale fixture bytes prevent any worker call; changed forwarding body or missing export refuses before execution. Whole-case assertion conservation must include every original macro.
- Ordering control: effectful call arguments execute left-to-right; a wrong first assertion prevents later worker calls. Record actual prompt, history and response observations.
- Run the existing 14 closest reader checks unchanged, then new controls and real originals. Do not claim an increased carry until the authoritative whole-suite checker executes the complete candidate set and root records actual counts, failures and unsupported reasons.

## Lowest-resolution requirement boundaries

- R1021-14 (recorded): one genuine solve-authored repository change per release must become a normally reviewed and merged PR after merge. Acceptance is a release-cycle run and qualifying PR event, not a parser artifact.
- R1187-8 (measured): after merge, with no AUTOMATION inputs, label a genuine issue formal-ai-solve; observe default credential summary and checks starting without approval. Current source tests prove the mechanism, not that event.
- R994 (measured): the real JS-first translation cycle still needs path-filtered ordering, CST round-trip closure and translated Rust adoption. Typed specification carry increases evidence for U29/U30 but does not close the pivot migration.
- U13: broad synthesis remains open after T3124. U28: the progressive level is reported, but automatic selection by level remains incomplete. U29/U30: preserve truthful executed original cases and unsupported profiles; no mechanical count inflation.

## Read-only native fallback audit

- api_fallback is declared and populated in the only SourceRecord struct literal. CaptureExtractor adds a default method, preserving existing implementors. The public helper lives in the public source_walk module and is correctly imported by SenseExtractor.
- Rust edition2024 and declared rust-version1.99 support the actual let-chain. The fallback queue retains depth and page accounting, avoids visited URLs and only consults a declared alternative after HTTP404/410 or honest offline absence; service/transport errors remain refusals.
- The new native test calls ConceptSense.content_id() and reads the genuine expected-senses record. Its offline diagnostic assertion matches FetchError display. No obvious compile/API defect was found by this review. Native compile, Clippy and execution remain pending CI; no local compiler was run.

## Actual runtime readiness observation

T3127 derived the two genuine native evidence-predicate bodies using the existing expression IR, then evaluated them against an actual WorkerHost response to the original English term-recall prompt and history. The response intent was unknown; filter:memory_query was absent, and both pure predicates correctly returned false with zero effects. This proves body interpretation feasibility and exposes a real runtime parity gap. It does not execute or promote a complete native case. The native solver handles in-process conversation log recall separately from persisted-store protocol recall. The reader must not fabricate store events or substitute a server memory profile to hide that gap. Native summary envelopes also have a current server-wrapper seam and require real original assertion execution before any carry claim.
