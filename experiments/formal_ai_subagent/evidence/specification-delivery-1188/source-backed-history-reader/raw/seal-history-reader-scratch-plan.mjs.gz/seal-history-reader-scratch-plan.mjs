import {readFileSync,writeFileSync} from 'node:fs';
const base='/private/tmp/spec-recurrence-1188';
const plan=base+'/next-history-reader-plan/next-history-reader-plan.md';
let text=readFileSync(plan,'utf8');
text+='\n## Actual runtime readiness observation\n\nT3127 derived the two genuine native evidence-predicate bodies using the existing expression IR, then evaluated them against an actual WorkerHost response to the original English term-recall prompt and history. The response intent was unknown; filter:memory_query was absent, and both pure predicates correctly returned false with zero effects. This proves body interpretation feasibility and exposes a real runtime parity gap. It does not execute or promote a complete native case. The native solver handles in-process conversation log recall separately from persisted-store protocol recall. The reader must not fabricate store events or substitute a server memory profile to hide that gap. Native summary envelopes also have a current server-wrapper seam and require real original assertion execution before any carry claim.\n';
writeFileSync(plan,text);
const rows=[
['T3124','Read real reader and native solver sources and create a finite next-history-reader plan in scratch','Fail: routed to literal_file and wrote only the requested design description; no source reads','Open G112: broad source-backed synthesis not delivered; T3126 literal draft is separate','bash,write,bash'],
['T3125','Run node /private/tmp/spec-recurrence-1188/audit-history-reader.mjs','Pass: actual current source identities and direct-call candidate inventory observed','Pass: 19 candidates /57 static macros remain unsupported; current production180/1178 unchanged','bash'],
['T3126','Set scratch next-history-reader-plan.md to the reviewed complete literal plan','Pass: supplied finite design physically authored and exact bytes verified','Pass: scratch draft only; no general synthesis or native case closure claimed','bash,write,bash'],
['T3127','Run node /private/tmp/spec-recurrence-1188/probe-pure-history-helper.mjs','Pass observation: actual pure helper AST evaluation produced false against a real unknown response','Open runtime parity: English term recall still unknown; zero whole native cases promoted','bash']
];
const head='| Task | Request | Before | After | Calls | Raw evidence |\n| --- | --- | --- | --- | --- | --- |\n';
writeFileSync(base+'/next-history-reader-plan/rows.md',head+rows.map(row=>'| '+[...row,`[request](${base}/${row[0]}-request.json), [full transcript](${base}/${row[0]}.log)`].join(' | ')+' |').join('\n')+'\n');
console.log('scratch plan addendum and four truthful rows written; no repository mutation');
