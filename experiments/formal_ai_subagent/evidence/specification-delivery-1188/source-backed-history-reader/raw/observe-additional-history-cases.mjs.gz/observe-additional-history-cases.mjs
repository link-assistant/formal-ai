import {writeFileSync} from 'node:fs';
import {specificationCases} from '/Users/konard/Code/Archive/link-assistant/formal-ai/scripts/lib/rust-specification-cases.mjs';
import {executeTypedProgram} from '/Users/konard/Code/Archive/link-assistant/formal-ai/scripts/lib/rust-specification-programs.mjs';
import {WorkerHost} from '/Users/konard/Code/Archive/link-assistant/formal-ai/js/server/worker-host.mjs';
const names=['greeting_prefixed_russian_connect_how_to_composes_procedure','procedural_elaboration_followup_rebinds_to_prior_how_to','procedural_elaboration_followup_covers_supported_languages'];
const inventory=specificationCases('/Users/konard/Code/Archive/link-assistant/formal-ai'),host=new WorkerHost(),results=[];
for(const name of names){const item=inventory.cases.find(candidate=>candidate.id.endsWith('::'+name));if(!item?.program)throw new Error('not a complete typed case '+name);results.push({id:item.id,...await executeTypedProgram(host,item.program)});}
writeFileSync('/private/tmp/spec-recurrence-1188/additional-history-cases-actual-report.json',JSON.stringify({scope:'actual original additional source-backed cases with full observations',results},null,2)+'\n');
console.log(JSON.stringify(results.map(({id,status,failure,nativeAssertions,assertions})=>({id,status,failure,nativeAssertions,assertions})),null,2));
