import {writeFileSync} from 'node:fs';
import {specificationCases,failingCases} from '/Users/konard/Code/Archive/link-assistant/formal-ai/scripts/lib/rust-specification-cases.mjs';
import {WorkerHost} from '/Users/konard/Code/Archive/link-assistant/formal-ai/js/server/worker-host.mjs';
const inventory=specificationCases('/Users/konard/Code/Archive/link-assistant/formal-ai');
const failures=await failingCases(new WorkerHost(),inventory.cases);
const report={scope:'actual whole-case candidate execution; no committed record write',total:inventory.total,carried:inventory.cases.length,passing:inventory.cases.length-failures.size,failures:[...failures].map(([id,failure])=>({id,failure})),unsupported:inventory.unsupported};
writeFileSync('/private/tmp/spec-recurrence-1188/history-reader-inventory-initial.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,unsupported:report.unsupported.length},null,2));
