import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {tokenize} from '/Users/konard/Code/Archive/link-assistant/formal-ai/scripts/lib/rust-specification-cases.mjs';
import {close,split,expression,evaluate} from '/Users/konard/Code/Archive/link-assistant/formal-ai/scripts/lib/rust-specification-values.mjs';
import {WorkerHost} from '/Users/konard/Code/Archive/link-assistant/formal-ai/js/server/worker-host.mjs';
import {symbolicFromWorker} from '/Users/konard/Code/Archive/link-assistant/formal-ai/js/server/solve.mjs';
const root='/Users/konard/Code/Archive/link-assistant/formal-ai';
const paths=['rust/tests/unit/specification/conversation_history.rs','rust/tests/unit/specification/reasoning_paths.rs'];
const parsed=[];
for(const path of paths){
 const source=readFileSync(root+'/'+path,'utf8'),tokens=tokenize(source);
 for(let i=0;i<tokens.length;i++){
  if(tokens[i].text!=='fn'||tokens[i+2]?.text!=='(')continue;
  const paramsEnd=close(tokens,i+2);let open=paramsEnd+1;while(tokens[open]?.text!=='{'&&open<tokens.length)open++;
  if(open===tokens.length)break;
  const end=close(tokens,open),returns=tokens.slice(paramsEnd+1,open).map(x=>x.text).join('');
  if(returns!=='->bool'){i=end;continue;}
  const params=split(tokens.slice(i+3,paramsEnd)).map(part=>({name:part[0]?.text,type:part.slice(2).map(x=>x.text).join('')}));
  const allowed=new Map([['&SymbolicAnswer','response'],['&str','string']]);
  if(params.some(p=>!allowed.has(p.type))){i=end;continue;}
  const environment=new Map(params.map(p=>[p.name,{type:allowed.get(p.type)}]));
  const ast=expression(tokens.slice(open+1,end),{environment,calls:new Map(),schemas:new Map()});
  parsed.push({path,name:tokens[i+1].text,params,ast,sha256:createHash('sha256').update(source).digest('hex')});i=end;
 }
}
const history=[{role:'user',content:'What is Rust?'},{role:'assistant',content:'Rust is a systems programming language.'}];
const prompt='When did I mention Rust?';
const raw=await new WorkerHost().solve(prompt,history),response=symbolicFromWorker(raw,history);
const observations=[];
for(const helper of parsed){
 const runtime={host:{solve(){throw new Error('pure helper attempted worker effect')}},observations:[]};
 const result=await evaluate(helper.ast,new Map([[helper.params[0].name,response],[helper.params[1].name,'filter:memory_query']]),runtime);
 observations.push({source:helper.path,sha256:helper.sha256,derivedHelperName:helper.name,parameterNames:helper.params.map(x=>x.name),returnType:helper.ast.type,result,effects:runtime.observations.length});
}
const report={scope:'scratch helper-body derivation and evaluation against a real worker response; zero native whole cases promoted',prompt,history,response,observations};
writeFileSync('/private/tmp/spec-recurrence-1188/pure-history-helper-scratch-observation.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({scope:report.scope,intent:response.intent,evidence:response.evidence_links,observations},null,2));
