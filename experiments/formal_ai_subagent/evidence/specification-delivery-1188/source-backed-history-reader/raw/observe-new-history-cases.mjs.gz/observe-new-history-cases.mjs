import {readFileSync,writeFileSync} from 'node:fs';
import {specificationCases} from '/Users/konard/Code/Archive/link-assistant/formal-ai/scripts/lib/rust-specification-cases.mjs';
import {executeTypedProgram} from '/Users/konard/Code/Archive/link-assistant/formal-ai/scripts/lib/rust-specification-programs.mjs';
import {WorkerHost} from '/Users/konard/Code/Archive/link-assistant/formal-ai/js/server/worker-host.mjs';
const root='/Users/konard/Code/Archive/link-assistant/formal-ai',base='/private/tmp/spec-recurrence-1188';
const before=JSON.parse(readFileSync(base+'/history-reader-readonly-audit.json','utf8'));
const inventory=specificationCases(root),host=new WorkerHost(),results=[];
for(const candidate of before.candidates){
 const carried=inventory.cases.find(item=>item.id===candidate.id);
 if(!carried){results.push({id:candidate.id,status:'unsupported',reason:inventory.unsupported.find(item=>item.id===candidate.id)?.reason});continue;}
 results.push({id:carried.id,...await executeTypedProgram(host,carried.program)});
}
const report={scope:'original native full cases, every assertion or honest stop-on-failure, no record write',total:inventory.total,carriedCandidates:inventory.cases.length,results};
writeFileSync(base+'/new-history-cases-actual-report.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({total:report.total,carriedCandidates:report.carriedCandidates,counts:Object.fromEntries(['passed','failed','unsupported'].map(status=>[status,results.filter(item=>item.status===status).length])),failures:results.filter(item=>item.status==='failed').map(item=>({id:item.id,failure:item.failure,assertions:item.assertions,nativeAssertions:item.nativeAssertions})),unsupported:results.filter(item=>item.status==='unsupported')},null,2));
