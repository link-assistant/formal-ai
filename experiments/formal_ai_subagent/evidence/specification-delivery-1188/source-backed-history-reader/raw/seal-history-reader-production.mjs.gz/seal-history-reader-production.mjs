import {readFileSync,writeFileSync} from 'node:fs';
import {gzipSync,gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const base='/Users/konard/Code/Archive/link-assistant/formal-ai/experiments/formal_ai_subagent/evidence/specification-delivery-1188/source-backed-history-reader',scratch='/private/tmp/spec-recurrence-1188';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const manifest=JSON.parse(readFileSync(base+'/artifacts.json','utf8'));
for(const artifact of manifest.artifacts){const bytes=gunzipSync(readFileSync(base+'/'+artifact.artifact));if(bytes.length!==artifact.bytes||sha(bytes)!==artifact.sha256)throw new Error('archive mismatch '+artifact.artifact);}
for(const name of ['T3139-request.json','T3139.log','T3139-observation.json','seal-history-reader-production.mjs']){const bytes=readFileSync(scratch+'/'+name),compressed=gzipSync(bytes);if(!gunzipSync(compressed).equals(bytes))throw new Error('loss');writeFileSync(base+'/raw/'+name+'.gz',compressed);manifest.artifacts.push({artifact:'raw/'+name+'.gz',origin:scratch+'/'+name,bytes:bytes.length,sha256:sha(bytes)});}
writeFileSync(base+'/artifacts.json',JSON.stringify(manifest,null,2)+'\n');
writeFileSync(base+'/rows.md',readFileSync(base+'/rows.md','utf8')+'| T3139 | Run reviewed finite archive generator | Pass:91original raw artifacts losslessly archived | Pass: source/evidence/changelog authored throughFA; original failures preserved | bash | [request](raw/T3139-request.json.gz), [full transcript](raw/T3139.log.gz) |\n');
writeFileSync(base+'/README.md',readFileSync(base+'/README.md','utf8')+'\nT3139 adds one archive Bash call (28physicalcalls throughthatcutoff). T3140 verifies every archived original byte length and hash, preserves the archive invocation, and adds one seal Bash call. Complete phaseT3124–T3140 totals29calls:21Bash,6Write,2Grep. T3140raw request/transcript is retained separately for coordinator sealing.\n');
console.log(JSON.stringify({verifiedOriginalArtifacts:91,sealedArtifacts:manifest.artifacts.length,phasePhysicalCalls:29,counts:{bash:21,write:6,grep:2}},null,2));
