import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { specificationCases, testFunctions, tokenize } from '/Users/konard/Code/Archive/link-assistant/formal-ai/scripts/lib/rust-specification-cases.mjs';
const root='/Users/konard/Code/Archive/link-assistant/formal-ai';
const inventory=specificationCases(root);
const files=['rust/tests/unit/specification/conversation_history.rs','rust/tests/unit/specification/reasoning_paths.rs'];
const candidates=[];
for(const file of files){
 const source=readFileSync(root+'/'+file,'utf8');
 const sha256=createHash('sha256').update(source).digest('hex');
 for(const test of testFunctions(tokenize(source))){
  const direct=test.body.some((token,i)=>token.text==='solve_with_history'&&test.body[i+1]?.text==='('&&test.body[i-1]?.text!=='.');
  if(!direct)continue;
  const id=file+'::'+test.name;
  candidates.push({id,sha256,staticAssertionMacros:test.body.filter((token,i)=>['assert','assert_eq','assert_ne'].includes(token.text)&&test.body[i+1]?.text==='!').length,usesLocalPredicate:test.body.some(token=>token.text==='has_evidence'),currentUnsupported:inventory.unsupported.find(item=>item.id===id),currentlyCarried:inventory.cases.some(item=>item.id===id)});
 }
}
const result={scope:'read-only native-source candidates, not promoted or executed cases',total:inventory.total,carried:inventory.cases.length,candidates,sourceIdentities:['rust/src/lib.rs','rust/src/solver.rs',...files].map(file=>({file,sha256:createHash('sha256').update(readFileSync(root+'/'+file)).digest('hex')}))};
writeFileSync('/private/tmp/spec-recurrence-1188/history-reader-readonly-audit.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({scope:result.scope,total:result.total,carried:result.carried,candidates:candidates.length,staticAssertionMacros:candidates.reduce((n,x)=>n+x.staticAssertionMacros,0),usesLocalPredicate:candidates.filter(x=>x.usesLocalPredicate).length,identities:result.sourceIdentities},null,2));
