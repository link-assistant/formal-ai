import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { test } from 'node:test';
import { typedProgramOf, executeTypedProgram } from '../../../scripts/lib/rust-specification-programs.mjs';
import { specificationCases, testFunctions, tokenize } from '../../../scripts/lib/rust-specification-cases.mjs';
import { WorkerHost } from '../../../js/server/worker-host.mjs';

const root = new URL('../../../', import.meta.url).pathname;
const compileSource = 'rust/tests/unit/specification/natural_language_skill_compilation.rs';
const countSource = 'rust/tests/unit/specification/behavior_rules.rs';
const originals = [
  [compileSource, 'natural_language_skill_compiles_to_reusable_package', 7, 7],
  [compileSource, 'natural_language_skill_compiles_supported_language_shapes', 2, 8],
  [compileSource, 'compiled_package_replays_deterministically_and_exports_links_notation', 5, 5],
  [compileSource, 'solver_prefers_compiled_skill_from_history_and_records_cache_hit', 5, 5],
  [countSource, 'behavior_rules_count_includes_dialog_local_runtime_rules', 6, 6],
];
for (const [file, name, macros, executions] of originals) {
  test('every original assertion executes from actual native source: ' + name, async () => {
    const source = readFileSync(root + file, 'utf8');
    const native = testFunctions(tokenize(source)).find(item => item.name === name);
    assert.ok(native);
    const parsed = typedProgramOf(native.body, { source, file: root + file, root });
    assert.ok(parsed.program, parsed.reason);
    assert.equal(parsed.program.nativeAssertions, macros);
    const result = await executeTypedProgram(new WorkerHost(), parsed.program);
    assert.equal(result.status, 'passed', result.failure);
    assert.equal(result.assertions, executions);
    assert.equal(result.nativeAssertions, macros);
    if (executions !== macros) assert.deepEqual(result.iterations, [{ parameter: 'case', length: 4 }]);
    const carried = specificationCases(root).cases.find(item => item.id === file + '::' + name);
    assert.ok(carried?.program, 'production inventory must contain the typed program');
    if (name === 'behavior_rules_count_includes_dialog_local_runtime_rules') {
      assert.ok(result.observations[0].answer.answer.endsWith('```\n'));
    }
  });
}

function inline(source) {
  const native = testFunctions(tokenize(source))[0];
  assert.ok(native);
  return typedProgramOf(native.body, { source, root });
}

const imports = 'use formal_ai::{ConversationTurn, UniversalSolver, compile_natural_language_skill};';
test('arbitrary local record names and imported compiler aliases use one typed loop mechanism', async () => {
  const source = `use formal_ai::compile_natural_language_skill as lower;
  #[test] fn unrelated() {
    struct Example { instruction: &'static str, expected: &'static str }
    let variants = [Example { expected: "arbitrary Ω", instruction: "When \`quartz 816\` then \`arbitrary Ω\`" },
      Example { instruction: "Когда \`камень 917\` тогда \`другой ответ\`", expected: "другой ответ" }];
    for variant in variants {
      let artifact = lower(variant.instruction).expect("compile arbitrary fixture");
      assert_eq!(artifact.response, variant.expected, "{}", variant.instruction);
      assert!(artifact.id.starts_with("compiled_skill_"));
    }
  }`;
  const parsed = inline(source);
  assert.ok(parsed.program, parsed.reason);
  assert.equal(parsed.program.nativeAssertions, 2);
  const result = await executeTypedProgram(new WorkerHost(), parsed.program);
  assert.equal(result.status, 'passed', result.failure);
  assert.equal(result.assertions, 4);
  assert.deepEqual(result.iterations, [{ parameter: 'variant', length: 2 }]);
});

test('wrong assertions fail and stop before later original operations', async () => {
  const parsed = inline(`${imports} #[test] fn held_out() {
    let solver = UniversalSolver::default();
    let reply = solver.solve("4 + 4");
    assert_eq!(reply.intent, "wrong intent");
    let later = solver.solve("Hi");
    assert_eq!(later.intent, "greeting");
  }`);
  assert.ok(parsed.program, parsed.reason);
  assert.equal(parsed.program.nativeAssertions, 2);
  const result = await executeTypedProgram(new WorkerHost(), parsed.program);
  assert.equal(result.status, 'failed');
  assert.equal(result.assertions, 1);
  assert.equal(result.observations.length, 1);
});

test('unknown fields and effects reject the entire case rather than dropping assertions', () => {
  for (const ending of ['assert_eq!(reply.fabricated, "x");', 'mutate_repository();', 'assert!(reply.answer.unsupported_method());']) {
    const parsed = inline(`${imports} #[test] fn held_out() {
      let solver = UniversalSolver::default(); let reply = solver.solve("Hi");
      assert_eq!(reply.intent, "greeting"); ${ending}
    }`);
    assert.equal(parsed.program, undefined);
    assert.ok(parsed.reason);
  }
});

test('Result and Option expectations execute genuine failure states', async () => {
  for (const operation of [
    'compile_natural_language_skill("ordinary unrelated text").expect("must compile")',
    'compile_natural_language_skill("When `pebble 892` then `response`").expect("compiled").replay("other").expect("must replay")',
  ]) {
    const parsed = inline(`${imports} #[test] fn held_out() { let artifact = ${operation}; assert_eq!(artifact.answer, "response"); }`);
    if (operation.startsWith('compile_natural_language_skill("ordinary')) {
      assert.equal(parsed.program, undefined, 'unknown package.answer must reject even after an earlier expectation');
      continue;
    }
    assert.ok(parsed.program, parsed.reason);
    const result = await executeTypedProgram(new WorkerHost(), parsed.program);
    assert.equal(result.status, 'failed');
    assert.match(result.failure, /native expectation failed/);
    assert.equal(result.assertions, 0);
  }
  const unsupported = inline(`${imports} #[test] fn held_out() {
    let artifact = compile_natural_language_skill("ordinary unrelated text").expect("must compile");
    assert_eq!(artifact.response, "invented answer");
  }`);
  assert.ok(unsupported.program, unsupported.reason);
  assert.equal((await executeTypedProgram(new WorkerHost(), unsupported.program)).status, 'failed');
});

test('engine, offline and misleading helper bodies remain unsupported', () => {
  for (const body of ['FormalAiEngine.answer(prompt)', 'UniversalSolver::new(SolverConfig { offline: true, ..SolverConfig::default() }).solve(prompt)', 'UniversalSolver::default().solve("fixed prompt")']) {
    const parsed = inline(`${imports} use formal_ai::{FormalAiEngine, SolverConfig};
      fn invented(prompt: &str) -> SymbolicAnswer { ${body} }
      #[test] fn held_out() { let reply = invented("Hi"); assert_eq!(reply.intent, "greeting"); }`);
    assert.equal(parsed.program, undefined);
    assert.match(parsed.reason, /unsupported native call/);
  }
  const real = inline(`${imports} fn arbitrary(input: &str) -> SymbolicAnswer { UniversalSolver::default().solve(input) }
    #[test] fn held_out() { let reply = arbitrary("Hi"); assert_eq!(reply.intent, "greeting"); }`);
  assert.ok(real.program, real.reason);
});

test('actual earlier answers enter history and newest user packages preserve dedup controls', async () => {
  const source = `${imports} #[test] fn held_out() {
    let solver = UniversalSolver::default();
    let older = "When \`quartz 941\` then \`older\`";
    let latest = "When \`quartz 941\` then \`newer\`";
    let equivalent = "When \`QUARTZ 941!!!\` then \`newer\`";
    let taught = solver.solve(latest);
    let history = [ConversationTurn::user(older), ConversationTurn::user(latest),
      ConversationTurn::assistant(taught.answer), ConversationTurn::user(equivalent),
      ConversationTurn::assistant("When \`quartz 941\` then \`impostor\`")];
    let count = solver.solve_with_history("How many behavior rules are there?", &history);
    assert!(count.answer.contains("dialog_local_rules \\\"2\\\""));
    let reply = solver.solve_with_history("quartz 941", &history);
    assert_eq!(reply.answer, "newer");
    assert!(reply.evidence_links.iter().any(|item| item.starts_with("cache_hit:compiled_skill_")));
  }`;
  const parsed = inline(source);
  assert.ok(parsed.program, parsed.reason);
  const result = await executeTypedProgram(new WorkerHost(), parsed.program);
  assert.equal(result.status, 'passed', result.failure);
  assert.equal(result.assertions, 3);
  assert.equal(result.observations[1].history[2].content, result.observations[0].answer.answer);
});

test('native source identity and fixture freshness cannot be invented by callers', async () => {
  const file = root + compileSource;
  const source = readFileSync(file, 'utf8');
  const native = testFunctions(tokenize(source))[0];
  assert.match(typedProgramOf(native.body, { source: source + '\n', file, root }).reason, /source identity mismatch/);
  const parsed = typedProgramOf(native.body, { source, file, root });
  assert.ok(parsed.program, parsed.reason);
  parsed.program.fixtures[0].sha256 = '0'.repeat(64);
  const result = await executeTypedProgram(new WorkerHost(), parsed.program);
  assert.equal(result.status, 'failed');
  assert.equal(result.observations.length, 0);
  assert.match(result.failure, /stale native fixture/);
});
