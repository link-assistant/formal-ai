"use strict";

const { app, BrowserWindow, dialog, ipcMain, powerMonitor, shell } = require("electron");
const { autoUpdater } = require("electron-updater");
const childProcess = require("node:child_process");
const fs = require("node:fs");
const http = require("node:http");
const os = require("node:os");
const path = require("node:path");
const { URL } = require("node:url");

const { createToolRouter, SUPPORTED_TOOLS } = require("./lib/tool-router.cjs");
const { createWebTools } = require("./lib/web-tools.cjs");
const { createAgentProvider } = require("./lib/agent-provider.cjs");
const { createEngineManager, OUT_OF_BOX_ENGINE } = require("./lib/engine-manager.cjs");
const { createMemorySync } = require("./lib/memory-sync.cjs");
const { createServiceControl } = require("./lib/service-control.cjs");
const { createDockerDetector } = require("./lib/docker-detect.cjs");
const { createDataMigration } = require("./lib/data-migration.cjs");
const { createAutoUpdateController } = require("./lib/auto-update.cjs");
const { createVsCodeInstaller } = require("./lib/vscode-install.cjs");
const { createDreamingScheduler } = require("./lib/dreaming.cjs");
const { createCommandRunner } = require("./lib/command-runner.cjs");
const {
  ensureSharedMemoryDirectory,
  resolveSharedMemoryPath,
} = require("./lib/shared-memory.cjs");

// Verbose desktop diagnostics (issue #541): opt-in via FORMAL_AI_DESKTOP_DEBUG so
// hard-to-reproduce environment problems (e.g. a GUI-launched app that cannot see
// the `docker` binary because it did not inherit the shell PATH) can be diagnosed
// from a user's logs without shipping noisy output by default.
function debugLog(...args) {
  if (process.env.FORMAL_AI_DESKTOP_DEBUG) {
    // eslint-disable-next-line no-console
    console.error("[formal-ai-desktop]", ...args);
  }
}
const {
  createLocalServerManager,
  findFreePort,
  serverModeRequested,
} = require("./lib/local-server.cjs");

const REPO_ROOT = path.resolve(__dirname, "..");
const commandRunner = createCommandRunner();

function packagedBrowserExecutable() {
  if (!app.isPackaged) return "";
  const browserRoot = path.join(process.resourcesPath, "browser-runtime");
  try {
    const relative = fs.readFileSync(path.join(browserRoot, "executable-path.txt"), "utf8").trim();
    const executable = path.resolve(browserRoot, relative);
    return executable.startsWith(browserRoot) && fs.existsSync(executable) ? executable : "";
  } catch (_error) {
    return "";
  }
}

function desktopMemoryPath() {
  ensureSharedMemoryDirectory(process.env);
  return resolveSharedMemoryPath(process.env);
}

function autoFreeSpacePreferencePath() {
  return `${desktopMemoryPath()}.auto-free-space`;
}

function autoFreeSpacePreference() {
  try {
    const value = fs.readFileSync(autoFreeSpacePreferencePath(), "utf8").trim();
    return value === "enabled" ? true : value === "disabled" ? false : null;
  } catch (_error) {
    return null;
  }
}

async function persistAutoFreeSpaceChoice(enabled) {
  fs.mkdirSync(path.dirname(autoFreeSpacePreferencePath()), { recursive: true });
  fs.writeFileSync(autoFreeSpacePreferencePath(), enabled ? "enabled\n" : "disabled\n");
}

async function requestAutoFreeSpaceConsent() {
  const preference = autoFreeSpacePreference();
  if (preference !== null) {
    return preference;
  }
  const result = await dialog.showMessageBox(mainWindow || undefined, {
    type: "question",
    title: "AI memory needs free space",
    message: "Enable automatic free-space maintenance?",
    detail:
      "Formal AI will free only enough recomputable or refetchable links for the next write. Raw events and retained learning are preserved.",
    buttons: ["Enable auto-free-space", "Keep everything"],
    defaultId: 1,
    cancelId: 1,
    noLink: true,
  });
  return result.response === 0;
}

async function notifyBiggerStorage() {
  await dialog.showMessageBox(mainWindow || undefined, {
    type: "warning",
    title: "Move AI memory to larger storage",
    message: "AI memory cannot free enough recomputable links for the next operation.",
    detail: "Migrate the Formal AI memory file to a larger storage location, then update FORMAL_AI_MEMORY_PATH.",
    buttons: ["OK"],
  });
}

// Desktop data persistence & migration (issue #541, R3). Pin the userData
// directory to a stable, productName-independent name so a future rebrand or
// package rename can never again orphan a user's conversations, and migrate any
// legacy profile forward on first launch. pinAppName() MUST run before the
// Electron `ready` event for the userData override to take effect, so it is
// invoked here at module load; the actual (non-destructive) copy runs in
// whenReady, before the window/session touches storage.
const dataMigration = createDataMigration({ app, fs, path, log: debugLog });
dataMigration.pinAppName();
// Issue #672 (F2): the outcome of the startup migration, kept so the renderer
// can show the notice and replay it on request. Null until whenReady runs.
let lastDataMigration = null;
const dreamingScheduler = createDreamingScheduler({
  repoRoot: REPO_ROOT,
  env: process.env,
  processRunner: commandRunner.run,
  resourcesPath: process.resourcesPath,
  memoryPath: desktopMemoryPath(),
  isIdle: () => powerMonitor.getSystemIdleTime() >= 60,
  requestAutoFreeSpaceConsent,
  persistAutoFreeSpaceChoice,
  notifyBiggerStorage,
  log: debugLog,
  onStatusChange: (status) => {
    desktopStatus = { ...desktopStatus, dreaming: status };
    return desktopStatus;
  },
});

let mainWindow = null;
let staticServer = null;
const updateController = createAutoUpdateController({
  app,
  autoUpdater,
  log: debugLog,
  onStatusChange: publishUpdaterStatus,
});
const engineManager = createEngineManager({
  preferencePath: `${desktopMemoryPath()}.desktop-engine.json`,
});
let desktopStatus = {
  shell: "Electron",
  platform: process.platform,
  appVersion: updateController.status().currentVersion,
  mode: "in-process",
  apiBase: "",
  staticBase: "",
  graphUrl: "",
  chatUrl: "",
  traceUrl: "",
  memory: "formal_ai_bundle",
  dreaming: dreamingScheduler.status(),
  agentModeDefault: false,
  toolCallPolicy: "explicit-permission",
  agentExecutionProvider: { type: "in-process" },
  ...engineManager.status(),
  updater: updateController.status(),
  apiReady: false,
  apiError: "",
};

function publishUpdaterStatus(status) {
  desktopStatus = {
    ...desktopStatus,
    appVersion: status.currentVersion || desktopStatus.appVersion,
    updater: status,
  };
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send("formalAiDesktop:updateStatus", status);
  }
  return desktopStatus;
}

function devWebRoot() {
  return path.join(REPO_ROOT, "src", "web");
}

function packagedWebRoot() {
  return path.join(__dirname, "dist-web");
}

function resolveWebRoot() {
  const packaged = packagedWebRoot();
  if (fs.existsSync(path.join(packaged, "index.html"))) {
    return packaged;
  }
  return devWebRoot();
}

function contentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return (
    {
      ".css": "text/css; charset=utf-8",
      ".html": "text/html; charset=utf-8",
      ".js": "application/javascript; charset=utf-8",
      ".json": "application/json; charset=utf-8",
      ".lino": "text/plain; charset=utf-8",
      ".map": "application/json; charset=utf-8",
      ".png": "image/png",
      ".svg": "image/svg+xml",
      ".wasm": "application/wasm",
    }[ext] || "application/octet-stream"
  );
}

function safeResolve(root, requestPath) {
  let cleanPath = "/";
  try {
    cleanPath = decodeURIComponent(requestPath.split("?")[0] || "/");
  } catch (_error) {
    return null;
  }
  const relative = cleanPath === "/" ? "index.html" : cleanPath.replace(/^\/+/, "");
  const absolute = path.resolve(root, relative);
  const rootWithSeparator = root.endsWith(path.sep) ? root : `${root}${path.sep}`;
  if (absolute !== root && !absolute.startsWith(rootWithSeparator)) {
    return null;
  }
  return absolute;
}

function startStaticServer(root, port) {
  const server = http.createServer((request, response) => {
    const url = new URL(request.url || "/", "http://127.0.0.1");
    let filePath = safeResolve(root, url.pathname);

    if (url.pathname.startsWith("/seed/") && filePath && !fs.existsSync(filePath)) {
      filePath = safeResolve(path.join(REPO_ROOT, "data"), url.pathname);
    }

    if (!filePath) {
      response.writeHead(403, { "content-type": "text/plain; charset=utf-8" });
      response.end("Forbidden");
      return;
    }

    if (fs.existsSync(filePath) && fs.statSync(filePath).isDirectory()) {
      filePath = path.join(filePath, "index.html");
    }

    if (!fs.existsSync(filePath)) {
      response.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
      response.end("Not found");
      return;
    }

    response.writeHead(200, {
      "content-type": contentType(filePath),
      "cross-origin-opener-policy": "same-origin",
      "cross-origin-embedder-policy": "require-corp",
    });
    fs.createReadStream(filePath).pipe(response);
  });

  return new Promise((resolve, reject) => {
    server.on("error", reject);
    server.listen(port, "127.0.0.1", () => resolve(server));
  });
}

const localServerManager = createLocalServerManager({
  repoRoot: REPO_ROOT,
  env: process.env,
  resourcesPath: process.resourcesPath,
  platform: process.platform,
  // External agentic clients include tool schemas in their protocol requests.
  // Match `formal-ai with`, which explicitly opts the loopback server into
  // handling those requests; agent-commander still enforces desktop grants.
  agentMode: true,
  stdout: process.stdout,
  stderr: process.stderr,
  startCommand: commandRunner.start,
});

function applyLocalServerStatus(status) {
  desktopStatus = {
    ...desktopStatus,
    ...status,
    appVersion: updateController.status().currentVersion,
    updater: updateController.status(),
    agentExecutionProvider: activeAgentProvider().status(),
    ...engineManager.status(),
  };
  return desktopStatus;
}

async function ensureAgentServer() {
  const status = await localServerManager.ensure();
  return applyLocalServerStatus(status);
}

async function createMainWindow() {
  const webRoot = resolveWebRoot();
  const staticPort = await findFreePort();
  staticServer = await startStaticServer(webRoot, staticPort);
  const staticBase = `http://127.0.0.1:${staticPort}`;

  // Default: in-process agent only. The web app falls back to the in-browser
  // engine when no `apiBase` is advertised (see app.js routing). The legacy
  // startup opt-in still starts the server immediately; agent/full-auto mode
  // can also start it later through `formalAiDesktop:ensureAgentServer`.
  desktopStatus = {
    ...desktopStatus,
    mode: "in-process",
    appVersion: updateController.status().currentVersion,
    updater: updateController.status(),
    staticBase,
    apiBase: "",
    chatUrl: "",
    graphUrl: "",
    traceUrl: "",
    apiReady: false,
    apiError: "",
    agentExecutionProvider: activeAgentProvider().status(),
    ...engineManager.status(),
  };
  if (serverModeRequested()) {
    await ensureAgentServer();
  }

  mainWindow = new BrowserWindow({
    width: 1280,
    height: 840,
    minWidth: 960,
    minHeight: 640,
    title: "formal-ai Desktop",
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.setMenuBarVisibility(false);
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });
  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (!url.startsWith(staticBase)) {
      event.preventDefault();
      shell.openExternal(url);
    }
  });

  const apiQuery = desktopStatus.apiBase
    ? `&api=${encodeURIComponent(desktopStatus.apiBase)}`
    : "";
  // The web app now lives under /app/ (issue #479): the site root is the
  // landing page chooser, so the desktop wrapper loads the app directly.
  await mainWindow.loadURL(`${staticBase}/app/index.html?desktop=1${apiQuery}`);
}

async function shutdown() {
  dreamingScheduler.stop();
  if (staticServer) {
    await new Promise((resolve) => staticServer.close(resolve));
    staticServer = null;
  }
  localServerManager.shutdown();
  await commanderAgentProvider.stop();
  await webTools.close();
}

// R5d (ROADMAP D2): route the agent's side effects through the local process and
// its Docker sandbox behind an explicit-permission gate. Shell commands run on
// the host desktop by default; code-exec / eval-js tools run inside
// `konard/box-dind` (the same image the Telegram microservice uses).
//
// Issue #541 (R2): Docker availability is detected by `docker-detect.cjs`, which
// resolves the `docker` binary across well-known install locations (fixing the
// GUI-launch PATH gap that made an installed, running Docker report as
// unavailable) and re-probes on a TTL so a daemon started after launch is seen.
const dockerDetector = createDockerDetector({
  env: process.env,
  platform: process.platform,
  spawnSync: childProcess.spawnSync,
  existsSync: fs.existsSync,
  log: debugLog,
});

function dockerIsAvailable() {
  return dockerDetector.dockerIsAvailable();
}

async function runInSandbox({ image, tool, command }) {
  const logPath = path.join(os.tmpdir(), `formal-ai-${tool}-${process.pid}-${Date.now()}.log`);
  const result = await commandRunner.runTool({
    isolation: "docker",
    dockerBinary: dockerDetector.resolveDockerBinary(),
    image,
    command,
  });
  const output = `${result.stdout}${result.stderr}`;
  try {
    fs.writeFileSync(logPath, output);
  } catch (_error) {
    /* best-effort log capture */
  }
  return { exitCode: result.code, output, stdout: result.stdout, stderr: result.stderr, logPath };
}

async function runOnHost({ tool, command }) {
  const logPath = path.join(os.tmpdir(), `formal-ai-${tool}-host-${process.pid}-${Date.now()}.log`);
  const result = await commandRunner.runTool({
    isolation: "host",
    command,
    cwd: os.homedir() || REPO_ROOT,
    env: process.env,
  });
  const output = `${result.stdout}${result.stderr}`;
  try {
    fs.writeFileSync(logPath, output);
  } catch (_error) {
    /* best-effort log capture */
  }
  return { exitCode: result.code, output, stdout: result.stdout, stderr: result.stderr, logPath };
}

// Issue #438 (follow-up): one-click start/stop of the prepared Telegram bot and
// OpenAI-compatible server containers. `runDocker` shells out to the real
// `docker` CLI and collects its result; `createServiceControl` owns the
// lifecycle logic (argument vectors, running-state probes, stale-container
// reaping) so the same contract is exercised by node:test without a daemon.
function runDocker(args) {
  return commandRunner.run(dockerDetector.resolveDockerBinary(), args, { env: process.env });
}

const serviceControl = createServiceControl({
  env: process.env,
  runDocker,
  dockerAvailable: dockerIsAvailable,
});

// The renderer's Services panel drives these handlers: status for the indicators,
// start/stop for the one-click buttons. Each returns a plain status object the UI
// renders directly (running/stopped/missing-config/docker-unavailable).
ipcMain.handle("formalAiDesktop:serviceStatus", () => serviceControl.statusAll());
ipcMain.handle("formalAiDesktop:startService", (_event, request) => {
  const key = request && request.service ? String(request.service) : "";
  const token = request && typeof request.token === "string" ? request.token : "";
  try {
    if (key === "agent") {
      return serviceControl.installAgentEnvironment();
    }
    return serviceControl.start(key, { token });
  } catch (error) {
    return Promise.resolve({
      ok: false,
      key,
      state: "error",
      running: false,
      reason: error && error.message ? error.message : String(error),
    });
  }
});
ipcMain.handle("formalAiDesktop:installAgentEnvironment", () => {
  try {
    return serviceControl.installAgentEnvironment();
  } catch (error) {
    return Promise.resolve({
      ok: false,
      key: "agent",
      state: "error",
      running: false,
      reason: error && error.message ? error.message : String(error),
    });
  }
});
ipcMain.handle("formalAiDesktop:stopService", (_event, request) => {
  const key = request && request.service ? String(request.service) : "";
  try {
    return serviceControl.stop(key);
  } catch (error) {
    return Promise.resolve({
      ok: false,
      key,
      state: "error",
      running: false,
      reason: error && error.message ? error.message : String(error),
    });
  }
});

// Issue #515 / R11: entering Agent or Full Auto mode needs a ready local
// OpenAI-compatible backend for the later Agent CLI provider. This handler
// starts `formal-ai serve` if needed, health-checks it, and reuses a healthy
// existing process instead of spawning twice.
ipcMain.handle("formalAiDesktop:ensureAgentServer", async () => {
  try {
    return await ensureAgentServer();
  } catch (error) {
    return applyLocalServerStatus(
      localServerManager.currentStatus({
        apiReady: false,
        apiError: error && error.message ? error.message : String(error),
      }),
    );
  }
});

const webTools = createWebTools({ browserExecutablePath: packagedBrowserExecutable() });
const toolRouter = createToolRouter({
  fetchImpl: globalThis.fetch,
  readFile: (filePath) => fs.promises.readFile(filePath, "utf8"),
  writeFile: (filePath, body) => fs.promises.writeFile(filePath, body, "utf8"),
  readDirectory: (directory) => fs.promises.readdir(directory, { withFileTypes: true }),
  createDirectory: (directory) => fs.promises.mkdir(directory, { recursive: true }),
  moveFile: async (from, to) => {
    await fs.promises.mkdir(path.dirname(to), { recursive: true });
    return fs.promises.rename(from, to);
  },
  allowedReadRoot: REPO_ROOT,
  computerUseRoot: path.join(app.getPath("userData"), "computer-use"),
  resolvePath: (value) => path.resolve(REPO_ROOT, value),
  // Issue #953: the supervised engine is the authoritative authorizer.
  // currentStatus() carries apiBase only when the local server is up, so
  // an offline engine degrades to the local spec-driven checks instead of
  // blocking the desktop.
  engineAuthorize: async (payload) => {
    try {
      const status = localServerManager.currentStatus();
      if (!status || !status.apiBase) return { available: false };
      const response = await globalThis.fetch(
        `${status.apiBase}/v1/tools/authorize`,
        {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(payload),
        },
      );
      if (!response || !response.ok) return { available: false };
      return await response.json();
    } catch (_error) {
      return { available: false };
    }
  },
  realpath: (target) => fs.promises.realpath(String(target)),
  dockerAvailable: dockerIsAvailable,
  runInSandbox,
  runOnHost,
  webSearch: webTools.search,
  webFetch: webTools.fetch,
});

// Issue #759: native and installed-CLI passthrough engines share one provider
// boundary. The commander adapter uses its JavaScript API and publishes parsed
// messages while the turn is running.
const inProcessAgentProvider = createAgentProvider({
  type: "in-process",
  toolRouter,
  workingDirectory: REPO_ROOT,
  processRunner: commandRunner.run,
});
const commanderAgentProvider = createAgentProvider({
  type: "commander",
  workingDirectory: REPO_ROOT,
  onEvent: (agentEvent, request) => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send("formalAiDesktop:agentEvent", {
        requestId: String(request.requestId || ""),
        engine: String(request.commanderTool || engineManager.status().activeEngine),
        event: agentEvent,
      });
    }
  },
});

function activeAgentProvider() {
  return engineManager.status().activeEngine === OUT_OF_BOX_ENGINE
    ? inProcessAgentProvider
    : commanderAgentProvider;
}

// The renderer's permission toggles (desktop-tool-permission / -agent-permission)
// drive the default-deny grant map. Until the user opts in, every tool call is
// refused and nothing executes.
ipcMain.handle("formalAiDesktop:setToolGrants", (_event, grants) => toolRouter.setGrants(grants));
ipcMain.handle("formalAiDesktop:invokeTool", async (_event, request) => {
  const tool = request && request.tool ? String(request.tool) : "";
  if (toolRouter.isReadOnly(tool)) {
    return toolRouter.invoke(request);
  }
  if (!SUPPORTED_TOOLS.includes(tool) || !toolRouter.isPermitted(tool)) {
    return toolRouter.invoke(request);
  }
  const readyStatus = desktopStatus.apiReady ? desktopStatus : await ensureAgentServer();
  // Server mode is required: tool routing only makes sense once the local app
  // is the execution surface. Agent mode auto-starts that server; if startup
  // fails, keep the default-deny shape and do not execute anything.
  if (!readyStatus.apiReady) {
    return {
      ok: false,
      tool,
      status: "refused",
      executed: false,
      reason: readyStatus.apiError || "tool routing requires the local server",
    };
  }
  return toolRouter.invoke(request);
});

ipcMain.handle("formalAiDesktop:runAgentProvider", async (_event, request) => {
  const payload = request && typeof request === "object" ? request : {};
  if (payload.grants && typeof payload.grants === "object") {
    toolRouter.setGrants(payload.grants);
  }
  const selection = engineManager.status();
  const provider = activeAgentProvider();
  const readyStatus = provider.type === "commander"
    ? desktopStatus.apiReady
      ? desktopStatus
      : await ensureAgentServer()
    : desktopStatus;
  return provider.run({
    ...payload,
    commanderTool: selection.activeEngine,
    apiBase: readyStatus.apiBase,
    agentProvider: readyStatus.agentProvider,
    workingDirectory: payload.workingDirectory || REPO_ROOT,
  });
});

// R5c (ROADMAP D1): reconcile the browser (IndexedDB) memory log with the native
// store over the local server's Links-Notation memory endpoints.
let memorySync = null;
ipcMain.handle("formalAiDesktop:syncMemory", async (_event, payload) => {
  if (!desktopStatus.apiReady || !desktopStatus.apiBase) {
    return { ok: false, status: "unavailable", reason: "memory sync requires the local server" };
  }
  if (!memorySync) {
    memorySync = createMemorySync({ apiBase: desktopStatus.apiBase, fetchImpl: globalThis.fetch });
  }
  try {
    const outbound = payload && typeof payload.lino === "string" ? payload.lino : "";
    const pushed = outbound.trim() ? await memorySync.push(outbound) : { added: 0, total: 0 };
    const pulled = await memorySync.pull();
    return { ok: true, status: "ok", pushed, pulled };
  } catch (error) {
    return { ok: false, status: "error", reason: error && error.message ? error.message : String(error) };
  }
});

// Issue #554 (R2): one-click install of the formal-ai VS Code extension. The
// extension is not on the Marketplace yet, so the installer downloads the signed
// `.vsix` attached to the latest GitHub release and runs `code
// --install-extension` — the same artifact the manual `install.sh vscode` flow
// uses. Each side-effecting dependency is injected so the lib stays testable.
function runVsCodeCli(command, args) {
  // Windows ships the CLI as the `code.cmd` shim, which cannot be executed
  // directly. command-stream's shell `{ file, args }` form hands argument
  // construction to Node's shell-enabled spawn (command-stream#191), so both
  // platforms go through the same adapter.
  return commandRunner.run(command, args, {
    env: process.env,
    shell: process.platform === "win32",
  });
}

async function fetchReleaseJson(url) {
  const response = await globalThis.fetch(url, {
    headers: { Accept: "application/vnd.github+json", "User-Agent": "formal-ai-desktop" },
  });
  if (!response.ok) {
    throw new Error(`GitHub Releases API returned HTTP ${response.status}`);
  }
  return response.json();
}

async function downloadReleaseAsset(url, dest) {
  const response = await globalThis.fetch(url, {
    headers: { "User-Agent": "formal-ai-desktop" },
    redirect: "follow",
  });
  if (!response.ok || !response.body) {
    throw new Error(`failed to download .vsix: HTTP ${response.status}`);
  }
  const buffer = Buffer.from(await response.arrayBuffer());
  await fs.promises.writeFile(dest, buffer);
  return dest;
}

const vscodeInstaller = createVsCodeInstaller({
  env: process.env,
  runCommand: runVsCodeCli,
  fetchJson: fetchReleaseJson,
  downloadFile: downloadReleaseAsset,
  joinPath: (dir, file) => path.join(dir, file),
  tmpDir: () => os.tmpdir(),
  log: debugLog,
});

ipcMain.handle("formalAiDesktop:installVsCodeExtension", async () => {
  try {
    return await vscodeInstaller.install();
  } catch (error) {
    return {
      ok: false,
      state: "error",
      reason: error && error.message ? error.message : String(error),
    };
  }
});

ipcMain.handle("formalAiDesktop:checkForUpdates", () => updateController.checkForUpdates());
ipcMain.handle("formalAiDesktop:installUpdate", () => updateController.installUpdate());
ipcMain.handle("formalAiDesktop:getStatus", () => desktopStatus);
// Issue #672 (F2): expose the profile migration to the renderer. `status`
// answers "did anything move, and from where"; `replay` runs another
// non-destructive pass for a user who believes something is still missing.
// Both return the same shape so the renderer has one code path.
function describeDataMigration(result) {
  if (!result) {
    return { known: false, migrated: false, reason: "not-run", copied: [] };
  }
  return {
    known: true,
    migrated: Boolean(result.migrated),
    reason: result.reason || "unknown",
    copied: Array.isArray(result.copied) ? result.copied : [],
    migratedFrom:
      typeof result.migratedFrom === "string" ? result.migratedFrom : null,
    version: result.version ?? null,
    dataVersion: result.dataVersion ?? null,
    error: result.error || null,
  };
}
ipcMain.handle("formalAiDesktop:dataMigrationStatus", () =>
  describeDataMigration(lastDataMigration),
);
ipcMain.handle("formalAiDesktop:replayDataMigration", () => {
  try {
    lastDataMigration = dataMigration.migrate({ force: true });
  } catch (error) {
    lastDataMigration = {
      migrated: false,
      reason: "failed",
      error: error && error.message ? error.message : String(error),
      copied: [],
    };
  }
  return describeDataMigration(lastDataMigration);
});
ipcMain.handle("formalAiDesktop:setEngine", (_event, engine) => {
  const selection = engineManager.setActiveEngine(engine);
  desktopStatus = {
    ...desktopStatus,
    ...selection,
    agentExecutionProvider: activeAgentProvider().status(),
  };
  return desktopStatus;
});
ipcMain.handle("formalAiDesktop:openExternal", async (_event, url) => {
  if (typeof url === "string" && /^https?:\/\//i.test(url)) {
    await shell.openExternal(url);
    return true;
  }
  return false;
});

app.whenReady().then(() => {
  // Issue #541 (R3): migrate any legacy profile into the pinned userData
  // directory before the window/session is created, so an upgrading user keeps
  // their conversations. Never fatal — a migration failure must not block
  // startup, and the copy is non-destructive so it is safe to retry next launch.
  try {
    // Issue #672 (F2): the result is retained so the renderer can surface a
    // notice ("your data was moved from <profile>") and offer a replay when the
    // user believes something did not come across. Before this it was dropped
    // on the floor and the whole migration was invisible to the user.
    lastDataMigration = dataMigration.migrate();
  } catch (error) {
    debugLog(
      "data migration failed:",
      error && error.message ? error.message : String(error),
    );
    lastDataMigration = {
      migrated: false,
      reason: "failed",
      error: error && error.message ? error.message : String(error),
      copied: [],
    };
  }
  dreamingScheduler.start();
  return createMainWindow().then((window) => {
    updateController.checkForUpdates().catch((error) => {
      debugLog("auto-update startup check failed:", error && error.message ? error.message : String(error));
    });
    return window;
  });
});
app.on("window-all-closed", () => {
  shutdown().finally(() => {
    if (process.platform !== "darwin") {
      app.quit();
    }
  });
});
app.on("before-quit", shutdown);
app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createMainWindow().then(() => {
      updateController.checkForUpdates().catch((error) => {
        debugLog("auto-update activation check failed:", error && error.message ? error.message : String(error));
      });
    });
  }
});
