import {readFileSync,writeFileSync} from 'node:fs';
let source=readFileSync('scripts/lib/rust-specification-cases.mjs','utf8');
source=source.replace("import { join } from 'node:path';", "import { join } from 'node:path';\nimport { executeTypedProgram, typedProgramOf } from './rust-specification-programs.mjs';");
source=source.replace('  const cases = [];\n  let total = 0;', '  const cases = [];\n  const unsupported = [];\n  let total = 0;');
const before=`      if (result.case) {
        cases.push({ id: \`\${SPECIFICATION}/\${name}::\${test.name}\`, ...result.case });
      }`;
const after=`      const id = \`\${SPECIFICATION}/\${name}::\${test.name}\`;
      if (result.case) {
        cases.push({ id, ...result.case });
      } else {
        const typed = typedProgramOf(test.body, { source, file: join(root, SPECIFICATION, name), root });
        if (typed.program) cases.push({ id, program: typed.program });
        else unsupported.push({ id, reason: typed.reason, legacyReason: result.reason });
      }`;
if(!source.includes(before))throw Error('case integration anchor changed');source=source.replace(before,after);
source=source.replace('  return { total, cases };','  return { total, cases, unsupported };');
source=source.replace('  for (const item of cases) {\n    const responses', `  for (const item of cases) {
    if (item.program) {
      const actual = await executeTypedProgram(host, item.program);
      if (actual.status !== 'passed') failing.set(item.id, actual.failure);
      continue;
    }
    const responses`);
writeFileSync('/private/tmp/spec-recurrence-1188/rust-specification-cases-integration.draft.mjs',source);
