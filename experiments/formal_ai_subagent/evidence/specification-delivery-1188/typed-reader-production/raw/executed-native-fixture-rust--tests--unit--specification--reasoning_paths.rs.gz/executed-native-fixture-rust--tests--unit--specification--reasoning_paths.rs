//! Reasoning-path tests (R85–R88).
//!
//! These tests pin down the universal solver's registry-dispatched methods and
//! prove that each interface (library and the convenience module-level
//! entry points) routes through the same loop, without any hardcoded
//! demo-style responses. Every test exercises the event-log projection so a
//! regression to memoized answers would break here first.

use formal_ai::{
    ConversationTurn, FormalAiEngine, SymbolicAnswer, UniversalSolver, solve, solve_with_history,
};

fn answer(prompt: &str) -> SymbolicAnswer {
    FormalAiEngine.answer(prompt)
}

fn has_evidence(response: &SymbolicAnswer, expected: &str) -> bool {
    response
        .evidence_links
        .iter()
        .any(|link| link.starts_with(expected))
}

// ---------------------------------------------------------------------------
// R85: arithmetic — symbols, words, parentheses, errors.
// ---------------------------------------------------------------------------

#[test]
fn arithmetic_handles_basic_addition() {
    let response = answer("What is 2 + 2?");
    assert_eq!(response.intent, "calculation");
    assert!(response.answer.contains('4'));
    assert!((response.confidence - 1.0).abs() < f32::EPSILON);
}

#[test]
fn arithmetic_handles_parentheses_and_precedence() {
    let response = answer("Calculate 7 * (3 + 4)");
    assert_eq!(response.intent, "calculation");
    assert!(response.answer.contains("49"));
}

#[test]
fn arithmetic_handles_word_operators() {
    let response = answer("What is 10 plus 20 times 3?");
    assert_eq!(response.intent, "calculation");
    assert!(response.answer.contains("70"));
}

#[test]
fn arithmetic_handles_division_remainder() {
    let response = answer("Compute 100 - 25 % 7");
    assert_eq!(response.intent, "calculation");
    assert!(response.answer.contains("96"));
}

#[test]
fn arithmetic_solves_train_meeting_problem_with_verification_tags() {
    let response = answer(
        "Solve this step-by-step, but with verification at each stage: \
         Problem: \"A train leaves Moscow at 60 km/h. Another leaves St. \
         Petersburg at 80 km/h. Distance: 700 km. When/where do they meet?\" \
         Required format: [STEP 1]... [VERIFY] ... [STEP 5] ... Then: Ask \
         formal-ai to solve SAME problem... Compare approaches.",
    );
    assert_eq!(response.intent, "calculation");
    assert!(
        response.answer.contains("[STEP 1]") && response.answer.contains("[VERIFY]"),
        "answer should preserve requested verification tags:\n{}",
        response.answer,
    );
    assert!(
        response.answer.contains("700 / (60 + 80) = 5"),
        "answer should evaluate the relative-speed expression:\n{}",
        response.answer,
    );
    assert!(
        response.answer.contains("5 hours")
            && response.answer.contains("300 km from Moscow")
            && response.answer.contains("400 km from St. Petersburg"),
        "answer should include meeting time and both route distances:\n{}",
        response.answer,
    );
}

#[test]
fn arithmetic_routes_simple_expressions_across_supported_languages() {
    struct Case {
        language: &'static str,
        prompt: &'static str,
        expected: &'static str,
        documented: &'static str,
    }

    let cases = [
        Case {
            language: "en",
            prompt: "Please calculate 6 + 7.",
            expected: "13",
            documented: "6 + 7 = 13",
        },
        Case {
            language: "ru",
            prompt: "подскажи, сколько будет 7 + 6",
            expected: "13",
            documented: "7 + 6 = 13",
        },
        Case {
            language: "hi",
            prompt: "2 + 2 कितना है?",
            expected: "4",
            documented: "2 + 2 = 4",
        },
        Case {
            language: "zh",
            prompt: "计算 2 + 2",
            expected: "4",
            documented: "2 + 2 = 4",
        },
    ];

    for case in cases {
        let response = answer(case.prompt);
        assert_eq!(response.answer, case.documented);
        assert_eq!(
            response.intent, "calculation",
            "{} prompt should route to calculation, got {} with answer {}",
            case.language, response.intent, response.answer,
        );
        assert!(
            response.answer.contains(case.expected),
            "{} prompt should evaluate {}, got {}",
            case.language,
            case.expected,
            response.answer,
        );
    }
}

#[test]
fn arithmetic_handles_decimals() {
    let response = answer("How much is 1.5 + 2.5?");
    assert_eq!(response.intent, "calculation");
    assert!(response.answer.contains('4'));
}

#[test]
fn arithmetic_reports_division_by_zero_without_panicking() {
    let response = answer("What is 5 / 0?");
    assert_eq!(response.intent, "calculation_error");
    assert!(response.answer.to_lowercase().contains("division by zero"));
    assert!(response.confidence < 1.0);
}

#[test]
fn arithmetic_records_calculation_event_in_evidence_log() {
    let response = answer("What is 6 * 7?");
    assert!(
        response
            .evidence_links
            .iter()
            .any(|link| link.starts_with("calculation")),
        "evidence links should include the calculation event so the answer is a \
         projection of the log, not a memoized constant: {:?}",
        response.evidence_links,
    );
}

/// Method selection flows through the single data-driven registry authority
/// (`meta_method_dispatch::try_dispatch`): the resolved method is published as a
/// `method:` evidence link and named in the Links Notation trace. This pins the
/// post-migration contract that the registry — not the retired legacy mapper — is
/// the sole surface that names the method behind each answer.
#[test]
fn selected_registry_method_is_recorded_as_a_meta_method() {
    let response = answer("What is 6 * 7?");
    assert_eq!(response.intent, "calculation");
    assert!(
        response
            .evidence_links
            .iter()
            .any(|link| link.starts_with("method:")),
        "registry-backed dispatch should record the selected method event: {:?}",
        response.evidence_links,
    );
    assert!(
        response.links_notation.contains("method \"arithmetic\""),
        "the method event should name the selected registry method:\n{}",
        response.links_notation,
    );
}

#[test]
fn arithmetic_handles_large_integer_multiplication_without_overflow() {
    // Multiplying large integers should yield an exact integer result,
    // not an overflow error. Regression for issue #55.
    // 9 pairs is enough to exceed f64's range (overflow happens at pair 8).
    let expr = "123123980921093128 * 2348023048230429324 * \
                123123980921093128 * 2348023048230429324 * \
                123123980921093128 * 2348023048230429324 * \
                123123980921093128 * 2348023048230429324 * \
                123123980921093128 * 2348023048230429324 * \
                123123980921093128 * 2348023048230429324 * \
                123123980921093128 * 2348023048230429324 * \
                123123980921093128 * 2348023048230429324 * \
                123123980921093128 * 2348023048230429324";
    let response = answer(expr);
    assert_eq!(
        response.answer,
        "123123980921093128 * 2348023048230429324 * 123123980921093128 * 2348023048230429324 * 123123980921093128 * 2348023048230429324 * 123123980921093128 * 2348023048230429324 * 123123980921093128 * 2348023048230429324 * 123123980921093128 * 2348023048230429324 * 123123980921093128 * 2348023048230429324 * 123123980921093128 * 2348023048230429324 * 123123980921093128 * 2348023048230429324 = 14106037729072578219732303763058131893558797911438976263759723254861297645532782853698438305271884662855522699368411530645666807157944703912711825919309276503681820752258928464177288947927128964537894542565939212004155831409388576062134381260971721670118984372679158715813314225808627206297070554572201889629074559598592"
    );
    assert_eq!(
        response.intent, "calculation",
        "large integer multiplication must succeed, not overflow: {}",
        response.answer,
    );
    assert!(
        !response.answer.contains("overflow"),
        "answer must not mention overflow: {}",
        response.answer,
    );
}

#[test]
fn arithmetic_never_fires_on_plain_greetings() {
    let response = answer("Hi");
    assert_eq!(response.intent, "greeting");
}

#[test]
fn calendar_reasoning_answers_russian_weekday_successor() {
    let response = answer("какой день недели наступает после вторника");
    assert_eq!(response.intent, "calendar_weekday_relation");
    assert!(
        response.answer.to_lowercase().contains("среда"),
        "weekday successor should be computed as Wednesday, got: {}",
        response.answer,
    );
    assert!(
        has_evidence(&response, "calendar:operation:next"),
        "calendar reasoning must expose the successor operation in evidence: {:?}",
        response.evidence_links,
    );
}

#[test]
fn calendar_reasoning_answers_current_day_questions_across_supported_languages() {
    let cases = [
        ("What day is today?", "Today is", "language:en"),
        ("Какой сегодня день?", "Сегодня", "language:ru"),
        ("आज कौन सा दिन है?", "आज", "language:hi"),
        ("今天是星期几?", "今天", "language:zh"),
    ];

    for (prompt, expected_fragment, language_tag) in cases {
        let response = answer(prompt);
        let date = response
            .evidence_links
            .iter()
            .find_map(|link| link.strip_prefix("calendar:today:"))
            .expect("current-day answer records its exact UTC date");
        let weekday = response
            .evidence_links
            .iter()
            .find_map(|link| link.strip_prefix("calendar:weekday:"))
            .expect("current-day answer records its weekday");
        let localized_weekday = match (language_tag, weekday) {
            ("language:en", "monday") => "Monday",
            ("language:en", "tuesday") => "Tuesday",
            ("language:en", "wednesday") => "Wednesday",
            ("language:en", "thursday") => "Thursday",
            ("language:en", "friday") => "Friday",
            ("language:en", "saturday") => "Saturday",
            ("language:en", "sunday") => "Sunday",
            ("language:ru", "monday") => "понедельник",
            ("language:ru", "tuesday") => "вторник",
            ("language:ru", "wednesday") => "среда",
            ("language:ru", "thursday") => "четверг",
            ("language:ru", "friday") => "пятница",
            ("language:ru", "saturday") => "суббота",
            ("language:ru", "sunday") => "воскресенье",
            ("language:hi", "monday") => "सोमवार",
            ("language:hi", "tuesday") => "मंगलवार",
            ("language:hi", "wednesday") => "बुधवार",
            ("language:hi", "thursday") => "गुरुवार",
            ("language:hi", "friday") => "शुक्रवार",
            ("language:hi", "saturday") => "शनिवार",
            ("language:hi", "sunday") => "रविवार",
            ("language:zh", "monday") => "星期一",
            ("language:zh", "tuesday") => "星期二",
            ("language:zh", "wednesday") => "星期三",
            ("language:zh", "thursday") => "星期四",
            ("language:zh", "friday") => "星期五",
            ("language:zh", "saturday") => "星期六",
            ("language:zh", "sunday") => "星期日",
            _ => panic!("unexpected current-day locale/weekday: {language_tag}/{weekday}"),
        };
        let documented = match language_tag {
            "language:ru" => format!("Сегодня {localized_weekday}, {date} (UTC)."),
            "language:hi" => format!("आज {localized_weekday} है, {date} (UTC)."),
            "language:zh" => format!("今天是{localized_weekday}，{date}（UTC）。"),
            _ => format!("Today is {localized_weekday}, {date} (UTC)."),
        };
        assert_eq!(response.answer, documented);
        assert_eq!(
            response.intent, "calendar_current_day",
            "today question {prompt:?} should use calendar reasoning, got: {}",
            response.answer,
        );
        assert!(
            response.answer.contains(expected_fragment),
            "current-day answer for {prompt:?} should be localized, got: {}",
            response.answer,
        );
        assert!(
            has_evidence(&response, "calendar:today"),
            "current-day reasoning must record the resolved date for {prompt:?}: {:?}",
            response.evidence_links,
        );
        assert!(
            has_evidence(&response, "calendar:weekday"),
            "current-day reasoning must record the resolved weekday for {prompt:?}: {:?}",
            response.evidence_links,
        );
        assert!(
            response
                .evidence_links
                .iter()
                .any(|link| link == language_tag),
            "current-day reasoning must record {language_tag} for {prompt:?}: {:?}",
            response.evidence_links,
        );
    }
}

#[test]
fn calendar_reasoning_answers_weekday_predecessor_and_successor_variations() {
    let cases = [
        ("What day of the week comes after Tuesday?", "Wednesday"),
        ("What day comes before Monday?", "Sunday"),
        ("какой день недели перед средой", "вторник"),
        ("следующий день после воскресенья", "понедельник"),
    ];

    for (prompt, expected) in cases {
        let response = answer(prompt);
        assert_eq!(
            response.intent, "calendar_weekday_relation",
            "prompt {prompt:?} should route to calendar reasoning, got {}",
            response.intent,
        );
        assert!(
            response
                .answer
                .to_lowercase()
                .contains(&expected.to_lowercase()),
            "prompt {prompt:?} should mention {expected:?}, got: {}",
            response.answer,
        );
    }
}

#[test]
fn calendar_reasoning_answers_weekday_relations_in_hindi_and_chinese() {
    // Issue #386: the weekday names, directions, and day references now live as
    // self-describing meanings in every supported language, so calendar
    // reasoning works in Hindi and Chinese too — not just English and Russian.
    // Each answer must also be localized in the asking language.
    let cases = [
        ("सोमवार के बाद कौन सा दिन आता है", "मंगलवार"), // after Monday → Tuesday
        ("सोमवार से पहले कौन सा दिन आता है", "रविवार"), // before Monday → Sunday
        ("星期一之后是星期几", "星期二"),            // after Monday → Tuesday
        ("星期三之前是星期几", "星期二"),            // before Wednesday → Tuesday
    ];

    for (prompt, expected) in cases {
        let response = answer(prompt);
        assert_eq!(
            response.intent, "calendar_weekday_relation",
            "prompt {prompt:?} should route to calendar reasoning, got {}",
            response.intent,
        );
        assert!(
            response.answer.contains(expected),
            "prompt {prompt:?} should mention {expected:?} (localized), got: {}",
            response.answer,
        );
    }
}

// ---------------------------------------------------------------------------
// R86: concept lookup against the offline seed.
// ---------------------------------------------------------------------------

#[test]
fn concept_lookup_answers_what_is_wikipedia() {
    let response = answer("What is Wikipedia?");
    assert_eq!(response.intent, "concept_lookup");
    assert!(response.answer.to_lowercase().contains("encyclopedia"));
    assert!(
        response
            .answer
            .contains("https://en.wikipedia.org/wiki/Wikipedia")
    );
}

#[test]
fn concept_lookup_handles_tell_me_about_links_notation() {
    let response = answer("Tell me about Links Notation");
    assert_eq!(response.intent, "concept_lookup");
    assert!(response.answer.contains("Links Notation"));
    assert!(response.answer.to_lowercase().contains("indentation"));
}

#[test]
fn concept_lookup_handles_what_does_x_mean() {
    let response = answer("What does Wikidata mean?");
    assert_eq!(response.intent, "concept_lookup");
    assert!(response.answer.contains("Wikidata"));
}

#[test]
fn concept_lookup_includes_source_citation() {
    let response = answer("What is WebAssembly?");
    assert!(response.answer.contains("Source:"));
}

#[test]
fn concept_lookup_does_not_fire_for_identity_questions() {
    let response = answer("What is formal-ai?");
    assert_eq!(
        response.intent, "identity",
        "identity rule must win over concept lookup for formal-ai questions"
    );
}

#[test]
fn concept_lookup_records_concept_event_in_evidence_log() {
    let response = answer("What is Rust?");
    assert!(
        response
            .evidence_links
            .iter()
            .any(|link| link.starts_with("concept_lookup")),
        "evidence links should include the concept_lookup event: {:?}",
        response.evidence_links,
    );
}

// ---------------------------------------------------------------------------
// R87: multi-turn conversation memory via solve_with_history.
// ---------------------------------------------------------------------------

#[test]
fn solve_with_history_recalls_name_across_turns() {
    let history = [ConversationTurn::user("Hi, my name is Ada Lovelace.")];
    let response = solve_with_history("What is my name?", &history);
    assert_eq!(response.intent, "recall_name");
    assert!(response.answer.contains("Ada"));
}

#[test]
fn solve_with_history_recalls_last_question() {
    let history = [
        ConversationTurn::user("What is 2 + 2?"),
        ConversationTurn::assistant("2 + 2 = 4"),
    ];
    let response = solve_with_history("What was my previous question?", &history);
    assert_eq!(response.intent, "recall_last_question");
    assert!(response.answer.contains("2 + 2"));
}

#[test]
fn solve_with_history_summarizes_conversation() {
    let history = [
        ConversationTurn::user("Hi"),
        ConversationTurn::assistant("Hi, how may I help you?"),
        ConversationTurn::user("What is 2 + 2?"),
        ConversationTurn::assistant("2 + 2 = 4"),
    ];
    let response = solve_with_history("Summarize the conversation so far.", &history);
    assert_eq!(response.intent, "summarize_conversation");
    assert!(response.answer.contains("Hi"));
    assert!(response.answer.contains("2 + 2"));
}

#[test]
fn solve_with_history_summarizes_conversation_in_russian() {
    let history = [
        ConversationTurn::user("Что такое яблоко?"),
        ConversationTurn::assistant("Яблоко: Я́блоко — сочный плод яблони."),
    ];
    let response = solve_with_history("О чём мы разговаривали?", &history);
    assert_eq!(response.intent, "summarize_conversation");
    assert!(response.answer.contains("яблоко"));
}

#[test]
fn solve_with_history_summarizes_conversation_rezyume_besedy() {
    let history = [
        ConversationTurn::user("Привет"),
        ConversationTurn::assistant("Здравствуйте! Чем могу помочь?"),
    ];
    let response = solve_with_history("Резюме беседы", &history);
    assert_eq!(response.intent, "summarize_conversation");
    assert!(response.answer.contains("Привет"));
}

#[test]
fn solve_with_history_summarizes_conversation_single_word_summarize() {
    let history = [
        ConversationTurn::user("Hi"),
        ConversationTurn::assistant("Hi, how may I help you?"),
    ];
    let response = solve_with_history("Summarize", &history);
    assert_eq!(response.intent, "summarize_conversation");
    assert!(response.answer.contains("Hi"));
}

#[test]
fn solve_with_history_summarizes_conversation_in_chinese() {
    let history = [
        ConversationTurn::user("你好"),
        ConversationTurn::assistant("你好!请问有什么可以帮您的?"),
    ];
    let response = solve_with_history("总结", &history);
    assert_eq!(response.intent, "summarize_conversation");
    assert!(response.answer.contains("你好"));
}

#[test]
fn solve_with_history_falls_through_for_unrelated_prompts() {
    let history = [ConversationTurn::user("My name is Ada.")];
    let response = solve_with_history("Hi", &history);
    assert_eq!(response.intent, "greeting");
}

#[test]
fn solve_without_history_matches_legacy_entry_point() {
    let a = solve("Hi");
    let b = FormalAiEngine.answer("Hi");
    assert_eq!(a, b);
}

#[test]
fn prior_turns_appear_in_evidence_log() {
    let history = [ConversationTurn::user("My name is Ada.")];
    let response = UniversalSolver::default().solve_with_history("Hi", &history);
    assert!(
        response
            .evidence_links
            .iter()
            .any(|link| link.starts_with("prior_turn:user")),
        "prior turns must be recorded as events so memory recall is a projection \
         of the append-only log: {:?}",
        response.evidence_links,
    );
}

// ---------------------------------------------------------------------------
// R88: JavaScript execution — explicit declaration, no silent failure.
// ---------------------------------------------------------------------------

#[test]
fn javascript_request_returns_explicit_unavailability() {
    let prompt = "Please run this javascript:\n```js\nconsole.log(1 + 2);\n```";
    let response = answer(prompt);
    assert_eq!(response.intent, "tool_call_refused");
    assert!(response.answer.contains("Execution status: refused"));
    assert!(response.answer.contains("agent mode"));
    assert!(response.answer.contains("console.log(1 + 2);"));
}

#[test]
fn javascript_request_records_execution_status_event() {
    let prompt = "Please execute this javascript:\n```js\nlet x = 5;\n```";
    let response = answer(prompt);
    assert!(
        response
            .evidence_links
            .iter()
            .any(|link| link.starts_with("execution_status")),
        "the JS handler must emit an execution_status event so refusal is \
         auditable: {:?}",
        response.evidence_links,
    );
}

#[test]
fn javascript_handler_does_not_intercept_unrelated_code_blocks() {
    // No "run this" cue, so the handler must not steal the prompt from the
    // generic algorithm/code-fence flow.
    let prompt = "Here is some javascript:\n```js\nconsole.log(1);\n```";
    let response = answer(prompt);
    assert_ne!(response.intent, "javascript_execution_unavailable");
}

// ---------------------------------------------------------------------------
// Issue #52: "how it works?" follow-up after a Wikipedia lookup must not
// return intent: unknown.
// ---------------------------------------------------------------------------

#[test]
fn how_it_works_bare_is_not_unknown() {
    // The simplest bare-form follow-up must never resolve to `unknown`.
    let response = answer("how it works?");
    assert_ne!(
        response.intent, "unknown",
        "\"how it works?\" must not return unknown; got intent={}, answer={}",
        response.intent, response.answer,
    );
}

#[test]
fn how_does_it_work_is_not_unknown() {
    let response = answer("how does it work?");
    assert_ne!(
        response.intent, "unknown",
        "\"how does it work?\" must not return unknown; got intent={}, answer={}",
        response.intent, response.answer,
    );
}

#[test]
fn how_it_works_after_concept_lookup_looks_up_the_concept() {
    // Issue #52: after looking up a concept, "how it works?" should elaborate
    // on it. The prior assistant reply starts with "Wikipedia (encyclopedia): ..."
    // so the solver should re-run a concept lookup for Wikipedia.
    let history = [
        ConversationTurn::user("what is 25519"),
        ConversationTurn::assistant(
            "Curve25519 (cryptography): An elliptic curve used in ECC. \
             Source: https://en.wikipedia.org/wiki/Curve25519 (wikipedia).",
        ),
    ];
    let response = solve_with_history("how it works?", &history);
    assert_ne!(
        response.intent, "unknown",
        "\"how it works?\" after a concept reply must not return unknown; \
         got intent={}, answer={}",
        response.intent, response.answer,
    );
}

#[test]
fn how_does_wikipedia_work_resolves_concept_lookup() {
    // Explicit subject in "how does X work?" form.
    let response = answer("how does Wikipedia work?");
    assert_ne!(
        response.intent, "unknown",
        "\"how does Wikipedia work?\" must not return unknown; got intent={}, answer={}",
        response.intent, response.answer,
    );
    // Since Wikipedia is in the concept seed it should resolve as concept_lookup.
    assert!(
        response.intent.starts_with("concept_lookup")
            || response.intent == "meta_explanation"
            || response.intent == "how_it_works",
        "unexpected intent {} for \"how does Wikipedia work?\"",
        response.intent,
    );
}

#[test]
fn how_it_works_followup_records_followup_event_in_evidence() {
    let history = [
        ConversationTurn::user("what is Wikipedia"),
        ConversationTurn::assistant(
            "Wikipedia (encyclopedia): A free online encyclopedia.\n\nSource: \
             https://en.wikipedia.org/wiki/Wikipedia (wikipedia).",
        ),
    ];
    let response = solve_with_history("how it works?", &history);
    assert!(
        response
            .evidence_links
            .iter()
            .any(|link| link.starts_with("followup:")),
        "\"how it works?\" handler must emit a followup: evidence event: {:?}",
        response.evidence_links,
    );
}

#[test]
fn how_it_works_prior_reply_fallback_skips_function_words_case_insensitively() {
    // When the prior reply has no "Term (category):" header, topic extraction
    // falls back to the first capitalised token that is not a
    // `topic_scan_stop_word` (data/seed/meanings-how.lino). The skip list is
    // matched case-insensitively, so the all-caps leading "THE" is skipped and
    // the real subject "Widgetronics" is taken. A hardcoded title-case array
    // (the pre-conversion behaviour) would have failed to match "THE" and
    // mis-read the function word itself as the topic — this test guards that
    // generalization.
    let history = [
        ConversationTurn::user("tell me about the gadget"),
        ConversationTurn::assistant(
            "THE Widgetronics core spins quietly without a category header.",
        ),
    ];
    let response = solve_with_history("how it works?", &history);
    assert!(
        response.answer.to_lowercase().contains("widgetronics"),
        "fallback topic scan must skip the all-caps function word and name \
         'Widgetronics'; got intent={}, answer={}",
        response.intent,
        response.answer,
    );
    assert!(
        !response.answer.to_lowercase().contains("how the works"),
        "fallback topic scan must not treat the function word 'the' as the \
         topic; got answer={}",
        response.answer,
    );
}

// ---------------------------------------------------------------------------
// Issue #183: "how X works?" must support explicit subjects across languages.
// ---------------------------------------------------------------------------

#[test]
fn multilingual_how_x_works_prompts_use_mechanism_discovery() {
    for prompt in [
        "как устроен AUR?",
        "как работает AUR?",
        "how does AUR work?",
        "AUR कैसे काम करता है?",
        "AUR 如何工作?",
    ] {
        let response = answer(prompt);
        if prompt == "how does AUR work?" {
            assert_eq!(
                response.answer,
                "Mechanism discovery plan for `AUR`.\n\nI do not answer this from a memoized fact. The solver treats the prompt as a question about how `AUR` works, checks Wikipedia for a source-backed overview, Wikidata for entity relationships, then web search across duckduckgo, internet-archive, wikipedia, wikidata, wiktionary, wikinews. If no source explains the mechanism, it should ask for a source or a narrower term instead of inventing details."
            );
        }
        assert_eq!(
            response.intent, "how_it_works",
            "{prompt:?} must route to mechanism discovery; got intent={}, answer={}",
            response.intent, response.answer,
        );
        assert!(
            response.answer.to_lowercase().contains("aur"),
            "{prompt:?} answer should name the requested subject; answer={}",
            response.answer,
        );

        for expected in [
            "followup:how_it_works",
            "followup:subject:inline:aur",
            "mechanism_query:stage:wikipedia",
            "mechanism_query:stage:wikidata",
            "mechanism_query:stage:web_search",
        ] {
            assert!(
                has_evidence(&response, expected),
                "{prompt:?} missing evidence prefix {expected:?}: {:?}",
                response.evidence_links,
            );
        }
    }
}

#[test]
fn russian_how_known_concept_works_resolves_concept_lookup() {
    let response = answer("как устроена Википедия?");
    assert!(
        response.intent.starts_with("concept_lookup"),
        "known Russian subject should still resolve through concept lookup; \
         got intent={}, answer={}",
        response.intent,
        response.answer,
    );
    assert!(
        has_evidence(&response, "followup:how_it_works"),
        "handler should record the how-it-works follow-up event: {:?}",
        response.evidence_links,
    );
    assert!(
        has_evidence(&response, "concept_lookup:hit:concept_wikipedia"),
        "known subject should hit the Wikipedia concept seed: {:?}",
        response.evidence_links,
    );
}

// ---------------------------------------------------------------------------
// Issue #404: natural language calendar create/schedule ("забей 18 число...").
// The prompt must not fall to unknown; it must produce a structured
// calendar_create_event with rich parsed_* evidence and a confirmation body.
// ---------------------------------------------------------------------------

mod extended;
