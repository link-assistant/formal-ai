from pathlib import Path
import gzip,hashlib,json,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'runtime-desktop-headroom-preservation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 assert result.returncode==0,(name,result.returncode)
 return (out/(name+'.stdout')).read_text()
def preserve(name,folders,helpers,summary):
 target=root/'experiments/issue-1580/evidence/checks'/name;target.mkdir(exist_ok=False);records=[]
 def archive(source,relative):
  raw=source.read_bytes();packed=gzip.compress(raw,mtime=0);dest=target/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed);records.append({'file':relative,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
 for folder in folders:
  directory=scratch/folder
  for file in sorted(directory.rglob('*')):
   if file.is_file() and file.name not in ['pid.json']:archive(file,folder+'/'+str(file.relative_to(directory))+'.gz')
 for helper in helpers:archive(scratch/helper,'supplied-helpers/'+helper+'.gz')
 for file in sorted((root/'experiments/issue-1580/evidence/commands').glob('2026-11-21T17-*.json')):
  if any(helper in json.loads(file.read_text())['request'] for helper in helpers):archive(file,'formal-sessions/'+file.name+'.gz')
 (target/'records.jsonl').write_text(''.join(json.dumps(record,separators=(',',':'))+'\n' for record in records));(target/'identity.json').write_text(json.dumps(summary,indent=2)+'\n')
 for record in records:
  packed=(target/record['file']).read_bytes();raw=gzip.decompress(packed);assert hashlib.sha256(raw).hexdigest()==record['rawSha256'] and hashlib.sha256(packed).hexdigest()==record['archiveSha256'] and len(raw)==record['bytes'] and len(raw.splitlines())==record['lines']
 return str(target.relative_to(root)),len(records)
def commit(name,paths,message):
 assert run(name+'-branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
 assert run(name+'-staged-before',['git','diff','--cached','--name-only']).strip()==''
 run(name+'-stage',['git','add','--',*paths]);run(name+'-whitespace',['git','diff','--cached','--check']);run(name+'-secrets',['bash','scripts/check-secrets.sh']);run(name+'-commit',['git','commit','-m',message])
 return run(name+'-head',['git','rev-parse','HEAD']).strip()
try:
 native=json.loads((scratch/'line-operation-implementation-headroom/outcome.json').read_text());desktop=json.loads((scratch/'desktop-manifest-headroom-continuation/outcome.json').read_text());assert native['complete'] and desktop['complete']
 doc=root/'docs/case-studies/issue-1580/line-operation-headroom-checkpoint.md';doc.write_text('# Whole-line operation implementation headroom\n\nBoth complete `LineOperation` implementation blocks, including their comments,\nnow live in a focused child module. The owner falls from 957 to 850 lines;\nthe child has 112 lines. An exact inverse preserves the original owner before\nformatting, and visibility still reaches the original `agentic_coding` ancestor.\nThe regression fails before extraction and passes after it. Existing whole-line\noperation behavior checks, Rust formatting, projection currency and whitespace\nchecks pass. Native execution remains for hosted CI.\n\nEvidence: `experiments/issue-1580/evidence/checks/line-operation-headroom/`.\nSupplied procedures receive zero independent authorship credit. Wider issue work\nremains unfinished: https://github.com/link-assistant/formal-ai/pull/1581.\n')
 fragment=root/'changelog.d/20261121_1580_line_operation_headroom.md';fragment.write_text('### Changed\n\n- Split complete whole-line operation implementations into a focused child module while preserving method bodies, comments, visibility and behavior.\n')
 evidence,native_archives=preserve('line-operation-headroom',['line-operation-implementation-headroom'],['extract-line-operation-implementation.py'],native)
 native_head=commit('line-operation',['rust/src/agentic_coding/workspace_line_operation.rs','rust/src/agentic_coding/workspace_line_operation/applied_changes.rs','experiments/issue-1580/native-test-headroom.test.mjs',str(doc.relative_to(root)),str(fragment.relative_to(root)),evidence],'Extract whole-line operation application without changing behavior')
 doc=root/'docs/case-studies/issue-1580/desktop-manifest-headroom-checkpoint.md';doc.write_text('# Desktop release shell implementation headroom\n\nThe complete checksum/provenance manifest and durable evidence-collection shell\nbodies move unchanged to two named scripts. Both helpers are captured from the\nworkflow-selected protocol checkout before the selected binary source is\nimported. Every existing step environment and producer-output identity remains\nunchanged. Exact inverses reconstruct both workflow edits.\n\nThe first extraction left the workflow two lines over the unchanged warning\nthreshold; that failed check is retained. Extracting the neighboring complete\nevidence-collection body supplies headroom. The release-asset regression still\nexecutes the actual manifest script against controlled release fragments, and\nall 267 maintained issue checks pass. Affected local gates pass; source scanning\nreports 42 warnings and zero violations. Hosted release execution is not claimed.\n\nEvidence: `experiments/issue-1580/evidence/checks/desktop-release-headroom/`.\nSupplied procedures receive zero independent authorship credit. Wider issue work\nremains unfinished: https://github.com/link-assistant/formal-ai/pull/1581.\n')
 fragment=root/'changelog.d/20261121_1580_desktop_release_headroom.md';fragment.write_text('### Changed\n\n- Extract desktop release checksum and evidence shell bodies into workflow-selected protocol helpers, retaining release-source isolation and producer receipts.\n')
 metadata=root/'docs/case-studies/issue-1580/metadata-storage-headroom-checkpoint.md';text=metadata.read_text();needle='The full 141-entry gate replay found a stale generated status line census.\n';assert needle in text;text=text.replace(needle,'The full 141-entry gate replay found a stale generated status line census\nand a new majority field in the small tail shard. Balancing complete records\nretained the original archive bytes without increasing notation ceilings.\n');metadata.write_text(text)
 assert 'ℹ pass 267' in (scratch/'desktop-manifest-headroom-continuation/maintained-observations.stdout').read_text()
 evidence,desktop_archives=preserve('desktop-release-headroom',['desktop-manifest-headroom','desktop-manifest-headroom-continuation'],['repair-desktop-manifest-headroom.py','finish-desktop-manifest-headroom.py',Path(__file__).name],desktop)
 desktop_head=commit('desktop',['.github/workflows/desktop-release.yml','scripts/desktop-release-manifest.sh','scripts/desktop-release-evidence.sh','rust/tests/web/issue-1181-cli-release-assets.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs','experiments/issue-1580/desktop-manifest-headroom.test.mjs',str(doc.relative_to(root)),str(fragment.relative_to(root)),str(metadata.relative_to(root)),evidence],'Extract desktop release shell bodies with pinned protocol selection')
 (out/'outcome.json').write_text(json.dumps({'complete':True,'nativeCommit':native_head,'desktopCommit':desktop_head,'nativeArchives':native_archives,'desktopArchives':desktop_archives,'pushed':False,'nativeExecutionVerified':False,'fullIssueComplete':False},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
