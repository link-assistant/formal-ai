from pathlib import Path
import hashlib,json,os,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/desktop-manifest-headroom')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':result.returncode}),flush=True);assert result.returncode in allowed,(name,result.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 assert json.loads(Path('/tmp/issue-1580-research/maintained-metadata-headroom/outcome.json').read_text())['complete']
 paths=['.github/workflows/desktop-release.yml','rust/tests/web/issue-1181-cli-release-assets.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs']
 for path in paths:
  dest=out/'preimages'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((root/path).read_bytes())
 test=root/'experiments/issue-1580/desktop-manifest-headroom.test.mjs'
 test.write_text('''// Desktop release manifests retain the workflow-selected protocol and source-size headroom.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import test from 'node:test';
import YAML from 'yaml';
import {checkListedFiles} from '../../scripts/check-file-size.mjs';
const root=fileURLToPath(new URL('../../',import.meta.url)).replace(/\\/$/u,'');
test('desktop release retains unchanged source-size headroom',()=>{
 assert.deepEqual(checkListedFiles(root,new Set(['.github/workflows/desktop-release.yml','scripts/desktop-release-manifest.sh'])),{warnings:[],violations:[],embeddedDataViolations:[]});
});
test('the manifest helper is captured before selected-source import',()=>{
 const workflow=YAML.parse(readFileSync(root+'/.github/workflows/desktop-release.yml','utf8'));
 const steps=workflow.jobs.finalize.steps;
 const capture=steps.findIndex(step=>step.name==='Capture release protocol before selecting binary source');
 const source=steps.findIndex(step=>step.name==='Import selected source for durable worker verification');
 const manifest=steps.find(step=>step.name==='Build consolidated SHA256SUMS.txt and BUILD-PROVENANCE.txt');
 assert(capture>=0&&capture<source);
 assert.match(steps[capture].run,/cp scripts\\/desktop-release-manifest\\.sh "\\$protocol_dir\\/"/u);
 assert.equal(manifest.run.trim(),'bash "$FORMAL_AI_NATIVE_PROTOCOL_DIR/desktop-release-manifest.sh"');
 assert.equal(manifest.env.RELEASE_PRODUCER_OUTPUT_STEP,'manifest');
 assert.equal(manifest.env.RELEASE_PRODUCER_OUTPUT_KEYS,'incomplete');
});
''')
 run('headroom-before',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)],(1,))
 native=root/'.github/workflows/desktop-release.yml';source=native.read_text();step=source.index('      - name: Build consolidated SHA256SUMS.txt and BUILD-PROVENANCE.txt\n');start=source.index('        run: |\n',step)+len('        run: |\n');end=source.index('      - name: Attest canonical producer outputs\n',start);old=source[start:end];assert all(not line.strip() or line.startswith('          ') for line in old.splitlines());body='\n'.join(line[10:] for line in old.splitlines())+'\n'
 script=root/'scripts/desktop-release-manifest.sh';assert not script.exists();script.write_text('#!/usr/bin/env bash\n# Workflow-selected desktop checksum and complete/partial provenance reporting.\n'+body);script.chmod(0o755)
 replacement='          bash "$FORMAL_AI_NATIVE_PROTOCOL_DIR/desktop-release-manifest.sh"\n';next=source[:start]+replacement+source[end:];capture='          cp .github/workflows/desktop-release.yml "$protocol_dir/producer-output-workflow.yml"\n';assert next.count(capture)==1;copy='          cp scripts/desktop-release-manifest.sh "$protocol_dir/"\n';next=next.replace(capture,copy+capture,1);native.write_text(next)
 assert next.replace(copy,'',1).replace(replacement,old,1)==source
 assert script.read_text().split('\n',2)[2]==body
 assets=root/'rust/tests/web/issue-1181-cli-release-assets.test.mjs';text=assets.read_text();old_assert='''  for (const leg of cliLegs()) {
    assert.match(script, new RegExp(`\\\\[${leg.label}\\\\]="${leg.os}"`), `builder_of maps ${leg.label}`);
    assert.match(script, new RegExp(`for label in [^;]*\\\\b${leg.label}\\\\b`), `the label loop covers ${leg.label}`);
  }''';new_assert=old_assert.replace('  for (const leg','  const implementation = read("scripts/desktop-release-manifest.sh");\n  for (const leg').replace('assert.match(script,','assert.match(implementation,');assert text.count(old_assert)==1;text=text.replace(old_assert,new_assert,1);old_names='["release-producer-output-receipt.mjs", "release-checksums.mjs"]';assert text.count(old_names)==1;text=text.replace(old_names,'["release-producer-output-receipt.mjs", "release-checksums.mjs", "desktop-release-manifest.sh"]',1);assets.write_text(text)
 owner=root/'rust/tests/web/issue-1580-template-observations.test.mjs';text=owner.read_text();addition="import '../../../experiments/issue-1580/desktop-manifest-headroom.test.mjs';\n";assert addition not in text;owner.write_text(text+'\n'+addition)
 (out/'conservation.json').write_text(json.dumps({'workflowExactInverse':True,'completeShellBodyUnchanged':True,'bodySha256':hashlib.sha256(body.encode()).hexdigest(),'workflowBeforeLines':len(source.splitlines()),'workflowAfterLines':len(next.splitlines()),'helperLines':len(script.read_text().splitlines()),'sourceSelectionAndEnvironmentUnchanged':True,'nativeExecutionVerified':False,'independentAuthorshipCredit':0},indent=2)+'\n')
 run('shell-parse',['bash','-n',str(script)])
 run('headroom-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)])
 run('release-asset-regressions',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(assets)])
 run('maintained-observations',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(owner)])
 run('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-abbreviations,check-runner-labels,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-changelog-fragment-js-twin,check-reconstructed-changelog,workflows'])
 run('source-warnings',['node','--max-old-space-size=256','scripts/check-file-size.mjs']);warnings=(out/'source-warnings.stdout').read_text().count('::warning file=');assert warnings==42,warnings
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'warnings':warnings,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
