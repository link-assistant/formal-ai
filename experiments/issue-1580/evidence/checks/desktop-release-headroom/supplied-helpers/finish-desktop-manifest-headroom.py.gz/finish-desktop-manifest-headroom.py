from pathlib import Path
import hashlib,json,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/desktop-manifest-headroom-continuation');initial=Path('/tmp/issue-1580-research/desktop-manifest-headroom')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':result.returncode}),flush=True);assert result.returncode==0,(name,result.returncode)
try:
 assert (initial/'failed.txt').exists()
 owner=root/'.github/workflows/desktop-release.yml';source=owner.read_text();(out/'workflow-before.yml').write_text(source)
 step=source.index('      - name: Validate and prepare exact-byte durable release evidence\n');start=source.index('        run: |\n',step)+len('        run: |\n');end=source.index('      - name: Preserve the verified worker and receipt as durable release assets\n',start);old=source[start:end]
 assert all(not row.strip() or row.startswith('          ') for row in old.splitlines())
 body='\n'.join(row[10:] for row in old.splitlines())+'\n';helper=root/'scripts/desktop-release-evidence.sh';assert not helper.exists();helper.write_text('#!/usr/bin/env bash\n# Workflow-selected durable desktop worker and receipt evidence.\n'+body);helper.chmod(0o755)
 call='          bash "$FORMAL_AI_NATIVE_PROTOCOL_DIR/desktop-release-evidence.sh"\n';capture='          cp scripts/desktop-release-manifest.sh "$protocol_dir/"\n';copy='          cp scripts/desktop-release-evidence.sh "$protocol_dir/"\n';assert source.count(capture)==1
 changed=(source[:start]+call+source[end:]).replace(capture,capture+copy,1);owner.write_text(changed)
 assert changed.replace(copy,'',1).replace(call,old,1)==source and helper.read_text().split('\n',2)[2]==body
 test=root/'experiments/issue-1580/desktop-manifest-headroom.test.mjs';text=test.read_text();text=text.replace("'.github/workflows/desktop-release.yml','scripts/desktop-release-manifest.sh'","'.github/workflows/desktop-release.yml','scripts/desktop-release-manifest.sh','scripts/desktop-release-evidence.sh'")
 needle=" assert.equal(manifest.env.RELEASE_PRODUCER_OUTPUT_KEYS,'incomplete');\n";assert text.count(needle)==1
 text=text.replace(needle,needle+''' const evidence=steps.find(step=>step.name==='Validate and prepare exact-byte durable release evidence');
 assert.match(steps[capture].run,/cp scripts\\/desktop-release-evidence\\.sh "\\$protocol_dir\\/"/u);
 assert.equal(evidence.run.trim(),'bash "$FORMAL_AI_NATIVE_PROTOCOL_DIR/desktop-release-evidence.sh"');
''');test.write_text(text)
 run('shell-parse',['bash','-n',str(helper)])
 run('headroom-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)])
 run('release-asset-regressions',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1181-cli-release-assets.test.mjs'])
 run('maintained-observations',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])
 run('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-abbreviations,check-runner-labels,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-changelog-fragment-js-twin,check-reconstructed-changelog,workflows'])
 run('source-warnings',['node','--max-old-space-size=256','scripts/check-file-size.mjs']);warnings=(out/'source-warnings.stdout').read_text().count('::warning file=');assert warnings==42,warnings
 run('whitespace',['git','diff','--check'])
 result={'complete':True,'warnings':warnings,'workflowLines':len(changed.splitlines()),'additionalHelperBodyUnchanged':True,'additionalHelperBodySha256':hashlib.sha256(body.encode()).hexdigest(),'additionalWorkflowExactInverse':True,'nativeExecutionVerified':False,'independentAuthorshipCredit':0,'fullIssueComplete':False}
 (out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');(initial/'outcome.json').write_text(json.dumps(result,indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
