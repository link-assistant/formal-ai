from pathlib import Path
import json, subprocess, hashlib, re
r=Path('/tmp/issue-1580-research/aggregate-other-docs-review-bc08')
base='03a636334975cd7ca5cedff119e2dd0efbc8579f';head='bc08222b5a5195dc9992c0459bde2b6369377b9f'
def blob(rev,p):return subprocess.check_output(['git','show',rev+':'+p])
def strict_pairs(pairs):
 d={}
 for k,v in pairs:
  assert k not in d
  d[k]=v
 return d
def js(s):return json.loads(s,object_pairs_hook=strict_pairs)
cp='docs/case-studies/issue-498/replay/google-trends-catalog.lino'
sp='docs/case-studies/issue-498/agent-cli-session-google-trends.json'
a=blob(base,cp).decode(); b=blob(head,cp).decode()
al=a.splitlines(keepends=True);bl=b.splitlines(keepends=True);assert len(al)==len(bl)==980
pairs=js((r/'catalog-uniform-answer-deltas.json').read_text())
proof=[];seen=set();topic=None
for i,(x,y) in enumerate(zip(al,bl),1):
 if x.startswith('    query '):topic=js(x.strip()[6:])
 if x==y:continue
 assert x.startswith('      answer ') and y.startswith('      answer ')
 old=js(x.strip()[7:]);new=js(y.strip()[7:])
 v=[v for v in pairs if i in v['lineNumbers']];assert len(v)==1;v=v[0]
 def match(pattern,s):
  regex=re.escape(pattern).replace(re.escape('<TOPIC>'),'(.*?)')
  m=re.fullmatch(regex,s);assert m,(i,pattern,s);return m.groups()
 ca=match(v['before'],old);cb=match(v['after'],new)
 assert not ca or ca==cb
 for captured in ca+cb:assert captured in {topic,topic.replace('grok45','grok4 5')}
 proof.append({'line':i,'query':topic,'captured':cb,'pair':pairs.index(v)});seen.add(i)
assert len(proof)==80 and seen=={i for v in pairs for i in v['lineNumbers']}
sa=js(blob(base,sp));sb=js(blob(head,sp))
prefix='Generated the Google Trends catalog from 10 top searches in US: produced 80 multilingual request variants and answered 80 of them through the standard Formal AI engine. The catalog is generated from the checked-in Trends RSS snapshot, so tests stay offline while the converter can refresh the seed from the live RSS feed.\n\nGenerated document (google-trends-catalog.lino):\n\n'
for v,c in [(sa,a),(sb,b)]:
 assert v['steps'][0]['arguments']['content']==c
 assert v['final_answer']==prefix+c.rstrip('\n')
 assert v['steps'][0]['result']=='wrote '+str(len(c.encode()))+' byte(s) to google-trends-catalog.lino'
sa['final_answer']=sb['final_answer'];sa['steps'][0]['arguments']['content']=sb['steps'][0]['arguments']['content'];sa['steps'][0]['result']=sb['steps'][0]['result'];assert sa==sb
fp='docs/case-studies/issue-951/function-inventory.json'
fa=js(blob(base,fp));fb=js(blob(head,fp));key='js/app/application-conversation-hooks.jsx'
assert fa['legacy_functions'][key]==['useConversationMessages','useInterfaceCommands']
assert fb['legacy_functions'][key]==['useConversationList','useConversationMessages','useInterfaceCommands']
fa['legacy_functions'][key]=fb['legacy_functions'][key];assert fa==fb
result={'base':base,'head':head,'catalogLines':980,'changedAnswerLines':proof,'otherCatalogBytesEqual':True,'sessionOnlyThreeDerivedFieldsChanged':True,'sessionCatalogContentExact':True,'sessionResultByteCountsExact':True,'functionInventoryOnlyAddedUseConversationList':True,'duplicateJSONKeysRejected':True,'newExecutionCredit':0}
(r/'structured-conservation.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='changedAnswerLines'}))
print('all 80 before/after answer lines match 10 reviewed topic-parametric transforms')
