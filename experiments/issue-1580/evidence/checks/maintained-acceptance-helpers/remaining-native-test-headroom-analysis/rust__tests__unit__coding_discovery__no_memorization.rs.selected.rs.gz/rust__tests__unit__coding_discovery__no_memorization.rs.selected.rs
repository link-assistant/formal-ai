#[test]
fn upstream_slice_names_and_sentences_are_absent_from_runtime_and_seed() {
    let root = Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("the repository root sits one level above the crate");
    let cache = benchmark_cache(root);
    let humaneval = cache.join("humaneval.jsonl");
    let mbpp = cache.join("mbpp.jsonl");

    let mut forbidden_names = BTreeSet::new();
    let mut forbidden_sentences = BTreeSet::new();
    if humaneval.is_file() {
        for value in json_lines(&humaneval, HUMANEVAL_SLICE) {
            if let Some(name) = value.get("entry_point").and_then(serde_json::Value::as_str) {
                forbidden_names.insert(name.to_owned());
            }
            if let Some(prompt) = value.get("prompt").and_then(serde_json::Value::as_str) {
                for sentence in docstring_sentences(prompt) {
                    if sentence.split_whitespace().count() > 4 {
                        forbidden_sentences.insert(sentence);
                    }
                }
            }
        }
    }
    if mbpp.is_file() {
        for value in json_lines(&mbpp, MBPP_SLICE) {
            if let Some(text) = value.get("text").and_then(serde_json::Value::as_str) {
                forbidden_sentences.insert(normalize(text));
            }
            if let Some(tests) = value.get("test_list").and_then(serde_json::Value::as_array) {
                for test in tests {
                    if let Some(name) = test
                        .as_str()
                        .and_then(|line| line.trim().strip_prefix("assert "))
                        .and_then(|assertion| {
                            assertion.split_once('(').map(|(name, _)| name.trim())
                        })
                    {
                        forbidden_names.insert(name.to_owned());
                    }
                }
            }
        }
    }
    add_non_coding_sentences(&cache, &mut forbidden_sentences);
    for (_, sentence) in NON_CODING_CANARIES {
        forbidden_sentences.insert(normalize(sentence));
    }
    forbidden_names.retain(|name| !GENERIC_FUNCTION_NAMES.contains(&name.as_str()));

    let mut violations = Vec::new();
    for path in source_and_seed_files(root) {
        let Ok(text) = fs::read_to_string(&path) else {
            continue;
        };
        let normalized = normalize(&text);
        for name in &forbidden_names {
            if contains_identifier(&text, name) {
                violations.push(format!(
                    "{} contains upstream entry point {name}",
                    path.display()
                ));
            }
        }
        for sentence in &forbidden_sentences {
            if !sentence.is_empty() && normalized.contains(sentence) {
                violations.push(format!(
                    "{} contains upstream task sentence {sentence:?}",
                    path.display()
                ));
            }
        }
    }

    assert!(
        violations.is_empty(),
        "benchmark-specific knowledge entered runtime or seed:\n{}",
        violations.join("\n")
    );
}
