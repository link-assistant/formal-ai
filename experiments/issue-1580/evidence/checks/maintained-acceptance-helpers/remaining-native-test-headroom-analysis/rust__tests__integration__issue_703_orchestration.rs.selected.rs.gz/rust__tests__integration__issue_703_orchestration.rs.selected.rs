#[test]
fn direct_vendor_entrypoints_keep_editing_and_prompt_arguments() {
    use std::os::unix::fs::PermissionsExt as _;

    let fake_bin = TestWorkspace::new("vendor-cli-bin");
    for cli in REQUIRED_CLIS {
        let path = fake_bin.path().join(cli);
        fs::write(&path, "#!/bin/sh\nprintf '%s\\n' \"$*\"\n").unwrap();
        fs::set_permissions(&path, fs::Permissions::from_mode(0o755)).unwrap();
    }
    let path = std::env::join_paths(std::iter::once(fake_bin.path().to_path_buf()).chain(
        std::env::split_paths(&std::env::var_os("PATH").unwrap_or_default()),
    ))
    .unwrap();

    for cli in REQUIRED_CLIS {
        let workspace = TestWorkspace::new(&format!("vendor-{cli}"));
        let session_path = workspace.path().join("session.json");
        let output = Command::new(env!("CARGO_BIN_EXE_formal-ai"))
            .args([
                "agent",
                "run",
                "--cli",
                cli,
                "--target",
                "vendor",
                "--task",
                "vendor task",
                "--workspace",
            ])
            .arg(workspace.path())
            .args(["--session"])
            .arg(&session_path)
            .env("PATH", &path)
            .output()
            .unwrap();

        assert!(
            output.status.success(),
            "{cli}: stdout={} stderr={}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
        let session = replay_session(&fs::read(session_path).unwrap()).unwrap();
        assert!(session.passed());
        assert_eq!(session.args.last().map(String::as_str), Some("vendor task"));
        match cli {
            "agent" => {
                assert!(
                    session
                        .args
                        .windows(2)
                        .any(|args| args == ["-p", "vendor task"])
                );
                assert!(
                    session
                        .args
                        .iter()
                        .any(|arg| arg == "--no-retry-on-rate-limits")
                );
            }
            "gemini" | "qwen" => {
                assert!(
                    session
                        .args
                        .windows(2)
                        .any(|args| args == ["-p", "vendor task"])
                );
            }
            "claude" => {
                assert!(
                    session
                        .args
                        .windows(2)
                        .any(|args| args == ["--print", "vendor task"])
                );
            }
            "codex" => {
                assert!(
                    session
                        .args
                        .windows(2)
                        .any(|args| args == ["-m", "formal-ai"])
                );
                assert!(
                    session
                        .args
                        .windows(2)
                        .any(|args| args == ["--sandbox", "workspace-write"])
                );
                assert!(session.args.iter().any(|arg| arg == "--json"));
                assert!(!session.args.iter().any(|arg| arg == "read-only"));
            }
            "opencode" => {
                assert!(session.args.iter().any(|arg| arg == "--auto"));
                assert!(
                    session
                        .args
                        .windows(2)
                        .any(|args| args == ["--format", "json"])
                );
            }
            _ => unreachable!(),
        }
    }
}
