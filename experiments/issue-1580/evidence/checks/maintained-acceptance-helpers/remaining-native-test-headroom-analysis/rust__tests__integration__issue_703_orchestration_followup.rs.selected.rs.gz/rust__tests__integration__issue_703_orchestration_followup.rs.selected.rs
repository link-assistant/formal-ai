#[test]
fn real_formal_ai_correction_chain_resumes_one_native_session_and_pins_the_artifact() {
    let parent = replay_session(include_bytes!(
        "../../../docs/case-studies/issue-703/followup-authorship/controller-session.json"
    ))
    .expect("the committed parent session is canonical");
    let corrected = replay_session(include_bytes!(
        "../../../docs/case-studies/issue-703/followup-authorship/corrected-session.json"
    ))
    .expect("the first correction session is canonical");
    let final_session = replay_session(include_bytes!(
        "../../../docs/case-studies/issue-703/followup-authorship/final-session.json"
    ))
    .expect("the final correction session is canonical");

    assert!(parent.changes.is_empty(), "the first claim was disproved");
    for session in [&parent, &corrected, &final_session] {
        assert_eq!(
            session
                .native_session
                .as_ref()
                .map(|native| native.id.as_str()),
            Some(CONTINUATION_SESSION)
        );
    }
    let parent_sha256 = formal_ai::orchestration::session_sha256(&parent).unwrap();
    let corrected_sha256 = formal_ai::orchestration::session_sha256(&corrected).unwrap();
    assert_eq!(
        corrected
            .continuation
            .as_ref()
            .map(|continuation| continuation.parent_session_sha256.as_str()),
        Some(parent_sha256.as_str())
    );
    assert_eq!(
        final_session
            .continuation
            .as_ref()
            .map(|continuation| continuation.parent_session_sha256.as_str()),
        Some(corrected_sha256.as_str())
    );

    let resume_position = final_session
        .args
        .windows(2)
        .position(|args| args == ["--orchestration-resume", CONTINUATION_SESSION])
        .expect("the Formal AI wrapper receives the recorded Agent session");
    let prompt_position = final_session
        .args
        .iter()
        .position(|arg| arg == "agent")
        .expect("the controlled client is explicit");
    assert!(resume_position < prompt_position);
    assert!(
        final_session
            .stdout
            .contains(&format!("--resume {CONTINUATION_SESSION} --no-fork -p"))
    );
    assert_eq!(
        final_session
            .native_session
            .as_ref()
            .map(|native| native.resume_command.as_str()),
        Some("agent --resume ses_04e25ba4cffeibfMekv188DNLX --no-fork")
    );

    let artifact = include_bytes!("../../../data/meta/orchestration-continuation-invariant.lino");
    assert_eq!(
        artifact,
        b"orchestration_continuation resume_exact_native_id."
    );
    let change = final_session
        .changes
        .iter()
        .find(|change| change.path == "data/meta/orchestration-continuation-invariant.lino")
        .expect("the final correction records the self-authored artifact");
    assert_eq!(
        change.after_sha256.as_deref(),
        Some("1a94da829c1803f18ea2bf0b16f93ec30c5edc1fa1c02936afb2383b467ec439")
    );
}

#[test]
fn council_results_are_formalized_summarized_and_cross_checked() {
    let first_workspace = TestWorkspace::new("synthesis-first");
    let second_workspace = TestWorkspace::new("synthesis-second");
    let first = fixture_config_with_output(
        "codex",
        first_workspace.path(),
        "Rust is memory safe. The Moon is cheese.",
    );
    let second = fixture_config_with_output(
        "claude",
        second_workspace.path(),
        "Rust is memory safe. The Moon is not cheese.",
    );
    let sessions = [
        run_agent(&first).expect("first source"),
        run_agent(&second).expect("second source"),
    ];

    let mut report = synthesize_sessions(&sessions, "ru").expect("deterministic synthesis");

    assert_eq!(report.schema, "formal-ai-agent-synthesis-v1");
    assert_eq!(report.sources.len(), 2);
    assert!(
        report
            .sources
            .iter()
            .all(|source| source.meta_language.starts_with("formalization_candidate"))
    );
    assert!(
        report
            .claims
            .iter()
            .any(|claim| claim.text.contains("Rust is memory safe") && claim.presented)
    );
    // R703-9: a claim another agent denied is withheld, not presented as fact.
    assert!(
        report
            .claims
            .iter()
            .any(|claim| !claim.presented && !claim.denied_by.is_empty()),
        "{:?}",
        report.claims
    );
    assert_ne!(
        report.contradictions,
        [] as [formal_ai::orchestration::AgentSynthesisContradiction; 0]
    );
    assert_ne!(
        report.corrections,
        [] as [formal_ai::orchestration::CorrectionRequest; 0]
    );
    assert_eq!(report.fact_check_scope, "cross_agent_evidence_preflight");
    assert!(report.translation_required);

    let wrong_language = apply_verified_translation(
        &mut report,
        "Rust is memory safe.",
        "translator-session-sha256",
    )
    .expect_err("a translation in the wrong language must not be presented");
    assert_eq!(
        wrong_language.to_string(),
        "translation_language_mismatch:ru:en"
    );

    apply_verified_translation(
        &mut report,
        "Rust обеспечивает безопасность памяти.",
        "translator-session-sha256",
    )
    .expect("Russian translation");
    assert_eq!(report.final_language, "ru");
    assert!(!report.translation_required);
    assert!(
        report
            .translation
            .as_ref()
            .is_some_and(|translation| translation.session_sha256 == "translator-session-sha256")
    );
}
