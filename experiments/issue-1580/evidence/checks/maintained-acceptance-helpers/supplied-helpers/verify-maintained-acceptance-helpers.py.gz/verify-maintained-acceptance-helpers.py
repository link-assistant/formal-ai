from pathlib import Path
import hashlib,json,os,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/maintained-acceptance-helper-verification')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 assert result.returncode==0,(name,result.returncode)
 print(json.dumps({'check':name,'status':result.returncode}),flush=True)
try:
 test=root/'experiments/issue-1580/native-test-headroom.test.mjs';source=test.read_text()
 old='''      const wrapper = '#[test]\\nfn ' + name + '() {\\n    ' + child + '::' + name + '();\\n}';
      assert(source.includes(wrapper), 'the original named test must execute its assertion body');
      assert(helper.includes('pub(super) fn ' + name + '() {'));
      assert(!source.replace(wrapper, '').includes('fn ' + name + '() {'), 'the test must have one owner');'''
 new='''      const wrappers = [...source.matchAll(new RegExp('^#\\\\[test\\\\]\\\\nfn ' + name + '\\\\(\\\\) \\\\{\\\\n([\\\\s\\\\S]*?)^\\\\}', 'gmu'))];
      assert.equal(wrappers.length, 1, 'the test must have one original owner');
      assert.equal(wrappers[0][1].replace(/\\s/gu, ''), child + '::' + name + '();',
        'the original named test must execute exactly its assertion body');
      assert(helper.includes('pub(super) fn ' + name + '() {'));'''
 assert source.count(old)==1;test.write_text(source.replace(old,new,1))
 (out/'test-harness-correction.json').write_text(json.dumps({'reason':'rustfmt wraps one long zero-argument call across lines; compare the exact wrapper expression independent of whitespace','priorFailedLog':'maintained-acceptance-helper-extraction/regression-after.stdout','nativeCodeChanged':False},indent=2)+'\n')
 run('regression-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)])
 run('maintained-observations',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])
 run('source-warnings',['node','--max-old-space-size=256','scripts/check-file-size.mjs'])
 warnings=(out/'source-warnings.stdout').read_text().count('::warning file=');assert warnings==46,warnings
 prior=json.loads(Path('/tmp/issue-1580-research/maintained-acceptance-helper-extraction/extraction.json').read_text())
 files=[]
 for row in prior['files']:
  files.extend([row['owner'],row['child']])
  for kind,path in [('owner',row['owner']),('child',row['child'])]:
   text=(root/path).read_text();row[kind+'CurrentLines']=len(text.splitlines());row[kind+'CurrentSha256']=hashlib.sha256(text.encode()).hexdigest()
   assert len(text.splitlines())<=900
 (out/'post-format-extraction.json').write_text(json.dumps(prior,indent=2)+'\n')
 run('rustfmt-check',['rustfmt','--check','--edition','2024',*files])
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'warnings':warnings,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
