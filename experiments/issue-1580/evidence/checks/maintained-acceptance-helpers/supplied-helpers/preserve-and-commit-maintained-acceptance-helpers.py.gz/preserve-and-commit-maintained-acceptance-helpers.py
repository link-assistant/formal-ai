from pathlib import Path
from datetime import datetime,timezone
import hashlib,gzip,json,os,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'maintained-acceptance-helper-preservation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 assert result.returncode==0,(name,result.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 verified=json.loads((scratch/'maintained-acceptance-helper-verification/outcome.json').read_text());assert verified['complete'] and verified['warnings']==46
 rows=json.loads((scratch/'maintained-acceptance-helper-verification/post-format-extraction.json').read_text())['files']
 target=root/'experiments/issue-1580/evidence/checks/maintained-acceptance-helpers';target.mkdir(exist_ok=False);records=[]
 def archive(source,relative):
  raw=source.read_bytes();packed=gzip.compress(raw,mtime=0);dest=target/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed)
  records.append({'file':relative,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
 for name in ['remaining-native-test-headroom-analysis','maintained-acceptance-helper-selection','maintained-acceptance-helper-extraction','maintained-acceptance-helper-verification']:
  for source in sorted((scratch/name).rglob('*')):
   if source.is_file() and source.name not in ['pid.json']:archive(source,name+'/'+str(source.relative_to(scratch/name))+'.gz')
 helpers=['inspect-remaining-native-test-headroom.py','select-maintained-acceptance-helpers.py','extract-maintained-acceptance-helpers.py','verify-maintained-acceptance-helpers.py','inspect-focused-native-owner-dependencies.py',Path(__file__).name]
 for name in helpers:
  archive(scratch/name,'supplied-helpers/'+name+'.gz')
 for source in sorted((root/'experiments/issue-1580/evidence/commands').glob('*.json')):
  if source.name[:19]<'2026-11-21T16-47-00':continue
  data=json.loads(source.read_text())
  if any(name in data['request'] for name in helpers):archive(source,'formal-sessions/'+source.name+'.gz')
 (target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
 body_count=sum(len(row['names']) for row in rows);native_count=sum(row['nativeTestCount'] for row in rows)
 (target/'identity.json').write_text(json.dumps({'sourceHeadBeforeCommit':run('source-head',['git','rev-parse','HEAD']).strip(),'owners':len(rows),'conservedAssertionBodies':body_count,'nativeTestsRetained':native_count,'maintainedObservationsPassed':217,'sourceWarnings':46,'archives':len(records),'nativeExecutionVerified':False,'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
 doc=root/'docs/case-studies/issue-1580/maintained-acceptance-helpers-checkpoint.md'
 doc.write_text('# Maintained native acceptance helpers\n\nNine maintained Rust test owners exceeded the unchanged 900-line warning\nthreshold. Sixteen complete assertion bodies now live in smaller helper\nmodules. Every original test name, attribute and wrapper remains in its\noriginal owner. The extraction records prove an exact inverse before\nformatting; all eighteen Rust files pass Rust 2024 formatting checks.\nPlatform-specific and relative-include bodies were left in their original\nlocations. No native compilation or native execution is claimed locally.\n\nThe new regression fails on all nine original warning owners and passes\nafter extraction. An intermediate check incorrectly required rustfmt to\nkeep a long call on one line; that failure and its whitespace-independent\ncorrection are retained. All 217 maintained issue observations pass. The\nunchanged-limit source scanner reports 46 warnings and zero violations.\n\nEvidence: `experiments/issue-1580/evidence/checks/maintained-acceptance-helpers/`.\nEvery compressed stream retains raw and archive hashes, byte counts and\nline counts. Supplied procedures receive zero independent authorship credit.\n\nCurrent-head hosted validation and the governed source-witness repair are\nseparate work. All eight complete template/practice comparisons, remaining\nwarnings and wider issue acceptance remain unfinished. PR #1581 stays draft\nand unmerged: https://github.com/link-assistant/formal-ai/pull/1581.\n')
 fragment=root/'changelog.d/20261121_1580_maintained_acceptance_helpers.md'
 fragment.write_text('### Fixed\n\n- Keep nine native acceptance modules below the unchanged source-size warning threshold while retaining every original test name and assertion body.\n')
 paths=[item for row in rows for item in [row['owner'],row['child']]]+['experiments/issue-1580/native-test-headroom.test.mjs',str(target.relative_to(root)),str(doc.relative_to(root)),str(fragment.relative_to(root))]
 assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
 assert run('preexisting-staged',['git','diff','--cached','--name-only']).strip()==''
 run('stage',['git','add','--',*paths]);run('staged-whitespace',['git','diff','--cached','--check']);run('staged-secret-scan',['bash','scripts/check-secrets.sh'])
 for row in records:
  packed=(target/row['file']).read_bytes();raw=gzip.decompress(packed)
  assert hashlib.sha256(packed).hexdigest()==row['archiveSha256'] and hashlib.sha256(raw).hexdigest()==row['rawSha256']
  assert len(raw)==row['bytes'] and len(raw.splitlines())==row['lines']
 run('commit',['git','commit','-m','Preserve native test identities while reducing nine size warnings'])
 head=run('committed-head',['git','rev-parse','HEAD']).strip()
 (out/'outcome.json').write_text(json.dumps({'committed':True,'head':head,'archives':len(records),'warnings':46,'pushed':False,'nativeExecutionVerified':False,'fullIssueComplete':False},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
