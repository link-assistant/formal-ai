from pathlib import Path
import json,re
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/remaining-native-test-headroom-analysis');out.mkdir(exist_ok=False)
warnings=(Path('/tmp/issue-1580-research/complete-local-repair-replay/source-warnings.stdout')).read_text()
paths=re.findall(r'^::warning file=(rust/tests/[^:]+\.rs)::',warnings,re.M)
rows=[]
for name in paths:
 source=(root/name).read_text();lines=len(source.splitlines());candidates=[]
 for match in re.finditer(r'^#\[test\]\nfn ([a-zA-Z0-9_]+)\(\) \{\n',source,re.M):
  stop=source.find('\n}\n',match.end())
  if stop<0:continue
  body=source[match.start():stop+3]
  if re.search(r'^#\[test\]',body[match.end()-match.start():],re.M):continue
  count=len(body.splitlines());candidates.append({'name':match[1],'lines':count,'start':match.start(),'end':stop+3,'body':body})
 selected=[];remaining=lines+3
 for candidate in sorted(candidates,key=lambda item:item['lines'],reverse=True):
  if remaining<=895:break
  if candidate['lines']<=4:continue
  selected.append(candidate);remaining-=candidate['lines']-4
 child=2+sum(item['lines']-1 for item in selected)+max(0,len(selected)-1)
 rows.append({'owner':name,'beforeLines':lines,'candidateParentLines':remaining,'candidateChildLines':child,'feasible':remaining<=900 and child<=900,'candidates':[{'name':item['name'],'lines':item['lines']} for item in selected]})
 if selected:(out/(name.replace('/','__')+'.selected.rs')).write_text('\n'.join(item['body'] for item in selected))
(out/'analysis.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
