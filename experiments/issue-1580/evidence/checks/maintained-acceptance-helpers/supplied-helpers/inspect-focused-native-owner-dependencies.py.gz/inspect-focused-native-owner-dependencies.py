from pathlib import Path
import json,re
root=Path('/tmp/gh-issue-solver-1794900398048')
paths=[x['owner'] for x in json.loads(Path('/tmp/issue-1580-research/maintained-acceptance-helper-extraction/extraction.json').read_text())['files']]
paths += [x['owner'] for x in json.loads(Path('/tmp/issue-1580-research/native-acceptance-headroom/extraction.json').read_text())['files']]
for name in paths:
 source=(root/name).read_text();lines=source.splitlines()
 print('\nFILE '+name+'\n'+'\n'.join(lines[:65]))
 matches=[(i+1,line) for i,line in enumerate(lines) if re.search(r'\bsuper::|\bcrate::|^mod |^pub mod |^#\[path|^#\[cfg',line)]
 print('DEPENDENCY REFERENCES\n'+'\n'.join(str(i)+': '+line[:240] for i,line in matches))
