from pathlib import Path
import json,re,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/maintained-acceptance-helper-selection');out.mkdir(exist_ok=True)
rows=json.loads(Path('/tmp/issue-1580-research/remaining-native-test-headroom-analysis/analysis.json').read_text())
records=[]
for row in rows:
 if not row['feasible']:continue
 source=(root/row['owner']).read_text();candidates=[]
 for match in re.finditer(r'^#\[test\]\nfn ([a-zA-Z0-9_]+)\(\) \{\n',source,re.M):
  stop=source.find('\n}\n',match.end())
  if stop<0:continue
  text=source[match.start():stop+3]
  if re.search(r'^#\[test\]',text[match.end()-match.start():],re.M):continue
  previous=source[:match.start()].rstrip().splitlines()[-1:]
  excluded=bool(re.search(r'include_(?:bytes|str)!|\b(?:file|line|column|module_path)!|\bsuper::',text) or (previous and previous[0].startswith('#[')))
  candidates.append({'name':match[1],'lines':len(text.splitlines()),'start':match.start(),'end':stop+3,'excluded':excluded,'previous':previous})
 needed=len(source.splitlines())+3-890
 safe=[x for x in candidates if not x['excluded'] and x['lines']>4]
 safe.sort(key=lambda x:x['lines'],reverse=True)
 # Prefer the smallest single body that supplies the complete headroom.
 singles=[x for x in safe if x['lines']-4>=needed]
 selected=[min(singles,key=lambda x:x['lines'])] if singles else []
 if not selected:
  gain=0
  for item in safe:
   selected.append(item);gain+=item['lines']-4
   if gain>=needed:break
 record={'owner':row['owner'],'beforeLines':len(source.splitlines()),'sourceSha256':hashlib.sha256(source.encode()).hexdigest(),'selected':selected,'parentLinesEstimate':len(source.splitlines())+3-sum(x['lines']-4 for x in selected),'candidates':candidates}
 records.append(record)
 (out/(row['owner'].replace('/','__')+'.selected.rs')).write_text('\n'.join(source[x['start']:x['end']] for x in selected))
(out/'selection.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps([{k:v for k,v in x.items() if k!='candidates'} for x in records],indent=2))
