from pathlib import Path
import hashlib,json,os,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/maintained-acceptance-helper-extraction')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 assert result.returncode in allowed,(name,result.returncode)
 print(json.dumps({'check':name,'status':result.returncode}),flush=True)
 return result.returncode
def sha(text):return hashlib.sha256(text.encode()).hexdigest()
try:
 selections=json.loads(Path('/tmp/issue-1580-research/maintained-acceptance-helper-selection/selection.json').read_text())
 children=['client_contracts','council_corrections','directory_prompts','storage_access','textual_requests','algorithm_answers','relation_schema','claim_table','edit_contracts']
 assert len(selections)==len(children)==9
 groups=[[x['owner'][:-3],child,[item['name'] for item in x['selected']]] for x,child in zip(selections,children)]
 test=root/'experiments/issue-1580/native-test-headroom.test.mjs'
 original_test=test.read_text();assert 'council_corrections' not in original_test
 addition='\nfor (const [owner, child, names] of '+json.dumps(groups,ensure_ascii=False,indent=2)+''') {
  test(owner + ' retains its native test inventory below the size warning', () => {
    assert.deepEqual(checkListedFiles(root, new Set([owner + '.rs', owner + '/' + child + '.rs'])),
      {warnings: [], violations: [], embeddedDataViolations: []});
    const source = readFileSync(root + '/' + owner + '.rs', 'utf8');
    const file = explicitHelperPath(owner, child, source);
    const helper = readFileSync(file, 'utf8');
    assert(!helper.includes('#[test]'), 'native test identities must remain in the original module');
    for (const name of names) {
      const wrapper = '#[test]\\nfn ' + name + '() {\\n    ' + child + '::' + name + '();\\n}';
      assert(source.includes(wrapper), 'the original named test must execute its assertion body');
      assert(helper.includes('pub(super) fn ' + name + '() {'));
      assert(!source.replace(wrapper, '').includes('fn ' + name + '() {'), 'the test must have one owner');
    }
    const declaration = '#[path = "' + owner.split('/').at(-1) + '/' + child + '.rs"]\\n';
    assert.throws(() => explicitHelperPath(owner, child, source.replace(declaration, '')),
      /must explicitly locate/u, 'losing the real child resolution must be detected');
  });
}
'''
 test.write_text(original_test+addition)
 before=run('regression-before',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)],(1,))
 rows=[];files=[]
 for selected,child in zip(selections,children):
  owner=selected['owner'];path=root/owner;source=path.read_text()
  assert sha(source)==selected['sourceSha256']
  baseline=subprocess.check_output(['git','show','HEAD:'+owner],cwd=root,text=True);assert source==baseline
  saved=out/'preimages'/owner;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_text(source)
  declaration='\n#[path = "'+Path(owner).stem+'/'+child+'.rs"]\nmod '+child+';\n'
  modified=source;chunks=[];inverses=[]
  for item in selected['selected']:
   original=source[item['start']:item['end']];name=item['name'];header='#[test]\nfn '+name+'() {\n'
   assert original.startswith(header) and original.endswith('\n}\n') and modified.count(original)==1
   assert not item['excluded']
   wrapper='#[test]\nfn '+name+'() {\n    '+child+'::'+name+'();\n}\n'
   moved=original.replace('#[test]\nfn ','pub(super) fn ',1)
   modified=modified.replace(original,wrapper,1);chunks.append(moved);inverses.append((original,wrapper,moved))
  modified+=declaration;inverse=modified[:-len(declaration)]
  for original,wrapper,moved in inverses:
   assert moved.replace('pub(super) fn ','#[test]\nfn ',1)==original
   inverse=inverse.replace(wrapper,original,1)
  assert inverse==source
  tests=lambda text:re.findall(r'^#\[test\]\nfn ([a-zA-Z0-9_]+)\(',text,re.M)
  assert tests(source)==tests(modified)
  target=root/owner[:-3]/(child+'.rs');target.parent.mkdir(exist_ok=True);assert not target.exists()
  helper='use super::*;\n\n'+'\n'.join(chunks)
  assert '#[test]' not in helper
  assert len(modified.splitlines())<=900 and len(helper.splitlines())<=900
  path.write_text(modified);target.write_text(helper)
  rows.append({'owner':owner,'child':str(target.relative_to(root)),'names':[x['name'] for x in selected['selected']],
   'beforeSha256':sha(source),'beforeLines':len(source.splitlines()),'afterLines':len(modified.splitlines()),'childLines':len(helper.splitlines()),
   'exactInverseBeforeFormatting':True,'nativeTestNamesUnchanged':True,'nativeTestCount':len(tests(source)),'nativeExecutionVerified':False})
  files.extend([owner,str(target.relative_to(root))])
 (out/'extraction.json').write_text(json.dumps({'files':rows,'regressionBefore':before,'independentAuthorshipCredit':0},indent=2)+'\n')
 run('rustfmt',['rustfmt','--edition','2024',*files]);run('rustfmt-check',['rustfmt','--check','--edition','2024',*files])
 run('regression-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)])
 run('maintained-observations',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])
 run('source-warnings',['node','--max-old-space-size=256','scripts/check-file-size.mjs'])
 warnings=(out/'source-warnings.stdout').read_text().count('::warning file=');assert warnings==46,warnings
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'warnings':warnings,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
