from pathlib import Path
import subprocess,json,datetime
r=Path('/tmp/issue-1580-research/file-size-literal-growth');records=[]
gates=['check-file-size','check-file-size-js-twin','check-readable-code','check-required-documentation','check-tests-as-docs','check-tests-as-documentation-javascript-twin','check-changelog-fragment-js-twin','release#1','check-closure-audit','check-generated-files','layered-ci#1']
for gate in gates:
 command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]
 with (r/('gate-'+gate+'.log')).open('w') as stream:result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
 row={'gate':gate,'command':command,'exitCode':result.returncode};records.append(row);print(json.dumps(row),flush=True)
(r/'gates-result.json').write_text(json.dumps({'records':records,'complete':True,'allPassed':all(row['exitCode']==0 for row in records),'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+chr(10))
