from pathlib import Path
import subprocess,json,datetime
r=Path('/tmp/issue-1580-research/file-size-literal-growth');records=[]
commands=[('focused',['node','--test','--test-concurrency=1','experiments/issue-1580/file-size-literal-growth.test.mjs']),('maintained-twins',['node','--test','--test-concurrency=1','rust/tests/web/scripts-js-twins-checks.test.mjs']),('rust-format',['rustfmt','--edition','2024','--check','scripts/check-file-size.rs','scripts/check-file-size/tests.rs']),('whitespace',['git','diff','--check'])]
for label,command in commands:
 with (r/(label+'.log')).open('w') as out:result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 row={'label':label,'command':command,'exitCode':result.returncode};records.append(row);print(json.dumps(row),flush=True)
(r/'focused-result.json').write_text(json.dumps({'records':records,'complete':True,'allPassed':all(row['exitCode']==0 for row in records),'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+chr(10))
