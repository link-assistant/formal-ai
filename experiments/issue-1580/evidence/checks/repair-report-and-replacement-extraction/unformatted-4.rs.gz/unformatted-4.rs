//! General text manipulation through composed substitution rules.

mod replacement;

use replacement::replace_text;

use std::collections::BTreeSet;
use std::fmt::Write as _;

use crate::engine::{SymbolicAnswer, stable_id};
use crate::event_log::EventLog;
use crate::links_format::push_lino_node;
use crate::normal_markov::{QuotedSegment, quoted_segment_spans, quoted_segments};
use crate::rule_interpreter::handler_table_rows;
use crate::solver::{ConversationRole, ConversationTurn};
use crate::solver_handlers::finalize_simple;
use crate::solver_handlers::text_edit_ops::{
    camel_case, comment_lines, count_unique_words, count_words, deduplicate_lines, delimiter_case,
    extract_email_addresses, extract_numbers, extract_urls, join_lines,
    number_lines, outdent_line, pascal_case, remove_punctuation, reverse_lines, sentence_case,
    sort_words, strip_empty_lines, title_case, uncomment_lines,
};
use crate::solver_handlers::text_request_framing::{phrase_argument, request_framing};
use crate::substitution::{
    CrudEvent, SubstitutionGraph, SubstitutionRuleSet, SubstitutionTraceReport,
};

// The cue tables of `data/seed/handler-rules.lino` and the row values that
// say how a cue is read (see `text_cue_matches`).
const REPLACEMENT_CUE_TABLE: &str = "text_replacement_cue";
const INPUT_CONTEXT_CUE_TABLE: &str = "text_input_context_cue";
const INPUT_CONTINUATION_CUE_TABLE: &str = "text_input_continuation_cue";
const SUFFIX_READING: &str = "ends_with";
const OPERANDS_IN_ORDER: &str = "operands_in_order";
const TARGET_FOLLOWS_CUE: &str = "target_follows_cue";

/// Does `prompt` name a replacement over quoted literals — the shape
/// [`parse_replace_request`] reads?
///
/// Issue #906: the operands of such a request are *content*. "Replace
/// \"Hello World\" with \"Bye world\"" quotes the words to edit, and the
/// program-task alias table matches "hello world" inside that quote, which is
/// how a text edit came to be routed as a request to write a program. The
/// routing check in `crate::intent_formalization` asks this before it reads a
/// task out of a request that never asked for a program.
#[must_use]
pub fn names_a_quoted_replacement(prompt: &str) -> bool {
    quoted_segment_spans(prompt).len() >= 2 && contains_replacement_keyword(prompt)
}

/// `prompt` with every quoted literal blanked out, leaving only the prose that
/// frames them.
///
/// Issue #906: this is how a caller asks whether a request names something
/// *itself* rather than merely quoting it. "Write hello world in JavaScript and
/// replace `Hello World` with `Bye JS`" still says "hello world" once the
/// quotes are gone, so it really does request that program; "заменил \"Hello
/// World\" на \"Bye world\"" says nothing of the sort.
#[must_use]
pub fn text_outside_quoted_segments(prompt: &str) -> String {
    let mut outside = String::with_capacity(prompt.len());
    let mut cursor = 0usize;
    for segment in quoted_segment_spans(prompt) {
        if segment.start < cursor {
            continue;
        }
        outside.push_str(&prompt[cursor..segment.start]);
        outside.push(' ');
        cursor = segment.end;
    }
    outside.push_str(&prompt[cursor..]);
    outside
}

/// Does the prose around the quoted literals name a format conversion?
///
/// "Convert this JSON to YAML: {...}" reads its payload as data: an
/// operation word inside it is a key, not a request. A cue inside a quote
/// ("Uppercase: 'json to yaml'") is content and names nothing.
pub(super) fn names_format_conversion(prompt: &str) -> bool {
    let frame = text_outside_quoted_segments(prompt).to_lowercase();
    super::shell_command_compose::any_cue_matches("format_conversion", &frame, &frame)
}

pub fn try_text_manipulation(
    prompt: &str,
    normalized: &str,
    log: &mut EventLog,
) -> Option<SymbolicAnswer> {
    try_text_manipulation_with_history(prompt, normalized, log, &[])
}

/// Whether the text-manipulation handler owns this prompt. The capability
/// table and its compose arm ask before claiming a turn, so an edit request
/// the handler recognizes is answered as the edit it is instead of reporting
/// a source or write capability gap (issue #1138: the text-operation family).
#[must_use]
pub fn names_text_operation(normalized: &str) -> bool {
    let mut log = EventLog::new();
    try_text_manipulation(normalized, normalized, &mut log).is_some()
}

/// Whether the request parses as input text and text operations.
///
/// The input may come from the earlier reply; the `text_operation` claim
/// evidence of issue #1175 R3.
#[must_use]
pub fn parses_text_operation(prompt: &str, normalized: &str, history: &[ConversationTurn]) -> bool {
    TextRequest::parse_with_history(prompt, normalized, history).is_some()
}

pub fn try_text_manipulation_with_history(
    prompt: &str,
    normalized: &str,
    log: &mut EventLog,
    history: &[ConversationTurn],
) -> Option<SymbolicAnswer> {
    if crate::solver_helpers::is_agent_request(normalized) {
        return None;
    }
    if names_format_conversion(prompt) {
        return None;
    }

    let request = TextRequest::parse_with_history(prompt, normalized, history)?;
    let chain = SubstitutionTextChain::build(&request.input, &request.operations)?;

    log.append(
        "text_input",
        format!(
            "bytes={} chars={}",
            request.input.len(),
            request.input.chars().count()
        ),
    );
    for step in &chain.steps {
        log.append("text_operation", step.operation.slug().to_owned());
        log.append("text_rule", step.rule_id.clone());
    }
    log.append(
        "text_rule_chain",
        chain
            .steps
            .iter()
            .map(|step| step.rule_id.as_str())
            .collect::<Vec<_>>()
            .join(">"),
    );
    log.append("text_substitution_rules", chain.rules.links_notation());
    log.append("text_substitution_trace", chain.report.links_notation());
    log.append("text_substitution_graph", chain.graph.links_notation());
    log.append("text_result", chain.result.clone());

    Some(finalize_simple(
        prompt,
        log,
        "text_manipulation",
        "response:text_manipulation",
        &chain.result,
        1.0,
    ))
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct TextRequest {
    input: String,
    operations: Vec<TextOperation>,
}

impl TextRequest {
    fn parse_with_history(
        prompt: &str,
        normalized: &str,
        history: &[ConversationTurn],
    ) -> Option<Self> {
        let vocabulary = crate::seed::operation_vocabulary();
        let quoted = quoted_segments(prompt);
        let spans = quoted_segment_spans(prompt);
        // The request's own words: its quoted payload is content, so a payload
        // word ("раз") never names an operation asked of the framing.
        let framing = request_framing(prompt, &spans);
        let fallback_input = || last_assistant_text_artifact(history);

        if contains_replacement_keyword(normalized) && quoted.len() >= 2 {
            let (input, from, to) = parse_replace_request(prompt, history)?;
            return Self::build(input, vec![TextOperation::Replace { from, to }]);
        }

        if vocabulary.matches("count_occurrences", &framing) && !quoted.is_empty() {
            let needle = quoted[0].clone();
            let input = quoted
                .get(1)
                .cloned()
                .or_else(|| text_after_colon(prompt))
                .or_else(fallback_input)?;
            return Self::build(input, vec![TextOperation::CountOccurrences { needle }]);
        }

        if vocabulary.matches("remove_text", normalized)
            && !matches_specific_remove_operation(&vocabulary, normalized)
            && !quoted.is_empty()
        {
            let (input, needle) = parse_remove_request(prompt, history)?;
            return Self::build(input, vec![TextOperation::RemoveText { needle }]);
        }

        if vocabulary.matches("append_text", normalized) && !quoted.is_empty() {
            let (input, suffix) = parse_affix_request(prompt, history)?;
            return Self::build(input, vec![TextOperation::AppendText { suffix }]);
        }

        if vocabulary.matches("prepend_text", normalized) && !quoted.is_empty() {
            let (input, prefix) = parse_affix_request(prompt, history)?;
            return Self::build(input, vec![TextOperation::PrependText { prefix }]);
        }

        // An operation phrase may carry its own argument ("lines that start
        // with x"); when that argument is quoted, the payload is the other
        // quoted segment.
        let line_prefix = phrase_argument(&vocabulary, "filter_lines_by_prefix", prompt, &spans);
        let argument_index = line_prefix.as_ref().and_then(|argument| argument.quoted);
        let input = spans
            .iter()
            .enumerate()
            .find(|(index, _)| Some(*index) != argument_index)
            .map(|(_, segment)| segment.text.clone())
            .or_else(|| text_after_colon(prompt))
            .or_else(fallback_input)?;
        let mut operations = Vec::new();
        if let Some(argument) = line_prefix {
            operations.push(TextOperation::FilterLinesByPrefix {
                prefix: argument.text,
            });
        }
        append_simple_operations(&vocabulary, normalized, &framing, &mut operations);
        Self::build(input, operations)
    }

    fn build(input: String, operations: Vec<TextOperation>) -> Option<Self> {
        if operations.is_empty() || input.is_empty() {
            return None;
        }
        Some(Self { input, operations })
    }
}

fn matches_specific_remove_operation(
    vocabulary: &crate::seed::OperationVocabulary,
    normalized: &str,
) -> bool {
    vocabulary.matches("remove_punctuation", normalized)
        || vocabulary.matches("strip_empty_lines", normalized)
}

fn append_simple_operations(
    vocabulary: &crate::seed::OperationVocabulary,
    normalized: &str,
    framing: &str,
    operations: &mut Vec<TextOperation>,
) {
    // A count is named outright ("count words") or asked of the request's own
    // framing: a seeded counting cue plus the unit noun ("how many words").
    let counts = |canonical: &str| {
        vocabulary.matches(canonical, normalized) || vocabulary.asks_count_of(canonical, framing)
    };
    if vocabulary.matches("lowercase", normalized) {
        operations.push(TextOperation::Lowercase);
    } else if vocabulary.matches("uppercase", normalized) {
        operations.push(TextOperation::Uppercase);
    }

    if vocabulary.matches("reverse_words", normalized) {
        operations.push(TextOperation::ReverseWords);
    }
    if vocabulary.matches("extract_email", normalized) {
        operations.push(TextOperation::ExtractEmails);
    }
    if vocabulary.matches("extract_url", normalized) {
        operations.push(TextOperation::ExtractUrls);
    }
    if vocabulary.matches("extract_number", normalized) {
        operations.push(TextOperation::ExtractNumbers);
    }
    if vocabulary.matches("deduplicate_lines", normalized) {
        operations.push(TextOperation::DeduplicateLines);
    }
    if vocabulary.matches("sort_lines", normalized) {
        operations.push(TextOperation::SortLines);
    }
    if vocabulary.matches("sort_words", normalized) {
        operations.push(TextOperation::SortWords);
    }
    if vocabulary.matches("trim_whitespace", normalized) {
        operations.push(TextOperation::TrimWhitespace);
    }
    if vocabulary.matches("normalize_whitespace", normalized) {
        operations.push(TextOperation::NormalizeWhitespace);
    }
    if vocabulary.matches("title_case", normalized) {
        operations.push(TextOperation::TitleCase);
    }
    if vocabulary.matches("sentence_case", normalized) {
        operations.push(TextOperation::SentenceCase);
    }
    if vocabulary.matches("snake_case", normalized) {
        operations.push(TextOperation::SnakeCase);
    }
    if vocabulary.matches("kebab_case", normalized) {
        operations.push(TextOperation::KebabCase);
    }
    if vocabulary.matches("camel_case", normalized) {
        operations.push(TextOperation::CamelCase);
    }
    if vocabulary.matches("pascal_case", normalized) {
        operations.push(TextOperation::PascalCase);
    }
    if vocabulary.matches("strip_empty_lines", normalized) {
        operations.push(TextOperation::StripEmptyLines);
    }
    if vocabulary.matches("join_lines", normalized) {
        operations.push(TextOperation::JoinLines);
    }
    if vocabulary.matches("reverse_lines", normalized) {
        operations.push(TextOperation::ReverseLines);
    }
    if vocabulary.matches("number_lines", normalized) {
        operations.push(TextOperation::NumberLines);
    }
    if vocabulary.matches("indent_lines", normalized) {
        operations.push(TextOperation::IndentLines);
    }
    if vocabulary.matches("outdent_lines", normalized) {
        operations.push(TextOperation::OutdentLines);
    }
    if vocabulary.matches("uncomment_lines", normalized) {
        operations.push(TextOperation::UncommentLines);
    } else if vocabulary.matches("comment_lines", normalized) {
        operations.push(TextOperation::CommentLines);
    }
    if vocabulary.matches("remove_punctuation", normalized) {
        operations.push(TextOperation::RemovePunctuation);
    }
    if counts("count_unique_words") {
        operations.push(TextOperation::CountUniqueWords);
    } else if counts("count_words") {
        operations.push(TextOperation::CountWords);
    }
    if counts("count_lines") {
        operations.push(TextOperation::CountLines);
    }
    // A seeded character class ("vowels") counted names its members.
    if let Some(members) = vocabulary.counted_character_class(framing) {
        operations.push(TextOperation::CountCharacterClass { members });
    } else if counts("count_characters") {
        operations.push(TextOperation::CountCharacters);
    }
    // The chain runs in the order the request names its steps ("sort the words
    // and reverse them" sorts first); a count reduces the text to a number, so
    // it ends the chain wherever it is named.
    operations.sort_by_key(|operation| {
        (
            operation.yields_count(),
            vocabulary.position(operation.slug(), normalized),
        )
    });
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum TextOperation {
    Uppercase,
    Lowercase,
    Replace { from: String, to: String },
    RemoveText { needle: String },
    AppendText { suffix: String },
    PrependText { prefix: String },
    ReverseWords,
    ExtractEmails,
    ExtractUrls,
    ExtractNumbers,
    CountOccurrences { needle: String },
    CountUniqueWords,
    CountWords,
    CountLines,
    CountCharacters,
    CountCharacterClass { members: String },
    FilterLinesByPrefix { prefix: String },
    DeduplicateLines,
    SortLines,
    SortWords,
    TrimWhitespace,
    NormalizeWhitespace,
    TitleCase,
    SentenceCase,
    SnakeCase,
    KebabCase,
    CamelCase,
    PascalCase,
    RemovePunctuation,
    StripEmptyLines,
    JoinLines,
    ReverseLines,
    NumberLines,
    IndentLines,
    OutdentLines,
    CommentLines,
    UncommentLines,
}

impl TextOperation {
    const fn yields_count(&self) -> bool {
        matches!(
            self,
            Self::CountOccurrences { .. }
                | Self::CountUniqueWords
                | Self::CountWords
                | Self::CountLines
                | Self::CountCharacters
                | Self::CountCharacterClass { .. }
        )
    }

    const fn slug(&self) -> &'static str {
        match self {
            Self::Uppercase => "uppercase",
            Self::Lowercase => "lowercase",
            Self::Replace { .. } => "replace_text",
            Self::RemoveText { .. } => "remove_text",
            Self::AppendText { .. } => "append_text",
            Self::PrependText { .. } => "prepend_text",
            Self::ReverseWords => "reverse_words",
            Self::ExtractEmails => "extract_email",
            Self::ExtractUrls => "extract_url",
            Self::ExtractNumbers => "extract_number",
            Self::CountOccurrences { .. } => "count_occurrences",
            Self::CountUniqueWords => "count_unique_words",
            Self::CountWords => "count_words",
            Self::CountLines => "count_lines",
            Self::CountCharacters => "count_characters",
            Self::CountCharacterClass { .. } => "count_character_class",
            Self::FilterLinesByPrefix { .. } => "filter_lines_by_prefix",
            Self::DeduplicateLines => "deduplicate_lines",
            Self::SortLines => "sort_lines",
            Self::SortWords => "sort_words",
            Self::TrimWhitespace => "trim_whitespace",
            Self::NormalizeWhitespace => "normalize_whitespace",
            Self::TitleCase => "title_case",
            Self::SentenceCase => "sentence_case",
            Self::SnakeCase => "snake_case",
            Self::KebabCase => "kebab_case",
            Self::CamelCase => "camel_case",
            Self::PascalCase => "pascal_case",
            Self::RemovePunctuation => "remove_punctuation",
            Self::StripEmptyLines => "strip_empty_lines",
            Self::JoinLines => "join_lines",
            Self::ReverseLines => "reverse_lines",
            Self::NumberLines => "number_lines",
            Self::IndentLines => "indent_lines",
            Self::OutdentLines => "outdent_lines",
            Self::CommentLines => "comment_lines",
            Self::UncommentLines => "uncomment_lines",
        }
    }

    fn apply(&self, input: &str) -> String {
        match self {
            Self::Uppercase => input.chars().flat_map(char::to_uppercase).collect(),
            Self::Lowercase => input.chars().flat_map(char::to_lowercase).collect(),
            Self::Replace { from, to } => replace_text(input, from, to),
            Self::RemoveText { needle } => replace_text(input, needle, ""),
            Self::AppendText { suffix } => format!("{input}{suffix}"),
            Self::PrependText { prefix } => format!("{prefix}{input}"),
            Self::ReverseWords => input.split_whitespace().rev().collect::<Vec<_>>().join(" "),
            Self::ExtractEmails => extract_email_addresses(input).join("\n"),
            Self::ExtractUrls => extract_urls(input).join("\n"),
            Self::ExtractNumbers => extract_numbers(input).join("\n"),
            Self::CountOccurrences { needle } => {
                if needle.is_empty() {
                    String::from("0")
                } else {
                    input.matches(needle).count().to_string()
                }
            }
            Self::CountUniqueWords => count_unique_words(input).to_string(),
            Self::CountWords => count_words(input).to_string(),
            Self::CountLines => input.lines().count().to_string(),
            Self::CountCharacters => input.chars().count().to_string(),
            Self::CountCharacterClass { members } => input
                .chars()
                .filter(|character| {
                    character
                        .to_lowercase()
                        .all(|lower| members.contains(lower))
                })
                .count()
                .to_string(),
            Self::FilterLinesByPrefix { prefix } => input
                .lines()
                .filter(|line| line.starts_with(prefix.as_str()))
                .collect::<Vec<_>>()
                .join("\n"),
            Self::DeduplicateLines => deduplicate_lines(input).join("\n"),
            Self::SortLines => {
                let mut lines = input.lines().map(str::to_owned).collect::<Vec<_>>();
                lines.sort();
                lines.join("\n")
            }
            Self::SortWords => sort_words(input),
            Self::TrimWhitespace => input.trim().to_owned(),
            Self::NormalizeWhitespace => input.split_whitespace().collect::<Vec<_>>().join(" "),
            Self::TitleCase => title_case(input),
            Self::SentenceCase => sentence_case(input),
            Self::SnakeCase => delimiter_case(input, "_"),
            Self::KebabCase => delimiter_case(input, "-"),
            Self::CamelCase => camel_case(input),
            Self::PascalCase => pascal_case(input),
            Self::RemovePunctuation => remove_punctuation(input),
            Self::StripEmptyLines => strip_empty_lines(input).join("\n"),
            Self::JoinLines => join_lines(input),
            Self::ReverseLines => reverse_lines(input),
            Self::NumberLines => number_lines(input).join("\n"),
            Self::IndentLines => input
                .lines()
                .map(|line| format!("    {line}"))
                .collect::<Vec<_>>()
                .join("\n"),
            Self::OutdentLines => input
                .lines()
                .map(outdent_line)
                .collect::<Vec<_>>()
                .join("\n"),
            Self::CommentLines => comment_lines(input),
            Self::UncommentLines => uncomment_lines(input),
        }
    }
}

fn last_assistant_text_artifact(history: &[ConversationTurn]) -> Option<String> {
    history
        .iter()
        .rev()
        .find(|turn| turn.role == ConversationRole::Assistant && !turn.content.trim().is_empty())
        .map(|turn| turn.content.clone())
}

fn parse_replace_request(
    prompt: &str,
    history: &[ConversationTurn],
) -> Option<(String, String, String)> {
    let quoted = quoted_segment_spans(prompt);
    if quoted.len() < 2 {
        return None;
    }

    if quoted.len() >= 3 && looks_like_input_first_replacement(prompt, &quoted) {
        let (from, to) = replacement_operands(prompt, &quoted[1], &quoted[2]);
        return Some((quoted[0].text.clone(), from, to));
    }

    let input = quoted
        .get(2)
        .map(|segment| segment.text.clone())
        .or_else(|| text_after_colon(prompt))
        .or_else(|| last_assistant_text_artifact(history))?;
    let (from, to) = replacement_operands(prompt, &quoted[0], &quoted[1]);
    Some((input, from, to))
}

/// The two operands of a replacement as `(from, to)`.
///
/// The quoted target comes first, unless a cue that names its target after it
/// sits between them ("cat" instead of "dog"). Twin of `replacementOperands`
/// in `js/worker/formal_ai_worker_coding_idioms_and_text_manipulation.js`.
fn replacement_operands(
    prompt: &str,
    first: &QuotedSegment,
    second: &QuotedSegment,
) -> (String, String) {
    let gap = prompt.get(first.end..second.start).unwrap_or_default();
    if text_cue_matches(REPLACEMENT_CUE_TABLE, gap, Some(TARGET_FOLLOWS_CUE)) {
        (second.text.clone(), first.text.clone())
    } else {
        (first.text.clone(), second.text.clone())
    }
}

fn parse_remove_request(prompt: &str, history: &[ConversationTurn]) -> Option<(String, String)> {
    let quoted = quoted_segment_spans(prompt);
    if quoted.is_empty() {
        return None;
    }

    if quoted.len() >= 2 && looks_like_input_first_unary_edit(prompt, &quoted) {
        return Some((quoted[0].text.clone(), quoted[1].text.clone()));
    }

    let input = quoted
        .get(1)
        .map(|segment| segment.text.clone())
        .or_else(|| text_after_colon(prompt))
        .or_else(|| last_assistant_text_artifact(history))?;
    Some((input, quoted[0].text.clone()))
}

fn parse_affix_request(prompt: &str, history: &[ConversationTurn]) -> Option<(String, String)> {
    let quoted = quoted_segment_spans(prompt);
    if quoted.is_empty() {
        return None;
    }

    if quoted.len() >= 2 && looks_like_input_first_unary_edit(prompt, &quoted) {
        return Some((quoted[0].text.clone(), quoted[1].text.clone()));
    }

    let input = quoted
        .get(1)
        .map(|segment| segment.text.clone())
        .or_else(|| text_after_colon(prompt))
        .or_else(|| last_assistant_text_artifact(history))?;
    Some((input, quoted[0].text.clone()))
}

fn looks_like_input_first_unary_edit(prompt: &str, quoted: &[QuotedSegment]) -> bool {
    if quoted.len() < 2 {
        return false;
    }

    let before_first = &prompt[..quoted[0].start];
    input_context_before_first_quote(before_first)
}

fn looks_like_input_first_replacement(prompt: &str, quoted: &[QuotedSegment]) -> bool {
    if quoted.len() < 3 {
        return false;
    }

    let before_first = &prompt[..quoted[0].start];
    let between_first_second = &prompt[quoted[0].end..quoted[1].start];
    let between_second_third = &prompt[quoted[1].end..quoted[2].start];

    let cue =
        |text: &str, reading: &str| text_cue_matches(REPLACEMENT_CUE_TABLE, text, Some(reading));

    input_context_before_first_quote(before_first)
        || cue(between_first_second, OPERANDS_IN_ORDER)
        || cue(between_second_third, TARGET_FOLLOWS_CUE)
        || (contains_input_continuation(between_first_second)
            && contains_replacement_keyword(between_second_third))
}

fn input_context_before_first_quote(text: &str) -> bool {
    !contains_replacement_keyword(text) && text_cue_matches(INPUT_CONTEXT_CUE_TABLE, text, None)
}

fn contains_input_continuation(text: &str) -> bool {
    text_cue_matches(INPUT_CONTINUATION_CUE_TABLE, text, None)
}

fn contains_replacement_keyword(text: &str) -> bool {
    text_cue_matches(REPLACEMENT_CUE_TABLE, text, None)
}

/// Does a row of the cue `table` occur in `text`, counting only rows whose
/// value is `reading` when one is given?
///
/// Issue #918 (R918-2): the cues are the `text_*` tables of
/// `data/seed/handler-rules.lino`. A row whose value is `ends_with`
/// is read at the end of the normalized text, any other row anywhere in the
/// lowercased text; a replacement cue's value is the order it quotes its
/// operands in. Twin of `textCueMatches` in `js/worker/formal_ai_worker_coding_idioms_and_text_manipulation.js`.
fn text_cue_matches(table: &str, text: &str, reading: Option<&str>) -> bool {
    let raw = text.to_lowercase();
    let normalized = normalize_replacement_prompt(text);
    handler_table_rows(table).iter().any(|(cue, value)| {
        let read = if value == SUFFIX_READING {
            normalized.ends_with(cue.as_str())
        } else {
            raw.contains(cue.as_str())
        };
        !cue.is_empty() && reading.is_none_or(|wanted| value == wanted) && read
    })
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct TextStep {
    operation: TextOperation,
    rule_id: String,
    before: String,
    after: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct SubstitutionTextChain {
    result: String,
    steps: Vec<TextStep>,
    rules: SubstitutionRuleSet,
    report: SubstitutionTraceReport,
    graph: SubstitutionGraph,
}

impl SubstitutionTextChain {
    fn build(input: &str, operations: &[TextOperation]) -> Option<Self> {
        if operations.is_empty() {
            return None;
        }

        let mut current = input.to_owned();
        let mut steps = Vec::new();
        let mut used_rule_ids = BTreeSet::new();
        for operation in operations {
            let after = operation.apply(&current);
            let rule_id = unique_rule_id(operation.slug(), &mut used_rule_ids);
            steps.push(TextStep {
                operation: operation.clone(),
                rule_id,
                before: current,
                after: after.clone(),
            });
            current = after;
        }

        let rules_text = build_rules_links_notation(input, &steps);
        let rules = SubstitutionRuleSet::from_links_notation(&rules_text).ok()?;
        let mut graph = SubstitutionGraph::new().with_link("stage:0", &text_node(input));
        let report = graph.apply_rules_with_limit(&rules, CrudEvent::Manual, steps.len());
        if report.applied_count() != steps.len() {
            return None;
        }

        Some(Self {
            result: current,
            steps,
            rules,
            report,
            graph,
        })
    }
}

fn unique_rule_id(slug: &str, used: &mut BTreeSet<String>) -> String {
    let base = format!("rule_{slug}");
    if used.insert(base.clone()) {
        return base;
    }
    for index in 2.. {
        let candidate = format!("{base}_{index}");
        if used.insert(candidate.clone()) {
            return candidate;
        }
    }
    unreachable!("unbounded suffix search must return")
}

fn build_rules_links_notation(input: &str, steps: &[TextStep]) -> String {
    let mut out = String::new();
    push_lino_node(&mut out, 0, "substitution_rules", None);
    push_lino_node(
        &mut out,
        2,
        "id",
        Some(&stable_id(
            "text_substitution_rules",
            &format!("{input}:{}", steps.len()),
        )),
    );
    for (index, step) in steps.iter().enumerate() {
        push_lino_node(&mut out, 2, "rule", Some(&step.rule_id));
        push_lino_node(&mut out, 4, "order", Some(&(index + 1).to_string()));
        push_lino_node(&mut out, 4, "event", Some("manual"));
        push_lino_node(
            &mut out,
            4,
            "replace",
            Some(&format!("stage:{index} -> {}", text_node(&step.before))),
        );
        push_lino_node(
            &mut out,
            6,
            "with",
            Some(&format!(
                "stage:{} -> {}",
                index + 1,
                text_node(&step.after)
            )),
        );
        push_lino_node(
            &mut out,
            6,
            "with",
            Some(&format!(
                "stage:{} -> operation:{}",
                index + 1,
                step.operation.slug()
            )),
        );
    }
    out.trim_end().to_owned()
}

fn text_node(text: &str) -> String {
    format!("text:hex:{}", hex_encode(text.as_bytes()))
}

fn hex_encode(bytes: &[u8]) -> String {
    let mut out = String::with_capacity(bytes.len() * 2);
    for byte in bytes {
        let _ = write!(out, "{byte:02x}");
    }
    out
}

fn normalize_replacement_prompt(prompt: &str) -> String {
    let mut normalized = String::with_capacity(prompt.len());
    for character in prompt.chars().flat_map(char::to_lowercase) {
        if character.is_alphanumeric() {
            normalized.push(character);
        } else {
            normalized.push(' ');
        }
    }
    normalized.split_whitespace().collect::<Vec<_>>().join(" ")
}

fn text_after_colon(prompt: &str) -> Option<String> {
    let (_, tail) = prompt.rsplit_once(':')?;
    let text = tail
        .trim()
        .trim_matches(|character| {
            matches!(
                character,
                '"' | '\'' | '`' | '«' | '»' | '“' | '”' | '‘' | '’' | '「' | '」' | '『' | '』'
            )
        })
        .trim();
    (!text.is_empty()).then(|| text.to_owned())
}
