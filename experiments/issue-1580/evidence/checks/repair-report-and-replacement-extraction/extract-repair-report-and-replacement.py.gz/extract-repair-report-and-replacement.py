from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'repair-report-and-replacement-extraction'
if len(sys.argv) == 1:
    out.mkdir(exist_ok=False)
    with (out / 'worker.log').open('wb') as stream:
        worker = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': worker.pid, 'finiteWorker': True}))
    sys.exit(0)
records = []
def run(name, argv):
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=root, env={**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}, stdout=stdout, stderr=stderr)
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == 0, name
    return (out / (name + '.stdout')).read_bytes()

assert json.loads((scratch / 'lexeme-native-registry-refresh/outcome.json').read_text())['passed']
assert not run('index-before', ['git', 'diff', '--cached', '--name-only']).strip()
proofs = []
source_paths = []
def save(label, parent, child, original, new_parent, new_child, restored):
    assert restored == original and not child.exists()
    assert len(new_parent.splitlines()) < 900 and len(new_child.splitlines()) < 900
    child.parent.mkdir(exist_ok=True)
    parent.write_text(new_parent)
    child.write_text(new_child)
    (out / (label + '-original-source.rs.gz')).write_bytes(gzip.compress(original.encode(), mtime=0))
    proofs.append({'parent': parent.relative_to(root).as_posix(), 'child': child.relative_to(root).as_posix(), 'originalSha256': hashlib.sha256(original.encode()).hexdigest(), 'reassembledOriginalSha256': hashlib.sha256(restored.encode()).hexdigest(), 'originalLines': len(original.splitlines()), 'parentLines': len(new_parent.splitlines()), 'childLines': len(new_child.splitlines()), 'exactOriginalReconstructionBeforeFormatting': True})
    source_paths.extend(p.relative_to(root).as_posix() for p in [parent, child])

parent = root / 'rust/src/agentic_coding/repair_loop.rs'
child = root / 'rust/src/agentic_coding/repair_loop/notes.rs'
original = parent.read_text()
assert len(original.splitlines()) == 921
marker = "/// Fill a localized repair template's `{placeholder}` slots."
start = original.index(marker)
block = original[start:]
declaration = 'mod notes;\n\npub use notes::{ladder_note, stop_note, unresolved_note};\n\n'
imports = 'use super::{\n    FailedStep, RepairStop, attempts_from, evidence_document, formalize_diagnostic, search_query,\n};\nuse crate::protocol::ChatMessage;\n\n'
new_parent = original[:start].rstrip() + '\n'
new_parent = new_parent.replace('use std::collections::BTreeSet;\n', declaration + 'use std::collections::BTreeSet;\n', 1)
new_child = imports + block
restored = new_parent.replace(declaration, '', 1).rstrip() + '\n\n' + new_child.removeprefix(imports)
save('repair-notes', parent, child, original, new_parent, new_child, restored)

parent = root / 'rust/src/agentic_coding/task_acceptance.rs'
child = root / 'rust/src/agentic_coding/task_acceptance/report.rs'
original = parent.read_text()
assert len(original.splitlines()) == 930
marker = "/// The verdict lines a finished recipe's answer carries, or an empty string"
start = original.index(marker)
block = original[start:]
declaration = 'mod report;\n\npub use report::acceptance_report;\n\n'
imports = 'use serde_json::{Value, json};\n\nuse super::{UNREAD, check_task, specify_task};\nuse super::super::work_item_steps::fill;\nuse crate::engine::ExecutionRecipe;\n\n'
new_parent = original[:start].rstrip() + '\n'
new_parent = new_parent.replace('use std::collections::BTreeSet;\n', declaration + 'use std::collections::BTreeSet;\n', 1).replace('use super::work_item_steps::{fill, template};', 'use super::work_item_steps::template;', 1).replace('use crate::engine::{ExecutionRecipe, normalize_prompt, stable_id};', 'use crate::engine::{normalize_prompt, stable_id};', 1)
new_child = imports + block
restored = new_parent.replace(declaration, '', 1).replace('use super::work_item_steps::template;', 'use super::work_item_steps::{fill, template};', 1).replace('use crate::engine::{normalize_prompt, stable_id};', 'use crate::engine::{ExecutionRecipe, normalize_prompt, stable_id};', 1).rstrip() + '\n\n' + new_child.removeprefix(imports)
save('acceptance-report', parent, child, original, new_parent, new_child, restored)

parent = root / 'rust/src/solver_handlers/text_manipulation.rs'
child = root / 'rust/src/solver_handlers/text_manipulation/replacement.rs'
original = parent.read_text()
assert len(original.splitlines()) == 949
start = original.index('fn replace_text(')
end_marker = 'fn parse_replace_request('
end = original.index(end_marker, start)
block = original[start:end]
declaration = 'mod replacement;\n\nuse replacement::replace_text;\n\n'
imports = 'use crate::solver_handlers::text_edit_ops::normalized_word_spans;\n\n'
new_parent = (original[:start] + original[end:]).replace('use std::collections::BTreeSet;\n', declaration + 'use std::collections::BTreeSet;\n', 1).replace('join_lines, normalized_word_spans,', 'join_lines,', 1)
new_child = imports + block[:-1].replace('fn replace_text(', 'pub(super) fn replace_text(', 1)
restored = new_parent.replace(declaration, '', 1).replace('join_lines,', 'join_lines, normalized_word_spans,', 1).replace(end_marker, new_child.removeprefix(imports).replace('pub(super) fn ', 'fn ') + '\n' + end_marker, 1)
save('replacement-ranges', parent, child, original, new_parent, new_child, restored)

unformatted = {}
for index, path in enumerate(source_paths):
    raw = (root / path).read_bytes()
    target = out / ('unformatted-' + str(index) + '.rs')
    target.write_bytes(raw)
    unformatted[path] = str(target)
run('canonical-rust-formatting', ['rustfmt', '--edition', '2024', *source_paths])
token_check = "import fs from 'node:fs'; import assert from 'node:assert/strict'; import {lex} from './scripts/self-translation/lexer.mjs'; const inputs=JSON.parse(fs.readFileSync(process.argv[1],'utf8')); for(const [file,old] of Object.entries(inputs)){ const tokens=s=>lex(s,'Rust').map(t=>[t.type,t.text]); assert.deepEqual(tokens(fs.readFileSync(file,'utf8')),tokens(fs.readFileSync(old,'utf8')),file); } console.log('Every Rust syntax token and comment is unchanged by formatting');"
(out / 'formatting-inputs.json').write_text(json.dumps(unformatted) + '\n')
run('formatting-token-equivalence', ['node', '--input-type=module', '-e', token_check, str(out / 'formatting-inputs.json')])
for proof in proofs:
    proof['parentLines'] = len((root / proof['parent']).read_text().splitlines())
    proof['childLines'] = len((root / proof['child']).read_text().splitlines())
    assert proof['parentLines'] < 900 and proof['childLines'] < 900
(out / 'inverse-proofs.json').write_text(json.dumps({'observedAt': datetime.now(timezone.utc).isoformat(), 'files': proofs, 'formattingPreservesEverySyntaxTokenAndComment': True, 'localRustExecution': False, 'hostedNativeVerificationPending': True, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
run('rust-format-check', ['rustfmt', '--edition', '2024', '--check', *source_paths])
for name, path in [('repair-note-javascript', 'rust/tests/web/issue-1185-production-repair-bridge.test.mjs'), ('acceptance-report-javascript', 'rust/tests/web/issue-1166-task-acceptance.test.mjs'), ('replacement-javascript', 'rust/tests/web/pull-request-1188-quoted-content.test.mjs')]:
    run(name, ['node', '--test', '--test-concurrency=1', path])
run('translation-current', ['node', 'scripts/translate-js-rust.mjs', '--verify'])
run('generated-registry-current', ['node', 'scripts/lib/generate-native-specification-programs.mjs', '--check'])
run('source-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code'])
(out / 'outcome.json').write_text(json.dumps({'passed': True, 'files': proofs, 'sourcePaths': source_paths, 'pushExecuted': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
