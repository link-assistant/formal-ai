from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'repair-report-and-replacement-extraction'
if len(sys.argv) == 1:
    with (out / 'finish-worker.log').open('wb') as stream:
        worker = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': worker.pid, 'finiteWorker': True}))
    sys.exit(0)
records = []
def run(name, argv):
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=root, env={**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}, stdout=stdout, stderr=stderr)
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (out / 'finish-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == 0, name
    return (out / (name + '.stdout')).read_bytes()

# Keep the original failed experiment and its formatted draft; restore this
# unrelated source rather than accepting rustfmt's broad expansion/reordering.
task = root / 'rust/src/agentic_coding/task_acceptance.rs'
report = root / 'rust/src/agentic_coding/task_acceptance/report.rs'
for path in [task, report]:
    (out / ('discarded-formatted-' + path.name + '.gz')).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
task.write_bytes(gzip.decompress((out / 'acceptance-report-original-source.rs.gz').read_bytes()))
report.unlink()
report.parent.rmdir()
assert task.read_bytes() == subprocess.check_output(['git', 'show', 'HEAD:rust/src/agentic_coding/task_acceptance.rs'], cwd=root)

inputs = json.loads((out / 'formatting-inputs.json').read_text())
inputs = {path: old for path, old in inputs.items() if '/task_acceptance' not in path}
(out / 'accepted-formatting-inputs.json').write_text(json.dumps(inputs) + '\n')
token_check = "import fs from 'node:fs'; import assert from 'node:assert/strict'; import {lex} from './scripts/self-translation/lexer.mjs'; const inputs=JSON.parse(fs.readFileSync(process.argv[1],'utf8')); for(const [file,old] of Object.entries(inputs)){ const tokens=s=>lex(s,'Rust').map(t=>[t.type,t.text]); assert.deepEqual(tokens(fs.readFileSync(file,'utf8')),tokens(fs.readFileSync(old,'utf8')),file); } console.log('Every accepted Rust syntax token and comment is unchanged by formatting');"
run('accepted-formatting-token-equivalence', ['node', '--input-type=module', '-e', token_check, str(out / 'accepted-formatting-inputs.json')])
proofs = []
for label, parent_path, child_path in [
    ('repair-notes', 'rust/src/agentic_coding/repair_loop.rs', 'rust/src/agentic_coding/repair_loop/notes.rs'),
    ('replacement-ranges', 'rust/src/solver_handlers/text_manipulation.rs', 'rust/src/solver_handlers/text_manipulation/replacement.rs'),
]:
    original = gzip.decompress((out / (label + '-original-source.rs.gz')).read_bytes()).decode()
    parent = Path(inputs[parent_path]).read_text()
    child = Path(inputs[child_path]).read_text()
    if label == 'repair-notes':
        declaration = 'mod notes;\n\npub use notes::{ladder_note, stop_note, unresolved_note};\n\n'
        imports = 'use super::{\n    FailedStep, RepairStop, attempts_from, evidence_document, formalize_diagnostic, search_query,\n};\nuse crate::protocol::ChatMessage;\n\n'
        restored = parent.replace(declaration, '', 1).rstrip() + '\n\n' + child.removeprefix(imports)
    else:
        declaration = 'mod replacement;\n\nuse replacement::replace_text;\n\n'
        imports = 'use crate::solver_handlers::text_edit_ops::normalized_word_spans;\n\n'
        marker = 'fn parse_replace_request('
        restored = parent.replace(declaration, '', 1).replace('join_lines,', 'join_lines, normalized_word_spans,', 1).replace(marker, child.removeprefix(imports).replace('pub(super) fn ', 'fn ') + '\n' + marker, 1)
    assert restored == original, label
    assert original.encode() == subprocess.check_output(['git', 'show', 'HEAD:' + parent_path], cwd=root)
    counts = [len((root / path).read_text().splitlines()) for path in [parent_path, child_path]]
    assert all(count < 900 for count in counts)
    proofs.append({'parent': parent_path, 'child': child_path, 'originalSha256': hashlib.sha256(original.encode()).hexdigest(), 'reassembledOriginalSha256': hashlib.sha256(restored.encode()).hexdigest(), 'originalLines': len(original.splitlines()), 'parentLines': counts[0], 'childLines': counts[1], 'exactOriginalReconstructionBeforeFormatting': True})
(out / 'inverse-proofs.json').write_text(json.dumps({'observedAt': datetime.now(timezone.utc).isoformat(), 'files': proofs, 'formattingPreservesEverySyntaxTokenAndComment': True, 'discardedDraft': 'task_acceptance broad formatting rejected; original parent restored byte-for-byte', 'localRustExecution': False, 'hostedNativeVerificationPending': True, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
run('rust-format-check', ['rustfmt', '--edition', '2024', '--check', *inputs])
for name, path in [('repair-note-javascript', 'rust/tests/web/issue-1185-stop-note.test.mjs'), ('replacement-javascript', 'rust/tests/web/issue-0408-text-edit-parity.test.mjs')]:
    run(name, ['node', '--test', '--test-concurrency=1', path])
run('translation-current', ['node', 'scripts/translate-js-rust.mjs', '--verify'])
run('generated-registry-current', ['node', 'scripts/lib/generate-native-specification-programs.mjs', '--check'])
run('source-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code'])
(out / 'outcome.json').write_text(json.dumps({'passed': True, 'files': proofs, 'sourcePaths': list(inputs), 'pushExecuted': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
