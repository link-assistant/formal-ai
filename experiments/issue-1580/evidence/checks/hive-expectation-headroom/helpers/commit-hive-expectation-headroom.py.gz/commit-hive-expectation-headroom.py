from pathlib import Path
import gzip,hashlib,json,os,re,subprocess

root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'hive-commit-expectations';summary=json.loads((out/'summary.json').read_text());parent=root/summary['parent'];child=root/summary['child']
before=(out/'extended.before.rs').read_text();current=parent.read_text();helpers=['commit_phase_prompt','expected_owned_recipe_commit','assert_named_branch_push']
functions=lambda s:re.findall(r'^fn (\w+)\(',s,re.M)
assert functions(current)==[name for name in functions(before) if name not in helpers]
assert re.findall(r'^pub\(super\) fn (\w+)\(',child.read_text(),re.M)==helpers
assert re.findall(r'#\[test\]\nfn (\w+)\(',before)==re.findall(r'#\[test\]\nfn (\w+)\(',current)
assert all(row['exitCode']==0 for row in json.loads((out/'commands.json').read_text()) if row['name']!='before')
assert '# pass 12\n# fail 0' in (out/'after.stdout').read_text()
(out/'function-inventory.json').write_text(json.dumps({'originalFunctions':functions(before),'retainedFunctions':functions(current),'extractedHelpers':helpers,'allOriginalTestNamesUnchanged':True},indent=2)+'\n')
target=root/'experiments/issue-1580/evidence/checks/hive-expectation-headroom';target.mkdir(exist_ok=False);records=[]
for path in [*sorted(out.iterdir()),scratch/'extract-hive-commit-expectations.py',scratch/'extract-hive-commit-expectations.log',scratch/'commit-hive-expectation-headroom.py']:
    if not path.is_file():continue
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);alias=('helpers/' if path.parent==scratch else 'validation/')+path.name+'.gz';destination=target/alias;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed)
    assert gzip.decompress(destination.read_bytes())==raw
    records.append({'source':str(path),'file':alias,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records));(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
note=root/'docs/case-studies/issue-1580/hive-expectation-headroom-checkpoint.md';note.write_text('''# Hive commit expectation helper headroom

The maintained scanner reproduced the 1000-line Hive extended-test warning.
Three fixture helpers and their private template placeholders now live in a
137-line child module; the owner has 872 lines. All 30 original native test
names, order, assertions and timing records stay in the original module. Moved
helper bodies are unchanged except for visibility. An independent function
inventory verifies that exactly those three helpers leave the parent.

The focused regression fails before extraction and all 12 cases pass afterward.
Formatting, whitespace and three touched JavaScript gates pass. The scanner
reports 78 warnings and zero violations under unchanged limits. The preceding
batch's 144 maintained and 50 native-runner cases remain its own qualification;
this batch executes the focused regression only. Hosted native execution and
full issue acceptance remain unfinished. Supplied scripts receive zero
independent authorship or reasoning credit.

Evidence: `experiments/issue-1580/evidence/checks/hive-expectation-headroom/`.
''')
fragment=root/'changelog.d/issue-1580-hive-expectation-headroom.md';fragment.write_text('''---
bump: patch
---

Separate Hive commit expectation fixture helpers while preserving all original
native regression names, assertions and recorded timing identities.
''')
plan=root/'experiments/issue-1580/work-plan.md';source=plan.read_text().replace('Local commits extract eight Rust test/helper groups','Local commits extract nine Rust test/helper groups').replace('bodies or scanner limits: 79 warnings remain.','bodies or scanner limits: 78 warnings remain.').replace('Eleven focused headroom/path cases, 50 native-runner cases and 144 maintained\nobservation cases pass;','Twelve focused headroom/path cases pass. The preceding batch passed 50\nnative-runner cases and 144 maintained observation cases;');source+='\n- Hive expectation helpers remove another warning with all 30 original native test names unchanged: 78 warnings remain. Twelve focused cases pass; hosted native execution is still pending. See [Hive expectation headroom](../../docs/case-studies/issue-1580/hive-expectation-headroom-checkpoint.md).\n';plan.write_text(source)
paths=[summary['parent'],summary['child'],'experiments/issue-1580/native-test-headroom.test.mjs',str(note.relative_to(root)),str(fragment.relative_to(root)),str(plan.relative_to(root)),str(target.relative_to(root))];subprocess.run(['git','add','--',*paths],cwd=root,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=root).decode().split('\0')[:-1];assert not any('/evidence/ci/' in path for path in staged)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
for name,args in [('final-naming',['node','scripts/measure-abbreviations.mjs','--check']),('final-secrets',['bash','scripts/check-secrets.sh',*staged]),('final-whitespace',['git','diff','--cached','--check'])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    assert result.returncode==0,name
with (out/'commit.stdout').open('wb') as stdout,(out/'commit.stderr').open('wb') as stderr:subprocess.run(['git','-c','gc.auto=0','commit','-m','Extract Hive commit expectation helpers without renaming tests'],cwd=root,stdout=stdout,stderr=stderr,check=True)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root,text=True)
result={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'committed':True,'pushed':False,'trackedWorkingTreeClean':True,'records':len(records),'fullIssueComplete':False};(out/'commit-outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
