from pathlib import Path
import datetime,gzip,hashlib,json,os,re,subprocess

root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'hive-commit-expectations';out.mkdir(exist_ok=False)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);records=[]
def run(name,args):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    records.append({'name':name,'args':args,'exitCode':result.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');return result.returncode
parent=root/'rust/tests/unit/issue_1133_hive_mind_three_runs/extended.rs';child=parent.with_suffix('')/'commit_expectations.rs';test=root/'experiments/issue-1580/native-test-headroom.test.mjs'
addition='''
test('Hive commit expectations retain headroom without moving native test names', () => {
  const owner = 'rust/tests/unit/issue_1133_hive_mind_three_runs/extended';
  assert.deepEqual(checkListedFiles(root, new Set([owner + '.rs', owner + '/commit_expectations.rs'])),
    {warnings: [], violations: [], embeddedDataViolations: []});
  const source = readFileSync(root + '/' + owner + '.rs', 'utf8');
  assert.match(source, /^mod commit_expectations;$/mu);
  const helpers = readFileSync(root + '/' + owner + '/commit_expectations.rs', 'utf8');
  for (const name of ['commit_phase_prompt', 'expected_owned_recipe_commit', 'assert_named_branch_push']) {
    assert(helpers.includes('pub(super) fn ' + name + '('));
    assert(source.includes(name));
  }
  assert(!helpers.includes('#[test]'), 'only fixture helpers move out of the original test module');
});
'''
assert 'Hive commit expectations retain headroom' not in test.read_text();test.write_text(test.read_text()+addition)
testargs=['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',str(test.relative_to(root))]
assert run('before',testargs)==1
assert '# pass 11\n# fail 1' in (out/'before.stdout').read_text()
original=parent.read_text();(out/'extended.before.rs').write_text(original)
start=original.index('// Canonical template keys');stop=original.index('#[test]\nfn the_claude_code_tool_set',start)
first=original[start:stop];start2=original.index('fn assert_named_branch_push(');stop2=original.index('#[test]\nfn the_named_branch_is_pushed_to_in_every_language()',start2);second=original[start2:stop2]
moved=first+second;child.parent.mkdir(exist_ok=True)
prefix='use super::{\n    AGENT_TOOLS, BRANCH, ChatMessage, ISSUE, PR, PlannedToolCall, command_of, drive,\n    is_work_item_read, page, path_of, prompt,\n};\n\n'
child.write_text(prefix+re.sub(r'^fn ','pub(super) fn ',moved,flags=re.M))
parent_source=original[:start]+original[stop:start2]+original[stop2:]
parent_source=parent_source.replace('use super::*;','use super::*;\n\nmod commit_expectations;\nuse commit_expectations::{\n    assert_named_branch_push, commit_phase_prompt, expected_owned_recipe_commit,\n};',1);parent.write_text(parent_source)
files=[str(parent.relative_to(root)),str(child.relative_to(root))]
assert run('format',['rustfmt','--edition','2024','--config','skip_children=true',*files])==0
assert run('format-check',['rustfmt','--edition','2024','--config','skip_children=true','--check',*files])==0
actual=child.read_text();normalized=re.sub(r'^pub\(super\) fn ','fn ',actual[actual.index('// Canonical template keys'):],flags=re.M)
assert normalized.rstrip()==moved.rstrip()
assert re.findall(r'^fn (\w+)\(',original,re.M)==re.findall(r'^fn (\w+)\(',parent.read_text(),re.M)[:0]+[name for name in re.findall(r'^fn (\w+)\(',original,re.M)]
# All tests retain their original declarations, order and parent module.
old_tests=re.findall(r'#\[test\]\nfn (\w+)\(',original);new_tests=re.findall(r'#\[test\]\nfn (\w+)\(',parent.read_text());assert old_tests==new_tests
assert run('after',testargs)==0
assert run('touched-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size,check-file-size-js-twin'])==0
assert run('whitespace',['git','diff','--check'])==0
gates=root/'experiments/formal_ai_subagent/sandboxes/gates';warnings=len(re.findall(r'^::warning file=',(gates/'check-file-size.log').read_text(),re.M));assert warnings==78
summary={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'parent':files[0],'child':files[1],'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'movedSha256':hashlib.sha256(moved.encode()).hexdigest(),'movedBodiesUnchanged':True,'allOriginalTestNamesPreserved':old_tests,'parentLines':len(parent.read_text().splitlines()),'childLines':len(child.read_text().splitlines()),'before':{'passed':11,'failed':1},'after':{'passed':12,'failed':0},'remainingWarnings':warnings,'nativeBuildRun':False,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
assert summary['parentLines']<=900 and summary['childLines']<=900
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'validated':True,'focusedCases':12,'remainingWarnings':78,'nativeBuildRun':False}))
