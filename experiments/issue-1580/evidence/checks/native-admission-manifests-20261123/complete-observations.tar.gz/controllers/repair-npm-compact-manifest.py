import datetime,json,subprocess
from pathlib import Path
root=Path('/tmp/issue-1580-research/npm-compact-manifest-repair');root.mkdir(exist_ok=False)
files=['scripts/check-dependencies-latest.rs','scripts/check-dependencies-latest-parsers.rs','scripts/check-dependencies-latest-tests.rs']
for name in files:(root/(Path(name).name+'.before')).write_bytes(Path(name).read_bytes())
module=r'''//! JSON member spans shared by npm collection and exact manifest rewrites.
use super::*;

pub(super) struct NpmMember {
    pub name: String,
    pub declared: String,
    pub line: usize,
    pub start: usize,
    pub end: usize,
    pub blocked: Option<String>,
}

// serde_json owns JSON syntax and escaping; byte offsets retain the original layout.
fn object_members(text: &str, offset: usize) -> Option<Vec<(String, usize, usize)>> {
    if !serde_json::from_str::<serde_json::Value>(text).ok()?.is_object() {
        return None;
    }
    let mut cursor = text.find('{')? + 1;
    let mut members = Vec::new();
    loop {
        cursor += text[cursor..].len() - text[cursor..].trim_start().len();
        if text.as_bytes().get(cursor) == Some(&b'}') {
            return Some(members);
        }
        let mut key = serde_json::Deserializer::from_str(&text[cursor..]).into_iter::<String>();
        let name = key.next()?.ok()?;
        cursor += key.byte_offset();
        cursor += text[cursor..].len() - text[cursor..].trim_start().len();
        if text.as_bytes().get(cursor) != Some(&b':') {
            return None;
        }
        cursor += 1;
        cursor += text[cursor..].len() - text[cursor..].trim_start().len();
        let start = cursor;
        let mut value = serde_json::Deserializer::from_str(&text[cursor..])
            .into_iter::<serde_json::Value>();
        value.next()?.ok()?;
        cursor += value.byte_offset();
        members.push((name, offset + start, offset + cursor));
        cursor += text[cursor..].len() - text[cursor..].trim_start().len();
        if text.as_bytes().get(cursor) == Some(&b',') {
            cursor += 1;
        }
    }
}

pub(super) fn dependency_members(text: &str) -> Vec<NpmMember> {
    let Some(root) = object_members(text, 0) else {
        return Vec::new();
    };
    let mut members = Vec::new();
    let mut notes = root.clone();
    for (section, start, end) in root {
        if matches!(
            section.as_str(),
            "dependencies" | "devDependencies" | "optionalDependencies"
        ) && let Some(entries) = object_members(&text[start..end], start)
        {
            notes.extend(entries.clone());
            members.extend(entries);
        }
    }
    let blocked: BTreeMap<String, String> = notes
        .into_iter()
        .filter_map(|(name, start, end)| {
            let name = name.strip_suffix("//")?;
            let note = serde_json::from_str::<String>(&text[start..end]).ok()?;
            let reason = note.trim().strip_prefix("blocked:")?;
            Some((name.to_string(), tracking_reference(reason)?))
        })
        .collect();
    members
        .into_iter()
        .filter_map(|(name, start, end)| {
            if name.ends_with("//") {
                return None;
            }
            let declared = serde_json::from_str::<String>(&text[start..end]).ok()?;
            Some(NpmMember {
                blocked: blocked.get(&name).cloned(),
                name,
                declared,
                line: text[..start].bytes().filter(|byte| *byte == b'\n').count() + 1,
                start,
                end,
            })
        })
        .collect()
}
'''
Path('scripts/check-dependencies-latest-npm.rs').write_text(module)
p=Path(files[1]);text=p.read_text()
start=text.index('    let mut blocked:',text.index('pub fn parse_package_json('))
end=text.index('\n}\n\n/// Registry identity',start)
text=text[:start]+'''    npm_manifest::dependency_members(text)
        .into_iter()
        .map(|member| (member.name, member.declared, member.line, member.blocked))
        .collect()'''+text[end:]
p.write_text(text)
p=Path(files[0]);text=p.read_text()
start=text.index('    let latest =',text.index('fn rewrite_npm_line('))
end=text.index('\n}\n\nfn rewrite_uses_line',start)
text=text[:start]+r'''    let Some(declared) = dependency.declared.as_deref() else {
        return text.to_string();
    };
    let Some(member) = npm_manifest::dependency_members(text).into_iter().find(|member| {
        member.line == dependency.line
            && member.declared == declared
            && member.blocked == dependency.blocked
            && npm_registry_identity(&member.name, declared)
                .is_some_and(|(name, _)| name == dependency.name)
    }) else {
        return text.to_string();
    };
    let Some((name, requirement)) = npm_registry_identity(&dependency.name, declared) else {
        return text.to_string();
    };
    let alias = if declared.starts_with("npm:") {
        format!("npm:{name}@")
    } else {
        String::new()
    };
    let prefix = ['^', '~', '>', '=']
        .iter()
        .find(|character| requirement.starts_with(**character))
        .map(std::string::ToString::to_string)
        .unwrap_or_default();
    let updated = format!("{alias}{prefix}{}", without_build_metadata(latest));
    let mut rewritten = text.to_string();
    rewritten.replace_range(
        member.start..member.end,
        &serde_json::to_string(&updated).expect("encode the updated npm requirement"),
    );
    rewritten'''+text[end:]
needle='#[path = "check-dependencies-latest-parsers.rs"]'
text=text.replace(needle,'#[path = "check-dependencies-latest-npm.rs"]\nmod npm_manifest;\n'+needle)
needle='''        let lock_versions = npm_lock_versions(&manifest_path);'''
assert text.count(needle)==1
text=text.replace(needle,'''        serde_json::from_str::<serde_json::Value>(&text)
            .map_err(|error| format!("{}: {error}", manifest_path.display()))?;
'''+needle)
p.write_text(text)
p=Path(files[2]);text=p.read_text()
old='let source = "{\\n  \\"alias\\": \\"npm:@scope/actual@^1.0.0\\"\\n}\\n";'
assert old in text
text=text.replace(old,'let source = "{\\n  \\"dependencies\\": { \\"alias\\": \\"npm:@scope/actual@^1.0.0\\" }\\n}\\n";')
text+=r'''
#[test]
fn compact_npm_members_keep_json_boundaries_order_and_blocked_notes() {
    let source = r#"{"description":"1.0.0","dependencies":{"z":"1.0.0","a":"^2.0.0","z//":"blocked: https://github.com/o/r/issues/9"},"scripts":{"pretend":"9.0.0"},"devDependencies":{"escaped\u002dname":"~3.0.0"},"optionalDependencies":{"optional":"4.0.0"}}"#;
    let parsed = parse_package_json(source);
    assert_eq!(
        parsed.iter().map(|(name, _, _, _)| name.as_str()).collect::<Vec<_>>(),
        ["z", "a", "escaped-name", "optional"]
    );
    assert!(parsed.iter().all(|(_, _, line, _)| *line == 1));
    assert_eq!(parsed[0].3.as_deref(), Some("https://github.com/o/r/issues/9"));
    assert!(parsed[1..].iter().all(|(_, _, _, blocked)| blocked.is_none()));
}

#[test]
fn compact_npm_rewrite_changes_only_the_selected_dependency_value() {
    let source = r#"{"description":"1.0.0","dependencies":{"held":"1.0.0","alias":"npm:@scope/actual@^1.0.0","chosen":"1.0.0"},"scripts":{"chosen":"1.0.0"},"chosen//":"blocked: waiting without a tracking reference"}"#;
    let dependency = |name: &str, declared: &str| Dependency {
        ecosystem: Ecosystem::Npm,
        name: name.to_string(),
        declared: Some(declared.to_string()),
        resolved: "1.0.0".to_string(),
        path: "package.json".into(),
        line: 1,
        blocked: None,
    };
    let alias = rewrite_npm_line(source, &dependency("@scope/actual", "npm:@scope/actual@^1.0.0"), "2.0.0");
    assert_eq!(alias, source.replace("@^1.0.0", "@^2.0.0"));
    let chosen = rewrite_npm_line(source, &dependency("chosen", "1.0.0"), "3.0.0");
    assert_eq!(chosen, source.replacen(r#""chosen":"1.0.0""#, r#""chosen":"3.0.0""#, 1));
}

#[test]
fn dependency_section_closure_excludes_following_root_members() {
    let source = "{\n \"dependencies\": {\n  \"real\": \"1.0.0\"\n },\n \"description\": \"9.0.0\",\n \"scripts\": {\"fake\": \"9.0.0\"}\n}\n";
    let parsed = parse_package_json(source);
    assert_eq!(parsed.len(), 1);
    assert_eq!((&*parsed[0].0, &*parsed[0].1, parsed[0].2), ("real", "1.0.0", 3));
}

#[test]
fn malformed_npm_manifest_is_an_error_instead_of_an_empty_collection() {
    let root = std::env::temp_dir().join(format!("npm-malformed-{}", std::process::id()));
    fs::create_dir_all(&root).expect("fixture directory");
    let manifest = root.join("package.json");
    fs::write(&manifest, r#"{"dependencies":{"lost":"1.0.0"}"#).expect("fixture manifest");
    let error = collect_npm_manifests(&[manifest], &mut Vec::new()).expect_err("invalid JSON must fail");
    assert!(error.contains("package.json"), "{error}");
    fs::remove_dir_all(root).expect("remove fixture");
}
'''
p.write_text(text)
command=['rustfmt','--edition','2024','--config','skip_children=true',*files,'scripts/check-dependencies-latest-npm.rs']
r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(root/'rustfmt.stdout.log').write_bytes(r.stdout);(root/'rustfmt.stderr.log').write_bytes(r.stderr);r.check_returncode()
diff=subprocess.check_output(['git','diff','--',*files])
(root/'repair.diff').write_bytes(diff)
print(json.dumps({'drafted':True,'newRegressionTests':4,'hostedRegression':'checked_npm_inventory_excludes_untracked_packages_and_refuses_missing_tracked_files','nativeVerification':'pending CI; no local Rust compilation','sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}))
