import json,subprocess
from pathlib import Path
root=Path('/tmp/issue-1580-research/npm-compact-manifest-repair')
p=Path('scripts/check-dependencies-latest-npm.rs');text=p.read_text()
text=text.replace('''            return Some(members);''','''            // JSON objects use their last occurrence of a repeated key.
            let mut seen = std::collections::BTreeSet::new();
            members.retain(|(name, _, _)| !name.is_empty() || name.is_empty());
            let mut unique: Vec<_> = members.into_iter().rev()
                .filter(|(name, _, _)| seen.insert(name.clone())).collect();
            unique.reverse();
            return Some(unique);''')
text=text.replace('''            members.retain(|(name, _, _)| !name.is_empty() || name.is_empty());
''','')
p.write_text(text)
p=Path('scripts/check-dependencies-latest-parsers.rs');text=p.read_text()
start=text.index('/// A `"key": value` member on one line, when present.')
end=text.index('/// The hoisted resolutions',start)
text=text[:start]+text[end:];p.write_text(text)
p=Path('scripts/check-dependencies-latest-tests.rs');text=p.read_text()
text+=r'''
#[test]
fn npm_members_follow_last_key_wins_json_semantics() {
    let source = r#"{"dependencies":{"ignored":"0.0.0"},"dependencies":{"same":"0.0.0","same":"1.0.0","last":"2.0.0"}}"#;
    let parsed = parse_package_json(source);
    assert_eq!(
        parsed.into_iter().map(|(name, version, _, _)| (name, version)).collect::<Vec<_>>(),
        [("same".to_string(), "1.0.0".to_string()), ("last".to_string(), "2.0.0".to_string())]
    );
}

#[test]
fn npm_rewrite_tracks_escaped_names_and_multiline_values() {
    let source = "{\n \"dependencies\": {\"escaped\\u002dname\":\n \"^1.0.0\"},\n \"description\": \"^1.0.0\"\n}\n";
    let parsed = parse_package_json(source);
    assert_eq!(parsed.len(), 1);
    assert_eq!((&*parsed[0].0, parsed[0].2), ("escaped-name", 3));
    let dependency = Dependency {
        ecosystem: Ecosystem::Npm,
        name: parsed[0].0.clone(),
        declared: Some(parsed[0].1.clone()),
        resolved: "1.0.0".to_string(),
        path: "package.json".into(),
        line: parsed[0].2,
        blocked: None,
    };
    assert_eq!(
        rewrite_npm_line(source, &dependency, "2.0.0"),
        source.replacen("\"^1.0.0\"", "\"^2.0.0\"", 1)
    );
}
'''
p.write_text(text)
files=['scripts/check-dependencies-latest.rs','scripts/check-dependencies-latest-parsers.rs','scripts/check-dependencies-latest-tests.rs','scripts/check-dependencies-latest-npm.rs']
r=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',*files],capture_output=True)
(root/'refine-rustfmt.stdout.log').write_bytes(r.stdout);(root/'refine-rustfmt.stderr.log').write_bytes(r.stderr);r.check_returncode()
(root/'repair.diff').write_bytes(subprocess.check_output(['git','diff','--',*files]))
print(json.dumps({'drafted':True,'addedNativeTests':6,'sourceLines':{name:len(Path(name).read_text().splitlines()) for name in files}}))
