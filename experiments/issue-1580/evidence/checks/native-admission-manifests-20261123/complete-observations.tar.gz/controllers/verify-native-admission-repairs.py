import datetime,hashlib,json,os,shutil,subprocess
from pathlib import Path
root=Path('/tmp/issue-1580-research/native-admission-repair-checks');root.mkdir(exist_ok=False)
doc=Path('docs/case-studies/issue-1580/native-admission-manifests-20261123.md')
doc.write_text("""# Native admission dependency collection

The original hosted admission job for source 8682a89a84d391d987a967b5764a27c8d1d0c457 completed 283 workflow controls and failed two. Its [original job](https://github.com/link-assistant/formal-ai/actions/runs/45109737000/job/137479512542) reports the compact npm fixture at log lines 2014-2018 and the unreadable active Cargo harness at line 2024. The full original stream is retained in the repair evidence.

The active Cargo policy correctly requires all three maintained manifests. Both native admission checkouts excluded the issue-1558 harness; their release-registry directory pattern also did not restore its descendants after the experiment exclusion. The corrected patterns retain the harness manifest and the release-registry tree. A small real Git repository applies each actual workflow pattern, checks every active manifest and each existing owning lock, and verifies that an unrelated experiment stays excluded. The regression fails against the original workflow, fails after restoring only the harness, and passes after both corrections.

The npm collector previously recognized only line-shaped dependency headers, so a valid compact package.json produced no dependencies. It also kept interpreting root strings after a dependency object closed. Collection now uses JSON object boundaries and decoded member spans, preserving physical dependency order while honoring JSON's last-key-wins semantics. Version updates replace the selected JSON value span; identical description, script, or other dependency strings remain intact. Invalid JSON is an explicit collection error. The existing hosted compact-inventory test is unchanged.

Six additional native regressions cover compact JSON and blocked notes, precise compact updates and aliases, section closure, malformed manifests, repeated keys, and escaped names with multiline values. These run through the existing workflow_contracts admission target. Local verification uses the neighboring JavaScript tests, the relevant JavaScript gate twins and Rust formatting; no local Rust compilation is performed. Native success requires the next hosted source and is not inferred from these checks.

The [evidence manifest](../../../experiments/issue-1580/evidence/checks/native-admission-manifests-20261123/manifest.json) identifies the exact original streams, before/after fixture controls, changed source, and local verification receipts. Supplied controllers receive zero independent-authorship credit. The remaining issue-wide requirements, including actual artifact reruns, production practices, dependency closure and CodeQL semantic extraction coverage, remain unfinished. The PR stays draft and unmerged: https://github.com/link-assistant/formal-ai/pull/1581.
""")
Path('changelog.d/20261123_043000_native_admission_manifests.md').write_text("""---
bump: patch
---

### Fixed

- Retain all active dependency manifests in native admission checkouts. Parse npm dependency objects across compact and multiline JSON, and update only the selected dependency value while preserving surrounding content.
""")
with Path('experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write("""
## Native admission manifest failures on 8682, 2026-11-23

- [x] Push the preceding complete repair batch once as 8682a89a8, with main ae36c8ac6 merged and a clean local gate receipt.
- [x] Preserve the actual failing admission job: 283 controls pass, compact npm inventory and absent active Cargo harness fail.
- [x] Reproduce both sparse-pattern omissions with real Git, then draft both checkout corrections and the regression.
- [x] Draft structural JSON collection, exact member-value updates and six additional native regressions. Keep the existing failing compact fixture unchanged.
- [ ] Complete focused local verification and preserve complete original evidence.
- [ ] Wait for the entire 8682 cohort, collect all actionable failures, and push one complete repair batch.
- [ ] Verify the corrected native admission and both actual artifact rerun paths on its exact hosted source.
- [ ] Complete the remaining original issue and practice criteria before readiness or acceptance; the current native goal remains usage-limited, not complete.
""")
commands=[
('maintenance-tests',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/dependencies-maintenance-workflow.test.mjs']),
('currency-workflow-tests',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1169-dependencies-latest-workflow.test.mjs']),
('native-artifact-tests',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/native-test-artifact.test.mjs']),
('rustfmt',['rustfmt','--edition','2024','--config','skip_children=true','--check','scripts/check-dependencies-latest.rs','scripts/check-dependencies-latest-parsers.rs','scripts/check-dependencies-latest-tests.rs','scripts/check-dependencies-latest-npm.rs']),
('focused-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-ci-speed,check-runner-labels,workflows,check-javascript-dependencies,check-changelog-fragment-js-twin']),
('diff-whitespace',['git','diff','--check'])]
records=[]
for label,command in commands:
    before=int(Path('/sys/fs/cgroup/memory.current').read_text())
    with (root/(label+'.stdout.log')).open('wb') as out,(root/(label+'.stderr.log')).open('wb') as err:
        run=subprocess.run(command,stdout=out,stderr=err)
    row={'label':label,'command':command,'exitCode':run.returncode,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'memoryBefore':before,'memoryAfter':int(Path('/sys/fs/cgroup/memory.current').read_text())}
    records.append(row);(root/'records.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    run.check_returncode()
    if label=='focused-gates':
        for name in ['check-file-size','check-ci-speed','check-runner-labels','workflows','check-javascript-dependencies','check-changelog-fragment-js-twin']:
            shutil.copyfile(Path('experiments/formal_ai_subagent/sandboxes/gates')/(name+'.log'),root/(name+'.log'))
outcome={'complete':True,'exitCode':0,'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'nativeCompiled':False,'records':records,'independentAuthorshipCredit':0,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(root/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps({'complete':True,'commands':len(commands)}),flush=True)
