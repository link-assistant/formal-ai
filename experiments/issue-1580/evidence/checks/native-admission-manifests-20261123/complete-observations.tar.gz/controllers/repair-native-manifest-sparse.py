import datetime, json, os, subprocess
from pathlib import Path
root=Path('/tmp/issue-1580-research/native-manifest-sparse-repair')
root.mkdir(exist_ok=True)
test=Path('rust/tests/web/dependencies-maintenance-workflow.test.mjs')
workflow=Path('.github/workflows/native-type-check.yml')
assert not (root/'outcome.json').exists(), 'already executed'
(root/'test-before.mjs').write_bytes(test.read_bytes())
(root/'workflow-before.yml').write_bytes(workflow.read_bytes())
addition=r"""
// Run the real sparse patterns rather than treating an include-string match as checkout evidence.
test('both native admission checkouts retain every active Cargo manifest', {timeout: 15000}, () => {
  const native = YAML.parse(readFileSync(new URL('../../../.github/workflows/native-type-check.yml', import.meta.url), 'utf8'));
  const policy = JSON.parse(readFileSync(new URL('../../../scripts/dependency-manifests.json', import.meta.url), 'utf8'));
  const checkouts = native.jobs.clippy.steps.filter(step => ['native-checkout', 'native-checkout-retry'].includes(step.id));
  assert.equal(checkouts.length, 2);
  const directory = realpathSync(mkdtempSync(path.join(tmpdir(), 'formal-ai-native-manifests-')));
  const write = (name, content) => {
    mkdirSync(path.dirname(path.join(directory, name)), {recursive: true});
    writeFileSync(path.join(directory, name), content);
  };
  const git = (args, input) => execFileSync('git', [
    '-c', 'core.hooksPath=/dev/null', '-c', 'commit.gpgsign=false', ...args,
  ], {cwd: directory, input, encoding: 'utf8', timeout: 3000, maxBuffer: 256 * 1024});
  const omitted = 'experiments/issue-1580/unrelated-sparse-fixture.txt';
  try {
    for (const name of policy.activeCargo) write(name, '[dependencies]\n');
    write(omitted, 'unrelated experiment stays outside native admission\n');
    git(['init', '--quiet']);
    git(['add', '.']);
    git(['-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.invalid',
      'commit', '--quiet', '-m', 'native sparse input fixture']);
    for (const checkout of checkouts) {
      assert.equal(checkout.with['sparse-checkout-cone-mode'], false);
      git(['sparse-checkout', 'set', '--no-cone', '--stdin'], checkout.with['sparse-checkout']);
      for (const name of policy.activeCargo) {
        assert.equal(existsSync(path.join(directory, name)), true, checkout.id + ' omitted active manifest ' + name);
        assert.equal(readFileSync(path.join(directory, name), 'utf8'), '[dependencies]\n');
      }
      assert.equal(existsSync(path.join(directory, omitted)), false, 'retain the bounded experiment exclusion');
    }
  } finally {rmSync(directory, {recursive: true, force: true});}
});
"""
text=test.read_text().replace('{mkdtempSync,mkdirSync,readFileSync,realpathSync,rmSync,writeFileSync}', '{existsSync,mkdtempSync,mkdirSync,readFileSync,realpathSync,rmSync,writeFileSync}')
text=text.replace("import test from 'node:test';", "import test from 'node:test';\nimport YAML from 'yaml';")
test.write_text(text+addition)
records=[]
def run(label):
    command=['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)]
    result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (root/(label+'.stdout.log')).write_bytes(result.stdout)
    (root/(label+'.stderr.log')).write_bytes(result.stderr)
    records.append({'label':label,'command':command,'exitCode':result.returncode})
    return result
before=run('before')
assert before.returncode!=0, 'regression must fail before production fix'
assert b'native-checkout omitted active manifest experiments/issue-1558/rust-module-harness/Cargo.toml' in before.stdout
text=workflow.read_text()
boundary=text.index('  contract-build:')
first=text[:boundary]
needle='            /experiments/issue-1580/release-registry/\n'
assert first.count(needle)==2
first=first.replace(needle,'            /experiments/issue-1558/rust-module-harness/Cargo.toml\n'+needle)
workflow.write_text(first+text[boundary:])
after=run('after')
assert after.returncode==0, after.stdout.decode(errors='replace')[-4000:]
diff=subprocess.run(['git','diff','--',str(test),str(workflow)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert diff.returncode==0
(root/'repair.diff').write_bytes(diff.stdout)
outcome={'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'beforeFailed':True,'afterPassed':True,
'records':records,'scope':'Both actual admission sparse checkout patterns, every active Cargo manifest, bounded experiment exclusion; no native compilation.'}
(root/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome))
