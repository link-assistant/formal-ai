import datetime,json,subprocess
from pathlib import Path
root=Path('/tmp/issue-1580-research/native-manifest-sparse-repair')
p=Path('.github/workflows/native-type-check.yml')
text=p.read_text(); boundary=text.index('  contract-build:')
first=text[:boundary]
needle='/experiments/issue-1580/release-registry/\n'
assert first.count(needle)==2
p.write_text(first.replace(needle,'/experiments/issue-1580/release-registry/**\n')+text[boundary:])
t=Path('rust/tests/web/dependencies-maintenance-workflow.test.mjs')
text=t.read_text()
text=text.replace("  const omitted = 'experiments/issue-1580/unrelated-sparse-fixture.txt';","  const locks = policy.activeCargo.map(name => name.replace(/Cargo[.]toml$/u, 'Cargo.lock'))\n    .filter(name => existsSync(new URL('../../../' + name, import.meta.url)));\n  const omitted = 'experiments/issue-1580/unrelated-sparse-fixture.txt';")
text=text.replace("    for (const name of policy.activeCargo) write(name, '[dependencies]\\n');","    for (const name of policy.activeCargo) write(name, '[dependencies]\\n');\n    for (const name of locks) write(name, 'version = 4\\n');")
text=text.replace("      assert.equal(existsSync(path.join(directory, omitted)), false,", "      for (const name of locks) assert.equal(readFileSync(path.join(directory, name), 'utf8'), 'version = 4\\n', checkout.id + ' omitted owning lock ' + name);\n      assert.equal(existsSync(path.join(directory, omitted)), false,")
t.write_text(text)
command=['node','--max-old-space-size=256','--test','--test-concurrency=1',str(t)]
r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(root/'after-complete.stdout.log').write_bytes(r.stdout); (root/'after-complete.stderr.log').write_bytes(r.stderr)
r.check_returncode()
diff=subprocess.check_output(['git','diff','--',str(p),str(t)])
(root/'repair.diff').write_bytes(diff)
outcome={'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'beforeFailed':True,'intermediateFailed':True,'afterPassed':True,'tests':10,'command':command,'exitCode':0,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual Git sparse patterns for both native admission attempts; all active manifests and their tracked owning lockfiles; unrelated experiments still excluded. No local Rust compilation.'}
(root/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome))
