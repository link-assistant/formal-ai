from pathlib import Path
import subprocess, os, json, hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');os.chdir(r)
out=Path('/tmp/issue-1580-research/main-664e03-integration')
def git(*args): return subprocess.check_output(['git',*args])
assert git('rev-parse','HEAD').decode().strip()=='95656065f154cd2c27953847f21b734630ff50a8'
assert git('rev-parse','MERGE_HEAD').decode().strip()=='664e03feb0d337d7e891313cfc9c705bc3943136'
source='data/seed/meanings-occupations.lino'
parents={name:git('show',f':{stage}:{source}').decode() for name,stage in [('ours',2),('main',3)]}
def blocks(text):
 lines=text.splitlines(keepends=True);assert lines[0]=='meanings\n';result={};key=None
 for line in lines[1:]:
  if line.startswith('  ') and not line.startswith('   '):
   key=line.strip();assert key not in result;result[key]=[]
  assert key is not None;result[key].append(line)
 return {key:''.join(value) for key,value in result.items()}
ours,main=(blocks(parents[name]) for name in ['ours','main'])
assert not set(ours)&set(main)
union={**ours,**main};assert len(union)==9
merged='meanings\n'+''.join(union[key] for key in sorted(union))
for name in [source,'rust/embedded/'+source]: (r/name).write_text(merged)
for label,text in parents.items(): (out/f'occupations-{label}.lino').write_text(text)
(out/'occupations-merged.lino').write_text(merged)
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'}
commands=[('seed-registry-write',['node','scripts/generate-seed-registry.mjs','--write']),('worker-crate-write',['node','scripts/generate-worker-crate-modules.mjs','--write']),('runtime-features-write',['node','scripts/generate-runtime-feature-inventory.mjs','--write'])]
results=[]
for label,cmd in commands:
 with (out/(label+'.log')).open('w') as log: p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
 results.append({'name':label,'command':cmd,'exitCode':p.returncode});assert p.returncode==0,label
js=r/'js/worker/formal_ai_worker_crate_seed_registry.js';ts=r/'ts/worker/formal_ai_worker_crate_seed_registry.ts';ts.write_bytes(js.read_bytes())
doc=r/'docs/case-studies/issue-1580/generated-inventory-merge-repair.md'
body=doc.read_text();body=body.replace('independently rendered expectations','previously rendered canonical expectations');doc.write_text(body)
witness=Path('/tmp/issue-1580-research/inspect-merged-governed-witness.mjs').read_text().replace("out='/tmp/issue-1580-research/merged-governed-witness'","out='/tmp/issue-1580-research/main-664e03-governed-witness'")
Path('/tmp/issue-1580-research/inspect-main-664e03-governed-witness.mjs').write_text(witness)
(out/'conflict-resolution.json').write_text(json.dumps({'commands':results,'occupationConcepts':sorted(union),'unionSha256':hashlib.sha256(merged.encode()).hexdigest(),'nativeExecuted':False,'autonomousAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps(results),flush=True)
