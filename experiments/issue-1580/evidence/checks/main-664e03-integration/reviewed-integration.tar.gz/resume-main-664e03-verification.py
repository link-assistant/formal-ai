from pathlib import Path
import subprocess, os, json, time
r=Path('/tmp/gh-issue-solver-1794900398048');os.chdir(r)
out=Path('/tmp/issue-1580-research/main-664e03-integration');env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'}
assert subprocess.check_output(['git','diff','HEAD','--','rust/src/seed/embedded_files.rs'])==b'', 'canonical child changed; investigate formatting'
(out/'format-scope-correction.json').write_text(json.dumps({'initialFailure':'rustfmt was also applied to unchanged generated embedded_files.rs whose canonical layout differs from rustfmt defaults','unchangedFromCommittedParent':True,'canonicalGeneratorCheckPassed':True,'correctedScope':['rust/src/server.rs','rust/src/server/embeddings.rs','rust/src/seed/embedded_registry.rs'],'previousFailureRetained':'native-format.log','nativeExecuted':False},indent=2)+'\n')
def run(name,args):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 row={'name':name,'argv':args,'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3)}
 with (out/'checks.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
 print(json.dumps(row),flush=True);assert p.returncode==0,name
for name,args in [
 ('changed-native-format',['rustfmt','--edition','2024','--check','rust/src/server.rs','rust/src/server/embeddings.rs','rust/src/seed/embedded_registry.rs']),
 ('status-render',['node','scripts/render-status.mjs','--write']),
 ('progressive-plan',['node','scripts/render-progressive-plan.mjs','--write']),
 ('translation-currency',['node','scripts/translate-js-rust.mjs','--verify']),
]:run(name,args)
baseline='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8'
resolved=['data/meta/runtime-feature-coverage.json','data/seed/meanings-occupations.lino','rust/embedded/data/seed/meanings-occupations.lino','js/worker/formal_ai_worker_crate_seed_registry.js','ts/worker/formal_ai_worker_crate_seed_registry.ts',baseline]
run('stage-resolved-conflicts',['git','add',*resolved])
run('source-whitespace',['git','diff','--check'])
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],text=True).strip()
(out/'verification-complete.json').write_text(json.dumps({'focusedBehaviorAndCanonicalChecksPassed':True,'failedBroaderFormatterScopeRetained':True,'nativeExecuted':False,'autonomousAuthorshipCredit':0},indent=2)+'\n')
