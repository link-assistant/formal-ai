import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {mkdirSync,readFileSync,readdirSync,writeFileSync} from 'node:fs';
import {isAbsolute,relative,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {deserialize,serialize} from 'node:v8';
import {isDeepStrictEqual} from 'node:util';
import {gzipSync} from 'node:zlib';
const root=process.cwd(),out='/tmp/issue-1580-research/main-664e03-governed-witness';mkdirSync(out,{recursive:true});
const {specificationCases}=await import(pathToFileURL(root+'/scripts/lib/rust-specification-cases.mjs'));
const hash=data=>createHash('sha256').update(data).digest('hex');
const baseline='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8';
const inventory=specificationCases(root),cases=structuredClone(inventory.cases);
for(const item of cases)for(const fixture of item.program?.fixtures??[])if(isAbsolute(fixture.file)){
 const name=relative(root,fixture.file);assert(!name.startsWith('..'));fixture.file='repo:'+name;
}
const sourceManifest=readdirSync('rust/tests/unit/specification',{recursive:true}).map(String).filter(file=>file.endsWith('.rs')).sort().map(name=>{
 const path='rust/tests/unit/specification/'+name;return{path,sha256:hash(readFileSync(path))};
});
const candidate={inventory:{...inventory,cases},sourceManifest};
writeFileSync(out+'/candidate.v8',serialize(candidate));
writeFileSync(out+'/candidate.json.gz',gzipSync(JSON.stringify(candidate,null,2)+'\n',{mtime:0}));
const sources=new Map();
function verify(value){
 if(!value||typeof value!=='object')return;
 if(typeof value.sha256==='string'){
  let path=typeof value.path==='string'?value.path:typeof value.file==='string'&&value.file.startsWith('repo:')?value.file.slice(5):null;
  if(path){assert(!isAbsolute(path)&&!path.split('/').includes('..'));const actual=hash(readFileSync(path));assert.equal(value.sha256,actual,path);sources.set(path,actual);}
 }
 for(const child of Object.values(value))verify(child);
}
verify(candidate);
function normalized(value){
 if(!value||typeof value!=='object')return value;
 if(Array.isArray(value))return value.map(normalized);
 const result=Object.fromEntries(Object.entries(value).map(([key,item])=>[key,normalized(item)]));
 if(typeof value.sha256==='string'&&(typeof value.path==='string'||typeof value.file==='string'))result.sha256='<source-identity>';
 return result;
}
const report={readerSha256:hash(readFileSync('scripts/lib/rust-specification-cases.mjs')),candidateSha256:hash(serialize(candidate)),verifiedSourceFiles:[...sources],parents:{},nativeExecuted:false,autonomousAuthorshipCredit:0};
for(const [label,raw] of [['ours',readFileSync(baseline)],['main',execFileSync('git',['show','MERGE_HEAD:'+baseline],{maxBuffer:16*1024*1024})]]){
 writeFileSync(out+'/'+label+'.v8.gz',gzipSync(raw,{mtime:0}));const old=deserialize(raw);
 const parent={sha256:hash(raw),counts:{before:{total:old.inventory.total,cases:old.inventory.cases.length,unsupported:old.inventory.unsupported.length},after:{total:inventory.total,cases:cases.length,unsupported:inventory.unsupported.length}},changedCases:[],changedUnsupported:[],sourceManifestBefore:old.sourceManifest,sourceManifestAfter:sourceManifest};
 for(const [field,target] of [['cases','changedCases'],['unsupported','changedUnsupported']]){
  const before=new Map(old.inventory[field].map(item=>[item.id,item]));const after=new Map(candidate.inventory[field].map(item=>[item.id,item]));
  for(const id of new Set([...before.keys(),...after.keys()]))if(!isDeepStrictEqual(before.get(id),after.get(id))){
   const first=before.get(id),second=after.get(id);const file=label+'-'+field+'-'+hash(id).slice(0,16)+'.json';
   writeFileSync(out+'/'+file,JSON.stringify({id,before:first??null,after:second??null},null,2)+'\n');
   parent[target].push({id,file,sourceIdentityOnly:isDeepStrictEqual(normalized(first),normalized(second)),keysChanged:[...new Set([...Object.keys(first??{}),...Object.keys(second??{})])].filter(key=>!isDeepStrictEqual(first?.[key],second?.[key]))});
  }
 }
 report.parents[label]=parent;
}
writeFileSync(out+'/report.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({sourcesVerified:sources.size,parents:Object.fromEntries(Object.entries(report.parents).map(([name,parent])=>[name,{counts:parent.counts,cases:parent.changedCases.length,semanticCaseChanges:parent.changedCases.filter(row=>!row.sourceIdentityOnly),unsupported:parent.changedUnsupported}]))},null,2));
