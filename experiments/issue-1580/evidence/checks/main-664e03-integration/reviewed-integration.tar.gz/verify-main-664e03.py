from pathlib import Path
import subprocess, os, json, time, hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');os.chdir(r)
out=Path('/tmp/issue-1580-research/main-664e03-integration');witness=Path('/tmp/issue-1580-research/main-664e03-governed-witness')
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'}
def run(name,args):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 row={'name':name,'argv':args,'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3)}
 with (out/'checks.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
 print(json.dumps(row),flush=True)
 assert p.returncode==0,name
report=json.loads((witness/'report.json').read_text())
assert report['readerSha256']=='861c6c5b40cfc8f4e99ad0ebece2cc3c20f941c6a1103dd5e8e70813c40ee0ca'
assert len(report['parents']['ours']['changedCases'])==4
assert not report['parents']['ours']['changedUnsupported']
assert all(row['sourceIdentityOnly'] for row in report['parents']['ours']['changedCases'])
assert all(row['sourceIdentityOnly'] for row in report['parents']['main']['changedCases'])
def changes(a,b,at=''):
 if type(a)!=type(b):return [{'path':at,'before':a,'after':b}]
 if isinstance(a,dict):
  assert a.keys()==b.keys();return [row for key in a for row in changes(a[key],b[key],at+'/'+str(key))]
 if isinstance(a,list):
  assert len(a)==len(b);return [row for i,(first,second) in enumerate(zip(a,b)) for row in changes(first,second,at+'/'+str(i))]
 return [] if a==b else [{'path':at,'before':a,'after':b}]
all_diffs=[]
for row in report['parents']['ours']['changedCases']:
 case=json.loads((witness/row['file']).read_text());diff=changes(case['before'],case['after']);assert diff
 assert all(d['path'].endswith('/sha256') for d in diff)
 all_diffs.append({'id':case['id'],'differences':diff})
(out/'baseline-leaf-differences.json').write_text(json.dumps(all_diffs,indent=2)+'\n')
run('guarded-baseline-refresh',['node','rust/tests/web/rust-specification-unicode-identifiers.test.mjs','--refresh-reviewed-baseline','--reviewed-reader-sha='+report['readerSha256'],'--previous-baseline-sha='+report['parents']['ours']['sha256']])
baseline='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8'
compare="import assert from 'node:assert/strict';import{readFileSync,writeFileSync}from'node:fs';import{deserialize}from'node:v8';import{createHash}from'node:crypto';const a=readFileSync(process.argv[1]),b=readFileSync(process.argv[2]);assert.deepStrictEqual(deserialize(a),deserialize(b));const sha=x=>createHash('sha256').update(x).digest('hex');console.log(JSON.stringify({completeObjectsEqual:true,candidateSha256:sha(a),canonicalSha256:sha(b),byteEqual:a.equals(b)}));"
run('baseline-complete-object-equality',['node','--input-type=module','-e',compare,str(witness/'candidate.v8'),baseline])
(witness/'canonical.v8').write_bytes(Path(baseline).read_bytes())
for name,args in [
 ('seed-registry-check',['node','scripts/generate-seed-registry.mjs','--check']),
 ('worker-crate-check',['node','scripts/generate-worker-crate-modules.mjs','--check']),
 ('runtime-feature-check',['node','scripts/generate-runtime-feature-inventory.mjs','--check']),
 ('embeddings-http',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/issue-1591-embeddings.test.mjs']),
 ('default-branch-policy',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/default-branch-build-policy.test.mjs']),
 ('unicode-identifiers',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/rust-specification-unicode-identifiers.test.mjs']),
 ('fixture-integrity',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/rust-specification-fixture-integrity.test.mjs']),
 ('seed-headroom',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/seed-registry-headroom.test.mjs']),
 ('native-format',['rustfmt','--edition','2024','--check','rust/src/server.rs','rust/src/server/embeddings.rs','rust/src/seed/embedded_registry.rs','rust/src/seed/embedded_files.rs']),
 ('status-render',['node','scripts/render-status.mjs','--write']),
 ('progressive-plan',['node','scripts/render-progressive-plan.mjs','--write']),
 ('translation-currency',['node','scripts/translate-js-rust.mjs','--verify']),
]:run(name,args)
resolved=['data/meta/runtime-feature-coverage.json','data/seed/meanings-occupations.lino','rust/embedded/data/seed/meanings-occupations.lino','js/worker/formal_ai_worker_crate_seed_registry.js','ts/worker/formal_ai_worker_crate_seed_registry.ts',baseline]
run('stage-resolved-conflicts',['git','add',*resolved])
run('source-whitespace',['git','diff','--check'])
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],text=True).strip()
(out/'verification-complete.json').write_text(json.dumps({'allFocusedChecksPassed':True,'nativeExecuted':False,'autonomousAuthorshipCredit':0},indent=2)+'\n')
