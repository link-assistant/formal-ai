import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {splitMeaningRecords} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/split-meaning-records.mjs';
import {splitResponseFamilies} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/split-response-families.mjs';
import {parseRegistry,canonicalize,renderRegistry,registryHeader} from '/tmp/gh-issue-solver-1794900398048/scripts/generate-seed-registry.mjs';
const root='/tmp/gh-issue-solver-1794900398048/',scratch='/tmp/issue-1580-research/seed-record-headroom/';
const pairs=[
 ['meanings-response-intents','meanings-response-intents-additional','meaning'],
 ['meanings-response-intents-handlers','meanings-response-intents-handlers-additional','meaning'],
 ['meanings-routing-vocabulary','meanings-routing-vocabulary-additional','meaning'],
 ['multilingual-responses-synthesis','multilingual-responses-synthesis-runtime','response'],
];
const registrySource=readFileSync(root+'data/meta/seed-registry.lino','utf8'),registry=parseRegistry(registrySource),result=[];
for(const [first,second,kind] of pairs){
 const original=readFileSync(scratch+first+'.original.lino','utf8');
 assert.equal(readFileSync(root+'data/seed/'+first+'.lino','utf8'),original);
 assert(!registry.seeds.some(seed=>seed.name===second));
 const split=(kind==='meaning'?splitMeaningRecords:splitResponseFamilies)(original,850);
 assert.equal(split.shards.length,2);
 assert.equal(split.shards.map(shard=>shard.slice(split.header.length)).join(''),original.slice(split.header.length));
 const existing=registry.seeds.find(seed=>seed.name===first);assert(existing&&existing.bundle&&existing.web&&existing.lexicon.has(kind));
 registry.seeds.push({...existing,name:second,lexicon:new Set(existing.lexicon)});
 for(const [index,name] of [first,second].entries())writeFileSync(root+'data/seed/'+name+'.lino',split.shards[index]);
 result.push({first,second,kind,originalSha256:createHash('sha256').update(original).digest('hex'),inverseExactlyOriginal:true,shardLines:split.shards.map(shard=>shard.split('\n').length-1),recordIds:split.recordIds??null,records:split.records??null,families:split.families??null});
}
writeFileSync(root+'data/meta/seed-registry.lino',renderRegistry(canonicalize(registry),registryHeader(registrySource)));
process.stdout.write(JSON.stringify(result,null,2)+'\n');
