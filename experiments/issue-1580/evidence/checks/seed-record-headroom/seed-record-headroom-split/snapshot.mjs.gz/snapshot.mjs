import {readFileSync} from 'node:fs';
import {installHost} from '/tmp/gh-issue-solver-1794900398048/js/agentic/host.mjs';
import {parseLino} from '/tmp/gh-issue-solver-1794900398048/js/server/lino.mjs';
import {lexicon} from '/tmp/gh-issue-solver-1794900398048/js/agentic/crate/seed_meanings.mjs';
import {multilingualResponses} from '/tmp/gh-issue-solver-1794900398048/js/agentic/crate/seed.mjs';
installHost({parseLino,readText:path=>readFileSync('/tmp/gh-issue-solver-1794900398048/'+path,'utf8')});
const meanings=lexicon(),responses=multilingualResponses();
if(meanings.length<100||responses.length<100)throw Error('nonempty complete runtime inventory required');
process.stdout.write(JSON.stringify({meanings,responses})+'\n');
