from pathlib import Path
import hashlib,json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'seed-record-headroom-split-retry'
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(json.dumps({'pid':worker.pid,'finite':True}));sys.exit(0)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=256';commands=[]
def run(name,args):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:r=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'arguments':args,'exitCode':r.returncode};commands.append(row);(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(row),flush=True);assert r.returncode==0,row
try:
    owner=root/'rust/tests/web/seed-data-headroom.test.mjs';text=owner.read_text();text=text.replace("assert(row.bundle&&row.web&&row.lexicon.has(kind),name+' retains all original consumers');","assert(row.bundle&&row.lexicon.has(kind),name+' retains its bundled lexicon consumer');\n    assert.equal(row.web,kind==='response',name+' retains original browser eligibility');").replace("assert(web.includes('\"seed/'+name+'.lino\"'),name+' remains browser-fetchable');","assert.equal(web.includes('\"seed/'+name+'.lino\"'),row.web,name+' browser registration follows original eligibility');");owner.write_text(text)
    committed=json.loads((scratch/'seed-registry-headroom-commit-retry/outcome.json').read_text());assert not committed['pushed']
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==committed['head']
    snapshot=out/'snapshot.mjs';snapshot.write_text(r'''import {readFileSync} from 'node:fs';
import {installHost} from '/tmp/gh-issue-solver-1794900398048/js/agentic/host.mjs';
import {parseLino} from '/tmp/gh-issue-solver-1794900398048/js/server/lino.mjs';
import {lexicon} from '/tmp/gh-issue-solver-1794900398048/js/agentic/crate/seed_meanings.mjs';
import {multilingualResponses} from '/tmp/gh-issue-solver-1794900398048/js/agentic/crate/seed.mjs';
installHost({parseLino,readText:path=>readFileSync('/tmp/gh-issue-solver-1794900398048/'+path,'utf8')});
const meanings=lexicon(),responses=multilingualResponses();
if(meanings.length<100||responses.length<100)throw Error('nonempty complete runtime inventory required');
process.stdout.write(JSON.stringify({meanings,responses})+'\n');
''')
    run('before-runtime',['node',str(snapshot)])
    mutation=out/'split.mjs';mutation.write_text(r'''import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {splitMeaningRecords} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/split-meaning-records.mjs';
import {splitResponseFamilies} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/split-response-families.mjs';
import {parseRegistry,canonicalize,renderRegistry,registryHeader} from '/tmp/gh-issue-solver-1794900398048/scripts/generate-seed-registry.mjs';
const root='/tmp/gh-issue-solver-1794900398048/',scratch='/tmp/issue-1580-research/seed-record-headroom/';
const pairs=[
 ['meanings-response-intents','meanings-response-intents-additional','meaning'],
 ['meanings-response-intents-handlers','meanings-response-intents-handlers-additional','meaning'],
 ['meanings-routing-vocabulary','meanings-routing-vocabulary-additional','meaning'],
 ['multilingual-responses-synthesis','multilingual-responses-synthesis-runtime','response'],
];
const registrySource=readFileSync(root+'data/meta/seed-registry.lino','utf8'),registry=parseRegistry(registrySource),result=[];
for(const [first,second,kind] of pairs){
 const original=readFileSync(scratch+first+'.original.lino','utf8');
 assert.equal(readFileSync(root+'data/seed/'+first+'.lino','utf8'),original);
 assert(!registry.seeds.some(seed=>seed.name===second));
 const split=(kind==='meaning'?splitMeaningRecords:splitResponseFamilies)(original,850);
 assert.equal(split.shards.length,2);
 assert.equal(split.shards.map(shard=>shard.slice(split.header.length)).join(''),original.slice(split.header.length));
 const existing=registry.seeds.find(seed=>seed.name===first);assert(existing&&existing.bundle&&existing.lexicon.has(kind));assert.equal(existing.web,kind==='response');
 registry.seeds.push({...existing,name:second,lexicon:new Set(existing.lexicon)});
 for(const [index,name] of [first,second].entries())writeFileSync(root+'data/seed/'+name+'.lino',split.shards[index]);
 result.push({first,second,kind,originalSha256:createHash('sha256').update(original).digest('hex'),inverseExactlyOriginal:true,shardLines:split.shards.map(shard=>shard.split('\n').length-1),recordIds:split.recordIds??null,records:split.records??null,families:split.families??null});
}
writeFileSync(root+'data/meta/seed-registry.lino',renderRegistry(canonicalize(registry),registryHeader(registrySource)));
process.stdout.write(JSON.stringify(result,null,2)+'\n');
''')
    run('split',['node',str(mutation)])
    run('registry',['node','scripts/generate-seed-registry.mjs','--write'])
    run('package-mirror',['node','scripts/mirror-package-data.mjs','--write'])
    run('web-mirror',['bash','scripts/sync-seed.sh'])
    run('after-runtime',['node',str(snapshot)])
    before=(out/'before-runtime.stdout').read_bytes();after=(out/'after-runtime.stdout').read_bytes();assert before==after,'complete ordered runtime arrays changed'
    data=json.loads(before)
    run('headroom',['node','--test','--test-concurrency=1','rust/tests/web/seed-data-headroom.test.mjs'])
    run('meaning-splitter',['node','--test','--test-concurrency=1','rust/tests/web/meaning-record-splitting.test.mjs'])
    run('response-splitter',['node','--test','--test-concurrency=1','rust/tests/web/response-family-splitting.test.mjs'])
    run('bundle-parity',['node','--test','--test-concurrency=1','rust/tests/web/bundled-seed-source-parity.test.mjs'])
    result={'split':True,'exactOrderedRuntimeBytes':True,'meaningCount':len(data['meanings']),'responseCount':len(data['responses']),'runtimeSha256':hashlib.sha256(before).hexdigest(),'independentAuthorshipCredit':0,'fullIssueComplete':False};(out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
