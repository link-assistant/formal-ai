from pathlib import Path
source=Path('/tmp/issue-1580-research/finish-seed-record-headroom.py').read_text()
source=source.replace("out=scratch/'seed-record-headroom-final';","out=scratch/'seed-record-headroom-commit-retry';")
start=source.index("    run('worker-registry'")
end=source.index("    counts=",start)
source=source[:start]+"""    prior=json.loads((scratch/'seed-record-headroom-final/commands.json').read_text())
    assert [row['name'] for row in prior if row['exitCode']!=0]==['format']
    run('format',['rustfmt','--check','--config','skip_children=true,use_small_heuristics=Max','--edition','2024','rust/src/seed/embedded_registry.rs','rust/src/seed/embedded_files.rs'])
"""+source[end:]
source=source.replace("'seed-record-headroom-verification']:", "'seed-record-headroom-verification','seed-record-headroom-final']:")
source=source.replace("'finish-seed-record-headroom.py']:", "'finish-seed-record-headroom.py','retry-seed-record-headroom-commit.py']:")
source=source.replace("'ts/worker/formal_ai_worker_crate_seed_registry.ts'])", "'ts/worker/formal_ai_worker_crate_seed_registry.ts','ts/seed-files.ts'])")
source=source.replace("No native build was run locally.\\n')", "No native build was run locally. The generated Rust includes retain the generator-owned 100-column layout; rustfmt with use_small_heuristics=Max verifies that layout. The failed default-heuristic check is retained and receives no passing credit.\\n')")
exec(compile(source,__file__,'exec'))
