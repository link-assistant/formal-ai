from pathlib import Path
import gzip,hashlib,json,os,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
out=scratch/'seed-record-headroom-final';evidence=root/'experiments/issue-1580/evidence/checks/seed-record-headroom'
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:
        worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(json.dumps({'pid':worker.pid,'finite':True}));sys.exit(0)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0'
env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH'];commands=[]
def run(name,args):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        r=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'arguments':args,'exitCode':r.returncode};commands.append(row)
    (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(row),flush=True);assert r.returncode==0,row
try:
    initial=scratch/'seed-record-headroom-verification'
    previous=json.loads((initial/'outcome.json').read_text());assert previous['warnings']==66
    failed=re.findall(r'^FAIL (\S+)',(initial/'all-local-gates.stdout').read_text(),re.M);assert failed==['check-worker-crate-modules']
    run('worker-registry',['node','scripts/generate-worker-crate-modules.mjs','--write'])
    run('typescript-mirror',['node','scripts/translate-es.mjs','--write'])
    for gate in ['check-worker-crate-modules','check-language-parity','check-generated-files','check_js_rust_translation','check-seed-registry']:
        run(gate,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate])
    run('worker-consumers',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/bundled-seed-source-parity.test.mjs'])
    run('format',['rustfmt','--check','--config','skip_children=true','--edition','2024','rust/src/seed/embedded_registry.rs','rust/src/seed/embedded_files.rs'])
    counts={key:len(re.findall('^'+key+r' ',(initial/'all-local-gates.stdout').read_text(),re.M)) for key in ['PASS','SKIP','FAIL']}
    note=root/'docs/case-studies/issue-1580/seed-record-headroom-checkpoint.md'
    note.write_text(note.read_text()+f'\nThe complete 141-gate local run recorded {counts["PASS"]} passes, {counts["SKIP"]} explicit hosted-only skips and one stale generated worker registry. Regenerating that registry and the TypeScript mirror repairs the failure; all five affected gate retries pass. The warning inventory falls from 74 to 66. No native build was run locally.\n')
    plan=root/'experiments/issue-1580/work-plan.md'
    plan.write_text(plan.read_text()+'\n- Seed checkpoint validation: all 141 local gates were attempted; the only failure was a stale generated worker registry, repaired through its maintained generator and TypeScript translator. All affected gate retries pass. The current warning inventory is 66; those remaining owners and hosted full-suite failures remain open.\n')
    evidence.mkdir(exist_ok=False);records=[]
    def archive(alias,file):
        raw=file.read_bytes();packed=gzip.compress(raw,mtime=0);target=evidence/(alias+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(packed)
        records.append({'file':alias+'.gz','bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
    for name in ['seed-record-headroom','seed-record-headroom-split','seed-record-headroom-split-retry','seed-record-headroom-verification']:
        for file in sorted((scratch/name).rglob('*')):
            if file.is_file():archive(name+'/'+str(file.relative_to(scratch/name)),file)
    for name in ['draft-seed-record-headroom.py','split-seed-record-headroom.py','verify-seed-record-headroom.py','finish-seed-record-headroom.py']:
        archive('helpers/'+name,scratch/name)
    for file in sorted(out.iterdir()):
        if file.is_file() and file.name not in ['worker.log','pid.json']:archive('final/'+file.name,file)
    (evidence/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
    run('stage',['git','add','--',str(evidence.relative_to(root)),str(note.relative_to(root)),str(plan.relative_to(root)),'js/worker/formal_ai_worker_crate_seed_registry.js','ts/worker/formal_ai_worker_crate_seed_registry.ts'])
    run('naming',['node','scripts/measure-abbreviations.mjs','--check'])
    staged=subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=ACMRT','-z'],cwd=root).decode().split('\0')[:-1]
    assert not any('/evidence/ci/' in name for name in staged)
    run('secrets',['bash','scripts/check-secrets.sh',*staged]);run('whitespace',['git','diff','--cached','--check'])
    run('commit',['git','-c','gc.auto=0','commit','-m','Split complete seed records while preserving runtime priority'])
    (out/'outcome.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'warnings':66,'allLocalGatesAttempted':141,'affectedRetriesPassed':True,'pushed':False,'fullIssueComplete':False},indent=2)+'\n')
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
