from pathlib import Path
import json,os,re,shutil,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'seed-record-headroom-verification'
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(json.dumps({'pid':worker.pid,'finite':True}));sys.exit(0)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';commands=[]
def run(name,args):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:r=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'arguments':args,'exitCode':r.returncode};commands.append(row);(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(row),flush=True);return r.returncode
try:
    result=json.loads((scratch/'seed-record-headroom-split-retry/outcome.json').read_text());assert result['exactOrderedRuntimeBytes']
    owner=root/'rust/tests/web/seed-data-headroom.test.mjs'
    owner.write_text(owner.read_text()+r'''

test('moved meanings retain priority and moved multilingual templates remain reachable',async()=>{
  const {installHost}=await import('../../../js/agentic/host.mjs');
  const {parseLino}=await import('../../../js/server/lino.mjs');
  const {lexicon,parseLexiconText,meaningFiles}=await import('../../../js/agentic/crate/seed_meanings.mjs');
  const {responseFor}=await import('../../../js/agentic/crate/seed.mjs');
  const read=path=>readFileSync(root+'/'+path,'utf8');
  installHost({parseLino,readText:read});
  const actual=lexicon(),files=meaningFiles();
  const boundaries=[
    ['meanings-response-intents-additional','web_open_in_new_tab','calendar-duration-label'],
    ['meanings-response-intents-handlers-additional','installation_conversion_heading','opaque-label'],
    ['meanings-routing-vocabulary-additional','install_steps','operand'],
  ];
  for(const [name,first,last] of boundaries){
    const path='data/seed/'+name+'.lino',index=files.indexOf(path);assert(index>=0);
    const entries=parseLexiconText(read(path));assert.equal(entries[0].slug,first);assert.equal(entries.at(-1).slug,last);
    const start=files.slice(0,index).reduce((total,file)=>total+parseLexiconText(read(file)).length,0);
    assert.deepEqual(actual.slice(start,start+entries.length),entries,'complete moved records retain declaration priority');
  }
  const responses=parseLino(read('data/seed/multilingual-responses-synthesis-runtime.lino')).children.filter(child=>child.name==='response');
  assert.equal(responses[0].id,'response_coding_rosetta_passed_en');
  assert.equal(responses.at(-1).id,'response_nl_tool_browser_unavailable_es');
  for(const entry of responses){
    const value=name=>entry.children.find(child=>child.name===name)?.value;
    assert.equal(responseFor(value('intent'),value('language')),value('text'),entry.id+' remains an actual localized lookup');
  }
});
''')
    note=root/'docs/case-studies/issue-1580/seed-record-headroom-checkpoint.md';note.write_text('''# Complete seed records retain headroom

Four canonical sources and their package mirrors produced eight real file-size
warnings. Three meaning inventories now split at complete records and the
synthesis responses split at complete contiguous multilingual intent families.
Every authored record byte and its order survive an exact inverse, including
grounding strings, text and variants. Headers repeat in the new independent
files. Both scanner thresholds remain unchanged.

The generated registry preserves each original consumer flag. Meaning sources
remain bundled lexicon inputs; response sources also remain browser inputs.
All package mirrors match canonical bytes and the browser mirror regenerates.
The declaration owner and verified bundle include retain headroom.

Complete runtime snapshots before and after contain 2,459 ordered meanings and
5,157 ordered responses and are byte-identical. Focused controls cover the real
warning failure, indivisible records, duplicate identity rejection, unknown
roots, exact bytes, moved record priority and every moved localized response.
The first draft incorrectly assumed that meaning sources were browser inputs;
its failed check receives no credit and changed no seed files.

Full local gates and hosted validation are recorded separately. Native
compilation remains hosted. Supplied implementation and commands receive zero
independent authorship or reasoning credit. Full issue acceptance remains open.
''')
    fragment=root/'changelog.d/issue-1580-seed-record-headroom.md';fragment.write_text('''---
bump: patch
---

Split complete meaning records and multilingual synthesis families while
preserving lexicon priority, localized lookups and all original consumers.
''')
    plan=root/'experiments/issue-1580/work-plan.md';plan.write_text(plan.read_text()+'\n- Split four oversized seed inputs at complete meaning records or multilingual families. Exact record-byte inverses and complete ordered runtime snapshots preserve all 2,459 meanings and 5,157 responses. Eight warning owners are repaired without changing thresholds or consumer eligibility. Full local gates and hosted execution remain separately required; supplied work has zero independent-authorship credit. See [seed record headroom](../../docs/case-studies/issue-1580/seed-record-headroom-checkpoint.md).\n')
    pairs=json.loads((scratch/'seed-record-headroom-split-retry/split.stdout').read_text());files=[]
    for row in pairs:
        for name in [row['first'],row['second']]:
            for parent in ['data/seed/','rust/embedded/data/seed/']:files.append(parent+name+'.lino')
    files+=['data/meta/seed-registry.lino','js/seed-files.js','rust/src/seed/embedded_files.rs','rust/src/seed/embedded_registry.rs','scripts/lib/split-meaning-records.mjs','rust/tests/web/meaning-record-splitting.test.mjs','rust/tests/web/seed-data-headroom.test.mjs',str(note.relative_to(root)),str(fragment.relative_to(root)),'experiments/issue-1580/work-plan.md']
    assert run('stage',['git','add','--',*files])==0
    focused=[('data-headroom','rust/tests/web/seed-data-headroom.test.mjs'),('meaning-splitter','rust/tests/web/meaning-record-splitting.test.mjs'),('provenance','rust/tests/web/generated-seed-owner-provenance.test.mjs'),('registry-headroom','rust/tests/web/seed-registry-headroom.test.mjs')]
    for name,file in focused:assert run(name,['node','--max-old-space-size=256','--test','--test-concurrency=1',file])==0
    run('all-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs'])
    detail=out/'gate-details';detail.mkdir()
    for line in (out/'all-local-gates.stdout').read_text().splitlines():
        match=re.match(r'^(?:PASS|FAIL) (\S+) ',line)
        if match:
            name=re.sub(r'[^\w.#-]','_',match[1])+'.log';shutil.copyfile(root/'experiments/formal_ai_subagent/sandboxes/gates'/name,detail/name)
    warnings=re.findall(r'^::warning file=([^:]+)::',(detail/'check-file-size.log').read_text(),re.M)
    result={'complete':all(row['exitCode']==0 for row in commands),'warnings':len(warnings),'warningOwners':warnings,'nativeBuildRun':False,'independentAuthorshipCredit':0,'fullIssueComplete':False};(out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='warningOwners'}),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
