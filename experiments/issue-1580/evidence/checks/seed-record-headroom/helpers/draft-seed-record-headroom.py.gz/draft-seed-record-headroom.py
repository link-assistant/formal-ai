from pathlib import Path
import json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'seed-record-headroom'
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(json.dumps({'pid':worker.pid,'finite':True}));sys.exit(0)
environment=os.environ.copy();environment['NODE_OPTIONS']='--max-old-space-size=256';records=[]
def run(name,args,expected=0):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:r=subprocess.run(args,cwd=root,env=environment,stdout=stdout,stderr=stderr)
    records.append({'name':name,'arguments':args,'exitCode':r.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records[-1]),flush=True);assert (r.returncode==0)==(expected==0),records[-1]
try:
    helper=root/'scripts/lib/split-meaning-records.mjs';helper.write_text(r'''/** Split complete ordered meaning records without rewriting any record byte. */
export function splitMeaningRecords(source,maximumLines) {
  if(typeof source!=='string'||!source.endsWith('\n')||!Number.isSafeInteger(maximumLines)||maximumLines<2)
    throw Error('complete source and positive line budget required');
  const lines=source.split('\n');lines.pop();
  const root=lines.findIndex(line=>line.trim()&&!line.trimStart().startsWith('#'));
  if(root<0||lines[root]!=='meanings')throw Error('one meanings root required');
  const prefix=lines.slice(0,root+1),records=[];let current=null;
  for(const line of lines.slice(root+1)){
    const declaration=/^  ([A-Za-z_][A-Za-z_0-9-]*)\s*$/u.exec(line);
    if(declaration){
      if(current)records.push(current);
      current={id:declaration[1],lines:[line]};
    }else if(!line.trim()||line.trimStart().startsWith('#')){
      (current?.lines??prefix).push(line);
    }else{
      if(!current||!line.startsWith('    '))throw Error('unknown root child or partial meaning');
      current.lines.push(line);
    }
  }
  if(current)records.push(current);
  if(!records.length)throw Error('empty meanings');
  const ids=new Set();
  for(const record of records){
    if(ids.has(record.id))throw Error('ambiguous meaning identity');ids.add(record.id);
    if(!record.lines.slice(1).some(line=>line.startsWith('    ')&&line.trim()&&!line.trimStart().startsWith('#')))
      throw Error('empty meaning record');
  }
  const header=prefix.join('\n')+'\n',shards=[];
  const targetRecords=Math.ceil(records.length/Math.ceil(lines.length/maximumLines));
  let pending=[],used=prefix.length;
  const emit=()=>{
    if(pending.length)shards.push(header+pending.map(record=>record.lines.join('\n')+'\n').join(''));
    pending=[];used=prefix.length;
  };
  for(const record of records){
    if(prefix.length+record.lines.length>maximumLines)throw Error('complete meaning exceeds unchanged line budget');
    if(pending.length>=targetRecords||used+record.lines.length>maximumLines)emit();
    pending.push(record);used+=record.lines.length;
  }
  emit();
  if(shards.some(shard=>shard.split('\n').length-1>maximumLines))throw Error('line budget exceeded');
  if(shards.map(shard=>shard.slice(header.length)).join('')!==source.slice(header.length))
    throw Error('meaning record bytes or order changed');
  return {header,shards,recordIds:records.map(record=>record.id),maximumLines};
}
''')
    test=root/'rust/tests/web/meaning-record-splitting.test.mjs';test.write_text(r'''import assert from 'node:assert/strict';
import test from 'node:test';
import {splitMeaningRecords} from '../../../scripts/lib/split-meaning-records.mjs';

const source='# Preserve authored grounding and text.\nmeanings\n  first\n    role action\n    example "{value}\\nfirst"\n\n  second\n    role concept\n    grounding "data/seed/arbitrary.lino"\n';
test('complete meaning records retain exact bytes, order and the root header',()=>{
  const result=splitMeaningRecords(source,7);
  assert.deepEqual(result.recordIds,['first','second']);assert.equal(result.shards.length,2);
  assert.equal(result.shards.map(shard=>shard.slice(result.header.length)).join(''),source.slice(result.header.length));
  assert(result.shards.every(shard=>shard.startsWith(result.header)&&shard.split('\n').length-1<=7));
});
test('unknown roots, partial records and duplicate identities refuse a split',()=>{
  for(const candidate of [source.replace('\nmeanings\n','\nresponses\n'),source+'\nother-root\n',source.replace('    role action','  unknown field'),source+'  first\n    role duplicate\n',source+'  empty\n',source.slice(0,-1)]){
    assert.throws(()=>splitMeaningRecords(candidate,7));
  }
  assert.throws(()=>splitMeaningRecords(source,1));
});
test('an indivisible meaning fails rather than raising its supplied budget',()=>{
  assert.throws(()=>splitMeaningRecords(source,5),/complete meaning exceeds/u);
});
''')
    ownerTest=root/'rust/tests/web/seed-data-headroom.test.mjs';ownerTest.write_text(r'''import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import test from 'node:test';
import {checkListedFiles} from '../../../scripts/check-file-size.mjs';
import {parseRegistry} from '../../../scripts/generate-seed-registry.mjs';

const root=fileURLToPath(new URL('../../../',import.meta.url)).replace(/\/$/u,'');
const pairs=[
  ['meanings-response-intents','meanings-response-intents-additional','meaning'],
  ['meanings-response-intents-handlers','meanings-response-intents-handlers-additional','meaning'],
  ['meanings-routing-vocabulary','meanings-routing-vocabulary-additional','meaning'],
  ['multilingual-responses-synthesis','multilingual-responses-synthesis-runtime','response'],
];
test('canonical seed records and package mirrors retain headroom without losing consumers',()=>{
  const paths=pairs.flatMap(([first,second])=>[first,second].flatMap(name=>['data/seed/'+name+'.lino','rust/embedded/data/seed/'+name+'.lino']));
  assert.deepEqual(checkListedFiles(root,new Set(paths)),{warnings:[],violations:[],embeddedDataViolations:[]});
  const registry=parseRegistry(readFileSync(root+'/data/meta/seed-registry.lino','utf8'));
  const web=readFileSync(root+'/js/seed-files.js','utf8');
  for(const [first,second,kind] of pairs)for(const name of [first,second]){
    const row=registry.seeds.find(seed=>seed.name===name);assert(row,name+' remains registered');
    assert(row.bundle&&row.web&&row.lexicon.has(kind),name+' retains all original consumers');
    assert(web.includes('"seed/'+name+'.lino"'),name+' remains browser-fetchable');
    assert.equal(readFileSync(root+'/data/seed/'+name+'.lino','utf8'),readFileSync(root+'/rust/embedded/data/seed/'+name+'.lino','utf8'),name+' package bytes');
  }
});
''')
    run('splitter',['node','--test','--test-concurrency=1',str(test)])
    run('before',['node','--test','--test-concurrency=1',str(ownerTest)],1)
    for name in ['meanings-response-intents','meanings-response-intents-handlers','meanings-routing-vocabulary','multilingual-responses-synthesis']:
        (out/(name+'.original.lino')).write_bytes((root/'data/seed'/ (name+'.lino')).read_bytes())
    summary={'drafted':True,'seedFilesChanged':False,'originalDataRetained':4,'independentAuthorshipCredit':0,'fullIssueComplete':False};(out/'draft.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
