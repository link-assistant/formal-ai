from pathlib import Path
source=Path('/tmp/issue-1580-research/review-rust-historical-diagnostics.py').read_text()
source=source.replace("rust-historical-remainder-comparison'","rust-historical-remainder-corrected-comparison'")
needle="page=int(sys.argv[1]);"
extra="""for path in sorted(base.glob('[0-9][0-9].json')):
 row=json.loads(path.read_text())
 if 'releaseRecords' in row:
  records=row['releaseRecords'];lines.append(row['path']+' '+str(len(records))+' Python.org records, complete field union='+str(sorted(set(key for item in records for key in item))))
  lines.append('first record '+json.dumps(records[0]));lines.append('last record '+json.dumps(records[-1]))
"""
assert source.count(needle)==1;source=source.replace(needle,extra+needle,1)
exec(compile(source,__file__,'exec'))
