from pathlib import Path
import gzip,hashlib,json,re
scratch=Path('/tmp/issue-1580-research');base=scratch/'rust-historical-remainder-corrected-comparison';pinned=scratch/'templates/rust-complete'
for i in [10,11,12,13,14,15,16]:
 row=json.loads((base/(str(i).zfill(2)+'.json')).read_text());print(row['path'])
 if 'releaseRecords' in row:
  records=row['releaseRecords'];keys=sorted({key for item in records for key in item});print('Python.org record count',len(records),'keys',keys)
  for item in [records[0],records[-1]]:print(json.dumps(item))
 elif 'solution-draft' in row['path']:
  print('Quoted tool/narrative evidence, not current annotations; whole decoded bytes',row['decodedBytes'],'sha256',row['decodedSha256'])
  for item in row.get('actualDiagnostics',[]):
   print('candidate source line',item['line'],'characters',len(item['text']),'sha256',hashlib.sha256(item['text'].encode()).hexdigest())
   for hit in re.finditer(r'(?:ENOENT|could not|Could not|##\[error\]|npm warn|severity vulnerabilities)',item['text']):print('quoted diagnostic fragment',item['text'][max(0,hit.start()-60):hit.end()+120])
 else:
  for item in row.get('actualDiagnostics',[]):print(str(item['line'])+' '+item['text'])
print('Desktop and initial pipeline root-error contexts')
for relative,centers in [('dev/log/issues/247/pulls/248/evidence/branch-desktop-43557817327.log.gz',[944]),('dev/log/issues/247/pulls/248/evidence/main-pipeline-43556886816.log.gz',[3447]),('dev/log/issues/247/pulls/248/evidence/pipeline-43562957241.log.gz',[3520])]:
 lines=gzip.decompress((pinned/relative).read_bytes()).decode().splitlines();print(relative)
 for center in centers:
  for number in range(max(1,center-12),min(len(lines),center+4)+1):print(number,lines[number-1])
