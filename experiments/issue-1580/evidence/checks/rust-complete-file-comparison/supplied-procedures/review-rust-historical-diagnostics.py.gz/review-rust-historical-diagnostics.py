from pathlib import Path
import json,sys
base=Path('/tmp/issue-1580-research/rust-historical-remainder-comparison');lines=[]
for path in sorted(base.glob('[0-9][0-9].json')):
 row=json.loads(path.read_text())
 if row.get('actualDiagnostics'):
  lines.append(row['path'])
  lines += [str(item['line'])+' '+item['text'] for item in row['actualDiagnostics']]
 if 'releases' in row:
  releases=row['releases'];lines.append(row['path']+' release records='+str(len(releases)))
  lines += [json.dumps({key:item.get(key) for key in ['tag_name','published_at','target_commitish','draft','prerelease']})+' assets='+str(len(item['assets'])) for item in releases]
page=int(sys.argv[1]);print('page',page,'of',(len(lines)+59)//60,'lines',len(lines));print('\n'.join(lines[(page-1)*60:page*60]))
