from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
r=subprocess.run(['rg','--files','.github','scripts'],cwd=root,text=True,capture_output=True);assert r.returncode==0
for topic in ['requirements','required-doc','python','rust-script','fresh-merge','pipeline-status','desktop-release','broken-link','link']:
 print(topic,[p for p in r.stdout.splitlines() if topic in p][:30])
