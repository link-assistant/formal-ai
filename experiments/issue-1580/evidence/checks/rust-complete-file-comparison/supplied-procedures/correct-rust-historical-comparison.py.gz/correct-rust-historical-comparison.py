from pathlib import Path
source=Path('/tmp/issue-1580-research/compare-rust-historical-remainder.py').read_text()
source=source.replace("out=scratch/'rust-historical-remainder-comparison'","out=scratch/'rust-historical-remainder-corrected-comparison'")
old="entry['releases']=[{k:item.get(k) for k in ['tag_name','name','published_at','target_commitish','draft','prerelease','html_url']} | {'assets':[{k:asset.get(k) for k in ['name','size','digest','content_type','browser_download_url']} for asset in item.get('assets',[])],'bodyBytes':len(item.get('body','').encode()),'bodySha256':hashlib.sha256(item.get('body','').encode()).hexdigest()} for item in releases]"
new="""entry['releases']=[{k:item.get(k) for k in ['tag_name','name','published_at','target_commitish','draft','prerelease','html_url']} | {'assets':[{k:asset.get(k) for k in ['name','size','digest','content_type','browser_download_url']} for asset in item.get('assets',[])],'bodyBytes':len(item.get('body','').encode()),'bodySha256':hashlib.sha256(item.get('body','').encode()).hexdigest()} for item in releases]
   if path.endswith('python-releases.json'):
    entry['releaseRecords']=[{key:value for key,value in item.items() if isinstance(value,(str,int,float,bool,type(None)))} for item in releases]
    del entry['releases']"""
assert source.count(old)==1;source=source.replace(old,new,1)
old="if re.search(r'##\\[(?:warning|error)\\]|^\\s*(?:WARN(?:ING)?|ERROR|error\\[E\\d+\\]|error:)',line):actual.append(item)"
new="if re.search(r'##\\[(?:warning|error)\\]|^\\s*(?:WARN(?:ING)?|ERROR|error\\[E\\d+\\]|error:)|\\dZ (?:warning(?:\\[[^]]+\\])?:|error(?:\\[[^]]+\\])?:)',line):actual.append(item)"
assert source.count(old)==1;source=source.replace(old,new,1)
exec(compile(source,__file__,'exec'))
