from pathlib import Path
import json,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'rust-current-complete-comparison';out.mkdir(exist_ok=True)
docs=root/'docs/case-studies/issue-1580/templates';old=json.loads((docs/'rust-source-review-progress.json').read_text());delta=json.loads((docs/'rust-current-delta-review.json').read_text());tree=json.loads((scratch/'fresh-template-delta-sources/trees/rust.json').read_text());assert not tree['truncated'] and tree['sha']==delta['commit']
oldidentities=json.loads((root/old['all373BlobIdentitiesVerifiedBy']).read_text());identities={r['path']:r for r in oldidentities};literal={r['path']:r for r in old['files']};changed={r['path']:r for r in delta['files']}
historical={}
for p in sorted((scratch/'rust-historical-remainder-corrected-comparison').glob('[0-9][0-9].json')):
 row=json.loads(p.read_text());historical[row['path']]=row
assert len(literal)==356 and len(historical)==17 and set(literal).isdisjoint(historical)
practices={}
for i,r in enumerate(old['practiceDecisions'],1):
 for path in r.get('templateEvidence',r.get('templateFiles',[])):
  path=path.split(':')[0];practices.setdefault(path,[]).append(i)
rows=[];unmapped=[]
for item in sorted((r for r in tree['tree'] if r['type']=='blob'),key=lambda r:r['path']):
 name=item['path'];p=scratch/'fresh-template-delta-sources/files/rust'/name
 if not p.is_file():p=scratch/'templates/rust-complete'/name
 raw=p.read_bytes();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();sha=hashlib.sha256(raw).hexdigest();assert blob==item['sha'],name
 row={'path':name,'gitBlob':blob,'sha256':sha,'bytes':len(raw),'templatePracticeRows':practices.get(name,[])}
 if name in changed:
  d=changed[name];assert sha==d['sha256'] and blob==d['gitBlob'];row.update({'comparisonMethod':'current-delta-source-review','literalSourceFullyRead':d['completeLiteralSourceRead'],'formalAiComparison':d['formalAiComparison'],'decision':d['decision'],'readEvidence':'rust-current-delta-review.json'})
 else:
  assert sha==identities[name]['sha256'] and blob==identities[name]['gitBlob'],name
  if name in literal:
   d=literal[name];assert d['literalSourceFullyRead'] and d['sha256']==sha;row.update({'comparisonMethod':'unchanged-pinned-literal-review','literalSourceFullyRead':True,'readEvidence':'rust-source-review-progress.json'})
  else:
   d=historical[name];assert d['sha256']==sha;row.update({'comparisonMethod':d['method'],'literalSourceFullyRead':False,'readEvidence':'rust-historical-remainder/'+next(p.name for p in (scratch/'rust-historical-remainder-corrected-comparison').glob('[0-9][0-9].json') if json.loads(p.read_text())['path']==name)})
  if name not in practices:unmapped.append(name)
 rows.append(row)
assert len({r['path'] for r in rows})==len(rows)
(out/'files.jsonl').write_text(''.join(json.dumps(r,separators=(',',':'))+'\n' for r in rows))
summary={'sourceCommit':tree['sha'],'baseCommit':old['sourceCommit'],'files':len(rows),'oldFiles':len(identities),'changedReviewed':len(changed),'unchangedCarried':len(rows)-len(changed),'allGitBlobsVerified':True,'allSourceArtifactsHaveComparisonMethod':True,'allFilesHaveReviewedApplicabilityDecision':False,'allApplicablePracticesVerified':False,'fullIssueComplete':False,'unmappedFiles':unmapped,'removed':[name for name in identities if name not in {r['path'] for r in rows}]}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
