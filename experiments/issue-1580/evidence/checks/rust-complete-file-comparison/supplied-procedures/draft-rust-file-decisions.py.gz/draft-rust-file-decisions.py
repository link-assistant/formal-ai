from pathlib import Path
import json
root=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');d=root/'docs/case-studies/issue-1580/templates';out=s/'rust-current-complete-comparison'
old=json.loads((d/'rust-source-review-progress.json').read_text());rows=[json.loads(x) for x in (out/'files.jsonl').read_text().splitlines()]
topics={
 'buildx':(['.github/actions/setup-buildx-resilient/action.yml'],'Keep finite bootstrap mirror recovery and require successful final setup. Historical image metadata cannot qualify a present registry image.'),
 'python':(['.github/workflows/workflows.yml','.pre-commit-config.yaml'],'Compare explicit Python runtime and pinned workflow-tool dependencies in the actual workflow and hooks; Formal AI has no root requirements-dev.txt counterpart. The Python.org release series field is not a semantic version; archived records are not current tool selection.'),
 'secrets':(['scripts/check-secrets.sh','.github/workflows/security.yml'],'Keep complete checked Git inventory, dedicated scanner dependencies and failure propagation; include tracked historical content instead of allowing a directory-name bypass.'),
 'codeql':(['.github/workflows/security.yml','scripts/check-codeql-results.mjs'],'Keep exact producer inputs and all original SARIF findings/invocation diagnostics; historical analyzer success does not override failed audit or report gates.'),
 'javascript':(['scripts/ci-pull-request-admission.mjs','.github/workflows/release.yml'],'Preserve candidate revision qualification, explicit successful prerequisites, conservative change detection and tested source identity. Example arithmetic APIs are language-specific fixtures, not Formal AI features.'),
 'aggregate':(['scripts/check-pipeline-status.sh'],'Keep failed, cancelled, timed-out and missing prerequisite observations visible at the terminal gate; expected event skips need explicit admission conditions.'),
 'documentation':(['scripts/render-status.mjs','scripts/generate-staged-release.mjs','.github/workflows/pages-artifact.yml'],'Compare repository-specific generated documentation gates and documentation-source identity independent of package publisher success. No same-named required-document helper exists in Formal AI; the template document list is not transplanted and equivalent missing-document refusal remains a separate practice question. Historical logs do not qualify a live deployment.'),
 'desktop':(['.github/workflows/desktop-release.yml','scripts/desktop-release-resolve.sh'],'Keep release source/artifact identity, exact asset selection, digest verification and visible empty/download-failure states; a historical screenshot or failed package run proves no available artifact.'),
 'installer':(['scripts/install-rust-script.sh'],'Keep bounded installation and transient-network recovery inside the job budget, with final failure propagation and locked tool dependencies.'),
 'cancellation':(['scripts/check-pipeline-status.sh','.github/workflows/release.yml'],'Preserve non-cancelling writer ownership. Classify cancellation using the actual workflow/run context; do not excuse arbitrary cancelled checks.'),
 'merge':(['scripts/simulate-fresh-merge.sh','.github/workflows/release.yml'],'Preserve complete Git evidence and tested source custody across merge refreshes; never publish a changed checkout using tests from the earlier source.'),
 'links':(['.github/workflows/links.yml','scripts/recheck-broken-links.mjs'],'Preserve permanent broken-link failure, bounded transport retries and checker-runtime errors. Archive availability is guidance and does not certify the live URL.'),
 'lock':(['scripts/check-rust-dependencies.sh','rust/Cargo.lock'],'Keep actual committed lock validation and checked complete inventories before audit. Historical duplicate syn input and missing standalone regex dependencies must retain their original failing status.'),
 'workflowlint':(['.github/workflows/workflows.yml'],'Compare the actual actionlint, ShellCheck and zizmor callers, tool pins and narrowly scoped compatibility rules. A CodeQL report is not a workflow-linter result.'),
}
def extra(name):
 if 'buildx' in name:return 'buildx'
 if 'python' in name:return 'python'
 if 'check-secrets' in name:return 'secrets'
 if 'codeql' in name or 'security-' in name:return 'codeql'
 if 'javascript' in name:return 'javascript'
 if 'pipeline-status' in name:return 'aggregate'
 if 'required-docs' in name or 'issue-38/' in name:return 'documentation'
 if 'desktop' in name or 'package-desktop' in name:return 'desktop'
 if 'install-rust-script' in name:return 'installer'
 if 'cancel' in name:return 'cancellation'
 if 'fresh-merge' in name or 'solution-draft-log' in name:return 'merge'
 if 'links-' in name:return 'links'
 if 'baseline-script-tests' in name or 'pipeline-' in name:return 'lock'
 if 'zizmor' in name:return 'workflowlint'
 raise ValueError(name)
for row in rows:
 if 'decision' in row:continue
 name=row['path']
 if name=='LICENSE':
  row.update({'formalAiComparison':['LICENSE'],'decision':'Each repository retains its own copyright and license terms. This file adds no executable CI practice and is not copied.','comparisonTopic':'license'});continue
 if name.startswith(('src/','tests/unit/sum','tests/integration/sum','examples/basic_usage')):
  row.update({'formalAiComparison':['rust/src/lib.rs','rust/tests'],'decision':'The template arithmetic application, examples and arithmetic expectations are repository-specific. Retain Formal AI application behavior and its own native test targets; do not introduce a sum application to reproduce the template.','comparisonTopic':'application'});continue
 if name=='.github/actions/download-artifact/action.yml' or name=='scripts/extract-artifacts.py':
  row.update({'formalAiComparison':['.github/actions/download-artifact/action.yml','scripts/extract-artifacts.py'],'decision':'Compare the owned raw artifact adapter and streaming extraction implementation, retaining transport digest validation, traversal/symlink/collision refusal and strict deprecation controls. Hosted adapter and production-consumer evidence remain distinct.','comparisonTopic':'artifact'});continue
 refs=row['templatePracticeRows']
 if refs:
  decisions=[old['practiceDecisions'][i-1] for i in refs];paths=sorted({p for decision in decisions for p in decision.get('formalAiPaths',[]) if (root/p).exists()})
  if not paths:paths=['.github/workflows/release.yml','scripts/ci-pull-request-admission.mjs','CONTRIBUTING.md']
  row.update({'formalAiComparison':paths,'decision':'Retain the applicable ownership, failure and source-identity contracts described in the linked reviewed practice rows; repository-specific example behavior and historical dependency versions are not transplanted. Practice implementation and runtime evidence remain separate from this source comparison.','practiceAssessments':'rust-source-review-progress.json#practiceDecisions'})
 else:
  topic=extra(row['path']);paths,decision=topics[topic];missing=[p for p in paths if not (root/p).exists()];assert not missing,(row['path'],missing)
  row.update({'formalAiComparison':paths,'decision':decision,'comparisonTopic':topic})
 assert all((root/p).exists() for p in row['formalAiComparison']),row['path']
for row in rows:
 assert row['decision'] and row['formalAiComparison'] and all((root/p).exists() for p in row['formalAiComparison'])
summary=json.loads((out/'summary.json').read_text());summary['allFilesHaveReviewedApplicabilityDecision']=True;summary['allFilesCompared']=True;summary['unmappedFiles']=[]
(out/'files-with-decisions.jsonl').write_text(''.join(json.dumps(r,separators=(',',':'))+'\n' for r in rows));(out/'source-comparison-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2));print('EXPLICIT DECISIONS')
for r in rows:
 if 'comparisonTopic' in r:print(r['path'],r['comparisonTopic'],r['formalAiComparison'])
