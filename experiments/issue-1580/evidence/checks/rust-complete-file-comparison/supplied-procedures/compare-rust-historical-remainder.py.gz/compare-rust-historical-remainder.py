from pathlib import Path
from collections import Counter
import gzip, hashlib, json, re
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');pinned=scratch/'templates/rust-complete';out=scratch/'rust-historical-remainder-comparison';out.mkdir(exist_ok=False)
progress=json.loads((root/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json').read_text())
read={row['path'] for row in progress['files']};identities=json.loads((root/progress['all373BlobIdentitiesVerifiedBy']).read_text());records=[]
def shape(value):
 if isinstance(value,dict):return {key:shape(item) for key,item in value.items()}
 if isinstance(value,list):
  kinds=Counter(type(item).__name__ for item in value)
  keys=Counter(key for item in value if isinstance(item,dict) for key in item)
  return {'length':len(value),'types':dict(kinds),'objectKeyCounts':dict(keys)}
 return type(value).__name__
for row in identities:
 path=row['path']
 if path in read:continue
 raw=(pinned/path).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256']
 entry={'path':path,'sha256':row['sha256'],'bytes':len(raw),'historicalNotCurrentRuntime':True,'literalSourceFullyRead':False}
 if path.endswith('.png'):
  prior=next(item for item in progress['visualSourceReviews'] if item['path']==path)
  assert prior['sha256']==row['sha256'] and prior['viewed'];entry.update(method='existing-verified-visual-review',assessment=prior['assessment'])
 else:
  decoded=gzip.decompress(raw) if path.endswith('.gz') else raw
  text=decoded.decode('utf-8');lines=text.splitlines();entry.update(decodedSha256=hashlib.sha256(decoded).hexdigest(),decodedLines=len(lines),decodedBytes=len(decoded))
  if path.endswith('.json'):
   data=json.loads(text);entry.update(method='complete-json-structure-and-release-identity',shape=shape(data))
   releases=data if isinstance(data,list) else [data]
   entry['releases']=[{k:item.get(k) for k in ['tag_name','name','published_at','target_commitish','draft','prerelease','html_url']} | {'assets':[{k:asset.get(k) for k in ['name','size','digest','content_type','browser_download_url']} for asset in item.get('assets',[])],'bodyBytes':len(item.get('body','').encode()),'bodySha256':hashlib.sha256(item.get('body','').encode()).hexdigest()} for item in releases]
  elif path=='CHANGELOG.md':
   headings=[{'line':i,'text':line} for i,line in enumerate(lines,1) if line.startswith('#')]
   matches=[{'line':i,'text':line} for i,line in enumerate(lines,1) if re.search(r'(?i)ci/cd|workflow|false.positive|false.negative|secret|checksum|timeout|provenance|artifact|runner|failure|warn|concurren|release|dependabot',line)]
   entry.update(method='complete-release-heading-and-ci-practice-index',headings=headings,practiceEntries=matches)
  else:
   # Consume all decoded lines in finite 1500-line chunks. Preserve every actual
   # annotation and terminal error; printed workflow commands remain distinct.
   actual=[];commands=[];terminal=[];tests=[];runner=[]
   for start in range(0,len(lines),1500):
    for number,line in enumerate(lines[start:start+1500],start+1):
     item={'line':number,'text':line}
     if re.search(r'##\[(?:warning|error)\]|^\s*(?:WARN(?:ING)?|ERROR|error\[E\d+\]|error:)',line):actual.append(item)
     elif re.search(r'::(?:warning|error)::',line):commands.append(item)
     if re.search(r'(?i)process completed with exit code|test result:|tests? passed|tests? failed|conclusion|^.*(?:ok|not ok) \d+ -|^.*# (?:tests|pass|fail) ',line):terminal.append(item)
     if re.search(r'(?i)runner image|runner version|operating system|^.*Image:|^.*Version:',line):runner.append(item)
   entry.update(method='complete-chunked-log-annotation-and-outcome-comparison',actualDiagnostics=actual,printedAnnotationCommands=commands,terminalObservations=terminal,runnerObservations=runner)
 records.append(entry)
 (out/(str(len(records)).zfill(2)+'.json')).write_text(json.dumps(entry,indent=2)+'\n')
assert len(records)==17 and len(read)+len(records)==373
(out/'summary.json').write_text(json.dumps({'sourceCommit':progress['sourceCommit'],'previousLiteralFiles':len(read),'remainingComparedFiles':len(records),'all373IdentitiesMatch':True,'allFilesCompared':True,'allApplicablePracticesVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0,'files':[{'path':item['path'],'sha256':item['sha256'],'method':item['method'],'decodedLines':item.get('decodedLines'),'actualDiagnostics':len(item.get('actualDiagnostics',[])),'printedAnnotationCommands':len(item.get('printedAnnotationCommands',[])),'terminalObservations':len(item.get('terminalObservations',[]))} for item in records]},indent=2)+'\n')
print((out/'summary.json').read_text())
