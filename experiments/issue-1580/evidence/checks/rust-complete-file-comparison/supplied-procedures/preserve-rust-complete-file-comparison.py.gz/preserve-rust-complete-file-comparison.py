from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'rust-complete-file-comparison-preservation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==0,(name,r.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 delivery=json.loads((scratch/'seed-reader-delivery-preflight/outcome.json').read_text());assert delivery['pushed']
 assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
 assert not run('status-before',['git','status','--porcelain']).strip()
 source=scratch/'rust-current-complete-comparison';summary=json.loads((source/'source-comparison-summary.json').read_text());assert summary['files']==374 and summary['allFilesCompared'] and not summary['allApplicablePracticesVerified']
 target=root/'experiments/issue-1580/evidence/checks/rust-complete-file-comparison';target.mkdir(exist_ok=False);archives=[]
 def archive(path,relative):
  raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);dest=target/(relative+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed)
  assert gzip.decompress(dest.read_bytes())==raw
  archives.append({'file':str(dest.relative_to(target)),'sha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
 for directory in ['rust-current-complete-comparison','rust-historical-remainder-comparison','rust-historical-remainder-corrected-comparison','rust-comparison-reachability']:
  for p in sorted((scratch/directory).rglob('*')):
   if p.is_file():archive(p,directory+'/'+str(p.relative_to(scratch/directory)))
 helpers=['compare-rust-historical-remainder.py','correct-rust-historical-comparison.py','review-rust-historical-findings.py','review-rust-historical-diagnostics.py','read-corrected-rust-historical-diagnostics.py','read-rust-final-history-context.py','check-rust-comparison-reachability.py','draft-rust-current-complete-comparison.py','draft-rust-file-decisions.py','find-current-ci-counterpart-paths.py',Path(__file__).name]
 for name in helpers:archive(scratch/name,'supplied-procedures/'+name)
 for name in ['read-rust-final-history-context-driver.log','check-rust-comparison-reachability-driver.log','draft-rust-current-complete-comparison-driver.log','draft-rust-file-decisions-driver.log','draft-rust-file-decisions-corrected-driver.log','draft-rust-file-decisions-final-driver.log','find-current-ci-counterpart-paths-driver.log']:
  archive(scratch/name,'review-attempts/'+name)
 docs=root/'docs/case-studies/issue-1580/templates';rows=[json.loads(line) for line in (source/'files-with-decisions.jsonl').read_text().splitlines()]
 for row in rows:
  assert row['decision'] and row['formalAiComparison'] and all((root/p).exists() for p in row['formalAiComparison']),row['path']
  if row['readEvidence'].startswith('rust-historical-remainder/'):
   row['readEvidence']=str(target.relative_to(root))+'/rust-historical-remainder-corrected-comparison/'+row['readEvidence'].split('/')[-1]+'.gz'
 (docs/'rust-complete-files.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in rows))
 (target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in archives))
 result={**summary,'reviewedAt':datetime.now(timezone.utc).isoformat(),'scope':'Complete per-file source applicability comparison at the selected current Rust tree. Literal reading, unchanged-source carry, structured historical log/JSON comparison and prior visual inspection remain distinct methods.','filesReceipt':'rust-complete-files.jsonl','earlierLiteralFiles':356,'earlierLiteralLines':57336,'historicalRemainderCompared':17,'allCurrentBlobIdentitiesReverified':True,'allComparisonPathsExist':True,'historicalLogsAreCurrentRuntimeProof':False,'allApplicablePracticesImplementedAndVerified':False,'nativeBuildExecutedLocally':False,'hostedPublicationExecuted':False,'independentAuthorshipCredit':0,'evidence':str(target.relative_to(root)),'limits':['The 74 earlier practice assessments retain their dated implementation/runtime limits; source comparison does not turn them into passing behavior.','Historical solution-draft JSON embeds quoted tool output and narrative; diagnostic matches in those artifacts are candidates, not current workflow annotations.','The initial Python.org metadata interpretation incorrectly used the GitHub release schema; the failed analysis and corrected all-505-record field comparison are retained.','A counterpart lookup initially named absent root requirements-dev.txt and check-required-docs.sh files. The corrected decisions use actual paths and retain the missing dedicated document-list equivalence as a separate practice question.','Historical duplicate syn, standalone missing regex, broken live links, audit/CodeQL failures, action deprecations and release working-directory failures retain their original sources and dates. None is called a current unresolved defect solely from archived logs.']}
 (docs/'rust-complete-file-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
 readme=docs/'README.md';text=readme.read_text();text+='''\n## Complete Rust file comparison, 2026-11-21\n\nThe [current 374-file receipt](rust-complete-file-comparison.json) compares every\nblob at `5f1e7a96acbf7a93b567195443cf6e5158fbbf1f`: 362 unchanged sources\ncarry their pinned review and 12 changed files retain the separate delta review.\nThe [per-file decisions](rust-complete-files.jsonl) bind Git/SHA256 identities,\ncomparison methods and actual Formal AI paths. The final 17 historical artifacts\nuse complete structured log/JSON/history comparison and an existing verified\nvisual review; they do not inflate the earlier 356-file literal-read count.\nAll files now have source applicability decisions. The 74 practice assessments,\napplicable behavior verification and wider issue acceptance remain unfinished.\nQuoted solution-draft output and historical failures supply context; neither is\na present workflow result. Earlier partial receipts remain dated evidence.\n''';readme.write_text(text)
 run('whitespace',['git','diff','--check'])
 run('focused-source-identities',['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/template-source-identities.test.mjs'])
 run('evidence-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-changelog-fragment-js-twin,check-reconstructed-changelog,check-file-size'])
 paths=[str(target.relative_to(root)),str((docs/'rust-complete-files.jsonl').relative_to(root)),str((docs/'rust-complete-file-comparison.json').relative_to(root)),str(readme.relative_to(root))]
 run('stage',['git','add','--',*paths]);run('staged-whitespace',['git','diff','--cached','--check']);run('secrets',['bash','scripts/check-secrets.sh']);run('commit',['git','commit','-m','Complete pinned Rust template file comparison with explicit evidence limits'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'filesCompared':374,'allApplicablePracticesVerified':False,'fullIssueComplete':False,'head':run('head',['git','rev-parse','HEAD']).strip(),'pushed':False},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
