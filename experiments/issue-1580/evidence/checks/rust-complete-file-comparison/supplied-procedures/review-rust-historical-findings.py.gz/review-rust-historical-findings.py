from pathlib import Path
import json,re,textwrap,sys
base=Path('/tmp/issue-1580-research/rust-historical-remainder-comparison');render=[]
for path in sorted(base.glob('[0-9][0-9].json')):
 row=json.loads(path.read_text());render.append(row['path'])
 for item in row.get('actualDiagnostics',[]):render.append(str(item['line'])+' '+item['text'])
 if 'releases' in row:
  for release in row['releases']:
   render.append(json.dumps({k:v for k,v in release.items() if k!='assets'}))
   render.extend('asset '+json.dumps(asset) for asset in release['assets'])
 if 'practiceEntries' in row:
  for item in row['practiceEntries']:
   if re.search(r'(?i)ci/cd|workflow|false.positive|false.negative|secret|checksum|timeout|provenance|runner|failure|warn|concurren|dependabot',item['text']):render.append(str(item['line'])+' '+item['text'])
 # Retain full structured terminal observations, while reading error/annotation
 # semantics separately from their printed command spellings.
 lines=[]
 for item in render:lines.extend(textwrap.wrap(item,width=180,replace_whitespace=False,drop_whitespace=False) or [''])
page=int(sys.argv[1]);start=(page-1)*100
print('page',page,'of',(len(lines)+99)//100,'total lines',len(lines))
print('\n'.join(lines[start:start+100]))
