from pathlib import Path
import subprocess,json
base=Path('/tmp/issue-1580-research/templates/rust-complete');out=Path('/tmp/issue-1580-research/rust-comparison-reachability');out.mkdir(exist_ok=True)
r=subprocess.run(['rg','-n','dev/log|case-studies|buildx-release.json|python-releases|CHANGELOG.md','.github','scripts','Cargo.toml'],cwd=base,capture_output=True,text=True)
(out/'direct-source-references.log').write_text(r.stdout+r.stderr)
print('REFERENCE STATUS',r.returncode,'LINES',len(r.stdout.splitlines()))
for line in r.stdout.splitlines():print(line[:1200])
for name in ['.github/workflows/release.yml','.github/workflows/links.yml','.github/workflows/workflows.yml','scripts/test-ci-scripts.sh','Cargo.toml']:
 p=base/name
 if not p.exists():continue
 print('CALLER',name)
 for i,line in enumerate(p.read_text().splitlines(),1):
  if any(v in line for v in ['paths','exclude','script','test','lychee','glob','find ','git ls-files','dev/log','case-studies','CHANGELOG','--all','cargo ']):print(i,line[:500])
