from pathlib import Path
import json, subprocess
base=Path('/tmp/issue-1580-research/active-ci-python-syntax');base.mkdir(exist_ok=False)
commands=[('pipeline-jobs',['gh','run','view','44882210284','--repo','link-assistant/formal-ai','--json','jobs,status,conclusion,headSha,createdAt,updatedAt,url']),('python-failed-main',['gh','run','view','44857673625','--repo','link-foundation/python-ai-driven-development-pipeline-template','--log']),('github-workflow-syntax',['curl','-fLsS','https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax'])]
for name,args in commands:
 r=subprocess.run(args,capture_output=True)
 (base/(name+'.stdout')).write_bytes(r.stdout);(base/(name+'.stderr')).write_bytes(r.stderr)
 print(json.dumps({'name':name,'exitCode':r.returncode,'stdoutBytes':len(r.stdout),'stderrBytes':len(r.stderr)}))
 if name=='github-workflow-syntax' and r.returncode==0:
  text=r.stdout.decode();terms=['$/','same repository','local action'];matches=[]
  for term in terms:
   start=0
   while True:
    pos=text.find(term,start)
    if pos<0:break
    matches.append({'term':term,'context':text[max(0,pos-400):pos+900]});start=pos+len(term)
  (base/'syntax-relevant.json').write_text(json.dumps(matches,indent=2)+'\n')
tool=Path('/tmp/issue-1580-research/actionlint-queue-negative-control/actionlint')
for label,uses in [('root-dollar','$/.github/actions/artifact'),('dot-relative','./.github/actions/artifact')]:
 path=base/(label+'.yml');path.write_text('name: syntax\non: push\njobs:\n  check:\n    runs-on: ubuntu-24.04\n    steps:\n      - uses: '+uses+'\n')
 r=subprocess.run([str(tool),'-shellcheck=','-pyflakes=',str(path)],capture_output=True)
 (base/(label+'.stdout')).write_bytes(r.stdout);(base/(label+'.stderr')).write_bytes(r.stderr)
 print(json.dumps({'name':label,'uses':uses,'exitCode':r.returncode}))
