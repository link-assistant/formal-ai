from pathlib import Path
import json,subprocess
out=Path('/tmp/issue-1580-research/python-scriv-upstream-report')
assert not (out/'created.json').exists()
assert json.loads(Path('/tmp/issue-1580-research/python-scriv-observations/outcome.json').read_text())['exitCode']==0
body=r'''At current commit 62cc393707ddfe7ceeddbc580d43cc35334636f1, scripts/create_manual_changeset.py:create_with_scriv() chooses the most recently modified Markdown file in the whole changelog.d/ directory after scriv create succeeds. With --description, it overwrites that file without verifying that Scriv created it.

Affected source: https://github.com/link-foundation/python-ai-driven-development-pipeline-template/blob/62cc393707ddfe7ceeddbc580d43cc35334636f1/scripts/create_manual_changeset.py

A pre-existing fragment with a future modification timestamp is a deterministic data-loss case: the requested new description replaces the earlier release history, while the actual new Scriv fragment stays untouched. A concurrent writer can create the same ambiguity. Sorting by time establishes neither ownership nor identity.

This bounded Python 3.14+ reproduction executes the actual template function, mocking only the external Scriv producer so its new file and timestamps are deterministic:

~~~python
import contextlib, io, os, resource, subprocess, tempfile
from pathlib import Path
from unittest.mock import patch
from scripts import create_manual_changeset as creator

resource.setrlimit(resource.RLIMIT_AS, (134217728, 134217728))
resource.setrlimit(resource.RLIMIT_CPU, (3, 3))
with tempfile.TemporaryDirectory() as temporary:
    before = Path.cwd()
    try:
        os.chdir(temporary)
        Path('changelog.d').mkdir()
        old = Path('changelog.d/earlier.md')
        old.write_text('### Added\n\n- Earlier feature.\n')
        os.utime(old, (1900000000, 1900000000))
        def scriv(arguments, **kwargs):
            assert arguments == ['scriv', 'create']
            new = Path('changelog.d/new.md')
            new.write_text('Scriv draft\n')
            os.utime(new, (1700000000, 1700000000))
            return subprocess.CompletedProcess(arguments, 0, 'Created new.md\n', '')
        with patch.object(creator.subprocess, 'run', scriv), contextlib.redirect_stdout(io.StringIO()):
            assert creator.create_with_scriv('patch', 'Later patch.') == 0
        print(old.read_text())
        print(Path('changelog.d/new.md').read_text())
    finally:
        os.chdir(before)
~~~

Observed earlier fragment: "### Fixed" / "Later patch.". Observed new fragment: unchanged "Scriv draft". Expected: preserve the earlier fragment and apply the description only to the new fragment.

Four maintained regression tests run the actual current Python source (SHA256 f254d822c125f1a2e2152085165ced5a55cb5b26bca6c430ab3be063b53c8be9) and a disposable candidate. The candidate records existing paths before calling Scriv, considers only newly created paths, and refuses zero or multiple candidates before writing. Tests cover the future-timestamp case, a successful producer that creates no file, ambiguous concurrent creation, and ordinary new-file controls with and without older fragments. All four pass under actual Python 3.15.0, with 128 MiB / three CPU seconds / five-second outer limits. Scriv itself is not installed or executed in these probes.

This differs from #157, whose --no-scriv same-second collision was repaired with exclusive creation. The affected Scriv branch remains independent of that repair. All 112 current issue titles and all issue bodies were searched for duplicate Scriv/mtime-selection reports; none was found.

The candidate is tested only in disposable copies and has not been applied upstream. Investigation and retained evidence: https://github.com/link-assistant/formal-ai/pull/1581 . The maintained test will be committed after local verification and will receive a permanent source link after the current hosted run finishes. These supplied probes receive zero independent Formal AI authorship credit.
'''
(out/'body.md').write_text(body)
r=subprocess.run(['gh','issue','create','--repo','link-foundation/python-ai-driven-development-pipeline-template','--title','Scriv changelog creator overwrites unrelated fragments by selecting the newest mtime','--body-file',str(out/'body.md')],capture_output=True,text=True,check=True)
(out/'create.stdout').write_text(r.stdout);(out/'create.stderr').write_text(r.stderr)
url=r.stdout.strip();assert url.startswith('https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/')
(out/'created.json').write_text(json.dumps({'url':url,'actualScrivExecuted':False,'upstreamRepairApplied':False,'fullIssueComplete':False},indent=2)+'\n')
print(json.dumps({'upstreamReport':url,'fullIssueComplete':False,'pushExecuted':False}))
