from pathlib import Path
import json,subprocess,shutil,re,html
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/direct-docs-current-ci');out.mkdir(exist_ok=False)
for name,args in [('tests-as-docs',['node','scripts/check-tests-as-docs.mjs']),('pipeline',['gh','run','view','44882210284','--repo','link-assistant/formal-ai','--json','jobs,status,conclusion,headSha'])]:
 r=subprocess.run(args,cwd=root,capture_output=True);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
 print(json.dumps({'name':name,'exitCode':r.returncode}))
 if name=='pipeline' and r.returncode==0:
  body=json.loads(r.stdout);(out/'job-summary.json').write_text(json.dumps({'head':body['headSha'],'status':body['status'],'conclusion':body['conclusion'],'jobs':[{'name':j['name'],'status':j['status'],'conclusion':j['conclusion']} for j in body['jobs'] if j['conclusion']!='skipped']},indent=2)+'\n')
raw=Path('/tmp/issue-1580-research/active-ci-python-syntax/github-workflow-syntax.stdout').read_text()
start=raw.index('<p><code>$/path/to/action</code></p>');end=raw.index('<p>The following table',start)
text=html.unescape(re.sub('<[^>]+>','',raw[start:end]));(out/'official-self-repository-syntax.txt').write_text(text+'\n')
(out/'python-tools.json').write_text(json.dumps({name:shutil.which(name) for name in ['python3','python3.15','pytest','uv']},indent=2)+'\n')
failed=Path('/tmp/issue-1580-research/active-ci-python-syntax/python-failed-main.stdout').read_text().splitlines()
(out/'python-main-failure-context.txt').write_text('\n'.join(f'{i+1}: {failed[i]}' for first,last in [(130,165),(2320,2400)] for i in range(first-1,last))+'\n')
