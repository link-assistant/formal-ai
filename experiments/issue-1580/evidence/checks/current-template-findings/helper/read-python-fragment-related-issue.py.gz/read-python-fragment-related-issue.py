from pathlib import Path
import json,subprocess
out=Path('/tmp/issue-1580-research/python-scriv-upstream-report')
for name,args in [('issue-157',['gh','issue','view','157','--repo','link-foundation/python-ai-driven-development-pipeline-template','--json','title,body,state,url']),('issue-157-comments',['gh','api','repos/link-foundation/python-ai-driven-development-pipeline-template/issues/157/comments','--paginate','--slurp'])]:
 r=subprocess.run(args,capture_output=True,text=True,check=True);(out/(name+'.json')).write_text(r.stdout)
 parsed=json.loads(r.stdout)
 text=parsed['body'] if isinstance(parsed,dict) else '\n\n'.join(item['body'] for page in parsed for item in page)
 (out/(name+'.txt')).write_text(text+'\n')
 print(json.dumps({'name':name,'lines':len(text.splitlines())}))
