from pathlib import Path
import base64,gzip,hashlib,json,subprocess

root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
php_report=json.loads((scratch/'php-process-upstream-report/created.json').read_text())['url']
python_report=json.loads((scratch/'python-scriv-upstream-report/created.json').read_text())['url']
source=scratch/'fresh-template-delta-sources/files/python';pin='62cc393707ddfe7ceeddbc580d43cc35334636f1'
fixture=root/'experiments/issue-1580/fixtures/python-current-changeset'
license_result=subprocess.run(['gh','api',f'repos/link-foundation/python-ai-driven-development-pipeline-template/contents/LICENSE?ref={pin}'],capture_output=True,check=True)
license_info=json.loads(license_result.stdout);license_bytes=base64.b64decode(license_info['content'])
assert hashlib.sha1(f'blob {len(license_bytes)}\0'.encode()+license_bytes).hexdigest()==license_info['sha']
assert license_bytes==(root/'experiments/issue-1580/fixtures/python-template/LICENSE').read_bytes()
(fixture/'LICENSE').write_bytes(license_bytes)
identity=json.loads((fixture/'source.json').read_text())
identity['files'].append({'path':'LICENSE','gitBlob':license_info['sha'],'sha256':hashlib.sha256(license_bytes).hexdigest()})
(fixture/'source.json').write_text(json.dumps(identity,indent=2)+'\n')
target=root/'experiments/issue-1580/evidence/checks/current-template-findings';target.mkdir(exist_ok=False)
records=[]
def retain(path,name):
 raw=path.read_bytes();archive=gzip.compress(raw,mtime=0);filename=name+'.gz';(target/filename).parent.mkdir(parents=True,exist_ok=True);(target/filename).write_bytes(archive)
 records.append({'source':str(path),'file':filename,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(archive).hexdigest()})
for directory in ['php-process-upstream-report','python-scriv-upstream-report','python-scriv-observations','php-pipe-publication-checks']:
 for path in sorted((scratch/directory).iterdir()):
  if path.is_file():retain(path,directory+'/'+path.name)
for directory,names in {
 'active-ci-python-syntax':['python-failed-main.stdout','python-failed-main.stderr','github-workflow-syntax.stdout','github-workflow-syntax.stderr','root-dollar.yml','root-dollar.stdout','root-dollar.stderr','dot-relative.yml','dot-relative.stdout','dot-relative.stderr'],
 'direct-docs-current-ci':['tests-as-docs.stdout','tests-as-docs.stderr','python-tools.json','official-self-repository-syntax.txt','python-main-failure-context.txt'],
}.items():
 for name in names:retain(scratch/directory/name,directory+'/'+name)
for name in ['prepare-php-process-report','publish-php-process-report','draft-python-scriv-integrity','prepare-python-scriv-report','read-python-fragment-related-issue','publish-python-scriv-report','check-direct-docs-and-ci','inspect-active-ci-and-python-syntax','seal-current-template-findings']:
 retain(scratch/(name+'.py'),'helper/'+name+'.py')
 if (scratch/(name+'.log')).exists() and name!='seal-current-template-findings':retain(scratch/(name+'.log'),'helper/'+name+'.log')
files=[]
unread={'.github/actions/artifact/dist/index.mjs','.github/actions/artifact/package-lock.json'}
for path in sorted(source.rglob('*')):
 if not path.is_file():continue
 relative=path.relative_to(source).as_posix();raw=path.read_bytes()
 retain(path,'python-current-source/'+relative)
 files.append({'path':relative,'bytes':len(raw),'lines':len(raw.splitlines()),'sha256':hashlib.sha256(raw).hexdigest(),'gitBlob':hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest(),'literalReviewComplete':relative not in unread,'assessment':'Generated bundle and dependency-lock comparison remain incomplete.' if relative in unread else 'Complete literal review; workflow, source, tests and license decisions are summarized in the checkpoint.'})
assert len(files)==35 and sum(f['literalReviewComplete'] for f in files)==33
ledger={'repository':'link-foundation/python-ai-driven-development-pipeline-template','commit':pin,'currentBlobCount':338,'changedFiles':files,'literalChangedFilesReviewed':33,'changedFileCount':35,'fullTemplateComparisonComplete':False,'historicalCoverageComplete':False,'allApplicablePracticesComplete':False,'acceptanceComplete':False,'scrivObservation':{'sourceSha256':'f254d822c125f1a2e2152085165ced5a55cb5b26bca6c430ab3be063b53c8be9','testFile':'experiments/issue-1580/template-python-scriv-integrity.test.mjs','testsPassed':4,'actualPython':True,'actualScrivExecuted':False,'externalScrivProducerMocked':True,'upstreamReport':python_report,'upstreamRepairApplied':False},'currentMainFailure':{'run':44857673625,'conclusion':'failure','reason':'PyPI 422 invalid-publisher: no configured publisher matches the current claims.','fullLogLines':[153,158,159,160,2393,2394],'ownerActionStillRequired':True},'parserFalsePositive':{'syntax':'$/ self repository action reference','oldParserVersion':'1.7.12','oldParserRejects':True,'officialGitHubSyntaxValid':True,'reportFiled':False},'evidence':str(target.relative_to(root)),'independentAuthorshipCredit':0,'fullIssueComplete':False}
ledger_path=root/'docs/case-studies/issue-1580/templates/python-current-delta-review.json';assert not ledger_path.exists();ledger_path.write_text(json.dumps(ledger,indent=2)+'\n')
doc=root/'docs/case-studies/issue-1580/python-current-findings-checkpoint.md'
doc.write_text(f'''# Current Python review and bounded template findings

The Python template is pinned at {pin}: 338 current blobs and 35
changed files. All 32 changed plain source, workflow, configuration,
documentation and test files have been read completely, along with all 426
generated license lines. The 2.2 MB generated action bundle and 3421-line
dependency lock still need complete comparison. The 338-file, historical and
practice-adoption requirements remain open; retained bytes do not establish
review.

Current release and validation changes include budgeted npm operations,
Secretlint 14, exclusive creation in the manual no-Scriv branch, fail-closed
Git observation, literal-preserving release formatting, same-run Pages
artifact selection and dependency-maintenance checks. Current hosted Python
run 44857673625 fails at full-log lines 153 and 158–160 with PyPI
422 invalid-publisher. Its terminal status at lines 2393–2394 names
release-preflight; the status input reports successful lint, test and build.
The log specifies the required trusted-publisher claims and project setting.
This owner configuration is unresolved.

The Scriv branch still selects a fragment by newest modification time across
the entire directory. The actual Python function overwrites an unrelated
future-dated entry while leaving the new draft untouched. Four maintained
tests use a finite mocked Scriv producer and a disposable candidate that
selects a unique newly created path. The tests cover prior-file preservation,
no-created-file and concurrent-creation refusal, and ordinary success controls.
Python runs with 128 MiB, three CPU seconds and a five-second outer limit.
Scriv itself was not installed or executed. The upstream report is
{python_report} . No upstream repair has been applied.

The old actionlint 1.7.12 rejection of the root-dollar action reference is a
tool false positive. The official GitHub workflow-syntax documentation
explicitly defines the self repository prefix, resolves it at the running
commit, requires no checkout, and forbids a ref suffix. The controlled
Ubuntu 24.04 examples isolate the old parser rejection from runner-label
support. No template defect was reported for valid syntax. The fetched
primary page, exact relevant paragraphs and both parser controls are retained:
https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax#example-using-an-action-in-the-same-repository-as-the-workflow-at-the-running-commit-recommended

The PHP Process defects are now reported at {php_report} .
The seven new PHP/Python observations are maintained executable tests, not
upstream repairs. Every supplied command, patch and conclusion receives zero
independent Formal AI authorship or reasoning credit.

The earlier PHP publication checks pass five valid repository gates and the
actual Secretlint 14 engine on all 28 changed files. The attempted gate name
check-tests-as-documentation is invalid and receives no pass credit.
The underlying node scripts/check-tests-as-docs.mjs checker passes separately;
the native twin parity wrapper was not run locally.

Evidence is retained under {target.relative_to(root)} . All raw and archive
SHA256 values are checked. A full issue conclusion is not implied.
PR: https://github.com/link-assistant/formal-ai/pull/1581
''')
with (root/'experiments/issue-1580/work-plan.md').open('a') as f:f.write(f'''

## Current Python Scriv selection and external report checkpoint

- [x] Read 33 of 35 current changed Python files completely; retain all 35
  source identities and keep generated bundle and lock comparison open.
- [x] Reproduce Scriv selection data loss with four bounded actual-Python
  tests and a mocked external producer; report it at {python_report} .
- [x] Report confirmed PHP Process defects at {php_report} .
- [x] Preserve the invalid gate-name attempt and the successful underlying
  documentation checker separately; preserve the old-parser false positive
  and official primary-source syntax evidence.
- [ ] Publish permanent regression links after preceding head becomes terminal.
- [ ] Finish all 338 Python files, every other full template/practice check
  and all remaining original issue criteria. No complete acceptance claimed.
''')
for record in records:
 packed=(target/record['file']).read_bytes();raw=gzip.decompress(packed)
 assert hashlib.sha256(packed).hexdigest()==record['archiveSha256'] and hashlib.sha256(raw).hexdigest()==record['rawSha256']
(target/'records.json').write_text(json.dumps({'records':records,'allHashesVerified':True,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
paths=['experiments/issue-1580/fixtures/python-current-changeset','experiments/issue-1580/template-python-scriv-integrity.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs',str(target.relative_to(root)),str(ledger_path.relative_to(root)),str(doc.relative_to(root)),'docs/case-studies/issue-1580/templates/php-current-delta-review.json','docs/case-studies/issue-1580/php-process-and-annotation-checkpoint.md','experiments/issue-1580/work-plan.md']
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
subprocess.run(['git','commit','-m','test: preserve current template findings and reproduce Scriv data loss'],cwd=root,check=True)
print(json.dumps({'records':len(records),'literalChangedPythonFiles':33,'remainingChangedPythonFiles':2,'phpReport':php_report,'pythonReport':python_report,'pushExecuted':False,'fullIssueComplete':False}))
