from pathlib import Path
import json,re,subprocess
out=Path('/tmp/issue-1580-research/python-scriv-upstream-report');out.mkdir(exist_ok=False)
repo='link-foundation/python-ai-driven-development-pipeline-template'
r=subprocess.run(['gh','api',f'repos/{repo}/issues?state=all&per_page=100','--paginate','--slurp'],capture_output=True,text=True,check=True)
(out/'all-issues.json').write_text(r.stdout)
items=[item for page in json.loads(r.stdout) for item in page if 'pull_request' not in item]
matches=[item for item in items if re.search(r'\bscriv\b',item['title'],re.I) or re.search(r'\bmtime\b|create_with_scriv|newest fragment|most recent fragment|future.dated',item.get('body') or '',re.I)]
review=['All issue titles:']+[f"#{i['number']} {i['title']} {i['html_url']}" for i in items]
review+=['\nPotential duplicate bodies:']
for item in matches:review.extend([f"\n#{item['number']} {item['title']} {item['html_url']}",item.get('body') or ''])
(out/'duplicate-review.txt').write_text('\n'.join(review)+'\n')
r=subprocess.run(['python3','-c','import importlib.util; print(importlib.util.find_spec("scriv"))'],capture_output=True,text=True)
(out/'scriv-runtime.stdout').write_text(r.stdout);(out/'scriv-runtime.stderr').write_text(r.stderr)
print(json.dumps({'issueCount':len(items),'matchingIssueNumbers':[i['number'] for i in matches],'reviewLines':len(review),'scrivAvailable':r.stdout.strip()}))
