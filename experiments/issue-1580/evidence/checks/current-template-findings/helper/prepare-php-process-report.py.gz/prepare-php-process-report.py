from pathlib import Path
import json,re,subprocess

out=Path('/tmp/issue-1580-research/php-process-upstream-report');out.mkdir(exist_ok=True)
repo='link-foundation/php-ai-driven-development-pipeline-template'
r=subprocess.run(['gh','api',f'repos/{repo}/issues?state=all&per_page=100','--paginate','--slurp'],capture_output=True,text=True,check=True)
(out/'fresh-all-issues.json').write_text(r.stdout)
items=[item for page in json.loads(r.stdout) for item in page if 'pull_request' not in item]
matches=[item for item in items if re.search(r'\bdeadlock\b|\bstdout\b|\bstderr\b|\bproc_open\b|\bpipes?\b',item['title']+'\n'+(item.get('body') or ''),re.I)]
review=['Fresh issue titles (all states):']+[f"#{i['number']} {i['title']} {i['html_url']}" for i in items]
review+=['\nPipe/deadlock-related issue bodies:']
for item in matches:review.extend([f"\n#{item['number']} {item['title']} {item['html_url']}",item.get('body') or ''])
(out/'duplicate-review.txt').write_text('\n'.join(review)+'\n')
body='''At current commit `b61e334703d93a15e08bf1a278e0df0a9d6e98a8`, `Process::run()` drains stdout completely before stderr:

https://github.com/link-foundation/php-ai-driven-development-pipeline-template/blob/b61e334703d93a15e08bf1a278e0df0a9d6e98a8/scripts/src/Process.php

Two independent output-integrity failures are reproducible with the actual helper:

1. A finite child that writes 131072 bytes to stderr before stdout stalls. The stderr pipe fills, the child cannot reach its stdout writes or exit, and the parent waits for stdout EOF without draining stderr.
2. The expressions `stream_get_contents(...) ?: ''` discard a valid literal `"0"` on either stream. A child exiting 7 is returned with the correct exit code but empty stdout and stderr.

From a checkout of the pinned template, this Linux/POSIX probe bounds each PHP process to 32 MiB and kills the entire process group after two seconds. Its child output is finite (262144 bytes total):

```python
import json, os, signal, subprocess
from pathlib import Path

base = Path('scripts/src').resolve()
expression = r"""
require $argv[1]; require $argv[2];
$r = \\LinkFoundation\\Template\\Pipeline\\Process::run(
    [PHP_BINARY, '-d', 'memory_limit=32M', '-r', $argv[3]]);
echo json_encode([$r->exitCode, $r->stdout, $r->stderr], JSON_THROW_ON_ERROR);
"""
cases = {
    'stderr-first': 'fwrite(STDERR,str_repeat("E",131072));fwrite(STDOUT,str_repeat("O",131072));',
    'literal-zero': 'echo "0";fwrite(STDERR,"0");exit(7);',
}
for name, child in cases.items():
    p = subprocess.Popen(
        ['php', '-d', 'memory_limit=32M', '-r', expression,
         str(base / 'ProcessResult.php'), str(base / 'Process.php'), child],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    try:
        stdout, stderr = p.communicate(timeout=2)
        print(name, p.returncode, json.loads(stdout), stderr.decode())
    except subprocess.TimeoutExpired:
        os.killpg(p.pid, signal.SIGKILL)
        p.communicate()
        print(name, 'two-second process-group deadline reached')
```

Observed: `stderr-first` reaches the deadline; `literal-zero` returns `[7, "", ""]`.
Expected: both finite streams finish and all output bytes survive, including literal zero strings.

Three bounded Node regression tests execute these same original PHP source bytes and a disposable repair candidate. The candidate drains nonblocking stdout/stderr concurrently with `stream_select()` and distinguishes failed reads from false-like string values. It preserves both 131072-byte streams, both literal zero strings, small-output controls, and exit codes 0 and 7. All three tests pass under actual PHP 8.5.11. The original and current helper SHA256 is `97a1b126035a71434739ecc962d73c74b44ea8ea802263b74031e04332b43bbf`.

This report documents the current upstream behavior; the disposable candidate has not been applied to this template. A proper repair should also clean up open pipes/processes when reads fail.

Investigation and retained regression evidence: https://github.com/link-assistant/formal-ai/pull/1581 . The test commit is local while the preceding hosted run finishes; a permanent source link will be added after publication. These externally supplied probes receive zero independent Formal AI authorship credit.
'''
(out/'body.md').write_text(body)
print(json.dumps({'issueCount':len(items),'matchingIssueNumbers':[i['number'] for i in matches],'bodyLines':len(body.splitlines()),'review':str(out/'duplicate-review.txt'),'reportCreated':False}))
