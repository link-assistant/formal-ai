from pathlib import Path
import json,subprocess

root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/php-process-upstream-report')
assert not (out/'created.json').exists()
body=(out/'body.md').read_text();assert "\\LinkFoundation\\Template\\Pipeline\\Process::run" in body
r=subprocess.run(['gh','issue','create','--repo','link-foundation/php-ai-driven-development-pipeline-template','--title','Process::run deadlocks on finite stderr-first output and loses literal zero strings','--body-file',str(out/'body.md')],capture_output=True,text=True,check=True)
(out/'create.stdout').write_text(r.stdout);(out/'create.stderr').write_text(r.stderr)
url=r.stdout.strip();assert url.startswith('https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/')
(out/'created.json').write_text(json.dumps({'url':url,'pinnedCommit':'b61e334703d93a15e08bf1a278e0df0a9d6e98a8','upstreamRepairApplied':False,'fullIssueComplete':False},indent=2)+'\n')
path=root/'docs/case-studies/issue-1580/templates/php-current-delta-review.json';ledger=json.loads(path.read_text())
ledger['processPipeObservations']['upstreamReport']=url
ledger['openObservations'][0]=ledger['openObservations'][0].replace('Upstream report remains pending.',f'Upstream report: {url} . No upstream repair has been applied.')
path.write_text(json.dumps(ledger,indent=2)+'\n')
doc=root/'docs/case-studies/issue-1580/php-process-and-annotation-checkpoint.md'
text=doc.read_text().replace('duplicates; the upstream report is pending publication of this evidence.',f'duplicates. The confirmed defects were reported at {url} .\nA permanent regression source link will follow publication of this local commit.')
doc.write_text(text)
plan=root/'experiments/issue-1580/work-plan.md'
with plan.open('a') as f:f.write(f'\n- [x] Report both confirmed PHP Process output defects upstream: {url} .\n- [ ] Add the permanent regression source link after publication; upstream repair remains open.\n')
print(json.dumps({'upstreamReport':url,'fullIssueComplete':False,'pushExecuted':False}))
