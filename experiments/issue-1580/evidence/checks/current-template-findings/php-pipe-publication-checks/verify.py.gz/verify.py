from pathlib import Path
import json,subprocess,time,os
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/php-pipe-publication-checks');results=[]
for gate in ['check-abbreviations','check-file-size','check-readable-code','check-ci-speed','check-runner-labels','check-tests-as-documentation']:
 start=time.monotonic()
 with (out/(gate+'.stdout')).open('wb') as log,(out/(gate+'.stderr')).open('wb') as error:
  r=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate],cwd=root,stdout=log,stderr=error)
 results.append({'name':gate,'exitCode':r.returncode,'seconds':round(time.monotonic()-start,3)});print(json.dumps(results[-1]),flush=True)
paths=subprocess.check_output(['git','diff','--name-only','-z','adeb4ff46c4bb162a82aacbeb0c38bbe9aeebd1a','HEAD'],cwd=root)
selected=[p for p in paths.split(bytes([0])) if p and (root/os.fsdecode(p)).is_file()]
(out/'selection.json').write_text(json.dumps([os.fsdecode(p) for p in selected],indent=2)+'\n')
environment={**os.environ,'SECRETLINT_VERSION':'14.0.0','PATH':'/tmp/issue-1580-research/secretlint-built-in-migration/dependencies/node_modules/.bin'+os.pathsep+os.environ['PATH']}
with (out/'secrets.stdout').open('wb') as log,(out/'secrets.stderr').open('wb') as error:r=subprocess.run(['node','--max-old-space-size=256','scripts/check-secrets-files.mjs'],cwd=root,env=environment,input=bytes([0]).join(selected)+bytes([0]),stdout=log,stderr=error)
results.append({'name':'actual-secretlint-14','exitCode':r.returncode,'selectedFiles':len(selected)})
(out/'outcome.json').write_text(json.dumps({'results':results,'allPassed':all(r['exitCode']==0 for r in results),'fullIssueComplete':False},indent=2)+'\n');print(json.dumps(results[-1]),flush=True)
