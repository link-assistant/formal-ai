import subprocess

subprocess.run(['node', 'scripts/render-status.mjs', '--write'], check=True)
subprocess.run(['node', 'scripts/render-status.mjs', '--check'], check=True)
subprocess.run(['git', 'diff', '--check'], check=True)
subprocess.run(['git', 'add', '--', 'docs/status.md'], check=True)
subprocess.run(['git', 'commit', '-m', 'docs: regenerate the measured handler ledger status'], check=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
print('The maintained generator restored its full output and the working tree is clean.')
