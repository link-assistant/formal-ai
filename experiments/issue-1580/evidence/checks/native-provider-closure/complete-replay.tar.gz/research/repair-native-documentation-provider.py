from pathlib import Path
import re, subprocess

source = Path('rust/src/solver_handlers/documentation_method.rs')
before = source.read_text()
old = "        let (root, path) = declaration.split_once('|')?;\n"
new = '''        let values = crate::seed::split_pipe_list(&declaration);
        let [root, path] = values.as_slice() else {
            return None;
        };
'''
assert before.count(old) == 1
updated = before.replace(old, new)
assert updated.count('root: root.to_owned(),') == 1
assert updated.count('path: path.to_owned(),') == 1
updated = updated.replace('root: root.to_owned(),', 'root: root.clone(),')
updated = updated.replace('path: path.to_owned(),', 'path: path.clone(),')
source.write_text(updated)
subprocess.run(['rustfmt', '--edition', '2024', str(source)], check=True)
after = source.read_text()
before_lines, after_lines = len(before.splitlines()), len(after.splitlines())
delta = after_lines - before_lines
assert before_lines == 319 and delta == 3

ledger = Path('data/meta/core-boundary-ledger.lino')
text = ledger.read_text()
boundary = '  source rust/src/solver_handlers/documentation_method.rs\n'
start = text.index(boundary)
end = text.find('\n  source ', start + len(boundary))
section = text[start:end]
assert section.count('    baseline_lines 319\n') == 1
text = text[:start] + section.replace('    baseline_lines 319\n', f'    baseline_lines {after_lines}\n') + text[end:]
assert text.count('  source_lines_max 36718\n') == 1
text = text.replace('  source_lines_max 36718\n', f'  source_lines_max {36718 + delta}\n')
note = f'  note "Issue #1580 closes the remaining native documentation-provider consumer after reference-list migration. The shared seed reader replaces its pipe split in documentation_method.rs ({before_lines} to {after_lines} lines), adding exactly {delta} promoted interpreter lines; outside-core ceilings, source counts and every disposition stay unchanged."\n'
text = text.replace('core_boundary_ledger\n', 'core_boundary_ledger\n' + note, 1)
ledger.write_text(text)

contracts = Path('rust/tests/unit/reasoning_contracts.rs')
text = contracts.read_text()
assert 'mod issue_1101_documentation_question_parity;' not in text
text += '\n// Preserve all original documentation publisher and routing controls in focused CI.\n#[path = "issue_1101_documentation_question_parity.rs"]\nmod issue_1101_documentation_question_parity;\n'
contracts.write_text(text)
subprocess.run(['rustfmt', '--edition', '2024', str(contracts)], check=True)

test = Path('experiments/issue-1580/native-regression-groups.test.mjs')
text = test.read_text()
text += '''

test('focused reasoning retains the original documentation publisher regressions', () => {
  assert.match(readFileSync('rust/tests/unit/reasoning_contracts.rs', 'utf8'),
    /#\\[path = "issue_1101_documentation_question_parity\\.rs"\\]\\nmod issue_1101_documentation_question_parity;/u);
});
'''
test.write_text(text)
subprocess.run(['node', 'scripts/render-status.mjs', '--write'], check=True)
subprocess.run(['git', 'diff', '--check'], check=True)
print(f'Repaired the remaining native provider, recorded {delta} measured lines, and registered all five existing publisher/routing regressions.')
