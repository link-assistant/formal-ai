from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'workspace-end-edit-extraction'
if len(sys.argv) == 1:
    out.mkdir(exist_ok=False)
    with (out / 'worker.log').open('wb') as stream:
        worker = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print('Started finite workspace end-edit extraction', worker.pid)
    raise SystemExit()
records = []
def run(name, argv):
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=root, env={**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}, stdout=stdout, stderr=stderr)
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == 0, name
    return (out / (name + '.stdout')).read_text()
assert json.loads((scratch / 'tool-result-quotation-extraction/outcome.json').read_text())['passed']
assert not run('index-before', ['git', 'diff', '--cached', '--name-only']).strip()
assert run('branch', ['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
parent = root / 'rust/src/agentic_coding/workspace_computed_change.rs'
child = root / 'rust/src/agentic_coding/workspace_computed_change/end_edit.rs'
assert not child.exists()
original = parent.read_text()
assert len(original.splitlines()) == 903
start_marker = 'fn inserted_at_end('
end_marker = 'impl ComputedChange {\n    /// The seed sentence that states the change'
start = original.index(start_marker)
end = original.index(end_marker, start)
block = original[start:end]
assert block.count('fn ') == 2 and block.endswith('\n\n')
declaration = 'mod end_edit;\n\nuse end_edit::{compact_end_edit, inserted_at_end};\n\n'
new_parent = (original[:start] + original[end:]).replace('use super::general_planner::compose_edit_request;\n', declaration + 'use super::general_planner::compose_edit_request;\n', 1)
imports = 'use super::MAX_ANCHOR_BYTES;\n\n'
new_child = imports + block[:-1].replace('fn inserted_at_end(', 'pub(super) fn inserted_at_end(', 1).replace('fn compact_end_edit(', 'pub(super) fn compact_end_edit(', 1)
restored = new_parent.replace(declaration, '', 1).replace(end_marker, new_child.removeprefix(imports).replace('pub(super) fn ', 'fn ') + '\n' + end_marker, 1)
assert restored == original
assert len(new_parent.splitlines()) < 900 and len(new_child.splitlines()) < 900
parent.write_text(new_parent)
child.write_text(new_child)
proof = {'observedAt': datetime.now(timezone.utc).isoformat(), 'originalSha256': hashlib.sha256(original.encode()).hexdigest(), 'reassembledOriginalSha256': hashlib.sha256(restored.encode()).hexdigest(), 'originalLines': 903, 'parentLines': len(new_parent.splitlines()), 'childLines': len(new_child.splitlines()), 'exactOriginalReconstruction': True, 'localRustExecution': False, 'hostedNativeVerificationPending': True, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
(out / 'inverse-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
(out / 'original-source.rs.gz').write_bytes(gzip.compress(original.encode(), mtime=0))
suffix = 'source_paths = ' + (scratch / 'extract-telegram-markdown.py').read_text().split('source_paths = ', 1)[1]
suffix = suffix.replace('telegram-markdown-extraction', 'workspace-end-edit-extraction')
suffix = suffix.replace("run('telegram-lines-javascript', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/mcp-telegram-lines.test.mjs'])", "run('workspace-line-operations-javascript', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/pull-request-1188-line-operations.test.mjs'])")
suffix = suffix.replace('Separate the unchanged Telegram Markdown renderer into a private module, preserving the existing public entry point and HTML escaping while removing the source-size warning.', 'Separate unchanged file-end insertion and compact anchor selection into a private module to remove the computed workspace change source-size warning.')
suffix = suffix.replace('Extract Telegram Markdown rendering without changing any function body or the public rendering path; exact inverse reconstruction matches the original source. Existing JavaScript Telegram line handling, translation projection and Rust formatting pass.', 'Extract file-end insertion and compact edit anchors without changing any function body, public API or the existing anchor byte bound; exact inverse reconstruction matches the original source. Existing JavaScript line-operation cases, translation projection and Rust formatting pass.')
suffix = suffix.replace('refactor: separate Telegram Markdown rendering below size warning', 'refactor: separate workspace end-edit helpers below size warning')
exec(compile(suffix, __file__, 'exec'))
