import sys;sys.tracebacklimit=0
import subprocess,json,time,os
from pathlib import Path
r=Path("/tmp/issue-1580-research/workflow-tool-installation")
commands=[
("branch-policy",["node","--max-old-space-size=192","--test","--test-concurrency=1","rust/tests/web/default-branch-build-policy.test.mjs"]),
*[(gate,["node","experiments/formal_ai_subagent/local-gates.mjs","--only",gate])for gate in
["workflows","check-runner-labels","check-ci-speed","check-file-size","check-tests-as-docs","check-readable-code"]]]
rows=[]
for name,cmd in commands:
 start=time.monotonic()
 with(r/(name+".log")).open("w")as out:
  result=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 row={"name":name,"command":cmd,"exitCode":result.returncode,"seconds":time.monotonic()-start}
 rows.append(row);(r/"verification.json").write_text(json.dumps(rows,indent=2)+"\n")
 print(json.dumps(row),flush=True)
(r/"verification-outcome.json").write_text(json.dumps({"allPassed":all(x["exitCode"]==0 for x in rows),"commands":len(rows),"fullIssueComplete":False,"independentAuthorshipCredit":0},indent=2)+"\n")
