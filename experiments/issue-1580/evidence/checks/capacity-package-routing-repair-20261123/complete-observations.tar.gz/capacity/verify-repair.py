import json,subprocess,time
from pathlib import Path
root=Path('/tmp/issue-1580-research/capacity-5ce441')
commands=[('fast-profile-repaired', ['node', '--max-old-space-size=192', '--test', '--test-concurrency=1', 'rust/tests/web/fast-pull-request-production-profile.test.mjs']), ('tests-as-docs-after-name', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-tests-as-docs']), ('requirements-after-name', ['node', 'scripts/check-requirement-status.mjs']), ('workflows-final', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'workflows']), ('changelog-final', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-changelog-fragment-js-twin'])]
results=[]
for name,command in commands:
 start=time.monotonic()
 with (root/(name+".stdout")).open("w") as out,(root/(name+".stderr")).open("w") as err:
  completed=subprocess.run(command,stdout=out,stderr=err)
 results.append({"name":name,"command":command,"exitCode":completed.returncode,"seconds":time.monotonic()-start})
 (root/"repair-verification.json").write_text(json.dumps(results,indent=2)+"\n")
(root/"repair-verification-outcome.json").write_text(json.dumps({"commands":len(results),"allPassed":all(row["exitCode"]==0 for row in results),"fullIssueComplete":False,"nativeRustTestsExecuted":False,"independentAuthorshipCredit":0},indent=2)+"\n")
