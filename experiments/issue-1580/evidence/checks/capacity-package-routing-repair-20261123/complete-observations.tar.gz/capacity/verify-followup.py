import json,subprocess,time
from pathlib import Path
root=Path('/tmp/issue-1580-research/capacity-5ce441')
commands=[('maintained-observation-owner', ['node', '--max-old-space-size=192', '--test', '--test-concurrency=1', 'rust/tests/web/issue-1580-template-observations.test.mjs']), ('fast-profile-owner', ['node', '--max-old-space-size=192', '--test', '--test-concurrency=1', 'rust/tests/web/fast-pull-request-production-profile.test.mjs']), ('runner-labels-corrected', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-runner-labels']), ('test-documentation', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-tests-as-docs']), ('test-documentation-twin', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-tests-as-documentation-javascript-twin']), ('requirement-status-read-only', ['node', 'scripts/check-requirement-status.mjs'])]
results=[]
for name,command in commands:
 start=time.monotonic()
 with (root/(name+".stdout")).open("w") as out,(root/(name+".stderr")).open("w") as err:
  completed=subprocess.run(command,stdout=out,stderr=err)
 results.append({"name":name,"command":command,"exitCode":completed.returncode,"seconds":time.monotonic()-start})
 (root/"followup-verification.json").write_text(json.dumps(results,indent=2)+"\n")
(root/"followup-verification-outcome.json").write_text(json.dumps({"commands":len(results),"allPassed":all(row["exitCode"]==0 for row in results),"fullIssueComplete":False,"nativeRustTestsExecuted":False,"independentAuthorshipCredit":0},indent=2)+"\n")
