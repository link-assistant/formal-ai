fn crate_archive_path(rust_root: &str, name: &str, version: &str) -> PathBuf {
    let base = if rust_root == "." {
        PathBuf::from(".")
    } else {
        Path::new(rust_root).to_path_buf()
    };

    base.join("target")
        .join("package")
        .join(crate_archive_name(name, version))
}
