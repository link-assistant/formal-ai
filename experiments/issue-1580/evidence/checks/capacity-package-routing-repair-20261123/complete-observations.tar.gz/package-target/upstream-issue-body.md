The package-size guard looks only in `<rust_root>/target/package`. Cargo can put the newly generated archive elsewhere, so the guard can fail after successful packaging or inspect an older archive at the assumed path.

Current main still contains this assumption in `scripts/check-crate-size.rs:108–118` (blob `81b027f01b40cc4f256922032aea9f63a25f01d7`). I checked the current file against the source reviewed during link-assistant/formal-ai#1580; they are byte-identical. The same defect is being repaired in https://github.com/link-assistant/formal-ai/pull/1581.

A bounded offline probe used a tiny dependency-free package, `cargo metadata --offline --no-deps --format-version 1`, and `cargo package --offline --allow-dirty --no-verify`. It performed no compilation. Results:

| Layout | Cargo target directory relative to fixture | Hardcoded archive lookup |
| --- | --- | --- |
| Single package, default | `rust/target` | Matches |
| Absolute `CARGO_TARGET_DIR` | `shared-target` | Missing |
| Relative `CARGO_TARGET_DIR` | `rust/relative-target` | Missing |
| `.cargo/config.toml` build target directory | `configured-target` | Missing |
| Workspace member at `rust/` | `target` | Missing |

Each actual archive exists and is 784 bytes. The archived probe and complete outputs will be linked from the Formal AI PR.

Minimal packaging reproduction:

```bash
probe_root=$(mktemp -d)
mkdir -p "$probe_root/rust/src"
printf '[package]\nname="archive-target-fixture"\nversion="0.1.0"\nedition="2021"\n' > "$probe_root/rust/Cargo.toml"
printf 'pub fn fixture() {}\n' > "$probe_root/rust/src/lib.rs"
export CARGO_TARGET_DIR="$probe_root/shared-target"
cargo package --offline --allow-dirty --no-verify --manifest-path "$probe_root/rust/Cargo.toml"
test -f "$probe_root/shared-target/package/archive-target-fixture-0.1.0.crate"
test ! -f "$probe_root/rust/target/package/archive-target-fixture-0.1.0.crate"
```

The template guard itself was inspected, not executed in this constrained development container. The observations above are actual Cargo metadata and packaging executions.

Please resolve the target directory from Cargo metadata using the same working directory and environment as packaging, then inspect that archive. Preserve metadata/packaging failures and reject an unknown target directory instead of falling back to a potentially stale default archive. A regression should include both custom targets and a workspace member, plus an old archive at the default path.
