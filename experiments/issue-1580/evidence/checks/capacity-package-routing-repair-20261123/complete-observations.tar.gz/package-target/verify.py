import sys;sys.tracebacklimit=0
import subprocess,json,time
from pathlib import Path
r=Path("/tmp/issue-1580-research/package-archive-target")
commands=[
("rustfmt",["rustfmt","--edition","2024","--config","skip_children=true","--check","scripts/check-crate-package-size.rs","rust/tests/unit/workflow_contracts.rs"]),
("branch-policy",["node","--max-old-space-size=192","--test","--test-concurrency=1","rust/tests/web/default-branch-build-policy.test.mjs"]),
("checkout-owner",["node","--max-old-space-size=192","--test","--test-concurrency=1","rust/tests/web/ci-change-detection-checkout.test.mjs"]),
*[(gate,["node","experiments/formal_ai_subagent/local-gates.mjs","--only",gate])for gate in
["workflows","check-ci-speed","check-file-size","check-file-size-js-twin","check-readable-code","check-changelog-fragment-js-twin","check-required-documentation"]]]
rows=[]
for name,cmd in commands:
 start=time.monotonic()
 with(r/(name+".log")).open("w")as out:
  v=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 row={"name":name,"command":cmd,"exitCode":v.returncode,"seconds":time.monotonic()-start}
 rows.append(row);(r/"verification.json").write_text(json.dumps(rows,indent=2)+"\n")
 print(json.dumps(row),flush=True)
(r/"verification-outcome.json").write_text(json.dumps({"allPassed":all(x["exitCode"]==0 for x in rows),"commands":len(rows),"nativeRustTestsExecuted":False,"fullIssueComplete":False,"independentAuthorshipCredit":0},indent=2)+"\n")
