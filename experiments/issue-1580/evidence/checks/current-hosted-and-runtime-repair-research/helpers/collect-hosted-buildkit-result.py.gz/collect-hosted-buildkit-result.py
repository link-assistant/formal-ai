from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess, sys, traceback

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research/hosted-buildkit-3bb3083b')
base = root / 'experiments/issue-1580/evidence/ci/buildkit-bootstrap-3bb3083b'
scratch.mkdir(exist_ok=False)
base.mkdir(exist_ok=False)
records = []
def run(name, argv, parsed=False, checked=True):
    result = subprocess.run(argv, cwd=root, capture_output=True)
    row = {'name': name, 'argv': argv, 'exitCode': result.returncode,
           'observedAt': datetime.now(timezone.utc).isoformat()}
    for kind, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
        packed = gzip.compress(raw, mtime=0)
        filename = name + '.' + kind + '.gz'
        (base / filename).write_bytes(packed)
        row[kind] = {'file': filename, 'bytes': len(raw), 'lines': len(raw.splitlines()),
                     'rawSha256': hashlib.sha256(raw).hexdigest(),
                     'archiveSha256': hashlib.sha256(packed).hexdigest()}
    records.append(row)
    (base / 'records.json').write_text(json.dumps(records, separators=(',', ':')) + '\n')
    if checked:
        assert result.returncode == 0, (name, result.stderr.decode(errors='replace')[-2000:])
    return json.loads(result.stdout) if parsed else result.stdout
try:
    state = run('state', ['gh', 'run', 'view', '44764893157', '--repo', 'link-assistant/formal-ai',
                         '--json', 'headSha,status,conclusion,jobs,url,event'], True)
    assert state['headSha'] == '3bb3083ba9d91dbb3b45386083875a1adb9a92f2'
    assert state['status'] == 'completed'
    for job in state['jobs']:
        if 'BuildKit' in job['name'] or job['conclusion'] not in ['success', 'skipped']:
            run('job-' + str(job['databaseId']), ['gh', 'run', 'view', '44764893157',
                '--repo', 'link-assistant/formal-ai', '--job', str(job['databaseId']), '--log'])
    pages = run('artifacts', ['gh', 'api', 'repos/link-assistant/formal-ai/actions/runs/44764893157/artifacts',
                             '--paginate', '--slurp'], True)
    artifacts = [a for p in pages for a in p['artifacts'] if a['name'] == 'buildkit-bootstrap-identity']
    copied = []
    for artifact in artifacts:
        assert not artifact['expired']
        destination = scratch / 'download' / str(artifact['id'])
        destination.mkdir(parents=True)
        run('download-' + str(artifact['id']), ['gh', 'run', 'download', '44764893157', '--repo',
            'link-assistant/formal-ai', '--name', artifact['name'], '--dir', str(destination)])
        for source in sorted(destination.rglob('*')):
            if not source.is_file():
                continue
            assert not source.is_symlink()
            raw = source.read_bytes()
            relative = source.relative_to(destination).as_posix()
            filename = 'producer-' + str(artifact['id']) + '-' + relative.replace('/', '_') + '.gz'
            packed = gzip.compress(raw, mtime=0)
            (base / filename).write_bytes(packed)
            copied.append({'artifact': artifact, 'relativePath': relative, 'file': filename,
                           'bytes': len(raw), 'lines': len(raw.splitlines()),
                           'rawSha256': hashlib.sha256(raw).hexdigest(),
                           'archiveSha256': hashlib.sha256(packed).hexdigest()})
    (base / 'producer-files.json').write_text(json.dumps(copied, indent=2) + '\n')
    outcome = {'complete': True, 'head': state['headSha'], 'url': state['url'],
               'workflowConclusion': state['conclusion'], 'jobs': state['jobs'],
               'artifactCount': len(artifacts), 'producerFiles': len(copied),
               'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
    (base / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    (scratch / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    print(json.dumps({k:v for k,v in outcome.items() if k != 'jobs'}))
except BaseException:
    traceback.print_exc()
    (scratch / 'failure.json').write_text(json.dumps({'complete':False, 'traceback':traceback.format_exc()})+'\n')
    sys.exit(1)
