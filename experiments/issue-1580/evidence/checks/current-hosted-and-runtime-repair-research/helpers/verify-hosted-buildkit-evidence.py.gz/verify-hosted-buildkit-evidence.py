from pathlib import Path
from datetime import datetime, timezone
import base64,gzip,hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/ci/buildkit-bootstrap-3bb3083b'
scratch=Path('/tmp/issue-1580-research/hosted-buildkit-3bb3083b')
files=json.loads((base/'producer-files.json').read_text());records=json.loads((base/'assessment-records.json').read_text()) if (base/'assessment-records.json').exists() else []
raws={}
for row in files:
 packed=(base/row['file']).read_bytes();raw=gzip.decompress(packed)
 assert hashlib.sha256(packed).hexdigest()==row['archiveSha256']
 assert hashlib.sha256(raw).hexdigest()==row['rawSha256']
 assert (len(raw),len(raw.splitlines()))==(row['bytes'],row['lines'])
 raws[row['relativePath']]=raw
def fetch(name,args):
 result=subprocess.run(args,cwd=root,capture_output=True)
 row={'name':name,'argv':args,'exitCode':result.returncode}
 for label,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
  filename='assessment-'+name+'.'+label+'.gz';packed=gzip.compress(raw,mtime=0)
  (base/filename).write_bytes(packed)
  row[label]={'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())}
 records.append(row);(base/'assessment-records.json').write_text(json.dumps(records,separators=(',',':'))+'\n')
 assert result.returncode==0,(name,result.stderr.decode())
 return result.stdout
context=json.loads(raws['context.json']);head='3bb3083ba9d91dbb3b45386083875a1adb9a92f2'
merge=json.loads(fetch('binding-merge-git-commit',['gh','api','repos/link-assistant/formal-ai/git/commits/'+context['head']]))
parents=[row['sha'] for row in merge['parents']];assert head in parents
source=[]
for name,path in [('action','.github/actions/setup-buildx-resilient/action.yml'),('workflow','.github/workflows/workflows.yml'),('probe','experiments/issue-1580/buildkit-bootstrap-probe.py')]:
 published=subprocess.check_output(['git','show',head+':'+path],cwd=root)
 response=json.loads(fetch('merge-'+name,['gh','api','repos/link-assistant/formal-ai/contents/'+path+'?ref='+context['head'],'--paginate']))
 actual=base64.b64decode(response['content']);assert actual==published
 if name=='action':assert actual==raws['action.yml'] and hashlib.sha256(actual).hexdigest()==context['actionSha256']
 source.append({'path':path,'sha256':hashlib.sha256(actual).hexdigest(),'publishedHeadEqualsTestedMerge':True})
assert context['runId']=='44764893157'
canonical=context['canonical'];observations=[]
for phase in ['initial','mirror']:
 verified=json.loads(raws[phase+'-verified.json']);image=json.loads(raws[phase+'-image.stdout'])[0];container=json.loads(raws[phase+'-container.stdout'])[0]
 selected=canonical if phase=='initial' else 'mirror.gcr.io/'+canonical
 assert verified['actualDockerBootVerified'] and verified['selectedImage']==selected
 assert verified['imageId']==image['Id']==container['Image'] and container['State']['Running']
 assert verified['containerId']==container['Id'] and container['Config']['Image']==selected
 assert selected in [r.removeprefix('docker.io/') for r in image['RepoDigests']]
 for kind in ['builder','image','container']:assert json.loads(raws[phase+'-'+kind+'.result.json'])['exitCode']==0
 assert 'Status:                running' in raws[phase+'-builder.stdout'].decode()
 observations.append({'phase':phase,'selectedImage':selected,'imageId':image['Id'],'containerId':container['Id'],'actualDockerBootVerified':True})
assert observations[0]['imageId']==observations[1]['imageId']
failures=[json.loads(line) for line in raws['injected-failures.jsonl'].splitlines()]
assert failures==[{'kind':'deliberate-canonical-pull-failure','image':canonical}]
outcome={'observedAt':datetime.now(timezone.utc).isoformat(),'publishedHead':head,'testedMerge':context['head'],'mergeParents':parents,'sourceIdentities':source,'artifactStreamsVerified':len(files),'observations':observations,'actualCanonicalPullFailureCount':len(failures),'runUrl':'https://github.com/link-assistant/formal-ai/actions/runs/44764893157','fullIssueComplete':False,'independentAuthorshipCredit':0}
(base/'assessment.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome,indent=2))
