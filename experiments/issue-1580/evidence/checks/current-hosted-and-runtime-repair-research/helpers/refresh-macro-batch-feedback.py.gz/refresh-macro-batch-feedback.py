from pathlib import Path
import json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/macro-batch-feedback')
base.mkdir(exist_ok=False)
records = []
def run(name, argv, parsed=False):
    result = subprocess.run(argv, cwd=root, capture_output=True)
    for label in ('stdout', 'stderr'):
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, name
    return json.loads(result.stdout) if parsed else result.stdout.decode()

assert run('branch', ['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
run('fetch-main', ['git', 'fetch', 'origin', 'main'])
main = run('main', ['git', 'rev-parse', 'origin/main']).strip()
head = run('head', ['git', 'rev-parse', 'HEAD']).strip()
run('main-ancestor', ['git', 'merge-base', '--is-ancestor', main, head])
run('issue', ['gh', 'issue', 'view', 'https://github.com/link-assistant/formal-ai/issues/1580', '--json', 'title,body,state,url,updatedAt'])
for name, endpoint in [('issue-comments', 'issues/1580/comments'), ('conversation', 'issues/1581/comments'), ('inline', 'pulls/1581/comments'), ('reviews', 'pulls/1581/reviews')]:
    rows = run(name, ['gh', 'api', 'repos/link-assistant/formal-ai/' + endpoint, '--paginate'], True)
    print(name, len(rows))
    for row in rows:
        print(json.dumps({key: row.get(key) for key in ('html_url', 'updated_at', 'state', 'body')}, ensure_ascii=False))
for status in ('in_progress', 'queued'):
    rows = run(status, ['gh', 'run', 'list', '--repo', 'link-assistant/formal-ai', '--branch', 'issue-1580-8d61a32a61e1', '--status', status, '--limit', '100', '--json', 'databaseId,workflowName,headSha'], True)
    print(status, json.dumps(rows))
run('published-diff', ['gh', 'pr', 'diff', '1581', '--repo', 'link-assistant/formal-ai'])
print('Fresh main is already an ancestor:', main, '; local head:', head)
