from pathlib import Path
import hashlib,json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');base=Path('/tmp/issue-1580-research/runtime-source-commits');base.mkdir(exist_ok=False)
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
fragment=root/'changelog.d/issue-1580-maintenance-and-retry-observation.md'
fragment.write_text('Require a complete successful lockfile inventory before dependency maintenance resolves any package, and keep transient-link request timers and retry waits within their shared budget.\n')
(root/'changelog.d/issue-1580-macro-context-observation.md').write_text('Add an optional read-only observation of original and expanded source macro contexts in the existing hosted CodeQL Rust database, retaining query/pack metadata and raw diagnostic outputs without replacing the security suite.\n')
tested=root/'experiments/issue-1580/evidence/checks/template-runtime-and-macro-observation-verified/source-identities.json'
for row in json.loads(tested.read_text()):assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256'],row
groups=[['.github/workflows/dependencies-latest.yml','scripts/recheck-broken-links.mjs','rust/tests/web/dependencies-maintenance-workflow.test.mjs','scripts/recheck-broken-links.test.mjs',fragment.relative_to(root).as_posix()],
 ['.github/workflows/security.yml','experiments/issue-1580/codeql-macro-contexts/observe.py','experiments/issue-1580/codeql-macro-contexts/MacroContexts.ql','experiments/issue-1580/codeql-macro-contexts/README.md','rust/tests/web/security-codeql-results.test.mjs','changelog.d/issue-1580-macro-context-observation.md']]
paths=[p for group in groups for p in group]
for name,args in [('branch',['git','branch','--show-current']),('secrets',['bash','scripts/check-secrets.sh',*paths]),('whitespace',['git','diff','--check'])]:
 with (base/(name+'.stdout')).open('wb') as stdout,(base/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 assert result.returncode==0,(name,(base/(name+'.stderr')).read_text()[-2000:])
 if name=='branch':assert (base/(name+'.stdout')).read_text().strip()=='issue-1580-8d61a32a61e1'
(base/'groups.json').write_text(json.dumps(groups,indent=2)+'\n')
(base/'source-identities.json').write_text(json.dumps([{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in paths],indent=2)+'\n')
print('Verified tested source identities, secret scan and whitespace for',len(paths),'source/release inputs. Two atomic local commits prepared; no push.')
