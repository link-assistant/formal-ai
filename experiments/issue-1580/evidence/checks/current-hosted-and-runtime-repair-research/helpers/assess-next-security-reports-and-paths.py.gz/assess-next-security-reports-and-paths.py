from pathlib import Path
from collections import Counter
import gzip,hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/ci/codeql-producer-3bb3083b'
reports=[];current=None
def decode(folder,record):
 packed=(folder/record['file']).read_bytes();raw=gzip.decompress(packed)
 assert hashlib.sha256(packed).hexdigest()==record['archiveSha256'] and hashlib.sha256(raw).hexdigest()==record['rawSha256']
 assert len(raw)==record['bytes'];return json.loads(raw)
for record in json.loads((base/'producer-files.json').read_text()):
 document=decode(base,record)
 for run in document['runs']:
  notifications=[r for i in run.get('invocations',[]) for field in ['toolExecutionNotifications','toolConfigurationNotifications'] for r in i.get(field,[])]
  warnings=[r for r in notifications if r.get('level','warning') in ['warning','error']]
  assert not warnings and not run.get('results',[]) and all(i.get('executionSuccessful') for i in run.get('invocations',[]))
  reports.append({'report':record['relativePath'],'originalSha256':record['rawSha256'],'toolVersion':run['tool']['driver'].get('semanticVersion'),'findings':0,'warningOrErrorNotifications':0,'notificationLevels':dict(Counter(r.get('level','warning') for r in notifications))})
  if record['relativePath']=='rust.sarif':current=notifications
assert current is not None
def paths(rows):return {l['physicalLocation']['artifactLocation']['uri'] for r in rows for l in r.get('locations',[])}
expected=paths([r for r in current if r.get('descriptor',{}).get('id')=='cli/expected-extracted-files/rust'])
extracted=paths([r for r in current if r.get('descriptor',{}).get('id')=='rust/diagnostics/successfully-extracted-files'])
assert expected==extracted and len(expected)==2576
prior=root/'experiments/issue-1580/evidence/ci/codeql-producer-ad59ff56';record=next(r for r in json.loads((prior/'producer-files.json').read_text()) if r['relativePath']=='rust.sarif')
old=decode(prior,record)['runs'][0]
oldcontexts=[r for i in old.get('invocations',[]) for r in i.get('toolExecutionNotifications',[]) if 'semantic analyzer unavailable (no manifest found)' in r.get('message',{}).get('text','')]
contextpaths=paths(oldcontexts);assert len(contextpaths)==105 and contextpaths<=extracted
macros=[r for r in current if r.get('descriptor',{}).get('id')=='rust/diagnostics/unresolved-macro-calls'];assert len(macros)==631
outcome={'head':'3bb3083ba9d91dbb3b45386083875a1adb9a92f2','reports':reports,'expectedRustFiles':len(expected),'extractedRustFiles':len(extracted),'missingExpectedRustFiles':sorted(expected-extracted),'formerlyMissingContextPaths':[{'path':p,'currentlyExtracted':p in extracted} for p in sorted(contextpaths)],'unresolvedMacroNotifications':len(macros),'allMacroSemanticsVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(base/'assessment.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps({k:v for k,v in outcome.items() if k!='formerlyMissingContextPaths'},indent=2))
