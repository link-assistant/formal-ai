from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path('/tmp/gh-issue-solver-1794900398048');base=Path('/tmp/issue-1580-research/runtime-source-commits');step=int(sys.argv[1]);assert step in (0,1)
groups=json.loads((base/'groups.json').read_text());paths=groups[step]
frozen={r['path']:r['sha256'] for r in json.loads((base/'source-identities.json').read_text())}
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==frozen[p] for p in paths)
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
title=['fix: preserve maintenance inventory failures and shared retry deadlines','feat: observe macro contexts in the original read-only CodeQL database'][step]
for name,args in [('stage',['git','add','--',*paths]),('commit',['git','commit','--only','-m',title,'--',*paths])]:
 with (base/(str(step)+'-'+name+'.stdout')).open('wb') as stdout,(base/(str(step)+'-'+name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 assert result.returncode==0,(name,(base/(str(step)+'-'+name+'.stderr')).read_text()[-2000:])
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
(base/(str(step)+'-outcome.json')).write_text(json.dumps({'head':head,'paths':paths,'pushExecuted':False,'independentAuthorshipCredit':0},indent=2)+'\n');print(title,head)
