import {writeFileSync} from 'node:fs';
import * as previous from './previous.mjs';
import * as current from './candidate.mjs';
const changes=[];
function compare(a,b,path){
 if(JSON.stringify(a)===JSON.stringify(b))return;
 if(a&&b&&typeof a==='object'&&typeof b==='object'){
  if(Array.isArray(a)&&Array.isArray(b)&&a.length!==b.length)changes.push({path,oldLength:a.length,newLength:b.length});
  for(const key of new Set([...Object.keys(a),...Object.keys(b)]))compare(a[key],b[key],path+'.'+key);
 }else changes.push({path,previous:a,current:b});
}
compare(previous,current,'exports');writeFileSync(new URL('./delta.json',import.meta.url),JSON.stringify(changes,null,2)+'\n');console.log(JSON.stringify({exportKeys:Object.keys(current),changes:changes.length}));
