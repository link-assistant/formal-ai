// Supplied relocation procedure; only lexical parent paths change.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {lex} from '/tmp/gh-issue-solver-1794900398048/scripts/self-translation/lexer.mjs';
const out='/tmp/issue-1580-research/final-native-special-selection';
const records=JSON.parse(readFileSync(out+'/selection.json'));
for(const row of records){
 const source=readFileSync(row.bodyFile,'utf8'),tokens=lex(source,'Rust');const edits=[];
 for(let i=0;i<tokens.length-1;i++)if(tokens[i].type==='ident'&&tokens[i].text==='super'&&tokens[i+1].text==='::')edits.push(tokens[i].start);
 let moved=source;for(const start of [...edits].reverse())moved=moved.slice(0,start)+'super::'+moved.slice(start);
 let restored=moved;for(let i=edits.length-1;i>=0;i--){const start=edits[i]+i*7;assert.equal(restored.slice(start,start+7),'super::');restored=restored.slice(0,start)+restored.slice(start+7);}
 assert.equal(restored,source);if(row.kind==='impl')assert.equal(edits.length,0);if(row.kind==='types')assert.equal(edits.length,1);
 row.parentPathInsertions=edits.length;row.exactInverse=true;row.movedBodyFile=row.bodyFile.replace('.original.rs','.relocated.rs');writeFileSync(row.movedBodyFile,moved);
}
writeFileSync(out+'/qualified.json',JSON.stringify(records,null,2)+'\n');console.log(JSON.stringify(records.map(x=>({owner:x.owner,parentPathInsertions:x.parentPathInsertions,exactInverse:x.exactInverse}))));
