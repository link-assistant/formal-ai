from pathlib import Path
import hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/final-native-special-selection');out.mkdir(exist_ok=False)
inventory=json.loads(Path('/tmp/issue-1580-research/runtime-headroom-leaf-inventory/inventory.json').read_text());records=[]
for owner,name,child in [('rust/src/agentic_coding/planner.rs','plan_chat_step_routes','request_routes'),('rust/src/agentic_coding/command_reroute.rs','recipe_step','recipe_execution')]:
 source=(root/owner).read_text();item=next(item for row in inventory if row['owner']==owner for item in row['candidates'] if item['name']==name)
 body=source[item['start']:item['end']];assert item['excluded'] and set(item['excluded'])=={'super::'}
 path=out/(child+'.original.rs');path.write_text(body)
 records.append({'owner':owner,'target':str(Path(owner).with_suffix('')/str(child+'.rs')),'child':child,'bodyFile':str(path),'bodySha256':hashlib.sha256(body.encode()).hexdigest(),'sourceSha256':hashlib.sha256(source.encode()).hexdigest(),'names':[name],'visibility':'','kind':'function'})
owner='rust/src/formalization/text_statements.rs';source=(root/owner).read_text();start=source.index('/// What one word of a clause is.');end=source.index('/// A letter, mark or number of any script:');body=source[start:end];path=out/'types.original.rs';path.write_text(body)
records.append({'owner':owner,'target':'rust/src/formalization/text_statements/types.rs','child':'types','bodyFile':str(path),'bodySha256':hashlib.sha256(body.encode()).hexdigest(),'sourceSha256':hashlib.sha256(source.encode()).hexdigest(),'names':['Polarity','Sentence','Statement','Token','Word','WordKind'],'kind':'types'})
owner='rust/tests/source/solver.rs';source=(root/owner).read_text();start=source.index('impl UniversalSolver {');end=source.index('/// Mirrors [`UniversalSolver::solve`]');body=source[start:end];path=out/'solver_execution.original.rs';path.write_text(body)
assert 'super::' not in body and 'self::' not in body
records.append({'owner':owner,'target':'rust/tests/source/solver/execution.rs','child':'execution','bodyFile':str(path),'bodySha256':hashlib.sha256(body.encode()).hexdigest(),'sourceSha256':hashlib.sha256(source.encode()).hexdigest(),'names':['UniversalSolver'],'kind':'impl'})
(out/'selection.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps([{'owner':row['owner'],'kind':row['kind'],'lines':len(Path(row['bodyFile']).read_text().splitlines())} for row in records]))
