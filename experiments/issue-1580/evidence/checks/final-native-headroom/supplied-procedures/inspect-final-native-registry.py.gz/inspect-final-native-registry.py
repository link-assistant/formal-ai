from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/final-native-registry-review');out.mkdir(exist_ok=False)
registry=root/'scripts/lib/generated-native-programs.mjs';(out/'previous.mjs').write_bytes(registry.read_bytes())
for name,args in [('generation',['node','--max-old-space-size=256','scripts/lib/generate-native-specification-programs.mjs']),('currency',['node','--max-old-space-size=256','scripts/lib/generate-native-specification-programs.mjs','--check'])]:
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 assert r.returncode==0,(name,r.returncode)
(out/'candidate.mjs').write_bytes(registry.read_bytes())
code='''import {writeFileSync} from 'node:fs';
import * as previous from './previous.mjs';
import * as current from './candidate.mjs';
const changes=[];
function compare(a,b,path){
 if(JSON.stringify(a)===JSON.stringify(b))return;
 if(a&&b&&typeof a==='object'&&typeof b==='object'){
  if(Array.isArray(a)&&Array.isArray(b)&&a.length!==b.length)changes.push({path,oldLength:a.length,newLength:b.length});
  for(const key of new Set([...Object.keys(a),...Object.keys(b)]))compare(a[key],b[key],path+'.'+key);
 }else changes.push({path,previous:a,current:b});
}
compare(previous,current,'exports');writeFileSync(new URL('./delta.json',import.meta.url),JSON.stringify(changes,null,2)+'\\n');console.log(JSON.stringify({exportKeys:Object.keys(current),changes:changes.length}));
'''
(out/'compare.mjs').write_text(code)
with (out/'compare.stdout').open('w') as stdout,(out/'compare.stderr').open('w') as stderr:r=subprocess.run(['node','--max-old-space-size=256',str(out/'compare.mjs')],cwd=root,stdout=stdout,stderr=stderr)
assert r.returncode==0
print((out/'compare.stdout').read_text());print((out/'delta.json').read_text()[:14000])
