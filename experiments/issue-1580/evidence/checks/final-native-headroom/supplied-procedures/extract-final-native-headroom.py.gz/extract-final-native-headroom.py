from pathlib import Path
import hashlib,json,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'final-native-headroom-extraction'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':result.returncode}),flush=True);assert result.returncode in allowed,(name,result.returncode)
def preimage(owner):
 path=out/'preimages'/owner;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((root/owner).read_bytes())
try:
 assert json.loads((scratch/'runtime-leaf-headroom-preservation/outcome.json').read_text())['complete']
 simple=json.loads((scratch/'final-native-headroom-selection/selection.json').read_text());special=json.loads((scratch/'final-native-special-selection/qualified.json').read_text())
 rows=[{'owner':row['owner'],'helpers':[row['target']]} for row in simple+special];rows.append({'owner':'rust/examples/generate_grammar_projection_rules/rules.rs','helpers':['rust/examples/generate_grammar_projection_rules/rules/primary_spine.rs','rust/examples/generate_grammar_projection_rules/rules/reverse_spine.rs']})
 test=root/'experiments/issue-1580/final-native-headroom.test.mjs';assert not test.exists();test.write_text('''// Replay the real unchanged-limit scanner against the final large native owners.
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import test from 'node:test';
import {checkListedFiles} from '../../scripts/check-file-size.mjs';
const root=fileURLToPath(new URL('../../',import.meta.url)).replace(/\\/$/u,'');
for(const {owner,helpers} of '''+json.dumps(rows,indent=2)+''') test(owner+' retains source headroom',()=>{
 assert.deepEqual(checkListedFiles(root,new Set([owner,...helpers])),{warnings:[],violations:[],embeddedDataViolations:[]});
});
''');run('headroom-before',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)],(1,))
 conservation=[];files=[]
 for row in simple:
  owner=root/row['owner'];source=owner.read_text();assert hashlib.sha256(source.encode()).hexdigest()==row['sourceSha256'];preimage(row['owner']);helper='use super::*;\n\n';changed=source;inverse=[]
  for index,item in enumerate(sorted(row['items'],key=lambda x:x['start'])):
   body=source[item['start']:item['end']];assert hashlib.sha256(body.encode()).hexdigest()==item['bodySha256'];visibility=item['visibility'];child_visibility={'':'pub(super) ','pub(super) ':'pub(in super::super) '}.get(visibility,visibility)
   declaration=visibility+'fn '+item['name'];assert body.count(declaration)==1;moved=body.replace(declaration,child_visibility+'fn '+item['name'],1);assert moved.replace(child_visibility+'fn '+item['name'],declaration,1)==body
   helper+=moved+'\n';replacement=('' if index else '#[path = "'+str(Path(row['target']).relative_to(owner.parent.relative_to(root)))+'"]\nmod '+row['child']+';\n')+visibility+'use '+row['child']+'::'+item['name']+';\n';assert changed.count(body)==1;changed=changed.replace(body,replacement,1);inverse.append((replacement,body))
  restored=changed
  for replacement,body in reversed(inverse):restored=restored.replace(replacement,body,1)
  assert restored==source;target=root/row['target'];target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_text(helper);owner.write_text(changed)
  conservation.append({**row,'ownerExactInverseBeforeFormatting':True,'completeBodiesAndCommentsConserved':True,'visibilityAncestorPreserved':True});files.extend([row['owner'],row['target']])
 for row in special:
  owner=root/row['owner'];source=owner.read_text();assert hashlib.sha256(source.encode()).hexdigest()==row['sourceSha256'];preimage(row['owner']);body=Path(row['bodyFile']).read_text();moved=Path(row['movedBodyFile']).read_text();assert row['exactInverse'];relative=str(Path(row['target']).relative_to(owner.parent.relative_to(root)));replacement='#[path = "'+relative+'"]\nmod '+row['child']+';\n'
  if row['kind']=='function':
   name=row['names'][0];assert moved.count('fn '+name+'(')==1;moved=moved.replace('fn '+name+'(','pub(super) fn '+name+'(',1);replacement+='use '+row['child']+'::'+name+';\n';prelude='use super::*;\n\n'
  elif row['kind']=='types':replacement+='pub use '+row['child']+'::{'+', '.join(row['names'])+'};\n\n';prelude=''
  else:prelude='use super::*;\nuse std::fmt::Write as _;\n\n'
  assert source.count(body)==1;changed=source.replace(body,replacement,1);assert changed.replace(replacement,body,1)==source
  if row['kind']=='impl':assert changed.count('use std::fmt::Write as _;\n')==1;changed=changed.replace('use std::fmt::Write as _;\n','',1)
  target=root/row['target'];target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_text(prelude+moved);owner.write_text(changed);conservation.append({**row,'ownerExactInverseBeforeFormatting':True,'completeBodiesAndCommentsConserved':True,'visibilityAncestorPreserved':True,'anonymousFormattingTraitRelocated':row['kind']=='impl'});files.extend([row['owner'],row['target']])
 owner=root/'rust/examples/generate_grammar_projection_rules/rules.rs';source=owner.read_text();preimage(str(owner.relative_to(root)));start=source.index('    // rust → javascript');middle=source.index('    // javascript / typescript → rust:');end=source.rindex('];');parts=[source[start:middle],source[middle:end]];assert ''.join(parts)==source[start:end]
 for name,body in zip(['primary_spine','reverse_spine'],parts):
  target=owner.with_suffix('')/(name+'.rs');target.parent.mkdir(exist_ok=True);assert not target.exists();target.write_text('use super::RuleRow;\n\n// Projection placeholders are not format strings.\n#[allow(clippy::literal_string_with_formatting_args)]\npub(super) const RULE_ROWS: &[RuleRow] = &[\n'+body+'];\n');files.append(str(target.relative_to(root)))
 owner.write_text(source[:source.index('// The template literals')]+'''mod primary_spine;
mod reverse_spine;

/// Ordered rule groups preserve first-match claim resolution across both directions.
pub const RULE_ROW_GROUPS: &[&[RuleRow]] = &[primary_spine::RULE_ROWS, reverse_spine::RULE_ROWS];
''');main=root/'rust/examples/generate_grammar_projection_rules/main.rs';preimage(str(main.relative_to(root)));text=main.read_text();assert text.count('use rules::RULE_ROWS;')==1 and text.count('for row in RULE_ROWS {')==1;main.write_text(text.replace('use rules::RULE_ROWS;','use rules::RULE_ROW_GROUPS;').replace('for row in RULE_ROWS {','for row in RULE_ROW_GROUPS.iter().flat_map(|rows| rows.iter()) {'));files.extend([str(owner.relative_to(root)),str(main.relative_to(root))]);conservation.append({'owner':str(owner.relative_to(root)),'allRuleBodiesAndCommentsConserved':True,'orderedConcatenationExact':True,'groupSha256':[hashlib.sha256(body.encode()).hexdigest() for body in parts],'nativeGenerationVerified':False})
 (out/'conservation.json').write_text(json.dumps(conservation,indent=2)+'\n');(out/'changed-native-files.json').write_text(json.dumps(files,indent=2)+'\n')
 issue=root/'rust/tests/web/issue-1580-template-observations.test.mjs';text=issue.read_text();addition="import '../../../experiments/issue-1580/final-native-headroom.test.mjs';\n";assert addition not in text;issue.write_text(text+'\n'+addition)
 run('rustfmt',['rustfmt','--edition','2024','--config','skip_children=true',*files]);run('rustfmt-check',['rustfmt','--check','--edition','2024','--config','skip_children=true',*files])
 run('headroom-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)])
 run('projection-currency',['node','--max-old-space-size=256','scripts/translate-js-rust.mjs','--verify'])
 run('native-registry-currency',['node','--max-old-space-size=256','scripts/lib/generate-native-specification-programs.mjs','--check'])
 run('maintained-observations',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(issue)])
 run('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-abbreviations,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-changelog-fragment-js-twin,check-reconstructed-changelog'])
 run('source-warnings',['node','--max-old-space-size=256','scripts/check-file-size.mjs']);warnings=(out/'source-warnings.stdout').read_text().count('::warning file=');assert warnings==13,warnings
 run('whitespace',['git','diff','--check']);assert 'ℹ pass 297' in (out/'maintained-observations.stdout').read_text();(out/'outcome.json').write_text(json.dumps({'complete':True,'owners':15,'maintainedIssueTestsPassed':297,'warnings':warnings,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
