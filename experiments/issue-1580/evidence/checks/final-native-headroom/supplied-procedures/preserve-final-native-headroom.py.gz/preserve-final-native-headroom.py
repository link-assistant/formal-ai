from pathlib import Path
import gzip,hashlib,json,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'final-native-headroom-preservation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 assert result.returncode==0,(name,result.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 final=json.loads((scratch/'final-native-headroom-continuation/outcome.json').read_text());assert final['complete'] and final['maintainedIssueTestsPassed']==297
 target=root/'experiments/issue-1580/evidence/checks/final-native-headroom';target.mkdir(exist_ok=False);records=[]
 def archive(source,relative):
  raw=source.read_bytes();packed=gzip.compress(raw,mtime=0);dest=target/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed);records.append({'file':relative,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
 for name in ['final-native-headroom-selection','final-native-special-selection','final-native-headroom-extraction','final-native-registry-review','final-native-headroom-continuation']:
  directory=scratch/name
  for file in sorted(directory.rglob('*')):
   if file.is_file() and file.name!='pid.json':archive(file,name+'/'+str(file.relative_to(directory))+'.gz')
 helpers=['select-final-native-headroom.py','prepare-final-native-specials.py','qualify-final-native-special-paths.mjs','extract-final-native-headroom.py','inspect-final-native-registry.py','inspect-final-native-witness.mjs','finish-final-native-headroom.py',Path(__file__).name]
 for name in helpers:archive(scratch/name,'supplied-procedures/'+name+'.gz')
 for file in sorted((root/'experiments/issue-1580/evidence/commands').glob('2026-11-21T17-*.json')):
  if any(name in json.loads(file.read_text())['request'] for name in helpers):archive(file,'formal-sessions/'+file.name+'.gz')
 for record in records:
  packed=(target/record['file']).read_bytes();raw=gzip.decompress(packed);assert hashlib.sha256(raw).hexdigest()==record['rawSha256'] and hashlib.sha256(packed).hexdigest()==record['archiveSha256'] and len(raw)==record['bytes'] and len(raw.splitlines())==record['lines']
 (target/'records.jsonl').write_text(''.join(json.dumps(record,separators=(',',':'))+'\n' for record in records));(target/'identity.json').write_text(json.dumps(final,indent=2)+'\n')
 doc=root/'docs/case-studies/issue-1580/final-native-headroom-checkpoint.md';doc.write_text('''# Native owner headroom and unchanged specification coverage

Fifteen large Rust owners now delegate complete functions, types,
implementations or ordered grammar rows to focused children. Exact inverse
checks retain the original bodies and comments before formatting; lexical
ancestor adjustments preserve relative paths and visibility. The grammar
generator concatenates the original ordered groups. Fifteen focused scanner
regressions fail before extraction and pass afterward under unchanged limits.

The official native registry generator initially rejects stale source hashes.
Regeneration changes exactly four execution-box source hashes; all programs
and values remain identical. A complete governed witness comparison has zero
differences: all 1,189 test identities, 221 carried programs and 968 unsupported
cases remain unchanged. No governed baseline refresh is needed for this batch.

All 297 maintained issue tests, six affected JavaScript gates, projection and
registry currency, Rust formatting and whitespace checks pass. The source scan
has 13 warnings and zero violations. Native compilation and execution remain
unverified for these local changes and will run in hosted CI.

Evidence: `experiments/issue-1580/evidence/checks/final-native-headroom/`.
Supplied procedures receive zero independent authorship credit. Wider issue
acceptance remains unfinished: https://github.com/link-assistant/formal-ai/pull/1581.
''')
 fragment=root/'changelog.d/20261121_1580_final_native_headroom.md';fragment.write_text('### Changed\n\n- Extract complete native runtime, source-test and grammar-generator units into focused modules while preserving ordered rules and every carried specification case.\n')
 plan=root/'experiments/issue-1580/work-plan.md';text=plan.read_text();text=text.replace('latest local replay passes 282 tests','latest local replay passes 297 tests').replace('reduce source warnings to 28 under unchanged limits.','reduce source warnings to 13 under unchanged limits.');plan.write_text(text)
 paths=json.loads((scratch/'final-native-headroom-extraction/changed-native-files.json').read_text())+['experiments/issue-1580/final-native-headroom.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs','scripts/lib/generated-native-programs.mjs',str(target.relative_to(root)),str(doc.relative_to(root)),str(fragment.relative_to(root)),str(plan.relative_to(root))]
 assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
 assert not run('staged-before',['git','diff','--cached','--name-only']).strip()
 run('stage',['git','add','--',*paths]);run('staged-whitespace',['git','diff','--cached','--check']);run('staged-secrets',['bash','scripts/check-secrets.sh']);run('commit',['git','commit','-m','Extract final large native owners without losing carried cases'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'head':run('head',['git','rev-parse','HEAD']).strip(),'archives':len(records),'pushed':False,'fullIssueComplete':False},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
