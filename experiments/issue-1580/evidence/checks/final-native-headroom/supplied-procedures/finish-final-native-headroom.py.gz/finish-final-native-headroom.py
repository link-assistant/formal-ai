from pathlib import Path
import json,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'final-native-headroom-continuation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':result.returncode}),flush=True);assert result.returncode==0,(name,result.returncode)
try:
 review=json.loads((scratch/'final-native-registry-review/witness-delta.json').read_text());assert review['changes']==[] and review['carried']==221 and review['total']==1189 and review['unsupported']==968
 changes=json.loads((scratch/'final-native-registry-review/delta.json').read_text());assert len(changes)==4
 for i,item in enumerate(changes,100):
  assert item['path']=='exports.GENERATED_NATIVE_PROGRAMS.'+str(i)+'.sourceWitnesses.0.sha256'
  assert item['previous']=='f8f043216ed49d05f7ebb9f77559b66576acd089c082e9658a19f8725f2b4001' and item['current']=='551fd634820c43cb662c921d2e691a2d4f086ba0a47b379682fd8ca4089412b1'
 files=json.loads((scratch/'final-native-headroom-extraction/changed-native-files.json').read_text())
 run('rustfmt-check',['rustfmt','--check','--edition','2024','--config','skip_children=true',*files])
 run('maintained-observations',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])
 run('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-abbreviations,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-changelog-fragment-js-twin,check-reconstructed-changelog'])
 run('source-warnings',['node','--max-old-space-size=256','scripts/check-file-size.mjs']);warnings=(out/'source-warnings.stdout').read_text().count('::warning file=');assert warnings==13,warnings
 run('whitespace',['git','diff','--check']);assert 'ℹ pass 297' in (out/'maintained-observations.stdout').read_text()
 (out/'outcome.json').write_text(json.dumps({'complete':True,'warnings':warnings,'owners':15,'maintainedIssueTestsPassed':297,'governedWitnessObjectUnchanged':True,'generatedRegistryOnlyFourReviewedSourceHashesChanged':True,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
