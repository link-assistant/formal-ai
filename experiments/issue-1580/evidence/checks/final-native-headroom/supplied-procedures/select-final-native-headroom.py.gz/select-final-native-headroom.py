from pathlib import Path
import hashlib,json,re
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/final-native-headroom-selection');out.mkdir(exist_ok=False)
inventory=json.loads(Path('/tmp/issue-1580-research/runtime-headroom-leaf-inventory/inventory.json').read_text())
chosen=[
 ('js/wasm-worker/src/lib.rs',['serialize_dialogue_answer','build_dialogue_fact_check'],'dialogue_rendering'),
 ('rust/src/agentic_coding/shell_command.rs',['sentences_with_mood','labels_a_value','command_named_in_prose'],'prose_classification'),
 ('rust/src/agentic_coding/evidence_record.rs',['relevance_score','later_route_delivering'],'evidence_relevance'),
 ('rust/src/agentic_coding/web_research.rs',['plan_deeper_round','extract_answer'],'answer_selection'),
 ('rust/src/agentic_coding/write_request.rs',['write_bindings','delivered_write_target'],'write_bindings'),
 ('rust/src/agentic_coding/general_execution.rs',['finish_general_change','plan_work_item_read'],'work_item_delivery'),
 ('rust/tests/source/solver_helpers.rs',['record_decomposition','is_write_script_request'],'request_classification'),
 ('rust/tests/source/intent_formalization.rs',['recover_write_program_rule'],'write_rule_recovery'),
 ('rust/tests/source/seed/meanings.rs',['parse_meaning','parse_lexicon'],'meaning_readers'),
 ('rust/src/execution_box/mod.rs',['backend_from_configuration'],'configuration'),
]
records=[]
for owner,names,child in chosen:
 source=(root/owner).read_text();row=next(row for row in inventory if row['owner']==owner);items=[]
 for name in names:
  item=next(item for item in row['candidates'] if item['name']==name);assert not item['excluded'];body=source[item['start']:item['end']]
  assert not re.search(r'\b(?:self|super)::|include_\w+!|\b(?:file|line|column|module_path)!',body)
  dest=out/'selected'/owner/('function-'+name+'.rs');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(body)
  items.append({**item,'bodySha256':hashlib.sha256(body.encode()).hexdigest()})
 target=(Path(owner).parent/child).with_suffix('.rs') if Path(owner).name in ['mod.rs','lib.rs'] else Path(str(Path(owner).with_suffix(''))+'/'+child+'.rs')
 assert not (root/target).exists()
 records.append({'owner':owner,'child':child,'target':str(target),'sourceSha256':hashlib.sha256(source.encode()).hexdigest(),'items':items})
(out/'selection.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps([{'owner':row['owner'],'names':[item['name'] for item in row['items']],'lines':sum(item['lines'] for item in row['items'])} for row in records],separators=(',',':')))
