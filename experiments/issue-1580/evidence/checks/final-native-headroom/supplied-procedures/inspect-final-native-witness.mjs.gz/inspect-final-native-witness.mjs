// External diagnostic procedure: zero independent authorship credit.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {serialize,deserialize} from 'node:v8';
import {relative,isAbsolute} from 'node:path';
import {specificationCases} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/rust-specification-cases.mjs';
const root='/tmp/gh-issue-solver-1794900398048',out='/tmp/issue-1580-research/final-native-registry-review';
const hash=x=>createHash('sha256').update(x).digest('hex');
const file=root+'/experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8';
const raw=readFileSync(file),previous=deserialize(raw),inventory=specificationCases(root);
for(const item of inventory.cases)for(const fixture of item.program?.fixtures??[])if(isAbsolute(fixture.file))fixture.file='repo:'+relative(root,fixture.file);
const sourceManifest=readdirSync(root+'/rust/tests/unit/specification',{recursive:true}).map(String).filter(x=>x.endsWith('.rs')).sort().map(x=>({path:'rust/tests/unit/specification/'+x,sha256:hash(readFileSync(root+'/rust/tests/unit/specification/'+x))}));
const current={inventory,sourceManifest},changes=[];
function compare(a,b,path){
 if(JSON.stringify(a)===JSON.stringify(b))return;
 if(a&&b&&typeof a==='object'&&typeof b==='object'){
  if(Array.isArray(a)&&Array.isArray(b)&&a.length!==b.length)changes.push({path,oldLength:a.length,newLength:b.length});
  for(const key of new Set([...Object.keys(a),...Object.keys(b)]))compare(a[key],b[key],path+'.'+key);
 }else changes.push({path,previous:a,current:b});
}
compare(previous,current,'witness');
writeFileSync(out+'/witness-previous.v8',raw);writeFileSync(out+'/witness-candidate.v8',serialize(current));
writeFileSync(out+'/witness-delta.json',JSON.stringify({previousSha256:hash(raw),total:inventory.total,carried:inventory.cases.length,unsupported:inventory.unsupported.length,changes},null,2)+'\n');
assert.equal(inventory.total,1189);assert.equal(inventory.cases.length,221);assert.equal(inventory.unsupported.length,968);
assert.deepEqual(inventory.cases.map(x=>x.id),previous.inventory.cases.map(x=>x.id));
console.log(JSON.stringify({total:inventory.total,carried:inventory.cases.length,unsupported:inventory.unsupported.length,changes:changes.length}));
