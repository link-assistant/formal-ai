//! Execution state machine for a composed general change plan.

use serde_json::json;

#[path = "general_execution/literal_creation.rs"]
mod literal_creation;
pub(super) use literal_creation::owned_creation_observation;

use super::append_contract::{AppendRecordStep, append_record_step};

use super::capability_router::shell_command_tool;
use super::final_result::{FinalDisposition, FinalResult, record};
use super::general_planner::{
    GeneralChangePlan, GeneralPlanMode, PLAN_PATH, compose_general_change_plan,
};
use super::planner::{AgenticPlan, Capability, plan_one, tool_for, write_arguments};
use super::progress::Progress;
use super::tool_result;
use super::work_item_evidence::plan_work_item_evidence;
use crate::protocol::ChatMessage;

const EXPECTED_PLACEHOLDER: &str = concat!("{", "expected", "}");
const OBSERVED_PLACEHOLDER: &str = concat!("{", "observed", "}");
const PLAN_PLACEHOLDER: &str = concat!("{", "plan", "}");
const PLAN_PATH_PLACEHOLDER: &str = concat!("{", "plan_path", "}");

pub(super) fn plan_general_change_step(
    messages: &[ChatMessage],
    tool_names: &[&str],
    plan: &GeneralChangePlan,
    result: &mut Option<FinalResult>,
) -> AgenticPlan {
    general_change_step(messages, tool_names, plan, false, result)
}

/// The same state machine entered from a resolved work item.
pub(super) fn plan_work_item_change_step(
    messages: &[ChatMessage],
    tool_names: &[&str],
    plan: &GeneralChangePlan,
) -> AgenticPlan {
    general_change_step(messages, tool_names, plan, true, &mut None)
}

/// A work-item session's terminal is a localized report, never JSON (issue #1560).
fn general_change_step(
    messages: &[ChatMessage],
    tool_names: &[&str],
    plan: &GeneralChangePlan,
    resolved_from_work_item: bool,
    result: &mut Option<FinalResult>,
) -> AgenticPlan {
    let step = change_step(messages, tool_names, plan, resolved_from_work_item, result);
    if resolved_from_work_item || plan.mode == GeneralPlanMode::RepositoryWorkItem {
        super::work_item_report::reported_work_item_final(step, &plan.goal, result)
    } else {
        step
    }
}

fn change_step(
    messages: &[ChatMessage],
    tool_names: &[&str],
    plan: &GeneralChangePlan,
    resolved_from_work_item: bool,
    result: &mut Option<FinalResult>,
) -> AgenticPlan {
    // A literal-file write reads its target first unless the request names a
    // whole-file write, and never replaces an existing file unasked (PR #1188 T96).
    if let Some(guarded) = super::literal_write_guard::guarded_step(plan, messages, tool_names) {
        return guarded;
    }
    let progress = Progress::scan(messages);
    if let Some(creation) =
        literal_creation::plan_owned_creation_step(plan, &progress, tool_names, result)
    {
        return creation;
    }
    if plan.mode == GeneralPlanMode::RepositoryWorkItem
        && let Some(objective) = repository_work_item_objective(plan, &progress)
    {
        if let Some(step) = super::repository_documentation::plan_repository_documentation(
            &objective,
            messages,
            tool_names,
            Some(&plan.target),
            result,
        ) {
            return step;
        }
        if let Some(step) = super::source_documentation::plan_source_documentation_step(
            &objective,
            messages,
            tool_names,
            Some(&plan.target),
            result,
        ) {
            return step;
        }
        if let Some(step) = super::work_item_boundary_candidate::plan_work_item_boundary_step(
            &objective,
            messages,
            tool_names,
            Some(&plan.target),
            |clause| {
                super::work_item_evidence::work_item_evidence_paths(clause)
                    .into_iter()
                    .map(str::to_owned)
                    .collect()
            },
            result,
        ) {
            return step;
        }
    }
    if let Some(command) = super::prerequisite_recovery::observed_recovery_command(messages)
        && let Some(output) = progress.latest_run_output_for(&command)
        && let Some(recovery) = super::prerequisite_recovery::plan_recovery(
            messages,
            tool_names,
            &command,
            tool_result::reported_exit_code(output).and_then(|value| i32::try_from(value).ok()),
            output,
        )
    {
        return recovery;
    }
    if plan.mode == GeneralPlanMode::RepositoryWorkItem
        && progress
            .latest_failure()
            .is_some_and(|failure| failure.capability == Capability::Run)
        && let Some(objective) = repository_work_item_objective(plan, &progress)
    {
        let mut answer = crate::solver::UniversalSolver::default().solve(&objective);
        // A recovery repairs only a program an obligation asked for (issue #1562).
        super::work_item_citations::unbind_cited_recipe(&mut answer, &objective);
        if let Some(owned) = super::command_reroute::plan_owned_recipe_recovery(
            messages, tool_names, &answer, &objective,
        ) {
            return owned;
        }
    }
    // Reading the work item is an attempt to find out whether anything *can* be
    // executed, not a step the request named. A read that comes back missing or
    // empty therefore answers that question — the capability is unavailable —
    // and the run continues to record the reference. Reporting the fetch as the
    // run's failure would replace the honest terminal state of issue #904 with
    // a transport message about a URL the user never asked to see.
    let work_item_unreadable = plan.mode == GeneralPlanMode::RepositoryWorkItem
        && progress.latest_failure().is_some_and(|failure| {
            failure.capability == Capability::Fetch || failure.is_work_item_read()
        });
    let target_missing = progress.latest_failure().is_some_and(|failure| {
        super::literal_write_guard::is_guard_read(
            plan,
            failure
                .arguments
                .as_deref()
                .and_then(tool_argument_path)
                .as_deref(),
            failure.capability,
        )
    });
    let event_missing = progress.latest_failure().is_some_and(|failure| {
        failure.capability == Capability::Read
            && failure
                .arguments
                .as_deref()
                .and_then(tool_argument_path)
                .as_deref()
                == Some(PLAN_PATH)
            && progress
                .source_read_for(PLAN_PATH)
                .is_some_and(|read| read.absent)
    });
    if let Some(failure) = progress
        .latest_failure()
        .filter(|_| !work_item_unreadable && !target_missing && !event_missing)
    {
        if failure.capability == Capability::Write {
            let path = failure.arguments.as_deref().and_then(tool_argument_path);
            if path.as_deref() == Some(PLAN_PATH) {
                let event = plan.links_notation();
                let identity = event.lines().nth(1).unwrap_or("");
                if matches!(
                    super::append_contract::append_record_step(
                        messages, tool_names, PLAN_PATH, &event, identity
                    ),
                    Some(super::append_contract::AppendRecordStep::Refused)
                ) {
                    return unverified_plan_event(plan);
                }
            }
            if let (Some(path), Some(read_tool)) =
                (path.as_deref(), tool_for(tool_names, Capability::Read))
                && progress.failed_write_count_for(path) == 1
            {
                return plan_one(read_tool, read_arguments(path));
            }
            // The plan event is auxiliary. A write-only client cannot perform
            // the preferred read-before-retry recovery, but its failure must
            // not swallow the user's primary literal-file write.
            if path.as_deref() == Some(PLAN_PATH)
                && plan.mode == GeneralPlanMode::LiteralFile
                && tool_for(tool_names, Capability::Read).is_none()
                && progress.failed_write_count_for(PLAN_PATH) == 1
                && let Some(write_tool) = tool_for(tool_names, Capability::Write)
            {
                return plan_one(write_tool, write_arguments(&plan.target, &plan.content));
            }
            // Recovery is exhausted, but the failed call is not the last word:
            // run the check the plan itself named so the report can carry the
            // status the workspace answered with rather than a transport
            // message alone (issue #916, rung R916-01).
            if plan.mode != GeneralPlanMode::RepositoryWorkItem
                && !plan.verification_command.trim().is_empty()
                && progress.run_count_for(&plan.verification_command) == 0
                && let Some(run_tool) = shell_command_tool(tool_names)
            {
                return plan_one(
                    run_tool,
                    json!({ "command": plan.verification_command }).to_string(),
                );
            }
            return AgenticPlan::Final(tool_result::render_failure(
                path.as_deref().unwrap_or("write"),
                &failure.detail,
                &plan.goal,
            ));
        }
        // A failed run is reported as the command that failed and the status it
        // exited with, not as an anonymous "run" step (issues #905 and #908).
        if failure.capability == Capability::Run
            && let Some(output) = progress.latest_run_output_for(&plan.verification_command)
            && let Some(report) = tool_result::failed_verification(
                std::slice::from_ref(output),
                &plan.verification_command,
                &plan.goal,
            )
        {
            return AgenticPlan::Final(report);
        }
        if failure.capability == Capability::Run
            && let Some(arguments) = failure.arguments.as_deref()
            && let Ok(value) = serde_json::from_str(arguments)
            && let Some(bound) = progress.latest_attempt_for(Capability::Run, &value)
            && bound.binding == super::qualified_tool_observation::Binding::Exact
            && let Some(command) = tool_result::command_argument(arguments)
        {
            return AgenticPlan::Final(tool_result::render_failure(
                &command,
                &failure.detail,
                &plan.goal,
            ));
        }
        // A client may require an attempted read before creating a missing
        // file. Whether that read found bytes or reported absence, retry the
        // original write once; its per-target failure budget remains bounded.
        let recovering_missing_write = failure.capability == Capability::Read
            && progress.previous_attempt().is_some_and(|previous| {
                previous.capability == Capability::Write && !previous.succeeded
            });
        if !recovering_missing_write {
            return AgenticPlan::Final(tool_result::render_failure(
                capability_label(failure.capability),
                &failure.detail,
                &plan.goal,
            ));
        }
    }
    let recovering_write = progress.last() == Some(Capability::Read)
        && progress.previous_attempt().is_some_and(|previous| {
            previous.capability == Capability::Write && !previous.succeeded
        });
    if recovering_write
        && let (Some(tool), Some(arguments)) = (
            tool_for(tool_names, Capability::Write),
            progress
                .previous_attempt()
                .and_then(|attempt| attempt.arguments.as_deref()),
        )
    {
        return plan_one(tool, arguments.to_owned());
    }
    // A repository work item names an issue, not an artifact. Recording the
    // reference and stopping is what issue #904 reported: nothing the request
    // asked for was ever produced. The issue itself is where the artifact is
    // named, so read it before concluding that nothing can be executed — the
    // capability is only genuinely unavailable once the fetch has been tried.
    if plan.mode == GeneralPlanMode::RepositoryWorkItem {
        if let Some(fetched) = repository_work_item_objective(plan, &progress) {
            if let Some(step) =
                plan_work_item_execution(&fetched, messages, tool_names, &plan.target, result)
            {
                return step;
            }
        } else if let Some(step) =
            plan_work_item_read(messages, tool_names, &plan.target, &progress)
        {
            return step;
        }
    }
    // Never spend the only write this mode produces on a plan record when the
    // goal could not be read (issue #1155): the record would claim a session
    // engaged with an issue it never saw one line of. The reads tried, each
    // with its result, are the answer instead.
    if plan.mode == GeneralPlanMode::RepositoryWorkItem
        && let Some(report) = work_item_read_failure_report(plan, &progress)
    {
        return AgenticPlan::Final(report);
    }
    if plan.mode == GeneralPlanMode::RepositoryWorkItem {
        let mut unresolved = plan.clone();
        unresolved.goal =
            repository_work_item_objective(plan, &progress).unwrap_or_else(|| plan.target.clone());
        return record(
            AgenticPlan::Final(unresolved.planned_not_executed_answer()),
            FinalDisposition::Gap,
            "work_item_execution_unavailable",
            result,
        );
    }
    let event_unavailable = match plan_event_step(plan, &progress, tool_names, messages) {
        PlanEventOutcome::Pending(step) => return step,
        PlanEventOutcome::Observed => false,
        PlanEventOutcome::Unavailable => true,
    };
    if let Some(tool) = tool_for(tool_names, Capability::Write)
        && plan.mode == GeneralPlanMode::LiteralFile
        && !progress.successful_write_for(&plan.target)
    {
        return plan_one(tool, write_arguments(&plan.target, &plan.content));
    }
    if let Some(tool) = shell_command_tool(tool_names) {
        match plan.mode {
            GeneralPlanMode::CommandOutput => {
                if let Some(generation) = plan.steps.get(1).and_then(|step| step.command.as_deref())
                {
                    if progress.successful_run_count_for(generation) == 0 {
                        return plan_one(tool, json!({ "command": generation }).to_string());
                    }
                    if progress.successful_run_count_for(&plan.verification_command) == 0 {
                        return plan_one(
                            tool,
                            json!({ "command": plan.verification_command }).to_string(),
                        );
                    }
                }
            }
            GeneralPlanMode::LiteralFile
                if progress.successful_run_count_for(&plan.verification_command) == 0 =>
            {
                return plan_one(
                    tool,
                    json!({ "command": plan.verification_command }).to_string(),
                );
            }
            // A repository work item names no verification command: the only
            // file this run writes is the plan record, and reading it back
            // would verify nothing but the write itself (issue #904).
            GeneralPlanMode::LiteralFile | GeneralPlanMode::RepositoryWorkItem => {}
        }
    }
    if event_unavailable {
        return record(
            unverified_plan_event(plan),
            FinalDisposition::Gap,
            "auxiliary_event_unavailable",
            result,
        );
    }
    finish_general_change(plan, &progress, resolved_from_work_item, result)
}

/// Request-local persistence status, separate from the requested workspace effect.
enum PlanEventOutcome {
    Observed,
    Pending(AgenticPlan),
    Unavailable,
}

// Write is an overwrite operation. Preserve observed history and read back the
// entire expected stream before treating its new event as recorded.
fn plan_event_append_command(plan: &GeneralChangePlan) -> String {
    let event = plan.links_notation();
    let identity = event.lines().nth(1).unwrap_or_default();
    let path = super::general_planner::shell_quote(PLAN_PATH);
    let identity = super::general_planner::shell_quote(identity);
    let event = super::general_planner::shell_quote(&event);
    super::work_item_steps::fill(
        "plan-event-append-command",
        &[
            (
                concat!("{", "lock_path", "}"),
                &super::general_planner::shell_quote(&format!("{PLAN_PATH}.lock")),
            ),
            (concat!("{", "path", "}"), &path),
            (concat!("{", "identity", "}"), &identity),
            (concat!("{", "event", "}"), &event),
        ],
    )
}

fn unverified_plan_event(plan: &GeneralChangePlan) -> AgenticPlan {
    let mut evidence = plan.clone();
    PLAN_PATH.clone_into(&mut evidence.target);
    evidence.verification_command = format!("cat {PLAN_PATH}");
    AgenticPlan::Final(general_plan_unverified(&evidence))
}

fn plan_event_step(
    plan: &GeneralChangePlan,
    progress: &Progress,
    tool_names: &[&str],
    messages: &[ChatMessage],
) -> PlanEventOutcome {
    let event = plan.links_notation();
    let identity = event.lines().nth(1).unwrap_or_default();
    let run = shell_command_tool(tool_names);
    let aliases = super::work_item_steps::fill("plan-event-shell-aliases", &[]);
    let atomic_shell = run.is_some_and(|name| {
        let leaf = name
            .rsplit("__")
            .next()
            .unwrap_or(name)
            .rsplit(['.', '/', ':'])
            .next()
            .unwrap_or(name);
        aliases
            .split_whitespace()
            .any(|alias| leaf.eq_ignore_ascii_case(alias))
    });
    if let (Some(read), Some(write)) = (
        tool_for(tool_names, Capability::Read),
        tool_for(tool_names, Capability::Write),
    ) && !atomic_shell
    {
        let observation = progress.source_read_for(PLAN_PATH);
        if observation
            .is_some_and(|observation| observation.error.is_none() && !observation.complete)
        {
            return PlanEventOutcome::Unavailable;
        }
        let prior = observation
            .filter(|observation| observation.complete)
            .and_then(|observation| observation.source.clone());
        if let Some(expected) = progress.successful_write_content_for(PLAN_PATH) {
            if prior
                .as_deref()
                .is_some_and(|prior| prior.starts_with(&expected))
            {
                return PlanEventOutcome::Observed;
            }
            if progress.last() == Some(Capability::Read)
                && progress
                    .latest_successful_arguments(Capability::Read)
                    .and_then(tool_argument_path)
                    .as_deref()
                    == Some(PLAN_PATH)
            {
                return PlanEventOutcome::Pending(unverified_plan_event(plan));
            }
            return PlanEventOutcome::Pending(plan_one(read, read_arguments(PLAN_PATH)));
        }
        if prior
            .as_deref()
            .is_some_and(|prior| prior.lines().any(|line| line == identity))
        {
            return if prior.as_deref().is_some_and(|prior| prior.contains(&event)) {
                PlanEventOutcome::Observed
            } else {
                PlanEventOutcome::Pending(unverified_plan_event(plan))
            };
        }
        let missing = progress.latest_failure().is_some_and(|failure| {
            failure.capability == Capability::Read
                && failure
                    .arguments
                    .as_deref()
                    .and_then(tool_argument_path)
                    .as_deref()
                    == Some(PLAN_PATH)
                && progress
                    .source_read_for(PLAN_PATH)
                    .is_some_and(|read| read.absent)
        });
        if prior.is_none() && !missing {
            return PlanEventOutcome::Pending(plan_one(read, read_arguments(PLAN_PATH)));
        }
        let mut stream = prior.unwrap_or_default();
        if !stream.is_empty() && !stream.ends_with('\n') {
            stream.push('\n');
        }
        stream.push_str(&event);
        return PlanEventOutcome::Pending(plan_one(write, write_arguments(PLAN_PATH, &stream)));
    }
    // A declared append provider retains its exact receipt contract with a shell present.
    if let Some(appended) = append_record_step(messages, tool_names, PLAN_PATH, &event, identity) {
        return match appended {
            AppendRecordStep::Pending(step) => PlanEventOutcome::Pending(step),
            AppendRecordStep::Observed => PlanEventOutcome::Observed,
            AppendRecordStep::Refused => PlanEventOutcome::Pending(unverified_plan_event(plan)),
        };
    }
    let Some(run) = run.filter(|_| atomic_shell) else {
        return PlanEventOutcome::Unavailable;
    };
    let append = plan_event_append_command(plan);
    if progress.successful_run_count_for(&append) == 0 {
        return PlanEventOutcome::Pending(plan_one(run, json!({"command": append}).to_string()));
    }
    let observed = progress
        .latest_successful_run_output_for(&append)
        .and_then(tool_result::observed_payload);
    if observed.is_some_and(|observed| observed.contains(event.trim_end())) {
        PlanEventOutcome::Observed
    } else {
        PlanEventOutcome::Pending(unverified_plan_event(plan))
    }
}

/// Plan the next step from what the fetched work item actually asks for.
fn plan_work_item_execution(
    objective: &str,
    messages: &[ChatMessage],
    tool_names: &[&str],
    work_item: &str,
    result: &mut Option<FinalResult>,
) -> Option<AgenticPlan> {
    // The default configuration is the right one: the recipe wanted here is the
    // same `write_program` answer a user typing this request directly would get,
    // and the client — not this solver — owns execution. Opting into agent mode
    // would only add the policy branches that answer *about* agent actions.
    let mut answer = crate::solver::UniversalSolver::default().solve(objective);
    // A program is written only for an obligation of the work item, never for
    // a span it merely cites (issue #1562): the address of a `test-hello-world`
    // repository or a quoted log is no request for a Hello World program.
    let unbound = super::work_item_citations::unbind_cited_recipe(&mut answer, objective);
    // The issue that asks for the program may also ask for the workflow that
    // runs it (issue #1133, requirement 6 of every Hello World task): the
    // recipe then carries the workflow as a supporting file, running the same
    // commands the harness verifies.
    if let Some(recipe) = answer.execution_recipe.as_mut()
        && super::ci_workflow::requested_in(objective)
    {
        super::ci_workflow::attach(recipe, objective);
    }
    if let Some(step) = super::command_reroute::plan_symbolic_command_reroute_for_objective(
        messages, tool_names, &answer, objective,
    ) {
        return Some(step);
    }
    let Some(executable) = compose_general_change_plan(objective)
        .filter(|executable| executable.mode != GeneralPlanMode::RepositoryWorkItem)
    else {
        return plan_work_item_evidence(
            objective,
            messages,
            tool_names,
            work_item,
            unbound.as_deref(),
            result,
        );
    };
    Some(plan_work_item_change_step(
        messages,
        tool_names,
        &executable,
    ))
}

/// The step that reads the work item, through whichever client tool reaches it.
fn plan_work_item_read(
    messages: &[ChatMessage],
    tool_names: &[&str],
    target: &str,
    progress: &Progress,
) -> Option<AgenticPlan> {
    let fetch = tool_for(tool_names, Capability::Fetch);
    if !progress.attempted_work_item_read_of(target)
        && let Some(run) = shell_command_tool(tool_names)
    {
        return Some(plan_one(
            run,
            json!({ "command": issue_view_command(target) }).to_string(),
        ));
    }
    // A read that failed — or one a client echoed without its status, which
    // the sentinel now exposes (issue #1155) — must not end the retrieval
    // while another route to the same text is untried. The fallbacks walk in
    // the issue's order: the client's fetch tool on the issue URL, the
    // credential-free REST read (`curl` needs no `gh` and no token for a
    // public repository — exactly the case an unauthenticated `gh` used to
    // end a session for), the authenticated REST read, and last the prepared
    // pull request's own page, whose title and body restate the issue.
    if !progress.attempted_fetch_of(target)
        && let Some(tool) = fetch
    {
        return Some(plan_one(tool, work_item_fetch_arguments(target)));
    }
    if let Some(run) = shell_command_tool(tool_names) {
        for fallback in [
            issue_rest_read_command(target),
            issue_api_read_command(target),
        ]
        .into_iter()
        .flatten()
        {
            if !progress.has_run(&fallback) {
                return Some(plan_one(run, json!({ "command": fallback }).to_string()));
            }
        }
    }
    if let Some(prepared_pull) = prepared_pull_reference(messages)
        && prepared_pull != target
        && !progress.attempted_fetch_of(&prepared_pull)
        && let Some(tool) = fetch
    {
        return Some(plan_one(tool, work_item_fetch_arguments(&prepared_pull)));
    }
    None
}

/// The pull-request URL the prompt names beside the work item ("Your prepared Pull Request: …"), when it names one.
fn prepared_pull_reference(messages: &[ChatMessage]) -> Option<String> {
    let prompt = messages
        .iter()
        .rev()
        .find(|message| message.role.eq_ignore_ascii_case("user"))?
        .content
        .plain_text();
    prompt.split_whitespace().find_map(|token| {
        let reference = super::general_planner::repository_work_reference(token)?;
        (reference.rsplit('/').nth(1) == Some("pull")).then_some(reference)
    })
}

fn work_item_fetch_arguments(target: &str) -> String {
    json!({
        "url": target,
        "format": "text",
        "prompt": super::work_item_steps::fill("issue_fetch_prompt", &[]),
    })
    .to_string()
}

/// The `gh` command that prints a work item as its title followed by its body.
#[allow(clippy::literal_string_with_formatting_args)]
pub(super) fn issue_view_command(target: &str) -> String {
    // `…/owner/repo/pull/7` reads through `gh pr`, everything else through
    // `gh issue`; the segment before the number says which.
    let kind = match target.trim_end_matches('/').rsplit('/').nth(1) {
        Some("pull") => "pr",
        _ => "issue",
    };
    let quoted_target = super::general_planner::shell_quote(target);
    super::work_item_steps::fill(
        "issue_view_command",
        &[("{kind}", kind), ("{target}", &quoted_target)],
    )
}

/// The REST segments of a GitHub work-item URL — `{owner}`, `{repo}`, the REST spelling of the kind (`issues` / `pulls`), and the number.
fn rest_segments(target: &str) -> Option<(String, String, &'static str, String)> {
    let mut segments = target.trim_end_matches('/').rsplit('/');
    let number = segments.next()?.to_owned();
    let kind = match segments.next()? {
        "issue" | "issues" => "issues",
        "pull" | "pulls" => "pulls",
        _ => return None,
    };
    let repo = segments.next()?.to_owned();
    let owner = segments.next()?.to_owned();
    (!number.is_empty() && number.chars().all(|character| character.is_ascii_digit()))
        .then_some((owner, repo, kind, number))
}

/// The work-item read that needs no `gh` and no credential: GitHub's REST API returns the raw body to `curl` for a public repository (issue #1155).
fn issue_rest_read_command(target: &str) -> Option<String> {
    let (owner, repo, kind, number) = rest_segments(target)?;
    Some(super::work_item_steps::fill(
        "issue_rest_read_command",
        &[
            (concat!("{", "owner}"), &owner),
            (concat!("{", "repo}"), &repo),
            (concat!("{", "kind}"), kind),
            (concat!("{", "number}"), &number),
        ],
    ))
}

/// The authenticated REST read, for a checkout whose `gh` answers `api` but could not render the view (issue #1155).
fn issue_api_read_command(target: &str) -> Option<String> {
    let (owner, repo, kind, number) = rest_segments(target)?;
    Some(super::work_item_steps::fill(
        "issue_api_read_command",
        &[
            (concat!("{", "owner}"), &owner),
            (concat!("{", "repo}"), &repo),
            (concat!("{", "kind}"), kind),
            (concat!("{", "number}"), &number),
        ],
    ))
}

/// The honest close of a work item no read could deliver (issue #1155).
fn work_item_read_failure_report(plan: &GeneralChangePlan, progress: &Progress) -> Option<String> {
    progress.failed_work_item_read_of(&plan.target)?;
    let attempts = progress.work_item_read_attempts(&plan.target);
    (!attempts.is_empty()).then(|| {
        super::work_item_steps::fill(
            "read_failed_report",
            &[
                ("{target}", &plan.target),
                (concat!("{", "attempts}"), &attempts.join("\n")),
            ],
        )
    })
}

/// The text of the issue this work item names, once the client has fetched it.
fn repository_work_item_objective(plan: &GeneralChangePlan, progress: &Progress) -> Option<String> {
    progress.fetched_pages.iter().rev().find_map(|(url, raw)| {
        if url != &plan.target {
            return None;
        }
        let text = if let Ok(mut data) = serde_json::from_str::<serde_json::Value>(raw.trim()) {
            // Retain source data from a successful MCP structured result rather
            // than treating its display placeholder as the fetched issue.
            if data.get("structuredContent").is_some()
                && data
                    .get("content")
                    .and_then(serde_json::Value::as_array)
                    .is_some_and(|parts| {
                        parts.iter().all(|part| {
                            part.get("type").and_then(serde_json::Value::as_str) == Some("text")
                                && part
                                    .get("text")
                                    .and_then(serde_json::Value::as_str)
                                    .is_some()
                        })
                    })
            {
                tool_result::observed_payload(raw)?;
                let structured = data.get("structuredContent")?;
                let inner = structured.get("content").unwrap_or(structured);
                let record = if let Some(text) = inner.as_str() {
                    serde_json::from_str::<serde_json::Value>(text).ok()?
                } else {
                    inner.clone()
                };
                let body = record.get("body")?.as_str()?;
                let title = record.get("title").and_then(serde_json::Value::as_str);
                let conflicts = |other: &serde_json::Value| {
                    other
                        .get("body")
                        .and_then(serde_json::Value::as_str)
                        .is_some_and(|other_body| {
                            other_body != body
                                || other
                                    .get("title")
                                    .and_then(serde_json::Value::as_str)
                                    .zip(title)
                                    .is_some_and(|(candidate, expected)| candidate != expected)
                        })
                };
                if [&data, structured].into_iter().any(conflicts) {
                    return None;
                }
                for part in data.get("content")?.as_array()? {
                    if let Ok(other) =
                        serde_json::from_str::<serde_json::Value>(part.get("text")?.as_str()?)
                        && conflicts(&other)
                    {
                        return None;
                    }
                }
                data = record;
            }
            let body = data.get("body")?.as_str()?;
            let title = data
                .get("title")
                .and_then(serde_json::Value::as_str)
                .unwrap_or("");
            [title, body]
                .into_iter()
                .filter(|part| !part.is_empty())
                .collect::<Vec<_>>()
                .join("\n\n")
        } else {
            let lower = raw.trim().to_ascii_lowercase();
            if lower.starts_with("<!doctype html")
                || lower.starts_with("<html")
                || lower.contains("<body")
                || lower.contains("<nav")
                || lower.contains("<script")
            {
                return None;
            }
            // A fetched page keeps its title and body; a page without a body
            // is rejected so the REST and gh api reads run instead (issue #1560).
            super::work_item_page::work_item_page_text(raw.trim())?
        };
        (!text.trim().is_empty()).then_some(text)
    })
}

// Exact declared data can describe failures without reporting an execution failure.
// Explicit harness errors and nonzero status always remain authoritative.
fn literal_verification_matches(plan: &GeneralChangePlan, output: &str) -> bool {
    plan.mode == GeneralPlanMode::LiteralFile
        && !tool_result::harness_reported_failure(output)
        && tool_result::reported_exit_code(output).is_none_or(|code| code == 0)
        && output.trim() == plan.content.trim()
}

fn finish_general_change(
    plan: &GeneralChangePlan,
    progress: &Progress,
    resolved_from_work_item: bool,
    result: &mut Option<FinalResult>,
) -> AgenticPlan {
    if plan.mode == GeneralPlanMode::RepositoryWorkItem {
        return record(
            AgenticPlan::Final(plan.planned_not_executed_answer()),
            FinalDisposition::Gap,
            "repository_work_not_executed",
            result,
        );
    }
    // The workspace gets the last word over a completion claim: a verification
    // command that exited non-zero replaces the claim with its own report.
    if let Some(report) = progress
        .latest_run_output_for(&plan.verification_command)
        .filter(|output| !literal_verification_matches(plan, output))
        .and_then(|output| {
            tool_result::failed_verification(
                std::slice::from_ref(output),
                &plan.verification_command,
                &plan.goal,
            )
        })
    {
        return AgenticPlan::Final(report);
    }
    if progress.successful_run_count_for(&plan.verification_command) == 0 {
        return AgenticPlan::Final(general_plan_unverified(plan));
    }
    if plan.mode == GeneralPlanMode::LiteralFile {
        let observed = progress
            .latest_successful_run_output_for(&plan.verification_command)
            .and_then(tool_result::observed_payload);
        let exact_literal = progress
            .latest_successful_run_output_for(&plan.verification_command)
            .is_some_and(|output| literal_verification_matches(plan, output));
        if !exact_literal && observed.as_deref().map(str::trim) != Some(plan.content.trim()) {
            return AgenticPlan::Final(general_plan_mismatch(
                plan,
                observed.as_deref().unwrap_or_default(),
            ));
        }
    }
    if resolved_from_work_item && plan.mode == GeneralPlanMode::LiteralFile {
        return record(
            AgenticPlan::Final(work_item_completion(plan, progress)),
            FinalDisposition::Finding,
            "work_item_completion_verified",
            result,
        );
    }
    record(
        AgenticPlan::Final(general_plan_completed(plan)),
        FinalDisposition::Finding,
        "general_plan_completed_verified",
        result,
    )
}

/// The completion a resolved work item earns: the harness voice the execution recipe already uses — the artifact created, the command that verified it, the output that command produced.
fn work_item_completion(plan: &GeneralChangePlan, progress: &Progress) -> String {
    let recipe = crate::engine::ExecutionRecipe {
        language: "text".to_owned(),
        source: plan.content.clone(),
        path: plan.target.clone(),
        supporting_files: Vec::new(),
        commands: vec![plan.verification_command.clone()],
    };
    let outputs = progress
        .latest_successful_run_output_for(&plan.verification_command)
        .map(|output| vec![output.to_owned()])
        .unwrap_or_default();
    recipe.final_answer(&outputs, None)
}

/// The completion claim is the sentence the issue quotes as the false report,
/// so it is seeded like every other outcome of this state machine rather than
/// typed into Rust: the words live in `data/seed/`, and the reply follows the
/// language the request was written in.
fn general_plan_completed(plan: &GeneralChangePlan) -> String {
    let language = plan.response_language();
    let mut answer =
        crate::seed::localized_response("general_plan_completed", language).unwrap_or_default();
    answer = answer.replace("{target}", &plan.target);
    answer = answer.replace("{command}", &plan.verification_command);
    answer = answer.replace(PLAN_PATH_PLACEHOLDER, PLAN_PATH);
    answer.replace(
        PLAN_PLACEHOLDER,
        &crate::issue_report::fenced_block(
            crate::issue_report::LINO_FENCE_LANGUAGE,
            &plan.links_notation(),
        ),
    )
}

fn tool_argument_path(arguments: &str) -> Option<String> {
    let value: serde_json::Value = serde_json::from_str(arguments).ok()?;
    ["path", "filePath", "file_path"]
        .iter()
        .find_map(|key| value.get(*key).and_then(serde_json::Value::as_str))
        .map(str::to_owned)
}

fn read_arguments(path: &str) -> String {
    json!({
        "path": path,
        "filePath": path,
        "file_path": path,
    })
    .to_string()
}

const fn capability_label(capability: Capability) -> &'static str {
    match capability {
        Capability::Search => "search",
        Capability::Fetch => "fetch",
        Capability::Read => "read",
        Capability::Write => "write",
        Capability::Edit => "edit",
        Capability::Run => "run",
        Capability::Grep => "grep",
        Capability::Glob => "glob",
        Capability::ListDir => "list directory",
        Capability::Todo => "todo",
        Capability::Subagent => "subagent",
        Capability::ReadMany => "read many",
        Capability::MultiEdit => "multi-edit",
        Capability::AskUser => "ask user",
    }
}

fn general_plan_mismatch(plan: &GeneralChangePlan, observed: &str) -> String {
    let language = plan.response_language();
    let mut answer =
        crate::seed::localized_response("general_plan_verification_mismatch", language)
            .unwrap_or_default();
    answer = answer.replace("{target}", &plan.target);
    let expected = if plan.mode == GeneralPlanMode::RepositoryWorkItem {
        plan.links_notation()
    } else {
        plan.content.clone()
    };
    answer = answer.replace(EXPECTED_PLACEHOLDER, expected.trim());
    answer.replace(OBSERVED_PLACEHOLDER, observed.trim())
}

fn general_plan_unverified(plan: &GeneralChangePlan) -> String {
    let language = plan.response_language();
    let mut answer =
        crate::seed::localized_response("general_plan_unverified", language).unwrap_or_default();
    answer = answer.replace("{target}", &plan.target);
    answer.replace("{command}", &plan.verification_command)
}
