/// The step that reads the work item, through whichever client tool reaches it.
fn plan_work_item_read(
    messages: &[ChatMessage],
    tool_names: &[&str],
    target: &str,
    progress: &Progress,
) -> Option<AgenticPlan> {
    let fetch = tool_for(tool_names, Capability::Fetch);
    if !progress.attempted_work_item_read_of(target)
        && let Some(run) = shell_command_tool(tool_names)
    {
        return Some(plan_one(
            run,
            json!({ "command": issue_view_command(target) }).to_string(),
        ));
    }
    // A read that failed — or one a client echoed without its status, which
    // the sentinel now exposes (issue #1155) — must not end the retrieval
    // while another route to the same text is untried. The fallbacks walk in
    // the issue's order: the client's fetch tool on the issue URL, the
    // credential-free REST read (`curl` needs no `gh` and no token for a
    // public repository — exactly the case an unauthenticated `gh` used to
    // end a session for), the authenticated REST read, and last the prepared
    // pull request's own page, whose title and body restate the issue.
    if !progress.attempted_fetch_of(target)
        && let Some(tool) = fetch
    {
        return Some(plan_one(tool, work_item_fetch_arguments(target)));
    }
    if let Some(run) = shell_command_tool(tool_names) {
        for fallback in [
            issue_rest_read_command(target),
            issue_api_read_command(target),
        ]
        .into_iter()
        .flatten()
        {
            if !progress.has_run(&fallback) {
                return Some(plan_one(run, json!({ "command": fallback }).to_string()));
            }
        }
    }
    if let Some(prepared_pull) = prepared_pull_reference(messages)
        && prepared_pull != target
        && !progress.attempted_fetch_of(&prepared_pull)
        && let Some(tool) = fetch
    {
        return Some(plan_one(tool, work_item_fetch_arguments(&prepared_pull)));
    }
    None
}
