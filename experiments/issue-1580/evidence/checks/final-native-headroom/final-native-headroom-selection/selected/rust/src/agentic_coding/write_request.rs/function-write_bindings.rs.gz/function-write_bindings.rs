/// Every path a cue binds, in token order.
///
/// A cue stands before its path in the languages that put it there and after it
/// in the languages that do not: Hindi writes `notes/attribution.md फ़ाइल` and
/// `notes/attribution.md में`, so a reader that only ever looks one token back
/// finds no target in a Hindi request at all. A postposition is therefore read
/// too, but only for the target and destination families — an action cue after a
/// path closes the clause rather than naming the file — and only when the path
/// has no cue in front of it.
fn write_bindings(toks: &[Token<'_>]) -> Vec<WriteBinding> {
    let target_cues = bare_surfaces(seed::ROLE_FILE_WRITE_TARGET_CUE);
    let dest_cues = bare_surfaces(seed::ROLE_FILE_WRITE_DESTINATION_CUE);
    let action_cues = bare_surfaces(seed::ROLE_FILE_WRITE_ACTION_CUE);
    // The fused reading is for the nouns and particles that a script without
    // spaces writes against their neighbour — `创建文件` is "create" and "file",
    // `文件` is the cue. A verb is not read that way: `输出内容 sample.txt` opens
    // with the write verb `输出` and means "output the contents of", a read, and
    // reading the verb out of the fused token claimed the file the request asked
    // to be shown.
    let families = [
        (CueFamily::Destination, &dest_cues, true),
        (CueFamily::Target, &target_cues, true),
        (CueFamily::Action, &action_cues, false),
    ];
    let quoted =
        crate::normal_markov::quoted_segment_spans(toks.first().map_or("", |token| token.request));
    toks.iter()
        .enumerate()
        .filter_map(|(index, token)| {
            let cleaned = clean_path_token(token.text);
            if !looks_like_file_path(cleaned) || !safe_relative_path(cleaned) {
                return None;
            }
            let path = cleaned.to_owned();
            if let Some(previous) = index.checked_sub(1).map(|before| &toks[before])
                && let Some((family, cue_start, cue_end)) =
                    families.iter().find_map(|(family, cues, fused)| {
                        trailing_cue(previous, cues, *fused).map(|span| (*family, span.0, span.1))
                    })
            {
                return Some(WriteBinding {
                    index,
                    path,
                    cue_start,
                    cue_end,
                    family,
                    cue_precedes: true,
                });
            }
            let next = toks.get(index + 1)?;
            families
                .iter()
                .take(2)
                .find_map(|(family, cues, fused)| {
                    leading_cue(next, cues, *fused).map(|span| (*family, span.0, span.1))
                })
                .map(|(family, cue_start, cue_end)| WriteBinding {
                    index,
                    path,
                    cue_start,
                    cue_end,
                    family,
                    cue_precedes: false,
                })
        })
        .filter(|binding| {
            !quoted
                .iter()
                .any(|segment| binding.cue_start < segment.end && binding.cue_end > segment.start)
        })
        .collect()
}
