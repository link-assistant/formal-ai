fn finish_general_change(
    plan: &GeneralChangePlan,
    progress: &Progress,
    resolved_from_work_item: bool,
    result: &mut Option<FinalResult>,
) -> AgenticPlan {
    if plan.mode == GeneralPlanMode::RepositoryWorkItem {
        return record(
            AgenticPlan::Final(plan.planned_not_executed_answer()),
            FinalDisposition::Gap,
            "repository_work_not_executed",
            result,
        );
    }
    // The workspace gets the last word over a completion claim: a verification
    // command that exited non-zero replaces the claim with its own report.
    if let Some(report) = progress
        .latest_run_output_for(&plan.verification_command)
        .filter(|output| !literal_verification_matches(plan, output))
        .and_then(|output| {
            tool_result::failed_verification(
                std::slice::from_ref(output),
                &plan.verification_command,
                &plan.goal,
            )
        })
    {
        return AgenticPlan::Final(report);
    }
    if progress.successful_run_count_for(&plan.verification_command) == 0 {
        return AgenticPlan::Final(general_plan_unverified(plan));
    }
    if plan.mode == GeneralPlanMode::LiteralFile {
        let observed = progress
            .latest_successful_run_output_for(&plan.verification_command)
            .and_then(tool_result::observed_payload);
        let exact_literal = progress
            .latest_successful_run_output_for(&plan.verification_command)
            .is_some_and(|output| literal_verification_matches(plan, output));
        if !exact_literal && observed.as_deref().map(str::trim) != Some(plan.content.trim()) {
            return AgenticPlan::Final(general_plan_mismatch(
                plan,
                observed.as_deref().unwrap_or_default(),
            ));
        }
    }
    if resolved_from_work_item && plan.mode == GeneralPlanMode::LiteralFile {
        return record(
            AgenticPlan::Final(work_item_completion(plan, progress)),
            FinalDisposition::Finding,
            "work_item_completion_verified",
            result,
        );
    }
    record(
        AgenticPlan::Final(general_plan_completed(plan)),
        FinalDisposition::Finding,
        "general_plan_completed_verified",
        result,
    )
}
