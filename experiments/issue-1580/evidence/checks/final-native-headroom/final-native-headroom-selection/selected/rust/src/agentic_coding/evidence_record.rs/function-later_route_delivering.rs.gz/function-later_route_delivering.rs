/// How a route below this one already produces `target` from the whole request,
/// or `None` when none of them does.
///
/// A composed change plan states the file it was compiled for, so asking it is
/// exact and costs nothing -- and it is the only one of the two that sees a file
/// a shell *redirect* produces, since "Run 'printf learned-output' and write its
/// exact stdout to reports/learned.txt" is delivered by `>` and never by a write
/// call at all.
///
/// Everything else is asked by running it rather than by listing it: plan the
/// request through the routes below, answer each planned call with a bare
/// success, and see whether `target` is among the files they write. That is what
/// reaches the recipes, which declare nothing and are recognised from the
/// artifact they write. A route's own state machine is what decides --
/// `plan_general_change_step` records its plan before writing the file the
/// caller named, so a first step alone would report that nobody owns
/// `policy/retention.md`, and a table of routes that "own an artifact" would
/// have to carry that knowledge secondhand and go stale.
///
/// The probe starts from a conversation holding the request and nothing else, so
/// the answer depends on the request alone and does not drift as the real run
/// accumulates results: a recipe that owns a destination owns it on every turn,
/// and its mid-run plan to read the file back would otherwise look like nobody
/// owning it.
fn later_route_delivering(
    task: &str,
    obligation: &DeliveryBinding,
    tool_names: &[&str],
) -> Option<&'static str> {
    // A schema or opening-line declaration constrains bytes that still have to
    // be derived from the residual investigation; it is not itself the file's
    // payload. The broad literal parser can nevertheless recover the words
    // after "with"/"exactly" as content. Do not let that lossy interpretation
    // displace the evidence transaction. A true literal write has no residual
    // finding to derive, so it never reaches this function.
    let derived_delivery = obligation.first_line.is_some() || !obligation.field_lines.is_empty();
    if derived_delivery {
        return None;
    }
    if let Some(plan) = compose_general_change_plan(task)
        && plan.target == obligation.target
    {
        return Some("declined_composed_target");
    }
    settled_route_delivers(task, &obligation.target, tool_names).then_some("declined_settled_route")
}
