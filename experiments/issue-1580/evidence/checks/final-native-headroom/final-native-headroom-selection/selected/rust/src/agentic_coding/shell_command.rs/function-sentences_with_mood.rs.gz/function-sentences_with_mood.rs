/// Resolve a semantic *intent* to its concrete command, backed by the seed
/// [`ShellIntentVocabulary`] (issue #680).
///
/// The two strategies above only fire when the prompt *names* the command (`run
/// pwd`) or asks, in prose, to list a directory. This third strategy handles the
/// common case where the user expresses an intent without naming the tool at all —
/// *"Print the current working directory"* → `pwd`, *"How much disk space is
/// free?"* → `df -h`, *"What is my username?"* → `whoami`. Each intent carries
/// multilingual cue phrases; the first intent whose cue is present in the prompt
/// wins (declaration order is most-specific-first), and its argument — if any — is
/// recovered from the prompt. An intent whose cue matches but whose required
/// argument is absent is skipped so the search continues rather than emitting an
/// argument-less command that would hang (`wc -l` on stdin).
/// The prompt split into sentences, each paired with whether it is a question.
///
/// Sentence boundaries are what separate the user's request from a sentence merely
/// *placed next to* it, so intent cues are read one sentence at a time (issue #907).
fn sentences_with_mood(lower: &str) -> Vec<(&str, bool)> {
    let mut sentences = Vec::new();
    let mut start = 0;
    for (index, character) in lower.char_indices() {
        if !matches!(
            character,
            '.' | '!' | '?' | ';' | '\n' | '。' | '！' | '？' | '；'
        ) {
            continue;
        }
        // A dot inside a token ends nothing — `main.py` is one word, not two
        // sentences.
        if character == '.'
            && lower[index + character.len_utf8()..]
                .chars()
                .next()
                .is_some_and(char::is_alphanumeric)
        {
            continue;
        }
        let text = lower[start..index].trim();
        if !text.is_empty() {
            sentences.push((text, matches!(character, '?' | '？')));
        }
        start = index + character.len_utf8();
    }
    let tail = lower[start..].trim();
    if !tail.is_empty() {
        sentences.push((tail, false));
    }
    sentences
}
