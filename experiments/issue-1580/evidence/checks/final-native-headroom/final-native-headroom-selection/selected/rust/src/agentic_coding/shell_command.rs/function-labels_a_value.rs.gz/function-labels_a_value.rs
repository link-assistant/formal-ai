/// Whether `sentence` states a fact *about* `cue` instead of requesting it.
///
/// The shape is `<cue> <copula> <value>` (English, Russian, Spanish, Chinese) or
/// `<cue> <value> <copula>` (Hindi): the cue opens the sentence as its subject,
/// a seed-declared copula links it, and a value follows. A question is never a
/// statement — neither one punctuated with `?` nor one that merely carries a
/// seed-declared question word ("我的用户名**是什么**") — and a cue that does not
/// open the sentence is not its subject, so
/// *"tell me what the current time is"* and *"what is the date?"* keep routing.
/// Whether `sentence` *declares where something lives*: the cue is followed by a
/// colon and a single absolute path.
///
/// A copula is not the only way to state a fact — agent harnesses prefer the
/// label form, and Hive Mind's *"Your prepared working directory: /tmp/example"*
/// supplies the working directory exactly as a copula would, which made every
/// production run answer with `pwd` (issue #907, follow-up).
///
/// The value is what separates this from a request, and it has to be: earlier
/// attempts keyed on the colon (which swallowed *"delete the file: old.log"*),
/// on request verbs (a four-word list that rescued nothing), and on subject
/// position (which cannot see that *"count"* and *"search"* are verbs). A
/// harness declares an **absolute** path — that is the only kind worth stating —
/// while a request's argument after a colon is a relative path, a search term,
/// or prose. Every row of the table above stays a request under this rule.
fn labels_a_value(sentence: &str, cue: &str) -> bool {
    let Some(head_end) = sentence.to_lowercase().find(cue) else {
        return false;
    };
    let Some(value) = sentence[head_end + cue.len()..]
        .trim_start()
        .strip_prefix([':', '：'])
        .map(str::trim)
    else {
        return false;
    };
    let mut words = value.split_whitespace();
    let Some(path) = words.next() else {
        return false;
    };
    words.next().is_none() && (path.starts_with('/') || path.starts_with("~/"))
}
