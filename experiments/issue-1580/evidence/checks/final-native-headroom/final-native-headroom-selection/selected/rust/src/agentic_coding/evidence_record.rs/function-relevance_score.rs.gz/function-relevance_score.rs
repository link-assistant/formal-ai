fn relevance_score(
    line: &str,
    terms: &[String],
    condition_requested: bool,
    implementation_requested: bool,
    serialized_relationship: Option<&str>,
    source_authority: usize,
) -> (
    usize,
    usize,
    usize,
    usize,
    usize,
    usize,
    usize,
    usize,
    usize,
    usize,
) {
    let words = line
        .split(|character: char| !character.is_ascii_alphanumeric())
        .filter(|word| !word.is_empty())
        .map(str::to_ascii_lowercase)
        .collect::<Vec<_>>();
    let matches = |term: &str| {
        words.iter().any(|word| word == term)
            || term
                .split('_')
                .all(|part| words.iter().any(|word| word == part))
    };
    let overlap = terms.iter().filter(|term| matches(term)).count();
    let requested_property = usize::from(terms.last().is_some_and(|term| matches(term)));
    let declaration_shape = if looks_like_declaration(line) {
        1 + usize::from(!looks_like_local_binding(line))
            + usize::from(looks_like_exposed_declaration(line))
    } else {
        0
    };
    let bound_requested = terms
        .iter()
        .any(|term| crate::seed::lexicon().mentions_role(crate::seed::ROLE_CODING_BOUND_CUE, term));
    let semantic_overlap = usize::from(
        bound_requested
            && words.iter().any(|word| {
                crate::seed::lexicon().mentions_role(crate::seed::ROLE_CODING_BOUND_CUE, word)
            }),
    );
    let code_shape = usize::from(line.contains(['{', '}', '(', ')', ';', '=', '<', '>']));
    let direct_serialized_identity =
        usize::from(serialized_relationship.is_some_and(|relationship| {
            words
                .windows(2)
                .any(|pair| pair[0] == relationship && pair[1] == "id")
        }));
    (
        usize::from(implementation_requested && !is_quoted_or_commented_source(source_text(line))),
        direct_serialized_identity,
        requested_property,
        usize::from(condition_requested && looks_like_condition(line)),
        source_authority,
        usize::from(condition_requested && looks_like_instance_condition(line)),
        declaration_shape,
        semantic_overlap,
        overlap,
        code_shape,
    )
}
