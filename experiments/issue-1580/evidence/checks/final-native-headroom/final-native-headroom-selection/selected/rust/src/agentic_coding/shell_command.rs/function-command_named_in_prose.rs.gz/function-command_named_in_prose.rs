/// Recover the command from a remainder that *names* it instead of being it.
///
/// Issue #866 and #867 reported *"Execute ls command"* running `/bin/ls
/// command`, which fails with *cannot access 'command'*. The trailing noun
/// names the command; it is not an argument to it. Seed data declares those
/// nouns per language in `data/seed/terminal-commands.lino`, and their presence
/// is the tell that the remainder is a noun phrase *about* a command rather
/// than a command line — so the command is collected out of it, dropping the
/// determiners that lead the phrase and stopping at the prose that ends it,
/// exactly as argument collection does elsewhere.
///
/// Quoting and shell metacharacters switch the recovery off, because inside
/// them a word is data: `git commit -m 'fix command parsing'` keeps its message.
fn command_named_in_prose(remainder: &str, vocab: &TerminalCommandVocabulary) -> Option<String> {
    if remainder.contains(|c| SHELL_QUOTING_AND_METACHARACTERS.contains(&c)) {
        return None;
    }
    let words = remainder.split_whitespace().collect::<Vec<_>>();
    let kept = words
        .iter()
        .copied()
        .filter(|word| !names_a_command(word, vocab))
        .collect::<Vec<_>>();
    if kept.len() == words.len() || kept.is_empty() {
        return None;
    }
    let start = kept.iter().position(|word| !is_prose_word(word))?;
    let mut command = vec![kept[start]];
    for word in &kept[start + 1..] {
        if is_prose_word(word) {
            break;
        }
        command.push(word);
    }
    Some(command.join(" "))
}
