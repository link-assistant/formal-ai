fn serialize_dialogue_answer(content: &str, statements: &[DialogueStatement]) -> String {
    let mut output = String::from("{\"intent\":\"fact_check_current_dialogue\",\"content\":");
    push_json_string(&mut output, content);
    output.push_str(",\"confidence\":1,\"evidence\":[");
    for (index, statement) in statements.iter().enumerate() {
        if index > 0 {
            output.push(',');
        }
        let mut evidence = format!("fact_check:statement:{}", statement.id);
        evidence.push(' ');
        evidence.push_str(statement.probability);
        evidence.push(' ');
        evidence.push_str(statement.basis);
        push_json_string(
            &mut output,
            &evidence,
        );
    }
    if !statements.is_empty() {
        output.push(',');
    }
    for (index, evidence) in [
        format!(
            "fact_check:audit:scope=current_dialogue;statements={}",
            statements.len()
        ),
        String::from("fact_check:scope:current_dialogue"),
        format!(
            "fact_check:formal_system:{}",
            stable_id(
                "formal_system",
                "name:current;universe:;interpretation:;"
            )
        ),
    ]
    .iter()
    .enumerate()
    {
        if index > 0 {
            output.push(',');
        }
        push_json_string(&mut output, evidence);
    }
    output.push_str("],\"trace\":[");
    for (index, statement) in statements.iter().enumerate() {
        if index > 0 {
            output.push(',');
        }
        push_json_string(
            &mut output,
            &format!(
                "fact_check:refutation:{}:disprove_statement:{}",
                statement.id, statement.outcome
            ),
        );
    }
    output.push_str("]}");
    output
}
