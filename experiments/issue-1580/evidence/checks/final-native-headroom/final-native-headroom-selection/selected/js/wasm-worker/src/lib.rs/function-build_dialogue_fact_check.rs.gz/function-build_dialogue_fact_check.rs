fn build_dialogue_fact_check(turns: &[String], templates: FactCheckTemplates<'_>) -> String {
    let mut statements = Vec::new();
    for text in turns
        .iter()
        .map(|turn| turn.trim())
        .filter(|turn| !turn.is_empty())
    {
        if !looks_declarative(text) {
            continue;
        }
        let id = stable_id("world_statement", text);
        if statements
            .iter()
            .any(|item: &DialogueStatement| item.id == id)
        {
            continue;
        }
        statements.push(assess_dialogue_statement(id, text, &templates));
    }
    statements.sort_by(|left, right| left.id.cmp(&right.id));

    let summary = if statements.is_empty() {
        templates.no_statements.to_string()
    } else {
        statements
            .iter()
            .map(|statement| render_dialogue_statement(statement, &templates))
            .collect::<Vec<_>>()
            .join("\n")
    };
    let content = fill_template(
        templates.audit,
        &[
            ("count", statements.len().to_string()),
            ("formal_system", String::from("current")),
            ("summary", summary),
        ],
    );
    serialize_dialogue_answer(&content, &statements)
}
