from pathlib import Path
import gzip, hashlib, io, json, tarfile

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
producer = root / 'experiments/issue-1580/evidence/ci/codeql-producer-f4588ce4'
assessment = json.loads((producer / 'macro-observation-assessment.json').read_text())
assert assessment['producerFilesVerified'] == 124 and assessment['macroRows'] == 122534
assert assessment['queryRuntimeWarnings'] == ['WARNING: Not caching stages during query-loading, since max heap size is only 1698 MB.']
inventory = json.loads((producer / 'producer-files.json').read_text())
verified = 0
for part in inventory['parts']:
    raw = (producer / part['file']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == part['sha256']
    rows = json.loads(raw)
    assert len(rows) == part['records']
    verified += len(rows)
assert verified == 124
destination = root / 'experiments/issue-1580/evidence/checks/macro-memory-f4588ce4'
destination.mkdir(exist_ok=False)
names = ['start-reasoning-budget-producer-collection.py', 'start-reasoning-budget-producer-collection.log',
    'collect-reasoning-budget-producer-reports.py', 'assess-reasoning-budget-producer.py',
    'assess-reasoning-budget-producer.log', 'assess-reasoning-budget-macro-observations.py',
    'draft-second-macro-memory-repair.py', 'draft-second-macro-memory-repair.log',
    'verify-second-macro-memory-repair.py', 'verify-second-macro-memory-repair.log',
    'read-next-recording-references.log', 'read-macro-seal-references.log']
selected = [Path(__file__)] + [scratch / name for name in names]
selected += [path for path in (scratch / 'second-macro-memory-repair').rglob('*') if path.is_file()]
buffer = io.BytesIO()
rows = []
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for path in sorted(selected):
        assert path.is_file(), path
        raw = path.read_bytes()
        name = path.relative_to(scratch).as_posix()
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
        archive.addfile(entry, io.BytesIO(raw))
        rows.append({'file': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
raw = buffer.getvalue()
packed = gzip.compress(raw, mtime=0)
(destination / 'supplied-investigation.tar.gz').write_bytes(packed)
(destination / 'supplied-investigation.json').write_text(json.dumps({'files': rows,
    'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(),
    'independentAuthorshipCredit': 0, 'fullIssueComplete': False}, indent=2) + '\n')
(destination / 'assessment.json').write_text(json.dumps({'publishedHead': assessment['head'],
    'originalProducerFilesVerified': 124, 'actualThreeGiBQueryCompiledAndExecuted': True,
    'actualThreeGiBWarningRemoved': False, 'measuredThreeGiBHeapMiB': 1698,
    'nextRequestedEvaluatorMiB': 4096, 'nextActualHostedWarningRemovalVerified': False,
    'negativeControlFailedAsExpected': True, 'localSecurityGroupsPassed': 19,
    'localProfileGroupsPassed': 18, 'fullIssueComplete': False,
    'independentAuthorshipCredit': 0}, indent=2) + '\n')
doc = root / 'docs/case-studies/issue-1580/second-hosted-macro-memory-checkpoint.md'
doc.write_text('''# Second hosted macro memory checkpoint

The original reports from [Security run 44785512004](https://github.com/link-assistant/formal-ai/actions/runs/44785512004) bind to published `f4588ce40023a1cc722cbed4ed7f977581fd4530`. All 124 producer files are retained with exact byte and archive identities. Rust and Actions SARIF each contain zero findings and zero warning/error notifications. The Rust report still contains 631 informational macro notifications; individual semantic/dataflow qualification remains open.

The optional query actually compiles and executes, retaining 122,534 rows across 2,216 paths, with the same 42,427 outside-expanded, 79,476 inside-expanded and 631 unexpanded partition. All 631 original notification start positions match unexpanded contexts. This agreement does not prove every included child maps to its expanded semantic entity.

The 3 GiB request leaves a measured 1,698 MiB Java heap and still emits `Not caching stages during query-loading`. The previous 2 GiB request left 914 MiB and the same warning. The next source adjustment requests 4 GiB based on those observations. It preserves two threads, a 512 MiB disk cache, the four-minute step boundary, strict compiler warnings and the original SARIF acceptance gate. Actual hosted warning removal remains unverified; no local query or native compilation runs.

The updated adapter contract fails against the 3 GiB source. After the bounded adjustment, all 19 security groups and 18 production-profile controls pass. Complete original producer reports, local negative controls, passing transcripts and supplied scripts are retained in the companion evidence archives. A reference-reading command that the Formal AI driver did not execute verbatim receives no verification credit. Every supplied script, conclusion and source replacement receives zero independent authorship credit.

This is an intermediate checkpoint. Macro semantics, unchanged original-native acceptance, complete eight-template review, applicable runtime adoption, production publication/served identity, warning cleanup and whole-PR review remain unfinished. The PR stays draft and unmerged.
''')
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- The second actual macro query on f4588ce4 compiles and executes with 122,534 rows and 124 original producer files. Its 3 GiB request still emits the stage-cache warning at a measured 1,698 MiB heap. A 4 GiB adjustment has the expected failing pre-fix contract and 19 security/18 profile passing controls; actual next-head warning removal and all semantic acceptance remain open. Strict SARIF still preserves zero findings/warning-error notifications and all 631 informational macro notes.\n')
print('Preserved actual 3 GiB warning, all 124 original reports, and bounded 4 GiB draft. Hosted removal remains unverified.')
