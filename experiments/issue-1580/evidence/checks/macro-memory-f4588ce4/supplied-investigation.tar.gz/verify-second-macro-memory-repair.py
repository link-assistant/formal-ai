from pathlib import Path
import json, os, subprocess, sys, traceback

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/second-macro-memory-repair')
if len(sys.argv) == 1:
    base.mkdir(exist_ok=False)
    with (base / 'worker.log').open('wb') as stream:
        child = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root,
            stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': child.pid, 'scratch': str(base)}))
    sys.exit(0)
environment = dict(os.environ)
environment.pop('NODE_OPTIONS', None)
records = []
def run(name, argv, expected=0):
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
    for label in ['stdout', 'stderr']:
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode, 'expectedExitCode': expected})
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == expected, (name, result.stdout[-2500:], result.stderr[-1000:])
    print(name, 'EXPECTED', expected, flush=True)
try:
    test = 'rust/tests/web/security-codeql-results.test.mjs'
    run('before', ['timeout', '600', 'node', '--max-old-space-size=256', '--test',
        '--test-reporter=tap', '--test-concurrency=1', '--test-name-pattern=macro observation preserves', test], 1)
    adapter = root / 'experiments/issue-1580/codeql-macro-contexts/observe.py'
    source = adapter.read_text()
    assert source.count('"--ram=3072"') == 1
    adapter.write_text(source.replace('"--ram=3072"', '"--ram=4096"'))
    readme = root / 'experiments/issue-1580/codeql-macro-contexts/README.md'
    source = readme.read_text()
    before = '''query execution requests two threads, 3 GiB RAM and a 512 MiB disk cache.
The first hosted run on `39196d1f` compiled and executed this query, retaining
122,534 rows. Its earlier 2 GiB setting left a 914 MiB Java heap and emitted a
stage-cache warning. The bounded 3 GiB adjustment needs its own hosted
verification; local adapter controls cannot prove the actual heap allocation.'''
    after = '''query execution requests two threads, 4 GiB RAM and a 512 MiB disk cache.
The hosted runs on `39196d1f` and `f4588ce4` each retain 122,534 rows. Their
2 and 3 GiB requests leave 914 and 1698 MiB Java heaps respectively; both emit
the query-loading stage-cache warning. The next bounded 4 GiB request is based
on that measured allocation, not a claim of warning removal. Actual next-head
execution must qualify it; local adapter controls cannot prove heap allocation.'''
    assert before in source
    readme.write_text(source.replace(before, after))
    fragment = root / 'changelog.d/issue-1580-macro-query-memory.md'
    fragment.write_text('Request a bounded 4 GiB evaluator budget for the optional hosted Rust macro observation after actual 2 and 3 GiB runs retain the query-loading cache warning. Preserve its four-minute deadline, two threads, strict compiler warnings and original security report checks; warning removal requires hosted verification.\n')
    run('security', ['timeout', '600', 'node', '--max-old-space-size=256', '--test',
        '--test-reporter=tap', '--test-concurrency=1', test])
    run('profile', ['timeout', '600', 'node', '--max-old-space-size=256', '--test',
        '--test-reporter=tap', '--test-concurrency=1', 'rust/tests/web/fast-pull-request-production-profile.test.mjs'])
    run('whitespace', ['git', 'diff', '--check'])
    (base / 'outcome.json').write_text(json.dumps({'complete': True, 'passed': True,
        'actualNextHostedWarningRemovalVerified': False, 'fullIssueComplete': False}, indent=2) + '\n')
except BaseException:
    traceback.print_exc()
    (base / 'failure.json').write_text(json.dumps({'complete': False, 'traceback': traceback.format_exc()}) + '\n')
    sys.exit(1)
