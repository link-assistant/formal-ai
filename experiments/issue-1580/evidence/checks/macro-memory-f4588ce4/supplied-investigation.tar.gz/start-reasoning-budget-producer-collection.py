from pathlib import Path
import subprocess

scratch = Path('/tmp/issue-1580-research')
source = (scratch / 'collect-macro-producer-reports.py').read_text()
for before, after in [
    ('macro-producer-original-reports', 'reasoning-budget-producer-original-reports'),
    ('codeql-producer-39196d1f', 'codeql-producer-f4588ce4'),
    ('39196d1fb218d0ef492f90915270f9ae3ac28ba1', 'f4588ce40023a1cc722cbed4ed7f977581fd4530'),
    ('macro-batch-publication/dispatch-security.stdout', 'reasoning-budget-publication/dispatch-security.stdout'),
    ('native-families-39196d1f', 'native-families-f4588ce4')]:
    assert before in source
    source = source.replace(before, after)
target = scratch / 'collect-reasoning-budget-producer-reports.py'
target.write_text(source)
result = subprocess.run(['python3', str(target)], capture_output=True)
for label in ['stdout', 'stderr']:
    (scratch / ('start-reasoning-budget-producer-collection.' + label)).write_bytes(getattr(result, label))
assert result.returncode == 0, result.stderr
print(result.stdout.decode())
