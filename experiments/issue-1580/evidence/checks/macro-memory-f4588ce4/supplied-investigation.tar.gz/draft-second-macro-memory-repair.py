from pathlib import Path

root = Path('/tmp/gh-issue-solver-1794900398048')
test = root / 'rust/tests/web/security-codeql-results.test.mjs'
source = test.read_text()
assert source.count("'--ram=3072'") == 1
test.write_text(source.replace("'--ram=3072'", "'--ram=4096'"))
print('Changed only the adapter contract first; preserve its failing control before changing the producer request.')
