from pathlib import Path
import ast,datetime,json,os,subprocess
repository=Path('/tmp/gh-issue-solver-1794900398048')
root=Path('/tmp/issue-1580-research/secretlint-node22-hosted')
env=dict(os.environ);env.pop('NODE_OPTIONS',None);env['PYTHONDONTWRITEBYTECODE']='1'
checks=[
 ('focused',['node','--test','--test-concurrency=1','experiments/issue-1580/secretlint-engine-workflow.test.mjs']),
 ('maintained',['node','--test','--test-concurrency=1','rust/tests/web/bounded-subprocess-boundaries.test.mjs']),
 ('security-neighbor',['node','--test','--test-concurrency=1','rust/tests/web/security-codeql-results.test.mjs']),
 ('fast-profile',['node','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs']),
 ('runner-labels',['node','scripts/check-runner-labels.mjs']),
]
for gate in ['check-required-documentation','check-readable-code','check-file-size','check-file-size-js-twin','check-tests-as-docs','check-tests-as-documentation-javascript-twin','workflows']:
 checks.append((gate,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]))
records=[]
for label,command in checks:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (root/(label+'.log')).open('w') as log:result=subprocess.run(command,cwd=repository,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'label':label,'command':command,'status':result.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 records.append(row);(root/'progress.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
ast.parse((repository/'experiments/issue-1580/secretlint-locked-live.py').read_text())
(root/'verification-outcome.json').write_text(json.dumps({'checks':records,'allPassed':all(r['status']==0 for r in records),'pythonParsed':True,'nodeOptionsRemovedForTestIsolation':True},indent=2)+'\n')
