from pathlib import Path
import json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/monitor-failure-termination-repair')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 assert result.returncode in allowed,(name,result.returncode)
def preserve(path):
 target=out/'preimages'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((root/path).read_bytes())
try:
 probe='experiments/issue-1580/probe-budget-process-lifetime.py';preserve(probe);p=root/probe;text=p.read_text()
 old="            'inspection-unavailable': ('sleep 4', 0),"
 assert text.count(old)==1;text=text.replace(old,old+"\n            'inspection-unavailable-delayed-kill': (\"bash -c 'trap \\\"\\\" TERM; exec sleep 4'\", 0),")
 text=text.replace("if case == 'inspection-unavailable':", "if case in ('inspection-unavailable', 'inspection-unavailable-delayed-kill'):")
 text=text.replace("if case == 'delayed-kill':", "if case in ('delayed-kill', 'inspection-unavailable-delayed-kill'):")
 p.write_text(text)
 tests=['experiments/issue-1580/budget-process-lifetime.test.mjs','experiments/issue-1580/deadline-process-lifetime.test.mjs']
 for i,path in enumerate(tests):
  preserve(path);p=root/path;text=p.read_text();old="['inspection-unavailable', 125],";assert text.count(old)==1
  p.write_text(text.replace(old,old+" ['inspection-unavailable-delayed-kill', 125],"))
  run('before-'+str(i),['node','--max-old-space-size=128','--test','--test-concurrency=1','--test-name-pattern','inspection-unavailable-delayed-kill',path],(1,))
 for path in ['scripts/run-with-deadline.sh','scripts/run-with-budget-warning.sh']:
  preserve(path);p=root/path;text=p.read_text();old='''    signal_command_tree KILL
    exit 125
''';assert text.count(old)==1
  new='''    signal_command_tree KILL
    # The failed inspection cannot certify termination. Still allow bounded
    # delivery time before releasing the caller: even SIGKILL is asynchronous.
    # kill -0 also sees zombies, so never wait indefinitely for an outside reaper.
    # This remains a monitoring failure (125), including when the group vanishes.
    monitor_failure_started=$SECONDS
    for ((monitor_check = 0; monitor_check < 20; monitor_check++)); do
      kill -0 "-$command_pid" 2> /dev/null || break
      [ $((SECONDS - monitor_failure_started)) -lt 2 ] || break
      sleep 0.1 2> /dev/null || sleep 1
    done
    exit 125
'''
  p.write_text(text.replace(old,new))
  run('syntax-'+p.stem,['bash','-n',path])
 for i,path in enumerate(tests):run('after-'+str(i),['node','--max-old-space-size=128','--test','--test-concurrency=1',path])
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'beforeFails':2,'monitorFailureStatus':125,'unavailableInspectionStillUnconfirmed':True,'boundedKillDeliverySeconds':2,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
