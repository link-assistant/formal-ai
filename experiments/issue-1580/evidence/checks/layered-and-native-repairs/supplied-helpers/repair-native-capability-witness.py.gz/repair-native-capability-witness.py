from pathlib import Path
import hashlib,json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/native-capability-witness-repair')
out.mkdir(exist_ok=False)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 assert result.returncode in allowed,(name,result.returncode)
 return result.returncode
try:
 test=root/'experiments/issue-1580/native-capability-trace.test.mjs'
 assert not test.exists()
 test.write_text(r'''// Replay the literal native source witness without compiling Rust.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {resolve, dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import test from 'node:test';

const root = fileURLToPath(new URL('../../', import.meta.url));
const owner = 'rust/tests/unit/docs_requirements/agent_cli_shell.rs';
function replayWitness(overrides = new Map()) {
  const read = file => overrides.get(file) ?? readFileSync(resolve(root, file), 'utf8');
  const witness = read(owner);
  const captures = [...witness.matchAll(/let (router|classification) = read\(root\.join\(\s*"([^"]+)"[,]?\s*\)\);\s*assert_contains_all\(\s*"[^"]+",\s*&(router|classification),\s*&\[([\s\S]*?)\],\s*\);/gu)];
  assert(captures.length, 'the real native witness must read and assert its capability sources');
  for (const [, binding, file, asserted, literals] of captures) {
    assert.equal(asserted, binding);
    const needles = [...literals.matchAll(/"(?:\\.|[^"\\])*"/gu)].map(match => JSON.parse(match[0]));
    assert(needles.length);
    for (const needle of needles) assert(read(file).includes(needle), file + ' lacks ' + needle);
  }
  const parent = captures.find(match => match[1] === 'router');
  const child = captures.find(match => match[1] === 'classification');
  assert(parent && child, 'the native witness must trace both owners');
  const declaration = /#\[path = "([^"]+)"\]\s*mod tool_classification;/u.exec(read(parent[2]));
  assert(declaration, 'the parent must actually compile the asserted child');
  assert.equal(resolve(root, child[2]), resolve(root, dirname(parent[2]), declaration[1]));
}

test('the native shell source witness follows the compiled capability child', () => replayWitness());
test('the native witness rejects disconnected modules and missing seed lookup', () => {
  const parent = 'rust/src/agentic_coding/capability_router.rs';
  const child = 'rust/src/agentic_coding/capability_router/tool_classification.rs';
  assert.throws(() => replayWitness(new Map([[parent, readFileSync(resolve(root, parent), 'utf8')
    .replace('mod tool_classification;', 'mod disconnected;')]])), /lacks|compile/u);
  assert.throws(() => replayWitness(new Map([[child, readFileSync(resolve(root, child), 'utf8')
    .replaceAll('seed::agentic_tool_capabilities()', 'disconnected_registry()')]])), /lacks/u);
});
''')
 run('before',['node','--max-old-space-size=128','--test','--test-concurrency=1',str(test)],(1,))
 path=root/'rust/tests/unit/docs_requirements/agent_cli_shell.rs';before=path.read_text();(out/'agent_cli_shell.before.rs').write_text(before)
 old='''    assert_contains_all(
        "canonical capability owner",
        &router,
        &["seed::agentic_tool_capabilities()", ".aliases"],
    );'''
 new='''    assert_contains_all(
        "canonical capability owner",
        &router,
        &[
            "#[path = \\\"capability_router/tool_classification.rs\\\"]",
            "mod tool_classification;",
            "pub(super) use tool_classification::{",
            "tool_for,",
        ],
    );
    let classification = read(root.join(
        "rust/src/agentic_coding/capability_router/tool_classification.rs",
    ));
    assert_contains_all(
        "compiled capability classification owner",
        &classification,
        &["seed::agentic_tool_capabilities()", ".aliases"],
    );'''
 assert before.count(old)==1
 path.write_text(before.replace(old,new))
 # Keep the read expression on one line for the literal native replay.
 text=path.read_text().replace('let classification = read(root.join(\n        "rust/src/agentic_coding/capability_router/tool_classification.rs",\n    ));','let classification = read(root.join("rust/src/agentic_coding/capability_router/tool_classification.rs"));')
 path.write_text(text)
 run('rustfmt',['rustfmt','--edition','2024',str(path)])
 run('after',['node','--max-old-space-size=128','--test','--test-concurrency=1',str(test)])
 run('rustfmt-check',['rustfmt','--check','--edition','2024',str(path)])
 owner=root/'rust/tests/web/issue-1580-template-observations.test.mjs';text=owner.read_text();assert 'native-capability-trace' not in text
 owner.write_text(text+"\nimport '../../../experiments/issue-1580/native-capability-trace.test.mjs';\n")
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'beforeSha256':hashlib.sha256(before.encode()).hexdigest(),'nativeExecutionVerified':False,'actualBeforeFailureJob':136890696816,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
