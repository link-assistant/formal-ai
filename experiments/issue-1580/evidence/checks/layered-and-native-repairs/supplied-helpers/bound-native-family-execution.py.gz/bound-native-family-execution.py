from pathlib import Path
import json,subprocess,os
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/native-family-execution-budget');out.mkdir(exist_ok=False)
test=root/'experiments/issue-1580/native-regression-groups.test.mjs';before=test.read_text();(out/'test.before.mjs').write_text(before)
old="  assert.equal(matrix.steps.at(-1).run, 'bash scripts/ci-native-regressions.sh \"${{ matrix.group }}\"');"
new="""  const execute = matrix.steps.at(-1);
  assert.equal(execute.run, 'bash scripts/run-with-budget-warning.sh 900 "Native contracts ${{ matrix.group }}" bash scripts/ci-native-regressions.sh "${{ matrix.group }}"');
  assert.deepEqual(execute.env, {TEST_WARN_RATIO_PERCENT: '75'});
  assert(900 + 2 * 120 < matrix['timeout-minutes'] * 60,
    'execution and both bounded checkout attempts must expire before the job clock');"""
assert before.count(old)==1;test.write_text(before.replace(old,new))
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
def run(name,args,expected=0):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 assert result.returncode==expected,(name,result.returncode)
run('before',['node','--max-old-space-size=128','--test','--test-name-pattern','native workflow gives','experiments/issue-1580/native-regression-groups.test.mjs'],1)
path=root/'.github/workflows/native-type-check.yml';before=path.read_text();(out/'workflow.before.yml').write_text(before)
old='''      - name: Verify the complete selected contract family
        run: bash scripts/ci-native-regressions.sh "${{ matrix.group }}"'''
new='''      - name: Verify the complete selected contract family
        env:
          TEST_WARN_RATIO_PERCENT: '75'
        run: bash scripts/run-with-budget-warning.sh 900 "Native contracts ${{ matrix.group }}" bash scripts/ci-native-regressions.sh "${{ matrix.group }}"'''
assert before.count(old)==1;path.write_text(before.replace(old,new))
run('after',['node','--max-old-space-size=128','--test','--test-name-pattern','native workflow gives','experiments/issue-1580/native-regression-groups.test.mjs'])
run('whitespace',['git','diff','--check'])
(out/'outcome.json').write_text(json.dumps({'complete':True,'executionSeconds':900,'jobMinutes':20,'warningPercent':75,'hostedExecutionVerified':False,'independentAuthorshipCredit':0},indent=2)+'\n')
