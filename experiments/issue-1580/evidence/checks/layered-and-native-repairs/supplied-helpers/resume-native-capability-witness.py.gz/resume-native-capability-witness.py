from pathlib import Path
import hashlib,json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/native-capability-witness-repair')
test=root/'experiments/issue-1580/native-capability-trace.test.mjs';text=test.read_text();assert ' = read\\(' in text
test.write_text(text.replace(' = read\\(', ' =\\s*read\\('))
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
for name,args in [
 ('after-replay-layout-repair',['node','--max-old-space-size=128','--test','--test-concurrency=1',str(test)]),
 ('rustfmt-check',['rustfmt','--check','--edition','2024','rust/tests/unit/docs_requirements/agent_cli_shell.rs']),
 ('whitespace',['git','diff','--check'])]:
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 assert result.returncode==0,(name,result.returncode)
owner=root/'rust/tests/web/issue-1580-template-observations.test.mjs';text=owner.read_text();assert 'native-capability-trace' not in text
owner.write_text(text+"\nimport '../../../experiments/issue-1580/native-capability-trace.test.mjs';\n")
(out/'outcome.json').write_text(json.dumps({'complete':True,'beforeSha256':hashlib.sha256((out/'agent_cli_shell.before.rs').read_bytes()).hexdigest(),'nativeExecutionVerified':False,'actualBeforeFailureJob':136890696816,'replayLayoutAttemptFailed':True,'independentAuthorshipCredit':0},indent=2)+'\n')
