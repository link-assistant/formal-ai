from pathlib import Path
from datetime import datetime
import gzip,json,re,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/native-coding-headroom-analysis');out.mkdir(exist_ok=False)
base=root/'experiments/issue-1580/evidence/ci/integrated-repairs-fbac28e5'
rows=[];jobs=[]
for path in sorted(base.glob('jobs-*.stdout.gz')):
 for line in gzip.decompress(path.read_bytes()).decode().splitlines():
  job=json.loads(line)
  if 'Native contracts (coding)' in job.get('name',''):jobs.append(job)
assert len(jobs)==1,jobs
job=jobs[0];(out/'previous-job.json').write_text(json.dumps(job,indent=2)+'\n')
log=base/('failed-job-'+str(job['id'])+'.stdout.gz')
if log.exists():raw=gzip.decompress(log.read_bytes())
else:
 logname=str(job['run_id'])
 full=gzip.decompress((base/('full-run-'+logname+'.stdout.gz')).read_bytes()).decode()
 lines=[]
 for line in full.splitlines():
  parts=line.split('\t',2)
  if len(parts)==3 and parts[0]==job['name']:lines.append(parts[2])
 assert lines
 raw=('\n'.join(lines)+'\n').encode()
(out/'previous-job.log').write_bytes(raw)
for tag,source in [('previous',out/'previous-job.log'),('current',Path('/tmp/issue-1580-research/active-pipeline-second-observation/failed-job-136890696854.log'))]:
 previous=None;costs={};summary=None;total=None;last=None
 for line in source.read_text().splitlines():
  timestamp,_,message=line.lstrip('\ufeff').partition(' ')
  if not timestamp.endswith('Z'):continue
  now=datetime.fromisoformat(timestamp);last=now
  start=re.fullmatch(r'running (\d+) tests',message)
  if start:previous=now;total=int(start[1])
  match=re.fullmatch(r'test ([A-Za-z0-9_:]+) \.{3} ok',message)
  if match:
   assert previous is not None
   costs[match[1]]=max((now-previous).total_seconds(),.001);previous=now
  if message.startswith('test result:'):summary=message
 assert costs
 value={'tag':tag,'listedCount':total,'completed':len(costs),'summary':summary,'observedSum':sum(costs.values()),'lastCompletionToEnd':(last-previous).total_seconds(),'durations':costs}
 (out/(tag+'-durations.json')).write_text(json.dumps(value,indent=2)+'\n')
 rows.append({k:v for k,v in value.items() if k!='durations'})
(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
