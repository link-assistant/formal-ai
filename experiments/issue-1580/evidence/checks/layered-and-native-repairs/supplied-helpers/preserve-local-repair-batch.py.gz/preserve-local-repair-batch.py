from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, re, subprocess, sys, time, traceback

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'local-repair-batch-preservation'
if len(sys.argv) == 1:
    out.mkdir(exist_ok=False)
    with (out / 'worker.log').open('w') as stream:
        worker = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root,
                                  stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    (out / 'pid.json').write_text(json.dumps({'pid': worker.pid}) + '\n')
    print(worker.pid)
    sys.exit(0)

try:
    replay = scratch / 'complete-local-repair-replay'
    for tick in range(180):
        assert not (replay / 'failed.txt').exists(), (replay / 'failed.txt').read_text() if (replay / 'failed.txt').exists() else ''
        if (replay / 'outcome.json').exists():
            break
        time.sleep(5)
    assert json.loads((replay / 'outcome.json').read_text())['complete']
    observed = (replay / 'maintained-observations.stdout').read_text()
    assert re.search(r'^ℹ tests 207$', observed, re.M)
    assert re.search(r'^ℹ pass 207$', observed, re.M)
    gates = (replay / 'all-local-gates.stdout').read_text()
    passed = len(re.findall(r'^PASS ', gates, re.M))
    skipped = len(re.findall(r'^SKIP ', gates, re.M))
    assert passed + skipped == 141 and passed == 88 and skipped == 53, (passed, skipped)
    target = root / 'experiments/issue-1580/evidence/checks/layered-and-native-repairs'
    target.mkdir(exist_ok=False)
    directories = [
        'layered-8d8-diagnosis', 'layered-fixture-and-projection-repair',
        'layered-duration-refresh-analysis', 'layered-duration-and-queue-repair',
        'native-capability-witness-repair', 'native-acceptance-headroom',
        'monitor-failure-termination-repair', 'native-coding-headroom-analysis',
        'native-coding-shard-repair', 'native-family-execution-budget',
        'local-repair-feedback-refresh', 'active-pipeline-second-observation',
        'active-native-failure-raw', 'complete-local-repair-replay',
        'local-repair-review', 'local-repair-staging',
    ]
    records = []
    for name in directories:
        for source in sorted((scratch / name).rglob('*')):
            if not source.is_file() or source.name == 'pid.json':
                continue
            raw = source.read_bytes()
            relative = source.relative_to(scratch)
            destination = target / (str(relative) + '.gz')
            destination.parent.mkdir(parents=True, exist_ok=True)
            packed = gzip.compress(raw, mtime=0)
            destination.write_bytes(packed)
            assert gzip.decompress(packed) == raw
            records.append({'file': str(destination.relative_to(target)),
                            'rawSha256': hashlib.sha256(raw).hexdigest(),
                            'archiveSha256': hashlib.sha256(packed).hexdigest(),
                            'bytes': len(raw), 'lines': len(raw.splitlines())})
    helpers = [
        'repair-native-capability-witness.py', 'resume-native-capability-witness.py',
        'extract-native-acceptance-headroom.py', 'repair-monitor-failure-termination.py',
        'inspect-native-coding-headroom.py', 'repair-native-coding-shards.py',
        'preserve-future-coding-modules.py', 'bound-native-family-execution.py',
        'replay-complete-local-repair-batch.py', 'prepare-local-repair-review.py',
        'stage-complete-local-repair-code.py', 'preserve-local-repair-batch.py',
    ]
    for name in helpers:
        raw = (scratch / name).read_bytes()
        destination = target / 'supplied-helpers' / (name + '.gz')
        destination.parent.mkdir(exist_ok=True)
        packed = gzip.compress(raw, mtime=0)
        destination.write_bytes(packed)
        records.append({'file': str(destination.relative_to(target)),
                        'rawSha256': hashlib.sha256(raw).hexdigest(),
                        'archiveSha256': hashlib.sha256(packed).hexdigest(),
                        'bytes': len(raw), 'lines': len(raw.splitlines())})
    (target / 'records.jsonl').write_text(''.join(json.dumps(row, separators=(',', ':')) + '\n' for row in records))
    receipt = {'observedAt': datetime.now(timezone.utc).isoformat(),
               'sourceHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
               'archives': len(records), 'maintainedTestsPassed': 207,
               'javascriptGatesPassed': passed, 'javascriptGatesSkipped': skipped,
               'sourceWarnings': 55, 'nativeExecutionVerified': False,
               'independentAuthorshipCredit': 0, 'fullIssueComplete': False}
    (target / 'identity.json').write_text(json.dumps(receipt, indent=2) + '\n')
    checkpoint = '''# Layered checkout, scheduling and native acceptance repair

Published head `8d8f1481` exposes several independent failures. Layered run
44918894968 lacks consumed issue-703, issue-859 and issue-989 transcripts after
sparse checkout; the desktop extraction step has no explicit deadline; the
capability-router TypeScript comments remain stale; and one JavaScript shard
reaches its 360-second execution budget. The complete failed streams and their
original line numbers remain retained. The earlier claim that self-translate
verified the module projections is corrected in the citation checkpoint.

Restore the four consumed transcripts through explicit sparse rules and check
every moved native fixture using Git's actual sparse-checkout rules. Run the
actual translate-es writer and currency check; only the five source citations
change. Give desktop artifact extraction its explicit five-minute step bound.
Raise measured scheduling weights from 872 completed hosted observations,
preserving every higher historical cost. The retained four-worker model's
largest shard falls from 321.454 to 261.051 seconds. This is a model replay;
next-head hosted timing remains unverified. Record the explicit file queue
before Node can emit synchronous enqueue events, and refuse to assign an
unfinished lower bound when the first queued case has no observed start.

Native core job 136890696816 fails at raw log lines 1840–1851: its old source
witness searches the capability-router parent after classification moved into
an actually compiled child. Follow the parent's module declaration and public
re-export, then check seed lookup and aliases in that child. Keep every native
behavior assertion. A lightweight literal replay rejects disconnected modules
and missing seed lookup without compiling Rust.

Native coding job 136890696854 is cancelled after 58 of 62 successful cases.
Retain that partial stream and the preceding complete 62-case stream with raw
hashes. Derive each completed sequential weight reproducibly; assign no duration
to the unfinished tail. Two coding shards partition the actual compiled test
listing, including future modules, and preserve listing/execution failures.
The 60 focused runner checks pass. Each native family now has a 900-second
execution budget inside its unchanged 20-minute job, with the original
read-only permissions, offline mode and matrix concurrency. No hosted timing or
native execution after these edits is claimed.

Extract five native acceptance bodies into explicitly compiled children.
The pre-format exact inverse reconstructs all five originals; all test names,
assertions and fixtures remain. Their five size warnings disappear under the
unchanged limits. The source scanner reports 55 warnings and no violations.
The initial 205-case combined attempt uncovers a separate cleanup race: a
failed process inspection releases the wrapper immediately after asynchronous
SIGKILL. Both wrappers now allow bounded delivery time and still return 125;
they do not claim confirmed termination when inspection is unavailable. Both
controlled delayed-delivery cases fail before repair and pass afterward.

The final maintained owner passes 207 tests. All 141 JavaScript gates finish:
88 pass and 53 explicitly skip their unavailable native-only execution. Focused
runtime projection checks, all 60 native-runner controls, Rust formatting and
whitespace checks pass. No local Rust build occurs. Failed before/after harness
attempts remain separate observations in the archive; they receive no passing
verification credit. The native extraction and witness edits still require CI.

Evidence: experiments/issue-1580/evidence/checks/layered-and-native-repairs/.
Every archive records original bytes, lines and SHA256 alongside its gzip hash.
The complete-tree template/practice reviews, remaining warnings, original live
and budget criteria, per-child CodeQL qualification, complete PR review and
independent Formal AI reasoning floor remain unfinished. Supplied commands and
conclusions earn zero independent credit. The PR remains draft and unmerged.

PR: https://github.com/link-assistant/formal-ai/pull/1581
'''
    (root / 'docs/case-studies/issue-1580/layered-and-native-repair-checkpoint.md').write_text(checkpoint)
    plan = root / 'experiments/issue-1580/work-plan.md'
    text = plan.read_text()
    start = text.index('## Current verification checkpoint\n')
    end = text.index('The entries below are retained historical observations', start)
    current = '''## Current verification checkpoint

Published `8d8f1481` includes main `f574289f`. At the 2026-11-21 16:18 UTC
observation, 32 workflows exist: 29 succeeded, one skipped, Layered CI failed
and CI/CD Pipeline is still active. Pipeline already reports a failed native
source witness and a cancelled coding family. These terminal job failures and
all known Layered failures have local repairs; complete terminal-run collection
and next-head hosted validation remain required before acceptance.

All 207 maintained issue observations pass. The complete 141-entry JavaScript
gate replay has 88 passes, 53 explicit native-only skips and zero failures.
All 60 focused native-runner controls pass; no native compilation or native
execution is claimed. Five exact-conservation acceptance extractions reduce the
unchanged-limit source scan to 55 warnings. The before/fixed cleanup race and
all failed harness attempts remain retained separately. See the
[Layered and native checkpoint](../../docs/case-studies/issue-1580/layered-and-native-repair-checkpoint.md).

All eight complete template/practice reviews, remaining source warnings,
original budget/live criteria, CodeQL per-child semantic qualification, complete
PR review and the independent Formal AI reasoning floor remain unfinished.
Independent reasoning remains 0/20. The PR remains draft and unmerged.

'''
    plan.write_text(text[:start] + current + text[end:])
    (root / 'changelog.d/20261121_1580_layered_native_repairs.md').write_text('''### Fixed

- Preserve consumed transcripts in Layered sparse checkouts, refresh hosted
  JavaScript scheduling costs without losing higher historical measurements,
  and record queued files before synchronous runner events.
- Follow the compiled capability classification owner in native acceptance,
  split coding contracts using complete compiled listings and retained timing
  evidence, and bound native execution within the existing job clock.
- Preserve native test coverage while extracting five warning-sized owners;
  allow bounded signal delivery after process-monitor inspection failure.
''')
    subprocess.run(['git', 'add', 'experiments/issue-1580/evidence/checks/layered-and-native-repairs',
                    'docs/case-studies/issue-1580/layered-and-native-repair-checkpoint.md',
                    'experiments/issue-1580/work-plan.md',
                    'changelog.d/20261121_1580_layered_native_repairs.md'], cwd=root, check=True)
    with (out / 'staged-whitespace.stdout').open('w') as stdout:
        subprocess.run(['git', 'diff', '--cached', '--check'], cwd=root, stdout=stdout, stderr=subprocess.STDOUT, check=True)
    (out / 'outcome.json').write_text(json.dumps(receipt, indent=2) + '\n')
except BaseException:
    traceback.print_exc()
    (out / 'failed.txt').write_text(traceback.format_exc())
    sys.exit(1)
