from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,os,re,subprocess,sys,time,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'corrected-local-repair-publication'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);env.pop('CI',None)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 assert result.returncode in allowed,(name,result.returncode)
 return result.returncode
try:
 preserved=scratch/'corrected-local-repair-batch-preservation'
 for attempt in range(240):
  assert not (preserved/'failed.txt').exists()
  if (preserved/'outcome.json').exists():break
  time.sleep(5)
 assert json.loads((preserved/'outcome.json').read_text())['maintainedTestsPassed']==208
 target=root/'experiments/issue-1580/evidence/checks/layered-and-native-repairs'
 records=[json.loads(line) for line in (target/'records.jsonl').read_text().splitlines()]
 def archive(source,relative):
  raw=source.read_bytes();packed=gzip.compress(raw,mtime=0);dest=target/relative
  assert not dest.exists(),relative
  dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed)
  records.append({'file':relative,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
 cutoff='2026-11-21T15-45-52'
 sessions=[]
 for source in sorted((root/'experiments/issue-1580/evidence/commands').glob('*.json')):
  if source.name[:19]<cutoff:continue
  json.loads(source.read_text());archive(source,'formal-sessions/'+source.name+'.gz');sessions.append(source.name)
 for name in ['lost-specification-case.json','identify-lost-specification-case-driver.log','identify-lost-specification-case-driver-2.log','identify-lost-specification-case-driver-3.log']:
  archive(scratch/name,'carry-diagnosis/'+name+'.gz')
 archive(Path(__file__),'supplied-helpers/'+Path(__file__).name+'.gz')
 def refresh():
  (target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
  identity=json.loads((target/'identity.json').read_text());identity.update({'archives':len(records),'formalSessions':len(sessions),'provenanceCutoff':cutoff,'independentAuthorshipCredit':0})
  (target/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
 refresh()
 run('stage-evidence',['git','add','--',str(target)])
 run('post-archive-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size,check-changelog-fragment-js-twin,check-reconstructed-changelog'])
 run('staged-secret-scan',['bash','scripts/check-secrets.sh'])
 run('fresh-main',['git','fetch','origin','main'])
 run('main-ancestry',['git','merge-base','--is-ancestor','origin/main','HEAD'])
 run('branch',['git','branch','--show-current']);assert (out/'branch.stdout').read_text().strip()=='issue-1580-8d61a32a61e1'
 for status in ['in_progress','queued']:
  run('runs-'+status,['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--status',status,'--limit','100','--json','databaseId,workflowName,headSha,status'])
  assert json.loads((out/('runs-'+status+'.stdout')).read_text())==[]
 run('pr-current',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','body,title,isDraft,headRefOid,url'])
 for label,endpoint in [('conversation','issues/1581/comments'),('inline','pulls/1581/comments'),('reviews','pulls/1581/reviews'),('issue-comments','issues/1580/comments')]:
  run('feedback-'+label,['gh','api','repos/link-assistant/formal-ai/'+endpoint,'--paginate'])
 run('github-pr-diff',['gh','pr','diff','1581','--repo','link-assistant/formal-ai'],(0,1))
 run('staged-stat',['git','diff','--cached','--stat'])
 run('unstaged-summary',['git','diff','--stat'])
 for source in sorted(out.iterdir()):
  if source.is_file() and source.name!='pid.json' and source.name!='worker.log':archive(source,'publication-preparation/'+source.name+'.gz')
 refresh();run('stage-final-evidence',['git','add','--',str(target)])
 run('final-whitespace',['git','diff','--cached','--check'])
 for row in records:
  packed=(target/row['file']).read_bytes();raw=gzip.decompress(packed)
  assert hashlib.sha256(packed).hexdigest()==row['archiveSha256'] and hashlib.sha256(raw).hexdigest()==row['rawSha256']
  assert len(raw)==row['bytes'] and len(raw.splitlines())==row['lines']
 (out/'outcome.json').write_text(json.dumps({'readyForReview':True,'archives':len(records),'formalSessions':len(sessions),'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
