from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/local-repair-staging');out.mkdir(exist_ok=False)
branch=subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip();assert branch=='issue-1580-8d61a32a61e1'
raw=subprocess.check_output(['git','status','--porcelain','-z','--untracked-files=all'],cwd=root)
paths=[];excluded=[]
for entry in raw.split(b'\0'):
 if not entry:continue
 status=entry[:2].decode();path=entry[3:].decode();assert status in [' M','??'],(status,path)
 if path.startswith('experiments/issue-1580/evidence/ci/integrated-repairs-8d8f1481/'):
  excluded.append(path);continue
 assert not path.startswith('.claude/')
 paths.append(path)
assert paths
result=subprocess.run(['git','add','--',*paths],cwd=root);assert result.returncode==0
(out/'summary.json').write_text(json.dumps({'branch':branch,'paths':paths,'activeCollectorFilesExcluded':len(excluded),'reason':'Stage complete code and static fixtures before gates using the Git inventory; active hosted collection remains open.'},indent=2)+'\n')
print(json.dumps({'staged':len(paths),'activeCollectorFilesExcluded':len(excluded)}))
