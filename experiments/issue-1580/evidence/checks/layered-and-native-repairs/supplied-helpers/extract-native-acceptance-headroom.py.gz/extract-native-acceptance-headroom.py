from pathlib import Path
import hashlib,json,os,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/native-acceptance-headroom')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 assert result.returncode in allowed,(name,result.returncode)
 return result.returncode
groups=[
 ('rust/tests/unit/specification/openai_compatibility','streaming_diagnostics',['streaming_chat_completion_emits_reasoning_content_delta','streaming_responses_emit_reasoning_summary_events','authenticated_routes_accept_bearer_token','authenticated_routes_reject_missing_bearer_token','rate_limit_metadata_is_exposed','responses_api_attaches_trace_link'],'use super::{ApiAuthConfig, ResponsesRequest, create_response, handle_api_request, handle_api_request_with_auth};\n\n'),
 ('rust/tests/unit/specification/external_benchmarks','upstream_records',['upstream_records_are_parsed_into_gradable_cases','a_full_slice_runs_as_offset_shards_that_add_up'],'use super::{Grading, SuiteManifest, external_benchmarks, manifest, read, repo_root};\n\n'),
 ('rust/tests/unit/specification/self_hosting_metric','release_policy',['release_pipeline_and_ledger_remain_pinned_to_the_metric'],'use super::{Path, fs};\n\n'),
 ('rust/tests/unit/specification/text_manipulation','framed_operands',['apostrophes_in_english_prose_do_not_swallow_the_quoted_operands','apostrophe_delimited_operands_are_recognized_in_every_supported_language','chained_operations_run_in_the_order_the_request_states_them','counting_questions_ask_the_seeded_count_of_the_framed_unit','line_prefix_filter_reads_its_argument_and_composes_with_counts','counting_a_seeded_character_class_counts_its_members'],'use super::text_solver;\n\n'),
 ('rust/tests/unit/issue_844_statement_merge','evidence_wording',['the_evidence_wording_comes_from_the_seed_for_every_supported_language'],'use super::{Language, SourceTier, SourcedStatement, deduplicate, many_sources, merge_into_context, rank, to_statements_in};\n\n'),
]
try:
 # A narrow policy regression must observe the actual warning state first.
 test=root/'experiments/issue-1580/native-test-headroom.test.mjs';text=test.read_text();assert 'streaming_diagnostics' not in text
 text+='\nfor (const [owner, child, names] of '+json.dumps([[a,b,c] for a,b,c,_ in groups],ensure_ascii=False,indent=2)+''') {
  test(owner + ' keeps warning-free native acceptance owners and original test names', () => {
    assert.deepEqual(checkListedFiles(root, new Set([owner + '.rs', owner + '/' + child + '.rs'])),
      {warnings: [], violations: [], embeddedDataViolations: []});
    const source = readFileSync(root + '/' + owner + '.rs', 'utf8');
    const extracted = readFileSync(root + '/' + owner + '/' + child + '.rs', 'utf8');
    const declaration = '#[path = "' + owner.split('/').at(-1) + '/' + child + '.rs"]\\nmod ' + child + ';';
    assert(source.includes(declaration), 'the actual parent resolves the extracted module');
    for (const name of names) {
      assert(source.includes('#[test]\\nfn ' + name + '() {\\n    ' + child + '::' + name + '();\\n}'));
      assert(extracted.includes('pub(super) fn ' + name + '() {'));
    }
  });
}
'''
 test.write_text(text)
 before=run('regression-before',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)],(1,))
 rows=[];files=[]
 for owner,child,names,imports in groups:
  p=root/(owner+'.rs');source=p.read_text();baseline=subprocess.check_output(['git','show','HEAD:'+owner+'.rs'],cwd=root,text=True);assert source==baseline
  dest=out/'preimages'/(owner+'.rs');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(source)
  declaration='\n#[path = "'+Path(owner).name+'/'+child+'.rs"]\nmod '+child+';\n'
  # Keep the original public native test names and attributes in their owners.
  modified=source;conserved=[];chunks=[]
  for name in names:
   header='#[test]\nfn '+name+'() {\n';assert modified.count(header)==1
   start=modified.index(header);end=modified.index('\n}\n',start)+3;original=modified[start:end]
   assert not re.search(r'^#\[test\]',original[len(header):],re.M)
   wrapper='#[test]\nfn '+name+'() {\n    '+child+'::'+name+'();\n}\n'
   modified=modified[:start]+wrapper+modified[end:]
   moved=original.replace('#[test]\nfn ','pub(super) fn ',1);chunks.append(moved);conserved.append((original,wrapper,moved))
  # Append after the existing items so no test documentation changes its owner.
  modified+=declaration
  inverse=modified[:-len(declaration)]
  for original,wrapper,moved in conserved:
   assert moved.replace('pub(super) fn ','#[test]\nfn ',1)==original
   assert inverse.count(wrapper)==1;inverse=inverse.replace(wrapper,original,1)
  assert inverse==source
  assert len(modified.splitlines())<=900,(owner,len(modified.splitlines()))
  directory=root/owner;directory.mkdir(exist_ok=True);target=directory/(child+'.rs');assert not target.exists();target.write_text(imports+'\n'.join(chunks));p.write_text(modified)
  assert len(target.read_text().splitlines())<=900
  rows.append({'owner':owner+'.rs','child':str(target.relative_to(root)),'names':names,'beforeLines':len(source.splitlines()),'afterLines':len(modified.splitlines()),'childLines':len(target.read_text().splitlines()),'beforeSha256':hashlib.sha256(source.encode()).hexdigest(),'exactInverse':True,'nativeExecutionVerified':False})
  files.extend([str(p.relative_to(root)),str(target.relative_to(root))])
 (out/'extraction.json').write_text(json.dumps({'files':rows,'before':before,'independentAuthorshipCredit':0},indent=2)+'\n')
 run('rustfmt',['rustfmt','--edition','2024',*files]);run('rustfmt-check',['rustfmt','--check','--edition','2024',*files])
 run('regression-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)])
 run('maintained-observations',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])
 run('source-warnings',['node','--max-old-space-size=256','scripts/check-file-size.mjs'])
 warnings=(out/'source-warnings.stdout').read_text().count('::warning file=');assert warnings==55,warnings
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'warnings':warnings,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
