from pathlib import Path
import json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/specification-carry-admission-repair')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 assert result.returncode in allowed,(name,result.returncode)
 return result.returncode
try:
 test=root/'experiments/issue-1580/procedure-extraction-parity.test.mjs'
 source=test.read_text();assert 'native constant coverage survives' not in source
 source+='''
test('native constant coverage survives extraction into an ordinarily resolved helper module', () => {
  const owner = 'rust/tests/unit/specification/openai_compatibility';
  const inventory = specificationCases(root);
  assert(inventory.cases.some(entry => entry.id === owner + '.rs::canonical_model_id_is_formal_ai'),
    'the previously passing native constant case must remain carried to JavaScript');
  const parent = readFileSync(root + owner + '.rs', 'utf8');
  const registry = readFileSync(root + 'rust/tests/unit/specification/mod.rs', 'utf8');
  assert.match(registry, /^mod openai_compatibility;$/mu);
  assert.match(parent, /^mod streaming_diagnostics;$/mu);
  assert(!parent.includes('#[path = "openai_compatibility/streaming_diagnostics.rs"]'));
  const child = readFileSync(root + owner + '/streaming_diagnostics.rs', 'utf8');
  assert.match(child, /^pub\\(super\\) fn streaming_chat_completion_emits_reasoning_content_delta\\(\\)/mu);
});
'''
 test.write_text(source)
 before=run('regression-before',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)],(1,))
 owner=root/'rust/tests/unit/specification/openai_compatibility.rs';prior=owner.read_text();(out/'owner-before.rs').write_text(prior)
 attribute='#[path = "openai_compatibility/streaming_diagnostics.rs"]\n';assert prior.count(attribute)==1
 owner.write_text(prior.replace(attribute,'',1))
 headroom=root/'experiments/issue-1580/native-test-headroom.test.mjs';original=headroom.read_text()
 old='''    const declaration = '#[path = "' + owner.split('/').at(-1) + '/' + child + '.rs"]\\nmod ' + child + ';';
    assert(source.includes(declaration), 'the actual parent resolves the extracted module');'''
 new='''    const declaration = owner.endsWith('/openai_compatibility')
      ? 'mod ' + child + ';'
      : '#[path = "' + owner.split('/').at(-1) + '/' + child + '.rs"]\\nmod ' + child + ';';
    assert(source.includes(declaration), 'the actual parent resolves the extracted module');'''
 assert original.count(old)==1;headroom.write_text(original.replace(old,new,1))
 run('rustfmt-check',['rustfmt','--check','--edition','2024',str(owner)])
 run('regression-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)])
 run('headroom-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(headroom)])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'priorFailureExit':before,'restoredCase':'rust/tests/unit/specification/openai_compatibility.rs::canonical_model_id_is_formal_ai','originalTestBodyChanged':False,'newIndependentCredit':0,'nativeExecutionVerified':False},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
