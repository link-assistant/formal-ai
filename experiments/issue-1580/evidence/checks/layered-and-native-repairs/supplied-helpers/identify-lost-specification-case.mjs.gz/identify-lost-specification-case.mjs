import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {caseOf,helperOf,specificationCases,testFunctions,tokenize} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/rust-specification-cases.mjs';
import {typedProgramOf} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/rust-specification-programs.mjs';
const root='/tmp/gh-issue-solver-1794900398048';
const directory='/tmp/issue-1580-research/native-acceptance-headroom';
const rows=[];
const current=new Set(specificationCases(root).cases.map(c=>c.id));
for(const item of JSON.parse(readFileSync(directory+'/extraction.json','utf8')).files){
 if(!item.owner.includes('/specification/'))continue;
 const source=readFileSync(directory+'/preimages/'+item.owner,'utf8');
 const helper=helperOf(root,item.owner.split('/specification/')[1],source);
 for(const test of testFunctions(tokenize(source))){
  const legacy=caseOf(test.body,helper);
  const typed=legacy.case?{}:typedProgramOf(test.body,{source,file:join(directory,'preimages',item.owner),root});
  const id=item.owner+'::'+test.name;
  rows.push({id,moved:item.names.includes(test.name),priorCarried:Boolean(legacy.case||typed.program),currentlyCarried:current.has(id),reason:typed.reason,legacyReason:legacy.reason});
 }
}
writeFileSync('/tmp/issue-1580-research/lost-specification-case.json',JSON.stringify(rows,null,2)+'\n');
process.stdout.write(JSON.stringify(rows.filter(row=>row.priorCarried&&!row.currentlyCarried))+'\n');
