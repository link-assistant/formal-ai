from pathlib import Path
import subprocess,sys
scratch=Path('/tmp/issue-1580-research')
source=(scratch/'preserve-local-repair-batch.py').read_text()
source=source.replace("out = scratch / 'local-repair-batch-preservation'","out = scratch / 'corrected-local-repair-batch-preservation'")
source=source.replace("replay = scratch / 'complete-local-repair-replay'","replay = scratch / 'corrected-local-repair-replay'")
source=source.replace('tests 207','tests 208').replace('pass 207','pass 208').replace("'maintainedTestsPassed': 207","'maintainedTestsPassed': 208")
source=source.replace("'local-repair-review', 'local-repair-staging',","'local-repair-review', 'local-repair-staging',\n        'terminal-integrated-repairs-review', 'local-repair-batch-preservation',\n        'specification-carry-admission-repair', 'corrected-local-repair-replay',")
source=source.replace("'stage-complete-local-repair-code.py', 'preserve-local-repair-batch.py',","'stage-complete-local-repair-code.py', 'preserve-local-repair-batch.py',\n        'identify-lost-specification-case.mjs', 'repair-specification-carry-admission.py',\n        'replay-corrected-local-repair-batch.py', 'preserve-corrected-local-repair-batch.py',\n        'review-terminal-integrated-repairs.py',")
source=source.replace('The final maintained owner passes 207 tests.', '''The first complete gate replay finds a real extraction regression: the new
path attribute makes the conservative borrowed-constant caller contract reject
the unchanged canonical model-id case. Remove that unnecessary attribute from
the ordinarily resolved OpenAI owner. A new case-identity and module-resolution
regression fails before repair and passes afterward. All 221 existing carried
specification cases remain; the passing floor is unchanged. The failed complete
gate replay and failed initial preservation attempt remain retained separately.

The final maintained owner passes 208 tests.''')
source=source.replace('Extract five native acceptance bodies into explicitly compiled children.','Extract native acceptance bodies from five owners into compiled children.')
source=source.replace('Published `8d8f1481` includes main `f574289f`. At the 2026-11-21 16:18 UTC\nobservation, 32 workflows exist: 29 succeeded, one skipped, Layered CI failed\nand CI/CD Pipeline is still active. Pipeline already reports a failed native\nsource witness and a cancelled coding family. These terminal job failures and\nall known Layered failures have local repairs; complete terminal-run collection\nand next-head hosted validation remain required before acceptance.', '''Published `8d8f1481` includes main `f574289f`. All 32 workflows are terminal:
29 succeeded, one skipped, Layered CI and CI/CD Pipeline failed. The retained
terminal collection verifies 178 archived command streams by raw hash and bytes.
Pipeline reports a failed native source witness, cancelled coding family and
the resulting failed status aggregator. These terminal job failures and all
known Layered failures have local repairs; next-head hosted validation remains
required before acceptance.''')
source=source.replace('All 207 maintained issue observations pass.','All 208 maintained issue observations pass.')
source=source.replace('The before/fixed cleanup race and\nall failed harness attempts remain retained separately.', 'The before/fixed cleanup race, restored 221-case specification carry inventory\nand failed complete replay remain retained separately.')
source=source.replace("subprocess.run(['git', 'add', 'experiments/issue-1580/evidence/checks/layered-and-native-repairs',", "subprocess.run(['git', 'add', 'experiments/issue-1580/procedure-extraction-parity.test.mjs',\n                    'experiments/issue-1580/native-test-headroom.test.mjs',\n                    'rust/tests/unit/specification/openai_compatibility.rs',\n                    'experiments/issue-1580/evidence/ci/integrated-repairs-8d8f1481',\n                    'experiments/issue-1580/evidence/checks/layered-and-native-repairs',")
assert 'still active' not in source and 'passes 207' not in source
exec(compile(source,__file__,'exec'))
