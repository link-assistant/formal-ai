from pathlib import Path
import subprocess,os,json
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/native-coding-shard-repair')
p=root/'scripts/ci-native-regressions.sh';text=p.read_text()
old='[[ "$name" =~ ^(agentic_general_planner|coding_discovery|observed_plan_tools|tool_workspace)::([[:alnum:]_]+::)*[[:alnum:]_]+$ ]]'
assert text.count(old)==1;p.write_text(text.replace(old,'[[ "$name" =~ ^([[:alnum:]_]+::)+[[:alnum:]_]+$ ]]'))
p=root/'experiments/issue-1580/native-regression-groups.test.mjs';text=p.read_text()
text=text.replace("'coding_discovery::composition::future_case'", "'future_coding_module::future_case'")
text=text.replace("['foreign::case', codingNames[0]]", "['unqualified_foreign_case', codingNames[0]]")
p.write_text(text)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
with (out/'future-module-controls.stdout').open('w') as stdout,(out/'future-module-controls.stderr').open('w') as stderr:
 result=subprocess.run(['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/native-regression-groups.test.mjs'],cwd=root,env=env,stdout=stdout,stderr=stderr)
assert result.returncode==0
(out/'future-module-controls.json').write_text(json.dumps({'complete':True,'newCompiledModuleAdmitted':True,'nativeExecutionVerified':False,'independentAuthorshipCredit':0})+'\n')
