from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/native-coding-shard-repair')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 assert result.returncode in allowed,(name,result.returncode)
def preserve(path):
 target=out/'preimages'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((root/path).read_bytes())
def replace(path,old,new):
 p=root/path;text=p.read_text();assert text.count(old)==1,(path,old,text.count(old));p.write_text(text.replace(old,new))
try:
 evidence=root/'experiments/issue-1580/evidence/checks/native-coding-budget';evidence.mkdir(exist_ok=False)
 observations=[]
 for job,run_id,sha,source,status in [
  (136874234881,44913466632,'fbac28e56a61dc763f264de3f4d74cbc8d4f6cce',Path('/tmp/issue-1580-research/native-coding-headroom-analysis/previous-job.log'),'success'),
  (136890696854,44918895118,'8d8f14810fdab9fa39f0d601f97dbfc43ec78f1a',Path('/tmp/issue-1580-research/active-pipeline-second-observation/failed-job-136890696854.log'),'cancelled')]:
  raw=source.read_bytes();name='job-'+str(job)+'.stdout.gz';(evidence/name).write_bytes(gzip.compress(raw,mtime=0))
  observations.append({'job':job,'run':run_id,'source':sha,'conclusion':status,'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
 (evidence/'identity.json').write_text(json.dumps({'observations':observations,'noUnfinishedCaseBounds':True,'nativeExecutionVerifiedAfterRepair':False},indent=2)+'\n')
 derive=root/'experiments/issue-1580/derive-native-coding-durations.py';assert not derive.exists()
 derive.write_text('''#!/usr/bin/env python3
"""Retain the largest completed sequential coding observation from each source."""
import argparse
from datetime import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / 'experiments/issue-1580/evidence/checks/native-coding-budget'
OUTPUT = ROOT / 'scripts/ci-native-coding-durations.lino'


def measured_text():
    identity = json.loads((EVIDENCE / 'identity.json').read_text())
    durations = {}
    for observation in identity['observations']:
        raw = gzip.decompress((EVIDENCE / observation['file']).read_bytes())
        assert hashlib.sha256(raw).hexdigest() == observation['rawSha256']
        previous = None
        completed = 0
        summary = None
        for line in raw.decode().splitlines():
            timestamp, _, message = line.lstrip('\\ufeff').partition(' ')
            if not timestamp.endswith('Z'):
                continue
            now = datetime.fromisoformat(timestamp)
            if re.fullmatch(r'running 62 tests', message):
                previous = now
            match = re.fullmatch(r'test ([A-Za-z0-9_:]+) \\.{3} ok', message)
            if match:
                assert previous is not None
                seconds = max((now - previous).total_seconds(), 0.001)
                durations[match[1]] = max(durations.get(match[1], 0), seconds)
                completed += 1
                previous = now
            if message.startswith('test result:'):
                summary = message
        if observation['conclusion'] == 'success':
            assert completed == 62 and summary.startswith('test result: ok. 62 passed; 0 failed; 0 ignored;')
        else:
            assert observation['conclusion'] == 'cancelled' and completed == 58 and summary is None
    assert len(durations) == 62
    rows = ['test_durations', '  recorded 2026-11-21', '  unit seconds', '  default-seconds 60',
            '  purpose "Largest completed coding observations; no duration assigned to unfinished cases."',
            '  regenerate "python3 experiments/issue-1580/derive-native-coding-durations.py --write"']
    for observation in identity['observations']:
        rows.append('  source_job ' + str(observation['job']))
    for name, seconds in sorted(durations.items(), key=lambda row: (-row[1], row[0])):
        rows.extend([f'  test "{name}"', f'    seconds {seconds:.3f}'])
    return '\\n'.join(rows) + '\\n'


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--write', action='store_true')
    mode.add_argument('--check', action='store_true')
    options = parser.parse_args()
    text = measured_text()
    if options.write:
        OUTPUT.write_text(text)
    elif options.check:
        assert OUTPUT.read_text() == text, 'hosted coding duration projection is stale'
    else:
        print(text, end='')
''')
 run('derive-coding-durations',['python3',str(derive),'--write'])
 tests='experiments/issue-1580/native-regression-groups.test.mjs';preserve(tests)
 replace(tests,"  'reasoning-1': ['reasoning_contracts'], 'reasoning-2': ['reasoning_contracts'],", "  'coding-1': ['coding_contracts'], 'coding-2': ['coding_contracts'],\n  'reasoning-1': ['reasoning_contracts'], 'reasoning-2': ['reasoning_contracts'],")
 replace(tests,"!name.startsWith('hive-') && !name.startsWith('reasoning-')", "!name.startsWith('hive-') && !name.startsWith('reasoning-') && !name.startsWith('coding-')")
 replace(tests,"!['core', 'hive', 'reasoning'].includes(group)", "!['core', 'hive', 'reasoning', 'coding'].includes(group)")
 # Reuse the actual Cargo stub and deployed planner checks.
 with (root/tests).open('a') as stream:stream.write(r'''
const codingNames = [...readFileSync('scripts/ci-native-coding-durations.lino', 'utf8')
  .matchAll(/^  test "([^"]+)"$/gmu)].map(match => match[1]);
function executedCodingShard(observed) {
  assert.equal(observed.result.status, 0, observed.result.stderr);
  assert.equal(observed.invocations.length, 2);
  const [list, run] = observed.invocations;
  assert.deepEqual(list.slice(-5), ['--test', 'coding_contracts', '--', '--list', '--format', 'terse'].slice(-5));
  assert.equal(list[list.indexOf('--test') + 1], 'coding_contracts');
  assert.deepEqual(run.slice(0, 9), ['test', '--manifest-path', 'rust/Cargo.toml', '--locked',
    '--no-fail-fast', '--test', 'coding_contracts', '--', '--exact']);
  assert.deepEqual(run.slice(-2), ['--test-threads=1', '--nocapture']);
  const names = run.slice(9, -2); assert(names.length > 0);
  return names;
}
test('coding shards cover all 62 observed names and an unseen compiled case exactly once', {timeout: 15000}, () => {
  const names = [...codingNames, 'coding_discovery::composition::future_case'];
  const actual = [1, 2].flatMap(index => executedCodingShard(observe(['coding-' + index], 0, {names})));
  assert.deepEqual(actual.toSorted(), names.toSorted());
  assert.equal(new Set(actual).size, actual.length);
  const weights = parseTestDurations(readFileSync('scripts/ci-native-coding-durations.lino', 'utf8'));
  const {shards, load} = planShards(names, 2, durationLookup(weights, 60));
  assert.deepEqual(partitionProblems(names, shards), {missing: [], repeated: [], extra: []});
  assert(Math.max(...load) < 450, 'retained coding costs leave compile headroom in the existing job');
});
test('coding shard selection remains deterministic under reordered compiled names', {timeout: 15000}, () => {
  for (const index of [1, 2]) assert.deepEqual(
    executedCodingShard(observe(['coding-' + index], 0, {names: codingNames})),
    executedCodingShard(observe(['coding-' + index], 0, {names: [...codingNames].reverse()})));
});
for (const index of [1, 2]) test('coding shard ' + index + ' propagates listing and execution failures', {timeout: 15000}, () => {
  const listed = observe(['coding-' + index], 0, {names: codingNames, listStatus: 19});
  assert.equal(listed.result.status, 19); assert.equal(listed.invocations.length, 1);
  const executed = observe(['coding-' + index], 17, {names: codingNames});
  assert.equal(executed.result.status, 17); assert.equal(executed.invocations.length, 2);
});
for (const names of [[], [codingNames[0]], [codingNames[0], codingNames[0]],
  ['foreign::case', codingNames[0]], ['invalid name', codingNames[0]]]) {
  test('coding rejects incomplete or foreign listings: ' + JSON.stringify(names), {timeout: 15000}, () => {
    const observed = observe(['coding-2'], 0, {names});
    assert.notEqual(observed.result.status, 0);
    assert.equal(observed.invocations.length, 1);
  });
}
test('coding weights reproduce complete observations while retaining unfinished-case uncertainty', {timeout: 15000}, () => {
  const result = spawnSync('python3', ['experiments/issue-1580/derive-native-coding-durations.py', '--check'],
    {encoding: 'utf8', timeout: 10000, maxBuffer: 65536});
  assert.equal(result.status, 0, result.stderr);
  assert.equal(admission(['scripts/ci-native-coding-durations.lino'])['native-type-check'], true);
});
''')
 run('coding-regressions-before',['node','--max-old-space-size=256','--test','--test-concurrency=1','--test-name-pattern','coding shard|coding rejects|coding weights',tests],(1,))
 runner='scripts/ci-native-regressions.sh';preserve(runner)
 p=root/runner;text=p.read_text().replace('all|core|coding|reasoning|','all|core|coding|coding-1|coding-2|reasoning|')
 text=text.replace('  hive-1|hive-2|hive-3|reasoning-1|reasoning-2)', '  hive-1|hive-2|hive-3|reasoning-1|reasoning-2|coding-1|coding-2)')
 text=text.replace('    if [[ "$family" == hive ]]; then\n      shard_count=3', '    target=reasoning_contracts\n    if [[ "$family" == coding ]]; then\n      target=coding_contracts\n      shard_count=2\n      listing="$(cargo test --manifest-path rust/Cargo.toml --locked --no-fail-fast \\\n        --test "$target" -- --list --format terse)"\n    elif [[ "$family" == hive ]]; then\n      shard_count=3',1)
 text=text.replace('      elif [[ "$name" =~', '      elif [[ "$family" == coding ]]; then\n        [[ "$name" =~ ^(agentic_general_planner|coding_discovery|observed_plan_tools|tool_workspace)::([[:alnum:]_]+::)*[[:alnum:]_]+$ ]] && valid=true\n      elif [[ "$name" =~',1)
 old='cargo test --manifest-path rust/Cargo.toml --locked --no-fail-fast --test reasoning_contracts \\\n      -- --exact';assert text.count(old)==1;text=text.replace(old,'cargo test --manifest-path rust/Cargo.toml --locked --no-fail-fast --test "$target" \\\n      -- --exact')
 p.write_text(text)
 workflow='.github/workflows/native-type-check.yml';preserve(workflow)
 replace(workflow,'group: [coding, reasoning-1, reasoning-2, benchmarks, interfaces, hive-1, hive-2, hive-3]','group: [coding-1, coding-2, reasoning-1, reasoning-2, benchmarks, interfaces, hive-1, hive-2, hive-3]')
 p=root/workflow;text=p.read_text().replace('# Run 44648187857 compiled successfully, then spent 637 seconds on coding\n  # alone. Separate families keep coverage within the existing 20-minute clock.', '# Run 44918895118 exhausted the coding clock after 58/62 passing tests.\n  # Partition the live listing while preserving the existing 20-minute clock.');p.write_text(text)
 admission='scripts/ci-pull-request-admission.mjs';preserve(admission)
 replace(admission,"  'scripts/ci-native-reasoning-durations.lino',", "  'scripts/ci-native-reasoning-durations.lino',\n  'scripts/ci-native-coding-durations.lino',")
 workflow='.github/workflows/layered-ci.yml';preserve(workflow)
 needle='            /experiments/issue-1580/evidence/checks/native-reasoning-budget/job-136423862321.stdout.gz'
 replace(workflow,needle,needle+'\n            /experiments/issue-1580/evidence/checks/native-coding-budget/*.stdout.gz')
 profile='rust/tests/web/fast-pull-request-production-profile.test.mjs';preserve(profile)
 needle='/experiments/issue-1580/evidence/checks/native-reasoning-budget/job-136423862321.stdout.gz\\n'
 replace(profile,needle,needle+'/experiments/issue-1580/evidence/checks/native-coding-budget/*.stdout.gz\\n')
 # Verify acquisition before the reproducer reads its real gzip observations.
 p=root/tests;text=p.read_text();needle="  const currentHiveEvidence = [136489959548, 136489959657, 136489959672]"
 assert text.count(needle)==1;text=text.replace(needle,"  const codingEvidence = [136874234881, 136890696854].map(job =>\n    'experiments/issue-1580/evidence/checks/native-coding-budget/job-' + job + '.stdout.gz');\n"+needle)
 text=text.replace('for (const path of [evidence, ...currentHiveEvidence, reasoningEvidence,', 'for (const path of [evidence, ...currentHiveEvidence, ...codingEvidence, reasoningEvidence,\n      \'experiments/issue-1580/evidence/checks/native-coding-budget/identity.json\',\n      \'scripts/ci-native-coding-durations.lino\', \'experiments/issue-1580/derive-native-coding-durations.py\',')
 text=text.replace('for (const path of [evidence, ...currentHiveEvidence])', 'for (const path of [evidence, ...currentHiveEvidence, ...codingEvidence])')
 text=text.replace("    run('python3', ['experiments/issue-1580/derive-native-reasoning-durations.py', '--check']);", "    run('python3', ['experiments/issue-1580/derive-native-reasoning-durations.py', '--check']);\n    run('python3', ['experiments/issue-1580/derive-native-coding-durations.py', '--check']);")
 p.write_text(text)
 run('runner-syntax',['bash','-n',runner])
 run('native-groups-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',tests])
 run('deployed-profile-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',profile])
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'nativeExecutionVerifiedAfterRepair':False,'nativeJobClockMinutes':20,'maxParallel':2,'codingShards':2,'completePreviousCases':62,'completeCurrentCases':58,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
