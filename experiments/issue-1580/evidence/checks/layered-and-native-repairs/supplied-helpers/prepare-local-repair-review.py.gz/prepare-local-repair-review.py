from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/local-repair-review');out.mkdir(exist_ok=False)
with (out/'tracked.diff').open('w') as stdout:
 result=subprocess.run(['git','diff','--no-ext-diff','--no-color'],cwd=root,stdout=stdout)
assert result.returncode==0
lines=(out/'tracked.diff').read_text().splitlines(keepends=True)
for index in range(0,len(lines),250):(out/('tracked-page-'+str(index//250+1).zfill(2)+'.diff')).write_text(''.join(lines[index:index+250]))
directories=['layered-8d8-diagnosis','layered-fixture-and-projection-repair','layered-duration-refresh-analysis','layered-duration-and-queue-repair','native-capability-witness-repair','native-acceptance-headroom','monitor-failure-termination-repair','native-coding-headroom-analysis','native-coding-shard-repair','native-family-execution-budget','local-repair-feedback-refresh','active-pipeline-second-observation','active-native-failure-raw']
summary=[]
for name in directories:
 files=[path for path in (out.parent/name).rglob('*') if path.is_file()]
 summary.append({'directory':name,'files':len(files),'bytes':sum(path.stat().st_size for path in files)})
(out/'summary.json').write_text(json.dumps({'trackedDiffLines':len(lines),'pages':(len(lines)+249)//250,'directories':summary},indent=2)+'\n')
print(json.dumps({'trackedDiffLines':len(lines),'pages':(len(lines)+249)//250,'directories':summary}))
