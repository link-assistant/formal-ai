from pathlib import Path
import gzip, hashlib, json, re, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/ci/integrated-repairs-8d8f1481'
out = Path('/tmp/issue-1580-research/terminal-integrated-repairs-review')
out.mkdir(exist_ok=False)
records = json.loads((base / 'records.json').read_text())
for record in records:
    for stream in ['stdout', 'stderr']:
        identity = record[stream]
        packed = (base / identity['file']).read_bytes()
        assert hashlib.sha256(packed).hexdigest() == identity['archiveSha256']
        raw = gzip.decompress(packed)
        assert hashlib.sha256(raw).hexdigest() == identity['rawSha256']
        assert len(raw) == identity['bytes']
jobs = [json.loads(line) for line in gzip.decompress((base / 'jobs-44918895118.stdout.gz').read_bytes()).splitlines()]
(out / 'jobs.jsonl').write_text(''.join(json.dumps({key: row.get(key) for key in ['id','name','status','conclusion','started_at','completed_at','html_url']}) + '\n' for row in jobs))
summary = []
for source in sorted(base.glob('failed-job-*.stdout.gz')):
    lines = gzip.decompress(source.read_bytes()).decode().splitlines()
    selected = set()
    for index, line in enumerate(lines):
        if re.search(r'::error|::warning|AssertionError|panicked at|FAILED|test result: FAILED|not ok |command was terminated|operation was canceled|Required checks failed', line, re.I):
            selected.update(range(max(0, index-3), min(len(lines), index+8)))
    if len(lines) < 150:
        selected.update(range(len(lines)))
    else:
        selected.update(range(max(0,len(lines)-15),len(lines)))
    review = [f'{index+1}: {lines[index]}' for index in sorted(selected)]
    (out / (source.stem + '.review.txt')).write_text('\n'.join(review) + '\n')
    summary.append({'file':source.name,'lines':len(lines),'reviewLines':len(review)})
(out / 'summary.json').write_text(json.dumps({'archivesVerified':len(records),'failedStreams':summary},indent=2)+'\n')
with (out / 'main-fetch.log').open('w') as stream:
    subprocess.run(['git','fetch','origin','main'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,check=True)
main = subprocess.check_output(['git','rev-parse','origin/main'],cwd=root,text=True).strip()
ancestor = subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],cwd=root).returncode
(out / 'main.json').write_text(json.dumps({'main':main,'mainIsAncestor':ancestor==0})+'\n')
print(json.dumps({'archivesVerified':len(records),'failedStreams':summary,'main':main,'mainIsAncestor':ancestor==0}))
