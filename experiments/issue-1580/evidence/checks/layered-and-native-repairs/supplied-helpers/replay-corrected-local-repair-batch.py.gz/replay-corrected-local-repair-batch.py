from pathlib import Path
import json,os,re,subprocess,sys,time,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/corrected-local-repair-replay')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);env.pop('CI',None)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 assert result.returncode==0,(name,result.returncode)
try:
 repair=Path('/tmp/issue-1580-research/specification-carry-admission-repair')
 for attempt in range(180):
  assert not (repair/'failed.txt').exists()
  if (repair/'outcome.json').exists():break
  time.sleep(1)
 assert json.loads((repair/'outcome.json').read_text())['complete']
 run('maintained-observations',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])
 observed=(out/'maintained-observations.stdout').read_text()
 assert re.search(r'^ℹ tests 208$',observed,re.M) and re.search(r'^ℹ pass 208$',observed,re.M)
 run('source-warnings',['node','--max-old-space-size=256','scripts/check-file-size.mjs'])
 warnings=(out/'source-warnings.stdout').read_text().count('::warning file=');assert warnings==55,warnings
 run('all-local-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs'])
 run('whitespace',['git','diff','--check']);run('staged-whitespace',['git','diff','--cached','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'maintainedTestsPassed':208,'warnings':warnings,'nativeExecutionVerified':False,'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
