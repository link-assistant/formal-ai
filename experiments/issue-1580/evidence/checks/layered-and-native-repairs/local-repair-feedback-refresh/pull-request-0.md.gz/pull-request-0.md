{
  "title": "fix: repair complete CI coverage and preserve failure evidence",
  "url": "https://github.com/link-assistant/formal-ai/pull/1581",
  "updatedAt": "2026-11-21T15:22:54Z"
}
CI could omit native regression inputs, accept failed or incomplete observations, and lose task or source ownership. This draft repairs those boundaries and adds reproducing tests. Issue #1580 remains unfinished; keep this PR draft and unmerged.

Fixes #1580

Changes:

- Require complete native input admission and independently scheduled coding, reasoning, Hive, benchmark and interface families. Preserve every original target, single test threads, failure propagation and existing twenty-minute clocks. Replay captured HTTP, localized-language, source-binding, release and workflow regressions through their maintained native targets.
- Propagate failed Git inventories, fetches, child processes, fragment reads/cleanup and Actions output writes. Validate package identity and immutable base metadata before release decisions. Preserve existing fragment files on collisions and symlinks, and retain uncertainty for unavailable registry observations.
- Repair process-group deadline ownership after the parent exits, including termination acknowledgement and partial-line diagnostics. Preserve command status and warning-only behavior; unavailable inspection remains explicit.
- Preserve quoted tasks, request-local constraints, selected-child provenance and current owned-source definitions. Retain multilingual reasoning, calendar, retrieval, typed composition and unresolved-answer behavior. Official writers regenerate the maintained projections.
- Bind CodeQL to verified source, compiler and Cargo contexts; reject incomplete or unsuccessful reports. Retain the original SARIF, included-string and macro-context observations. Bound diagnostic queries without suppressing retained extraction failures or changing their deadlines.
- Pin BuildKit to a verified immutable multi-platform digest, retry the actual setup action through its mirror, and exercise an actual daemon with a deliberate canonical-outage control. Preserve explicit overrides, cleanup and image identity.
- Migrate 97 artifact consumers across 19 workflows to strict-digest raw transport and validated streaming extraction. Retry observed transient lookup failures while preserving selection, permissions and terminal failure propagation.
- Bind Pages retry adoption to repository, source SHA and immutable upload artifact identity. Permit trusted-main Pages generation after validated release checks when package publication fails; preserve successful release-child identity. Retain malformed concurrency and pipeline-result negative controls.
- Adopt built-in Secretlint 14 with actual positive/negative controls. Reduce source-size warnings through unchanged helper extractions and exact inverse checks, retaining the original limits. Upgrade web-capture and remove only its obsolete audit exception.
- Merge current main's dynamic meta feature while retaining the existing native matrix. Admit its actual JavaScript host, worker and frozen dependency inputs; preserve recursive sparse checkout in both attempts. Remove the obsolete fast-inventory count cap that rejected the valid 257th suite, retaining valid existing paths, uniqueness, measured shards and execution deadlines.
- Run the identical complete 903-file default JavaScript suite for PRs, feature-branch check dispatches and main. Preserve eight measured shards, the 360-second execution budget, 75% warnings and continued failure reporting. Keep the fast inventory as a local tool and remove hosted FAST_PR_PROFILE skips.
- Extract native helpers and fixtures under the unchanged source limits. Register complete planner, budget, image and release owners in the hosted targets. Restore all 221 carried procedure specification cases after the full gate run caught an unpushed wrapper extraction regression; retain original native test identities and documentation exceptions.

Verification and limits:

- Published fbac28e5 completed all 26 workflows: 22 succeeded, one was skipped, and three failed. All eight native contract families and registry checks passed. Complete workflow and failed-job streams are retained. Coverage, Layered CI and Pipeline change detection hit the same Git stdout limit; the other Pipeline failure is a coverage observer omitting a helper already compiled into two native test owners. This batch repairs both causes. New-head hosted qualification remains pending.
- Read the complete NUL-delimited Git change inventory from a temporary spool, preserving chunked Unicode decoding, complete termination and Git failure status. A finite real Git fixture with more than 4 MiB of paths reproduces the old failure and verifies every changed path, including the final Rust input.
- Restrict cancellation to repeated pull-request synchronize events and keep manual, ready-for-review and push runs independent. Verify all 75 actual check scopes and preserve unrelated workflow fields and deployed release projection identity.
- Adapt the Go template's bounded recovery of explicitly confirmed unacquired runners. Inspect complete job and annotation pages, validate trusted default-branch source and current run identity, refuse ordinary code failures, and stop after three attempts. Mocked command/API regressions pass; real hosted recovery is available only after this workflow reaches the default branch.
- Preserve exact non-whitespace JSON tokens while compacting short primitive leaves, test the feasibility producer's formatting round trip, and retain complete fixture preimages. Existing fixture suites and all five new regression cases pass.
- Repair all twelve extracted helper module paths, with a failing-before path-resolution fixture, fifteen passing headroom cases and unchanged native assertion bodies.
- Isolate offline fixture source caches; prove polluted caller-cache replay, clean shipped-baseline execution and caller restoration with a real cache regression. Existing CI deadlines stay unchanged.
- Update stale release, TypeScript and notation assertions with negative controls. Preserve all response records and the exact ordered runtime/bootstrap body while splitting the primary response seed.
- Merge main 665795fe and its v0.356.0 release f574289f, preserving the new Codex reporting replay and release admission. Require successful native lint and Bun for the added replay. Reuse the existing explicit-query parser directly at the sole protocol-policy caller, preserving behavior without raising handler ceilings.
- Local validation: a fresh complete 141-gate run against released main has 88 passes, 53 explicit hosted-only skips and zero failures. Earlier integration failures and successful retries remain retained. All 191 maintained issue cases, Unicode controls and focused affected checks pass. Complete witness equality permits only four reviewed Cargo fixture hashes, retaining 221 cases and 968 unsupported items. No local native build was run.
- Current source-size warnings: 60, under unchanged limits. The complete 903-file JavaScript suite and native compilation/execution must still pass on the newly published head. Full template/practice and original issue acceptance remain open; this PR remains draft and unmerged.

The actual CodeQL producer run 44879033589 retains both original standard
SARIF reports, 2,180 included-string rows and 122,579 macro-context rows.
Complete child-macro semantic qualification, main-only/live acceptance,
original workflow qualification and remaining dependency observations stay
open. Independent Formal AI reasoning remains 0/20 and the independent
authorship acceptance floor is unmet; supplied work receives no credit.

The [latest release integration checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/release-main-integration-checkpoint.md),
[CI repair checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/terminal-ci-repair-checkpoint.md),
[work plan](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/experiments/issue-1580/work-plan.md)
and [case study](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/README.md)
retain the complete requirement/evidence mapping and dated head scopes.

Upstream reproductions:

- Rust runner-loss annotations can miss failures beyond the first API page: [Rust #257](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/257). Six finite before/candidate cases reproduce the pagination boundary, ordinary code failure and no-failure controls; no upstream repair is claimed.
- Current Rust timeout documentation drift: [Rust #256](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/256). The source-pin regression also repairs our invalid 41-character ledger identifier after verifying the actual commit/tree and all twelve changed-file Git blobs.
- Current PHP finite pipe deadlock and literal-zero loss: [PHP #33](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/33); missing version evidence: [PHP #31](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/31); malformed UTF-8 release notes: [PHP #32](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/32).
- Current Python fragment data loss: [Python #165](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/165); JavaScript production-helper changes bypass release outputs: [Python #166](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/166).
- Malformed pipeline-result observations: [Go #23](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/23), [C++ #39](https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/issues/39).
- Cross-artifact Pages adoption: [JavaScript #310](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/issues/310), [Python #163](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/163).
- Project-version and checksum observations: [Java #32](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/32), [Rust #213](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/213), [Rust #251](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/251). Fragment overwrite/symlink source observation: [Rust #254](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/254); template CLI execution remains unverified.

Reports and disposable candidates establish no upstream repair. Complete template/practice acceptance remains open.

The [current readable JSON and terminal CI checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/readable-json-headroom-checkpoint.md) records the latest complete local gate replay and exact hosted failure locations. GitHub's PR diff endpoint returns HTTP 406 because this PR exceeds 300 files; the failure is preserved, and local Git source diffs remain available. Complete whole-PR review is still unfinished.

Focused reproduction (run each file separately):

```sh
node --test --test-concurrency=1 experiments/issue-1580/large-change-admission.test.mjs
node --test --test-concurrency=1 experiments/issue-1580/runner-acquisition-recovery.test.mjs
node --test --test-concurrency=1 experiments/issue-1580/readable-json-headroom.test.mjs
node --test --test-concurrency=1 experiments/issue-1580/workflow-concurrency.test.mjs
node --test --test-concurrency=1 experiments/issue-1580/full-default-javascript-profile.test.mjs
node --test --test-concurrency=1 experiments/issue-1580/procedure-extraction-parity.test.mjs
node --test --test-concurrency=1 experiments/issue-1580/native-test-headroom.test.mjs
node --test --test-concurrency=1 experiments/issue-1580/native-checkout-retry.test.mjs
node --test --test-concurrency=1 experiments/issue-1580/fast-inventory-boundary.test.mjs
node --test --test-concurrency=1 rust/tests/web/default-branch-build-policy.test.mjs
node --test --test-concurrency=1 rust/tests/web/issue-1580-template-observations.test.mjs
node --test --test-concurrency=1 rust/tests/web/native-test-artifact.test.mjs
node --test --test-concurrency=1 experiments/issue-1580/pages-release-failure.test.mjs
node --test --test-concurrency=1 rust/tests/web/security-codeql-results.test.mjs
node scripts/check-workflow-concurrency.mjs
node scripts/generate-staged-release.mjs --check-deployed
node experiments/formal_ai_subagent/local-gates.mjs
```

The hosted registry job runs the actual release helper and both CLIs against local HTTP fixtures, plus the original assembler, ordered-list and self-hosting Rust script suites. No registry publication is performed by that job.

Earlier browser source-binding evidence uses the labeled production-worker harness with external requests blocked:

![Before: Spanish definition frame skipped](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/screenshots/issue-1580/meaning-hydration-before.png?raw=true)

![After: definition routes to search and the unresolved sibling remains intact](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/screenshots/issue-1580/meaning-hydration-after.png?raw=true)

