{
  "html_url": "https://github.com/link-assistant/formal-ai/pull/1581#issuecomment-6909598996",
  "url": "https://api.github.com/repos/link-assistant/formal-ai/issues/comments/6909598996",
  "created_at": "2026-11-16T06:53:03Z",
  "updated_at": "2026-11-16T06:53:03Z"
}
<!-- hive-mind:session-kill-notice -->
## ⚠️ Container OOM event during a failed work session

container OOM event — a process in the task cgroup was killed earlier; the session-end memory reading was 7.8 GB of 11.7 GB RAM available (33.6% used) at 2026-11-16T06:51:14.913Z

- **Exit code:** 1
- **OOM event observed at:** 2026-11-16T06:11:38.998Z
- **Working session:** `95ecf303-1875-4592-8ecd-85cb131bb081`
- **On-kill policy:** `resume` (`--on-session-kill=resume`)

<details><summary>Kill diagnostics</summary>

- last session memory reading — 7.8 GB of 11.7 GB RAM available (33.6% used) at 2026-11-16T06:51:14.913Z (phase `solve_exit`)
- last session V8 heap reading — 52 MB used of 1.6 GB limit (3.3%) at 2026-11-16T06:51:14.913Z (phase `solve_exit`)
- last session disk /: 102.2 GB free of 192.7 GB (47.0% used) at 2026-11-16T06:51:14.913Z (phase `solve_exit`)
- lowest host disk /tmp/start-command/logs/isolation/docker: 94.2 GB free of 192.7 GB (51.1% used) at 2026-11-16T06:14:12.578Z observed by the monitor while the session ran
- last session container cgroup reading — 2.4 GB used, 2.9 GB limit, peak 2.9 GB, 7 process(es) killed by the OOM killer, memory.events oom=7 at 2026-11-16T06:51:14.913Z (phase `solve_exit`)
- start-command watcher container cgroup reading — 2.9 GB limit, peak 2.9 GB, 7 process(es) killed by the OOM killer, memory.events oom=7
- container reports `State.OOMKilled = true` (an OOM event hit the container cgroup)
- host memory now — 8.2 GB of 11.7 GB RAM available (29.6% used)
- `/proc/pressure/memory`: some avg10=0.00 avg60=0.00 avg300=0.07 total=2930139473

</details>

The work process survived the container OOM event but later exited with a failure. No replacement session was launched.

📎 The intermediate working-session log was uploaded as a separate comment.

<sub>Reported by Hive Mind</sub>
