#!/usr/bin/env bash
# Run a command under an execution budget that expires before the job clock.
#
# GitHub reports a job killed by `timeout-minutes` as **cancelled**, not
# **failed** (issue #977), so a step that is allowed to run until the runner
# kills it converts a real, actionable timeout into a benign-looking
# cancellation. Issue #1017 is that exact regression: `macOS core slice 10/12`
# spent 133s on checkout/toolchain/artifact setup and was killed 467s into a
# test step whose 480s budget could therefore never expire first, so the whole
# `CI/CD Pipeline` run reported `cancelled` and no release was published.
#
# This wrapper owns the deadline instead of the runner: it warns while the
# command can still be acted on and -- unless enforcement is explicitly
# disabled -- terminates the command at the budget and exits 124, so the job
# reports `failure` with an ::error annotation naming the budget it blew.
#
# Usage: run-with-budget-warning.sh <budget-seconds> <label> <command> [args...]
#
# Environment:
#   TEST_WARN_RATIO_PERCENT    warn once this share of the budget is spent (70)
#   TEST_BUDGET_ENFORCE        `false` warns only and never terminates (true)
#   TEST_BUDGET_GRACE_SECONDS  SIGTERM -> SIGKILL grace period (15)
#   TEST_BUDGET_POLL_SECONDS   deadline polling interval (1)
#   FORMAL_AI_CI_VERBOSE       `true` prints periodic progress lines (false)
#
# After the command finishes -- whatever its outcome -- the compiler cache's
# write-rejection rate is checked once (issue #1081, D9). That check is silent
# unless the rate crosses its threshold, so a healthy step stays exactly as
# quiet as it was before.
set -euo pipefail

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

budget_seconds="${1:?budget seconds are required}"
label="${2:?a warning label is required}"
shift 2
[ "$#" -gt 0 ] || {
  echo "a command is required" >&2
  exit 2
}

warn_ratio="${TEST_WARN_RATIO_PERCENT:-70}"
enforce="${TEST_BUDGET_ENFORCE:-true}"
grace_seconds="${TEST_BUDGET_GRACE_SECONDS:-15}"
poll_seconds="${TEST_BUDGET_POLL_SECONDS:-1}"
verbose="${FORMAL_AI_CI_VERBOSE:-false}"
heartbeat_seconds="${TEST_BUDGET_HEARTBEAT_SECONDS:-60}"

threshold=$((budget_seconds * warn_ratio / 100))
[ "$threshold" -gt 0 ] || threshold=1
started=$SECONDS

# Job control gives the command its own process group, so the whole process
# tree can be signalled at the deadline instead of only its root.
set -m
"$@" &
command_pid=$!
set +m

# A budgeted Rust step that runs long has two causes with the same shape in the
# log -- work that grew, and a compiler cache that stopped answering -- and
# nothing printed so far tells them apart. Issue #1021 hit exactly that:
# `Test (macos-15-intel / specification)` blew its 1200s budget still compiling
# dependencies, and deciding whether the runner was slow or the cache was cold
# took reconstructing per-crate rustc timestamps out of a megabyte of log
# (`experiments/issue_1021_compile_rate_compare.py`). sccache already counts
# the answer. It is printed when the budget is in trouble and never otherwise,
# so a healthy run stays quiet and a red one arrives with its own diagnosis.
report_compiler_cache() {
  case "${RUSTC_WRAPPER:-}" in
    *sccache*) ;;
    *) return 0 ;;
  esac
  local sccache="${SCCACHE_PATH:-}"
  [ -n "$sccache" ] || sccache="$(command -v sccache 2> /dev/null || true)"
  [ -n "$sccache" ] || return 0
  echo "[budget] compiler cache counters for ${label}:" >&2
  # Never fatal: this is a diagnostic, and `set -e` is in force. A wrapper that
  # died reporting why a step was slow would replace the finding with a worse
  # one.
  "$sccache" --show-stats 2>&1 | sed 's/^/[budget] /' >&2 || true
}

# Issue #1081 (D9): the counter that says how much of the compilation this step
# just did will actually be there for the next one. `Cache write errors` is
# printed by --show-stats above, but only when the budget is already in trouble,
# and nothing has ever compared it to a threshold -- so a run whose cache
# accepted half of what it was offered looked identical to a healthy one. Run
# 34095902681 refused 868 of 1711 writes (50.7%) across eight jobs with no
# annotation anywhere. This runs on every budgeted step and is silent unless the
# share crosses SCCACHE_WRITE_ERROR_WARN_PERCENT, and it can never fail the
# step: it is a diagnostic, and `set -e` is in force.
report_compiler_cache_write_health() {
  case "${RUSTC_WRAPPER:-}" in
    *sccache*) ;;
    *) return 0 ;;
  esac
  local checker="${script_dir}/check-sccache-write-health.sh"
  [ -x "$checker" ] || return 0
  SCCACHE_HEALTH_LABEL="${label}" "$checker" || true
}

signal_command_tree() {
  local signal="$1"
  kill "-$signal" "-$command_pid" 2> /dev/null ||
    kill "-$signal" "$command_pid" 2> /dev/null ||
    true
}

# The root may finish while a child still owns the output pipe or does work.
# Keep the deadline until every live process in its group has finished. Zombies
# have already exited and cannot hold a pipe open; do not wait for their reaper.
command_is_running() {
  kill -0 "$command_pid" 2> /dev/null && return 0
  local processes
  if ! processes="$(ps -eo pgid=,stat=)"; then
    printf '\n%s\n' "::error title=Execution budget monitoring failed::Cannot inspect the process group for ${label}." >&2
    signal_command_tree KILL
    exit 125
  fi
  awk -v group="$command_pid" '
    $1 == group && $2 !~ /^[ZX]/ { alive = 1 }
    END { exit !alive }
  ' <<< "$processes"
}

# shellcheck disable=SC2329  # invoked indirectly by the trap below
forward_cancellation() {
  signal_command_tree TERM
}
trap forward_cancellation INT TERM

warned=false
terminated=false
last_heartbeat=0

while command_is_running; do
  elapsed=$((SECONDS - started))

  if [ "$warned" = false ] && [ "$elapsed" -ge "$threshold" ]; then
    warned=true
    printf '\n%s\n' "::warning title=${label} is approaching its timeout::The command is still running after ${elapsed}s (${warn_ratio}% of its ${budget_seconds}s execution budget). Speed up or repartition it before the budget terminates the step." >&2
    report_compiler_cache
  fi

  if [ "$verbose" = true ] &&
    [ $((elapsed - last_heartbeat)) -ge "$heartbeat_seconds" ]; then
    last_heartbeat="$elapsed"
    echo "[budget] ${label} has been running for ${elapsed}s of its ${budget_seconds}s budget." >&2
  fi

  # SECONDS counts wall-clock boundaries and may read almost one second high.
  # A strictly greater reading proves the full positive interval has passed;
  # warnings may still be early, and a zero budget remains immediate.
  if [ "$enforce" = true ] &&
    { [ "$budget_seconds" -eq 0 ] || [ "$elapsed" -gt "$budget_seconds" ]; }; then
    terminated=true
    printf '\n%s\n' "::error title=${label} exceeded its execution budget::The command was terminated after ${elapsed}s, its full ${budget_seconds}s execution budget. The budget expires before \`timeout-minutes\` so this reports as a failure instead of a cancelled job (issue #977, issue #1017). Speed up or repartition the work, or raise the budget together with the job timeout." >&2
    report_compiler_cache
    signal_command_tree TERM
    grace_deadline=$((SECONDS + grace_seconds))
    while command_is_running && [ "$grace_seconds" -gt 0 ] &&
      [ "$SECONDS" -le "$grace_deadline" ]; do
      sleep "$poll_seconds"
    done
    signal_command_tree KILL
    # SIGKILL delivery is asynchronous. An exited root cannot reap its live
    # descendants; acknowledge group termination before reporting the deadline.
    # Bound both observations and wall time if a process cannot leave the kernel.
    kill_started=$SECONDS
    for ((kill_check = 0; kill_check < 100; kill_check++)); do
      command_is_running || break
      [ $((SECONDS - kill_started)) -lt 10 ] || break
      sleep 0.1 2> /dev/null || sleep 1
    done
    if command_is_running; then
      echo "Cannot confirm process-group termination after SIGKILL." >&2
      exit 125
    fi
    break
  fi

  sleep "$poll_seconds"
done

set +e
wait "$command_pid"
status=$?
set -e
trap - INT TERM

report_compiler_cache_write_health

elapsed=$((SECONDS - started))
if [ "$terminated" = true ]; then
  printf '\n%s was terminated after %ss, its full %ss execution budget.\n' \
    "$label" "$elapsed" "$budget_seconds"
  exit 124
fi

printf '\n%s took %ss of its %ss execution budget.\n' "$label" "$elapsed" "$budget_seconds"
exit "$status"
