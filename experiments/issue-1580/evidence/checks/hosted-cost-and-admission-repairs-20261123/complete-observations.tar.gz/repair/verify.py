from pathlib import Path
import subprocess,json,os,time,datetime,shutil
r=Path('/tmp/issue-1580-research/e462-shard-repair')
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
commands=[('scheduling-final',['node','--test','--test-concurrency=1','experiments/issue-1580/hosted-javascript-scheduling.test.mjs']),
 ('dialogue-partition',['node','--test','--test-concurrency=1','experiments/issue-1580/cnl-dialogue-partition.test.mjs']),
 ('ci-speed-policy',['node','scripts/check-ci-speed.mjs']),
 ('all-javascript-gates',['node','experiments/formal_ai_subagent/local-gates.mjs'])]
records=[]
for name,cmd in commands:
 started=time.time()
 with (r/(name+'.log')).open('wb')as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 record={'name':name,'command':cmd,'exitCode':p.returncode,'seconds':time.time()-started,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 records.append(record);(r/'verification-records.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
 if name=='all-javascript-gates':
  text=(r/(name+'.log')).read_text();record['counts']={status:sum(line.startswith(status+' ')for line in text.splitlines())for status in ['PASS','SKIP','FAIL']}
  d=r/'complete-gate-outputs';d.mkdir(exist_ok=True)
  for file in Path('experiments/formal_ai_subagent/sandboxes/gates').glob('*.log'):
   if file.stat().st_mtime>=started-1:shutil.copyfile(file,d/file.name)
(r/'verification-outcome.json').write_text(json.dumps({'complete':True,'records':records},indent=2)+'\n')
