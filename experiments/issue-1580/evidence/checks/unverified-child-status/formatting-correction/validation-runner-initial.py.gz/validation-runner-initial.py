from pathlib import Path
import gzip, hashlib, json, os, resource, subprocess, sys, time, traceback

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/unverified-child-status')
destination = root / 'experiments/issue-1580/evidence/checks/unverified-child-status'
if len(sys.argv) == 1:
    assert not (base / 'process.json').exists()
    available = int(Path('/sys/fs/cgroup/memory.max').read_text()) - int(Path('/sys/fs/cgroup/memory.current').read_text())
    assert available > 512 * 1024 * 1024, available
    with (base / 'worker.log').open('wb') as stream:
        worker = subprocess.Popen([sys.executable, __file__, 'finish'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    (base / 'process.json').write_text(json.dumps({'pid': worker.pid, 'availableBytes': available}) + '\n')
    print(json.dumps({'pid': worker.pid, 'availableBytes': available, 'sequential': True, 'rustBuildsEnabled': False, 'logDirectory': str(base)}))
    sys.exit(0)

assert sys.argv == [__file__, 'finish']
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
environment = dict(os.environ)
environment['NODE_OPTIONS'] = '--max-old-space-size=256'
environment['PATH'] = '/tmp/issue-1580-research/shellcheck-v0.11.0:' + environment['PATH']
results = []
started = time.time()
gate_started = None
destination.mkdir(exist_ok=False)

def check(name, command):
    beginning = time.time()
    log = base / (name + '.log')
    with log.open('wb') as stream:
        outcome = subprocess.run(command, cwd=root, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    raw = log.read_bytes()
    row = {'name': name, 'command': command, 'exitCode': outcome.returncode, 'durationSeconds': round(time.time() - beginning, 3), 'rawBytes': len(raw), 'rawLines': len(raw.splitlines()), 'rawSha256': hashlib.sha256(raw).hexdigest(), 'log': str(log)}
    results.append(row)
    (base / 'progress.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    return outcome.returncode

try:
    assert check('mirror-package-data-write', ['node', 'scripts/mirror-package-data.mjs', '--write']) == 0
    assert check('parity-fixture-write', ['node', 'experiments/issue-1550/parity-fixture.mjs', '--write']) == 0
    original = json.loads((base / 'original-fixture.json').read_text())
    current = json.loads((root / 'rust/tests/fixtures/meta-executor-parity.json').read_text())
    assert len(original['cases']) == 25 and len(current['cases']) == 29
    assert current['cases'][:25] == original['cases']
    expected = {'unverified-program-leaf': 'unresolved', 'unverified-program-child': 'unresolved', 'unverified-program-cache': 'unresolved', 'verified-program-child': 'resolved'}
    assert {entry['name']: entry['expected']['status'] for entry in current['cases'][25:]} == expected
    (base / 'fixture-preservation.json').write_text(json.dumps({'oldCasesUnchanged': 25, 'currentCaseCount': 29, 'newStatuses': expected, 'nativeExecutionClaimed': False}, indent=2) + '\n')
    check('meta-executor-tests', ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-concurrency=1', 'rust/tests/web/issue-1550-meta-executor.test.mjs'])
    check('factual-qa-tests', ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-concurrency=1', 'rust/tests/web/factual-qa-seed.test.mjs'])
    check('parity-fixture-check', ['node', 'experiments/issue-1550/parity-fixture.mjs', '--check'])
    gate_started = time.time()
    check('all-local-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs'])
    check('git-diff-check', ['git', 'diff', '--check'])
    complete = all(row['exitCode'] == 0 for row in results)
except BaseException:
    traceback.print_exc()
    complete = False
finally:
    archives = []
    for path in sorted(base.iterdir()):
        if path.is_file() and path.name != 'worker.log':
            raw = path.read_bytes()
            output = destination / (path.name + '.gz')
            packed = gzip.compress(raw, mtime=0)
            output.write_bytes(packed)
            archives.append({'source': str(path), 'archive': str(output.relative_to(destination)), 'rawBytes': len(raw), 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest()})
    details = []
    if gate_started is not None:
        for path in sorted((root / 'experiments/formal_ai_subagent/sandboxes/gates').glob('*.log')):
            if path.stat().st_mtime < gate_started:
                continue
            raw = path.read_bytes()
            output = destination / 'gate-details' / (path.name + '.gz')
            output.parent.mkdir(exist_ok=True)
            output.write_bytes(gzip.compress(raw, mtime=0))
            details.append({'source': str(path), 'archive': str(output.relative_to(destination)), 'rawBytes': len(raw), 'rawSha256': hashlib.sha256(raw).hexdigest()})
    report = {'complete': complete, 'durationSeconds': round(time.time() - started, 3), 'nodeHeapMiB': 256, 'childrenPeakRssKiB': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss, 'rustBuildsEnabled': False, 'nativeExecuted': False, 'independentAuthorshipCredit': 0, 'checks': results, 'archives': archives, 'perGateLogs': details}
    (destination / 'validation-outcome.json').write_text(json.dumps(report, indent=2) + '\n')
    (base / 'outcome.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: value for key, value in report.items() if key not in ['checks', 'archives', 'perGateLogs']}), flush=True)
sys.exit(0 if complete else 1)
