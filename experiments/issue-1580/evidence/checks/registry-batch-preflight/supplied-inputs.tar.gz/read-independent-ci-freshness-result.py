from pathlib import Path
import base64,json
p=Path('/tmp/gh-issue-solver-1794900398048/experiments/issue-1580/evidence/checks/registry-uncertainty/independent-ci-freshness')
for n in ['response.stdout.log','response.stderr.log','execution.json']:
 print('ENCODED',n,base64.b64encode((p/n).read_bytes()).decode())
