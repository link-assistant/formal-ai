from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');b=r/'experiments/issue-1580/evidence/ci/native-families-14ef1b5f'
review=json.loads((b/'review.json').read_text());review['diagnosticReview']='All 17 selected-job candidates are echoed shell source, not emitted diagnostics.';review['emittedSelectedJobDiagnostics']=0;(b/'review.json').write_text(json.dumps(review,indent=2)+'\n')
d=json.loads((b/'diagnostic-review.json').read_text());d['classificationComplete']=True;d['review']='All 144 candidates inspected: 20 echoed shell statements and 124 emitted file-size headroom warnings. Warnings remain unresolved.';(b/'diagnostic-review.json').write_text(json.dumps(d,indent=2)+'\n')
ledger=r/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json';d=json.loads(ledger.read_text());log=s/'rust-template-guidance-read.log';raw=log.read_bytes();content=raw.decode();assert 'Exit Code: 0' in content
readbase=r/'experiments/issue-1580/evidence/checks/rust-source-review';packed=gzip.compress(raw,mtime=0);(readbase/(log.name+'.gz')).write_bytes(packed);logs=json.loads((readbase/'logs.json').read_text());assert not any(x['file']==log.name+'.gz' for x in logs);logs.append({'file':log.name+'.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()});(readbase/'logs.json').write_text(json.dumps(logs,indent=2)+'\n')
for name in ['CONTRIBUTING.md','README.md']:
 source=(s/'templates/rust-complete'/name).read_bytes();lines=source.decode().splitlines();assert name not in {row['path'] for row in d['files']}
 for i,line in enumerate(lines,1):assert f'   {i}: {line}\n' in content,(name,i)
 d['files'].append({'path':name,'lines':len(lines),'sha256':hashlib.sha256(source).hexdigest(),'readLogs':[log.name+'.gz'],'literalReadRanges':[[1,len(lines)]],'literalReadLines':len(lines),'literalSourceFullyRead':True,'formalAiPracticeImplementationVerified':False})
d['files'].sort(key=lambda x:x['path']);d['fullyReadFiles']=len(d['files']);d['fullyReadSourceLines']=sum(x['lines'] for x in d['files']);assert d['fullyReadFiles']==139 and d['fullyReadSourceLines']==24142;d['observedAt']=datetime.now(timezone.utc).isoformat()
d['practiceDecisions'].append({'practice':'Developer and adoption documentation: script test closure, whole-checkout release custody, bounded steps, network retry and publishing trust','templateFiles':['CONTRIBUTING.md','README.md'],'assessment':'All 797 lines read. Explicit script-only test harnesses and dirty-checkout refusal require counterpart verification. Budget wrappers, Cargo network hardening, lock currency and source-qualified registry behavior have existing counterparts; documentation proves no runtime or hosted publication. OIDC fallback, manual release PR identity and Pages configuration remain distinct acceptance questions.','status':'literal-source-read-counterpart-investigation-pending','verification':str(readbase.relative_to(r)/'logs.json')})
url='https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/254';assert not any(x['url']==url for x in d['upstreamReports']);d['upstreamReports'].append({'scope':'Manual fragment creation truncates existing same-second fragments and follows pre-existing symlinks','url':url,'evidenceCommit':'14ef1b5f8dc590733283b0e4cb0cd75e47ba89d2','templateCliExecuted':False,'formalAiPhysicalRegressionsPassed':True,'upstreamRepairVerified':False})
encoded=json.dumps(d,indent=2,ensure_ascii=False);start=encoded.index('  "files": [');end=encoded.index('\n  ],',start)+len('\n  ],');encoded=encoded[:start]+'  "files": [\n'+',\n'.join('    '+json.dumps(row,ensure_ascii=False) for row in d['files'])+'\n  ],'+encoded[end:];ledger.write_text(encoded+'\n')
checkpoint=r/'docs/case-studies/issue-1580/registry-release-checkpoint.md';assert not checkpoint.exists();checkpoint.write_text('''# Registry and release verification checkpoint

This checkpoint belongs to [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581).
The full issue remains unfinished and the PR remains draft and unmerged.

## Published CI and warnings

All 23 workflows on published commit 14ef1b5f8dc590733283b0e4cb0cd75e47ba89d2
completed successfully. Eight actual native jobs pass: workflow contracts 102,
coding 32, reasoning 141, interfaces 78, benchmarks 11 and Hive 20/10/7.
These are source-bound hosted results, separate from unchanged-original credit.
Full logs for all 23 workflows and selected native/JavaScript job logs are
preserved with raw/compressed hashes under evidence/ci/native-families-14ef1b5f/.
All 194 original collector archives and 46 additional full-run archives are
hash-verified. Only diagnostic/result selections were read; no literal review
of every successful log line is claimed.

The warning/error candidate scan finds 144 records: 20 echoed shell statements
and 124 emitted source-size headroom warnings. Pipeline raw lines 2106–2352
identify the warning files. Those warnings remain open, with thresholds
unchanged. Green workflows do not establish warning-free CI. The first full-log
collector hit Formal AI's 60-second shell limit after preserving 19 workflows;
a background worker resumes the remaining four and verifies all 23. Both
attempts are retained. Classification and raw locations are in diagnostic-review.json
and classified-diagnostics.jsonl beside the full-run records.

## Registry repair and fixture correction

Both release CLIs converted transport/status/JSON failures to missing-version
or missing-artifact decisions. Local commit 899de4d12 adopts the pinned Rust
registry helper with bounded retries and HTTP deadlines, validating returned
crate/tag identities. Only a genuine 404 establishes absence. Version-floor
and candidate checks complete before writes; existing source-qualified recovery
and publication guards remain intact.

A separate ten-minute hosted job compiles only the registry helper and both
actual release scripts. Loopback cases cover throttling, unavailable services,
dropped connections, permanent errors, malformed/wrong identities, actual 404,
retry recovery and published-version floors. This native job has not yet run
for the local changes. No local Rust build ran.

Local checks pass 36 admission, 96 maintained policy and 32 documentation policy
cases, Rust formatting and nine affected gates. Historical-source admission
controls fail as expected. These are not actual Rust behavior tests. The first
two-job policy mismatch is retained before correction in registry-uncertainty.

Fixture review then found that unpublished candidates returned 404 even in
wrong-identity mode. Commit 00f954c7b fixes the fixture and adds a real HTTP
regression for two unpublished versions. It fails before and passes after the
correction. The fixture-only entrypoint explicitly skips Cargo and claims no
release CLI execution. It, 36 admission checks and nine gates pass. Its receipt
in evidence/checks/registry-candidate-fixture supersedes the earlier Python
fixture digest without changing the original registry receipt.

## Review and remaining acceptance

Rust literal review reaches 139/373 files and 24,142 lines, including all 797
root guidance lines. The remaining 234 files, counterpart applicability and
runtime verification remain unfinished. The shared fragment overwrite/symlink
defect is reported at https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/254.
The template source is inspected; its CLI was not compiled or executed. The
report separately cites Formal AI's passing physical regression evidence.
No upstream repair is claimed.

One bounded independent CI freshness attempt retains its frozen request,
complete response and tool route in registry-uncertainty/independent-ci-freshness.
The response is unparseable and earns no accepted reasoning: 0/20. Supplied
commands, patches and source reviews earn zero authorship credit. Strict dated
original-source acceptance remains 31/53. Broad template, warning, budget,
identity/delivery, benchmark and full PR review requirements remain open.
''')
readme=r/'docs/case-studies/issue-1580/README.md';readme.write_text(readme.read_text()+'''

The [registry/release checkpoint](registry-release-checkpoint.md) records all 23
passing workflows on 14ef1b5f, actual native family counts, 124 unresolved source
size warnings, the unexecuted local registry repair, its failing-before HTTP
fixture correction and Rust literal review at 139/373 files. Independent
reasoning remains 0/20 and strict original-source acceptance remains 31/53.
''')
plan=r/'experiments/issue-1580/work-plan.md';plan.write_text(plan.read_text()+'''

### Registry fixture and published-head checkpoint (2026-11-20)

- [x] Preserve fixture correction 00f954c7b with failing-before/passing-after HTTP evidence for two unpublished candidates. Fixture-only execution skips Rust and claims no native CLI behavior. Final 36 admission checks and nine gates pass.
- [x] Preserve all 23 passing workflows on 14ef1b5f, eight native families and full workflow logs. Inspect all 144 diagnostic candidates: 20 shell source echoes and 124 real source-size warnings. Warnings remain open with unchanged thresholds. Retain the interrupted and resumed collectors.
- [x] Read both pinned root Rust guides: 139/373 files and 24,142 lines. The remaining 234 files and counterpart verification stay open. Report the source-confirmed shared fragment defect at https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/254; template CLI execution and upstream repair remain unverified.
- [x] Preserve one independently requested CI freshness reasoning attempt. Formal AI reports an unparseable request; accepted units remain 0/20.
- [ ] Publish the combined registry/evidence batch once after size checks, current-main/feedback review and empty active/queued lists. Execute actual registry/helper and both release CLIs in hosted CI, collecting and fixing every failure before another push. Keep broader requirements open and PR draft/unmerged.
''');assert len(plan.read_text().splitlines())<1500
print(json.dumps({'registryNativeExecuted':False,'fixtureHttpExecuted':True,'publishedWorkflowsPassed':23,'openSourceWarnings':124,'rustFilesRead':139,'rustLinesRead':24142,'independentAccepted':'0/20','originalStrict':'31/53','fullIssueComplete':False}))
