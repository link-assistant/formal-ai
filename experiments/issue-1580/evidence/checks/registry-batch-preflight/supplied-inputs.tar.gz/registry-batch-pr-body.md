CI omitted native inputs, lost task/source ownership and accepted incomplete process or Git evidence. This draft repairs those boundaries and adds focused native replays. Issue #1580 remains unfinished; keep this PR draft and unmerged.

Fixes #1580

Changes:

- Preserve quoted task passages, request-local constraints, selected-child provenance and unresolved status for unverified drafts. Reuse source-bound calculation and counting evidence; regenerate maintained language projections through their official writers.
- Preserve multilingual lookup, explanation, calendar and controlled-language grammar behavior. Accept canonical IPv4 web operands while excluding attachment metadata.
- Admit complete native reasoning, interface, Hive, workflow, benchmark and fixture source closures. Separate expensive native families with two concurrent matrix runners, preserving all 14 targets, single test threads, failure propagation and existing 20-minute clocks. Keep the complete runner available.
- Keep routine wrapper diagnostics in files unless verbosity is explicit. Forward client flags independently and retain the empty-stderr contract.
- Open closed-program sequence search using bounded atoms from actual ranked fragment types. Preserve IR content IDs and rejection stages; an empty frontier creates no attempt. Verification requirements remain intact.
- Decode appended HTTP capture records individually using their public schemas, preserving capture/privacy/ephemeral-memory assertions. Replay Hive workflow delivery in real temporary Git repositories with explicit compiler/CI fixtures; missing Git evidence or failed verification prevents commit.
- Enforce budgets until the process group finishes, including children whose parent exited. Account for Bash's coarse elapsed clock at the deadline boundary. Preserve command statuses, stdout, stderr and warning-only behavior; report unavailable process inspection.
- Reject failed/partial Git lockfile inventories before Cargo audits. Check package versions on release-prefixed PR branches instead of trusting branch names.
- Create manual changelog fragments exclusively, preserving existing files on collisions and refusing symlinks. Adopt the Rust template shared fallible Actions output writer in all six release callers; configured output failures now stop before success reporting. Add both helpers and all callers to native admission.
- Parse actual Cargo package identity and workspace configuration in release helpers. Replace only the package-version token, preserving comments, CRLF and unrelated manifest bytes; refuse missing or inherited versions before writes. Include the separate changelog collector and preserve name-only badge lookup.
- Retry a failed native checkout once within the existing four-minute checkout allowance and twenty-minute job clock; preserve sparse checkout, ref selection and credential settings. Require one actual success before compilation.
- Refuse uncertain crates.io, GitHub release and Docker tag observations before release decisions or version mutations. Bound retryable failures, stop on permanent errors and validate returned identities. Add a separate read-only native job for the actual helper and both release CLIs against local HTTP fixtures.
- Propagate fragment directory, read and cleanup errors in bump selection, standalone changelog collection and version preparation. Use the exact consumed snapshot for cleanup; retain canonical formatting and newly arrived fragments. Admit actual filesystem regression functions to focused native CI.
- Refresh JavaScript weights from complete measured events without lowering conservative historical costs; split the complete fast PR inventory into four groups with the same deadlines and eight main groups.
- Retain pinned template comparisons, executable negative controls and upstream reports. Reporting a defect establishes no upstream repair.

Verification:

- All 23 workflows on published commit `14ef1b5f8dc590733283b0e4cb0cd75e47ba89d2` pass. Actual hosted native counts are workflow contracts 102, coding 32, reasoning 141, interfaces 78, benchmarks 11 and Hive 20/10/7. These source-bound results include changelog I/O regressions; they do not execute the subsequent local registry changes or change strict original-source acceptance. [Complete logs and classification](https://github.com/link-assistant/formal-ai/tree/issue-1580-8d61a32a61e1/experiments/issue-1580/evidence/ci/native-families-14ef1b5f) preserve every workflow and exact source identity.
- All 144 warning/error candidates are inspected: 20 echoed shell statements and 124 actual source-size headroom warnings (pipeline raw lines 2106–2352). The warnings remain unresolved, with thresholds unchanged. Green CI is not warning-free acceptance.
- The local registry batch passes 36 admission, 96 maintained workflow-policy and 32 documentation-policy checks, Rust formatting and nine affected gates. Historical-source admission controls fail as expected. Its HTTP fixture regression fails before and passes after the unpublished-candidate correction. No local Rust build or release CLI behavior ran; the new hosted registry job remains pending. [Registry checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/registry-release-checkpoint.md) separates those evidence scopes.
- Published `14ef1b5f` also verifies the previous documentation admission and 360-second JavaScript shard repairs. Conservative measured weights and four complete PR groups retain existing deadlines. The timing repair passes 25 timing and 18 production-profile checks plus the full local gate inventory with explicit exclusions.
- Timer regressions reproduce failures before repair: two coarse-clock cases and six parent-exit/child-lifetime cases. All focused cases pass after repair, alongside maintained release/cache/template, container and native-artifact controls. Fixtures bound memory and lifetime and reap their children. ShellCheck passes; no local Rust build or native execution runs.
- Four release-prefix controls fail before repair and pass after it; the maintained policy entrypoint passes 86 checks. Legitimate manual release fragments still pass, and immutable current-base comparison remains required.
- Java's pinned project-version CLI reports success without changing the version in three parent/comment cases. Rust's pinned desktop checksum command includes stale fragments and can include its own output on GNU and shasum paths. Fresh-output self-inclusion races enumeration; pre-existing-output self-inclusion is deterministic. Local reproductions and corrected candidates are retained; 57 maintained template checks and 43 unchanged upstream prerequisite checks pass. The source-confirmed manual fragment overwrite/symlink defect is reported in [Rust #254](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/254), with template CLI execution explicitly unverified. Reports also include [Java #32](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/32), [Rust #213](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/213) and [Rust #251](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/251). Upstream repair and hosted publication remain unverified.
- Selected production review covers 106 selected diffs, with identities reverified; complete PR review remains unfinished. Java's pinned 207-file applicability map is complete, while applicable implementation/runtime acceptance remains open. Rust literal source review covers 139/373 files and 24,142 lines; 234 files and practice verification remain open.

Focused reproduction:

```sh
timeout 600 node --test --test-concurrency=1 rust/tests/web/hive-work-item-consumer.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/fast-pull-request-production-profile.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/native-regression-groups.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/native-checkout-retry.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/documentation-only-ci-policy.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/ci-speed.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/budget-clock-boundary.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/deadline-process-lifetime.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/default-branch-build-policy.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-java-project-version.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-rust-desktop-checksums.test.mjs
python3 experiments/issue-1580/release-registry/check_fixture.py
node experiments/formal_ai_subagent/local-gates.mjs
```

The hosted-only registry job runs `cargo test --manifest-path experiments/issue-1580/release-registry/Cargo.toml --locked --lib -- --test-threads=1 --nocapture` and `python3 experiments/issue-1580/release-registry/cli_regressions.py`.

Earlier browser source-binding evidence uses a labeled production-worker harness with external requests blocked:

![Before: the Spanish definition frame is skipped](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/screenshots/issue-1580/meaning-hydration-before.png?raw=true)

![After: the definition routes to search and the unresolved sibling answer remains intact](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/screenshots/issue-1580/meaning-hydration-after.png?raw=true)

Unfinished acceptance is tracked in the [work plan](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/experiments/issue-1580/work-plan.md) and [case study](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/README.md): current-head CI, remaining original native and budget contracts, all eight complete template comparisons and applicable practices, dependency migrations and warnings, historical cache/Docker evidence, live delivery/model identity, general binding/provenance and complete PR review. Strict dated original-source passing evidence is 31/53; matching names from changed fixtures alone earn no original-source acceptance. Independently accepted Formal AI reasoning remains 0/20; supplied commands, patches and reviews earn no independent credit.
