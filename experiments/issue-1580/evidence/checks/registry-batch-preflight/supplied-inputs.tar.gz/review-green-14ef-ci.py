from pathlib import Path
import gzip,hashlib,json,re,datetime
r=Path('/tmp/gh-issue-solver-1794900398048')
b=r/'experiments/issue-1580/evidence/ci/native-families-14ef1b5f'
out=json.loads((b/'outcome.json').read_text());assert out['complete'] and out['success']==23 and out['failed']==[]
records=json.loads((b/'records.json').read_text());summaries=[];candidates=[];verified=0
for row in records:
 for stream in ['stdout','stderr']:
  d=row[stream];packed=(b/d['file']).read_bytes();raw=gzip.decompress(packed)
  assert hashlib.sha256(packed).hexdigest()==d['archiveSha256'];assert hashlib.sha256(raw).hexdigest()==d['rawSha256'];verified+=1
 if not row['name'].startswith('job-'):continue
 raw=gzip.decompress((b/row['stdout']['file']).read_bytes()).decode(errors='replace')
 clean=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',raw)
 lines=clean.splitlines();results=[]
 for i,line in enumerate(lines,1):
  if 'test result:' in line or re.search(r'# (tests|pass|fail|skipped|duration_ms) ',line):results.append({'line':i,'text':line})
  if re.search(r'(^|\s)(warning(?:\[.*?\])?:|error(?:\[.*?\])?:)|::(?:warning|error)::',line,re.I):
   candidates.append({'record':row['name'],'line':i,'text':line})
 summaries.append({'record':row['name'],'lineCount':len(lines),'results':results})
assessment={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':out['head'],'workflowCount':23,'allTerminal':True,'failedWorkflows':[],'verifiedArchives':verified,'jobResultSummaries':summaries,'diagnosticCandidateCount':len(candidates),'allLogLinesLiterallyRead':False,'nativeRegistryDraftExecuted':False,'fullIssueComplete':False}
(b/'review.json').write_text(json.dumps(assessment,indent=2)+'\n');(b/'diagnostic-candidates.json').write_text(json.dumps(candidates,indent=2)+'\n')
print(json.dumps(assessment,indent=2));print('DIAGNOSTIC CANDIDATES');print(json.dumps(candidates,indent=2))
p=r/'experiments/issue-1580/evidence/checks/registry-uncertainty/independent-ci-freshness/execution.json'
d=json.loads(p.read_text());d['acceptancePendingHumanReview']=False;d['reviewedBy']='coordinating agent';d['accepted']=False;d['reason']='The complete Formal AI response reports an unparseable request and supplies no CI evidence assessment. Exit zero is not successful reasoning.';d['acceptedUnits']=0;d['fixedDenominator']=20;p.write_text(json.dumps(d,indent=2)+'\n')
print('INDEPENDENT RESULT',json.dumps(d))
