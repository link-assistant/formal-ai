from pathlib import Path
import subprocess,gzip,hashlib,json,re,datetime,sys
if len(sys.argv)==1:
 log=Path('/tmp/issue-1580-research/full-green-14ef-worker.log')
 with log.open('wb') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':worker.pid,'log':str(log)}));raise SystemExit(0)
r=Path('/tmp/gh-issue-solver-1794900398048');base=r/'experiments/issue-1580/evidence/ci/native-families-14ef1b5f'
latest=json.loads((base/'latest.json').read_text());assert latest['completed']==latest['workflowCount']==23
records=json.loads((base/'full-run-records.json').read_text()) if (base/'full-run-records.json').exists() else [];candidates=[]
for row in latest['runs']:
 assert row['headSha']==latest['head'] and row['status']=='completed' and row['conclusion']=='success'
 if row['databaseId'] in {record['runId'] for record in records}:continue
 args=['gh','run','view',str(row['databaseId']),'--repo','link-assistant/formal-ai','--log']
 result=subprocess.run(args,cwd=r,capture_output=True);record={'runId':row['databaseId'],'workflow':row['workflowName'],'headSha':row['headSha'],'argv':args,'exitCode':result.returncode}
 for label,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
  filename='full-run-'+str(row['databaseId'])+'.'+label+'.gz';packed=gzip.compress(raw,mtime=0);(base/filename).write_bytes(packed)
  record[label]={'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())}
 records.append(record);(base/'full-run-records.json').write_text(json.dumps(records,separators=(',',':'))+'\n')
 assert result.returncode==0,(row['workflowName'],result.stderr.decode(errors='replace'))
 print(json.dumps({'workflow':row['workflowName'],'runId':row['databaseId'],'lines':record['stdout']['lines'],'exitCode':result.returncode}),flush=True)
for record in records:
 for label in ['stdout','stderr']:
  d=record[label];packed=(base/d['file']).read_bytes();raw=gzip.decompress(packed)
  assert hashlib.sha256(raw).hexdigest()==d['rawSha256'];assert hashlib.sha256(packed).hexdigest()==d['archiveSha256']
 lines=gzip.decompress((base/record['stdout']['file']).read_bytes()).decode(errors='replace').splitlines()
 for i,line in enumerate(lines,1):
  cleaned=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',line)
  if re.search(r'(^|\s)(warning(?:\[.*?\])?:|error(?:\[.*?\])?:)|::(?:warning|error)::',cleaned,re.I):
   candidates.append({'runId':record['runId'],'workflow':record['workflow'],'line':i,'text':cleaned,'context':lines[max(0,i-2):i+2]})
(base/'full-run-diagnostic-candidates.json').write_text(json.dumps(candidates,indent=2)+'\n')
print('DIAGNOSTIC CANDIDATES',len(candidates))
for item in candidates:print(json.dumps({k:v for k,v in item.items() if k!='context'}))
print('COMPLETE',len(records),flush=True)
