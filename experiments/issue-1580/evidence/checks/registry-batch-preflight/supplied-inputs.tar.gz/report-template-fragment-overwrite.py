from pathlib import Path
import subprocess,json,base64,hashlib
from datetime import datetime,timezone
repo='link-foundation/rust-ai-driven-development-pipeline-template';out=Path('experiments/issue-1580/evidence/checks/template-fragment-overwrite-report');out.mkdir(exist_ok=True)
queries=['fragment overwrite','fragment collision','fragment symlink']
for index,query in enumerate(queries):
 r=subprocess.run(['gh','search','issues','--repo',repo,query,'--limit','100','--json','number,title,url,state'],capture_output=True,text=True,check=True);items=json.loads(r.stdout);(out/f'search-{index}.json').write_text(r.stdout);assert not items,(query,items)
r=subprocess.run(['gh','api',f'repos/{repo}/commits/main'],capture_output=True,text=True,check=True);commit=json.loads(r.stdout)['sha']
r=subprocess.run(['gh','api',f'repos/{repo}/contents/scripts/create-changelog-fragment.rs?ref={commit}'],capture_output=True,text=True,check=True);data=json.loads(r.stdout);raw=base64.b64decode(data['content']);source=raw.decode();assert 'fs::write(&fragment_file, &fragment_content)' in source;assert 'format!("{}/{}-manual-{}.md", changelog_dir, timestamp, bump_type)' in source;assert '%Y%m%d%H%M%S' in source
(out/'source-identity.json').write_text(json.dumps({'observedAt':datetime.now(timezone.utc).isoformat(),'repository':repo,'commit':commit,'blobSha':data['sha'],'sha256':hashlib.sha256(raw).hexdigest(),'currentMainSourceConfirmed':True,'templateCliExecuted':False,'formalAiCoreJob':136121028636},indent=2)+'\n')
body=f'''The manual fragment writer constructs `{{timestamp}}-manual-{{bump_type}}.md` with a timestamp resolved to one second, then calls `fs::write` on that path. A second invocation with the same bump type in that second truncates the existing fragment. A pre-existing symbolic link is followed and its target is overwritten.

Confirmed by reading current `main` at `{commit}`: [filename construction and write](https://github.com/{repo}/blob/{commit}/scripts/create-changelog-fragment.rs#L119). This report is a source-confirmed finding; the template CLI has not been compiled or executed in this investigation.

Reproduction for a deterministic regression: extract the final fragment write into a helper accepting a path and bytes. Precreate that path with an original fragment, call the helper with different bytes, and assert the original bytes remain and the operation reports a collision. The current `fs::write` implementation fails that assertion. Also exercise two concurrent creators for the same path, a missing parent, and on Unix a symbolic link to a separate file. Exactly one concurrent creator should succeed and the winner must contain one complete fragment; a symbolic-link target must remain unchanged.

Use `OpenOptions::new().write(true).create_new(true)` (or an equivalent exclusive creation operation) at the actual write boundary. Adding random filename text alone does not protect a pre-existing path or symbolic link. Preserve the concrete path in any failure diagnostic.

The same defect was found during [Formal AI issue #1580](https://github.com/link-assistant/formal-ai/issues/1580). The corresponding repair and physical filesystem regressions are in [Formal AI PR #1581](https://github.com/link-assistant/formal-ai/pull/1581), with [the shared writer and four regression cases](https://github.com/link-assistant/formal-ai/blob/14ef1b5f8dc590733283b0e4cb0cd75e47ba89d2/scripts/changelog-fragment-file.rs). All four cases passed in [hosted core job 136121028636](https://github.com/link-assistant/formal-ai/actions/runs/44686151225/job/136121028636). This evidence verifies the Formal AI repair; upstream repair remains unverified.
'''
path=Path('/tmp/issue-1580-research/template-fragment-overwrite-issue.md');path.write_text(body);print('REPORT BODY\n'+body,flush=True)
r=subprocess.run(['gh','issue','create','--repo',repo,'--title','Manual fragment creation can overwrite an existing fragment or symlink target','--body-file',str(path)],capture_output=True,text=True,check=True);url=r.stdout.strip();assert url.startswith(f'https://github.com/{repo}/issues/');(out/'created-issue.json').write_text(json.dumps({'url':url,'title':'Manual fragment creation can overwrite an existing fragment or symlink target','body':body,'upstreamImplemented':False,'upstreamVerified':False,'fullIssueComplete':False},indent=2)+'\n');print('CREATED',url)
