from pathlib import Path
import hashlib
r=Path('/tmp/issue-1580-research/templates/rust-complete')
for name in ['CONTRIBUTING.md','README.md']:
 p=r/name;raw=p.read_bytes();print('FILE',name,'SHA256',hashlib.sha256(raw).hexdigest(),'LINES',len(raw.decode().splitlines()))
 for i,line in enumerate(raw.decode().splitlines(),1):print(f'{i}: {line}')
