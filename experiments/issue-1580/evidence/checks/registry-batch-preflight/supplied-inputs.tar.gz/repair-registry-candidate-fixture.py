from pathlib import Path
p=Path('experiments/issue-1580/release-registry/cli_regressions.py');s=p.read_text();assert 'import http.server\n' in s;s=s.replace('import http.server\n','import http.client\nimport http.server\n',1)
needle='    def test_failed_lookup_never_decides_release_or_mutates_version(self):\n';assert needle in s
method='''    def test_fixture_can_return_wrong_identity_for_an_unpublished_candidate(self):
        self.__class__.scope = '/crates/fixture/'
        for version in ['1.2.4', '2.4.10']:
            self.__class__.mode = 'success'
            connection = http.client.HTTPConnection('127.0.0.1', self.server.server_port, timeout=5)
            try:
                connection.request('GET', f'/api/v1/crates/fixture/{version}')
                response = connection.getresponse()
                self.assertEqual(response.status, 404)
                response.read()
                self.__class__.mode = 'wrong-identity'
                connection.request('GET', f'/api/v1/crates/fixture/{version}')
                response = connection.getresponse()
                self.assertEqual(response.status, 200)
                self.assertEqual(json.loads(response.read()), {'version': {'num': '0.0.0'}})
            finally:
                connection.close()

'''
s=s.replace(needle,method+needle,1);p.write_text(s)
p=Path('experiments/issue-1580/release-registry/check_fixture.py');p.write_text('''#!/usr/bin/env python3
"""Validate the loopback HTTP fixture only, without building or running Rust."""
import importlib.util
from pathlib import Path
import subprocess
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('registry_cli_fixture', Path(__file__).with_name('cli_regressions.py'))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
actual_run = subprocess.run


def without_cargo_build(args, **kwargs):
    if args[:2] == ['cargo', 'build']:
        return subprocess.CompletedProcess(args, 0, stdout='', stderr='')
    return actual_run(args, **kwargs)


suite = unittest.TestSuite([module.RegistryRegressions(
    'test_fixture_can_return_wrong_identity_for_an_unpublished_candidate')])
with patch.object(module.subprocess, 'run', side_effect=without_cargo_build):
    result = unittest.TextTestRunner(verbosity=2).run(suite)
print('HTTP fixture check only: no Rust compilation or release CLI execution.')
raise SystemExit(0 if result.wasSuccessful() else 1)
''')
print('Added a real HTTP fixture regression and a local no-build entrypoint; wrong-candidate server repair intentionally not applied yet.')
