from pathlib import Path
import subprocess,hashlib,json,gzip,sys,ast
from datetime import datetime,timezone
base=Path('experiments/issue-1580/evidence/checks/registry-candidate-fixture');base.mkdir(exist_ok=True);records=[]
p=Path('experiments/issue-1580/release-registry/check_fixture.py');s=p.read_text().replace('import subprocess\n','import subprocess\nimport sys\n',1).replace("spec = importlib.util", "sys.dont_write_bytecode = True\n\nspec = importlib.util",1);p.write_text(s)
def run(label,expected):
 args=['python3','experiments/issue-1580/release-registry/check_fixture.py'];r=subprocess.run(args,capture_output=True);raw=r.stdout+r.stderr;packed=gzip.compress(raw,mtime=0);(base/(label+'.log.gz')).write_bytes(packed);records.append({'label':label,'command':args,'exitCode':r.returncode,'expectedExitCode':expected,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'nativeBehaviorExecuted':False});print(label,r.returncode,raw.decode(),flush=True);assert r.returncode==expected
run('before',1)
p=Path('experiments/issue-1580/release-registry/cli_regressions.py');s=p.read_text();old="elif self.path.endswith('/1.2.3'):";new="elif self.path.endswith('/1.2.3') or (affected and cls.mode == 'wrong-identity'\n                                                                  and '/crates/fixture/' in self.path):";assert s.count(old)==1;s=s.replace(old,new,1);p.write_text(s)
run('after',0)
for p in Path('experiments/issue-1580/release-registry').glob('*.py'):ast.parse(p.read_text(),filename=str(p))
p=Path('experiments/issue-1580/release-registry/README.md');s=p.read_text();s+='''
The local command `python3 experiments/issue-1580/release-registry/check_fixture.py`
checks the real loopback server's absent versus wrong-identity responses for
unpublished candidates. It replaces only the setup compilation call and does
not build or run release binaries. The same HTTP fixture regression runs in the
full hosted CLI suite. Its preserved before-control fails with HTTP 404 instead
of the intended mismatched HTTP 200 response.
''';p.write_text(s)
(base/'verification.json').write_text(json.dumps({'observedAt':datetime.now(timezone.utc).isoformat(),'rootCause':'The wrong-identity fixture previously produced 404 for unpublished bump candidates, so that candidate path never supplied an invalid success identity.','records':records,'sourceIdentities':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(Path('experiments/issue-1580/release-registry').glob('*.py'))],'httpFixtureExecuted':True,'nativeBehaviorExecuted':False,'independentAuthorshipCredit':False,'fullIssueComplete':False},indent=2)+'\n')
print('Actual HTTP fixture regression fails before and passes after. Both production release CLIs remain pending hosted execution.')
