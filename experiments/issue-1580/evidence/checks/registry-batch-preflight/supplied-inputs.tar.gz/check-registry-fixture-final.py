from pathlib import Path
import os,subprocess,sys,json,gzip,hashlib,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research/registry-fixture-final-checks')
if len(sys.argv)==1:
 scratch.mkdir(exist_ok=False)
 with (scratch/'worker.log').open('wb') as log:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'scratch':str(scratch)}));sys.exit(0)
base=root/'experiments/issue-1580/evidence/checks/registry-candidate-fixture';d=json.loads((base/'verification.json').read_text())
try:
 for label,args in [('http-fixture-final',['python3','experiments/issue-1580/release-registry/check_fixture.py']),('native-admission-final',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/native-regression-groups.test.mjs']),('gates-final',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size-js-twin,check-changelog-fragment-js-twin,check-generated-files,check-runner-labels,check_js_rust_translation,layered-ci#1,layered-ci#2,layered-ci#3,layered-ci#4']),('diff-check-final',['git','diff','--check'])]:
  r=subprocess.run(args,cwd=root,capture_output=True,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','PYTHONDONTWRITEBYTECODE':'1'});raw=r.stdout+r.stderr;packed=gzip.compress(raw,mtime=0);(base/(label+'.log.gz')).write_bytes(packed);d['records'].append({'label':label,'command':args,'exitCode':r.returncode,'expectedExitCode':0,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'nativeBehaviorExecuted':False});(base/'verification.json').write_text(json.dumps(d,indent=2)+'\n');print(label,r.returncode,raw.decode(errors='replace')[-2000:],flush=True);assert r.returncode==0,label
 d['complete']=True;d['sourceIdentities']=[{'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((root/'experiments/issue-1580/release-registry').glob('*.py'))];(base/'verification.json').write_text(json.dumps(d,indent=2)+'\n');(scratch/'outcome.json').write_text(json.dumps({'complete':True,'nativeBehaviorExecuted':False})+'\n');print('COMPLETE',flush=True)
except BaseException:
 traceback.print_exc();(scratch/'failure.json').write_text(json.dumps({'complete':False,'traceback':traceback.format_exc()})+'\n');sys.exit(1)
