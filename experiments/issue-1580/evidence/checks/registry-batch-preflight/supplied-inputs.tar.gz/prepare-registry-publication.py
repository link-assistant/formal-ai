from pathlib import Path
import subprocess,json,gzip,hashlib,tarfile,io,datetime,os,sys,traceback
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');scratch=s/'registry-batch-final-preflight'
if len(sys.argv)==1:
 scratch.mkdir(exist_ok=False)
 with (scratch/'worker.log').open('wb') as out:worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=r,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':worker.pid,'scratch':str(scratch)}));raise SystemExit(0)
b=r/'experiments/issue-1580/evidence/checks/registry-batch-preflight';b.mkdir(exist_ok=False);records=[]
def run(label,args):
 result=subprocess.run(args,cwd=r,capture_output=True,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','PYTHONDONTWRITEBYTECODE':'1'});row={'label':label,'argv':args,'exitCode':result.returncode}
 for name,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
  packed=gzip.compress(raw,mtime=0);filename=label+'.'+name+'.gz';(b/filename).write_bytes(packed);row[name]={'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()}
 records.append(row);(b/'records.json').write_text(json.dumps(records,separators=(',',':'))+'\n');print(label,result.returncode,result.stdout.decode(errors='replace')[-1800:],result.stderr.decode(errors='replace')[-1000:],flush=True);assert result.returncode==0,label
 return result.stdout
try:
 assert run('branch',['git','branch','--show-current']).decode().strip()=='issue-1580-8d61a32a61e1'
 run('fetch-main',['git','fetch','origin','main']);run('main-ancestor',['git','merge-base','--is-ancestor','origin/main','HEAD'])
 for label,path in [('issue-comments','issues/1580/comments'),('pull-request-comments','issues/1581/comments'),('pull-request-inline','pulls/1581/comments'),('pull-request-reviews','pulls/1581/reviews')]:
  raw=run(label,['gh','api','repos/link-assistant/formal-ai/'+path,'--paginate']);data=json.loads(raw);print('FEEDBACK',label,len(data),flush=True)
 run('source-diff-stat',['git','diff','--stat','14ef1b5f..HEAD'])
 # Preserve the supplied scripts and full investigation outputs for this round only.
 names=['resume-1580-status.py','read-next-review-context.py','attempt-ci-freshness-reasoning.py','registry-cli-fixture-review.py','read-independent-ci-freshness-result.py','review-green-14ef-ci.py','collect-full-green-14ef-logs.py','read-rust-template-guidance.py','summarize-green-diagnostics.py','document-registry-round.py','prepare-registry-publication.py','repair-registry-candidate-fixture.py','verify-registry-candidate-fixture.py','check-registry-fixture-final.py','report-template-fragment-overwrite.py','registry-batch-pr-body.md']
 buffer=io.BytesIO();rows=[]
 with tarfile.open(fileobj=buffer,mode='w') as archive:
  for name in names:
   p=s/name
   if not p.exists():continue
   data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data));rows.append({'file':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 raw=buffer.getvalue();packed=gzip.compress(raw,mtime=0);(b/'supplied-inputs.tar.gz').write_bytes(packed);(b/'supplied-inputs.json').write_text(json.dumps({'files':rows,'archiveSha256':hashlib.sha256(packed).hexdigest(),'autonomousAuthorshipCredit':0},indent=2)+'\n')
 logs=[]
 for name in ['read-next-review-context.log','read-next-review-context-corrected.log','reasoning-entrypoints-review.log','reasoning-entrypoints-numbered-review.log','registry-candidate-fixture-validation.log','registry-candidate-fixture-commit.log','registry-cli-fixture-review.log','collect-full-green-14ef-logs.log','collect-full-green-14ef-logs-resumed.log','full-green-14ef-worker.log','summarize-green-diagnostics.log','document-registry-round.log','document-registry-round-corrected.log','template-fragment-overwrite-report.log','original-acceptance-feedback-current.log']:
  p=s/name
  if not p.exists():continue
  raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);(b/(name+'.gz')).write_bytes(packed);logs.append({'file':name+'.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
 (b/'investigation-logs.json').write_text(json.dumps(logs,indent=2)+'\n')
 run('archive-command-transcripts',['python3',str(s/'archive-evidence.py')])
 run('file-size-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size-js-twin'])
 run('diff-check',['git','diff','--check'])
 outcome={'complete':True,'nativeRegistryExecuted':False,'fullIssueComplete':False,'suppliedAuthorshipCredit':0};(scratch/'outcome.json').write_text(json.dumps(outcome)+'\n');print('COMPLETE',flush=True)
except BaseException:
 traceback.print_exc();(scratch/'failure.json').write_text(json.dumps({'complete':False,'traceback':traceback.format_exc()})+'\n');sys.exit(1)
