from pathlib import Path
import json,re,gzip,hashlib,collections
b=Path('experiments/issue-1580/evidence/ci/native-families-14ef1b5f');p=b/'full-run-diagnostic-candidates.json';raw=p.read_bytes();items=json.loads(raw);groups=collections.defaultdict(list)
for item in items:
 text=item['text'];message=re.split(r'\d{4}-\d\d-\d\dT[^ ]+ ',text,maxsplit=1)[-1]
 if '^[[36;1m' in text or '\x1b[36;1m' in text:category='workflow shell source echo'
 elif re.search(r'WARNING: .+ has \d+ lines \(approaching',message):category='source file size headroom warning'
 elif 'unsafe-libyaml' in text or 'unmaintained' in text or 'RUSTSEC-' in text:category='dependency advisory'
 else:category='other diagnostic requiring review'
 item['classification']=category;groups[category].append(item)
print('TOTAL',len(items))
for category,rows in groups.items():
 print('CATEGORY',category,'COUNT',len(rows))
 dedup={}
 for row in rows:
  text=re.split(r'\d{4}-\d\d-\d\dT[^ ]+ ',row['text'],maxsplit=1)[-1]
  dedup.setdefault(text,[]).append((row['runId'],row['line']))
 for text,locations in dedup.items():print(json.dumps({'message':text,'locations':locations}))
packed=gzip.compress(raw,mtime=0);target=p.with_suffix('.json.gz');target.write_bytes(packed);p.unlink()
receipt={'file':target.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'candidateCount':len(items),'categories':{k:len(v) for k,v in groups.items()},'classificationComplete':False,'allLogLinesLiterallyRead':False,'allWarningsResolved':False,'fullIssueComplete':False}
(b/'diagnostic-review.json').write_text(json.dumps(receipt,indent=2)+'\n')
# Keep the annotated classification separate, compact, and bounded by candidate count.
(b/'classified-diagnostics.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in items))
print('ARCHIVED',json.dumps(receipt))
