from pathlib import Path
import subprocess,json,hashlib,datetime
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'experiments/issue-1580/evidence/checks/registry-uncertainty/independent-ci-freshness'
p.mkdir(parents=True,exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
request=('Assess the validation evidence for pull request 1581. The published commit is 14ef1b5f. Its completed native core job passed 102 workflow-contract tests, including changelog I/O behavior. A later local commit 899de4d12 changes registry failure handling in two release CLIs and adds a new native release-registry job. Another local commit 00f954c7b repairs its unpublished-candidate HTTP fixture. Neither local commit has been pushed. Is registry failure handling verified by the completed core job? Explain what the observed result establishes and what evidence is still needed for the local changes.')
frozen={'schemaVersion':1,'frozenAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':head,'frozenSubstantiveUnit':'CI freshness/taxonomy','fixedDenominator':20,'maxAttempts':1,'maxSteps':4,'nodeHeapMiB':256,'request':request,'externallySuppliedConclusion':False,'externallySuppliedPatch':False,'acceptanceCriteria':['Distinguish the observed published-source core behavior from subsequent local source changes.','Explain whether the new registry behavior has actually executed and identify the needed source-bound evidence.','Produce an independent useful rationale rather than echoing the facts or an unknown/refusal response.']}
(p/'frozen-request.json').write_text(json.dumps(frozen,indent=2)+'\n')
args=['node','--max-old-space-size=256','experiments/js_dogfood/drive.mjs','--dir',str(r),'--steps','4',request]
result=subprocess.run(args,cwd=r,text=True,capture_output=True)
for suffix,value in [('stdout',result.stdout),('stderr',result.stderr)]: (p/('response.'+suffix+'.log')).write_text(value)
record={'sourceCommit':head,'argv':args,'exitCode':result.returncode,'stdoutSha256':hashlib.sha256(result.stdout.encode()).hexdigest(),'stderrSha256':hashlib.sha256(result.stderr.encode()).hexdigest(),'accepted':False,'acceptancePendingHumanReview':True,'autonomousAuthorshipCredit':0,'fullIssueComplete':False}
(p/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2));print('FULL STDOUT',result.stdout);print('FULL STDERR',result.stderr)
