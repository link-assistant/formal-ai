from pathlib import Path
import json
r=Path('/tmp/gh-issue-solver-1794900398048')
for name in ['experiments/issue-1580/release-registry/cli_regressions.py','experiments/issue-1580/release-registry/Cargo.toml']:
 print('FILE',name)
 for i,l in enumerate((r/name).read_text().splitlines(),1):print(f'{i:04d} {l}')
p=Path('/tmp/issue-1580-research/release-io-batch-14ef1b5f-ci/worker.log')
print('CI TAIL');print('\n'.join(p.read_text().splitlines()[-5:]))
