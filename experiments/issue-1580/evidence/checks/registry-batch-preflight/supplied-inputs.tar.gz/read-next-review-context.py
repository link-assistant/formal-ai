from pathlib import Path
import json
r=Path('/tmp/gh-issue-solver-1794900398048')
for name in ['docs/case-studies/issue-1580/templates/rust-source-review-progress.json','experiments/issue-1580/evidence/checks/rust-source-review/logs.json']:
 data=json.loads((r/name).read_text());print('FILE',name,'TYPE',type(data).__name__);
 if isinstance(data,list):
  print('LOG COUNT',len(data),'LAST',json.dumps(data[-3:]));continue
 print('KEYS',list(data))
 for k,v in data.items():
  if not isinstance(v,list) or k in ['upstreamReports']: print(k,json.dumps(v)[:9000])
for name in ['experiments/issue-1580/work-plan.md','docs/case-studies/issue-1580/README.md']:
 lines=(r/name).read_text().splitlines();print('FILE',name,'LINES',len(lines))
 indexes=set(range(min(145,len(lines)))) if 'work-plan' in name else set()
 for i,line in enumerate(lines):
  if any(k in line.lower() for k in ['upstream','registry','14ef','899de','00f954','source review','native-type']): indexes.update(range(max(0,i-2),min(len(lines),i+5)))
 for i in sorted(indexes): print(f'{i+1:04d} {lines[i]}')
for name in ['experiments/issue-1580/evidence/checks/calendar-dispatch-registration/independent-test-reasoning/frozen-request.json','experiments/formal_ai_subagent/probe.mjs']:
 p=r/name
 if p.exists():
  print('FILE',name)
  for i,line in enumerate(p.read_text().splitlines(),1):print(i,json.dumps(line))
