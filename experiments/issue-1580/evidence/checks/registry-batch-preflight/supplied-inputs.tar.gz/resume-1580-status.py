from pathlib import Path
import json,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048')
def run(args):
 print('COMMAND',json.dumps(args),flush=True)
 p=subprocess.run(args,cwd=r,text=True,capture_output=True)
 print(p.stdout);print(p.stderr);print('STATUS',p.returncode)
 if p.returncode: raise SystemExit(p.returncode)
run(['git','branch','--show-current'])
run(['git','status','--short'])
run(['git','log','-3','--format=%H %s'])
run(['gh','run','view','44686151225','--repo','link-assistant/formal-ai','--json','status,conclusion,headSha,jobs'])
for name in ['experiments/issue-1580/formal-command.mjs','experiments/formal_ai_subagent/probe.mjs']:
 p=r/name
 print('FILE',name)
 for i,line in enumerate(p.read_text().splitlines(),1): print(f'{i:04d} {line}')
