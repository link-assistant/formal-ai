from pathlib import Path
import subprocess, json, datetime
root = Path('/tmp/issue-1580-research/extracted-module-witness-validation')
root.mkdir(exist_ok=True)
prefix = '/tmp/issue-1580-research/extracted-module-witness'
outcomes = []
def run(label, args, expected=0):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (root/(label+'.stdout')).open('wb') as out, (root/(label+'.stderr')).open('wb') as err:
        result = subprocess.run(args, stdout=out, stderr=err)
    row = dict(label=label,command=args,exitCode=result.returncode,expected=expected,
               startedAt=started,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
    outcomes.append(row)
    (root/'progress.json').write_text(json.dumps(outcomes,indent=2)+'\n')
    print(json.dumps(row), flush=True)
    if expected == 'nonzero':
        assert result.returncode != 0, label
    else:
        assert result.returncode == expected, label
    return result.returncode
tests = ['rust/tests/web/rust-specification-fixture-integrity.test.mjs',
         'rust/tests/web/rust-specification-unicode-identifiers.test.mjs']
for i, file in enumerate(tests):
    run('before-'+str(i), ['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',file], 'nonzero')
run('complete-review-and-refresh',['node','--max-old-space-size=256',
    'experiments/issue-1580/review-extracted-module-witness.mjs',prefix,'--refresh'])
for i, file in enumerate(tests):
    run('after-'+str(i), ['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',file])
run('all-javascript-local-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs'])
(root/'outcome.json').write_text(json.dumps(dict(complete=True,passed=True,observations=outcomes),indent=2)+'\n')
