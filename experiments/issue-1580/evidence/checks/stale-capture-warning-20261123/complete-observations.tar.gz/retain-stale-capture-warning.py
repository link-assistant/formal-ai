from pathlib import Path

path = Path('rust/src/source_walk.rs')
text = path.read_text()
old = '''        if let Some(detail) = read.detail {
            outcome.detail = detail;
        }
'''
new = '''        if let Some(detail) = read.detail
            && (read.items.is_empty() || age <= bounds.max_capture_age_seconds)
        {
            outcome.detail = detail;
        }
'''
assert text.count(old) == 1
path.write_text(text.replace(old, new))
path = Path('js/worker/formal_ai_worker_source_walk.js')
text = path.read_text()
old = '      if (read.detail) outcome.detail = read.detail;'
new = '      if (read.detail && (!read.items?.length || !(age > bounds.maxCaptureAgeSeconds))) outcome.detail = read.detail;'
assert text.count(old) == 1
path.write_text(text.replace(old, new))
