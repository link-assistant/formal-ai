import hashlib, io, json, tarfile
from pathlib import Path

root = Path.cwd()
scratch = Path('/tmp/issue-1580-research')

path = root / 'experiments/issue-1580/evidence/ci/cec9207c3-terminal/manifest.json'
data = json.loads(path.read_text())
def render(value, level=0):
    prefix = '  ' * level
    if isinstance(value, dict):
        if all(not isinstance(child, (dict, list)) for child in value.values()):
            return json.dumps(value, ensure_ascii=False)
        return '{\n' + ',\n'.join('  ' * (level + 1) + json.dumps(key) + ': ' + render(child, level + 1) for key, child in value.items()) + '\n' + prefix + '}'
    if isinstance(value, list):
        return '[\n' + ',\n'.join('  ' * (level + 1) + render(child, level + 1) for child in value) + '\n' + prefix + ']'
    return json.dumps(value, ensure_ascii=False)
encoded = render(data) + '\n'
assert json.loads(encoded) == data
assert len(encoded.splitlines()) <= 1500
path.write_text(encoded)

destination = root / 'experiments/issue-1580/evidence/checks/stale-capture-warning-20261123'
destination.mkdir(parents=True, exist_ok=True)
archive = destination / 'complete-observations.tar.gz'
assert not archive.exists()
files = [scratch / name for name in (
    'stale-warning-before.log', 'stale-warning-after.log',
    'stale-source-detail.test.mjs', 'stage-stale-warning-control.py',
    'retain-stale-capture-warning.py', 'stale-repair-first.log',
    'finish-stale-warning-batch.py',
)]
files += sorted(p for p in (scratch / 'corrected-observation-full-gates').rglob('*') if p.is_file())
records = []
with tarfile.open(archive, 'w:gz', compresslevel=6) as stream:
    for source in files:
        payload = source.read_bytes()
        name = str(source.relative_to(scratch))
        info = tarfile.TarInfo(name)
        info.size = len(payload)
        info.mode = 0o644
        stream.addfile(info, io.BytesIO(payload))
        records.append({'path': name, 'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()})
with tarfile.open(archive, 'r:gz') as stream:
    assert len(stream.getmembers()) == len(records)
    for row in records:
        payload = stream.extractfile(row['path']).read()
        assert len(payload) == row['bytes'] and hashlib.sha256(payload).hexdigest() == row['sha256']
(destination / 'members.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in records))
manifest = {'sourceBefore': '423be15fcdb4c14b828c9bc287db6d8d559fa03b',
            'scope': 'Actual failing stale-warning reproduction, passing focused repair, and complete preceding clean local gate observation (87 pass, 2 manifest-size failures, 54 hosted exclusions).',
            'independentAuthorshipCredit': 0, 'roundTripVerified': True,
            'members': len(records), 'inventory': 'members.jsonl',
            'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')

path = root / 'docs/case-studies/issue-1580/ci-observation-boundaries-20261123.md'
with path.open('a') as out:
    out.write('''
The corrected clean `423be15fc` replay passes the 18 procedure cases and again
has 87 gate passes, two failures and 54 hosted exclusions. This time both failures
identify the terminal evidence manifest's 3,462 lines, rather than the worker
budget. Compacting individual inventory records preserves the complete parsed
manifest object, all hashes and the original archive, while satisfying the same
file-size limit.

A separate actual regression control catches a stale-capture age warning being
overwritten by the accepted URL. The shared native and worker walkers now keep
that warning when a stale capture contributes items; failed extraction can still
report its own failure. The new worker regression fails before the change and
passes afterward, together with the recovered-article control. Formatting and
source/projection currency checks pass. The full 19-case suite and complete gate
inventory still require their next clean replay. The complete preceding gate
streams, failed reproduction, passing controls and supplied scripts are retained
with round-trip hashes in
`experiments/issue-1580/evidence/checks/stale-capture-warning-20261123/`.
''')
print(json.dumps({'manifestLines': len(encoded.splitlines()), 'evidence': manifest}))
