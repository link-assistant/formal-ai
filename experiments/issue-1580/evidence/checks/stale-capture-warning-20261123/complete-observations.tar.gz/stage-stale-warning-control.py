from pathlib import Path
import json, re, sys

root = Path.cwd()
source = root / 'rust/tests/web/procedural-runtime-parity.test.mjs'
body = source.read_text()
addition = '''test("a contributing stale procedure retains its capture-age warning", async () => {
  const context = await bootWorker(new Map([[RUSSIAN_API, { body: RUSSIAN_CAPTURE }]]));
  const initial = plain(await answerRussian(context));
  assert.equal(initial.guide.steps.length, 2, initial.content);
  const retained = await evaluate(context, `
    for (const [url, capture] of sourceWalkCaptureCache) {
      sourceWalkCaptureCache.set(url, { ...capture, fetchedAt: "1" });
    }
    sourceWalkCaptureCache.size
  `);
  assert.ok(retained > 0);
  const stale = plain(await answerRussian(context, { offline: true }));
  assert.equal(stale.guide.steps.length, 2, stale.content);
  assert.ok(stale.guide.steps.every(step => step.fetchedAt === "1"));
  const outcome = stale.guide.outcomes.find(row => row.sourceId === "wikihow");
  assert.equal(outcome.status, "contributed");
  assert.match(outcome.detail, /stale_capture age_seconds=/u);
  assert.ok(outcome.detail.includes(RUSSIAN_API), outcome.detail);
});

'''
anchor = 'test("a recovered procedure reports the accepted article after rejecting an unrelated capture",'
assert body.count(anchor) == 1 and 'a contributing stale procedure' not in body
body = body.replace(anchor, addition + anchor)
if sys.argv[1:] == ['--commit-test']:
    source.write_text(body)
else:
    body = re.sub(r'from "(\.[^"]+)"', lambda match: 'from ' + json.dumps(str((source.parent / match.group(1)).resolve())), body)
    body = body.replace('const REPO_ROOT = path.resolve(import.meta.dirname, "../../..");', 'const REPO_ROOT = ' + json.dumps(str(root)) + ';')
    target = Path('/tmp/issue-1580-research/stale-source-detail.test.mjs')
    target.write_text(body)
    print(target)
