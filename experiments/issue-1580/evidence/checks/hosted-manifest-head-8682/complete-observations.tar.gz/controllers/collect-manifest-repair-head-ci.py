import datetime
import gzip
import json
import subprocess
import time
from pathlib import Path

root = Path('/tmp/issue-1580-research/manifest-repair-head-ci')
root.mkdir(exist_ok=True)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
repository = 'link-assistant/formal-ai'
records = []

def capture(label, command):
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    for stream, value in [('stdout', result.stdout), ('stderr', result.stderr)]:
        (root / f'{label}.{stream}.gz').write_bytes(gzip.compress(value, mtime=0))
    records.append({'label': label, 'command': command, 'exitCode': result.returncode})
    (root / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    if result.returncode:
        raise RuntimeError(f'{label} failed: {result.stderr.decode(errors="replace")[:2000]}')
    return result.stdout

try:
    terminal_same = 0
    previous = None
    saved = set()
    for observation in range(240):
        runs = json.loads(capture(f'observation-{observation:03}', [
            'gh', 'run', 'list', '--repo', repository, '--branch', 'issue-1580-8d61a32a61e1',
            '--commit', head, '--limit', '100', '--json',
            'databaseId,workflowName,status,conclusion,createdAt,updatedAt,headSha,url,event']))
        assert all(run['headSha'] == head for run in runs)
        (root / 'latest.json').write_text(json.dumps(runs, indent=2) + '\n')
        for run in runs:
            if run['status'] != 'completed' or run['conclusion'] not in ['failure', 'cancelled', 'timed_out', 'action_required']:
                continue
            identity = run['databaseId']
            if identity in saved:
                continue
            capture(f'failed-run-{identity}', ['gh', 'run', 'view', str(identity), '--repo', repository, '--log'])
            capture(f'failed-jobs-{identity}', ['gh', 'api', '--allow-escape-sequences', f'repos/{repository}/actions/runs/{identity}/jobs', '--paginate'])
            saved.add(identity)
        signature = sorted((run['databaseId'], run['status'], run['conclusion']) for run in runs)
        terminal = len(runs) >= 33 and all(run['status'] == 'completed' for run in runs)
        terminal_same = terminal_same + 1 if terminal and signature == previous else 0
        print(json.dumps({'observation': observation, 'head': head, 'runs': len(runs),
                          'pending': sum(run['status'] != 'completed' for run in runs),
                          'failed': len(saved), 'terminalStable': terminal_same}), flush=True)
        previous = signature
        if terminal_same >= 2:
            for run in runs:
                if run['workflowName'] in ['CI/CD Pipeline', 'Layered CI']:
                    capture(f'complete-run-{run["databaseId"]}', ['gh', 'run', 'view', str(run['databaseId']), '--repo', repository, '--log'])
                    capture(f'complete-jobs-{run["databaseId"]}', ['gh', 'api', '--allow-escape-sequences', f'repos/{repository}/actions/runs/{run["databaseId"]}/jobs', '--paginate'])
            capture('pull-request-checks', ['gh', 'pr', 'view', '1581', '--repo', repository,
                    '--json', 'headRefOid,isDraft,mergeStateStatus,statusCheckRollup'])
            outcome = {'head': head, 'complete': True, 'runs': runs,
                       'failedRuns': sorted(saved), 'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()}
            (root / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
            break
        time.sleep(30)
    else:
        raise RuntimeError('Bounded collector exhausted observations with unfinished workflows.')
except Exception as error:
    (root / 'collector-error.json').write_text(json.dumps({'head': head, 'error': str(error)}, indent=2) + '\n')
    raise
