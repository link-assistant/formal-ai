import gzip,hashlib,json,re
from collections import Counter
from pathlib import Path
scratch=Path('/tmp/issue-1580-research')
root=scratch/'manifest-repair-head-ci'
out=scratch/'native-manifest-terminal-review'
out.mkdir(exist_ok=False)
raw=gzip.decompress((root/'failed-run-45109737000.stdout.gz').read_bytes())
(out/'pipeline-original.log').write_bytes(raw)
text=gzip.decompress((root/'failed-jobs-45109737000.stdout.gz').read_bytes()).decode()
decoder=json.JSONDecoder();pages=[];offset=0
while offset<len(text):
    while offset<len(text) and text[offset].isspace():offset+=1
    if offset==len(text):break
    value,end=decoder.raw_decode(text,offset);pages.append(value);offset=end
jobs=[j for page in pages for j in page['jobs']]
summary=[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'startedAt':j['started_at'],'completedAt':j['completed_at'],'failedSteps':[s for s in j.get('steps',[]) if s['conclusion']=='failure']} for j in jobs]
(out/'jobs.json').write_text(json.dumps(summary,indent=2)+'\n')
lines=raw.decode(errors='replace').splitlines()
candidates=[{'line':i+1,'text':s} for i,s in enumerate(lines) if re.search(r'FAILED|failures:|error:|##\[error\]|panicked at|test result: FAILED|warning:',s,re.I)]
(out/'diagnostic-candidates.json').write_text(json.dumps(candidates,indent=2)+'\n')
run=json.loads((root/'latest.json').read_text())
value={'source':'8682a89a84d391d987a967b5764a27c8d1d0c457','runCount':len(run),'runConclusions':dict(Counter(r['conclusion'] for r in run)),'jobCount':len(jobs),'jobConclusions':dict(Counter(j['conclusion'] for j in jobs)),'failedJobs':[j for j in summary if j['conclusion']=='failure'],'nativeJobs':[j for j in summary if 'Native contracts (' in j['name']],'pipelineOriginalBytes':len(raw),'pipelineOriginalLines':len(lines),'pipelineOriginalSha256':hashlib.sha256(raw).hexdigest(),'diagnosticCandidates':len(candidates)}
(out/'summary.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value,indent=2))
print(json.dumps(candidates,indent=2))
