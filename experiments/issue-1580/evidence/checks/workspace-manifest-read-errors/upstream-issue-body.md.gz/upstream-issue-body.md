Workspace release discovery treats every member manifest read failure as an absent member and can select a different release package. This is separate from the table-aware parsing in #155 and workspace support in #36.

Current source: https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/blob/260ae6f826d6bff0cbfe2280098c287a4c09b3f4/scripts/rust-paths.rs#L252 (blob `4f4d9d36b710dc029918ab6ec53c26677174adc6`, observed 2026-11-22T04:09:35.277939+00:00).

```rust
let Ok(member_content) = fs::read_to_string(&manifest) else {
    continue;
};
```

Reproduction layout:

```text
Cargo.toml                  [workspace] members = ["broken", "public"]
broken/Cargo.toml           one byte: ff (invalid UTF-8)
public/Cargo.toml           [package] name = "public", version = "1.2.3"
```

Call `get_package_manifest_path` on the root manifest, directly or through `scripts/get-version.rs --rust-root <fixture-directory>`. The current control flow discards `InvalidData`, then returns `public/Cargo.toml`. Replacing `broken/Cargo.toml` with a directory reaches the same discarded-error branch. Permission errors are also discarded.

Expected: return a read error identifying `broken/Cargo.toml`; inability to read a member is not evidence that it is absent or private. Preserve the existing supported selection of later members when an earlier manifest is genuinely absent, and preserve the existing `publish = false` filtering.

Suggested repair: match the read result, continue only on `ErrorKind::NotFound`, and propagate every other error with the member path. Regression cases should use actual invalid UTF-8 bytes and an actual directory in place of a manifest, with a later valid package that must not be selected; retain a separate missing-member fallback control.

This report is based on the complete source and physical fixture design, not an executed native upstream reproduction. A matching downstream repair and native regression are being prepared in https://github.com/link-assistant/formal-ai/pull/1581; their new hosted execution is still pending. No release or publication effect was performed.
