CI omitted native test inputs and allowed source ownership failures to pass unnoticed. This draft repairs those boundaries, task composition and retained-source behavior, and adds focused native replays. Issue #1580 remains unfinished; keep this PR draft and unmerged.

Fixes #1580

Changes:

- Preserve quoted task passages, request-local constraints, selected-child provenance and unresolved status for unverified drafts. Reuse source-bound calculation and counting evidence.
- Preserve multilingual lookup, explanation, calendar and controlled-language grammar behavior; regenerate maintained JavaScript, TypeScript, Rust and embedded projections through their official writers.
- Admit complete native reasoning, interface, Hive, workflow, benchmark and fixture source closures. Give expensive native contract families independent jobs with two concurrent matrix runners, preserving all 14 targets, single Rust test threads, failure propagation and the existing 20-minute clocks. The default complete runner remains available.
- Accept canonical IPv4 web operands while excluding attachment metadata. Keep equivalent domain-label boundaries in native and browser paths.
- Keep routine wrapper diagnostics in files unless wrapper verbosity is explicit. Forward client flags independently, and retain the original empty-stderr contract.
- Open closed-program sequence search using bounded atoms derived from actual ranked fragment types. Preserve actual IR content IDs and rejection stages when fragments, typing, backends or lowering fail; an empty frontier creates no attempt. Verification requirements remain intact.
- Decode each appended HTTP capture record using its transport or conversation schema. Keep the real Git operations, failed-verifier evidence and existing capture, privacy and ephemeral-memory assertions.
- Enforce execution budgets until the command process group finishes, including children whose parent exited. Preserve root statuses, stdout, stderr and warning-only behavior; terminate lingering workers and report unavailable process inspection.
- Reject failed or partial Git lockfile inventories before any Cargo audit. Preserve strict primary/experiment audit policies and missing-checkout failures.
- Retain pinned template comparisons, executable negative controls and linked upstream reports. Reporting a defect does not establish an upstream repair.

Verification:

- Exact head `7fce5c19` completed 23 workflows: 22 succeeded, including [Layered CI](https://github.com/link-assistant/formal-ai/actions/runs/44652802292). The [pipeline](https://github.com/link-assistant/formal-ai/actions/runs/44652802985) contains an interface failure (`invalid_typed_log_record` at `http_server.rs:505`) and Hive cancellation at the existing 20-minute job clock. Coding passes 32 cases, reasoning 141 and benchmarks 11. Interfaces pass 77/78; Hive completes 30/36 before cancellation. Full logs and exact job identities are retained. Cancelled and unrun cases receive no pass credit.
- The HTTP failure reproduces the test decoding two appended health records as one record. The revised native test reads every record with the appropriate public type. Hosted execution of that unchanged test name at `03ff3a8e8a6999bb436de66dd625b3c637720ba1` remains pending.
- Hive uses the existing longest-first planner over the actual compiled listing, with three exact-filter shards. Thirty measured weights reproduce the retained hosted timestamps; unseen cases have an explicit planning estimate. The focused controls cover every listed case exactly once, deterministic selection, malformed inventories, listing/execution failures and complete planner-input admission. A real disposable Git sparse checkout verifies the exact log needed to reproduce the weights while excluding unrelated archives. Focused controls pass 28/28 and the maintained policy entrypoint passes 81/81. All native Hive cases still require hosted verification.
- A bounded child-process regression fails all six initial controls before the budget repair, then all seven pass. The maintained release loader passes 10 tests, cache controls 12 and budget/registry controls three, with no skips. Fixtures limit memory and lifetime and reap their children. ShellCheck and Rust formatting pass; touched JavaScript gate results are retained. No local Rust build or native execution runs.
- Java's pinned project-version CLI reports success without changing the project version in three parent/comment cases. Both focused controls pass. Rust's pinned desktop checksum command includes the output manifest itself and stale checksum fragments on both GNU and shasum paths. Three focused controls, all 57 maintained template controls and 43 unchanged upstream prerequisite controls pass. These disposable local reproductions establish neither hosted publication nor upstream repair.
- The selected production review now covers all 106 selected diffs, with source/diff identities reverified. This is not a complete review of the whole PR. Java's exact 207-file pinned applicability map is complete (62 active, 145 historical); applicable practice implementation and runtime/dependency acceptance remain unfinished. The partial Rust source review covers 38/373 files (4792 literal lines); the remaining 335 files still need comparison.

Focused reproduction:

```sh
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/native-regression-groups.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-java-project-version.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-rust-desktop-checksums.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/budget-process-lifetime.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/default-branch-build-policy.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/attachment-url-scope.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/rust-specification-unicode-identifiers.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/rust-specification-fixture-integrity.test.mjs
node experiments/formal_ai_subagent/local-gates.mjs
```

Hosted native CI executes `coding_contracts`, the original linked-list named-gap regression, wrapper flag-scope checks and the retained interface/Hive contracts. Rejected IR tests assert actual IDs, exact stages and absence of a selected artifact; the admission test fails before its source closure is added.

Earlier browser source-binding evidence uses a labeled production-worker harness with external requests blocked:

![Before: the Spanish definition frame is skipped](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/screenshots/issue-1580/meaning-hydration-before.png?raw=true)

![After: the definition routes to search and the unresolved sibling answer remains intact](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/screenshots/issue-1580/meaning-hydration-after.png?raw=true)

Unfinished acceptance is tracked in the [work plan](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/experiments/issue-1580/work-plan.md) and [case study](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/README.md): current-head hosted CI, the remaining original native and budget contracts, all eight complete template comparisons/applicability decisions, dependency migrations and warnings, historical cache/Docker evidence, live delivery/model identity, general binding/provenance and complete PR review. The strict original-source replay union remains 27/53; the completed cases in the cancelled run add no new qualifying original-source replay. Independently accepted Formal AI reasoning remains 0/20; supplied commands, patches and reviews earn no independent credit.
