//! Regression coverage for issue #1079: the false positives, false negatives,
//! warnings and errors found by auditing every CI/CD run at `main` head
//! `f971b8205`, and by comparing this repository's whole file tree against the
//! five `link-foundation/*-ai-driven-development-pipeline-template`
//! repositories.
//!
//! Two of the defects were gates that could not fail, which is the worst kind
//! of green check -- it is indistinguishable from a gate that passed.
//!
//! * **D2.** `scripts/check-rust-dependencies.sh` ran `cargo audit` with no
//!   `--deny warnings`. `cargo audit` classifies `unmaintained`, `unsound` and
//!   `yanked` as warnings, and a warning does not move the exit status: it
//!   prints `warning: N allowed warnings found` and exits 0. The gate was green
//!   for the whole time `Cargo.lock` pinned `chacha20 0.10.1`, a release its
//!   own authors had yanked. A yanked crate carries no advisory ID, so it
//!   cannot be silenced by an `ignore` entry either -- the only way past the
//!   line is to change the lockfile.
//! * **D3.** `.github/zizmor.yml` has declared `'*': hash-pin` since issue
//!   #1076, and that policy had never once been applied to a container image.
//!   It configures `unpinned-uses`, which reads *action* references only;
//!   images belong to the separate `unpinned-images` audit, which zizmor
//!   classifies as Pedantic, and the job ran `--persona regular`. So
//!   `docker://rhysd/actionlint:1.7.12` was a mutable third-party tag executing
//!   with the repository checked out, under a written policy forbidding exactly
//!   that.
//! * **D6.** The zizmor job left `version:` at its default while two comments
//!   told a maintainer to reproduce with `zizmor==1.30.0`. `zizmor-action`
//!   resolves versions from a static table shipped inside the action, and
//!   v0.6.2's table stops at 1.29.0 -- its `latest` row is literally the same
//!   digest as its `1.29.0` row. "Reproduce locally with X" is only true when
//!   CI runs X.
//!
//! D3 and D6 reproduce unchanged in all five templates and are filed against
//! each; the reports and the filed issue URLs are in
//! `dev/log/issues/1079/pulls/1080/upstream-reports/README.md`. The full
//! reconstruction is in `dev/log/issues/1079/pulls/1080/README.md`.

#[path = "pinned_tool_images/image_policy.rs"]
mod image_policy;

#[path = "pinned_tool_images/agent_cli.rs"]
mod agent_cli;

use std::fs;
use std::path::Path;

fn repository_root() -> std::path::PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("the repository root sits above the crate")
        .canonicalize()
        .expect("physical repository root")
}

fn yaml_step_code(line: &str) -> &str {
    let line = line.trim();
    let code = line.strip_prefix("- ").unwrap_or(line);
    code.strip_prefix("run:").unwrap_or(code).trim()
}

fn repository_file(path: &str) -> String {
    fs::read_to_string(format!("{}/../{path}", env!("CARGO_MANIFEST_DIR")))
        .unwrap_or_else(|error| panic!("failed to read {path}: {error}"))
        .replace("\r\n", "\n")
}

/// Strip a YAML line's trailing comment, keeping `#` that a quoted scalar owns.
///
/// Only the unquoted case matters here: every image reference in these
/// workflows is a plain scalar, and the marker this sweep looks for lives in
/// the comment it removes -- so the comment is read separately rather than
/// thrown away.
fn code_and_comment(line: &str) -> (&str, &str) {
    match line.split_once(" #") {
        Some((code, comment)) => (code, comment),
        None => (line, ""),
    }
}

/// Every YAML file anywhere under `.github/`, in a stable order.
///
/// The sweeps below read the directory rather than a hand-written list: a
/// defect that only holds for the files someone remembered to enumerate is
/// not an invariant, and every one of these defects was originally introduced
/// by a file nobody thought to look at.
fn github_yaml_files() -> Vec<std::path::PathBuf> {
    let mut stack = vec![repository_root().join(".github")];
    let mut files = Vec::new();
    while let Some(dir) = stack.pop() {
        for entry in fs::read_dir(&dir).expect("readable .github directory") {
            let path = entry.expect("directory entry").path();
            if path.is_dir() {
                stack.push(path);
            } else if path
                .extension()
                .is_some_and(|ext| ext == "yml" || ext == "yaml")
            {
                files.push(path);
            }
        }
    }
    files.sort();
    files
}

/// Every container image `.github/` runs, as `(file, line number, reference,
/// trailing comment)`.
///
/// Three spellings reach a registry: a `docker://` step, a job-level
/// `container:`, and a service's `image:`. zizmor's `unpinned-images` audit
/// covers all three, so this sweep does too -- a fix applied only to the
/// spelling that happened to be in the tree is not a fix.
fn image_references() -> Vec<(String, usize, String, String)> {
    let mut found = Vec::new();

    for path in github_yaml_files() {
        let name = path
            .strip_prefix(repository_root())
            .unwrap_or(&path)
            .to_string_lossy()
            .into_owned();
        let body = fs::read_to_string(&path).expect("readable workflow");
        for (index, line) in body.replace("\r\n", "\n").lines().enumerate() {
            let trimmed = line.trim();
            if trimmed.starts_with('#') {
                continue;
            }
            let (code, comment) = code_and_comment(trimmed);
            let code = code.trim();
            let reference = if let Some(rest) = code.strip_prefix("- uses: docker://") {
                rest
            } else if let Some(rest) = code.strip_prefix("uses: docker://") {
                rest
            } else if let Some(rest) = code.strip_prefix("container:") {
                rest.trim()
            } else if let Some(rest) = code.strip_prefix("image:") {
                rest.trim()
            } else {
                continue;
            };
            if reference.is_empty() || reference.starts_with("${{") {
                continue;
            }
            found.push((
                name.clone(),
                index + 1,
                reference.to_owned(),
                comment.trim().to_owned(),
            ));
        }
    }

    found
}

/// D2. The audit that could not fail.
#[test]
fn the_rust_dependency_audit_treats_a_warning_as_a_finding() {
    let script = repository_file("scripts/check-rust-dependencies.sh");

    let invocation = script
        .lines()
        .find(|line| line.trim_start().starts_with("run_audit cargo audit"))
        .expect("check-rust-dependencies.sh must invoke `cargo audit` through `run_audit`");
    assert!(
        invocation.contains("--deny warnings"),
        "`{}` exits 0 on `unmaintained`, `unsound` and `yanked` findings -- it \
         prints \"warning: N allowed warnings found\" and returns success. This \
         gate was green for the whole time Cargo.lock pinned the yanked \
         `chacha20 0.10.1`. Add `--deny warnings` (issue #1079, defect D2).",
        invocation.trim()
    );
    assert!(
        !invocation.contains("--no-yanked"),
        "`--no-yanked` turns the yanked-crate check off entirely, which is the \
         one class `[advisories] ignore` cannot silence -- a yanked release \
         carries no advisory ID. Suppressing it here would put the gate back \
         where issue #1079 found it."
    );
}

/// The proof parser runs on both GNU sed in CI and BSD sed on macOS.
#[test]
fn the_dependency_audit_proof_parser_uses_portable_extended_sed() {
    let script = repository_file("scripts/check-rust-dependencies.sh");

    assert_eq!(
        script.matches("sed -E -n").count(),
        3,
        "all three proof fields must use extended regular expressions, whose `+` and grouping \
         syntax are shared by GNU and BSD sed"
    );
    assert!(
        !script.contains("[[:space:]]\\+") && !script.contains("[^\"]\\+"),
        "basic-sed `\\+` is a GNU extension in this context; on macOS it made every valid audit \
         proof look missing"
    );
}

/// Every ignored advisory carries exactly one proof, and a `blocked-upstream`
/// proof names a report that exists.
///
/// `check-rust-dependencies.sh` re-derives each proof from `cargo tree` on
/// every run, so the property is already enforced where it matters. This test
/// covers the part `cargo tree` cannot: that the *shape* of each entry is one
/// of the two honest forms. An ignore with no proof, or with both, would be
/// caught by the script -- but only on a machine that can resolve the whole
/// dependency graph, and a config defect should fail in the unit suite.
#[test]
fn every_ignored_advisory_carries_exactly_one_proof() {
    let config = repository_file(".cargo/audit.toml");

    // The same reading `scripts/check-rust-dependencies.sh` does: collect every
    // quoted value inside `ignore = [...]`, which TOML allows to be written on
    // one line or spread over several.
    let mut ignored: Vec<String> = Vec::new();
    let mut collecting = false;
    for line in config.lines() {
        if line.trim_start().starts_with("ignore") && line.contains('=') {
            collecting = true;
        }
        if !collecting {
            continue;
        }
        let code = line.split_once('#').map_or(line, |(code, _)| code);
        ignored.extend(
            code.split('"')
                .skip(1)
                .step_by(2)
                .filter(|value| value.starts_with("RUSTSEC-"))
                .map(str::to_owned),
        );
        if code.contains(']') {
            break;
        }
    }

    assert!(
        !ignored.is_empty(),
        ".cargo/audit.toml must keep its `ignore` list parseable by the same \
         reading `scripts/check-rust-dependencies.sh` uses"
    );

    for advisory in &ignored {
        let unreachable = config.contains(&format!("# {advisory} unreachable = \""));
        let blocked = config.contains(&format!("# {advisory} blocked-upstream = \""));

        assert!(
            unreachable || blocked,
            ".cargo/audit.toml ignores {advisory} without a proof line. Write \
             one of:\n  # {advisory} unreachable = \"<crate>@<version>\"\n  \
             # {advisory} blocked-upstream = \"<crate>@<version>\" \
             report = \"<url>\"\nAn advisory that can be neither proven \
             unreachable nor traced to a filed upstream report must be fixed, \
             not ignored (issue #1079)."
        );
        assert!(
            !(unreachable && blocked),
            ".cargo/audit.toml proves {advisory} both ways. An advisory is \
             either unreachable or blocked upstream, never both -- the two \
             forms expire in opposite directions, so an entry claiming both \
             can never expire at all (issue #1079)."
        );

        if blocked {
            let report = config
                .lines()
                .find(|line| line.contains(&format!("# {advisory} blocked-upstream = \"")))
                .and_then(|line| line.split_once("report = \""))
                .and_then(|(_, rest)| rest.split('"').next())
                .unwrap_or("");
            assert!(
                report.starts_with("https://github.com/") && report.contains("/issues/"),
                ".cargo/audit.toml ignores {advisory} as blocked upstream, but \
                 `report = {report:?}` is not a filed report. \"Someone should \
                 fix this upstream\" is not a report; a URL is (issue #1079)."
            );
        }
    }
}

/// The evidence bundle is part of the deliverable, not a by-product of it.
///
/// Issue #1079 asks for the data to be collected into
/// `dev/log/issues/1079/pulls/1080/`, for every defect to be traced to a root
/// cause, and for a report to be filed upstream wherever a template shares the
/// defect. A claim about an upstream repository that nobody can check is worth
/// less than no claim, so each report keeps its reproduction here and the
/// index records where it was filed.
#[test]
fn the_upstream_reports_are_recorded_with_the_issues_they_were_filed_as() {
    let bundle = "dev/log/issues/1079/pulls/1080";
    let index = repository_file(&format!("{bundle}/upstream-reports/README.md"));

    for template in ["rust", "js", "python", "php", "csharp"] {
        assert!(
            index.contains(&format!(
                "{template}-ai-driven-development-pipeline-template"
            )),
            "{bundle}/upstream-reports/README.md must record what the sweep \
             found in the {template} template -- issue #1079 asks for all five \
             to be compared, and \"nothing found\" is a result that has to be \
             written down too"
        );
    }

    // Every report body in the directory is linked from the index, so a report
    // cannot be written, filed and then lost.
    let dir = format!(
        "{}/../{bundle}/upstream-reports",
        env!("CARGO_MANIFEST_DIR")
    );
    let mut bodies = 0_usize;
    for entry in fs::read_dir(&dir).expect("upstream-reports directory") {
        let path = entry.expect("directory entry").path();
        if path.extension().is_none_or(|extension| extension != "md") {
            continue;
        }
        let name = path.file_name().unwrap().to_string_lossy().into_owned();
        if name == "README.md" {
            continue;
        }
        bodies += 1;
        assert!(
            index.contains(&name),
            "{name} is an upstream report the index does not list; add it to \
             {bundle}/upstream-reports/README.md with the issue it was filed as"
        );
    }
    assert!(
        bodies >= 8,
        "expected the eight report bodies this sweep produced -- six against \
         the pipeline templates and two against the Agent CLI (D11) -- found \
         {bodies}"
    );
}

/// `actions/checkout` writes the job's token into `.git/config` as an
/// `http.extraheader`, where it stays for the rest of the job. Every later
/// step -- and every tool any of them shells out to -- can read it, and
/// anything that archives the workspace carries it out of the run. zizmor
/// calls this `artipacked`, and reported it 46 times here before this sweep.
///
/// All five `link-foundation/*-ai-driven-development-pipeline-template`
/// repositories set `persist-credentials: false`; this one did not, at 46 of
/// its 48 checkouts. It is a Low-confidence finding, so neither of the two
/// live gates was ever going to report it -- the default pass floors
/// confidence at medium and the pedantic pass at high. That is exactly why it
/// needs a test: an invariant no gate enforces is a comment.
///
/// Four checkouts keep the credential because a later step in the same job
/// pushes with it. Each says so in a comment, and the cap below is what stops
/// a fifth from being added silently.
///
/// The sweep runs in both directions, because the first pass of it broke two
/// releases: `auto-release` and `manual-release` call
/// `scripts/version-and-commit.rs`, which ends in `git push` and
/// `git push --tags`, and `scripts/git-config.rs` sets only the committer
/// identity, so those two jobs push with exactly the credential the input
/// removes. Dropping a credential a job needs fails at release time, on
/// `main`, in the one workflow no pull request exercises -- so the direction
/// that matters more is the one that checks that a job which pushes still has
/// something to push with.
#[test]
fn every_checkout_drops_its_credential_unless_it_pushes() {
    let mut exceptions = Vec::new();
    let mut swept = 0_usize;

    for path in github_yaml_files() {
        let name = path
            .strip_prefix(repository_root())
            .unwrap_or(&path)
            .to_string_lossy()
            .into_owned();
        let body = fs::read_to_string(&path).expect("readable workflow");
        let body = body.replace("\r\n", "\n");
        let lines: Vec<&str> = body.lines().collect();

        for (index, line) in lines.iter().enumerate() {
            if !line.contains("actions/checkout@") || line.trim_start().starts_with('#') {
                continue;
            }

            // A `- uses:` line opens the step, so its sibling keys sit one
            // level deeper; a bare `uses:` is already at that level.
            let indent = line.len() - line.trim_start().len();
            let key_indent = if line.trim_start().starts_with("- ") {
                indent + 2
            } else {
                indent
            };

            let mut drops_credential = false;
            for following in &lines[index + 1..] {
                if following.trim().is_empty() {
                    continue;
                }
                let following_indent = following.len() - following.trim_start().len();
                if following_indent < key_indent || following.trim_start().starts_with("- ") {
                    break;
                }
                if following.contains("persist-credentials: false") {
                    drops_credential = true;
                    break;
                }
            }

            if drops_credential {
                swept += 1;
                continue;
            }

            // An exception has to be argued for where it is written, not in a
            // list somewhere else that drifts out of date.
            let reason: String = lines[..index]
                .iter()
                .rev()
                .take_while(|previous| previous.trim_start().starts_with('#'))
                .map(|previous| previous.trim_start().trim_start_matches('#'))
                .collect();
            assert!(
                reason.contains("#1079") && reason.contains("persist-credentials"),
                "{name}:{} keeps its checkout credential without a comment \
                 saying why. Set `persist-credentials: false`, or, if a later \
                 step in this job pushes with it, write the reason directly \
                 above the step and name issue #1079 (issue #1079)",
                index + 1
            );
            exceptions.push(format!("{name}:{}", index + 1));
        }
    }

    assert!(
        swept >= 44,
        "expected the 44 swept checkouts, found {swept}: a checkout that \
         stopped being read by this sweep is a checkout that stopped being \
         checked"
    );
    // Five pushing jobs, plus the two the version-currency and E2E-isolation
    // work added: `dependencies-latest` (create-pull-request pushes its
    // branch) and `e2e-isolation` (its orphan branch is pushed through the
    // retrying helper). Each carries its #1079 reason above the checkout.
    let dormant_retained = exceptions
        .iter()
        .filter(|entry| entry.starts_with(".github/workflows/release-staged.yml:"))
        .count();
    assert_eq!(
        dormant_retained, 2,
        "exactly the two checked dormant root writers retain credentials"
    );
    let staged = repository_file(".github/workflows/release-staged.yml");
    for role in ["auto_prepare-source", "manual_prepare-source"] {
        let body = super::workflow_fixtures::job_block(&staged, role);
        let lines: Vec<&str> = body.lines().collect();
        assert!(root_push_credential_is_retained(&lines));
    }
    assert!(
        exceptions.len() - dormant_retained <= 7,
        "only the seven pushing jobs may keep their checkout credential, found \
         {}: {exceptions:?}",
        exceptions.len()
    );
}

/// Anything that writes to the remote over git -- rather than over the API,
/// which reads its token from the environment instead of from `.git/config`.
const REMOTE_GIT_WRITES: [&str; 4] = [
    "git push",
    // Issue #1081 (D13) moved one `git push` behind a rebase-and-retry helper.
    // A push through a script is still a push, and a sweep that only knows the
    // literal command answers "no job here pushes" the moment one is wrapped --
    // which would have dropped `external-benchmarks` out of this count in the
    // same commit that made its push more reliable.
    "scripts/push-to-shared-branch.sh",
    "scripts/version-and-commit.rs",
    "peter-evans/create-pull-request",
];

/// The converse of the sweep above, and the more expensive direction to get
/// wrong: a job that drops a credential a later step pushes with fails on
/// `main` at release time, in a workflow no pull request runs.
///
/// Rather than trusting a list of which jobs push, this reads each job body
/// and asks whether anything in it writes to the remote over git. A job that
/// does must keep its checkout credential. The composite author's explicit
/// selected-token helper is verified separately below; `scripts/git-config.rs`
/// alone supplies committer identity, not authentication.
fn root_push_credential_is_retained(job: &[&str]) -> bool {
    let mut starts: Vec<usize> = job
        .iter()
        .enumerate()
        .filter_map(|(index, line)| (line.starts_with("      - ")).then_some(index))
        .collect();
    if job[..starts.first().copied().unwrap_or(job.len())]
        .iter()
        .any(|line| line.trim().starts_with("working-directory:"))
    {
        return false;
    }
    starts.push(job.len());
    let mut root_credential = false;
    let mut observed_push = false;
    for window in starts.windows(2) {
        let step = &job[window[0]..window[1]];
        let active: Vec<&str> = step
            .iter()
            .copied()
            .filter(|line| !line.trim_start().starts_with('#'))
            .collect();
        if active.iter().any(|line| line.contains("actions/checkout@")) {
            let path = active
                .iter()
                .find_map(|line| line.trim().strip_prefix("path:"))
                .map_or(".", str::trim);
            if path.contains("${{") || path.contains("..") || path.starts_with('/') {
                return false;
            }
            if path == "." || path.is_empty() {
                let persistence = active
                    .iter()
                    .find_map(|line| line.trim().strip_prefix("persist-credentials:"))
                    .map(str::trim);
                if !matches!(persistence, None | Some("true")) {
                    root_credential = false;
                    continue;
                }
                let token = active
                    .iter()
                    .find_map(|line| line.trim().strip_prefix("token:"))
                    .map(str::trim);
                root_credential = matches!(
                    token,
                    None | Some("${{ github.token }}" | "${{ secrets.GITHUB_TOKEN }}")
                );
            }
        }
        if active
            .iter()
            .any(|line| REMOTE_GIT_WRITES.iter().any(|write| line.contains(write)))
        {
            if !root_credential
                || active.iter().any(|line| {
                    line.trim().starts_with("working-directory:")
                        || yaml_step_code(line)
                            .split([';', '&', '|'])
                            .any(|part| part.trim().starts_with("cd "))
                        || line.contains("git -C ")
                })
            {
                return false;
            }
            observed_push = true;
        }
    }
    observed_push
}

#[test]
fn every_job_that_pushes_still_has_a_credential_to_push_with() {
    let mut pushing_jobs = Vec::new();
    // Logical original writer obligations retain their checked physical staged producer.
    let physical_release = repository_file(".github/workflows/release.yml");
    if physical_release.contains("uses: ./.github/workflows/release-staged.yml") {
        let staged = repository_file(".github/workflows/release-staged.yml");
        for (caller, producer) in [
            ("auto-release", "auto_prepare-source"),
            ("manual-release", "manual_prepare-source"),
        ] {
            crate::ci_gates::staged_release_operations::assert_release_delivery_budget(caller);
            let producer_body = super::workflow_fixtures::job_block(&staged, producer);
            let producer_lines: Vec<&str> = producer_body.lines().collect();
            assert!(root_push_credential_is_retained(&producer_lines));
        }
    }

    for path in github_yaml_files() {
        let name = path
            .strip_prefix(repository_root())
            .unwrap_or(&path)
            .to_string_lossy()
            .into_owned();
        let body = if path == repository_root().join(".github/workflows/release.yml") {
            crate::ci_gates::staged_release_operations::release_operation_workflow()
        } else {
            fs::read_to_string(&path).expect("readable workflow")
        };
        let body = body.replace("\r\n", "\n");
        let lines: Vec<&str> = body.lines().collect();

        // Job bodies, split at the two-space job headers under `jobs:`.
        let mut starts: Vec<usize> = lines
            .iter()
            .enumerate()
            .filter(|(_, line)| {
                line.starts_with("  ")
                    && !line.starts_with("   ")
                    && line.trim_end().ends_with(':')
                    && !line.trim_start().starts_with('#')
            })
            .map(|(index, _)| index)
            .collect();
        starts.push(lines.len());

        for window in starts.windows(2) {
            let (start, end) = (window[0], window[1]);
            let job = &lines[start..end];
            let job_name = lines[start].trim().trim_end_matches(':');

            // A comment explaining why a credential is kept names the push it
            // is kept for, so it must not be read as the push itself.
            let writes = job.iter().any(|line| {
                !line.trim_start().starts_with('#')
                    && REMOTE_GIT_WRITES.iter().any(|write| line.contains(write))
            });
            if !writes {
                continue;
            }

            let checkouts = job
                .iter()
                .filter(|line| {
                    line.contains("actions/checkout@") && !line.trim_start().starts_with('#')
                })
                .count();
            if checkouts == 0 {
                continue;
            }

            pushing_jobs.push(format!("{name}:{job_name}"));
            assert!(
                root_push_credential_is_retained(job),
                "{name}: job `{job_name}` writes to the remote over git but its \
                 checkout sets `persist-credentials: false`, which removes the \
                 only credential the push has. Nothing else supplies one -- \
                 `scripts/git-config.rs` sets the committer identity and no \
                 credential helper (issue #1079)"
            );
        }
    }

    assert_eq!(
        pushing_jobs.len(),
        8,
        "expected the six jobs that write to the remote over git (the three \
         release writers, the benchmark ledger writer, the daily dependency \
         pull request of issue #1169 and the orphan-branch isolation run of \
         issue #1187), found \
         {pushing_jobs:?}. A new one must keep its checkout credential; one \
         that stopped pushing should drop it"
    );

    for role in [
        "dependencies-latest.yml:update",
        "e2e-isolation.yml:isolate",
        "external-benchmarks.yml:external-benchmarks",
        "release.yml:auto-release",
        "release.yml:manual-release",
        "release.yml:changelog-pr",
        "release-staged.yml:auto_prepare-source",
        "release-staged.yml:manual_prepare-source",
    ] {
        assert_eq!(
            pushing_jobs
                .iter()
                .filter(|actual| actual.ends_with(role))
                .count(),
            1,
            "original or checked dormant writer missing: {role}"
        );
    }

    // The composite writer is the self-authored author job, and its pushes moved
    // into `.github/actions/author-with-formal-ai` when the loop became an
    // action another repository can install (issue #1085). Its selected-token
    // helper supplies Git credentials, including the default-token fallback,
    // while checkout's old header must not shadow that selection. The pair is
    // asserted here
    // rather than being lost with the `git push` line that used to be visible.
    let authoring = repository_file(".github/workflows/self-authored-pull-request.yml");
    assert!(
        authoring.contains("uses: ./.github/actions/author-with-formal-ai"),
        "the self-authored workflow drives the loop through the action"
    );
    // Read the actual setting, rather than matching explanatory comments.
    assert!(
        authoring
            .lines()
            .any(|line| line.trim().starts_with("persist-credentials: false")),
        "the author checkout must not shadow the selected credential with a default header"
    );
    assert!(
        authoring.contains("run: gh auth setup-git --hostname github.com"),
        "the author must configure its selected credential before fetching or writing"
    );
    let action =
        repository_file(".github/actions/author-with-formal-ai/scripts/push-formal-ai-commit.sh");
    assert!(
        action.contains("push-to-shared-branch.sh"),
        "the action pushes through the retrying helper like every other writer"
    );
}

#[test]
fn root_git_credential_proof_rejects_missing_scope_and_late_credentials() {
    let valid = [
        "      - uses: actions/checkout@v7",
        "        with:",
        "          token: ${{ secrets.GITHUB_TOKEN }}",
        "      - run: git push origin HEAD:main",
        "      - uses: actions/checkout@v7",
        "        with:",
        "          path: _protocol",
        "          persist-credentials: false",
    ];
    assert!(root_push_credential_is_retained(&valid));
    for invalid in [
        vec![
            "      - run: git push origin HEAD:main",
            "      - uses: actions/checkout@v7",
        ],
        vec![
            "      - uses: actions/checkout@v7",
            "          persist-credentials: false",
            "      - run: git push",
        ],
        vec![
            "      - uses: actions/checkout@v7",
            "          path: _protocol",
            "      - run: git push",
        ],
        vec![
            "      - uses: actions/checkout@v7",
            "          token: ${{ inputs.token }}",
            "      - run: git push",
        ],
        vec![
            "      - uses: actions/checkout@v7",
            "      - run: cd _protocol",
            "          git push",
        ],
        vec![
            "      - uses: actions/checkout@v7",
            "      - run: git push",
            "        working-directory: _protocol",
        ],
    ] {
        assert!(!root_push_credential_is_retained(&invalid));
    }
}
