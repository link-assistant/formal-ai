import json
import os
import subprocess
from pathlib import Path

root = Path('/tmp/issue-1580-research/native-audit-invocation-17a')
root.mkdir(exist_ok=True)
path = Path('rust/tests/unit/ci-cd/pinned_tool_images.rs')
before = path.read_text()
old = '.find(|line| line.trim_start().starts_with("cargo audit"))\n        .expect("check-rust-dependencies.sh must invoke `cargo audit`");'
new = '.find(|line| line.trim_start().starts_with("run_audit cargo audit"))\n        .expect("check-rust-dependencies.sh must invoke `cargo audit` through `run_audit`");'
assert before.count(old) == 1
script = Path('scripts/check-rust-dependencies.sh').read_text()
before_matches = [line for line in script.splitlines() if line.lstrip().startswith('cargo audit')]
after_matches = [line for line in script.splitlines() if line.lstrip().startswith('run_audit cargo audit')]
assert not before_matches and len(after_matches) == 2
assert '--deny warnings' in after_matches[0] and '--no-yanked' not in after_matches[0]
after = before.replace(old, new)
(root / 'native-before.rs').write_text(before)
(root / 'native-after.rs').write_text(after)
(root / 'invocation-source-observation.json').write_text(json.dumps({'beforeMatches': before_matches, 'afterMatches': after_matches,
    'nativeTestExecutedLocally': False, 'scope': 'Literal source selector compared against the actual wrapper; actual failing native execution is retained separately.'}, indent=2) + '\n')
path.write_text(after)
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
records = []
for label, command in [
    ('inventory', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/cargo-audit-inventory.test.mjs']),
    ('blocked-proof', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/cargo-audit-blocked-proof.test.mjs']),
    ('advisory-proof', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/cargo-audit-proof.test.mjs']),
    ('rustfmt', ['rustfmt', '--edition', '2024', '--check', '--config', 'skip_children=true', str(path)]),
    ('diff-check', ['git', 'diff', '--check']),
    ('diff', ['git', 'diff', '--', str(path)]),
]:
    with (root / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, env=environment)
    records.append({'label': label, 'command': command, 'exitCode': result.returncode})
    (root / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == 0
(root / 'outcome.json').write_text(json.dumps({'complete': True, 'records': records}, indent=2) + '\n')
