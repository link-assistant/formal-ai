from pathlib import Path
import json,os,subprocess,time,resource,traceback
r=Path("/tmp/issue-1580-research/link-capacity-main-integration")
checks=[
("source-model-bounded",512,["node","experiments/formal_ai_subagent/local-gates.mjs","--only","layered-ci#4"]),
("status-and-documentation",192,["node","experiments/formal_ai_subagent/local-gates.mjs","--only","check-status-render,check-render-status-js-twin,check-generate-requirement-status-js-twin,check-required-documentation,check-readable-code,check-file-size,check-file-size-js-twin,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-changelog-fragment-js-twin"])]
results=[]
def no_core():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
try:
 for name,heap,cmd in checks:
  (r/"repair-current.json").write_text(json.dumps({"name":name,"heapMiB":heap,"startedAt":time.time()})+"\n")
  started=time.monotonic()
  with (r/(name+".stdout")).open("w") as out,(r/(name+".stderr")).open("w") as err:
   p=subprocess.Popen(cmd,stdout=out,stderr=err,env={**os.environ,"NODE_OPTIONS":"--max-old-space-size="+str(heap)},preexec_fn=no_core)
   _,status,usage=os.wait4(p.pid,0)
   p.returncode=os.waitstatus_to_exitcode(status)
   (r/(name+".rusage")).write_text(json.dumps({"maximumResidentSetKiB":usage.ru_maxrss,"userSeconds":usage.ru_utime,"systemSeconds":usage.ru_stime,"exitCode":p.returncode},indent=2)+"\n")
  row={"name":name,"command":cmd,"heapMiB":heap,"coreDumpLimit":0,"exitCode":p.returncode,"elapsedSeconds":round(time.monotonic()-started,3)}
  results.append(row);(r/"repair-results.json").write_text(json.dumps(results,indent=2)+"\n")
  print(json.dumps(row),flush=True)
 (r/"repair-outcome.json").write_text(json.dumps({"complete":True,"passed":all(x["exitCode"]==0 for x in results),"head":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"results":results},indent=2)+"\n")
except Exception:
 (r/"repair-worker-error.txt").write_text(traceback.format_exc());raise
