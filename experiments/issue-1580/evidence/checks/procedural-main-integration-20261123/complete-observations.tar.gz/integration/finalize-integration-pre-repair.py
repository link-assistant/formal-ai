import sys;sys.tracebacklimit=0
from pathlib import Path
import collections,datetime,gzip,hashlib,io,json,subprocess,tarfile,contextlib,shutil,re
r=Path("/tmp/issue-1580-research")
root=r/"link-capacity-main-integration"
outcome=json.loads((root/"verification-outcome.json").read_text())
assert outcome["complete"] and outcome["passed"]
head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
assert head==outcome["head"]=="6e36d3a2ba995a2150151170f00511bc6efdb2a0"
assert not subprocess.check_output(["git","status","--porcelain"],text=True).strip()
gate_counts=collections.Counter(line.split()[0] for line in (root/"all-javascript-gates.stdout").read_text().splitlines() if line.startswith(("PASS ","SKIP ","FAIL ")))
assert gate_counts["PASS"]+gate_counts["SKIP"]==143 and gate_counts["FAIL"]==0
test_counts={}
for row in outcome["results"]:
 if row["name"] in ["all-javascript-gates","rustfmt"]: continue
 text=(root/(row["name"]+".stdout")).read_text()
 vals={k:int(v) for k,v in re.findall(r"^[#ℹ] (tests|pass|fail|skipped|cancelled) (\d+)$",text,re.M)}
 assert vals and vals["fail"]==0 and vals["cancelled"]==0 and vals["skipped"]==0
 test_counts[row["name"]]=vals
metadata={"source":head,"includedMain":"0e550f6d56528d6d26bf575e08ab35c13e4af234","release":"0.356.11",
 "gateCounts":dict(gate_counts),"focusedSuites":test_counts,"focusedTestsPassed":sum(v["pass"] for v in test_counts.values()),
 "rustfmtPassed":True,"localRustCompilation":False,"hostedCombinedHeadQualified":False,
 "witness":{"total":1193,"supported":223,"unsupported":970,"sourceManifest":141,"scalarDifferences":18,"completeObjectComparison":True},
 "foregroundInterruptionSeconds":60,"independentReasoningCredit":0}
(root/"verification-summary.json").write_text(json.dumps(metadata,indent=2)+"\n")
gdir=root/"gate-streams";gdir.mkdir()
glogs=[]
for p in sorted(Path("experiments/formal_ai_subagent/sandboxes/gates").glob("*.log")):
 shutil.copyfile(p,gdir/p.name)
 glogs.append({"name":p.name,"bytes":p.stat().st_size,"mtime":p.stat().st_mtime})
(root/"gate-streams-index.json").write_text(json.dumps(glogs,indent=2)+"\n")
files={}
for p in sorted(root.rglob("*")):
 if p.is_file():files["integration/"+p.relative_to(root).as_posix()]=p
changed=subprocess.check_output(["git","diff","--name-only","5fac3b1fa9399fbdd72e6cc22c002229b4694bb7",head],text=True).splitlines()
source_index=[]
for name in changed:
 p=Path(name)
 if p.is_file():
  files["sources/"+name]=p
  source_index.append({"path":name,"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()})
(root/"source-index.json").write_text(json.dumps(source_index,indent=2)+"\n")
files["integration/source-index.json"]=root/"source-index.json"
diff=subprocess.run(["git","diff","--no-ext-diff","5fac3b1fa9399fbdd72e6cc22c002229b4694bb7",head],capture_output=True,check=True)
(root/"integration.diff").write_bytes(diff.stdout);files["integration/integration.diff"]=root/"integration.diff"
p=Path("experiments/issue-1580/review-procedural-main-integration.mjs")
files["sources/"+str(p)]=p
s=(r/"seal-extracted-native-modules.py").read_text()
exec(s[s.index("def seal("):s.index("cohort=r/")])
with contextlib.redirect_stdout(io.StringIO()):
 sealed=seal("procedural-main-integration-20261123",files,metadata)
doc=f"""# Procedural publisher main integration

Current main MDQUOTE0e550f6d56528d6d26bf575e08ab35c13e4af234MDQUOTE (release 0.356.11)
is included in integration commit MDQUOTE{head}MDQUOTE for
[PR #1581](https://github.com/link-assistant/formal-ai/pull/1581).
Its public-search recovery, method selection and explicit unverified answer
remain intact in JavaScript, TypeScript and Rust.

Conflict resolution preserves the branch's canonical Links Notation lists,
extracted response-intent rows, native fixture modules and all case identities.
The new scope markers use the existing shared list parser in all three roots.
The core ledger keeps its actual measured source inventory rather than
restoring stale counts.

The governed witness is refreshed through the maintained reviewed interface.
The complete before and after objects are compared, including every unsupported
record. The inventory retains 1,193 cases: 223 supported and 970 unsupported,
with 141 source identities. All eighteen scalar differences are reviewed:
the complete main-supplied Russian procedural-response case and the exact
source/Cargo fixture identities. No case or unsupported record is dropped.
V8 byte encodings may differ for equal objects; both the originally reviewed
candidate bytes and full deserialized-object equality are retained.

Eight focused suites pass all {metadata["focusedTestsPassed"]} tests. The full
143-entry JavaScript inventory passes {gate_counts["PASS"]} gates and explicitly
skips {gate_counts["SKIP"]} CI-only entries. Rust 2024 formatting passes.
The initial foreground batch stopped at the command wrapper's sixty-second
limit after two successful suites. Its partial streams are retained alongside
the complete sequential background rerun. No Rust build runs locally.

The [complete receipt](../../../experiments/issue-1580/evidence/checks/procedural-main-integration-20261123/manifest.json)
round-trip verifies {sealed["members"]} archive members. It retains original
conflicts, the initial witness-byte assertion failure, all three baseline sides,
both candidates, the complete scalar comparison, source snapshots and complete
local check streams. Earlier immutable receipts remain unchanged.

Hosted native behavior and the combined link/capacity allocation await
exact-head execution. Wider issue acceptance remains unfinished. Supplied
commands, edits and this merge review receive zero independent authorship or
reasoning credit.
"""
Path("docs/case-studies/issue-1580/procedural-main-integration.md").write_text(doc.replace("MDQUOTE",chr(96)))
p=Path("experiments/issue-1580/work-plan.md")
prefix=f"""## Active checkpoint: procedural main integration (2026-11-23)

The objective remains every requirement of issue #1580 in
[PR #1581](https://github.com/link-assistant/formal-ai/pull/1581), draft and unmerged.

- [x] Read fresh feedback: one issue comment, eleven PR comments, no inline comments or reviews; all unchanged.
- [x] Include current main 0e550f6d5, release 0.356.11, retaining publisher recovery, method selection and unverified-answer behavior across all three roots.
- [x] Preserve extracted fixtures and canonical lists; compare complete governed objects and retain all eighteen reviewed scalar differences and all 1,193 case identities.
- [x] Pass eight focused suites ({metadata["focusedTestsPassed"]} tests), {gate_counts["PASS"]} JavaScript gates and Rust formatting. Retain {gate_counts["SKIP"]} explicit CI-only skips, interrupted streams and initial assertion failure; no local Rust build.
- [x] Seal the complete integration receipt without rewriting earlier archives.
- [ ] Pass the final changed-source secret scan, confirm an idle branch and fresh main, update the PR and publish one complete batch.
- [ ] Qualify the exact published source in hosted CI and complete every wider original criterion below.
- Supplied commands and edits retain zero independent authorship/reasoning credit. The native goal remains usage-limited.

Evidence: [procedural main integration](../../docs/case-studies/issue-1580/procedural-main-integration.md).

"""
text=prefix+p.read_text()
assert len(text.splitlines())<1000
p.write_text(text)
print(json.dumps({"archive":sealed["archive"],"members":sealed["members"],"gateCounts":dict(gate_counts),"focusedTests":metadata["focusedTestsPassed"],"workPlanLines":len(text.splitlines())}))
