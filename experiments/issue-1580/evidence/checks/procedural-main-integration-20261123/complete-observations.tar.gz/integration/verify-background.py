import pathlib,subprocess,json,os,time,traceback
e=pathlib.Path('/tmp/issue-1580-research/link-capacity-main-integration')
specs=[
('issue-991','rust/tests/web/issue-991-how-to-synthesis.test.mjs'),
('procedural-parity','rust/tests/web/procedural-runtime-parity.test.mjs'),
('fixture-integrity','rust/tests/web/rust-specification-fixture-integrity.test.mjs'),
('unicode-inventory','rust/tests/web/rust-specification-unicode-identifiers.test.mjs'),
('link-terminal','experiments/issue-1580/link-observation-boundaries.test.mjs'),
('javascript-capacity','experiments/issue-1580/javascript-capacity-replay.test.mjs')]
cmds=[(n,['node','--test','--test-concurrency=1',f]) for n,f in specs]
cmds.append(('all-javascript-gates',['node','experiments/formal_ai_subagent/local-gates.mjs']))
cmds.append(('rustfmt',['rustfmt','--check','--edition','2024','rust/src/how_to_guide.rs','rust/src/how_to_guide/extract.rs','rust/src/how_to_guide/render.rs','rust/src/how_to_guide/wiki_how.rs','rust/src/solver_handler_how.rs','rust/src/solver_handler_how_synthesis.rs','rust/tests/unit/specification/reasoning_paths_procedures.rs','rust/tests/integration/issue_991_how_to_http.rs']))
results=json.loads((e/'verification.json').read_text())
try:
 for name,cmd in cmds:
  (e/'current-check.json').write_text(json.dumps({'name':name,'command':cmd,'startedAt':time.time()})+'\n')
  start=time.monotonic()
  with (e/(name+'.stdout')).open('w') as out,(e/(name+'.stderr')).open('w') as err:
   p=subprocess.run(cmd,stdout=out,stderr=err,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=192'})
  row={'name':name,'command':cmd,'exitCode':p.returncode,'elapsedSeconds':round(time.monotonic()-start,3)}
  results.append(row);(e/'verification.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 (e/'verification-outcome.json').write_text(json.dumps({'complete':True,'passed':all(x['exitCode']==0 for x in results),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'results':results},indent=2)+'\n')
except Exception:
 (e/'verification-worker-error.txt').write_text(traceback.format_exc());raise
