// Issue #918 (E71, R914-6), browser root: the `memory_program` and
// `memory_program_gap` rows of the worker's solve table answer exactly as the
// native memory surface does. Both runtimes compile a request against
// data/seed/memory-programs.lino and render the outcome through the seeded
// `memory_program_*` responses. Prompts, stores and expected wording are the
// ones rust/tests/unit/memory/issue_918_browser_twins.rs asserts against
// `execute_memory_query_with_options`.

import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

import { createWorkerContext, evaluate, plain } from "./support/browser-runtime.mjs";

import { currencyCaptures, currencyFetch, quoteDate } from "./support/currency-publisher-captures.mjs";

const worker = createWorkerContext({}, { networkFetch: currencyFetch });
const ready = evaluate(worker, "loadSeed()");
const defaultFetch = worker.fetch;

const RENAME_REQUEST = "List every fact I contributed about X and rename X to Y in all of them.";
const RENAME_EN = "Memory program memory_program_41ef0c9602340676 matched 1 event(s), changed 1, and stopped at fixpoint after 2 iteration(s).";
const RENAME_EMPTY_RU = "Программа памяти memory_program_41ef0c9602340676 сопоставила событий: 0, изменила: 0 и остановилась с результатом fixpoint после итераций: 1.";
const DESTRUCTIVE_EN = "Destructive memory actions require explicit human confirmation. No memory event was erased or retracted.";
const GAP_EN = "I could not compile this memory request without dropping a step. program_gap:no_complete_seeded_family";

const factStore = () => [{ id: "fact", kind: "fact", role: "user", content: "X" }];

async function solve(prompt, memoryEvents = []) {
  await ready;
  return worker.solve(prompt, [], {}, {}, [], { memoryEvents });
}

// FNV-1a 64 as rust/src/web_engine_core.rs::stable_id computes it.
function stableId(prefix, text) {
  let hash = 0xcbf29ce484222325n;
  for (const byte of new TextEncoder().encode(text)) {
    hash ^= BigInt(byte);
    hash = (hash * 0x100000001b3n) & 0xffffffffffffffffn;
  }
  return `${prefix}_${hash.toString(16).padStart(16, "0")}`;
}

test("a seeded rename program runs to fixpoint with the seeded wording", async () => {
  const response = await solve(RENAME_REQUEST, factStore());
  assert.equal(response.intent, "memory_program");
  assert.equal(response.content, RENAME_EN);
  assert.equal(response.memoryOperation.updates[0].fields.content, "Y");
});

test("the program id is the native stable id of the canonical program", async () => {
  await ready;
  const compiled = plain(evaluate(worker, `compileMemoryProgramForWorker(${JSON.stringify(RENAME_REQUEST)})`));
  assert.equal(compiled.status, "compiled");
  assert.equal(compiled.program.canonical.split("\n")[0], "family=contributed_fact_rename");
  assert.equal(stableId("memory_program", compiled.program.canonical), "memory_program_41ef0c9602340676");
});

test("the russian request compiles to the same program and answers in russian", async () => {
  const response = await solve("Перечисли все факты, которые я добавил о X, и переименуй X в Y во всех них.");
  assert.equal(response.intent, "memory_program");
  assert.equal(response.content, RENAME_EMPTY_RU);
  assert.equal(response.memoryOperation, undefined);
});

test("a destructive program is refused without confirmation", async () => {
  const response = await solve("Delete every fact I contributed about X.", factStore());
  assert.equal(response.intent, "memory_program_refused");
  assert.equal(response.content, DESTRUCTIVE_EN);
  assert.equal(response.memoryOperation, undefined);
});

test("a memory request no seeded family covers names its gap", async () => {
  const response = await solve("Transpose every fact matrix in memory.");
  assert.equal(response.intent, "memory_program_gap");
  assert.equal(response.content, GAP_EN);
});

const COMPOUND_REPORT = "Compound interest calculation\n\nFormula: A = P(1 + r/n)^(n*t)\nP = 1000 USD\nr = 0.08 (8% annual)\nn = 12 (monthly)\nt = 5 years\n\nStep 1: periodic rate = r/n = 0.08/12 = 0.006666666666667\nStep 2: number of periods = n*t = 12*5 = 60\nStep 3: A = 1000 * (1 + 0.006666666666667)^60\nFinal amount: 1489.85 USD";
const COMPOUND_EUR = compoundExpected("EUR", "0.9086", "1353.68");
const COMPOUND_RUB = compoundExpected("RUB", "82.5143", "122933.93");

function compoundExpected(target, rate, converted) {
  const source = [...currencyCaptures.keys()].find(url => url.includes(`/usd/${target.toLowerCase()}?`));
  return `\n\nConversion: USD -> ${target}\n1 USD in ${target} = ${rate} ${target}\n1489.85 USD * ${rate} = ${converted} ${target}\nRate detail: Exchange rate: 1 USD = ${rate} ${target} (${source}, ${quoteDate})`;
}

const COMPOUND_PROMPT = "Invest $1000 at 8% annual interest compounded monthly for 5 years";

async function solveWith(prompt, history) {
  await ready;
  return worker.solve(prompt, history, {}, {}, [], {});
}

test("a compound-interest report converts at the publisher euro and ruble rates", async () => {
  for (const [prompt, expected] of [
    [`${COMPOUND_PROMPT} and convert the final amount to EUR on ${quoteDate}.`, COMPOUND_REPORT + COMPOUND_EUR],
    [`${COMPOUND_PROMPT} and convert the final amount to rubles on ${quoteDate}.`, COMPOUND_REPORT + COMPOUND_RUB],
  ]) {
    const response = await solveWith(prompt, []);
    assert.equal(response.intent, "calculation", prompt);
    assert.equal(response.content, expected, prompt);
  }
});

test("a principal spelled in dollars is never converted to dollars", async () => {
  const response = await solveWith("invest 1000 dollars at 8,5% interest compounded daily for 2 years", []);
  assert.equal(response.content, "Compound interest calculation\n\nFormula: A = P(1 + r/n)^(n*t)\nP = 1000 USD\nr = 0.085 (8.5% annual)\nn = 365 (daily)\nt = 2 years\n\nStep 1: periodic rate = r/n = 0.085/365 = 0.000232876712329\nStep 2: number of periods = n*t = 365*2 = 730\nStep 3: A = 1000 * (1 + 0.000232876712329)^730\nFinal amount: 1185.28 USD");
});

test("a follow-up converts the earlier final amount", async () => {
  const history = [
    { role: "user", content: COMPOUND_PROMPT },
    { role: "assistant", content: COMPOUND_REPORT },
  ];
  const response = await solveWith(`Convert the final amount to rubles on ${quoteDate}`, history);
  assert.equal(response.intent, "calculation");
  assert.equal(response.content, `Final amount conversion\nSource amount: 1489.85 USD${COMPOUND_RUB}`);
});

test("compound interest accepts another ISO principal without a network quote", async () => {
  const response = await solveWith("Invest 1000 CAD at 8% annual interest compounded monthly for 5 years", []);
  assert.equal(response.intent, "calculation");
  assert.match(response.content, /Final amount: 1489\.85 CAD/u);
});

// Issue #918 (R914-6): the playwright_script prelude row renders the seeded
// playwright_* responses and the docs URL of `policy playwright_script` in
// both runtimes. The expected answers are read from the native pins in
// rust/tests/unit/solver/playwright_script.rs, so the two suites hold one text.
function rustRawConstant(name) {
  const source = readFileSync(new URL("../unit/solver/playwright_script.rs", import.meta.url), "utf8");
  const match = new RegExp(`const ${name}: &str = r"([\\s\\S]*?)";`).exec(source);
  assert.ok(match, `${name} in rust/tests/unit/solver/playwright_script.rs`);
  return match[1];
}

test("playwright starters answer with the native pins in every language", async () => {
  const english = rustRawConstant("PLAYWRIGHT_EN_ANSWER");
  const russian = rustRawConstant("PLAYWRIGHT_RU_TYPO_ANSWER");
  for (const [prompt, expected] of [
    ["Can you write a Playwright script?", english],
    ["Можешь написать мне Playright скрипт?", russian],
    ["क्या तुम Playwright script लिख सकते हो?", rustRawConstant("PLAYWRIGHT_HI_ANSWER")],
    ["可以写一个 Playwright script 吗？", rustRawConstant("PLAYWRIGHT_ZH_ANSWER")],
  ]) {
    const response = await solveWith(prompt, []);
    assert.equal(response.intent, "playwright_script", prompt);
    assert.equal(response.content, expected, prompt);
  }
});

test("a low guess probability asks for the script's scope", async () => {
  await ready;
  const response = await worker.solve("Можешь написать мне Playright скрипт?", [], { guessProbability: 0.1 }, {}, [], {});
  assert.equal(response.intent, "playwright_script_clarification");
  assert.equal(response.content, "Я могу написать Playwright-скрипт. Уточните URL страницы, действия и ожидаемую проверку. Если нужен пример по умолчанию, я могу взять стартовый сценарий из документации Playwright.");
});

// Issue #918 (R914-6): the fetch, navigation and frame-policy wording of the
// http_fetch and url_navigate rows is the seeded web_* responses, which the
// native url_navigate row renders too (its exact answer is pinned in
// rust/tests/unit/formal_ai/seed_and_memory.rs). The browser answers depend
// on what the page and the frame-policy service return, so each outcome is
// pinned against a stubbed fetch; every answer is unchanged.
const WEB_CORS_NOTE = "Browser JavaScript also cannot read the page content directly unless the site allows CORS, so the direct external link is the reliable option.";
const webHeaders = (values) => ({ get: (name) => values[name.toLowerCase()] || null });

async function withFetch(fetchImpl, code) {
  await ready;
  worker.fetch = fetchImpl;
  return plain(await evaluate(worker, code));
}

test("a navigation the frame policy blocks keeps the external link", async () => {
  const response = await withFetch(
    async () => ({ ok: true, status: 200, json: async () => ({ headers: { "x-frame-options": "DENY", "content-security-policy": "frame-ancestors 'none'" } }), headers: webHeaders({}) }),
    'tryUrlNavigate("Navigate to github.com")',
  );
  assert.equal(response.intent, "url_navigate");
  assert.equal(response.content, `I suggest opening this in a new tab: [https://github.com](https://github.com).\n\nI checked the page's frame policy, and it does not allow embedding here because the page sends X-Frame-Options: DENY and CSP frame-ancestors 'none'.\n${WEB_CORS_NOTE}`);
});

test("a navigation the frame policy allows shows the page", async () => {
  const response = await withFetch(
    async () => ({ ok: true, status: 200, json: async () => ({ headers: {} }), headers: webHeaders({}) }),
    'tryUrlNavigate("Navigate to example.com")',
  );
  assert.equal(response.content, "I checked the page's frame policy and can show it here.\n\nDirect link: [https://example.com](https://example.com).");
  assert.equal(response.iframeUrl, "https://example.com");
});

test("an unreachable frame-policy service names its reason", async () => {
  const response = await withFetch(async () => ({ ok: false, status: 503, headers: webHeaders({}) }), 'tryUrlNavigate("Go to example.org")');
  assert.equal(response.content, `I suggest opening this in a new tab: [https://example.org](https://example.org).\n\nI could not verify that this page allows embedding here because the frame-policy service returned HTTP 503.\n${WEB_CORS_NOTE}`);
});

test("a fetched text body is shown and a binary body is not", async () => {
  const text = await withFetch(
    async () => ({ ok: true, status: 200, headers: webHeaders({ "content-type": "text/plain" }), text: async () => "hello {url} world", json: async () => ({ headers: {} }) }),
    'tryFetch("fetch example.com")',
  );
  assert.equal(text.intent, "http_fetch");
  assert.equal(text.content, "Fetched `https://example.com` — status **200**.\n\nResponse body:\n```\nhello {url} world\n```");
  const binary = await withFetch(
    async () => ({ ok: true, status: 204, headers: webHeaders({ "content-type": "image/png" }), text: async () => "", json: async () => ({ headers: {} }) }),
    'tryFetch("fetch example.com")',
  );
  assert.equal(binary.content, "Fetched `https://example.com` — status **204**.\n\nContent-Type: `image/png` — binary or empty body, not shown.\n\nYou can view this URL directly: [https://example.com](https://example.com)");
});

test("a failed fetch falls back to the frame policy", async () => {
  const response = await withFetch(
    async (url) => {
      if (!String(url).includes("api") && String(url).includes("example.com")) throw new Error("boom");
      return { ok: true, status: 200, json: async () => ({ headers: {} }), headers: webHeaders({}) };
    },
    'tryFetch("fetch example.com")',
  );
  assert.equal(response.content, "Could not fetch `https://example.com` directly (network error).\n\nI checked the page's frame policy and can show it in the embedded frame below.");
});

// Issue #918 (R914-6): the browser web search renders its result header,
// source labels, no-result and all-disabled sentences and the Wikinews
// fallback description from seeded web_search_* responses instead of
// per-language tables in js/worker/formal_ai_worker_web_search_and_projects.js and
// js/worker/formal_ai_worker_web_providers_and_wasm_calls.js; every text is unchanged.
test("web search texts come from the seed in every language", async () => {
  await ready;
  const texts = plain(evaluate(worker, `["en", "ru", "es"].map((language) => { const t = webSearchTexts(language); return [t.header("rust", 10, 60), t.otherSources, t.via, t.readMore, t.noResults("rust", "duckduckgo, wikipedia"), t.allDisabled("duckduckgo")]; })`));
  assert.deepEqual(texts[0], [
    "Search results for `rust` — top 10 after reciprocal rank fusion (k = 60).",
    "Other sources", "via", "Read more",
    "No CORS-enabled web search results were returned for `rust`.\n\nProviders tried: duckduckgo, wikipedia.",
    "All CORS-readable search providers are disabled for this session. Tried: duckduckgo.",
  ]);
  assert.deepEqual(texts[1], [
    "Результаты поиска для `rust` — топ 10 после реципрокного объединения рангов (k = 60).",
    "Другие источники", "через", "Подробнее",
    "Не получены результаты веб-поиска с поддержкой CORS для `rust`.\n\nПопробованы провайдеры: duckduckgo, wikipedia.",
    "Все CORS-совместимые поисковые провайдеры отключены в этой сессии. Пробовали: duckduckgo.",
  ]);
  assert.deepEqual(texts[2], [
    "Resultados de búsqueda para `rust`: los 10 primeros tras reciprocal rank fusion (k = 60).",
    "Otras fuentes",
    "vía",
    "Leer más",
    "No se devolvieron resultados de búsqueda web con CORS para `rust`.\n\nProveedores probados: duckduckgo, wikipedia.",
    "Todos los proveedores de búsqueda legibles por CORS están desactivados en esta sesión. Probados: duckduckgo.",
  ]);
  assert.equal(plain(evaluate(worker, 'wikinewsFallbackDescription("Mars rover lands", "ru")')), "В Wikinews есть новостная статья «Mars rover lands».");
  assert.equal(plain(evaluate(worker, 'wikinewsFallbackDescription("Mars rover lands", "en")')), 'Wikinews has a news article titled "Mars rover lands".');
});

// Issue #918 (R914-6): the procedural_how_to and how_it_works rows render
// every line from seeded procedural_how_to_* and how_it_works* responses and
// the search-query frames of the `policy procedural_how_to` and
// `policy how_it_works` blocks, filled in one pass in both runtimes. The
// harness serves seed data and refuses external URLs. Disabled sources retain
// their outcome in the evidence.
async function procedure(prompt, language, preferences) {
  await ready;
  worker.fetch = defaultFetch;
  return plain(await evaluate(worker, `tryProceduralHowTo(${JSON.stringify(prompt)}, ${JSON.stringify(language)}, ${JSON.stringify(preferences)})`));
}

test("an unverified procedural answer uses localized wording and retains source stages", async () => {
  const tea = await procedure("how to make tea", "en", { externalServiceWikihow: false });
  assert.equal(tea.content, "I couldn’t verify steps for “make tea”. If you have a guide, share its link and I can help you work through it.");
  assert.ok(tea.evidence.includes("procedural_how_to:service_disabled:wikihow"));
  const docker = await procedure("how to install docker", "en", {});
  assert.equal(docker.content, "I couldn’t verify steps for “install docker”. If you have a guide, share its link and I can help you work through it.");
  assert.ok(docker.evidence.includes("procedural_how_to:source_gate:official_documentation_first"));
  assert.ok(docker.evidence.includes("web_search:request:docker install official documentation"));
  const russian = await procedure("как установить docker", "ru", { externalServiceWikihow: false });
  assert.equal(russian.content, "Не удалось найти проверенные инструкции по запросу «установить docker». Если у вас есть ссылка на руководство, пришлите её.");
  assert.equal(russian.query, "how to установить docker");
});

test("a task text with braces is never re-filled", async () => {
  const response = await procedure("how to {task} it {k}", "en", { externalServiceWikihow: false });
  assert.ok(response.content.startsWith("I couldn’t verify steps for “task it k”."));
});

test("the mechanism discovery plan answers as the native row does", async () => {
  const response = await solveWith("how does AUR work?", []);
  assert.equal(response.intent, "how_it_works");
  // Deliberate parity fix: the English record now ends as the native
  // answer pinned in rust/tests/unit/specification/reasoning_paths.rs does.
  assert.equal(response.content, "Mechanism discovery plan for `AUR`.\n\nI do not answer this from a memoized fact. The solver treats the prompt as a question about how `AUR` works, checks Wikipedia for a source-backed overview, Wikidata for entity relationships, then web search across duckduckgo, internet-archive, wikipedia, wikidata, wiktionary, wikinews. If no source explains the mechanism, it should ask for a source or a narrower term instead of inventing details.");
});

// Issue #918 (R914-6): feature-capability questions answer from
// data/seed/feature-capabilities.lino and the seeded feature_capability_*
// responses in both runtimes. The two hand-kept tables had drifted (the
// browser said "diagnostics" where the native row said "diagnostic trace",
// and a dozen labels and examples differed); the seed holds the native
// table, so these answers are the ones the native pins in
// rust/tests/unit/specification/capabilities.rs and
// rust/tests/unit/memory/issue_918_browser_twins.rs assert.
test("feature capability questions answer from the seeded table", async () => {
  for (const [prompt, preferences, expected] of [
    ["Can you show diagnostics?", {}, "No. diagnostic trace is not available in this configuration: diagnostics are off; enable them to show traces. Example message after enabling it: `Turn on diagnostics`."],
    ["Can you show diagnostics?", { diagnosticsMode: true }, "Yes. diagnostic trace is available in this configuration. Example message: `Turn on diagnostics`."],
    ["Can you use agent mode?", { agentMode: true }, "Yes. agent mode is available in this configuration. Example message: `Turn on agent mode`."],
    ["Can you merge definitions automatically?", {}, "No. automatic definition fusion is not available in this configuration: automatic definition fusion is set to explicit-only. Example message after enabling it: `Turn on definition fusion`."],
    ["Ты умеешь переводить?", {}, "Да. Возможность «перевод» доступна в этой конфигурации. Пример сообщения: `Переведи hello на русский`."],
    ["Can you remember conversation context?", {}, "Yes. conversation memory is available in this configuration. Example message: `Remember my name is Ada`."],
  ]) {
    await ready;
    const response = await worker.solve(prompt, [], preferences, {}, [], {});
    assert.equal(response.intent, "capabilities", prompt);
    assert.equal(response.content, expected, prompt);
  }
});

// Issue #918 (R914-6): numeric-list code answers introduce their program and
// label their result with seeded numeric_list_* responses in both runtimes
// (the native pins are rust/tests/integration/issue_395_sort_numbers.rs and
// its siblings), filled in one pass so a list item with braces stays as
// given. Every answer is unchanged.
test("numeric-list answers render their seeded intro and result label", async () => {
  for (const [prompt, expected] of [
    ["Write Python code to sort the numbers 3, 1, 2", "Here is Python code that sorts the numbers 3, 1, 2 in ascending order:\n\n```python\nnumbers = [3, 1, 2]\nsorted_numbers = sorted(numbers)\nprint(\", \".join(str(n) for n in sorted_numbers))\n```\n\nResult: 1, 2, 3"],
    ["Напиши код на Python, который сортирует числа 3, 1, 2", "Вот код на Python, который сортирует числа 3, 1, 2 по возрастанию:\n\n```python\nnumbers = [3, 1, 2]\nsorted_numbers = sorted(numbers)\nprint(\", \".join(str(n) for n in sorted_numbers))\n```\n\nРезультат: 1, 2, 3"],
    ["Python में संख्याओं 3, 1, 2 को क्रमबद्ध करने का कोड लिखो", "यह Python कोड है जो संख्याओं 3, 1, 2 को आरोही क्रम में क्रमबद्ध करता है:\n\n```python\nnumbers = [3, 1, 2]\nsorted_numbers = sorted(numbers)\nprint(\", \".join(str(n) for n in sorted_numbers))\n```\n\nपरिणाम: 1, 2, 3"],
    ["用 Python 对数字 3, 1, 2 排序", "这是用 Python 编写的将数字 3, 1, 2 按升序排序的代码:\n\n```python\nnumbers = [3, 1, 2]\nsorted_numbers = sorted(numbers)\nprint(\", \".join(str(n) for n in sorted_numbers))\n```\n\n结果: 1, 2, 3"],
    ["Sort the strings \"b\", \"a\", \"{lang}\" in Python", "Here is Python code that sorts the strings b, a, {lang} in ascending order:\n\n```python\nnumbers = [\"b\", \"a\", \"{lang}\"]\nsorted_numbers = sorted(numbers)\nprint(\", \".join(str(n) for n in sorted_numbers))\n```\n\nResult: a, b, {lang}"],
  ]) {
    const response = await solveWith(prompt, []);
    assert.equal(response.intent, "write_program", prompt);
    assert.equal(response.content, expected, prompt);
  }
});

// Issue #918 (R914-6): meta_explanation renders the seeded why, how-I-work
// and meta_explanation_architecture records in both runtimes (the native pins
// are rust/tests/unit/specification/self_awareness_prompts.rs), and both read which
// languages take the fronted and the compositional why-question readings
// from the `policy meta_explanation` block. Every answer is unchanged.
test("meta explanations render the seeded records", async () => {
  for (const [prompt, expected] of [
    ["Why did you answer that way?", "I answered that way because the prompt matched a deterministic Links Notation rule. The evidence links and trace events are appended to the log; see the trace link for the full chain."],
    ["Почему ты так ответил?", "Я ответил так, потому что запрос совпал с детерминированным правилом Links Notation. Evidence-ссылки и trace-события добавлены в журнал; по trace-ссылке можно проверить всю цепочку."],
    ["你为什么这样回答？", "我这样回答是因为该提示匹配了确定性的 Links Notation 规则。evidence links 和 trace events 已追加到日志中; 可通过 trace link 检查完整链路。"],
    ["How do you work?", "I work by matching your prompt against deterministic Links Notation rules stored in memory. Each rule maps a recognized pattern to a fixed response. When no rule matches, I report intent: unknown. There is no neural inference — every answer is fully traceable to a symbolic rule."],
    ["Are you an LLM?", "I am not an LLM runtime and I do not perform neural inference. Current environment: browser demo with JavaScript and WebAssembly worker (`browser`). Runtime: JavaScript UI plus a WebAssembly worker mirror of the solver. The project exposes OpenAI-compatible API shapes, but answers come from a deterministic solver: it checks the local Links Notation seed, rules, and memory (browser IndexedDB/local storage plus worker state and imported memory) first; web search is used only when this environment allows it: available through browser CORS-readable providers when online and not blocked. The whole internet is not preloaded into local rules."],
    ["Ты нейросеть?", "Я не LLM-рантайм и не выполняю нейросетевой инференс. Текущая среда: browser demo with JavaScript and WebAssembly worker (`browser`). Рантайм: JavaScript UI plus a WebAssembly worker mirror of the solver. У проекта есть OpenAI-совместимые API-форматы, но ответы строит детерминированный solver: сначала он проверяет локальный seed Links Notation, правила и память (browser IndexedDB/local storage plus worker state and imported memory); затем веб-поиск используется только с учетом среды: available through browser CORS-readable providers when online and not blocked. Весь интернет не загружен в локальные правила целиком."],
  ]) {
    const response = await solveWith(prompt, []);
    assert.equal(response.intent, "meta_explanation", prompt);
    assert.equal(response.content, expected, prompt);
  }
});
