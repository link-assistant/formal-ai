import {readFileSync,writeFileSync} from 'node:fs';
import {parseRegistry,canonicalize,renderRegistry,registryHeader} from '/tmp/gh-issue-solver-1794900398048/scripts/generate-seed-registry.mjs';
const path='/tmp/gh-issue-solver-1794900398048/data/meta/seed-registry.lino',source=readFileSync(path,'utf8'),registry=parseRegistry(source);
const original=registry.seeds.find(seed=>seed.name==='multilingual-responses');
if(!original?.bundle||!original.web||!original.lexicon.has('response'))throw Error('original response consumers required');
if(registry.seeds.some(seed=>seed.name==='multilingual-responses-administration'))throw Error('duplicate shard');
registry.seeds.push({...original,name:'multilingual-responses-administration',lexicon:new Set(original.lexicon)});
writeFileSync(path,renderRegistry(canonicalize(registry),registryHeader(source)));
