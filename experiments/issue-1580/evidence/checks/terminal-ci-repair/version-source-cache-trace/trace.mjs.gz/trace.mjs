import {installNodeHost} from '/tmp/gh-issue-solver-1794900398048/js/agentic/node-host.mjs';
import {host,installHost} from '/tmp/gh-issue-solver-1794900398048/js/agentic/host.mjs';
import {forGeneration,baselineVersionSet} from '/tmp/gh-issue-solver-1794900398048/js/agentic/crate/version_resolution.mjs';
process.env.FORMAL_AI_OFFLINE='1';
console.error('before fake realm installation');await installNodeHost({boot:async()=>({})});
const original=host(),make=original.sourceFetch;
installHost({...original,sourceFetch:()=>{console.error('before source fetch construction');const fetch=make();console.error('after source fetch construction');return url=>{console.error('before fetch',url);const result=fetch(url);console.error('after fetch',url,result===null?'miss':{length:result.text.length,cached:result.cached});return result;};}});
console.error('before generation');const actual=forGeneration();console.error('after generation');const expected=baselineVersionSet();console.error('baselineEqual',JSON.stringify(actual)===JSON.stringify(expected));
