import {installHost} from '/tmp/gh-issue-solver-1794900398048/js/agentic/host.mjs';
import {parseLino,readRepoFile} from '/tmp/gh-issue-solver-1794900398048/js/server/lino.mjs';
import {baselineVersionSet} from '/tmp/gh-issue-solver-1794900398048/js/agentic/crate/version_resolution.mjs';
installHost({parseLino,readText:readRepoFile});
console.error('before baseline');const result=baselineVersionSet();console.error('after baseline',JSON.stringify(result));