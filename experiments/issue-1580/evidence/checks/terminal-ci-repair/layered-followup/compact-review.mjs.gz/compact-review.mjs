import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {deserialize} from 'node:v8';import {createHash} from 'node:crypto';import {resolve,relative,isAbsolute} from 'node:path';
import {specificationCases} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/rust-specification-cases.mjs';
const root='/tmp/gh-issue-solver-1794900398048',out='/tmp/issue-1580-research/layered-assertion-verification/';
const hash=value=>createHash('sha256').update(value).digest('hex');
const baseline=deserialize(readFileSync(root+'/experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8'));
const inventory=specificationCases(root);
for(const item of inventory.cases)for(const fixture of item.program?.fixtures??[])if(isAbsolute(fixture.file))fixture.file='repo:'+relative(root,fixture.file);
const sourceManifest=readdirSync(root+'/rust/tests/unit/specification',{recursive:true}).map(String).filter(name=>name.endsWith('.rs')).sort().map(name=>{const path='rust/tests/unit/specification/'+name;return {path,sha256:hash(readFileSync(root+'/'+path))};});

const before=new Map(baseline.sourceManifest.map(row=>[row.path,row.sha256]));
const after=new Map(sourceManifest.map(row=>[row.path,row.sha256]));
const changedSources=[...new Set([...before.keys(),...after.keys()])].sort().filter(path=>before.get(path)!==after.get(path)).map(path=>({path,before:before.get(path)??null,after:after.get(path)??null}));
const caseChanges=[];
function compare(left,right,path=''){
 if(JSON.stringify(left)===JSON.stringify(right))return;
 if(left&&right&&typeof left==='object'&&typeof right==='object'){
  for(const key of new Set([...Object.keys(left),...Object.keys(right)]))compare(left[key],right[key],path+'/'+key);
 }else caseChanges.push({path,before:left,after:right});
}
compare(baseline.inventory,inventory);
console.log(JSON.stringify({casesBefore:baseline.inventory.cases.length,casesAfter:inventory.cases.length,unsupportedBefore:baseline.inventory.unsupported.length,unsupportedAfter:inventory.unsupported.length,caseChanges,changedSources},null,2));
