from pathlib import Path
import json, os, subprocess, sys, resource
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/layered-followup');out.mkdir(exist_ok=True)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
review=(Path('/tmp/issue-1580-research/layered-assertion-verification/governed-review.mjs').read_text())
review=review[:review.index('const current=')]+r'''
const before=new Map(baseline.sourceManifest.map(row=>[row.path,row.sha256]));
const after=new Map(sourceManifest.map(row=>[row.path,row.sha256]));
const changedSources=[...new Set([...before.keys(),...after.keys()])].sort().filter(path=>before.get(path)!==after.get(path)).map(path=>({path,before:before.get(path)??null,after:after.get(path)??null}));
const caseChanges=[];
function compare(left,right,path=''){
 if(JSON.stringify(left)===JSON.stringify(right))return;
 if(left&&right&&typeof left==='object'&&typeof right==='object'){
  for(const key of new Set([...Object.keys(left),...Object.keys(right)]))compare(left[key],right[key],path+'/'+key);
 }else caseChanges.push({path,before:left,after:right});
}
compare(baseline.inventory,inventory);
console.log(JSON.stringify({casesBefore:baseline.inventory.cases.length,casesAfter:inventory.cases.length,unsupportedBefore:baseline.inventory.unsupported.length,unsupportedAfter:inventory.unsupported.length,caseChanges,changedSources},null,2));
'''
(out/'compact-review.mjs').write_text(review)
with (out/'compact-review.json').open('w') as stream:
 subprocess.run(['node','--max-old-space-size=256',str(out/'compact-review.mjs')],cwd=root,env=env,stdout=stream,check=True)
with (out/'runs.json').open('w') as stream:
 subprocess.run(['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','30','--json','databaseId,workflowName,status,conclusion,createdAt,headSha'],stdout=stream,check=True)
probe=root/'experiments/issue-1580/worker-bootstrap-probe.mjs'
text=probe.read_text()
text=text.replace("record('before offline version resolution');assert.deepEqual(forGeneration(),baselineVersionSet());", "record('before offline version resolution');const actual=forGeneration();record('after resolution before baseline');const expected=baselineVersionSet();record('after baseline before comparison');assert.equal(JSON.stringify(actual),JSON.stringify(expected));")
probe.write_text(text)
# Start with a parse-only host: no worker, source cache, transport or large diff.
code=r'''import {installHost} from '/tmp/gh-issue-solver-1794900398048/js/agentic/host.mjs';
import {parseLino,readRepoFile} from '/tmp/gh-issue-solver-1794900398048/js/server/lino.mjs';
import {baselineVersionSet} from '/tmp/gh-issue-solver-1794900398048/js/agentic/crate/version_resolution.mjs';
installHost({parseLino,readText:readRepoFile});
console.error('before baseline');const result=baselineVersionSet();console.error('after baseline',JSON.stringify(result));'''
(out/'parse-only.mjs').write_text(code)
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(10,12))
 resource.setrlimit(resource.RLIMIT_DATA,(768*1024*1024,768*1024*1024))
with (out/'parse-only.stdout').open('w') as stdout,(out/'parse-only.stderr').open('w') as stderr:
 result=subprocess.run(['node','--max-old-space-size=128',str(out/'parse-only.mjs')],cwd=root,env=env,stdout=stdout,stderr=stderr,preexec_fn=limits)
(out/'outcome.json').write_text(json.dumps({'parseOnlyExit':result.returncode,'fullIssueComplete':False})+'\n')
print((out/'outcome.json').read_text())
