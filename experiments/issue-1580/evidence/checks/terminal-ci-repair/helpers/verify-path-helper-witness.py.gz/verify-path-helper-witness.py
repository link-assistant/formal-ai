from pathlib import Path
import hashlib,json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/path-helper-witness-validation')
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('w') as stream:
        worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);commands=[]
def run(name,args):
    with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
        result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'arguments':args,'exitCode':result.returncode};commands.append(row)
    (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(json.dumps(row),flush=True);assert result.returncode==0,row
try:
    review=json.loads(Path('/tmp/issue-1580-research/path-loaded-test-helpers/compact-review.json').read_text())
    assert review['casesBefore']==review['casesAfter']==221
    assert review['unsupportedBefore']==review['unsupportedAfter']==968
    assert [row['path'] for row in review['caseChanges']]==['/cases/182/program/fixtures/0/sha256','/cases/183/program/fixtures/0/sha256','/cases/185/program/fixtures/0/sha256']
    assert [row['path'] for row in review['changedSources']]==['rust/tests/unit/specification/benchmarks.rs','rust/tests/unit/specification/reasoning_paths_procedures.rs']
    baseline=root/'experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8'
    (out/'baseline-before.v8').write_bytes(baseline.read_bytes())
    sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
    run('reviewed-witness-refresh',['node','--max-old-space-size=256','rust/tests/web/rust-specification-unicode-identifiers.test.mjs','--refresh-reviewed-baseline','--reviewed-reader-sha='+sha(root/'scripts/lib/rust-specification-cases.mjs'),'--previous-baseline-sha='+sha(baseline)])
    for name,file in [
        ('unicode-identifiers','rust/tests/web/rust-specification-unicode-identifiers.test.mjs'),
        ('native-helper-headroom','experiments/issue-1580/native-test-headroom.test.mjs'),
        ('maintained-issue-observations','rust/tests/web/issue-1580-template-observations.test.mjs')]:
        run(name,['node','--max-old-space-size=256','--test','--test-concurrency=1',file])
    for gate in ['check-specification-in-javascript','check-tests-as-docs','check-tests-as-documentation-javascript-twin','check-file-size']:
        run(gate,['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only',gate])
    (out/'outcome.json').write_text(json.dumps({'allPassing':True,'commands':commands,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
