from pathlib import Path
import os,subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/registry-layout-repair');out.mkdir(exist_ok=False)
file=root/'scripts/generate-worker-crate-modules.mjs'
source=file.read_text();(out/'generator-before.mjs').write_text(source)
needle='''export function registryFileOf(seeds, responseSeeds = []) {
  return [
'''
replacement='''export function registryFileOf(seeds, responseSeeds = []) {
  // Pack complete data entries to a readable column limit. Adding a seed does
  // not require raising the worker's reviewed line ceiling.
  const rows = entries => {
    const result = [];
    let row = ' ';
    for (const entry of entries) {
      const token = ' ' + JSON.stringify(entry) + ',';
      if (row.length > 1 && row.length + token.length > 100) {
        result.push(row);
        row = ' ';
      }
      row += token;
    }
    if (row.length > 1) result.push(row);
    return result;
  };
  return [
'''
assert source.count(needle)==1
source=source.replace(needle,replacement)
quote=chr(96); interpolation=chr(36)+'{seed}'
for name in ['seeds','responseSeeds']:
 old='...'+name+'.map((seed) => '+quote+'  "'+interpolation+'",'+quote+'),'
 assert old in source
 source=source.replace(old,'...rows('+name+'),')
file.write_text(source)
test=root/'rust/tests/web/r999-worker-budget-rationale.test.mjs'
text=test.read_text().replace("import {parseLino}","import { parseLino }")
text=text.replace("  assert.equal(actual, registryFileOf(meanings, responses));","  assert.equal(actual, registryFileOf(meanings, responses));\n  for (const line of actual.split('\\n')) assert(line.length <= 100, 'readable generated registry width');")
test.write_text(text)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
commands=[]
for name,args in [
 ('generate',['node','--max-old-space-size=256','scripts/generate-worker-crate-modules.mjs','--write']),
 ('rationale',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/r999-worker-budget-rationale.test.mjs']),
 ('generated',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','worker-crate-modules'])
]:
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 commands.append({'name':name,'arguments':args,'exitCode':result.returncode})
 if result.returncode:break
(out/'outcome.json').write_text(json.dumps({'commands':commands,'allPassing':all(row['exitCode']==0 for row in commands)},indent=2)+'\n')
print((out/'outcome.json').read_text())
