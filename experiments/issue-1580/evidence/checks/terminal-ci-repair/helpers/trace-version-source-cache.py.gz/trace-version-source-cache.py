from pathlib import Path
import subprocess,resource,os,json
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/version-source-cache-trace');out.mkdir(exist_ok=False)
code=r'''import {installNodeHost} from '/tmp/gh-issue-solver-1794900398048/js/agentic/node-host.mjs';
import {host,installHost} from '/tmp/gh-issue-solver-1794900398048/js/agentic/host.mjs';
import {forGeneration,baselineVersionSet} from '/tmp/gh-issue-solver-1794900398048/js/agentic/crate/version_resolution.mjs';
process.env.FORMAL_AI_OFFLINE='1';
console.error('before fake realm installation');await installNodeHost({boot:async()=>({})});
const original=host(),make=original.sourceFetch;
installHost({...original,sourceFetch:()=>{console.error('before source fetch construction');const fetch=make();console.error('after source fetch construction');return url=>{console.error('before fetch',url);const result=fetch(url);console.error('after fetch',url,result===null?'miss':{length:result.text.length,cached:result.cached});return result;};}});
console.error('before generation');const actual=forGeneration();console.error('after generation');const expected=baselineVersionSet();console.error('baselineEqual',JSON.stringify(actual)===JSON.stringify(expected));
'''
(out/'trace.mjs').write_text(code)
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(10,12))
 resource.setrlimit(resource.RLIMIT_DATA,(768*1024*1024,768*1024*1024))
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
with (out/'trace.stdout').open('w') as stdout,(out/'trace.stderr').open('w') as stderr:
 result=subprocess.run(['node','--max-old-space-size=128',str(out/'trace.mjs')],cwd=root,env=env,stdout=stdout,stderr=stderr,preexec_fn=limits)
(out/'outcome.json').write_text(json.dumps({'exitCode':result.returncode,'finiteCPUSeconds':12,'dataLimitBytes':768*1024*1024,'qualificationCredit':0})+'\n')
print((out/'outcome.json').read_text())
