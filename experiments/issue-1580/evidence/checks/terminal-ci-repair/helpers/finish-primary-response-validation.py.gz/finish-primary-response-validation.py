from pathlib import Path
import os,sys,json,subprocess,hashlib,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/primary-response-validation')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);commands=[]
def run(name,args,allowed=[0]):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 row={'name':name,'arguments':args,'exitCode':result.returncode};commands.append(row)
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert result.returncode in allowed,row
try:
 file=root/'rust/tests/web/worker-bootstrap.test.mjs';text=file.read_text()
 text=text.replace('    acknowledgement "three"','    ack_variant "three"').replace('    followup "four"','    follow_up_variant "four"').replace("followups:['four']","followUps:['four']").replace("variants:[],acknowledgements:[],followups:[]","variants:['five'],acknowledgements:[],followUps:[]")
 file.write_text(text)
 for name in ['worker-bootstrap','seed-data-headroom','r999-worker-budget-rationale','bundled-seed-source-parity','release-stage-transfer','typescript-runtime']:
  run(name,['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs'])
 # Gate children inherit a small heap; guarded compiler tests above ran with an
 # empty NODE_OPTIONS. No local native build is requested by this runner.
 env['NODE_OPTIONS']='--max-old-space-size=256'
 run('all-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs'],[0,1])
 (out/'outcome.json').write_text(json.dumps({'commands':commands,'allPassing':all(row['exitCode']==0 for row in commands),'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
