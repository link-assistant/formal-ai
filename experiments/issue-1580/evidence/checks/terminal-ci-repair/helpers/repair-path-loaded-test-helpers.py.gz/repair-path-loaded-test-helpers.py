from pathlib import Path
import json,subprocess,sys,traceback,os,hashlib,gzip,re
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/path-loaded-test-helpers')
pairs=[
 ('rust/tests/unit/agentic-coding/agentic_general_planner','command_capture'),
 ('rust/tests/unit/ci-cd/job_budget_fit','standalone_suites'),
 ('rust/tests/unit/ci-cd/job_budget_fit','link_recheck'),
 ('rust/tests/unit/ci-cd/job_budget_fit','release_preflight'),
 ('rust/tests/unit/ci-cd/pinned_tool_images','image_policy'),
 ('rust/tests/unit/ci-cd/pinned_tool_images','agent_cli'),
 ('rust/tests/unit/ci-cd/release_publishing','artifact_contracts'),
 ('rust/tests/unit/ci-cd/workflow_release','workflow_policy'),
 ('rust/tests/unit/specification/benchmarks','evaluation'),
 ('rust/tests/unit/specification/reasoning_paths_procedures','fixtures'),
 ('rust/tests/unit/docs_requirements','text_haystack'),
 ('rust/tests/integration/with_formal_ai','global_configuration'),
]
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);commands=[]
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 row={'name':name,'arguments':args,'exitCode':result.returncode};commands.append(row)
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert result.returncode in allowed,row
try:
 assert (Path('/tmp/issue-1580-research/primary-response-validation')/'outcome.json').exists(),'wait for preceding full gate run'
 baseline=root/'experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8'
 (out/'baseline-before.v8').write_bytes(baseline.read_bytes())
 file=root/'experiments/issue-1580/native-test-headroom.test.mjs'
 text=file.read_text();assert 'explicitHelperPath' not in text
 text+='''

// A #[path]-loaded owner resolves an unqualified child beside its source file,
// rather than in the ordinary stem directory. Extracted helpers need an
// explicit relative path so the focused and original native targets agree.
function explicitHelperPath(owner, child, source) {
  const declaration = new RegExp('(?:^#\\\\[path = "([^"]+)"\\\\]\\\\n)?^mod ' + child + ';$', 'mu').exec(source);
  assert(declaration?.[1], owner + ' must explicitly locate ' + child);
  const stem = owner.slice(owner.lastIndexOf('/') + 1);
  assert.equal(declaration[1], stem + '/' + child + '.rs');
  const file = resolve(root, dirname(owner), declaration[1]);
  assert(existsSync(file), 'missing extracted native module: ' + file);
  return file;
}

test('path-loaded native owners explicitly resolve every extracted helper', () => {
  const pairs = '''+json.dumps(pairs)+''';
  for (const [owner, child] of pairs) {
    const source = readFileSync(root + '/' + owner + '.rs', 'utf8');
    explicitHelperPath(owner, child, source);
    const attribute = '#[path = "' + owner.slice(owner.lastIndexOf('/') + 1) + '/' + child + '.rs"]\\n';
    assert.throws(() => explicitHelperPath(owner, child, source.replace(attribute, '')),
      /must explicitly locate/u, 'removing the path must reproduce the compile admission failure');
    assert.throws(() => explicitHelperPath(owner, child, source.replace(attribute, '#[path = "missing.rs"]\\n')),
      /AssertionError/u, 'a wrong explicit path must also be rejected');
  }
});
'''
 # Keep the maintained test readable rather than embedding one wide inventory.
 text=text.replace('const pairs = '+json.dumps(pairs)+';', 'const pairs = [\n'+''.join('    '+json.dumps(pair)+',\n' for pair in pairs)+'  ];')
 file.write_text(text)
 run('regression-before',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(file.relative_to(root))],(1,))
 fixture=out/'rustfmt-fixture';(fixture/'suite/owner').mkdir(parents=True)
 (fixture/'root.rs').write_text('#[path = "suite/owner.rs"]\nmod renamed;\n')
 (fixture/'suite/owner.rs').write_text('mod helper;\n')
 (fixture/'suite/owner/helper.rs').write_text('pub(super) fn helper() {}\n')
 run('rustfmt-resolution-before',['rustfmt','--emit','stdout','--config','skip_children=false','--edition','2024',str(fixture/'root.rs')],(1,))
 changes=[]
 for owner,child in pairs:
  file=root/(owner+'.rs');before=file.read_text()
  declaration='mod '+child+';\n';assert before.count(declaration)==1
  attribute='#[path = "'+Path(owner).name+'/'+child+'.rs"]\n'
  after=before.replace(declaration,attribute+declaration)
  assert after.replace(attribute,'',1)==before
  file.write_text(after);changes.append({'owner':owner+'.rs','child':owner+'/'+child+'.rs','attribute':attribute.strip(),'bodyPreserved':True})
 (fixture/'suite/owner.rs').write_text('#[path = "owner/helper.rs"]\nmod helper;\n')
 run('rustfmt-resolution-after',['rustfmt','--emit','stdout','--config','skip_children=false','--edition','2024',str(fixture/'root.rs')])
 run('regression-after',['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/native-test-headroom.test.mjs'])
 paths=sorted(set(owner+'.rs' for owner,_ in pairs))
 run('changed-rust-format',['rustfmt','--check','--config','skip_children=true','--edition','2024',*paths])
 (out/'changes.json').write_text(json.dumps(changes,indent=2)+'\n')
 (out/'outcome.json').write_text(json.dumps({'allExpectedOutcomes':True,'changes':len(changes),'nativeBuildRun':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
