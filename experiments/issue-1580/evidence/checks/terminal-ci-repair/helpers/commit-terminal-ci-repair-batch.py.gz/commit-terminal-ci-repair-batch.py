from pathlib import Path
import gzip,hashlib,json,os,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
out=scratch/'terminal-ci-repair-commit'
evidence=root/'experiments/issue-1580/evidence/checks/terminal-ci-repair'
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('w') as stream:
        worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0'
env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
commands=[]
def run(name,args):
    with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
        result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'arguments':args,'exitCode':result.returncode};commands.append(row)
    (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(json.dumps(row),flush=True);assert result.returncode==0,row
try:
    assert json.loads((scratch/'path-helper-witness-validation/outcome.json').read_text())['allPassing']
    assert json.loads((scratch/'primary-response-validation/outcome.json').read_text())['allPassing']
    ci=json.loads((scratch/'native-ci-ff6-final/outcome.json').read_text())
    assert ci['complete'] and ci['workflowCount']==26 and ci['success']==23 and len(ci['failed'])==2
    full=(scratch/'primary-response-validation/all-local-gates.stdout').read_text()
    counts={key:len(re.findall('^'+key+r' ',full,re.M)) for key in ['PASS','SKIP','FAIL']}
    assert counts=={'PASS':88,'SKIP':53,'FAIL':0},counts
    seed=scratch/'primary-response-headroom'
    before=(seed/'before-runtime.stdout').read_bytes();after=(seed/'after-runtime.stdout').read_bytes()
    assert before==after
    bootstrap=(root/'js/worker-bootstrap-responses.js').read_text()
    assert (seed/'bootstrap-before.js').read_text().split('\n',1)[1]==bootstrap.split('\n',1)[1]
    seedProof={'orderedRuntimeBytes':len(before),'orderedRuntimeSha256':hashlib.sha256(before).hexdigest(),'bootstrapBodyUnchanged':True,'fullIssueComplete':False,'independentAuthorshipCredit':0}
    (out/'seed-proof.json').write_text(json.dumps(seedProof,indent=2)+'\n')
    note=root/'docs/case-studies/issue-1580/terminal-ci-repair-checkpoint.md'
    note.write_text('''# Terminal CI failure repair checkpoint

The published ff6b097f head finishes all 26 workflows: 23 succeed, one is
explicitly skipped, and Layered CI plus CI/CD Pipeline fail. The retained raw
logs identify ten missing extracted native modules, stale release/TypeScript/
notation assertions, and three JavaScript shards reaching their existing
360-second execution deadline.

Twelve explicit relative module paths repair the native admission failure,
including two additional owners with the same layout. Removing each attribute
or substituting a wrong path fails the new maintained regression. A tiny
rustfmt module-resolution fixture fails before the path and passes afterward;
no local native compilation is claimed. Existing Rust assertion bodies remain
unchanged. The reviewed governed witness retains 221 cases and 968 unsupported
items; only the reviewed fixture/source hashes change.

Offline fixture tests now own a fresh temporary source cache. The regression
first proves that offline mode replays a populated caller cache, then proves
the isolated fixture reads the shipped baseline and restores the caller.
Existing product cache behavior and CI deadlines remain unchanged.

Update stale assertions to the checked artifact adapter, actual ordered
TypeScript cases and the canonical notation parser, with negative controls.
Preserve all generated registry entries in readable lines. Splitting complete
response records preserves the ordered runtime snapshot and every bootstrap
response field, while reducing the current file-size warning count to 64.

All 141 local gates were attempted: 88 passed and 53 explicitly require hosted
execution. The focused assertion/cache/bootstrap checks pass, as do the affected
post-path-change specification/documentation gates and maintained issue entry.
Actual native compilation and the complete 903-file hosted JavaScript suite
must still pass on the next head. The 64 remaining warnings, full eight-template
practice comparison and other original acceptance requirements remain open.
Supplied code and commands receive zero independent-authorship credit.

Evidence: experiments/issue-1580/evidence/checks/terminal-ci-repair/ and
experiments/issue-1580/evidence/ci/native-families-final-ff6b097f/.
PR: https://github.com/link-assistant/formal-ai/pull/1581
''')
    plan=root/'experiments/issue-1580/work-plan.md'
    plan.write_text(plan.read_text()+'\n- Terminal ff6b097f review: all 26 workflows completed (23 successful, one skipped, two failed). Repair every identified native module-path failure, stale assertion and caller-cache fixture leak together. All 141 local gates report 88 passes and 53 hosted-only skips; affected post-path-change checks pass. Preserve runtime response bytes and all 221 governed cases. The current warning count is 64; native/full 903-file hosted execution and complete issue acceptance remain open. See [terminal CI repair](../../docs/case-studies/issue-1580/terminal-ci-repair-checkpoint.md).\n')
    (root/'changelog.d/issue-1580-terminal-ci-repair.md').write_text('Repair extracted native test module paths and isolate offline fixture source caches. Update stale release, TypeScript and notation assertions with negative controls; preserve response ordering while splitting the remaining primary response seed and wrapping generated registry entries.\n')
    evidence.mkdir(exist_ok=False);records=[]
    def archive(alias,file):
        raw=file.read_bytes();packed=gzip.compress(raw,mtime=0)
        target=evidence/(alias+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(packed)
        records.append({'file':alias+'.gz','bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
    directories=['layered-assertion-repairs','layered-assertion-verification','layered-followup','layered-followup-verification','registry-layout-repair','version-source-cache-trace','primary-response-headroom','primary-response-validation','path-loaded-test-helpers','path-helper-witness-validation']
    for name in directories:
        for file in sorted((scratch/name).rglob('*')):
            if file.is_file():archive(name+'/'+str(file.relative_to(scratch/name)),file)
    helpers=['draft-layered-assertion-repairs.py','verify-layered-assertion-repairs.py','investigate-layered-followup.py','verify-layered-followup.py','repair-generated-registry-layout.py','trace-version-source-cache.py','split-primary-response-seed.py','finish-primary-response-validation.py','repair-path-loaded-test-helpers.py','verify-path-helper-witness.py','commit-terminal-ci-repair-batch.py']
    for name in helpers:archive('helpers/'+name,scratch/name)
    for file in sorted((root/'experiments/formal_ai_subagent/sandboxes/gates').iterdir()):
        if file.is_file():archive('latest-local-gate-logs/'+file.name,file)
    for name in ['outcome.json','runs.json','pipeline-jobs.json']:
        file=scratch/'native-ci-ff6-final'/name
        if file.exists():archive('terminal-hosted-observation/'+name,file)
    archive('seed-proof.json',out/'seed-proof.json')
    (evidence/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
    run('stage-tracked',['git','add','-u'])
    run('stage-new',['git','add','--','data/seed/multilingual-responses-administration.lino','rust/embedded/data/seed/multilingual-responses-administration.lino','experiments/issue-1162/offline-source-cache.mjs','rust/tests/web/offline-source-cache.test.mjs','experiments/issue-1580/worker-bootstrap-probe.mjs',str(evidence.relative_to(root)),str(note.relative_to(root)),'changelog.d/issue-1580-terminal-ci-repair.md','experiments/issue-1580/evidence/ci/native-families-ff6b097f','experiments/issue-1580/evidence/ci/native-families-final-ff6b097f','experiments/issue-1580/evidence/ci/superseded-6672bfc9-cancellation'])
    run('naming',['node','scripts/measure-abbreviations.mjs','--check'])
    staged=subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=ACMRT','-z'],cwd=root).decode().split('\0')[:-1]
    run('secrets',['bash','scripts/check-secrets.sh',*staged])
    run('whitespace',['git','diff','--cached','--check'])
    run('commit',['git','-c','gc.auto=0','commit','-m','Repair all terminal native and layered CI failures'])
    (out/'outcome.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'allPassing':True,'warnings':64,'pushed':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
