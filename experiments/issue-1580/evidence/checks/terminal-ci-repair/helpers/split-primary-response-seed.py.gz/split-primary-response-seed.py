from pathlib import Path
import os,sys,subprocess,json,hashlib,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'primary-response-headroom'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);commands=[]
def run(name,args,allowed=[0]):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 row={'name':name,'arguments':args,'exitCode':result.returncode};commands.append(row)
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert result.returncode in allowed,row
try:
 snapshot=scratch/'seed-record-headroom-split-retry/snapshot.mjs'
 run('before-runtime',['node','--max-old-space-size=256',str(snapshot)])
 source=root/'data/seed/multilingual-responses.lino';original=source.read_text();(out/'original.lino').write_text(original)
 bootstrap=root/'js/worker-bootstrap-responses.js';beforeBootstrap=bootstrap.read_text();(out/'bootstrap-before.js').write_text(beforeBootstrap)
 # Complete record boundary: keep protocol, greeting and tool-result readers in
 # the primary seed. Later language records are merged by the bootstrap writer.
 marker='  response response_lexeme_import_refused_batch_en\n'
 assert original.count(marker)==1
 offset=original.index(marker);header='multilingual_responses\n'
 assert original.startswith(header)
 first,second=original[:offset],header+original[offset:]
 assert first[len(header):]+second[len(header):]==original[len(header):]
 assert max(len(first.splitlines()),len(second.splitlines()))<900
 source.write_text(first)
 (root/'data/seed/multilingual-responses-administration.lino').write_text(second)
 mutation=out/'register.mjs'
 mutation.write_text(r'''import {readFileSync,writeFileSync} from 'node:fs';
import {parseRegistry,canonicalize,renderRegistry,registryHeader} from '/tmp/gh-issue-solver-1794900398048/scripts/generate-seed-registry.mjs';
const path='/tmp/gh-issue-solver-1794900398048/data/meta/seed-registry.lino',source=readFileSync(path,'utf8'),registry=parseRegistry(source);
const original=registry.seeds.find(seed=>seed.name==='multilingual-responses');
if(!original?.bundle||!original.web||!original.lexicon.has('response'))throw Error('original response consumers required');
if(registry.seeds.some(seed=>seed.name==='multilingual-responses-administration'))throw Error('duplicate shard');
registry.seeds.push({...original,name:'multilingual-responses-administration',lexicon:new Set(original.lexicon)});
writeFileSync(path,renderRegistry(canonicalize(registry),registryHeader(source)));
''')
 run('register',['node','--max-old-space-size=256',str(mutation)])
 file=root/'scripts/generate-worker-bootstrap.mjs';text=file.read_text()
 text=text.replace("export const SOURCE = 'data/seed/multilingual-responses.lino';","export const SOURCE = 'data/seed/multilingual-responses.lino';\nexport const SOURCES = Object.freeze([SOURCE, 'data/seed/multilingual-responses-administration.lino']);\nexport function readBootstrapSeeds(root) {\n  return SOURCES.map(source => readFileSync(path.join(root, source), 'utf8'));\n}")
 text=text.replace("  const responses = api.extractMultilingualResponses(api.parse(seed));","  const responses = Object.create(null);\n  for (const document of Array.isArray(seed) ? seed : [seed]) {\n    for (const [intent, languages] of Object.entries(api.extractMultilingualResponses(api.parse(document)))) {\n      Object.assign(responses[intent] ??= Object.create(null), languages);\n    }\n  }")
 text=text.replace("'+SOURCE+'; do not edit","'+SOURCES.join(', ')+'; do not edit")
 text=text.replace("readFileSync(path.join(root,SOURCE),'utf8')","readBootstrapSeeds(root)")
 file.write_text(text)
 file=root/'scripts/check-prompt-specialization.mjs';text=file.read_text().replace("renderBootstrap, SOURCE as RESPONSE_SEED","renderBootstrap, readBootstrapSeeds").replace("read(RESPONSE_SEED)","readBootstrapSeeds(root)");file.write_text(text)
 file=root/'rust/tests/web/worker-bootstrap.test.mjs';text=file.read_text().replace("renderBootstrap, SOURCE, OUTPUT","renderBootstrap, readBootstrapSeeds, OUTPUT").replace("const seed = readFileSync(SOURCE,'utf8');","const seed = readBootstrapSeeds(new URL('../../../',import.meta.url).pathname);")
 text+=r'''
test('bootstrap projection preserves every field while merging response shards', () => {
  const context = vm.createContext({}); context.self = context;
  const first = 'multilingual_responses\n  response first\n    intent arbitrary\n    language en\n    text "one"\n    variant "two"\n    acknowledgement "three"\n    followup "four"\n';
  const second = 'multilingual_responses\n  response second\n    intent arbitrary\n    language ru\n    text "five"\n';
  vm.runInContext(renderBootstrap(loader,[first,second]),context);
  assert.deepEqual(JSON.parse(JSON.stringify(context.FORMAL_AI_BOOTSTRAP_RESPONSES.arbitrary)), {
    en: {text:'one',variants:['two'],acknowledgements:['three'],followups:['four']},
    ru: {text:'five',variants:[],acknowledgements:[],followups:[]},
  });
});
test('offline entry retains moved administration responses in all original languages', () => {
  const context = createWorkerContext({fetch:()=>Promise.reject(new Error('offline'))});
  for (const language of ['en','ru','hi','zh']) {
    assert.equal(evaluate(context,'answerFor("lexeme_import_refused_batch", "'+language+'")'),
      evaluate(context,'self.FORMAL_AI_BOOTSTRAP_RESPONSES.lexeme_import_refused_batch.'+language+'.text'));
    assert(evaluate(context,'self.FORMAL_AI_BOOTSTRAP_RESPONSES.budget_search_solution.'+language+'.text').includes('{expression}'));
  }
});
'''
 file.write_text(text)
 file=root/'rust/tests/web/seed-data-headroom.test.mjs';text=file.read_text().replace("const pairs=[","const pairs=[\n  ['multilingual-responses','multilingual-responses-administration','response'],");file.write_text(text)
 for name,args in [
  ('registry',['node','--max-old-space-size=256','scripts/generate-seed-registry.mjs','--write']),
  ('package-mirror',['node','--max-old-space-size=256','scripts/mirror-package-data.mjs','--write']),
  ('web-mirror',['bash','scripts/sync-seed.sh']),
  ('worker-registry',['node','--max-old-space-size=256','scripts/generate-worker-crate-modules.mjs','--write']),
  ('typescript',['node','--max-old-space-size=256','scripts/translate-es.mjs','--write']),
 ]:run(name,args)
 run('after-runtime',['node','--max-old-space-size=256',str(snapshot)])
 before=(out/'before-runtime.stdout').read_bytes();after=(out/'after-runtime.stdout').read_bytes()
 assert before==after,'ordered meanings/responses changed'
 afterBootstrap=bootstrap.read_text()
 assert beforeBootstrap.split('\n',1)[1]==afterBootstrap.split('\n',1)[1],'bootstrap response objects or fields changed'
 for name in ['worker-bootstrap','seed-data-headroom','r999-worker-budget-rationale','bundled-seed-source-parity']:
  run(name,['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs'])
 result={'shardLines':[len(first.splitlines()),len(second.splitlines())],'exactRecordInverse':True,'runtimeExactBytes':True,'runtimeSha256':hashlib.sha256(before).hexdigest(),'bootstrapBodyUnchanged':True,'fullIssueComplete':False,'independentAuthorshipCredit':0}
 (out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
except BaseException:
 (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
