from pathlib import Path
import os,sys,subprocess,json,hashlib,resource,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/layered-followup-verification')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);commands=[]
def run(name,args,bounded=False):
 def limits():
  resource.setrlimit(resource.RLIMIT_CPU,(50,55))
  resource.setrlimit(resource.RLIMIT_DATA,(1024*1024*1024,1024*1024*1024))
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr,preexec_fn=limits if bounded else None)
 row={'name':name,'arguments':args,'exitCode':result.returncode};commands.append(row)
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(row),flush=True)
 return result.returncode
try:
 # Compact full-object review was read before this explicit witness refresh.
 review=json.loads(Path('/tmp/issue-1580-research/layered-followup/compact-review.json').read_text())
 assert review['casesBefore']==review['casesAfter']==221
 assert review['unsupportedBefore']==review['unsupportedAfter']==968
 assert len(review['caseChanges'])==9 and len(review['changedSources'])==4
 baseline=root/'experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8'
 (out/'governed-baseline-before.v8').write_bytes(baseline.read_bytes())
 (out/'reviewed-delta.json').write_text(json.dumps(review,indent=2)+'\n')
 hash=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 args=['node','--max-old-space-size=256','rust/tests/web/rust-specification-unicode-identifiers.test.mjs','--refresh-reviewed-baseline','--reviewed-reader-sha='+hash(root/'scripts/lib/rust-specification-cases.mjs'),'--previous-baseline-sha='+hash(baseline)]
 assert run('refresh-reviewed-witness',args)==0
 for name in ['offline-source-cache','issue-1168-version-resolution-parity','issue-1168-workflow-render-parity','rust-specification-unicode-identifiers']:
  run(name,['node','--max-old-space-size=256','--test','--test-concurrency=1','--test-timeout=60000','rust/tests/web/'+name+'.test.mjs'],bounded=True)
 run('generated-workers',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-worker-crate-modules'])
 (out/'outcome.json').write_text(json.dumps({'commands':commands,'allPassing':all(row['exitCode']==0 for row in commands),'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
