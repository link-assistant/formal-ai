from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/layered-assertion-repairs')
out.mkdir(exist_ok=False)
paths=['rust/tests/web/typescript-runtime.test.mjs','rust/tests/web/r999-worker-budget-rationale.test.mjs','rust/tests/web/release-stage-transfer.test.mjs']
for path in paths:(out/(Path(path).name+'.before')).write_bytes((root/path).read_bytes())
p=root/paths[0];text=p.read_text();old="  assert.equal(result.cases.length, 4);"
new="""  assert.deepEqual(result.cases, [
    'three multilingual calculations with independent numeric oracle',
    'real filesystem source write',
    'compiled dynamic meta recipe',
    'missing owned projection refuses despite existing JS source',
    'altered TS identity refuses',
  ]);"""
assert text.count(old)==1;p.write_text(text.replace(old,new))
p=root/paths[1];text=p.read_text();text=text.replace("import test from 'node:test';","import test from 'node:test';\nimport {parseLino} from '../../../js/server/lino.mjs';",1)
old="""    const module = /^\\s*module "([^"]+)"/m.exec(text)?.[1];
    const ceiling = Number(/^\\s*ceiling (\\d+)/m.exec(text)?.[1]);
    const rationale = /^\\s*rationale "([\\s\\S]*)"\\s*$/m.exec(text)?.[1] ?? '';
    shards.set(module, { name, ceiling, rationale });"""
new="""    const {module, ceiling, rationale} = budgetFields(text);
    shards.set(module, { name, ceiling, rationale });"""
assert text.count(old)==1;text=text.replace(old,new)
marker='/** Line count as the gate counts it'
new="""function budgetFields(text) {
  const document = parseLino(text);
  const value = key => document.children.find(child => child.name === key)?.value ?? '';
  return {module: value('module'), ceiling: Number(value('ceiling')), rationale: value('rationale')};
}

test('budget rationale accepts both Links Notation quote forms and preserves emptiness', () => {
  for (const rationale of ['"Written reason"', "'Written reason'"]) {
    assert.deepEqual(budgetFields('worker_module_budget\\n  module "fixture.js"\\n  ceiling 9\\n  rationale ' + rationale + '\\n'),
      {module: 'fixture.js', ceiling: 9, rationale: 'Written reason'});
  }
  for (const rationale of ['""', "''"]) {
    assert.equal(budgetFields('worker_module_budget\\n  rationale ' + rationale + '\\n').rationale, '');
  }
});

"""
assert text.count(marker)==1;text=text.replace(marker,new+marker);p.write_text(text)
p=root/paths[2];text=p.read_text()
old="      assert.equal(sourceDownload.with['digest-mismatch'], 'error');"
new="""      assert.equal(sourceDownload.uses, './_protocol/.github/actions/download-artifact');
      assert.deepEqual(Object.keys(sourceDownload.with).sort(), ['artifact-ids', 'path'],
        'the checked adapter takes only its supported source identity and destination');
      assert.ok(job.steps.indexOf(sourceDownload) < job.steps.findIndex(step =>
        step.run === 'node _protocol/scripts/release-stage-transfer.mjs verify-source'),
        'independent descriptor and source-byte verification follows the checked transfer');"""
assert text.count(old)==1;text=text.replace(old,new)
marker="  const mutations = [candidate => candidate.jobs['auto_verify-package']"
replacement="""  const mutations = [
    candidate => candidate.jobs['auto_compile-release'].steps.find(step =>
      step.name === 'Download immutable selected source artifact').uses = 'actions/download-artifact@v5',
    candidate => candidate.jobs['auto_compile-release'].steps.find(step =>
      step.name === 'Download immutable selected source artifact').with['digest-mismatch'] = 'error',
    candidate => candidate.jobs['auto_verify-package']"""
assert text.count(marker)==1;text=text.replace(marker,replacement);p.write_text(text)
(out/'outcome.json').write_text(json.dumps({'drafted':paths,'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
