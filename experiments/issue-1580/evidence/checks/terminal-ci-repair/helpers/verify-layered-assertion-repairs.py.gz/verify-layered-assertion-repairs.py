from pathlib import Path
import json,os,resource,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'layered-assertion-verification'
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:
        worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(json.dumps({'pid':worker.pid,'finite':True}));sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);commands=[]
def run(name,args,limit_cpu=False):
    def bounded_cpu():resource.setrlimit(resource.RLIMIT_CPU,(40,45))
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr,preexec_fn=bounded_cpu if limit_cpu else None)
    row={'name':name,'arguments':args,'exitCode':result.returncode};commands.append(row)
    (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(row),flush=True)
    return result.returncode
try:
    code=out/'governed-review.mjs'
    code.write_text(r'''import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {deserialize} from 'node:v8';import {createHash} from 'node:crypto';import {resolve,relative,isAbsolute} from 'node:path';
import {specificationCases} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/rust-specification-cases.mjs';
const root='/tmp/gh-issue-solver-1794900398048',out='/tmp/issue-1580-research/layered-assertion-verification/';
const hash=value=>createHash('sha256').update(value).digest('hex');
const baseline=deserialize(readFileSync(root+'/experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8'));
const inventory=specificationCases(root);
for(const item of inventory.cases)for(const fixture of item.program?.fixtures??[])if(isAbsolute(fixture.file))fixture.file='repo:'+relative(root,fixture.file);
const sourceManifest=readdirSync(root+'/rust/tests/unit/specification',{recursive:true}).map(String).filter(name=>name.endsWith('.rs')).sort().map(name=>{const path='rust/tests/unit/specification/'+name;return {path,sha256:hash(readFileSync(root+'/'+path))};});
const current={inventory,sourceManifest},changes=[];
function compare(left,right,path=''){
 if(JSON.stringify(left)===JSON.stringify(right))return;
 if(left&&right&&typeof left==='object'&&typeof right==='object'){
  for(const key of new Set([...Object.keys(left),...Object.keys(right)]))compare(left[key],right[key],path+'/'+key);
 }else changes.push({path,before:left,after:right});
}
compare(baseline,current);
writeFileSync(out+'governed-review-delta.json',JSON.stringify({casesBefore:baseline.inventory.cases.length,casesAfter:inventory.cases.length,unsupportedBefore:baseline.inventory.unsupported.length,unsupportedAfter:inventory.unsupported.length,changes},null,2)+'\n');
console.log(JSON.stringify({changes:changes.length,cases:inventory.cases.length,unsupported:inventory.unsupported.length}));
''')
    assert run('governed-review',['node','--max-old-space-size=512',str(code)])==0
    for name in ['release-stage-transfer','r999-worker-budget-rationale','typescript-runtime']:
        run(name,['node','--max-old-space-size=512','--test','--test-concurrency=1','--test-timeout=60000','rust/tests/web/'+name+'.test.mjs'])
    probe=root/'experiments/issue-1580/worker-bootstrap-probe.mjs'
    probe.write_text(r'''#!/usr/bin/env node
// Finite investigation only. No runtime, native or authorship qualification.
const started=performance.now();
const record=stage=>console.error(JSON.stringify({stage,seconds:(performance.now()-started)/1000,memory:process.memoryUsage()}));
const deadline=setTimeout(()=>{record('bounded probe deadline');process.exit(1);},45000);
const heartbeat=setInterval(()=>record('pending bootstrap'),5000);heartbeat.unref();
try{
  process.env.FORMAL_AI_OFFLINE='1';
  record('before module import');
  const {WorkerHost}=await import('../../js/server/worker-host.mjs');
  record('before worker boot');
  const worker=new WorkerHost();await worker.boot();
  record('after worker boot');
  const {installNodeHost}=await import('../../js/agentic/node-host.mjs');
  record('before host installation');await installNodeHost(worker);
  record('after host installation');
  const {forGeneration,baselineVersionSet}=await import('../../js/agentic/crate/version_resolution.mjs');
  const assert=(await import('node:assert/strict')).default;
  record('before offline version resolution');assert.deepEqual(forGeneration(),baselineVersionSet());
  record('after offline version resolution');
}finally{clearTimeout(deadline);clearInterval(heartbeat);}
''')
    run('worker-bootstrap-probe',['node','--max-old-space-size=384',str(probe)],True)
    (out/'outcome.json').write_text(json.dumps({'commands':commands,'allPassing':all(row['exitCode']==0 for row in commands),'fullIssueComplete':False},indent=2)+'\n')
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
