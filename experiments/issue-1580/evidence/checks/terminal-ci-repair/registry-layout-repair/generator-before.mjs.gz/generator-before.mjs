#!/usr/bin/env node
// Generate the browser worker's copies of the crate modules the chat routes
// call (R1188-U18, U19, U21): text formalization, dependency summarization,
// page formalization and round-trip translation; and the event log's evidence
// projection every answer carries (R1188-U29).
//
// The browser worker is a classic script (js/worker/formal_ai_worker.js loads
// its modules with `importScripts`), so it cannot import the ES modules of
// js/agentic/crate/. Instead of a second, hand-kept port, every module in the
// import closure of the entry modules below is written to
// js/worker/formal_ai_worker_crate_<name>.js as a factory:
//
//   (self.FORMAL_AI_CRATE_FACTORIES ||= {})["crate/text_formalization.mjs"] =
//     (crateRequire) => { <the module body>; return { <its exports> }; };
//
// Its body preserves module tokens and comments, with each `import` turned
// into a `crateRequire` of the module it names and each `export` keyword
// dropped. Over-budget factories collapse blank trivia and reflow generated headers/export lists.
// A factory runs on first use, so the worker loads the files in any
// order. js/worker/formal_ai_worker_crate_modules.js instantiates them and
// installs the worker as the host of js/agentic/host.mjs.
//
// host.mjs reads the seed registry to find the meaning lexicon's files; the
// browser does not fetch data/meta/, so the registry's meaning seeds are
// written to formal_ai_worker_crate_seed_registry.js in its order.
//
// Usage:
//   node scripts/generate-worker-crate-modules.mjs --write   regenerate the files
//   node scripts/generate-worker-crate-modules.mjs --check   fail when a file drifts (CI gate)

import { existsSync, readFileSync, readdirSync, unlinkSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

import { REPO_ROOT } from '../js/server/lino.mjs';
import { tokenize, layoutOf, renderSource } from './translate-es.mjs';

/** The modules the chat routes call; their import closure is generated. */
export const ENTRY_MODULES = Object.freeze([
  'crate/cnl_output.mjs',
  'crate/command_output_contract.mjs',
  'crate/conversation_summary.mjs',
  'crate/concise_dependency_restatement.mjs',
  'crate/dependency_summarization.mjs',
  'crate/event_log.mjs',
  'crate/fact_derivation.mjs',
  'crate/literal_authoring_contract.mjs',
  'crate/literal_content.mjs',
  'crate/meta_executor.mjs',
  'crate/page_formalization.mjs',
  'crate/skill_compiler.mjs',
  'crate/skill_procedure.mjs',
  'crate/skill_procedure_artifact.mjs',
  'crate/solver_formalization.mjs',
  'crate/solver_event_projection.mjs',
  'crate/requirement_extraction.mjs',
  'crate/round_trip_translation.mjs',
  'crate/theorem_claim_binding.mjs',
  'crate/unread_structure.mjs',
]);

const AGENTIC_ROOT = 'js/agentic';
const WORKER_ROOT = 'js/worker';
const FILE_PREFIX = 'formal_ai_worker_crate_';
const REGISTRY_FILE = `${FILE_PREFIX}seed_registry.js`;
const LOADER_FILE = `${FILE_PREFIX}modules.js`;
const SEED_REGISTRY = 'data/meta/seed-registry.lino';
const COMMAND = 'node scripts/generate-worker-crate-modules.mjs --write';

const IMPORT = /^(?:import|export)\s*\{([^}]*)\}\s*from\s*'([^']+)';\n/gmu;
const EXPORT_DECLARATION = /^export (async function|function|const|let|class) ([A-Za-z_$][\w$]*)/gmu;
const LOCAL_EXPORT = /^export\s*\{([^}]*)\};\n/gmu;

/**
 * The module name of `specifier` imported from `from`, both relative to
 * js/agentic (`crate/x.mjs`, `host.mjs`).
 * @param {string} from
 * @param {string} specifier
 */
export function resolveModule(from, specifier) {
  return path.posix.normalize(path.posix.join(path.posix.dirname(from), specifier));
}

/** Local export clauses preserve the existing binding and its public alias. */
function localExportBindings(source) {
  const pairs = [...source.matchAll(LOCAL_EXPORT)].flatMap((match) =>
    match[1].split(',').map((binding) => {
      const [local, exposed = local] = binding.trim().split(/\s+as\s+/u);
      return [exposed, local];
    }).filter(([exposed, local]) => exposed && local));
  return new Map(pairs);
}

/** The names a module exports, in source order. @param {string} source */
export function exportedNames(source) {
  const declared = [...source.matchAll(EXPORT_DECLARATION)].map((match) => match[2]);
  const forwarded = [...source.matchAll(IMPORT)].filter((match) => match[0].startsWith('export'))
    .flatMap((match) => match[1].split(',').map((binding) => binding.trim().split(/\s+as\s+/u).at(-1)).filter(Boolean));
  return [...new Set([...declared, ...forwarded, ...localExportBindings(source).keys()])];
}

/**
 * The bindings of one import list as a destructuring pattern
 * (`a, b as c` gives `a, b: c`).
 * @param {string} list
 */
export function bindingPattern(list) {
  return list
    .split(',')
    .map((binding) => binding.trim())
    .filter(Boolean)
    .map((binding) => binding.replace(/^([\w$]+)\s+as\s+([\w$]+)$/u, '$1: $2'))
    .join(', ');
}

/**
 * The modules `name` imports, as `{module, pattern, text}` with the import
 * statement's text.
 * @param {string} name
 * @param {string} source
 */
export function importsOf(name, source) {
  return [...source.matchAll(IMPORT)].map((match) => ({
    module: resolveModule(name, match[2]),
    pattern: bindingPattern(match[1]),
    text: match[0],
  }));
}

/**
 * The import closure of `entries`, dependencies before the modules that
 * import them.
 * @param {readonly string[]} entries
 * @param {(name: string) => string} read
 */
export function importClosure(entries, read) {
  const order = [];
  const visit = (name) => {
    if (order.includes(name)) return;
    order.push(name);
    for (const dependency of importsOf(name, read(name))) visit(dependency.module);
  };
  for (const entry of entries) visit(entry);
  return order.sort();
}

/**
 * The worker file a module is written to.
 * @param {string} name
 */
export function workerFileOf(name) {
  const stem = path.posix.basename(name, '.mjs');
  return `${FILE_PREFIX}${stem}.js`;
}

/**
 * The factory text of one module.
 * @param {string} name
 * @param {string} source
 */
/** Collapse blank whitespace only, preserving comments, literals and ASI newlines. */
export function compactFactoryLayout(source, ceiling) {
  if (!Number.isSafeInteger(ceiling) || ceiling < 1) throw new Error('Invalid worker ceiling');
  const count = text => text === '' ? 0 : text.split('\n').length - Number(text.endsWith('\n'));
  if (count(source) <= ceiling) return source;
  const trees = tokenize(source);
  const compact = trivia => {
    let result = '';
    let cursor = 0;
    for (const match of trivia.matchAll(/[/][/][^\n]*(?:\n|$)|[/]\*[\s\S]*?\*[/]|\s+/gu)) {
      if (match.index !== cursor) throw new Error('Unsupported worker trivia');
      cursor += match[0].length;
      const part = match[0];
      if (part.startsWith('//') || part.startsWith('/*')) result += part;
      else {
        let space = part.replace(/\n(?:[ \t\f\r]*\n)+/gu, '\n');
        if (result.endsWith('\n')) space = space.replace(/^[ \t\f\r]*\n/u, '');
        result += space;
      }
    }
    if (cursor !== trivia.length) throw new Error('Unsupported worker trivia');
    return result;
  };
  const result = renderSource(trees, layoutOf(source, trees).map(compact));
  if (JSON.stringify(tokenize(result)) !== JSON.stringify(trees)) throw new Error('Worker token drift');
  if (count(result) > ceiling) throw new Error('Worker cannot fit unchanged ceiling with blank trivia alone');
  new vm.Script(result);
  return result;
}

/** Read the exact source-owned reviewed budget; missing or ambiguous values refuse. */
function reviewedCeiling(file) {
  const shard = path.join(REPO_ROOT, 'data/meta/worker-line-budget', file.replace(/\.js$/u, '.lino'));
  const text = readFileSync(shard, 'utf8');
  const modules = [...text.matchAll(/^\s*module "([^"]+)"\s*$/gmu)];
  const values = [...text.matchAll(/^\s*ceiling (\d+)\s*$/gmu)];
  const value = Number(values[0]?.[1]);
  if (modules.length !== 1 || modules[0][1] !== file || values.length !== 1
    || !Number.isSafeInteger(value) || value < 1) throw new Error('Invalid reviewed worker budget');
  return value;
}

export function factoryOf(name, source, ceiling = null) {
  let body = source;
  for (const dependency of importsOf(name, source)) {
    const binding = `const { ${dependency.pattern} } = crateRequire("${dependency.module}");\n`;
    body = body.replace(dependency.text, binding);
  }
  body = body.replace(EXPORT_DECLARATION, '$1 $2').replace(LOCAL_EXPORT, '');
  const aliases = localExportBindings(source);
  const exports = exportedNames(source).map((exported) => {
    const local = aliases.get(exported) ?? exported;
    return local === exported ? `  ${exported},` : `  ${exported}: ${local},`;
  }).join('\n');
  const text = [
    `// Generated by \`${COMMAND}\``,
    `// from ${AGENTIC_ROOT}/${name}.`,
    '// Do not edit by hand: edit that module and regenerate. The browser worker',
    '// cannot import ES modules, so the module is a factory that',
    '// formal_ai_worker_crate_modules.js runs on first use.',
    '',
    `(self.FORMAL_AI_CRATE_FACTORIES ||= {})["${name}"] = (crateRequire) => {`,
    body.trimEnd(),
    '',
    'return Object.freeze({',
    exports,
    '});',
    '};',
    '',
  ].join('\n');
  // Validate the classic-script target before any generated file is written.
  new vm.Script(text, { filename: workerFileOf(name) });
  if (ceiling === null) return text;
  try {
    return compactFactoryLayout(text, ceiling);
  } catch (error) {
    if (error.message !== 'Worker cannot fit unchanged ceiling with blank trivia alone') throw error;
  }
  // Only generated export-list trivia may be reflowed. Source-owned comments,
  // literals and ASI boundaries remain the existing compactor's responsibility.
  const rows = [];
  let row = '  ';
  for (const binding of exports.split('\n').map(line => line.trim()).filter(Boolean)) {
    if (row.length > 2 && row.length + binding.length + 1 > 80) {
      rows.push(row);
      row = '  ';
    }
    row += (row.length > 2 ? ' ' : '') + binding;
  }
  if (row.length > 2) rows.push(row);
  const tail = 'return Object.freeze({\n' + exports + '\n});\n};\n';
  if (!text.endsWith(tail)) throw new Error('Unexpected generated factory footer');
  const header = text.split('\n').slice(0, 5).join('\n');
  const compactHeader = [
    `// Generated by \`${COMMAND}\``,
    `// Source: ${AGENTIC_ROOT}/${name}. Edit source and regenerate.`,
    '// Do not edit by hand; formal_ai_worker_crate_modules.js runs this factory.',
  ].join('\n');
  const reflowed = (text.slice(0, -tail.length)
    + 'return Object.freeze({\n' + rows.join('\n') + '\n});\n};\n')
    .replace(header, compactHeader);
  if (JSON.stringify(tokenize(reflowed)) !== JSON.stringify(tokenize(text))) {
    throw new Error('Worker export-layout token drift');
  }
  return compactFactoryLayout(reflowed, ceiling);
}

/**
 * The seeds the registry gives the meaning lexicon, in its order.
 * @param {string} registry
 */
export function meaningSeeds(registry, lexicon = 'meaning') {
  const seeds = [];
  let current = null;
  for (const line of registry.split('\n')) {
    const seed = /^ {2}seed (\S+)\s*$/u.exec(line);
    if (seed) {
      current = seed[1];
      continue;
    }
    if (current !== null && /^ {4}lexicon (\S+)\s*$/u.exec(line)?.[1] === lexicon) seeds.push(current);
  }
  return seeds;
}

/**
 * The registry file text.
 * @param {string[]} seeds
 */
export function registryFileOf(seeds, responseSeeds = []) {
  return [
    `// Generated by \`${COMMAND}\``,
    `// from ${SEED_REGISTRY}. Do not edit by hand.`,
    '// Ordered meaning and response seeds; the browser does not fetch the registry.',
    'self.FORMAL_AI_CRATE_MEANING_SEEDS = Object.freeze([',
    ...seeds.map((seed) => `  "${seed}",`),
    ']);',
    'self.FORMAL_AI_CRATE_RESPONSE_SEEDS = Object.freeze([',
    ...responseSeeds.map((seed) => `  "${seed}",`),
    ']);',
    '',
  ].join('\n');
}

/** Every generated file, as a map from its worker path to its text. */
export function generatedFiles() {
  const read = (name) => readFileSync(path.join(REPO_ROOT, AGENTIC_ROOT, name), 'utf8');
  const files = new Map();
  for (const name of importClosure(ENTRY_MODULES, read)) {
    files.set(`${WORKER_ROOT}/${workerFileOf(name)}`, factoryOf(name, read(name), reviewedCeiling(workerFileOf(name))));
  }
  const registry = readFileSync(path.join(REPO_ROOT, SEED_REGISTRY), 'utf8');
  files.set(`${WORKER_ROOT}/${REGISTRY_FILE}`, registryFileOf(meaningSeeds(registry), meaningSeeds(registry, 'response')));
  const inventory = 'js/worker-modules.js';
  const entries = readdirSync(path.join(REPO_ROOT, WORKER_ROOT), {withFileTypes: true})
    .filter(entry => entry.isFile()).map(entry => entry.name);
  files.set(inventory, workerModuleInventory(readFileSync(path.join(REPO_ROOT, inventory), 'utf8'), entries, files));
  return files;
}

/** Preserve the inventory's comments while deriving every current module from its owner. */
export function workerModuleInventory(current, entries, generated) {
  const marker = 'self.FORMAL_AI_WORKER_MODULES = Object.freeze([';
  const at = current.indexOf(marker);
  if (at < 0 || current.indexOf(marker, at + marker.length) >= 0 || !current.endsWith(']);\n')) {
    throw new Error('Malformed worker module inventory');
  }
  const names = new Set(entries.filter(name => name.endsWith('.js') && name !== 'formal_ai_worker.js'
    && (!name.startsWith(FILE_PREFIX) || name === LOADER_FILE || generated.has(`${WORKER_ROOT}/${name}`))));
  for (const file of generated.keys()) {
    if (file.startsWith(`${WORKER_ROOT}/`) && file.endsWith('.js')) names.add(path.posix.basename(file));
  }
  const rows = [...names].sort((left, right) => Buffer.compare(Buffer.from(left), Buffer.from(right))).map(name => `  ${JSON.stringify('worker/' + name)},`);
  return current.slice(0, at) + marker + '\n' + rows.join('\n') + '\n]);\n';
}

/** The generated worker files on disk now (the hand-written loader excluded). */
function filesOnDisk() {
  return readdirSync(path.join(REPO_ROOT, WORKER_ROOT))
    .filter((file) => file.startsWith(FILE_PREFIX) && file !== LOADER_FILE)
    .map((file) => `${WORKER_ROOT}/${file}`);
}

function main(argv) {
  const write = argv.includes('--write');
  const expected = generatedFiles();
  const drift = [];
  for (const [file, text] of expected) {
    const full = path.join(REPO_ROOT, file);
    if (existsSync(full) && readFileSync(full, 'utf8') === text) continue;
    drift.push(file);
    if (write) writeFileSync(full, text);
  }
  for (const file of filesOnDisk()) {
    if (expected.has(file)) continue;
    drift.push(file);
    if (write) unlinkSync(path.join(REPO_ROOT, file));
  }
  if (write) {
    console.log(`${expected.size} worker crate files, ${drift.length} rewritten.`);
    return 0;
  }
  if (drift.length === 0) {
    console.log(`The ${expected.size} worker crate files are current.`);
    return 0;
  }
  console.error(`Stale worker crate files (run \`${COMMAND}\`):`);
  for (const file of drift) console.error(`  ${file}`);
  return 1;
}

if (import.meta.url === `file://${process.argv[1]}`) process.exitCode = main(process.argv.slice(2));
