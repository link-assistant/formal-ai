from pathlib import Path
import gzip, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
base = root / 'experiments/issue-1580/evidence/ci/native-families-3bb3083b'
assessment = json.loads((base / 'assessment.json').read_text())
assert assessment['verifiedStreams'] == 296 and assessment['nativeRustPassingTests'] == 528
assert assessment['nativeRustFailingTests'] == 0 and assessment['successfulWorkflows'] == 26
annotations = json.loads((base / 'workflow-annotations.json').read_text())
errors = [row for row in annotations if row['level'] == 'error' and not row['quotedShellSource']]
sizes = [row for row in annotations if row['level'] == 'warning' and 'approaching limit of' in row['text'] and not row['quotedShellSource']]
assert len(errors) == 1 and errors[0]['line'] == 660 and 'deliberate fallback control' in errors[0]['text']
assert len(sizes) == 119
assessment['emittedDiagnosticsClassification'] = {'remainingSourceSizeWarnings': 119,
    'publishTokenCertaintyWarnings': 1, 'deliberatelyInjectedCanonicalOutageError': 1,
    'unresolvedOtherErrors': 0,
    'negativeControlEvidence': 'full-run-44764893157.stdout.gz:660; exact image command at 657, explicit failure state at 661, verified mirror container in buildkit-bootstrap-3bb3083b/assessment.json'}
(base / 'assessment.json').write_text(json.dumps(assessment, indent=2) + '\n')
text = '''# Hosted bootstrap and security checkpoint on 3bb3083b

All 27 workflows on published head `3bb3083ba9d91dbb3b45386083875a1adb9a92f2`
are terminal: 26 succeed and one is explicitly skipped. Every one of the 296
collected command streams matches its original/compressed hash, byte count and
line count. The earlier stale Layered profile assertion no longer fails.

[CI/CD Pipeline 44764893448](https://github.com/link-assistant/formal-ai/actions/runs/44764893448)
passes 528 actual Rust cases across nine native jobs, with no Rust failures.
The release registry job also passes eight actual Python-driven CLI cases
(`job-136387247048.stdout.gz`, lines 757–759). This does not qualify changed
original fixtures as unchanged historical contracts or prove all three moved
script test modules execute in this focused job. Complete summary line numbers
and original job logs are retained in `native-families-3bb3083b/`.

[Workflows 44764893157](https://github.com/link-assistant/formal-ai/actions/runs/44764893157)
verifies two actual BuildKit daemon starts and mirror recovery through the real
official setup action. The wrapper/probe/workflow bytes match the published
head and tested merge; both containers bind to the same pinned image ID.
See [the detailed bootstrap checkpoint](buildkit-bootstrap-identity-checkpoint.md).
Its one error annotation is the deliberately injected canonical pull failure,
not an unexamined failure: full log lines 657–661 show the exact pin, injection
and expected canonical failure before the verified mirror start. No annotations
are removed or hidden. Application image publication remains unverified.

[Manual Security 44765053281](https://github.com/link-assistant/formal-ai/actions/runs/44765053281)
retains original CodeQL 2.27.5 Rust and Actions SARIF with zero findings and
zero warning/error notifications, including omitted-level warning semantics.
All 2,576 expected Rust paths are extracted; exact-message crosswalk verifies
all 105 formerly context-free paths. The 631 informational unresolved macro
records still need semantic qualification. The new local default-off observer
has not yet compiled or run on a hosted database. Original reports and identities
are in `codeql-producer-3bb3083b/`.

The fresh full workflow logs still emit 119 source-size warnings and one
crates.io token-certainty warning. Preserve these as unfinished requirements.
Earlier 122 warnings precede the three structural script splits; ceilings are
unchanged. Dependencies, original/budget contracts, Pages publication and served
identity, eight full template comparisons/practices, delivery/provenance and
complete pull-request review remain open. Strict original-byte replay evidence
stays 31/53 and independent accepted reasoning stays 0/20.

The next local repair batch is separately verified: three runtime regressions
fail on original bytes and pass after repair; four maintenance, 16 retry,
three actual HTTP and 19 security adapter groups pass. Five touched gates and
whitespace pass. See [the local repair checkpoint](macro-observation-and-runtime-budget-checkpoint.md).
The entire issue remains unfinished and [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581)
stays draft and unmerged.
'''
(root / 'docs/case-studies/issue-1580/hosted-bootstrap-and-security-3bb3083b-checkpoint.md').write_text(text)
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- Exact published 3bb3083b collection completes: 27 terminal workflows (26 success / one skip), all 296 command streams identity-verified, 528 native Rust and eight actual release CLI cases pass. All diagnostics are classified: 119 remaining source-size warnings, one token-certainty warning and one deliberate canonical-outage error with subsequent verified actual mirror recovery. Original SARIF/path evidence is retained without semantic-macro or changed-original-fixture credit. Complete feedback is unchanged; gh pr diff explicitly fails HTTP 406 at its 300-file limit, so retain that failure and use exact local Git comparisons for review. Broader requirements remain unfinished.\n')

archive = root / 'experiments/issue-1580/evidence/checks/terminal-bootstrap-head-assessment'
archive.mkdir(exist_ok=False)
records = []
def capture(name, path):
    raw = path.read_bytes(); packed = gzip.compress(raw, mtime=0)
    target = archive / (name + '.gz'); target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(packed)
    records.append({'file': name + '.gz', 'rawSha256': hashlib.sha256(raw).hexdigest(),
                    'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
for stem in ['assess-terminal-bootstrap-head', 'document-terminal-bootstrap-head', 'collect-next-repair-head-ci']:
    for suffix in ['.py', '.log']:
        path = scratch / (stem + suffix)
        if path.is_file() and path.stat().st_size:
            capture('helpers/' + path.name, path)
capture('collector-worker.log', scratch / 'next-repair-head-ci/worker.log')
for path in sorted((scratch / 'next-repair-head-ci').glob('*.json')):
    capture('collector/' + path.name, path)
for name, argv in [('current-source-diff', ['git', 'diff', '3bb3083ba9d91dbb3b45386083875a1adb9a92f2', 'HEAD']),
                   ('published-file-list', ['git', 'diff', '--name-status', 'origin/main...3bb3083ba9d91dbb3b45386083875a1adb9a92f2'])]:
    result = subprocess.run(argv, cwd=root, capture_output=True)
    assert result.returncode == 0
    path = scratch / (name + '.txt'); path.write_bytes(result.stdout); capture(name + '.txt', path)
(archive / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
publication = scratch / 'macro-batch-publication'; publication.mkdir(exist_ok=False)
body = (scratch / 'next-repair-publication/pull-request-body.md').read_text()
start = body.index('- Published `763713221c0681393da9266d9ffc9cc7c2bbefe2` finishes')
end = body.index('- Published `8c712eb980e777b9fe16beaca4d9d78d649be2bb` finishes', start)
body = body[:start] + '''- Published `3bb3083ba9d91dbb3b45386083875a1adb9a92f2` finishes all 27 workflows: 26 success and one explicit skip. [CI/CD Pipeline 44764893448](https://github.com/link-assistant/formal-ai/actions/runs/44764893448) passes 528 native Rust and eight actual release CLI cases; all 296 collected command streams are hash/byte/line verified. The stale Layered assertion is repaired. [Exact-head checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/hosted-bootstrap-and-security-3bb3083b-checkpoint.md) retains original logs and limits.
- [Workflows 44764893157](https://github.com/link-assistant/formal-ai/actions/runs/44764893157) boots two real BuildKit v0.35.1 daemons at the pinned digest. One deliberately failed canonical pull exercises the actual official setup fallback; the mirror starts a real running container with the same image ID. All 25 original artifact streams and byte-identical published/merge sources are verified. The intentional negative control emits one classified error annotation; application image publication is still unverified. [Bootstrap evidence](https://github.com/link-assistant/formal-ai/tree/issue-1580-8d61a32a61e1/experiments/issue-1580/evidence/ci/buildkit-bootstrap-3bb3083b).
- [Manual Security 44765053281](https://github.com/link-assistant/formal-ai/actions/runs/44765053281) preserves original Rust/Actions SARIF with zero findings and zero warning/error notifications. All 2,576 expected Rust source paths are extracted, including all 105 formerly context-free paths. The 631 informational unresolved macro records remain unqualified. A default-off read-only observer now retains the producer database/pack identity, exact query, BQRS and decoded AST contexts; its local adapter tests do not prove QL compilation or hosted semantics.
- Three new regressions fail on original bytes and pass after repair: reject a partial failed Git maintenance inventory before any resolver, stop retry waits before the shared budget expires and cap each request at its remaining allowance. Four maintenance, 16 retry, three real HTTP and 19 security adapter groups pass, alongside five touched gates and whitespace. [Local checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/macro-observation-and-runtime-budget-checkpoint.md) retains failed controls and all corrected evidence. No local Rust/QL compilation runs.

''' + body[end:]
body = body.replace('Rust literal source review covers 289/373 files and 34,914 lines; 84 files', 'Rust literal source review covers 309/373 files and 37,626 lines; 64 files')
body = body.replace('fresh hosted verification of the new script splits, stale-profile assertion repair and actual BuildKit daemon/fallback probe;', 'fresh hosted compilation/execution of the new macro observer and runtime repairs; the remaining moved script module test execution;')
body = body.replace('- Pin every BuildKit setup', '- Reject failed maintenance lock enumeration before any resolver; enforce one shared retry/request budget. Add a default-off Rust macro-context observation using the original read-only security database and bundled pack.\n- Pin every BuildKit setup', 1)
(publication / 'pull-request-body.md').write_text(body)
print('Terminal checkpoint recorded; evidence records:', len(records), '; PR body bytes:', len(body.encode()))
