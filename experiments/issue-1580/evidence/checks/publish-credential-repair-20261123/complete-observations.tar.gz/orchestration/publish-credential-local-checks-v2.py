from pathlib import Path
import ast,json,os,runpy,subprocess,sys,tempfile
root=Path('/tmp/issue-1580-research/publish-credential-repair');root.mkdir(exist_ok=True)
p=Path('scripts/publish-crate.rs');repaired=p.read_bytes()
old=subprocess.check_output(['git','show','bc08222b5a5195dc9992c0459bde2b6369377b9f:scripts/publish-crate.rs'])
test=['node','--test','--test-concurrency=1','--test-name-pattern=publishing credentials','experiments/issue-1580/native-regression-groups.test.mjs']
try:
 p.write_bytes(old)
 with (root/'before-javascript-contract.log').open('wb') as stream:
  before=subprocess.run(test,stdout=stream,stderr=subprocess.STDOUT).returncode
finally:p.write_bytes(repaired)
with (root/'after-javascript-contract.log').open('wb') as stream:
 after=subprocess.run(test,stdout=stream,stderr=subprocess.STDOUT).returncode
assert before!=0 and after==0,(before,after)
for path in ['cli_regressions.py','publish_process_regressions.py']:
 ast.parse(Path('experiments/issue-1580/release-registry',path).read_text())
sys.dont_write_bytecode=True
m=runpy.run_path('experiments/issue-1580/release-registry/publish_process_regressions.py')
with tempfile.TemporaryDirectory(prefix='publish-local-controls-') as directory:
 f=type('Fixture',(m['PublishProcessRegressions'],),{})()
 f.work=Path(directory)/'work';f.work.mkdir();f.env=dict(os.environ)
 f.publish_stub();f.env['CARGO_REGISTRY_TOKEN']='fixture-local-token'
 result=subprocess.run(['cargo','publish','--allow-dirty','-p','fixture'],cwd=f.work,env=f.env,capture_output=True,text=True)
 receipt=json.loads(f.publish_receipt.read_text())
 assert result.returncode==0 and receipt['token']=='fixture-local-token'
 assert receipt['arguments']==['publish','--allow-dirty','-p','fixture'] and receipt['cwd']==str(f.work)
 f.publish_stub('auth-failed')
 result=subprocess.run(['cargo','publish'],cwd=f.work,env=f.env,capture_output=True,text=True)
 assert result.returncode==101 and 'unauthorized' in result.stderr
 scripts=Path(directory)/'scripts';scripts.mkdir()
 controls=m['add_publish_process_controls'](Path('experiments/issue-1580/release-registry'),scripts)
 assert (scripts/'publish-crate-before-token-fix.rs').read_bytes()==old
 assert 'name = "publish-crate-before-token-fix"' in controls
with (root/'full-javascript-contracts.log').open('wb') as stream:
 full=subprocess.run(['node','--test','--test-concurrency=1','experiments/issue-1580/native-regression-groups.test.mjs'],stdout=stream,stderr=subprocess.STDOUT).returncode
with (root/'rustfmt.log').open('wb') as stream:
 fmt=subprocess.run(['rustfmt','--check','scripts/publish-crate.rs'],stdout=stream,stderr=subprocess.STDOUT).returncode
result={'beforeJavaScriptContractExit':before,'afterJavaScriptContractExit':after,'allNativeGroupJavaScriptContractsExit':full,'rustfmtExit':fmt,'pythonSyntaxFiles':2,'recordingCargoStubControls':2,'originalBinaryFixtureHashAndBytesVerified':True,'newNativeExecutionCredit':0,'hostedCliCasesPending':5}
(root/'local-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
assert full==fmt==0
