from pathlib import Path
import subprocess,os,time,datetime,json
root=Path('/tmp/issue-1580-research/scheduling-contracts-53816/pre-push-scan')
env=os.environ.copy();env['BASE_REF']='53816c9eb4bd11729a8be347ccd9497d07042660'
command=['bash','scripts/check-secrets.sh'];start=time.monotonic()
with (root/'masked-scan.log').open('wb') as out:r=subprocess.run(command,env=env,stdout=out,stderr=subprocess.STDOUT)
(root/'outcome.json').write_text(json.dumps({'command':command,'baseRef':env['BASE_REF'],'exitCode':r.returncode,'seconds':time.monotonic()-start,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
