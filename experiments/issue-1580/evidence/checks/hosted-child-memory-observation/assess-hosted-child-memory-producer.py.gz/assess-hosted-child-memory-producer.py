from pathlib import Path
import gzip, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
base = root / 'experiments/issue-1580/evidence/ci/codeql-producer-9fd9360d'
outcome = json.loads((base / 'outcome.json').read_text())
assert outcome['complete'] and outcome['conclusion'] == 'success'
inventory = base / 'producer-files.json'
original = inventory.read_bytes()
rows = json.loads(original)
assert isinstance(rows, list)
renames = []
for row in rows:
    old = row['file']
    new = old.replace('_temp_', '_temporary_')
    packed = (base / old).read_bytes()
    assert hashlib.sha256(packed).hexdigest() == row['archiveSha256']
    raw = gzip.decompress(packed)
    assert hashlib.sha256(raw).hexdigest() == row['rawSha256']
    assert len(raw) == row['bytes'] and len(raw.splitlines()) == row['lines']
    if new != old:
        assert not (base / new).exists()
        (base / old).rename(base / new)
        row['file'] = new
        renames.append({'old': old, 'new': new, 'archiveSha256': row['archiveSha256']})
(base / 'original-producer-inventory.json.gz').write_bytes(gzip.compress(original, mtime=0))
parts = []
for start in range(0, len(rows), 40):
    name = 'producer-files-part-' + str(start // 40 + 1) + '.json'
    content = (json.dumps(rows[start:start + 40], indent=2) + '\n').encode()
    assert len(content.splitlines()) <= 1400
    (base / name).write_bytes(content)
    parts.append({'file': name, 'records': len(rows[start:start + 40]), 'sha256': hashlib.sha256(content).hexdigest()})
inventory.write_text(json.dumps({'format': 'partitioned-producer-inventory', 'records': len(rows), 'parts': parts,
    'originalInventory': {'file': 'original-producer-inventory.json.gz', 'rawSha256': hashlib.sha256(original).hexdigest(),
                          'bytes': len(original), 'lines': len(original.splitlines())}}, indent=2) + '\n')
(base / 'archive-path-renames.json').write_text(json.dumps(renames, indent=2) + '\n')
source = (scratch / 'assess-current-explicit-heap-producer.py').read_text()
assert source.count('codeql-producer-90b51590') == 1
source = source.replace('codeql-producer-90b51590', 'codeql-producer-9fd9360d')
marker = "assessment = {'head': outcome['head']"
assert source.count(marker) == 1
checks = '''resolved = json.loads(raw('macro-contexts/memory.stdout'))
assert resolved == manifest['resolvedMemory']['arguments']
assert manifest['resolvedMemory']['totalMiB'] == 4096 and manifest['resolvedMemory']['offHeapMiB'] == 0
assert 2048 <= manifest['resolvedMemory']['heapMiB'] <= 4096
assert manifest['queryRuntimeDiagnostics'] == [] and warnings == []
command_map = {command['name']: command for command in manifest['commands']}
for name in ['memory', 'query']:
    argv = command_map[name]['argv']
    assert '--ram=4096' in argv and '--off-heap-ram=0' in argv
    assert command_map[name]['exitCode'] == 0
assert any(value.startswith('--dataset=') and value.endswith('/db-rust') for value in command_map['memory']['argv'])
assert all(report['results'] == 0 and report['warningErrorNotifications'] == 0 for report in reports.values())
'''
source = source.replace(marker, checks + marker)
source = source.replace("'queryCompiledAndExecuted': True", "'resolvedMemory': manifest['resolvedMemory'], 'queryRuntimeDiagnostics': manifest['queryRuntimeDiagnostics'], 'queryCompiledAndExecuted': True")
target = scratch / 'assess-hosted-child-memory-macro-observations.py'
assert not target.exists()
target.write_text(source)
result = subprocess.run(['python3', str(target)], cwd=root, capture_output=True)
for label in ['stdout', 'stderr']:
    (scratch / ('assess-hosted-child-memory-macro-observations.' + label)).write_bytes(getattr(result, label))
assert result.returncode == 0, result.stderr
print(result.stdout.decode())
