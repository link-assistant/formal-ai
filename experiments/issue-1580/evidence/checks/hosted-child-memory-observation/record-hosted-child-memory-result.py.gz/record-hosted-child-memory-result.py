from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
base = root / 'experiments/issue-1580/evidence/ci/codeql-producer-9fd9360d'
assessment = json.loads((base / 'macro-observation-assessment.json').read_text())
assert assessment['resolvedMemory']['heapMiB'] == 2607
assert assessment['queryRuntimeDiagnostics'] == []
assert assessment['producerFilesVerified'] == 126
assert not assessment['allMacroSemanticsQualified'] and not assessment['fullIssueComplete']
read_log = (scratch / 'read-hosted-child-memory-streams.log').read_text()
assert 'Exit Code: 0' in read_log and 'Compiled ' in read_log and 'Evaluation done' in read_log
archive = root / 'experiments/issue-1580/evidence/checks/hosted-child-memory-observation'
archive.mkdir(exist_ok=False)
files = [Path(__file__), *[scratch / name for name in ['collect-child-memory-producer-reports.py', 'assess-hosted-child-memory-producer.py', 'assess-hosted-child-memory-producer.log', 'assess-hosted-child-memory-macro-observations.py', 'assess-hosted-child-memory-macro-observations.stdout', 'assess-hosted-child-memory-macro-observations.stderr', 'read-hosted-child-memory-streams.py', 'read-hosted-child-memory-streams.log']], *[path for path in (scratch / 'child-memory-producer-original-reports').iterdir() if path.is_file()]]
entries = []
for path in sorted(files):
    raw = path.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    target = archive / (path.name + '.gz')
    assert not target.exists()
    target.write_bytes(packed)
    entries.append({'file': target.name, 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
(archive / 'records.json').write_text(json.dumps({'observedAt': datetime.now(timezone.utc).isoformat(), 'entries': entries, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
checkpoint = root / 'docs/case-studies/issue-1580/codeql-child-memory-checkpoint.md'
old = '''Actual new-head resolution, successful hosted query execution without runtime
diagnostics and every original semantic requirement remain unverified until a
new producer runs. Current native jobs are still being collected; the next push
must wait for their complete failures. Strict original source identity remains
31/53 with 22 separate scoped assertion reviews. Full issue completion is false;
independently accepted reasoning remains 0/20 and supplied scripts earn zero.
'''
new = '''## Published producer verification

The next exact-head read-only producer at
`9fd9360d88d084aeee109ebf8375cde3cd816ff1` succeeds in
[run 44813086995](https://github.com/link-assistant/formal-ai/actions/runs/44813086995).
All 126 original payloads pass compressed/raw SHA-256, byte and line checks.
The original database resolver returns `-J-Xmx2607M` at `memory.stdout` line 2;
its stderr is empty. Manifest lines 24–44 record successful resolution against
the completed `db-rust` dataset with `--ram=4096 --off-heap-ram=0`.
The query receives the same policy at manifest lines 47–70 and exits zero.
Its original nine-line stderr records compilation in 20.3 seconds at line 6
and evaluation in 53.5 seconds at line 8, with no runtime warning/error line.
No local native build or query execution is used for this verification.

Both original SARIF reports have zero findings and zero warning/error
notifications. The decoded query still has 122,534 rows from 2,216 files, with
the same 631 unexpanded contexts at all 631 original notification positions.
The warning-free evaluator verifies this memory repair; the positional
crosswalk still does not qualify generated-child security/dataflow semantics.
Original payloads and the machine assessment are retained in
[`codeql-producer-9fd9360d`](../../../experiments/issue-1580/evidence/ci/codeql-producer-9fd9360d/).

Current native jobs are still being collected; the next push must wait for all
actionable failures. Strict original source identity remains 31/53 with 22
separate scoped assertion reviews. Full issue completion is false;
independently accepted reasoning remains 0/20 and supplied scripts earn zero.
'''
text = checkpoint.read_text()
assert text.count(old) == 1
checkpoint.write_text(text.replace(old, new))
print(json.dumps({'archiveEntries': len(entries), 'head': assessment['head'], 'resolvedHeapMiB': 2607, 'queryRuntimeDiagnostics': [], 'allMacroSemanticsQualified': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}))
