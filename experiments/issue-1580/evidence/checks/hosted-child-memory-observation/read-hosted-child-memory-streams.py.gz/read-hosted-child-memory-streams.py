from pathlib import Path
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/ci/codeql-producer-9fd9360d'
inventory = json.loads((base / 'producer-files.json').read_text())
rows = []
for part in inventory['parts']:
    value = (base / part['file']).read_bytes()
    assert hashlib.sha256(value).hexdigest() == part['sha256']
    rows.extend(json.loads(value))
lookup = {row['relativePath']: row for row in rows}
for name in ['macro-contexts/memory.stdout', 'macro-contexts/memory.stderr', 'macro-contexts/query.stdout', 'macro-contexts/query.stderr', 'macro-contexts/manifest.json']:
    row = lookup[name]
    packed = (base / row['file']).read_bytes()
    assert hashlib.sha256(packed).hexdigest() == row['archiveSha256']
    raw = gzip.decompress(packed)
    assert hashlib.sha256(raw).hexdigest() == row['rawSha256']
    lines = raw.decode().splitlines()
    assert len(lines) == row['lines'] and len(raw) == row['bytes']
    assert len(lines) <= 1500 and len(raw) < 23000
    print(json.dumps({'path': name, 'sha256': row['rawSha256'], 'bytes': len(raw), 'lines': len(lines)}))
    for number, line in enumerate(lines, 1):
        print(str(number) + ': ' + line)
