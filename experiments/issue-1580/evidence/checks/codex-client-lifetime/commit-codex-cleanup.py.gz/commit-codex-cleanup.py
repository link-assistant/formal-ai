from pathlib import Path
import subprocess,json,gzip,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');o=Path('/tmp/issue-1580-research/runtime-cleanup')
p=r/'data/benchmarks/focused-test-map.json';s=p.read_text();needle='''    {
      "id": "workflow-policy",''';assert s.count(needle)==1
s=s.replace(needle,'''    {
      "id": "codex-client-process-lifetime",
      "reasons": [],
      "description": "The integration client stops its plugin clone descendants before removing CODEX_HOME, preserving the client exit status.",
      "tests": ["experiments/issue-1580/codex-process-lifetime.test.mjs"]
    },
'''+needle)
needle='''  "components": [\n''';assert s.count(needle)==1
s=s.replace(needle,needle+'''    { "prefixes": ["experiments/issue_859_codex_e2e/", "experiments/issue-1580/codex-process-lifetime.test.mjs"], "families": ["codex-client-process-lifetime"] },
''');p.write_text(s)
with (o/'focused-test-map-after.log').open('w') as log:
 p=subprocess.run(['node','--test','--test-concurrency=1','rust/tests/web/focused-test-map.test.mjs'],cwd=r,stdout=log,stderr=subprocess.STDOUT)
print('MAP TEST',p.returncode);print((o/'focused-test-map-after.log').read_text());assert p.returncode==0
archive=r/'experiments/issue-1580/evidence/checks/codex-client-lifetime';archive.mkdir(parents=True,exist_ok=True)
manifest=[]
for name in ['run.before.sh','codex-lifetime-before.log','codex-lifetime-after.log','codex-lifetime-both-routes.log','codex-lifetime-both-routes-final.log','focused-test-map-after.log','cleanup-gate-workflows.log','cleanup-gate-file-size.log','cleanup-gate-check-file-size.log','cleanup-gate-check-abbreviations.log','cleanup-gate-check-readable-code.log']:
 p=o/name
 if p.is_file():
  raw=p.read_bytes();(archive/(name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));manifest.append({'file':name+'.gz','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
for name in ['draft-owned-codex.py','finish-cleanup-tests.py','repair-bunx-fixture.py','commit-codex-cleanup.py']:
 p=Path('/tmp/issue-1580-research')/name;raw=p.read_bytes();(archive/(name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));manifest.append({'file':name+'.gz','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
(archive/'manifest.json').write_text(json.dumps({'authorship':'Supplied procedures; independent Formal AI authorship is zero.','files':manifest},indent=2)+'\n')
doc=r/'docs/case-studies/issue-1580/codex-client-lifetime.md'
doc.write_text('''# Codex integration client lifetime

Published run [44992281354](https://github.com/link-assistant/formal-ai/actions/runs/44992281354), job 137115847267, completed all 228 workflow-contract tests and the real Codex report scenario before failing at cleanup. The raw job log lines 2498–2500 show the successful scenario followed by `rm: cannot remove` on a still-changing `codex/.tmp/plugins-clone-…/plugins` directory. Killing the API server and proxy did not stop descendants of the already-exited Codex client.

The client launcher now creates an owned process group for both the explicit binary and Bun package invocation. After the foreground client exits, it terminates the remaining group, escalates to SIGKILL after a finite grace period, and verifies that no live group members remain before returning. Zombies are already stopped and do not block removal. The original client exit status is preserved; failed liveness inspection or unconfirmed cleanup fails the invocation. Optional `FORMAL_AI_TRACE_CODEX_LIFETIME=1` prints the group and completed cleanup receipt; tracing defaults off. The artifact version query uses the same launcher.

The finite regression probe launches a parent that returns while a child still owns its output pipe. All five cases fail with the original actual `codex_cli` declaration. All ten cases pass after the fix, covering success/failure exits, short-lived and longer-lived descendants, and both binary and Bun routes. The Linux subreaper fixture reaps every child and limits memory, stack, and worker lifetime. This validates the launcher boundary; another actual hosted Codex replay remains required.

The regression is registered in the existing focused-test map for changes to the integration experiment. The maintained map tests and workflow, file-size, abbreviation, and readability gates pass. Complete negative controls, intermediate fixture mistakes, final outputs, source preimage, and supplied procedures are retained in `experiments/issue-1580/evidence/checks/codex-client-lifetime/`. These supplied changes have no independent Formal AI authorship credit.
''')
(r/'changelog.d/20261122064000-codex-client-lifetime.md').write_text('Fix integration cleanup by stopping Codex plugin-clone descendants before deleting their temporary home.\n')
plan=r/'experiments/issue-1580/work-plan.md'
plan.write_text(plan.read_text()+'''\n## Codex integration cleanup follow-up, 2026-11-22

- Published 754fd314 job 137115847267 ran the native parser contracts successfully, then failed removing the Codex plugin-clone directory (raw lines 2498–2500).
- The actual client launcher now stops and observes its owned process group before returning. Five original-launcher negative controls fail; ten fixed-launcher cases and the focused-map test pass. Hosted replay is pending. See `docs/case-studies/issue-1580/codex-client-lifetime.md`.
- Supplied implementation and procedures retain zero independent authorship credit. The historical Agent recipe failure and GPU dependency warnings remain unresolved.
''')
paths=['experiments/issue_859_codex_e2e/run.sh','experiments/issue_859_codex_e2e/own-process-group.py','experiments/issue-1580/codex-process-lifetime.test.mjs','data/benchmarks/focused-test-map.json',str(archive.relative_to(r)),str(doc.relative_to(r)),'changelog.d/20261122064000-codex-client-lifetime.md','experiments/issue-1580/work-plan.md']
subprocess.run(['git','add',*paths],cwd=r,check=True)
subprocess.run(['git','commit','-m','fix: stop Codex client descendants before temporary-home cleanup'],cwd=r,check=True)
print(subprocess.run(['git','status','--short'],cwd=r,capture_output=True,text=True).stdout)
