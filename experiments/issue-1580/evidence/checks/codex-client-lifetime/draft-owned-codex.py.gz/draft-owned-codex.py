from pathlib import Path
import subprocess, json, shutil
r=Path('/tmp/gh-issue-solver-1794900398048');o=Path('/tmp/issue-1580-research/runtime-cleanup');o.mkdir(exist_ok=True)
p=r/'experiments/issue_859_codex_e2e/run.sh'
s=p.read_text();(o/'run.before.sh').write_text(s)
old='''    "$CODEX_BIN" "$@"
  else
    bunx --package "@openai/codex@$CODEX_VERSION" codex "$@"'''
assert s.count(old)==1
new='''    python3 "$ROOT/experiments/issue_859_codex_e2e/own-process-group.py" "$CODEX_BIN" "$@"
  else
    python3 "$ROOT/experiments/issue_859_codex_e2e/own-process-group.py" \\
      bunx --package "@openai/codex@$CODEX_VERSION" codex "$@"'''
p.write_text(s.replace(old,new))
helper=r/'experiments/issue_859_codex_e2e/own-process-group.py'
helper.write_text('''#!/usr/bin/env python3
"""Wait for a client, then stop its remaining helpers before releasing its home."""
import json
import os
import signal
import subprocess
import sys
import time


def signal_group(group, value):
    try:
        os.killpg(group, value)
    except ProcessLookupError:
        pass


def live_group(group):
    result = subprocess.run(["ps", "-eo", "pgid=,stat="], check=True,
                            stdout=subprocess.PIPE, encoding="utf-8", timeout=2)
    return any(len(fields) == 2 and fields[0] == str(group)
               and not fields[1].startswith(("Z", "X"))
               for fields in (line.split() for line in result.stdout.splitlines()))


def stop_group(group):
    # The client can exit while a plugin clone still writes in CODEX_HOME.
    # A group leader's exit alone therefore cannot certify safe directory removal.
    signal_group(group, signal.SIGTERM)
    try:
        for _ in range(10):
            if not live_group(group):
                return
            time.sleep(0.05)
        signal_group(group, signal.SIGKILL)
        for _ in range(40):
            if not live_group(group):
                return
            time.sleep(0.05)
        raise RuntimeError("client process group still has live descendants")
    except BaseException:
        signal_group(group, signal.SIGKILL)
        raise


def main(arguments):
    if not arguments:
        raise ValueError("a client command is required")
    process = subprocess.Popen(arguments, start_new_session=True)
    def cancel(value, _frame):
        signal_group(process.pid, value)
        raise SystemExit(128 + value)
    signal.signal(signal.SIGTERM, cancel)
    signal.signal(signal.SIGINT, cancel)
    try:
        status = process.wait()
    finally:
        stop_group(process.pid)
        process.wait()
    if os.environ.get("FORMAL_AI_TRACE_CODEX_LIFETIME") == "1":
        print(json.dumps({"client_group": process.pid, "cleanup_complete": True,
                          "status": status}), file=sys.stderr)
    return status if status >= 0 else 128 - status


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
''')
test=r/'experiments/issue-1580/codex-process-lifetime.test.mjs'
test.write_text('''import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {mkdtempSync, readFileSync, rmSync, writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import test from 'node:test';
import {fileURLToPath} from 'node:url';

const root = fileURLToPath(new URL('../../', import.meta.url));
const probe = join(root, 'experiments/issue-1580/probe-budget-process-lifetime.py');
const source = process.env.FORMAL_AI_CODEX_LIFETIME_SOURCE
  ?? join(root, 'experiments/issue_859_codex_e2e/run.sh');
const declaration = readFileSync(source, 'utf8').match(/^codex_cli\\(\\) \\{\\n[\\s\\S]*?^\\}/mu)?.[0];
assert.ok(declaration, 'exercise the actual integration client launcher');
for (const [fixture, status] of [
  ['expired-parent-success', 0], ['expired-parent-failure', 7],
  ['term-resistant', 0], ['short-success', 0], ['short-failure', 7],
]) {
  test(`Codex launcher stops descendants before returning: ${fixture}`, {
    skip: process.platform !== 'linux' && 'fixture needs the Linux child-subreaper API',
    timeout: 15000,
  }, () => {
    const directory = mkdtempSync(join(tmpdir(), 'codex-child-regression-'));
    try {
      const adapter = join(directory, 'adapter.sh'), output = join(directory, 'observation.json');
      writeFileSync(adapter, 'shift 2\\nROOT="$CODEX_FIXTURE_ROOT"\\nCODEX_BIN="$1"\\nshift\\n'
        + declaration + '\\ncodex_cli "$@"\\n');
      const observed = spawnSync('python3', [probe, adapter, output, '--case', fixture], {
        env: {...process.env, CODEX_FIXTURE_ROOT: root}, encoding: 'utf8',
        timeout: 12000, maxBuffer: 65536,
      });
      assert.equal(observed.status, 0, observed.stderr);
      const result = JSON.parse(readFileSync(output, 'utf8'));
      assert.equal(result.exitCode, status, JSON.stringify(result));
      assert.equal(result.workerRunningWhenWrapperExited, false, JSON.stringify(result));
      assert.match(result.stdout, /fixture stdout/u);
      assert.match(result.stderr, /fixture stderr/u);
      assert.ok(result.pipeClosedSeconds < 3.5, JSON.stringify(result));
    } finally {
      rmSync(directory, {recursive: true, force: true});
    }
  });
}
''')
env={**__import__('os').environ,'FORMAL_AI_CODEX_LIFETIME_SOURCE':str(o/'run.before.sh')}
for name,environment in [('before',env),('after',None)]:
 with (o/f'codex-lifetime-{name}.log').open('w') as log:
  result=subprocess.run(['node','--test','--test-concurrency=1',str(test)],cwd=r,env=environment,stdout=log,stderr=subprocess.STDOUT)
 print(name,result.returncode);print((o/f'codex-lifetime-{name}.log').read_text())
 assert (result.returncode!=0 if name=='before' else result.returncode==0)
