from pathlib import Path
import subprocess,os,json
r=Path('/tmp/gh-issue-solver-1794900398048');o=Path('/tmp/issue-1580-research/runtime-cleanup')
for args in [['rg','-n','deadline-process-lifetime|fast-pull-request-javascript-tests|experiments/issue-1580/.*test','scripts/ci-pull-request-admission.mjs','scripts/js-test-files.mjs','experiments/formal_ai_subagent/local-gates.mjs','data/benchmarks'],['node','experiments/formal_ai_subagent/local-gates.mjs','--list'],['git','status','--short']]:
 p=subprocess.run(args,cwd=r,capture_output=True,text=True);print(args,p.returncode,p.stdout[:12000],p.stderr)
# The launcher has both an explicit binary and a Bun package path. Run the same
# finite ownership probe against both actual routes, including --version cleanup.
t=r/'experiments/issue-1580/codex-process-lifetime.test.mjs';s=t.read_text()
s=s.replace("for (const [fixture, status] of [", "for (const route of ['binary', 'bunx']) for (const [fixture, status] of [")
s=s.replace('`Codex launcher stops descendants before returning: ${fixture}`','`Codex launcher stops descendants before returning: ${route} ${fixture}`')
s=s.replace("      writeFileSync(adapter, 'shift 2\\nROOT=\"$CODEX_FIXTURE_ROOT\"\\nCODEX_BIN=\"$1\"\\nshift\\n'\n        + declaration + '\\ncodex_cli \"$@\"\\n');", """      const setup = route === 'binary' ? 'CODEX_BIN="$1"\\nshift\\n'
        : 'CODEX_BIN=\\nCODEX_VERSION=fixture\\nbunx() { shift 3; "$@"; }\\n';
      writeFileSync(adapter, 'shift 2\\nROOT="$CODEX_FIXTURE_ROOT"\\n' + setup
        + declaration + '\\ncodex_cli "$@"\\n');""")
t.write_text(s)
with (o/'codex-lifetime-both-routes.log').open('w') as log:
 p=subprocess.run(['node','--test','--test-concurrency=1',str(t)],cwd=r,stdout=log,stderr=subprocess.STDOUT)
print('BOTH ROUTES',p.returncode);print((o/'codex-lifetime-both-routes.log').read_text());assert p.returncode==0
for gate in ['workflows','file-size','abbreviation','readable-code']:
 with (o/f'cleanup-gate-{gate}.log').open('w') as log:
  p=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate],cwd=r,stdout=log,stderr=subprocess.STDOUT)
 print('GATE',gate,p.returncode);print((o/f'cleanup-gate-{gate}.log').read_text()[-3000:]);assert p.returncode==0
