from pathlib import Path
import subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');o=Path('/tmp/issue-1580-research/runtime-cleanup')
p=r/'experiments/issue-1580/codex-process-lifetime.test.mjs';s=p.read_text()
s=s.replace("import {join} from 'node:path';", "import {delimiter, join} from 'node:path';")
s=s.replace("        : 'CODEX_BIN=\\nCODEX_VERSION=fixture\\nbunx() { shift 3; \"$@\"; }\\n';", "        : 'CODEX_BIN=\\nCODEX_VERSION=fixture\\n';\n      writeFileSync(join(directory, 'bunx'), '#!/usr/bin/env bash\\nshift 3\\nexec \"$@\"\\n', {mode: 0o700});")
s=s.replace("env: {...process.env, CODEX_FIXTURE_ROOT: root},", "env: {...process.env, CODEX_FIXTURE_ROOT: root, PATH: directory + delimiter + process.env.PATH},")
p.write_text(s)
with (o/'codex-lifetime-both-routes-final.log').open('w') as log:
 result=subprocess.run(['node','--test','--test-concurrency=1',str(p)],cwd=r,stdout=log,stderr=subprocess.STDOUT)
print('BOTH ROUTES',result.returncode);print((o/'codex-lifetime-both-routes-final.log').read_text());assert result.returncode==0
for gate in ['workflows','file-size','abbreviation','readable-code']:
 with (o/f'cleanup-gate-{gate}.log').open('w') as log:
  result=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate],cwd=r,stdout=log,stderr=subprocess.STDOUT)
 print('GATE',gate,result.returncode);print((o/f'cleanup-gate-{gate}.log').read_text()[-2500:]);assert result.returncode==0
