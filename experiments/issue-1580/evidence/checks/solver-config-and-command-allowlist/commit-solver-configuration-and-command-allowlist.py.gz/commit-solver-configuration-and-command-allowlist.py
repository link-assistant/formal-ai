from pathlib import Path
import gzip, hashlib, json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch/'solver-config-and-command-allowlist'
proof = json.loads((out/'outcome.json').read_text())
assert proof['passed'] and not proof['registryChanged']
def run(name, argv):
    result = subprocess.run(argv,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},capture_output=True)
    (out/('commit-'+name+'.stdout')).write_bytes(result.stdout)
    (out/('commit-'+name+'.stderr')).write_bytes(result.stderr)
    print(name,result.returncode,flush=True)
    assert result.returncode==0,name
    return result.stdout.decode()
assert not run('index-before',['git','diff','--cached','--name-only']).strip()
archive = root/'experiments/issue-1580/evidence/checks/solver-config-and-command-allowlist'
archive.mkdir(exist_ok=False)
inputs = [(p.name,p) for p in sorted(out.iterdir()) if p.is_file() and p.name!='worker.log']
inputs.extend([(name,scratch/name) for name in ['extract-solver-config-and-command-allowlist.py','extract-solver-config-and-command-allowlist.log']])
inputs.append((Path(__file__).name,Path(__file__)))
entries = []
for name,path in inputs:
    raw = path.read_bytes()
    packed = gzip.compress(raw,mtime=0)
    target = archive/(name+'.gz')
    target.write_bytes(packed)
    entries.append({'file':target.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
(archive/'records.json').write_text(json.dumps({'entries':entries,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
fragment = root/'changelog.d/issue-1580-computer-use-content.md'
fragment.write_text(fragment.read_text()+'\nSeparate unchanged solver configuration and repository command admission into private modules while preserving their public paths.\n')
plan = root/'experiments/issue-1580/work-plan.md'
plan.write_text(plan.read_text()+'\n- Separate unchanged solver configuration (950 to 810 parent lines, 144 child lines) and repository command allowlist matching (968 to 836 parent lines, 139 child lines). Exact inverse reconstruction restores both originals, and Rust formatting preserves every syntax/comment token. All nine existing JavaScript repository-runner cases pass; the maintained source projection, generated registry, literal ownership and four source gates remain current without regeneration. Public APIs, default values, default-deny matching and deadline selection are preserved. No local Rust execution or independent authorship credit; hosted native and broader issue acceptance remain open.\n')
selected = [*proof['sourcePaths'],archive.relative_to(root).as_posix(),fragment.relative_to(root).as_posix(),plan.relative_to(root).as_posix()]
run('stage',['git','add','--',*selected])
secret_paths = []
for relative in selected:
    path = root/relative
    secret_paths.extend(p.relative_to(root).as_posix() for p in sorted(path.rglob('*')) if p.is_file()) if path.is_dir() else secret_paths.append(relative)
run('secrets',['bash','scripts/check-secrets.sh',*secret_paths])
run('whitespace',['git','diff','--cached','--check'])
run('commit',['git','commit','-m','refactor: separate solver configuration and command admission'])
head = run('head',['git','rev-parse','HEAD']).strip()
(out/'commit-outcome.json').write_text(json.dumps({'head':head,'passed':True,'pushExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
