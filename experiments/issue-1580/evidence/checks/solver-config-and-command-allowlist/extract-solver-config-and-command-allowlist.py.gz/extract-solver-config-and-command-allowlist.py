from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/solver-config-and-command-allowlist')
if len(sys.argv) == 1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:
        worker = subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({'pid':worker.pid,'finiteWorker':True}))
    sys.exit(0)
records = []
def run(name, argv, check=True):
    result = subprocess.run(argv,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},capture_output=True)
    (out/(name+'.stdout')).write_bytes(result.stdout)
    (out/(name+'.stderr')).write_bytes(result.stderr)
    records.append({'name':name,'argv':argv,'exitCode':result.returncode})
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    if check: assert result.returncode==0,name
    return result
proofs = []
paths = []
formatting = {}
def retain(parent, child, original, updated, child_text, restored, label):
    assert restored == original,label
    assert not child.exists()
    (out/(label+'-original.rs.gz')).write_bytes(gzip.compress(original.encode(),mtime=0))
    child.parent.mkdir(exist_ok=True)
    parent.write_text(updated)
    child.write_text(child_text)
    pair = [parent.relative_to(root).as_posix(),child.relative_to(root).as_posix()]
    for relative in pair:
        target = out/('unformatted-'+str(len(formatting))+'.rs')
        target.write_bytes((root/relative).read_bytes())
        formatting[relative] = str(target)
    paths.extend(pair)
    proofs.append({'parent':pair[0],'child':pair[1],'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'reassembledOriginalSha256':hashlib.sha256(restored.encode()).hexdigest(),'originalLines':len(original.splitlines()),'exactOriginalReconstructionBeforeFormatting':True})

parent = root/'rust/src/solver.rs'
child = root/'rust/src/solver/configuration.rs'
original = parent.read_text()
assert len(original.splitlines())==950
start = original.index('/// Runtime configuration for the universal solver.')
end = original.index('/// The universal solver itself.')
block = original[start:end]
addition = 'mod configuration;\n'
export = 'pub use configuration::SolverConfig;\n'
old_import = 'use crate::probability::{ProbabilityDecisionPolicy, ProbabilityStore};\n'
new_import = 'use crate::probability::ProbabilityStore;\n'
updated = (original[:start]+original[end:]).replace('mod conversation;\n',addition+'mod conversation;\n'+export,1).replace(old_import,new_import,1)
imports = 'use super::{BlueprintComposition, ExecutionSurface};\nuse crate::probability::ProbabilityDecisionPolicy;\n\n'
child_text = imports+block.rstrip()+'\n'
restored = updated.replace(addition,'',1).replace(export,'',1).replace(new_import,old_import,1)
restored = restored.replace('/// The universal solver itself.',child_text.removeprefix(imports)+'\n/// The universal solver itself.',1)
retain(parent,child,original,updated,child_text,restored,'solver-configuration')

parent = root/'rust/src/repository_workspace/mod.rs'
child = root/'rust/src/repository_workspace/command_allowlist.rs'
original = parent.read_text()
assert len(original.splitlines())==968
start = original.index('/// One row of `data/seed/repository-command-allowlist.lino`.')
end = original.index('/// Every file under `directory`, relative to `root`, excluding the git database.')
block = original[start:end]
addition = 'mod command_allowlist;\n'
export = 'pub use command_allowlist::{\n    AllowedCommand, DEFAULT_DEADLINE_SECONDS, allows, command_allowlist, deadline_seconds,\n};\n'
updated = (original[:start]+original[end:]).replace('pub mod clone;\n','pub mod clone;\n'+addition,1).replace('use verify::RunCommand;\n','use verify::RunCommand;\n\n'+export,1)
imports = 'use super::{ALLOWLIST_LINO, RECORD_ALLOWED};\nuse crate::seed::parser::parse_lino;\n\n'
child_text = imports+block.rstrip()+'\n'
restored = updated.replace(addition,'',1).replace('\n'+export,'',1)
restored = restored.replace('/// Every file under `directory`, relative to `root`, excluding the git database.',child_text.removeprefix(imports)+'\n/// Every file under `directory`, relative to `root`, excluding the git database.',1)
retain(parent,child,original,updated,child_text,restored,'command-allowlist')

(out/'formatting-inputs.json').write_text(json.dumps(formatting)+'\n')
run('canonical-format',['rustfmt','--edition','2024',*paths])
code = "import fs from 'node:fs'; import assert from 'node:assert/strict'; import {lex} from './scripts/self-translation/lexer.mjs'; for(const [file,old] of Object.entries(JSON.parse(fs.readFileSync(process.argv[1],'utf8')))){const tokens=s=>lex(s,'Rust').map(t=>[t.type,t.text]);assert.deepEqual(tokens(fs.readFileSync(file,'utf8')),tokens(fs.readFileSync(old,'utf8')),file);} console.log('Every Rust syntax token and comment is unchanged by formatting');"
run('format-token-equivalence',['node','--input-type=module','-e',code,str(out/'formatting-inputs.json')])
for proof in proofs:
    proof['parentLines'] = len((root/proof['parent']).read_text().splitlines())
    proof['childLines'] = len((root/proof['child']).read_text().splitlines())
    assert max(proof['parentLines'],proof['childLines'])<900
(out/'inverse-proofs.json').write_text(json.dumps({'observedAt':datetime.now(timezone.utc).isoformat(),'files':proofs,'formattingPreservesEverySyntaxTokenAndComment':True,'hostedNativeVerificationPending':True,'localRustExecution':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
run('rust-format-check',['rustfmt','--edition','2024','--check',*paths])
run('repository-workspace-runners-javascript',['node','--test','--test-concurrency=1','rust/tests/web/repository-workspace-runners.test.mjs'])
run('translation-current',['node','scripts/translate-js-rust.mjs','--verify'])
before = run('generated-registry-before',['node','scripts/lib/generate-native-specification-programs.mjs','--check'],False)
if before.returncode:
    old = (root/'scripts/lib/generated-native-programs.mjs').read_bytes()
    (out/'generated-native-programs-before.mjs.gz').write_bytes(gzip.compress(old,mtime=0))
    run('generated-registry-write',['node','scripts/lib/generate-native-specification-programs.mjs'])
    run('generated-registry-current',['node','scripts/lib/generate-native-specification-programs.mjs','--check'])
    run('generated-registry-diff',['git','diff','--','scripts/lib/generated-native-programs.mjs'])
run('literal-owner-current',['node','scripts/check-hardcoded-language.mjs'])
run('source-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code'])
(out/'outcome.json').write_text(json.dumps({'passed':True,'files':proofs,'sourcePaths':paths,'registryChanged':before.returncode!=0,'pushExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
