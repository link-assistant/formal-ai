import hashlib,json,os,pathlib,subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
scratch=pathlib.Path('/tmp/issue-1580-research')
out=scratch/'native-test-headroom-commit'
out.mkdir(exist_ok=True)
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
assert json.loads((scratch/'native-test-headroom/followup-outcome.json').read_text())['allPassed']
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=root).decode().split('\0')[:-1]
assert len(staged)==57,len(staged)
assert not any('/evidence/ci/' in name for name in staged)
env=os.environ.copy()
env['NODE_OPTIONS']='--max-old-space-size=512'
env['SECRETLINT_VERSION']='14.0.0'
env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
records=[]
for name,argv in [('naming',['node','scripts/measure-abbreviations.mjs','--check']),('secrets',['bash','scripts/check-secrets.sh',*staged]),('whitespace',['git','diff','--cached','--check'])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        result=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
    records.append({'name':name,'exitCode':result.returncode})
    (out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
    assert result.returncode==0,name
with (out/'commit.stdout').open('wb') as stdout,(out/'commit.stderr').open('wb') as stderr:
    subprocess.run(['git','-c','gc.auto=0','commit','-m','Split oversized native regression modules without changing assertions'],cwd=root,stdout=stdout,stderr=stderr,check=True)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root,text=True)
outcome={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'committed':True,'pushed':False,'trackedWorkingTreeClean':True,'stagedFiles':len(staged),'fullIssueComplete':False}
(out/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome))
