from pathlib import Path
import json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/native-headroom-coverage');out.mkdir(exist_ok=True)
path=root/'experiments/issue-1580/native-test-headroom.test.mjs'
source=path.read_text()
source+='''
test('the hosted native targets execute every extracted regression owner', () => {
  for (const [target, owners] of [
    ['coding_contracts', ['agentic-coding/agentic_general_planner']],
    ['workflow_contracts', ['ci-cd/job_budget_fit', 'ci-cd/pinned_tool_images']],
  ]) {
    const source = readFileSync(root + '/rust/tests/unit/' + target + '.rs', 'utf8');
    for (const owner of owners) {
      assert(source.includes('#[path = "' + owner + '.rs"]'), target + ' omits ' + owner);
    }
    assert(readFileSync(root + '/scripts/ci-native-regressions.sh', 'utf8').includes('--test ' + target));
  }
});
'''
assert 'hosted native targets execute' not in path.read_text()
path.write_text(source)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
with (out/'before.stdout').open('wb') as stdout,(out/'before.stderr').open('wb') as stderr:
    result=subprocess.run(['node','--max-old-space-size=256','--test','--test-concurrency=1','--test-reporter=tap',str(path)],cwd=root,env=env,stdout=stdout,stderr=stderr)
assert result.returncode==1
before=(out/'before.stdout').read_text();assert '# pass 3' in before and '# fail 1' in before and 'coding_contracts omits agentic-coding/agentic_general_planner' in before
coding=root/'rust/tests/unit/coding_contracts.rs';coding.write_text(coding.read_text()+'''
// Preserve the existing planner and transport fixtures in the hosted coding lane.
#[path = "../fixtures/observed-plan-tools.rs"]
mod observed_plan_tools;
#[path = "issue_1066_ladder_capability/tool_workspace.rs"]
mod tool_workspace;
#[path = "agentic-coding/agentic_general_planner.rs"]
mod agentic_general_planner;
''')
workflow=root/'rust/tests/unit/workflow_contracts.rs';workflow.write_text(workflow.read_text()+'''
// Share the complete budget and pinned-image regressions with PR qualification.
#[path = "ci-cd/job_budget_fit.rs"]
mod job_budget_fit;
#[path = "ci-cd/pinned_tool_images.rs"]
mod pinned_tool_images;
''')
budget=root/'rust/tests/unit/ci-cd/job_budget_fit.rs';source=budget.read_text();old='use super::step_budgets_within_job_clocks::{job_timeout, workflow_files};';new='use super::workflow_fixtures::{job_timeout, workflow_files};';assert source.count(old)==1;budget.write_text(source.replace(old,new))
(out/'draft.json').write_text(json.dumps({'beforePassed':3,'beforeFailed':1,'actualOwnersAdded':3,'nativeExecutionVerified':False,'fullIssueComplete':False},indent=2)+'\n')
print(json.dumps({'drafted':True,'regressionFailedBefore':True,'nativeBuildRun':False}))
