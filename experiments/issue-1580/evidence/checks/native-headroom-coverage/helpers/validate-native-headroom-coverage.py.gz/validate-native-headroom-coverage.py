from pathlib import Path
import json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/native-headroom-coverage')
if len(sys.argv)==1:
    path=root/'.github/workflows/native-type-check.yml';source=path.read_text()
    marker='            !/dev/log/\n'
    boundary=source.index('  contract-family:')
    assert source[:boundary].count(marker)==2
    source=source[:boundary].replace(marker,marker+'            /dev/log/issues/1079/pulls/1080/upstream-reports/\n')+source[boundary:]
    path.write_text(source)
    path=root/'experiments/issue-1580/native-test-headroom.test.mjs';source=path.read_text()
    source=source.replace("import test from 'node:test';", "import test from 'node:test';\nimport YAML from 'yaml';")
    source+='''
test('both core checkout attempts retain the original upstream-report fixtures', () => {
  const workflow = YAML.parse(readFileSync(root + '/.github/workflows/native-type-check.yml', 'utf8'));
  const attempts = workflow.jobs.clippy.steps.filter(step => step.uses === 'actions/checkout@v7');
  assert.equal(attempts.length, 2);
  for (const step of attempts) {
    assert(step.with['sparse-checkout'].split('\\n').includes('/dev/log/issues/1079/pulls/1080/upstream-reports/'));
  }
});
'''
    path.write_text(source)
    with (out/'worker.log').open('wb') as stream:
        process=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':process.pid})+'\n')
    print(json.dumps({'pid':process.pid,'finite':True}));sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);records=[]
def run(name,args):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    records.append({'name':name,'args':args,'exitCode':result.returncode})
    (out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(records[-1]),flush=True)
    return result.returncode
try:
    files=['rust/tests/unit/coding_contracts.rs','rust/tests/unit/workflow_contracts.rs','rust/tests/unit/ci-cd/job_budget_fit.rs']
    assert run('format',['rustfmt','--edition','2024','--config','skip_children=true',*files])==0
    assert run('format-check',['rustfmt','--edition','2024','--config','skip_children=true','--check',*files])==0
    for name,path in [('headroom','experiments/issue-1580/native-test-headroom.test.mjs'),('native-groups','experiments/issue-1580/native-regression-groups.test.mjs'),('maintained','rust/tests/web/issue-1580-template-observations.test.mjs')]:
        run(name,['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',path])
    run('touched-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size,check-file-size-js-twin'])
    run('whitespace',['git','diff','--check'])
    outcome={'complete':True,'allPassed':all(row['exitCode']==0 for row in records),'nativeBuildRun':False,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
    (out/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
