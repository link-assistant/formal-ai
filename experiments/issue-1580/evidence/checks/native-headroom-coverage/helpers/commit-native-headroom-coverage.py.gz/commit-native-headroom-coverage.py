from pathlib import Path
import gzip,hashlib,json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'native-headroom-coverage'
assert json.loads((out/'outcome.json').read_text())['allPassed']
target=root/'experiments/issue-1580/evidence/checks/native-headroom-coverage';target.mkdir(exist_ok=False)
records=[]
def retain(path,alias):
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);destination=target/(alias+'.gz');destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed)
    records.append({'source':str(path),'file':alias+'.gz','bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
for path in sorted(out.iterdir()):
    if path.is_file():retain(path,'validation/'+path.name)
for name in ['draft-native-headroom-coverage.py','draft-native-headroom-coverage.log','validate-native-headroom-coverage.py','validate-native-headroom-coverage.log','commit-native-headroom-coverage.py','commit-native-test-headroom.py','commit-native-test-headroom.log']:
    retain(scratch/name,'helpers/'+name)
for path in sorted((scratch/'native-test-headroom-commit').iterdir()):
    if path.is_file():retain(path,'preceding-commit/'+path.name)
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
summary={'records':len(records),'beforeFix':{'passed':3,'failed':1},'afterFix':{'headroomCasesPassed':5,'nativeGroupCasesPassed':50,'maintainedCasesPassed':138},'nativeBuildRun':False,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for row in records:
    packed=(target/row['file']).read_bytes();raw=gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest()==row['archiveSha256'] and hashlib.sha256(raw).hexdigest()==row['rawSha256'] and len(raw)==row['bytes'] and len(raw.splitlines())==row['lines']
note=root/'docs/case-studies/issue-1580/native-headroom-coverage-checkpoint.md'
note.write_text('''# Hosted coverage for extracted native regressions

The focused native targets omitted three edited regression owners. A maintained
JavaScript regression demonstrates the omission before repair (three passing
scanner checks and one failed coverage check). The coding target now imports
the complete original general planner and its real shared tool fixtures. The
workflow target imports the complete original job-budget and pinned-image
modules. Budget fixtures come directly from their existing shared reader.

Both core checkout attempts retain the nine original upstream-report fixture
files those assertions inspect. No native assertion is removed or replaced.
The existing core and coding lanes execute these targets under their existing
budgets. These imports add coverage; they do not qualify the full unit suite.

Five focused coverage cases, 50 native-runner cases, 138 maintained observation
cases, three touched JavaScript gates, formatting and whitespace checks pass
locally. Rust compilation and execution of the new coverage remain pending in
hosted CI. The current published CI round precedes these local edits.

Evidence: `experiments/issue-1580/evidence/checks/native-headroom-coverage/`.
Full issue acceptance remains unfinished; supplied commands and patches receive
zero independent authorship or reasoning credit.
''')
fragment=root/'changelog.d/issue-1580-native-headroom-coverage.md'
fragment.write_text('''---
bump: patch
---

Replay complete planner, job-budget and pinned-image regression modules in
the existing focused native CI targets, retaining their original fixtures.
''')
plan=root/'experiments/issue-1580/work-plan.md';source=plan.read_text();start=source.index('## Current verification checkpoint\n');end=source.index('\n\nLatest checkpoint:',start)
source=source[:start]+'''## Current verification checkpoint

Published `6672bfc9` merges current main `873f1c33`; its 26 normal workflows
are still being collected. The preceding published `84e1ad85` has 25 successful
workflows and one skip, including all eight native families and registry checks.
The merged source passes all 88 executed local gates (53 explicit skips),
TypeScript generation/runtime, gateway/server checks and 133 maintained cases.

Local commit `018d71a4` removes three more Rust test size warnings through
ordinary child modules, preserving every original body: 84 warnings remain
under unchanged limits. Follow-up coverage repairs connect all three owners
to the existing hosted core/coding targets and retain their original fixtures.
Five coverage cases, 50 native-runner cases and 138 maintained observation
cases pass locally; hosted native compilation/execution is still pending.
See the [native coverage checkpoint](../../docs/case-studies/issue-1580/native-headroom-coverage-checkpoint.md).

Full template/practice, original budget/live, complete PR review, independent
authorship/reasoning and complete issue acceptance remain unfinished.
''' +source[end:]
plan.write_text(source)
paths=['.github/workflows/native-type-check.yml','experiments/issue-1580/native-test-headroom.test.mjs','rust/tests/unit/coding_contracts.rs','rust/tests/unit/workflow_contracts.rs','rust/tests/unit/ci-cd/job_budget_fit.rs',str(note.relative_to(root)),str(fragment.relative_to(root)),str(plan.relative_to(root)),str(target.relative_to(root))]
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=root).decode().split('\0')[:-1]
assert not any('/evidence/ci/' in path for path in staged)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
for name,args in [('final-naming',['node','scripts/measure-abbreviations.mjs','--check']),('final-secrets',['bash','scripts/check-secrets.sh',*staged]),('final-whitespace',['git','diff','--cached','--check'])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    assert result.returncode==0,name
with (out/'commit.stdout').open('wb') as stdout,(out/'commit.stderr').open('wb') as stderr:subprocess.run(['git','-c','gc.auto=0','commit','-m','Qualify extracted native regression owners in focused CI targets'],cwd=root,stdout=stdout,stderr=stderr,check=True)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root,text=True)
outcome={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'committed':True,'pushed':False,'trackedWorkingTreeClean':True,'records':len(records),'fullIssueComplete':False}
(out/'commit-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))
