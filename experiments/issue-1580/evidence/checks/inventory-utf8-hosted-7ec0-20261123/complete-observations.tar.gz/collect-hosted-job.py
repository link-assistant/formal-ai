from pathlib import Path
import subprocess,json,gzip,datetime,hashlib
r=Path('/tmp/issue-1580-research/inventory-utf8-hosted-7ec0'); records=[]
for label,cmd in [
 ('run',['gh','api','repos/link-assistant/formal-ai/actions/runs/45218148759']),
 ('complete-job',['gh','api','--allow-escape-sequences','repos/link-assistant/formal-ai/actions/jobs/137845376042/logs'])]:
 proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (r/(label+'.stdout.gz')).write_bytes(gzip.compress(proc.stdout,mtime=0));(r/(label+'.stderr')).write_bytes(proc.stderr)
 records.append({'label':label,'command':cmd,'exitCode':proc.returncode,'bytes':len(proc.stdout),'sha256':hashlib.sha256(proc.stdout).hexdigest(),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 (r/'collection-records.json').write_text(json.dumps(records,indent=2)+'\n')
 if proc.returncode:raise RuntimeError(label+': '+proc.stderr.decode(errors='replace'))
(r/'collection-outcome.json').write_text(json.dumps({'complete':True,'allPassed':True,'records':records},indent=2)+'\n')
print('complete',flush=True)
