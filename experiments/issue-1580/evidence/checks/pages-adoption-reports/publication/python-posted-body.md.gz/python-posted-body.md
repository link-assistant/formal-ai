This follows the retry implementation in [PR #134](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/pull/134). That PR explicitly documents the same-commit adoption limitation; this report supplies an executable cross-artifact regression and artifact-bound candidate for that remaining limitation. 

The current [Pages helper](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/blob/b497e24e5be049cad0b9840eb0e0b8d2eb6077b0/.github/actions/deploy-pages/deploy.mjs) adopts a deployment by source commit after a transient creation failure. That lookup can return a different artifact uploaded by an earlier run of the same commit. The caller then reports success without deploying the requested artifact.

For example, artifact 41 is already successfully deployed from source SHA S. A rebuild/rerun uploads artifact 42 from the same S. Its first creation request fails before the server creates anything. On retry, GET `/pages/deployments/S` finds the successful deployment of artifact 41. The helper adopts it and never creates a deployment of artifact 42. Builds from identical source may differ because of dependency resolution, generated output, build inputs or environment; the requested immutable artifact still matters even when content happens to match.

A finite offline probe runs the actual unchanged helper with this API history. It observes adopted artifact 41, one failed POST, and no deployment of requested artifact 42. The same probe also covers a lost response after successful creation: the correct artifact is adopted with one POST, preserving retry safety. No GitHub deployment or writes are needed.

Reproduction and regression evidence in link-assistant/formal-ai PR https://github.com/link-assistant/formal-ai/pull/1581 at f8718c44e7fdf7b9aa5ad9951c50a8d0efeec55d:

- [Executable probe](https://github.com/link-assistant/formal-ai/blob/f8718c44e7fdf7b9aa5ad9951c50a8d0efeec55d/experiments/issue-1580/probe-pages-adoption.mjs)
- [Actual pinned helper fixtures and source identities](https://github.com/link-assistant/formal-ai/tree/f8718c44e7fdf7b9aa5ad9951c50a8d0efeec55d/experiments/issue-1580/fixtures/pages-templates)
- [Regression tests and negative control](https://github.com/link-assistant/formal-ai/blob/f8718c44e7fdf7b9aa5ad9951c50a8d0efeec55d/experiments/issue-1580/template-pages-adoption.test.mjs)

Run `node --test experiments/issue-1580/template-pages-adoption.test.mjs`. All six assertions pass, including observations of the original defects. With `ISSUE_1580_DISABLE_PAGES_BINDING=1`, two candidate assertions fail because the old artifact is adopted.

Suggested repair: derive the API build-version key from the repository, immutable artifact ID and source SHA, using the same key for creation and retry lookup. Keep the real source SHA in the artifact's provenance stamp. GitHub documents `pages_build_version` as a unique artifact-version string; the status API returns only status, so source-only lookup cannot verify the artifact ID. The downstream candidate passes bounded mocked tests; real hosted publication with the new key has not yet been verified.

Acceptance: a failed pre-creation attempt for artifact 42 must never adopt artifact 41 from the same source. A lost response after creation of artifact 42 should still adopt 42 without another POST. Preserve permanent-error refusal, bounded retry/polling, cancellation and output behavior.

Protocol references: [create deployment](https://docs.github.com/en/rest/pages/pages#create-a-github-pages-deployment) and [read deployment status](https://docs.github.com/en/rest/pages/pages#get-the-status-of-a-github-pages-deployment).
