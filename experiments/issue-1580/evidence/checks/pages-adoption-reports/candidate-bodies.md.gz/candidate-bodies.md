# link-foundation/js-ai-driven-development-pipeline-template #282 fix: retry Pages deploys, recheck links weekly, report all npm advisories, rerun unacquired runners
https://github.com/link-foundation/js-ai-driven-development-pipeline-template/pull/282

This PR fixes the four CI infrastructure issues tracked in #281 in one PR. Generated repositories inherited each one: a transient Pages 500 failed the deploy, links were only rechecked when Markdown changed and the lychee cache was always discarded, moderate npm advisories passed silently, and a job GitHub never found a runner for was reported as a code failure.

Fixes #277
Fixes #278
Fixes #279
Fixes #280
Fixes #281

## #277: Pages deployment retries a transient failure, without deploying twice

`actions/deploy-pages@v5` does not retry a failure to create the deployment (`Failed to create deployment (status: 500)`). Wrapping the action in a retry loop is not safe, because a lost response can hide a deployment that was created.

- `scripts/deploy-pages.mjs` speaks the action's REST protocol with plain `fetch`: OIDC token, `POST /pages/deployments`, poll, and cancel when abandoned. The deploy job no longer runs `npm ci` and needs no npm dependencies.
  - **Retries:** HTTP 429, 5xx, timeouts and network errors are retried up to 3 times with a growing delay.
  - **Permanent errors:** 400/401/403/404/422 fail at once. The message names the method, the path, the status and the `x-github-request-id`.
  - **Never twice:** before every retry, the script reads `GET /pages/deployments/{sha}`. If an earlier attempt's deployment exists and has not failed, the script adopts it, so a lost response never leads to a second deployment of the same commit.
  - **Polling:** it polls until a final state. On timeout, on too many polling errors, on a permanent polling error, or on SIGINT/SIGTERM (job cancelled), it cancels the deployment.
- `web-build` outputs the `artifact-id` of the Pages upload, and `pages-deploy` publishes exactly that artifact.
- Removing the action also removes the punycode adapter it needed: `scripts/check-pages-punycode.mjs`, `.github/actions/artifact-transport/punycode.mjs` and the `punycode` dependency.
- `scripts/github-api.mjs` holds the dependency-free REST client that the deploy and rerun scripts share.
- `tests/deploy-pages.test.js` has 17 tests against a scripted API: a 500 followed by success (exactly one `POST`), retries on 429, network failure and timeout, each permanent status, retry exhaustion, adoption after a lost response, an earlier failed deployment of the same commit, every final failed state, polling errors and timeout followed by a cancel, and the OIDC request.

## #278: Weekly link recheck and a day-scoped lychee cache

- `links.yml` also runs on `schedule: '0 6 * * 1'`, so link rot is detected without commits.
- The cache key is `cache-lychee-<os>-<UTC date>-<sha>`, and the restore key is `cache-lychee-<os>-<UTC date>-`. Only a cache saved the same UTC day is restored, and that is younger than lychee's `--max-cache-age 1d`.
- `tests/links-workflow.test.js` asserts both.
- Hosted evidence: [Broken Link Checker run 41528788321](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/actions/runs/41528788321) logged `Cache restored from key: cache-lychee-Linux-2026-11-02-…`, and its log has no `Cache is too old` line.

## #279: Every npm advisory is reported, and fixable moderate ones fail the weekly run

- `scripts/npm-audit-report.mjs` runs `npm audit --package-lock-only --json` once per lock.
  - **Reporting:** it emits one annotation per advisory (GHSA), not per package. Advisories below the gate are warnings and failing ones are errors. It also writes a table of all of them to the step summary.
  - **Gates:** pull requests and pushes still fail at `high`. The weekly run also fails on a `moderate` advisory that `npm audit fix` resolves without `--force`.
  - **Fails closed:** a registry error or unparsable output fails the job.
- The artifact SDK's `glob` override moves to 14.0.3, which fixes GHSA-3g3m-2fjr-6pw4.
- One moderate advisory remains: GHSA-g3hv-75wg-m249, in `minimatch@10`. It has no non-breaking fix. `minimatch` 11 removes `makeRe`, `regexp` and `AST`, and eslint, `@actions/glob` and `readdir-glob` all require `^10`. It is now reported as a warning annotation and in the summary, not hidden. Once a patched 10.x exists, the weekly run fails until the lock is updated.
- Tested by `tests/npm-audit-report.test.js`, which uses a fixture of real audit output, and by `tests/security-workflow.test.js`. `docs/CONTRIBUTING.md` documents the policy.

## #280: Jobs GitHub never acquired a runner for

When GitHub gives up with "The job was not acquired by Runner of type hosted even after multiple attempts", the job ends `cancelled` or `failure` with an empty `runner_name` and no steps.

- **Status gates name the cause.**
  - All five `Pipeline Status` gates get `GH_TOKEN` and job-level `actions: read`. The workflow default stays `contents: read`.
  - When a required job failed or was cancelled, `scripts/check-pipeline-status.sh` lists the attempt's jobs and adds `::error title=Hosted runner not acquired::<jobs>. GitHub could not provide a runner, so no code ran.`
  - The gate stays red, because nothing was tested. If the jobs cannot be listed, it warns and still reports the original failure.
- **Automatic rerun.** `.github/workflows/rerun-unacquired.yml` runs `scripts/rerun-unacquired.mjs`.
  - **Trigger:** `workflow_run`, `completed`, on every top-level workflow, for a run that concluded `failure` with `run_attempt < 3`.
  - **Action:** it calls `POST /actions/runs/{id}/rerun-failed-jobs`, which also reruns the dependent gates and release.
  - **When it reruns:** only when the failure is fully explained by unacquired jobs. It skips a run where any job that ran steps failed (status gates excepted), a run someone already reran, and a run that a newer run of the same workflow, branch and event supersedes.
  - **Permissions:** `actions: write` is granted to that one job only. It never checks out the inspected run's commit, which is why `dangerous-triggers` is ignored inline.
  - `workflow_run` fires only for workflow files on the default branch, so it takes effect after merge.
- **Optional macOS `continue-on-error`:** not applied. Releases still require every runtime on every OS. The trade-off (`needs.test.result` would report success for a failed macOS leg) is documented in the README's new "Hosted Runner Capacity" section.
- **Tests:**
  - `tests/rerun-unacquired.test.js`: detection, pagination, rerun, real failure, attempt limit, already rerun, superseded run, a refused rerun, and the workflow's trigger, permissions and concurrency.
  - `tests/pipeline-status.test.js`: the gate annotation from an injected `JOBS_JSON`, no API call on green runs, the listing-failure warning, the no-token path, and `GH_TOKEN`/`actions: read` in every gate.

## How to reproduce

- **#277:** in `tests/deploy-pages.test.js`, the scripted API answers the first `POST /pages/deployments` with a 500. The old action failed on it. The script retries and publishes once.
- **#278:** before this PR, the Broken Link Checker logs showed `[WARN] Cache is too old`, and the workflow had no `schedule`.
- **#279:** `npm audit --package-lock-only --audit-level=high` in `.github/actions/artifact-transport` exits 0 and says nothing about the moderate advisories. `tests/fixtures/npm-audit-moderate.json` is that lock's audit output.
- **#280:** give one job an unavailable runner label, or wait for a macOS capacity event. Then compare the gate's annotation with the fixture in `tests/pipeline-status.test.js`.

## Verification

- `npm test`: 1108 pass, 0 fail.
- The changed test files pass on Bun and Deno.
- `npm run check` (eslint, prettier, jscpd, line limits) passes.
- `node scripts/check-ci-workflows.mjs` and `node scripts/check-status-gate-covers-all-jobs.mjs` pass.
- `zizmor==1.30.1 --min-confidence low --persona regular` reports no findings.
- Hosted CI on final revision `10159d0` passes all six workflows, including all nine OS/runtime test legs and macOS desktop packaging:
  - [Checks and release 41529561414](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/actions/runs/41529561414)
  - [Example app 41529561417](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/actions/runs/41529561417)
  - [Security 41529561351](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/actions/runs/41529561351)
  - [Workflows 41529561367](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/actions/runs/41529561367)
  - [Broken Link Checker 41529561465](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/actions/runs/41529561465)
  - [JavaScript-first mixed-language example 41529561334](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/actions/runs/41529561334)

## What CI on this pull request cannot exercise

Two paths only run after merge, so pull request CI covers them with unit tests and workflow assertions only:

- `pages-deploy` runs only on a push to `main`, in the `github-pages` environment.
- `rerun-unacquired.yml` runs only from the default branch.

The first push to `main` after merging will run the real Pages deployment.


# link-foundation/js-ai-driven-development-pipeline-template #277 Pages deployment fails on a single transient HTTP 500: actions/deploy-pages@v5 never retries creating the deployment
https://github.com/link-foundation/js-ai-driven-development-pipeline-template/issues/277

## Problem

`actions/deploy-pages@v5` creates the Pages deployment with a single `POST /repos/{owner}/{repo}/pages/deployments` request and fails the job on any error, including a transient HTTP 500. Only the later status polling tolerates errors (`error_count`). A single GitHub-side 5xx therefore turns a run red even though the build, the tests and the artifact were all fine, and `main` stays red until someone reruns the job by hand.

This happened in konard/konard.github.io run [41480863205](https://github.com/konard/konard.github.io/actions/runs/41480863205) on `main`:

```
##[error]Creating Pages deployment failed
##[error]Error: Failed to create deployment (status: 500) with build version 5f7f468bef7af0fbb6a0074123743cbcb3e6b1e8. Request ID AA00:25F91:3BD2504:C7A75DA:6AE8C100 Server error, is githubstatus.com reporting a Pages outage? Please re-run the deployment at a later time.
...
Pipeline failed: deploy: failure
```

The action itself suggests re-running. The template runs the same action with no retry, so every repository generated from it inherits this failure mode:

- [`.github/workflows/example-app.yml` line 144](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/blob/c2463c74/.github/workflows/example-app.yml#L142-L148) (`uses: actions/deploy-pages@v5`, step "Deploy Pages artifact")

An older report of 5xx failures upstream (actions/deploy-pages#193) is closed, and v5 still sends a single creation request.

## Why a plain retry wrapper is not enough

Rerunning the whole action (for example with a generic retry action) can create a second deployment when the first POST succeeded but its response was lost. That races two deployments of the same commit.

## Suggested fix

This was fixed in konard/konard.github.io#52 (issue konard/konard.github.io#51) with a small local action that speaks the same REST protocol as deploy-pages v5, without npm dependencies:

- [`scripts/deploy-pages.mjs`](https://github.com/konard/konard.github.io/blob/issue-51-bc3e586ec5c3/scripts/deploy-pages.mjs) and [`.github/actions/deploy-pages`](https://github.com/konard/konard.github.io/tree/issue-51-bc3e586ec5c3/.github/actions/deploy-pages):
  1. Request the OIDC token (`ACTIONS_ID_TOKEN_REQUEST_URL`), as `core.getIDToken()` does.
  2. Make `POST .../pages/deployments` with `{artifact_id, pages_build_version, oidc_token}`.
     - Retry only 429, 5xx and network errors, a bounded number of times with backoff.
     - Fail permanent 4xx (400/401/403/404/422) on the first attempt.
  3. Before each retry, `GET .../pages/deployments/{sha}`. If a deployment of this commit exists and has not failed, adopt it instead of creating a second one.
  4. Poll until `succeed`. Fail on `deployment_failed`, `deployment_content_failed`, `deployment_cancelled` or `deployment_lost`.
  5. Cancel the deployment (`POST .../cancel`) on timeout, on too many polling errors, or when the job is cancelled (SIGINT/SIGTERM).
- The build job outputs the ID of the artifact it uploaded, and the deploy job publishes exactly that artifact.
- Unit tests with a mocked API: [`src/deploy-pages.test.js`](https://github.com/konard/konard.github.io/blob/issue-51-bc3e586ec5c3/src/deploy-pages.test.js). They cover a 500 followed by success (one publication), each permanent status, retry exhaustion, adoption after a lost response, a failed earlier deployment, every final state, polling errors and timeout.

Because the replacement uses only `fetch`, it also removes the bundled punycode DEP0040 warning (actions/deploy-pages#413 and #434). That would make the NODE_OPTIONS workaround unnecessary.

A lighter alternative is to keep `actions/deploy-pages@v5` and add a second attempt guarded by `if: steps.deployment.outcome == 'failure'` (with `continue-on-error` on the first attempt). Note that this alternative retries permanent errors too, and does not adopt a deployment whose response was lost.

## Acceptance criteria

- A transient 5xx or 429 from the deployment creation is retried a bounded number of times.
- A permanent 4xx fails at once with the status and request ID.
- A retry never creates a second deployment of the same commit.
- Covered by unit tests with a mocked API.


# link-foundation/js-ai-driven-development-pipeline-template #59 Use real example package name
https://github.com/link-foundation/js-ai-driven-development-pipeline-template/pull/59

## Summary

- adopts `@link-foundation/example-package-name` as the real scoped package name, with public publish metadata, a changeset, and a packed runtime file list
- adds the globally installable `example-package-name` CLI and regression coverage for direct and npm-bin-link invocation
- fixes the GitHub Pages deployment path by adding Pages permissions plus `actions/configure-pages@v6`, and enables repository Pages for workflow deployments
- stores the issue 58 investigation, failed CI logs, template comparison data, registry probes, and local verification logs under `docs/case-studies/issue-58/`

## Reproduction / Root Cause

- `Checks and release` run `25733140225` failed after PR 57 because the release still targeted `my-package@0.10.0`; npm returned `404 Not Found - PUT https://registry.npmjs.org/my-package`.
- `Example app` run `25733140224` built and uploaded web plus desktop artifacts, then failed at `actions/deploy-pages@v5` with status 404 because GitHub Pages was not enabled for the repository.
- Temporary global install testing exposed a CLI entrypoint edge case through npm bin links; the CLI now resolves real paths before deciding whether to execute.

## Verification

- `node --test --test-timeout=30000 tests/*.test.js`
- `bun test --timeout 30000`
- `deno test --allow-read`
- `npm run check`
- `npx --yes -p secretlint -p @secretlint/secretlint-rule-preset-recommend secretlint "**/*"`
- `bash scripts/check-mjs-syntax.sh`
- `bash scripts/check-file-line-limits.sh`
- `node scripts/validate-changeset.mjs`
- `npm pack --dry-run --json --ignore-scripts`
- `npm install -g . --prefix /tmp/issue-58-global-prefix && /tmp/issue-58-global-prefix/bin/example-package-name multiply 6 7`
- `npm run example:web:build`
- `npm run example:desktop:package`
- `npm run example:mobile:sync`

## Notes

The local checkout is not authenticated to npm, so npm-side trusted publisher setup could not be completed from this machine. The release workflow keeps the required OIDC `id-token: write` permissions and npm registry configuration; the first main release still requires npm trusted publishing to be configured for `@link-foundation/example-package-name` and this repository workflow.

Closes #58

# link-foundation/python-ai-driven-development-pipeline-template #145 CI gates: the release push's rebase retry is unreachable, PR-only jobs write caches that evict main's, non-Python helpers skip the size check, and lychee is verified only against its own release
https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/145

Repository: `link-foundation/python-ai-driven-development-pipeline-template`
Commit inspected: `f28c9d836cd18426adbc2f17629ac58202e04a83`

Items 4 and 5 were found and fixed downstream in link-foundation/link-cli (https://github.com/link-foundation/link-cli/pull/174). Item 8 has no link-cli counterpart. No open duplicate exists. Related closed issues: #73 (rebase-retry), #131, #66, #74, #122, #141.

---

## 8a. `push_branch_with_rebase_retry` never rebases, so a lost push race fails the release

**Summary.** The docstring promises to retry "a lost race with a rebase (issue #73)". After a non-fast-forward rejection, the function:
1. fetches;
2. calls `attest_release(validated_sha, origin/<branch>)`, which raises unless the remote head *is* the validated commit or a release commit whose sole parent is it;
3. if the remote moved to an equivalent release, resets to it, or raises if the version differs.

The `git pull --rebase` block runs only when the remote still equals `validated_sha`. In that state the original push was a fast-forward and could not have been rejected as non-fast-forward, so the rebase path is unreachable.

A real race fails the release job with "Release must retain the original validated commit as its sole parent; rerun CI". A real race here means another PR merged into main between validation and the push. The newer commit's own run normally picks the change up. But if that commit was pushed with `GITHUB_TOKEN`, no run starts, and the release is lost until the next human push.

**Evidence**
- `scripts/version_and_commit.py:167` ([permalink](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/blob/f28c9d836cd18426adbc2f17629ac58202e04a83/scripts/version_and_commit.py#L167)): `"""Push to a branch, retrying a lost race with a rebase (issue #73).`
- `scripts/version_and_commit.py:227-249` ([permalink](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/blob/f28c9d836cd18426adbc2f17629ac58202e04a83/scripts/version_and_commit.py#L227))
  ```python
  run_command(["git", "fetch", "origin", branch])
  remote = f"origin/{branch}"
  attest_release(validated_sha, remote, pyproject_git_path)
  if git_text(["rev-parse", remote]) != validated_sha:
      ...
      run_command(["git", "reset", "--hard", remote])
      return
  ...
  rebase = run_git_capturing(["git", "pull", "--rebase", "origin", branch])
  ```
- `scripts/version_and_commit.py:339-343` ([permalink](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/blob/f28c9d836cd18426adbc2f17629ac58202e04a83/scripts/version_and_commit.py#L339))
  ```python
  parents = git_text(["show", "-s", "--format=%P", head]).split()
  if parents != [validated]:
      raise ValueError(
          "Release must retain the original validated commit as its sole parent; rerun CI"
      )
  ```
- `main()` turns this into `Error: ...` and returns 1 (L575-577).

**MRE.**
1. In a scratch clone, commit `A` (validated) and a release commit `R` on top of it.
2. On the remote, push an unrelated commit `B` on top of `A`.
3. Call `push_branch_with_rebase_retry("main", validated_sha=A)`.

The first push is rejected (non-fast-forward). Then `attest_release(A, origin/main)` raises because `B`'s parent is `A` but `B` is not a release commit with only metadata changes. No rebase is attempted.

**Workaround.** Re-run the release workflow on the new head.

**Suggested fix.** Choose one:
- Remove the dead rebase block and the docstring claim, and on a lost race dispatch the workflow on the new head so the release is not dropped.
- Implement the intended rebase: rebase `R` onto the new remote head and re-attest that only `pyproject.toml`'s version and changelog files differ from the new head.

There is no link-cli counterpart.

---

## 8b. The lychee binary is checked only against a checksum from the same release (hardening)

**Summary.** `install-lychee.sh` downloads the archive and its `.sha256` from the same GitHub release. This detects corruption but not a replaced asset. The version is pinned, but its digest is not.

**Evidence**
- `scripts/install-lychee.sh:42` and L47 ([permalink](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/blob/f28c9d836cd18426adbc2f17629ac58202e04a83/scripts/install-lychee.sh#L42))
  ```bash
  if ! fetch "${base_url}/${asset}" "$work/$asset" || ! fetch "${base_url}/${asset}.sha256" "$work/$asset.sha256"; then
  ...
  expected="$(awk '{print $1; exit}' "$work/$asset.sha256")"
  ```
- `.github/workflows/links.yml:77`: `LYCHEE_VERSION: v0.24.2`, with no pinned digest.

**MRE.** Point `LYCHEE_DOWNLOAD_BASE_URL` at a server that returns a modified archive and its matching `.sha256`. The install succeeds.

**Workaround.** None.

**Suggested fix.** Commit per-architecture SHA-256 values next to `LYCHEE_VERSION` and compare against them. There is no link-cli counterpart; link-cli uses `lycheeverse/lychee-action`.

---

## 4. PR-only jobs write caches that main can never read (minor)

**Summary.** Caches saved from `pull_request` runs are scoped to the merge ref. Main cannot read them, but they count toward the 10 GB LRU and evict main's entries. Two jobs save such caches:
- the PR-only Docker check exports `mode=max` layers;
- the link check saves a new per-commit lychee cache on every PR push.

**Evidence**
- `.github/workflows/release.yml:506` (`if: github.event_name == 'pull_request' && ...`) and L539 ([permalink](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/blob/f28c9d836cd18426adbc2f17629ac58202e04a83/.github/workflows/release.yml#L539)): `cache-to: type=gha,mode=max,scope=docker-pr-check`
- `.github/workflows/links.yml:68-71` ([permalink](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/blob/f28c9d836cd18426adbc2f17629ac58202e04a83/.github/workflows/links.yml#L68)), in a workflow triggered by `pull_request` (L17):
  ```yaml
  uses: actions/cache@v5
  with:
    path: .lycheecache
    key: cache-lychee-${{ steps.link-cache.outputs.day }}-${{ github.sha }}
  ```

**MRE.** Push several commits to a PR. `gh cache list` shows accumulating `refs/pull/N/merge` entries, and `refs/heads/main` entries are evicted.

**Workaround.** Prune PR caches with `gh cache delete`.

**Suggested fix.**
- Restore with `actions/cache/restore`, and save with `actions/cache/save` only on `push` to `refs/heads/main` without an exact hit.
- Drop `cache-to` on the PR-only Docker build, or use `mode=min`.

See link-cli `.github/workflows/rust.yml`, `crash.yml`, `docs.yml`, `js-client.yml` and `wasm.yml`, https://github.com/link-foundation/link-cli/pull/174.

---

## 5. The file-size limit covers only `.py` and `.md`; shell and JavaScript helpers are unchecked

**Summary.** The 1000/900 band applies to `.py` and the 2500/2250 band to `.md`. Shell and `.mjs` CI helpers are never measured.

**Evidence**
- `scripts/check_file_size.py:20-23` ([permalink](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/blob/f28c9d836cd18426adbc2f17629ac58202e04a83/scripts/check_file_size.py#L20))
  ```python
  LIMITS = {
      ".py": (MAX_LINES, WARN_LINES),
      ".md": (MAX_DOC_LINES, WARN_DOC_LINES),
  }
  ```
- L92: `if path.is_file() and path.suffix in LIMITS:`
- Unchecked today: `scripts/preflight-credentials.sh` (347 lines), `tests/deploy-pages.test.mjs` (315 lines).

**MRE.** Grow `scripts/preflight-credentials.sh` past 1000 lines. `python scripts/check_file_size.py` passes.

**Workaround.** Review sizes by hand.

**Suggested fix.** Add `.sh`, `.mjs` and `.js` to `LIMITS` with the 1000/900 band. See link-cli `.github/scripts/check-javascript-quality.mjs` (900-line warning band), https://github.com/link-foundation/link-cli/pull/174.

---

## Checked and not affected
- **1:** `scripts/check-links.sh` treats only exit codes 0 and 2 as expected, and `links.yml` has a schedule.
- **3:** not affected.
- **12:** lint and test do not depend on the release preflight.
- **2 (latent):** the secrets step is `secretlint "**/*"` (`.github/workflows/release.yml:200`), which does not decompress `.gz` files. No compressed files are tracked today. If gzip evidence is ever committed, adopt the gunzip-and-stdin scan from link-cli `.github/scripts/check-secrets.mjs`.
- **6:** there is no rerun-infrastructure workflow, and all jobs run on Ubuntu runners. Consider one if unacquired-runner failures appear.
- **7, 9, 10, 11:** not applicable.


# link-foundation/python-ai-driven-development-pipeline-template #134 fix(ci): retry Pages deploys, schedule the link checker, audit npm locks
https://github.com/link-foundation/python-ai-driven-development-pipeline-template/pull/134

Fixes #133
Fixes #130
Fixes #131
Fixes #132

## Changes

### #130: Pages deploy retries transient failures without deploying twice
- New dependency-free local action `.github/actions/deploy-pages` (`deploy.mjs`, `index.mjs`, `action.yml`). It replaces `actions/deploy-pages@v5`.
  - It uses the same REST protocol: an OIDC token, `POST /repos/{repo}/pages/deployments`, polling with ×1.5 backoff capped at 30 s, an error budget of 10 polls, a 10-minute timeout followed by a cancel, a cancel on SIGINT/SIGTERM, and the `page_url` output. The status messages match upstream.
  - A transient HTTP 5xx, 429, lost connection or request timeout while creating the deployment is retried up to 3 times, 10 s and then 20 s apart.
  - Before each retry the action calls `GET .../pages/deployments/{sha}`. It adopts that deployment unless it is in a final failed state, so a response lost after the server created the deployment never leads to a second deployment of the same commit.
  - Any other 4xx fails at once, without a retry. The message includes the status, the `x-github-request-id`, the response body, and a hint: for 401/403 it names the `pages: write` / `id-token: write` permissions, and for 404 it links the Pages settings.
- `docs.yml`:
  - The Pages upload step has `id: pages-artifact`, and the build job outputs `pages-artifact-id`.
  - The deploy job runs `uses: $/.github/actions/deploy-pages` with `artifact_id: ${{ needs.build.outputs.pages-artifact-id }}`, so it publishes exactly that artifact.
  - The `NODE_OPTIONS: --disable-warning=DEP0040` workaround is removed. The action has no npm dependencies, so there is no bundled `punycode`.
- `.github/actionlint.yaml`: the self-repository `$/` exception now also covers the `deploy-pages` path.

### #131: link checker
- `links.yml` runs every Monday at 06:00 UTC (`schedule`).
- The new step "Name today's link cache" outputs `date -u +%F`. The cache uses `key: cache-lychee-<day>-<sha>` and `restore-keys: cache-lychee-<day>-`, so only a cache saved the same UTC day is restored. lychee accepts such a cache under `--max-cache-age 1d`, so `[WARN] Cache is too old` cannot occur.

### #132: npm lockfile security
- **glob GHSA-3g3m-2fjr-6pw4 / minimatch GHSA-g3hv-75wg-m249:**
  - The artifact action now pins `glob` 14.0.3 (via the `archiver-utils` override) and `minimatch` 11.0.4 (direct dependency plus `"minimatch": "$minimatch"` override).
  - `npm audit` reports 0 vulnerabilities.
  - `@actions/glob` 0.7.0, the latest release, calls `Minimatch#matchOne`, which minimatch 11 removed. `files.mjs` therefore matches upload paths with minimatch 11 directly and keeps the `@actions/glob` rules:
    - one pattern per line, with `#` comments and `!` exclusions;
    - every file under a matched directory is included;
    - hidden entries and symlinks are skipped.
  - `experiments/find_files_differential.mjs` checks this: 42 cases gave output identical to the old `@actions/glob` implementation.
  - `dist/` is rebuilt, and the rebuild is reproducible.
- **Security workflow:** the new job "Audit npm Lockfiles" runs `scripts/audit-npm-locks.sh`. It runs `npm audit --package-lock-only --audit-level=moderate` for every tracked `package-lock.json`, and on failure prints a `::error file=…` annotation with how to fix it. The job is part of the Pipeline Status gate and runs on pushes, PRs and the weekly schedule.
- **Dependabot:** new `.github/dependabot.yml` with `github-actions` for `/` and `npm` for `/.github/actions/artifact`. Both run weekly with `cooldown: default-days: 7` and grouped updates.
- **Dependabot and `dist/`:** Dependabot does not rebuild `dist/`. "Verify committed action bundle" now fails with an explicit annotation listing the rebuild commands, and this is documented in `dependabot.yml` and `docs/ci-evidence.md`.

### Docs and changelog
- README ("Deploying API documentation", Lychee section) and `docs/ci-evidence.md` are updated.
- Changelog fragment: `changelog.d/20261102_issue_133_ci_reliability.md`.

## How to reproduce the original problems
- **#130:** with `actions/deploy-pages@v5`, a single HTTP 500 from `POST /pages/deployments` fails the job with no retry. `tests/deploy-pages.test.mjs` scripts exactly this with a mocked API.
  - Mutation check: with adoption disabled, 2 tests fail; with `attempts = 1`, 10 tests fail.
- **#131:** before this change, `restore-keys: cache-lychee-` restored a cache of any age, and lychee logged `[WARN] Cache is too old` and discarded it. `links.yml` also had no `schedule`.
- **#132:** `npm audit --package-lock-only` on the old `.github/actions/artifact/package-lock.json` reports the glob and minimatch advisories. `scripts/audit-npm-locks.sh` exits 1 on a fixture repository containing that lock.

## Tests
- `node --throw-deprecation --test tests/deploy-pages.test.mjs`: 28 tests, all passing, covering:
  - 500/502/503/504/429 retried with exactly one deployment created;
  - network errors and timeouts retried;
  - 400/401/403/404/409/422 failing on the first call, reporting the status and request ID;
  - retries exhausted after 3 attempts;
  - adoption of a queued, in-progress or succeeded deployment;
  - a new deployment when the earlier one failed;
  - every final state;
  - temporary states and poll errors;
  - backoff, the interval cap, cancel after too many errors, and cancel on timeout;
  - artifact ID validation;
  - `githubApi`, `oidcToken`, and `main` writing `page_url`.
- These tests run in the Workflows pipeline ("Test Pages deployment retries and refusals"). `tests/*.test.mjs` is added to its path filters.
- `node --throw-deprecation --test tests/artifact.test.mjs`: 21 tests, all passing, including the new `findFiles` semantics test and the lockfile version assertions.
- `tests/test_issue_133_workflows.py` covers:
  - the build output, the deploy wiring, and the action interface with no dependencies;
  - the weekly schedule and the UTC-day cache key/restore-keys;
  - the npm-audit job and its gate;
  - the audit script listing every tracked lockfile;
  - the Dependabot ecosystems, directories, weekly interval and cooldown;
  - the stale-bundle error;
  - patched lockfile versions.
- Updated `tests/test_issue_118_workflows.py`: the cache key test, and the DEP0040 test is replaced by an assertion that no `NODE_OPTIONS` remain.
- Updated `tests/test_workflows.py`: the deploy-pages pin and the checkout count (27).
- Local checks:
  - actionlint 1.7.12 (the pinned image) is clean.
  - zizmor 1.30.1 (regular and pedantic, as in CI) reports no findings.
  - shellcheck 0.11.0.1 is clean.
  - `ruff check` and `ruff format --check` pass.

## Notes
- Adoption identifies a deployment by commit SHA (`pages_build_version`), which is what the Pages API's `GET /pages/deployments/{sha}` exposes. Adoption is only attempted on a retry within the same job, so the adopted deployment is normally the one the lost response created. The API cannot tell apart a deployment of the same commit that an earlier run created and that has not failed; such a deployment would also be adopted, and it publishes a site built from the same commit.
- The two moderate Dependabot alerts GitHub reports on `main` are the glob/minimatch advisories that this PR fixes.


# link-foundation/python-ai-driven-development-pipeline-template #130 Pages deployment fails on a single transient HTTP 500: actions/deploy-pages@v5 never retries creating the deployment
https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/130

## Problem

`actions/deploy-pages@v5` creates the Pages deployment with a single `POST /repos/{owner}/{repo}/pages/deployments` request and fails the job on any error, including a transient HTTP 500. Only the later status polling tolerates errors (`error_count`). A single GitHub-side 5xx therefore turns a run red even though the build, the tests and the artifact were all fine, and `main` stays red until someone reruns the job by hand.

This happened in konard/konard.github.io run [41480863205](https://github.com/konard/konard.github.io/actions/runs/41480863205) on `main`:

```
##[error]Creating Pages deployment failed
##[error]Error: Failed to create deployment (status: 500) with build version 5f7f468bef7af0fbb6a0074123743cbcb3e6b1e8. Request ID AA00:25F91:3BD2504:C7A75DA:6AE8C100 Server error, is githubstatus.com reporting a Pages outage? Please re-run the deployment at a later time.
...
Pipeline failed: deploy: failure
```

The action itself suggests re-running. The template runs the same action with no retry, so every repository generated from it inherits this failure mode:

- [`.github/workflows/docs.yml` line 114](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/blob/67cfe05f/.github/workflows/docs.yml#L112-L118) (`uses: actions/deploy-pages@v5`, step "Deploy Pages artifact")

An older report of 5xx failures upstream (actions/deploy-pages#193) is closed, and v5 still sends a single creation request.

## Why a plain retry wrapper is not enough

Rerunning the whole action (for example with a generic retry action) can create a second deployment when the first POST succeeded but its response was lost. That races two deployments of the same commit.

## Suggested fix

This was fixed in konard/konard.github.io#52 (issue konard/konard.github.io#51) with a small local action that speaks the same REST protocol as deploy-pages v5, without npm dependencies:

- [`scripts/deploy-pages.mjs`](https://github.com/konard/konard.github.io/blob/issue-51-bc3e586ec5c3/scripts/deploy-pages.mjs) and [`.github/actions/deploy-pages`](https://github.com/konard/konard.github.io/tree/issue-51-bc3e586ec5c3/.github/actions/deploy-pages):
  1. Request the OIDC token (`ACTIONS_ID_TOKEN_REQUEST_URL`), as `core.getIDToken()` does.
  2. Make `POST .../pages/deployments` with `{artifact_id, pages_build_version, oidc_token}`.
     - Retry only 429, 5xx and network errors, a bounded number of times with backoff.
     - Fail permanent 4xx (400/401/403/404/422) on the first attempt.
  3. Before each retry, `GET .../pages/deployments/{sha}`. If a deployment of this commit exists and has not failed, adopt it instead of creating a second one.
  4. Poll until `succeed`. Fail on `deployment_failed`, `deployment_content_failed`, `deployment_cancelled` or `deployment_lost`.
  5. Cancel the deployment (`POST .../cancel`) on timeout, on too many polling errors, or when the job is cancelled (SIGINT/SIGTERM).
- The build job outputs the ID of the artifact it uploaded, and the deploy job publishes exactly that artifact.
- Unit tests with a mocked API: [`src/deploy-pages.test.js`](https://github.com/konard/konard.github.io/blob/issue-51-bc3e586ec5c3/src/deploy-pages.test.js). They cover a 500 followed by success (one publication), each permanent status, retry exhaustion, adoption after a lost response, a failed earlier deployment, every final state, polling errors and timeout.

Because the replacement uses only `fetch`, it also removes the bundled punycode DEP0040 warning (actions/deploy-pages#413 and #434). That would make the NODE_OPTIONS workaround unnecessary.

A lighter alternative is to keep `actions/deploy-pages@v5` and add a second attempt guarded by `if: steps.deployment.outcome == 'failure'` (with `continue-on-error` on the first attempt). Note that this alternative retries permanent errors too, and does not adopt a deployment whose response was lost.

## Acceptance criteria

- A transient 5xx or 429 from the deployment creation is retried a bounded number of times.
- A permanent 4xx fails at once with the status and request ID.
- A retry never creates a second deployment of the same commit.
- Covered by unit tests with a mocked API.

