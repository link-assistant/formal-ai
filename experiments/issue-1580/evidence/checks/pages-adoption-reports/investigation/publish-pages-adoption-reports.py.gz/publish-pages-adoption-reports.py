from pathlib import Path
import base64,hashlib,json,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/pages-reports-preflight');out=s/'publication';out.mkdir(exist_ok=True)
commit='f8718c44e7fdf7b9aa5ad9951c50a8d0efeec55d'
summary=json.loads((s/'summary.json').read_text());assert [len(x['candidates']) for x in summary]==[3,3]
for name in ['probe-pages-adoption.mjs','template-pages-adoption.test.mjs','fixtures/pages-templates/source.json']:
 path='experiments/issue-1580/'+name
 raw=subprocess.check_output(['gh','api',f'repos/link-assistant/formal-ai/contents/{path}?ref={commit}'],cwd=r)
 (out/(name.replace('/','__')+'-hosted.json')).write_bytes(raw)
 actual=base64.b64decode(json.loads(raw)['content'])
 expected=subprocess.check_output(['git','show',commit+':'+path],cwd=r)
 assert actual==expected,path
results=[]
for row in summary:
 lang=row['language'];repo=row['repository'];body=(Path('/tmp/issue-1580-research/pages-publication')/(lang+'-adoption-report.md')).read_text().replace('COMMIT_PLACEHOLDER',commit)
 related='282' if lang=='js' else '134'
 note=f'This follows the retry implementation in [PR #{related}](https://github.com/{repo}/pull/{related}). '
 if lang=='python':note+='That PR explicitly documents the same-commit adoption limitation; this report supplies an executable cross-artifact regression and artifact-bound candidate for that remaining limitation. '
 else:note+='Its job wiring supplies the exact upload ID, but retry adoption is still indexed only by the source commit. '
 body=note+'\n\n'+body
 body+='\nProtocol references: [create deployment](https://docs.github.com/en/rest/pages/pages#create-a-github-pages-deployment) and [read deployment status](https://docs.github.com/en/rest/pages/pages#get-the-status-of-a-github-pages-deployment).\n'
 bodyfile=out/(lang+'-posted-body.md');bodyfile.write_text(body)
 urlfile=out/(lang+'-create.stdout')
 assert not urlfile.exists(),'Refuse duplicate creation; inspect prior result first.'
 p=subprocess.run(['gh','issue','create','--repo',repo,'--title','Pages retry can adopt an earlier upload from the same source commit','--body-file',str(bodyfile)],cwd=r,capture_output=True)
 urlfile.write_bytes(p.stdout);(out/(lang+'-create.stderr')).write_bytes(p.stderr);assert p.returncode==0,p.returncode
 url=p.stdout.decode().strip();raw=subprocess.check_output(['gh','issue','view',url,'--json','body,title,url,number,state,createdAt'],cwd=r)
 (out/(lang+'-posted.json')).write_bytes(raw);posted=json.loads(raw);assert posted['body']==body and posted['url']==url
 results.append({'language':lang,'repository':repo,'url':url,'number':posted['number'],'evidenceCommit':commit,'bodySha256':hashlib.sha256(body.encode()).hexdigest(),'upstreamRepairVerified':False})
 (out/'outcome.json').write_text(json.dumps(results,indent=2)+'\n');print('Filed',url,flush=True)
