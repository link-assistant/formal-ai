from pathlib import Path
import base64,hashlib,json,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/pages-reports-preflight');s.mkdir(exist_ok=True)
def run(name,args):
 p=subprocess.run(args,cwd=r,capture_output=True);(s/(name+'.stdout')).write_bytes(p.stdout);(s/(name+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,(name,p.returncode);return p.stdout
run('security-dispatch',['gh','workflow','run','security.yml','--repo','link-assistant/formal-ai','--ref','issue-1580-8d61a32a61e1','-f','mode=checks','-f','codeql=true','-f','pull-request=1581'])
manifest=json.loads((r/'experiments/issue-1580/fixtures/pages-templates/source.json').read_text());rows=[];bodies=[]
for entry in manifest:
 lang=entry['language'];repo=entry['repository']
 pages=json.loads(run(lang+'-all-issues',['gh','api',f'repos/{repo}/issues?state=all&per_page=100','--paginate','--slurp']))
 issues=[row for page in pages for row in page]
 candidates=[]
 for item in issues:
  text=(item['title']+'\n'+(item.get('body') or '')).lower()
  if 'pages' in text and ('adopt' in text or 'same commit' in text or 'same source' in text):
   candidates.append({'number':item['number'],'title':item['title'],'url':item['html_url'],'state':item['state'],'pullRequest':'pull_request' in item})
   bodies.append(f"# {repo} #{item['number']} {item['title']}\n{item['html_url']}\n\n{item.get('body') or ''}\n")
 files=[]
 for source in entry['files']:
  if source['path']=='LICENSE':continue
  data=json.loads(run(lang+'-current-'+source['path'].replace('/','__'),['gh','api',f"repos/{repo}/contents/{source['path']}?ref=main"]))
  raw=base64.b64decode(data['content']);sha=hashlib.sha256(raw).hexdigest()
  assert sha==source['sha256'],(lang,source['path'],sha)
  files.append({'path':source['path'],'gitBlob':data['sha'],'sha256':sha,'sameAsPinnedFixture':True})
 rows.append({'language':lang,'repository':repo,'issueAndPullRequestCount':len(issues),'candidates':candidates,'currentFiles':files})
(s/'candidate-bodies.md').write_text('\n'.join(bodies))
(s/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Dispatched new-head read-only CodeQL. Current template helpers match pinned bytes. Review these report candidates:')
for row in rows:
 print(row['language'],row['issueAndPullRequestCount'],json.dumps(row['candidates']))
