from pathlib import Path
import ast,collections,datetime,gzip,hashlib,io,json,subprocess,tarfile
r=Path('/tmp/issue-1580-research')
out=r/'rust-practice-hosted-reconciliation'
assert not out.exists()
out.mkdir()
source='aaac490e3087736f303434502f9710c3228aed4e'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
changed=subprocess.check_output(['git','diff','--name-only',source,'HEAD','--','scripts','experiments/issue-1580/release-registry','rust/tests/unit/cargo_package_identity.rs','rust/tests/unit/changelog_parsing.rs'],text=True).splitlines()
assert changed==['scripts/check-workflow-concurrency.mjs'],changed
paths=['scripts/check-version-modification.rs','scripts/rust-paths.rs','scripts/registry.rs','scripts/cargo-package.rs','scripts/publish-crate.rs','scripts/wait-for-crate.rs','scripts/check-release-needed.rs','scripts/version-and-commit.rs','scripts/create-changelog-fragment.rs','scripts/collect-changelog.rs','scripts/changelog-files.rs','scripts/release-changelog.rs','experiments/issue-1580/release-registry/cli_regressions.py','experiments/issue-1580/release-registry/release_process_regressions.py','experiments/issue-1580/release-registry/Cargo.toml','experiments/issue-1580/release-registry/Cargo.lock']
bindings=[]
for name in paths:
 data=Path(name).read_bytes()
 old=subprocess.check_output(['git','show',source+':'+name])
 assert data==old,name
 bindings.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'unchangedFromHostedSource':True})
cases=[]
for name in paths[12:14]:
 v=ast.parse(Path(name).read_text())
 cases.extend({'path':name,'test':n.name,'line':n.lineno} for n in ast.walk(v) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_'))
assert len(cases)==33
version=[x for x in cases if x['test'].startswith('test_version_check')]
assert len(version)==10
allpasses=json.loads((r/'hosted-aaac-native-practice-review/passing-native-tests.json').read_text())
prefixes=['cargo_package_identity::','changelog_fragment_file::','changelog_parsing::release_changelog::','collect_changelog::','check_changelog_fragment::','version_changelog::']
native=[x for x in allpasses if any(x['test'].startswith(p) for p in prefixes)]
assert native
pipeline=r/'extracted-native-head-ci/complete-run-45129261558.stdout.gz'
wanted={x['line']:x for x in native}
captured=[]
wholehash=hashlib.sha256()
with gzip.open(pipeline,'rb') as stream:
 for i,raw in enumerate(stream,1):
  wholehash.update(raw)
  if i in wanted:
   text=raw.decode()
   assert wanted[i]['test'] in text and ' ... ok' in text,(i,text)
   captured.append(str(i)+' '+text)
  elif 66023<=i<=66032:captured.append(str(i)+' '+raw.decode())
wholelines=i
assert wholelines==78689
counts={p:sum(x['test'].startswith(p) for x in native) for p in prefixes}
base={'hostedSource':source,'observedAgainstLocalHead':head,'pipelineRun':45129261558,'pipelineUrl':'https://github.com/link-assistant/formal-ai/actions/runs/45129261558','checkoutMerge':'5325c4d0071f6528fabfe474d7390771da874780','wholeLogLines':wholelines,'wholeLogSha256':wholehash.hexdigest(),'wholeLogReceipt':'experiments/issue-1580/evidence/checks/hosted-merged-head-aaac/manifest.json','sourceBindings':bindings,'broaderSourceDelta':changed,'nativePassesByPrefix':counts,'nativePassingRows':native,'cliSuite':{'methods':cases,'passed':33,'versionMethods':10,'summaryLogLines':[66026,66030,66032],'pressureControlsLogLines':[66027,66029]},'scopeLimit':'Local fixtures use loopback registry and command controls. This is not live publication authority, sparse registry equivalence, whole-template adoption or qualification of the newer concurrency repair.','allApplicablePracticesImplementedAndVerified':False,'independentAuthorshipCredit':0,'fullIssueComplete':False}
(out/'observations.json').write_text(json.dumps(base,indent=2)+'\n')
(out/'actual-passing-log-lines.txt').write_text(''.join(captured))
ledger=Path('docs/case-studies/issue-1580/templates/rust-source-review-progress.json')
value=json.loads(ledger.read_text())
(out/'practice-ledger-before.json').write_text(json.dumps(value['practiceDecisions'],indent=2)+'\n')
updates={
'Parsed version identity and branch authorization':('The production guard parses package identity, refuses malformed/missing/inherited versions and failed current-base fetches, and checks current-base equality. The hosted aaac pipeline passes all 33 release CLI methods, including ten version methods covering every former release-prefix exemption, increases/decreases, a real base-version merge, custom refmaps and concurrent tracking-ref changes. Eleven package-identity native cases also pass. These source files are byte-identical at the reconciliation head. The fixed repository release layout has a literal package version; generalized workspace-guard parity remains unverified.','hosted-expanded-version-controls-verified-full-template-parity-pending'),
'Registry uncertainty, crate publication and package path helpers':('The pinned template helpers remain fully source-reviewed. Formal AI uses bounded shared registry requests, validates the requested version identity and preserves transient/permanent/absence distinctions. The hosted 33-method CLI suite now verifies the waiter, failed lookups, candidate identities, output-write failures and writer version floors against a loopback registry. Actual registry helper tests pass in the same hosted job. Sparse-first parity, credential-store fallback, rate-limit deferral and dependent-job ownership still need complete applicability and implementation verification; actual publication authority remains unknown.','hosted-registry-and-cli-controls-verified-remaining-practices-pending'),
'Release-source and Git-index ownership':('Formal AI retains staged tested-artifact authority. The hosted aaac pipeline verifies parsed package identity and physical version CLI cases, including highest-published floors and preserved version bytes after failed observations. Its former whole-document version regex is removed. These results do not complete comparison of release-only mutation ownership, optional lock handling, push races or ruleset refusals with the pinned template.','hosted-parsed-identity-verified-release-ownership-parity-pending'),
'Changelog fragment ownership and collection':('Exclusive creation, symlink preservation, concurrent creators and physical collection failures pass in the hosted aaac native results. Both shared release-heading consumers and snapshot cleanup controls pass. The hosted 33-method CLI suite includes inventory/read failures, byte preservation and both encoded fragment-diagnostic controls. The selected sources are unchanged at the reconciliation head. Complete fragment-guard applicability and full template CLI equivalence remain unfinished.','hosted-ownership-heading-and-diagnostic-controls-verified-full-parity-pending'),
'Crate release identity, package size and downstream smoke tests':('The pinned template bounds registry-version collisions, checks Actions outputs, caps release text and verifies published installation/dependent compilation. Formal AI hosted controls now verify exact registry identity, output-write failures and both bounded pipe-pressure reproductions: the original exceeds its deadline while the repair exits zero with 131072 diagnostic bytes. The CLI fixtures use a loopback registry and controlled commands. Actual publication, package-size applicability and published downstream smoke qualification remain unfinished.','hosted-release-identity-and-pipe-controls-verified-publication-and-smoke-pending')
}
receipt='experiments/issue-1580/evidence/checks/rust-practice-hosted-reconciliation/manifest.json'
for x in value['practiceDecisions']:
 if x['practice'] in updates:
  x['assessment'],x['status']=updates[x['practice']]
  x['latestHostedObservation']={'sourceHead':source,'pipelineRun':45129261558,'evidence':receipt,'allApplicablePracticeVerified':False,'actualPublicationVerified':False,'independentAuthorshipCredit':0}
 if x['practice']=='Exact candidate identity before native jobs':
  x['latestHostedObservation']={'sourceHead':source,'checkoutMerge':base['checkoutMerge'],'pipelineRun':45129261558,'nativeGroupsExecuted':10,'evidence':receipt,'allApplicablePracticeVerified':False,'newerConcurrencyRepairVerified':False,'independentAuthorshipCredit':0}
assert value['allApplicablePracticesImplementedAndVerified'] is False
ledger.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
(out/'practice-ledger-after.json').write_text(json.dumps(value['practiceDecisions'],indent=2)+'\n')
prior=(r/'seal-extracted-native-modules.py').read_text()
exec(prior[prior.index('def seal('):prior.index('cohort=r/')])
files={p.relative_to(r).as_posix():p for p in out.iterdir() if p.is_file()}
seal('rust-practice-hosted-reconciliation',files,{'hostedSource':source,'observedAgainstLocalHead':head,'pipelineRun':45129261558,'nativePassesByPrefix':counts,'cliMethodsPassed':33,'versionCliMethodsPassed':10,'sourceBindings':len(bindings),'wholeLogSha256':base['wholeLogSha256'],'fullTemplatePracticeEquivalenceVerified':False,'actualPublicationVerified':False})
Path('docs/case-studies/issue-1580/hosted-rust-practice-reconciliation.md').write_text("""# Hosted Rust practice reconciliation

The [aaac pipeline](https://github.com/link-assistant/formal-ai/actions/runs/45129261558)
passed on branch source aaac490e3087736f303434502f9710c3228aed4e, checked
out as synthetic merge 5325c4d0071f6528fabfe474d7390771da874780. All ten native
groups ran. This historical result does not qualify the newer rerun policy.

Its registry job passed all 33 CLI methods, including ten version methods.
These exercise the former release-like branch exemptions, version increases and
decreases, a real base-version merge, current-base fetching, custom refmaps and
concurrent ref changes. Both fragment logging controls pass with exact file
bytes and encoded diagnostics. Both pipe-pressure controls record the original
deadline failure and repaired exit zero with 131072 diagnostic bytes.

The native output also records package-identity, exclusive fragment creation,
physical collection failures, snapshot cleanup and strict release-heading cases.
The receipt retains their exact names and whole-log line numbers. Repeated
consumers of a shared helper remain separate observations of the same cases.

All sixteen bound script, harness and lockfile sources are byte-identical
between the hosted branch source and reconciliation head. The broader script
delta contains only the new workflow-concurrency checker. AST enumeration gives
28 primary methods and five inherited process methods, matching the hosted
33-test summary at lines 66026 through 66032. The whole 78689-line log is retained
in the earlier hosted receipt and bound here by its uncompressed SHA-256.

The [reconciliation receipt](../../../experiments/issue-1580/evidence/checks/rust-practice-hosted-reconciliation/manifest.json)
preserves exact passing lines, source bindings and both ledger versions. The
practice ledger now records this execution instead of leaving these cases
pending. Archive members were reopened and checked for byte length and SHA-256.

Loopback registry and controlled-command tests do not establish live publication
authority, complete template equivalence, package-size applicability or published
downstream smoke qualification. Those criteria and the newer concurrency repair
remain unfinished in [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581).
The PR stays draft and unmerged; supplied work receives zero independent
authorship credit.
""")
print(json.dumps({'nativeCounts':counts,'cliMethods':len(cases),'ledgerRowsUpdated':len(updates),'head':head}))
