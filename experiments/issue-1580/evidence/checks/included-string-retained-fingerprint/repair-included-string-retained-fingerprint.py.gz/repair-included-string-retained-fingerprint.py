from pathlib import Path
import gzip, hashlib, json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/checks/included-string-retained-fingerprint'
base.mkdir(exist_ok=False)
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
records = []
def run(name, argv, expected=0):
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
    record = {'name': name, 'argv': argv, 'exitCode': result.returncode, 'expectedExitCode': expected}
    for label, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
        filename = name + '.' + label + '.gz'
        packed = gzip.compress(raw, mtime=0)
        (base / filename).write_bytes(packed)
        record[label] = {'file': filename, 'sha256': hashlib.sha256(raw).hexdigest(),
            'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())}
    records.append(record)
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == expected, (name, result.stdout.decode(errors='replace')[-3000:], result.stderr.decode(errors='replace')[-1000:])
    return result
run('before', ['node', '--test', '--test-reporter=tap', '--test-concurrency=1',
    '--test-name-pattern=heavy original job bodies', 'rust/tests/web/fast-pull-request-production-profile.test.mjs'], 1)
code = '''import fs from 'node:fs';import assert from 'node:assert/strict';import YAML from 'yaml';import {execFileSync} from 'node:child_process';import {createHash} from 'node:crypto';
const file='data/benchmarks/fast-pull-request-retained-jobs.json';
const old=YAML.parse(execFileSync('git',['show','5e6037196159d1a83f3bbe23f2c404dbdae1105e^:.github/workflows/security.yml'],{encoding:'utf8'})).jobs.codeql;
const current=YAML.parse(fs.readFileSync('.github/workflows/security.yml','utf8')).jobs.codeql;
const payload=job=>({steps:job.steps,uses:job.uses,with:job.with,strategy:job.strategy});
const normalized=structuredClone(current), observer=normalized.steps.filter(step=>step.name==='Observe included Rust string payloads');
assert.equal(observer.length,1);
assert.equal(observer[0].if,"${{ github.job == 'codeql-readonly' && matrix.language == 'rust' && inputs.macro-contexts }}");
assert.equal(observer[0]['timeout-minutes'],4);
assert.match(observer[0].run,/--profile included-string-payloads/u);
normalized.steps=normalized.steps.filter(step=>step!==observer[0]);
assert.deepEqual(payload(normalized),payload(old),'all previously reviewed producer payload must survive unchanged');
assert.equal(current.if,old.if,'the production admission predicate is unchanged');
const manifest=JSON.parse(fs.readFileSync(file,'utf8')), before=structuredClone(manifest);
const rows=manifest.jobs.filter(row=>row.file==='security.yml'&&row.id==='codeql');assert.equal(rows.length,1);
const hash=job=>createHash('sha256').update(JSON.stringify(payload(job))).digest('hex');
assert.equal(rows[0].payloadSha256,hash(old));
const previous=rows[0].payloadSha256; rows[0].payloadSha256=hash(current);
const reverted=structuredClone(manifest);reverted.jobs.find(row=>row.file==='security.yml'&&row.id==='codeql').payloadSha256=previous;
assert.deepEqual(reverted,before,'only the single reviewed fingerprint may change');
fs.writeFileSync(file,JSON.stringify(manifest,null,2)+'\\n');
console.log(JSON.stringify({previous,current:rows[0].payloadSha256,onlyIncludedStringObserverAdded:true,originalProducerPayloadPreserved:true,productionAdmissionUnchanged:true,observerDisabledInProduction:true}));'''
run('review-and-refresh', ['node', '--input-type=module', '-e', code])
for name, file in [('production-profile', 'fast-pull-request-production-profile'), ('security', 'security-codeql-results')]:
    run(name, ['node', '--test', '--test-reporter=tap', '--test-concurrency=1', 'rust/tests/web/' + file + '.test.mjs'])
run('whitespace', ['git', 'diff', '--check'])
(base / 'verification.json').write_text(json.dumps({'complete': True, 'failingRun': 44843761720,
    'head': 'd48b09883ac91cd1d2319bea2afbaf0df2df8f86', 'originalLogErrorLine': 8379,
    'failingBefore': True, 'passingAfter': True, 'onlyReviewedFingerprintChanged': True,
    'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
print('Stale retained payload failed before; exact isolated-observer inverse and both maintained suites pass after refresh.')
