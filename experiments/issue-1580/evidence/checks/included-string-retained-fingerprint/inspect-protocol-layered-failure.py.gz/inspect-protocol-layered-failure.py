from pathlib import Path
import gzip, hashlib, json, subprocess
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/protocol-layered-failure')
out.mkdir(exist_ok=False)
rid = '44843761720'
for name, args in [('state', ['--json', 'headSha,status,conclusion,jobs,url,createdAt,updatedAt']), ('full-log', ['--log'])]:
    argv = ['gh', 'run', 'view', rid, '--repo', 'link-assistant/formal-ai'] + args
    result = subprocess.run(argv, cwd=root, capture_output=True)
    for stream, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
        (out / (name + '.' + stream + '.gz')).write_bytes(gzip.compress(raw, mtime=0))
    assert result.returncode == 0, result.stderr.decode()
    if name == 'state':
        state = json.loads(result.stdout)
        assert state['headSha'] == 'd48b09883ac91cd1d2319bea2afbaf0df2df8f86'
        print(json.dumps(state), flush=True)
    else:
        lines = result.stdout.decode().splitlines()
        selected = set()
        for i, line in enumerate(lines):
            if any(word in line for word in ['not ok', '##[error]', 'AssertionError', 'ERR_ASSERTION', 'FAIL ']):
                selected.update(range(max(0, i-4), min(len(lines), i+15)))
        print(json.dumps({'bytes': len(result.stdout), 'lines': len(lines), 'sha256': hashlib.sha256(result.stdout).hexdigest()}))
        for i in sorted(selected):
            print(str(i+1) + ': ' + lines[i])
