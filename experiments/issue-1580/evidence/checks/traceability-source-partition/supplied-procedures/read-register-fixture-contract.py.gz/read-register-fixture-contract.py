from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
for name in ['scripts/lib/requirements-register.mjs','scripts/lib/requirements-traceability.mjs']:
 print(name);print((root/name).read_text())
