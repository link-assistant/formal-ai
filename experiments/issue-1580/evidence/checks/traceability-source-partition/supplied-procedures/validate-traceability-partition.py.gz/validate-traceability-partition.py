from pathlib import Path
import subprocess,json,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/traceability-partition-validation-corrected')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 p=root/'rust/tests/unit/architect_notes.rs';text=p.read_text();matches=[line for line in text.splitlines() if line.strip()=='"docs/requirements-traceability.md",'];assert len(matches)==1;old=matches[0];indent=old[:len(old)-len(old.lstrip())];p.write_text(text.replace(old,old+'\n'+indent+'"docs/requirements-traceability-continuation.md",'))
 with (out/'worker.log').open('w') as stream:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':p.pid})+'\n');print(p.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==0,(name,r.returncode)
try:
 files=['scripts/lib/requirements-traceability.rs','scripts/generate-requirement-status.rs','scripts/check-issue-citations.rs','rust/tests/support/assembled_docs.rs','rust/tests/unit/architect_notes.rs']+['rust/tests/unit/docs_requirements/'+name+'.rs' for name in ['equation_corpus_ratchet','full_range_coding_artifacts','ci_template_upstream_filings','headless_client_configuration','summarization_validation']]
 run('rustfmt',['rustfmt','--edition','2024',*files]);run('rustfmt-check',['rustfmt','--edition','2024','--check',*files])
 for name,file in [('partition','experiments/issue-1580/traceability-partition.test.mjs'),('requirement-evidence-matrix','rust/tests/web/requirement-evidence-matrix.test.mjs'),('requirement-status-test-path','rust/tests/web/requirement-status-test-path.test.mjs')]:run(name,['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',file])
 run('complete-javascript-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs'])
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'rowCount':1429,'nativeCompilation':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
