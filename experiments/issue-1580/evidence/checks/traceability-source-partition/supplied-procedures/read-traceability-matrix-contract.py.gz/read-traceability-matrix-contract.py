from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
for name,start,end in [('scripts/lib/requirement-evidence-matrix.mjs',80,243),('rust/tests/web/requirement-evidence-matrix.test.mjs',1,200),('experiments/issue-1580/work-plan.md',1,90)]:
 lines=(root/name).read_text().splitlines();print('\nFILE',name,'TOTAL',len(lines))
 for i in range(start-1,min(end,len(lines))):print(f'{i+1}: {lines[i]}')
