from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048')
p=root/'docs/case-studies/issue-951/function-inventory.json';print(p.read_text())
r=subprocess.run(['rg','-n','function-inventory|legacy_functions|ui_jsx_character_ceiling','scripts','rust/tests','docs/case-studies/issue-951'],cwd=root,capture_output=True,text=True);print(r.stdout)
p=root/'experiments/issue-1580/application-conversation-list.test.mjs';print(p.read_text())
