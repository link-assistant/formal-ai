from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
for name in ['scripts/check-web-ui-boundary.py','js/app/application-conversation-hooks.jsx','experiments/issue-1580/application-conversation-list.test.mjs']:
 lines=(root/name).read_text().splitlines();assert len(lines)<=1500;print('FILE',name,'LINES',len(lines))
 for i,line in enumerate(lines,1):print(f'{i}: {line}')
