from pathlib import Path
import shutil,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/traceability-partition-validation-corrected')
p=root/'experiments/formal_ai_subagent/sandboxes/gates/web-ui-boundary.log';shutil.copyfile(p,out/'web-ui-boundary.failed.log');print(p.read_text())
for term in ['web-ui-boundary','requirements-traceability.md']:
 r=subprocess.run(['rg','-n',term,'scripts/check-web-ui-boundary.mjs','scripts/check-web-ui-boundary.rs','experiments/formal_ai_subagent/local-gates.mjs'],cwd=root,text=True,capture_output=True);print(r.stdout);print(r.stderr)
