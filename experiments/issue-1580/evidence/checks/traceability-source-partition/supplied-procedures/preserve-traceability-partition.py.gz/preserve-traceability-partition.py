from pathlib import Path
import subprocess,json,gzip,hashlib,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'traceability-partition-preservation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==0,(name,r.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 assert json.loads((scratch/'traceability-final-gates/outcome.json').read_text())['allPassed']
 assert json.loads((scratch/'csharp-complete-comparison-preservation/outcome.json').read_text())['complete']
 assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
 target=root/'experiments/issue-1580/evidence/checks/traceability-source-partition';target.mkdir(exist_ok=False);records=[]
 def archive(raw,name):
  packed=gzip.compress(raw,mtime=0);dest=target/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed);assert gzip.decompress(dest.read_bytes())==raw
  records.append({'path':str(dest.relative_to(target)),'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
 for dirname in ['traceability-partition','traceability-partition-validation','traceability-partition-validation-corrected','traceability-final-regression','traceability-final-regression-corrected','traceability-final-gates']:
  for p in sorted((scratch/dirname).rglob('*')):
   if p.is_file():archive(p.read_bytes(),dirname+'/'+str(p.relative_to(scratch/dirname)))
 for name in ['draft-traceability-partition.py','validate-traceability-partition.py','finish-traceability-regression.py','correct-traceability-fixture.py','finish-traceability-gates.py','read-traceability-review.py','read-traceability-matrix-contract.py','read-traceability-gate-failure.py','read-web-boundary-hook.py','read-web-boundary-inventory.py','read-register-fixture-contract.py',Path(__file__).name]:archive((scratch/name).read_bytes(),'supplied-procedures/'+name)
 for name in ['draft-traceability-partition-driver.log','validate-traceability-partition-driver.log','validate-traceability-partition-corrected-driver.log','finish-traceability-regression-driver.log','correct-traceability-fixture-driver.log','finish-traceability-gates-driver.log','read-traceability-review-driver.log','read-traceability-matrix-contract-driver.log','read-traceability-gate-failure-driver.log','read-web-boundary-hook-driver.log','read-web-boundary-inventory-driver.log','read-register-fixture-contract-driver.log']:
  p=scratch/name
  if p.exists():archive(p.read_bytes(),'review-attempts/'+name)
 changed=['docs/requirements-traceability.md','scripts/generate-requirement-status.mjs','scripts/generate-requirement-status.rs','scripts/check-issue-citations.rs','scripts/lib/requirements-head-overlay.mjs','scripts/lib/requirement-evidence-matrix.mjs','rust/tests/support/assembled_docs.rs','rust/tests/unit/architect_notes.rs','rust/tests/web/issue-1580-template-observations.test.mjs','docs/case-studies/issue-951/function-inventory.json','experiments/issue-1580/application-conversation-list.test.mjs']+['rust/tests/unit/docs_requirements/'+name+'.rs' for name in ['equation_corpus_ratchet','full_range_coding_artifacts','ci_template_upstream_filings','headless_client_configuration','summarization_validation']]
 for name in changed:
  original=subprocess.check_output(['git','show','HEAD:'+name],cwd=root);archive(original,'git-head-preimages/'+name)
 (target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
 doc=root/'docs/case-studies/issue-1580/traceability-source-partition.md';doc.write_text('''# Complete traceability source partition

The 1,480-line traceability document crossed the existing 1,400-line warning
threshold. Its root page now links a continuation beside it, retaining the
same relative-link base and all 1,429 original table rows byte for byte. The
introduction, column definitions and manual retirement notice are unchanged.
Neither requirement verdicts nor generated status fields change.

JavaScript and Rust readers follow the explicit continuation index, preserve
legacy single-file fixtures and fail when an indexed page is missing. Status
generation, source overlays, evidence bindings, citations and Rust documentation
consumers read both pages. Evidence capture binds the continuation bytes and
rejects later changes. A compressed original is a consumed conservation fixture.

Four focused cases and all 313 maintained issue cases pass. Existing evidence
matrix and status-path suites pass. Rust formatting passes for all ten changed
Rust files; no local native compilation or execution occurred. The full
141-gate JavaScript run recorded 87 passes, 53 explicit hosted-only skips and
one failure: the earlier conversation-list hook lacked its inventory entry.
Its exact conserved-body regression now also checks the registration and the
unchanged 306,259-character ceiling. It fails before that correction; all six
hook cases and the unchanged boundary gate pass afterward. The full run and
targeted corrections are separate retained results, not a fabricated green
full rerun.

The stronger continuation-drift fixture initially omitted the required assembled
register; adding a minimal register corrected the fixture. An invalid guessed
gate name also failed explicitly, then the four actual affected gates passed.
All attempts, complete streams and true Git preimages remain under
`experiments/issue-1580/evidence/checks/traceability-source-partition/`.

Nine size warnings on retained source captures remain under unchanged limits.
Current hosted validation, remaining template/practice checks and the wider
issue are unfinished. Supplied procedures and conclusions earn zero independent
Formal AI authorship credit. Pull request:
https://github.com/link-assistant/formal-ai/pull/1581.
''')
 fragment=root/'changelog.d/20261121_1580_traceability_source_partition.md';fragment.write_text('''Keep every requirement traceability row while splitting the large source table
into indexed pages, with matching readers and complete evidence bindings. Register
the conserved conversation-list hook in the existing UI boundary inventory.
''')
 plan=root/'experiments/issue-1580/work-plan.md';s=plan.read_text();start=s.index('Published `9e945eae`');end=s.index('\nThe entries below',start);s=s[:start]+'''Published `9e945eae` includes main `f574289f`. All 32 workflows are terminal:
29 pass, one skips, Layered CI and Pipeline fail. Six source/transport checks
are repaired locally; Pipeline reports the same missing seed-reader prerequisite
in native HTTP replay. The actual cycle-rejection panic is an expected passing
negative control. All nine native contract groups and release registry scripts
pass on the published source; later local Rust changes still require hosted CI.

All 313 maintained issue cases pass. The complete JavaScript gate run has 87
passes, 53 hosted-only skips and one UI inventory failure, corrected afterward
with a failing-before registration regression and passing unchanged boundary gate.
All 1,429 traceability rows survive the indexed partition with unchanged status
fields and explicit evidence bindings. Nine retained source-capture size warnings
remain under unchanged limits. Complete pinned C# and Rust per-file comparisons
are recorded; applicable practices and other template comparisons remain open.

The stale WASM worker input receipt still requires actual hosted regeneration;
the inactive, admission-tested proposal awaits the explicit build-policy exception.
No local native compilation or execution is claimed. Independent reasoning remains
0/20. PR #1581 remains draft and unmerged; wider acceptance is unfinished.
'''+s[end:];plan.write_text(s)
 paths=changed+['docs/requirements-traceability-continuation.md','scripts/lib/requirements-traceability.mjs','scripts/lib/requirements-traceability.rs','experiments/issue-1580/traceability-partition.test.mjs','experiments/issue-1580/fixtures/traceability-partition',str(target.relative_to(root)),str(doc.relative_to(root)),str(fragment.relative_to(root)),str(plan.relative_to(root))]
 run('documentation-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-changelog-fragment-js-twin,check-reconstructed-changelog,check-file-size'])
 run('stage',['git','add','--',*paths]);run('staged-whitespace',['git','diff','--cached','--check']);run('commit',['git','commit','-m','Preserve every traceability row across indexed source pages'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'head':run('head',['git','rev-parse','HEAD']).strip(),'pushed':False,'rowsPreserved':1429,'maintainedCasesPassed':313,'nativeCompilation':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
