from pathlib import Path
import subprocess,json,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/traceability-final-regression-corrected')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False);p=root/'experiments/issue-1580/traceability-partition.test.mjs';s=p.read_text();needle="  mkdirSync(join(directory,'docs'));";assert needle in s;s=s.replace(needle,"  mkdirSync(join(directory,'docs/requirements/assembled'),{recursive:true});\n  writeFileSync(join(directory,'docs/requirements/assembled/standing-doctrine.md'),'# Empty requirement fixture\\n');");p.write_text(s)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(child.pid);sys.exit(0)
try:
 for name,args in [('partition',['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/traceability-partition.test.mjs']),('maintained-entry',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs']),('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','web-ui-boundary,check-file-size,check-requirement-status,check-requirement-coverage,check-head-requirement-ledger']),('git-whitespace',['git','diff','--check'])]:
  with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
  print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==0,(name,r.returncode)
 (out/'outcome.json').write_text(json.dumps({'allPassed':True,'nativeCompilation':False,'fullIssueComplete':False,'independentAuthorshipCredit':0})+'\n')
except BaseException:traceback.print_exc();sys.exit(1)
