from pathlib import Path
import subprocess,json,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/traceability-final-gates')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(child.pid);sys.exit(0)
try:
 for name,args in [('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','web-ui-boundary,check-file-size,check-requirement-status,check-requirement-coverage']),('git-whitespace',['git','diff','--check'])]:
  with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
  print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==0
 (out/'outcome.json').write_text(json.dumps({'allPassed':True,'maintainedCasesPassed':313,'nativeCompilation':False,'fullIssueComplete':False,'independentAuthorshipCredit':0})+'\n')
except BaseException:traceback.print_exc();sys.exit(1)
