from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
for name in ['scripts/lib/requirements-traceability.mjs','scripts/lib/requirements-traceability.rs','experiments/issue-1580/traceability-partition.test.mjs']:
 print('\nFILE',name)
 for i,line in enumerate((root/name).read_text().splitlines()):print(f'{i+1}: {line}')
for name in ['scripts/generate-requirement-status.mjs','scripts/lib/requirement-evidence-matrix.mjs']:
 lines=(root/name).read_text().splitlines();print('\nRELEVANT',name)
 for i,line in enumerate(lines):
  if any(term in line for term in ['readOrEmpty','traceability','readTraceability','traceabilityPaths','function observe','observed','hash']):print(f'{i+1}: {line}')
