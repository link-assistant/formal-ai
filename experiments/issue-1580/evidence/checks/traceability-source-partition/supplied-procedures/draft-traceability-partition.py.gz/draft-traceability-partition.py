from pathlib import Path
import subprocess,json,gzip,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/traceability-partition');out.mkdir(exist_ok=False)
def change(name,old,new):
 p=root/name;text=p.read_text();assert text.count(old)==1,(name,old);before=out/'before'/name;before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(gzip.compress(text.encode(),mtime=0));p.write_text(text.replace(old,new))
helpers=root/'scripts/lib'
(helpers/'requirements-traceability.mjs').write_text('''// JavaScript twin of scripts/lib/requirements-traceability.rs (issue #1580).
import {joinPath,readOrEmpty,readToString,ioErrorDisplay} from './requirements-rust-compat.mjs';
export const TRACEABILITY='docs/requirements-traceability.md';
export const TRACEABILITY_CONTINUATION='docs/requirements-traceability-continuation.md';
const link='(requirements-traceability-continuation.md)';

/** Read only explicitly indexed parts; legacy single-file fixtures stay valid. */
export function traceabilityPaths(root) {
  const head=readOrEmpty(joinPath(root,TRACEABILITY));
  return head.includes(link)?[TRACEABILITY,TRACEABILITY_CONTINUATION]:[TRACEABILITY];
}
export function readTraceability(root) {
  const head=readOrEmpty(joinPath(root,TRACEABILITY));
  if(!head.includes(link))return head;
  const file=joinPath(root,TRACEABILITY_CONTINUATION);
  try{return head+'\\n'+readToString(file);}
  catch(error){throw new Error(`cannot read ${file}: ${ioErrorDisplay(error)}`);}
}
''')
(helpers/'requirements-traceability.rs').write_text('''//! Indexed traceability reader; JavaScript twin: requirements-traceability.mjs.
//! Source partition only (issue #1580): no delivery or manual verdict changes.
use std::fs;
use std::path::Path;

const TRACEABILITY: &str = "docs/requirements-traceability.md";
const CONTINUATION: &str = "docs/requirements-traceability-continuation.md";
const LINK: &str = "(requirements-traceability-continuation.md)";

pub fn read_traceability(root: &Path) -> Result<String, String> {
    let head = fs::read_to_string(root.join(TRACEABILITY)).unwrap_or_default();
    if !head.contains(LINK) {
        return Ok(head);
    }
    let file = root.join(CONTINUATION);
    let tail = fs::read_to_string(&file)
        .map_err(|error| format!("cannot read {}: {error}", file.display()))?;
    Ok(format!("{head}\\n{tail}"))
}
''')
fixtures=root/'experiments/issue-1580/fixtures/traceability-partition';fixtures.mkdir(parents=True)
original=(root/'docs/requirements-traceability.md').read_bytes();(fixtures/'original.md.gz').write_bytes(gzip.compress(original,mtime=0))
test=root/'experiments/issue-1580/traceability-partition.test.mjs';test.write_text('''import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {gunzipSync} from 'node:zlib';
import test from 'node:test';
import {readTraceability,traceabilityPaths,TRACEABILITY,TRACEABILITY_CONTINUATION} from '../../scripts/lib/requirements-traceability.mjs';
import {traceRows} from '../../scripts/generate-requirement-status.mjs';
import {requirementEvidenceMatrix} from '../../scripts/lib/requirement-evidence-matrix.mjs';
const root=fileURLToPath(new URL('../../',import.meta.url));
const original=gunzipSync(readFileSync(new URL('./fixtures/traceability-partition/original.md.gz',import.meta.url))).toString();
const rows=text=>text.split('\\n').filter(line=>line.startsWith('| R'));
test('traceability pages obey the existing source warning threshold',()=>{
  for(const file of traceabilityPaths(root))assert.ok(readFileSync(join(root,file),'utf8').trimEnd().split('\\n').length<1400,file);
  assert.equal(traceabilityPaths(root).length,2);
});
test('every traceability row and generated status field survives the partition',()=>{
  const assembled=readTraceability(root);
  assert.deepEqual(rows(assembled),rows(original));
  assert.deepEqual(traceRows(assembled,root),traceRows(original,root));
  assert.ok(assembled.includes(original.slice(0,original.indexOf('| ID |'))));
});
test('legacy fixtures work and an indexed missing continuation fails explicitly',t=>{
  const directory=mkdtempSync(join(tmpdir(),'traceability-index-'));t.after(()=>rmSync(directory,{recursive:true,force:true}));
  mkdirSync(join(directory,'docs'));
  writeFileSync(join(directory,TRACEABILITY),'| R1 | shard | delivered | test | unknown |\\n');
  assert.equal(traceabilityPaths(directory).length,1);
  assert.match(readTraceability(directory),/R1/u);
  writeFileSync(join(directory,TRACEABILITY),'[Continued rows](requirements-traceability-continuation.md)\\n');
  assert.throws(()=>readTraceability(directory),/cannot read .*requirements-traceability-continuation[.]md/u);
  writeFileSync(join(directory,TRACEABILITY_CONTINUATION),'| R2 | shard | pending | test | unknown |\\n');
  assert.match(readTraceability(directory),/R2/u);
});
test('evidence inventory binds the continuation bytes',()=>{
  const matrix=requirementEvidenceMatrix(root);
  const source=JSON.stringify(matrix);
  assert.ok(source.includes(TRACEABILITY_CONTINUATION));
});
''')
with (out/'before.stdout').open('w') as stdout,(out/'before.stderr').open('w') as stderr:r=subprocess.run(['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test.relative_to(root))],cwd=root,stdout=stdout,stderr=stderr)
assert r.returncode==1,r.returncode
# Preserve prose and every row byte. Both pages keep the same docs/ link base.
lines=original.decode().splitlines(keepends=True);cut=800;assert lines[cut].startswith('| R')
head=''.join(lines[:cut]);tail=''.join(lines[cut:]);navigation='\n[Continued traceability rows](requirements-traceability-continuation.md).\n'
(root/'docs/requirements-traceability.md').write_text(head+navigation)
header='# Requirements Traceability — continued\n\n[Introduction and earlier rows](requirements-traceability.md).\n\n'+lines[49]+lines[50]
(root/'docs/requirements-traceability-continuation.md').write_text(header+tail)
change('scripts/generate-requirement-status.mjs',"import { readRegister, requirementIds } from './lib/requirements-register.mjs';","import { readRegister, requirementIds } from './lib/requirements-register.mjs';\nimport {readTraceability} from './lib/requirements-traceability.mjs';")
change('scripts/generate-requirement-status.mjs',"const TRACEABILITY = 'docs/requirements-traceability.md';\n",'')
change('scripts/generate-requirement-status.mjs','traceRows(readOrEmpty(joinPath(root, TRACEABILITY)), root)','traceRows(readTraceability(root), root)')
change('scripts/generate-requirement-status.rs','const TRACEABILITY: &str = "docs/requirements-traceability.md";','#[path = "lib/requirements-traceability.rs"]\nmod requirements_traceability;')
change('scripts/generate-requirement-status.rs','''    let trace = trace_rows(
        &fs::read_to_string(root.join(TRACEABILITY)).unwrap_or_default(),
        root,
    );''','''    let trace = trace_rows(&requirements_traceability::read_traceability(root)?, root);''')
change('scripts/lib/requirements-head-overlay.mjs',"  'docs/requirements-traceability.md',","  'docs/requirements-traceability.md',\n  'docs/requirements-traceability-continuation.md',")
change('scripts/lib/requirement-evidence-matrix.mjs',"import fs from 'node:fs';","import fs from 'node:fs';\nimport {traceabilityPaths} from './requirements-traceability.mjs';")
change('scripts/lib/requirement-evidence-matrix.mjs',"  if(fs.existsSync(path.join(root,\n  'docs/requirements-traceability.md')))observe('docs/requirements-traceability.md');","  for(const file of traceabilityPaths(root))if(fs.existsSync(path.join(root,file)))observe(file);")
change('scripts/check-issue-citations.rs','    "docs/requirements-traceability.md",','    "docs/requirements-traceability.md",\n    "docs/requirements-traceability-continuation.md",')
change('rust/tests/support/assembled_docs.rs','use std::path::{Path, PathBuf};','''use std::path::{Path, PathBuf};

#[path = "../../../scripts/lib/requirements-traceability.rs"]
mod requirements_traceability;

/// Every indexed traceability row, preserving legacy single-file fixtures.
pub fn traceability_at<P: AsRef<Path> + ?Sized>(root: &P) -> String {
    requirements_traceability::read_traceability(root.as_ref())
        .unwrap_or_else(|error| panic!("traceability should be readable: {error}"))
}''')
for name in ['equation_corpus_ratchet','full_range_coding_artifacts','ci_template_upstream_filings','headless_client_configuration','summarization_validation']:
 p=root/('rust/tests/unit/docs_requirements/'+name+'.rs');text=p.read_text();old='read(root.join("docs/requirements-traceability.md"))';assert old in text;before=out/'before'/p.relative_to(root);before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(gzip.compress(text.encode(),mtime=0));p.write_text(text.replace(old,'crate::assembled_docs::traceability_at(&root)'))
entry=root/'rust/tests/web/issue-1580-template-observations.test.mjs';entry.write_text(entry.read_text()+"\nimport '../../../experiments/issue-1580/traceability-partition.test.mjs';\n")
print(json.dumps({'draftComplete':True,'rowsPreserved':len([line for line in lines if line.startswith('| R')]),'nativeCompilation':False,'fullIssueComplete':False}))
