from pathlib import Path
import subprocess,json,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/traceability-final-regression')
if len(sys.argv)==1:
 gates=Path('/tmp/issue-1580-research/traceability-partition-validation-corrected')
 assert (gates/'failed.txt').exists() and '140/141 passed or skipped; failed: web-ui-boundary' in (gates/'complete-javascript-gates.stdout').read_text(),'complete full gate results must be preserved before final edits'
 out.mkdir(exist_ok=False)
 p=root/'experiments/issue-1580/traceability-partition.test.mjs';s=p.read_text();s=s.replace("import test from 'node:test';","import test from 'node:test';\nimport {createHash} from 'node:crypto';")
 s=s.replace("import {requirementEvidenceMatrix}","import {requirementEvidenceMatrix,checkRequirementEvidenceMatrix}")
 old="""test('evidence inventory binds the continuation bytes',()=>{
  const matrix=requirementEvidenceMatrix(root);
  const source=JSON.stringify(matrix);
  assert.ok(source.includes(TRACEABILITY_CONTINUATION));
});"""
 new="""test('evidence inventory binds continuation bytes and rejects later drift',t=>{
  const matrix=requirementEvidenceMatrix(root);
  const bytes=readFileSync(join(root,TRACEABILITY_CONTINUATION));
  assert.deepEqual(matrix.bindings.find(binding=>binding.path===TRACEABILITY_CONTINUATION),{
    path:TRACEABILITY_CONTINUATION,status:'Bound',sha256:createHash('sha256').update(bytes).digest('hex'),bytes:bytes.length,
  });
  const directory=mkdtempSync(join(tmpdir(),'traceability-evidence-'));t.after(()=>rmSync(directory,{recursive:true,force:true}));
  mkdirSync(join(directory,'docs'));
  writeFileSync(join(directory,TRACEABILITY),'[Continued rows](requirements-traceability-continuation.md)\\n');
  writeFileSync(join(directory,TRACEABILITY_CONTINUATION),'original continuation\\n');
  const captured=requirementEvidenceMatrix(directory);
  writeFileSync(join(directory,TRACEABILITY_CONTINUATION),'changed continuation\\n');
  assert.throws(()=>checkRequirementEvidenceMatrix(captured,directory),/stale or counterfeit/u);
});"""
 assert old in s;p.write_text(s.replace(old,new))
 with (out/'worker.log').open('w') as stream:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(p.pid);sys.exit(0)
try:
 p=root/'experiments/issue-1580/application-conversation-list.test.mjs';s=p.read_text();needle="  assert.match(read(app), /} = useConversationList\\(\\{/);"
 assert needle in s
 s=s.replace(needle,needle+"\n  const inventory = JSON.parse(read(new URL('../../docs/case-studies/issue-951/function-inventory.json', import.meta.url)));\n  assert.equal(inventory.ui_jsx_character_ceiling, 306259);\n  assert.deepEqual(inventory.legacy_functions['js/app/application-conversation-hooks.jsx'], ['useConversationList', 'useConversationMessages', 'useInterfaceCommands']);")
 p.write_text(s)
 file='experiments/issue-1580/application-conversation-list.test.mjs'
 with (out/'boundary-registration-before.stdout').open('w') as stdout,(out/'boundary-registration-before.stderr').open('w') as stderr:r=subprocess.run(['node','--max-old-space-size=256','--test','--test-concurrency=1',file],cwd=root,stdout=stdout,stderr=stderr)
 assert r.returncode==1,'new registration regression must fail before correction'
 p=root/'docs/case-studies/issue-951/function-inventory.json';s=p.read_text();needle='"js/app/application-conversation-hooks.jsx": [\n      "useConversationMessages",';assert needle in s;p.write_text(s.replace(needle,'"js/app/application-conversation-hooks.jsx": [\n      "useConversationList",\n      "useConversationMessages",'))
 for name,args in [('boundary-registration-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',file]),('web-ui-boundary',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','web-ui-boundary'])]:
  with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
  print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==0
 for name,file in [('partition','experiments/issue-1580/traceability-partition.test.mjs'),('maintained-entry','rust/tests/web/issue-1580-template-observations.test.mjs')]:
  with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',file],cwd=root,stdout=stdout,stderr=stderr)
  print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==0
 (out/'outcome.json').write_text(json.dumps({'allPassed':True,'nativeCompilation':False,'fullIssueComplete':False,'independentAuthorshipCredit':0})+'\n')
except BaseException:traceback.print_exc();sys.exit(1)
