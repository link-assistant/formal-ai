from pathlib import Path
import subprocess,json,gzip,hashlib,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'traceability-partition-preservation-final'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==0,(name,r.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 target=root/'experiments/issue-1580/evidence/checks/traceability-source-partition';index=target/'records.jsonl';records=[json.loads(s) for s in index.read_text().splitlines()]
 renamed=[]
 for row in records:
  if row['path'].endswith('/assembled_docs.rs.gz'):
   previous=row['path'];replacement=previous.replace('/assembled_docs.rs.gz','/assembled-documents.rs.gz');(target/previous).rename(target/replacement)
   row['path']=replacement;row['originalTransportPath']=previous;renamed.append(replacement)
 assert len(renamed)==2,renamed
 def archive(raw,name):
  packed=gzip.compress(raw,mtime=0);dest=target/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed)
  records.append({'path':str(dest.relative_to(target)),'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
 for p in sorted((scratch/'traceability-partition-preservation').iterdir()):
  if p.is_file():archive(p.read_bytes(),'failed-preservation-attempt/'+p.name)
 for name in ['traceability-abbreviation-list-driver.log','read-traceability-abbreviation-failure-driver.log',Path(__file__).name]:archive((scratch/name).read_bytes(),'review-attempts/'+name)
 index.write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
 for row in records:
  packed=(target/row['path']).read_bytes();raw=gzip.decompress(packed);assert len(raw)==row['rawBytes'];assert hashlib.sha256(raw).hexdigest()==row['rawSha256'];assert hashlib.sha256(packed).hexdigest()==row['archiveSha256']
 doc=root/'docs/case-studies/issue-1580/traceability-source-partition.md';s=doc.read_text();s=s.replace('Nine size warnings on retained source captures remain under unchanged limits.','The first preservation gate also rejected two newly copied abbreviated evidence\nfilenames. Their archive transport names now spell out documents, preserving\nevery raw byte and recording the former names; no abbreviation baseline changed.\nThe failed preservation attempt is retained.\n\nNine size warnings on retained source captures remain under unchanged limits.');doc.write_text(s)
 assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
 run('documentation-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-changelog-fragment-js-twin,check-reconstructed-changelog,check-file-size'])
 paths=run('tracked-changes',['git','diff','--name-only']).splitlines()
 paths+=['docs/requirements-traceability-continuation.md','scripts/lib/requirements-traceability.mjs','scripts/lib/requirements-traceability.rs','experiments/issue-1580/traceability-partition.test.mjs','experiments/issue-1580/fixtures/traceability-partition',str(target.relative_to(root)),str(doc.relative_to(root)),'changelog.d/20261121_1580_traceability_source_partition.md']
 assert not any('/proposals/' in p or '/seed-readers-9e945eae/' in p for p in paths)
 run('stage',['git','add','--',*paths]);run('staged-whitespace',['git','diff','--cached','--check']);run('commit',['git','commit','-m','Preserve every traceability row across indexed source pages'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'head':run('head',['git','rev-parse','HEAD']).strip(),'pushed':False,'rowsPreserved':1429,'maintainedCasesPassed':313,'nativeCompilation':False,'fullIssueComplete':False,'independentAuthorshipCredit':0,'renamedArchiveTransports':renamed},indent=2)+'\n')
except BaseException:traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
