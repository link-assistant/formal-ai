#!/usr/bin/env bash
set -euo pipefail
# Output records are one line. Refuse malformed input before Docker IO.
if [[ -z "${BUILDKIT_IMAGE}" || "${BUILDKIT_IMAGE}${REGISTRY_MIRROR}" == *$'\n'* || "${BUILDKIT_IMAGE}${REGISTRY_MIRROR}" == *$'\r'* ]]; then
  echo 'BuildKit image must be nonempty; image and mirror must be single-line references.' >&2
  exit 1
fi
printf 'canonical=%s\n' "$BUILDKIT_IMAGE" >> "$GITHUB_OUTPUT"
if [ -n "$REGISTRY_MIRROR" ]; then
  printf 'mirror=%s/%s\n' "$REGISTRY_MIRROR" "$BUILDKIT_IMAGE" >> "$GITHUB_OUTPUT"
fi
