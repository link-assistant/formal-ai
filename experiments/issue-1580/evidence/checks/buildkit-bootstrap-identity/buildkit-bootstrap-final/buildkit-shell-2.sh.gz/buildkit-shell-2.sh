#!/usr/bin/env bash
set -euo pipefail
if [ "$VERBOSE" = true ] || [ "${RUNNER_DEBUG:-}" = 1 ]; then
  set -x
fi
if [ -z "$REGISTRY_MIRROR" ]; then
  echo '::error::Canonical BuildKit setup failed and registry mirror is disabled'
  exit 1
fi
echo "Canonical setup failed; retrying actual Buildx setup with $MIRROR_IMAGE"
