from pathlib import Path
root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
source = scratch / 'buildkit-bootstrap-probe.py.draft'
target = root / 'experiments/issue-1580/buildkit-bootstrap-probe.py'
target.write_bytes(source.read_bytes())
workflow = root / '.github/workflows/workflows.yml'
original = workflow.read_text()
assert '\n  buildkit-bootstrap:' not in original
addition = (scratch / 'buildkit-bootstrap-job.yml.draft').read_text().replace('@{{', '$' + '{{')
workflow.write_text(original.rstrip() + '\n' + addition)
print('Drafted a read-only hosted real-daemon probe; its local self-test starts no Docker or image downloads.')
