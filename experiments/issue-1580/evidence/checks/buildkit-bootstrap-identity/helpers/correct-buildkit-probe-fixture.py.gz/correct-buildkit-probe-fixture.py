from pathlib import Path
import gzip
base=Path('/tmp/issue-1580-research/buildkit-immutable-identity')
for name in ('regression-before.stdout','regression-before.stderr'):
    path=base/name
    (base/(name+'.initial-fixture.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
path=Path('experiments/issue-1580/buildkit-image-identity.test.mjs')
source=path.read_text()
(base/'regression-initial-fixture.mjs.gz').write_bytes(gzip.compress(source.encode(),mtime=0))
backslash=chr(92)
old="JSON.stringify(args)+'"+backslash+"n');"
new="JSON.stringify(args)+'"+backslash+backslash+"n');"
assert source.count(old)==1
path.write_text(source.replace(old,new))
helper=Path('/tmp/issue-1580-research/repair-buildkit-identity.py')
source=helper.read_text()
source='\n'.join(line for line in source.splitlines() if not line.startswith('test_source=') and not line.startswith('test_file.write_text('))+'\n'
source=source.replace("'--test','--test-concurrency=1'", "'--test','--test-reporter=tap','--test-concurrency=1'")
helper.write_text(source)
print('Preserved the initial probe failure; corrected only the mock log newline and pinned TAP reporting.')
