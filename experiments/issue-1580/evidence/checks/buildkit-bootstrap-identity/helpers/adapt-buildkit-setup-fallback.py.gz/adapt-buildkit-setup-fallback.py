from pathlib import Path
import gzip, json

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/buildkit-bootstrap-adaptation')
base.mkdir(exist_ok=False)
for name in ['.github/actions/setup-buildx-resilient/action.yml', 'experiments/issue-1580/buildkit-image-identity.test.mjs']:
    (base / (Path(name).name + '.earlier-draft.gz')).write_bytes(gzip.compress((root / name).read_bytes(), mtime=0))
image = json.loads(Path('/tmp/issue-1580-research/buildkit-immutable-identity/resolution.json').read_text())['reference']
action = '''name: 'Set up Docker Buildx (resilient)'
description: >
  Set up the Docker container builder with upstream bounded pull retries,
  then retry actual setup against an independent registry mirror on failure.
  Adapted from link-foundation/rust-ai-driven-development-pipeline-template:
  locally seeding or retagging an image cannot bypass setup-buildx's own pull.
inputs:
  buildkit-image:
    description: 'BuildKit image; the default is an immutable multi-platform index.'
    required: false
    # buildx-stable-1 resolved from Docker Hub on 2026-11-20; retains all native architectures.
    default: '__IMAGE__'
  registry-mirror:
    description: 'Docker Hub pull-through mirror host; empty disables fallback.'
    required: false
    default: 'mirror.gcr.io'
  verbose:
    description: 'Enable shell diagnostics; RUNNER_DEBUG also enables tracing.'
    required: false
    default: 'false'
  cleanup:
    description: 'Remove builders after the job; disable only on disposable hosted runners.'
    required: false
    default: 'true'
outputs:
  image:
    description: 'Exact canonical or mirror image used by successful setup.'
    value: ${{ steps.mirror.outcome == 'success' && steps.references.outputs.mirror || steps.references.outputs.canonical }}
  name:
    description: 'Name of the successfully initialized builder.'
    value: ${{ steps.mirror.outcome == 'success' && steps.mirror.outputs.name || steps.canonical.outputs.name }}
runs:
  using: 'composite'
  steps:
    - name: Validate BuildKit image references
      id: references
      shell: bash
      env:
        BUILDKIT_IMAGE: ${{ inputs.buildkit-image }}
        REGISTRY_MIRROR: ${{ inputs.registry-mirror }}
      run: |
        set -euo pipefail
        # Output records are one line. Refuse malformed input before Docker IO.
        if [[ -z "${BUILDKIT_IMAGE}" || "${BUILDKIT_IMAGE}${REGISTRY_MIRROR}" == *$'\\n'* || "${BUILDKIT_IMAGE}${REGISTRY_MIRROR}" == *$'\\r'* ]]; then
          echo 'BuildKit image must be nonempty; image and mirror must be single-line references.' >&2
          exit 1
        fi
        printf 'canonical=%s\\n' "$BUILDKIT_IMAGE" >> "$GITHUB_OUTPUT"
        if [ -n "$REGISTRY_MIRROR" ]; then
          printf 'mirror=%s/%s\\n' "$REGISTRY_MIRROR" "$BUILDKIT_IMAGE" >> "$GITHUB_OUTPUT"
        fi

    # The official action owns bounded pull retries, including its unconditional
    # pre-pull. Retry that actual action, rather than an earlier cache seed.
    - name: Set up Docker Buildx from canonical registry
      id: canonical
      continue-on-error: true
      uses: docker/setup-buildx-action@v4
      with:
        driver-opts: image=${{ steps.references.outputs.canonical }}
        cleanup: ${{ inputs.cleanup }}

    - name: Report registry fallback
      if: steps.canonical.outcome == 'failure'
      shell: bash
      env:
        REGISTRY_MIRROR: ${{ inputs.registry-mirror }}
        MIRROR_IMAGE: ${{ steps.references.outputs.mirror }}
        VERBOSE: ${{ inputs.verbose }}
      run: |
        set -euo pipefail
        if [ "$VERBOSE" = true ] || [ "${RUNNER_DEBUG:-}" = 1 ]; then
          set -x
        fi
        if [ -z "$REGISTRY_MIRROR" ]; then
          echo '::error::Canonical BuildKit setup failed and registry mirror is disabled'
          exit 1
        fi
        echo "Canonical setup failed; retrying actual Buildx setup with $MIRROR_IMAGE"

    - name: Set up Docker Buildx from registry mirror
      id: mirror
      if: steps.canonical.outcome == 'failure' && inputs.registry-mirror != ''
      uses: docker/setup-buildx-action@v4
      with:
        driver-opts: image=${{ steps.references.outputs.mirror }}
        cleanup: ${{ inputs.cleanup }}
'''.replace('__IMAGE__', image)
(root / '.github/actions/setup-buildx-resilient/action.yml').write_text(action)
print('Adapted actual setup fallback, preserving explicit caller references, disabled mirrors, verbose diagnostics and default cleanup.')
