from pathlib import Path
import gzip,json,subprocess,os
root=Path('/tmp/gh-issue-solver-1794900398048')
base=Path('/tmp/issue-1580-research/buildkit-immutable-identity')
test_file=root/'experiments/issue-1580/buildkit-image-identity.test.mjs'
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
argv=['timeout','600','node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',str(test_file.relative_to(root))]
with (base/'regression-before.stdout').open('wb') as out,(base/'regression-before.stderr').open('wb') as err:
    result=subprocess.run(argv,cwd=root,env=env,stdout=out,stderr=err)
assert result.returncode==1
before=(base/'regression-before.stdout').read_text()
assert 'buildx-stable-1' in before and 'not ok' in before
print('Current mutable default and missing selected-image custody fail the five new controls.',flush=True)
resolution=json.loads((base/'resolution.json').read_text())
image=resolution['reference']
action=root/'.github/actions/setup-buildx-resilient/action.yml'
original=action.read_text()
(base/'action-before.yml.gz').write_bytes(gzip.compress(original.encode(),mtime=0))
source=original.replace('(mirror.gcr.io by default) before re-tagging the image to its canonical\n  reference.',
    '(mirror.gcr.io by default) and supplies that exact reference to Buildx.')
source=source.replace('  Adopted verbatim from\n','  Adapted from\n')
source=source.replace("    default: 'moby/buildkit:buildx-stable-1'", "    # buildx-stable-1 resolved from Docker Hub on 2026-11-20; index retains all native architectures.\n    default: '"+image+"'")
source=source.replace('runs:\n',"outputs:\n  image:\n    description: 'Actual canonical or mirror reference selected for the BuildKit daemon.'\n    value: ${{ steps.pull.outputs.image }}\nruns:\n",1)
source=source.replace('    - name: Pre-pull BuildKit image (retry + registry-mirror fallback)\n',
    '    - name: Pre-pull BuildKit image (retry + registry-mirror fallback)\n      id: pull\n',1)
source=source.replace('        set -u\n','''        set -u
        # Output records are one line; reject malformed caller references before IO.
        if [[ -z "${BUILDKIT_IMAGE}" || "${BUILDKIT_IMAGE}${REGISTRY_MIRROR}" == *$'\\n'* || "${BUILDKIT_IMAGE}${REGISTRY_MIRROR}" == *$'\\r'* ]]; then
          echo 'BuildKit image and registry mirror must be nonempty-image, single-line references.' >&2
          exit 1
        fi
''',1)
source=source.replace('          echo "==> BuildKit image cached locally from canonical registry; boot will not need a registry pull"\n',
    '          printf \'image=%s\\n\' "${BUILDKIT_IMAGE}" >> "$GITHUB_OUTPUT"\n          echo "==> BuildKit image cached locally from canonical registry"\n',1)
old='''        #    it usually still serves the image. We pull from there and re-tag to
        #    the canonical reference so the docker-container driver boot finds it
        #    locally and never touches the failing registry.
'''
new='''        #    it usually still serves the image. Pass the successful mirror
        #    reference directly to Buildx: Docker cannot create a digest alias
        #    with `docker tag`, and a mirror RepoDigest is not a canonical one.
        #    The unchanged @sha256 suffix preserves exact image content.
'''
assert source.count(old)==1
source=source.replace(old,new)
source=source.replace('            docker tag "${mirror_ref}" "${BUILDKIT_IMAGE}"\n            echo "==> BuildKit image cached locally via mirror and tagged as ${BUILDKIT_IMAGE}; boot will reuse it"\n',
    '            printf \'image=%s\\n\' "${mirror_ref}" >> "$GITHUB_OUTPUT"\n            echo "==> BuildKit image cached locally via mirror as ${mirror_ref}"\n',1)
source=source.replace('        echo "==> WARNING: could not pre-pull',
    '        printf \'image=%s\\n\' "${BUILDKIT_IMAGE}" >> "$GITHUB_OUTPUT"\n        echo "==> WARNING: could not pre-pull',1)
source=source.replace('driver-opts: image=${{ inputs.buildkit-image }}','driver-opts: image=${{ steps.pull.outputs.image }}',1)
assert source!=original and 'docker tag "${mirror_ref}"' not in source
action.write_text(source)
workflow=root/'.github/workflows/container-images.yml'
original_workflow=workflow.read_text()
(base/'container-workflow-before.yml.gz').write_bytes(gzip.compress(original_workflow.encode(),mtime=0))
old='    - uses: docker/setup-buildx-action@v4\n      with: {cleanup: false}'
assert original_workflow.count(old)==4
new='    - uses: docker/setup-buildx-action@v4\n      with:\n        cleanup: false\n        driver-opts: image='+image
workflow.write_text(original_workflow.replace(old,new))
with (base/'regression-after.stdout').open('wb') as out,(base/'regression-after.stderr').open('wb') as err:
    result=subprocess.run(argv,cwd=root,env=env,stdout=out,stderr=err)
assert result.returncode==0
print('All five bounded controls pass after preserving exact digest identity through canonical, mirror and boot paths.')
