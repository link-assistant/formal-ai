from pathlib import Path
import base64, gzip, hashlib, json, subprocess, urllib.request, urllib.error

base = Path('/tmp/issue-1580-research/buildkit-bootstrap-sources')
base.mkdir(exist_ok=False)
def request(name, argv):
    result = subprocess.run(argv, capture_output=True)
    (base / (name + '.stdout')).write_bytes(result.stdout)
    (base / (name + '.stderr')).write_bytes(result.stderr)
    (base / (name + '.result.json')).write_text(json.dumps({'argv': argv, 'exitCode': result.returncode}) + '\n')
    assert result.returncode == 0, name
    return json.loads(result.stdout)
current = request('rust-template-head', ['gh', 'api', 'repos/link-foundation/rust-ai-driven-development-pipeline-template/commits/main'])
sha = current['sha']
action = request('rust-template-action', ['gh', 'api', 'repos/link-foundation/rust-ai-driven-development-pipeline-template/contents/.github/actions/setup-buildx-resilient/action.yml?ref=' + sha])
(base / 'rust-template-action.yml').write_bytes(base64.b64decode(action['content']))
for path in ['src/main.ts', 'action.yml', 'package.json']:
    data = request('docker-buildx-' + path.replace('/', '_'), ['gh', 'api', 'repos/docker/setup-buildx-action/contents/' + path + '?ref=v4'])
    (base / ('docker-buildx-' + path.replace('/', '_') + '.decoded')).write_bytes(base64.b64decode(data['content']))
digest = json.loads(Path('/tmp/issue-1580-research/buildkit-immutable-identity/resolution.json').read_text())['reference'].split('@', 1)[1]
url = 'https://mirror.gcr.io/v2/moby/buildkit/manifests/' + digest
headers = {'Accept': 'application/vnd.oci.image.index.v1+json, application/vnd.docker.distribution.manifest.list.v2+json'}
try:
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers)) as response:
        raw = response.read(1048577)
        assert len(raw) <= 1048576
        (base / 'mirror-index.json').write_bytes(raw)
        record = {'url': url, 'status': response.status, 'headers': dict(response.headers), 'sha256': hashlib.sha256(raw).hexdigest()}
        assert record['sha256'] == digest.split(':', 1)[1]
except urllib.error.HTTPError as error:
    record = {'url': url, 'status': error.code, 'headers': dict(error.headers), 'error': str(error)}
(base / 'mirror-resolution.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'currentRustTemplateHead': sha, 'mirrorStatus': record['status'], 'downloadedImageLayers': 0}))
