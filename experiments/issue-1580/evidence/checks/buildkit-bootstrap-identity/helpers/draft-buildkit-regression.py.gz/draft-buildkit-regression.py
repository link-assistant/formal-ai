from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
target=root/'experiments/issue-1580/buildkit-image-identity.test.mjs'
assert not target.exists()
target.write_text(r'''import assert from 'node:assert/strict';
import {mkdtempSync, readFileSync, writeFileSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import test from 'node:test';
import YAML from 'yaml';
import {boundedCommand} from '../../js/server/bounded-command.mjs';

const actionPath='.github/actions/setup-buildx-resilient/action.yml';
const action=()=>YAML.parse(readFileSync(actionPath,'utf8'));
const immutable=/^moby\/buildkit@sha256:[a-f0-9]{64}$/u;
const defaultImage=()=>action().inputs['buildkit-image'].default;
async function execute(t,{image=defaultImage(),mode='canonical',mirror='mirror.gcr.io'}={}) {
  const directory=mkdtempSync(join(tmpdir(),'formal-ai-buildkit-'));
  t.after(()=>rmSync(directory,{recursive:true,force:true}));
  const trace=join(directory,'docker.jsonl'),output=join(directory,'output');
  writeFileSync(output,'');
  writeFileSync(join(directory,'docker'),`#!/usr/bin/env node
import('node:fs').then(fs=>{
 const args=process.argv.slice(2);
 fs.appendFileSync(process.env.MOCK_TRACE,JSON.stringify(args)+'\\n');
 if(args[0]==='pull') {
  const canonical=!args[1].startsWith('mirror.gcr.io/');
  process.exit(process.env.MOCK_MODE==='canonical'&&canonical||process.env.MOCK_MODE==='mirror'&&!canonical?0:1);
 }
 if(args[0]==='tag'&&args[2].includes('@'))process.exit(1);
 process.exit(2);
});
`,{mode:0o755});
  const step=action().runs.steps.find(row=>row.name.startsWith('Pre-pull BuildKit'));
  const result=await boundedCommand('bash',['-c',step.run],{
    cwd:process.cwd(),timeout:10000,maxBuffer:128*1024,
    env:{...process.env,PATH:directory+':'+process.env.PATH,BUILDKIT_IMAGE:image,
      REGISTRY_MIRROR:mirror,VERBOSE:'false',RUNNER_DEBUG:'0',PREPULL_ATTEMPTS:'2',
      PREPULL_DELAY:'0',GITHUB_OUTPUT:output,MOCK_TRACE:trace,MOCK_MODE:mode},
  });
  assert.equal(result.error,undefined,result.stderr?.toString());
  assert.equal(result.status,0,result.stderr?.toString());
  assert.equal(result.cleanup_complete,true);
  const calls=readFileSync(trace,'utf8').trim().split('\n').map(line=>JSON.parse(line));
  const outputs=Object.fromEntries(readFileSync(output,'utf8').trim().split('\n').filter(Boolean)
    .map(line=>{const at=line.indexOf('=');return [line.slice(0,at),line.slice(at+1)];}));
  return {calls,outputs,stdout:result.stdout.toString()};
}

test('every current BuildKit bootstrap selects the same immutable multi-platform image',()=>{
  const document=action(),image=defaultImage();assert.match(image,immutable);
  const setup=document.runs.steps.find(row=>row.uses==='docker/setup-buildx-action@v4');
  assert.equal(setup.with['driver-opts'],'image=${{ steps.pull.outputs.image }}');
  assert.equal(document.runs.steps.find(row=>row.id==='pull').name.startsWith('Pre-pull BuildKit'),true);
  assert.equal(document.outputs.image.value,'${{ steps.pull.outputs.image }}');
  const workflow=YAML.parse(readFileSync('.github/workflows/container-images.yml','utf8'));
  const direct=Object.values(workflow.jobs).flatMap(job=>job.steps??[])
    .filter(step=>step.uses==='docker/setup-buildx-action@v4');
  assert.equal(direct.length,4);
  for(const step of direct){assert.equal(step.with['driver-opts'],'image='+image);assert.equal(step.with.cleanup,false);}
});
test('canonical success uses the exact digest and stops after one pull',async t=>{
  const image=defaultImage(),result=await execute(t);
  assert.deepEqual(result.calls,[['pull',image]]);assert.equal(result.outputs.image,image);
});
test('mirror success preserves the digest and supplies the mirror identity directly to Buildx',async t=>{
  const image=defaultImage(),result=await execute(t,{mode:'mirror'});
  assert.deepEqual(result.calls,[['pull',image],['pull',image],['pull','mirror.gcr.io/'+image]]);
  assert.equal(result.outputs.image,'mirror.gcr.io/'+image);
  assert.match(result.outputs.image,/@sha256:[a-f0-9]{64}$/u);
  assert.equal(result.calls.some(args=>args[0]==='tag'),false);
});
test('exhausted pulls retain the exact canonical identity for the inherited boot attempt',async t=>{
  const image=defaultImage(),result=await execute(t,{mode:'failed'});
  assert.deepEqual(result.calls,[['pull',image],['pull',image],['pull','mirror.gcr.io/'+image],['pull','mirror.gcr.io/'+image]]);
  assert.equal(result.outputs.image,image);assert.match(result.stdout,/letting setup-buildx try its own boot pull/u);
});
test('disabled mirror never adds a fallback and explicit caller references remain supported',async t=>{
  const image='moby/buildkit:v0.27.0';
  const failed=await execute(t,{image,mode:'failed',mirror:''});
  assert.deepEqual(failed.calls,[['pull',image],['pull',image]]);assert.equal(failed.outputs.image,image);
  const success=await execute(t,{image});assert.deepEqual(success.calls,[['pull',image]]);
});
''')
entry=root/'rust/tests/web/bounded-subprocess-boundaries.test.mjs'
source=entry.read_text()
entry.write_text("import '../../../experiments/issue-1580/buildkit-image-identity.test.mjs';\n"+source)
print('Drafted five bounded controls and registered the existing hosted entry point.')
