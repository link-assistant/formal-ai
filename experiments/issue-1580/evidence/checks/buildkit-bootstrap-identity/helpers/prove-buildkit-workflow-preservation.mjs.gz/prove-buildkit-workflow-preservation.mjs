import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import YAML from '/tmp/gh-issue-solver-1794900398048/node_modules/yaml/dist/index.js';
const base='/tmp/issue-1580-research/buildkit-bootstrap-final/';
const digest=value=>createHash('sha256').update(value).digest('hex');
const paths=['.github/workflows/container-images.yml','.github/workflows/workflows.yml'];
const proofs=[];
for(const path of paths){
 const original=execFileSync('git',['show','HEAD:'+path],{encoding:'utf8',maxBuffer:8*1024*1024});
 const current=readFileSync(path,'utf8');
 const before=YAML.parse(original),after=YAML.parse(current);
 const changes=[];
 if(path.endsWith('/container-images.yml')){
  const image=YAML.parse(readFileSync('.github/actions/setup-buildx-resilient/action.yml','utf8')).inputs['buildkit-image'].default;
  for(const [id,job]of Object.entries(after.jobs))for(const step of job.steps??[]){
   if(step.uses!=='docker/setup-buildx-action@v4')continue;
   assert.equal(step.with['driver-opts'],'image='+image);
   assert.equal(step.with.cleanup,false);delete step.with['driver-opts'];changes.push(id);
  }
  assert.equal(changes.length,4);
 }else{
  assert.ok(after.jobs['buildkit-bootstrap']);delete after.jobs['buildkit-bootstrap'];
  for(const event of ['push','pull_request']){
   const paths=after.on[event].paths;
   assert.equal(paths.filter(path=>path==='experiments/issue-1580/buildkit-bootstrap-probe.py').length,1);
   after.on[event].paths=paths.filter(path=>path!=='experiments/issue-1580/buildkit-bootstrap-probe.py');
  }
  changes.push('new read-only BuildKit job','matching probe source triggers');
 }
 assert.deepEqual(after,before);
 proofs.push({path,originalSha256:digest(original),currentSha256:digest(current),completeSemanticInverse:true,changes});
}
const action=YAML.parse(readFileSync('.github/actions/setup-buildx-resilient/action.yml','utf8'));
const originalAction=YAML.parse(execFileSync('git',['show','HEAD:.github/actions/setup-buildx-resilient/action.yml'],{encoding:'utf8'}));
assert.deepEqual(Object.keys(originalAction.inputs).sort(),['buildkit-image','registry-mirror','verbose']);
for(const name of ['registry-mirror','verbose'])for(const field of ['required','default'])
 assert.equal(action.inputs[name][field],originalAction.inputs[name][field]);
assert.equal(action.inputs.cleanup.default,'true');
writeFileSync(base+'whole-workflow-preservation.json',JSON.stringify({proofs,inputCompatibilityVerified:true,independentAuthorshipCredit:0},null,2)+'\n');
for(const [index,step]of action.runs.steps.entries())if(step.run)
 writeFileSync(base+'buildkit-shell-'+index+'.sh','#!/usr/bin/env bash\n'+step.run);
console.log('Both complete workflow payloads restore exactly after reversing only the intended changes; existing inputs retain their defaults.');
