from pathlib import Path
root = Path('/tmp/gh-issue-solver-1794900398048')
path = root / '.github/workflows/workflows.yml'
source = path.read_text()
needle = "'experiments/issue-1580/artifact-transport-roundtrip.py']"
assert source.count(needle) == 2
path.write_text(source.replace(needle, "'experiments/issue-1580/artifact-transport-roundtrip.py', 'experiments/issue-1580/buildkit-bootstrap-probe.py']"))
path = root / 'experiments/issue-1580/buildkit-image-identity.test.mjs'
source = path.read_text()
addition = r'''
test('hosted real-daemon probe retains read-only authority and immutable image observations',()=>{
  const workflow=YAML.parse(readFileSync('.github/workflows/workflows.yml','utf8'));
  assert.equal(workflow.permissions.contents,'read');
  for(const event of ['push','pull_request'])assert(workflow.on[event].paths.includes('experiments/issue-1580/buildkit-bootstrap-probe.py'));
  const job=workflow.jobs['buildkit-bootstrap'];
  assert.equal(job['runs-on'],'ubuntu-24.04');assert.equal(job['timeout-minutes'],12);
  const checkout=job.steps[0];assert.equal(checkout.with['persist-credentials'],false);
  for(const path of ['/.github/actions/setup-buildx-resilient/','/experiments/issue-1580/buildkit-bootstrap-probe.py'])
    assert(checkout.with['sparse-checkout'].split('\n').includes(path));
  const setups=job.steps.filter(step=>step.uses==='./.github/actions/setup-buildx-resilient');
  assert.deepEqual(setups.map(step=>step.id),['initial','fallback']);
  for(const step of setups){assert.equal(step.with.cleanup,'false');assert.equal(step['timeout-minutes'],4);}
  const faultIndex=job.steps.findIndex(step=>step.run?.includes(' install-fault '));
  assert(faultIndex>job.steps.findIndex(step=>step.run?.includes(' initial ')));
  assert(faultIndex<job.steps.findIndex(step=>step.id==='fallback'));
  const verification=job.steps.find(step=>step.run?.includes(' mirror '));
  assert.equal(verification.env.IMAGE,'@{{ steps.fallback.outputs.image }}');
  assert.equal(verification.env.BUILDER,'@{{ steps.fallback.outputs.name }}');
  const upload=job.steps.at(-1);assert.equal(upload.uses,'actions/upload-artifact@v7');
  assert.equal(upload.if,'always()');assert.equal(upload.with['if-no-files-found'],'error');
});
test('hosted outage injector delegates every unrelated Docker command unchanged',async()=>{
  const result=await boundedCommand('python3',['experiments/issue-1580/buildkit-bootstrap-probe.py','self-test'],{
    cwd:process.cwd(),timeout:10000,maxBuffer:128*1024,env:{...process.env,PYTHONDONTWRITEBYTECODE:'1'},
  });
  assert.equal(result.error,undefined,result.stderr?.toString());assert.equal(result.status,0,result.stderr?.toString());
  assert.equal(result.cleanup_complete,true);assert.match(result.stdout.toString(),/rejects only the exact canonical pull/u);
});
'''.replace('@{{', '$' + '{{')
assert 'hosted real-daemon probe retains' not in source
path.write_text(source + addition)
print('Registered ten adapter/injector groups in the existing hosted subprocess entrypoint and retained probe-change triggers.')
