from pathlib import Path
import ast, gzip, json, os, resource, subprocess, sys, time
root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/buildkit-bootstrap-final')
if len(sys.argv) == 1:
    base.mkdir(exist_ok=False)
    with (base/'worker.log').open('wb') as stream:
        child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({'pid':child.pid,'directory':str(base)}))
    sys.exit(0)
env=dict(os.environ)
env.pop('NODE_OPTIONS',None)
rows=[]
def check(name,argv,expected=0,extra_env=None,input_bytes=None):
    started=time.monotonic()
    with (base/(name+'.stdout')).open('wb') as out,(base/(name+'.stderr')).open('wb') as err:
        result=subprocess.run(argv,cwd=root,env={**env,**(extra_env or {})},input=input_bytes,stdout=out,stderr=err)
    rows.append({'name':name,'argv':argv,'exitCode':result.returncode,'expectedExitCode':expected,'seconds':round(time.monotonic()-started,3)})
    (base/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    assert result.returncode==expected,name
test='experiments/issue-1580/buildkit-image-identity.test.mjs'
earlier=base/'cache-only-draft.yml'
earlier.write_bytes(gzip.decompress(Path('/tmp/issue-1580-research/buildkit-bootstrap-adaptation/action.yml.earlier-draft.gz').read_bytes()))
check('cache-only-setup-regression-before',['timeout','600','node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',
    '--test-name-pattern=canonical setup failure retries actual setup',test],1,{'FORMAL_AI_BUILDKIT_ACTION':str(earlier)})
assert 'validate before Docker IO' in (base/'cache-only-setup-regression-before.stdout').read_text()
ast.parse((root/'experiments/issue-1580/buildkit-bootstrap-probe.py').read_text())
for name,path in [
    ('buildkit-identity',test),
    ('subprocess-boundaries','rust/tests/web/bounded-subprocess-boundaries.test.mjs'),
    ('container-workflow','rust/tests/web/container-images-workflow.test.mjs'),
    ('registry-transport','rust/tests/web/container-registry-transport.test.mjs'),
    ('container-step-boundary','rust/tests/web/container-authority-step-boundary.test.mjs'),
    ('production-profile','rust/tests/web/fast-pull-request-production-profile.test.mjs'),
    ('default-branch-policy','rust/tests/web/default-branch-build-policy.test.mjs'),
]:
    check(name,['timeout','600','node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',path])
check('whitespace',['git','diff','--check'])
(base/'outcome.json').write_text(json.dumps({'complete':True,'results':rows,
    'childrenPeakRssKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
    'actualDockerBootVerified':False,'localRustExecution':False,'localImageLayerDownloads':0,
    'independentAuthorshipCredit':0},indent=2)+'\n')
