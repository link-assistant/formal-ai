from pathlib import Path
import gzip,hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
base=root/'experiments/issue-1580/evidence/checks/buildkit-bootstrap-identity';base.mkdir(exist_ok=False)
final=json.loads((scratch/'buildkit-bootstrap-final/outcome.json').read_text());assert final['complete']
assert json.loads((scratch/'buildkit-bootstrap-final/remaining-gates.json').read_text())['exitCode']==0
proof=json.loads((scratch/'buildkit-bootstrap-final/whole-workflow-preservation.json').read_text());assert all(r['completeSemanticInverse'] for r in proof['proofs'])
sources=[]
for folder in ['buildkit-immutable-identity','buildkit-bootstrap-sources','buildkit-bootstrap-adaptation','buildkit-identity-final','buildkit-identity-final-corrected','buildkit-bootstrap-final']:
 for path in sorted((scratch/folder).rglob('*')):
  if path.is_file():sources.append((folder+'/'+str(path.relative_to(scratch/folder)),path))
for name in ['resolve-buildkit-manifest','draft-buildkit-regression','repair-buildkit-identity','correct-buildkit-probe-fixture',
 'extend-buildkit-negative-controls','validate-buildkit-identity','review-buildx-bootstrap-sources','adapt-buildkit-setup-fallback',
 'draft-buildkit-setup-regressions','draft-buildkit-hosted-probe','finish-buildkit-probe-regressions','validate-buildkit-bootstrap',
 'prove-buildkit-workflow-preservation','check-buildkit-workflow-gates','continue-buildkit-gates']:
 for suffix in ['.py','.mjs','.log','-corrected.log']:
  path=scratch/(name+suffix)
  if path.is_file():sources.append(('helpers/'+path.name,path))
for name in ['.github/actions/setup-buildx-resilient/action.yml','.github/workflows/container-images.yml','.github/workflows/workflows.yml',
 'experiments/issue-1580/buildkit-bootstrap-probe.py','experiments/issue-1580/buildkit-image-identity.test.mjs']:
 sources.append(('reviewed-source/'+name,root/name))
sources.append(('helpers/'+Path(__file__).name,Path(__file__)))
records=[]
for relative,path in sources:
 original=path.read_bytes();raw=gzip.decompress(original) if path.suffix=='.gz' else original
 packed=original if path.suffix=='.gz' else gzip.compress(raw,mtime=0)
 name=relative if relative.endswith('.gz') else relative+'.gz';target=base/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(packed)
 assert gzip.decompress(target.read_bytes())==raw
 records.append({'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
(base/'records.json').write_text(json.dumps(records,indent=2)+'\n')
(root/'docs/case-studies/issue-1580/buildkit-bootstrap-identity-checkpoint.md').write_text('''# Immutable BuildKit setup and actual mirror recovery

Pull request: https://github.com/link-assistant/formal-ai/pull/1581

The resilient setup wrapper called `moby/buildkit:buildx-stable-1` pinned, but
that tag can move. Four direct setup calls also allowed an implicit mutable
BuildKit default. Docker Hub and mirror.gcr.io independently returned the same
5,296-byte multi-platform index on 20 November 2026. Its SHA-256 equals both
registry response identities:

`baf6138eb8c37644800c7c913fba051e840ebb9ba13eaf92d92ef9a1712d0b4c`

The wrapper default and all four direct callers now select that immutable index.
It retains Linux amd64, arm, arm64, ppc64le, riscv64 and s390x. No image layer is
downloaded locally. Caller-selected images remain supported, direct callers keep
cleanup disabled, and the wrapper keeps cleanup enabled by default.

The earlier mirror pre-pull/retag approach also could not recover actual setup.
The official Docker action unconditionally pulls its selected image. A real
local Docker CLI rejects digest retagging with “refusing to create a tag with a
digest reference”; even a cache seed cannot bypass that official pull. The
pinned and freshly fetched Rust pipeline template already retries the actual
setup action with a mirror reference. This repair adopts that approach: execute
canonical setup, then retry actual setup on failure with the identical digest at
the mirror. Disabled mirrors and failure of both setups remain fatal. Validate
one-line references before writing action outputs; retain opt-in diagnostics.
The template's existing fallback is not reported as an unfixed upstream defect.

Ten local controls execute the real shell blocks and model only the remote
setup outcomes. They cover canonical success, actual-action fallback wiring,
both failures, disabled mirrors, explicit references, malformed input, output
write failure, hosted probe admission and a narrowly scoped outage injector.
The complete existing subprocess suite imports them. Seven focused JavaScript
files pass sequentially. Whole-payload inverses preserve every existing job and
container-workflow field except the four explicit image options; the workflow
addition contains only the new read-only probe and its source triggers. Both
shell blocks pass ShellCheck, and all five touched gates pass.

The hosted probe initializes real BuildKit daemons without building application
images. It verifies the selected RepoDigest, running daemon, image ID and builder
identity. Its second setup injects failure only for an exact canonical Docker
pull; mirror pulls and all other Docker commands still execute for real. A
12-minute job ceiling, individual step limits, sparse read-only checkout and an
always-retained artifact bound the trial. Actual hosted daemon startup and
mirror recovery remain pending on the next published commit; local adapter
passes do not grant that credit.

Retained failed attempts include fixture quoting mistakes, the superseded
cache-only draft, a harness injecting NODE_OPTIONS into a check that deliberately
refuses it, and an interrupted gate run at the Formal AI wrapper's 60-second
boundary. The corrected gate continuation completes under a detached supervisor
in 68.267 seconds, peak child RSS 814,504 KiB; no local Rust compilation occurs.
Complete original/compressed identities, registry responses, primary upstream
sources, helpers, traces and outputs are under
`experiments/issue-1580/evidence/checks/buildkit-bootstrap-identity/`.
Supplied commands and patches earn zero independent authorship or reasoning
credit. Every broader unfinished issue requirement remains open.
''')
(root/'changelog.d/issue-1580-buildkit-bootstrap-identity.md').write_text('Pin every BuildKit bootstrap to one verified multi-platform image digest, recover registry outages by retrying actual builder setup through the mirror, and verify real daemon and image identity in the hosted workflow checks.\n')
with (root/'experiments/issue-1580/work-plan.md').open('a') as stream:
 stream.write('\n- BuildKit repair: bind the default wrapper and four direct setup calls to the same freshly verified immutable index; adopt the Rust template\'s actual-setup fallback because a pre-pull or digest retag cannot bypass the official action\'s own pull. Ten local controls, seven focused files, ShellCheck, complete workflow inverse proofs and five touched gates pass. Retain all failed drafts/harness attempts; the final 68.267-second continuation runs under supervision. Add a bounded read-only hosted real-daemon/digest/fallback probe, whose actual execution remains pending until publication. No local layers or Rust builds; independent credit remains zero.\n')
print('Archived and verified',len(records),'BuildKit records')
