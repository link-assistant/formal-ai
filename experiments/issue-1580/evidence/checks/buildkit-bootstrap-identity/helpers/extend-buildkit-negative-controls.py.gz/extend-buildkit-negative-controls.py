from pathlib import Path
import json,subprocess
base=Path('/tmp/issue-1580-research/buildkit-immutable-identity')
image=json.loads((base/'resolution.json').read_text())['reference']
for name,argv in [('docker-version',['docker','--version']),
                  ('docker-digest-tag',['docker','image','tag','formal-ai-absent-buildkit-probe:invalid',image])]:
    result=subprocess.run(argv,capture_output=True)
    (base/(name+'.stdout')).write_bytes(result.stdout)
    (base/(name+'.stderr')).write_bytes(result.stderr)
    (base/(name+'.result.json')).write_text(json.dumps({'argv':argv,'exitCode':result.returncode})+'\n')
    if name=='docker-digest-tag':
        assert result.returncode!=0
        assert 'digest' in result.stderr.decode().lower(),result.stderr
        print(result.stderr.decode().strip())
path=Path('.github/actions/setup-buildx-resilient/action.yml')
source=path.read_text().replace('and supplies that exact reference to Buildx. Booting the docker-container driver otherwise pulls moby/buildkit',
    'and supplies that exact reference to Buildx.\n  Booting the docker-container driver otherwise pulls moby/buildkit')
source=source.replace('        set -u\n','        set -euo pipefail\n',1)
path.write_text(source)
path=Path('experiments/issue-1580/buildkit-image-identity.test.mjs')
source=path.read_text()
source=source.replace('mkdtempSync, readFileSync, writeFileSync, rmSync','mkdtempSync, readFileSync, writeFileSync, rmSync, existsSync')
source=source.replace("mode='canonical',mirror='mirror.gcr.io'", "mode='canonical',mirror='mirror.gcr.io',expectedStatus=0")
source=source.replace('assert.equal(result.status,0,result.stderr?.toString());','assert.equal(result.status,expectedStatus,result.stderr?.toString());')
source=source.replace("const calls=readFileSync(trace,'utf8').trim().split('"+chr(92)+"n').map(line=>JSON.parse(line));",
    "const calls=existsSync(trace)?readFileSync(trace,'utf8').trim().split('"+chr(92)+"n').map(line=>JSON.parse(line)):[];")
source+='''
test('invalid multiline or empty references fail before Docker or output records',async t=>{
  for(const options of [{image:''},{image:'moby/buildkit:tag'+String.fromCharCode(10)+'image=forged'},
    {mirror:'mirror.gcr.io'+String.fromCharCode(13)+'image=forged'}]) {
    const result=await execute(t,{...options,expectedStatus:1});
    assert.deepEqual(result.calls,[]);assert.deepEqual(result.outputs,{});
  }
});
'''
path.write_text(source)
print('Added negative input controls and fail-closed selected-image output writes.')
