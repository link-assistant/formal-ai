from pathlib import Path
from urllib.request import Request,urlopen
import hashlib,json,datetime
base=Path('/tmp/issue-1580-research/buildkit-immutable-identity')
base.mkdir(exist_ok=False)
endpoint='https://auth.docker.io/token?service=registry.docker.io&scope=repository:moby/buildkit:pull'
with urlopen(endpoint,timeout=30) as response:
    token=json.loads(response.read(1024*1024))['token']
url='https://registry-1.docker.io/v2/moby/buildkit/manifests/buildx-stable-1'
request=Request(url,headers={'Authorization':'Bearer '+token,
    'Accept':'application/vnd.oci.image.index.v1+json, application/vnd.docker.distribution.manifest.list.v2+json'})
with urlopen(request,timeout=30) as response:
    raw=response.read(2*1024*1024+1)
    assert len(raw)<=2*1024*1024
    headers=dict(response.headers)
    digest=response.headers['Docker-Content-Digest']
assert digest=='sha256:'+hashlib.sha256(raw).hexdigest()
index=json.loads(raw)
platforms={entry.get('platform',{}).get('architecture') for entry in index['manifests'] if entry.get('platform',{}).get('os')=='linux'}
assert {'amd64','arm64'}<=platforms
(base/'registry-index.json').write_bytes(raw)
(base/'registry-headers.json').write_text(json.dumps(headers,indent=2)+'\n')
(base/'resolution.json').write_text(json.dumps({'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'registryUrl':url,'tag':'moby/buildkit:buildx-stable-1','digest':digest,
    'reference':'moby/buildkit@'+digest,'architectures':sorted(platforms),'bytes':len(raw),
    'rawSha256':hashlib.sha256(raw).hexdigest(),'imageLayersDownloaded':False,
    'independentAuthorshipCredit':0},indent=2)+'\n')
print((base/'resolution.json').read_text())
