from pathlib import Path
import json, os, resource, subprocess, sys, time
base=Path('/tmp/issue-1580-research/buildkit-bootstrap-final')
if len(sys.argv)==1:
    for name in ('additional-checks.json','touched-gates.stdout','touched-gates.stderr'):
        source=base/name
        if source.exists(): source.rename(base/('interrupted-'+name))
    with (base/'additional-worker.log').open('wb') as stream:
        process=subprocess.Popen([sys.executable,__file__,'worker'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print('Supervised remaining gates:',process.pid)
    sys.exit(0)
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
argv=['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-runner-labels,check-fragment-release-map']
started=time.monotonic()
with (base/'remaining-gates.stdout').open('wb') as out,(base/'remaining-gates.stderr').open('wb') as err:
    result=subprocess.run(argv,env=env,stdout=out,stderr=err)
row={'argv':argv,'exitCode':result.returncode,'seconds':round(time.monotonic()-started,3),'childrenPeakRssKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss}
(base/'remaining-gates.json').write_text(json.dumps(row,indent=2)+'\n')
assert result.returncode==0,row
print('Complete',json.dumps(row),flush=True)
