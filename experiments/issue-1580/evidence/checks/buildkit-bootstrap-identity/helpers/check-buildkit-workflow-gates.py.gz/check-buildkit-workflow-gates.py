from pathlib import Path
import json, os, resource, subprocess, time
base=Path('/tmp/issue-1580-research/buildkit-bootstrap-final')
env=dict(os.environ)
env.pop('NODE_OPTIONS',None)
rows=[]
checks=[('whole-workflow-preservation',['node','--max-old-space-size=256','/tmp/issue-1580-research/prove-buildkit-workflow-preservation.mjs']),
        ('shellcheck',['shellcheck','--shell=bash',str(base/'buildkit-shell-0.sh'),str(base/'buildkit-shell-2.sh')]),
        ('touched-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only',
                         'check-runner-labels,check-file-size,check-file-size-js-twin,check-changelog-fragment-js-twin,check-fragment-release-map'])]
for name,argv in checks:
    started=time.monotonic()
    with (base/(name+'.stdout')).open('wb') as out,(base/(name+'.stderr')).open('wb') as err:
        result=subprocess.run(argv,env=env,stdout=out,stderr=err)
    rows.append({'name':name,'argv':argv,'exitCode':result.returncode,'seconds':round(time.monotonic()-started,3)})
    (base/'additional-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    assert result.returncode==0,name
print('children peak RSS KiB',resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
