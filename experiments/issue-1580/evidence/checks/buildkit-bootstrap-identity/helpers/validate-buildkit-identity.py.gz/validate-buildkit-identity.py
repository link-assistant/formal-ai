from pathlib import Path
import json, os, resource, subprocess, sys, time

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/buildkit-identity-final-corrected')
if len(sys.argv) == 1:
    base.mkdir(exist_ok=False)
    with (base / 'worker.log').open('wb') as stream:
        child = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root,
                                 stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': child.pid, 'directory': str(base)}))
    sys.exit(0)

rows = []
env = dict(os.environ)
# Release-source observation refuses ambient Node loader options. Bound the test
# process with its explicit CLI heap option without injecting NODE_OPTIONS.
env.pop('NODE_OPTIONS', None)
for name, path in [
    ('buildkit-identity', 'experiments/issue-1580/buildkit-image-identity.test.mjs'),
    ('subprocess-boundaries', 'rust/tests/web/bounded-subprocess-boundaries.test.mjs'),
    ('container-workflow', 'rust/tests/web/container-images-workflow.test.mjs'),
    ('registry-transport', 'rust/tests/web/container-registry-transport.test.mjs'),
    ('container-step-boundary', 'rust/tests/web/container-authority-step-boundary.test.mjs'),
    ('production-profile', 'rust/tests/web/fast-pull-request-production-profile.test.mjs'),
    ('default-branch-policy', 'rust/tests/web/default-branch-build-policy.test.mjs'),
]:
    argv = ['timeout', '600', 'node', '--max-old-space-size=256', '--test',
            '--test-reporter=tap', '--test-concurrency=1', path]
    start = time.monotonic()
    with (base / (name + '.stdout')).open('wb') as out, (base / (name + '.stderr')).open('wb') as err:
        result = subprocess.run(argv, cwd=root, env=env,
                                stdout=out, stderr=err)
    rows.append({'name': name, 'path': path, 'argv': argv, 'exitCode': result.returncode,
                 'seconds': round(time.monotonic() - start, 3)})
    (base / 'results.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == 0, name
(base / 'outcome.json').write_text(json.dumps({'complete': True, 'results': rows,
    'childrenPeakRssKiB': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
    'localRustExecution': False, 'imageLayerDownloads': 0, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
