from pathlib import Path
import hashlib,json,os,subprocess,time

root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/staged-only-primary-lock')
path=root/'scripts/check-rust-dependencies.sh'
old=path.read_text()
(out/'wrapper.before.sh').write_text(old)
needle='''if [[ "$primary_tracked" -ne 1 ]]; then
  echo "::error::$lock is not in the committed lockfile inventory." >&2
  exit 1
fi
'''
replacement=needle+'''
# The index also contains newly staged files. A binary lock is reproducible
# from this revision only when it is already part of the HEAD commit.
if ! git cat-file -e "HEAD:$lock"; then
  echo "::error::$lock is not committed at HEAD." >&2
  exit 1
fi
'''
assert old.count(needle)==1
path.write_text(old.replace(needle,replacement))
commands=[
 ['bash','-n','scripts/check-rust-dependencies.sh'],
 ['node','--test','--test-concurrency=1','rust/tests/web/cargo-audit-inventory.test.mjs'],
 ['rg','--files','rust/tests/web','-g','*audit*','-g','*security*','-g','*cargo*'],
 ['node','experiments/formal_ai_subagent/local-gates.mjs','--list'],
]
results=[]
for number,args in enumerate(commands):
    start=time.monotonic();name=f'after-{number:02d}.log'
    with (out/name).open('wb') as log:
        result=subprocess.run(args,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},stdout=log,stderr=subprocess.STDOUT)
    results.append({'args':args,'exit':result.returncode,'seconds':time.monotonic()-start,'log':name})
    assert result.returncode==0,results[-1]
    print(name+': '+(out/name).read_text())
(out/'after.json').write_text(json.dumps({'checks':results,'rustExecuted':False,'independentAuthorshipCredit':0,'sourceSha256':hashlib.sha256(path.read_bytes()).hexdigest()},indent=2)+'\n')
