from pathlib import Path
import json,subprocess,os,time
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/staged-only-primary-lock')
path=root/'rust/tests/web/cargo-audit-blocked-proof.test.mjs';old=path.read_text();(out/'blocked-proof.before.mjs').write_text(old)
new=old.replace("import {spawnSync} from 'node:child_process';", "import {execFileSync,spawnSync} from 'node:child_process';")
needle="    writeFileSync(join(directory,'extra/Cargo.lock'),'# independent committed-lock fixture\\n');"
replacement=needle+'''
    const git=(args)=>execFileSync('git',args,{cwd:directory,encoding:'utf8',stdio:['ignore','pipe','pipe']});
    git(['init','--quiet']);
    git(['add','--','rust/Cargo.lock','extra/Cargo.lock']);
    git(['-c','user.name=Formal AI test fixture','-c','user.email=fixture@example.invalid',
      '-c','core.hooksPath=/dev/null','commit','--quiet','--no-gpg-sign','-m','Commit audit lock fixtures']);'''
assert new.count(needle)==1;new=new.replace(needle,replacement)
needle="if(process.argv[2]!=='ls-files')process.exit(99);"
replacement='''if(process.argv[2]!=='ls-files'){
  const result=require('node:child_process').spawnSync('git',process.argv.slice(2),{
    stdio:'inherit',env:{...process.env,PATH:process.env.AUDIT_ORIGINAL_PATH}
  });
  process.exit(result.status??1);
}'''
assert new.count(needle)==1;new=new.replace(needle,replacement)
needle="env:{...process.env,PATH:join(directory,'bin')+':'+process.env.PATH,AUDIT_TRACE:trace,...env},"
replacement="env:{...process.env,PATH:join(directory,'bin')+':'+process.env.PATH,\n        AUDIT_ORIGINAL_PATH:process.env.PATH,AUDIT_TRACE:trace,...env},"
assert new.count(needle)==1;new=new.replace(needle,replacement)
needle="      const calls=readFileSync(trace,'utf8')"
assert new.count(needle)==1;new=new.replace(needle,"      assert.ifError(result.error);\n"+needle)
path.write_text(new)
for label,args in [
 ('blocked-proof-repaired',['node','--test','--test-concurrency=1','rust/tests/web/cargo-audit-blocked-proof.test.mjs']),
 ('fast-inventory-shape',['python3','-c',"import json; p='data/benchmarks/fast-pull-request-javascript-tests.json';d=json.load(open(p));print(type(d).__name__);print(list(d) if isinstance(d,dict) else len(d));print(json.dumps(d,indent=2)[:3500])"]),
 ('test-lane-routing',['rg','-n','fast-pull-request-javascript-tests|cargo-audit|node --test','scripts/plan-javascript-tests.mjs','.github/workflows/layered-ci.yml']),
]:
    start=time.monotonic()
    with (out/(label+'.log')).open('wb') as log:
        p=subprocess.run(args,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},stdout=log,stderr=subprocess.STDOUT)
    print(label+': '+str(p.returncode)+'\n'+(out/(label+'.log')).read_text())
    if label=='blocked-proof-repaired':assert p.returncode==0
