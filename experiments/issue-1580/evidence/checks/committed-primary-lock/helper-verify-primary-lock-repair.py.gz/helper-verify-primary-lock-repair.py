from pathlib import Path
import subprocess,json,os,time
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/staged-only-primary-lock')
commands=[
 ['node','--test','--test-concurrency=1','rust/tests/web/cargo-audit-proof.test.mjs'],
 ['node','--test','--test-concurrency=1','rust/tests/web/cargo-audit-blocked-proof.test.mjs'],
 ['node','--test','--test-concurrency=1','rust/tests/web/repository-audit-action-contract.test.mjs'],
 ['node','experiments/formal_ai_subagent/local-gates.mjs','--only','lint-shell-scripts'],
]
results=[]
for i,args in enumerate(commands):
    start=time.monotonic();name=f'related-{i:02d}.log'
    with (out/name).open('wb') as log:
        result=subprocess.run(args,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},stdout=log,stderr=subprocess.STDOUT)
    results.append({'args':args,'exit':result.returncode,'seconds':time.monotonic()-start,'log':name})
    print(name+': '+(out/name).read_text())
(out/'related.json').write_text(json.dumps({'checks':results,'rustExecuted':False,'independentAuthorshipCredit':0},indent=2)+'\n')
raise SystemExit(any(row['exit'] for row in results))
