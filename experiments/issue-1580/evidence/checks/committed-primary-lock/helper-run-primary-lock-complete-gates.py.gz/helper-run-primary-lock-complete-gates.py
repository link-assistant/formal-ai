from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,sys,time
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/committed-primary-lock-complete-gates')
if '--worker' not in sys.argv:
    out.mkdir(exist_ok=False)
    fragment=root/'changelog.d/issue-1580-committed-primary-lock.md'
    assert not fragment.exists()
    fragment.write_text('''### Fixed

- Refuse a newly staged primary Rust lockfile that is absent from the HEAD
  commit before invoking Cargo; retain independent lock audits and strict
  advisory proofs. Exercise the actual wrapper with finite temporary Git
  repositories in the fast pull-request regression lane.
''')
    subprocess.run(['git','add','--','scripts/check-rust-dependencies.sh','rust/tests/web/cargo-audit-inventory.test.mjs','rust/tests/web/cargo-audit-blocked-proof.test.mjs','data/benchmarks/fast-pull-request-javascript-tests.json','docs/case-studies/issue-1580/templates/rust-source-review-progress.json','docs/case-studies/issue-1580/committed-primary-lock-checkpoint.md','experiments/issue-1580/work-plan.md','experiments/issue-1580/evidence/checks/committed-primary-lock',str(fragment.relative_to(root))],cwd=root,check=True)
    with (out/'worker.log').open('wb') as log:
        process=subprocess.Popen([sys.executable,__file__,'--worker'],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':process.pid})+'\n')
    print(json.dumps({'workerPid':process.pid,'output':str(out)}))
else:
    started=time.monotonic()
    args=['node','experiments/formal_ai_subagent/local-gates.mjs']
    with (out/'gates.log').open('wb') as log:
        result=subprocess.run(args,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},stdout=log,stderr=subprocess.STDOUT)
    receipt={'args':args,'exit':result.returncode,'seconds':time.monotonic()-started,'at':datetime.now(timezone.utc).isoformat(),'rustExecuted':False,'independentAuthorshipCredit':0,'allIssueAcceptanceComplete':False}
    (out/'outcome.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt))
