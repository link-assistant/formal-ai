from pathlib import Path
import subprocess,json,os
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/staged-only-primary-lock');out.mkdir(exist_ok=False)
path=root/'rust/tests/web/cargo-audit-inventory.test.mjs';old=path.read_text();(out/'test.before.mjs').write_text(old)
new=old.replace('inventoryBytes = null, quotePaths = true, untracked = []} = {}) {','inventoryBytes = null, quotePaths = true, untracked = [], stagedOnly = []} = {}) {')
new=new.replace("    if (paths.length) git(['add', '--', ...paths]);", """    const committed = paths.filter(path => !stagedOnly.includes(path));
    if (committed.length) git(['add', '--', ...committed]);
    git(['-c', 'user.name=Formal AI test fixture', '-c', 'user.email=fixture@example.invalid',
      '-c', 'core.hooksPath=/dev/null', 'commit', '--quiet', '--allow-empty', '--no-gpg-sign',
      '-m', 'Commit finite lockfile fixtures']);
    if (stagedOnly.length) git(['add', '--', ...stagedOnly]);""")
new+='''
test('a staged-only primary binary lock cannot stand in for a committed HEAD lock', {timeout:10000}, () => {
  const result = observe({paths:[primary, 'extra/Cargo.lock'], stagedOnly:[primary]});
  assert.equal(result.status, 1, result.stdout + result.stderr);
  assert.match(result.stdout + result.stderr, /rust\\/Cargo\\.lock is not committed at HEAD/u);
  assert.deepEqual(result.calls, []);
});
'''
assert new!=old and new.count('stagedOnly = []')==1 and new.count('Commit finite lockfile fixtures')==1
path.write_text(new)
args=['node','--test','--test-concurrency=1','--test-name-pattern=staged-only','rust/tests/web/cargo-audit-inventory.test.mjs']
with (out/'regression-before.log').open('wb') as log:p=subprocess.run(args,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},stdout=log,stderr=subprocess.STDOUT)
assert p.returncode!=0,'The staged-only regression must fail before the production repair'
(out/'before.json').write_text(json.dumps({'command':args,'exit':p.returncode,'expectedFailure':True,'rustExecuted':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print((out/'regression-before.log').read_text())
