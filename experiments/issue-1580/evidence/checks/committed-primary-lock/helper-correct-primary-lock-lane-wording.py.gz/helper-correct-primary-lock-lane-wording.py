from pathlib import Path
import json
root=Path('/tmp/gh-issue-solver-1794900398048')
replacements={
 'docs/case-studies/issue-1580/committed-primary-lock-checkpoint.md':('The inventory regression is registered in the fast pull-request JavaScript lane.','The inventory regression is registered in the optional local feedback inventory.\nHosted pull requests and main already discover it through their full default\nJavaScript test glob.'),
 'experiments/issue-1580/work-plan.md':('- [x] Register the inventory regression in the fast pull-request JavaScript lane.','- [x] Register the inventory regression in the optional local feedback inventory;\n  the full hosted JavaScript test glob already discovers it.'),
 'changelog.d/issue-1580-committed-primary-lock.md':('  repositories in the fast pull-request regression lane.','  repositories in the full hosted JavaScript suite and local feedback inventory.'),
}
for name,(before,after) in replacements.items():
    path=root/name;text=path.read_text();assert text.count(before)==1,name
    path.write_text(text.replace(before,after,1))
print(json.dumps({'corrected':list(replacements),'hostedSuiteUnchanged':True}))
