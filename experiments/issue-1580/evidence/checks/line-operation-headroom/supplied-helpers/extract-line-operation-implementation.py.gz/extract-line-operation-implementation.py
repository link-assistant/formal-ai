from pathlib import Path
import hashlib,json,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/line-operation-implementation-headroom');out.mkdir(exist_ok=False)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 assert result.returncode in allowed,(name,result.returncode)
try:
 assert json.loads(Path('/tmp/issue-1580-research/maintained-metadata-headroom/outcome.json').read_text())['complete']
 owner='rust/src/agentic_coding/workspace_line_operation.rs';child='rust/src/agentic_coding/workspace_line_operation/applied_changes.rs';test='experiments/issue-1580/native-test-headroom.test.mjs'
 for path in [owner,test]:
  target=out/'preimages'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((root/path).read_bytes())
 regression='''
test('whole-line operation application retains source-size headroom', () => {
  const owner = 'rust/src/agentic_coding/workspace_line_operation';
  assert.deepEqual(checkListedFiles(root, new Set([owner + '.rs', owner + '/applied_changes.rs'])),
    {warnings: [], violations: [], embeddedDataViolations: []});
  const source = readFileSync(root + '/' + owner + '.rs', 'utf8');
  const helper = readFileSync(root + '/' + owner + '/applied_changes.rs', 'utf8');
  assert(source.includes('mod applied_changes;'));
  for (const name of ['compute', 'bounded', 'reported', 'reported_values'])
    assert(helper.includes('fn ' + name + '('), 'every original operation method remains');
});
'''
 (root/test).write_text((root/test).read_text()+regression)
 run('headroom-before',['node','--max-old-space-size=256','--test','--test-concurrency=1',test],(1,))
 source=(root/owner).read_text();start=source.index('impl LineOperation {\n');end=source.index('/// Exactly one of the two seeded meanings:',start);body=source[start:end];assert body.count('impl LineOperation {')==2 and body.count('pub(super) ')==4
 dest=root/child;assert not dest.exists();dest.parent.mkdir(exist_ok=True);changed=body.replace('pub(super) ','pub(in super::super) ');dest.write_text('//! Apply and report whole-line edits without changing request parsing.\nuse super::*;\n\n'+changed)
 declaration='#[path = "workspace_line_operation/applied_changes.rs"]\nmod applied_changes;\n\n';(root/owner).write_text(source[:start]+declaration+source[end:]);assert (root/owner).read_text().replace(declaration,body,1)==source
 assert dest.read_text().split('\n\n',1)[1].replace('pub(in super::super) ','pub(super) ')==body
 run('rustfmt',['rustfmt','--edition','2024',owner,child]);run('rustfmt-check',['rustfmt','--check','--edition','2024',owner,child]);run('headroom-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',test]);run('line-operation-behavior',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/pull-request-1188-line-operations.test.mjs']);run('projection-currency',['node','--max-old-space-size=256','scripts/translate-js-rust.mjs','--verify']);run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'owner':owner,'child':child,'beforeLines':len(source.splitlines()),'ownerAfterLines':len((root/owner).read_text().splitlines()),'childLines':len(dest.read_text().splitlines()),'completeImplementationBodySha256':hashlib.sha256(body.encode()).hexdigest(),'ownerExactInverseBeforeFormatting':True,'allCompleteMethodBodiesAndCommentsUnchanged':True,'visibilityAncestorPreserved':'original parent, agentic_coding','nativeExecutionVerified':False,'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
