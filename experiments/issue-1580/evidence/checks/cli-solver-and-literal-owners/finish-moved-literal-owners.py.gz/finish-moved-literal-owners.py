from pathlib import Path
import json, os, subprocess
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/moved-literal-owner-refresh')
proof = json.loads((out/'owner-proof.json').read_text())
assert proof['sameLiteralMultiset'] and proof['rowsBefore']==proof['rowsAfter']
records = []
for name,argv in [
    ('gate-inventory',['node','experiments/formal_ai_subagent/local-gates.mjs','--list']),
    ('corrected-owner-and-debt-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-hardcoded-language,check-hardcoded-language-js-twin,check-debt-ratchet-js-twin']),
]:
    result = subprocess.run(argv,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},capture_output=True)
    (out/(name+'.stdout')).write_bytes(result.stdout)
    (out/(name+'.stderr')).write_bytes(result.stderr)
    records.append({'name':name,'argv':argv,'exitCode':result.returncode})
    (out/'corrected-commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    assert result.returncode==0,name
(out/'outcome.json').write_text(json.dumps({'passed':True,**proof,'pushExecuted':False,'initialGateSelectorFailureRetained':True},indent=2)+'\n')
