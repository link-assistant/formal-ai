from pathlib import Path
import gzip, hashlib, json, re, subprocess
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/fast-source-warning-failure')
out.mkdir(exist_ok=False)
result = subprocess.run(['gh', 'run', 'view', '44821503308', '--repo', 'link-assistant/formal-ai', '--job', '136583238188', '--log'], cwd=root, capture_output=True)
for name,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
    (out / (name + '.log.gz')).write_bytes(gzip.compress(raw, mtime=0))
assert result.returncode == 0, result.stderr.decode()
lines = result.stdout.decode().splitlines()
matches = [i for i,line in enumerate(lines) if re.search(r'##\[error\]|^.*not ok |AssertionError|stale|FAIL:|Error:',line)]
indices = sorted({j for i in matches for j in range(max(0,i-3),min(len(lines),i+10))})
text = '\n'.join(str(i+1) + ': ' + lines[i] for i in indices) + '\n'
(out / 'failure-excerpts.txt').write_text(text)
(out / 'identity.json').write_text(json.dumps({'head':'f8b372ad314c8052a00dbd2a3139dac0f45d0f78','run':44821503308,'job':136583238188,'bytes':len(result.stdout),'lines':len(lines),'sha256':hashlib.sha256(result.stdout).hexdigest(),'exitCode':result.returncode,'excerptLines':len(indices)},indent=2)+'\n')
print(text)
