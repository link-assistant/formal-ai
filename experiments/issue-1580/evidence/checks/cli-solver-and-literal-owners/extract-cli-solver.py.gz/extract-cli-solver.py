from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import gzip, hashlib, json, os, subprocess, sys, time
root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch/'cli-solver-extraction'
if len(sys.argv) == 1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:
        worker = subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({'pid':worker.pid,'finiteWorker':True}))
    sys.exit(0)
for tick in range(180):
    previous = scratch/'moved-literal-owner-refresh/outcome.json'
    if previous.exists():
        assert json.loads(previous.read_text())['passed']
        break
    time.sleep(5)
else:
    raise RuntimeError('Previous finite check has not completed; no source mutation')
records = []
def run(name,argv,expected=0):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        result = subprocess.run(argv,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},stdout=stdout,stderr=stderr)
    records.append({'name':name,'argv':argv,'exitCode':result.returncode})
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    assert result.returncode==expected,name
parent = root/'rust/src/main.rs'
child = root/'rust/src/cli_solver.rs'
original = parent.read_text()
assert len(original.splitlines())==992 and not child.exists()
first_start,first_end = original.index('fn run_agent('),original.index('pub(crate) struct TelegramRunArgs')
second_start,second_end = original.index('fn solver_for_chat('),original.index('pub(crate) fn read_input(')
first,second = original[first_start:first_end],original[second_start:second_end]
old_imports = '''use formal_ai::agentic_coding::run_agentic_task;
use formal_ai::{
    ChatCompletionRequest, ChatMessage, DEFAULT_MODEL, ExecutionSurface, ProxyConfig,
    ResponsesRequest, SolverConfig, UniversalSolver, WithFormalAiArgs,
    create_chat_completion_with_solver, create_response_with_solver, delimit_tool_args,
    enable_http_agent_mode_for_current_process, knowledge_links_notation, run_proxy,
    run_with_formal_ai,
};
'''
new_imports = '''use formal_ai::{
    ProxyConfig, WithFormalAiArgs, delimit_tool_args, enable_http_agent_mode_for_current_process,
    knowledge_links_notation, run_proxy, run_with_formal_ai,
};
'''
child_imports = '''use crate::cli_thinking::print_thinking_trace;
use crate::{DefinitionFusionMode, OutputFormat};
use formal_ai::agentic_coding::run_agentic_task;
use formal_ai::{
    ChatCompletionRequest, ChatMessage, DEFAULT_MODEL, ExecutionSurface, ResponsesRequest,
    SolverConfig, UniversalSolver, create_chat_completion_with_solver, create_response_with_solver,
};
use std::error::Error;

'''
assert old_imports in original
module = 'mod cli_solver;\n'
export = 'use cli_solver::{run_agent, run_chat};\n'
new_parent = original.replace(first,'',1).replace(second,'',1).replace(old_imports,new_imports,1).replace('use cli_thinking::print_thinking_trace;\n','',1).replace('mod cli_statement_audit;\n',module+'mod cli_statement_audit;\n',1).replace('use cli_statement_audit::',export+'use cli_statement_audit::',1)
new_child = child_imports+first.replace('fn run_agent(','pub(super) fn run_agent(',1)+second.replace('fn run_chat(','pub(super) fn run_chat(',1).rstrip()+'\n'
restored = new_parent.replace(module,'',1).replace(export,'',1).replace('mod cli_translate;\n','mod cli_translate;\nuse cli_thinking::print_thinking_trace;\n',1).replace(new_imports,old_imports,1).replace('pub(crate) struct TelegramRunArgs',first+'pub(crate) struct TelegramRunArgs',1).replace('pub(crate) fn read_input(',second+'pub(crate) fn read_input(',1)
assert restored==original
assert new_child.removeprefix(child_imports).replace('pub(super) fn ','fn ')==(first+second).rstrip()+'\n'
(out/'original-source.rs.gz').write_bytes(gzip.compress(original.encode(),mtime=0))
parent.write_text(new_parent)
child.write_text(new_child)
paths = [parent.relative_to(root).as_posix(),child.relative_to(root).as_posix()]
inputs = {}
for index,path in enumerate(paths):
    target = out/('unformatted-'+str(index)+'.rs')
    target.write_bytes((root/path).read_bytes())
    inputs[path] = str(target)
(out/'formatting-inputs.json').write_text(json.dumps(inputs)+'\n')
run('canonical-format',['rustfmt','--edition','2024',*paths])
code = "import fs from 'node:fs'; import assert from 'node:assert/strict'; import {lex} from './scripts/self-translation/lexer.mjs'; for(const [file,old] of Object.entries(JSON.parse(fs.readFileSync(process.argv[1],'utf8')))){const tokens=s=>lex(s,'Rust').map(t=>[t.type,t.text]);assert.deepEqual(tokens(fs.readFileSync(file,'utf8')),tokens(fs.readFileSync(old,'utf8')),file);} console.log('Every Rust syntax token and comment is unchanged by formatting');"
run('format-token-equivalence',['node','--input-type=module','-e',code,str(out/'formatting-inputs.json')])
counts = [len(path.read_text().splitlines()) for path in [parent,child]]
assert all(count<900 for count in counts)
proof = {'parent':paths[0],'child':paths[1],'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'reassembledOriginalSha256':hashlib.sha256(restored.encode()).hexdigest(),'originalLines':992,'parentLines':counts[0],'childLines':counts[1],'exactOriginalReconstructionBeforeFormatting':True,'formattingPreservesEverySyntaxTokenAndComment':True}
(out/'inverse-proofs.json').write_text(json.dumps({'observedAt':datetime.now(timezone.utc).isoformat(),'files':[proof],'hostedNativeVerificationPending':True,'actualCliExecutionPending':True,'localRustExecution':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
run('rust-format-check',['rustfmt','--edition','2024','--check',*paths])
run('translation-current',['node','scripts/translate-js-rust.mjs','--verify'])
run('generated-registry-current',['node','scripts/lib/generate-native-specification-programs.mjs','--check'])
allowlist = root/'scripts/hardcoded-language-allowlist.txt'
old_allowlist = allowlist.read_bytes()
(out/'original-allowlist.txt.gz').write_bytes(gzip.compress(old_allowlist,mtime=0))
run('hardcoded-before',['node','scripts/check-hardcoded-language.mjs'],1)
run('maintained-owner-refresh',['node','scripts/check-hardcoded-language.mjs','--write'])
def rows(raw):
    return [tuple(line.split('\t',1)) for line in raw.decode().splitlines() if line and not line.startswith('#')]
old_rows,new_rows = rows(old_allowlist),rows(allowlist.read_bytes())
removed,added = sorted(set(old_rows)-set(new_rows)),sorted(set(new_rows)-set(old_rows))
assert len(old_rows)==len(new_rows) and Counter(row[1] for row in old_rows)==Counter(row[1] for row in new_rows)
assert len(removed)==len(added)==1 and removed[0][0]=='rust/src/main.rs' and added[0][0]=='rust/src/cli_solver.rs' and removed[0][1]==added[0][1]
(out/'owner-proof.json').write_text(json.dumps({'removed':removed,'added':added,'rowsBefore':len(old_rows),'rowsAfter':len(new_rows),'sameLiteralMultiset':True,'noNewAllowlistedLiteral':True},indent=2)+'\n')
run('hardcoded-language',['node','scripts/check-hardcoded-language.mjs'])
run('source-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code'])
(out/'outcome.json').write_text(json.dumps({'passed':True,'files':[proof],'sourcePaths':[*paths,'scripts/hardcoded-language-allowlist.txt'],'pushExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
