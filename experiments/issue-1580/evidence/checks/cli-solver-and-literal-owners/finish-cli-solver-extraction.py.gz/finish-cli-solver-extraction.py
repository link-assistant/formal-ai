from pathlib import Path
from collections import Counter
import gzip, json, os, subprocess
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/cli-solver-extraction')
proof = json.loads((out/'inverse-proofs.json').read_text())['files'][0]
assert proof['formattingPreservesEverySyntaxTokenAndComment']
paths = [proof['parent'],proof['child']]
records = []
def run(name,argv,expected=0):
    with (out/('finish-'+name+'.stdout')).open('wb') as stdout,(out/('finish-'+name+'.stderr')).open('wb') as stderr:
        result = subprocess.run(argv,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},stdout=stdout,stderr=stderr)
    records.append({'name':name,'argv':argv,'exitCode':result.returncode,'expectedExitCode':expected})
    (out/'finish-commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    assert result.returncode==expected,name
source = Path('/tmp/issue-1580-research/extract-cli-solver.py').read_text()
tail = source[source.index("allowlist = root/'scripts/hardcoded-language-allowlist.txt'"):]
exec(compile(tail,__file__,'exec'))
