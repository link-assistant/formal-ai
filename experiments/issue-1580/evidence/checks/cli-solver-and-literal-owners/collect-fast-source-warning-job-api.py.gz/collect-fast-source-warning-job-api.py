from pathlib import Path
source = Path('/tmp/issue-1580-research/collect-fast-source-warning-failure.py').read_text()
source = source.replace("out.mkdir(exist_ok=False)", "assert out.is_dir()")
source = source.replace("['gh', 'run', 'view', '44821503308', '--repo', 'link-assistant/formal-ai', '--job', '136583238188', '--log']", "['gh', 'api', 'repos/link-assistant/formal-ai/actions/jobs/136583238188/logs']")
source = source.replace("name + '.log.gz'", "'job-api-' + name + '.log.gz'")
source = source.replace("out / 'failure-excerpts.txt'", "out / 'job-api-failure-excerpts.txt'")
source = source.replace("out / 'identity.json'", "out / 'job-api-identity.json'")
exec(compile(source, __file__, 'exec'))
