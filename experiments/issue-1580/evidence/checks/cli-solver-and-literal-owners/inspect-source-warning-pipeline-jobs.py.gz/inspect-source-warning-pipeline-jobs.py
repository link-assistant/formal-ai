from pathlib import Path
import json, subprocess
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/source-warning-pipeline-jobs')
out.mkdir(exist_ok=False)
result = subprocess.run(['gh', 'run', 'view', '44821503308', '--repo', 'link-assistant/formal-ai', '--json', 'jobs,status,conclusion,headSha'], cwd=root, capture_output=True)
(out / 'stdout.json').write_bytes(result.stdout)
(out / 'stderr.log').write_bytes(result.stderr)
assert result.returncode == 0
data = json.loads(result.stdout)
print(json.dumps({key:value for key,value in data.items() if key != 'jobs'}))
for row in data['jobs']:
    print(json.dumps({key:row[key] for key in ['databaseId','name','status','conclusion','startedAt','completedAt']}))
