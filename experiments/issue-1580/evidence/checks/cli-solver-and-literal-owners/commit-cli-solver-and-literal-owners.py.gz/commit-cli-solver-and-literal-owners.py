from pathlib import Path
import gzip, hashlib, json, os, subprocess
root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch/'cli-solver-extraction'
assert json.loads((out/'outcome.json').read_text())['passed']
assert json.loads((scratch/'moved-literal-owner-refresh/outcome.json').read_text())['passed']
def run(name,argv):
    result = subprocess.run(argv,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},capture_output=True)
    (out/('commit-'+name+'.stdout')).write_bytes(result.stdout)
    (out/('commit-'+name+'.stderr')).write_bytes(result.stderr)
    print(name,result.returncode,flush=True)
    assert result.returncode==0,name
    return result.stdout.decode()
assert not run('index-before',['git','diff','--cached','--name-only']).strip()
archive = root/'experiments/issue-1580/evidence/checks/cli-solver-and-literal-owners'
archive.mkdir(exist_ok=False)
entries = []
inputs = []
for directory in [out,scratch/'moved-literal-owner-refresh',scratch/'fast-source-warning-failure',scratch/'source-warning-pipeline-jobs']:
    for path in sorted(directory.iterdir()):
        if path.is_file() and path.name!='worker.log': inputs.append((directory.name+'-'+path.name,path))
for name in ['extract-cli-solver.py','extract-cli-solver.log','finish-cli-solver-extraction.py','finish-cli-solver-extraction.log','refresh-moved-literal-owners.py','refresh-moved-literal-owners.log','finish-moved-literal-owners.py','finish-moved-literal-owners.log','inspect-source-warning-pipeline-jobs.py','inspect-source-warning-pipeline-jobs.log','collect-fast-source-warning-failure.py','collect-fast-source-warning-failure.log','collect-fast-source-warning-job-api.py','collect-fast-source-warning-job-api.log','collect-fast-source-warning-job-api-raw.py','collect-fast-source-warning-job-api-raw.log']:
    inputs.append((name,scratch/name))
inputs.append((Path(__file__).name,Path(__file__)))
for name,path in inputs:
    raw = path.read_bytes()
    packed = gzip.compress(raw,mtime=0)
    target = archive/(name+'.gz')
    assert not target.exists()
    target.write_bytes(packed)
    entries.append({'file':target.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
(archive/'records.json').write_text(json.dumps({'entries':entries,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
fragment = root/'changelog.d/issue-1580-computer-use-content.md'
fragment.write_text(fragment.read_text()+'\nSeparate unchanged CLI solver invocation helpers; regenerate literal-owner paths after source moves without adding allowlisted text.\n')
plan = root/'experiments/issue-1580/work-plan.md'
plan.write_text(plan.read_text()+'\n- Collect actual failed Fast Linux job 136583238188 through the job API while its parent run is active. Original lines 692–709 identify two moved Telegram HTML literals and stale owners. Preserve both refused log transports and the successful raw API response. The maintained allowlist generator moves precisely those two owner paths without adding literals or rows; the existing seven-case debt regression and three available owner/debt gates pass after correcting one unavailable gate selector. Separately extract CLI solver invocation (992 to 886 parent lines, 111 child lines), prove exact source reconstruction and unchanged syntax/comment tokens, and regenerate exactly one further moved literal owner. Projection, registry freshness, hardcoded-language and four source gates pass. Preserve the initially loaded worker\'s expected stale-owner failure. Native compilation/actual CLI execution and every broader criterion remain open; independent credit remains zero.\n')
selected = ['rust/src/main.rs','rust/src/cli_solver.rs','scripts/hardcoded-language-allowlist.txt',archive.relative_to(root).as_posix(),fragment.relative_to(root).as_posix(),plan.relative_to(root).as_posix()]
run('stage',['git','add','--',*selected])
secret_paths = []
for relative in selected:
    path = root/relative
    secret_paths.extend(p.relative_to(root).as_posix() for p in sorted(path.rglob('*')) if p.is_file()) if path.is_dir() else secret_paths.append(relative)
run('secrets',['bash','scripts/check-secrets.sh',*secret_paths])
run('whitespace',['git','diff','--cached','--check'])
run('commit',['git','commit','-m','refactor: separate CLI solver and refresh moved literal owners'])
head = run('head',['git','rev-parse','HEAD']).strip()
(out/'commit-outcome.json').write_text(json.dumps({'head':head,'passed':True,'pushExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
