from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys, time
root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch/'moved-literal-owner-refresh'
if len(sys.argv) == 1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:
        worker = subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({'pid':worker.pid,'finiteWorker':True}))
    sys.exit(0)
# Keep heavyweight checks sequential with the already running realization file.
for tick in range(180):
    previous = scratch/'cnl-realization-extraction/outcome.json'
    if previous.exists():
        assert json.loads(previous.read_text())['passed']
        break
    time.sleep(5)
else:
    raise RuntimeError('Previous finite source check has not completed; no allowlist mutation')
records = []
def run(name,argv,expected=0):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        result = subprocess.run(argv,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},stdout=stdout,stderr=stderr)
    records.append({'name':name,'argv':argv,'exitCode':result.returncode,'expectedExitCode':expected})
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    assert result.returncode == expected,name
path = root/'scripts/hardcoded-language-allowlist.txt'
old = path.read_bytes()
(out/'original-allowlist.txt.gz').write_bytes(gzip.compress(old,mtime=0))
run('hardcoded-before',['node','scripts/check-hardcoded-language.mjs'],1)
before = (out/'hardcoded-before.stdout').read_text()+(out/'hardcoded-before.stderr').read_text()
assert 'rust/src/telegram/markdown.rs' in before and 'Stale allowlist rows' in before
run('regenerate-maintained-allowlist',['node','scripts/check-hardcoded-language.mjs','--write'])
new = path.read_bytes()
def rows(raw):
    return [tuple(line.split('\t',1)) for line in raw.decode().splitlines() if line and not line.startswith('#')]
old_rows,new_rows = rows(old),rows(new)
removed = sorted(set(old_rows)-set(new_rows))
added = sorted(set(new_rows)-set(old_rows))
assert len(old_rows)==len(new_rows) and Counter(row[1] for row in old_rows)==Counter(row[1] for row in new_rows)
assert len(removed)==len(added)==2
assert all(row[0]=='rust/src/telegram.rs' for row in removed)
assert all(row[0]=='rust/src/telegram/markdown.rs' for row in added)
assert [row[1] for row in removed]==[row[1] for row in added]
proof = {'observedAt':datetime.now(timezone.utc).isoformat(),'originalSha256':hashlib.sha256(old).hexdigest(),'newSha256':hashlib.sha256(new).hexdigest(),'rowsBefore':len(old_rows),'rowsAfter':len(new_rows),'removed':removed,'added':added,'sameLiteralMultiset':True,'noNewAllowlistedLiteral':True,'generator':'node scripts/check-hardcoded-language.mjs --write','fullIssueComplete':False,'independentAuthorshipCredit':0}
(out/'owner-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
run('hardcoded-after',['node','scripts/check-hardcoded-language.mjs'])
run('debt-ceiling-regression',['node','--test','--test-concurrency=1','rust/tests/web/debt-ceiling-fast-lane.test.mjs'])
run('owner-and-debt-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-hardcoded-language,check-hardcoded-language-js-twin,check-debt-ratchet,check-debt-ratchet-js-twin'])
(out/'outcome.json').write_text(json.dumps({'passed':True,**proof,'pushExecuted':False},indent=2)+'\n')
