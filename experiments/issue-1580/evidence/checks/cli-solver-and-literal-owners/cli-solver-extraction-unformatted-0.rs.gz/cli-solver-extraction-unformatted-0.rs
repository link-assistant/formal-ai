use std::error::Error;
use std::path::PathBuf;

use clap::{CommandFactory, Subcommand, ValueEnum};
use lino_arguments::Parser;

mod cli_algorithm;
mod cli_benchmark;
mod cli_bundle;
mod cli_clients;
mod cli_coding;
mod cli_computer_use;
mod cli_context;
mod cli_environments;
mod cli_explain;
mod cli_file_legality;
mod cli_github_logs;
mod cli_import;
mod cli_improve;
mod cli_learn;
mod cli_local_transport;
mod cli_logs;
mod cli_memory;
mod cli_orchestration;
mod cli_paths;
mod cli_procedure;
mod cli_provenance;
mod cli_report;
mod cli_repository_history;
mod cli_shared_dialog;
mod cli_solver;
mod cli_statement_audit;
mod cli_summarization;
mod cli_telegram;
mod cli_thinking;
mod cli_translate;

use cli_algorithm::{AlgorithmArgs, run_algorithm};
use cli_benchmark::{BenchmarkAction, run_benchmark};
use cli_bundle::run_bundle;
use cli_clients::{ClientsAction, ClientsFormat, run_clients};
use cli_coding::{CodingArgs, run_coding};
use cli_computer_use::{ComputerUseArgs, run_computer_use};
use cli_context::{ContextArgs, run_context};
use cli_environments::run_environments;
use cli_explain::{ExplainFormat, run_explain};
use cli_file_legality::{FileLegalityArgs, run_file_legality};
use cli_github_logs::{GithubLogsAction, run_github_logs};
use cli_import::{ImportAction, run_import};
use cli_improve::{ImproveArgs, run_improve};
use cli_learn::{LearnAction, run_learn_action};
use cli_local_transport::{ConnectArgs, ServeArgs, run_connect, run_serve};
use cli_memory::run_memory;
use cli_orchestration::{AgentArgs, run_external_action};
use cli_procedure::{ProcedureArgs, run_procedure};
use cli_report::{ReportArgs, run_report};
use cli_repository_history::{RepositoryHistoryAction, run_repository_history};
use cli_shared_dialog::{SharedDialogAction, run_shared_dialog};
use cli_solver::{run_agent, run_chat};
use cli_statement_audit::{StatementAuditArgs, run_statement_audit};
use cli_summarization::{SummarizationAction, run_summarization};
use cli_telegram::run_telegram;
use cli_translate::run_translate;
use formal_ai::{
    ProxyConfig, WithFormalAiArgs, delimit_tool_args, enable_http_agent_mode_for_current_process,
    knowledge_links_notation, run_proxy, run_with_formal_ai,
};

/// The canonical issue-#468 task; its wording carries the planner's routing keywords.
const DEFAULT_AGENT_TASK: &str = "Formalize «Сказка о рыбаке и рыбке» into a Links Notation \
                                  knowledge base covering all nine protocol primitives.";

#[derive(Parser, Debug)]
#[command(
    name = "formal-ai",
    version,
    about = "Formal symbolic AI implementation"
)]
struct Args {
    /// Print verbose CLI output (wrapper diagnostics need this explicit flag).
    #[arg(long, global = true, default_value_t = true)]
    verbose: bool,

    /// Disable diagnostics and dialog capture.
    // Issue #1181: route `FORMAL_AI_SILENT` through the shared boolean parser
    // so `=1`, `=yes`, `=on` (any case) work like `=true`; the action stays
    // `SetTrue`, so a bare `--silent` flag keeps working.
    #[arg(
        long,
        global = true,
        env = "FORMAL_AI_SILENT",
        default_value_t = false,
        value_parser = formal_ai::cli_env::bool_env_value_parser
    )]
    silent: bool,

    /// Named output constraints, independent of accepted input phrasing.
    #[arg(long, global = true, env = "FORMAL_AI_OUTPUT_STANDARD")]
    output_standard: Option<String>,
    /// Vocabulary density: standard, primes, top-N, dense or max-precision.
    #[arg(long, global = true, env = "FORMAL_AI_LEXICAL_DENSITY")]
    lexical_density: Option<String>,

    #[command(subcommand)]
    command: Option<Command>,
}

#[derive(Debug, Subcommand)]
enum Command {
    Chat {
        #[arg(long, env = "FORMAL_AI_PROMPT")]
        prompt: String,

        #[arg(long, value_enum, default_value_t = OutputFormat::Text)]
        format: OutputFormat,

        /// Definition fusion mode for plain definition prompts such as
        /// "What is IIR?". Defaults to `FORMAL_AI_DEFINITION_FUSION` or explicit.
        #[arg(long, value_enum)]
        definition_fusion: Option<DefinitionFusionMode>,

        /// Print the solver's concrete, human-readable thinking steps before the
        /// answer (text format only). Composite steps are shown nested under
        /// their parent. The same trace the web UI and API surfaces expose.
        #[arg(long, default_value_t = false)]
        thinking: bool,

        /// Compute budget for the step-7 random/evolutionary search stage
        /// (issue #662), counted in candidate evaluations. Overrides
        /// `FORMAL_AI_COMPUTE_BUDGET`. `0` disables the search.
        #[arg(long, env = "FORMAL_AI_COMPUTE_BUDGET")]
        compute_budget: Option<u32>,

        /// Independent candidate drafts to evaluate for each eligible synthesis
        /// leaf (issue #704). Overrides `FORMAL_AI_DRAFT_COUNT`.
        #[arg(long, env = "FORMAL_AI_DRAFT_COUNT")]
        draft_count: Option<u8>,
    },
    Dataset,
    /// Convert legacy JSONL or canonical diagnostic/dialog logs.
    Logs(cli_logs::LogsArgs),
    /// Authenticate bounded tracked working-source bytes.
    Provenance(cli_provenance::ProvenanceArgs),
    /// Translate a document between the source roots through the meta
    /// language (plan 16 L2): `--from`/`--to` one of rust|js|ts|meta,
    /// `--input` the source file for a live leg, `--list` every direction
    /// and the leaf that owes the ones still pending, `--write` to write the
    /// mapped sibling-root file (or, without `--input`, the whole tree).
    Translate {
        #[arg(long)]
        from: Option<String>,

        #[arg(long)]
        to: Option<String>,

        #[arg(long)]
        input: Option<PathBuf>,

        /// Write the translation at its mapped path under the target root
        /// instead of printing it (plan 16 L2g).
        #[arg(long, default_value_t = false)]
        write: bool,

        #[arg(long, default_value_t = false)]
        list: bool,
    },
    /// Forget or rediscover source-grounded coding fragments.
    Coding(CodingArgs),
    /// Export complete conversations or convert arbitrary JSON to Links Notation.
    Context(ContextArgs),
    /// Build the issue-report document every Formal AI surface files (#839).
    Report(ReportArgs),
    /// Serve the API with request metadata by default.
    /// Set FORMAL_AI_DIALOG_LOG_DIR to opt in to full dialog capture.
    /// Structured diagnostics default to debug level in ~/.formal-ai/logs.
    Serve(ServeArgs),
    /// Use the same binary as a WebSocket or WebRTC OpenAI-compatible client.
    Connect(ConnectArgs),
    /// Run a logging reverse proxy in front of a Formal AI HTTP server.
    Proxy {
        #[arg(long, env = "FORMAL_AI_PROXY_LISTEN", default_value = "127.0.0.1:8090")]
        listen: String,

        #[arg(long, env = "FORMAL_AI_PROXY_UPSTREAM")]
        upstream: String,

        #[arg(long, env = "FORMAL_AI_PROXY_LOG", default_value = "proxy.jsonl")]
        log: PathBuf,

        /// Include complete request and response bodies in each JSONL row.
        #[arg(long, default_value_t = false)]
        body: bool,
    },
    /// Export or import the agent's append-only memory log as a portable
    /// `demo_memory` Links Notation file. Round-trips with the browser demo.
    Memory {
        #[command(subcommand)]
        action: MemoryAction,
    },
    /// Convert shared chat captures or compact transcripts into `demo_memory`.
    SharedDialog {
        #[command(subcommand)]
        action: SharedDialogAction,
    },
    /// Export or import the full self-contained `formal_ai_bundle` (seed +
    /// memory). The same file format the browser's "Download bundle" button
    /// produces.
    Bundle {
        #[command(subcommand)]
        action: BundleAction,
    },
    /// Print the environment directory baked into the seed so users can see
    /// every interface the agent supports and how to migrate memory between
    /// them.
    Environments,
    /// Print the seed-baked registry of external agentic CLI clients that
    /// `formal-ai with` can drive, including each client's protocols, endpoints,
    /// headless invocation, and persistent-config location. `--format json`
    /// makes the registry machine-readable so the multi-CLI end-to-end matrix
    /// (issue #671) derives its legs from the same data the wrapper uses.
    Clients {
        #[arg(long, value_enum, default_value_t = ClientsFormat::Text)]
        format: ClientsFormat,
        #[command(subcommand)]
        action: Option<ClientsAction>,
    },
    /// Import lexical semantics in bulk from external sources (issue #660,
    /// R378). Generalises `scripts/ground-meanings.rs` into a deterministic,
    /// validate-then-write pipeline.
    Import {
        #[command(subcommand)]
        action: ImportAction,
    },
    /// Plan or collect GitHub issue, PR, review, and Actions run evidence
    /// into a case-study directory.
    GithubLogs {
        #[command(subcommand)]
        action: GithubLogsAction,
    },
    /// Import or query the repository's formalized history (issue #1180).
    RepositoryHistory {
        #[command(subcommand)]
        action: RepositoryHistoryAction,
    },
    /// Run real upstream benchmark suites (issue #698) and record honest
    /// `passed/total` scores in `data/benchmarks/external-results.lino`.
    Benchmark {
        #[command(subcommand)]
        action: BenchmarkAction,
    },
    /// Solve one repository requirement in an isolated exact-commit clone.
    Solve {
        /// Canonical GitHub issue URL, or `-` to read the requirement on stdin.
        #[arg(long)]
        issue: Option<String>,
        /// Literal requirement text, used instead of `--issue`.
        #[arg(long)]
        task: Option<String>,
        /// Repository path, URL, or OWNER/REPO origin.
        #[arg(long, default_value = ".")]
        repository: String,
        /// Exact forty-character base commit; defaults to repository HEAD.
        #[arg(long)]
        base_commit: Option<String>,
        /// Authoring model identifier. Hosted models are refused.
        #[arg(long, default_value = "formal-ai")]
        model: String,
        /// External copy of the attributable evidence bundle.
        #[arg(long)]
        evidence: PathBuf,
        /// Canonical GitHub pull-request URL required by `--commit`.
        #[arg(long)]
        pull_request: Option<String>,
        /// Commit inside the isolated clone. Mutation is off by default.
        #[arg(long, default_value_t = false)]
        commit: bool,
        /// Live authoring loop: workspace-relative files the Agent CLI must
        /// write (repeatable).
        #[arg(long = "produces")]
        produces: Vec<String>,
        /// Live authoring loop: repository-relative landing spots, pairwise
        /// with `--produces` (repeatable; missing entries default to their
        /// `--produces` twin).
        #[arg(long = "into")]
        into: Vec<String>,
        /// Live authoring loop: repository-relative directory copied into the
        /// workspace before the run.
        #[arg(long)]
        seed: Option<String>,
        /// Live authoring loop: text at least one artifact must contain
        /// (repeatable).
        #[arg(long = "contains")]
        contains: Vec<String>,
        /// Live authoring loop: port the authoring server binds.
        #[arg(long, default_value_t = 8899)]
        port: u16,
        /// Live authoring loop: the commit subject.
        #[arg(long)]
        message: Option<String>,
    },
    /// Weigh statement-bearing repository text against captured provenance.
    StatementAudit(StatementAuditArgs),
    /// Validate repository-file summarization quality on seeded random files
    /// and enforce the published 80 percent ratchet (issue #893).
    Summarization {
        #[command(subcommand)]
        action: SummarizationAction,
    },
    /// Assess file risk signals by legal category and jurisdiction.
    FileLegality(FileLegalityArgs),
    /// Run or permanently configure external CLIs against a local Formal AI server.
    With(WithFormalAiArgs),
    /// Execute and inspect persisted natural-language procedure artifacts.
    Procedure(ProcedureArgs),
    /// Inspect learned execution-algorithm proposals without approving them.
    Algorithm(AlgorithmArgs),
    /// Execute a seeded natural-language computer-use plan inside a fresh,
    /// isolated workspace and emit its per-step verification record.
    ComputerUse(ComputerUseArgs),
    /// Drive the full agentic-coding loop offline (issue #468). The in-repo driver
    /// acts as an external CLI: it advertises tools, executes emitted calls in an
    /// offline sandbox, feeds results back, and loops until the server returns the
    /// finished Links Notation knowledge base.
    Agent(Box<AgentArgs>),
    /// Run the Telegram bot client (long polling by default; webhook server is opt-in).
    Telegram {
        #[arg(
            long,
            value_enum,
            env = "FORMAL_AI_TELEGRAM_MODE",
            default_value_t = TelegramMode::Polling
        )]
        mode: TelegramMode,

        /// Telegram bot token (required for polling mode; ignored by webhook mode).
        #[arg(long, env = "TELEGRAM_BOT_TOKEN")]
        token: Option<String>,

        /// Telegram API base URL (override for self-hosted or mocked Bot API).
        #[arg(
            long,
            env = "FORMAL_AI_TELEGRAM_API_BASE",
            default_value = "https://api.telegram.org"
        )]
        api_base: String,

        /// Long-polling timeout in seconds forwarded to Telegram's getUpdates.
        #[arg(long, env = "FORMAL_AI_TELEGRAM_TIMEOUT", default_value_t = 30)]
        timeout: u32,

        /// Maximum number of updates fetched per getUpdates call (1-100).
        #[arg(long, env = "FORMAL_AI_TELEGRAM_LIMIT", default_value_t = 100)]
        limit: u32,

        /// Comma-separated allowed update types (for example `message,edited_message`).
        #[arg(long, env = "FORMAL_AI_TELEGRAM_ALLOWED_UPDATES", default_value = "")]
        allowed_updates: String,

        /// Webhook listening host (only used when --mode=webhook).
        #[arg(long, env = "FORMAL_AI_HOST", default_value = "127.0.0.1")]
        host: String,

        /// Webhook listening port (only used when --mode=webhook).
        #[arg(long, env = "FORMAL_AI_PORT", default_value_t = 8080)]
        port: u16,
    },
    /// Benchmark-gated promotion of self-improvement proposals (issue #656, E37).
    ///
    /// Collects open promotion proposals, replays their benchmark ratchets, and
    /// prints the promotion plan. `--promote` runs the protocol; without
    /// `--apply` it is a dry run that touches no files. `--apply` materializes the
    /// accepted seed edits into `--seed-root` and requires `--confirm`; it never
    /// pushes — the branch/PR step is emitted as a plan for human review.
    Improve {
        /// Run the promotion protocol. Without it, prints usage guidance only.
        #[arg(long, default_value_t = false)]
        promote: bool,

        /// `promotion_proposals` Links Notation document containing the actual
        /// open proposals. Required with `--promote`; synthetic demonstration
        /// proposals are never a production default.
        #[arg(long, value_name = "PATH")]
        proposals: Option<PathBuf>,

        /// Workspace root the accepted seed edits are materialized into on
        /// `--apply`. Defaults to the current directory.
        #[arg(long, value_name = "PATH", default_value = ".")]
        seed_root: PathBuf,

        /// Optional memory file the promotion event chain is appended to on
        /// `--apply`.
        #[arg(long, value_name = "PATH")]
        memory: Option<PathBuf>,

        /// Materialize the accepted seed edits. Requires `--confirm`.
        #[arg(long, default_value_t = false)]
        apply: bool,

        /// Optional full-memory backup written before applying to `--memory`.
        #[arg(long)]
        backup: Option<PathBuf>,

        /// Required acknowledgement when `--apply` is used.
        #[arg(long, default_value_t = false)]
        confirm: bool,

        /// Open the applied promotion as a draft pull request instead of
        /// printing the plan for a human to run. Never targets the default
        /// branch, never marks the review ready, and never merges.
        #[arg(long, default_value_t = false)]
        open_draft_pr: bool,
    },
    /// Run the auto-learning adoption cycle over a recorded learning frontier
    /// (issue #701, E59).
    Learn {
        #[command(subcommand)]
        action: LearnAction,
    },
    /// Print the white-box derivation of a previously returned answer
    /// (issue #1184, E148): the search queries issued, the fetched URLs
    /// with their SHA-256 hashes and fetch timestamps, the formalized page
    /// fragments, the parts decomposed from retrieved examples, the
    /// recomposition, the rendering, and the verification output — read
    /// from the durable record keyed by the answer's `derivation_id`.
    /// `--format links` prints the canonical Links Notation record instead
    /// of the readable per-stage explanation. Distinct from the in-chat
    /// "explain how Formal AI works" self-explanation recipe.
    Explain {
        /// The `derivation_id` the answer carried (`answer_<16 hex digits>`).
        answer_id: String,

        #[arg(long, value_enum, default_value_t = ExplainFormat::Text)]
        format: ExplainFormat,
    },
}

#[derive(Debug, Subcommand)]
enum MemoryAction {
    /// Inspect persisted-memory compatibility without creating artifacts.
    UpgradeStatus(cli_memory::UpgradeStatusArgs),
    /// Explicitly migrate under the writer lock after a verified backup.
    Migrate(cli_memory::MigrateArgs),
    /// Write the agent's full memory (seed + event log) to a `.lino` file —
    /// the same self-contained `formal_ai_bundle` the browser's "Export
    /// memory" button produces. Pass `--events-only` to fall back to the
    /// legacy events-only `demo_memory` shape. `--path -` streams to stdout.
    Export {
        /// Destination file. Use `-` to write to stdout. Defaults to
        /// the shared per-user memory file.
        #[arg(
            long,
            env = "FORMAL_AI_MEMORY_PATH",
            default_value_os_t = formal_ai::shared_memory_path()
        )]
        path: PathBuf,

        /// Source file to read the log from. Defaults to `--path` when
        /// `--path` is a real file, and to `FORMAL_AI_MEMORY_PATH` /
        /// the shared per-user memory file when `--path -` is used.
        #[arg(long)]
        from: Option<PathBuf>,

        /// Emit only the `demo_memory` event log (no seed, no metadata).
        /// Backwards-compatible with pre-0.22 exports.
        #[arg(long, default_value_t = false)]
        events_only: bool,
    },
    /// Read a `demo_memory` Links Notation file and append its events to the
    /// destination memory log.
    Import {
        /// Source file. Use `-` to read from stdin.
        #[arg(long)]
        path: PathBuf,

        /// Destination memory log file to append to. Created if missing.
        #[arg(
            long,
            env = "FORMAL_AI_MEMORY_PATH",
            default_value_os_t = formal_ai::shared_memory_path()
        )]
        into: PathBuf,
    },
    /// Print every recorded event in human-readable form.
    Show {
        #[arg(
            long,
            env = "FORMAL_AI_MEMORY_PATH",
            default_value_os_t = formal_ai::shared_memory_path()
        )]
        path: PathBuf,
    },
    /// Execute a natural-language, ANSI/common-vendor SQL, or GraphQL memory query.
    Query {
        #[arg(
            long,
            env = "FORMAL_AI_MEMORY_PATH",
            default_value_os_t = formal_ai::shared_memory_path()
        )]
        path: PathBuf,

        /// Natural-language, SQL, or GraphQL query over the shared memory schema.
        #[arg(long)]
        prompt: String,
    },
    /// Plan low-priority memory dreaming: recomputable duplicate cleanup,
    /// cache/intermediate eviction under storage pressure, and deleted-thread
    /// purge candidates. Prints the plan by default; `--apply --confirm` is
    /// required before the memory file is changed.
    Dream {
        #[arg(
            long,
            env = "FORMAL_AI_MEMORY_PATH",
            default_value_os_t = formal_ai::shared_memory_path()
        )]
        path: PathBuf,

        /// Total capacity, in bytes, of the storage area that holds memory.
        #[arg(long)]
        storage_capacity_bytes: Option<u64>,

        /// Current free bytes in the storage area.
        #[arg(long)]
        free_bytes: Option<u64>,

        /// Bytes expected for the next write/fetch before the free-space target
        /// is evaluated.
        #[arg(long, default_value_t = 0)]
        incoming_bytes: u64,

        /// Desired free-space ratio after the next write. Defaults to 20%.
        #[arg(long, default_value_t = 20)]
        target_free_ratio_percent: u8,

        /// Turn off the default background dreaming planner for this run.
        #[arg(long, default_value_t = false)]
        disable_daydreaming: bool,

        /// Apply the selected plan actions to the memory file.
        #[arg(long, default_value_t = false)]
        apply: bool,

        /// Optional full-memory backup written before deletion.
        #[arg(long)]
        backup: Option<PathBuf>,

        /// Required acknowledgement when `--apply` is used.
        #[arg(long, default_value_t = false)]
        confirm: bool,
    },
    /// Permanently remove every event attached to conversations that were
    /// already soft-deleted in the browser conversation list. Irreversible:
    /// pass `--confirm`, and use `--backup` to export a full bundle first.
    PurgeDeleted {
        #[arg(
            long,
            env = "FORMAL_AI_MEMORY_PATH",
            default_value_os_t = formal_ai::shared_memory_path()
        )]
        path: PathBuf,

        /// Optional full-memory backup written before deletion.
        #[arg(long)]
        backup: Option<PathBuf>,

        /// Required acknowledgement for this irreversible operation.
        #[arg(long, default_value_t = false)]
        confirm: bool,
    },
    /// Permanently clear the dynamic event log so the agent starts from the
    /// built-in seed again. Irreversible: pass `--confirm`, and use
    /// `--backup` to export a full bundle first.
    Reset {
        #[arg(
            long,
            env = "FORMAL_AI_MEMORY_PATH",
            default_value_os_t = formal_ai::shared_memory_path()
        )]
        path: PathBuf,

        /// Optional full-memory backup written before deletion.
        #[arg(long)]
        backup: Option<PathBuf>,

        /// Required acknowledgement for this irreversible operation.
        #[arg(long, default_value_t = false)]
        confirm: bool,
    },
}

#[derive(Debug, Subcommand)]
enum BundleAction {
    /// Build a `formal_ai_bundle` containing the embedded seed and the
    /// current memory log, and write it to `--path` (or stdout for `-`).
    Export {
        #[arg(long, default_value = "formal-ai-bundle.lino")]
        path: PathBuf,

        /// Existing memory log to embed in the bundle. Optional.
        #[arg(long, env = "FORMAL_AI_MEMORY_PATH")]
        memory: Option<PathBuf>,
    },
    /// Read a `formal_ai_bundle` and append its memory section to the local
    /// memory log. The seed section is informational.
    Import {
        #[arg(long)]
        path: PathBuf,

        #[arg(
            long,
            env = "FORMAL_AI_MEMORY_PATH",
            default_value_os_t = formal_ai::shared_memory_path()
        )]
        into: PathBuf,
    },
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum OutputFormat {
    Text,
    Chat,
    Responses,
}

#[derive(Debug, Clone, Copy, ValueEnum, PartialEq, Eq)]
enum DefinitionFusionMode {
    Explicit,
    Auto,
}

#[derive(Debug, Clone, Copy, ValueEnum, PartialEq, Eq)]
enum TelegramMode {
    Polling,
    Webhook,
}

impl std::fmt::Display for OutputFormat {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Text => formatter.write_str("text"),
            Self::Chat => formatter.write_str("chat"),
            Self::Responses => formatter.write_str("responses"),
        }
    }
}

impl std::fmt::Display for DefinitionFusionMode {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Explicit => formatter.write_str("explicit"),
            Self::Auto => formatter.write_str("auto"),
        }
    }
}

impl std::fmt::Display for TelegramMode {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Polling => formatter.write_str("polling"),
            Self::Webhook => formatter.write_str("webhook"),
        }
    }
}

fn main() -> Result<(), Box<dyn Error>> {
    lino_arguments::init();
    // `formal-ai with <tool> …` hands everything after the tool name to that
    // tool, including flags this command also defines globally.
    let argv = delimit_tool_args(std::env::args_os().collect(), &Args::command());
    // The delimiter already separates our options from the client's, so a
    // client's own --verbose must never opt the wrapper into terminal logs.
    let explicit_verbose = argv
        .iter()
        .take_while(|argument| *argument != "--")
        .any(|argument| argument == "--verbose");
    let arguments = Args::parse_from(argv);
    formal_ai::cnl_output::configuration::configure_options(
        arguments.output_standard.as_deref(),
        arguments.lexical_density.as_deref(),
    )?;
    if matches!(&arguments.command, Some(Command::Serve(args)) if args.ephemeral()) {
        formal_ai::server::enable_ephemeral_for_current_process();
    }
    formal_ai::structured_tracing::install().map_err(std::io::Error::other)?;
    let verbose = arguments.verbose && !arguments.silent;
    formal_ai::dialog_log::configure_verbose(!arguments.silent);
    // Keep the default chat verbosity while the wrapper's normal diagnostics
    // stay in the log files. Explicit wrapper verbosity still mirrors them.
    let terminal_verbose =
        verbose && (explicit_verbose || !matches!(&arguments.command, Some(Command::With(_))));
    formal_ai::dialog_log::structured_log::configure_terminal(terminal_verbose);
    formal_ai::dialog_log::structured_log::configure(
        arguments.silent,
        matches!(arguments.command.as_ref(), Some(Command::Serve(_))),
    );
    let command = arguments.command.unwrap_or_else(|| Command::Chat {
        prompt: String::from("Hi"),
        format: OutputFormat::Text,
        definition_fusion: None,
        thinking: false,
        compute_budget: None,
        draft_count: None,
    });

    match command {
        Command::Chat {
            prompt,
            format,
            definition_fusion,
            thinking,
            compute_budget,
            draft_count,
        } => run_chat(
            &prompt,
            format,
            definition_fusion,
            thinking || verbose,
            compute_budget,
            draft_count,
        )?,
        Command::Dataset => println!("{}", knowledge_links_notation()),
        Command::Logs(arguments) => cli_logs::run_logs(&arguments),
        Command::Provenance(arguments) => cli_provenance::run_provenance(arguments)?,
        Command::Translate {
            from,
            to,
            input,
            write,
            list,
        } => run_translate(from.as_deref(), to.as_deref(), input, write, list)?,
        Command::Coding(args) => run_coding(args)?,
        Command::Context(args) => run_context(args)?,
        Command::Report(args) => run_report(args)?,
        Command::Memory { action } => run_memory(action)?,
        Command::SharedDialog { action } => run_shared_dialog(action)?,
        Command::Bundle { action } => run_bundle(action)?,
        Command::Environments => run_environments(),
        Command::Clients { format, action } => run_clients(format, action)?,
        Command::Import { action } => run_import(action)?,
        Command::GithubLogs { action } => run_github_logs(action)?,
        Command::RepositoryHistory { action } => run_repository_history(action)?,
        Command::Benchmark { action } => run_benchmark(action)?,
        Command::Solve {
            issue,
            task,
            repository,
            base_commit,
            model,
            evidence,
            pull_request,
            commit,
            produces,
            into,
            seed,
            contains,
            port,
            message,
        } => {
            let outcome = formal_ai::cli_solve::run_solve(&formal_ai::cli_solve::SolveArgs {
                issue,
                task,
                repository,
                base_commit,
                model,
                evidence,
                pull_request,
                commit,
                produces,
                into,
                seed,
                contains,
                port,
                message,
                server_executable: None,
                agent_executable: None,
            })?;
            print!("{}", outcome.diff);
            if !outcome.report.is_empty() {
                formal_ai::diagnostic!("debug"; "{}", outcome.report);
            }
            for open in outcome.open {
                formal_ai::diagnostic!("debug"; "open: {open}");
            }
        }
        Command::StatementAudit(args) => run_statement_audit(&args)?,
        Command::Summarization { action } => run_summarization(action)?,
        Command::FileLegality(args) => run_file_legality(&args)?,
        Command::With(args) => run_with_formal_ai(&args)?,
        Command::Procedure(args) => run_procedure(args)?,
        Command::Algorithm(args) => run_algorithm(args)?,
        Command::ComputerUse(args) => run_computer_use(args)?,
        Command::Agent(args) => {
            let AgentArgs {
                action,
                task,
                transcript,
                session_json,
            } = *args;
            if let Some(action) = action {
                run_external_action(action)?;
            } else {
                run_agent(&task, transcript || verbose, session_json.as_deref())?;
            }
        }
        Command::Serve(args) => {
            if args.agent_mode() {
                enable_http_agent_mode_for_current_process();
            }
            run_serve(&args)?;
        }
        Command::Connect(args) => run_connect(&args)?,
        Command::Proxy {
            listen,
            upstream,
            log,
            body,
        } => run_proxy(&ProxyConfig {
            listen,
            upstream,
            log_path: log,
            log_bodies: body || verbose,
        })?,
        Command::Telegram {
            mode,
            token,
            api_base,
            timeout,
            limit,
            allowed_updates,
            host,
            port,
        } => run_telegram(TelegramRunArgs {
            mode,
            token,
            api_base,
            timeout,
            limit,
            allowed_updates,
            host,
            port,
        })?,
        Command::Improve {
            promote,
            proposals,
            seed_root,
            memory,
            apply,
            backup,
            confirm,
            open_draft_pr,
        } => run_improve(&ImproveArgs {
            promote,
            proposals,
            seed_root,
            memory,
            apply,
            backup,
            confirm: confirm.into(),
            open_draft_pr,
        })?,
        Command::Learn { action } => run_learn_action(action)?,
        Command::Explain { answer_id, format } => run_explain(&answer_id, format)?,
    }

    Ok(())
}

pub(crate) struct TelegramRunArgs {
    pub(crate) mode: TelegramMode,
    pub(crate) token: Option<String>,
    pub(crate) api_base: String,
    pub(crate) timeout: u32,
    pub(crate) limit: u32,
    pub(crate) allowed_updates: String,
    pub(crate) host: String,
    pub(crate) port: u16,
}

pub(crate) fn read_input(path: &std::path::Path) -> Result<String, Box<dyn Error>> {
    if path.as_os_str() == "-" {
        use std::io::Read;
        let mut buf = String::new();
        std::io::stdin().read_to_string(&mut buf)?;
        return Ok(buf);
    }
    Ok(std::fs::read_to_string(path)?)
}
