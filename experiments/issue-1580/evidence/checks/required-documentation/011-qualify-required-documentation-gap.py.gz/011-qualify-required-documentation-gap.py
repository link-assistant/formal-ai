from pathlib import Path
import subprocess,json,os,tempfile
out=Path('/tmp/issue-1580-research/required-documentation-validation')
root=Path.cwd()
with tempfile.TemporaryDirectory(prefix='required-docs-gap-') as name:
 p=Path(name);(p/'.github').mkdir();(p/'.github/workflows').symlink_to(root/'.github/workflows',target_is_directory=True)
 code=f"import {{checkDocumentationPolicy}} from {json.dumps((root/'scripts/documentation-only-ci-policy.mjs').as_uri())}; console.log(checkDocumentationPolicy());"
 old=subprocess.run(['node','--input-type=module','-e',code],cwd=p,capture_output=True,text=True)
 (out/'before-missing-documentation.log').write_text(old.stdout+old.stderr)
 assert old.returncode==0,old.stderr
 code=f"import {{documentationProblems}} from {json.dumps((root/'scripts/check-required-documentation.mjs').as_uri())}; const problems=documentationProblems(process.cwd()); console.log(JSON.stringify(problems)); process.exitCode=problems.length?1:0;"
 new=subprocess.run(['node','--input-type=module','-e',code],cwd=p,capture_output=True,text=True)
 (out/'after-missing-documentation.log').write_text(new.stdout+new.stderr)
 assert new.returncode==1,new.stderr
 errors=json.loads(new.stdout)
 assert len(errors)==3 and all('ENOENT' in x for x in errors),errors
 (out/'before-after.json').write_text(json.dumps({'oldPolicyExit':old.returncode,'requiredDocumentationExit':new.returncode,'missingDocuments':errors,'realWorkflowPolicyExecuted':True,'autonomousAuthorshipCredit':0},indent=2)+'\n')
print((out/'before-after.json').read_text())
