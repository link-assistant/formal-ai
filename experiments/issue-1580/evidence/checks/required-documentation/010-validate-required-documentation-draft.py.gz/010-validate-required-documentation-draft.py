from pathlib import Path
import subprocess,os,json
out=Path('/tmp/issue-1580-research/required-documentation-validation');out.mkdir(exist_ok=True)
commands=[('documentation-regressions',['node','--test','--test-concurrency=1','rust/tests/web/documentation-only-ci-policy.test.mjs']),('required-documentation',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-required-documentation']),('documentation-policy',['node','scripts/documentation-only-ci-policy.mjs']),('whitespace',['git','diff','--check'])]
rows=[]
for name,args in commands:
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'})
 rows.append({'name':name,'exitCode':p.returncode})
(out/'outcome.json').write_text(json.dumps({'passed':all(x['exitCode']==0 for x in rows),'checks':rows},indent=2)+'\n')
print((out/'outcome.json').read_text())
