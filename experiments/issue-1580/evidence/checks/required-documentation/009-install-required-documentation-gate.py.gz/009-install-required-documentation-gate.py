from pathlib import Path
import subprocess
scratch=Path('/tmp/issue-1580-research')
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
for source,target in [('required-documentation.json','data/meta/required-documentation.json'),('check-required-documentation.mjs','scripts/check-required-documentation.mjs')]:
 assert not Path(target).exists(),target
 Path(target).write_bytes((scratch/source).read_bytes())
workflow=Path('.github/workflows/documentation-policy.yml')
text=workflow.read_text()
needle='            /package.json\n'
extra=['scripts/check-required-documentation.mjs','data/meta/required-documentation.json','README.md','CONTRIBUTING.md','CHANGELOG.md']
assert text.count(needle)==1
text=text.replace(needle,needle+''.join('            /'+p+'\n' for p in extra))
text+='      - run: node scripts/check-required-documentation.mjs\n'
workflow.write_text(text)
tests=Path('rust/tests/web/documentation-only-ci-policy.test.mjs')
text=tests.read_text()
text=text.replace("import {readFileSync, readdirSync} from 'node:fs';", "import {readFileSync, readdirSync, mkdtempSync, writeFileSync, unlinkSync, mkdirSync, rmSync} from 'node:fs';")
text=text.replace("import {posix} from 'node:path';", "import {posix, join} from 'node:path';\nimport {tmpdir} from 'node:os';\nimport {documentationProblems, requirements as requiredDocumentation} from '../../../scripts/check-required-documentation.mjs';\nimport {spawnSync} from 'node:child_process';")
needle='/package.json\\n";'
assert text.count(needle)==1
text=text.replace(needle,'/package.json\\n'+''.join('/'+p+'\\n' for p in extra)+'";')
needle="node --test rust/tests/web/documentation-only-ci-policy.test.mjs\\n'}\n"
assert text.count(needle)==1
text=text.replace(needle,"node --test rust/tests/web/documentation-only-ci-policy.test.mjs\\n'},\n      {run:'node scripts/check-required-documentation.mjs'}\n")
text=text.replace("    'scripts/documentation-only-ci-policy.mjs',\n", "    'scripts/check-required-documentation.mjs',\n    'scripts/documentation-only-ci-policy.mjs',\n")
needle="  const dependency=JSON.parse(readFileSync('scripts/documentation-policy-dependencies/package.json','utf8'));"
assert text.count(needle)==1
text=text.replace(needle,"  for (const file of ['data/meta/required-documentation.json', ...Object.keys(requiredDocumentation)]) assert.ok(covered(file), file);\n"+needle)
text+=(scratch/'required-documentation-tests.mjs').read_text()
tests.write_text(text)
Path('data/meta/ci-gates/check-required-documentation.lino').write_text('''# One CI gate, one file (issue #991).
ci_gate check-required-documentation
  stage web
  description "Required public documents exist and retain the level-two sections declared in data/meta/required-documentation.json."
  run "node scripts/check-required-documentation.mjs"
  justification "Issue #1580 and Hive Mind CI/CD best practice 12 require documentation files and headings; policy-only and rustdoc checks cannot detect a deleted README or contribution section."
''')
with Path('experiments/issue-1580/work-plan.md').open('a') as log:log.write('''

### 2026-11-22: reconcile required-documentation practice

- [x] Inspect the pinned template documentation checker and current workflow; confirm current checks do not enforce required public files and headings.
- [ ] Add one shared documentation requirement contract, bounded missing-file/heading controls, local admission and the existing lightweight hosted documentation lane; verify the complete changed gate inventory before publication.
- [ ] Continue original eight-step verifier-failure reconciliation without increasing the budget or discarding source ownership.
''')
subprocess.run(['git','diff','--check'],check=True)
print('Drafted required-documentation gate, existing-lane regression cases and sparse inputs; supplied authorship credit 0.')
