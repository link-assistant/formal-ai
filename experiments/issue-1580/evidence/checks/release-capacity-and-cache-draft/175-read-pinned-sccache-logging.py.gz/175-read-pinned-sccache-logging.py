from pathlib import Path
import subprocess,re
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-publish-cache-observations')
for source in ['src/lib.rs','src/main.rs','Cargo.toml','docs/Configuration.md','docs/Debugging.md']:
 name='sccache-'+source.replace('/','-');p=subprocess.run(['gh','api','--header','Accept: application/vnd.github.raw+json',f'repos/mozilla/sccache/contents/{source}?ref=v0.16.0'],cwd=root,capture_output=True,text=True);(out/name).write_text(p.stdout);(out/(name+'.stderr')).write_text(p.stderr);print(name,p.returncode,len(p.stdout.splitlines()))
 if p.returncode==0:
  lines=p.stdout.splitlines();chosen=set()
  for i,line in enumerate(lines):
   if re.search('SCCACHE_LOG|env_logger|Logger|logging|log::|log\\(',line):chosen.update(range(max(0,i-4),min(len(lines),i+9)))
  (out/(name+'.selected')).write_text('\n'.join(f'{i+1}: {lines[i]}' for i in sorted(chosen))+'\n')
lines=(out/'sccache-server-source.rs').read_text().splitlines();(out/'sccache-server-write-context.txt').write_text('\n'.join(f'{i+1}: {lines[i]}' for i in range(1508,1543))+'\n')
