from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'capacity-and-release-cli-verification'
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
checks=json.loads((out/'outcome.json').read_text());correction=json.loads((out/'corrected-outcome.json').read_text())
assert [r['file'] for r in checks['commands'] if r['exit']] == ['native-workflow-cache-bindings.log']
assert correction['exit']==0 and correction['sourceGuardUnchanged'] and not checks['nativeExecution']
p=root/'experiments/issue-1580/release-registry/README.md';s=p.read_text().replace('fixtures. The writer\nuses a temporary Git repository and local bare origin.','fixtures. The writer uses a temporary Git repository and local bare origin.').replace('Local Python\nfixture and syntax checks do not establish CLI success or live publication.','Local Python\nsyntax checks do not establish CLI success or live publication.');p.write_text(s)
release=['scripts/wait-for-crate.rs','scripts/detect-code-changes.rs','experiments/issue-1580/release-registry/Cargo.toml','experiments/issue-1580/release-registry/cli_regressions.py','experiments/issue-1580/release-registry/README.md']
fragment='changelog.d/20261122_complete_release_script_observations.md';(root/fragment).write_text('---\nbump: patch\n---\n\n### Fixed\n- Require the requested crate version in successful registry responses, reject incomplete release-fragment inventories before emitting job decisions, and preserve configured output paths across release tools.\n')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--',*release,fragment],cwd=root,check=True)
subprocess.run(['git','commit','-m','fix: require complete release-script observations'],cwd=root,stdout=subprocess.DEVNULL,check=True)
release_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
capacity=['.github/workflows/layered-ci.yml','rust/tests/web/ci-speed.test.mjs','rust/tests/web/default-branch-build-policy.test.mjs','rust/tests/web/fast-pull-request-production-profile.test.mjs']
fragment='changelog.d/20261122_full_javascript_shard_capacity.md';(root/fragment).write_text('---\nbump: patch\n---\n\n### Fixed\n- Split the full JavaScript inventory across nine measured groups, retaining every suite and timing record within the existing 360-second execution budget, and verify the projected queue of every group.\n')
subprocess.run(['git','add','--',*capacity,fragment],cwd=root,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
subprocess.run(['git','commit','-m','fix(ci): fit full suite within retained timing budget'],cwd=root,stdout=subprocess.DEVNULL,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
result={'releaseHead':release_head,'capacityHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'clean':True,'pushed':False,'nativeCasesExecuted':False,'allIssueAcceptanceComplete':False}
(out/'commits.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
