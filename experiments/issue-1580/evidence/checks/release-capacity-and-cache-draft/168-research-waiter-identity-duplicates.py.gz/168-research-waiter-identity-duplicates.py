from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/shared-release-observation-gaps')
repo='link-foundation/rust-ai-driven-development-pipeline-template'
queries={'identity':f'repo:{repo} "wait-for-crate" "identity"','visibility':f'repo:{repo} "wait-for-crate" in:title,body'}
for name,query in queries.items():
 p=out/(name+'-duplicates.json')
 with p.open('wb') as f:r=subprocess.run(['gh','api','--method','GET','search/issues','-f','q='+query,'-f','per_page=100','--paginate','--slurp'],cwd=root,stdout=f,stderr=subprocess.PIPE)
 print(name,r.returncode,r.stderr.decode()[:1000]);assert r.returncode==0
 for page in json.loads(p.read_text()):
  for item in page['items']:print(item['number'],item['state'],item['title'])
for number in [143,144,218,261,262,263]:
 name=f'issue-{number}.json'
 with (out/name).open('wb') as f:r=subprocess.run(['gh','api',f'repos/{repo}/issues/{number}'],cwd=root,stdout=f,stderr=subprocess.PIPE)
 print(name,r.returncode)
for number in [216,225,260]:
 with (out/f'pr-{number}.json').open('wb') as f:r=subprocess.run(['gh','pr','view',str(number),'--repo',repo,'--json','title,body,url,mergedAt,headRefOid'],cwd=root,stdout=f,stderr=subprocess.PIPE)
 print('pr',number,r.returncode)
