from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-speed-regression')
p=root/'.github/workflows/layered-ci.yml';s=p.read_text();needle='    # eight longest-first groups and unchanged execution budgets. The explicit\n';assert s.count(needle)==1
s=s.replace(needle,'    # nine longest-first groups and unchanged execution budgets. The retained\n    # timing maxima need over 12,200 worker-seconds: eight four-worker groups\n    # cannot fit that conservative projection in 360s. A ninth group retains\n    # all measurements and keeps every projected queue below the deadline.\n    # The explicit\n')
needle='        shard: [1, 2, 3, 4, 5, 6, 7, 8]\n';assert s.count(needle)==1;s=s.replace(needle,'        shard: [1, 2, 3, 4, 5, 6, 7, 8, 9]\n');assert s.count('          SHARDS: 8\n')==2;s=s.replace('          SHARDS: 8\n','          SHARDS: 9\n');p.write_text(s)
p=root/'rust/tests/web/ci-speed.test.mjs';s=p.read_text();assert s.count('planShards(files, 8, secondsOf)')==3;assert s.count('planShards([...files].reverse(), 8, secondsOf)')==3;s=s.replace('planShards(files, 8, secondsOf)','planShards(files, 9, secondsOf)').replace('planShards([...files].reverse(), 8, secondsOf)','planShards([...files].reverse(), 9, secondsOf)')
needle="""  const workers = [0, 0, 0, 0];
  for (const file of shards[selected]) {
    const worker = workers.indexOf(Math.min(...workers));
    workers[worker] += secondsOf(file);
  }
  assert(Math.max(...workers) < 360,
    'the conservative queue must fit the original four-worker job budget');""";assert s.count(needle)==1
s=s.replace(needle,"""  for (const [index, shard] of shards.entries()) {
    const workers = [0, 0, 0, 0];
    for (const file of shard) {
      const worker = workers.indexOf(Math.min(...workers));
      workers[worker] += secondsOf(file);
    }
    assert(Math.max(...workers) < 360,
      `conservative queue ${index + 1} must fit the original four-worker job budget`);
  }""");p.write_text(s)
p=root/'rust/tests/web/default-branch-build-policy.test.mjs';s=p.read_text().replace('// The same eight full-suite groups retain the deadline on every hosted profile.','// The same nine full-suite groups retain the deadline on every hosted profile.');needle="""  assert.deepEqual(Array.from(evaluate(job.strategy.matrix.shard,'pull_request','refs/pull/1500/merge')),[1,2,3,4,5,6,7,8]);
  const shards=job.steps.find(s=>s.name==='Run this shard of the JavaScript suites').env.SHARDS;
  assert.equal(evaluate(shards,'pull_request','refs/pull/1500/merge'),8);
  assert.equal(evaluate(shards,'push','refs/heads/main'),8);
  assert.equal(evaluate(job.strategy.matrix.shard,'push','refs/heads/main').length,8);""";assert s.count(needle)==1;s=s.replace(needle,needle.replace('[1,2,3,4,5,6,7,8]','[1,2,3,4,5,6,7,8,9]').replace('),8);','),9);').replace('.length,8);','.length,9);'));p.write_text(s)
p=root/'rust/tests/web/fast-pull-request-production-profile.test.mjs';s=p.read_text();needle="test('measured full JavaScript plans retain every suite within eight unchanged execution budgets'";assert s.count(needle)==1;s=s.replace(needle,needle.replace('eight','nine'))
for needle in ["['pull_request', 'refs/pull/1581/merge', 8]","['workflow_dispatch', 'refs/heads/feature', 8]","['push', 'refs/heads/main', 8]","['workflow_dispatch', 'refs/heads/main', 8]",'planShards(selected, 8, secondsOf)']:
 assert s.count(needle)==1;s=s.replace(needle,needle.replace(', 8',', 9'))
p.write_text(s)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
(out/'capacity.patch').write_bytes(subprocess.check_output(['git','diff','--','.github/workflows/layered-ci.yml','rust/tests/web/ci-speed.test.mjs','rust/tests/web/default-branch-build-policy.test.mjs','rust/tests/web/fast-pull-request-production-profile.test.mjs'],cwd=root))
print('Drafted ninth full-suite group; retain every timing, four workers, 360s deadline and 75% warning; strengthen queue assertion to every shard.')
