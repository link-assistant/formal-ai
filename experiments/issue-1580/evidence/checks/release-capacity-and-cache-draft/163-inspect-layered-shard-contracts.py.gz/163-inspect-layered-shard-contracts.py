from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-speed-regression')
for name,args in [('layered-job.log',['sed','-n','292,545p','.github/workflows/layered-ci.yml']),('shard-contracts.log',['rg','-n','SHARDS.{0,20}8|shards.{0,30}8|planShards\(files, 8|shard.{0,40}1, 2, 3, 4, 5, 6, 7, 8|of 8|eight.*shard|8.*shard','rust/tests/web','scripts/check-ci-speed.mjs','scripts/lib','experiments/formal_ai_subagent/fast-js.mjs']),('speed-read-workflows.log',['cat','scripts/lib/ci-speed-workflows.mjs'])]:
 with (out/name).open('wb') as f:r=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 print(name,r.returncode,(out/name).stat().st_size)
