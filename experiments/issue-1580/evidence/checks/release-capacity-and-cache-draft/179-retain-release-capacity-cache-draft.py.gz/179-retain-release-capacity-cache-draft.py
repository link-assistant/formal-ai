from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,gzip,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');cache=scratch/'current-publish-cache-observations';verify=scratch/'capacity-and-release-cli-verification'
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
outcome=json.loads((cache/'verification-outcome.json').read_text());assert outcome['allPassed']
assert json.loads((verify/'corrected-outcome.json').read_text())['exit']==0
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--','.github/actions/setup-sccache/action.yml','.github/workflows/native-type-check.yml','scripts/check-sccache-write-health.sh','rust/tests/web/sccache-outage-fallback.test.mjs','changelog.d/20261122_targeted_compiler_cache_observations.md'],cwd=root,check=True)
subprocess.run(['git','commit','-m','fix(ci): retain targeted compiler cache write observations'],cwd=root,check=True,stdout=subprocess.DEVNULL)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
print('CACHE_COMMIT',head)
base=root/'experiments/issue-1580/evidence/checks/release-capacity-and-cache-draft';base.mkdir(exist_ok=False)
sources=[]
for directory in ['release-cli-parity-draft','capacity-and-release-cli-verification','current-speed-regression','current-native-lint-failure','current-publish-cache-observations','shared-release-observation-gaps']:
 for path in sorted((scratch/directory).iterdir()):
  if not path.is_file() or path.name in ['pid.json','verification-pid.json','fresh-pipeline-jobs.json','all-practice-rows.log','diagnostic-context.txt','practice-summary.log']:continue
  if directory=='current-native-lint-failure' and path.name in ['heading-test-formatted.log','native-workflow-complete.log','cache-health-source.log']:continue
  sources.append(path)
controllers=['draft-release-cli-parity-regressions.py','repair-release-cli-observations.py','refine-release-cli-regressions.py','inspect-release-cli-draft.py','refine-capacity-and-read-native.py','commit-release-and-capacity-repairs.py','verify-capacity-and-release-cli-draft.py','correct-focused-wrapper-and-inspect-queue.py','inspect-current-speed-regression.py','reproduce-current-speed-regression.py','read-current-scheduling-paths.py','inspect-layered-shard-contracts.py','read-shard-policy-test.py','repair-full-suite-capacity.py','report-shared-waiter-identity.py','research-shared-release-observation-gaps.py','research-waiter-identity-duplicates.py','collect-current-native-lint-failure.py','inspect-release-heading-lint-failure.py','read-heading-contract-and-cache-diagnostics.py','repair-release-heading-native-contract.py','collect-current-publish-and-cache-observations.py','review-current-cache-diagnostic-limit.py','read-pinned-sccache-logging.py','read-env-logger-filter-contract.py','draft-targeted-cache-diagnostic-contract.py','repair-targeted-cache-observations.py','retain-release-capacity-cache-draft.py']
sources += [scratch/name for name in controllers]
records=[]
for i,path in enumerate(sources,1):
 raw=path.read_bytes();packed=gzip.compress(raw,compresslevel=6,mtime=0);name=f'{i:03d}-{path.name}.gz';(base/name).write_bytes(packed);assert gzip.decompress((base/name).read_bytes())==raw
 records.append({'source':str(path.relative_to(scratch)),'file':name,'bytes':len(raw),'lines':len(raw.splitlines()),'sha256':hashlib.sha256(raw).hexdigest(),'compressedSha256':hashlib.sha256(packed).hexdigest()})
paths=['scripts/wait-for-crate.rs','scripts/detect-code-changes.rs','scripts/release-changelog/tests.rs','experiments/issue-1580/release-registry/Cargo.toml','experiments/issue-1580/release-registry/cli_regressions.py','.github/workflows/layered-ci.yml','.github/workflows/native-type-check.yml','.github/actions/setup-sccache/action.yml','scripts/check-sccache-write-health.sh','rust/tests/web/ci-speed.test.mjs','rust/tests/web/sccache-outage-fallback.test.mjs']
manifest={'at':datetime.now(timezone.utc).isoformat(),'sourceHead':head,'publishedHead':'db19866f4383a62afd333f16077ca3522639f936','publishedBatchStillRunning':True,'hostedFailures':{'layered':{'run':45032341706,'jobs':[137238538583,137238538645],'assertion':'conservative worker queue exceeds 360-second budget','capacityRepair':'nine complete-suite shards; same workers, warning and execution limits; every queue asserted'},'native':{'run':45032342321,'job':137238752857,'rawLines':[5322,5335],'error':'first_heading_offset is never used with -D warnings','repair':'actual byte-offset regression calls helper in workflow-contract target; no warning suppression'}},'localVerification':{'fiveJavaScriptFilesPassAcrossOriginalAndCorrectedCommands':True,'initialNodeOptionsWrapperFailureRetained':True,'sevenInitialGatesPassed':True,'targetedCacheFourteenTestsPassed':True,'cacheFocusedWorkflowTestAndSixGatesPassed':True,'rustFormattingPassed':True,'pythonSyntaxPassed':True,'compiledCliMethods':25,'newNativeCasesExecuted':False,'localRustCompilation':False},'cacheObservation':{'publishedContractBuildTailRawLines':[3196,3201],'largestArgumentLineBytes':57146,'backendCauseKnown':False,'sourceGroundedProducerFilter':'debug/Error executing cache write:','source':'mozilla/sccache v0.16.0 src/lib.rs:94 and src/server.rs:1524','syntax':'env_logger v0.11.8 src/lib.rs:152','newHostedExecutionPending':True},'sharedUpstreamReport':'https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/264','upstreamReproductionSourceDerivedOnly':True,'allIssueAcceptanceComplete':False,'independentAuthorshipCredit':0,'sourceIdentities':[{'path':name,'sha256':hashlib.sha256((root/name).read_bytes()).hexdigest()} for name in paths],'files':records}
lines=['{']+[f'  {json.dumps(k)}: {json.dumps(v,separators=(",",":"))},' for k,v in manifest.items() if k!='files']+['  "files": [']+['    '+json.dumps(r,separators=(',',':'))+(',' if i+1<len(records) else '') for i,r in enumerate(records)]+['  ]','}']
text='\n'.join(lines)+'\n';assert json.loads(text)==manifest and len(lines)<1500;(base/'manifest.json').write_text(text)
section='''

## Complete release observations and full-suite capacity, 2026-11-22

- [x] Preserve both exact-head Layered failures: the retained worker estimates project about 381.8 seconds in eight shards, beyond the unchanged 360-second boundary. A local replay fails before the repair; nine full-suite shards pass all 27 CI-speed controls. The test now checks every worker queue and uses the actual 0.4-second metadata default. No tests, receipts or timing floors are removed; the warning remains 270 seconds.
- [x] Require validated version identity in the crate waiter and complete fallible changelog inventory before change-detector outputs. Extend the isolated compiled harness to ten production binaries and 25 methods, including output write failures, Unix paths, failed inventory reads and unknown registry states. Python syntax and changed-file rustfmt pass; all eight new native methods remain unexecuted until hosted CI.
- [x] Report the shared waiter defect in upstream issue 264 with exact current source and clearly source-derived reproduction limits. The Formal AI detector inventory defect is not attributed to that template.
- [x] Preserve native job 137238752857's actual unused-function error at raw lines 5322–5335. Add an actual offset regression for Unicode, CRLF, fences and missing headings so the strict workflow-contract target calls the helper. No warning is suppressed; native verification remains pending.
- [x] Preserve the failed opt-in cache observation: the actual bounded tail contains an argument record of 57,146 bytes and no backend response. Read the pinned sccache producer and env_logger filter contract; select the cache-write error message at its producer, and retain it after failed native-check jobs. The new startup contract fails before repair; all 14 cache controls, native-workflow binding and six related gates pass after it. The actual backend cause remains unknown.
- [x] Pass five focused JavaScript files across original and corrected commands, seven initial gates, Rust formatting and Python syntax. Preserve the original NODE_OPTIONS wrapper failure and its corrected command without changing the environment guard.
- [ ] Finish every current db19866f hosted job, collect all actionable failures, restore the originally absent diagnostic variable and fix the complete batch before one push. Verify the new native methods, heading contract, nine-shard schedule and targeted cache response on the exact next published source.
- [ ] Finish all wider template practices, complete source review and original runtime, delivery, trusted-epoch, serving-identity and independent-authorship criteria. Supplied patches, controllers and assessments earn zero independent credit. The PR remains draft and unmerged.

Evidence: [release, capacity and cache draft manifest](evidence/checks/release-capacity-and-cache-draft/manifest.json). Report: https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/264.
'''
plan=root/'experiments/issue-1580/work-plan.md';plan.write_text(plan.read_text()+section)
case=root/'docs/case-studies/issue-1580/release-capacity-and-cache-observations.md';case.write_text('''# Release observations, conservative shard capacity and targeted cache evidence

PR: https://github.com/link-assistant/formal-ai/pull/1581

The published db19866f batch exposes two independent failures. Layered CI jobs
137238538583 and 137238538645 fail the conservative worker-queue contract; its
retained estimates need about 381.8 seconds in eight shards. Nine complete-suite
shards fit every projected queue below the existing 360-second execution budget,
with all 27 focused controls passing. This is a planning result, not a new hosted
wall-time claim. Every test, receipt and earlier timing floor remains retained.

Native job 137238752857 fails at raw log lines 5322–5335 because the newly shared
`first_heading_offset` has no caller in the strict workflow-contract test target.
A real byte-offset contract now exercises that function with Unicode, CRLF,
fenced examples, invalid headings and missing headings. It preserves `-D warnings`;
no local native compiler or test executable ran.

The release waiter now validates registry response identity through the existing
bounded helper. Unknown success bodies and transport errors cannot confirm crate
availability. The change detector requires a complete relevant changelog inventory
before emitting job decisions, including fallible directory entries and filenames.
The native harness now builds ten production CLIs and declares 25 test methods.
Its eight additional methods still require hosted execution. Earlier 17-method
success remains bound to db19866f; it is not credited to the new cases.

The shared template waiter defect is reported in
[upstream issue 264](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/264).
That report follows complete current-source inspection. It clearly separates
source-derived outcomes from execution and does not attribute the local detector
defect to the template.

The actual opt-in cache trace also exposes an observation gap. Contract-build job
137238752864 retains only six tail records at raw lines 3196–3201. One compiler
argument record is 57,146 bytes; the bounded tail contains no backend failure.
The pinned sccache v0.16.0 producer increments `cache_write_errors` immediately
after logging `Error executing cache write:`. Its logger uses env_logger's
documented level/message-regex filter. The shared setup now selects that message
before server startup; the native job retains the bounded, URL-redacted report
even after another step fails. Defaults, cache policy and compiler outcomes are
preserved. The startup regression fails before the repair; 14 cache tests and
the native workflow binding pass afterward. This establishes local configuration
behavior and source compatibility; the real backend response remains unknown.

Five initial focused JavaScript files pass across original/corrected commands,
along with seven gates, changed-file rustfmt and Python syntax. The initial
NODE_OPTIONS wrapper failure and corrected successful command remain retained.
The cache draft additionally passes its focused workflow check and six gates.
Complete evidence, source hashes, primary-source logging excerpts and supplied
controllers are in the
[manifest](../../../experiments/issue-1580/evidence/checks/release-capacity-and-cache-draft/manifest.json).
No local Rust build, new-source hosted success, live publication, upstream
execution or independently authored Formal AI work is claimed. Current CI
collection, all broader original criteria and the draft PR remain unfinished.
''')
progress=root/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json';data=json.loads(progress.read_text());rows=data['practiceDecisions']
for index in [10,15,17,23,30]:
 row=rows[index];row['currentDraftObservation']={'at':datetime.now(timezone.utc).isoformat(),'sourceHead':head,'newNativeExecutionVerified':False,'evidence':'experiments/issue-1580/evidence/checks/release-capacity-and-cache-draft/manifest.json','assessment':{10:'The published native contract compilation exposes an unused helper under strict warnings; a real UTF-8/CRLF/fence byte-offset contract now calls it. Existing successful controls do not establish this new target compilation.',15:'The local waiter now uses the shared bounded registry helper and validates version identity. Eight new compiled CLI methods and the expanded ten-binary harness await hosted execution. Current shared-template source identity defect reported in upstream issue 264; template sparse-first behavior is not claimed for the downstream API-only waiter.',17:'Safe creator execution passes in the published 17-method CLI suite. New actual detector/collector/bump output, inventory and byte-preservation controls extend the harness to 25 methods; new cases and repaired heading target await hosted execution.',23:'The new change-detector consumer delegates to the shared fatal output writer. Actual CLI output-path tests cover directory, empty, post-open and Unix filename behavior for five output CLIs; their new native execution remains pending.',30:'The expanded compiled harness declares ten production binaries and 25 methods, covering the former detector, collector, bump and output gaps. Python syntax succeeds, but full CLI parity is not credited before the new hosted execution.'}[index]}
progress.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
paths=[str(base.relative_to(root)),'experiments/issue-1580/work-plan.md',str(case.relative_to(root)),str(progress.relative_to(root))]
subprocess.run(['git','add','--',*paths],cwd=root,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
subprocess.run(['git','commit','-m','docs: retain release, capacity and cache regression evidence'],cwd=root,check=True,stdout=subprocess.DEVNULL)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
print('ARCHIVED',len(records),'RAW_BYTES',sum(r['bytes'] for r in records),'HEAD',subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip());print('All original acceptance remains incomplete; no push performed')
