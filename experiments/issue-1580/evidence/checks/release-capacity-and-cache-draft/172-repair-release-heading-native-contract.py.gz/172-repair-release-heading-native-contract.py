from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-native-lint-failure')
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
path=root/'scripts/release-changelog/tests.rs';before=path.read_text();assert 'fn first_actual_heading_uses_byte_offsets' not in before
addition='''
#[test]
fn first_actual_heading_uses_byte_offsets_and_ignores_fenced_examples() {
    for newline in ["\\n", "\\r\\n"] {
        let prefix = [
            "# 更新履歴 🦀",
            "",
            "~~~markdown",
            "## [9.9.9]",
            "Example only.",
            "~~~",
            "## [1.2.3]suffix",
            "    ## [8.8.8]",
            "",
        ]
        .join(newline)
            + newline;
        let text = format!("{prefix}   ## [1.2.3] - 2026-11-22{newline}Notes.");
        let offset = first_heading_offset(&text).unwrap();
        assert_eq!(offset, prefix.len(), "offsets count UTF-8 bytes");
        assert!(text[offset..].starts_with("   ## [1.2.3]"));
        assert_eq!(&text.as_bytes()[..offset], prefix.as_bytes());
    }
    for text in ["", "# Changelog\\nNo releases.\\n", "```\\n## [1.2.3]\\n", "    ## [1.2.3]\\n"] {
        assert_eq!(first_heading_offset(text), None);
    }
}
'''
path.write_text(before+addition)
subprocess.run(['rustfmt','--edition','2024',str(path)],cwd=root,check=True)
with (out/'heading-contract.patch').open('w') as f:subprocess.run(['git','diff','--','scripts/release-changelog/tests.rs'],cwd=root,stdout=f,check=True)
for name,args in {
 'native-workflow-complete.log':['cat','.github/workflows/native-type-check.yml'],
 'heading-test-formatted.log':['cat','scripts/release-changelog/tests.rs'],
 'cache-health-source.log':['cat','scripts/check-sccache-write-health.sh'],
}.items():
 p=subprocess.run(args,cwd=root,capture_output=True,text=True);(out/name).write_text(p.stdout);print(name,p.returncode,len(p.stdout.splitlines()));assert p.returncode==0
with (out/'heading-rustfmt-check.log').open('wb') as f:r=subprocess.run(['rustfmt','--edition','2024','--check','scripts/release-changelog/tests.rs'],cwd=root,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0
(out/'heading-contract-outcome.json').write_text(json.dumps({'rustfmtPassed':True,'nativeExecution':False,'hostedRegressionBefore':'137238752857:5322-5335','testCallsActualPreviouslyUnusedFunction':True,'allIssueAcceptanceComplete':False},indent=2)+'\n')
print('DRAFTED targeted native heading contract; no warning suppression or native execution')
