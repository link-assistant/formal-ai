from pathlib import Path
import subprocess,json,re,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-publish-cache-observations');out.mkdir(exist_ok=True)
rows=[]
for identifier in [137238752864,137238453415]:
 path=out/f'{identifier}.log'
 with path.open('wb') as f,(out/f'{identifier}.stderr').open('wb') as err:r=subprocess.run(['gh','api','--allow-escape-sequences',f'repos/link-assistant/formal-ai/actions/jobs/{identifier}/logs'],cwd=root,stdout=f,stderr=err)
 assert r.returncode==0
 raw=path.read_text();lines=raw.splitlines();selected=set();matches=[]
 for i,line in enumerate(lines):
  clean=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',line)
  if '[sccache] ' in clean or any(s in clean for s in ['UNKNOWN','::warning title=Compiler cache','publication authority','publish authority','credential','crates.io authority']):
   matches.append(i);selected.update(range(max(0,i-2),min(len(lines),i+4)))
 context=out/f'{identifier}-selected.txt';context.write_text('\n'.join(f'{i+1}: {lines[i]}' for i in sorted(selected))+'\n')
 rows.append({'job':identifier,'lines':len(lines),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'matches':len(matches),'contextLines':len(selected)})
 print(identifier,'lines',len(lines),'selected',len(selected))
(out/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
