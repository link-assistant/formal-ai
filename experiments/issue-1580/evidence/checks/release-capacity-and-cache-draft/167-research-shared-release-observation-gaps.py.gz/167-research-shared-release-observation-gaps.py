from pathlib import Path
import subprocess,json,base64
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/shared-release-observation-gaps');out.mkdir(exist_ok=False)
repo='link-foundation/rust-ai-driven-development-pipeline-template'
for name,args in [('latest-commit.json',['gh','api',f'repos/{repo}/commits/main']),('related-issues.json',['gh','api',f'search/issues?q=repo:{repo}+wait-for-crate+in:body&per_page=100','--paginate','--slurp']),('recent-release-prs.json',['gh','pr','list','--repo',repo,'--state','merged','--search','release','--limit','10','--json','number,title,body,mergedAt,url'])]:
 with (out/name).open('wb') as f:subprocess.run(args,cwd=root,stdout=f,check=True)
head=json.loads((out/'latest-commit.json').read_text())['sha'];print('LATEST TEMPLATE',head)
for name in ['wait-for-crate.rs','detect-code-changes.rs']:
 data=json.loads(subprocess.check_output(['gh','api',f'repos/{repo}/contents/scripts/{name}?ref={head}'],cwd=root));raw=base64.b64decode(data['content']);(out/name).write_bytes(raw);print(name,'LINES',len(raw.splitlines()),'BLOB',data['sha'])
for page in json.loads((out/'related-issues.json').read_text()):
 print('RELATED COUNT',page['total_count'])
 for item in page['items']:print(item['number'],item['state'],item['title'],item['html_url'])
for item in json.loads((out/'recent-release-prs.json').read_text()):print('RECENT PR',item['number'],item['mergedAt'],item['title'],item['url'])
