from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-native-lint-failure')
for name,args in {
 'heading-tests.log':['cat','scripts/release-changelog/tests.rs'],
 'ci-changelog-tests.log':['cat','rust/tests/unit/ci-cd/changelog_parsing.rs'],
 'cache-action.log':['cat','.github/actions/setup-sccache/action.yml'],
 'cache-diagnostic-paths.log':['rg','-n','sccache-server|SCCACHE_ERROR_LOG|SCCACHE_LOG|diagnostic','scripts/ci','.github/actions/setup-sccache','rust/tests/web/sccache-outage-fallback.test.mjs','.github/workflows/native-type-check.yml'],
 'contract-manifest.log':['rg','-n','workflow_contracts|ci-cd|changelog_parsing','rust/Cargo.toml','rust/tests/workflow_contracts','rust/tests/unit/ci-cd/mod.rs'],
}.items():
 p=subprocess.run(args,cwd=root,capture_output=True,text=True);(out/name).write_text(p.stdout);(out/(name+'.stderr')).write_text(p.stderr);print(name,p.returncode,len(p.stdout.splitlines()))
