from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-publish-cache-observations')
p=subprocess.run(['gh','api','--header','Accept: application/vnd.github.raw+json','repos/rust-cli/env_logger/contents/src/lib.rs?ref=v0.11.8'],cwd=root,capture_output=True,text=True)
(out/'env-logger-0.11.8-lib.rs').write_text(p.stdout);(out/'env-logger-0.11.8-lib.rs.stderr').write_text(p.stderr);print('ENV_LOGGER',p.returncode,len(p.stdout.splitlines()));assert p.returncode==0
lines=p.stdout.splitlines();chosen=set()
for i,line in enumerate(lines):
 if any(s in line for s in ['regular expression','regex','/foo','/bar','/.*']):chosen.update(range(max(0,i-3),min(len(lines),i+9)))
(out/'env-logger-message-filter-contract.txt').write_text('\n'.join(f'{i+1}: {lines[i]}' for i in sorted(chosen))+'\n')
