from pathlib import Path
import subprocess,json,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-native-lint-failure');out.mkdir(exist_ok=True)
for name,args in {
 'job.json':['gh','api','repos/link-assistant/formal-ai/actions/jobs/137238752857'],
 'job.log':['gh','api','--allow-escape-sequences','repos/link-assistant/formal-ai/actions/jobs/137238752857/logs'],
}.items():
 with (out/name).open('wb') as f,(out/(name+'.stderr')).open('wb') as err:r=subprocess.run(args,cwd=root,stdout=f,stderr=err)
 print(name,r.returncode,(out/name).stat().st_size);assert r.returncode==0
lines=(out/'job.log').read_text().splitlines();matches=[]
for i,line in enumerate(lines):
 if any(s in line.lower() for s in ['error:','warning:','failed to','cache write','cache error','publish authority','permission denied','status code:','caused by:']):matches.append(i)
selected=set()
for i in matches:
 selected.update(range(max(0,i-4),min(len(lines),i+12)))
(out/'diagnostic-context.txt').write_text('\n'.join(f'{i+1}: {lines[i]}' for i in sorted(selected))+'\n')
(out/'manifest.json').write_text(json.dumps({'job':137238752857,'head':'db19866f4383a62afd333f16077ca3522639f936','rawLines':len(lines),'rawSha256':hashlib.sha256((out/'job.log').read_bytes()).hexdigest(),'diagnosticMatches':len(matches)},indent=2)+'\n')
print('RAW_LINES',len(lines),'MATCHES',len(matches),'CONTEXT_LINES',len(selected))
