from pathlib import Path
import subprocess,hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'release-cli-parity-draft';out.mkdir(exist_ok=False)
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
assert json.loads((scratch/'warning-batch-publication/outcome.json').read_text())['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
for name in ['detect-code-changes.rs','wait-for-crate.rs']:
 raw=(root/'scripts'/name).read_bytes();assert raw==(scratch/'remaining-release-cli-contracts'/name).read_bytes();(out/(name+'.before')).write_bytes(raw)
p=root/'experiments/issue-1580/release-registry/Cargo.toml';source=p.read_text();marker='# Compile the exact standalone sources';assert source.count(marker)==1
bins=['get-version','get-bump-type','detect-code-changes','publish-crate','wait-for-crate','collect-changelog']
source=source.replace(marker,''.join(f'[[bin]]\nname = "{name}"\npath = "../../../scripts/{name}.rs"\ntest = false\n\n' for name in bins)+marker);p.write_text(source)
p=root/'experiments/issue-1580/release-registry/cli_regressions.py';source=p.read_text();source=source.replace('def script(self, name):','def script(self, name, *extra):').replace("str(self.target / 'debug' / name.removesuffix('.rs')), *args]","str(self.target / 'debug' / name.removesuffix('.rs')), *args, *extra]")
needle="        for key in ['RUST_ROOT', 'GITHUB_TOKEN', 'DOCKERHUB_IMAGE', 'RELEASE_RECOVERY_PROTOCOL_ROOT']:"
assert needle in source;source=source.replace(needle,"        for key in ['RUST_ROOT', 'GITHUB_TOKEN', 'DOCKERHUB_IMAGE', 'RELEASE_RECOVERY_PROTOCOL_ROOT',\n                    'GITHUB_EVENT_NAME', 'GITHUB_EVENT_BEFORE', 'GITHUB_REF', 'GITHUB_BASE_REF',\n                    'RELEASE_PIPELINE', 'BUMP_TYPE', 'DESCRIPTION', 'DEFAULT']:")
tests='''
    OUTPUT_CLIS = {
        'get-version.rs': 'version=1.2.3',
        'get-bump-type.rs': 'bump_type=patch',
        'detect-code-changes.rs': 'release-pending=false',
        'publish-crate.rs': 'publish_result=skipped',
        'wait-for-crate.rs': 'crate_available=skipped',
    }

    def output_cli_fixture(self):
        # The template identity takes the real publish/wait skip paths. No cargo
        # publication or external registry request can be part of this matrix.
        manifest = self.work / 'Cargo.toml'
        manifest.write_text(manifest.read_text().replace('name="fixture"',
                                                       'name="example-sum-package-name"'))
        self.git('add', 'Cargo.toml')
        self.git('commit', '-qm', 'template identity for output-only controls')
        self.env.update(GITHUB_EVENT_NAME='push', GITHUB_REF='refs/heads/main')

    def test_each_output_cli_refuses_directory_and_empty_output_paths(self):
        self.output_cli_fixture()
        for path in [str(self.work), '']:
            self.env['GITHUB_OUTPUT'] = path
            for script in self.OUTPUT_CLIS:
                with self.subTest(script=script, path=path):
                    result = self.script(script)
                    self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
                    self.assertIn('GITHUB_OUTPUT', result.stderr)
        self.assertEqual(self.requests, [])

    @unittest.skipUnless(Path('/dev/full').exists(), 'requires the finite Linux full device')
    def test_each_output_cli_refuses_write_failure_after_open(self):
        self.output_cli_fixture()
        self.env['GITHUB_OUTPUT'] = '/dev/full'
        for script in self.OUTPUT_CLIS:
            with self.subTest(script=script):
                result = self.script(script)
                self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
                self.assertIn('GITHUB_OUTPUT', result.stderr)
        self.assertEqual(self.requests, [])

    def test_each_output_cli_appends_and_supports_unset_local_output(self):
        self.output_cli_fixture()
        for script, expected in self.OUTPUT_CLIS.items():
            with self.subTest(script=script):
                self.env['GITHUB_OUTPUT'] = str(self.output)
                self.output.write_text('existing=value\\n')
                result = self.script(script)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                output = self.output.read_text()
                self.assertTrue(output.startswith('existing=value\\n'))
                self.assertIn(expected, output.splitlines())
                del self.env['GITHUB_OUTPUT']
                result = self.script(script)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                self.assertIn(expected, result.stdout)
                self.assertEqual(self.output.read_text(), output)
        self.assertEqual(self.requests, [])

    @unittest.skipUnless(os.name == 'posix', 'Unix path-byte contract')
    def test_each_output_cli_preserves_non_utf8_output_paths(self):
        self.output_cli_fixture()
        path = os.fsdecode(os.fsencode(self.output) + b'-\\xff')
        self.env['GITHUB_OUTPUT'] = path
        for script, expected in self.OUTPUT_CLIS.items():
            with self.subTest(script=script):
                result = self.script(script)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                self.assertIn(expected, Path(path).read_text().splitlines())
        self.assertEqual(self.requests, [])

    def test_waiter_requires_the_requested_identity_and_a_complete_registry_answer(self):
        for mode in ['malformed', 'wrong-identity', '503', '429', '403', 'drop']:
            with self.subTest(mode=mode):
                self.__class__.mode = mode
                self.__class__.requests = []
                self.output.unlink(missing_ok=True)
                result = self.script('wait-for-crate.rs', '--max-attempts', '2', '--sleep-seconds', '0')
                self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
                self.assertIn('availability', result.stderr.lower())
                self.assertNotIn('crate_available=true', self.output.read_text() if self.output.exists() else '')
                self.assertLessEqual(len(self.requests), 4, 'one bounded shared lookup fails closed')
                self.assertEqual(self.git('status', '--porcelain'), '')

    def test_waiter_distinguishes_expected_absence_from_confirmed_visibility(self):
        self.__class__.mode = '404'
        result = self.script('wait-for-crate.rs', '--max-attempts', '2', '--sleep-seconds', '0')
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(len(self.requests), 2)
        self.assertFalse(self.output.exists())
        self.__class__.mode = 'success'
        result = self.script('wait-for-crate.rs', '--max-attempts', '2', '--sleep-seconds', '0')
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(self.output.read_text(), 'crate_available=true\\n')

    def test_release_change_detection_refuses_an_unreadable_fragment_inventory(self):
        (self.work / 'src/lib.rs').write_text('pub fn changed_fixture() {}\\n')
        self.git('add', 'src/lib.rs')
        self.git('commit', '-qm', 'code change requiring release classification')
        self.env.update(GITHUB_EVENT_NAME='push', GITHUB_REF='refs/heads/main', RELEASE_PIPELINE='true')
        fragments = self.work / 'changelog.d'
        fragments.write_text('not a directory')
        result = self.script('detect-code-changes.rs')
        self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn('changelog.d', result.stderr)
        self.assertFalse(self.output.exists(), 'do not emit job decisions from an incomplete inventory')
        self.assertEqual(fragments.read_text(), 'not a directory')
        fragments.unlink()
        fragments.mkdir()
        (fragments / 'fixture.MD').write_text('A release note.\\n')
        result = self.script('detect-code-changes.rs')
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn('release-pending=true', self.output.read_text().splitlines())

    def test_collect_and_bump_refuse_inventory_and_fragment_read_failures(self):
        fragments = self.work / 'changelog.d'
        fragments.write_text('not a directory')
        original = (self.work / 'CHANGELOG.md').read_bytes()
        for script in ['collect-changelog.rs', 'get-bump-type.rs']:
            with self.subTest(script=script, mode='inventory'):
                result = self.script(script)
                self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
                self.assertIn('changelog.d', result.stderr)
                self.assertEqual((self.work / 'CHANGELOG.md').read_bytes(), original)
        fragments.unlink()
        fragments.mkdir()
        good = fragments / 'good.md'
        good.write_text('---\\nbump: patch\\n---\\n\\n### Fixed\\n- Keep this note.\\n')
        broken = fragments / 'unreadable.md'
        broken.mkdir()
        for script in ['collect-changelog.rs', 'get-bump-type.rs']:
            with self.subTest(script=script, mode='fragment'):
                result = self.script(script)
                self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
                self.assertIn('unreadable.md', result.stderr)
                self.assertEqual((self.work / 'CHANGELOG.md').read_bytes(), original)
                self.assertTrue(good.is_file() and broken.is_dir())
        broken.rmdir()
        (fragments / 'README.md').write_text('Retain instructions.\\n')
        (fragments / 'notes.txt').write_text('Retain other files.\\n')
        result = self.script('collect-changelog.rs')
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertFalse(good.exists())
        self.assertEqual((fragments / 'README.md').read_text(), 'Retain instructions.\\n')
        self.assertEqual((fragments / 'notes.txt').read_text(), 'Retain other files.\\n')
        self.assertIn('### Fixed\\n- Keep this note.', (self.work / 'CHANGELOG.md').read_text())

'''
marker='    def test_fragment_content_cannot_inject_actions_commands_into_the_log(self):';assert source.count(marker)==1;source=source.replace(marker,tests+marker);compile(source,str(p),'exec');p.write_text(source)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('Drafted ten-binary isolated harness and eight native test methods. No native execution; baseline waiter still needs the ureq 3 API migration before these bins can compile.')
(out/'tests-only.patch').write_bytes(subprocess.check_output(['git','diff','--','experiments/issue-1580/release-registry'],cwd=root))
