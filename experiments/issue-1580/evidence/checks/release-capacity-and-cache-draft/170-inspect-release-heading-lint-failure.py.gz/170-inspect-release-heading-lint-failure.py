from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-native-lint-failure')
commands={
 'heading-source.log':['cat','scripts/release-changelog.rs'],
 'heading-consumers.log':['rg','-n','release_changelog|release-changelog|first_heading_offset','scripts','rust/tests/unit/ci-cd'],
 'workflow-contract-root.log':['cat','rust/tests/workflow_contracts.rs'],
 'native-diagnostics-workflow.log':['rg','-n','sccache|diagnostic|first_heading|workflow_contracts','scripts/ci-sccache-setup.mjs','.github/workflows/native-type-check.yml'],
 'all-practice-rows.log':['python3','-c',"import json,textwrap; x=json.load(open('docs/case-studies/issue-1580/templates/rust-source-review-progress.json')); [print('PRACTICE '+str(i+1)+' '+r['practice']+'\\n'+'\\n'.join(textwrap.wrap(json.dumps({k:v for k,v in r.items() if k!='practice'},ensure_ascii=False),110))+'\\n') for i,r in enumerate(x['practiceDecisions'])]"],
}
for name,args in commands.items():
 p=subprocess.run(args,cwd=root,capture_output=True,text=True);(out/name).write_text(p.stdout);(out/(name+'.stderr')).write_text(p.stderr);print(name,p.returncode,len(p.stdout.splitlines()))
job=json.loads((out/'job.json').read_text());print('FAILED_STEPS',[(s['number'],s['name'],s['conclusion']) for s in job['steps'] if s['conclusion'] not in ['success','skipped']])
