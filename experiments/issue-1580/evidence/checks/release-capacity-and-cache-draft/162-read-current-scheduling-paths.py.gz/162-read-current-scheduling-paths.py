from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-speed-regression')
commands=[('paths.log',['rg','--files','scripts','rust/tests/web','experiments/formal_ai_subagent']),('tier.log',['cat','scripts/run-js-tier-tests.sh']),('planner.log',['cat','scripts/plan-test-shards.mjs']),('admission.log',['sed','-n','1,350p','scripts/ci-pull-request-admission.mjs']),('speed-test-history.log',['git','log','-5','--oneline','--','rust/tests/web/ci-speed.test.mjs']),('workflow-selection.log',['rg','-n','ci-speed|run-js-tier|suite|SELECT|selected',' .github/workflows/layered-ci.yml'.strip()])]
for name,args in commands:
 with (out/name).open('wb') as f:r=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 print(name,r.returncode,(out/name).stat().st_size)
