from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-speed-regression')
for name,args in [('policy-test.log',['sed','-n','340,400p','rust/tests/web/default-branch-build-policy.test.mjs']),('focused-test-model.log',['sed','-n','480,540p','rust/tests/web/fast-pull-request-production-profile.test.mjs']),('speed-check.log',['cat','scripts/check-ci-speed.mjs']),('scoped-references.log',['rg','-n','SHARDS: 8|eight longest|eight source-derived|eight.*JavaScript|eight.*groups|shard: \[1, 2, 3, 4, 5, 6, 7, 8\]','scripts','rust/tests/web','.github/workflows/layered-ci.yml','docs/ci-cd'])]:
 with (out/name).open('wb') as f:r=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 print(name,r.returncode,(out/name).stat().st_size)
