from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,sys,os,traceback,time
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/capacity-and-release-cli-verification')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('wb') as f:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':p.pid})+'\n');print('FINITE FOCUSED WORKER',p.pid);sys.exit(0)
records=[]
try:
 tests=['ci-speed','default-branch-build-policy','fast-pull-request-production-profile','native-workflow-cache-bindings','ordered-javascript-test-runner']
 commands=[(name+'.log',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs']) for name in tests]
 commands.extend([('rustfmt.log',['rustfmt','--edition','2024','--config','skip_children=true','--check','scripts/wait-for-crate.rs','scripts/detect-code-changes.rs']),('python-syntax.log',['python3','-c',"from pathlib import Path; p=Path('experiments/issue-1580/release-registry/cli_regressions.py'); compile(p.read_text(),str(p),'exec'); print('Python syntax valid; no native compilation or CLI execution')"]),('diff-check.log',['git','diff','--check'])])
 gates=['check-ci-speed','check-runner-labels','workflows','check-changelog-fragment-js-twin','check-abbreviations','check-file-size','check-file-size-js-twin']
 commands.extend([('gate-'+name+'.log',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only',name]) for name in gates])
 for name,args in commands:
  start=time.monotonic()
  with (out/name).open('wb') as f:r=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
  records.append({'file':name,'args':args,'exit':r.returncode,'seconds':round(time.monotonic()-start,3)});(out/'checkpoint.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,flush=True)
 (out/'outcome.json').write_text(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'commands':records,'allPassed':all(r['exit']==0 for r in records),'nativeExecution':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()},indent=2)+'\n');raise
