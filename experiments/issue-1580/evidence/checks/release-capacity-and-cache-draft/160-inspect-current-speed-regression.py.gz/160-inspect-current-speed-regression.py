from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-speed-regression');out.mkdir(exist_ok=False)
commands=[('branch.log',['git','branch','--show-current']),('status.log',['git','status','--short']),('speed-test.log',['sed','-n','1,450p','rust/tests/web/ci-speed.test.mjs']),('related-paths.log',['rg','-n','conservative|behavior-range|default-seconds|safety|reserve|CI_TEST','scripts/ci-speed.mjs','scripts/ci-test-shards.mjs','scripts/ci-pull-request-admission.mjs','data/benchmarks/javascript-test-durations.lino'])]
for name,args in commands:
 with (out/name).open('wb') as stream:r=subprocess.run(args,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
 print(name,r.returncode,(out/name).stat().st_size)
