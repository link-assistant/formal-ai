from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/release-cli-parity-draft')
p=root/'.github/workflows/layered-ci.yml';s=p.read_text().replace('    # The explicit\n    # fast inventory remains available for local development only.','    # The explicit fast inventory remains available for local development only.');p.write_text(s)
p=root/'rust/tests/web/ci-speed.test.mjs';s=p.read_text();needle="  const secondsOf = durationLookup(recorded);";assert s.count(needle)==3;s=s.replace(needle,"  const fallback = Number(readFileSync(join(ROOT, 'data/meta/javascript-test-durations.lino'), 'utf8')\n    .match(/^  default-seconds (\\S+)$/mu)[1]);\n  const secondsOf = durationLookup(recorded, fallback);");p.write_text(s)
for name,args in [('get-bump-type.log',['cat','scripts/get-bump-type.rs']),('collect-changelog.log',['cat','scripts/collect-changelog.rs']),('manifest.log',['cat','experiments/issue-1580/release-registry/Cargo.toml']),('registry.log',['sed','-n','1,190p','scripts/registry.rs']),('waiter-final.log',['cat','scripts/wait-for-crate.rs']),('detector-final-patch.log',['git','diff','--','scripts/detect-code-changes.rs'])]:
 with (out/name).open('wb') as f:r=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 print(name,r.returncode,(out/name).stat().st_size)
