from pathlib import Path
import subprocess,json,os
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-speed-regression')
for name,args in [('shards-module.log',['cat','scripts/lib/ci-speed-shards.mjs']),('scheduler-module.log',['cat','scripts/lib/javascript-test-scheduling.mjs']),('timing-paths.log',['rg','-n','reserve|workers|planShards|parallel|concurr','scripts/plan-test-shards.mjs','scripts/lib/ci-speed-shards.mjs','scripts/lib/javascript-test-scheduling.mjs','scripts/run-js-tier-tests.sh','scripts/ci-pull-request-admission.mjs']),('before-test.log',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/ci-speed.test.mjs'])]:
 with (out/name).open('wb') as f:r=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 print(name,r.returncode,(out/name).stat().st_size)
node="""import {readFileSync,readdirSync} from 'node:fs';
import {parseTestDurations} from './scripts/lib/ci-speed-durations.mjs';
import {durationLookup,planShards} from './scripts/lib/ci-speed-shards.mjs';
const files=readdirSync('rust/tests/web').filter(n=>n.endsWith('.test.mjs')).map(n=>'rust/tests/web/'+n).sort();
const lookup=durationLookup(parseTestDurations(readFileSync('data/meta/javascript-test-durations.lino','utf8')));
const plan=planShards(files,8,lookup);console.log(JSON.stringify(plan));
for(let i=0;i<plan.shards.length;i++){let workers=[0,0,0,0];for(const f of plan.shards[i])workers[workers.indexOf(Math.min(...workers))]+=lookup(f);console.log(JSON.stringify({shard:i+1,workers,total:plan.shards[i].reduce((s,f)=>s+lookup(f),0),first:plan.shards[i].slice(0,10).map(f=>[f,lookup(f)])}));}
"""
with (out/'projection.log').open('wb') as f:r=subprocess.run(['node','--max-old-space-size=256','--input-type=module','-e',node],cwd=root,stdout=f,stderr=subprocess.STDOUT)
print('projection.log',r.returncode)
