from pathlib import Path
import subprocess,os,json
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-publish-cache-observations')
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--','scripts/release-changelog/tests.rs'],cwd=root,check=True)
subprocess.run(['git','commit','-m','test: exercise release heading offsets in native contracts'],cwd=root,check=True,stdout=subprocess.DEVNULL)
print('HEADING_COMMIT',subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip())
path=root/'rust/tests/web/sccache-outage-fallback.test.mjs';before=path.read_text();assert 'diagnostic startup selects the write-error message' not in before
addition='''
test('diagnostic startup selects the write-error message before compiler noise can displace it', t => {
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'sccache-diagnostic-filter-'));
  t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));
  const environmentFile=path.join(directory,'environment');
  const observed=spawnSync('bash',['-e','-c',step('Enable opt-in sccache diagnostics').run],{
    cwd:root,encoding:'utf8',timeout:5000,
    env:{...process.env,GITHUB_ENV:environmentFile,RUNNER_TEMP:directory},
  });
  assert.equal(observed.status,0,observed.stderr);
  const exported=Object.fromEntries(fs.readFileSync(environmentFile,'utf8').trim().split('\\n').map(line=>{
    const split=line.indexOf('=');return[line.slice(0,split),line.slice(split+1)];
  }));
  // sccache 0.16.0 uses env_logger's supported level/message-regex syntax.
  // Its server emits this exact prefix before incrementing cache_write_errors.
  assert.equal(exported.SCCACHE_LOG,'debug/Error executing cache write:');
  assert.equal(exported.SCCACHE_LOG_MILLIS,'1');
  assert.equal(exported.SCCACHE_ERROR_LOG,path.join(directory,'sccache-server.log'));
  const messageFilter=new RegExp(exported.SCCACHE_LOG.split('/')[1]);
  assert(messageFilter.test('Error executing cache write: HTTP 429 reservation refused'));
  assert(messageFilter.test('Error executing cache write: HTTP 409 concurrent key reservation'));
  assert(!messageFilter.test('parse_arguments: CannotCache(crate-type, bin): '+ 'argument '.repeat(10000)));
  assert(!messageFilter.test('handle_client: get_stats'));
  assert(action.runs.steps.indexOf(step('Enable opt-in sccache diagnostics'))<
    action.runs.steps.indexOf(step('Start the sccache server')));
});
'''
path.write_text(before+addition)
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
with (out/'targeted-filter-before.log').open('wb') as f:r=subprocess.run(['node','--max-old-space-size=256','--test','--test-concurrency=1','--test-name-pattern=diagnostic startup selects','rust/tests/web/sccache-outage-fallback.test.mjs'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode!=0,'regression must fail with the current broad logger'
print('NEW_LOGGER_CONTRACT_FAILS_BEFORE',r.returncode)
