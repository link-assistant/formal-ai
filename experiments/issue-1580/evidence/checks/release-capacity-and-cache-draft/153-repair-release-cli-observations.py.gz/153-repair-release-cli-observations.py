from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/release-cli-parity-draft')
p=root/'scripts/wait-for-crate.rs';source=p.read_text();source=source.replace('//! ureq = "2"','//! ureq = "3.5.2"\n//! serde_json = "1"')
marker='#[path = "rust-paths.rs"]\nmod rust_paths;';assert source.count(marker)==1;source=source.replace(marker,marker+'\n\n#[path = "registry.rs"]\nmod registry;')
start=source.index('fn crate_version_exists(');end=source.index('fn should_skip_crate_wait(',start);source=source[:start]+source[end:]
old='        if crate_version_exists(&crate_name, &version) {';new='''        if registry::or_exit(
            "Crates.io availability",
            registry::version_exists(&crate_name, &version),
        ) {''';assert source.count(old)==1;source=source.replace(old,new);p.write_text(source)
p=root/'scripts/detect-code-changes.rs';source=p.read_text();source=source.replace('use std::io::Write;\n','');marker='use std::process::Command;';assert source.count(marker)==1;source=source.replace(marker,marker+'\n\n#[path = "github-output.rs"]\nmod github_output;')
start=source.index('    if let Ok(output_file) = env::var("GITHUB_OUTPUT") {');end=source.index('    println!("{name}={value}");',start);source=source[:start]+'    github_output::write_output(name, value)?;\n'+source[end:]
start=source.index('/// The file names in `changelog.d/`');end=source.index('fn classify_changes(',start)
source=source[:start]+'''/// Only an absent directory is an empty inventory. Unreadable entries and
/// non-UTF-8 names cannot establish a complete release observation.
fn changelog_fragments(directory: &Path) -> std::io::Result<Vec<String>> {
    let entries = match fs::read_dir(directory) {
        Ok(entries) => entries,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
        Err(error) => {
            return Err(std::io::Error::new(
                error.kind(),
                format!("Could not read fragment inventory '{}': {error}", directory.display()),
            ));
        }
    };
    let mut names = Vec::new();
    for entry in entries {
        let entry = entry.map_err(|error| {
            std::io::Error::new(
                error.kind(),
                format!("Could not read fragment entry in '{}': {error}", directory.display()),
            )
        })?;
        let name = entry.file_name().into_string().map_err(|_| {
            std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                format!("Non-UTF-8 fragment name in '{}'", directory.display()),
            )
        })?;
        names.push(name);
    }
    names.sort();
    Ok(names)
}

'''+source[end:]
old='''    let pending = env::var("RELEASE_PIPELINE").is_ok_and(|value| value == "true")
        && automatic_release_pending(
            &env::var("GITHUB_EVENT_NAME").unwrap_or_default(),
            &env::var("GITHUB_REF").unwrap_or_default(),
            &changelog_fragments(),
            &changed_files,
        );
''';assert source.count(old)==1;source=source.replace(old,'')
marker='    let flags = classify_changes(&changed_files);';assert source.count(marker)==1
source=source.replace(marker,'''    // Establish the release inventory before emitting any job decision. Other
    // workflows do not consume it and must not acquire a new filesystem input.
    let event = env::var("GITHUB_EVENT_NAME").unwrap_or_default();
    let git_ref = env::var("GITHUB_REF").unwrap_or_default();
    let pending = if env::var("RELEASE_PIPELINE").is_ok_and(|value| value == "true")
        && event == "push"
        && git_ref == "refs/heads/main"
    {
        automatic_release_pending(
            &event,
            &git_ref,
            &changelog_fragments(Path::new("changelog.d"))?,
            &changed_files,
        )
    } else {
        false
    };

'''+marker)
p.write_text(source)
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','scripts/wait-for-crate.rs','scripts/detect-code-changes.rs'],cwd=root,check=True)
p=root/'experiments/issue-1580/release-registry/README.md';source=p.read_text().replace('the four CLI binaries','the ten CLI binaries');source+='''

The pinned template's output-I/O practice now applies to all five output-writing
counterparts: version reader, bump reader, change detector, publisher and crate
waiter. The real CLI matrix covers a directory, empty path, Linux `/dev/full`,
append behavior, unset local output and Unix non-UTF-8 output paths. Publisher and
waiter use the real template-default skip paths, so this matrix never publishes
or contacts a registry. The maintained smoke test is Bash and has no step-output
protocol; inventing one is not required to apply this practice. The collector's
inventory, fragment-read and successful-consumption cases run as a sixth added
binary and preserve README and unrelated files.

Separate loopback cases require the crate waiter's exact requested identity and
a complete response. Only HTTP 404 can mean absence; malformed success, wrong
identity and exhausted transport/status failures cannot authorize availability.
The change detector preserves case-insensitive `.md` discovery and fails before
any job decision if its relevant main-release inventory cannot be read. Other
workflow contexts do not gain a new fragment-inventory dependency.

These new native cases require hosted compilation and execution. Local Python
fixture and syntax checks do not establish CLI success or live publication.
''';p.write_text(source)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
(out/'solution.patch').write_bytes(subprocess.check_output(['git','diff','--','scripts/wait-for-crate.rs','scripts/detect-code-changes.rs','experiments/issue-1580/release-registry'],cwd=root))
print('Drafted shared bounded identity lookup, fallible complete inventory and shared output writer. No native execution and no push.')
