from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/release-cli-parity-draft')
for name,args in [('final.patch',['git','diff','--','scripts/wait-for-crate.rs','scripts/detect-code-changes.rs','experiments/issue-1580/release-registry']),('harness-final.log',['cat','experiments/issue-1580/release-registry/cli_regressions.py']),('release-helpers.log',['rg','-n','pub fn|version_exists|retry|num|read_dir|github_output','scripts/registry.rs','scripts/get-bump-type.rs','scripts/get-version.rs','scripts/publish-crate.rs','scripts/collect-changelog.rs','scripts/github-output.rs']),('local-gates-list.log',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--list'])]:
 with (out/name).open('wb') as f:r=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 print(name,r.returncode,(out/name).stat().st_size)
