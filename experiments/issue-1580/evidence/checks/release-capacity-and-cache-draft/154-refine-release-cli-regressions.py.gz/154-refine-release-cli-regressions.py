from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
p=root/'scripts/detect-code-changes.rs';s=p.read_text();needle='#[path = "github-output.rs"]\nmod github_output;';assert s.count(needle)==1;s=s.replace(needle,'#[allow(dead_code)] // This CLI uses the fallible writer and retains its own stdout format.\n'+needle);p.write_text(s)
p=root/'experiments/issue-1580/release-registry/README.md';s=p.read_text();s=s.replace('Hosted native CI runs the real HTTP/module tests and the ten CLI binaries against\n503, 429, 403, malformed-success, dropped-connection and 404 fixtures. The writer','Hosted native CI runs the real HTTP/module tests and ten CLI binaries. Registry\nconsumers cover 503, 429, 403, malformed-success, dropped-connection and 404\nfixtures. The writer');s=s.replace('\n\n\nThe pinned template', '\n\nThe pinned template');p.write_text(s)
p=root/'experiments/issue-1580/release-registry/cli_regressions.py';s=p.read_text().replace('\n\n    OUTPUT_CLIS', '\n    OUTPUT_CLIS')
needle="        self.assertEqual(fragments.read_text(), 'not a directory')\n        fragments.unlink()\n        fragments.mkdir()";assert s.count(needle)==1
s=s.replace(needle,"""        self.assertEqual(fragments.read_text(), 'not a directory')
        self.env['RELEASE_PIPELINE'] = 'false'
        result = self.script('detect-code-changes.rs')
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn('release-pending=false', self.output.read_text().splitlines())
        self.output.unlink()
        self.env['RELEASE_PIPELINE'] = 'true'
        fragments.unlink()
        result = self.script('detect-code-changes.rs')
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn('release-pending=false', self.output.read_text().splitlines())
        self.output.unlink()
        fragments.mkdir()""")
needle="        self.assertIn('release-pending=true', self.output.read_text().splitlines())\n\n    def test_collect_and_bump";assert s.count(needle)==1
s=s.replace(needle,"""        self.assertIn('release-pending=true', self.output.read_text().splitlines())
        if os.name == 'posix':
            invalid = Path(os.fsdecode(os.fsencode(fragments) + b'/invalid-\\xff.md'))
            invalid.write_text('Preserve this unclassifiable name.\\n')
            self.output.unlink()
            result = self.script('detect-code-changes.rs')
            self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn('Non-UTF-8', result.stderr)
            self.assertFalse(self.output.exists())
            self.assertTrue(invalid.exists())

    def test_collect_and_bump""")
compile(s,str(p),'exec');p.write_text(s)
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','scripts/detect-code-changes.rs'],cwd=root,check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('Keep stdout, uppercase discovery and irrelevant-workflow behavior; add missing-directory and non-UTF-8 inventory controls. No native execution.')
