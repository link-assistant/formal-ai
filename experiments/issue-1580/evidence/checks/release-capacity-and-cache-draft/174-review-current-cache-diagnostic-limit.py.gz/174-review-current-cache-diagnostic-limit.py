from pathlib import Path
import subprocess,re,json
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-publish-cache-observations')
lines=(out/'137238752864.log').read_text().splitlines();selected=[]
for n,line in enumerate(lines,1):
 if '[sccache]' in line:
  row=re.sub(r'https?://[^\s]+','<url-redacted>',line)
  selected.append({'line':n,'bytes':len(line.encode()),'complete':len(row)<=700,'display':row if len(row)<=700 else row[:700]+' [display clipped; raw retained]'})
(out/'cache-diagnostic-summary.json').write_text(json.dumps(selected,indent=2)+'\n')
for row in selected:print(row['line'],row['bytes'],row['display'])
for n,line in enumerate((out/'137238453415.log').read_text().splitlines(),1):
 if any(s in line for s in ['UNKNOWN','authority','::warning','::notice','PASS','FAIL']):print('PREFLIGHT',n,line[:1000])
for name,args in {
 'sccache-cache-source.rs':['gh','api','--header','Accept: application/vnd.github.raw+json','repos/mozilla/sccache/contents/src/cache/cache.rs?ref=v0.16.0'],
 'sccache-server-source.rs':['gh','api','--header','Accept: application/vnd.github.raw+json','repos/mozilla/sccache/contents/src/server.rs?ref=v0.16.0'],
 'health-js-tests.log':['cat','rust/tests/web/sccache-outage-fallback.test.mjs'],
}.items():
 p=subprocess.run(args,cwd=root,capture_output=True,text=True);(out/name).write_text(p.stdout);(out/(name+'.stderr')).write_text(p.stderr);print('CAPTURE',name,p.returncode,len(p.stdout.splitlines()))
