from pathlib import Path
import subprocess,json,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/shared-release-observation-gaps');repo='link-foundation/rust-ai-driven-development-pipeline-template'
assert sum(p['total_count'] for p in json.loads((out/'identity-duplicates.json').read_text()))==0
source=(out/'wait-for-crate.rs').read_bytes();assert hashlib.sha256(source).hexdigest()=='62061970a4b80182e9fab9195daf8adb1c898cc33cf8fc644532c052cb728fea'
body='''The crate waiter can announce availability without reading a valid response for the requested version. The sparse-index error classification from #143/#144 and shared registry repairs from #218/#225 are present; this concerns successful responses in the remaining waiter implementation.

Observed revision: `260ae6f826d6bff0cbfe2280098c287a4c09b3f4` (latest main when checked on 2026-11-22). Complete source: [scripts/wait-for-crate.rs](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/blob/260ae6f826d6bff0cbfe2280098c287a4c09b3f4/scripts/wait-for-crate.rs).

- `classify_api_status` maps every HTTP 200 to `Published` (lines 163–168). `check_api` never reads the response body. Empty, invalid JSON and a different `version.num` therefore authorize success.
- `index_body_has_version` splits text on the literal `"vers"` instead of parsing each JSON record (lines 131–143). A malformed line such as `not-json "vers":"1.2.3"` counts as published; an unreadable/malformed 200 without that token counts as a definitive absence.
- `combine` accepts `Published` from either source (line 175), so a failed or missing index lookup does not prevent a spurious API 200 from reaching `crate_available=true`.

Minimal loopback reproduction design for the actual waiter (no real publication): request `fixture@1.2.3`, redirect only the two production origins in a temporary copy, and run with `--max-attempts 1 --sleep-seconds 0`:

| Sparse index response | Version API response | Current source-derived result | Expected |
| --- | --- | --- | --- |
| HTTP 404 | HTTP 200, `{}` | available | unknown/error; no availability output |
| HTTP 429 | HTTP 200, `{"version":{"num":"0.0.0"}}` | available | unknown/error; no availability output |
| HTTP 200, `not-json "vers":"1.2.3"` | unused | available | unknown/error |
| HTTP 200, valid record for 1.2.3 | unused | available | available |
| HTTP 404 | HTTP 404 | absent | absent |

Suggested repair: parse complete successful bodies with the existing JSON dependency, verify the requested version (and crate identity where supplied), preserve sparse-index-first behavior and explicit unknown-versus-absent reporting, and reuse the shared bounded HTTP helper where compatible. A malformed success is not evidence of either publication or absence. Keep 404 controls, transient status/transport controls, valid unrelated index records and exact successful matches in the regression suite.

Validation boundary: this report follows a complete read of the current 542-line source and related reports/merged fixes. No upstream native executable or Rust compiler was run in this memory-limited container. The current inline test explicitly asserts that status 200 alone is published. Matching downstream real-CLI loopback cases and a shared-helper migration are drafted in [formal-ai PR #1581](https://github.com/link-assistant/formal-ai/pull/1581); their new hosted execution remains pending. The downstream change detector's separate changelog-inventory defect is not attributed to this template.

Found during the complete template comparison requested by [formal-ai issue #1580](https://github.com/link-assistant/formal-ai/issues/1580).
'''
p=out/'waiter-identity-issue-body.md';p.write_text(body)
with (out/'waiter-identity-issue-create.log').open('wb') as f:r=subprocess.run(['gh','issue','create','--repo',repo,'--title','Crate waiter accepts malformed or unrelated HTTP 200 responses as confirmed availability','--body-file',str(p)],cwd=root,stdout=f,stderr=subprocess.STDOUT)
print('UPSTREAM REPORT',r.returncode,(out/'waiter-identity-issue-create.log').read_text());assert r.returncode==0
