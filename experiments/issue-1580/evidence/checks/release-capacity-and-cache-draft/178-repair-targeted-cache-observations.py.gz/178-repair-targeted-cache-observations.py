from pathlib import Path
import subprocess,os,json,time,sys
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-publish-cache-observations')
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
if len(sys.argv)==1:
 action=root/'.github/actions/setup-sccache/action.yml';text=action.read_text();assert text.count('echo "SCCACHE_LOG=debug"')==1
 text=text.replace('echo "SCCACHE_LOG=debug"','echo "SCCACHE_LOG=debug/Error executing cache write:"')
 anchor='    - name: Enable opt-in sccache diagnostics\n'
 text=text.replace(anchor,'''    # sccache v0.16.0 uses env_logger's level/message-regex filter. Its server
    # records this prefix immediately before cache_write_errors increments.
    # A broad debug trace ended with 57 KiB compiler argument messages in run
    # 45032342321, displacing the actual backend failure from the bounded tail.
    # Filter at the producer so failed writes survive without retaining that noise.
'''+anchor)
 action.write_text(text)
 workflow=root/'.github/workflows/native-type-check.yml';text=workflow.read_text();anchor='  # Run 44918895118 exhausted the coding clock after 58/62 passing tests.\n';assert text.count(anchor)==1
 text=text.replace(anchor,'''      - name: Retain opt-in native compiler cache observations
        if: ${{ !cancelled() && inputs.compile-inputs-changed && env.FORMAL_AI_CI_VERBOSE == 'true' }}
        run: bash scripts/check-sccache-write-health.sh

'''+anchor);workflow.write_text(text)
 health=root/'scripts/check-sccache-write-health.sh';text=health.read_text();text=text.replace('# under `SCCACHE_LOG=debug`. That is wired to the `FORMAL_AI_CI_VERBOSE`','# under debug logging. The shared setup filters the producer by the exact\n# `Error executing cache write:` message so large compiler arguments cannot\n# displace the backend response. That is wired to `FORMAL_AI_CI_VERBOSE`');health.write_text(text)
 test=root/'rust/tests/web/sccache-outage-fallback.test.mjs';text=test.read_text();anchor="  assert.equal(workflow.env.FORMAL_AI_CI_VERBOSE, \"${{ vars.FORMAL_AI_CI_VERBOSE || 'false' }}\");\n";assert text.count(anchor)==1
 text=text.replace(anchor,anchor+'''  const retain=workflow.jobs.clippy.steps.find(row=>row.name==='Retain opt-in native compiler cache observations');
  assert.equal(retain.if,"${{ !cancelled() && inputs.compile-inputs-changed && env.FORMAL_AI_CI_VERBOSE == 'true' }}");
  assert.equal(retain.run,'bash scripts/check-sccache-write-health.sh');
  assert.equal(workflow.jobs.clippy.steps.at(-1),retain,'retain failures after the last compiler command');
''');test.write_text(text)
 (root/'changelog.d/20261122_targeted_compiler_cache_observations.md').write_text('''---
bump: patch
---

Retain targeted opt-in compiler-cache write failures before compiler argument logs can displace them, including failed native-check jobs.
''')
 with (out/'cache-observation-repair.patch').open('w') as f:subprocess.run(['git','diff','--','.github/actions/setup-sccache/action.yml','.github/workflows/native-type-check.yml','scripts/check-sccache-write-health.sh','rust/tests/web/sccache-outage-fallback.test.mjs'],cwd=root,stdout=f,check=True)
 with (out/'verification-worker.log').open('wb') as log:p=subprocess.Popen([sys.executable,__file__,'verify'],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'verification-pid.json').write_text(json.dumps({'pid':p.pid})+'\n');print('DRAFTED targeted source filter and final-job observation; VERIFY_PID',p.pid);sys.exit(0)
env=dict(os.environ);env.pop('NODE_OPTIONS',None);results=[]
commands=[('targeted-filter-after.log',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/sccache-outage-fallback.test.mjs']),('native-workflow-after.log',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/native-workflow-cache-bindings.test.mjs']),('shell-syntax.log',['bash','-n','scripts/check-sccache-write-health.sh']),('diff-check.log',['git','diff','--check'])]
commands +=[(f'cache-gate-{gate}.log',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]) for gate in ['workflows','check-runner-labels','check-changelog-fragment-js-twin','check-abbreviations','check-file-size','check-file-size-js-twin']]
for name,args in commands:
 start=time.monotonic()
 with (out/name).open('wb') as log:r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 result={'file':name,'args':args,'exit':r.returncode,'seconds':round(time.monotonic()-start,3)};results.append(result);print(json.dumps(result),flush=True)
 (out/'verification-latest.json').write_text(json.dumps({'commands':results},indent=2)+'\n')
(out/'verification-outcome.json').write_text(json.dumps({'commands':results,'allPassed':all(r['exit']==0 for r in results),'nativeExecution':False,'actualBackendCauseVerified':False,'independentAuthorshipCredit':0},indent=2)+'\n')
