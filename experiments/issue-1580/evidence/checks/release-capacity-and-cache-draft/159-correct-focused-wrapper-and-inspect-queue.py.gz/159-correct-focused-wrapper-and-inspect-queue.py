from pathlib import Path
import subprocess,os,json,time
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/capacity-and-release-cli-verification')
env=dict(os.environ);removed=env.pop('NODE_OPTIONS',None) is not None
args=['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/native-workflow-cache-bindings.test.mjs'];start=time.monotonic()
with (out/'native-workflow-cache-bindings-corrected.log').open('wb') as f:r=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
(out/'corrected-outcome.json').write_text(json.dumps({'exit':r.returncode,'seconds':round(time.monotonic()-start,3),'removedAmbientNodeOptions':removed,'sourceGuardUnchanged':True,'nativeExecution':False},indent=2)+'\n');print('NATIVE SOURCE BINDING TEST',r.returncode)
path=out/'fresh-pipeline-jobs.json'
with path.open('wb') as f:subprocess.run(['gh','api','repos/link-assistant/formal-ai/actions/runs/45032342321/jobs?per_page=100','--paginate','--slurp'],cwd=root,stdout=f,check=True)
for page in json.loads(path.read_text()):
 for j in page['jobs']:print(j['id'],j['name'],j['status'],j['conclusion'],j.get('started_at'))
