from pathlib import Path
import json,hashlib,subprocess
out=Path('/tmp/issue-1580-research/rust-source-warning-headroom')
extra=out/'worker-and-indexes'
extra.mkdir(exist_ok=False)
test=Path('experiments/issue-1580/rust-warning-headroom.test.mjs')
s=test.read_text()
paths=['js/worker/formal_ai_worker_coding_idioms_and_text_manipulation.js','js/worker/formal_ai_worker_arithmetic_and_numeric_lists.js','js/worker/formal_ai_worker_solve.js','js/worker/formal_ai_worker_solver_events.js']
twins=[p.replace('js/worker/','ts/worker/').removesuffix('.js')+'.ts' for p in paths]
indexes=['experiments/issue-1580/evidence/checks/java-historical-forward-035/manifest.json','experiments/issue-1580/evidence/checks/template-delta-20261122/manifest.json']
s=s.replace('const files = [','const files = [\n'+''.join("  "+json.dumps(p)+",\n" for p in paths+twins+indexes))
s=s.replace('reported Rust source warnings','reported source warnings')
test.write_text(s)
with (extra/'before.stdout').open('w') as a,(extra/'before.stderr').open('w') as b:
    before=subprocess.run(['timeout','600','node','--test','--test-concurrency=1',str(test)],stdout=a,stderr=b)
assert before.returncode!=0
moves=[]
for path,marker,destination in [(paths[0],'function numericListProgramLinks(',paths[1]),(paths[2],'function finalize(',paths[3])]:
    p=Path(path); dst=Path(destination)
    src=p.read_text(); original_dst=dst.read_text()
    (extra/(p.name+'.before')).write_text(src)
    (extra/(dst.name+'.before')).write_text(original_dst)
    start=src.index(marker); end=src.index('\n}\n',start)+3
    moved=src[start:end]
    p.write_text(src[:start]+src[end:].lstrip('\n'))
    dst.write_text(original_dst.rstrip()+'\n\n'+moved)
    assert p.read_text()+moved != src
    assert p.read_text()==src[:start]+src[end:].lstrip('\n')
    assert dst.read_text().endswith(moved)
    moves.append({'source':path,'destination':destination,'movedBytes':len(moved.encode()),'movedSha256':hashlib.sha256(moved.encode()).hexdigest(),'sourceBeforeSha256':hashlib.sha256(src.encode()).hexdigest(),'destinationBeforeSha256':hashlib.sha256(original_dst.encode()).hexdigest(),'bodyPreserved':True})
def render(value,level=0):
    compact=json.dumps(value,ensure_ascii=False)
    indent='  '*level
    if '\n' not in compact and len(indent+compact)<=180:
        return compact
    if isinstance(value,list):
        return '[\n'+',\n'.join('  '*(level+1)+render(v,level+1) for v in value)+'\n'+indent+']'
    if isinstance(value,dict):
        return '{\n'+',\n'.join('  '*(level+1)+json.dumps(k,ensure_ascii=False)+': '+render(v,level+1) for k,v in value.items())+'\n'+indent+'}'
    return compact
formats=[]
for i,path in enumerate(indexes):
    p=Path(path); raw=p.read_bytes(); old=json.loads(raw)
    (extra/f'index-{i}.before.json').write_bytes(raw)
    p.write_text(render(old)+'\n')
    assert json.loads(p.read_bytes())==old
    formats.append({'path':path,'beforeSha256':hashlib.sha256(raw).hexdigest(),'afterSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'beforeLines':len(raw.splitlines()),'afterLines':len(p.read_bytes().splitlines()),'allJsonValuesPreserved':True})
(extra/'preservation.json').write_text(json.dumps({'moves':moves,'formats':formats},indent=2)+'\n')
print(json.dumps({'moves':moves,'formats':formats}))
