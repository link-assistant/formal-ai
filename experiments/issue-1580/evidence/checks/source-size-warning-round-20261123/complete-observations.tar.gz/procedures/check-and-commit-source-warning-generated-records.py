from pathlib import Path
import subprocess,json
root=Path("/tmp/issue-1580-research/source-warning-generated-records")
before=json.loads((root/"runtime-feature-coverage.json.before").read_text())
after=json.loads(Path("data/meta/runtime-feature-coverage.json").read_text())
for k in before.keys()|after.keys():
 if before.get(k)!=after.get(k):
  print("inventory field",k)
  if isinstance(before.get(k),list):
   old=before[k]; new=after[k]
   for i in range(max(len(old),len(new))):
    if i>=len(old) or i>=len(new) or old[i]!=new[i]:print(json.dumps({"index":i,"before":old[i] if i<len(old) else None,"after":new[i] if i<len(new) else None}))
  else:print(json.dumps({"before":before.get(k),"after":after.get(k)}))
checks=[]
commands=[["timeout","600","node","--test","--test-concurrency=1",p] for p in ["rust/tests/web/runtime-feature-inventory.test.mjs","rust/tests/web/r999-worker-budget-rationale.test.mjs"]]
commands += [["node","experiments/formal_ai_subagent/local-gates.mjs","--only",g] for g in ["check-runtime-feature-inventory","check-worker-line-budget-js-twin","check-worker-line-budget"]]
for i,c in enumerate(commands):
 with (root/("check-"+str(i)+".stdout")).open("w") as out,(root/("check-"+str(i)+".stderr")).open("w") as err:
  p=subprocess.run(c,stdout=out,stderr=err)
 checks.append({"command":c,"exitCode":p.returncode})
 print(json.dumps(checks[-1]),flush=True)
(root/"focused-outcome.json").write_text(json.dumps(checks,indent=2)+"\n")
assert all(x["exitCode"]==0 for x in checks)
subprocess.run(["git","diff","--check"],check=True)
subprocess.run(["git","add","data/meta/runtime-feature-coverage.json","data/meta/worker-line-budget/formal_ai_worker_arithmetic_and_numeric_lists.lino","data/meta/worker-line-budget/formal_ai_worker_coding_idioms_and_text_manipulation.lino","data/meta/worker-line-budget/formal_ai_worker_solve.lino","data/meta/worker-line-budget/formal_ai_worker_solver_events.lino","docs/case-studies/issue-1580/source-size-warnings-20261123.md"],check=True)
subprocess.run(["git","commit","-m","fix: keep generated coverage and module budgets current after source moves"],check=True)
assert not subprocess.check_output(["git","status","--porcelain"],text=True).strip()
