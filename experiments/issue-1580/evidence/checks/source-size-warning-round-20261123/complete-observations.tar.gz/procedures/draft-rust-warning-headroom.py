import hashlib,json,subprocess
from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/rust-source-warning-headroom')
out.mkdir(exist_ok=False)
paths=['scripts/detect-code-changes.rs','rust/src/coding/list_program.rs','rust/tests/unit/specification/chat_surface.rs','rust/tests/unit/specification/debug_session.rs']
test=root/'experiments/issue-1580/rust-warning-headroom.test.mjs'
test.write_text("""import assert from 'node:assert/strict';
import test from 'node:test';
import {fileURLToPath} from 'node:url';
import {checkListedFiles} from '../../scripts/check-file-size.mjs';

const root = fileURLToPath(new URL('../../', import.meta.url)).replace(/\\/$/u, '');
const files = [
  'scripts/detect-code-changes.rs',
  'scripts/detect-code-changes-tests.rs',
  'rust/src/coding/list_program.rs',
  'rust/src/coding/list_program/literals.rs',
  'rust/tests/unit/specification/chat_surface.rs',
  'rust/tests/unit/specification/chat_surface/rule_details.rs',
  'rust/tests/unit/specification/debug_session.rs',
  'rust/tests/unit/specification/debug_session/calculator_origins.rs',
];
test('reported Rust source warnings have headroom under the maintained policy', {timeout: 10000}, () => {
  const observed = checkListedFiles(root, new Set(files));
  assert.deepEqual(observed.errors, []);
  assert.deepEqual(observed.violations, []);
  assert.deepEqual(observed.warnings, []);
});
""")
def run(label,cmd):
    value=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (out/(label+'.stdout')).write_bytes(value.stdout)
    (out/(label+'.stderr')).write_bytes(value.stderr)
    return value.returncode
before=run('before',['timeout','600','node','--test','--test-concurrency=1',str(test)])
assert before!=0,'Expected the unchanged source policy to reproduce current warnings'
changes=[]
def move(path,marker,dest,header,registration,replacement=None):
    original=(root/path).read_bytes()
    (out/(Path(path).name+'.before')).write_bytes(original)
    text=original.decode()
    assert text.count(marker)==1,(path,marker)
    at=text.index(marker)
    moved=text[at:]
    if replacement:
        old,new=replacement
        assert moved.count(old)==1
        moved=moved.replace(old,new)
    target=root/dest
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(header+moved)
    (root/path).write_text(text[:at].rstrip()+'\n\n'+registration+'\n')
    changes.append({'source':path,'destination':dest,'preimageSha256':hashlib.sha256(original).hexdigest(),'preimageLines':len(original.splitlines()),'originalSuffixSha256':hashlib.sha256(text[at:].encode()).hexdigest(),'movedSuffixSha256':hashlib.sha256(moved.encode()).hexdigest(),'onlyMovedVisibilityChange':replacement})
move(paths[0],'#[cfg(test)]\nmod tests {','scripts/detect-code-changes-tests.rs','',
     '#[cfg(test)]\n#[path = "detect-code-changes-tests.rs"]\nmod tests;',
     ('#[cfg(test)]\nmod tests {\n',''))
# The original module body needs dedenting, but no Rust source token changes.
p=root/'scripts/detect-code-changes-tests.rs'
s=p.read_text()
assert s.endswith('}\n')
s=s[:-2]
assert all(not line or line.startswith('    ') for line in s.splitlines())
p.write_text('\n'.join(line[4:] if line else '' for line in s.splitlines())+'\n')
move(paths[1],'pub(crate) fn parse_list_items(','rust/src/coding/list_program/literals.rs',
     '//! Literal extraction shared by numeric-list requests.\nuse super::{ListValue, Operation, ParsedListItem};\n\n',
     'mod literals;\npub use literals::{names_list_items, parse_numbers};\npub(crate) use literals::parse_list_items;')
move(paths[2],'#[test]\nfn self_facts_answer_includes_model_id_and_strategy()','rust/tests/unit/specification/chat_surface/rule_details.rs',
     'use super::*;\n\n','mod rule_details;')
move(paths[3],'#[test]\nfn calculator_folding_retains_each_origin_and_clears_it_between_clusters()','rust/tests/unit/specification/debug_session/calculator_origins.rs',
     '', 'mod calculator_origins;')
allpaths=paths+['scripts/detect-code-changes-tests.rs','rust/src/coding/list_program/literals.rs','rust/tests/unit/specification/chat_surface/rule_details.rs','rust/tests/unit/specification/debug_session/calculator_origins.rs']
assert run('rustfmt',['rustfmt','--edition','2024','--config','skip_children=true']+allpaths)==0
assert run('after',['timeout','600','node','--test','--test-concurrency=1',str(test)])==0
for c in changes:
    c['sourceLines']=len((root/c['source']).read_bytes().splitlines())
    c['destinationLines']=len((root/c['destination']).read_bytes().splitlines())
    c['sourceSha256']=hashlib.sha256((root/c['source']).read_bytes()).hexdigest()
    c['destinationSha256']=hashlib.sha256((root/c['destination']).read_bytes()).hexdigest()
(out/'extractions.json').write_text(json.dumps(changes,indent=2)+'\n')
(out/'outcome.json').write_text(json.dumps({'beforeExitCode':before,'afterExitCode':0,'changes':changes,'localRustCompilation':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps({'changes':changes,'beforeExitCode':before,'afterExitCode':0}))
