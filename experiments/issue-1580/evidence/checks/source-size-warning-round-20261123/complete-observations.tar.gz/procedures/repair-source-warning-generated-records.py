from pathlib import Path
import json,subprocess
r=Path("/tmp/issue-1580-research/source-warning-generated-records")
r.mkdir(exist_ok=False)
changes=[("arithmetic_and_numeric_lists",786,814,"Receives the unchanged numericListProgramLinks body from the coding-idioms module."),("coding_idioms_and_text_manipulation",1425,1393,"Transfers the unchanged numericListProgramLinks body to the arithmetic module."),("solve",1416,1359,"Transfers the unchanged finalize body to the solver-events module."),("solver_events",355,413,"Receives the unchanged finalize body from the solve module.")]
records=[]
for n,old,new,why in changes:
 p=Path("data/meta/worker-line-budget/formal_ai_worker_"+n+".lino")
 before=p.read_text()
 assert "\n  ceiling "+str(old)+"\n" in before
 (r/(p.name+".before")).write_text(before)
 after=before.replace("\n  ceiling "+str(old)+"\n","\n  ceiling "+str(new)+"\n")
 suffix=" Issue #1580 source-size repair (2026-11-23): "+why+" The four affected ceilings sum to 3979, below their previous 3982; source conservation and the unchanged line-budget gate remain required."
 assert after.endswith('"\n')
 after=after[:-2]+suffix+'"\n'
 p.write_text(after)
 records.append({"path":str(p),"before":old,"after":new,"reason":why})
assert sum(x["after"] for x in records)<=sum(x["before"] for x in records)
p=Path("data/meta/runtime-feature-coverage.json")
(r/"runtime-feature-coverage.json.before").write_bytes(p.read_bytes())
with (r/"runtime-generation.stdout").open("w") as out,(r/"runtime-generation.stderr").open("w") as err:
 result=subprocess.run(["node","scripts/generate-runtime-feature-inventory.mjs","--write"],stdout=out,stderr=err)
result.check_returncode()
(r/"changes.json").write_text(json.dumps(records,indent=2)+"\n")
p=Path("docs/case-studies/issue-1580/source-size-warnings-20261123.md")
s=p.read_text()
needle="The evidence indexes retain multiline JSON"
insert="The first full local run found stale generated coverage and per-module line\nbudgets after these moves. The maintained generator refreshes the coverage\ninventory. Only the four affected budget shards change: their combined ceiling\nfalls from 3982 to 3979 lines, with each transfer explained in its rationale.\nThe per-module check and the 3000-line migration target remain enforced.\n\n"
assert needle in s
p.write_text(s.replace(needle,insert+needle))
print(json.dumps(records))
