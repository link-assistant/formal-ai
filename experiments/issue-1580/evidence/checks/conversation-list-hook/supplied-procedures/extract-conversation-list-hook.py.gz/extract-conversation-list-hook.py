from pathlib import Path
import gzip,hashlib,json,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'conversation-list-hook-extraction'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args,expected=0):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==expected,(name,r.returncode)
try:
 app=root/'js/app/application.jsx';hooks=root/'js/app/application-conversation-hooks.jsx';original=app.read_text();oldhooks=hooks.read_text()
 target=root/'experiments/issue-1580/evidence/checks/conversation-list-hook';target.mkdir(exist_ok=False)
 (target/'application-before.jsx.gz').write_bytes(gzip.compress(original.encode(),mtime=0))
 (target/'hooks-before.jsx.gz').write_bytes(gzip.compress(oldhooks.encode(),mtime=0))
 test=root/'experiments/issue-1580/application-conversation-list.test.mjs'
 test.write_text('''import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import vm from 'node:vm';
import { test } from 'node:test';

const app = new URL('../../js/app/application.jsx', import.meta.url);
const hooks = new URL('../../js/app/application-conversation-hooks.jsx', import.meta.url);
const before = new URL('./evidence/checks/conversation-list-hook/application-before.jsx.gz', import.meta.url);
const read = url => readFileSync(url, 'utf8');
const segments = [
  ['  // Issue #27: on mount', '  const {\\n    handleExportMemory'],
  ['  const handleShowDeletedConversations =', '  const { handleContextResizePointerDown'],
  ['  const handleDeleteConversation =', '  // Issue #386: copy a whole conversation'],
];
const plain = value => JSON.parse(JSON.stringify(value));

test('authored App remains below its existing source warning threshold', () => {
  assert.ok(read(app).trimEnd().split('\\n').length < 1400);
});

test('the complete conversation-list bodies and comments remain unchanged', () => {
  const original = gunzipSync(readFileSync(before)).toString('utf8');
  for (const [start, end] of segments) {
    const body = original.slice(original.indexOf(start), original.indexOf(end));
    assert.ok(read(hooks).includes(body), start);
    assert.ok(!read(app).includes(body), start);
  }
  assert.match(read(app), /} = useConversationList\\(\\{/);
});

function mount({ events = [], unavailable = false, error = null } = {}) {
  const effects = [], recorded = [], values = {}, calls = [];
  const memory = { listEvents: async () => { if (error) throw error; return events; } };
  const context = vm.createContext({
    React: { useCallback: fn => fn, useEffect: fn => effects.push(fn) },
    window: unavailable ? undefined : { FormalAiMemory: memory },
    groupConversations: (rows, options) => {
      calls.push({ rows, options });
      return rows.filter(row => options.showDeleted || !row.deleted);
    },
    messagesForConversation: (rows, id) => rows.filter(row => row.id === id),
    recordMemoryEvent: async event => recorded.push(event),
  });
  const source = read(hooks).replace(/^import[\\s\\S]*?;\\n/gm, '').replace(/export function /g, 'function ');
  vm.runInContext(source + '\\nglobalThis.load = useConversationList;', context);
  const props = {
    initialPreferences: { current: { currentConversationId: 'current' } },
    conversationEventsRef: { current: [] }, conversationTitlesRef: { current: new Map() },
    showDeletedConversationsRef: { current: false }, currentConversationRef: { current: 'current' },
  };
  for (const key of ['Conversations', 'Messages', 'DemoMode', 'CurrentConversationId', 'Prompt', 'ShowDeletedConversations']) {
    props['set' + key] = value => { values[key] = value; };
  }
  return { api: context.load(props), props, effects, recorded, values, calls };
}

test('refresh preserves deletion selection, cached events and known titles', async () => {
  const events = [{ id: 'current', title: 'Current' }, { id: 'old', title: 'Old', deleted: true }];
  const state = mount({ events });
  assert.equal(await state.api.refreshConversations(), events);
  assert.equal(state.props.conversationEventsRef.current, events);
  assert.deepEqual(state.values.Conversations, events.slice(0, 1));
  assert.equal(state.props.conversationTitlesRef.current.get('current'), 'Current');
  state.props.showDeletedConversationsRef.current = true;
  await state.api.refreshConversations();
  assert.deepEqual(state.values.Conversations, events);
  await state.api.refreshConversations(false);
  assert.deepEqual(state.values.Conversations, events.slice(0, 1));
  state.api.handleShowDeletedConversations({ target: { checked: 1 } });
  await Promise.resolve();
  assert.equal(state.values.ShowDeletedConversations, true);
  assert.equal(state.calls.at(-1).options.showDeleted, true);
});

test('unavailable and failed memory retain the empty projection contract', async () => {
  for (const options of [{ unavailable: true }, { error: new Error('unreadable memory') }]) {
    const state = mount(options);
    assert.deepEqual(plain(await state.api.refreshConversations()), []);
    assert.deepEqual(plain(state.props.conversationEventsRef.current), []);
    assert.deepEqual(state.values, {});
  }
});

test('initial hydration restores the selected thread and respects unmount', async () => {
  const events = [{ id: 'current', title: 'Current' }, { id: 'other', title: 'Other' }];
  for (const cancelled of [false, true]) {
    const state = mount({ events });
    const cleanup = state.effects[0]();
    if (cancelled) cleanup();
    await Promise.resolve(); await Promise.resolve();
    if (cancelled) {
      assert.equal(state.values.Messages, undefined);
      assert.equal(state.values.DemoMode, undefined);
    } else {
      assert.deepEqual(state.values.Messages, events.slice(0, 1));
      assert.equal(state.values.DemoMode, false);
    }
  }
});

test('deletion records an event, clears only the selected thread and refreshes', async () => {
  for (const id of ['current', 'other']) {
    const state = mount();
    await state.api.handleDeleteConversation({ id, title: 'Saved title' });
    assert.equal(state.recorded.length, 1);
    assert.equal(state.recorded[0].kind, 'conversation_deleted');
    assert.equal(state.recorded[0].conversationId, id);
    assert.equal(state.recorded[0].conversationTitle, 'Saved title');
    assert.ok(!Number.isNaN(Date.parse(state.recorded[0].sentAt)));
    assert.equal(state.values.ShowDeletedConversations, false);
    assert.equal(state.calls.at(-1).options.showDeleted, false);
    if (id === 'current') {
      assert.equal(state.props.currentConversationRef.current, '');
      assert.equal(state.values.CurrentConversationId, '');
      assert.deepEqual(plain(state.values.Messages), []);
      assert.equal(state.values.Prompt, '');
      assert.equal(state.values.DemoMode, false);
    } else {
      assert.equal(state.props.currentConversationRef.current, 'current');
      assert.equal(state.values.Messages, undefined);
    }
    await state.api.handleDeleteConversation(null);
    await state.api.handleDeleteConversation({});
    assert.equal(state.recorded.length, 1);
  }
});
''')
 run('warning-before',['node','--max-old-space-size=256','--test','--test-concurrency=1','--test-name-pattern=authored App remains',str(test)],1)
 markers=[('  // Issue #27: on mount','  const {\n    handleExportMemory'),('  const handleShowDeletedConversations =','  const { handleContextResizePointerDown'),('  const handleDeleteConversation =','  // Issue #386: copy a whole conversation')]
 bodies=[];updated=original
 for start,end in markers:
  body=original[original.index(start):original.index(end)];assert body and original.count(body)==1;bodies.append(body)
 call='''  const { refreshConversations, handleShowDeletedConversations, handleDeleteConversation } = useConversationList({
    initialPreferences, conversationEventsRef, conversationTitlesRef, showDeletedConversationsRef,
    currentConversationRef, setConversations, setMessages, setDemoMode, setCurrentConversationId,
    setPrompt, setShowDeletedConversations,
  });

'''
 updated=updated.replace(bodies[0],call).replace(bodies[1],'').replace(bodies[2],'')
 updated=updated.replace('useConversationMessages, useInterfaceCommands','useConversationList, useConversationMessages, useInterfaceCommands').replace('conversationToMarkdown, groupConversations, localizeTool','conversationToMarkdown, localizeTool').replace('import { recordMemoryEvent } from "./memory-events.jsx";\n','')
 hook='''// Projects the append-only conversation event log and owns sidebar list actions.
export function useConversationList({
  initialPreferences, conversationEventsRef, conversationTitlesRef, showDeletedConversationsRef,
  currentConversationRef, setConversations, setMessages, setDemoMode, setCurrentConversationId,
  setPrompt, setShowDeletedConversations,
}) {
'''+''.join(bodies)+'''  return { refreshConversations, handleShowDeletedConversations, handleDeleteConversation };
}

'''
 newhooks=oldhooks.replace('  createMessage, deriveConversationTitle, generateConversationId,','  createMessage, deriveConversationTitle, generateConversationId, groupConversations, messagesForConversation,').replace('// Appends user/system/assistant messages',hook+'// Appends user/system/assistant messages',1)
 app.write_text(updated);hooks.write_text(newhooks)
 assert len(updated.splitlines())<1400
 entry=root/'rust/tests/web/issue-1580-template-observations.test.mjs';entry.write_text(entry.read_text()+"\nimport '../../../experiments/issue-1580/application-conversation-list.test.mjs';\n")
 (target/'body-conservation.json').write_text(json.dumps({'sourceSha256':hashlib.sha256(original.encode()).hexdigest(),'bodies':[{'sha256':hashlib.sha256(body.encode()).hexdigest(),'bytes':len(body.encode()),'lines':len(body.splitlines())} for body in bodies],'appLinesBefore':len(original.splitlines()),'appLinesAfter':len(updated.splitlines()),'hooksLinesBefore':len(oldhooks.splitlines()),'hooksLinesAfter':len(newhooks.splitlines()),'renderedMarkupUnchanged':original[original.index('  return ('):]==updated[updated.index('  return ('):],'independentAuthorshipCredit':0},indent=2)+'\n')
 run('focused-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)])
 run('jsx-factory',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/web-jsx-factory.test.mjs'])
 run('issue-entry',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])
 run('gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-abbreviations,check-readability,check-ci-test-admission,check-script-js-twins'])
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'focusedTests':7,'maintainedIssueTests':308,'appLines':len(updated.splitlines()),'markupChanged':False,'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
