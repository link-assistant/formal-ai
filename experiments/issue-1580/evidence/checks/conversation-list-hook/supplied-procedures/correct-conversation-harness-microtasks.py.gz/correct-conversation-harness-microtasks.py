from pathlib import Path
import gzip
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
test=root/'experiments/issue-1580/application-conversation-list.test.mjs';source=test.read_text()
target=root/'experiments/issue-1580/evidence/checks/conversation-list-hook/test-before-microtask-correction.mjs.gz';assert not target.exists();target.write_bytes(gzip.compress(source.encode(),mtime=0))
assert source.count('await Promise.resolve(); await Promise.resolve();')==1
source=source.replace('await Promise.resolve(); await Promise.resolve();','await new Promise(setImmediate);')
assert source.count('  await Promise.resolve();')==1
source=source.replace('  await Promise.resolve();','  await new Promise(setImmediate);')
test.write_text(source)
runner=(scratch/'validate-conversation-list-hook.py').read_text().replace("'conversation-list-hook-validation'","'conversation-list-hook-corrected-validation'").replace("'--test-concurrency=1'","'--test-concurrency=1','--test-reporter=tap'")
exec(compile(runner,__file__,'exec'))
