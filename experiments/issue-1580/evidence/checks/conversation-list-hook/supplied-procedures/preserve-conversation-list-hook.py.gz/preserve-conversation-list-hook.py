from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'conversation-list-hook-preservation';out.mkdir(exist_ok=False)
def run(name,args):
 r=subprocess.run(args,cwd=root,capture_output=True);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);assert r.returncode==0,(name,r.returncode);return r.stdout.decode()
final=json.loads((scratch/'conversation-list-hook-final-validation/outcome.json').read_text());assert final['complete'] and final['maintainedIssueTests']==307
target=root/'experiments/issue-1580/evidence/checks/conversation-list-hook';records=[]
def archive(path,relative):
 raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);dest=target/(relative+'.gz');assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed);assert gzip.decompress(dest.read_bytes())==raw
 records.append({'file':str(dest.relative_to(target)),'sha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
for name in ['conversation-list-hook-extraction','conversation-list-hook-validation','conversation-list-hook-corrected-validation','conversation-list-hook-final-validation']:
 for p in sorted((scratch/name).rglob('*')):
  if p.is_file() and p.name!='pid.json':archive(p,name+'/'+str(p.relative_to(scratch/name)))
for name in ['extract-conversation-list-hook.py','validate-conversation-list-hook.py','correct-conversation-harness-microtasks.py','resume-conversation-list-hook-validation.py',Path(__file__).name]:archive(scratch/name,'supplied-procedures/'+name)
for p in sorted(target.glob('*.gz')):
 raw=gzip.decompress(p.read_bytes());records.append({'file':p.name,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
doc=root/'docs/case-studies/issue-1580/conversation-list-hook-checkpoint.md';doc.write_text('''# Conversation list source headroom

The existing conversation hook module now owns complete list refresh, initial
hydration, deleted-thread visibility and deletion callbacks. Their original
bodies and comments are byte-conserved. App falls from 1,451 to 1,382 lines under
the unchanged 1,400-line warning threshold. Rendered markup is unchanged.

Six focused cases cover source conservation, cached events and titles, deletion
visibility, unavailable/failed memory, selected-thread restoration and unmount,
and append-only deletion. All 307 maintained issue tests, the JSX factory test
and seven affected local gates pass. Cross-realm asynchronous assertions first
failed because two microtasks did not drain the VM callback chain; the corrected
harness drains the event loop once. Initial receipt-marker and non-idempotent
continuation failures remain archived. No Rust build or browser render is claimed.

These supplied edits and checks receive zero independent-authorship credit.
Current hosted CI repairs and the wider issue remain unfinished.
Evidence: `experiments/issue-1580/evidence/checks/conversation-list-hook/`.
Pull request: https://github.com/link-assistant/formal-ai/pull/1581.
''')
fragment=root/'changelog.d/20261121_1580_conversation_list_hook.md';fragment.write_text('### Changed\n\n- Keep conversation list hydration and deletion in the existing hook module while preserving sidebar behavior and source headroom.\n')
plan=root/'experiments/issue-1580/work-plan.md';text=plan.read_text().replace('latest local replay passes 301 tests','latest local replay passes 307 tests').replace('reduce source warnings to 11 under unchanged limits.','reduce source warnings to 10 under unchanged limits.');plan.write_text(text)
assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
paths=['js/app/application.jsx','js/app/application-conversation-hooks.jsx','rust/tests/web/issue-1580-template-observations.test.mjs','experiments/issue-1580/application-conversation-list.test.mjs',str(target.relative_to(root)),str(doc.relative_to(root)),str(fragment.relative_to(root)),str(plan.relative_to(root))]
run('whitespace',['git','diff','--check']);run('stage',['git','add','--',*paths]);run('secrets',['bash','scripts/check-secrets.sh']);run('staged-whitespace',['git','diff','--cached','--check']);run('commit',['git','commit','-m','Extract complete conversation list hooks with behavior conservation tests'])
(out/'outcome.json').write_text(json.dumps({**final,'head':run('head',['git','rev-parse','HEAD']).strip(),'pushed':False},indent=2)+'\n');print((out/'outcome.json').read_text())
