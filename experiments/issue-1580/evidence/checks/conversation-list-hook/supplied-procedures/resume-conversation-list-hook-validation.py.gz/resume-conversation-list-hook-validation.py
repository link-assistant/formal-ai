from pathlib import Path
source=Path('/tmp/issue-1580-research/validate-conversation-list-hook.py').read_text()
source=source.replace("'conversation-list-hook-validation'","'conversation-list-hook-final-validation'").replace("'--test-concurrency=1'","'--test-concurrency=1','--test-reporter=tap'")
exec(compile(source,__file__,'exec'))
