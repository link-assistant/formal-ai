from pathlib import Path
import gzip,hashlib,json,subprocess,sys,traceback,re
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'conversation-list-hook-validation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==0,(name,r.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 target=root/'experiments/issue-1580/evidence/checks/conversation-list-hook';original=gzip.decompress((target/'application-before.jsx.gz').read_bytes()).decode();oldhooks=gzip.decompress((target/'hooks-before.jsx.gz').read_bytes()).decode();updated=(root/'js/app/application.jsx').read_text();newhooks=(root/'js/app/application-conversation-hooks.jsx').read_text()
 markers=[('  // Issue #27: on mount','  const {\n    handleExportMemory'),('  const handleShowDeletedConversations =','  const { handleContextResizePointerDown'),('  const handleDeleteConversation =','  // Issue #386: copy a whole conversation')]
 bodies=[original[original.index(start):original.index(end)] for start,end in markers]
 assert all(body in newhooks and body not in updated for body in bodies)
 markup='  return <main';assert original[original.index(markup):]==updated[updated.index(markup):]
 (target/'body-conservation.json').write_text(json.dumps({'sourceSha256':hashlib.sha256(original.encode()).hexdigest(),'bodies':[{'sha256':hashlib.sha256(body.encode()).hexdigest(),'bytes':len(body.encode()),'lines':len(body.splitlines())} for body in bodies],'appLinesBefore':len(original.splitlines()),'appLinesAfter':len(updated.splitlines()),'hooksLinesBefore':len(oldhooks.splitlines()),'hooksLinesAfter':len(newhooks.splitlines()),'renderedMarkupUnchanged':True,'independentAuthorshipCredit':0},indent=2)+'\n')
 focused=run('focused-after',['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/application-conversation-list.test.mjs'])
 run('jsx-factory',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/web-jsx-factory.test.mjs'])
 issue=run('issue-entry',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])
 run('gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-abbreviations,check-readable-code,check-web-tdz,check-web-hardcoded-ui,check-language-parity,check-twin-citations'])
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'focusedTests':int(re.search(r'^# tests (\d+)$',focused,re.M)[1]),'maintainedIssueTests':int(re.search(r'^# tests (\d+)$',issue,re.M)[1]),'appLines':len(updated.splitlines()),'markupChanged':False,'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
