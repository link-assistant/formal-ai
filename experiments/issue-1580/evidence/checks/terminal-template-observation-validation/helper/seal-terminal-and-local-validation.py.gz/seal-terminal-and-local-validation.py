from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
terminal=scratch/'terminal-scanner-boundary-evidence';validation=scratch/'python-javascript-publication-validation'
summary=json.loads((terminal/'summary.json').read_text());assert summary['allHashesVerified'] and summary['failed']==0 and summary['nativeFamiliesWithRetainedSuccessfulLogs']==8
assert json.loads((validation/'outcome.json').read_text())['allPassed']
assert all(path.stat().st_size==0 for path in validation.glob('*.stderr'))
target=root/'experiments/issue-1580/evidence/checks/terminal-template-observation-validation';target.mkdir(exist_ok=False);records=[]
def retain(path,alias):
 raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);name=alias+'.gz';destination=target/name;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed)
 records.append({'source':str(path),'file':name,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
for path in sorted(validation.iterdir()):
 if path.is_file():retain(path,'local/'+path.name)
for name in ['summary.json','annotations.json']:retain(terminal/name,'terminal/'+name)
for path in sorted((scratch/'terminal-annotation-context').iterdir()):
 if path.is_file():retain(path,'annotations/'+path.name)
for name in ['verify-terminal-scanner-boundary-evidence','review-terminal-annotations','verify-python-javascript-publication','seal-terminal-and-local-validation']:
 retain(scratch/(name+'.py'),'helper/'+name+'.py')
 log=scratch/(name+'.log')
 if log.exists():retain(log,'helper/'+name+'.log')
retain(scratch/'review-terminal-annotations-retry.log','helper/review-terminal-annotations-retry.log')
for item in records:
 archive=(target/item['file']).read_bytes();raw=gzip.decompress(archive)
 assert hashlib.sha256(raw).hexdigest()==item['rawSha256'] and hashlib.sha256(archive).hexdigest()==item['archiveSha256']
(target/'records.json').write_text(json.dumps({'records':records,'allHashesVerified':True,'maintainedTestsPassed':126,'validationChecksPassed':7,'headQualifiedByHostedCI':summary['head'],'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
doc=root/'docs/case-studies/issue-1580/terminal-template-observation-checkpoint.md'
doc.write_text('''# Terminal hosted round and maintained template observations

Published adeb4ff46c4bb162a82aacbeb0c38bbe9aeebd1a has 26 terminal normal
workflows: 25 success, one skip and no failed workflow. Pipeline
https://github.com/link-assistant/formal-ai/actions/runs/44882210284 passes all
eight native contract families and release-registry checks. All 147 retained
command records have successful exits and empty stderr. All 294 compressed
streams verify against their raw/archive SHA256, byte and line identities;
they contain 21,527,495 raw bytes. Hash verification is not literal review of
every log line. The separately dispatched CodeQL producer qualifies its
earlier e06d1f18 source as documented in its own checkpoint.

The full-run annotation inventory has 95 rows. Ninety-one are unresolved
source-size warnings under unchanged limits; one reports the unresolved
crates.io token scope. Three failure annotations occur in successful Workflows
jobs and are confirmed through GitHub's check annotation API. The deliberate
canonical registry outage is a negative control; the other two are actual
initial name-based artifact lookup failures on Ubuntu and Windows. Their
retries and complete round trips succeed. These annotations remain explicit
investigation items rather than being dismissed because the workflow passed.
A separate macOS queue-capacity notice is recorded by the API.

The current local maintained entry executes 126 tests, with zero failures or
skips, in 83.8 seconds. All five affected JavaScript gates and the direct
tests-as-documentation checker also pass. Their stderr streams are empty.
The new cases retain the actual PHP pipe/zero-output defects and actual
Python Scriv/JavaScript gating defects, disposable candidate controls and
finite memory, time and captured-output limits. They establish no upstream
repair. Three reports are linked from the current findings checkpoints.

Hosted streams are retained under
experiments/issue-1580/evidence/ci/native-families-adeb4ff4/ . The maintained
validation, annotation API responses, focused native result lines and
verification helpers are retained under
experiments/issue-1580/evidence/checks/terminal-template-observation-validation/ .
All supplied commands, code and conclusions earn zero independent Formal AI
authorship or reasoning credit. The issue remains unfinished and the PR stays
draft and unmerged: https://github.com/link-assistant/formal-ai/pull/1581 .
''')
plan=root/'experiments/issue-1580/work-plan.md';text=plan.read_text();start=text.index('Latest published head ',text.index('## Current verification checkpoint'));end=text.index('\n\nLatest checkpoint:',start)
current='''Latest published head __BT__adeb4ff4__BT__ has all 26 normal workflows terminal:
25 success, one skip and no failed workflow. All eight native families and
release-registry checks pass. Three retained failure annotations, 91 source
warnings and publish-token uncertainty remain explicit investigation items.
The current local maintained entry passes all 126 cases with zero skips;
five affected gates and the direct documentation checker also pass.
See [terminal hosted and local evidence](../../docs/case-studies/issue-1580/terminal-template-observation-checkpoint.md).
The earlier __BT__e06d1f18__BT__ has a successful separately dispatched actual CodeQL
producer. Full template/practice, original source/budget/live and complete PR
acceptance remain open. Earlier checkpoint entries below retain their dated
heads and do not describe the latest run.
'''.replace('__BT__',chr(96))
plan.write_text(text[:start]+current+text[end:])
php=root/'docs/case-studies/issue-1580/php-process-and-annotation-checkpoint.md';text=php.read_text().replace('All eight complete template comparisons and full issue acceptance remain open.','Acceptance across all eight templates and full issue acceptance remain open.')
php.write_text(text)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
paths=[str(target.relative_to(root)),'experiments/issue-1580/evidence/ci/native-families-adeb4ff4',str(doc.relative_to(root)),str(plan.relative_to(root)),str(php.relative_to(root))]
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
with (scratch/'terminal-validation-commit.stdout').open('wb') as stdout,(scratch/'terminal-validation-commit.stderr').open('wb') as stderr:
 subprocess.run(['git','commit','-m','docs: retain terminal native CI and 126 template observations'],cwd=root,stdout=stdout,stderr=stderr,check=True)
print(json.dumps({'recordsSealed':len(records),'allHashesVerified':True,'committed':True,'pushExecuted':False,'fullIssueComplete':False}))
