from pathlib import Path
import gzip,hashlib,json,re,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/ci/native-families-adeb4ff4'
out=Path('/tmp/issue-1580-research/terminal-scanner-boundary-evidence');out.mkdir(exist_ok=False)
outcome=json.loads((base/'outcome.json').read_text());assert outcome['complete'] and not outcome['failed'] and outcome['workflowCount']==26 and outcome['success']==25,outcome
records=json.loads((base/'records.json').read_text());streams=0;total=0;annotations=[];proof=[]
latest=json.loads((base/'latest.json').read_text());runs={str(row['databaseId']):row for row in latest['runs']}
jobs={}
for row in records:
 for channel in ['stdout','stderr']:
  metadata=row[channel];archive=(base/metadata['file']).read_bytes();raw=gzip.decompress(archive)
  assert len(raw)==metadata['bytes'] and len(raw.splitlines())==metadata['lines'],metadata['file']
  assert hashlib.sha256(raw).hexdigest()==metadata['rawSha256'],metadata['file']
  assert hashlib.sha256(archive).hexdigest()==metadata['archiveSha256'],metadata['file']
  streams+=1;total+=len(raw)
  if channel=='stderr':assert not raw,(row['name'],raw[-2000:])
  if channel=='stdout' and row['name'].startswith('jobs-'):
   run=str(row['name'].split('-')[-1]);data=json.loads(raw)
   for job in data['jobs']:jobs[str(job['databaseId'])]={'run':run,**job}
  if channel=='stdout' and row['name'].startswith('full-run-'):
   run=str(row['name'].split('-')[-1])
   for index,line in enumerate(raw.decode(errors='replace').splitlines(),1):
    text=line.split('\t',2)[-1];text=re.sub(r'^\ufeff?\d{4}-\d\d-\d\dT\S+\s*','',text)
    if re.match(r'(?:::warning|::error|##\[warning\]|##\[error\])',text):
     annotations.append({'workflow':runs[run]['workflowName'],'run':int(run),'line':index,'text':text})
 assert row['exitCode']==0,(row['name'],row['exitCode'])
for row in records:
 if not row['name'].startswith('job-'):continue
 job=jobs.get(row['name'][4:]);assert job,row['name']
 if 'Native contracts (' not in job['name'] and 'Release registry' not in job['name']:continue
 assert job['conclusion']=='success',job
 raw=gzip.decompress((base/row['stdout']['file']).read_bytes()).decode(errors='replace')
 contexts=[]
 for index,line in enumerate(raw.splitlines(),1):
  if re.search(r'test result:|native contract family|--group |--family|cargo test|scripts passed|tests passed|Native contracts',line,re.I):
   text=line.split('\t',2)[-1];contexts.append(f'{index}: {text}')
 proof.append({'name':job['name'],'job':job['databaseId'],'run':int(job['run']),'conclusion':job['conclusion'],'retainedLog':row['stdout']['file'],'results':contexts})
(out/'annotations.json').write_text(json.dumps(annotations,indent=2)+'\n')
(out/'native-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
summary={'head':outcome['head'],'workflowCount':26,'success':25,'skipped':1,'failed':0,'records':len(records),'streamsVerified':streams,'rawBytesVerified':total,'nativeFamiliesWithRetainedSuccessfulLogs':len([row for row in proof if 'Native contracts (' in row['name']]),'registryWithRetainedSuccessfulLog':any('Release registry' in row['name'] for row in proof),'rawAnnotationRows':len(annotations),'allRecordsExitZero':True,'allHashesVerified':True,'fullIssueComplete':False}
assert summary['nativeFamiliesWithRetainedSuccessfulLogs']==8 and summary['registryWithRetainedSuccessfulLog'],summary
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
