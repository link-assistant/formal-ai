from pathlib import Path
import json,subprocess,sys,time
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/python-javascript-publication-validation')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('wb') as stream:process=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':process.pid})+'\n')
 print(json.dumps({'pid':process.pid}));raise SystemExit(0)
commands=[('maintained-entry',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])]
commands += [(name,['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only',name]) for name in ['check-abbreviations','check-file-size','check-readable-code','check-ci-speed','check-runner-labels']]
commands += [('tests-as-documentation',['node','--max-old-space-size=256','scripts/check-tests-as-docs.mjs'])]
results=[]
for name,args in commands:
 start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 row={'name':name,'exitCode':result.returncode,'seconds':round(time.monotonic()-start,3)};results.append(row)
 (out/'partial.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
(out/'outcome.json').write_text(json.dumps({'results':results,'allPassed':all(row['exitCode']==0 for row in results),'fullIssueComplete':False},indent=2)+'\n')
