from pathlib import Path
import gzip,json,re,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
scratch=Path('/tmp/issue-1580-research')
source=root/'experiments/issue-1580/evidence/ci/native-families-adeb4ff4'
out=scratch/'terminal-annotation-context';out.mkdir(exist_ok=True)
records=json.loads((source/'records.json').read_text())
rows=records if isinstance(records,list) else records['records']
print(json.dumps({'recordShape':list(rows[0])}))
full=next(row for row in rows if row['argv']==['gh','run','view','44882210115','--repo','link-assistant/formal-ai','--log'])
for file in [source/full['stdout']['file']]:
 raw=gzip.decompress(file.read_bytes()).decode('utf-8-sig',errors='replace')
 if True:
  lines=raw.splitlines();selected=set()
  for index,line in enumerate(lines):
   if re.search(r'##\[error\]',line):selected.update(range(max(0,index-22),min(len(lines),index+35)))
  (out/'workflows-context.txt').write_text('\n'.join(f'{i+1}: {lines[i]}' for i in sorted(selected))+'\n')
proof=json.loads((scratch/'terminal-scanner-boundary-evidence/native-proof.json').read_text())
compact=[]
for item in proof:
 selected=[line for line in item['results'] if re.search(r'Z test result: ok\.|Z ##\[group\]Run cargo test|Z .*Native contract family .*passed',line)]
 compact.append({**{key:value for key,value in item.items() if key!='results'},'selectedResults':selected})
(out/'native-result-summary.json').write_text(json.dumps(compact,indent=2)+'\n')
jobs=json.loads((scratch/'current-publication-state/pipeline.stdout').read_text())
with (out/'jobs.stdout').open('wb') as stdout,(out/'jobs.stderr').open('wb') as stderr:
 run=subprocess.run(['gh','api','repos/link-assistant/formal-ai/actions/runs/44882210115/jobs','--paginate'],stdout=stdout,stderr=stderr)
assert run.returncode==0
annotations=[]
for job in json.loads((out/'jobs.stdout').read_text())['jobs']:
 url=job['check_run_url'];number=url.rsplit('/',1)[1]
 with (out/(number+'.stdout')).open('wb') as stdout,(out/(number+'.stderr')).open('wb') as stderr:
  run=subprocess.run(['gh','api','repos/link-assistant/formal-ai/check-runs/'+number+'/annotations','--paginate'],stdout=stdout,stderr=stderr)
 assert run.returncode==0
 for row in json.loads((out/(number+'.stdout')).read_text()):annotations.append({'job':job['name'],'checkRun':number,**row})
(out/'github-annotations.json').write_text(json.dumps(annotations,indent=2)+'\n')
print(json.dumps({'nativeFamilies':len(compact)-1,'output':str(out)}))
