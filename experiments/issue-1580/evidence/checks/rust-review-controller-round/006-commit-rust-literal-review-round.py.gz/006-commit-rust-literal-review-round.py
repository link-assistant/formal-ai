from pathlib import Path
import subprocess, json, gzip, hashlib

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert (data['fullyReadFiles'], data['fullyReadSourceLines']) == (355, 52823)
archive = root / 'experiments/issue-1580/evidence/checks/rust-source-review'
logs = json.loads((archive / 'logs.json').read_text())
for name in [f'rust-issue19-ci-review-{n:02d}.log.gz' for n in range(1, 10)] + [f'rust-recent-merged-review-{n:02d}.log.gz' for n in range(1, 9)]:
    row = next(x for x in logs if x['file'] == name)
    packed = (archive / name).read_bytes()
    assert hashlib.sha256(packed).hexdigest() == row['archiveSha256']
    assert hashlib.sha256(gzip.decompress(packed)).hexdigest() == row['rawSha256']
evidence = root / 'experiments/issue-1580/evidence/checks/rust-review-controller-round'
evidence.mkdir(exist_ok=False)
sources = [scratch / name for name in ['read-rust-pinned-byte-range.py',
    'record-rust-issue19-ci-review.py', 'record-rust-issue19-ci-review.log',
    'record-rust-recent-merged-review.py', 'record-rust-recent-merged-review.log',
    'commit-rust-literal-review-round.py']]
stems = ['record-rust-issue19-ci-review', 'record-rust-recent-merged-review',
         'read-rust-pinned-byte-range', 'read-rust-pinned-evidence-range']
for p in (root / 'experiments/issue-1580/evidence/commands').glob('*.json'):
    if any(stem in json.loads(p.read_text()).get('request', '') for stem in stems):
        sources.append(p)
records = []
for n, p in enumerate(sources, 1):
    raw = p.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    name = f'{n:03d}-' + p.name + '.gz'
    (evidence / name).write_bytes(packed)
    records.append({'source': str(p), 'file': name, 'rawSha256': hashlib.sha256(raw).hexdigest(),
                    'archiveSha256': hashlib.sha256(packed).hexdigest()})
(evidence / 'inventory.json').write_text(json.dumps(records, indent=2) + '\n')
out = scratch / 'rust-literal-review-round-commit'
out.mkdir(exist_ok=False)
paths = [str(ledger.relative_to(root)), str(archive.relative_to(root)), str(evidence.relative_to(root))]
for name, command in [('whitespace', ['git', 'diff', '--check']),
                      ('stage', ['git', 'add', '--', *paths]),
                      ('commit', ['git', 'commit', '-m', 'docs: compare complete pinned release log and dependency discussions'])]:
    result = subprocess.run(command, cwd=root, capture_output=True)
    (out / (name + '.stdout')).write_bytes(result.stdout)
    (out / (name + '.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0, name
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
print(json.dumps({'head': head, 'fullyReadFiles': 355, 'fullyReadSourceLines': 52823,
                  'pushed': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}))
