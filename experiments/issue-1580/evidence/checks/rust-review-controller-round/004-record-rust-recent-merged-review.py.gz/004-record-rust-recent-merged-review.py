from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, re

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert (data['fullyReadFiles'], data['fullyReadSourceLines']) == (354, 52822)
path = 'dev/log/issues/247/pulls/248/recent-merged-prs.json'
raw = (scratch / 'templates/rust-complete' / path).read_bytes()
names = [f'rust-recent-merged-review-{part:02d}.log' for part in range(1, 9)]
observed = []
for name in names:
    lines = (scratch / name).read_text().splitlines()
    assert lines[-1].strip() == 'Exit Code: 0', name
    found = [json.loads(match[1]) for line in lines if (match := re.fullmatch(r'   SOURCE-BYTES (.*)', line))]
    assert len(found) == 1, name
    observed.append(found[0])
position = 0
chunks = []
for row in observed:
    assert row['first'] == position
    chunk = row['text'].encode()
    assert len(chunk) == row['last'] - row['first']
    chunks.append(chunk)
    position = row['last']
assert b''.join(chunks) == raw and position == len(raw) == 66338
identities = {row['path']: row for row in json.loads((root / data['all373BlobIdentitiesVerifiedBy']).read_text())}
digest = hashlib.sha256(raw).hexdigest()
assert identities[path]['sha256'] == digest == 'de6439df7715b4fd3cd14bc8929ceb9f40146dfaa67f1007b15a477d06b62c03'
assert path not in {row['path'] for row in data['files']}
assert [row['number'] for row in json.loads(raw)] == [246, 245, 244, 243, 242, 241, 240, 238]
archive = root / 'experiments/issue-1580/evidence/checks/rust-source-review'
logs = json.loads((archive / 'logs.json').read_text())
for name in names:
    value = (scratch / name).read_bytes()
    packed = gzip.compress(value, mtime=0)
    assert not (archive / (name + '.gz')).exists()
    (archive / (name + '.gz')).write_bytes(packed)
    logs.append({'file': name + '.gz', 'rawSha256': hashlib.sha256(value).hexdigest(),
                 'archiveSha256': hashlib.sha256(packed).hexdigest()})
(archive / 'logs.json').write_text(json.dumps(logs, indent=2) + '\n')
data['files'].append({'path': path, 'lines': 1, 'sha256': digest,
                      'readLogs': [name + '.gz' for name in names],
                      'literalReadRanges': [[1, 1]], 'literalReadLines': 1,
                      'literalReadByteRanges': [[row['first'], row['last']] for row in observed],
                      'literalSourceFullyRead': True,
                      'formalAiPracticeImplementationVerified': False,
                      'reviewNote': 'Eight contiguous escaped UTF-8 byte ranges were displayed completely and reassemble the original 66,338 bytes exactly. Embedded upstream excerpts are explicitly truncated by their historical producer; reading this complete artifact does not imply reading every referenced upstream page or present runtime verification.'})
data['files'].sort(key=lambda row: row['path'])
data['fullyReadFiles'] = len(data['files'])
data['fullyReadSourceLines'] = sum(row['literalReadLines'] for row in data['files'])
assert (data['fullyReadFiles'], data['fullyReadSourceLines']) == (355, 52823)
data['observedAt'] = datetime.now(timezone.utc).isoformat()
data['practiceDecisions'].append({'practice': 'Qualify grouped dependency changes against complete validation, including negative controls',
    'templateEvidence': [path],
    'assessment': 'The complete pinned eight-PR artifact is literally read. Six dependency PRs cover actions, clap, lino-arguments, serde_json, toml and regex; major/runtime/compiler changes, changed offsets and no_std behavior require relevant compatibility checks rather than interpreting a merged bot PR as current verification. PR 240 describes all-external-Docker-stage dependency coverage, exact populated directory semantics, updater bypass controls and a nested Dockerfile negative case. PR 238 describes whole-PR base-to-merge detection, timeout/error aggregation, safe complete SARIF diagnostics, restore-only PR caches, real source-size boundaries and source-scoped sibling release independence. Preserve these actual behavioral controls, require current exact-head proof before publication, and distinguish package-root discovery from native Cargo requirements. This historical conversation artifact has intentionally truncated quoted upstream pages and supplies no independent present Formal AI practice implementation or publication proof.',
    'status': 'complete-literal-byte-review-current-practice-runtime-open'})
ledger.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps({'fullyReadFiles': 355, 'fullyReadSourceLines': 52823,
                  'remainingIdentities': 18, 'practiceDecisions': len(data['practiceDecisions']),
                  'fullIssueComplete': False, 'independentAuthorshipCredit': 0}))
