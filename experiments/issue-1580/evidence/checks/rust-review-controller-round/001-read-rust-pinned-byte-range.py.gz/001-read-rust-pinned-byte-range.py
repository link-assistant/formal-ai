from pathlib import Path
import hashlib, json, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
pinned = Path('/tmp/issue-1580-research/templates/rust-complete')
name, first, last = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
assert 0 <= first < last and last - first <= 10000
data = json.loads((root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json').read_text())
identities = {row['path']: row for row in json.loads((root / data['all373BlobIdentitiesVerifiedBy']).read_text())}
raw = (pinned / name).read_bytes()
assert hashlib.sha256(raw).hexdigest() == identities[name]['sha256']
last = min(last, len(raw))
assert first < last
segment = raw[first:last]
print(json.dumps({'path': name, 'bytes': len(raw), 'range': [first, last],
                  'sha256': hashlib.sha256(raw).hexdigest()}))
print('SOURCE-BYTES ' + json.dumps({'first': first, 'last': last, 'text': segment.decode('utf-8')}, ensure_ascii=False))
