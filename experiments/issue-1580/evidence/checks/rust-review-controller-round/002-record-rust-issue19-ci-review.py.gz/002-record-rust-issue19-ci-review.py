from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, re

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert (data['fullyReadFiles'], data['fullyReadSourceLines']) == (353, 51512)
path = 'docs/case-studies/issue-19/ci-logs/ci-run-20885464993.log.gz'
raw = (scratch / 'templates/rust-complete' / path).read_bytes()
decoded = gzip.decompress(raw)
names = [f'rust-issue19-ci-review-{part:02d}.log' for part in range(1, 10)]
observed = []
for name in names:
    lines = (scratch / name).read_text().splitlines()
    assert lines[-1].strip() == 'Exit Code: 0', name
    for line in lines:
        match = re.fullmatch(r'   SOURCE-LINE (.*)', line)
        if match:
            observed.append(json.loads(match[1]))
assert [number for number, text in observed] == list(range(1, 1311))
assert ''.join(text for number, text in observed).encode() == decoded
identities = {row['path']: row for row in json.loads((root / data['all373BlobIdentitiesVerifiedBy']).read_text())}
digest = hashlib.sha256(raw).hexdigest()
assert identities[path]['sha256'] == digest == 'd4eaf069fcaf9357a5a53242fb1118140ab2d878055a80d2548b7201db23bf84'
assert hashlib.sha256(decoded).hexdigest() == '125c194c419c0c925caa4ceab1325efad1f0d65ab87c99f823b634f8713d58fb'
assert path not in {row['path'] for row in data['files']}
archive = root / 'experiments/issue-1580/evidence/checks/rust-source-review'
logs = json.loads((archive / 'logs.json').read_text())
for name in names:
    value = (scratch / name).read_bytes()
    packed = gzip.compress(value, mtime=0)
    assert not (archive / (name + '.gz')).exists()
    (archive / (name + '.gz')).write_bytes(packed)
    logs.append({'file': name + '.gz', 'rawSha256': hashlib.sha256(value).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest()})
(archive / 'logs.json').write_text(json.dumps(logs, indent=2) + '\n')
data['files'].append({'path': path, 'lines': 1310, 'sha256': digest, 'decodedSha256': hashlib.sha256(decoded).hexdigest(), 'readLogs': [name + '.gz' for name in names], 'literalReadRanges': [[1, 1310]], 'literalReadLines': 1310, 'literalSourceFullyRead': True, 'formalAiPracticeImplementationVerified': False, 'reviewNote': 'All nine contiguous escaped-line ranges were displayed completely; their exact UTF-8 concatenation equals the decoded original stream. This historical Agent repository run is not current Rust-template or Formal AI runtime evidence.'})
data['files'].sort(key=lambda row: row['path'])
data['fullyReadFiles'] = len(data['files'])
data['fullyReadSourceLines'] = sum(row['literalReadLines'] for row in data['files'])
assert (data['fullyReadFiles'], data['fullyReadSourceLines']) == (354, 52822)
data['observedAt'] = datetime.now(timezone.utc).isoformat()
data['practiceDecisions'].append({'practice': 'Bind release working directories and publication to the tested source identity', 'templateEvidence': [path], 'assessment': 'All 1,310 decoded historical lines are literally read and reassembled exactly. This is the Agent repository run at 1347edef98519b56b62c10f340740eecc50b7558, not a present Rust-template run. Its three Bun platform jobs each pass 17 JSON protocol tests, while the release fails at lines 1294–1295 with ENOENT opening ./js/package.json after changing package version from 0.7.0 to 0.8.0. The release first checks out the trigger revision, observes remote main advanced to 4f7a0d469c67403139a8017960b8e74ee52d8031, then rebases before versioning. A successful earlier test cannot qualify that changed checkout. Preserve process-owned working directories, explicit package roots, refreshed source qualification before side effects, pinned runtime/runner identities and least permissions. The historical npm audit count and mutable latest Bun/runner selections do not establish current security or compatibility. This source comparison supplies no present package publication or complete practice adoption proof.', 'status': 'complete-literal-decoded-log-review-current-practice-runtime-open'})
ledger.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps({'fullyReadFiles': 354, 'fullyReadSourceLines': 52822, 'remainingIdentities': 19, 'practiceDecisions': len(data['practiceDecisions']), 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}))
