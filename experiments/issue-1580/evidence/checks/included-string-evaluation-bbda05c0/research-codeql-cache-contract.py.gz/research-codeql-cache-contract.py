from pathlib import Path
import subprocess, json, gzip
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/included-string-evaluator-bbda05c0')
for label, path in [('codeql-cli-source', 'src/codeql.ts')]:
    result = subprocess.run(['gh', 'api', '-H', 'Accept: application/vnd.github.raw+json', 'repos/github/codeql-action/contents/' + path + '?ref=v4'], cwd=root, capture_output=True)
    (out / (label + '.stdout')).write_bytes(result.stdout)
    (out / (label + '.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0, label
    lines = result.stdout.decode().splitlines()
    matches = []
    for number, line in enumerate(lines, 1):
        if any(term in line.lower() for term in ['cleanup-level', 'cleanupdatabase', 'keep-full-cache', 'cleanup-level', 'max-disk-cache', 'min-disk-free', 'databasecleanup']):
            matches.append({'line': number, 'text': line})
    print(json.dumps({'file': label, 'bytes': len(result.stdout), 'lines': len(lines), 'matches': matches}))
base = root / 'experiments/issue-1580/evidence/ci/native-families-bbda05c0'
matches = []
with gzip.open(base / 'failed-run-44848465533.stdout.gz', 'rt') as stream:
    for number, line in enumerate(stream, 1):
        if any(term in line.lower() for term in ['cache', 'cleanup', 'controlflow', 'codeql database analyze', 'database run-queries']):
            if len(line) < 1800:
                matches.append({'line': number, 'text': line.rstrip()})
(out / 'producer-cache-log-excerpts.json').write_text(json.dumps(matches, indent=2) + '\n')
print(json.dumps({'logMatches': len(matches)}))
