from pathlib import Path
import base64, collections, gzip, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/ci/codeql-producer-bbda05c0'
scratch = Path('/tmp/issue-1580-research/included-string-evaluator-bbda05c0')
scratch.mkdir(exist_ok=True)
inventory = base / 'producer-files.json'
original = inventory.read_bytes()
if isinstance(json.loads(original), dict):
    original = gzip.decompress((base / 'original-producer-inventory.json.gz').read_bytes())
files = json.loads(original)
assert isinstance(files, list) and len(files) == 137
for row in files:
    packed = base / row['file']
    assert hashlib.file_digest(packed.open('rb'), 'sha256').hexdigest() == row['archiveSha256']
    digest = hashlib.sha256(); size = 0; newlines = 0; last = b''
    with gzip.open(packed, 'rb') as stream:
        while True:
            chunk = stream.read(65536)
            if not chunk: break
            digest.update(chunk); size += len(chunk); newlines += chunk.count(b'\n'); last = chunk[-1:]
    assert (digest.hexdigest(), size, newlines + int(bool(last) and last != b'\n')) == (row['rawSha256'], row['bytes'], row['lines'])
(base / 'original-producer-inventory.json.gz').write_bytes(gzip.compress(original, mtime=0))
parts = []
for start in range(0, len(files), 20):
    name = 'producer-files-part-' + str(len(parts) + 1) + '.json'
    raw = (json.dumps(files[start:start+20], indent=2) + '\n').encode()
    assert len(raw.splitlines()) <= 1400
    (base / name).write_bytes(raw)
    parts.append({'file': name, 'records': len(files[start:start+20]), 'sha256': hashlib.sha256(raw).hexdigest()})
inventory.write_text(json.dumps({'format': 'partitioned-producer-inventory', 'records': len(files), 'parts': parts, 'originalInventory': {'file': 'original-producer-inventory.json.gz', 'rawSha256': hashlib.sha256(original).hexdigest(), 'bytes': len(original), 'lines': len(original.splitlines())}}, indent=2) + '\n')
trace = next(row for row in files if row['relativePath'] == 'included-string-payloads/evaluation.jsonl')
starts = {}; completed = []; types = collections.Counter(); buffer = []; last_event = None
with gzip.open(base / trace['file'], 'rt') as stream:
    for line_number, line in enumerate(stream, 1):
        if not line.strip(): continue
        buffer.append(line)
        if not line.startswith('}'): continue
        event = json.loads(''.join(buffer)); buffer = []
        types[event['type']] += 1; last_event = event
        if event['type'] == 'PREDICATE_STARTED':
            starts[event['eventId']] = {key: event.get(key) for key in ['eventId', 'predicateName', 'nanoTime', 'position', 'dependencies']}
            starts[event['eventId']]['sourceEndingLine'] = line_number
        elif event['type'] == 'PREDICATE_COMPLETED':
            start = starts.pop(event['startEvent'])
            completed.append({'name': start['predicateName'], 'seconds': (event['nanoTime'] - start['nanoTime']) / 1e9, 'rows': event.get('resultSize'), 'startEvent': start['eventId'], 'endEvent': event['eventId'], 'sourceEndingLine': line_number, 'position': start['position']})
assert not buffer and types['PREDICATE_STARTED'] == types['PREDICATE_COMPLETED'] + 1
errors = []
with gzip.open(base / 'full-log.stdout.gz', 'rt') as stream:
    for number, line in enumerate(stream, 1):
        if '##[error]' in line: errors.append({'line': number, 'text': line.rstrip()})
assert len(errors) == 1 and 'timed out after 4 minutes' in errors[0]['text']
assessment = {'head': 'bbda05c06bce8e9fef10a9c8812b6b6cc31858b2', 'runId': 44848465533, 'filesVerified': len(files), 'trace': trace, 'eventCounts': types, 'longestCompletedPredicates': sorted(completed, key=lambda row: row['seconds'], reverse=True)[:20], 'largestCompletedPredicates': sorted(completed, key=lambda row: row['rows'] if row['rows'] is not None else -1, reverse=True)[:10], 'unfinishedPredicatesAtTermination': list(starts.values()), 'lastRecordedEvent': last_event, 'originalErrors': errors, 'queryCompiled': True, 'evaluationComplete': False, 'semanticCoverageProven': False, 'inference': 'The trace measures expensive whole-database relations but does not by itself establish which selected query expression introduces them.', 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
(base / 'included-string-evaluation-assessment.json').write_text(json.dumps(assessment, indent=2) + '\n')
for label, relative in [('controlflow-directory', 'rust/ql/lib/codeql/rust/controlflow'), ('elements-cfg', 'rust/ql/lib/codeql/rust/elements/CfgNode.qll')]:
    result = subprocess.run(['gh', 'api', 'repos/github/codeql/contents/' + relative + '?ref=codeql-cli/v2.27.5'], cwd=root, capture_output=True)
    (scratch / (label + '.stdout.json')).write_bytes(result.stdout)
    (scratch / (label + '.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0, (label, result.stderr.decode())
    data = json.loads(result.stdout)
    if isinstance(data, dict):
        (scratch / (label + '.qll')).write_bytes(base64.b64decode(data['content']))
    else:
        print(json.dumps({'label': label, 'entries': [{'name': row['name'], 'path': row['path']} for row in data]}))
print(json.dumps({'verifiedFiles': len(files), 'tracePredicates': types['PREDICATE_STARTED'], 'longest': assessment['longestCompletedPredicates'][:5], 'unfinished': [row['predicateName'] for row in starts.values()], 'originalErrors': errors}))
