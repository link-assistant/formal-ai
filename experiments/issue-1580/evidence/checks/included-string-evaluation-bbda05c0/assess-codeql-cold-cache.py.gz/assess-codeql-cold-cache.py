from pathlib import Path
import collections, gzip, hashlib, json, subprocess
root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/ci/codeql-producer-bbda05c0'
out = Path('/tmp/issue-1580-research/included-string-evaluator-bbda05c0')
lookup = []
buffer = []
with gzip.open(base / 'producer-14685530112-included-string-payloads_evaluation.jsonl.gz', 'rt') as stream:
    for number, line in enumerate(stream, 1):
        if not line.strip(): continue
        buffer.append(line)
        if not line.startswith('}'): continue
        event = json.loads(''.join(buffer)); buffer = []
        if event['type'] == 'CACHE_LOOKUP':
            lookup.append(event)
assert not buffer
schema = collections.Counter(tuple(sorted(event)) for event in lookup)
selected = lookup[:3] + [event for event in lookup if any(term in str(event) for term in ['PathResolution::getASuccessor', 'CfgStage', 'LocalNameBinding'])][:8]
result = {'lookupEvents': len(lookup), 'lookupResults': dict(collections.Counter(event['cacheLookupResult'] for event in lookup)), 'schemas': [{'keys': list(keys), 'events': count} for keys, count in schema.items()], 'samples': selected, 'missSamples': [event for event in lookup if 'MISS' in event['cacheLookupResult']][:6], 'inferenceOnly': True, 'hostedCacheRepairQualified': False}
(out / 'cache-lookup-assessment.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
with gzip.open(base / 'full-log.stdout.gz', 'rt') as stream:
    matches = [{'line': number, 'text': line.rstrip()} for number, line in enumerate(stream, 1) if 'Download action repository' in line and 'codeql-action' in line]
(out / 'action-version.json').write_text(json.dumps(matches, indent=2) + '\n')
print(json.dumps(matches))
