from pathlib import Path
from collections import Counter
import datetime,gzip,hashlib,json,re
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/ci/native-families-90b51590'
outcome=json.loads((base/'outcome.json').read_text());assert outcome['complete'] and outcome['workflowCount']==27
records=json.loads((base/'records.json').read_text());lookup={row['name']:row for row in records}
def raw(entry):
    packed=(base/entry['file']).read_bytes();value=gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest()==entry['archiveSha256'] and hashlib.sha256(value).hexdigest()==entry['rawSha256']
    assert len(value)==entry['bytes'] and len(value.splitlines())==entry['lines'];return value
annotations=[];runtime=[];verified=0
for row in records:
    assert row['exitCode']==0 or row['name']=='pull-request-checks' and row['exitCode']==1,(row['name'],row['exitCode'])
    for label in ['stdout','stderr']:
        value=raw(row[label]);verified+=1
        if label!='stdout' or not row['name'].startswith('full-run-'):continue
        for number,line in enumerate(value.decode().splitlines(),1):
            match=re.search(r'##\[(warning|error)\](.*)',line)
            if match:annotations.append({'file':row[label]['file'],'line':number,'level':match[1],'text':match[2],'quotedShellSource':'\x1b[36;1m' in line})
            if 'WARNING:' in line or 'warning:' in line:runtime.append({'file':row[label]['file'],'line':number,'text':line})
pipeline=json.loads(raw(lookup['jobs-44804037828']['stdout']));native=[]
for job in pipeline['jobs']:
    if not job['name'].startswith('Native type and lint check /'):continue
    record=lookup['job-'+str(job['databaseId'])];lines=raw(record['stdout']).decode().splitlines();summaries=[];cli=[]
    for number,line in enumerate(lines,1):
        match=re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',line)
        if match:summaries.append({'line':number,'passed':int(match[1]),'failed':int(match[2]),'text':line})
        if 'registry' in job['name'].lower() and any(word in line for word in ['Ran 8 tests','CLI','OK','FAIL']):cli.append({'line':number,'text':line})
    start=datetime.datetime.fromisoformat(job['startedAt'].replace('Z','+00:00'));end=datetime.datetime.fromisoformat(job['completedAt'].replace('Z','+00:00'))
    native.append({'name':job['name'],'job':job['databaseId'],'log':record['stdout']['file'],'lines':len(lines),'passed':sum(row['passed'] for row in summaries),'failed':sum(row['failed'] for row in summaries),'summaries':summaries,'cliObservations':cli,'startedAt':job['startedAt'],'completedAt':job['completedAt'],'seconds':(end-start).total_seconds(),'conclusion':job['conclusion']})
checks=json.loads(raw(lookup['pull-request-checks']['stdout']))
assessment={'head':outcome['head'],'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verifiedStreams':verified,'terminalWorkflows':27,'successfulWorkflows':outcome['success'],'skippedWorkflows':27-outcome['success']-len(outcome['failed']),'failedWorkflows':outcome['failed'],'failedPipelineJobs':[{key:job[key] for key in ['databaseId','name','conclusion']} for job in pipeline['jobs'] if job['conclusion'] not in ['success','skipped']],'nativeJobs':native,'nativeRustPassingTests':sum(row['passed'] for row in native),'nativeRustFailingTests':sum(row['failed'] for row in native),'pullRequestCheckBuckets':dict(Counter(row['bucket'] for row in checks)),'annotationCounts':dict(Counter(row['level']+(':quoted' if row['quotedShellSource'] else ':emitted') for row in annotations)),'allAggregateLinesLiterallyRead':False,'allWarningsResolved':False,'strictOriginalNativeSourceAcceptance':'31/53 strict whole-file identity; 22 separate scoped assertion reviews; historical budgets and live acceptance open','fullIssueComplete':False,'independentAuthorshipCredit':0}
(base/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n');(base/'workflow-annotations.json').write_text(json.dumps(annotations,indent=2)+'\n');(base/'runtime-diagnostics.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in runtime))
print(json.dumps({key:value for key,value in assessment.items() if key!='nativeJobs'},indent=2))
for row in native:print(row['name'],row['passed'],'Rust passes',row['seconds'],'job seconds',row['conclusion'])
for row in annotations:
    if not row['quotedShellSource'] and 'approaching limit of' not in row['text']:print('OTHER DIAGNOSTIC',json.dumps(row))
