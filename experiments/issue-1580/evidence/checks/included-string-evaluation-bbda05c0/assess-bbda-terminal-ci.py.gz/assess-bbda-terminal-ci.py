from pathlib import Path
source = Path('/tmp/issue-1580-research/assess-artifact-and-child-memory-parent-ci.py').read_text()
assert source.count('native-families-90b51590') == 1
assert source.count('jobs-44804037828') == 1
source = source.replace('native-families-90b51590', 'native-families-bbda05c0').replace('jobs-44804037828', 'jobs-44848472447')
exec(compile(source, __file__, 'exec'))
