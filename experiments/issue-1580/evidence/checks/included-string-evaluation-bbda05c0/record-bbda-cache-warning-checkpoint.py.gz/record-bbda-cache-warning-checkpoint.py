from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
checks = root / 'experiments/issue-1580/evidence/checks'
cache = json.loads((checks / 'codeql-cache-retention-repair/outcome.json').read_text())
assert cache['passed'] and cache['allGateEntriesCovered'] and cache['hostedRepairQualificationPending']
ci = json.loads((root / 'experiments/issue-1580/evidence/ci/native-families-bbda05c0/assessment.json').read_text())
warnings = json.loads((checks / 'world-algorithm-warning-inventory/outcome.json').read_text())
assert ci['verifiedStreams'] == 312 and ci['nativeRustPassingTests'] == 573 and not ci['failedPipelineJobs']
assert warnings['warningCount'] == 92 and warnings['violations'] == warnings['embeddedDataViolations'] == 0

archive = checks / 'included-string-evaluation-bbda05c0'
archive.mkdir(exist_ok=False)
inventory = []
source_directory = scratch / 'included-string-evaluator-bbda05c0'
sources = [(p, p.name.replace('cfg', 'control-flow')) for p in sorted(source_directory.iterdir()) if p.is_file()]
for name in ['assess-included-string-evaluator.py', 'research-codeql-cache-contract.py', 'assess-codeql-cold-cache.py',
             'assess-current-macro-observation.py', 'assess-source-warning-macro-observations.py',
             'assess-bbda-terminal-ci.py', 'assess-artifact-and-child-memory-parent-ci.py',
             'inventory-link-record-warning-checkpoint.py', 'inventory-world-algorithm-warning-checkpoint.py',
             'record-bbda-cache-warning-checkpoint.py']:
    p = scratch / name
    assert p.is_file(), name
    sources.append((p, name))
for source, name in sources:
    raw = source.read_bytes(); packed = gzip.compress(raw, mtime=0); filename = name + '.gz'
    (archive / filename).write_bytes(packed)
    inventory.append({'source': str(source.relative_to(scratch)), 'file': filename,
        'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(),
        'bytes': len(raw), 'lines': len(raw.splitlines())})
(archive / 'inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
(archive / 'outcome.json').write_text(json.dumps({'observedAt': datetime.now(timezone.utc).isoformat(),
    'sourceCount': len(inventory), 'originalProducerPayloadsVerified': 137,
    'originalTraceArchive': '../../ci/codeql-producer-bbda05c0/',
    'cacheEvictionCauseProven': False, 'actualRepairExecutionPending': True,
    'allAggregateLinesLiterallyRead': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')

checkpoint = '''Latest fully collected published head `bbda05c06bce8e9fef10a9c8812b6b6cc31858b2`
has 27 terminal workflows: 24 success, one skip and two failures. All 312
retained command streams verify by original/compressed hash, bytes and lines.
CI/CD Pipeline 44848472447 passes all ten native jobs: 573 Rust tests and
eight actual registry CLI cases. This qualifies the previously missing private
imports on that published head, not the five later parent-module extractions.

Layered CI 44848472242 reports one stale generated TypeScript owner comment
at full-log lines 13034–13036. Commit 601cbdf8 reproduces the maintained
translator failure, regenerates that one projection and passes its unchanged
currency check. Twelve translator and six page-formalization cases pass.

Security 44848465533 times out the additional included-string observation at
full-log line 2241 after the unchanged four-minute allowance. Query compilation
takes 21.4 seconds. The complete evaluator trace reaches whole-database path
resolution and name binding; one successor relation has 60,738,981 rows. Its
413 cache lookups comprise two relation hits, 206 CACHACA hits and 205 partial
CACHACA results. Partial results are not recorded as cache misses. The trace
does not prove which selected expression introduces that cost or establish
cache eviction as the cause.

The local cache repair preserves intermediate results from the standard action
and both observers, only for opt-in read-only Rust macro investigation. It uses
the pinned action's actual extra-option mechanism and retains the original
query, nine columns, 4 GiB memory allowance, two threads, four-minute clocks
and strict security gate. An exact inverse proves the retained job changes
only by that opt-in environment. Fixture regressions fail before and pass after
the repair. Hosted execution must still qualify its performance and results.

Both original standard SARIF reports have zero findings and warning/error
notifications. The completed macro profile has 122,555 contexts across 2,229
files, a 2,607 MiB heap and no runtime diagnostics; all 137 original producer
payloads verify. The 631 unexpanded original positions still lack per-child
security/dataflow semantic qualification.

The complete local 141-entry gate replay finishes 140 passed or skipped. Its
sole failure is the source-model check exhausting the imposed 192 MiB local
JavaScript heap. That unchanged gate passes separately with a 256 MiB heap.
The adapter, strict security and production-profile suites pass. A stale fake
CLI cache expectation, the initial heap failure and the passing repairs remain
separate retained observations. No local Rust compilation or execution occurs.

The release-map fixture now preserves the real shared Git history while checking
out only its five consumed path groups. All seven cases pass, reconstructing
961 fragments and 432 nonempty releases. Its largest reaped child uses 105,172
KiB, versus the earlier observed full-checkout Git child near 750 MiB. That
earlier owned replay was stopped before container exhaustion; no host OOM was
observed. The sparse fixture also passes in the full gate replay.

Five additional unchanged parent modules move record-field projection, source
layout, linear-equation, dialogue-memory and algorithm-evidence helpers into
private children. Exact inverse controls and focused checks pass; public paths
remain intact. The fresh scanner reports 92 source-size warnings and zero
ordinary or embedded-data violations under unchanged limits. Published logs
still contain the earlier 97 size warnings and publish-token uncertainty.
Experimental unsafe-libyaml and the two Chrono consumers remain unresolved.

Pinned PHP original/candidate controls and upstream reports remain distinct
from complete template acceptance. Whole aggregate literal review, all-warning
resolution, dependency migration, complete PR review, all eight full template
comparisons/practices and original/live acceptance remain unfinished. Rust
literal review stays 352/373 identities and 49,166 lines. Strict dated original
whole-file acceptance stays 31/53 plus 22 separate scoped assertion reviews;
original budgets and live criteria remain open. Independent Formal AI reasoning
remains 0/20. Supplied work receives zero independent credit. PR #1581 remains
draft and unmerged; full issue completion remains false.

Evidence: `evidence/ci/native-families-bbda05c0/`,
`evidence/ci/codeql-producer-bbda05c0/` and the check directories
`codeql-cache-retention-repair`, `included-string-evaluation-bbda05c0`,
`typescript-currency-repair`, `release-fixture-sparse-checkout`,
`world-algorithm-warning-inventory`, `layout-and-equation-extraction` and
`world-memory-algorithm-evidence-extraction` under the issue experiments.
'''
for relative, start, end in [
    ('experiments/issue-1580/work-plan.md', '## Current verification checkpoint\n\n', '\nEarlier chronology:'),
    ('docs/case-studies/issue-1580/source-warning-extraction-checkpoint.md', '## Current repair checkpoint\n\n', '\n## Earlier dated observations'),
]:
    path = root / relative; text = path.read_text()
    assert text.count(start) == text.count(end) == 1, relative
    before, rest = text.split(start, 1); old, after = rest.split(end, 1)
    assert old.startswith('Latest fully collected published head `d48b0988'), relative
    path.write_text(before + start + checkpoint + end + after)

body_source = checks / 'php-input-integrity-upstream-publication/pull-request-body-with-upstream.md'
body = body_source.read_text()
old = '- Reduce source-size warnings through twenty-one helper extractions'
assert body.count(old) == 1
line = next(line for line in body.splitlines() if line.startswith(old))
body = body.replace(line, '- Reduce source-size warnings with unchanged helper extractions and exact inverse controls. Five more parent modules isolate record fields, source layout, linear equations, dialogue memory and algorithm evidence. Keep public paths, every assertion and the original size limits.\n- Preserve CodeQL intermediate caches only for the manual read-only Rust investigation; retain the exact query, strict security gate, memory policy and four-minute deadlines. Hosted execution must qualify the performance hypothesis.\n- Keep the release-map fixture on real Git history with a sparse checkout of its actual inputs, reducing measured local process memory while preserving all seven cases.')
body = body.replace('Preserve original SARIF gates, two threads, disk-cache limit and command budgets.', 'Preserve original SARIF gates, two threads and command budgets.')
start = 'Verification:\n\n'
end = '- PHP source review adds 98 fully read files'
assert body.count(start) == body.count(end) == 1
before, rest = body.split(start, 1); previous, after = rest.split(end, 1)
verification = '''- The latest fully collected head `bbda05c06bce8e9fef10a9c8812b6b6cc31858b2` has 27 terminal workflows: 24 success, one skip and two failures. All 312 original/compressed command streams verify. [Pipeline 44848472447](https://github.com/link-assistant/formal-ai/actions/runs/44848472447) passes all ten native jobs, 573 Rust tests and eight actual registry CLI cases. Newer helper extractions still need hosted compilation. [Layered CI 44848472242](https://github.com/link-assistant/formal-ai/actions/runs/44848472242) exposes one stale TypeScript owner comment at lines 13034–13036; commit 601cbdf8 reproduces and repairs it with the official translator. Twelve translator and six page-formalization cases pass locally.
- [Security 44848465533](https://github.com/link-assistant/formal-ai/actions/runs/44848465533) times out the additional included-string observation at line 2241 after query compilation in 21.4 seconds. The complete trace reaches expensive whole-database name binding. Its cache counts do not prove eviction as the cause. The local retention repair has failing-before/passing-after fixture controls and an exact retained-job inverse; actual performance and result equivalence remain unqualified. Both original standard SARIF reports are clean. The completed macro profile has 122,555 contexts across 2,229 files, a 2,607 MiB heap and no runtime diagnostics; all 137 payloads verify. All 631 unexpanded positions still need semantic qualification.
- The complete 141-entry local JavaScript gate replay finishes 140 passed or skipped; its sole failure exhausts the imposed 192 MiB JavaScript heap in the source-model gate. That unchanged gate passes separately at 256 MiB. The complete template adapter previously passes 93 cases, including 15 PHP input-integrity and seven lifetime cases; cache adapter, strict security and production-profile tests pass. Initial failures remain retained separately. No local Rust compilation or execution occurs.
- All seven real-history release-map cases pass with the sparse fixture, reconstructing 961 fragments and 432 nonempty releases. Its largest reaped child is 105,172 KiB; the earlier full-checkout Git child was observed near 750 MiB. The sparse fixture also passes in the full replay. Fresh source scanning reports 92 warnings and zero ordinary/embedded-data violations under unchanged limits. Published annotations retain the earlier 97 size warnings and token-scope uncertainty. Unsafe-libyaml and the two Chrono consumers remain open. [Source checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/source-warning-extraction-checkpoint.md).
'''
body = before + start + verification + end + after
assert body.count('Fixes #1580') == 1
publication = scratch / 'cache-warning-publication'
publication.mkdir(exist_ok=False)
(publication / 'previous-pull-request-body.md').write_bytes(body_source.read_bytes())
(publication / 'pull-request-body.md').write_text(body)
(publication / 'current-checkpoint.md').write_text(checkpoint)
print(json.dumps({'checkpointRecorded': True, 'warningCount': 92, 'verifiedCiStreams': 312,
    'bodyFile': str(publication / 'pull-request-body.md'), 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}))
