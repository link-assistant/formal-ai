from pathlib import Path
source = Path('/tmp/issue-1580-research/assess-source-warning-macro-observations.py').read_text()
source = source.replace('codeql-producer-f8b372ad', 'codeql-producer-bbda05c0')
source = source.replace("outcome['conclusion'] == 'success'", "outcome['conclusion'] == 'failure'")
source = source.replace("len(value.splitlines()) == row['lines']", "value.count(b'\\n') + int(bool(value) and not value.endswith(b'\\n')) == row['lines']")
exec(compile(source, '<current-macro-observation-assessment>', 'exec'), globals())
