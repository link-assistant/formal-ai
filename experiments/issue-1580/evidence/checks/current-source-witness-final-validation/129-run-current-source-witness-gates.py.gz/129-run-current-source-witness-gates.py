from pathlib import Path
import gzip, hashlib, json, os, resource, subprocess, sys, time

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research/current-source-witness-gates')
if len(sys.argv) == 1:
    scratch.mkdir(exist_ok=False)
    with (scratch / 'worker.log').open('wb') as output:
        child = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root,
            stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    (scratch / 'pid').write_text(str(child.pid) + '\n')
    print(json.dumps({'pid': child.pid, 'boundedInventory': 'maintained JavaScript gates, sequential'}))
else:
    source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
    started = time.monotonic()
    environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
    with (scratch / 'aggregate.log').open('wb') as output:
        result = subprocess.run(['node', 'experiments/formal_ai_subagent/local-gates.mjs'],
            cwd=root, env=environment, stdout=output, stderr=subprocess.STDOUT)
    archive = scratch / 'logs'
    archive.mkdir()
    records = []
    for line in (scratch / 'aggregate.log').read_text().splitlines():
        if not line.startswith(('PASS ', 'FAIL ')):
            continue
        name = line.split()[1]
        original = root / 'experiments/formal_ai_subagent/sandboxes/gates' / (name + '.log')
        raw = original.read_bytes()
        packed = gzip.compress(raw, mtime=0)
        target = archive / (name + '.log.gz')
        target.write_bytes(packed)
        assert gzip.decompress(target.read_bytes()) == raw
        records.append({'gate': name, 'file': str(target.relative_to(scratch)),
            'bytes': len(raw), 'lines': len(raw.splitlines()),
            'rawSha256': hashlib.sha256(raw).hexdigest(),
            'archiveSha256': hashlib.sha256(packed).hexdigest()})
    (scratch / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    lines = (scratch / 'aggregate.log').read_text().splitlines()
    outcome = {'source': source, 'exitCode': result.returncode,
        'seconds': round(time.monotonic() - started, 3),
        'passed': sum(line.startswith('PASS ') for line in lines),
        'failed': sum(line.startswith('FAIL ') for line in lines),
        'skipped': sum(line.startswith('SKIP ') for line in lines),
        'allExecutedLogsRetained': len(records),
        'childrenPeakRssKiB': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
        'localRustBuild': False, 'independentAuthorshipCredit': 0,
        'fullIssueComplete': False}
    (scratch / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    print(json.dumps(outcome), flush=True)
