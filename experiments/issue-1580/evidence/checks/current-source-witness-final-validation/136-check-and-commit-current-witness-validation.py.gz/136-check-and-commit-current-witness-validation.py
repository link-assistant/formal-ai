from pathlib import Path
import json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/current-witness-validation-checks')
out.mkdir(exist_ok=False)
checks = []
for gate in ['check-abbreviations', 'check-file-size', 'check-readable-code']:
    result = subprocess.run(['node', '--max-old-space-size=256',
        'experiments/formal_ai_subagent/local-gates.mjs', '--only', gate],
        cwd=root, capture_output=True)
    (out / (gate + '.stdout')).write_bytes(result.stdout)
    (out / (gate + '.stderr')).write_bytes(result.stderr)
    checks.append({'gate': gate, 'exitCode': result.returncode})
    print(json.dumps(checks[-1]), flush=True)
assert all(row['exitCode'] == 0 for row in checks)
paths = ['docs/case-studies/issue-1580/templates/rust-source-review-progress.json',
    'docs/case-studies/issue-1580/source-witness-validation-checkpoint.md',
    'experiments/issue-1580/work-plan.md',
    'experiments/issue-1580/evidence/checks/rust-source-review',
    'experiments/issue-1580/evidence/checks/current-source-witness-final-validation']
for name, command in [('whitespace', ['git', 'diff', '--check']),
                      ('stage', ['git', 'add', '--', *paths]),
                      ('commit', ['git', 'commit', '-m', 'docs: retain source witness gates and complete package metadata review'])]:
    result = subprocess.run(command, cwd=root, capture_output=True)
    (out / (name + '.stdout')).write_bytes(result.stdout)
    (out / (name + '.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0, name
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
outcome = {'head': head, 'checks': checks, 'pushed': False, 'fullIssueComplete': False}
(out / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
print(json.dumps(outcome), flush=True)
