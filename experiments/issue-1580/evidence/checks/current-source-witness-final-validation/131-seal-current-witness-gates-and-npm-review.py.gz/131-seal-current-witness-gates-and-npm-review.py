from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
gates = scratch / 'current-source-witness-gates'
outcome = json.loads((gates / 'outcome.json').read_text())
assert (outcome['passed'], outcome['failed'], outcome['skipped']) == (88, 0, 53)
assert outcome['exitCode'] == 0
records = json.loads((gates / 'records.json').read_text())
assert len(records) == 88
for row in records:
    packed = (gates / row['file']).read_bytes()
    raw = gzip.decompress(packed)
    assert hashlib.sha256(raw).hexdigest() == row['rawSha256']
    assert hashlib.sha256(packed).hexdigest() == row['archiveSha256']
    assert (len(raw), len(raw.splitlines())) == (row['bytes'], row['lines'])
ledger = json.loads((root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json').read_text())
assert (ledger['fullyReadFiles'], ledger['fullyReadSourceLines']) == (356, 57336)
maintenance = scratch / 'maintenance-publications-2026-11-21'
publications = json.loads((maintenance / 'outcome.json').read_text())
for row in publications['files']:
    raw = (maintenance / row['file']).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
archive = root / 'experiments/issue-1580/evidence/checks/current-source-witness-final-validation'
archive.mkdir(exist_ok=False)
stems = ['run-current-source-witness-gates', 'record-rust-npm-release-review',
         'refresh-maintenance-publications-2026-11-21',
         'inspect-current-repair-run-state-03-57', 'seal-current-witness-gates-and-npm-review']
sources = {p for stem in stems for p in scratch.glob(stem + '*') if p.is_file()}
sources.update(p for p in gates.rglob('*') if p.is_file())
sources.update(p for p in maintenance.rglob('*') if p.is_file())
sources.add(scratch / 'read-rust-pinned-source-range.py')
for p in (root / 'experiments/issue-1580/evidence/commands').glob('*.json'):
    value = json.loads(p.read_text())
    request = value.get('request', '')
    if any(stem in request for stem in stems) or ('read-rust-pinned-source-range.py' in request and 'npm-release.json' in request):
        sources.add(p)
inventory = []
for number, p in enumerate(sorted(sources), 1):
    raw = p.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    name = f'{number:03d}-' + p.name + '.gz'
    (archive / name).write_bytes(packed)
    assert gzip.decompress((archive / name).read_bytes()) == raw
    inventory.append({'source': str(p), 'file': name, 'bytes': len(raw),
        'lines': len(raw.splitlines()), 'rawSha256': hashlib.sha256(raw).hexdigest(),
        'archiveSha256': hashlib.sha256(packed).hexdigest()})
parts = []
for first in range(0, len(inventory), 35):
    name = f'inventory-{first // 35 + 1:02d}.json'
    raw = (json.dumps(inventory[first:first + 35], indent=2) + '\n').encode()
    (archive / name).write_bytes(raw)
    parts.append({'file': name, 'records': len(inventory[first:first + 35]),
        'sha256': hashlib.sha256(raw).hexdigest()})
(archive / 'inventory.json').write_text(json.dumps({'records': len(inventory), 'parts': parts}, indent=2) + '\n')
(archive / 'outcome.json').write_text(json.dumps({
    'observedAt': datetime.now(timezone.utc).isoformat(), 'gates': outcome,
    'allExecutedGateIdentitiesVerified': True, 'rustLiteralFiles': 356,
    'rustLiteralSourceLines': 57336, 'rustPracticeDecisions': len(ledger['practiceDecisions']),
    'dependencyMutation': False, 'maintenanceMigrationComplete': False,
    'independentAuthorshipCredit': 0, 'fullIssueComplete': False}, indent=2) + '\n')
document = '''# Source witness validation and template metadata, 2026-11-21

The maintained complete JavaScript gate inventory passes after the generated
native source witness repair: 88 executed gates pass and 53 entries are
explicitly skipped, with zero failures. The sequential run takes 577.591
seconds under a 256 MiB Node heap setting; measured child peak RSS is
382,472 KiB. All 88 executed gate streams verify by raw/compressed SHA256,
byte count and line count. No local Rust compilation or native execution
is performed. The run starts at local commit `396a4af7`; later evidence-only
changes do not acquire additional native runtime verification from it.

The pinned Rust template's complete npm 12.2.2 metadata is now literally
read: all 4,513 lines across ten contiguous ranges reassemble the original
96,962 bytes exactly. Literal source review reaches 356/373 files and
57,336 lines, with 74 practice decisions. Node engine patch floors,
registry integrity/signatures, dependencies and bundled payload identity
must be checked before a package-manager major upgrade. This historical
metadata does not prove live compatibility or publication. Complete template
comparison and applicable behavioral verification remain unfinished.

Fresh registry observations still show `command-stream 1.13.0` and
`link-calculator 0.24.0` requiring Chrono. The command-stream migration
[issue 238](https://github.com/link-foundation/command-stream/issues/238)
is closed, but that registry version still has the dependency. Calculator
[issue 265](https://github.com/link-assistant/calculator/issues/265) remains
open. Both complete comment endpoints are empty. `meta-language 1.0.0`
has none of the selected direct maintenance dependencies; this does not
qualify a change to the intentionally historical 0.58.1 reproducer or its
transitive graph. No dependency or lockfile changes are made. Maintenance
migrations remain unresolved.

The published head `27e895c1` is still collecting its final Pipeline jobs.
Its known Layered CI source-witness failure is repaired locally, with the
existing five-case regression passing. Do not interpret the JavaScript gate
result as final-head hosted acceptance. All source warnings, wider issue
requirements and final review remain open; PR #1581 stays draft and unmerged.

Evidence: `experiments/issue-1580/evidence/checks/current-source-witness-final-validation/`
and `experiments/issue-1580/evidence/checks/rust-source-review/`.
'''
(root / 'docs/case-studies/issue-1580/source-witness-validation-checkpoint.md').write_text(document)
plan = root / 'experiments/issue-1580/work-plan.md'
text = plan.read_text()
marker = '## Current verification checkpoint\n\n'
assert text.count(marker) == 1
text = text.replace(marker, marker + 'Latest local validation: [88 executed gates pass](../../docs/case-studies/issue-1580/source-witness-validation-checkpoint.md), with 53 explicit skips and no local Rust build. Rust literal review is 356/373 files and 57,336 lines. Fresh registry observations retain both Chrono consumers; migration remains unresolved.\n\n', 1)
plan.write_text(text)
print(json.dumps({'archivedRecords': len(inventory), 'gates': outcome,
    'rustLiteralFiles': 356, 'rustLiteralSourceLines': 57336,
    'fullIssueComplete': False}, indent=2))
