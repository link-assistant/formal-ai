from pathlib import Path
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
archive = root / 'experiments/issue-1580/evidence/checks/current-source-witness-final-validation'
index = json.loads((archive / 'inventory.json').read_text())
changed = []
for part in index['parts']:
    target = archive / part['file']
    rows = json.loads(target.read_text())
    for row in rows:
        if row['file'] == '075-check-tests-as-docs.log.gz.gz':
            old = archive / row['file']
            row['file'] = '075-check-tests-as-documentation.log.gz.gz'
            new = archive / row['file']
            assert not new.exists()
            old.rename(new)
            assert hashlib.sha256(new.read_bytes()).hexdigest() == row['archiveSha256']
            changed.append(row['file'])
    raw = (json.dumps(rows, indent=2) + '\n').encode()
    target.write_bytes(raw)
    part['sha256'] = hashlib.sha256(raw).hexdigest()
assert len(changed) == 1
sources = list((scratch / 'current-witness-validation-checks').glob('*'))
sources += [scratch / name for name in ['check-and-commit-current-witness-validation.py',
    'check-and-commit-current-witness-validation.log', 'current-witness-abbreviation-findings.log',
    'list-current-witness-abbreviation-findings.log', 'repair-current-witness-archive-filenames.py']]
gate = root / 'experiments/formal_ai_subagent/sandboxes/gates/check-abbreviations.log'
assert 'rose from 90 to 91' in gate.read_text()
sources.append(gate)
for p in (root / 'experiments/issue-1580/evidence/commands').glob('*.json'):
    request = json.loads(p.read_text()).get('request', '')
    if 'check-and-commit-current-witness-validation.py' in request or 'current-witness-abbreviation-findings.log' in request:
        sources.append(p)
rows = []
for number, p in enumerate(sorted(set(sources)), 132):
    raw = p.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    name = f'{number:03d}-' + p.name + '.gz'
    assert not (archive / name).exists()
    (archive / name).write_bytes(packed)
    rows.append({'source': str(p), 'file': name, 'bytes': len(raw),
        'lines': len(raw.splitlines()), 'rawSha256': hashlib.sha256(raw).hexdigest(),
        'archiveSha256': hashlib.sha256(packed).hexdigest()})
name = 'inventory-05.json'
assert not (archive / name).exists()
raw = (json.dumps(rows, indent=2) + '\n').encode()
(archive / name).write_bytes(raw)
index['parts'].append({'file': name, 'records': len(rows), 'sha256': hashlib.sha256(raw).hexdigest()})
index['records'] += len(rows)
(archive / 'inventory.json').write_text(json.dumps(index, indent=2) + '\n')
outcome = json.loads((archive / 'outcome.json').read_text())
outcome['postArchiveAbbreviationFailure'] = {'retained': True,
    'cause': 'Evidence filename expanded a maintained fixed-name abbreviation into a new prefixed filename',
    'repair': changed[0], 'gateLimitsChanged': False}
(archive / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
document = root / 'docs/case-studies/issue-1580/source-witness-validation-checkpoint.md'
text = document.read_text()
text += '''

The post-archive abbreviation check rejects one prefixed copy of the existing
`check-tests-as-docs` gate log: its new evidence filename falls outside the
maintained command's fixed-name spelling. Rename that evidence file using
`documentation`, preserve its original bytes and update the manifest identity.
The failed check and exact original finding are retained separately. Gate
limits and production commands remain unchanged; the targeted retry must pass
before committing this evidence batch.
'''
document.write_text(text)
source = (scratch / 'check-and-commit-current-witness-validation.py').read_text()
source = source.replace("'current-witness-validation-checks'", "'current-witness-validation-checks-retry'")
(scratch / 'check-and-commit-current-witness-validation-retry.py').write_text(source)
print(json.dumps({'renamed': changed, 'retainedFailureRecords': len(rows),
    'gateLimitsChanged': False, 'fullIssueComplete': False}))
