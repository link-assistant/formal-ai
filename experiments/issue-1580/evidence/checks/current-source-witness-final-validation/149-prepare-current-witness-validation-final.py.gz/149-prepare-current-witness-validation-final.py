from pathlib import Path
import gzip, hashlib, json

scratch = Path('/tmp/issue-1580-research')
root = Path('/tmp/gh-issue-solver-1794900398048')
archive = root / 'experiments/issue-1580/evidence/checks/current-source-witness-final-validation'
source = (scratch / 'check-and-commit-current-witness-validation.py').read_text()
old = '/tmp/issue-1580-research/current-witness-validation-checks'
new = old + '-final'
assert source.count(old) == 1
updated = source.replace(old, new)
assert updated.count(new) == 1
(scratch / 'check-and-commit-current-witness-validation-final.py').write_text(updated)
names = ['check-and-commit-current-witness-validation-retry.py',
    'check-and-commit-current-witness-validation-retry.log',
    'repair-current-witness-archive-filenames.log',
    'prepare-current-witness-validation-final.py']
rows = []
for number, name in enumerate(names, 146):
    raw = (scratch / name).read_bytes()
    packed = gzip.compress(raw, mtime=0)
    target = f'{number:03d}-' + name + '.gz'
    assert not (archive / target).exists()
    (archive / target).write_bytes(packed)
    rows.append({'source': str(scratch / name), 'file': target,
        'bytes': len(raw), 'lines': len(raw.splitlines()),
        'rawSha256': hashlib.sha256(raw).hexdigest(),
        'archiveSha256': hashlib.sha256(packed).hexdigest()})
name = 'inventory-06.json'
raw = (json.dumps(rows, indent=2) + '\n').encode()
(archive / name).write_bytes(raw)
index = json.loads((archive / 'inventory.json').read_text())
index['parts'].append({'file': name, 'records': len(rows), 'sha256': hashlib.sha256(raw).hexdigest()})
index['records'] += len(rows)
(archive / 'inventory.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({'retainedHarnessFailure': 'retry directory substitution did not match absolute path',
    'newCheckDirectory': new, 'replacementCountVerified': 1}))
