from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, re

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert (data['fullyReadFiles'], data['fullyReadSourceLines']) == (355, 52823)
path = 'dev/log/issues/247/pulls/248/npm-release.json'
raw = (scratch / 'templates/rust-complete' / path).read_bytes()
names = [f'rust-npm-release-review-{part:02d}.log' for part in range(1, 11)]
observed = []
for name in names:
    lines = (scratch / name).read_text().splitlines()
    assert lines[-1].strip() == 'Exit Code: 0', name
    observed.extend((int(match[1]), match[2]) for line in lines
                    if (match := re.fullmatch(r'   (\d+): (.*)', line)))
assert [number for number, _ in observed] == list(range(1, 4514))
assert ('\n'.join(text for _, text in observed) + '\n').encode() == raw
identities = {row['path']: row for row in json.loads((root / data['all373BlobIdentitiesVerifiedBy']).read_text())}
digest = hashlib.sha256(raw).hexdigest()
assert identities[path]['sha256'] == digest == '0724fc531c6c699f492a67b2d43d26ce33a41a2d6a8a1b075bd7120e24316202'
assert path not in {row['path'] for row in data['files']}
package = json.loads(raw)
assert package['version'] == '12.2.2'
assert package['engines']['node'] == '^22.22.2 || ^24.15.0 || >=26.0.0'
archive = root / 'experiments/issue-1580/evidence/checks/rust-source-review'
logs = json.loads((archive / 'logs.json').read_text())
for name in names:
    value = (scratch / name).read_bytes()
    packed = gzip.compress(value, mtime=0)
    assert not (archive / (name + '.gz')).exists()
    (archive / (name + '.gz')).write_bytes(packed)
    logs.append({'file': name + '.gz', 'rawSha256': hashlib.sha256(value).hexdigest(),
                 'archiveSha256': hashlib.sha256(packed).hexdigest()})
(archive / 'logs.json').write_text(json.dumps(logs, indent=2) + '\n')
data['files'].append({'path': path, 'lines': 4513, 'sha256': digest,
    'readLogs': [name + '.gz' for name in names],
    'literalReadRanges': [[1, 4513]], 'literalReadLines': 4513,
    'literalSourceFullyRead': True, 'formalAiPracticeImplementationVerified': False,
    'reviewNote': 'All 4,513 numbered source lines were displayed completely across ten contiguous ranges and reassembled byte-for-byte against the pinned original. Most of the artifact is contributor metadata; registry engines, integrity/signatures, dependencies and bundled payload metadata are read without claiming a live registry observation or installation.'})
data['files'].sort(key=lambda row: row['path'])
data['fullyReadFiles'] = len(data['files'])
data['fullyReadSourceLines'] = sum(row['literalReadLines'] for row in data['files'])
assert (data['fullyReadFiles'], data['fullyReadSourceLines']) == (356, 57336)
data['observedAt'] = datetime.now(timezone.utc).isoformat()
data['practiceDecisions'].append({
    'practice': 'Check package-manager engine compatibility and exact registry artifact identity before a major-tool upgrade',
    'templateEvidence': [path + ':1-500', path + ':4341-4513'],
    'assessment': 'The complete pinned npm 12.2.2 metadata supplies explicit Node engines, registry tarball identity, integrity/signatures, unpacked size, bundled dependencies and publication git identity. Its engines exclude older Node patch releases even within Node 22 and Node 24. For Formal AI dependency-latest and release workflows, a major npm update must be qualified against the selected Node version and actual registry package; a historical metadata artifact, contributor count, latest tag or successful source-only scan cannot establish that compatibility or publication. Preserve exact producer identities and observed failure status. No npm installation or current publication verification is claimed by this literal comparison.',
    'status': 'complete-literal-source-review-current-tool-compatibility-open'})
ledger.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps({'fullyReadFiles': 356, 'fullyReadSourceLines': 57336,
    'remainingIdentities': 17, 'practiceDecisions': len(data['practiceDecisions']),
    'fullIssueComplete': False, 'independentAuthorshipCredit': 0}))
