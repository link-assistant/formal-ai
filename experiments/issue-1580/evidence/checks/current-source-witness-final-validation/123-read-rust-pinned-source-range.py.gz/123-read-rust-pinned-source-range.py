from pathlib import Path
import sys,hashlib,json
r=Path('/tmp/gh-issue-solver-1794900398048');t=Path('/tmp/issue-1580-research/templates/rust-complete');name=sys.argv[1];first=int(sys.argv[2]);last=int(sys.argv[3]);assert 1<=first<=last and last-first<1500
raw=(t/name).read_bytes();lines=raw.decode('utf-8').splitlines();d=json.loads((r/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json').read_text());identities={x['path']:x['sha256'] for x in json.loads((r/d['all373BlobIdentitiesVerifiedBy']).read_text())};assert hashlib.sha256(raw).hexdigest()==identities[name];last=min(last,len(lines));print('FILE',name,'LINES',len(lines),'RANGE',first,last,'SHA256',identities[name])
for n in range(first,last+1):print(str(n)+': '+lines[n-1])
