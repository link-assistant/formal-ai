from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, urllib.request

root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/maintenance-publications-2026-11-21')
out.mkdir(exist_ok=False)
records = []
for repository, number in [('link-foundation/command-stream', 238), ('link-assistant/calculator', 265)]:
    stem = repository.replace('/', '--') + '-' + str(number)
    for kind, endpoint in [('issue', f'repos/{repository}/issues/{number}'),
                           ('comments', f'repos/{repository}/issues/{number}/comments')]:
        result = subprocess.run(['gh', 'api', endpoint, '--paginate'], cwd=root, capture_output=True)
        (out / (stem + '-' + kind + '.json')).write_bytes(result.stdout)
        (out / (stem + '-' + kind + '.stderr')).write_bytes(result.stderr)
        assert result.returncode == 0, (repository, kind)
        value = json.loads(result.stdout)
        records.append({'repository': repository, 'number': number, 'kind': kind,
            'state': value.get('state') if isinstance(value, dict) else None,
            'updatedAt': value.get('updated_at') if isinstance(value, dict) else None,
            'comments': len(value) if isinstance(value, list) else value.get('comments')})
        print(json.dumps(records[-1]), flush=True)
for crate in ['command-stream', 'link-calculator', 'meta-language']:
    def fetch(suffix, name):
        request = urllib.request.Request('https://crates.io/api/v1/crates/' + crate + suffix,
            headers={'User-Agent': 'formal-ai-issue-1580-maintenance-verification'})
        with urllib.request.urlopen(request, timeout=20) as response:
            raw = response.read(2 * 1024 * 1024 + 1)
            assert len(raw) <= 2 * 1024 * 1024
        target = out / (crate + '-' + name + '.json')
        target.write_bytes(raw)
        return json.loads(raw)
    info = fetch('', 'registry')
    version = info['crate']['max_version']
    dependencies = fetch('/' + version + '/dependencies', 'dependencies')
    selected = [row for row in dependencies['dependencies']
        if row['crate_id'] in ['chrono', 'jiff', 'time', 'serde_yaml', 'serde_yaml_ng', 'unsafe-libyaml']]
    records.append({'crate': crate, 'publishedLatest': version, 'maintenanceDependencies': selected})
    print(json.dumps(records[-1]), flush=True)
manifest = [{'file': p.name, 'bytes': p.stat().st_size,
    'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.glob('*'))]
(out / 'outcome.json').write_text(json.dumps({'observedAt': datetime.now(timezone.utc).isoformat(),
    'records': records, 'files': manifest, 'dependencyMutation': False,
    'independentAuthorshipCredit': 0, 'fullIssueComplete': False}, indent=2) + '\n')
