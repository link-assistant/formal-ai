from pathlib import Path
import json,subprocess,hashlib,gzip
root=Path('experiments/issue-1580/evidence/checks/owned-source-batch')
manifest=root/'manifest.json'
before=manifest.read_bytes()
data=json.loads(before)
print('MANIFEST SHAPE',type(data).__name__,list(data)[:25])
names=[p for p in root.iterdir() if 'rust--src--' in p.name]
assert len(names)==5
changes=[]
for old in names:
 new=old.with_name(old.name.replace('rust--src--','rust--source--'))
 assert not new.exists()
 raw=old.read_bytes();old.rename(new)
 changes.append({'before':old.name,'after':new.name,'compressedSha256':hashlib.sha256(raw).hexdigest()})
text=before.decode()
for row in changes:
 assert text.count(row['before'])==1,(row['before'],text.count(row['before']))
 text=text.replace(row['before'],row['after'])
manifest.write_text(text)
evidence=Path('experiments/issue-1580/evidence/checks/owned-source-archive-name-repair');evidence.mkdir(exist_ok=True)
for name,path in [
 ('before-name-gate.log',Path('/tmp/issue-1580-research/6903-push-preparation/abbreviation-before.log')),
 ('before-abbreviated-file-names.txt',Path('/tmp/issue-1580-research/6903-push-preparation/abbreviation-list.txt')),
 ('repair-controller.py',Path(__file__)),
]:
 (evidence/(name+'.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
(evidence/'before-owned-source-manifest.json.gz').write_bytes(gzip.compress(before,mtime=0))
(evidence/'manifest.json').write_text(json.dumps({'cause':'Five retained source filenames exposed the src abbreviation in their archive basename.','repair':'Expand only the archive basename to source; retain exact original source fields and stream hashes.','ratchetRaised':False,'files':changes,'independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps(changes,indent=2))
print(subprocess.check_output(['git','status','--short'],text=True))
