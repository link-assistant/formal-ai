from pathlib import Path
import gzip, hashlib, json, os, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'surface-and-html-helper-extraction'
proof = json.loads((out / 'outcome.json').read_text())
assert proof['passed']
def run(name, argv):
    result = subprocess.run(argv, cwd=root, env={**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}, capture_output=True)
    (out / (name + '.stdout')).write_bytes(result.stdout)
    (out / (name + '.stderr')).write_bytes(result.stderr)
    print(name, result.returncode, flush=True)
    assert result.returncode == 0
    return result.stdout.decode()

archive = root / 'experiments/issue-1580/evidence/checks/surface-and-html-helper-extraction'
archive.mkdir(exist_ok=False)
entries = []
inputs = [*[p for p in out.iterdir() if p.is_file() and p.name != 'worker.log'], scratch / 'extract-surface-and-html-helpers.py', scratch / 'extract-surface-and-html-helpers.log', Path(__file__)]
for path in sorted(inputs):
    raw = path.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    target = archive / (path.name + '.gz')
    target.write_bytes(packed)
    entries.append({'file': target.name, 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
(archive / 'records.json').write_text(json.dumps({'entries': entries, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
fragment = root / 'changelog.d/issue-1580-computer-use-content.md'
fragment.write_text(fragment.read_text() + '\nExtract unchanged rule-surface matching, unknown-word span readers and HTML text helpers into private modules; retain public concept-lookup paths.\n')
plan = root / 'experiments/issue-1580/work-plan.md'
plan.write_text(plan.read_text() + '\n- Remove three further production Rust source-size warnings by extracting rule-surface matching (973 to 863 lines), unknown-word spans (961 to 816), and HTML text helpers (936 to 823). Exact inverse reconstruction retains every original byte after undoing imports, visibility and one qualified rustdoc link. Existing JavaScript handler, concept-lookup and page-formalization files pass 5, 5 and 9 cases respectively; formatting, source projection and four source gates pass. Native compilation/execution is reserved for CI. No independent authorship credit is claimed.\n')
selected = [*proof['sourcePaths'], archive.relative_to(root).as_posix(), fragment.relative_to(root).as_posix(), plan.relative_to(root).as_posix()]
run('stage', ['git', 'add', '--', *selected])
secret_paths = []
for relative in selected:
    path = root / relative
    secret_paths.extend(p.relative_to(root).as_posix() for p in sorted(path.rglob('*')) if p.is_file()) if path.is_dir() else secret_paths.append(relative)
run('secrets', ['bash', 'scripts/check-secrets.sh', *secret_paths])
run('whitespace', ['git', 'diff', '--cached', '--check'])
run('commit', ['git', 'commit', '-m', 'refactor: separate surface matching and HTML text helpers'])
head = run('head', ['git', 'rev-parse', 'HEAD']).strip()
(out / 'commit-outcome.json').write_text(json.dumps({'head': head, 'passed': True, 'pushExecuted': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
