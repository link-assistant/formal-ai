from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'surface-and-html-helper-extraction'
if len(sys.argv) == 1:
    out.mkdir(exist_ok=False)
    with (out / 'worker.log').open('wb') as stream:
        child = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': child.pid, 'finiteWorker': True}))
    sys.exit(0)
records = []
def run(name, argv):
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=root, env={**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}, stdout=stdout, stderr=stderr)
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == 0, name
    return (out / (name + '.stdout')).read_text()

assert run('branch', ['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
assert not run('index-before', ['git', 'diff', '--cached', '--name-only']).strip()
proofs = []
source_paths = []
def save(label, parent, child, original, new_parent, new_child, restored):
    assert restored == original and not child.exists()
    assert len(new_parent.splitlines()) < 900 and len(new_child.splitlines()) < 900
    child.parent.mkdir(exist_ok=True)
    parent.write_text(new_parent)
    child.write_text(new_child)
    (out / (label + '-original-source.rs.gz')).write_bytes(gzip.compress(original.encode(), mtime=0))
    proofs.append({'parent': parent.relative_to(root).as_posix(), 'child': child.relative_to(root).as_posix(), 'originalSha256': hashlib.sha256(original.encode()).hexdigest(), 'reassembledOriginalSha256': hashlib.sha256(restored.encode()).hexdigest(), 'originalLines': len(original.splitlines()), 'parentLines': len(new_parent.splitlines()), 'childLines': len(new_child.splitlines()), 'exactOriginalReconstruction': True})
    source_paths.extend(p.relative_to(root).as_posix() for p in [parent, child])

parent = root / 'rust/src/rule_interpreter.rs'
child = root / 'rust/src/rule_interpreter/surfaces.rs'
original = parent.read_text()
assert len(original.splitlines()) == 973
marker = '/// Whether a seeded role surface is present, including the open slot carried by'
start = original.index(marker)
block = original[start:]
assert block.count('\nfn ') == 5
declaration = 'mod surfaces;\n'
uses = 'use surfaces::{before_slot, separated_surface_present, spelled_surface_present};\n'
imports = 'use super::ConditionSurface;\nuse crate::seed::Slot;\n\n'
new_parent = original[:start].rstrip() + '\n'
new_parent = new_parent.replace('mod shape;\n', 'mod shape;\n' + declaration, 1).replace('use values::TableLookup;\n', uses + 'use values::TableLookup;\n', 1)
new_child = imports + block.replace('[`ConditionSource`]', '[`super::ConditionSource`]')
for name in ['spelled_surface_present', 'separated_surface_present', 'before_slot']:
    new_child = new_child.replace('fn ' + name + '(', 'pub(super) fn ' + name + '(', 1)
restored_block = new_child.removeprefix(imports).replace('pub(super) fn ', 'fn ').replace('[`super::ConditionSource`]', '[`ConditionSource`]')
restored = new_parent.replace(declaration, '', 1).replace(uses, '', 1).rstrip() + '\n\n' + restored_block
save('rule-surfaces', parent, child, original, new_parent, new_child, restored)

parent = root / 'rust/src/concept_lookup.rs'
child = root / 'rust/src/concept_lookup/unknown_surfaces.rs'
original = parent.read_text()
assert len(original.splitlines()) == 961
marker = '/// The surfaces in `normalized` that no seeded meaning accounts for'
start = original.index(marker)
block = original[start:]
declaration = 'mod unknown_surfaces;\n\npub use unknown_surfaces::{\n+    has_quoted_span, is_unknown_surface, unknown_surface_spans, unknown_surfaces,\n+};\n\n'.replace('\n+', '\n')
imports = 'use std::collections::BTreeSet;\nuse std::sync::OnceLock;\n\n'
new_parent = original[:start].rstrip() + '\n'
new_parent = new_parent.replace('use std::sync::OnceLock;\n', '', 1).replace('use std::collections::BTreeSet;\n', declaration + 'use std::collections::BTreeSet;\n', 1)
new_child = imports + block
restored = new_parent.replace(declaration, '', 1).replace('use std::collections::BTreeSet;\n', imports[:-1], 1).rstrip() + '\n\n' + new_child.removeprefix(imports)
save('unknown-surfaces', parent, child, original, new_parent, new_child, restored)

parent = root / 'rust/src/web_formalize.rs'
child = root / 'rust/src/web_formalize/html_text.rs'
original = parent.read_text()
assert len(original.splitlines()) == 936
start_marker = '/// Value of `name="..."` in a tag\'s attribute text, if present.'
end_marker = '/// The trust features the seed weighs (issue #1163 R7).'
start = original.index(start_marker)
end = original.index(end_marker, start)
block = original[start:end]
assert block.count('\nfn ') == 6
declaration = 'mod html_text;\n\nuse html_text::{cell_texts, decode_entities, strip_tags, strip_tags_keep_lines, tag_attr};\n\n'
new_parent = (original[:start] + original[end:]).replace('use std::collections::BTreeMap;\n', declaration + 'use std::collections::BTreeMap;\n', 1)
new_child = block[:-1]
for name in ['cell_texts', 'decode_entities', 'strip_tags', 'strip_tags_keep_lines', 'tag_attr']:
    new_child = new_child.replace('fn ' + name + '(', 'pub(super) fn ' + name + '(', 1)
restored = new_parent.replace(declaration, '', 1).replace(end_marker, new_child.replace('pub(super) fn ', 'fn ') + '\n' + end_marker, 1)
save('html-text', parent, child, original, new_parent, new_child, restored)
(out / 'inverse-proofs.json').write_text(json.dumps({'observedAt': datetime.now(timezone.utc).isoformat(), 'files': proofs, 'localRustExecution': False, 'hostedNativeVerificationPending': True, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
run('rust-format', ['rustfmt', '--edition', '2024', '--check', *source_paths])
for name, path in [('rule-surfaces-javascript', 'rust/tests/web/issue-1085-handler-rules-parity.test.mjs'), ('unknown-surfaces-javascript', 'rust/tests/web/issue-1138-concept-lookup.test.mjs'), ('html-text-javascript', 'rust/tests/web/issue-1163-web-formalize-parity.test.mjs')]:
    run(name, ['node', '--test', '--test-concurrency=1', path])
run('translation-current', ['node', 'scripts/translate-js-rust.mjs', '--verify'])
run('source-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code'])
(out / 'outcome.json').write_text(json.dumps({'passed': True, 'files': proofs, 'sourcePaths': source_paths, 'pushExecuted': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
