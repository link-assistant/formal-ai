from pathlib import Path
import ast,json,runpy,subprocess,sys,tempfile
r=Path('/tmp/issue-1580-research/registry-template-parity-current')
targets=['scripts/registry.rs','scripts/wait-for-crate.rs']
fixed={name:Path(name).read_bytes() for name in targets}
test=['node','--test','--test-concurrency=1','--test-name-pattern=sparse availability','experiments/issue-1580/native-regression-groups.test.mjs']
try:
    for name in targets:Path(name).write_bytes((r/('original-'+Path(name).name)).read_bytes())
    with (r/'before-javascript-contract.log').open('w') as f:
        before=subprocess.run(test,stdout=f,stderr=subprocess.STDOUT).returncode
finally:
    for name,data in fixed.items():Path(name).write_bytes(data)
with (r/'after-javascript-contract.log').open('w') as f:
    after=subprocess.run(test,stdout=f,stderr=subprocess.STDOUT).returncode
assert before!=0 and after==0,(before,after)
with (r/'javascript-contracts.log').open('w') as f:
    full=subprocess.run(['node','--test','--test-concurrency=1','experiments/issue-1580/native-regression-groups.test.mjs'],stdout=f,stderr=subprocess.STDOUT).returncode
with (r/'fixture-controls.log').open('w') as f:
    controls=subprocess.run([sys.executable,'experiments/issue-1580/verify-sparse-registry-controls.py'],stdout=f,stderr=subprocess.STDOUT).returncode
with (r/'rustfmt.log').open('w') as f:
    fmt=subprocess.run(['rustfmt','--edition','2024','--check',*targets],stdout=f,stderr=subprocess.STDOUT).returncode
with (r/'whitespace.log').open('w') as f:
    whitespace=subprocess.run(['git','diff','--check'],stdout=f,stderr=subprocess.STDOUT).returncode
for path in ['experiments/issue-1580/release-registry/cli_regressions.py','experiments/issue-1580/release-registry/sparse_registry_regressions.py','experiments/issue-1580/verify-sparse-registry-controls.py']:
    ast.parse(Path(path).read_text())
sys.dont_write_bytecode=True
m=runpy.run_path('experiments/issue-1580/release-registry/sparse_registry_regressions.py')
with tempfile.TemporaryDirectory(prefix='sparse-source-control-') as directory:
    control=m['add_sparse_registry_controls'](Path('experiments/issue-1580/release-registry'),Path(directory))
    assert Path(directory,'wait-for-crate-before-sparse.rs').read_bytes()==(r/'original-wait-for-crate.rs').read_bytes()
result={'beforeSourceContractExit':before,'afterSourceContractExit':after,'all67JavaScriptContractsExit':full,'fixtureControlsExit':controls,'rustfmtExit':fmt,'whitespaceExit':whitespace,'pythonSyntaxFiles':3,'originalWaiterFixtureVerified':True,'nativeExecutionCredit':0,'nativeCliMethodsPending':6,'nativeParserTestPending':1}
(r/'local-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
assert full==controls==fmt==whitespace==0
