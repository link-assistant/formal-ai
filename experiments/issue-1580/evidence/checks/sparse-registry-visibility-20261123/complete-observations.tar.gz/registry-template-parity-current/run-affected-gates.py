from pathlib import Path
import subprocess,json,datetime
root=Path('/tmp/issue-1580-research/registry-template-parity-current')
gates=['check-file-size','check-file-size-js-twin','check-readable-code','check-required-documentation','check-tests-as-docs','check-tests-as-documentation-javascript-twin','check-changelog-fragment-js-twin','release#1','check-closure-audit','check-generated-files','layered-ci#1']
results=[]
for index,gate in enumerate(gates):
    target=root/('gate-%02d.log'%index)
    with target.open('w') as stream:
        run=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate],stdout=stream,stderr=subprocess.STDOUT)
    results.append({'gate':gate,'exitCode':run.returncode,'log':str(target),'bytes':target.stat().st_size})
    (root/'gate-results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results[-1]),flush=True)
print('ALL_GATES_FINISHED',flush=True)
