from pathlib import Path
import datetime, gzip, hashlib, io, json, tarfile

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
source = scratch / 'templates/rust-complete'
names = ['actionlint-release.json', 'npm-major-migration.json', 'actionlint-upstream.json',
    'buildkit-release.json', 'branch-security-run-before.json', 'branch-desktop-before.json']
paths = ['dev/log/issues/247/pulls/248/' + name for name in names]
inventory = json.loads((root / 'experiments/issue-1580/evidence/checks/rust-template-first-gate/pinned-file-identities.json').read_text())
identities = {row['path']: row for row in inventory}
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert data['fullyReadFiles'] == 324
manifest = root / data['readLogManifest']
records = json.loads(manifest.read_text())
for index, path in enumerate(paths):
    assert path not in {row['path'] for row in data['files']}
    raw = (source / path).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == identities[path]['sha256'] and len(raw.decode().splitlines()) == 1
    rendered = (scratch / 'rust-next-small-history' / (str(index + 1) + '.read.txt')).read_bytes()
    assert json.loads(rendered) == json.loads(raw)
    read = ('FILE ' + path + ' SOURCE LINES 1 SHA256 ' + digest + '\n').encode() + rendered
    name = 'small-release-history-' + str(index + 1) + '.read.txt.gz'
    packed = gzip.compress(read, mtime=0)
    assert not (manifest.parent / name).exists()
    (manifest.parent / name).write_bytes(packed)
    records.append({'file': name, 'rawSha256': hashlib.sha256(read).hexdigest(),
        'archiveSha256': hashlib.sha256(packed).hexdigest()})
    data['files'].append({'path': path, 'lines': 1, 'sha256': digest, 'readLogs': [name],
        'literalReadRanges': [[1, 1]], 'literalReadLines': 1, 'literalSourceFullyRead': True,
        'formalAiPracticeImplementationVerified': False})
manifest.write_text(json.dumps(records, indent=2) + '\n')
data['files'].sort(key=lambda row: row['path'])
data['fullyReadFiles'] = len(data['files'])
data['fullyReadSourceLines'] = sum(row['literalReadLines'] for row in data['files'])
assert data['fullyReadFiles'] == 330 and data['fullyReadSourceLines'] == 37647
data['observedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
data['practiceDecisions'].append({'practice': 'Qualify tool-release claims and aggregate success against original producer results',
    'templateEvidence': paths,
    'assessment': 'Read all six complete pinned JSON records, including all 13 queue-support PR comments and every desktop job. Historical actionlint 1.7.12 lacks queue support; exact unknown-key suppression alone cannot establish valid queue type/value or cancellation combinations. PR #654 remains open in this historical response; current upstream state requires fresh verification. npm 12 changes JSON output, strict flags, supported Node versions and lifecycle defaults. BuildKit 0.35.0 release notes describe retry, cancellation and cache fixes; release notes alone do not prove current image publication. The original security analysis step succeeds while its strict SARIF gate and dependency audit fail. All six historical desktop package jobs fail and all checksums/uploads skip. Job metadata does not establish those failures\' causes; original logs must be read separately. One initially truncated desktop metadata display was reread in bounded chunks until complete.',
    'status': 'six-original-release-and-job-records-fully-read-current-adoption-open',
    'formalAiPaths': ['.github/actionlint.yaml', '.github/workflows/workflows.yml',
        '.github/workflows/security.yml', '.github/workflows/desktop-release.yml',
        '.github/workflows/docker-publish.yml'],
    'verification': 'experiments/issue-1580/evidence/checks/rust-small-release-history/assessment.json'})
ledger.write_text(json.dumps(data, indent=2) + '\n')
destination = root / 'experiments/issue-1580/evidence/checks/rust-small-release-history'
destination.mkdir(exist_ok=False)
selected = [Path(__file__), scratch / 'read-rust-next-small-history.py',
    scratch / 'read-rust-next-small-history.log', scratch / 'read-next-recording-references.log',
    scratch / 'record-rust-small-release-history.log']
selected.extend(path for path in (scratch / 'rust-next-small-history').rglob('*') if path.is_file())
buffer = io.BytesIO()
rows = []
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for path in sorted(selected):
        raw = path.read_bytes()
        name = path.relative_to(scratch).as_posix()
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
        archive.addfile(entry, io.BytesIO(raw))
        rows.append({'file': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
raw = buffer.getvalue()
packed = gzip.compress(raw, mtime=0)
(destination / 'supplied-investigation.tar.gz').write_bytes(packed)
(destination / 'supplied-investigation.json').write_text(json.dumps({'files': rows,
    'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(),
    'independentAuthorshipCredit': 0, 'fullIssueComplete': False}, indent=2) + '\n')
(destination / 'assessment.json').write_text(json.dumps({'sourceFilesFullyRead': paths,
    'desktopMetadataInitialDisplayTruncated': True, 'desktopMetadataRereadComplete': True,
    'historicalDesktopPackageFailures': 6, 'historicalRustAnalysisSucceeded': True,
    'historicalStrictSarifAndAuditFailed': True, 'queueSuppressionFullyQualifiesConcurrency': False,
    'currentRuntimeAdoptionVerified': False, 'fullIssueComplete': False,
    'independentAuthorshipCredit': 0}, indent=2) + '\n')
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- Six more complete pinned Rust release/upstream/job records are read with all fields and comments: 330/373 literal files, 37,647 lines. Original security analysis success did not imply strict SARIF/audit success; six historical desktop package failures had no delivered checksum artifacts. Exact actionlint queue-key suppression needs separate validity qualification. Current upstream and adoption state remain unverified; original failure logs and broader comparisons remain open.\n')
print('Literal pinned Rust review: 330/373 files; 37,647 lines. Full issue and practice adoption remain open.')
