from pathlib import Path
import hashlib, json

source = Path('/tmp/issue-1580-research/templates/rust-complete')
base = Path('/tmp/issue-1580-research/rust-next-small-history')
base.mkdir(exist_ok=False)
names = ['actionlint-release.json', 'npm-major-migration.json', 'actionlint-upstream.json',
    'buildkit-release.json', 'branch-security-run-before.json', 'branch-desktop-before.json']
rows = []
for index, name in enumerate(names):
    path = 'dev/log/issues/247/pulls/248/' + name
    raw = (source / path).read_bytes()
    parsed = json.loads(raw)
    text = json.dumps(parsed, indent=2, ensure_ascii=False) + '\n'
    target = base / (str(index + 1) + '.read.txt')
    target.write_text(text)
    rows.append({'path': path, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw),
        'sourceLines': len(raw.splitlines()), 'renderedFile': target.name, 'renderedLines': len(text.splitlines())})
(base / 'sources.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows, indent=2))
