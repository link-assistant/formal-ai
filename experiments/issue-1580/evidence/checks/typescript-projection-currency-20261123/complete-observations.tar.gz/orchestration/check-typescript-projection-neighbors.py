import datetime
import json
import os
import subprocess
from pathlib import Path

root = Path('/tmp/issue-1580-research/typescript-projection-currency-17a')
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
records = []
for label, command in [
    ('translator-neighbors', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/translate-es.test.mjs']),
    ('touched-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-file-size,check-readable-code']),
    ('canonical-check', ['node', 'scripts/translate-es.mjs', '--check']),
    ('diff-check-final', ['git', 'diff', '--check']),
]:
    with (root / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, env=environment)
    records.append({'label': label, 'command': command, 'exitCode': result.returncode})
    (root / 'neighbor-records.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    assert result.returncode == 0
(root / 'neighbor-outcome.json').write_text(json.dumps({'complete': True, 'records': records, 'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2) + '\n')
