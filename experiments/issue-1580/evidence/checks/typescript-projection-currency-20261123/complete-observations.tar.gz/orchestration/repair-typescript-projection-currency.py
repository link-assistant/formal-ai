import json
import os
import subprocess
from pathlib import Path

root = Path('/tmp/issue-1580-research/typescript-projection-currency-17a')
root.mkdir(exist_ok=True)
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
records = []

def run(label, command, expected=0):
    with (root / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, env=environment)
    records.append({'label': label, 'command': command, 'exitCode': result.returncode})
    (root / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label, result.returncode, flush=True)
    if expected == 'nonzero':
        assert result.returncode != 0
    else:
        assert result.returncode == expected

run('before-runtime', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/typescript-runtime.test.mjs'], 'nonzero')
run('before-currency', ['node', 'scripts/translate-es.mjs', '--check'], 'nonzero')
run('canonical-regeneration', ['node', 'scripts/translate-es.mjs', '--write'])
run('after-currency', ['node', 'scripts/translate-es.mjs', '--check'])
run('after-runtime', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/typescript-runtime.test.mjs'])
run('diff-check', ['git', 'diff', '--check'])
run('diff', ['git', 'diff', '--', 'ts'])
(root / 'outcome.json').write_text(json.dumps({'complete': True, 'records': records}, indent=2) + '\n')
