from pathlib import Path
import gzip,hashlib,json,os,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
out=scratch/'release-main-integration-validation';evidence=root/'experiments/issue-1580/evidence/checks/release-main-integration'
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('w') as stream:
        worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=256';env['SECRETLINT_VERSION']='14.0.0'
env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
commands=[]
def run(name,args):
    with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
        result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'exitCode':result.returncode};commands.append(row)
    (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert result.returncode==0,row
    return (out/(name+'.stdout')).read_text()
try:
    main=run('merged-release-head',['git','rev-parse','MERGE_HEAD']).strip()
    assert main.startswith('f574289f4'),main
    run('reviewed-witness-refresh',['node','--max-old-space-size=256',str(scratch/'refresh-release-main-witness.mjs')])
    run('unicode-witness',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/rust-specification-unicode-identifiers.test.mjs'])
    run('maintained-issue-cases',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])
    run('all-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs'])
    full=(out/'all-local-gates.stdout').read_text()
    counts={key:len(re.findall('^'+key+r' ',full,re.M)) for key in ['PASS','SKIP','FAIL']}
    assert counts=={'PASS':88,'SKIP':53,'FAIL':0},counts
    assert not run('unmerged-paths',['git','diff','--name-only','--diff-filter=U']).strip()
    note=root/'docs/case-studies/issue-1580/release-main-integration-checkpoint.md'
    note.write_text('''# Released main integration checkpoint

Main releases v0.356.0 at f574289f while the preceding merge is under local
validation. The publication preflight refuses the stale ancestry before any
remote write. Merge that release and preserve the branch's security-backport
description in its own new fragment after main consumes the original fragment.

The complete governed witness changes only four SHA references to the
version-updated Cargo manifest. The reader, source manifest, all 221 case
objects and all 968 unsupported objects remain equal after substituting those
four reviewed hashes. The official versioned writer performs the refresh.

Unicode controls and all 158 maintained issue observations pass. A fresh
complete 141-gate run against released main records 88 passes, 53 explicit
hosted-only skips and zero failures. This supersedes the earlier partial
integration run, whose failures and successful retries remain retained.

No local native build runs. The next published head still needs hosted native
and complete JavaScript execution. Remaining warnings, full template/practice
comparison and wider issue acceptance stay open. Supplied work earns zero
independent-authorship or reasoning credit.

Evidence: experiments/issue-1580/evidence/checks/release-main-integration/.
PR: https://github.com/link-assistant/formal-ai/pull/1581
''')
    plan=root/'experiments/issue-1580/work-plan.md'
    plan.write_text(plan.read_text()+'\n- Merge released main f574289f (v0.356.0) after the ancestry preflight correctly refuses the earlier source. Preserve the backport description in a new fragment. Full witness equality permits only four reviewed Cargo fixture hashes, retaining 221 cases and 968 unsupported items. All 158 maintained observations and the fresh complete 141-gate run pass (88 executed, 53 explicit hosted-only skips). Hosted qualification, remaining warnings and wider issue acceptance remain open. See [released main integration](../../docs/case-studies/issue-1580/release-main-integration-checkpoint.md).\n')
    evidence.mkdir(exist_ok=False);records=[]
    def archive(alias,file):
        raw=file.read_bytes();packed=gzip.compress(raw,mtime=0);target=evidence/(alias+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(packed)
        records.append({'file':alias+'.gz','bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
    for name in ['release-main-integration','integrated-ci-repair-publication','integrated-ci-repair-hosted']:
        for file in sorted((scratch/name).rglob('*')):
            if file.is_file():archive(name+'/'+str(file.relative_to(scratch/name)),file)
    for name in ['reviewed-witness-refresh','unicode-witness','maintained-issue-cases','all-local-gates']:
        for suffix in ['stdout','stderr']:archive(name+'.'+suffix,out/(name+'.'+suffix))
    for name in ['integrate-release-main.py','resolve-release-main-conflicts.py','refresh-release-main-witness.mjs','finish-release-main-integration.py','publish-integrated-ci-repairs.py','collect-integrated-ci-repairs.py']:
        archive('helpers/'+name,scratch/name)
    for file in sorted((root/'experiments/formal_ai_subagent/sandboxes/gates').iterdir()):
        if file.is_file():archive('local-gate-logs/'+file.name,file)
    (evidence/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
    run('stage-tracked',['git','add','-u'])
    run('stage-evidence',['git','add','--',str(evidence.relative_to(root)),str(note.relative_to(root))])
    run('naming',['node','scripts/measure-abbreviations.mjs','--check'])
    staged=subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=ACMRT','-z'],cwd=root).decode().split('\0')[:-1]
    run('secrets',['bash','scripts/check-secrets.sh',*staged])
    run('whitespace',['git','diff','--cached','--check'])
    run('commit',['git','-c','gc.auto=0','commit','-m','Merge released main and retain reviewed CI witness identities'])
    head=run('committed-head',['git','rev-parse','HEAD']).strip()
    (out/'outcome.json').write_text(json.dumps({'head':head,'integratedMain':main,'allPassing':True,'localGates':counts,'warnings':64,'published':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
