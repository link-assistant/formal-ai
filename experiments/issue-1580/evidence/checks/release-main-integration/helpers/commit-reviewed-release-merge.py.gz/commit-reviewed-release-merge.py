from pathlib import Path
import json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/release-merge-before-gates');out.mkdir(exist_ok=False)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=256'
env['PATH']='/tmp/issue-1580-research/secretlint-built-in-migration/dependencies/node_modules/.bin:'+env['PATH']
def run(name,args):
    with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
        result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    assert result.returncode==0,(name,result.returncode)
    return (out/(name+'.stdout')).read_text()
assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
assert run('merge-parent',['git','rev-parse','MERGE_HEAD']).strip()=='f574289f4559f1d8b801eca9d60bc087a4cd888f'
assert not run('conflicts',['git','diff','--name-only','--diff-filter=U']).strip()
run('stage-reviewed-witness',['git','add','--','experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8'])
staged=run('staged-paths',['git','diff','--cached','--name-only','--diff-filter=ACMRT','-z']).split('\0')[:-1]
run('actual-secretlint',['bash','scripts/check-secrets.sh',*staged])
run('whitespace',['git','diff','--cached','--check'])
run('commit',['git','-c','gc.auto=0','commit','-m','Merge released main and retain reviewed CI witness identities'])
head=run('head',['git','rev-parse','HEAD']).strip()
(out/'outcome.json').write_text(json.dumps({'head':head,'mergedMain':'f574289f4559f1d8b801eca9d60bc087a4cd888f','focusedObservationsPassed':158,'fullGateRetryPending':True,'published':False,'independentAuthorshipCredit':0})+'\n')
print(head)
