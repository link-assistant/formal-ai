import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {deserialize} from 'node:v8';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const out='/tmp/issue-1580-research/release-main-integration';
const file='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8';
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const raw=readFileSync(file),before=deserialize(raw),expected=structuredClone(before);
const review=JSON.parse(readFileSync(out+'/witness-candidate-review.json','utf8'));
assert.equal(review.beforeCases,221);assert.equal(review.afterCases,221);assert.equal(review.changes.length,4);
assert.equal(before.inventory.unsupported.length,968);
const current=hash(readFileSync('rust/Cargo.toml'));
for(const change of review.changes){
  const [inventory,cases,index,program,fixtures,fixture,property]=change.path;
  assert.deepEqual([inventory,cases,program,fixtures,property],['inventory','cases','program','fixtures','sha256']);
  const entry=expected.inventory.cases[Number(index)].program.fixtures[Number(fixture)];
  assert.equal(entry.file,'repo:rust/Cargo.toml');assert.equal(entry.sha256,change.before);assert.equal(change.after,current);
  entry.sha256=current;
}
writeFileSync(out+'/baseline-before-reviewed-refresh.v8',raw);
const reader=hash(readFileSync('scripts/lib/rust-specification-cases.mjs'));
assert.equal(reader,'861c6c5b40cfc8f4e99ad0ebece2cc3c20f941c6a1103dd5e8e70813c40ee0ca');
execFileSync(process.execPath,['--max-old-space-size=256','rust/tests/web/rust-specification-unicode-identifiers.test.mjs','--refresh-reviewed-baseline','--reviewed-reader-sha='+reader,'--previous-baseline-sha='+hash(raw)],{stdio:'inherit'});
const afterRaw=readFileSync(file),after=deserialize(afterRaw);
assert.deepEqual(after,expected);
writeFileSync(out+'/witness-refresh-proof.json',JSON.stringify({beforeSha256:hash(raw),afterSha256:hash(afterRaw),readerSha256:reader,cargoSha256:current,changedReferences:4,supportedCases:221,unsupportedItems:968,completeObjectEqualityExceptReviewedCargoHashes:true,fullIssueComplete:false,independentAuthorshipCredit:0},null,2)+'\n');
