from pathlib import Path
import json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/release-main-integration')
baseline='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8'
for stage in [1,2,3]:
    raw=subprocess.check_output(['git','show',':'+str(stage)+':'+baseline],cwd=root)
    (out/('baseline-stage-'+str(stage)+'.v8')).write_bytes(raw)
(root/baseline).write_bytes((out/'baseline-stage-2.v8').read_bytes())
fragment='changelog.d/20261117_190000_picomatch_security_backport.md'
text=subprocess.check_output(['git','show',':2:'+fragment],cwd=root)
destination='changelog.d/issue-1580-picomatch-backport-validation.md'
assert not (root/destination).exists();(root/destination).write_bytes(text)
subprocess.run(['git','rm','--',fragment],cwd=root,check=True)
subprocess.run(['git','add','--',baseline,destination],cwd=root,check=True)
with (out/'witness-candidate-review.stdout').open('w') as stdout,(out/'witness-candidate-review.stderr').open('w') as stderr:
    result=subprocess.run(['node','--max-old-space-size=256','/tmp/issue-1580-research/review-governed-baseline.mjs'],cwd=root,stdout=stdout,stderr=stderr)
assert result.returncode==0
review=Path('/tmp/issue-1580-research/governed-baseline-review.json')
(out/'witness-candidate-review.json').write_bytes(review.read_bytes())
value=json.loads(review.read_text());print(json.dumps({'beforeCases':value['beforeCases'],'afterCases':value['afterCases'],'changes':[{'path':'/'.join(row['path']),'before':row['before'],'after':row['after']} for row in value['changes']]}))
