from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/release-main-integration');out.mkdir(exist_ok=False)
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
with (out/'merge.stdout').open('w') as stdout,(out/'merge.stderr').open('w') as stderr:
    result=subprocess.run(['git','-c','gc.auto=0','merge','--no-commit','--no-ff','origin/main'],cwd=root,stdout=stdout,stderr=stderr)
assert result.returncode in [0,1]
conflicts=subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=root,text=True).splitlines()
(out/'observation.json').write_text(json.dumps({'mergeExitCode':result.returncode,'conflicts':conflicts},indent=2)+'\n')
print((out/'observation.json').read_text())
