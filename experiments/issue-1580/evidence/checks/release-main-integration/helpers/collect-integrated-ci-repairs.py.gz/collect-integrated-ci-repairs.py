from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,os,subprocess,sys,time,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'integrated-ci-repair-hosted'
repo='link-assistant/formal-ai';branch='issue-1580-8d61a32a61e1'
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('w') as stream:
        worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
records=[];saved={};base=None
def run(name,args,allowed=(0,)):
    assert name not in saved
    rawfile=out/(name+'.temporary')
    with rawfile.open('wb') as stdout:
        result=subprocess.run(args,cwd=root,stdout=stdout,stderr=subprocess.PIPE)
    packed=base/(name+'.stdout.gz');digest=hashlib.sha256();size=0;lines=0;last=b''
    with rawfile.open('rb') as source,packed.open('wb') as target,gzip.GzipFile(fileobj=target,mode='wb',mtime=0,filename='') as archive:
        while True:
            chunk=source.read(1024*1024)
            if not chunk:break
            digest.update(chunk);size+=len(chunk);lines+=chunk.count(b'\n');last=chunk[-1:];archive.write(chunk)
    if size and last!=b'\n':lines+=1
    with packed.open('rb') as stream: packed_hash=hashlib.file_digest(stream,'sha256').hexdigest()
    stderr=base/(name+'.stderr.gz');stderr.write_bytes(gzip.compress(result.stderr,mtime=0))
    record={'name':name,'exitCode':result.returncode,'stdout':{'file':packed.name,'rawSha256':digest.hexdigest(),'archiveSha256':packed_hash,'bytes':size,'lines':lines},'stderr':{'file':stderr.name,'rawSha256':hashlib.sha256(result.stderr).hexdigest(),'archiveSha256':hashlib.sha256(stderr.read_bytes()).hexdigest(),'bytes':len(result.stderr)}}
    records.append(record);saved[name]=record;(base/'records.json').write_text(json.dumps(records,separators=(',',':'))+'\n')
    assert result.returncode in allowed,(name,result.returncode,result.stderr.decode(errors='replace')[-1000:])
    if size<2*1024*1024: raw=rawfile.read_bytes()
    else: raw=None
    rawfile.unlink()
    return raw
try:
    publication=scratch/'integrated-ci-repair-publication'
    while not (publication/'outcome.json').exists():
        assert not (publication/'failure.json').exists()
        time.sleep(5)
    head=json.loads((publication/'outcome.json').read_text())['head']
    base=root/'experiments/issue-1580/evidence/ci'/('integrated-repairs-'+head[:8]);base.mkdir(exist_ok=False)
    complete=False;started=datetime.now(timezone.utc).isoformat()
    for tick in range(120):
        raw=run('observation-'+str(tick).zfill(3),['gh','run','list','--repo',repo,'--branch',branch,'--limit','100','--json','databaseId,workflowName,status,conclusion,headSha,createdAt,updatedAt,url'])
        current=[row for row in json.loads(raw) if row['headSha']==head]
        for workflow in current:
            if workflow['status']!='completed':continue
            identifier=str(workflow['databaseId']);logname='full-run-'+identifier
            if logname not in saved:run(logname,['gh','run','view',identifier,'--repo',repo,'--log'],(0,1) if workflow['conclusion']=='skipped' else (0,))
            jobname='jobs-'+identifier
            if jobname not in saved:
                raw=run(jobname,['gh','api','repos/'+repo+'/actions/runs/'+identifier+'/jobs','--paginate','--jq','.jobs[] | tojson'])
                jobs=[json.loads(line) for line in raw.splitlines() if line.strip()]
                for job in jobs:
                    if job['conclusion'] not in ['success','skipped']:
                        run('failed-job-'+str(job['id']),['gh','run','view',identifier,'--repo',repo,'--job',str(job['id']),'--log'])
        failed=[{'id':row['databaseId'],'name':row['workflowName'],'conclusion':row['conclusion'],'url':row['url']} for row in current if row['status']=='completed' and row['conclusion'] not in ['success','skipped']]
        status={'head':head,'observedAt':datetime.now(timezone.utc).isoformat(),'workflowCount':len(current),'completed':sum(row['status']=='completed' for row in current),'success':sum(row['conclusion']=='success' for row in current),'failed':failed,'runs':current,'fullIssueComplete':False}
        (out/'latest.json').write_text(json.dumps(status,indent=2)+'\n');(base/'latest.json').write_text(json.dumps(status,indent=2)+'\n')
        print(json.dumps({k:v for k,v in status.items() if k!='runs'}),flush=True)
        if len(current)>=26 and all(row['status']=='completed' for row in current):complete=True;break
        time.sleep(30)
    run('pull-request-checks',['gh','pr','checks','1581','--repo',repo,'--json','name,state,bucket,workflow,link'],(0,1,8))
    result={'complete':complete,'head':head,'startedAt':started,'workflowCount':len(current),'success':status['success'],'failed':failed,'fullIssueComplete':False,'independentAuthorshipCredit':0}
    (out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');(base/'outcome.json').write_text(json.dumps(result,indent=2)+'\n')
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
