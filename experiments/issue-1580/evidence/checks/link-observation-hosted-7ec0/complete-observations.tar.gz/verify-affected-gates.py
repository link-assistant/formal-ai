from pathlib import Path
import subprocess,json,datetime,os,shutil,re
r=Path('/tmp/issue-1580-research/link-observation-hosted-7ec0')
env=os.environ.copy();env.pop('NODE_OPTIONS',None);records=[]
gates=['check-abbreviations','check-file-size','check-file-size-js-twin','check-minimal-core-boundary','check-minimal-core-boundary-js-twin','check-debt-ratchet-js-twin','check_debt_ratchet','check-changelog-fragment-js-twin']
d=r/'complete-gate-outputs';d.mkdir(exist_ok=True)
for gate in gates:
 cmd=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]
 with (r/(gate+'.log')).open('wb') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
 source=Path('experiments/formal_ai_subagent/sandboxes/gates')/(gate+'.log')
 if source.exists():shutil.copyfile(source,d/(gate+'.log'))
 records.append({'gate':gate,'command':cmd,'exitCode':p.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 (r/'gate-records.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records[-1]),flush=True)
(r/'gate-outcome.json').write_text(json.dumps({'complete':True,'allPassed':all(x['exitCode']==0 for x in records),'records':records},indent=2)+'\n')
