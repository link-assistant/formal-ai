from pathlib import Path
import collections,datetime,gzip,hashlib,io,json,subprocess,tarfile,zipfile
r=Path('/tmp/issue-1580-research')
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='114d366e89d6717f8d9990d8c0ed2d308e13832a'
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
prior=(r/'seal-extracted-native-modules.py').read_text()
exec(prior[prior.index('def seal('):prior.index('cohort=r/')])
root=r/'failed-consumer-rerun-qualification'
historical=json.loads((root/'outcome.json').read_text());assert historical['complete'] and not historical['producerReran'] and len(historical['nativeConsumers'])==3
files={p.relative_to(r).as_posix():p for p in root.iterdir() if p.is_file()}
for name in ['qualify-actual-failed-consumer-rerun-v2.py','finish-historical-rerun.py']:files['supplied-orchestration/'+name]=r/name
seal('actual-failed-consumer-rerun-20261123',files,{'source':historical['source'],'comparedArtifactSourceHead':'8190c9efaa82777e576b7bae18297d2de33dcf9d','run':45085971679,'attempt':2,'nativeConsumersExecuted':3,'producerReran':False,'originalArtifactReused':14778573986,'historicalSemanticFailuresRetained':True,'currentHeadNativeSuccess':False,'wholeCliLogUnavailable':True,'availableArchiveAndIndividualConsumerLogsVerified':True})
root=r/'extracted-witness-head-ci-v2'
ci=json.loads((root/'outcome.json').read_text());assert ci['complete'] and len(ci['runs'])==33 and all(v['status']=='completed' for v in ci['runs'])
counts=dict(collections.Counter(v['conclusion'] for v in ci['runs']));assert counts=={'success':31,'cancelled':1,'skipped':1},counts
with zipfile.ZipFile(root/'available-logs-45136124038.zip') as z:
 raw=z.read('0_Pipeline Status.txt');lines=raw.decode().splitlines()
 assert 'Failed jobs: <none>' in raw.decode() and 'Cancelled jobs: native-type-check' in raw.decode()
 (root/'pipeline-status-complete.txt').write_bytes(raw)
 (root/'pipeline-status-line-index.txt').write_text('\n'.join(str(i+1)+': '+line for i,line in enumerate(lines))+'\n')
files={p.relative_to(r).as_posix():p for p in root.iterdir() if p.is_file()}
for name in ['collect-extracted-witness-head-ci-v2.py','extracted-witness-head-ci-v2-worker.log']:files['supplied-orchestration/'+name]=r/name
seal('terminal-8190-ci-20261123',files,{'source':ci['head'],'workflows':33,'conclusions':counts,'pipelineRun':45136124038,'pipelineStatusJobFailedForCancelledNativeChecks':True,'nativeConsumersDidNotExecute':True,'nativeProducerAndRegistrySucceeded':True,'missingLogsAreNotExecutionEvidence':True,'localRerunRepairCommit':'bd586bfd24275b7b2fc757dff9d1a2fe74b6cba2'})
root=r/'upstream-refresh-20261123-0950'
calc=json.loads((root/'calculator-jiff-issue.stdout.json').read_text());assert calc['state']=='open' and 'pull_request' not in calc
cs=json.loads((root/'command-stream-jiff-corrected.stdout.json').read_text());assert cs['merged'] and cs['merged_at']
for name in ['command-stream','link-calculator']:assert json.loads((root/(name+'.crate.json')).read_text())['crate']['newest_version'] in ['1.13.0','0.24.0']
files={p.relative_to(r).as_posix():p for p in root.iterdir() if p.is_file()}
for name in ['refresh-upstream-0950.py','refresh-corrected-upstream.py','refresh-calculator-issue.py']:files['supplied-orchestration/'+name]=r/name
seal('upstream-blocker-refresh-20261123-0946',files,{'source':'114d366e89d6717f8d9990d8c0ed2d308e13832a','commandStreamPullRequest240Merged':True,'calculatorIssue265Open':True,'latestPublishedVersions':{'command-stream':'1.13.0','link-calculator':'0.24.0'},'wrongRepositoryAndWrongPullRequestLookupsHaveNoCredit':True,'registryPublicationOfMigrationVerified':False,'codeqlAndServingIdentityIssuesRemainOpen':True})
coverage=r/'remaining-maintained-diff-review-8190/review-coverage.json'
d=json.loads(coverage.read_text());d['compactLiteralChunksRead']=list(range(9,44));d['updatedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
d['notes'].update({'compact-33-35':'Reviewed checkout and installed-resource closures, valid TOML spellings versus decoys, independent package audits, literal documentation fences, all-file hosted shard bounds, bounded large Git inventories and fail-closed partial output.','compact-36-38':'Reviewed provenance fixture partition conservation, streaming generator-header boundaries, quoted request and multilingual passage cues, real Git delivery controls versus explicit network/compiler mocks, immutable main identity and per-invocation version selection.','compact-39-41':'Reviewed CI fallback selection epoch invalidation, retained historical AST source-byte captures and digest checks, current source edits/moves/deletion, complete paginated PR discovery, lazy private diagnostics, selected-child evidence and concrete program output obligations.','compact-42-43':'Reviewed Git inventory failure and empty success controls, JavaScript candidate commit/clean-state binding, canonical source reassembly, unsafe/corrupt artifact refusal, all 99 adapter consumers and real multi-host transfer qualification, exact ordered runner queue/file results, factual round-trip semantics and Pages artifact ID outputs.'})
assert not d['remainingMaintainedReviewComplete'] and not d['completeAggregateReview'];coverage.write_text(json.dumps(d,indent=2)+'\n')
p=Path('docs/case-studies/issue-1580/rerun-cancellation.md');s=p.read_text();old='Hosted qualification of this repair, actual artifact rerun qualification,\naggregate source review and the remaining original acceptance criteria are\nunfinished.';new='The actual historical failed-consumer rerun now qualifies reuse of the original\nproducer artifact without recompilation; its old semantic failures remain failures.\nThe [terminal cohort and rerun receipt](ci-qualification-20261123.md) records that\nlimited result. Hosted qualification of the cancellation repair, aggregate source\nreview and the remaining original acceptance criteria are unfinished.';assert old in s;p.write_text(s.replace(old,new))
case='''# Terminal CI and historical artifact rerun qualification

The terminal cohort at 8190c9efaa82777e576b7bae18297d2de33dcf9d has 31
successful workflows, one explicit skip and one cancelled workflow. Its
[Pipeline run](https://github.com/link-assistant/formal-ai/actions/runs/45136124038)
reports no failed prerequisite jobs and cancelled `native-type-check` checks.
The Pipeline Status job exits 1 at 09:29:06 UTC on 2026-11-23. These are distinct
workflow and job conclusions. The producer and registry checks succeeded; the
queued Clippy job and ten consumers were cancelled without executing.

The complete available status log is indexed in the
[terminal cohort receipt](../../../experiments/issue-1580/evidence/checks/terminal-8190-ci-20261123/manifest.json).
The ordinary CLI whole-log command failed because one cancelled job has no log.
The available ZIP was verified, and missing logs earn no execution credit.
[Layered CI](https://github.com/link-assistant/formal-ai/actions/runs/45136122908)
passes the previously stale fixture witness. The cancellation reproduction and
local repair are described in [rerun cancellation](rerun-cancellation.md).
Qualification of that repair on a new hosted head remains pending.

The actual `gh run rerun --failed` operation on historical
[run 45085971679](https://github.com/link-assistant/formal-ai/actions/runs/45085971679/attempts/2)
reexecuted all three previously failing consumers. It retained artifact
14778573986 from attempt 1, with no producer reexecution or attempt-2 upload.
Each consumer log identifies that artifact and actual native test execution.
GitHub copied successful jobs into the new attempt with new IDs but old start
times; comparison with the rerun request time prevents counting those as runs.

| Reexecuted consumer | Job | Native result |
| --- | --- | --- |
| reasoning-1 | 137573053282 | 80 passed, 2 failed |
| reasoning-2 | 137573053334 | 83 passed, 1 failed |
| interfaces | 137573053365 | 79 passed, 1 failed |

The historical assertions still fail: source-refusal provenance at reasoning-1
log lines 863-870, missing ambiguity wording at 895-899, bare documentation
wording at reasoning-2 lines 883-888, and the named synthesis skill gap at
interfaces lines 881-890. The full logs and available archive remain in the
[actual failed-consumer receipt](../../../experiments/issue-1580/evidence/checks/actual-failed-consumer-rerun-20261123/manifest.json).
This demonstrates original-artifact lookup and execution, not passing tests for
the current source. The compared artifact helper paths match head 8190; this
receipt does not claim that every later edit is identical.

The dated [upstream refresh](../../../experiments/issue-1580/evidence/checks/upstream-blocker-refresh-20261123-0946/manifest.json)
confirms that [command-stream PR 240](https://github.com/link-foundation/command-stream/pull/240)
is merged, while the latest published crate remains 1.13.0. The latest
link-calculator is 0.24.0 and its
[migration issue 265](https://github.com/link-assistant/calculator/issues/265)
is open. Wrong-repository lookups and a mistaken pull-request lookup were
retained with their errors and receive zero verification credit. The
[CodeQL included-file context issue](https://github.com/github/codeql/issues/23198)
and [serving-identity report](https://github.com/link-assistant/hive-mind/issues/3909)
also remain open. A merged upstream change does not establish published
migration availability or repair either dependency graph.

All sealed archive members were reopened and checked against their lengths and
SHA-256 digests. Supplied orchestration receives zero independent authorship
credit. Aggregate source review, complete template practice acceptance and the
remaining original criteria are unfinished.
[PR #1581](https://github.com/link-assistant/formal-ai/pull/1581) stays draft
and unmerged.
'''
Path('docs/case-studies/issue-1580/ci-qualification-20261123.md').write_text(case)
p=Path('experiments/issue-1580/work-plan.md');s=p.read_text();checkpoint='''## Active checkpoint: terminal cohort and actual failed-consumer reuse (2026-11-23)

- Head 8190 has 31 successful workflows, one explicit skip and one cancelled Pipeline workflow. Its status job fails for cancelled native checks; missing logs earn no execution credit. The Layered witness regression now passes hosted CI.
- The historical failed-consumer rerun finished. All three consumers fetched original attempt-1 artifact 14778573986 and executed without a producer rerun or new upload. Their old semantic failures remain failures; this is artifact-reuse qualification only.
- Local cancellation repair bd586bfd2 and Rust practice evidence 114d366e8 await one batch push and latest-head hosted qualification. All affected local JavaScript checks and gates already pass.
- Remaining maintained review: original literal chunks 0,1,2,6,7 and compact chunks 9 through 43 read; exact grammar and module-move conservation proofs checked. Full aggregate review remains unfinished.
- Fresh upstream evidence: command-stream PR 240 merged, published command-stream still 1.13.0; link-calculator 0.24.0 and migration issue 265 open. CodeQL context and serving-identity reports remain open. Failed mistaken lookups are retained with zero credit.
- Complete template execution/adoption, strict style debt disposition, original family and full-suite budgets, main-only publication/delivery, cache reliability, live useful delivery, trusted cross-request epochs and registry authority remain unfinished. No waiver or report counts as acceptance. Keep PR #1581 draft and unmerged.
- The existing native goal is usage-limited; the unchanged issue-completion objective and all unfinished acceptance criteria remain tracked here.

''';p.write_text(checkpoint+s)
print('Drafted terminal cohort documentation and preserved complete observations.')
