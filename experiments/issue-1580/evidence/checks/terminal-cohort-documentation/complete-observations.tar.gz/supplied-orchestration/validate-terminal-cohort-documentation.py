from pathlib import Path
import os,sys,json,subprocess,datetime
r=Path('/tmp/issue-1580-research/terminal-cohort-documentation-validation')
if '--worker' not in sys.argv:
 r.mkdir(exist_ok=False)
 with (r/'worker.log').open('wb') as f:p=subprocess.Popen([sys.executable,__file__,'--worker'],stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 (r/'pid').write_text(str(p.pid)+'\n');print(json.dumps({'pid':p.pid,'directory':str(r)}));raise SystemExit()
rows=[]
for name,cmd in [(g,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',g]) for g in ['check-file-size','check-readable-code','check-required-documentation','check-tests-as-docs']]+[('whitespace',['git','diff','--check'])]:
 with (r/(name+'.log')).open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':cmd,'exitCode':p.returncode})
 (r/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
result={'total':len(rows),'failed':[v for v in rows if v['exitCode']],'complete':True,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(r/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
