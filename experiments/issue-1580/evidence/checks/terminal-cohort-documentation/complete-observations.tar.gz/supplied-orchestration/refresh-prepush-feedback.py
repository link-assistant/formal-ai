from pathlib import Path
import json,gzip,subprocess,datetime
r=Path('/tmp/issue-1580-research');dest=r/'prepush-feedback-20261123-1000';dest.mkdir(exist_ok=False)
repo='link-assistant/formal-ai'
rows=[]
def capture(name,cmd):
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (dest/(name+'.stdout')).write_bytes(p.stdout);(dest/(name+'.stderr')).write_bytes(p.stderr)
 rows.append({'name':name,'command':cmd,'exitCode':p.returncode});(dest/'records.json').write_text(json.dumps(rows,indent=2)+'\n')
 p.check_returncode();return p.stdout
for label,endpoint,old in [('issue-comments','issues/1580/comments','issue-comments-rerun-repair.json'),('pr-conversation','issues/1581/comments','pr-conversation-rerun-repair.json'),('pr-inline','pulls/1581/comments','pr-inline-rerun-repair.json'),('pr-reviews','pulls/1581/reviews','pr-reviews-rerun-repair.json')]:
 raw=capture(label,['gh','api','repos/'+repo+'/'+endpoint,'--paginate','--slurp'])
 def flatten(d):return [item for page in d for item in page] if d and isinstance(d[0],list) else d
 current=flatten(json.loads(raw));previous=flatten(json.loads((r/old).read_text()))
 prior={v['id']:v for v in previous};changed=[v for v in current if v['id'] not in prior or any(v.get(k)!=prior[v['id']].get(k) for k in ['body','updated_at','state','submitted_at'])]
 print(json.dumps({'feedback':label,'count':len(current),'changed':changed}),flush=True)
main=json.loads(capture('main',['gh','api','repos/'+repo+'/commits/main']))['sha']
assert main=='03a636334975cd7ca5cedff119e2dd0efbc8579f',main
capture('fetch-main',['git','fetch','origin','main'])
capture('main-ancestor',['git','merge-base','--is-ancestor',main,'HEAD'])
for status in ['in_progress','queued']:
 data=json.loads(capture(status,['gh','run','list','--repo',repo,'--branch','issue-1580-8d61a32a61e1','--status',status,'--limit','100','--json','databaseId,workflowName,headSha']))
 assert not data,(status,data)
print(json.dumps({'main':main,'mainIsAncestor':True,'queuedAndInProgressEmpty':True}),flush=True)
p=r/'failed-consumer-rerun-qualification/attempt-2-job-137573053334.stdout.gz';lines=gzip.decompress(p.read_bytes()).decode().splitlines();print('\n'.join(str(i+1)+': '+line for i,line in enumerate(lines) if 875<=i<900))
(dest/'outcome.json').write_text(json.dumps({'complete':True,'main':main,'mainIsAncestor':True,'queuedAndInProgressEmpty':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
