from pathlib import Path
import collections,datetime,gzip,hashlib,io,json,subprocess,tarfile,zipfile,re
r=Path('/tmp/issue-1580-research')
prior=(r/'seal-extracted-native-modules.py').read_text()
exec(prior[prior.index('def seal('):prior.index('cohort=r/')])
first=r/'terminal-cohort-documentation-validation'
assert (first/'outcome.json').exists(), 'wait for the preliminary worker before moving its files'
assert json.loads((first/'outcome.json').read_text())['complete']
first.rename(r/'terminal-cohort-pre-draft-validation')
s=(r/'seal-terminal-cohort-and-rerun.py').read_text()
s=s[s.index("root=r/'extracted-witness-head-ci-v2'"):]
s=s.replace("assert 'Failed jobs: <none>' in raw.decode() and 'Cancelled jobs: native-type-check' in raw.decode()", "assert re.search(r'Failed jobs:\\s+<none>',raw.decode()) and 'Cancelled jobs: native-type-check' in raw.decode()")
exec(compile(s,'continued-terminal-seal','exec'))
print('Pre-draft documentation validation retained without final-draft verification credit.')
