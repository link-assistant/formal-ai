from pathlib import Path
import subprocess,json,os,time,datetime,shutil
r=Path('/tmp/issue-1580-research/e462-shard-repair/final-prepush')
env=os.environ.copy();env.pop('NODE_OPTIONS',None);records=[]
gates=['check-abbreviations','check-file-size','check-file-size-js-twin','check-minimal-core-boundary','check-minimal-core-boundary-js-twin','check-debt-ratchet-js-twin','check_debt_ratchet','check-changelog-fragment-js-twin']
d=r/'complete-gate-outputs';d.mkdir(exist_ok=True)
for gate in gates:
 cmd=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate];start=time.monotonic()
 with (r/(gate+'.log')).open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 source=Path('experiments/formal_ai_subagent/sandboxes/gates')/(gate+'.log')
 if source.exists():shutil.copyfile(source,d/source.name)
 rec={'gate':gate,'exitCode':p.returncode,'seconds':time.monotonic()-start};records.append(rec)
 (r/'gate-records.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(rec),flush=True)
(r/'gates-outcome.json').write_text(json.dumps({'complete':True,'allPassed':all(x['exitCode']==0 for x in records),'records':records},indent=2)+'\n')
paths=set()
for cmd in [['git','diff','--name-only','origin/issue-1580-8d61a32a61e1','--diff-filter=ACMRT','-z'],['git','ls-files','--others','--exclude-standard','-z']]:
 p=subprocess.run(cmd,capture_output=True,check=True);paths.update(x.decode() for x in p.stdout.split(bytes([0])) if x)
paths=sorted(p for p in paths if Path(p).is_file());(r/'secret-scan-paths.json').write_text(json.dumps(paths,indent=2)+'\n')
cmd=['bash','scripts/check-secrets.sh',*paths];start=time.monotonic()
with (r/'secret-scan.log').open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
out={'complete':True,'exitCode':p.returncode,'files':len(paths),'seconds':time.monotonic()-start}
(r/'secret-scan-outcome.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
