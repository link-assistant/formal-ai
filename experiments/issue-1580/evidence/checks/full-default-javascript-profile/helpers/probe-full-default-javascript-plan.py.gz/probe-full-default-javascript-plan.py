from pathlib import Path
import json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/full-default-javascript-plan');out.mkdir(exist_ok=False)
code='''import {readdirSync,readFileSync} from 'node:fs';
import {readTestDurations} from './scripts/lib/ci-speed-durations.mjs';
import {durationLookup,planShards,partitionProblems,isLongestFirst} from './scripts/lib/ci-speed-shards.mjs';
const path='data/meta/javascript-test-durations.lino',files=readdirSync('rust/tests/web').filter(name=>name.endsWith('.test.mjs')).map(name=>'rust/tests/web/'+name);
const secondsOf=durationLookup(readTestDurations(path),Number(readFileSync(path,'utf8').match(/^  default-seconds (\\S+)$/mu)[1]));
const groups=planShards(files,8,secondsOf);
console.log(JSON.stringify({count:files.length,groups:groups.shards.map((files,index)=>({group:index+1,count:files.length,seconds:groups.load[index],fourWorkerSeconds:Math.max(...planShards(files,4,secondsOf).load)})),partition:partitionProblems(files,groups.shards),longestFirst:isLongestFirst(groups.shards,secondsOf),measurementsProveActualExecution:false},null,2));
'''
(out/'probe.mjs').write_text(code);env=os.environ.copy();env.pop('NODE_OPTIONS',None)
with (out/'stdout.json').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:run=subprocess.run(['node','--max-old-space-size=256','--input-type=module','-e',code],cwd=root,env=env,stdout=stdout,stderr=stderr)
assert run.returncode==0;print((out/'stdout.json').read_text())
