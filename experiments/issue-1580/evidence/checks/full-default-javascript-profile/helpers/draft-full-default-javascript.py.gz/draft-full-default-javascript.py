from pathlib import Path
import json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/full-default-javascript');out.mkdir(exist_ok=True)
test=root/'experiments/issue-1580/full-default-javascript-profile.test.mjs'
test.write_text(r'''// Replay the real hosted selector and runner without compiling product sources.
import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,readFileSync,readdirSync,rmSync,writeFileSync} from 'node:fs';
import {join,relative} from 'node:path';
import {tmpdir} from 'node:os';
import {spawnSync} from 'node:child_process';
import {Script} from 'node:vm';
import YAML from 'yaml';
const read=file=>readFileSync(file,'utf8');
function evaluate(value,event,ref) {
  if(typeof value!=='string')return value;
  return new Script(value.replace(/^\$\{\{\s*|\s*\}\}$/gu,''))
    .runInNewContext({github:{event_name:event,ref},fromJSON:JSON.parse},{timeout:100});
}
test('PR, feature dispatch and main plan the identical complete default JavaScript suite',{timeout:30000},t=>{
  const job=YAML.parse(read('.github/workflows/layered-ci.yml')).jobs.js;
  const plan=job.steps.find(step=>step.id==='javascript-plan');
  const execute=job.steps.find(step=>step.name==='Run this shard of the JavaScript suites');
  const expected=readdirSync('rust/tests/web').filter(name=>name.endsWith('.test.mjs')).map(name=>'rust/tests/web/'+name).sort();
  assert(expected.includes('rust/tests/web/pull-request-1188-teach-f.test.mjs'));
  const directory=mkdtempSync(join(tmpdir(),'complete-javascript-plan-'));
  t.after(()=>rmSync(directory,{recursive:true,force:true}));
  for(const [event,ref] of [['pull_request','refs/pull/1581/merge'],['workflow_dispatch','refs/heads/feature'],['push','refs/heads/main']]){
    const shards=Array.from(evaluate(job.strategy.matrix.shard,event,ref));
    assert.deepEqual(shards,[1,2,3,4,5,6,7,8]);
    assert.equal(evaluate(plan.env.SHARDS,event,ref),8);
    assert.equal(evaluate(execute.env.SHARDS,event,ref),8);
    assert.equal(plan.env.FAST_PR_PROFILE,undefined);
    assert.equal(execute.env.FAST_PR_PROFILE,undefined);
    const actual=[];
    for(const shard of shards){
      const output=join(directory,'outputs');writeFileSync(output,'');
      const result=spawnSync('bash',['-c',plan.run],{encoding:'utf8',timeout:10000,maxBuffer:65536,
        env:{...process.env,RUNNER_TEMP:directory,GITHUB_OUTPUT:output,SHARD:String(shard),SHARDS:'8'}});
      assert.equal(result.error,undefined,String(result.error));
      assert.equal(result.status,0,result.stdout+result.stderr);
      const selected=read(join(directory,'javascript-shard.txt')).trim().split('\n');
      actual.push(...selected);
      assert.equal(read(output),`python-required=${selected.includes('rust/tests/web/issue-1580-template-observations.test.mjs')}\n`);
    }
    assert.deepEqual(actual.sort(),expected,event+' must neither omit nor duplicate suites');
  }
});
test('the shared ordered runner reports two failures and still finishes the later passing file',{timeout:15000},t=>{
  const directory=mkdtempSync(join(tmpdir(),'javascript-continue-failures-'));
  t.after(()=>rmSync(directory,{recursive:true,force:true}));
  const files=['first-failure','second-failure','later-success'].map((name,index)=>{
    const file=join(directory,name+'.test.mjs');
    writeFileSync(file,`import test from 'node:test';\ntest('${name}',()=>{${index<2?`throw new Error('${name}-diagnostic');`:''}});\n`);
    return file;
  });
  const env={...process.env};delete env.NODE_TEST_CONTEXT;
  const result=spawnSync(process.execPath,['--max-old-space-size=64','scripts/run-ordered-javascript-tests.mjs','--concurrency','1',...files],{
    encoding:'utf8',timeout:10000,maxBuffer:65536,env});
  assert.equal(result.error,undefined,String(result.error));
  assert.equal(result.status,1,result.stdout+result.stderr);
  for(const [index,file] of files.entries()){
    const prefix='[test-file] '+(index<2?'failed ':'completed ')+relative(process.cwd(),file)+' ';
    const rows=result.stderr.split('\n').filter(line=>line.startsWith(prefix));
    assert.equal(rows.length,1,result.stderr);
    assert(Number.isFinite(JSON.parse(rows[0].slice(prefix.length)).duration_ms));
  }
  for(const name of ['first-failure-diagnostic','second-failure-diagnostic','later-success'])assert(result.stdout.includes(name),result.stdout);
});
''')
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
def check(name,file,expected=0):
    args=['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',file]
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:run=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    assert run.returncode==expected,(name,run.returncode)
    return {'name':name,'arguments':args,'exitCode':run.returncode}
records=[check('before','experiments/issue-1580/full-default-javascript-profile.test.mjs',1)]
assert '# pass 1\n# fail 1' in (out/'before.stdout').read_text()
workflow=root/'.github/workflows/layered-ci.yml';source=workflow.read_text();start=source.index('  js:\n');end=source.index('\n  # Issue #1186 R4:',start);body=source[start:end]
old="${{ (github.event_name == 'pull_request' || (github.event_name == 'workflow_dispatch' && github.ref != 'refs/heads/main')) && 4 || 8 }}"
assert body.count(old)==2;body=body.replace(old,'8')
import re
body,count=re.subn(r"shard: \$\{\{[^\n]+\}\}", 'shard: [1, 2, 3, 4, 5, 6, 7, 8]',body);assert count==1,count
flag="          FAST_PR_PROFILE: ${{ (github.event_name == 'pull_request' || (github.event_name == 'workflow_dispatch' && github.ref != 'refs/heads/main')) }}\n"
assert body.count(flag)==2;body=body.replace(flag,'',1).replace('FAST_PR_PROFILE','PULL_REQUEST_CHECKS')
selector='''          if [[ "$FAST_PR_PROFILE" == 'true' ]]; then
            node scripts/list-fast-pull-request-tests.mjs > "$suites"
          else
            printf '%s\\n' rust/tests/web/*.test.mjs > "$suites"
          fi'''
selector=selector.replace('FAST_PR_PROFILE','PULL_REQUEST_CHECKS');assert selector in body
body=body.replace(selector,"          printf '%s\\n' rust/tests/web/*.test.mjs > \"$suites\"")
comment='''    # groups retain the complete inventory and the original execution budgets;
    # regenerated hosted timings keep the longest work first.'''
assert comment in body;body=body.replace(comment,'''    # groups retained that fast inventory. Issue #1580 removes the hosted
    # subset: PRs, feature dispatches and main use the same full default suite,
    # eight longest-first groups and unchanged execution budgets. The explicit
    # fast inventory remains available for local development only.''')
workflow.write_text(source[:start]+body+source[end:])
selector_file=root/'scripts/list-fast-pull-request-tests.mjs';source=selector_file.read_text().replace('// Explicit offline PR inventory; the full suite stays selected on main.','// Optional local feedback inventory; hosted PRs and main run the full default suite.');selector_file.write_text(source)
profile=root/'rust/tests/web/fast-pull-request-production-profile.test.mjs';source=profile.read_text().replace('{readFileSync,existsSync,','{readFileSync,readdirSync,existsSync,')
source=source.replace('=> new Script(expression.trim()',"=> typeof expression!=='string' ? expression : new Script(expression.trim()",1)
source=source.replace('step.env.FAST_PR_PROFILE','step.env.PULL_REQUEST_CHECKS')
source=source.replace("test('measured TeachF integration stays on main while fast coding and QA controls remain selected'","test('the local fast inventory stays small while hosted profiles include TeachF'")
source=source.replace("test('measured fast JavaScript plans retain every suite within four unchanged execution budgets'","test('measured full JavaScript plans retain every suite within eight unchanged execution budgets'")
source=source.replace("['pull_request', 'refs/pull/1581/merge', 4]","['pull_request', 'refs/pull/1581/merge', 8]").replace("['workflow_dispatch', 'refs/heads/feature', 4]","['workflow_dispatch', 'refs/heads/feature', 8]")
old="  const selected = selectFastTests(JSON.parse(read('data/benchmarks/fast-pull-request-javascript-tests.json')));\n  const {shards} = planShards(selected, 4, secondsOf);"
assert old in source;source=source.replace(old,"  const selected = readdirSync('rust/tests/web').filter(name=>name.endsWith('.test.mjs')).map(name=>'rust/tests/web/'+name);\n  const {shards} = planShards(selected, 8, secondsOf);");profile.write_text(source)
policy=root/'rust/tests/web/default-branch-build-policy.test.mjs';source=policy.read_text().replace('  const source = String(expression).trim()',"  if(typeof expression!=='string')return expression;\n  const source = String(expression).trim()",1)
source=source.replace('// Four fast PR groups retain the deadline and divide by the same matrix count.','// The same eight full-suite groups retain the deadline on every hosted profile.').replace("test('PRs split the fast JS inventory over four groups; full main inventory retains its measured shard plan'","test('PR and main use the same complete JavaScript inventory and measured shard plan'")
source=source.replace("job.strategy.matrix.shard,'pull_request','refs/pull/1500/merge')),[1,2,3,4]","job.strategy.matrix.shard,'pull_request','refs/pull/1500/merge')),[1,2,3,4,5,6,7,8]").replace("evaluate(shards,'pull_request','refs/pull/1500/merge'),4","evaluate(shards,'pull_request','refs/pull/1500/merge'),8");policy.write_text(source)
runtime=root/'experiments/issue-1580/template-python-runtime.test.mjs';source=runtime.read_text().replace("import {selectFastTests} from '../../scripts/list-fast-pull-request-tests.mjs';\n",'')
old="    const files=shards===2\n      ? selectFastTests(JSON.parse(readFileSync(join(root,'data/benchmarks/fast-pull-request-javascript-tests.json'),'utf8')))\n      : readdirSync(join(root,'rust/tests/web')).filter(name=>name.endsWith('.test.mjs')).map(name=>'rust/tests/web/'+name);"
assert old in source;source=source.replace(old,"    const files=readdirSync(join(root,'rust/tests/web')).filter(name=>name.endsWith('.test.mjs')).map(name=>'rust/tests/web/'+name);").replace(",FAST_PR_PROFILE:String(shards===2)",'');runtime.write_text(source)
entry=root/'rust/tests/web/issue-1580-template-observations.test.mjs';entry.write_text(entry.read_text()+"import '../../../experiments/issue-1580/full-default-javascript-profile.test.mjs';\n")
records.append(check('after','experiments/issue-1580/full-default-javascript-profile.test.mjs'))
(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps({'drafted':True,'beforeFail':1,'afterPass':2,'fullSuiteRun':False}))
