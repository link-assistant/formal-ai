from pathlib import Path
import json,os,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/full-default-javascript-validation')
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(json.dumps({'pid':worker.pid,'finite':True}));sys.exit(0)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';records=[]
try:
    files=[('production-profile','rust/tests/web/fast-pull-request-production-profile.test.mjs'),('default-branch-policy','rust/tests/web/default-branch-build-policy.test.mjs'),('python-runtime','experiments/issue-1580/template-python-runtime.test.mjs'),('ci-speed','rust/tests/web/ci-speed.test.mjs'),('maintained','rust/tests/web/issue-1580-template-observations.test.mjs')]
    for name,file in files:
        args=['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',file]
        with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:run=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
        row={'name':name,'arguments':args,'exitCode':run.returncode,'summary':(out/(name+'.stdout')).read_text().splitlines()[-9:]};records.append(row);(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
    args=['node','experiments/formal_ai_subagent/local-gates.mjs']
    with (out/'all-gates.stdout').open('wb') as stdout,(out/'all-gates.stderr').open('wb') as stderr:run=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    records.append({'name':'all-local-gates','arguments':args,'exitCode':run.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records[-1]),flush=True)
    detail=out/'gate-details';detail.mkdir()
    import shutil
    for file in (root/'experiments/formal_ai_subagent/sandboxes/gates').glob('*.log'):shutil.copyfile(file,detail/file.name)
    result={'complete':all(row['exitCode']==0 for row in records),'nativeBuildRun':False,'fullHostedSuiteExecuted':False,'independentAuthorshipCredit':0,'fullIssueComplete':False};(out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
