from pathlib import Path
import subprocess,json,os
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/full-default-javascript')
file=root/'rust/tests/web/default-branch-build-policy.test.mjs';source=file.read_text();old="    '/*','!/dev/log/','!/experiments/**','/experiments/**/*.sh',"
if old not in source:
    old="'/*', '!/dev/log/', '!/experiments/**', '/experiments/**/*.sh',"
assert old in source
source=source.replace(old,old.replace("'!/dev/log/',", "'!/dev/log/','/dev/log/issues/1079/pulls/1080/upstream-reports/',"),1);file.write_text(source)
file=root/'docs/ci-cd/default-branch-builds.md';source=file.read_text();source=source.replace('PRs and checks dispatched on feature branches run essential Linux JavaScript\n  unit, coding, question-answering, reporting, policy and security checks.','PRs and checks dispatched on feature branches run the complete default Linux\n  JavaScript unit suite, including coding, question-answering, reporting, policy\n  and security checks.')
old='''- Small PR unit suites share one JavaScript runner. The broad main inventory
  retains its measured eight-shard plan. Do not shard merely to add runners.
  Native test optimization remains on main: prior measurements found expensive
  tests slower without optimization. No Rust compilation or tests run locally.'''
new='''- PRs, feature-branch check dispatches and main select the same complete default
  JavaScript inventory through the same ordered runner. All use eight measured
  longest-first shards, the unchanged 360-second execution budget and the 75%
  warning threshold. A failed file does not hide later failures or passing files.
  The explicit fast inventory remains an optional local feedback loop only;
  hosted checks do not set FAST_PR_PROFILE, which skips individual test cases.
  Native test optimization remains on main: prior measurements found expensive
  tests slower without optimization. No Rust compilation or tests run locally.'''
assert old in source;file.write_text(source.replace(old,new))
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=256'
args=['node','--test','--test-reporter=tap','--test-concurrency=1','--test-name-pattern=the focused PR native check limits execution','rust/tests/web/default-branch-build-policy.test.mjs']
with (out/'checkout-control-retry.stdout').open('wb') as stdout,(out/'checkout-control-retry.stderr').open('wb') as stderr:run=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
assert run.returncode==0,run.returncode
print(json.dumps({'staleCheckoutExpectationRepaired':True,'runtimeCheckoutUnchanged':True,'focusedRetryExit':run.returncode}))
