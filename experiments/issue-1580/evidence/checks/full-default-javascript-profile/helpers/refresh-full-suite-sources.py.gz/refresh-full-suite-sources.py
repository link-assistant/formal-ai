from pathlib import Path
import base64,hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/full-default-javascript-sources');out.mkdir(exist_ok=False)
args=['gh','api','repos/link-assistant/hive-mind/contents/docs/CI-CD-BEST-PRACTICES.md?ref=main'];run=subprocess.run(args,cwd=root,capture_output=True);(out/'guidance-response.json').write_bytes(run.stdout);(out/'guidance.stderr').write_bytes(run.stderr);assert run.returncode==0
response=json.loads(run.stdout);raw=base64.b64decode(response['content']);(out/'CI-CD-BEST-PRACTICES.md').write_bytes(raw);previous=Path('/tmp/issue-1580-research/ci-best-practices.md').read_bytes()
args=['git','fetch','--no-tags','origin','main'];run=subprocess.run(args,cwd=root,capture_output=True);(out/'fetch.stdout').write_bytes(run.stdout);(out/'fetch.stderr').write_bytes(run.stderr);assert run.returncode==0
main=subprocess.check_output(['git','rev-parse','origin/main'],cwd=root,text=True).strip();ancestry=subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],cwd=root)
result={'guidanceSha':response['sha'],'guidanceSha256':hashlib.sha256(raw).hexdigest(),'lines':len(raw.splitlines()),'guidanceUnchangedSinceReview':raw==previous,'defaultBranchHead':main,'defaultBranchMerged':ancestry.returncode==0};(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert raw==previous,'Re-read changed guidance before claiming adoption'
