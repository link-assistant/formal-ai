import {readdirSync,readFileSync} from 'node:fs';
import {readTestDurations} from './scripts/lib/ci-speed-durations.mjs';
import {durationLookup,planShards,partitionProblems,isLongestFirst} from './scripts/lib/ci-speed-shards.mjs';
const path='data/meta/javascript-test-durations.lino',files=readdirSync('rust/tests/web').filter(name=>name.endsWith('.test.mjs')).map(name=>'rust/tests/web/'+name);
const secondsOf=durationLookup(readTestDurations(path),Number(readFileSync(path,'utf8').match(/^  default-seconds (\S+)$/mu)[1]));
const groups=planShards(files,8,secondsOf);
console.log(JSON.stringify({count:files.length,groups:groups.shards.map((files,index)=>({group:index+1,count:files.length,seconds:groups.load[index],fourWorkerSeconds:Math.max(...planShards(files,4,secondsOf).load)})),partition:partitionProblems(files,groups.shards),longestFirst:isLongestFirst(groups.shards,secondsOf),measurementsProveActualExecution:false},null,2));
