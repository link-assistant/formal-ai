from pathlib import Path
import gzip, hashlib, json, os, subprocess, sys, traceback
root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research/cache-warning-publication')
if '--worker' not in sys.argv:
    with (scratch / 'validation.log').open('ab') as stream:
        worker = subprocess.Popen([sys.executable, __file__, '--worker'], cwd=root,
            stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': worker.pid, 'directory': str(scratch)})); sys.exit(0)
archive = root / 'experiments/issue-1580/evidence/checks/cache-warning-round-seal'
archive.mkdir(exist_ok=False)
records = []
try:
    for name in ['check-abbreviations', 'check-file-size', 'check-readable-code']:
        argv = ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', name]
        with (scratch / (name + '.stdout')).open('wb') as stdout, (scratch / (name + '.stderr')).open('wb') as stderr:
            result = subprocess.run(argv, cwd=root, env=dict(os.environ, NODE_OPTIONS='--max-old-space-size=192'), stdout=stdout, stderr=stderr)
        row = {'name': name, 'argv': argv, 'exitCode': result.returncode}; records.append(row)
        print(json.dumps(row), flush=True); assert result.returncode == 0, name
    result = subprocess.run(['git', 'diff', '--check'], cwd=root, capture_output=True)
    (scratch / 'whitespace.stdout').write_bytes(result.stdout); (scratch / 'whitespace.stderr').write_bytes(result.stderr)
    records.append({'name': 'whitespace', 'argv': ['git', 'diff', '--check'], 'exitCode': result.returncode})
    assert result.returncode == 0
    sources = [Path(__file__), Path('/tmp/issue-1580-research/commit-codeql-cache-retention.py'),
        Path('/tmp/issue-1580-research/commit-codeql-cache-retention.log'),
        Path('/tmp/issue-1580-research/cache-retention-final-diff-review.log'),
        Path('/tmp/issue-1580-research/record-bbda-cache-warning-checkpoint.log')]
    sources += sorted(p for p in scratch.iterdir() if p.is_file() and p.name != 'validation.log')
    inventory = []
    for source in sources:
        raw = source.read_bytes(); packed = gzip.compress(raw, mtime=0); name = source.name + '.gz'
        (archive / name).write_bytes(packed)
        inventory.append({'file': name, 'rawSha256': hashlib.sha256(raw).hexdigest(),
            'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
    (archive / 'streams.json').write_text(json.dumps(inventory, indent=2) + '\n')
    (archive / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    outcome = {'passed': True, 'currentPublishedHead': 'bbda05c06bce8e9fef10a9c8812b6b6cc31858b2',
        'publishedNativeTestsPassed': 573, 'localSizeWarnings': 92, 'newHostedCompilationPending': True,
        'cacheRepairHostedQualificationPending': True, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
    (archive / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    (scratch / 'seal.json').write_text(json.dumps(outcome, indent=2) + '\n')
    print(json.dumps(outcome), flush=True)
except Exception:
    (scratch / 'validation-failure.json').write_text(json.dumps({'records': records, 'traceback': traceback.format_exc()}, indent=2) + '\n')
    traceback.print_exc(); sys.exit(1)
