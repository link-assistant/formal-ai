from pathlib import Path
import gzip, hashlib, json, subprocess
root = Path('/tmp/gh-issue-solver-1794900398048')
archive = root / 'experiments/issue-1580/evidence/checks/codeql-cache-retention-repair'
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip() == 'issue-1580-8d61a32a61e1'
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=root, text=True).strip()
outcome = json.loads((archive / 'outcome.json').read_text())
assert outcome['passed'] and outcome['allGateEntriesCovered'] and outcome['hostedRepairQualificationPending']
for row in outcome['paths']:
    assert hashlib.sha256((root / row['path']).read_bytes()).hexdigest() == row['sha256'], row['path']
for row in json.loads((archive / 'streams.json').read_text()):
    packed = (archive / row['file']).read_bytes(); raw = gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest() == row['archiveSha256']
    assert hashlib.sha256(raw).hexdigest() == row['sha256']
    assert len(raw) == row['bytes'] and len(raw.splitlines()) == row['lines']
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
paths = [row['path'] for row in outcome['paths']] + [str(archive.relative_to(root))]
subprocess.run(['git', 'add', '--', *paths], cwd=root, check=True)
subprocess.run(['git', 'commit', '-m', 'Preserve CodeQL caches for opt-in Rust observations'], cwd=root, check=True)
print(json.dumps({'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'pushed': False, 'hostedQualificationPending': True, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}))
