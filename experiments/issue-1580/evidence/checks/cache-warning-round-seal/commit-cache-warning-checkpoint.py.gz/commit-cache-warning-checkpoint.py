from pathlib import Path
import gzip, hashlib, json, os, subprocess
root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research/cache-warning-publication')
checks = root / 'experiments/issue-1580/evidence/checks'
archive = checks / 'cache-warning-round-seal'
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip() == 'issue-1580-8d61a32a61e1'
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=root, text=True).strip()
assert json.loads((scratch / 'seal.json').read_text())['passed']
assert json.loads((scratch / 'preflight/outcome.json').read_text())['emptyQueues']
warning = json.loads((checks / 'world-algorithm-warning-inventory/outcome.json').read_text())
assert len(warning['verifiedParentPaths']) == 5 and warning['warningCount'] == 92
inventory = json.loads((archive / 'streams.json').read_text())
sources = [Path(__file__), Path('/tmp/issue-1580-research/cache-warning-other-source-review.log'),
    Path('/tmp/issue-1580-research/verify-selected-warning-parent-paths.log')]
def capture(source):
    raw = source.read_bytes(); packed = gzip.compress(raw, mtime=0); name = source.name + '.gz'
    assert not (archive / name).exists(), name
    (archive / name).write_bytes(packed)
    inventory.append({'file': name, 'rawSha256': hashlib.sha256(raw).hexdigest(),
        'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
for source in sources:
    capture(source)
records = []
for gate in ['check-abbreviations', 'check-file-size', 'check-readable-code']:
    argv = ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', gate]
    output = scratch / ('final-' + gate + '.stdout'); errors = scratch / ('final-' + gate + '.stderr')
    with output.open('wb') as stdout, errors.open('wb') as stderr:
        result = subprocess.run(argv, cwd=root, env=dict(os.environ, NODE_OPTIONS='--max-old-space-size=192'), stdout=stdout, stderr=stderr)
    records.append({'gate': gate, 'argv': argv, 'exitCode': result.returncode})
    print(json.dumps(records[-1]), flush=True)
    assert result.returncode == 0, gate
    capture(output); capture(errors)
(archive / 'streams.json').write_text(json.dumps(inventory, indent=2) + '\n')
(archive / 'final-records.json').write_text(json.dumps(records, indent=2) + '\n')
paths = ['docs/case-studies/issue-1580/source-warning-extraction-checkpoint.md', 'experiments/issue-1580/work-plan.md']
paths += ['experiments/issue-1580/evidence/checks/' + name for name in [
    'included-string-evaluation-bbda05c0', 'layout-equation-warning-inventory', 'link-record-warning-inventory',
    'world-algorithm-warning-inventory', 'cache-warning-round-seal', 'cache-warning-round-preflight']]
paths += ['experiments/issue-1580/evidence/ci/' + name for name in ['codeql-producer-bbda05c0', 'native-families-bbda05c0']]
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
subprocess.run(['git', 'add', '--', *paths], cwd=root, check=True)
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=root, check=True)
subprocess.run(['git', 'commit', '-m', 'Retain native CI outcomes and bounded CodeQL repair evidence'], cwd=root, check=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
(scratch / 'expected-head.json').write_text(json.dumps({'head': head}) + '\n')
print(json.dumps({'head': head, 'cleanTree': True, 'pushed': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}))
