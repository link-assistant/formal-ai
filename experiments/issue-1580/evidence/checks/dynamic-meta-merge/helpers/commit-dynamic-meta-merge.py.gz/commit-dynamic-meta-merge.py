import gzip,hashlib,json,os,pathlib,re,subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');scratch=pathlib.Path('/tmp/issue-1580-research');out=scratch/'dynamic-meta-merge-preflight'
assert json.loads((out/'outcome.json').read_text())['allRequiredPassed']
before=scratch/'template-observation-head-review';feedback=[]
for old,new in [('issue-comments','issue-comments'),('pull-request-comments','conversation-comments'),('inline-comments','inline-comments'),('reviews','reviews')]:
    first=json.loads((before/(old+'.stdout')).read_text());last=json.loads((out/(new+'.stdout')).read_text())
    first={row['id']:row for row in first};last={row['id']:row for row in last}
    changed=[key for key,row in last.items() if key not in first or row.get('body')!=first[key].get('body')]
    assert not changed,(new,changed)
    feedback.append({'endpoint':new,'count':len(last),'newOrChangedBodies':changed})
(out/'feedback-comparison.json').write_text(json.dumps(feedback,indent=2)+'\n')
target=root/'experiments/issue-1580/evidence/checks/dynamic-meta-merge';records=[json.loads(line) for line in (target/'records.jsonl').read_text().splitlines()];added=[]
def retain(path,alias):
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);destination=target/(alias+'.gz');destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed)
    records.append({'source':str(path),'file':alias+'.gz','bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()});added.append(str(destination.relative_to(root)))
for path in sorted(out.rglob('*')):
    if path.is_file():retain(path,'preflight/'+str(path.relative_to(out)))
for name in ['start-dynamic-meta-merge-preflight.py','start-dynamic-meta-merge-preflight.log','resume-dynamic-meta-merge-preflight.py','resume-dynamic-meta-merge-preflight.log','prepare-dynamic-meta-merge-publication.py','prepare-dynamic-meta-merge-publication.log','seal-dynamic-meta-merge.log','commit-dynamic-meta-merge.py']:
    retain(scratch/name,'helpers/'+name)
retain(scratch/'dynamic-meta-merge-publication/body.md','publication/draft-body.md')
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
summary=json.loads((target/'summary.json').read_text());summary['retainedRecords']=len(records);summary['postArchivePreflight']=json.loads((out/'outcome.json').read_text());summary['feedback']=feedback;(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for row in records:
    packed=(target/row['file']).read_bytes();raw=gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest()==row['archiveSha256'] and hashlib.sha256(raw).hexdigest()==row['rawSha256'] and len(raw)==row['bytes'] and len(raw.splitlines())==row['lines']
commands=root/'experiments/issue-1580/evidence/commands';old_index=subprocess.check_output(['git','show','HEAD:experiments/issue-1580/evidence/commands/index.jsonl'],cwd=root,text=True);known={json.loads(line)['file'] for line in old_index.splitlines()};verified=0
for line in (commands/'index.jsonl').read_text().splitlines():
    row=json.loads(line)
    if row['file'] in known:continue
    packed=(commands/row['file']).read_bytes();raw=gzip.decompress(packed);value=json.loads(raw)
    assert hashlib.sha256(packed).hexdigest()==row['compressedSha256'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    assert row['source']==value['source'] and re.fullmatch('[a-f0-9]{40}',row['source'])
    assert row['status']==value['status'] and row['signal']==value['signal']
    assert row['autonomousAuthorshipCredit']==value['autonomousAuthorshipCredit']==0
    verified+=1
subprocess.run(['git','add','--',str(target.relative_to(root))],cwd=root,check=True)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
incoming=json.loads((out/'whitespace-scope.json').read_text())['incomingMainLogUnchangedFromMergeHead']
for name,argv in [('final-naming',['node','scripts/measure-abbreviations.mjs','--check']),('final-secrets',['bash','scripts/check-secrets.sh',*added,str(target.relative_to(root)/'records.jsonl'),str(target.relative_to(root)/'summary.json')]),('final-whitespace',['git','diff','--cached','--check','HEAD','--','.',':(exclude)'+incoming])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
    assert result.returncode==0,name
with (out/'commit.stdout').open('wb') as stdout,(out/'commit.stderr').open('wb') as stderr:subprocess.run(['git','-c','gc.auto=0','commit','-m','Merge main and preserve dynamic meta CI qualification'],cwd=root,stdout=stdout,stderr=stderr,check=True)
assert subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)==''
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
subprocess.run(['git','merge-base','--is-ancestor','origin/main',head],cwd=root,check=True)
outcome={'head':head,'committed':True,'pushed':False,'cleanWorkingTree':True,'mainIsAncestor':True,'retainedRecords':len(records),'verifiedNewCommandArchives':verified,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(out/'commit-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))
