import json,pathlib,subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');out=pathlib.Path('/tmp/issue-1580-research/dynamic-meta-package-runtime')
program='''import json,pathlib,re,subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');out=pathlib.Path('/tmp/issue-1580-research/dynamic-meta-package-runtime')
argv=['npm','install','--prefix',str(out/'dependencies'),'--ignore-scripts','--no-audit','--no-fund','--save-exact','@link-foundation/ui-links@0.1.0','@link-foundation/ui-core@0.1.3','links-notation@0.27.1','ws@8.23.0']
with (out/'pinned-install.stdout').open('wb') as stdout,(out/'pinned-install.stderr').open('wb') as stderr:result=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
assert result.returncode==0
lock=json.loads((out/'dependencies/package-lock.json').read_text())['packages'];source=(root/'bun.lock').read_text();rows=[]
for name in ['@link-foundation/ui-links','@link-foundation/ui-core','links-notation','ws']:
    match=re.search(r'^    "'+re.escape(name)+r'": (\\[.*\\]),$',source,re.M);assert match,name
    pinned=json.loads(match[1]);actual=lock['node_modules/'+name]
    assert pinned[0]==name+'@'+actual['version'] and pinned[-1]==actual['integrity'],name
    rows.append({'package':name,'version':actual['version'],'integrity':actual['integrity'],'matchesBunLock':True})
(out/'pinned-outcome.json').write_text(json.dumps({'verifiedPackages':rows,'rootManifestChanged':False,'fullIssueComplete':False},indent=2)+'\\n')
'''
(out/'pin.py').write_text(program)
with (out/'pinned-worker.log').open('wb') as stream:
    child=subprocess.Popen(['python3',str(out/'pin.py')],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
(out/'pinned-pid.json').write_text(json.dumps({'pid':child.pid})+'\n')
print(json.dumps({'pid':child.pid,'rootManifestChanged':False}))
