import json, pathlib, subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/current-main-merge')
workflow=root/'.github/workflows/native-type-check.yml'
text=workflow.read_text().replace('/experiments/dynamic-meta/\n','/experiments/dynamic-meta/**\n').replace('/experiments/js_dogfood/\n','/experiments/js_dogfood/**\n')
workflow.write_text(text)
test=root/'rust/tests/web/default-branch-build-policy.test.mjs'
text=test.read_text().replace("'/experiments/dynamic-meta/', '/experiments/js_dogfood/'", "'/experiments/dynamic-meta/**', '/experiments/js_dogfood/**'")
text=text.replace("|| step.uses === 'actions/setup-node@v7' || step.name?.startsWith('Replay ')","|| ['actions/setup-node@v7', 'oven-sh/setup-bun@v2'].includes(step.uses) || step.name?.startsWith('Replay ')")
text=text.replace('  assert.equal(later.length, 5);','  assert.equal(later.length, 7);',1)
test.write_text(text)
subprocess.run(['git','add','--',str(workflow.relative_to(root)),str(test.relative_to(root))],cwd=root,check=True)
directory=pathlib.Path('/tmp/issue-1580-research/dynamic-meta-package-runtime')
directory.mkdir(exist_ok=False)
script='''import json,os,pathlib,subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');directory=pathlib.Path('/tmp/issue-1580-research/dynamic-meta-package-runtime')
argv=['npm','install','--prefix',str(directory/'dependencies'),'--ignore-scripts','--no-audit','--no-fund','@link-foundation/ui-links@0.1.0']
with (directory/'install.stdout').open('wb') as stdout,(directory/'install.stderr').open('wb') as stderr:result=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
assert result.returncode==0,result.returncode
package=directory/'dependencies/node_modules/@link-foundation/ui-links'
metadata=json.loads((package/'package.json').read_text());assert metadata['version']=='0.1.0'
target=root/'node_modules/@link-foundation/ui-links';target.parent.mkdir(exist_ok=True)
assert not target.exists();target.symlink_to(package,target_is_directory=True)
(directory/'outcome.json').write_text(json.dumps({'installed':True,'rootManifestChanged':False,'version':metadata['version'],'fullIssueComplete':False},indent=2)+'\\n')
'''
(directory/'install.py').write_text(script)
with (directory/'worker.log').open('wb') as stream:
    child=subprocess.Popen(['python3',str(directory/'install.py')],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
(directory/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n')
print(json.dumps({'sparsePatternsFixed':True,'retryGuardsExtended':True,'dependencyInstallPid':child.pid,'pushed':False}))
