import gzip, hashlib, json, pathlib, subprocess

root = pathlib.Path('/tmp/gh-issue-solver-1794900398048')
scratch = pathlib.Path('/tmp/issue-1580-research')
base = root / 'experiments/issue-1580/evidence/ci/native-families-84e1ad85'
out = scratch / 'template-observation-head-review'
out.mkdir(exist_ok=False)
outcome = json.loads((base / 'outcome.json').read_text())
assert outcome['complete'] and not outcome['failed'] and outcome['success'] == 25 and outcome['workflowCount'] == 26
records = json.loads((base / 'records.json').read_text())
total_bytes = 0
results = []
for row in records:
    for label in ['stdout','stderr']:
        stream = row[label]
        packed = (base / stream['file']).read_bytes()
        raw = gzip.decompress(packed)
        assert hashlib.sha256(raw).hexdigest() == stream['rawSha256']
        assert hashlib.sha256(packed).hexdigest() == stream['archiveSha256']
        assert len(raw) == stream['bytes'] and len(raw.splitlines()) == stream['lines']
        total_bytes += len(raw)
        if label == 'stdout' and (row['name'].startswith('job-') or row['name'].startswith('full-run-')):
            lines = raw.decode(errors='replace').splitlines()
            matches = [{'line':index+1,'text':line} for index,line in enumerate(lines) if 'test result:' in line or 'Pipeline passed' in line or 'All required jobs' in line]
            if matches: results.append({'record':row['name'],'lines':len(lines),'results':matches})
    assert row['exitCode'] == 0, row['name']
(out / 'test-results.json').write_text(json.dumps(results,indent=2)+'\n')
assert len([row for row in records if row['name'].startswith('full-run-')]) == 26
summary = {'head':outcome['head'],'allWorkflowLogs':26,'workflowSuccess':25,'workflowSkipped':1,'workflowFailed':0,'retainedCommandRecords':len(records),'verifiedCompressedStreams':2*len(records),'totalRawBytes':total_bytes,'allHashesVerified':True,'fullIssueComplete':False}
(out / 'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for name,argv in [('recent-runs',['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','5','--json','databaseId,conclusion,createdAt,headSha']),('pipeline-jobs',['gh','api','repos/link-assistant/formal-ai/actions/runs/44887270503/jobs?per_page=100','--paginate']),('pull-request',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','title,body,isDraft,headRefOid,url']),('issue-comments',['gh','api','repos/link-assistant/formal-ai/issues/1580/comments','--paginate']),('pull-request-comments',['gh','api','repos/link-assistant/formal-ai/issues/1581/comments','--paginate']),('inline-comments',['gh','api','repos/link-assistant/formal-ai/pulls/1581/comments','--paginate']),('reviews',['gh','api','repos/link-assistant/formal-ai/pulls/1581/reviews','--paginate']),('fetch-main',['git','fetch','origin','main'])]:
    with (out / (name+'.stdout')).open('wb') as stdout,(out / (name+'.stderr')).open('wb') as stderr:
        result = subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
    assert result.returncode == 0, name
print(json.dumps(summary))
