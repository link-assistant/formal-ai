import hashlib,json,os,pathlib,re,subprocess,time
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');scratch=pathlib.Path('/tmp/issue-1580-research');out=scratch/'dynamic-meta-merge-preflight'
rows=json.loads((out/'records.json').read_text());assert rows[-1]['name']=='our-whitespace' and rows[-1]['exitCode']==2
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512'
def run(name,argv,check=True):
    started=time.time()
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'argv':argv,'exitCode':result.returncode,'seconds':round(time.time()-started,3)};rows.append(row);(out/'records.json').write_text(json.dumps(rows,indent=2)+'\n')
    if check:assert result.returncode==0,(name,result.returncode)
    return (out/(name+'.stdout')).read_bytes()
paths=set(re.findall(r'(?m)^([^+].*?):\d+: trailing whitespace\.$',(out/'our-whitespace.stdout').read_text()))
historical='dev/log/issues/1580/pulls/1581/sessions/ses_e1d024c95ffesDpv5Qnl5AKr9J/solve.log'
assert paths=={historical}
assert (root/historical).read_bytes()==subprocess.check_output(['git','show','HEAD:'+historical],cwd=root)
incoming=json.loads((out/'archive-and-incoming-whitespace-validation.json').read_text())['initialWhitespacePaths'][0]
run('new-change-whitespace',['git','diff','--cached','--check','HEAD','--','.',':(exclude)'+incoming])
(out/'whitespace-scope.json').write_text(json.dumps({'historicalBranchLogUnchangedFromHead':historical,'incomingMainLogUnchangedFromMergeHead':incoming,'newChangeCheckPassed':True,'historicalLogBytesModified':False},indent=2)+'\n')
doc=root/'docs/case-studies/issue-1580/dynamic-meta-merge-checkpoint.md';text=doc.read_text().replace('Whitespace validation against main checks our changes separately. After correction,','A comparison with main separately flags only the original unchanged #1580 raw\nlog. Both logs retain their exact parent bytes; checking newly changed files\npasses. After correction,',1);doc.write_text(text)
run('stage-doc',['git','add','--',str(doc.relative_to(root))])
run('rust-format',['rustfmt','--edition','2024','--check','rust/examples/basic_usage.rs','rust/src/server.rs','rust/src/server/dynamic_meta.rs','rust/src/server/transport.rs','rust/tests/unit/dynamic_meta_gateway.rs'])
run('fetch-main',['git','-c','gc.auto=0','fetch','origin','main'])
assert subprocess.check_output(['git','rev-parse','origin/main'],cwd=root)==subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=root)
for label,endpoint in [('issue-comments','issues/1580/comments'),('conversation-comments','issues/1581/comments'),('inline-comments','pulls/1581/comments'),('reviews','pulls/1581/reviews')]:run(label,['gh','api','repos/link-assistant/formal-ai/'+endpoint,'--paginate'])
run('recent-runs',['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','5','--json','databaseId,conclusion,createdAt,headSha'])
for status in ['in_progress','queued']:
    data=json.loads(run('runs-'+status,['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--status',status,'--limit','100','--json','databaseId,workflowName,headSha']));assert data==[],data
run('pull-request',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','headRefOid,isDraft,state,title,body,url,baseRefName'])
run('pull-request-diff',['gh','pr','diff','1581','--repo','link-assistant/formal-ai'],False)
(out/'outcome.json').write_text(json.dumps({'allRequiredPassed':True,'records':len(rows),'mergeParentCurrent':True,'queuesEmpty':True,'unchangedRawLogsPreserved':True,'broadHistoricalWhitespaceFailureRetained':True,'committed':False,'pushed':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n');print((out/'outcome.json').read_text())
