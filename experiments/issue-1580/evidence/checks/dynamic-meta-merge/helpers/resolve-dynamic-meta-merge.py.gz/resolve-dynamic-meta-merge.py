import json, pathlib, re, subprocess

root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/current-main-merge')
def ours(path):
    target=root/path
    text=target.read_text()
    text=re.sub(r'^<<<<<<< HEAD\n(.*?)^=======\n.*?^>>>>>>> origin/main\n',lambda match:match[1],text,flags=re.M|re.S)
    assert not re.search(r'^(<<<<<<<|=======|>>>>>>>)',text,re.M),path
    return target,text

target,text=ours('.github/workflows/native-type-check.yml')
prefix,families=text.split('\n  # Run 44648187857',1)
prefix=prefix.replace('            /experiments/**/*.sh\n','            /experiments/**/*.sh\n            /experiments/dynamic-meta/\n            /experiments/js_dogfood/\n')
condition="${{ !cancelled() && inputs.compile-inputs-changed && steps.native-lint.outcome == 'success' }}"
steps='''      - uses: oven-sh/setup-bun@v2
        if: CONDITION
        with:
          bun-version-file: .bun-version
          no-cache: true
      - name: Replay dynamic meta authorization and receipts through the native gateway
        if: CONDITION
        env:
          FORMAL_AI_DYNAMIC_META_NATIVE: ${{ github.workspace }}/rust/target/debug/formal-ai
        run: |
          bun install --frozen-lockfile --ignore-scripts
          node --test --test-concurrency=1 --test-name-pattern='HTTP credentials' rust/tests/web/dynamic-meta.test.mjs
'''.replace('CONDITION',condition)
prefix=prefix.replace('      - name: Stage deterministic Google Trends fixtures',steps+'      - name: Stage deterministic Google Trends fixtures')
target.write_text(prefix+'\n  # Run 44648187857'+families)

target,text=ours('rust/tests/web/default-branch-build-policy.test.mjs')
declaration='''  const gatewayReplay = 'bun install --frozen-lockfile --ignore-scripts\\n' +
    "node --test --test-concurrency=1 --test-name-pattern='HTTP credentials' rust/tests/web/dynamic-meta.test.mjs\\n";
'''
text=text.replace('  const runs = check.steps.map(step => step.run).filter(Boolean);',declaration+'  const runs = check.steps.map(step => step.run).filter(Boolean);',1)
text=text.replace("    'node --test --test-concurrency=1 rust/tests/web/issue-1396-native.test.mjs',\n", "    'node --test --test-concurrency=1 rust/tests/web/issue-1396-native.test.mjs',\n    gatewayReplay,\n",1)
text=text.replace("['actions/setup-node@v7', 'actions/upload-artifact@v7']","['actions/setup-node@v7', 'actions/upload-artifact@v7', 'oven-sh/setup-bun@v2']",1)
text=text.replace("    ['/*', '!/dev/log/', '!/experiments/*', '/experiments/dynamic-meta/', '/experiments/js_dogfood/']);",'''    ['/*', '!/dev/log/', '!/experiments/**', '/experiments/**/*.sh',
      '/experiments/dynamic-meta/', '/experiments/js_dogfood/',
      '/experiments/issue-1580/release-registry/', '/experiments/agent_cli_e2e/mock-meaning-mcp.mjs',
      ...['candidate-output-bindings.json', 'candidate-release-caller.yml', 'original-release-workflow.yml',
        'stage-source-coverage.json'].map(file =>
        '/experiments/formal_ai_subagent/evidence/specification-delivery-1188/dormant-staged-release/' + file)]);''',1)
text=text.replace("  assert.deepEqual(check.steps.find(step => step.uses === 'oven-sh/setup-bun@v2').with,",'''  for (const step of check.steps.filter(step => step.uses === 'oven-sh/setup-bun@v2' || step.run === gatewayReplay))
    assert.equal(step.if, "${{ !cancelled() && inputs.compile-inputs-changed && steps.native-lint.outcome == 'success' }}");
  assert.deepEqual(check.steps.find(step => step.uses === 'oven-sh/setup-bun@v2').with,''',1)
# Exercise both added experiment directories through Git's actual sparse matcher.
text=text.replace("    'experiments/new/nested/payload.json', 'experiments/unrelated.mjs', 'dev/log/payload.json'];", "    'experiments/dynamic-meta/package.json', 'experiments/js_dogfood/drive.mjs',\n    'experiments/new/nested/payload.json', 'experiments/unrelated.mjs', 'dev/log/payload.json'];",1)
text=text.replace('paths.slice(0, 6)', 'paths.slice(0, 8)',1).replace('paths.slice(6)', 'paths.slice(8)',1)
target.write_text(text)

target,text=ours('docs/ci-cd/default-branch-builds.md')
text=text.replace('  against the native CLI. All compile-dependent steps retain the same input\n', '''  against the native CLI. Issue #1604 also reuses that binary to verify dynamic
  meta authorization and transaction receipts through the native gateway. Its
  JavaScript host installs the frozen Bun lockfile with lifecycle scripts disabled.
  All compile-dependent steps retain the same input
''',1)
text=text.replace('  condition, with two compiler jobs and test optimization disabled. Successful\n','  condition, with two compiler jobs and the maintained optimized test profile. Successful\n',1)
text=text.replace('  suites and product builds remain on main. The job uploads and attests nothing,\n  saves no cache and publishes no outputs.','''  suites and product builds remain on main. The job retains deterministic Google
  Trends fixture projections for replay, with their generation identity. It grants
  no release authorization, saves no cache and publishes no workflow outputs.''',1)
target.write_text(text)

test=root/'experiments/issue-1580/native-checkout-retry.test.mjs'
text=test.read_text().replace("import YAML from 'yaml';","import YAML from 'yaml';\nimport {admission} from '../../scripts/ci-pull-request-admission.mjs';")
text+='''
test('the native dynamic meta replay admits its host, package and loader inputs', () => {
  for (const path of [
    'rust/tests/web/dynamic-meta.test.mjs', 'rust/tests/web/support/structured-log-fixture.mjs',
    'js/server/dynamic-meta/host.mjs', 'js/server/dynamic-meta/runtime.mjs',
    'js/server/main.mjs', 'js/server/worker-host.mjs', 'js/server/response.mjs',
    'js/agentic/crate/links_substitution_query.mjs', 'js/worker/formal_ai_worker.js',
    'js/seed/parser.js', 'js/parser-cache-primordials.js', 'js/seed_loader.js',
    'js/worker-bootstrap-responses.js', 'js/worker-modules.js',
    'experiments/dynamic-meta/package.json', 'experiments/dynamic-meta/instructions.md',
    'experiments/js_dogfood/drive.mjs', 'package.json', 'bun.lock', '.bun-version',
  ]) assert.equal(admission([path])['native-type-check'], true, path);
  for (const path of ['js/app.js', 'ts/server/main.mts', 'experiments/unrelated.mjs',
    'docs/unrelated.md', 'rust/tests/web/unrelated.test.mjs'])
    assert.equal(admission([path])['native-type-check'], false, path);
});
'''
test.write_text(text)

def run(name,args):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
    return result.returncode
before=run('dynamic-admission-before',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test.relative_to(root))])
assert before==1,before
selector=root/'scripts/ci-pull-request-admission.mjs'
text=selector.read_text()
needle="  // The download contract discovers every shell script, including new paths."
replacement="""  // The native dynamic-meta replay starts the JavaScript HTTP host and its
  // worker. Retain these discovered module trees and frozen package inputs;
  // a changed host must not silently bypass its native gateway qualification.
  if (['js/server/', 'js/agentic/', 'js/worker/', 'js/seed/',
    'experiments/dynamic-meta/', 'experiments/js_dogfood/'].some(prefix => path.startsWith(prefix))
    || ['rust/tests/web/dynamic-meta.test.mjs', 'package.json', 'bun.lock', '.bun-version',
      'js/parser-cache-primordials.js', 'js/seed_loader.js', 'js/worker-bootstrap-responses.js',
      'js/worker-modules.js'].includes(path)) return true;
"""+needle
assert text.count(needle)==1
selector.write_text(text.replace(needle,replacement,1))
target=root/'rust/tests/web/default-branch-build-policy.test.mjs'
text=target.read_text().replace("    'js/server/structured-log.mjs', '.github/workflows/links.yml'", "    'js/server/structured-log.mjs', 'package.json', 'bun.lock', '.bun-version', '.github/workflows/links.yml'",1)
text=text.replace("'rust/tests/web/support/structured-log-fixture.mjs', 'js/server/structured-log.mjs', '.github/workflows/links.yml'", "'rust/tests/web/support/structured-log-fixture.mjs', 'js/server/structured-log.mjs',\n    'package.json', 'bun.lock', '.bun-version', '.github/workflows/links.yml'",1)
text=text.replace("'scripts/check-tests-as-docs.mjs', 'data/meta/x.txt',\n    'package.json', 'bun.lock'", "'scripts/check-tests-as-docs.mjs', 'data/meta/x.txt'",1)
target.write_text(text)
assert run('runtime-feature-generation',['node','--max-old-space-size=256','scripts/generate-runtime-feature-inventory.mjs','--write'])==0
assert run('resolved-whitespace',['git','diff','--check'])==0
(out/'resolution.json').write_text(json.dumps({'resolvedFiles':['.github/workflows/native-type-check.yml','data/meta/runtime-feature-coverage.json','docs/ci-cd/default-branch-builds.md','rust/tests/web/default-branch-build-policy.test.mjs'],'dynamicAdmissionBeforeExit':before,'runtimeInventoryOfficialWriter':True,'committed':False,'pushed':False,'fullIssueComplete':False},indent=2)+'\n')
print((out/'resolution.json').read_text())
