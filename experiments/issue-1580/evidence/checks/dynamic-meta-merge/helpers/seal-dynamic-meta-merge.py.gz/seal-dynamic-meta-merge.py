import collections,gzip,hashlib,json,pathlib,re,subprocess

root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');scratch=pathlib.Path('/tmp/issue-1580-research')
target=root/'experiments/issue-1580/evidence/checks/dynamic-meta-merge'
assert not target.exists()
initial=json.loads((scratch/'dynamic-meta-merge-validation/records.json').read_text())
follow=json.loads((scratch/'dynamic-meta-merge-followup/outcome.json').read_text());assert follow['allPassed']
assert next(row for row in initial if row['name']=='all-local-gates')['exitCode']==0
gate_text=(scratch/'dynamic-meta-merge-validation/all-local-gates.stdout').read_text()
gate_counts=collections.Counter(re.findall(r'(?m)^(PASS|SKIP|FAIL) ',gate_text));assert gate_counts=={'PASS':88,'SKIP':53}
maintained=(scratch/'dynamic-meta-merge-followup/test-5.stdout').read_text()
assert re.search(r'(?m)^.*pass 133$',maintained) and re.search(r'(?m)^.*fail 0$',maintained)
assert re.search(r'(?m)^.*skipped 0$',maintained)
annotation=json.loads((scratch/'terminal-annotations-84e1ad85/summary.json').read_text())
levels=collections.Counter(item['annotation_level'] for row in annotation['annotatedChecks'] for item in row['annotations'])
compact=[{'check':row['name'],'id':row['id'],'level':item['annotation_level'],'path':item['path'],'message':item['message']} for row in annotation['annotatedChecks'] for item in row['annotations']]
(scratch/'terminal-annotations-84e1ad85/compact.json').write_text(json.dumps({'levels':dict(levels),'annotations':compact},indent=2)+'\n')
merge_head=subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=root,text=True).strip()
assert subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=root,text=True)==''
review_paths=['.github/workflows/native-type-check.yml','scripts/ci-pull-request-admission.mjs','scripts/list-fast-pull-request-tests.mjs','experiments/issue-1580/native-checkout-retry.test.mjs','experiments/issue-1580/fast-inventory-boundary.test.mjs','rust/tests/web/default-branch-build-policy.test.mjs','rust/tests/web/fast-pull-request-production-profile.test.mjs','docs/ci-cd/default-branch-builds.md','changelog.d/issue-1580-dynamic-meta-ci-inputs.md']
for parent in ['HEAD','MERGE_HEAD']:
    (scratch/'current-main-merge'/('resolved-diff-'+parent.lower()+'.txt')).write_bytes(subprocess.check_output(['git','diff','--cached',parent,'--',*review_paths],cwd=root))
rows=[];target.mkdir(parents=True)
def retain(path,alias):
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);name=alias+'.gz';destination=target/name
    destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed)
    assert gzip.decompress(packed)==raw
    rows.append({'source':str(path),'file':name,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
for directory in ['current-main-merge','dynamic-meta-merge-validation','dynamic-meta-merge-followup','terminal-annotations-84e1ad85','template-observation-head-review','rust-observation-preflight']:
    for path in sorted((scratch/directory).rglob('*')):
        if path.is_file():retain(path,directory+'/'+str(path.relative_to(scratch/directory)))
for path in sorted((scratch/'dynamic-meta-package-runtime').iterdir()):
    if path.is_file():retain(path,'dynamic-meta-package-runtime/'+path.name)
for name in re.findall(r'(?m)^PASS ([\w.#-]+) ',gate_text):
    path=root/'experiments/formal_ai_subagent/sandboxes/gates'/(name+'.log')
    assert path.is_file(),name
    retain(path,'gate-logs/'+path.name)
for stem in ['resolve-dynamic-meta-merge','repair-dynamic-meta-merge-fixtures','repair-fast-inventory-boundary','pin-dynamic-meta-runtime','start-dynamic-meta-merge-validation','start-dynamic-meta-merge-followup','observe-terminal-annotations','review-template-observation-head','commit-rust-timeout-observation','seal-dynamic-meta-merge']:
    for suffix in ['.py','.log']:
        path=scratch/(stem+suffix)
        if path.exists() and (stem!='seal-dynamic-meta-merge' or suffix=='.py'):
            retain(path,'helpers/'+path.name)
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in rows))
size_text=(root/'experiments/formal_ai_subagent/sandboxes/gates/check-file-size.log').read_text()
warnings=len(re.findall(r'(?m)^WARNING: ',size_text));assert warnings==87,warnings
summary={'publishedHead':annotation['head'],'workflowSuccess':25,'workflowSkipped':1,'workflowFailure':0,'checkRuns':annotation['checks'],'annotationLevels':dict(levels),'mergeHead':merge_head,'initialFailures':[row['name'] for row in initial if row['exitCode']!=0],'followupCommandsPassed':5,'maintainedCasesPassed':133,'localGates':dict(gate_counts),'sourceWarnings':warnings,'retainedRecords':len(rows),'allArchiveHashesVerified':True,'sourceSha256':{path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in review_paths},'localNativeBuildPerformed':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
doc=root/'docs/case-studies/issue-1580/dynamic-meta-merge-checkpoint.md'
doc.write_text('''# Terminal CI and dynamic meta merge

Published commit `84e1ad85fc70541ae64c59a8518dbce59b883e64` has all 26
normal workflows terminal: 25 successful and one skipped. The Pipeline,
all eight native contract families and the release registry job succeed.
All 294 compressed command streams verify against their original hashes,
byte counts and line counts. This evidence qualifies that published commit.

A fresh inventory covers 143 check runs and every reported annotation. The
only failure annotation is the deliberate canonical-registry outage in the
actual BuildKit fallback control. Its real mirror retry and immutable image
identity checks succeed. Source-size and publish-token uncertainty warnings
remain unresolved; successful retries do not establish their resolution.

Merging current main preserves its dynamic meta gateway feature and the
existing eight native families. A before-fix admission regression shows that
changing its JavaScript host or frozen packages could bypass native replay.
The selector now retains the discovered host/worker module trees and package
inputs. Both checkout attempts include the required experiment directories
recursively. A real temporary Git sparse checkout verifies retained and
excluded files. Bun setup and the gateway replay retain cancellation, compile
admission and successful native-lint requirements while allowing independent
replays to continue after an earlier regression failure.

Main's additional JavaScript test also exposes a distinct inventory failure:
the previous fixed 256-file limit rejects all 257 valid reviewed suites.
The maintained failing-before case verifies that defect. Selection now remains
bounded by distinct existing valid paths, measured shard planning and unchanged
job deadlines. Empty, malformed, duplicate, unavailable and escaping inputs
still fail. No warning threshold or execution deadline was increased.

The complete local gate run passes 88 entries with 53 explicit skips. The
initial policy-fixture failures, missing local package and inventory failure
are retained separately. After correction, all five follow-up commands pass,
including 133 maintained observation cases without skips. Native group checks
pass 50 cases, server checks pass seven and dreaming-runtime checks pass nine.
TypeScript generation verifies 738 projections; its runtime check includes a
compiled dynamic meta recipe. Four local JavaScript package versions and
integrities match the frozen Bun lockfile; installation skips lifecycle hooks
and leaves the root manifest unchanged. This focused local setup does not
qualify the hosted frozen Bun installation or native gateway execution.

No local native build runs. Hosted CI must qualify the merged source after
publication. Eighty-seven source-size warnings, full template/practice review,
original budget/live criteria, per-child security semantics and complete issue
acceptance remain unfinished. Supplied commands and patches receive zero
independent authorship or reasoning credit. PR #1581 stays draft and unmerged.

Evidence: `experiments/issue-1580/evidence/ci/native-families-84e1ad85/` and
`experiments/issue-1580/evidence/checks/dynamic-meta-merge/`.
''')
plan=root/'experiments/issue-1580/work-plan.md';text=plan.read_text();start=text.index('## Current verification checkpoint\n');end=text.index('\n\nLatest checkpoint:',start)
text=text[:start]+'''## Current verification checkpoint

Published `84e1ad85` has all 26 normal workflows terminal: 25 success,
one skip and no failures. All eight native families and registry checks pass.
The merged local source passes 88 local gates with 53 explicit skips,
133 maintained observation cases, TypeScript generation/runtime and focused
gateway/server checks. New before-fix regressions cover omitted dynamic meta
native inputs and rejection of the inventory's valid 257th suite. Both fixes
retain existing execution deadlines and source validation. Hosted qualification
of the merged source remains pending. See the
[dynamic meta merge checkpoint](../../docs/case-studies/issue-1580/dynamic-meta-merge-checkpoint.md).

Four worker source-size warnings were repaired; 87 remain under unchanged
limits. The [Rust timeout and source identity checkpoint](../../docs/case-studies/issue-1580/rust-timeout-and-source-identity-checkpoint.md)
records the invalid source pin correction and upstream documentation report.
Full template/practice, original budget/live, complete PR review and complete
issue acceptance remain open. Earlier entries below retain their dated scope.
'''+text[end:];plan.write_text(text)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print(json.dumps(summary))
