import pathlib,subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');out=pathlib.Path('/tmp/issue-1580-research/current-main-merge')
test=root/'experiments/issue-1580/fast-inventory-boundary.test.mjs'
assert not test.exists()
test.write_text('''// A valid new suite must not invalidate the entire reviewed PR inventory.
import assert from 'node:assert/strict';
import test from 'node:test';
import {selectFastTests} from '../../scripts/list-fast-pull-request-tests.mjs';

test('fast inventory accepts 257 distinct available suites while rejecting invalid source inventories', () => {
  const files = Array.from({length:257}, (_, index) => 'rust/tests/web/fixture-' + index + '.test.mjs');
  const available = new Set(files);
  const manifest = files => ({schema:'fast-pr-javascript-tests/v1', files});
  assert.deepEqual(selectFastTests(manifest(files), file => available.has(file)), files);
  for (const invalid of [[], null, 'not-an-array', [...files, files[0]],
    [...files, 'rust/tests/web/missing.test.mjs'], [...files, '../outside.test.mjs']])
    assert.throws(() => selectFastTests(manifest(invalid), file => available.has(file)));
});
''')
with (out/'fast-inventory-before.stdout').open('wb') as stdout,(out/'fast-inventory-before.stderr').open('wb') as stderr:
    result=subprocess.run(['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test.relative_to(root))],cwd=root,stdout=stdout,stderr=stderr)
assert result.returncode==1
selector=root/'scripts/list-fast-pull-request-tests.mjs'
text=selector.read_text()
old="  assert.ok(Array.isArray(manifest.files) && manifest.files.length > 0 && manifest.files.length <= 256);"
assert text.count(old)==1
text=text.replace(old,"""  // Distinct existing paths bound the inventory to the checked-out test tree.
  // A fixed count rejects otherwise valid newly added regression suites; actual
  // execution remains bounded by the measured shard plan and job deadlines.
  assert.ok(Array.isArray(manifest.files) && manifest.files.length > 0);""",1)
selector.write_text(text)
entry=root/'rust/tests/web/fast-pull-request-production-profile.test.mjs'
text=entry.read_text()
text="import '../../../experiments/issue-1580/fast-inventory-boundary.test.mjs';\n"+text
entry.write_text(text)
fragment=root/'changelog.d/issue-1580-dynamic-meta-ci-inputs.md'
fragment.write_text('''---
bump: patch
---

Preserve dynamic meta gateway qualification when its host, frozen dependencies or fixtures change. Retain both checkout attempts and recursive fixture inclusion after merging the latest main. Accept distinct existing test suites beyond the obsolete 256-file inventory cap while preserving source validation, measured shards and job deadlines.
''')
subprocess.run(['git','add','--',str(test.relative_to(root)),str(selector.relative_to(root)),str(entry.relative_to(root)),str(fragment.relative_to(root))],cwd=root,check=True)
print('Retained failing-before inventory regression; selected paths, shard planning and job deadlines remain validated.')
