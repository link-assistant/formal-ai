import json,pathlib,subprocess,sys
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');out=pathlib.Path('/tmp/issue-1580-research/dynamic-meta-merge-followup')
out.mkdir(exist_ok=False)
worker=r'''import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');scratch=pathlib.Path('/tmp/issue-1580-research');out=scratch/'dynamic-meta-merge-followup'
for _ in range(1800):
    if (scratch/'dynamic-meta-merge-validation/outcome.json').exists():break
    time.sleep(1)
else:raise RuntimeError('prior finite validation did not finish')
assert (scratch/'dynamic-meta-package-runtime/pinned-outcome.json').exists()
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512'
tests=['experiments/issue-1580/fast-inventory-boundary.test.mjs','rust/tests/web/default-branch-build-policy.test.mjs','rust/tests/web/fast-pull-request-production-profile.test.mjs','rust/tests/web/dynamic-meta.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs']
rows=[]
for index,file in enumerate(tests):
    name='test-'+str(index+1);argv=['node','--max-old-space-size=256','--test','--test-concurrency=1',file];started=time.time()
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'argv':argv,'exitCode':result.returncode,'seconds':round(time.time()-started,3)}
    for label in ['stdout','stderr']:
        raw=(out/(name+'.'+label)).read_bytes();row[label]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    rows.append(row);(out/'records.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
(out/'outcome.json').write_text(json.dumps({'allPassed':all(row['exitCode']==0 for row in rows),'commands':len(rows),'sequentialAfterPriorValidation':True,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
'''
(out/'validate.py').write_text(worker)
with (out/'worker.log').open('wb') as stream:
    child=subprocess.Popen([sys.executable,str(out/'validate.py')],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
(out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n')
print(json.dumps({'pid':child.pid,'scheduledAfterExistingSequentialValidation':True,'pushed':False}))
