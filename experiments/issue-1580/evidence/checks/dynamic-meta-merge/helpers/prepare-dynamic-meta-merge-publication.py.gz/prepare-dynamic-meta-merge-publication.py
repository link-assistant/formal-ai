import pathlib
scratch=pathlib.Path('/tmp/issue-1580-research');out=scratch/'dynamic-meta-merge-publication';out.mkdir(exist_ok=False)
(out/'body.md').write_text('''CI could omit native regression inputs, accept failed or incomplete observations, and lose task or source ownership. This draft repairs those boundaries and adds reproducing tests. Issue #1580 remains unfinished; keep this PR draft and unmerged.

Fixes #1580

Changes:

- Require complete native input admission and independently scheduled coding, reasoning, Hive, benchmark and interface families. Preserve every original target, single test threads, failure propagation and existing twenty-minute clocks. Replay captured HTTP, localized-language, source-binding, release and workflow regressions through their maintained native targets.
- Propagate failed Git inventories, fetches, child processes, fragment reads/cleanup and Actions output writes. Validate package identity and immutable base metadata before release decisions. Preserve existing fragment files on collisions and symlinks, and retain uncertainty for unavailable registry observations.
- Repair process-group deadline ownership after the parent exits, including termination acknowledgement and partial-line diagnostics. Preserve command status and warning-only behavior; unavailable inspection remains explicit.
- Preserve quoted tasks, request-local constraints, selected-child provenance and current owned-source definitions. Retain multilingual reasoning, calendar, retrieval, typed composition and unresolved-answer behavior. Official writers regenerate the maintained projections.
- Bind CodeQL to verified source, compiler and Cargo contexts; reject incomplete or unsuccessful reports. Retain the original SARIF, included-string and macro-context observations. Bound diagnostic queries without suppressing retained extraction failures or changing their deadlines.
- Pin BuildKit to a verified immutable multi-platform digest, retry the actual setup action through its mirror, and exercise an actual daemon with a deliberate canonical-outage control. Preserve explicit overrides, cleanup and image identity.
- Migrate 97 artifact consumers across 19 workflows to strict-digest raw transport and validated streaming extraction. Retry observed transient lookup failures while preserving selection, permissions and terminal failure propagation.
- Bind Pages retry adoption to repository, source SHA and immutable upload artifact identity. Permit trusted-main Pages generation after validated release checks when package publication fails; preserve successful release-child identity. Retain malformed concurrency and pipeline-result negative controls.
- Adopt built-in Secretlint 14 with actual positive/negative controls. Reduce source-size warnings through unchanged helper extractions and exact inverse checks, retaining the original limits. Upgrade web-capture and remove only its obsolete audit exception.
- Merge current main's dynamic meta feature while retaining the existing native matrix. Admit its actual JavaScript host, worker and frozen dependency inputs; preserve recursive sparse checkout in both attempts. Remove the obsolete fast-inventory count cap that rejected the valid 257th suite, retaining valid existing paths, uniqueness, measured shards and execution deadlines.

Verification and limits:

- Published `84e1ad85fc70541ae64c59a8518dbce59b883e64` has all 26 normal workflows terminal: 25 success, one skip, zero workflow failures. Pipeline, all eight native contract families and release-registry checks pass. All 294 retained command streams verify by hashes, bytes and lines. This qualifies that published source, before the local merge.
- The fresh 143-check annotation inventory has 21 notices, 11 warnings and one failure annotation. The failure is the deliberate BuildKit canonical-outage control; the actual mirror retry succeeds. Source-size warnings and publish-token uncertainty remain open. Earlier artifact-lookup failure annotations did not recur on this head.
- The merged local source passes all 141 local gate entries: 88 passes and 53 explicit skips. Follow-up files pass 145 CI-policy, 19 fast-profile, ten dynamic-meta and 133 maintained observation cases, without skips. TypeScript currency verifies 738 projections; the runtime check includes a compiled dynamic meta recipe. No local Rust build occurs. Hosted qualification of this merged source remains pending at publication.
- Before-fix controls cover omitted native dynamic-meta inputs and rejection of 257 valid suites. Initial fixture, missing-package and broad historical-whitespace failures remain archived. Four local package versions/integrities match the Bun lockfile; no install lifecycle scripts run. Existing raw logs retain their exact parent bytes. The hosted frozen Bun/native gateway path still needs its own CI result.
- Earlier actual CodeQL producer [44879033589](https://github.com/link-assistant/formal-ai/actions/runs/44879033589) succeeds at its recorded `e06d1f18` source: 2,180 included-string rows/nine columns, 122,579 macro-context rows/eight columns, both original standard SARIF reports without security findings. All 631 unexpanded macro positions still lack complete per-child semantic qualification.
- The local source scanner retains 87 warnings and zero violations under unchanged limits. Full template comparisons/practice adoption, original budget/live contracts and complete PR review remain unfinished. Independent Formal AI reasoning remains 0/20; supplied commands, patches and reviews earn zero independent credit.

The [current checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/dynamic-meta-merge-checkpoint.md), [work plan](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/experiments/issue-1580/work-plan.md) and [case study](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/README.md) retain the requirement/evidence mapping and dated head scopes. Passing normal PR workflows does not verify main-only builds, live Pages fallback publication/served identity, model identity, all original native budgets, remaining dependency migrations or all eight complete template/practice comparisons. Strict dated original whole-file acceptance remains 31/53; the other 22 assertion contracts have separate scoped compatibility reviews.

Upstream reproductions:

- Current Rust timeout documentation drift: [Rust #256](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/256). The source-pin regression also repairs our invalid 41-character ledger identifier after verifying the actual commit/tree and all twelve changed-file Git blobs.
- Current PHP finite pipe deadlock and literal-zero loss: [PHP #33](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/33); missing version evidence: [PHP #31](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/31); malformed UTF-8 release notes: [PHP #32](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/32).
- Current Python fragment data loss: [Python #165](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/165); JavaScript production-helper changes bypass release outputs: [Python #166](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/166).
- Malformed pipeline-result observations: [Go #23](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/23), [C++ #39](https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/issues/39).
- Cross-artifact Pages adoption: [JavaScript #310](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/issues/310), [Python #163](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/163).
- Project-version and checksum observations: [Java #32](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/32), [Rust #213](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/213), [Rust #251](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/251). Fragment overwrite/symlink source observation: [Rust #254](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/254); template CLI execution remains unverified.

Reports and disposable candidates establish no upstream repair. Complete template/practice acceptance remains open.

Focused reproduction (run each file separately):

```sh
node --test --test-concurrency=1 experiments/issue-1580/native-checkout-retry.test.mjs
node --test --test-concurrency=1 experiments/issue-1580/fast-inventory-boundary.test.mjs
node --test --test-concurrency=1 rust/tests/web/default-branch-build-policy.test.mjs
node --test --test-concurrency=1 rust/tests/web/issue-1580-template-observations.test.mjs
node --test --test-concurrency=1 rust/tests/web/native-test-artifact.test.mjs
node --test --test-concurrency=1 experiments/issue-1580/pages-release-failure.test.mjs
node --test --test-concurrency=1 rust/tests/web/security-codeql-results.test.mjs
node scripts/check-workflow-concurrency.mjs
node scripts/generate-staged-release.mjs --check-deployed
node experiments/formal_ai_subagent/local-gates.mjs
```

The hosted registry job runs the actual release helper and both CLIs against local HTTP fixtures, plus the original assembler, ordered-list and self-hosting Rust script suites. No registry publication is performed by that job.

Earlier browser source-binding evidence uses the labeled production-worker harness with external requests blocked:

![Before: Spanish definition frame skipped](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/screenshots/issue-1580/meaning-hydration-before.png?raw=true)

![After: definition routes to search and the unresolved sibling remains intact](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/screenshots/issue-1580/meaning-hydration-after.png?raw=true)
''')
print('Prepared concrete draft PR description; publication and issue completion remain separate.')
