import gzip,hashlib,json,os,pathlib,subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');scratch=pathlib.Path('/tmp/issue-1580-research');out=scratch/'dynamic-meta-merge-preflight';target=root/'experiments/issue-1580/evidence/checks/dynamic-meta-merge'
records=[json.loads(line) for line in (target/'records.jsonl').read_text().splitlines()]
for row in records:
    if '/stage-doc.' in row['file']:
        old=target/row['file'];row['file']=row['file'].replace('/stage-doc.','/stage-document.');subprocess.run(['git','mv',str(old.relative_to(root)),str((target/row['file']).relative_to(root))],cwd=root,check=True)
def retain(path,alias):
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);destination=target/(alias+'.gz');destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed)
    records.append({'source':str(path),'file':alias+'.gz','bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
for suffix in ['stdout','stderr']:retain(out/('final-naming.'+suffix),'preflight/failed-final-naming.'+suffix)
for name in ['commit-dynamic-meta-merge.log','finish-dynamic-meta-merge-commit.py']:retain(scratch/name,'helpers/'+name)
assert len({row['file'] for row in records})==len(records)
for row in records:
    packed=(target/row['file']).read_bytes();raw=gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest()==row['archiveSha256'] and hashlib.sha256(raw).hexdigest()==row['rawSha256'] and len(raw)==row['bytes'] and len(raw.splitlines())==row['lines']
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records));summary=json.loads((target/'summary.json').read_text());summary['retainedRecords']=len(records);summary['postArchiveEvidenceNamingCorrection']='spell stage-document in full; preserve the failing naming check';(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
subprocess.run(['git','add','--',str(target.relative_to(root))],cwd=root,check=True)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
files=subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=ACMR','-z'],cwd=root).decode().strip('\0').split('\0')
incoming=json.loads((out/'whitespace-scope.json').read_text())['incomingMainLogUnchangedFromMergeHead']
for name,argv in [('corrected-final-naming',['node','scripts/measure-abbreviations.mjs','--check']),('corrected-final-secrets',['bash','scripts/check-secrets.sh',*files]),('corrected-final-whitespace',['git','diff','--cached','--check','HEAD','--','.',':(exclude)'+incoming])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
    assert result.returncode==0,name
with (out/'commit.stdout').open('wb') as stdout,(out/'commit.stderr').open('wb') as stderr:subprocess.run(['git','-c','gc.auto=0','commit','-m','Merge main and preserve dynamic meta CI qualification'],cwd=root,stdout=stdout,stderr=stderr,check=True)
assert subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)==''
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();subprocess.run(['git','merge-base','--is-ancestor','origin/main',head],cwd=root,check=True)
outcome={'head':head,'committed':True,'pushed':False,'cleanWorkingTree':True,'mainIsAncestor':True,'retainedRecords':len(records),'fullIssueComplete':False,'independentAuthorshipCredit':0};(out/'commit-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))
