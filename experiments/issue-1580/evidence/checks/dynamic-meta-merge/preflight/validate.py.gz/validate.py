import gzip,hashlib,json,os,pathlib,re,subprocess,time
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');scratch=pathlib.Path('/tmp/issue-1580-research');out=scratch/'dynamic-meta-merge-preflight'
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH'];rows=[]
def run(name,argv,check=True):
    started=time.time()
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'argv':argv,'exitCode':result.returncode,'seconds':round(time.time()-started,3)};rows.append(row);(out/'records.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({key:value for key,value in row.items() if key!='argv'}),flush=True)
    if check:assert result.returncode==0,(name,result.returncode)
    return (out/(name+'.stdout')).read_bytes()
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
run('archive-commands',['python3','experiments/issue-1580/archive-evidence.py'])
verified={}
for directory,index in [('checks/dynamic-meta-merge','records.jsonl'),('ci/native-families-84e1ad85','records.json')]:
    base=root/'experiments/issue-1580/evidence'/directory
    content=(base/index).read_text();records=json.loads(content) if index.endswith('.json') else [json.loads(line) for line in content.splitlines()]
    streams=[record[label] for record in records for label in ['stdout','stderr']] if index.endswith('.json') else records
    for row in streams:
        packed=(base/row['file']).read_bytes();raw=gzip.decompress(packed)
        assert hashlib.sha256(packed).hexdigest()==row['archiveSha256']
        assert hashlib.sha256(raw).hexdigest()==row['rawSha256'] and len(raw)==row['bytes'] and len(raw.splitlines())==row['lines']
    verified[directory]=len(streams)
summary=json.loads((root/'experiments/issue-1580/evidence/checks/dynamic-meta-merge/summary.json').read_text())
for file,digest in summary['sourceSha256'].items():assert hashlib.sha256((root/file).read_bytes()).hexdigest()==digest,file
raw_whitespace=(scratch/'dynamic-meta-merge-validation/whitespace.stdout').read_text()
paths=set(re.findall(r'(?m)^([^+].*?):\d+: trailing whitespace\.$',raw_whitespace))
expected='dev/log/issues/1604/pulls/1605/sessions/ses_e0b779509ffe2Dlj2ErtFECO1g/solve.log'
assert paths=={expected},paths
assert (root/expected).read_bytes()==subprocess.check_output(['git','show','MERGE_HEAD:'+expected],cwd=root)
(out/'archive-and-incoming-whitespace-validation.json').write_text(json.dumps({'verifiedStreams':verified,'sourceIdentitiesMatchPassingChecks':True,'initialWhitespacePaths':sorted(paths),'incomingLogMatchesMainExactly':True,'rawLogPreserved':True,'independentAuthorshipCredit':0},indent=2)+'\n')
doc=root/'docs/case-studies/issue-1580/dynamic-meta-merge-checkpoint.md';text=doc.read_text().replace('are retained separately. After correction,','are retained separately. The broad first-parent whitespace check also flags\nonly an unchanged incoming raw agent log; its exact main bytes are preserved.\nWhitespace validation against main checks our changes separately. After correction,',1);doc.write_text(text)
run('stage',['git','add','--','experiments/issue-1580/evidence/ci/native-families-84e1ad85','experiments/issue-1580/evidence/checks/dynamic-meta-merge','experiments/issue-1580/evidence/commands','docs/case-studies/issue-1580/dynamic-meta-merge-checkpoint.md','experiments/issue-1580/work-plan.md'])
run('naming',['node','scripts/measure-abbreviations.mjs','--check'])
run('post-archive-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-tests-as-docs,check-tests-as-documentation-javascript-twin'])
files=run('staged-files',['git','diff','--cached','--name-only','--diff-filter=ACMR','-z']).decode().split('\0');files=[file for file in files if file]
run('secrets',['bash','scripts/check-secrets.sh',*files])
run('our-whitespace',['git','diff','--cached','--check','origin/main'])
run('rust-format',['rustfmt','--edition','2024','--check','rust/examples/basic_usage.rs','rust/src/server.rs','rust/src/server/dynamic_meta.rs','rust/src/server/transport.rs','rust/tests/unit/dynamic_meta_gateway.rs'])
run('fetch-main',['git','-c','gc.auto=0','fetch','origin','main'])
assert subprocess.check_output(['git','rev-parse','origin/main'],cwd=root)==subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=root)
for label,endpoint in [('issue-comments','issues/1580/comments'),('conversation-comments','issues/1581/comments'),('inline-comments','pulls/1581/comments'),('reviews','pulls/1581/reviews')]:run(label,['gh','api','repos/link-assistant/formal-ai/'+endpoint,'--paginate'])
run('recent-runs',['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','5','--json','databaseId,conclusion,createdAt,headSha'])
for status in ['in_progress','queued']:
    data=json.loads(run('runs-'+status,['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--status',status,'--limit','100','--json','databaseId,workflowName,headSha']))
    assert data==[],data
run('pull-request',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','headRefOid,isDraft,state,title,body,url,baseRefName'])
run('pull-request-diff',['gh','pr','diff','1581','--repo','link-assistant/formal-ai'],False)
(out/'outcome.json').write_text(json.dumps({'allRequiredPassed':True,'records':len(rows),'archiveStreamsVerified':verified,'mergeParentCurrent':True,'queuesEmpty':True,'committed':False,'pushed':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
