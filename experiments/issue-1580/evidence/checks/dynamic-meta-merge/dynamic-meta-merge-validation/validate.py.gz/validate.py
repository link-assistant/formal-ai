import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');out=pathlib.Path('/tmp/issue-1580-research/dynamic-meta-merge-validation')
tests=['experiments/issue-1580/native-checkout-retry.test.mjs','rust/tests/web/default-branch-build-policy.test.mjs','experiments/issue-1580/native-regression-groups.test.mjs','rust/tests/web/dynamic-meta.test.mjs','rust/tests/web/server-dreaming-runtime.test.mjs','rust/tests/web/server.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs']
commands=[('test-'+str(i+1),['node','--max-old-space-size=256','--test','--test-concurrency=1',file]) for i,file in enumerate(tests)]
commands += [('typescript-currency',['node','scripts/translate-es.mjs','--check']),('typescript-runtime',['node','scripts/check-typescript-runtime.mjs']),('all-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs']),('whitespace',['git','diff','--cached','--check'])]
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']='/tmp/issue-1580-research/secretlint-built-in-migration/dependencies/node_modules/.bin:'+env['PATH'];env['FORMAL_AI_GATE_LOG_DIR']=str(out/'gate-logs')
rows=[]
for name,argv in commands:
    started=time.time()
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'argv':argv,'exitCode':result.returncode,'seconds':round(time.time()-started,3)}
    for stream in ['stdout','stderr']:
        raw=(out/(name+'.'+stream)).read_bytes();row[stream]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    rows.append(row);(out/'records.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
(out/'outcome.json').write_text(json.dumps({'allPassed':all(row['exitCode']==0 for row in rows),'commands':len(rows),'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
