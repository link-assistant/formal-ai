import json,os,pathlib,subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');directory=pathlib.Path('/tmp/issue-1580-research/dynamic-meta-package-runtime')
argv=['npm','install','--prefix',str(directory/'dependencies'),'--ignore-scripts','--no-audit','--no-fund','@link-foundation/ui-links@0.1.0']
with (directory/'install.stdout').open('wb') as stdout,(directory/'install.stderr').open('wb') as stderr:result=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
assert result.returncode==0,result.returncode
package=directory/'dependencies/node_modules/@link-foundation/ui-links'
metadata=json.loads((package/'package.json').read_text());assert metadata['version']=='0.1.0'
target=root/'node_modules/@link-foundation/ui-links';target.parent.mkdir(exist_ok=True)
assert not target.exists();target.symlink_to(package,target_is_directory=True)
(directory/'outcome.json').write_text(json.dumps({'installed':True,'rootManifestChanged':False,'version':metadata['version'],'fullIssueComplete':False},indent=2)+'\n')
