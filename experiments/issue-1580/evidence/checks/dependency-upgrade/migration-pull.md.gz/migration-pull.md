https://github.com/link-foundation/command-stream/pull/240

## Changes

- Declare `@xterm/headless`, `@resvg/resvg-js`, and `gifenc` as optional npm peers. The development manifests still install them for feature tests. Default consumer installs omit the emulator, GIF encoder, rasterizer, and platform binaries.
- Keep `new TerminalBuffer()` synchronous and resolve the emulator when the constructor is called. PTY capture and GIF rendering resolve their peers on demand. Deno HTTP entry points use peers installed in the consuming project. Missing packages report the feature and the corresponding install command. SVG and other selected artifact formats remain available without GIF packages. The current JavaScript release fragment requests a major version because existing terminal consumers must explicitly add their peers.
- Replace Chrono with Jiff across the crate, benchmarks, example packages, release scripts, and reusable Rust workflow templates. Preserve Unix seconds for asciicast headers, fixed-millisecond UTC output for the timestamp example, and the existing numeric UTC offset and fractional precision for traces and benchmark reports. Preserve UTC date and filename formats in release scripts. The Cargo release fragment prepares a patch release through the existing publish workflow.
- Refresh dependencies listed by the baseline freshness failure and upgrade `rustix` to a patched release. Replace the deprecated `filetime` call with `std::fs::set_times` to preserve virtual `touch` behavior under the warning-free build. This standard-library API is available on Rust 1.99 and later. Both Cargo lockfile audits now treat warnings as fatal, and the workflow invariant test checks both commands. Dependency freshness now checks optional peer declarations and uses the read-only workflow token for GitHub blocker lookups.

- Keep the Linux Evcxr subprocess on Cargo’s legacy intermediate layout. Cargo 1.100 changed the relative paths from compiled REPL cells to the shared Tokio facade. Evcxr copies the cells before loading them, and the Linux loader could no longer find the facade. The setting applies only to Evcxr. [Cargo build cache](https://doc.rust-lang.org/cargo/reference/build-cache.html)
- Give core-entry tests their own virtual-command configuration and restore the prior value after each affected test. This keeps earlier Bun tests that disable virtual commands from changing these assertions.

## Alternatives and scope

`optionalDependencies` would support `--omit=optional` while retaining the rasterizer in default installs. Optional peers address the default lockfile and downstream licensing concern. The synchronous buffer constructor uses the existing Node `createRequire` pattern, which preserves ESM and CommonJS entry points without introducing top-level await. The existing renderer and emulator still handle output. [npm package metadata](https://docs.npmjs.com/files/package.json/#peerdependenciesmeta)

RustSec recommends Jiff or Time. Time can provide UTC formatting and epoch conversion. Jiff also supports the existing strftime format strings, explicit precision and offsets, and application use without time-zone database features. A standard-library implementation would require separate calendar-formatting code. [RustSec advisory](https://rustsec.org/advisories/RUSTSEC-2026-0543) · [Jiff Timestamp](https://docs.rs/jiff/latest/jiff/struct.Timestamp.html) · [Time OffsetDateTime](https://docs.rs/time/latest/time/struct.OffsetDateTime.html)

Issue #239 attaches only #237 and #238. `link-calculator` is absent from these Cargo manifests and lockfiles. Its parsing, timezone, and date-difference work belongs to its independently tracked migration. The downstream audit exception belongs to Formal AI and is unnecessary for this crate after the release. [Calculator migration](https://github.com/link-assistant/calculator/issues/265) · [Formal AI downstream report](https://github.com/link-assistant/formal-ai/issues/1582)

## Reproduction and verification

- Pack the baseline npm package, install it into an empty npm project, and run the regression in `js/scripts/verify-production-install.mjs`. The baseline fails the optional peer assertion and the consumer lockfile contains the emulator, renderer, and encoder. The updated package passes with a normal install and with `--omit=optional`. The test exercises ESM `$` with `echo ok`, synchronous CommonJS, absent peer resolution and lockfile entries, first-use diagnostics, and SVG output. CI runs the packed check for local and global installations on Node 22, 24, and 26.
- The focused JavaScript suite passed 28 tests covering the installed emulator, capture, GIF/SVG rendering, artifact selection, and the lightweight runner. An isolated Bun consumer ran `echo ok` and got the expected terminal errors when the emulator was absent. A packed Deno npm consumer verified core use and the missing-peer diagnostics. The Deno HTTP smoke check ran core and ShellJS operations and verified `TerminalBuffer` with an explicitly installed peer. The benchmark and workflow invariant tests passed, including a check of the generated JavaScript report timestamp.
- Audit the baseline Rust lockfile using `cargo audit --deny warnings --file Cargo.lock`. The published graph can also be reproduced with a minimal consumer pinned to `command-stream = "=1.13.0"`. That consumer reproduced RUSTSEC-2026-0543, and a consumer using the PR crate passed. The strict audits passed for both updated repository lockfiles. Focused Rust tests passed for the UTC offset and fractional widths, leap-day rollover, Unix epoch boundary, the timestamp example, and `touch` modification time.

- The earlier Linux CI runs exposed two integration failures. The real REPL test failed with `dlopen failed` as detailed in the Rust job log around lines 2680–2706. A minimal Evcxr fixture on Rust 1.100 reproduced the loader failure and retained state with the legacy layout. The full command-stream REPL transcript then passed locally and in Linux CI. The Bun job reported `127 !== 0` and an empty result for a registered command around lines 290612–290673. The seeded `experiments/issue-239/disable-virtual-commands.mjs` reproducer failed both checks before the fix, and all five core-entry tests passed after the fix under Bun 1.4.5 and Node. [Rust CI log](https://github.com/link-foundation/command-stream/actions/runs/44678162387/job/136097094491) · [Bun CI log](https://github.com/link-foundation/command-stream/actions/runs/44678162459/job/136096983528)

The executable parity check passed for all 37 features and the generated documentation is up to date. The npm and Cargo release fragments prepare publication through the existing release workflows after merging.

All eight workflows passed on `c73e95f1c61cd3e6de61b7c005fcd0d4ce33809d`, with 49 passing jobs and six release-only jobs skipped on the pull request event. The Rust workflow built and verified the crate package. Registry publication depends on the release workflow after merge. [Pull request checks](https://github.com/link-foundation/command-stream/pull/240/checks)

Fixes #237
Fixes #238
Fixes #239

