from pathlib import Path
import json,subprocess,sys,os,tomllib,shutil,time,hashlib,resource
r=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/dependency-refresh/resolution')
if '--worker' not in sys.argv:
 out.mkdir(exist_ok=True)
 with (out/'worker.log').open('ab') as stream:p=subprocess.Popen([sys.executable,__file__,'--worker'],cwd=r,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid').write_text(str(p.pid)+'\n');print('Started non-compiling dependency resolution',p.pid,flush=True);sys.exit(0)
manifest=(r/'rust/Cargo.toml').read_text();assert 'web-capture = { version = "0.3.37"' in manifest
manifest=manifest.replace('web-capture = { version = "0.3.37"','web-capture = { version = "0.5.3"')
(out/'Cargo.toml').write_text(manifest);shutil.copy2(r/'rust/Cargo.lock',out/'Cargo.lock');config=tomllib.loads(manifest)
paths=['src/lib.rs','src/main.rs']
for kind in ['bin','test','example','bench']:
 for item in config.get(kind,[]):
  if 'path' in item:paths.append(item['path'])
if config.get('lib',{}).get('path'):paths.append(config['lib']['path'])
for name in paths:
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('// Resolution only; never compiled.\n')
command=['cargo','update','--manifest-path',str(out/'Cargo.toml'),'--package','web-capture','--precise','0.5.3'];env=dict(os.environ,CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0');start=time.monotonic()
def limit():resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
with (out/'update.stdout').open('wb') as stdout,(out/'update.stderr').open('wb') as stderr:p=subprocess.run(command,cwd=out,stdout=stdout,stderr=stderr,env=env,preexec_fn=limit)
d={'command':command,'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3),'memoryLimitMiB':512,'compiled':False,'independentAuthorshipCredit':0,'manifestSha256':hashlib.sha256((out/'Cargo.toml').read_bytes()).hexdigest(),'lockSha256':hashlib.sha256((out/'Cargo.lock').read_bytes()).hexdigest()};(out/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
if p.returncode==0:
 packages=tomllib.loads((out/'Cargo.lock').read_text())['package'];print('fxhash versions',[x['version']for x in packages if x['name']=='fxhash'],flush=True);print('web-capture versions',[x['version']for x in packages if x['name']=='web-capture'],flush=True)
