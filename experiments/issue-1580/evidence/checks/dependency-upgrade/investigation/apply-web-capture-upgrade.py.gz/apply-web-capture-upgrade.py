from pathlib import Path
import subprocess,json,time,shutil,tomllib,hashlib,os,sys
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/dependency-refresh')
manifest=r/'rust/Cargo.toml';text=manifest.read_text();assert 'web-capture = { version = "0.3.37"' in text
manifest.write_text(text.replace('web-capture = { version = "0.3.37"','web-capture = { version = "0.5.3"'))
shutil.copyfile(s/'resolution/Cargo.lock',r/'rust/Cargo.lock')
p=r/'.cargo/audit.toml';text=p.read_text();first=text.index('# RUSTSEC-2025-0057 blocked-upstream');last=text.index('# RUSTSEC-2026-0543 blocked-upstream');text=text[:first]+text[last:]
first=text.index('#   The current lockfile reaches Chrono');last=text.index('#   The maintainer\'s deprecation report')
text=text[:first]+'''#   The current lockfile reaches Chrono through command-stream 1.5.3 and
#   link-calculator 0.22.0. On 2026-11-20, command-stream merged its Jiff
#   migration (PR #240), but crates.io still publishes 1.13.0 with Chrono.
#   Calculator's migration report #265 remains open; its latest published
#   0.24.0 still requires Chrono. Both dependency paths must be removed before
#   this exception can expire. A source fix alone is not a published release.
'''+text[last:]
text=text.replace('ignore = ["RUSTSEC-2025-0057", "RUSTSEC-2026-0543"]','ignore = ["RUSTSEC-2026-0543"]');p.write_text(text)
p=r/'rust/tests/web/cargo-audit-blocked-proof.test.mjs';text=p.read_text().replace('assert.doesNotMatch(lock,/^name = "fxhash"$/mu);','assert.equal(/^name = "fxhash"$/mu.test(lock),false,\'fxhash must leave the production lockfile\');');p.write_text(text)
p=r/'rust/tests/unit/reasoning_contracts.rs';text=p.read_text();assert 'mod component_boundaries;' not in text;text+='\n#[path = "issue_896_component_boundaries.rs"]\nmod component_boundaries;\n';p.write_text(text)
paths=['rust/tests/unit/issue_896_component_boundaries.rs','docs/case-studies/issue-896/self-hosting-authorship/web-component-boundary-invariant.lino','docs/case-studies/issue-896/self-hosting-authorship/agent-cli.log','docs/case-studies/issue-896/self-hosting-authorship/formal-ai.log','docs/case-studies/issue-896/self-hosting-authorship/decomposition.lino']
p=r/'scripts/ci-pull-request-admission.mjs';text=p.read_text();anchor="  'rust/tests/unit/reasoning_contracts.rs',\n";assert text.count(anchor)==1;text=text.replace(anchor,anchor+''.join('  '+repr(x)+',\n' for x in paths));p.write_text(text)
p=r/'rust/tests/web/default-branch-build-policy.test.mjs';text=p.read_text();text+='''
test('published search component regressions and their runtime fixtures select the focused native lane', () => {
  const inputs = '''+json.dumps(paths+['data/meta/web-component-boundary-invariant.lino'])+''';
  for (const path of inputs) assert.equal(admission([path])['native-type-check'], true, path);
  assert.equal(admission(['docs/case-studies/issue-896/unrelated.md'])['native-type-check'], false);
  assert(read('rust/tests/unit/reasoning_contracts.rs').includes('#[path = "issue_896_component_boundaries.rs"]'));
  assert(read('rust/tests/unit/reasoning_contracts.rs').includes('mod component_boundaries;'));
  const step = Object.values(workflow('native-type-check.yml').jobs)[0].steps
    .find(step => step.name === 'Verify isolated native behavior regressions');
  assert.match(nativeRegressionSource(step), /--test reasoning_contracts(?:\\s|$)/u);
  for (const fixture of inputs.filter(path => path.startsWith('docs/'))) assert(readFileSync(fixture).length > 0, fixture);
});
''';p.write_text(text)
(r/'changelog.d/1580-web-capture-upgrade.md').write_text('Upgrade the search-only web-capture component to remove fxhash, retire its audit exception, and execute the existing native search component regressions in pull requests.\n')
print('Applied published dependency upgrade; preserved strict audit and added complete existing component regression module. No Rust build.',flush=True)
