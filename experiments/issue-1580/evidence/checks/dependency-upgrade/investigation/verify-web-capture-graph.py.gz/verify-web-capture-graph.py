from pathlib import Path
import tomllib,json,subprocess,urllib.request,hashlib,resource
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/dependency-refresh')
old=tomllib.loads(subprocess.check_output(['git','show','HEAD:rust/Cargo.lock'],cwd=r,text=True));new=tomllib.loads((r/'rust/Cargo.lock').read_text());before={(p['name'],p['version']) for p in old['package']};after={(p['name'],p['version']) for p in new['package']}
assert not any(name=='fxhash' for name,version in after)
indexes=list((Path.home()/'.cargo/registry/index').glob('*/.cache'));changed=[]
for name,version in sorted(after-before):
 relative=Path('1')/name if len(name)==1 else Path('2')/name if len(name)==2 else Path('3')/name[0]/name if len(name)==3 else Path(name[:2])/name[2:4]/name
 found=[]
 for index in indexes:
  p=index/relative
  if not p.exists():continue
  for chunk in p.read_bytes().split(b'\0'):
   if not chunk.startswith(b'{'):continue
   row=json.loads(chunk)
   if row.get('vers')==version:found.append(row)
 assert len(found)==1,(name,version,len(found))
 entry=found[0];msrv=entry.get('rust_version');assert not msrv or tuple(int(x) for x in msrv.split('.')[:2]) <= (1,99),(name,version,msrv)
 package=next(p for p in new['package'] if p['name']==name and p['version']==version);assert entry['cksum']==package['checksum']
 changed.append({'name':name,'version':version,'rustVersion':msrv,'registryChecksum':entry['cksum'],'yanked':entry['yanked']});assert not entry['yanked']
published=[]
for name,version in [('command-stream','1.13.0'),('link-calculator','0.24.0')]:
 url='https://crates.io/api/v1/crates/'+name+'/'+version+'/dependencies';req=urllib.request.Request(url,headers={'User-Agent':'formal-ai issue 1580 published dependency verification'})
 with urllib.request.urlopen(req) as response:raw=response.read(2*1024*1024)
 (s/(name+'-published-dependencies.json')).write_bytes(raw);deps=json.loads(raw)['dependencies'];chrono=[x for x in deps if x['crate_id']=='chrono'];assert chrono and all(not x['optional'] for x in chrono)
 published.append({'name':name,'version':version,'url':url,'sha256':hashlib.sha256(raw).hexdigest(),'chrono':chrono})
proof={'rootManifestSha256':hashlib.sha256((r/'rust/Cargo.toml').read_bytes()).hexdigest(),'rootLockSha256':hashlib.sha256((r/'rust/Cargo.lock').read_bytes()).hexdigest(),'fxhashPresent':False,'addedVersions':changed,'removedVersions':[{'name':n,'version':v} for n,v in sorted(before-after)],'publishedChronoBlockers':published,'compiled':False,'runtimeBehaviorVerified':False,'independentAuthorshipCredit':0}
(s/'graph-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print('Verified',len(changed),'changed registry versions, checksums, unyanked state and MSRV <= 1.99; published Chrono requirements remain.',flush=True)
args=['cargo','tree','--offline','--locked','--manifest-path','rust/Cargo.toml','--no-default-features','--invert','web-capture','--depth','3']
def bound():resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
with (s/'component-tree.stdout').open('wb') as out,(s/'component-tree.stderr').open('wb') as err:p=subprocess.run(args,cwd=r,stdout=out,stderr=err,preexec_fn=bound)
(s/'component-tree-result.json').write_text(json.dumps({'command':args,'status':p.returncode,'offline':True,'memoryLimitMiB':512,'compiled':False},indent=2)+'\n');print('Offline noncompiling graph observation status',p.returncode,flush=True)
