from pathlib import Path
import json
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/dependency-refresh/checks')
result=json.loads((s/'results.json').read_text());assert result['checks'][-1]['name']=='default-branch-build-policy' and result['checks'][-1]['status']==1
failure=s/'initial-missing-canonical-fixture';failure.mkdir();
for p in s.iterdir():
 if p.is_file() and p.name not in ['pid','worker.log']:p.rename(failure/p.name)
p=r/'scripts/ci-pull-request-admission.mjs';text=p.read_text();anchor="  'rust/tests/unit/issue_896_component_boundaries.rs',\n";assert anchor in text
text=text.replace(anchor,anchor+"  'data/meta/web-component-boundary-invariant.lino',\n");p.write_text(text)
print('Added the exact canonical runtime fixture to native admission; initial focused failure preserved.')
