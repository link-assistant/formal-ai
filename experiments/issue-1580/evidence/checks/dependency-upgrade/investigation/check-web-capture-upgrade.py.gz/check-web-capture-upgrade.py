from pathlib import Path
import subprocess,json,time,os,sys,resource
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/dependency-refresh/checks');s.mkdir(exist_ok=True)
if '--worker' not in sys.argv:
 with (s/'worker.log').open('ab') as out:p=subprocess.Popen([sys.executable,__file__,'--worker'],cwd=r,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 (s/'pid').write_text(str(p.pid)+'\n');print('Started sequential dependency verification',p.pid,flush=True);sys.exit(0)
checks=[]
for name in ['cargo-audit-blocked-proof','default-branch-build-policy','ci-change-detection-checkout','fast-pull-request-production-profile','pages-live-rate-budget']:
 checks.append((name,['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs'],0))
checks.extend([('rust-format',['rustfmt','--edition','2024','--config','skip_children=true','--check','rust/tests/unit/reasoning_contracts.rs'],0),('manifest-metadata',['cargo','metadata','--manifest-path','rust/Cargo.toml','--locked','--no-deps','--format-version','1'],0),('artifact-frozen-proof',['node','experiments/issue-1580/verify-artifact-migration.mjs','--revision','f400d7ab2'],0),('pages-whole-workflow-proof',['node','experiments/issue-1580/verify-pages-migration.mjs'],0),('all-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs'],0)])
rows=[]
for name,args,want in checks:
 print('START',name,flush=True)
 with (s/(name+'.stdout')).open('wb') as out,(s/(name+'.stderr')).open('wb') as err:
  start=time.monotonic();p=subprocess.run(args,cwd=r,stdout=out,stderr=err,env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256',CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0'))
 row={'name':name,'command':args,'status':p.returncode,'expected':want,'seconds':round(time.monotonic()-start,3)};rows.append(row)
 (s/'results.json').write_text(json.dumps({'complete':False,'checks':rows,'nativeBuild':False,'independentAuthorshipCredit':0},indent=2)+'\n');print(row,flush=True)
 if p.returncode!=want:sys.exit(1)
(s/'results.json').write_text(json.dumps({'complete':True,'checks':rows,'nativeBuild':False,'independentAuthorshipCredit':0},indent=2)+'\n')
