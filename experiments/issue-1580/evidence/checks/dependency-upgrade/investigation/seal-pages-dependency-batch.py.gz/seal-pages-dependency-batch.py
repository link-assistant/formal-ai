from pathlib import Path
import gzip, hashlib, json, re, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
evidence = root / 'experiments/issue-1580/evidence'
check = json.loads((scratch / 'dependency-refresh/checks/results.json').read_text())
assert check['complete'] and all(row['status'] == 0 for row in check['checks'])
aggregate = (scratch / 'dependency-refresh/checks/all-local-gates.stdout').read_text()
passed = len(re.findall(r'^PASS ', aggregate, re.M))
skipped = len(re.findall(r'^SKIP ', aggregate, re.M))
assert passed + skipped == 140 and 'FAIL ' not in aggregate
assert '140/140 passed or skipped; failed: none' in aggregate

def digest(raw): return hashlib.sha256(raw).hexdigest()
def write_index(path, rows):
    path.write_text('[\n' + ',\n'.join(json.dumps(row, separators=(',', ':')) for row in rows) + '\n]\n')

def pack_group(destination, sources):
    destination.mkdir(parents=True, exist_ok=True)
    rows = []
    for source, relative in sources:
        raw = source.read_bytes()
        relative = str(relative).replace('src__', 'source__').replace('check-tests-as-docs', 'check-tests-as-documentation')
        archive = raw if source.suffix == '.gz' else gzip.compress(raw, mtime=0)
        target = destination / (relative if source.suffix == '.gz' else relative + '.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        assert not target.exists(), target
        target.write_bytes(archive)
        rows.append({'file': str(target.relative_to(destination)), 'source': str(source),
                     'rawSha256': digest(raw), 'archiveSha256': digest(archive),
                     'bytes': len(raw), 'alreadyCompressed': source.suffix == '.gz'})
    write_index(destination / 'records.json', rows)
    return len(rows)

dependency = scratch / 'dependency-refresh'
sources = []
for source in sorted(dependency.iterdir()):
    if source.is_file() and source.suffix != '.crate': sources.append((source, source.name))
for version in ['0.3.37', '0.4.0', '0.5.3']:
    directory = dependency / ('web-capture-' + version)
    sources.extend((source, str(source.relative_to(dependency))) for source in sorted(directory.rglob('*')) if source.is_file())
for name in ['Cargo.toml', 'Cargo.lock', 'result.json', 'update.stdout', 'update.stderr', 'lock.diff']:
    source = dependency / 'resolution' / name
    if source.exists(): sources.append((source, 'resolution/' + name))
for source in sorted((dependency / 'checks').iterdir()):
    if source.is_file() and source.name not in ['pid', 'worker.log']: sources.append((source, 'checks/' + source.name))
for name in ['resolve-web-capture-upgrade', 'draft-web-capture-regression', 'apply-web-capture-upgrade',
             'check-web-capture-upgrade', 'verify-web-capture-graph', 'repair-candidate-admission']:
    for suffix in ['.py', '.log']:
        source = scratch / (name + suffix)
        if source.exists(): sources.append((source, 'investigation/' + source.name))
for source in sorted((root / 'sandboxes/gates').glob('*.log')):
    gate = source.stem
    if re.search(r'^PASS ' + re.escape(gate) + r' ', aggregate, re.M):
        sources.append((source, 'gates/' + source.name))
count = pack_group(evidence / 'checks/dependency-upgrade', sources)

page_sources = []
for name in ['pages-abbreviated-names.log', 'pages-abbreviated-names-after.log',
             'finish-pages-checks.py', 'finish-pages-checks.log', 'commit-pages-protocol.py',
             'commit-pages-protocol.log']:
    source = scratch / name
    if source.exists(): page_sources.append((source, 'investigation/' + name))
for name in ['aggregate.log', 'result.json']:
    source = scratch / 'all-pages-gates' / name
    if source.exists(): page_sources.append((source, 'initial-full-gates/' + name))
for name in ['final-results.json', 'final-artifact-frozen-proof.stdout', 'final-artifact-frozen-proof.stderr',
             'final-pages-whole-workflow-proof.stdout', 'final-pages-whole-workflow-proof.stderr']:
    source = scratch / 'pages-checks' / name
    if source.exists(): page_sources.append((source, 'later-checks/' + name))
pack_group(evidence / 'checks/pages-deployment/final-batch', page_sources)

review = scratch / 'aca-hosted-review'
transport = json.loads((review / 'artifact-transports.json').read_text())
original = gzip.decompress((evidence / 'ci/native-families-aca32b1a/full-run-44730577755.stdout.gz').read_bytes()).decode().splitlines()
assert digest(('\n'.join(original) + '\n').encode()) == transport['originalLogSha256']
for host in transport['hosts']:
    payload = [{'line': n, 'text': line} for n, line in enumerate(original, 1)
               if line.startswith('Artifact transport (' + host['host'] + ')\t')
               and 'Actual artifact transport preserved every byte and refreshed the cached file.' in line
               and '2026-' in line and not 'echo ' in line]
    assert len(payload) == 1, (host['host'], payload)
    host['payloadAssertions'] = payload
(review / 'artifact-transports-with-payload.json').write_text(json.dumps(transport, indent=2) + '\n')
hosted_sources = [(source, source.name) for source in sorted(review.iterdir()) if source.is_file()]
for name in ['review-aca-hosted-results', 'review-aca-artifact-transports', 'resume-optional-context-collection']:
    for suffix in ['.py', '.log']:
        source = scratch / (name + suffix)
        if source.exists(): hosted_sources.append((source, 'investigation/' + source.name))
for name in ['failure.json', 'worker.log', 'outcome.json', 'resumed-worker.log']:
    source = scratch / 'optional-context-ci' / name
    if source.exists(): hosted_sources.append((source, 'collection/' + name))
pack_group(evidence / 'ci/native-families-aca32b1a/assessment', hosted_sources)

verified = 0
def verify_row(base, row):
    global verified
    packed = (base / row['file']).read_bytes()
    assert digest(packed) == row['archiveSha256'], row['file']
    raw = packed if row.get('alreadyCompressed') else gzip.decompress(packed)
    assert digest(raw) == row['rawSha256'], row['file']
    if 'bytes' in row: assert len(raw) == row['bytes'], row['file']
    verified += 1
for relative, index in [('checks/dependency-upgrade', 'records.json'),
                        ('checks/pages-deployment', 'records.json'),
                        ('checks/pages-deployment/final-batch', 'records.json'),
                        ('checks/artifact-consumers', 'records.json'),
                        ('ci/native-families-aca32b1a/assessment', 'records.json'),
                        ('ci/codeql-producer-aca32b1a', 'producer-files.json')]:
    base = evidence / relative
    for row in json.loads((base / index).read_text()): verify_row(base, row)
base = evidence / 'ci/native-families-aca32b1a'
for row in json.loads((base / 'records.json').read_text()):
    for stream in ['stdout', 'stderr']:
        if stream in row: verify_row(base, row[stream])
summary = {'complete': True, 'gatesPassed': passed, 'explicitExclusions': skipped,
           'nativeBuild': False, 'verifiedArchives': verified, 'dependencyFiles': count,
           'hostedHead': transport['head'], 'unpublishedSourceHosted': False,
           'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
(evidence / 'checks/dependency-upgrade/seal-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
