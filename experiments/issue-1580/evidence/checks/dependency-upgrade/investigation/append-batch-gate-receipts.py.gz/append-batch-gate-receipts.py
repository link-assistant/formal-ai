from pathlib import Path
import gzip, hashlib, json, re
root=Path('/tmp/gh-issue-solver-1794900398048')
scratch=Path('/tmp/issue-1580-research')
out=root/'experiments/issue-1580/evidence/checks/dependency-upgrade'
rows=json.loads((out/'records.json').read_text())
aggregate=(scratch/'dependency-refresh/checks/all-local-gates.stdout').read_text()
names=re.findall(r'^PASS (\S+) ',aggregate,re.M)
assert len(names)==87
sources=[]
for name in names:
    source=root/'experiments/formal_ai_subagent/sandboxes/gates'/(name+'.log')
    assert source.is_file(),source
    sources.append((source,'gates/'+source.name.replace('check-tests-as-docs','check-tests-as-documentation')))
for name in ['seal-pages-dependency-batch.py','seal-pages-dependency-batch.log',
             'write-pages-batch-checkpoints.py','write-pages-batch-checkpoints.log',
             'append-batch-gate-receipts.py']:
    sources.append((scratch/name,'investigation/'+name))
for source,relative in sources:
    raw=source.read_bytes();packed=gzip.compress(raw,mtime=0);target=out/(relative+'.gz')
    target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists(),target
    target.write_bytes(packed)
    rows.append({'file':str(target.relative_to(out)),'source':str(source),
      'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),
      'bytes':len(raw),'alreadyCompressed':False})
for row in rows:
    packed=(out/row['file']).read_bytes();assert hashlib.sha256(packed).hexdigest()==row['archiveSha256']
    raw=packed if row['alreadyCompressed'] else gzip.decompress(packed)
    assert hashlib.sha256(raw).hexdigest()==row['rawSha256']
(out/'records.json').write_text('[\n'+',\n'.join(json.dumps(row,separators=(',',':')) for row in rows)+'\n]\n')
summary=json.loads((out/'seal-summary.json').read_text());summary.update(dependencyFiles=len(rows),detailedGateLogs=87,verifiedArchives=summary['verifiedArchives']+len(sources))
(out/'seal-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Archived and hash-verified all 87 detailed gate logs and five supplied batch helpers/logs.')
