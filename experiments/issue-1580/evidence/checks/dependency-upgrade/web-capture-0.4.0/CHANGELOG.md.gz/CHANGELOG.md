# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 0.4.0

- Add opt-in transport-independent SHA-256 capture caching, TTL, offline stale replay, portable fixtures, and capture listing/pruning.
- Upgrade every direct dependency to its current stable release, including reqwest 0.13, scraper 0.27, zip 8, and browser-commander 0.19; remove fxhash.
- Adapt reqwest TLS/query features and WebSocket text payloads; preserve native TLS as an opt-in and minimal search builds.
- Require dependency freshness and a fully updated lockfile in CI.

## 0.3.37

### Patch Changes

- Take `reqwest` with `default-features = false` and `rustls-tls`, so the crate no
  longer forces `native-tls`/`openssl-sys` on consumers (#151). System TLS is now
  available as the opt-in `native-tls` feature.

## 0.3.36

### Patch Changes

- Auto-release unreleased changes

## 0.3.35

### Patch Changes

- Auto-release unreleased changes

## 0.3.34

### Patch Changes

- Auto-release unreleased changes

## 0.3.33

### Patch Changes

- Auto-release unreleased changes

## 0.3.32

### Patch Changes

- Add shared AI dialog capture for ChatGPT share links with structured
  transcript output and unsupported-provider diagnostics.

## 0.3.31

### Patch Changes

- Fix fresh dependency resolution failures (issue #137). Update to
  `html-to-markdown-rs` 3.6 and adapt `src/kreuzberg.rs` to the new
  `InlineImage.dimensions` (`ImageDimensions { width, height }` instead of a
  `(u32, u32)` tuple). Drop the unused `brotli` decompression feature from
  `reqwest` to avoid the broken `brotli 8.0.3` / `alloc-no-stdlib` graph, which
  lets a from-scratch `cargo add web-capture` build succeed again. Bump
  `rust-version` to the latest stable (1.96) and add a CI job that builds the
  crate against a freshly resolved lockfile to catch registry drift before
  release.

## 0.3.30

### Patch Changes

- Auto-release unreleased changes

## 0.3.29

### Patch Changes

- Auto-release unreleased changes

## 0.3.28

### Patch Changes

- Auto-release unreleased changes

## 0.3.27

### Patch Changes

- Auto-release unreleased changes

## 0.3.24

### Patch Changes

- Auto-release unreleased changes

## 0.3.23

### Patch Changes

- Auto-release unreleased changes

## 0.3.22

### Patch Changes

- Auto-release unreleased changes

## 0.3.21

### Patch Changes

- Auto-release unreleased changes

## 0.3.20

### Patch Changes

- Auto-release unreleased changes

## 0.3.19

### Patch Changes

- Auto-release unreleased changes

## 0.3.18

### Patch Changes

- Auto-release unreleased changes

## 0.3.17

### Patch Changes

- Auto-release unreleased changes

## 0.3.16

### Patch Changes

- Auto-release unreleased changes

## 0.3.15

### Patch Changes

- Auto-release unreleased changes

## 0.3.14

### Patch Changes

- Auto-release unreleased changes

## 0.3.13

### Patch Changes

- Auto-release unreleased changes

## 0.3.12

### Patch Changes

- Auto-release unreleased changes

## 0.3.11

### Patch Changes

- Auto-release unreleased changes

## 0.3.10

### Patch Changes

- Auto-release unreleased changes

## 0.3.9

### Patch Changes

- Wait for Google Docs browser-model chunks to quiesce before parsing captures.

## 0.3.8

### Patch Changes

- Auto-release unreleased changes

## 0.3.7

### Patch Changes

- Auto-release unreleased changes

## 0.3.6

### Patch Changes

- Auto-release unreleased changes

## 0.3.5

### Patch Changes

- Auto-release unreleased changes

## 0.3.4

### Patch Changes

- Auto-release unreleased changes

## 0.3.3

### Patch Changes

- Auto-release unreleased changes

## 0.2.1

### Patch Changes

- Auto-release unreleased changes

## [0.1.0] - 2025-01-22

### Added

- Initial Rust implementation of web-capture
- HTTP server with compatible API to JavaScript version
- CLI with `--serve`, `--format`, `--output`, and `--port` options
- HTML fetching and rendering via browser-commander
- HTML to Markdown conversion
- PNG screenshot capture
- Relative to absolute URL conversion
- UTF-8 encoding support
- Docker support
