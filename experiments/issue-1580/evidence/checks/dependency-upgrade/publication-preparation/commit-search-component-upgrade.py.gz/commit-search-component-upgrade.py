from pathlib import Path
import subprocess,json
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/dependency-refresh/checks')
d=json.loads((s/'results.json').read_text());assert d['complete'] and all(x['status']==0 for x in d['checks'])
assert subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip()=='issue-1580-8d61a32a61e1'
files=['.cargo/audit.toml','rust/Cargo.toml','rust/Cargo.lock',
 'rust/tests/unit/reasoning_contracts.rs','rust/tests/web/cargo-audit-blocked-proof.test.mjs',
 'rust/tests/web/default-branch-build-policy.test.mjs','scripts/ci-pull-request-admission.mjs',
 'experiments/issue-1580/fixtures/audit-before-web-capture-upgrade.toml','changelog.d/1580-web-capture-upgrade.md']
subprocess.run(['git','diff','--check'],cwd=r,check=True)
subprocess.run(['git','add','--',*files],cwd=r,check=True)
subprocess.run(['git','commit','-m','Remove fxhash through published search component upgrade'],cwd=r,check=True)
print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip())
