from pathlib import Path
import subprocess,gzip,hashlib,json
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research')
assert subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip()=='issue-1580-8d61a32a61e1'
log=(s/'final-pages-batch-gates.log').read_text();assert '5/5 passed or skipped; failed: none' in log and 'Exit Code: 0' in log
out=r/'experiments/issue-1580/evidence/checks/dependency-upgrade/publication-preparation';out.mkdir(exist_ok=True)
rows=[]
sources=[s/name for name in ['final-pages-batch-gates.log','commit-search-component-upgrade.py','commit-search-component-upgrade.log','append-batch-gate-receipts.log','prepare-combined-pages-publication.py','prepare-combined-pages-publication.log','commit-combined-pages-evidence.py']]
sources.extend(sorted((s/'combined-pages-publication').glob('*.txt')))
for p in sorted((r/'experiments/issue-1580/evidence/commands').glob('2026-11-20T13-*.json')):sources.append(p)
for source in sources:
 raw=source.read_bytes();packed=gzip.compress(raw,mtime=0);name=source.name+'.gz';target=out/name;assert not target.exists(),target;target.write_bytes(packed)
 rows.append({'file':name,'source':str(source),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw)})
(out/'records.json').write_text('[\n'+',\n'.join(json.dumps(x,separators=(',',':')) for x in rows)+'\n]\n')
files=['docs/case-studies/issue-1580/README.md','docs/case-studies/issue-1580/pages-deployment-checkpoint.md','docs/case-studies/issue-1580/published-search-dependency-checkpoint.md','docs/case-studies/issue-1580/hosted-aca32b1a-checkpoint.md',
 'experiments/issue-1580/work-plan.md','experiments/issue-1580/evidence/checks/artifact-consumers','experiments/issue-1580/evidence/checks/pages-deployment','experiments/issue-1580/evidence/checks/dependency-upgrade','experiments/issue-1580/evidence/ci/codeql-producer-aca32b1a','experiments/issue-1580/evidence/ci/native-families-aca32b1a']
subprocess.run(['git','diff','--check'],cwd=r,check=True)
subprocess.run(['git','add','--',*files],cwd=r,check=True)
subprocess.run(['git','commit','-m','Preserve Pages dependency and actual hosted verification receipts'],cwd=r,check=True)
print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip())
