from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research')
out=s/'combined-pages-publication';out.mkdir(exist_ok=True)
body=(s/'optional-context-publication/pull-request-body.md').read_text()
anchor='- Retain pinned template comparisons, executable negative controls and upstream reports. Reporting a defect establishes no upstream repair.'
assert anchor in body
body=body.replace(anchor,'''- Migrate all 97 direct artifact consumers across 19 workflows to the strict-digest raw transport and streaming extractor, preserving names, destinations, selection semantics, Python compatibility and staged release operations.
- Replace the deprecated Pages bundle with the template REST retry/poll/cancel protocol. Bind retry adoption to repository, immutable upload artifact ID and full source SHA; preserve workflow trust, permissions, concurrency, deadlines and live verification. The actual pinned JavaScript/Python helpers reproduce cross-artifact adoption before this repair.
- Upgrade published web-capture to 0.5.3, removing fxhash from the actual lockfile and deleting only its obsolete audit exception. Admit all seven existing component-boundary native tests and their runtime fixture closure. Strict Chrono proof and --deny warnings remain.
'''+anchor)
a=body.index('- Previous published head ')
b=body.index('- Full workflow logs contain 123 actual source-size warnings;',a)
body=body[:a]+'''- Published head `aca32b1aa27aee55f1d9443f54d6a1c08f77ccb0` finishes all 24 workflows successfully. [CI/CD Pipeline 44730578227](https://github.com/link-assistant/formal-ai/actions/runs/44730578227) passes 521 actual native tests across nine executed jobs. [Complete evidence](https://github.com/link-assistant/formal-ai/tree/issue-1580-8d61a32a61e1/experiments/issue-1580/evidence/ci/native-families-aca32b1a) preserves 404 hash-verified command streams, original summary line numbers and the transient collection retry. These results do not verify the subsequent artifact consumer, Pages or dependency changes.
- Original Actions and Rust SARIF from [Security 44730612343](https://github.com/link-assistant/formal-ai/actions/runs/44730612343) both contain zero findings, successful invocations and no warning/error extraction notifications. Actions extracts 75 files; Rust extracts 2,573 files. Rust retains 66 informational consistency notes and 631 unresolved macro records at level none. The earlier 406 ABI/105 context warnings no longer emit, while path-by-path coverage qualification remains open. [Original reports and producer evidence](https://github.com/link-assistant/formal-ai/tree/issue-1580-8d61a32a61e1/experiments/issue-1580/evidence/ci/codeql-producer-aca32b1a) are retained without altering analysis notifications.
- [Workflows 44730577755](https://github.com/link-assistant/formal-ai/actions/runs/44730577755) passes actual artifact upload/download/extraction on Ubuntu 24.04, macOS 15 and Windows 2025. Every upload/download digest matches; all three 1,024-byte assertions preserve payload bytes, cached replacement and unrelated files. Node runs with --throw-deprecation and emits no deprecation or warning/error annotation. This verifies the shared adapter at aca32b1a; the later 97 consumer rewrites still require hosted execution.
- The final combined 140-entry local JavaScript inventory passes 87 gates, with 53 explicit native/context exclusions and zero failures. All 87 detailed gate logs and 1,102 archive identities are preserved. All twelve Pages-related test files pass; six actual pinned-template controls include two failing negative controls when artifact binding is disabled. Five documentation/archive gates pass again after archival. No local Rust build runs. [Pages checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/pages-deployment-checkpoint.md) separates local protocol tests from pending actual server publication and served identity.
- The minimal fxhash regression fails against the old production lock and passes after the published dependency update. All eight audit groups and 98 admission/build-policy checks pass; all 22 changed registry versions have verified checksums and MSRV at or below 1.99. Locked metadata and formatting pass without compilation. The offline cargo-tree observation fails on an uncached aead version and earns no execution credit. Actual strict audit and seven unchanged component tests await new-head CI. [Dependency checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/published-search-dependency-checkpoint.md) retains both currently published Chrono blockers.
'''+body[b:]
old='Experimental `unsafe-libyaml` maintenance and crates.io publish-token certainty remain open. Extracting the CodeQL tests removes one former size warning; thresholds and dependency exceptions are unchanged.'
assert old in body
body=body.replace(old,'Experimental `unsafe-libyaml` maintenance and crates.io publish-token certainty remain open. Extracting the CodeQL tests removes one former size warning; thresholds remain unchanged. The new published search update removes the obsolete fxhash exception; Chrono remains proof-guarded.')
old='fresh hosted verification of the Rust optional-context repair, native detector and three artifact transports; remaining direct artifact consumers, Pages deprecation and complete Rust extraction coverage,'
assert old in body
body=body.replace(old,'fresh hosted verification of the 97 consumer migrations, Pages protocol and published search upgrade; actual Pages server acceptance/publication and served identity, complete Rust extraction coverage,')
assert body.count('Fixes #1580')==1 and '?raw=true' in body
(out/'pull-request-body.md').write_text(body)
# Preserve review tooling limits and use local Git for the remaining review.
failure='gh pr diff 1581 failed: HTTP 406, diff exceeded GitHub maximum of 300 files. Local Git diff is required; complete PR review remains unfinished.\n'
(out/'github-diff-limit.txt').write_text(failure)
with (out/'local-production.diff').open('wb') as f:
 subprocess.run(['git','diff','--no-ext-diff','origin/main...HEAD','--','.cargo','.github','scripts','rust/src','rust/tests'],cwd=r,stdout=f,check=True)
print('Prepared current PR description; original closing reference and both screenshots retained.')
