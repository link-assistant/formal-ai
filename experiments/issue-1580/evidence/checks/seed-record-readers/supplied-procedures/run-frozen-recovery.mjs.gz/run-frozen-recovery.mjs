// Temporary recovery using the previously retained immutable JavaScript driver.
// Supplied command and implementation receive zero independent authorship credit.
import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const root='/tmp/gh-issue-solver-1794900398048';
const driver='/tmp/issue-1580-research/frozen-formal-driver-a748854/experiments/js_dogfood/drive.mjs';
const shellCommand="env sh -c 'python3 /tmp/issue-1580-research/finish-seed-record-readers.py'";
const request='Run '+shellCommand;
const result=spawnSync(process.execPath,['--max-old-space-size=256',driver,'--dir',root,'--steps','4',request],{cwd:root,encoding:'utf8',maxBuffer:8*1024*1024});
const record={runtime:'Formal AI JavaScript immutable recovery driver',source:'a748854197dcc693033610acc6589f10b1c6d525',driver,request,...result,independentAuthorshipCredit:0,verificationCredit:0};
writeFileSync(root+'/experiments/issue-1580/evidence/commands/2026-11-21T18-02-frozen-seed-reader-recovery.json',JSON.stringify(record,null,2)+'\n');
const exact=[...(result.stdout??'').matchAll(/^>> bash (\{.*\})$/gmu)].some(match=>JSON.parse(match[1]).command===shellCommand);
const codes=[...(result.stdout??'').matchAll(/Exit Code: (\d+)/gu)].map(match=>Number(match[1]));
console.log(JSON.stringify({status:result.status,exact,codes}));
if(result.status||!exact||!codes.length||codes.some(x=>x!==0))process.exit(1);
