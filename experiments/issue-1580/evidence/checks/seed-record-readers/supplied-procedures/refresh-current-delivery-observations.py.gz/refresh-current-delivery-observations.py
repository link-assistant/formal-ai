from pathlib import Path
import subprocess,json,gzip,re,concurrent.futures
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-delivery-observations');out.mkdir(exist_ok=False)
commands={
 'issue':['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','title,body,url'],
 'issue-comments':['gh','api','repos/link-assistant/formal-ai/issues/1580/comments','--paginate'],
 'conversation':['gh','api','repos/link-assistant/formal-ai/issues/1581/comments','--paginate'],
 'inline-comments':['gh','api','repos/link-assistant/formal-ai/pulls/1581/comments','--paginate'],
 'reviews':['gh','api','repos/link-assistant/formal-ai/pulls/1581/reviews','--paginate'],
 'pull-request':['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','title,body,headRefOid,baseRefName,isDraft,statusCheckRollup,mergeStateStatus,url'],
 'runs':['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','100','--json','databaseId,status,conclusion,createdAt,headSha,workflowName'],
 'main':['gh','api','repos/link-assistant/formal-ai/commits/main']}
def run(item):
 name,args=item
 with (out/(name+'.json')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 assert r.returncode==0,(name,r.returncode)
 return name
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,commands.items()))
captures=root/'experiments/issue-1580/evidence/ci/corrected-repair-round-ba01ef99';warnings=[]
for file in sorted(captures.glob('full-run-*.stdout.gz')):
 with gzip.open(file,'rt') as stream:
  for number,line in enumerate(stream,1):
   if re.search(r'::warning|##\[warning\]|warning: ',line):warnings.append({'archive':file.name,'line':number,'text':line.rstrip()})
(out/'warning-observations.jsonl').write_text(''.join(json.dumps(row)+'\n' for row in warnings))
feedback={name:len(json.loads((out/(name+'.json')).read_text())) for name in ['issue-comments','conversation','inline-comments','reviews']}
main=json.loads((out/'main.json').read_text())['sha'];runs=json.loads((out/'runs.json').read_text());active=[row for row in runs if row['status']!='completed']
(out/'outcome.json').write_text(json.dumps({'complete':True,'feedbackCounts':feedback,'main':main,'active':active,'warnings':len(warnings),'independentAuthorshipCredit':0},indent=2)+'\n');print((out/'outcome.json').read_text())
