from pathlib import Path
import json, subprocess, sys, traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'final-gate-integration-resumed'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':result.returncode}),flush=True)
 assert result.returncode in allowed,(name,result.returncode)
try:
 previous=scratch/'final-gate-integration-completion'
 assert 'rust-projection-generation' in (previous/'failed.txt').read_text()
 assert 'ERR_WORKER_OUT_OF_MEMORY' in (previous/'rust-projection-generation.stderr').read_text()
 run('rust-projection-generation',['node','--max-old-space-size=768','scripts/translate-js-rust.mjs','--write','--jobs','1','--meta-language','.meta-language','js/agentic/crate/proposition_structure.mjs','js/agentic/crate/text_formalization.mjs'])
 run('rust-projection-currency',['node','--max-old-space-size=256','scripts/translate-js-rust.mjs','--verify'])
 run('scoped-closure-controls',['python3','scripts/test-shared-lexeme-closure.py'])
 run('package-mirror-before',['node','--max-old-space-size=256','scripts/mirror-package-data.mjs','--check'],(1,))
 run('package-mirror-generation',['node','--max-old-space-size=256','scripts/mirror-package-data.mjs','--write'])
 for name in ['issue-0918-handler-inventory','package-data-mirror-twin']:
  run(name,['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs'])
 gates='check-closure-audit,check-hardcoded-language-js-twin,check-hardcoded-language,check-minimal-core-boundary-js-twin,check-minimal-core-boundary,check-package-self-containment,check-twin-citations,check-worker-line-budget-js-twin,check-worker-line-budget,check-abbreviations,check-file-size,check-changelog-fragment-js-twin,check-reconstructed-changelog'
 run('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only',gates])
 run('all-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs'])
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'unchangedCoreDispositions':True,'outsideCoreCeilingsUnchanged':True,'sourceFiles':93,'sourceLines':36532,'allGatesStatus':0,'maintainedIssueTestsPassed':301,'warnings':11,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0,'projectionJobs':1,'projectionHeapMiB':768},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
