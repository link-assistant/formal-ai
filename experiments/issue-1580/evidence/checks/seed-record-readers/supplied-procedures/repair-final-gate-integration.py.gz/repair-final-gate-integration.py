from pathlib import Path
import json,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'final-gate-integration-repair'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode in allowed,(name,r.returncode)
try:
 previous=scratch/'seed-record-reader-validation';assert (previous/'failed.txt').exists() and 'all-gates' in (previous/'failed.txt').read_text()
 run('inventory-before',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-0918-handler-inventory.test.mjs'],(1,))
 ledger=root/'data/meta/core-boundary-ledger.lino';text=ledger.read_text();(out/'previous-ledger.lino').write_text(text)
 assert text.count('  source_file_count_max 92\n')==1 and text.count('  source_lines_max 36532\n')==1
 parent='rust/src/solver_handlers/statistics.rs';child='rust/src/solver_handlers/statistics/word_problems.rs'
 assert len((root/parent).read_text().splitlines())==865 and len((root/child).read_text().splitlines())==112
 needle='  source '+parent+'\n    disposition promote\n    baseline_lines 976\n';assert text.count(needle)==1
 text=text.replace(needle,needle.replace('976','865'),1).replace('  source_file_count_max 92\n','  source_file_count_max 93\n',1).replace('  source_lines_max 36532\n','  source_lines_max 36533\n',1)
 entry='  source '+child+'\n    disposition promote\n    baseline_lines 112\n    core_component statistics_interpreter\n    reason "Issue #1580 extracts the existing complete seed-driven word-problem entry point from statistics.rs. The original body and comments are conserved; its promoted statistics disposition remains unchanged."\n'
 text=text.replace('  source '+parent+'\n',entry+'  source '+parent+'\n',1)
 note='  note "Issue #1580 conserves the complete statistics word-problem function in a child module: statistics.rs 976 to 865 lines and statistics/word_problems.rs 112 lines. One module boundary adds one net line. All prior dispositions and outside-core ceilings remain unchanged; the exact recursive source census is 93 files and 36533 lines."\n'
 assert text.startswith('core_boundary_ledger\n');ledger.write_text(text.replace('core_boundary_ledger\n','core_boundary_ledger\n'+note,1))
 run('package-mirror-before',['node','--max-old-space-size=256','scripts/mirror-package-data.mjs','--check'],(1,))
 run('package-mirror-generation',['node','--max-old-space-size=256','scripts/mirror-package-data.mjs','--write'])
 for name in ['issue-0918-handler-inventory','package-data-mirror-twin']:
  run(name,['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs'])
 run('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-minimal-core-boundary-js-twin,check-minimal-core-boundary,check-package-self-containment,check-abbreviations,check-file-size,check-changelog-fragment-js-twin,check-reconstructed-changelog'])
 run('all-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs'])
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'unchangedCoreDispositions':True,'outsideCoreCeilingsUnchanged':True,'sourceFiles':93,'sourceLines':36533,'allGatesStatus':0,'maintainedIssueTestsPassed':301,'warnings':11,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
