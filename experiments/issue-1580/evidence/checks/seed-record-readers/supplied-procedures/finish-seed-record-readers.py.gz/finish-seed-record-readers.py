from pathlib import Path
import json,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'seed-record-reader-continuation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==0,(name,r.returncode)
try:
 host=root/'js/server/worker-host.mjs';source=host.read_text();old='  evaluated.delete(script);\n';assert source.count(old)==1;host.write_text(source.replace(old,'''  // The constructor already completed this readonly lexical provider.
  // Only the private evaluator receipt for these exact bytes permits reuse.
  if (script === "js/seed-record-readers.js" && evaluated.get(script) === sourceHash) return context;
'''+old,1))
 test=root/'rust/tests/web/worker-script-prerequisites.test.mjs';source=test.read_text();assert source.count('function freshBrowserEntry(failBootstrap = false) {')==1;source=source.replace('function freshBrowserEntry(failBootstrap = false) {','function freshBrowserEntry(failBootstrap = false, failRecords = false) {',1)
 old="      vm.runInContext(readFileSync(path.join(REPO_ROOT, owner), 'utf8'), browser, { filename: owner });";assert source.count(old)==1;source=source.replace(old,"      if (failRecords && owner === 'js/seed-record-readers.js') throw Error('ActualRecordReaderImportFailed');\n"+old,1)
 source+='''
test('constructor record reader can be reused by the actual worker importer', () => {
  const context = createBrowserContext();
  loadBrowserScript(context, 'js/seed-record-readers.js');
  loadBrowserScript(context, 'js/seed-record-readers.js');
  loadBrowserScript(context, 'js/seed_loader.js');
  assert.equal(vm.runInContext('typeof self.FormalAiSeed.extractFacts', context), 'function');
});
test('failed record reader import stops browser seed evaluation', () => {
  const {browser, imports, bootstrapError} = freshBrowserEntry(false, true);
  assert.match(bootstrapError?.message ?? '', /ActualRecordReaderImportFailed/);
  assert(imports.includes('js/seed-record-readers.js'));
  assert(!imports.includes('js/seed_loader.js'));
  assert.equal(vm.runInContext('typeof self.FormalAiSeed', browser), 'undefined');
});
''';test.write_text(source)
 for owner in ['worker-script-prerequisites','worker-bootstrap','shared-lexeme-fields','esm-parser-bootstrap','browser-seed-byte-roundtrip','browser-modules','meta-program-transition-cache','three-source-roots-layout']:
  run(owner,['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+owner+'.test.mjs'])
 run('projection-currency',['node','--max-old-space-size=256','scripts/translate-js-rust.mjs','--verify'])
 run('source-warnings',['node','--max-old-space-size=256','scripts/check-file-size.mjs']);warnings=(out/'source-warnings.stdout').read_text().count('::warning file=');assert warnings==11,warnings
 run('whitespace',['git','diff','--check']);(out/'outcome.json').write_text(json.dumps({'complete':True,'warnings':warnings,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
