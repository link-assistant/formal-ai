from pathlib import Path
import json,collections
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'published-warning-review';out.mkdir(exist_ok=False)
rows=[json.loads(x) for x in (scratch/'current-delivery-observations/warning-observations.jsonl').read_text().splitlines()]
categories=collections.defaultdict(list)
for row in rows:
 text=row['text']
 if '##[warning]' in text:category='emitted-annotation'
 elif '\\x1b' in repr(text) or 'echo ' in text or '"^[[0m' in text:category='printed-command-or-test-source'
 else:category='needs-context'
 categories[category].append(row)
for name,records in categories.items():
 (out/(name+'.jsonl')).write_text(''.join(json.dumps(x)+'\n' for x in records))
summary={k:len(v) for k,v in categories.items()};(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
for row in categories['emitted-annotation']:
 if not any(x in row['text'] for x in ['file has','still running after']):print(row['archive'],row.get('line'),row['text'][:1000])
