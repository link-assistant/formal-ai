from pathlib import Path
source=Path('/tmp/issue-1580-research/repair-final-gate-integration.py').read_text().replace("out=scratch/'final-gate-integration-repair'","out=scratch/'final-gate-integration-continuation'")
needle=" run('package-mirror-before'"
assert source.count(needle)==1
extra='''
 # Capture every actionable failure from the completed inventory, not just its tail.
 logs=root/'experiments/formal_ai_subagent/sandboxes/gates'
 for name in ['check-closure-audit','check-hardcoded-language-js-twin','check-hardcoded-language','check-minimal-core-boundary-js-twin','check-minimal-core-boundary','check-package-self-containment','check-twin-citations','check-worker-line-budget-js-twin','check-worker-line-budget']:
  (out/(name+'.previous.log')).write_bytes((logs/(name+'.log')).read_bytes())
 schema=root/'data/meta/shared-lexeme-fields-schema.lino';before=schema.read_text();(out/'previous-shared-lexeme-schema.lino').write_text(before)
 import hashlib
 changed=[]
 def current_identity(match):
  path,digest=match[1],match[2];actual=hashlib.sha256((root/path).read_bytes()).hexdigest()
  if digest!=actual:changed.append(path)
  return '  runtime-source '+path+' '+actual
 schema.write_text(re.sub(r'^  runtime-source (\\S+) ([a-f0-9]{64})$',current_identity,before,flags=re.M));assert changed==['js/seed_loader.js','ts/seed_loader.ts'],changed
 allowlist=root/'scripts/hardcoded-language-allowlist.txt';before=allowlist.read_text();(out/'previous-hardcoded-language-allowlist.txt').write_text(before)
 expected=before.replace('rust/src/engine.rs\\trule_', 'rust/src/engine/knowledge_graph.rs\\trule_')
 assert sum(line.startswith('rust/src/engine.rs\\trule_') for line in before.splitlines())==8
 run('hardcoded-allowlist-generation',['node','--max-old-space-size=256','scripts/check-hardcoded-language.mjs','--write'])
 assert sorted(allowlist.read_text().splitlines())==sorted(expected.splitlines()),'only the eight conserved source paths may move'
 for owner,markers,previous_path,current_path in [
  ('js/agentic/crate/proposition_structure.mjs',['fn read_proposition_structure'],'rust/src/formalization/proposition_structure.rs','rust/src/formalization/proposition_structure/reader.rs'),
  ('js/agentic/crate/text_formalization.mjs',['enum WordKind','enum Polarity','WordKind::is_term','WordKind::is_known'],'rust/src/formalization/text_statements.rs','rust/src/formalization/text_statements/types.rs'),
  ('js/agentic/planner.mjs',['fn plan_chat_step_routes'],'rust/src/agentic_coding/planner.rs','rust/src/agentic_coding/planner/request_routes.rs')]:
  p=root/owner;before=p.read_text();backup=out/'preimages'/owner;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_text(before)
  lines=before.splitlines(keepends=True);count=0
  for i,line in enumerate(lines):
   if any('`'+marker+'`' in line for marker in markers) and previous_path in line:lines[i]=line.replace(previous_path,current_path);count+=1
  assert count==len(markers),(owner,count,markers);p.write_text(''.join(lines))
 budget=root/'data/meta/worker-line-budget/formal_ai_worker.lino';before=budget.read_text();(out/'previous-worker-entry-budget.lino').write_text(before)
 assert before.count('  ceiling 88\\n')==1;budget.write_text(before.replace('  ceiling 88\\n','  ceiling 89\\n',1).replace('bootstrapping does.','bootstrapping does. Issue #1580 adds one required seed-record reader prerequisite import; the entry still contains no solver logic.'))
 run('worker-mirror-generation',['node','--max-old-space-size=256','scripts/generate-worker-crate-modules.mjs','--write'])
 run('typescript-generation',['node','--max-old-space-size=256','scripts/translate-es.mjs','--write'])
 run('typescript-currency',['node','--max-old-space-size=256','scripts/translate-es.mjs','--check'])
 run('rust-projection-generation',['node','--max-old-space-size=256','scripts/translate-js-rust.mjs','--write','--meta-language','.meta-language','js/agentic/crate/proposition_structure.mjs','js/agentic/crate/text_formalization.mjs'])
 run('rust-projection-currency',['node','--max-old-space-size=256','scripts/translate-js-rust.mjs','--verify'])
 run('scoped-closure-controls',['python3','scripts/test-shared-lexeme-closure.py'])
'''
source=source.replace(needle,extra+'\n'+needle,1)
source=source.replace("'check-minimal-core-boundary-js-twin,check-minimal-core-boundary,check-package-self-containment,check-abbreviations,check-file-size,check-changelog-fragment-js-twin,check-reconstructed-changelog'","'check-closure-audit,check-hardcoded-language-js-twin,check-hardcoded-language,check-minimal-core-boundary-js-twin,check-minimal-core-boundary,check-package-self-containment,check-twin-citations,check-worker-line-budget-js-twin,check-worker-line-budget,check-abbreviations,check-file-size,check-changelog-fragment-js-twin,check-reconstructed-changelog'")
exec(compile(source,__file__,'exec'))
