from pathlib import Path
import gzip,hashlib,json,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'seed-record-reader-extraction'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode in allowed,(name,r.returncode)
def replace(owner,old,new):
 path=root/owner;text=path.read_text();assert text.count(old)==1,(owner,old);before=out/'preimages'/owner;before.parent.mkdir(parents=True,exist_ok=True);assert not before.exists();before.write_text(text);path.write_text(text.replace(old,new,1))
try:
 assert json.loads((scratch/'final-native-headroom-preservation/outcome.json').read_text())['complete']
 source=(root/'js/seed_loader.js').read_text();assert source==(root/'ts/seed_loader.ts').read_text()
 fixture=root/'experiments/issue-1580/evidence/checks/seed-record-readers/previous-loader.js.gz';fixture.parent.mkdir(exist_ok=False);fixture.write_bytes(gzip.compress(source.encode(),mtime=0))
 test=root/'experiments/issue-1580/seed-record-readers.test.mjs';assert not test.exists();test.write_text('''import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import vm from 'node:vm';
import test from 'node:test';
import {fileURLToPath} from 'node:url';
import {checkListedFiles} from '../../scripts/check-file-size.mjs';
const root=fileURLToPath(new URL('../../',import.meta.url)).replace(/\\/$/u,'');
const read=name=>readFileSync(root+'/'+name,'utf8');
for(const owner of ['js/seed_loader.js','ts/seed_loader.ts'])test(owner+' retains source headroom',()=>{
 assert.deepEqual(checkListedFiles(root,new Set([owner])),{warnings:[],violations:[],embeddedDataViolations:[]});
});
function api(loader,records=true){
 const context=vm.createContext({console,TextEncoder});context.self=context;
 vm.runInContext(read('js/parser-cache-primordials.js'),context);
 if(records&&existsSync(root+'/js/seed-record-readers.js'))vm.runInContext(read('js/seed-record-readers.js'),context);
 vm.runInContext(loader,context);return context.FormalAiSeed;
}
const plain=value=>JSON.parse(JSON.stringify(value));
test('all concept, context and fact fields equal the original reader on real seed documents',()=>{
 const previous=api(gunzipSync(readFileSync(new URL('./evidence/checks/seed-record-readers/previous-loader.js.gz',import.meta.url))).toString());
 const current=api(read('js/seed_loader.js'));
 for(const file of ['data/seed/concepts.lino','data/seed/concept-contexts.lino','data/seed/facts.lino','data/seed/fact-captures.lino']){
  const text=read(file),oldRoot=previous.parse(text),newRoot=current.parse(text);
  for(const name of ['extractConcepts','extractConceptContexts','extractFacts'])assert.deepEqual(plain(current[name](newRoot)),plain(previous[name](oldRoot)),name+' '+file);
 }
 for(const value of [null,undefined,{}, {name:'other',children:[]}])for(const name of ['extractConcepts','extractConceptContexts','extractFacts'])assert.deepEqual(plain(current[name](value)),plain(previous[name](value)));
});
test('seed evaluation rejects a missing record reader prerequisite',()=>{
 assert.throws(()=>api(read('js/seed_loader.js'),false),/formalAiSeedRecordReaders/u);
});
''')
 run('regression-before',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)],(1,))
 start=source.index('  function extractConcepts(root) {');end=source.index('  // Mirrors ProjectStatement::parse:',start);body=source[start:end]
 assert body.count('  function extract')==3
 factory='''// Whole record readers shared by the browser, worker and Node hosts.
// Dependencies stay in the seed loader; this factory owns no parser cache.
const formalAiSeedRecordReaders = (function () {
  "use strict";
  return function (findChildren, findChildValue, splitRefList, splitList, toLower) {
'''+body+'''    return { extractConcepts: extractConcepts,
      extractConceptContexts: extractConceptContexts, extractFacts: extractFacts };
  };
})();
'''
 facade='''  var recordReaders = formalAiSeedRecordReaders(findChildren, findChildValue, splitRefList, splitList, toLower);
  var extractConcepts = recordReaders.extractConcepts;
  var extractConceptContexts = recordReaders.extractConceptContexts;
  var extractFacts = recordReaders.extractFacts;
'''
 changed=source[:start]+facade+source[end:];assert changed.replace(facade,body,1)==source
 changed='// @worker-prerequisite js/seed-record-readers.js\n'+changed
 for owner in ['js/seed_loader.js','ts/seed_loader.ts']:
  path=root/owner;preimage=out/'preimages'/owner;preimage.parent.mkdir(parents=True,exist_ok=True);preimage.write_bytes(path.read_bytes());path.write_text(changed)
 for owner in ['js/seed-record-readers.js','ts/seed-record-readers.ts']:
  path=root/owner;assert not path.exists();path.write_text(factory)
 replace('scripts/generate-worker-prerequisites.mjs',"const names = ['js/parser-cache-primordials.js', 'js/seed_loader.js',", "const names = ['js/parser-cache-primordials.js', 'js/seed-record-readers.js', 'js/seed_loader.js',")
 replace('js/worker/formal_ai_worker.js','  loadWorkerAsset("parser-cache-primordials.js");\n','  loadWorkerAsset("parser-cache-primordials.js");\n  loadWorkerAsset("seed-record-readers.js");\n')
 replace('js/app/index.html','    <script src="seed_loader.js?v=__FORMAL_AI_ASSET_VERSION__"></script>','    <script src="seed-record-readers.js?v=__FORMAL_AI_ASSET_VERSION__"></script>\n    <script src="seed_loader.js?v=__FORMAL_AI_ASSET_VERSION__"></script>')
 replace('js/server/worker-host.mjs','  initializeParserBootstrap(context,provenance);\n','  initializeParserBootstrap(context,provenance);\n  loadBrowserScript(context, "js/seed-record-readers.js");\n')
 host=root/'js/server/worker-host.mjs';text=host.read_text();old='const parserMemoSeedIdentity = "4a3b4ef0056d6b191f2b2504189f1e760c419c6ed945e3bb9f022de44d076c4d";';assert text.count(old)==1;host.write_text(text.replace(old,'const parserMemoSeedIdentity = "'+hashlib.sha256(changed.encode()).hexdigest()+'";',1))
 replace('rust/tests/web/shared-lexeme-fields.test.mjs',"vm.runInNewContext(readFileSync(path.join(root,'js/seed_loader.js'),'utf8'),context);","vm.runInNewContext(readFileSync(path.join(root,'js/seed-record-readers.js'),'utf8'),context);\nvm.runInNewContext(readFileSync(path.join(root,'js/seed_loader.js'),'utf8'),context);")
 replace('rust/tests/web/esm-parser-bootstrap.test.mjs',"['parser-cache-primordials.js','seed_loader.js','worker/one.js']","['parser-cache-primordials.js','seed-record-readers.js','seed_loader.js','worker/one.js']")
 replace('scripts/ci-pull-request-admission.mjs',"'js/parser-cache-primordials.js', 'js/seed_loader.js',","'js/parser-cache-primordials.js', 'js/seed-record-readers.js', 'js/seed_loader.js',")
 issue=root/'rust/tests/web/issue-1580-template-observations.test.mjs';text=issue.read_text();issue.write_text(text+"\nimport '../../../experiments/issue-1580/seed-record-readers.test.mjs';\n")
 (out/'conservation.json').write_text(json.dumps({'completeOriginalFunctionsAndCommentsConserved':True,'exactInverseBeforeAddingDependencyDeclaration':True,'dependencyParameters':['findChildren','findChildValue','splitRefList','splitList','toLower'],'previousLoaderSha256':hashlib.sha256(source.encode()).hexdigest(),'currentLoaderSha256':hashlib.sha256(changed.encode()).hexdigest(),'bodySha256':hashlib.sha256(body.encode()).hexdigest(),'parserBootstrapUnchanged':True,'independentAuthorshipCredit':0},indent=2)+'\n')
 run('generate-prerequisites',['node','--max-old-space-size=256','scripts/generate-worker-prerequisites.mjs','--write'])
 run('prerequisites-currency',['node','--max-old-space-size=256','scripts/generate-worker-prerequisites.mjs'])
 run('regression-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)])
 for owner in ['worker-script-prerequisites','worker-bootstrap','shared-lexeme-fields','esm-parser-bootstrap','browser-seed-byte-roundtrip','browser-modules','meta-program-transition-cache','three-source-roots-layout']:
  run(owner,['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+owner+'.test.mjs'])
 run('projection-currency',['node','--max-old-space-size=256','scripts/translate-js-rust.mjs','--verify'])
 run('source-warnings',['node','--max-old-space-size=256','scripts/check-file-size.mjs']);warnings=(out/'source-warnings.stdout').read_text().count('::warning file=');assert warnings==11,warnings
 run('whitespace',['git','diff','--check']);(out/'outcome.json').write_text(json.dumps({'complete':True,'warnings':warnings,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
