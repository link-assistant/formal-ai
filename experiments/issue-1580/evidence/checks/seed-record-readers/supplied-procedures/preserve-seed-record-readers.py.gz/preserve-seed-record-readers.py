from pathlib import Path
import gzip,hashlib,json,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'seed-record-reader-preservation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 assert r.returncode==0,(name,r.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 final=json.loads((scratch/'final-status-render-correction/outcome.json').read_text());assert final['complete'] and final['maintainedIssueTestsPassed']==301
 target=root/'experiments/issue-1580/evidence/checks/seed-record-readers';assert (target/'previous-loader.js.gz').exists();records=[]
 def archive(source,relative):
  raw=source.read_bytes();packed=gzip.compress(raw,mtime=0);dest=target/relative;assert not dest.exists(),relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed)
  records.append({'file':relative,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
 for name in ['seed-record-reader-extraction','seed-record-reader-continuation','seed-record-reader-validation','final-gate-integration-repair','final-gate-integration-continuation','final-gate-integration-completion','final-gate-integration-resumed','final-status-render-correction','current-delivery-observations','published-warning-review']:
  directory=scratch/name
  for file in sorted(directory.rglob('*')):
   if file.is_file() and file.name!='pid.json':archive(file,name+'/'+str(file.relative_to(directory))+'.gz')
 helpers=['extract-seed-record-readers.py','finish-seed-record-readers.py','run-frozen-recovery.mjs','validate-seed-record-readers.py','repair-final-gate-integration.py','continue-final-gate-integration.py','complete-final-gate-integration.py','resume-final-gate-integration.py','correct-final-status-render.py','refresh-current-delivery-observations.py','review-published-warnings.py',Path(__file__).name]
 for name in helpers:archive(scratch/name,'supplied-procedures/'+name+'.gz')
 for name in ['finish-seed-record-readers-driver.log','frozen-seed-reader-recovery-driver.log','current-status-driver.log']:
  archive(scratch/name,'driver-attempts/'+name+'.gz')
 for file in sorted((root/'experiments/issue-1580/evidence/commands').glob('2026-11-21T18-*.json')):
  d=json.loads(file.read_text())
  if any(name in str(d) for name in helpers) or 'frozen-seed-reader-recovery' in file.name or 'python3 - <<' in str(d):archive(file,'formal-sessions/'+file.name+'.gz')
 for record in records:
  packed=(target/record['file']).read_bytes();raw=gzip.decompress(packed);assert hashlib.sha256(raw).hexdigest()==record['rawSha256'] and hashlib.sha256(packed).hexdigest()==record['archiveSha256'] and len(raw)==record['bytes'] and len(raw.splitlines())==record['lines']
 (target/'records.jsonl').write_text(''.join(json.dumps(x,separators=(',',':'))+'\n' for x in records));(target/'identity.json').write_text(json.dumps(final,indent=2)+'\n')
 doc=root/'docs/case-studies/issue-1580/seed-record-reader-checkpoint.md';doc.write_text('''# Seed record readers and prerequisite transport

Complete concept, context and fact readers move to a shared lexical factory.
The original bodies and comments have an exact inverse before the prerequisite
declaration is added. Four real seed documents retain every returned field;
missing prerequisite evaluation fails. Both seed loader source warnings disappear
under the unchanged scanner limits. TypeScript projections use the maintained
generator and the actual JavaScript/TypeScript runtime comparison passes.

The first worker replay exposed duplicate lexical initialization. The Node host
now reuses only its private exact-source receipt after constructor initialization.
Worker import failure remains fatal before seed evaluation. Eight affected test
suites and all 301 maintained issue tests pass. The complete local gate inventory
first exposed nine failures: stale recursive statistics accounting and package
mirrors, two loader hashes, eight relocated prose-debt rows, seven moved-source
citations, and the additional prerequisite import in bootstrap accounting.
The reviewed core ledger retains every disposition and line ceiling; the complete
word-problem extraction adds a child while conserving the aggregate line count.
Only the eight conserved allowlist paths move. The worker entry gains one required
import and no solver logic; its reviewed bootstrap census increases by one.
 Official projection and package generators pass. The first integrated replay
 also identifies a stale generated status page after ledger changes; the maintained
 JavaScript renderer regenerates it before a final complete gate replay passes.
The first projection attempt exhausted its 256 MiB worker heap. The retained
retry uses one worker and a 768 MiB heap within the container memory budget;
neither attempt compiles Rust.
The scanner retains 11 warnings and zero violations. No native execution or
visual browser rendering is claimed by these local checks.

The broken current driver could not execute the initial repair request. Recovery
uses the explicitly identified immutable a748854 JavaScript driver against this
working directory; the failed request and complete recovery session are retained.
A later multiline request was refused without effects and receives no credit.
Supplied procedures and recovery receive zero independent authorship credit.
The 20% independent-authorship floor and wider issue acceptance remain unmet.

Evidence: `experiments/issue-1580/evidence/checks/seed-record-readers/`.
PR remains unfinished: https://github.com/link-assistant/formal-ai/pull/1581.
''')
 fragment=root/'changelog.d/20261121_1580_seed_record_readers.md';fragment.write_text('### Changed\n\n- Share complete seed record readers across browser, worker and Node hosts, preserving seed fields and failing missing prerequisites.\n')
 plan=root/'experiments/issue-1580/work-plan.md';text=plan.read_text().replace('latest local replay passes 297 tests','latest local replay passes 301 tests').replace('reduce source warnings to 13 under unchanged limits.','reduce source warnings to 11 under unchanged limits.');plan.write_text(text)
 paths=run('changed',['git','diff','--name-only']).splitlines()+['js/seed-record-readers.js','ts/seed-record-readers.ts','experiments/issue-1580/seed-record-readers.test.mjs',str(target.relative_to(root)),str(doc.relative_to(root)),str(fragment.relative_to(root))]
 assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
 assert not run('staged-before',['git','diff','--cached','--name-only']).strip()
 run('stage',['git','add','--',*paths]);run('staged-whitespace',['git','diff','--cached','--check']);run('staged-secrets',['bash','scripts/check-secrets.sh']);run('commit',['git','commit','-m','Share complete seed readers with verified host prerequisites'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'head':run('head',['git','rev-parse','HEAD']).strip(),'archives':len(records),'pushed':False,'fullIssueComplete':False},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
