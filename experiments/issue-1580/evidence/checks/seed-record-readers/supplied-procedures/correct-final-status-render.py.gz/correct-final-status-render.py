from pathlib import Path
import json,subprocess,sys,time,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'final-status-render-correction'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==0,(name,r.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 prior=scratch/'final-gate-integration-resumed'
 for tick in range(60):
  if (prior/'failed.txt').exists() or (prior/'outcome.json').exists():break
  print(json.dumps({'waitingForPreviousInventory':tick}),flush=True);time.sleep(10)
 else:raise RuntimeError('Previous inventory did not finish within finite observation window')
 before=(prior/'all-gates.stdout').read_text();failures=[line for line in before.splitlines() if line.startswith('FAIL ')]
 assert len(failures)==1 and failures[0].startswith('FAIL check-status-render '),failures
 (out/'previous-status-render-gate.log').write_bytes((root/'experiments/formal_ai_subagent/sandboxes/gates/check-status-render.log').read_bytes())
 run('status-generation',['node','--max-old-space-size=256','scripts/render-status.mjs','--write'])
 run('status-diff',['git','diff','--','docs/status.md','README.md'])
 run('status-currency',['node','--max-old-space-size=256','scripts/render-status.mjs','--check'])
 run('all-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs'])
 lines=(out/'all-gates.stdout').read_text().splitlines();passed=sum(line.startswith('PASS ') for line in lines);skipped=sum(line.startswith('SKIP ') for line in lines);assert passed==88 and skipped==53,(passed,skipped)
 run('whitespace',['git','diff','--check'])
 result={'complete':True,'maintainedIssueTestsPassed':301,'finalLocalGateInventory':{'total':141,'passed':passed,'hostedOnlySkipped':skipped,'failed':0},'sourceWarnings':11,'coreSourceFiles':93,'coreSourceLines':36532,'coreDispositionsAndOutsideCoreCeilingsUnchanged':True,'nativeExecutionVerified':False,'projectionWorkers':1,'projectionHeapMiB':768,'independentAuthorshipCredit':0,'fullIssueComplete':False}
 (out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
