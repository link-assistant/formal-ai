from pathlib import Path
import json,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'seed-record-reader-validation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode in allowed,(name,r.returncode)
try:
 assert json.loads((scratch/'seed-record-reader-continuation/outcome.json').read_text())['complete']
 run('typescript-currency-before',['node','--max-old-space-size=256','scripts/translate-es.mjs','--check'],(1,))
 run('typescript-generation',['node','--max-old-space-size=256','scripts/translate-es.mjs','--write'])
 run('typescript-currency-after',['node','--max-old-space-size=256','scripts/translate-es.mjs','--check'])
 run('intent-new-readers',['git','add','--intent-to-add','js/seed-record-readers.js','ts/seed-record-readers.ts'])
 run('typescript-runtime',['node','--max-old-space-size=256','scripts/check-typescript-runtime.mjs'])
 run('maintained-observations',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])
 run('all-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs'])
 run('whitespace',['git','diff','--check']);assert 'ℹ pass 301' in (out/'maintained-observations.stdout').read_text()
 (out/'outcome.json').write_text(json.dumps({'complete':True,'maintainedIssueTestsPassed':301,'allGatesStatus':0,'warnings':11,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
