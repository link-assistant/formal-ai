from pathlib import Path
code=Path('/tmp/issue-1580-research/continue-final-gate-integration.py').read_text()
code=code.replace("out=scratch/'final-gate-integration-continuation'","out=scratch/'final-gate-integration-completion'")
needle="exec(compile(source,__file__,'exec'))"
assert code.count(needle)==1
code=code.replace(needle,"""
source=source.replace('==112','==111').replace('baseline_lines 112','baseline_lines 111').replace('word_problems.rs 112','word_problems.rs 111').replace('36533','36532').replace('One module boundary adds one net line.','The complete extraction retains the original aggregate line count.')
exec(compile(source,__file__,'exec'))
""",1)
exec(compile(code,__file__,'exec'))
