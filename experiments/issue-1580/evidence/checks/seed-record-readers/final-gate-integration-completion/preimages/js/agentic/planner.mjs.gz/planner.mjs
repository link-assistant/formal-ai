import { fileCommandContract } from './file_command_contract.mjs';
import { planOwnedSourceRepair } from './source_repair.mjs';
import { planRepositoryDocumentation } from './repository_documentation.mjs';
import { planSourceDocumentationStep } from './source_documentation.mjs';
import { planWorkItemBoundaryStep } from './work_item_boundary_candidate.mjs';
import { workItemEvidencePaths } from './work_item_evidence.mjs';
import { planSourceUnaryConsolidationStep } from './source_unary_consolidation.mjs';
import { planSemanticSourcePreflight } from './semantic_source_preflight.mjs';
import { host, hasHost } from './host.mjs';
import { repeatedActionStop } from './repetition_guard.mjs';
import { EventLog } from './crate/event_log.mjs';
import { answerDerivationId, recordFor, toLino } from './crate/derivation.mjs';
import { planSourceMaintenanceStep, ownedSourceMaintenanceRequest } from './source_maintenance.mjs';
import { planGoalLedger, ownsCompleteEditRequest, instructionViewForRequest, pendingReadGap } from './planner/owned_goals.mjs';
import { ownedSemanticAuthoringLead } from './crate/literal_authoring_contract.mjs';
// Deterministic agentic planner: the next tool call or final answer from a
// conversation and its advertised tools, without hidden neural state
// (rust/src/agentic_coding/planner.rs).
//
// Every route arm is the twin of the Rust arm of the same name, run in the
// order data/seed/planner-precedence.lino declares. Arms that consult the
// host solver are async, so the cascade awaits each arm.

import * as algorithmLearning from './algorithm_learning.mjs';
import { Capability } from './capability.mjs';
import * as capabilityRouter from './capability_router.mjs';
import * as changeRequest from './change_request.mjs';
import * as ciWorkflow from './ci_workflow.mjs';
import * as codeArtifact from './code_artifact.mjs';
import * as codeTask from './code_task.mjs';
import * as commandReroute from './command_reroute.mjs';
import { planCodingResearchStep } from './coding_research.mjs';
import * as comparison from './comparison.mjs';
import { programContractAnswer } from './crate/coding_program_contract.mjs';
import { ownedSourceTreeRequest as metaSourceTreeRequest } from './crate/meta_translate.mjs';
import { handlerMatches } from './crate/rule_interpreter.mjs';
import { quoteFault } from './crate/normal_markov.mjs';
import * as testAssertion from './test_assertion.mjs';
import * as replaceList from './replace_list.mjs';
import * as quoteNesting from './quote_nesting.mjs';
import * as requestSequence from './request_sequence.mjs';
import { plannerPrecedence } from './crate/seed.mjs';
import { looksLikeSkillDescription } from './crate/skill_compiler.mjs';
import { computerUsePlanAgenticStep } from './crate/computer_use_planner.mjs';
import { latestUserRequest } from './content.mjs';
import * as conversationRecall from './conversation_recall.mjs';
import * as diagram from './diagram.mjs';
import * as documentRecipe from './document_recipe.mjs';
import * as dreamingAudit from './dreaming_audit.mjs';
import * as evidenceRecord from './evidence_record.mjs';
import * as fileSummary from './file_summary.mjs';
import * as explain from './explain.mjs';
import { fileReadEvidence, fileReadTaskFor, planFileReadStep, readPolicyBlocksPlan } from './file_read.mjs';
import * as formalizationRecipe from './formalization_recipe.mjs';
import * as functionExpectation from './function_expectation.mjs';
import { planGeneralChangeStep } from './general_execution.mjs';
import { composeEditRequest, composeGeneralChangePlan, hasAuthoritativeLiteralWrite, objectiveText } from './general_planner.mjs';
import * as gitCommit from './git_commit.mjs';
import * as googleTrendsCatalog from './google_trends_catalog.mjs';
import * as googleTrendsLearning from './google_trends_learning.mjs';
import * as harnessEnvelope from './harness_envelope.mjs';
import * as intentRouter from './intent_router.mjs';
import * as learningReport from './learning_report.mjs';
import * as ledger from './ledger.mjs';
import * as localSearch from './local_search.mjs';
import * as meaningDetail from './meaning_detail.mjs';
import * as moduleExports from './module_exports.mjs';
import * as moduleFunction from './module_function.mjs';
import * as mutatingAction from './mutating_action.mjs';
import * as noteComposition from './note_composition.mjs';
import { agenticMessage } from './messages.mjs';
import { FinalDisposition, finalAnswer, isToolCalls, jsonText, planOne, projectPlan, resolvedFinalAnswer } from './plan.mjs';
import { continuedAgentTask, isContinuationCue, traceRoute } from './planner/continuation.mjs';
import * as positionalEdit from './positional_edit.mjs';
import * as procedure from './procedure.mjs';
import { planRecovery, recoveryOutput, observedRecoveryCommand, observedDeniedPrerequisiteCommand, withRecoveryReport } from './prerequisite_recovery.mjs';
import { Progress } from './progress.mjs';
import * as questionCatalog from './question_catalog.mjs';
import * as rebuildPlan from './rebuild_plan.mjs';
import * as repairStrategy from './repair_strategy.mjs';
import * as reportIssue from './report_issue.mjs';
import * as restartFeedback from './restart_feedback.mjs';
import * as selfAst from './self_ast.mjs';
import * as selfHeal from './self_heal.mjs';
import * as shellCommand from './shell_command.mjs';
import * as shellFileFallback from './shell_file_fallback.mjs';
import * as sourceLinks from './source_links.mjs';
import * as statementAudit from './statement_audit.mjs';
import * as structuredDocument from './structured_document.mjs';
import * as structuredEdit from './structured_edit.mjs';
import { planSourceCstTransformStep } from './source_cst_transform.mjs';
import * as taskObligations from './task_obligations.mjs';
import { planObligationsStep } from './planner/obligations.mjs';
import * as taskStructure from './task_structure.mjs';
import * as toolResult from './tool_result.mjs';
import * as webResearch from './web_research.mjs';
import { fill } from './work_item_steps.mjs';
import * as workspaceChange from './workspace_change.mjs';
import * as workspaceInspection from './workspace_inspection.mjs';
import * as workspaceSearch from './workspace_search.mjs';
const {
  toolFor
} = capabilityRouter;

/**
 * Mirrors `PLANNER_ROUTE_ARMS` in rust/src/agentic_coding/planner/precedence.rs: the
 * route arms of the cascade, named and in run order.
 */
export const PLANNER_ROUTE_ARMS = [['plan_chat_step_routes', 'conversation-control-decline'], ['plan_chat_step_routes',
         'computer_use'], ['plan_chat_step_routes', 'authoritative-literal-write'], ['plan_chat_step_routes',
         'program_contract'], ['plan_chat_step_routes', 'evidence_record'], ...['git_commit', 'workspace_change',
         'generated-source', 'structured_edit', 'structured_document', 'statement_audit', 'task_obligations',
         'literal-write', 'algorithm_learning', 'procedure', 'learning_report', 'code_artifact', 'self_heal',
         'dreaming_audit', 'self_ast', 'source_links', 'learning_ledger', 'explain', 'change_request', 'repair_strategy',
         'rebuild_plan', 'google_trends_learning', 'google_trends_catalog', 'question_catalog', 'file-analysis',
         'report-flow', 'conversation_recall', 'follow_up_answer', 'contextual_reference_clarification', 'definition-followup',
         'intent-edit', 'typed-file-read', 'local_search', 'comparison', 'named-capability-table', 'shell_command',
         'file_read', 'formalization_recipe', 'meaning_detail', 'diagram', 'workspace_inspection', 'task_structure',
         'capability-table-named-or-local', 'positional-edit-decline', 'web-research-query', 'intent_web_search',
         'code-search-fallback', 'research-continuation', 'latest_turn_answer', 'note_composition', 'general-change-fallback',
         'web-research-final', 'capability-table-open-web'].map(arm => ['plan_settled_routes', arm])];

/**
 * Mirrors `fn checked_route_precedence` in rust/src/agentic_coding/planner/precedence.rs:
 * throws unless planner-precedence.lino names exactly the coded arms in order.
 */
export function checkedRoutePrecedence() {
  const declared = plannerPrecedence();
  if (declared.length !== PLANNER_ROUTE_ARMS.length) {
    throw new Error(agenticMessage('planner_precedence_count', {
      declared: declared.length,
      coded: PLANNER_ROUTE_ARMS.length
    }));
  }
  PLANNER_ROUTE_ARMS.forEach(([fn, name], index) => {
    if (declared[index] !== name) {
      throw new Error(agenticMessage('planner_precedence_order', {
        declared: declared[index],
        function: fn,
        name
      }));
    }
  });
  return declared;
}

/**
 * The workspace_change arm of `fn plan_settled_routes`: a learned
 * workspace-change procedure, or the module-function composition (PR #1188 T1)
 * that is one of them.
 */
async function planWorkspaceChangeArm(task, messages, toolNames) {
  // A copy or move followed by edits of the file it makes is planned sentence
  // by sentence (PR #1188 G82).
  return planSourceUnaryConsolidationStep(task, messages, toolNames) ?? (await planSourceMaintenanceStep(task,
         messages, toolNames)) ?? (await requestSequence.planRequestSequenceStep(task, messages, toolNames, planChatStepResolved)) ?? (await workspaceChange.planWorkspaceChangeStep(task,
         messages, toolNames)) ?? (await planModuleFunctionResearchStep(task, messages, toolNames))
  // A bug report with a stated expectation is checked before anything is
  // rewritten (PR #1188 T93).
  ?? functionExpectation.planFunctionExpectationStep(task, messages, toolNames)
  // An assertion of a stated call and value is added in the test file's own
  // form, and the file is run (PR #1188 G13).
  ?? testAssertion.planTestAssertionStep(task, messages, toolNames)
  // A test asked for with no expected result is a question (PR #1188 G25).
  ?? functionExpectation.planTestExpectationQuestion(task);
}

/** Research runs only after the ordinary source composer returns its exact missing-contract gap. */
async function planModuleFunctionResearchStep(task, messages, toolNames) {
  const existing = await moduleFunction.planModuleFunctionStep(task, messages, toolNames);
  if (!['module-function-request-unconsumed', 'module-function-recipe-missing'].includes(existing?.result?.origin)) return existing;
  return planCodingResearchStep(task, messages, toolNames) ?? existing;
}

/**
 * Mirrors `fn request_fault_answer`: the seeded answer declining a request
 * whose quotes do not pair (PR #1188 G71) or whose edit names several files
 * (G91), or null.
 * @param {string} task
 */
function requestFaultAnswer(task, allowMultipleFiles = false) {
  // Formal query escapes are validated by its own grammar before prose pairing.
  if (codeArtifact.explicitSubstitutionQuery(task) !== null || shellCommand.explicitPassthroughCommand(task) !== null) return null;
  const fault = quoteFault(task) ?? quoteNesting.nestedQuoteFault(task);
  if (fault !== null) {
    const answer = codeTask.renderSeededChange(fault.intent ?? `request_quote_${fault.kind}`, task, '', [['{fragment}', fault.fragment]]);
    return answer === null ? null : finalAnswer(answer);
  }
  // Steps joined by a sequence cue are each checked alone (PR #1188 G99).
  if (requestSequence.sequenceSteps(task) !== null) return null;
  const files = replaceList.severalEditTargets(task);
  if (files !== null && allowMultipleFiles) return null;
  const clause = files === null ? replaceList.unplannedEditClause(task) : null;
  const answer = files !== null ? codeTask.renderSeededListChange('request_several_edit_targets', task, '', '{files}', files) : clause !== null ? codeTask.renderSeededChange('request-edit-clause-unplanned', task, '', [['{clause}', clause]]) : null;
  return answer === null ? null : finalAnswer(answer);
}

/**
 * Mirrors `fn tool_capability` in rust/src/agentic_coding/planner.rs.
 * @param {string} name
 * @returns {string|null}
 */
export function toolCapability(name) {
  return capabilityRouter.classifyTool(name);
}

/**
 * Mirrors `fn plan_chat_step` in rust/src/agentic_coding/planner.rs.
 * @param {Array<object>} messages parsed chat messages
 * @param {Array<string>} toolNames the grounded advertised tool names
 * @returns {Promise<object|null>} an `AgenticPlan` or null
 */
export async function planChatStep(messages, toolNames) {
  const observer = hasHost() ? host().planningObserver?.() : null;
  if (!observer) return projectPlan(await planChatStepResolved(messages, toolNames));
  const events = new EventLog();
  events.append('impulse', latestUserRequest(messages) ?? '');
  try {
    const resolved = await planChatStepResolved(messages, toolNames),
      projected = projectPlan(resolved);
    events.append('agentic:resolved', jsonText(resolved));
    events.append('render:emit', jsonText(projected));
    observer({
      schema: 'formal-ai-planner-observation-v1',
      messages,
      tools: toolNames,
      resolved,
      projected,
      eventLog: events.events,
      derivation: toLino(recordFor(events.events, answerDerivationId(jsonText(projected))))
    });
    return projected;
  } catch (error) {
    events.append('agentic:failed', String(error?.name ?? 'ThrownValue'));
    observer({
      schema: 'formal-ai-planner-failure-v1',
      messages,
      tools: toolNames,
      eventLog: events.events,
      error: {
        name: String(error?.name ?? 'ThrownValue'),
        message: String(error?.message ?? error)
      }
    });
    throw error;
  }
}

/** Internal planner result; recursion retains disposition and origin. */
export async function planChatStepResolved(messages, toolNames) {
  const plan = await planChatStepInner(messages, toolNames);
  if (latestUserRequest(messages) === null) return plan;
  const repeated = repeatedActionStop(messages, isToolCalls(plan) ? plan.calls : null);
  return withRecoveryReport(messages, repeated === null ? plan : resolvedFinalAnswer(repeated, FinalDisposition.Failure, 'repeated_action_budget'));
}

/** Mirrors `fn plan_chat_step_inner` in rust/src/agentic_coding/planner.rs. */
async function planChatStepInner(messages, toolNames) {
  const received = latestUserRequest(messages);
  if (received === null) return null;
  const repeated = repeatedActionStop(messages, []);
  if (repeated !== null) return resolvedFinalAnswer(repeated, FinalDisposition.Failure, 'repeated_action_budget');
  const summary = harnessEnvelope.summarizeRequest(received);
  if (summary !== null) return resolvedFinalAnswer(summary, FinalDisposition.Finding, 'harness_summary');
  const effective = continuedAgentTask(messages, received);
  const restart = await restartFeedback.planRestart(effective ?? received, messages, toolNames);
  const plan = restart ?? (await planChatStepRoutes(messages, toolNames, received));
  if (plan === null || readPolicyBlocksPlan(received, plan)) return null;
  return stopRepeatedFailure(stopRepeatedCall(plan, messages), messages);
}

/** Standing coding progress remains durable; explicit source reads require fresh observations. */
function repetitionProgress(messages) {
  // Only later user requests can create a shorter source-read window.
  if (messages.findLastIndex(message => message.role.toLowerCase() === 'user') <= 0) {
    return Progress.scan(messages);
  }
  const current = fileReadEvidence(messages);
  if (current.length === messages.length) return Progress.scan(messages);
  const request = latestUserRequest(messages) ?? '';
  return Progress.scan(fileReadTaskFor(request) !== null ? current : messages);
}

/** Mirrors `fn stop_repeated_call` in rust/src/agentic_coding/planner/steps.rs. */
function stopRepeatedCall(plan, messages) {
  if (!isToolCalls(plan)) return plan;
  const progress = repetitionProgress(messages);
  for (const call of plan.calls) {
    const attempt = progress.repeatedCall(call);
    if (attempt) {
      return resolvedFinalAnswer(fill('stuck_step_report', [['{step}', `${call.tool} ${call.arguments}`], ['{result}', attempt.detail.trim()]]), FinalDisposition.Gap, 'repeated_call_guard');
    }
  }
  return plan;
}

/** Mirrors `fn stop_repeated_failure` in rust/src/agentic_coding/planner/steps.rs. */
function stopRepeatedFailure(plan, messages) {
  const REPEATED_FAILURES_THAT_STOP = 2;
  if (!isToolCalls(plan)) return plan;
  const progress = repetitionProgress(messages);
  const repeated = plan.calls.find(call => progress.identicalFailuresOf(call.tool) >= REPEATED_FAILURES_THAT_STOP);
  if (!repeated) return plan;
  const failure = progress.latestFailureOfTool(repeated.tool);
  if (!failure) return plan;
  const prompt = latestUserRequest(messages) ?? '';
  return resolvedFinalAnswer(toolResult.renderFailure(repeated.tool, failure.detail, prompt), FinalDisposition.Failure, 'repeated_tool_failure');
}

/** Resolve request ownership before incidental routes or prerequisite gaps. */
function planRequestPreflight(task, messages, toolNames) {
  const fileCommand = fileCommandContract(task);
  if (fileCommand !== null && fileCommand.operation !== 'listing'
    && !(toolFor(toolNames, Capability.Read) !== null && fileReadTaskFor(task) !== null)
    && workspaceSearch.contentSearchFor(task) === null
    && !localSearch.ownsPathDiscovery(task)
    && (fileCommand.operation !== 'search' || capabilityRouter.toolFor(toolNames, Capability.Grep) === null)
) {
    const raw = fileCommand.operation === 'count' ? Progress.scan(messages).latestRunOutputFor(fileCommand.command) : null;
    if (raw !== null) {
      const status = toolResult.reportedExitCode(raw), output = toolResult.normalizedPayload(raw)?.trim();
      if (status === 0 && typeof output === 'string' && /^(?:0|[1-9][0-9]{0,3})$/u.test(output) && Number(output) <= 4096)
        return {claimed:true,plan:resolvedFinalAnswer(output,FinalDisposition.Finding,'file-count-observed')};
      if (status === 0 || status === null) return {claimed:true,plan:resolvedFinalAnswer(jsonText({schema:'file-command-contract/v1',operation:'count',complete:false,verified:false,
        reason:status===null?'FileCountStatusUnavailable':'FileCountOutputUnsupported'}),FinalDisposition.Gap,'file-count-observed')};
    }
    return {
    claimed: true,
    plan: fileCommand.command ? planShellStep(messages, toolNames, fileCommand.command) : resolvedFinalAnswer(jsonText(fileCommand), FinalDisposition.Gap, 'file-command-contract')
    };
  }
  // A declared issue objective and continuation/prerequisite guards share the
  // request boundary: surrounding examples never become independent effects.
  const workItem = composeGeneralChangePlan(task);
  if (workItem?.mode === 'command_output' || workItem?.mode === 'repository_work_item' && task.trimStart().startsWith(workItem.target)) {
    return {
      claimed: true,
      plan: planGeneralChangeStep(messages, toolNames, workItem)
    };
  }
  if (handlerMatches('conversation_control', task) || isContinuationCue(task)) {
    return {
      claimed: true,
      plan: null
    };
  }
  const prerequisiteGap = pendingReadGap(task);
  if (prerequisiteGap !== null) return {
    claimed: true,
    plan: prerequisiteGap
  };
  // Quoted edit payloads are data; their documentation examples grant no new route.
  if (composeEditRequest(task) !== null) return {claimed: false, plan: null};
  const boundary = planWorkItemBoundaryStep(task, messages, toolNames, null, workItemEvidencePaths);
  if (boundary !== null) return {
    claimed: true,
    plan: boundary
  };
  const supportedMaintenance = ownedSourceMaintenanceRequest(task) !== null || functionExpectation.expectationRequest(task) !== null;
  const sourceRepair = supportedMaintenance ? null : planOwnedSourceRepair(task, messages, toolNames);
  if (sourceRepair !== null) return {
    claimed: true,
    plan: sourceRepair
  };
  const repositoryDocumentation = planRepositoryDocumentation(task, messages, toolNames);
  if (repositoryDocumentation !== null) return {
    claimed: true,
    plan: repositoryDocumentation
  };
  const documentation = planSourceDocumentationStep(task, messages, toolNames);
  if (documentation !== null) return {
    claimed: true,
    plan: documentation
  };
  return {
    claimed: false,
    plan: null
  };
}

/** Mirrors `fn plan_chat_step_routes` in rust/src/agentic_coding/planner.rs. */
async function planChatStepRoutes(messages, toolNames, received) {
  checkedRoutePrecedence();
  traceRoute('agentic_received', received);
  const effective = continuedAgentTask(messages, received) ?? received;
  const task = objectiveText(effective);
  traceRoute('agentic_task', task);
  const preflight = planRequestPreflight(task, messages, toolNames);
  if (preflight.claimed) return preflight.plan;
  if (
  // An edit request's block is its payload: a `when … then` inside it is text
  // being written, not a skill being taught (PR #1188 T57).
  !hasAuthoritativeLiteralWrite(task) && composeEditRequest(task) === null && looksLikeSkillDescription(positionalEdit.ownText(task))) {
    return null;
  }
  if (codeTask.verifiedSourceDescription(task) !== null) {
    return planVerifiedSourceStep(task, messages, toolNames);
  }
  const ownedGoals = evidenceRecord.hasTypedEvidenceDelivery(task) || metaSourceTreeRequest(task) !== null || statementAudit.ownedStatementAuditOutput(task) !== null ? null : await planGoalLedger(task, messages, toolNames, planChatStepResolved);
  if (ownedGoals !== null) return ownedGoals;
  // The computer_use arm. Ahead of it, quotes that do not pair leave no
  // telling the quoted text from the instruction, so the request is declined
  // before any arm reads its payload as words to act on (PR #1188 G71).
  const computerUse = requestFaultAnswer(task, toolFor(toolNames, Capability.MultiEdit) !== null) ?? computerUsePlanAgenticStep(messages, toolNames);
  if (computerUse !== null) return computerUse;
  if (hasAuthoritativeLiteralWrite(task) && !ownsCompleteEditRequest(task) && capabilityRouter.workspaceCreationTool(toolNames) !== null) {
    const obligations = taskObligations.obligations(task);
    if (obligations !== null) return await planObligationsStep(task, messages, toolNames, obligations);
    const general = composeGeneralChangePlan(task);
    if (general !== null) return await planGeneralChangeStep(messages, toolNames, general);
  }
  const answer = programContractAnswer(task);
  if (answer !== null) {
    if (answer.execution_recipe && ciWorkflow.requestedIn(task)) ciWorkflow.attach(answer.execution_recipe, task);
    const rerouted = await commandReroute.planSymbolicCommandReroute(messages, toolNames, answer);
    if (rerouted !== null) return rerouted;
  }
  const evidence = await evidenceRecord.planEvidenceRecordStep(task, messages, toolNames);
  if (evidence !== null) return evidence;
  return planSettledRoutes(task, messages, toolNames);
}

/**
 * Mirrors `fn plan_settled_routes` in rust/src/agentic_coding/planner.rs.
 * @returns {Promise<object|null>}
 */
export async function planSettledRoutes(task, messages, toolNames) {
  const explicit = shellCommand.explicitPassthroughCommand(task);
  if (explicit !== null && toolFor(toolNames, Capability.Run) !== null) {
    return (await shellFileFallback.planStep(task, messages, toolNames, explicit)) ?? (await mutatingAction.planStep(explicit, messages, toolNames, task)) ?? planShellStep(messages, toolNames, explicit);
  }
  const sourceTransform = planSourceCstTransformStep(task, messages, toolNames, planShellStep);
  if (sourceTransform !== null) return sourceTransform;
  const verifiedSource = codeTask.planVerifiedGeneratedSourceStep(task, messages, toolNames);
  if (verifiedSource !== null) return verifiedSource;
  for (const arm of [gitCommit.planCommitStep, planWorkspaceChangeArm, codeTask.planGeneratedSourceStep, structuredEdit.planStructuredEditStep, structuredDocument.planStep]) {
    const plan = await arm(instructionViewForRequest(task), messages, toolNames);
    if (plan !== null) return plan;
  }
  if (statementAudit.isStatementAuditTask(task)) {
    return planShellStep(messages, toolNames, statementAudit.commandFor(task));
  }
  if (metaSourceTreeRequest(task) !== null) {
    const step = await conversationRecall.planSharedSolverStep(messages, toolNames);
    if (step.kind === 'ready') return step.plan;
  }
  const shellOwned = shellCommand.semanticShellCommandForTask(task) !== null && composeGeneralChangePlan(task) === null;
  const obligations = capabilityRouter.workspaceCreationTool(toolNames) !== null && !shellOwned && !ownsCompleteEditRequest(task) ? taskObligations.obligations(task) : null;
  if (obligations !== null) {
    return await planObligationsStep(task, messages, toolNames, obligations);
  }
  if (capabilityRouter.workspaceCreationTool(toolNames) !== null && !ownsCompleteEditRequest(task)) {
    const general = composeGeneralChangePlan(task);
    if (general !== null) return await planGeneralChangeStep(messages, toolNames, general);
  }
  const algorithm = algorithmLearning.compileTask(task);
  if (algorithm !== null) return algorithmLearning.planStep(messages, toolNames, algorithm);
  const compiled = procedure.compileTask(task);
  if (compiled !== null) return procedure.planStep(messages, toolNames, compiled);
  const report = learningReport.route(task);
  if (report !== null) return learningReport.planReportStep(report, messages, toolNames);
  const artifact = (await codeArtifact.planCodeArtifactStep(task, messages, toolNames)) ?? (await missingSemanticImplementation(task, messages, toolNames));
  if (artifact !== null) return artifact;
  for (const [predicate, step] of [[selfHeal.isSelfHealTask, documentRecipe.planSelfHealStep], [dreamingAudit.isDreamingAuditTask,
         documentRecipe.planDreamingAuditStep], [selfAst.isSelfAstTask, documentRecipe.planSelfAstStep], [sourceLinks.isSourceLinksTask,
         documentRecipe.planSourceLinksStep], [ledger.isLedgerTask, documentRecipe.planLedgerStep], [explain.isExplainTask,
         documentRecipe.planExplainStep], [changeRequest.isChangeRequestTask, documentRecipe.planChangeRequestStep],
         [repairStrategy.isRepairStrategyTask, documentRecipe.planRepairStrategyStep], [rebuildPlan.isRebuildTask,
         documentRecipe.planRebuildStep], [googleTrendsLearning.isGoogleTrendsLearningTask, documentRecipe.planGoogleTrendsLearningStep],
         [googleTrendsCatalog.isGoogleTrendsCatalogTask, documentRecipe.planGoogleTrendsCatalogStep], [questionCatalog.isQuestionCatalogTask,
         documentRecipe.planQuestionCatalogStep]]) {
    if (predicate(task)) return await step(messages, toolNames);
  }
  // The file-analysis arm. After its typed read, where a name or literal is
  // used inside the workspace is a content search (PR #1188 T90): grep it,
  // ahead of the file-name locate arm and web search.
  const analysis = fileReadTaskFor(task);
  const search = (analysis !== null && analysis.isAnalysis() ? await planFileReadStep(analysis, messages, toolNames) : null) ?? workspaceSearch.planWorkspaceSearchStep(task, messages, toolNames)
  // What a named module exports is answered from its declarations (T99).
  ?? moduleExports.planModuleExportsStep(task, messages, toolNames)
  // A summary of a named file summarizes the file's text (T100).
  ?? (await fileSummary.planFileSummaryStep(task, messages, toolNames));
  if (search !== null) return search;
  const reportFlow = await reportIssue.planReportFlow(messages, toolNames);
  if (reportFlow !== null) return reportFlow;
  const shared = await conversationRecall.planSharedSolverStep(messages, toolNames);
  if (shared.kind === 'ready') return shared.plan;
  if (shared.kind === 'defer') return null;
  return planLaterRoutes(task, messages, toolNames);
}

/** The second half of `plan_settled_routes`, from `follow_up_answer` on. */
async function planLaterRoutes(task, messages, toolNames) {
  const followUp = toolResult.followUpAnswer(messages, task);
  if (followUp !== null) return finalAnswer(followUp);
  const clarification = webResearch.contextualReferenceClarification(task);
  if (clarification !== null) return resolvedFinalAnswer(clarification, FinalDisposition.Clarification, 'contextual_reference_clarification');
  if (webResearch.isDefinitionFollowup(task)) {
    const query = await webResearch.definitionFollowupTopic(messages, task);
    if (query === null) return resolvedFinalAnswer(webResearch.definitionFollowupClarification(task), FinalDisposition.Clarification, 'definition_followup_clarification');
    const plan = await webResearch.planWebResearchStep(messages, toolNames, query, true);
    if (plan !== null) return plan;
  }
  const edit = await intentRouter.planEditStep(task, messages, toolNames);
  if (edit !== null) return edit;
  if (toolFor(toolNames, Capability.Read) !== null) {
    const fileTask = fileReadTaskFor(task);
    if (fileTask !== null) return await planFileReadStep(fileTask, messages, toolNames);
  }
  for (const step of [() => localSearch.planLocalSearchStep(messages, toolNames), () => comparison.planComparisonStep(task, messages, toolNames), () => capabilityRouter.planNamedCapabilityStep(task, messages, toolNames)]) {
    const plan = await step();
    if (plan !== null) return plan;
  }
  // A destructive shell intent read against a request about text inside a
  // file is declined honestly, never composed (PR #1188).
  const refused = shellCommand.refusedDestructiveEdit(task);
  if (refused !== null) {
    const decline = codeTask.renderSeededChange('file_text_unit', task, refused, []);
    if (decline !== null) return resolvedFinalAnswer(decline, FinalDisposition.Gap, 'destructive_edit_declined');
  }
  const deniedCommand = observedDeniedPrerequisiteCommand(messages);
  if (deniedCommand !== null) return planShellStep(messages, toolNames, deniedCommand);
  const command = shellCommand.shellCommandForTask(task) ?? observedRecoveryCommand(messages);
  if (command !== null) {
    const fallback = await shellFileFallback.planStep(task, messages, toolNames, command);
    if (fallback !== null) return fallback;
    const mutating = await mutatingAction.planStep(command, messages, toolNames, task);
    if (mutating !== null) return mutating;
    return planShellStep(messages, toolNames, command);
  }
  const fileTask = fileReadTaskFor(task);
  if (fileTask !== null) return await planFileReadStep(fileTask, messages, toolNames);
  if (formalizationRecipe.isFormalizationTask(task)) {
    return await formalizationRecipe.planFormalizationStep(task, messages, toolNames);
  }
  if (meaningDetail.isMeaningDetailTask(task)) return await documentRecipe.planMeaningDetailStep(task, messages, toolNames);
  if (diagram.isDiagramTask(task)) return await documentRecipe.planDiagramStep(messages, toolNames);
  return planOpenRoutes(task, messages, toolNames);
}

/** The tail of `plan_settled_routes`, from `workspace_inspection` on. */
async function planOpenRoutes(task, messages, toolNames) {
  if (!toolResult.hasLatestTurnResult(messages)) {
    const search = workspaceInspection.workspaceInspectionSearchForTask(task);
    const tool = search === null ? null : toolFor(toolNames, Capability.Grep);
    if (tool !== null) {
      const args = {
        query: search.query,
        pattern: search.pattern
      };
      if (search.include !== null && search.include !== undefined) args.include = search.include;
      return planOne(tool, jsonText(args));
    }
  }
  const structure = await taskStructure.planTaskStructureStep(messages, task);
  if (structure !== null) return structure;
  if (!webResearch.hasSuccessfulSearchResult(messages)) {
    const routed = await capabilityRouter.planRoutedCapabilityStep(task, messages, toolNames, capabilityRouter.RoutingStage.NamedOrLocal);
    if (routed !== null) return routed;
  }
  // An addition that quotes no text earns a question naming what is missing
  // (PR #1188 G69); any other unplanned local edit is declined.
  const unquoted = positionalEdit.unquotedAdditionPath(task);
  if (unquoted !== null || positionalEdit.namesLocalEdit(task)) {
    const question = unquoted === null ? null : codeTask.renderSeededChange('file_addition_unquoted', task, unquoted, []);
    return question === null ? null : resolvedFinalAnswer(question, FinalDisposition.Clarification, 'file_addition_unquoted');
  }
  const researchQuery = await webResearch.webResearchQueryFor(messages);
  if (researchQuery !== null) {
    const plan = await webResearch.planWebResearchStep(messages, toolNames, researchQuery, false);
    if (plan !== null) return plan;
  }
  const webSearch = await intentRouter.planWebSearchStep(task, messages, toolNames);
  if (webSearch !== null) return webSearch;
  if (!toolResult.hasLatestTurnResult(messages)) {
    const query = shellCommand.codeSearchQueryForTask(task);
    const tool = query === null ? null : toolFor(toolNames, Capability.Grep);
    if (tool !== null) return planOne(tool, jsonText({
      query,
      pattern: query
    }));
  }
  if (webResearch.hasSuccessfulSearchResult(messages)) {
    const query = await webResearch.midResearchWebQueryFor(messages);
    if (query !== null) {
      const plan = await webResearch.planWebResearchStep(messages, toolNames, query, false);
      if (plan !== null) return plan;
    }
  }
  const latest = await toolResult.latestTurnAnswer(messages, toolNames, task);
  if (latest !== null) return finalAnswer(latest);
  const note = await noteComposition.planNoteCompositionStep(task, messages);
  if (note !== null) return note;
  const general = composeGeneralChangePlan(task);
  if (general !== null) return await planGeneralChangeStep(messages, toolNames, general);
  const unresolved = await webResearch.unresolvedWebResearchQueryFor(messages);
  if (unresolved !== null) {
    const plan = await webResearch.planWebResearchStep(messages, toolNames, unresolved, false);
    if (plan !== null) return plan;
  }
  return capabilityRouter.planRoutedCapabilityStep(task, messages, toolNames, capabilityRouter.RoutingStage.OpenWeb);
}

/**
 * Mirrors `fn plan_shell_step` in rust/src/agentic_coding/planner.rs.
 * @returns {object} an `AgenticPlan`
 */
export function planShellStep(messages, toolNames, command) {
  const progress = Progress.scan(messages);
  const raw = recoveryOutput(messages, command) ?? progress.latestRunOutputFor(command);
  if (raw !== null) {
    if (toolResult.stepOutcome(raw) === toolResult.StepOutcome.Failed) {
      const recovery = planRecovery(messages, toolNames, command, toolResult.reportedExitCode(raw), raw);
      if (recovery?.kind === 'final') {
        return resolvedFinalAnswer(agenticMessage('shell-recovery-final-failure', {
          failure: toolResult.render(command, raw, latestUserRequest(messages) ?? ''),
          recovery: recovery.answer
        }), FinalDisposition.Failure, 'shell_result_observed');
      }
      if (recovery !== null) return recovery;
    }
    return resolvedFinalAnswer(toolResult.render(command, raw, latestUserRequest(messages) ?? ''), toolResult.stepOutcome(raw) === toolResult.StepOutcome.Failed ? FinalDisposition.Failure : FinalDisposition.Finding, 'shell_result_observed');
  }
  const tool = toolFor(toolNames, Capability.Run);
  if (tool !== null) return planOne(tool, jsonText({
    command
  }));
  return finalAnswer(agenticMessage('shell_tool_missing', {
    command
  }));
}
async function missingSemanticImplementation(task, messages, toolNames) {
  if (ownedSemanticAuthoringLead(task) && shellCommand.semanticShellCommandForTask(task) === null && composeGeneralChangePlan(task) === null && composeEditRequest(task) === null) {
    const verifiedRecipe = await conversationRecall.planVerifiedRecipeStep(messages, toolNames);
    if (verifiedRecipe !== null) return verifiedRecipe;
    const research = planCodingResearchStep(task, messages, toolNames);
    if (research !== null) return research;
    const sourcePreflight = planSemanticSourcePreflight(task, messages, toolNames);
    if (sourcePreflight !== null) return sourcePreflight;
    const discovery = {
      reason: 'MissingContract',
      goal: task,
      authored: false,
      verified: false,
      missingContracts: ['source-bound-implementation-plan', 'independent-goal-validation']
    };
    const plan = resolvedFinalAnswer(agenticMessage('callable-discovery-outcome', {
      reason: discovery.reason,
      discovery: jsonText(discovery)
    }), FinalDisposition.Gap, 'semantic-authoring-missing-contract');
    plan.result.discovery = discovery;
    return plan;
  }
  return null;
}

/** Mirrors plan_verified_source_step: a full source proof gates the existing transaction. */
function planVerifiedSourceStep(task, messages, toolNames) {
  return codeTask.planVerifiedGeneratedSourceStep(task, messages, toolNames) ?? workspaceChange.planWorkspaceChangeStep(task, messages, toolNames);
}
