import fs from 'node:fs';
import assert from 'node:assert/strict';
import {generatedFiles} from './scripts/generate-worker-crate-modules.mjs';
import {translateJsToTs} from './scripts/translate-es.mjs';
for(const [name,text] of generatedFiles()) {
  if(name==='js/worker-modules.js') fs.writeFileSync(name,text);
  else assert.equal(fs.readFileSync(name,'utf8'),text,'unrelated generator drift: '+name);
}
for(const name of ['worker/formal_ai_worker_code_tasks','worker/formal_ai_worker_code_refactoring','worker-modules']) {
  fs.writeFileSync('ts/'+name+'.ts',translateJsToTs(fs.readFileSync('js/'+name+'.js','utf8')));
}
