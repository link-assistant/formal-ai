import os, pathlib, subprocess, time, json, hashlib, shutil
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/worker-warning-validation')
tests=['experiments/issue-1580/worker-notation.test.mjs','experiments/issue-1580/worker-code-tasks.test.mjs','rust/tests/web/worker-module-inventory.test.mjs','rust/tests/web/worker-mirror.test.mjs','rust/tests/web/worker-script-prerequisites.test.mjs','rust/tests/web/worker-quote-parser-cycle.test.mjs','rust/tests/web/issue-1177-code-tasks-parity.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs']
commands=[('test-'+str(i+1),['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',file]) for i,file in enumerate(tests)]
commands += [('typescript-currency',['node','scripts/translate-es.mjs','--check']),('typescript-runtime',['node','scripts/check-typescript-runtime.mjs']),('all-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs'])]
env=os.environ.copy()
env['NODE_OPTIONS']='--max-old-space-size=512'
env['SECRETLINT_VERSION']='14.0.0'
env['PATH']='/tmp/issue-1580-research/secretlint-built-in-migration/dependencies/node_modules/.bin:'+env['PATH']
records=[]
for name,argv in commands:
 started=time.time()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  result=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
 record={'name':name,'argv':argv,'exitCode':result.returncode,'seconds':round(time.time()-started,3)}
 for stream in ['stdout','stderr']:
  data=(out/(name+'.'+stream)).read_bytes()
  record[stream]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 records.append(record)
 (out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 if name=='all-local-gates':
  shutil.copytree(root/'experiments/formal_ai_subagent/sandboxes/gates',out/'gate-logs')
outcome={'allPassed':all(x['exitCode']==0 for x in records),'completedCommands':len(records),'authorshipCredit':0,'fullIssueComplete':False}
(out/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome),flush=True)
