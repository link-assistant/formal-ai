import pathlib, subprocess, json, time, hashlib
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/worker-notation-admission')
prior=pathlib.Path('/tmp/issue-1580-research/worker-notation-validation/outcome.json')
for tick in range(120):
 if prior.exists(): break
 time.sleep(5)
assert prior.exists(),'prior sequential validation did not finish within the finite observation budget'
previous=json.loads(prior.read_text())
argv=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs']
start=time.time()
with (out/'maintained.stdout').open('wb') as stdout,(out/'maintained.stderr').open('wb') as stderr:
 result=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
record={'argv':argv,'exitCode':result.returncode,'seconds':round(time.time()-start,3),'priorAllPassed':previous['allPassed'],'authorshipCredit':0,'fullIssueComplete':False}
for label in ['stdout','stderr']:
 raw=(out/('maintained.'+label)).read_bytes()
 record[label]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(out/'outcome.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
