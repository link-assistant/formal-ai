import pathlib,json,re
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/code-task-warning-sources')
out.mkdir(exist_ok=True)
names=['js/worker/formal_ai_worker_code_tasks.js','js/worker/formal_ai_worker_code_task_support.js','data/meta/worker-line-budget/formal_ai_worker_code_tasks.lino','data/meta/worker-line-budget/formal_ai_worker_code_task_support.lino']
for name in names:
 raw=(root/name).read_bytes()
 (out/(name.replace('/','--')+'.txt')).write_bytes(raw)
 print(json.dumps({'source':name,'bytes':len(raw),'lines':len(raw.splitlines())}))
text=(root/names[0]).read_text()
index=[{'line':n,'declaration':line} for n,line in enumerate(text.splitlines(),1) if re.match(r'^(?:async )?function |^(?:const|let) [A-Z_]+',line)]
(out/'declarations.json').write_text(json.dumps(index,indent=2)+'\n')
