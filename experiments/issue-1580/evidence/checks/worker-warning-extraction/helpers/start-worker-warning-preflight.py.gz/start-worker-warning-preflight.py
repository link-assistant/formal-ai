import json,pathlib,subprocess
out=pathlib.Path('/tmp/issue-1580-research/worker-warning-preflight');out.mkdir(exist_ok=True)
program='''import os,pathlib,subprocess,json,time,hashlib
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/worker-warning-preflight')
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']='/tmp/issue-1580-research/secretlint-built-in-migration/dependencies/node_modules/.bin:'+env['PATH']
gates=['check-abbreviations','check-file-size','check-tests-as-docs','check-tests-as-documentation-javascript-twin','check-status-render','check-generated-files']
commands=[(name,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',name]) for name in gates]
paths=subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=ACMRT','-z'],cwd=root).decode().split('\\0');paths=[path for path in paths if path]
(out/'selection.json').write_text(json.dumps({'files':paths,'total':len(paths),'archives':sum(path.endswith('.gz') for path in paths)},indent=2)+'\\n')
commands += [('secretlint',['bash','scripts/check-secrets.sh',*paths]),('staged-whitespace',['git','diff','--cached','--check'])]
rows=[]
for name,argv in commands:
    started=time.time()
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:run=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'exitCode':run.returncode,'seconds':round(time.time()-started,3)}
    for stream in ['stdout','stderr']:
        data=(out/(name+'.'+stream)).read_bytes();row[stream]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    rows.append(row);(out/'records.json').write_text(json.dumps(rows,indent=2)+'\\n');print(json.dumps(row),flush=True)
(out/'outcome.json').write_text(json.dumps({'completedCommands':len(rows),'allPassed':all(row['exitCode']==0 for row in rows),'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\\n')
'''
(out/'validate.py').write_text(program)
with (out/'worker.log').open('wb') as stream:child=subprocess.Popen(['python3',str(out/'validate.py')],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
(out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(json.dumps({'pid':child.pid,'commands':8,'selection':'staged files including archive contents'}))
