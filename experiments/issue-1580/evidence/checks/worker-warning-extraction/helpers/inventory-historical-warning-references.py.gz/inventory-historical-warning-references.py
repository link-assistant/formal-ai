import pathlib, subprocess, json

root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/historical-warning-references')
out.mkdir(exist_ok=False)
warnings=json.loads(pathlib.Path('/tmp/issue-1580-research/worker-lexicon-split/current-warning-paths.json').read_text())
rows=[]
for relative,lines in warnings:
 if not relative.startswith('experiments/formal_ai_subagent/evidence/'):
  continue
 file=root/relative
 result=subprocess.run(['rg','-n','-F',file.name,'.github','data','scripts','js','ts','rust','docs','experiments','--glob','!**/evidence/**','--glob','!**/sandboxes/**'],cwd=root,capture_output=True)
 name=str(len(rows))
 (out/(name+'.stdout')).write_bytes(result.stdout)
 (out/(name+'.stderr')).write_bytes(result.stderr)
 rows.append({'file':relative,'lines':int(lines),'bytes':file.stat().st_size,'referenceSearchExit':result.returncode,'stdoutBytes':len(result.stdout),'referenceStream':name+'.stdout'})
(out/'inventory.json').write_text(json.dumps(rows,indent=2)+'\n')
for name,argv in {
 'issue':['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','title,body,url,comments'],
 'php-review':['cat','docs/case-studies/issue-1580/templates/php-current-delta-review.json'],
 'candidate-inventories':['rg','--files','docs/case-studies/issue-1580/templates'],
}.items():
 result=subprocess.run(argv,cwd=root,capture_output=True)
 (out/(name+'.stdout')).write_bytes(result.stdout)
 (out/(name+'.stderr')).write_bytes(result.stderr)
 print(json.dumps({'name':name,'exitCode':result.returncode,'bytes':len(result.stdout)}))
print(json.dumps(rows))
