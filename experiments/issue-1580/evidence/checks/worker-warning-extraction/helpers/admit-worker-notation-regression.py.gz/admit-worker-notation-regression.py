import pathlib, subprocess, json, sys
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/worker-notation-admission')
out.mkdir(exist_ok=True)
entry=root/'rust/tests/web/issue-1580-template-observations.test.mjs'
text=entry.read_text()
line="import '../../../experiments/issue-1580/worker-notation.test.mjs';\n"
assert line not in text
text=text.replace('// Keep the content-addressed template reproductions in the maintained JS CI suite.','// Keep content-addressed reproductions and CI warning regressions in the maintained JS CI suite.')
entry.write_text(text+line)
subprocess.run(['git','add','--',str(entry.relative_to(root))],cwd=root,check=True)
worker=r'''import pathlib, subprocess, json, time, hashlib
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/worker-notation-admission')
prior=pathlib.Path('/tmp/issue-1580-research/worker-notation-validation/outcome.json')
for tick in range(120):
 if prior.exists(): break
 time.sleep(5)
assert prior.exists(),'prior sequential validation did not finish within the finite observation budget'
previous=json.loads(prior.read_text())
argv=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs']
start=time.time()
with (out/'maintained.stdout').open('wb') as stdout,(out/'maintained.stderr').open('wb') as stderr:
 result=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
record={'argv':argv,'exitCode':result.returncode,'seconds':round(time.time()-start,3),'priorAllPassed':previous['allPassed'],'authorshipCredit':0,'fullIssueComplete':False}
for label in ['stdout','stderr']:
 raw=(out/('maintained.'+label)).read_bytes()
 record[label]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
(out/'outcome.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
'''
(out/'validate.py').write_text(worker)
with (out/'worker.log').open('wb') as stream:
 process=subprocess.Popen([sys.executable,str(out/'validate.py')],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
(out/'pid.json').write_text(json.dumps({'pid':process.pid})+'\n')
print(json.dumps({'pid':process.pid,'testEntry':str(entry.relative_to(root)),'expectedTests':128,'sequencedAfter':'worker-notation-validation'}))
