import pathlib, subprocess, json
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/buildkit-control-annotation')
out.mkdir(exist_ok=False)
for name,argv in {
 'references':['rg','-n','--glob','!**/evidence/**','--glob','!**/historical/**','canonical registry unavailable|deliberate fallback|Immutable BuildKit|canonical.*outcome|buildx.*fallback','.github','rust/tests/web','scripts','experiments/issue-1580'],
 'ci-current':['gh','run','view','44887270503','--repo','link-assistant/formal-ai','--json','status,conclusion,jobs'],
 'source-changes':['git','diff','--cached','--numstat'],
}.items():
 result=subprocess.run(argv,cwd=root,capture_output=True)
 (out/(name+'.stdout')).write_bytes(result.stdout)
 (out/(name+'.stderr')).write_bytes(result.stderr)
 print(json.dumps({'name':name,'exitCode':result.returncode,'stdoutBytes':len(result.stdout),'stderrBytes':len(result.stderr)}))
