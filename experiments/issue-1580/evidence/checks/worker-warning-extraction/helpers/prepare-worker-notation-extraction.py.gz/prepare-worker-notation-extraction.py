import pathlib, subprocess, json

root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/worker-lexicon-split')
commands={
 'ci-test-owner':['rg','-n','experiments/issue-1580|worker-module-inventory|worker-mirror.test','--glob','*.yml','--glob','*.mjs','.github/workflows','scripts'],
 'gate-list':['node','experiments/formal_ai_subagent/local-gates.mjs','--list'],
 'line-budget':['cat','scripts/check-worker-line-budget.mjs'],
}
for name,argv in commands.items():
 r=subprocess.run(argv,cwd=root,capture_output=True)
 (out/(name+'.stdout')).write_bytes(r.stdout)
 (out/(name+'.stderr')).write_bytes(r.stderr)
 assert r.returncode==0,(name,r.returncode)
 print(name,len(r.stdout),flush=True)
old=root/'rust/tests/web/issue-1580-worker-notation.test.mjs'
new=root/'experiments/issue-1580/worker-notation.test.mjs'
assert old.exists() and not new.exists()
text=old.read_text().replace("from './support/browser-runtime.mjs'","from '../../rust/tests/web/support/browser-runtime.mjs'")
text=text.replace("    'ts/worker/formal_ai_worker_meaning_lexicon.ts',","    'ts/worker/formal_ai_worker_meaning_lexicon.ts',\n    'js/worker/formal_ai_worker_notation.js',\n    'ts/worker/formal_ai_worker_notation.ts',")
new.write_text(text)
old.unlink()
print('Regression moved into the existing automatically collected issue test suite',flush=True)
