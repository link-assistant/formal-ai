import pathlib, subprocess, hashlib, json, re

root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/code-task-warning-sources')
relative='js/worker/formal_ai_worker_code_tasks.js'
source=(root/relative).read_bytes()
assert source==subprocess.check_output(['git','show','84e1ad85:'+relative],cwd=root)
marker=b'// ---------------------------------------------------------------------------\n// code_refactoring\n// ---------------------------------------------------------------------------\n'
assert source.count(marker)==1
offset=source.index(marker)
retained=source[:offset].rstrip(b'\n')+b'\n'
separator=source[len(retained):offset]
refactoring=source[offset:]
assert retained+separator+refactoring==source
assert retained.count(b'\n')<=1400 and refactoring.count(b'\n')<=1400
target=root/'js/worker/formal_ai_worker_code_refactoring.js'
assert not target.exists()
(out/'code-tasks-before.js').write_bytes(source)
(root/relative).write_bytes(retained)
target.write_bytes(refactoring)
budget=root/'data/meta/worker-line-budget/formal_ai_worker_code_tasks.lino'
old=budget.read_text()
assert re.search(r'^  ceiling 1417$',old,re.M)
budget.write_text(re.sub(r'^  ceiling 1417$', '  ceiling '+str(retained.count(b'\n')),old,flags=re.M))
(root/'data/meta/worker-line-budget/formal_ai_worker_code_refactoring.lino').write_text('worker_module_budget\n  module "formal_ai_worker_code_refactoring.js"\n  ceiling '+str(refactoring.count(b'\n'))+'\n  rationale "Existing promise-chain parser, rendering, bounded recording-stub checks and refactoring handlers extracted unchanged from code tasks; the combined ceiling does not grow."\n')
generator="""import fs from 'node:fs';
import assert from 'node:assert/strict';
import {generatedFiles} from './scripts/generate-worker-crate-modules.mjs';
import {translateJsToTs} from './scripts/translate-es.mjs';
for(const [name,text] of generatedFiles()) {
  if(name==='js/worker-modules.js') fs.writeFileSync(name,text);
  else assert.equal(fs.readFileSync(name,'utf8'),text,'unrelated generator drift: '+name);
}
for(const name of ['worker/formal_ai_worker_code_tasks','worker/formal_ai_worker_code_refactoring','worker-modules']) {
  fs.writeFileSync('ts/'+name+'.ts',translateJsToTs(fs.readFileSync('js/'+name+'.js','utf8')));
}
"""
(out/'regenerate-owned-mirrors.mjs').write_text(generator)
for name,argv in [('regenerate',['node','--max-old-space-size=256','--input-type=module','-e',generator]),('render-status',['node','scripts/render-status.mjs','--write'])]:
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  result=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
 assert result.returncode==0,name
entry=root/'rust/tests/web/issue-1580-template-observations.test.mjs'
text=entry.read_text()
needle="import '../../../experiments/issue-1580/worker-notation.test.mjs';"
assert text.count(needle)==1
entry.write_text(text.replace(needle,needle+"\nimport '../../../experiments/issue-1580/worker-code-tasks.test.mjs';"))
with (root/'experiments/issue-1580/work-plan.md').open('a') as stream:
 stream.write('\n### Code-task file-size warning repair, 2026-11-21\n\nThe unchanged size gate also warns on both 1417-line code-task twins. The new focused test reproduces that warning while the original success/rejection/refusal behavior passes. Extract the complete existing refactoring section unchanged, regenerate the canonical module inventory and TypeScript twins, partition the existing ceiling without growth, admit the regression through the maintained CI entry, and refresh the generated status inventory. Recheck all affected tests and the complete JavaScript gates before publication. Supplied edits and commands retain zero independent-authorship credit. Full issue acceptance remains unfinished.\n')
result={'preimageCommit':'84e1ad85fc70541ae64c59a8518dbce59b883e64','preimageSha256':hashlib.sha256(source).hexdigest(),'retainedLines':retained.count(b'\n'),'extractedLines':refactoring.count(b'\n'),'separatorHex':separator.hex(),'combinedCeilingBefore':1417,'combinedCeilingAfter':retained.count(b'\n')+refactoring.count(b'\n'),'exactInverse':retained+separator+refactoring==source,'newModule':'js/worker/formal_ai_worker_code_refactoring.js','authorshipCredit':0,'verificationPending':True}
(out/'extraction.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
for name,argv in [('correct-pipeline-jobs',['gh','api','repos/link-assistant/formal-ai/actions/runs/44887270503/jobs','--paginate'])]:
 result=subprocess.run(argv,cwd=root,capture_output=True)
 (out/(name+'.stdout')).write_bytes(result.stdout)
 (out/(name+'.stderr')).write_bytes(result.stderr)
 print(json.dumps({'name':name,'exitCode':result.returncode,'stdoutBytes':len(result.stdout),'stderrBytes':len(result.stderr)}))
