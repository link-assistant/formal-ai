import gzip,hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');scratch=pathlib.Path('/tmp/issue-1580-research')
target=root/'experiments/issue-1580/evidence/checks/worker-warning-extraction'
initial=scratch/'worker-warning-preflight';assert (initial/'outcome.json').exists()
rows=[json.loads(line) for line in (target/'records.jsonl').read_text().splitlines()]
renames={}
for row in rows:
    old=row['file'];new=old.replace('/pr-conversation.','/pull-request-conversation.').replace('/draft-stat.','/draft-difference-statistics.')
    if old!=new:
        assert not (target/new).exists();(target/old).rename(target/new);row['file']=new;renames[old]=new
assert len(renames)==4
out=scratch/'worker-warning-corrected-preflight';out.mkdir(exist_ok=True)
(out/'renames.json').write_text(json.dumps(renames,indent=2)+'\n')
def retain(path,alias):
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);destination=target/(alias+'.gz');destination.parent.mkdir(exist_ok=True,parents=True);assert not destination.exists();destination.write_bytes(packed)
    rows.append({'source':str(path),'file':alias+'.gz','bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
for path in sorted(initial.iterdir()):
    if path.is_file():retain(path,'initial-preflight/'+path.name)
for name in ['seal-worker-warning-extraction-corrected.log','start-worker-warning-preflight.py','start-worker-warning-preflight.log','inspect-worker-warning-naming-failure.py','inspect-worker-warning-naming-failure.log','correct-worker-evidence-names.py']:
    retain(scratch/name,'helpers/'+name)
retain(out/'renames.json','corrected-preflight/renames.json')
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in rows))
summary=json.loads((target/'summary.json').read_text());summary['retainedRecords']=len(rows);summary['initialPostArchiveNamingFailure']={'observed':94,'ceiling':90,'renamedArchivePaths':4,'ceilingChanged':False};(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
doc=root/'docs/case-studies/issue-1580/worker-warning-extraction-checkpoint.md'
with doc.open('a') as stream:stream.write('\nThe post-archive naming check rejected four abbreviated evidence filenames.\nTheir full-word renames preserve the original source paths, bytes and hashes;\nthe failed 94-versus-90 observation remains retained. The ratchet is unchanged.\n')
for row in rows:
    packed=(target/row['file']).read_bytes();raw=gzip.decompress(packed)
    assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['rawSha256'] and hashlib.sha256(packed).hexdigest()==row['archiveSha256']
subprocess.run(['git','add','--',str(target.relative_to(root)),str(doc.relative_to(root))],cwd=root,check=True)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']='/tmp/issue-1580-research/secretlint-built-in-migration/dependencies/node_modules/.bin:'+env['PATH']
commands=[(name,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',name]) for name in ['check-abbreviations','check-file-size','check-tests-as-docs']]
paths=[path for path in subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=ACMRT','-z'],cwd=root).decode().split('\0') if path]
(out/'selection.json').write_text(json.dumps({'files':len(paths),'archives':sum(path.endswith('.gz') for path in paths)})+'\n')
commands += [('secretlint',['bash','scripts/check-secrets.sh',*paths]),('staged-whitespace',['git','diff','--cached','--check'])]
results=[]
for name,argv in commands:
    started=time.time()
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:run=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
    results.append({'name':name,'exitCode':run.returncode,'seconds':round(time.time()-started,3)})
(out/'outcome.json').write_text(json.dumps({'allPassed':all(row['exitCode']==0 for row in results),'commands':results,'allArchiveHashesVerified':True,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print((out/'outcome.json').read_text())
assert all(row['exitCode']==0 for row in results)
