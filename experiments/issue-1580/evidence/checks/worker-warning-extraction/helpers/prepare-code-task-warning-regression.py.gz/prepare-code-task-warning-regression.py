import pathlib, subprocess, json

root = pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out = pathlib.Path('/tmp/issue-1580-research/code-task-warning-sources')
commands = {
 'existing-tests': ['rg', '-n', '--glob', '*.test.mjs', 'codeRefactoring|code_refactoring|tryCodeDebugging', 'rust/tests/web'],
 'ci-runs': ['gh', 'run', 'list', '--repo', 'link-assistant/formal-ai', '--branch', 'issue-1580-8d61a32a61e1', '--limit', '5', '--json', 'databaseId,conclusion,createdAt,headSha,status,workflowName'],
 'ci-pipeline': ['gh', 'api', 'repos/link-assistant/formal-ai/actions/runs/44887270462/jobs', '--paginate'],
 'pr-conversation': ['gh', 'api', 'repos/link-assistant/formal-ai/issues/1581/comments', '--paginate'],
 'issue-comments': ['gh', 'api', 'repos/link-assistant/formal-ai/issues/1580/comments', '--paginate'],
}
for name, argv in commands.items():
 result = subprocess.run(argv, cwd=root, capture_output=True)
 (out/(name+'.stdout')).write_bytes(result.stdout)
 (out/(name+'.stderr')).write_bytes(result.stderr)
 print(json.dumps({'name':name,'exitCode':result.returncode,'stdoutBytes':len(result.stdout),'stderrBytes':len(result.stderr)}))
source = '''// Issue #1580: code-task extraction retains behavior below the size warning.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import test from 'node:test';
import {createWorkerContext, plain, REPO_ROOT} from '../../rust/tests/web/support/browser-runtime.mjs';

test('code-task worker sources preserve file-size headroom', () => {
  for (const file of [
    'js/worker/formal_ai_worker_code_tasks.js',
    'ts/worker/formal_ai_worker_code_tasks.ts',
    'js/worker/formal_ai_worker_code_refactoring.js',
    'ts/worker/formal_ai_worker_code_refactoring.ts',
  ]) {
    const source = readFileSync(REPO_ROOT + '/' + file, 'utf8');
    const lines = source.split('\\n').length - Number(source.endsWith('\\n'));
    assert.ok(lines <= 1400, file + ' has ' + lines + ' lines; warning threshold is 1400');
  }
});

test('extracted code-refactoring handlers preserve success, rejection and refusal in either load order', () => {
  for (const reverse of [false, true]) {
    const worker = createWorkerContext({}, reverse ? {reorderModules: modules => modules.reverse()} : {});
    const original = 'fetchData().then(data => process(data)).then(result => display(result)).catch(error => report(error));';
    const chain = worker.codeRefactoringParseChain(original);
    assert.equal(chain.thens.length, 2);
    const check = plain(worker.codeRefactoringExecutionCheck(original, chain));
    assert.equal(check.status, 'matched');
    assert.equal(check.scenarios, 4);
    assert.equal(check.calls, 3);
    assert.match(check.detail, /fetchData.*process.*display/);
    const rejected = plain(worker.codeRefactoringTraceRun(original, 1));
    assert.equal(rejected.length, 2);
    assert.match(rejected[1], /^report\\(error</);
    assert.equal(worker.codeRefactoringParseChain('print(1)'), null);
    const loop = worker.codeRefactoringParseChain('fetchData().then(data => { while (true) {} });');
    assert.equal(worker.codeRefactoringExecutionCheck(original, loop).status, 'skipped');
    assert.equal(worker.tryCodeRefactoring('unrelated question'), null);
  }
});
'''
path = root/'experiments/issue-1580/worker-code-tasks.test.mjs'
path.write_text(source)
with (out/'before-regression.stdout').open('wb') as stdout, (out/'before-regression.stderr').open('wb') as stderr:
 result = subprocess.run(['node','--max-old-space-size=256','--test','--test-concurrency=1',str(path)],cwd=root,stdout=stdout,stderr=stderr)
(out/'before-regression.json').write_text(json.dumps({'exitCode':result.returncode,'expectedSizeFailure':True,'authorshipCredit':0})+'\n')
assert result.returncode != 0
print(json.dumps({'beforeRegressionExitCode':result.returncode}))
