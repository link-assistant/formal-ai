import pathlib,subprocess
out=pathlib.Path('/tmp/issue-1580-research/worker-warning-preflight')
(out/'initial-naming-failure.log').write_bytes(pathlib.Path('experiments/formal_ai_subagent/sandboxes/gates/check-abbreviations.log').read_bytes())
run=subprocess.run(['node','scripts/measure-abbreviations.mjs','--list','file-names'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(out/'naming-inventory.stdout').write_bytes(run.stdout);(out/'naming-inventory.stderr').write_bytes(run.stderr)
print('exitCode',run.returncode)
for line in run.stdout.decode().splitlines():
    if 'worker-warning-extraction' in line:print(line)
