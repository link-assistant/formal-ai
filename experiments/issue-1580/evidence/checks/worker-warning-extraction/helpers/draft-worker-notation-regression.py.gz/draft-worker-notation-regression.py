import pathlib, subprocess, json

root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/worker-lexicon-split')
test=root/'rust/tests/web/issue-1580-worker-notation.test.mjs'
assert not test.exists()
test.write_text(r"""// Issue #1580: keep worker notation sources below the warning threshold.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import test from 'node:test';
import {createWorkerContext, plain, REPO_ROOT} from './support/browser-runtime.mjs';

test('worker notation sources preserve file-size headroom', () => {
  for (const file of [
    'js/worker/formal_ai_worker_meaning_lexicon.js',
    'ts/worker/formal_ai_worker_meaning_lexicon.ts',
  ]) {
    const source = readFileSync(REPO_ROOT + '/' + file, 'utf8');
    const lines = source.split('\n').length - Number(source.endsWith('\n'));
    assert.ok(lines <= 1400, file + ' has ' + lines + ' lines; warning threshold is 1400');
  }
});

test('worker notation preserves quoting, tree structure and shared variable bindings in either load order', () => {
  for (const reverse of [false, true]) {
    const worker = createWorkerContext({}, reverse ? {reorderModules: modules => modules.reverse()} : {});
    const tree = plain(worker.parseLinoTree([
      'root',
      '  phrase: "quoted # hash: value" # discarded comment',
      "  single: 'one\\x27two'",
      '  point: codepoints 0x41 66',
    ].join('\n')));
    assert.deepEqual(tree.children[0].children.map(node => [node.name, node.value]), [
      ['phrase', 'quoted # hash: value'], ['single', "one'two"], ['point', 'AB'],
    ]);
    const rule = plain(worker.parseSubstitutionRules([
      'substitution_rules', '  id test', '  rule join', '    order 2',
      '    event update', '    when $left -> $middle',
      '    when $middle -> $right', '    replace $left -> $middle',
      '      with $left -> $right',
    ].join('\n'))).rules[0];
    const links = [{from: 'a', to: 'b'}, {from: 'b', to: 'c'}];
    const bindings = worker.findBindings(links, rule.conditions, 0, {});
    assert.deepEqual(plain(bindings), {left: 'a', middle: 'b', right: 'c'});
    assert.deepEqual(plain(worker.instantiatePattern(rule.actions[0].add[0], bindings)), {from: 'a', to: 'c'});
    assert.equal(worker.findBindings([{from: 'a', to: 'b'}, {from: 'd', to: 'c'}], rule.conditions, 0, {}), null);
    assert.equal(worker.instantiatePattern(worker.parseLinkPattern('$missing -> c'), {}), null);
    assert.throws(() => worker.parseLinkPattern('missing arrow'), /expected/);
    assert.throws(() => worker.parseCrudEvent('unsupported'), /invalid CRUD event/);
  }
});
""")
argv=['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test.relative_to(root))]
with (out/'before-regression.stdout').open('wb') as stdout,(out/'before-regression.stderr').open('wb') as stderr:
 r=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
result={'argv':argv,'exitCode':r.returncode,'expectedFailure':'meaning lexicon exceeds the unchanged 1400-line warning threshold','authorshipCredit':0}
(out/'before-regression.json').write_text(json.dumps(result,indent=2)+'\n')
assert r.returncode!=0, 'Regression must reproduce the existing warning'
print(json.dumps(result))
