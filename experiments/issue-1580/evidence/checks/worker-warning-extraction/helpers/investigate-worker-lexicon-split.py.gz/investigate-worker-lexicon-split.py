import pathlib, subprocess

root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/worker-lexicon-split')
out.mkdir(exist_ok=True)
commands={
 'references':['rg','-n','formal_ai_worker_meaning_lexicon|formal_ai_worker_code_tasks','--glob','!*.gz','--glob','!*.json','--glob','!**/evidence/**','scripts','js','ts','experiments','rust','.github'],
 'generation':['rg','-n',r'js/worker|ts/worker|copy.*\.ts|\.replace.*\.ts|JS_TO_TS|generate.*mirror|typescript.*mirror','scripts','experiments','--glob','*.mjs','--glob','!**/evidence/**'],
 'worker':['sed','-n','1,220p','js/worker/formal_ai_worker.js'],
 'contributing':['sed','-n','1,250p','CONTRIBUTING.md'],
 'test-files':['rg','--files','experiments','scripts','rust/tests/web','--glob','*lino*','--glob','*substitution*','--glob','*worker*test*','--glob','!**/evidence/**'],
 'status':['git','status','--short'],
}
for name,argv in commands.items():
 r=subprocess.run(argv,cwd=root,capture_output=True)
 (out/(name+'.stdout')).write_bytes(r.stdout)
 (out/(name+'.stderr')).write_bytes(r.stderr)
 print(name,r.returncode,len(r.stdout),flush=True)
