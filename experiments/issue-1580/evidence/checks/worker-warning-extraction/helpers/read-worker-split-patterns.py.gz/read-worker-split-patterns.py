import pathlib, subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/worker-lexicon-split')
files=['js/worker-modules.js','scripts/normalize-ordered-lists.mjs','scripts/translate-es.mjs','scripts/check-typescript-runtime.mjs','rust/tests/web/worker-module-inventory.test.mjs','rust/tests/web/worker-mirror.test.mjs','rust/tests/web/worker-quote-parser-cycle.test.mjs','rust/tests/web/issue-1580-algebra-substitution.test.mjs','rust/tests/web/worker-script-prerequisites.test.mjs','rust/tests/web/harness.mjs','scripts/check-worker-line-budget.mjs','experiments/formal_ai_subagent/local-gates.mjs']
for name in files:
 p=root/name
 dest=out/(name.replace('/','--')+'.txt')
 if p.exists():
  dest.write_bytes(p.read_bytes())
  print(name,len(p.read_bytes().splitlines()),flush=True)
 else: print('MISSING',name,flush=True)
r=subprocess.run(['rg','-n','worker-module|worker.*mirror|typescript|worker-line|worker.*prerequisite','data/benchmarks/fast-pull-request-javascript-tests.json'],cwd=root,capture_output=True)
(out/'inventory-test-entries.stdout').write_bytes(r.stdout)
assert r.returncode==0
