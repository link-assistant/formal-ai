import gzip, hashlib, json, pathlib, re, subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
scratch=pathlib.Path('/tmp/issue-1580-research')
validation=scratch/'worker-warning-validation'
outcome=json.loads((validation/'outcome.json').read_text())
assert outcome['allPassed'] and outcome['completedCommands']==11
records=json.loads((validation/'records.json').read_text())
assert all(row['exitCode']==0 for row in records)
gates=(validation/'all-local-gates.stdout').read_text()
assert '141/141 passed or skipped' in gates, gates[-700:]
gate_log=(validation/'gate-logs/check-file-size.log').read_text()
warnings=re.findall(r'^::warning file=([^:]+)::',gate_log,re.M)
assert len(warnings)==87 and len(set(warnings))==87,len(warnings)
removed=['js/worker/formal_ai_worker_meaning_lexicon.js','ts/worker/formal_ai_worker_meaning_lexicon.ts','js/worker/formal_ai_worker_code_tasks.js','ts/worker/formal_ai_worker_code_tasks.ts']
assert not any(path in warnings for path in removed)
assert 'All checked files are within their line limits' in gate_log
assert re.search(r'(?m)^[^\n]*tests 130$',(validation/'test-8.stdout').read_text())
before_head='84e1ad85fc70541ae64c59a8518dbce59b883e64'
extractions=[]
for old,new,separator,budget in [('formal_ai_worker_meaning_lexicon','formal_ai_worker_notation',b'\n',1460),('formal_ai_worker_code_tasks','formal_ai_worker_code_refactoring',b'\n',1417)]:
    old_path='js/worker/'+old+'.js';new_path='js/worker/'+new+'.js'
    before=subprocess.run(['git','show',before_head+':'+old_path],cwd=root,stdout=subprocess.PIPE,check=True).stdout
    retained=(root/old_path).read_bytes();extracted=(root/new_path).read_bytes()
    assert retained+separator+extracted==before
    lines=[len(value.splitlines()) for value in [before,retained,extracted]]
    assert sum(lines[1:])<=budget and max(lines[1:])<=1400
    extractions.append({'beforePath':old_path,'afterPaths':[old_path,new_path],'beforeHead':before_head,'beforeSha256':hashlib.sha256(before).hexdigest(),'beforeLines':lines[0],'afterLines':lines[1:],'separatorHex':separator.hex(),'exactInverse':True,'combinedCeilingBefore':budget,'combinedCeilingAfter':sum(lines[1:])})
summary={'publishedHead':before_head,'suppliedImplementation':True,'independentAuthorshipCredit':0,'extraWarningsRemoved':4,'remainingWarnings':87,'sizeViolations':0,'ordinaryLimit':1500,'rustLimit':1000,'ordinaryWarningThreshold':1400,'rustWarningThreshold':900,'maintainedTestsPassed':130,'focusedTestsPassed':45,'typescriptFilesCurrent':731,'allLocalGates':{'passed':sum(line.startswith('PASS ') for line in gates.splitlines()),'skipped':sum(line.startswith('SKIP ') for line in gates.splitlines()),'failed':sum(line.startswith('FAIL ') for line in gates.splitlines()),'total':141},'localRustBuildPerformed':False,'fullIssueComplete':False,'extractions':extractions,'warnings':warnings}
target=root/'experiments/issue-1580/evidence/checks/worker-warning-extraction'
target.mkdir(exist_ok=False)
archive_records=[]
def retain(path,alias):
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0)
    destination=target/(alias+'.gz');destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed)
    assert gzip.decompress(packed)==raw
    archive_records.append({'source':str(path),'file':alias+'.gz','bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
directories=['worker-lexicon-split','worker-notation-validation','worker-notation-admission','worker-notation-current-annotations','code-task-warning-sources','worker-warning-validation','buildkit-control-annotation','historical-warning-references','worker-warning-round-review']
for name in directories:
    for path in sorted((scratch/name).rglob('*')):
        if path.is_file():retain(path,name+'/'+str(path.relative_to(scratch/name)))
helpers=['investigate-worker-lexicon-split','read-worker-split-patterns','draft-worker-notation-regression','prepare-worker-notation-extraction','extract-worker-notation','fix-worker-extraction-boundary','start-worker-notation-validation','investigate-maintained-test-admission','admit-worker-notation-regression','start-current-annotation-observation','inspect-worker-notation-checkpoint','read-code-task-warning-sources','prepare-code-task-warning-regression','extract-worker-code-refactoring','start-worker-warning-validation','investigate-buildkit-control-annotation','inventory-historical-warning-references','inspect-worker-warning-round','seal-worker-warning-extraction']
for name in helpers:
    for suffix in ['.py','.log']:
        path=scratch/(name+suffix)
        if path.exists():retain(path,'helpers/'+path.name)
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in archive_records))
summary['retainedRecords']=len(archive_records);summary['allArchiveHashesVerified']=True
(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
doc=root/'docs/case-studies/issue-1580/worker-warning-extraction-checkpoint.md'
doc.write_text('''# Worker source warning extraction

The unchanged size gate warned on the 1460-line meaning-lexicon twins and
1417-line code-task twins. The new focused regressions fail on those original
sources while their behavior controls pass. Extracting the existing notation
and refactoring sections into named modules removes four warnings. The retained
meaning lexicon is 1157 lines and notation is 302; code tasks is 1083 and
refactoring is 333. Each extraction has a verified exact byte inverse against
published source `84e1ad85`, including the removed blank separator. No behavior
or existing handler was removed, and the combined worker ceilings decrease by
one line per pair. The source limits and warning thresholds remain unchanged.

Canonical generation updates both module inventories and TypeScript twins.
The maintained status renderer updates its inventory from 177 to 179 worker
budgets. The initial full-gate pass rejected the stale status projection; that
failure remains retained separately from the final successful run.

All 45 focused tests and all 130 maintained observation-entry tests pass,
including both module loading orders, notation quoting and shared variable
bindings, refactoring success and rejection traces, and refusal controls.
The deliberate loop input is refused before execution. All 731 TypeScript
files match canonical generation, and the existing bounded TypeScript runtime
comparison passes. It does not establish complete native or product WASM
parity. No local Rust build was performed.

The complete 141-entry JavaScript gate run has 88 passes and 53 explicit skips,
with zero failures. The actual size gate reports 87 warnings and no violations.
The four removed warnings do not resolve those other warnings or the full
issue. Full gate streams, before-fix failures, helpers, source identities and
compressed archive hashes are retained in
`experiments/issue-1580/evidence/checks/worker-warning-extraction/`.

The published Workflows run
[44887270329](https://github.com/link-assistant/formal-ai/actions/runs/44887270329)
retains the expected official-action failure annotation from the deliberately
injected canonical BuildKit pull outage; mirror recovery succeeds. Its other
annotation is a macOS runner-capacity notice. Earlier artifact-lookup failure
annotations did not recur in this capture. These observations are preserved
without suppressing genuine setup failures or claiming all annotations fixed.

The implementation and commands were supplied through the actual JavaScript
Formal AI driver and receive zero independent reasoning or authorship credit.
Full template/practice, source-warning, original budget/live qualification,
security child semantics and complete pull-request acceptance remain open.
''')
assert summary['allLocalGates']=={'passed':88,'skipped':53,'failed':0,'total':141},summary['allLocalGates']
plan=root/'experiments/issue-1580/work-plan.md';text=plan.read_text()
start=text.index('Latest published head ',text.index('## Current verification checkpoint'))
end=text.index('\n\nLatest checkpoint:',start)
text=text[:start]+'''Latest published head `84e1ad85` has 25 of 26 normal workflows terminal:
24 success, one skip and no failures observed; Pipeline remains active in the
current capture. No push is permitted until current-head workflows finish.
The local worker extraction passes 45 focused tests, 130 maintained cases,
TypeScript generation/runtime checks and all 141 local gate entries (88 pass,
53 explicit skips). Four source-size warnings are repaired; 87 remain under
unchanged limits. Full template/practice, original budget/live and complete
issue acceptance remain open. See the
[worker extraction checkpoint](../../docs/case-studies/issue-1580/worker-warning-extraction-checkpoint.md).
Earlier checkpoint entries below retain their dated heads and scope.
'''+text[end:]
plan.write_text(text)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--',str(target.relative_to(root)),str(doc.relative_to(root)),str(plan.relative_to(root))],cwd=root,check=True)
print(json.dumps({'records':len(archive_records),'summary':str(target/'summary.json'),'staged':True,'committed':False,'pushed':False,'fullIssueComplete':False}))
