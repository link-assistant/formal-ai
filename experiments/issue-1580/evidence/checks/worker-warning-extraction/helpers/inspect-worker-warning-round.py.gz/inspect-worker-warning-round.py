import json, pathlib, subprocess
root = pathlib.Path('/tmp/issue-1580-research')
out = root / 'worker-warning-round-review'
out.mkdir(exist_ok=True)
queries = {
  'historical-references': ['rg', '-n', '--glob', '!*.gz', '--glob', '!*.lock', 'release-staged.yml.txt|original-release-workflow.yml.txt|project-parity-pre-repair-observations.json|T2415-reconstructed-formatted-statistics.rs|T2415-preimage-web_search_intent.rs|T2415-reconstructed-formatted-web_search_intent.rs|T2415-preimage-statistics.rs|.github_workflows_release.yml.before.txt'],
  'staged-nonmechanical-diff': ['git', 'diff', '--cached', '--', 'changelog.d/issue-1580-worker-warning-extraction.md', 'data/meta/worker-line-budget', 'docs/status.md', 'experiments/issue-1580/work-plan.md', 'experiments/issue-1580/worker-code-tasks.test.mjs', 'experiments/issue-1580/worker-notation.test.mjs', 'js/worker-modules.js', 'ts/worker-modules.ts', 'rust/tests/web/issue-1580-template-observations.test.mjs'],
  'working-diff': ['git', 'diff', '--stat'],
}
rows=[]
for name, argv in queries.items():
    run = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    for stream, data in [('stdout',run.stdout),('stderr',run.stderr)]:
        (out/(name+'.'+stream)).write_bytes(data)
    rows.append({'name':name,'exitCode':run.returncode,'stdoutBytes':len(run.stdout),'stderrBytes':len(run.stderr)})
(out/'outcome.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
