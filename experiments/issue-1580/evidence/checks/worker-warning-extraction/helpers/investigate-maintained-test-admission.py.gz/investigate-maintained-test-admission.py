import pathlib, subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/worker-lexicon-split')
commands={
 'test-admission':['rg','-n',r'experiments/.*test|fast-pull-request-javascript-tests|--test-concurrency|readdirSync.*experiments','.github/workflows','scripts','data/benchmarks/fast-pull-request-javascript-tests.json','--glob','*.mjs','--glob','*.yml','--glob','*.json'],
 'checkpoint-paths':['rg','--files','docs/case-studies/issue-1580','--glob','*php*','--glob','*template*'],
}
for name,argv in commands.items():
 r=subprocess.run(argv,cwd=root,capture_output=True)
 (out/(name+'.stdout')).write_bytes(r.stdout)
 (out/(name+'.stderr')).write_bytes(r.stderr)
 assert r.returncode==0,(name,r.returncode)
 print(name,len(r.stdout))
