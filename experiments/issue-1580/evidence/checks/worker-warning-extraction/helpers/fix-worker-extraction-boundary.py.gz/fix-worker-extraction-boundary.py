import pathlib, subprocess, json, hashlib
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/worker-lexicon-split')
source=root/'js/worker/formal_ai_worker_meaning_lexicon.js'
before=source.read_bytes()
after=before.rstrip(b'\n')+b'\n'
separator=before[len(after):]
assert separator==b'\n'
source.write_bytes(after)
budget=root/'data/meta/worker-line-budget/formal_ai_worker_meaning_lexicon.lino'
text=budget.read_text()
assert text.count('ceiling 1158')==1
budget.write_text(text.replace('ceiling 1158','ceiling 1157'))
code="import fs from 'node:fs';import {translateJsToTs} from './scripts/translate-es.mjs';const p='worker/formal_ai_worker_meaning_lexicon';fs.writeFileSync('ts/'+p+'.ts',translateJsToTs(fs.readFileSync('js/'+p+'.js','utf8')));"
subprocess.run(['node','--max-old-space-size=256','--input-type=module','-e',code],cwd=root,check=True)
record=json.loads((out/'extraction.json').read_text())
notation=(root/'js/worker/formal_ai_worker_notation.js').read_bytes()
assert after+separator+notation==(out/'meaning-lexicon-before.js').read_bytes()
record.update({'retainedLines':after.count(b'\n'),'separatorBytesHex':separator.hex(),'combinedCeilingAfter':after.count(b'\n')+notation.count(b'\n'),'exactInverse':True,'boundaryWhitespaceRepair':'one separating blank line retained in inverse metadata rather than at the shortened file EOF'})
(out/'extraction.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
