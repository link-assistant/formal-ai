import pathlib,re,json,subprocess,hashlib
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/worker-lexicon-split')
log=(root/'experiments/formal_ai_subagent/sandboxes/gates/check-file-size.log').read_text()
warnings=re.findall(r'^WARNING: (.*?) has (\d+) lines',log,re.M)
assert len(warnings)==89,len(warnings)
assert all('formal_ai_worker_meaning_lexicon' not in path for path,_ in warnings)
assert 'All checked files are within their line limits' in log
record={'ordinaryWarnings':len(warnings),'ordinaryViolations':0,'removedWarningPaths':['js/worker/formal_ai_worker_meaning_lexicon.js','ts/worker/formal_ai_worker_meaning_lexicon.ts'],'warningThreshold':1400,'lineLimit':1500,'thresholdsChanged':False,'fullIssueComplete':False}
(out/'warning-summary.json').write_text(json.dumps(record,indent=2)+'\n')
(out/'current-warning-paths.json').write_text(json.dumps(warnings,indent=2)+'\n')
argv=['git','diff','--cached','--stat']
result=subprocess.run(argv,cwd=root,capture_output=True)
(out/'draft-stat.stdout').write_bytes(result.stdout)
(out/'draft-stat.stderr').write_bytes(result.stderr)
assert result.returncode==0
print(json.dumps(record))
