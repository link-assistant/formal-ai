import pathlib, subprocess, hashlib, json, re

root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/worker-lexicon-split')
relative='js/worker/formal_ai_worker_meaning_lexicon.js'
source=(root/relative).read_bytes()
baseline=subprocess.check_output(['git','show','84e1ad85fc70541ae64c59a8518dbce59b883e64:'+relative],cwd=root)
assert source==baseline
marker=b'// --- Substitution engine (mirror of src/substitution.rs) -------------------\n'
assert source.count(marker)==1
offset=source.index(marker)
lexicon,notation=source[:offset],source[offset:]
assert lexicon+notation==source
assert lexicon.count(b'\n')<=1400 and notation.count(b'\n')<=1400
target=root/'js/worker/formal_ai_worker_notation.js'
assert not target.exists()
(out/'meaning-lexicon-before.js').write_bytes(source)
(root/relative).write_bytes(lexicon)
target.write_bytes(notation)

budget=root/'data/meta/worker-line-budget/formal_ai_worker_meaning_lexicon.lino'
old_budget=budget.read_text()
assert re.search(r'^  ceiling 1460$',old_budget,re.M)
budget.write_text(re.sub(r'^  ceiling 1460$', '  ceiling '+str(lexicon.count(b'\n')),old_budget,flags=re.M))
new_budget=root/'data/meta/worker-line-budget/formal_ai_worker_notation.lino'
assert not new_budget.exists()
new_budget.write_text('worker_module_budget\n  module "formal_ai_worker_notation.js"\n  ceiling '+str(notation.count(b'\n'))+'\n  rationale "Links Notation parsing, substitution rule parsing and variable bindings extracted unchanged from the meaning lexicon; the combined ceiling does not grow."\n')

generator=r"""import fs from 'node:fs';
import assert from 'node:assert/strict';
import {generatedFiles} from './scripts/generate-worker-crate-modules.mjs';
import {translateJsToTs} from './scripts/translate-es.mjs';
for(const [name,text] of generatedFiles()) {
  if(name==='js/worker-modules.js') fs.writeFileSync(name,text);
  else assert.equal(fs.readFileSync(name,'utf8'),text,'unrelated generator drift: '+name);
}
for(const name of ['worker/formal_ai_worker_meaning_lexicon','worker/formal_ai_worker_notation','worker-modules']) {
  fs.writeFileSync('ts/'+name+'.ts',translateJsToTs(fs.readFileSync('js/'+name+'.js','utf8')));
}
"""
(out/'regenerate-owned-mirrors.mjs').write_text(generator)
with (out/'regenerate.stdout').open('wb') as stdout,(out/'regenerate.stderr').open('wb') as stderr:
 r=subprocess.run(['node','--max-old-space-size=256','--input-type=module','-e',generator],cwd=root,stdout=stdout,stderr=stderr)
assert r.returncode==0,'regenerate owned mirrors'
plan=root/'experiments/issue-1580/work-plan.md'
with plan.open('a') as stream:
 stream.write('\n### Worker notation file-size warning repair, 2026-11-21\n\nThe unchanged file-size gate reports 1460 lines in each meaning-lexicon twin. A focused regression reproduces that warning before extraction while notation and binding behavior pass. Extract the existing notation/parser/substitution section byte-for-byte into its own named worker module, regenerate the worker inventory and TypeScript twins, and partition the existing worker ceiling without increasing the combined allowance. Verify the regression, both worker loading orders, canonical generation, and the complete JavaScript gate set before the next push. Supplied implementation and commands receive zero independent-authorship credit. This repairs two warnings only; the remaining issue acceptance criteria stay open.\n')
result={'preimageCommit':'84e1ad85fc70541ae64c59a8518dbce59b883e64','preimageSha256':hashlib.sha256(source).hexdigest(),'retainedLines':lexicon.count(b'\n'),'extractedLines':notation.count(b'\n'),'combinedCeilingBefore':1460,'combinedCeilingAfter':lexicon.count(b'\n')+notation.count(b'\n'),'exactInverse':lexicon+notation==source,'newModule':'js/worker/formal_ai_worker_notation.js','authorshipCredit':0,'verificationPending':True}
(out/'extraction.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
