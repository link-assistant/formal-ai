from pathlib import Path
import json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/release-artifact-contracts-validation')
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(json.dumps({'pid':worker.pid,'finite':True}));sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);records=[]
try:
    for name,file in [('native-groups','experiments/issue-1580/native-regression-groups.test.mjs'),('selected-source-wasm','rust/tests/web/selected-source-wasm.test.mjs'),('maintained','rust/tests/web/issue-1580-template-observations.test.mjs')]:
        args=['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',file]
        with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:run=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
        records.append({'name':name,'arguments':args,'exitCode':run.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records[-1]),flush=True);assert run.returncode==0,name
    text=(out/'maintained.stdout').read_text();assert '# pass 153\n# fail 0' in text
    result={'complete':True,'maintainedPassed':153,'nativeBuildRun':False,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0};(out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
