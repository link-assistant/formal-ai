from pathlib import Path
import datetime,hashlib,json,os,re,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'release-artifact-contracts';out.mkdir(exist_ok=False)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);records=[]
def run(name,args):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    records.append({'name':name,'arguments':args,'exitCode':result.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');return result.returncode
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
parent=root/'rust/tests/unit/ci-cd/release_publishing.rs';child=parent.with_suffix('')/'artifact_contracts.rs';test=root/'experiments/issue-1580/native-test-headroom.test.mjs';target=root/'rust/tests/unit/workflow_contracts.rs'
test_source=test.read_text();needle="['workflow_contracts', ['ci-cd/job_budget_fit', 'ci-cd/pinned_tool_images']]";assert test_source.count(needle)==1;test_source=test_source.replace(needle,"['workflow_contracts', ['ci-cd/job_budget_fit', 'ci-cd/pinned_tool_images', 'ci-cd/release_publishing']]")
needle="for (const [owner, child, names] of [\n";assert test_source.count(needle)==1;test_source=test_source.replace(needle,needle+"  ['rust/tests/unit/ci-cd/release_publishing', 'artifact_contracts', [\n    'desktop_linux_artifact_names_are_normalized_for_download_contract',\n    'release_scripts_check_configured_release_artifacts',\n  ]],\n",1);test.write_text(test_source)
args=['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',str(test.relative_to(root))]
assert run('before',args)==1;before=(out/'before.stdout').read_text();assert '# pass 11\n# fail 2' in before
original=parent.read_text();(out/'release_publishing.before.rs').write_text(original);names=['desktop_linux_artifact_names_are_normalized_for_download_contract','release_scripts_check_configured_release_artifacts'];start=original.index('#[test]\nfn '+names[0]+'()');moved=original[start:];assert re.findall(r'#\[test\]\nfn (\w+)\(',moved)==names
child.parent.mkdir(exist_ok=True);prefix='use std::fs;\nuse std::process::Command;\n\n';child.write_text(prefix+moved.replace('#[test]\nfn ','pub(super) fn '))
wrappers='\n\n'.join('#[test]\nfn '+name+'() {\n    artifact_contracts::'+name+'();\n}' for name in names)+'\n';updated=original[:start]+wrappers;needle='mod selected_wasm_build_contract;';assert updated.count(needle)==1;parent.write_text(updated.replace(needle,needle+'\n\nmod artifact_contracts;',1))
target_source=target.read_text();assert 'mod release_publishing;' not in target_source;target.write_text(target_source+'\n// Qualify complete artifact, Pages and release policy assertions on pull requests.\n#[path = "ci-cd/release_publishing.rs"]\nmod release_publishing;\n')
files=[str(path.relative_to(root)) for path in [parent,child,target]]
assert run('format',['rustfmt','--edition','2024','--config','skip_children=true',*files])==0
assert run('format-check',['rustfmt','--edition','2024','--config','skip_children=true','--check',*files])==0
actual=child.read_text();assert actual.startswith(prefix);restored=actual[len(prefix):].replace('pub(super) fn ','#[test]\nfn ');assert restored.rstrip()==moved.rstrip()
old_tests=re.findall(r'#\[test\]\nfn (\w+)\(',original);new_tests=re.findall(r'#\[test\]\nfn (\w+)\(',parent.read_text());assert old_tests==new_tests
assert run('after',args)==0;assert '# pass 13\n# fail 0' in (out/'after.stdout').read_text()
assert run('touched-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size,check-file-size-js-twin'])==0
assert run('whitespace',['git','diff','--check'])==0
gate_log=(root/'experiments/formal_ai_subagent/sandboxes/gates/check-file-size.log').read_text();warnings=len(re.findall(r'^::warning file=',gate_log,re.M));assert warnings==76,warnings
summary={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'parent':files[0],'child':files[1],'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'movedSha256':hashlib.sha256(moved.encode()).hexdigest(),'movedBodiesUnchanged':True,'allOriginalTestNamesPreserved':old_tests,'parentLines':len(parent.read_text().splitlines()),'childLines':len(child.read_text().splitlines()),'before':{'passed':11,'failed':2},'after':{'passed':13,'failed':0},'remainingWarnings':warnings,'completeOwnerAddedToHostedWorkflowTarget':True,'nativeBuildRun':False,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0};assert summary['parentLines']<=900 and summary['childLines']<=900;(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
