from pathlib import Path
import gzip,hashlib,json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');draft=scratch/'release-artifact-contracts';validated=scratch/'release-artifact-contracts-validation';assert json.loads((validated/'outcome.json').read_text())['complete'];summary=json.loads((draft/'summary.json').read_text());assert summary['movedBodiesUnchanged']
target=root/'experiments/issue-1580/evidence/checks/release-artifact-contracts';target.mkdir(exist_ok=False);records=[]
sources=[path for directory in [draft,validated] for path in sorted(directory.iterdir()) if path.is_file()]+[scratch/name for name in ['extract-release-artifact-contracts.py','extract-release-artifact-contracts.log','validate-release-artifact-contracts.py','validate-release-artifact-contracts.log','commit-release-artifact-contracts.py']]
for path in sources:
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);alias=(path.parent.name if path.parent!=scratch else 'helpers')+'/'+path.name+'.gz';destination=target/alias;destination.parent.mkdir(parents=True,exist_ok=True);assert not destination.exists();destination.write_bytes(packed);assert gzip.decompress(packed)==raw;records.append({'source':str(path),'file':alias,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records));(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
note=root/'docs/case-studies/issue-1580/release-artifact-headroom-checkpoint.md';note.write_text('''# Release artifact regression headroom

The maintained scanner catches the 1000-line release-publishing owner. Its two
artifact assertion bodies now live in an explicit child with ordinary imports.
Their original parent test names, order, assertions, fixture bytes, process
behavior and cleanup stay unchanged. The parent has 850 lines, its child 162;
the unchanged repository limits report 76 warnings and no violations.

The complete existing release-publishing owner, including its release-recovery
and selected-WASM-build children, is registered in the hosted workflow contract
target. This adds actual native coverage instead of relying on the JavaScript
source checks. Compilation and native execution still require hosted evidence.

Before extraction/registration, the focused suite has 11 successes and two
expected failures; afterward all 13 cases pass. All 50 native-runner controls,
18 actual selected-source-WASM JavaScript tests, 153 maintained issue cases,
three affected JavaScript gates, Rust 2024 formatting and whitespace checks
pass locally. No Rust build was run. These results do not establish full issue
acceptance or independent Formal AI authorship; supplied work receives zero
independent credit.

Evidence: `experiments/issue-1580/evidence/checks/release-artifact-contracts/`.
''')
fragment=root/'changelog.d/issue-1580-release-artifact-headroom.md';fragment.write_text('''---
bump: patch
---

Keep release-publishing assertions below the existing source warning band while
preserving native test identities and qualifying the complete owner on PRs.
''')
plan=root/'experiments/issue-1580/work-plan.md';text=plan.read_text().replace('Local commits extract nine Rust test/helper groups','Local commits extract ten Rust test/helper groups',1).replace('77 warnings remain after contributor-guide extraction.','76 warnings remain after contributor-guide and release-artifact extraction.',1).replace('Twelve focused headroom/path cases pass.','Thirteen focused headroom/path cases pass.',1);text+='\n- Release artifact extraction preserves all fourteen original native test names and complete assertion bodies, while the full owner joins the hosted workflow target. All 13 headroom controls, 50 native-runner controls, 18 selected-WASM JavaScript cases and 153 maintained issue cases pass; 76 warnings remain. Hosted native compilation/execution remains unfinished. See [release artifact checkpoint](../../docs/case-studies/issue-1580/release-artifact-headroom-checkpoint.md).\n';plan.write_text(text)
files=['rust/tests/unit/ci-cd/release_publishing.rs','rust/tests/unit/ci-cd/release_publishing/artifact_contracts.rs','rust/tests/unit/workflow_contracts.rs','experiments/issue-1580/native-test-headroom.test.mjs',str(target.relative_to(root)),str(note.relative_to(root)),str(fragment.relative_to(root)),str(plan.relative_to(root))];subprocess.run(['git','add','--',*files],cwd=root,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=root).decode().split('\0')[:-1];assert not any('/evidence/ci/' in path for path in staged)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
for name,args in [('final-naming',['node','scripts/measure-abbreviations.mjs','--check']),('final-secrets',['bash','scripts/check-secrets.sh',*staged]),('final-whitespace',['git','diff','--cached','--check'])]:
    with (draft/(name+'.stdout')).open('wb') as stdout,(draft/(name+'.stderr')).open('wb') as stderr:run=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    assert run.returncode==0,name
with (draft/'commit.stdout').open('wb') as stdout,(draft/'commit.stderr').open('wb') as stderr:subprocess.run(['git','-c','gc.auto=0','commit','-m','Qualify complete release artifact contracts and preserve native test names'],cwd=root,stdout=stdout,stderr=stderr,check=True)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root,text=True)
result={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'committed':True,'pushed':False,'records':len(records),'trackedWorkingTreeClean':True,'fullIssueComplete':False};(draft/'commit-outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
