//! Release artifact publishing (crate, Docker, electron) + Pages asset
//! version-stamping / cache-busting assertions. Shared helpers live in
//! `workflow_fixtures`.

use std::fs;
use std::path::PathBuf;
use std::process::Command;

use super::workflow_fixtures::*;

#[path = "release_recovery.rs"]
mod release_recovery;

#[path = "selected_wasm_build_contract.rs"]
mod selected_wasm_build_contract;

fn read_worker_source(manifest_dir: &str) -> String {
    let mut source =
        fs::read_to_string(format!("{manifest_dir}/js/worker/formal_ai_worker.js")).unwrap();
    let worker_dir = PathBuf::from(format!("{manifest_dir}/js/worker"));
    if !worker_dir.exists() {
        return source;
    }

    let mut modules: Vec<PathBuf> = fs::read_dir(&worker_dir)
        .unwrap()
        .map(|entry| entry.unwrap().path())
        .filter(|path| path.extension().and_then(|ext| ext.to_str()) == Some("js"))
        .collect();
    modules.sort();

    for module in modules {
        source.push('\n');
        source.push_str(&fs::read_to_string(module).unwrap());
    }

    source
}

/// The bundled front-end imports JSX and JavaScript modules under `js/app/`;
/// source assertions include the constants module that owns version metadata.
fn read_web_app_source(manifest_dir: &str) -> String {
    let mut modules: Vec<PathBuf> = fs::read_dir(format!("{manifest_dir}/js/app"))
        .unwrap()
        .map(|entry| entry.unwrap().path())
        .filter(|path| {
            matches!(
                path.extension().and_then(|ext| ext.to_str()),
                Some("jsx" | "js" | "mjs")
            )
        })
        .collect();
    modules.sort();

    let mut source = String::new();
    for module in modules {
        source.push_str(&fs::read_to_string(module).unwrap());
        source.push('\n');
    }
    source
}

#[test]
fn github_pages_artifact_advertises_crate_version_from_cargo_toml() {
    // Issue #72: the deployed Pages site advertised `0.16.0` long after the
    // crate moved past it. The fix replaces a hardcoded literal with the
    // `__FORMAL_AI_VERSION__` placeholder and a stamp step that reads the
    // current `Cargo.toml` version during the Pages deploy. Without these
    // pieces the deploy can drift again.
    let manifest_dir = concat!(env!("CARGO_MANIFEST_DIR"), "/..");
    let index_html = fs::read_to_string(format!("{manifest_dir}/js/index.html")).unwrap();
    // Issue #550: app source moved to JSX (bundled by bun into the served
    // app.js); these checks assert source-level code, so read the JSX modules.
    let app_js = read_web_app_source(manifest_dir);
    let stamp_script =
        fs::read_to_string(format!("{manifest_dir}/scripts/stamp-pages-artifact.sh")).unwrap();
    let workflow = pages_artifact_workflow();
    let deploy_demo = job_block(&workflow, "build");

    assert!(
        index_html.contains("__FORMAL_AI_VERSION__"),
        "index.html should advertise the formal-ai version via a placeholder, not a hardcoded literal"
    );
    assert!(
        !index_html.contains("content=\"0.16.0\""),
        "index.html should not pin the stale 0.16.0 version literal"
    );
    assert!(
        app_js.contains("formal-ai-version"),
        "app.js should still read the formal-ai-version meta tag"
    );
    assert!(
        !app_js.contains("\"0.16.0\"") && !app_js.contains("'0.16.0'"),
        "app.js should not hardcode the stale 0.16.0 version as a string literal"
    );
    assert!(
        stamp_script.contains("__FORMAL_AI_VERSION__"),
        "stamp script should substitute the formal-ai version placeholder"
    );
    assert!(
        stamp_script.contains("formal-ai-version"),
        "stamp script should validate the rendered meta tag content"
    );
    assert!(
        stamp_script.contains("formal_ai_version"),
        "stamp deployment.json should carry the formal-ai version for the e2e wait script"
    );
    assert!(
        deploy_demo.contains("Read formal-ai version from Cargo.toml"),
        "deploy-pages should detect the crate version before stamping the artifact"
    );
    assert!(
        deploy_demo.contains(
            "scripts/stamp-pages-artifact.sh js \"${{ steps.pages_ref.outputs.sha }}\" \"${{ steps.pages_ref.outputs.sha }}\" \"${{ steps.formal_ai_version.outputs.version }}\""
        ),
        "deploy-pages should forward the selected deployment SHA and resolved crate version to the stamp script"
    );

    let wait_script = fs::read_to_string(format!(
        "{manifest_dir}/scripts/wait-for-pages-deployment.sh"
    ))
    .unwrap();
    assert!(
        wait_script.contains("__FORMAL_AI_VERSION__"),
        "pages-deployment wait script should reject lingering version placeholders"
    );
}

#[test]
fn stamp_pages_artifact_replaces_formal_ai_version_placeholder() {
    // Issue #72: end-to-end smoke test for the stamp script. Copy
    // `js/index.html` into a scratch directory, run the script the
    // same way CI does, and assert the rendered file advertises the
    // requested formal-ai version. Catches regressions in either the
    // placeholder or the substitution logic.
    let manifest_dir = concat!(env!("CARGO_MANIFEST_DIR"), "/..");
    let script = format!("{manifest_dir}/scripts/stamp-pages-artifact.sh");
    if !std::path::Path::new("/bin/bash").exists() {
        eprintln!("skipping: /bin/bash not available");
        return;
    }
    let tmp = std::env::temp_dir().join(format!(
        "formal-ai-stamp-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |duration| duration.as_nanos())
    ));
    let web_dir = tmp.join("web");
    fs::create_dir_all(&web_dir).expect("create scratch web dir");
    fs::create_dir_all(web_dir.join("tests")).expect("create scratch tests dir");
    let source_index = fs::read_to_string(format!("{manifest_dir}/js/index.html")).unwrap();
    fs::write(web_dir.join("index.html"), &source_index).expect("seed index.html");
    fs::write(
        web_dir.join("tests/index.html"),
        r#"<meta name="formal-ai-version" content="__FORMAL_AI_VERSION__"><script src="connectivity.js?v=__FORMAL_AI_ASSET_VERSION__"></script>"#,
    )
    .expect("seed tests/index.html");

    let output = Command::new("/bin/bash")
        .arg(&script)
        .arg(web_dir.to_str().unwrap())
        .arg("deadbeef")
        .arg("deadbeef")
        .arg("9.9.9")
        .output()
        .expect("run stamp script");
    let status_ok = output.status.success();
    let stdout = String::from_utf8_lossy(&output.stdout).into_owned();
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
    let rendered = fs::read_to_string(web_dir.join("index.html")).unwrap_or_default();
    let rendered_tests = fs::read_to_string(web_dir.join("tests/index.html")).unwrap_or_default();
    let marker = fs::read_to_string(web_dir.join("deployment.json")).unwrap_or_default();
    let _ = fs::remove_dir_all(&tmp);

    assert!(
        status_ok,
        "stamp script exited with {status:?}\nstdout: {stdout}\nstderr: {stderr}",
        status = output.status
    );
    assert!(
        rendered.contains("content=\"9.9.9\""),
        "stamped index.html should advertise the supplied formal-ai version, got:\n{rendered}"
    );
    assert!(
        !rendered.contains("__FORMAL_AI_VERSION__"),
        "stamped index.html should not retain the formal-ai version placeholder"
    );
    assert!(
        !rendered.contains("__FORMAL_AI_ASSET_VERSION__"),
        "stamped index.html should not retain the asset version placeholder"
    );
    assert!(
        rendered.contains("?v=deadbeef"),
        "issue #479: the stamped landing index must embed the deploy asset version (SHA) on its \
         asset refs so the Pages freshness probe and CDN cache-busting both see it, got:\n{rendered}"
    );
    assert!(
        rendered_tests.contains("content=\"9.9.9\""),
        "stamped tests/index.html should advertise the supplied formal-ai version, got:\n{rendered_tests}"
    );
    assert!(
        rendered_tests.contains("connectivity.js?v=deadbeef"),
        "stamp script should cache-bust nested test page assets, got:\n{rendered_tests}"
    );
    assert!(
        !rendered_tests.contains("__FORMAL_AI_VERSION__")
            && !rendered_tests.contains("__FORMAL_AI_ASSET_VERSION__"),
        "stamped tests/index.html should not retain placeholders, got:\n{rendered_tests}"
    );
    assert!(
        marker.contains("\"formal_ai_version\": \"9.9.9\""),
        "deployment.json should record the formal-ai version, got:\n{marker}"
    );
}

#[test]
fn static_demo_runtime_assets_are_cache_busted_by_deployment_version() {
    let manifest_dir = concat!(env!("CARGO_MANIFEST_DIR"), "/..");
    // The interactive app moved to /app/ (issue #479); its cache-busted runtime
    // assets now live in js/app/index.html. The site root index.html is the
    // landing-page chooser; it ALSO cache-busts its own assets with the deploy
    // asset version (so the stamped index embeds the SHA the Pages probe waits
    // for) but, unlike /app/, its strict CSP forbids an inline asset-version
    // script, so the SHA rides on ?v= refs rather than window.FORMAL_AI_ASSET_VERSION.
    let landing_html = fs::read_to_string(format!("{manifest_dir}/js/index.html")).unwrap();
    let app_index_html = fs::read_to_string(format!("{manifest_dir}/js/app/index.html")).unwrap();
    let tests_index = fs::read_to_string(format!("{manifest_dir}/js/tests/index.html")).unwrap();
    // Issue #550: app source moved to JSX (bundled by bun into the served
    // app.js); these checks assert source-level code, so read the JSX modules.
    let app_js = read_web_app_source(manifest_dir);
    let seed_loader_js = fs::read_to_string(format!("{manifest_dir}/js/seed_loader.js")).unwrap();
    let worker_js = read_worker_source(manifest_dir);
    let worker_prerequisites_js =
        fs::read_to_string(format!("{manifest_dir}/js/worker-script-prerequisites.js")).unwrap();
    let stamp_script =
        fs::read_to_string(format!("{manifest_dir}/scripts/stamp-pages-artifact.sh")).unwrap();
    let wait_script = fs::read_to_string(format!(
        "{manifest_dir}/scripts/wait-for-pages-deployment.sh"
    ))
    .unwrap();

    for asset in [
        // The app stylesheet is split by concern into js/styles/ (linked in
        // cascade order); every part is cache-busted like any other asset.
        "styles/01-tokens.css?v=__FORMAL_AI_ASSET_VERSION__",
        "styles/02-shell.css?v=__FORMAL_AI_ASSET_VERSION__",
        "styles/03-panels.css?v=__FORMAL_AI_ASSET_VERSION__",
        "styles/04-message-content.css?v=__FORMAL_AI_ASSET_VERSION__",
        "styles/05-composer-responsive.css?v=__FORMAL_AI_ASSET_VERSION__",
        "styles/06-dark-theme.css?v=__FORMAL_AI_ASSET_VERSION__",
        "styles/07-interactions.css?v=__FORMAL_AI_ASSET_VERSION__",
        // The generated seed inventory ships and cache-busts like any other
        // asset; without it seed_loader.js would fetch nothing (issue #991).
        "seed-files.js?v=__FORMAL_AI_ASSET_VERSION__",
        "seed_loader.js?v=__FORMAL_AI_ASSET_VERSION__",
        "preferences.js?v=__FORMAL_AI_ASSET_VERSION__",
        "i18n.js?v=__FORMAL_AI_ASSET_VERSION__",
        "memory.js?v=__FORMAL_AI_ASSET_VERSION__",
        "app.js?v=__FORMAL_AI_ASSET_VERSION__",
    ] {
        assert!(
            app_index_html.contains(asset),
            "app/index.html should version local asset {asset}"
        );
    }
    assert!(app_index_html.contains("window.FORMAL_AI_ASSET_VERSION"));
    // The landing page (site root) advertises the stamped formal-ai version AND
    // cache-busts every one of its own assets with the deploy asset version, so
    // the stamped index embeds the SHA the Pages freshness probe waits for
    // (issue #479 regression guard).
    assert!(landing_html.contains("__FORMAL_AI_VERSION__"));
    for asset in [
        "landing.css?v=__FORMAL_AI_ASSET_VERSION__",
        "preferences.js?v=__FORMAL_AI_ASSET_VERSION__",
        "site-chrome.js?v=__FORMAL_AI_ASSET_VERSION__",
        "landing.js?v=__FORMAL_AI_ASSET_VERSION__",
    ] {
        assert!(
            landing_html.contains(asset),
            "landing index.html should version local asset {asset} so the stamped page carries the deploy SHA"
        );
    }
    assert!(app_js.contains("withAssetVersion(\"worker/formal_ai_worker.js\")"));
    assert!(seed_loader_js.contains("fetchText(withAssetVersion(file))"));
    assert!(worker_js.contains("createWorkerAssetLoader(importScripts, withAssetVersion)"));
    assert!(worker_js.contains("loadWorkerAsset(\"seed-files.js\")"));
    assert!(worker_js.contains("loadWorkerAsset(\"seed_loader.js\")"));
    assert!(
        worker_js.contains("loadWorkerModules(self.FORMAL_AI_WORKER_MODULES, loadWorkerAsset)")
    );
    assert!(worker_prerequisites_js.contains("nativeImport(withAssetVersion(asset))"));
    assert!(worker_prerequisites_js.contains("loadWorkerAsset(modulePath)"));
    assert!(worker_js.contains("fetch(withAssetVersion(\"formal_ai_worker.wasm\"))"));
    for asset in [
        "connectivity.css?v=__FORMAL_AI_ASSET_VERSION__",
        "connectivity.js?v=__FORMAL_AI_ASSET_VERSION__",
    ] {
        assert!(
            tests_index.contains(asset),
            "tests/index.html should version local asset {asset}"
        );
    }
    assert!(tests_index.contains("__FORMAL_AI_VERSION__"));
    assert!(stamp_script.contains("__FORMAL_AI_ASSET_VERSION__"));
    assert!(stamp_script.contains("find \"$artifact_dir\" -type f -name '*.html'"));
    assert!(stamp_script.contains("deployment.json"));
    assert!(wait_script.contains("deployment.json"));
    assert!(wait_script.contains("expected_sha"));
}

#[test]
fn crate_package_manifest_uses_publish_allowlist() {
    let manifest = fs::read_to_string(format!("{}/Cargo.toml", env!("CARGO_MANIFEST_DIR")))
        .unwrap()
        .replace("\r\n", "\n");

    assert!(
        manifest.contains("include = ["),
        "Cargo.toml should explicitly allowlist files published to crates.io"
    );

    for required in [
        "\"/Cargo.lock\"",
        "\"/Cargo.toml\"",
        "\"../LICENSE\"",
        "\"../README.md\"",
        "\"/embedded/**\"",
        "\"/src/**\"",
    ] {
        assert!(
            manifest.contains(required),
            "Cargo.toml package include list should contain {required}"
        );
    }

    for excluded in [
        "\"/docs/**\"",
        "\"/tests/**\"",
        "\"/scripts/**\"",
        "\"/examples/**\"",
        "\"/experiments/**\"",
        "\"/.github/**\"",
        // `cargo package` extracts the .crate as the package root, so any
        // `../`-escaping row packs files at paths no rust/src literal can
        // resolve (issue #1138): sources read the rust/embedded/ mirror
        // instead, and only that mirror ships.
        "\"../data/**\"",
        "\"../js/**\"",
        "\"../scripts/opencode-conversation-to-lino.py\"",
    ] {
        assert!(
            !manifest.contains(excluded),
            "Cargo.toml should use an include allowlist instead of carrying explicit excluded repository artifacts"
        );
    }
}

#[test]
fn readme_keeps_traditional_ci_and_artifact_badges() {
    let readme = fs::read_to_string(format!("{}/../README.md", env!("CARGO_MANIFEST_DIR")))
        .unwrap()
        .replace("\r\n", "\n");

    for required in [
        "actions/workflows/release.yml/badge.svg?branch=main",
        "actions/workflows/desktop-release.yml/badge.svg?branch=main",
        "img.shields.io/crates/v/formal-ai?label=crates.io&style=flat",
        "img.shields.io/docsrs/formal-ai?label=docs.rs&style=flat",
        "img.shields.io/badge/rust-1.99%2B-blue.svg",
        "codecov.io/gh/link-assistant/formal-ai/branch/main/graph/badge.svg",
        "img.shields.io/badge/license-Unlicense-blue.svg",
    ] {
        assert!(
            readme.contains(required),
            "README.md should keep the traditional project badge `{required}`"
        );
    }

    assert!(
        !readme.contains("example-sum-package-name"),
        "README.md badges should use formal-ai, not the template placeholder package"
    );
}

#[test]
fn build_job_verifies_the_publishable_archive_before_checking_its_size() {
    let workflow = release_workflow();
    let build = job_block(&workflow, "build");
    let package_verify = build
        .find("- name: Check package")
        .expect("build job should verify the package archive");
    let package_size = build
        .find("- name: Check crate package size")
        .expect("build job should check the generated crate archive size");
    let install_rust_script = build
        .find("- name: Install rust-script")
        .expect("build job should install rust-script before running script guards");

    assert!(
        package_verify < package_size,
        "build job should verify the publishable archive before checking archive size"
    );
    assert!(
        install_rust_script < package_size,
        "build job should install rust-script before checking archive size"
    );
    assert!(
        build.contains("cargo package --manifest-path rust/Cargo.toml --locked -p formal-ai")
            && !build.contains("cargo package --list --allow-dirty"),
        "the pull-request build must compile from the .crate archive, not merely list source-tree files"
    );
    assert!(
        build.contains("rust-script scripts/check-crate-package-size.rs"),
        "build job should run the crate size guard"
    );
}

#[test]
fn lint_job_guards_the_wasm_worker_migration() {
    selected_wasm_build_contract::require_compiler_contract();
    // Issue #658 (E39 / R380): the JavaScript worker logic is being absorbed
    // into the Rust→WASM worker. Three guards keep that migration honest and
    // must run in the lint job: the worker JS line-budget ratchet, a rebuild of
    // the shipped `.wasm` from source (which caught a latent no_std break), and
    // its size budget.
    // Two of the three guards are registered gates since issue #991;
    // `ci_surface()` splices them in where their stage runs, so the ordering
    // assertions below still describe the order CI executes them.
    let workflow = ci_surface();
    let lint = job_block(&workflow, "lint");

    assert!(
        lint.contains("targets: wasm32-unknown-unknown"),
        "lint job should install the wasm32 target so the worker can be rebuilt"
    );

    let line_budget = lint
        .find("rust-script scripts/check-worker-line-budget.rs")
        .expect("lint job should ratchet the worker JS line budget");
    let build_wasm = lint
        .find("node scripts/build-selected-wasm.mjs build")
        .expect("lint job should rebuild the Rust→WASM worker from source");
    let wasm_size = lint
        .find("rust-script scripts/check-wasm-worker-size.rs")
        .expect("lint job should check the shipped .wasm size budget");
    let install_rust_script = lint
        .find("- name: Install rust-script")
        .expect("lint job should install rust-script before running script guards");

    assert!(
        install_rust_script < line_budget,
        "lint job should install rust-script before the worker line-budget guard"
    );
    assert!(
        build_wasm < wasm_size,
        "lint job should rebuild the .wasm before checking its size budget"
    );
}

#[test]
fn release_workflow_publishes_prebuilt_ghcr_image_after_crate_is_visible_and_optional_docker_hub_mirror()
 {
    let workflow = crate::ci_gates::staged_release_operations::release_operation_workflow();

    assert!(
        workflow.contains("GHCR_IMAGE: ghcr.io/${{ github.repository }}"),
        "workflow should expose the default GHCR image name for prepared Docker releases"
    );
    // Issue #1131: this used to require the bare `${{ vars.DOCKERHUB_IMAGE }}`,
    // which pinned the defect -- the variable was never set, so Docker Hub was
    // disabled on every release while the release reported success. The image
    // and the username now default, and the token is what opts in.
    assert!(
        workflow.contains("DOCKERHUB_IMAGE: ${{ vars.DOCKERHUB_IMAGE || 'konard/formal-ai' }}"),
        "workflow should default the Docker Hub image and let a fork override it"
    );
    assert!(
        !workflow.contains("${{ vars.DOCKERHUB_USERNAME || secrets.DOCKERHUB_USERNAME }}"),
        "every Docker Hub username site should carry the default too"
    );
    assert_eq!(
        workflow.matches("docker/login-action@v4").count(),
        // Four publishing logins, plus the issue #982 pull-request upgrade
        // check, which pulls the last released image from GHCR.
        5,
        "release publishing and upgrade checks should authenticate to their registries"
    );
    // Validated source/version labels are rendered by the compile-free factory;
    // each of the two guarded release jobs retains a GHCR route and optional Hub mirror.
    for mode in ["publish", "mirror"] {
        let invocation = format!(
            "run: node scripts/release-image-factory.mjs {mode} prepared-release \"$RELEASE_VERSION\""
        );
        assert_eq!(
            workflow.matches(invocation.as_str()).count(),
            2,
            "both release jobs must retain the {mode} route"
        );
    }
    assert_eq!(
        workflow.matches("docker/metadata-action@v6").count(),
        0,
        "factory tags are selected version/latest, without unused action outputs"
    );
    assert_eq!(
        workflow.matches("docker/build-push-action@v7").count(),
        1,
        "the independent pull-request Docker build remains action-backed"
    );
    assert!(
        workflow.matches("packages: write").count() >= 2,
        "release jobs should grant package write permission for GHCR publication"
    );
    assert!(
        workflow.contains("registry: ghcr.io"),
        "GHCR login should target the GitHub Container Registry"
    );
    assert!(
        workflow.contains("password: ${{ secrets.GITHUB_TOKEN }}"),
        "GHCR login should use the workflow GITHUB_TOKEN"
    );
    assert!(
        workflow.contains("password: ${{ env.DOCKERHUB_TOKEN }}"),
        "Docker Hub login should use DOCKERHUB_TOKEN"
    );

    let auto_release = job_block(&workflow, "auto-release");
    let auto_publish = auto_release
        .find("- name: Publish to Crates.io")
        .expect("auto release should publish the crate");
    let auto_wait = auto_release
        .find("- name: Wait for Crate availability on Crates.io")
        .expect("auto release should wait for the crate");
    let auto_docker = auto_release
        .find("- name: Publish Docker image to GHCR")
        .expect("auto release should publish the prepared GHCR Docker image");
    let auto_docker_hub = auto_release
        .find("- name: Publish Docker image to Docker Hub")
        .expect("auto release should optionally mirror the Docker image to Docker Hub");
    let auto_github_release = auto_release
        .find("- name: Create GitHub Release")
        .expect("auto release should create a GitHub release");

    assert!(
        auto_publish < auto_wait
            && auto_wait < auto_docker
            && auto_docker < auto_docker_hub
            && auto_docker_hub < auto_github_release,
        "auto release should publish crates.io first, then GHCR, then optional Docker Hub, then GitHub release"
    );

    let manual_release = job_block(&workflow, "manual-release");
    let manual_publish = manual_release
        .find("- name: Publish to Crates.io")
        .expect("manual release should publish the crate");
    let manual_wait = manual_release
        .find("- name: Wait for Crate availability on Crates.io")
        .expect("manual release should wait for the crate");
    let manual_docker = manual_release
        .find("- name: Publish Docker image to GHCR")
        .expect("manual release should publish the prepared GHCR Docker image");
    let manual_docker_hub = manual_release
        .find("- name: Publish Docker image to Docker Hub")
        .expect("manual release should optionally mirror the Docker image to Docker Hub");
    let manual_github_release = manual_release
        .find("- name: Create GitHub Release")
        .expect("manual release should create a GitHub release");

    assert!(
        manual_publish < manual_wait
            && manual_wait < manual_docker
            && manual_docker < manual_docker_hub
            && manual_docker_hub < manual_github_release,
        "manual release should publish crates.io first, then GHCR, then optional Docker Hub, then GitHub release"
    );
}

#[test]
fn desktop_release_lets_electron_builder_read_package_json_build_key() {
    let workflow = desktop_release_workflow();
    let package_json = fs::read_to_string(format!(
        "{}/../desktop/package.json",
        env!("CARGO_MANIFEST_DIR")
    ))
    .unwrap();
    let smoke = fs::read_to_string(format!(
        "{}/../desktop/scripts/smoke.mjs",
        env!("CARGO_MANIFEST_DIR")
    ))
    .unwrap();

    // Issue #1055 routed every packaging leg through the retry wrapper, so the
    // invocation moved there. What matters is unchanged: electron-builder is
    // called without `--config`, so it reads the `build` key from package.json.
    let wrapper = fs::read_to_string(format!(
        "{}/../desktop/scripts/package-macos-with-retry.sh",
        env!("CARGO_MANIFEST_DIR")
    ))
    .unwrap();
    assert!(
        workflow.contains(
            "bash scripts/package-macos-with-retry.sh ${{ matrix.ebflag }} --publish never"
        ),
        "desktop release workflow should package through the retry wrapper"
    );
    assert!(
        wrapper.contains("npx --no-install electron-builder \"$@\""),
        "the wrapper should invoke electron-builder without passing package.json as a config file"
    );
    assert!(
        !workflow.contains("--config package.json"),
        "package.json is an app manifest; passing it as --config makes electron-builder reject its top-level build key"
    );
    assert!(
        !package_json.contains("--config package.json"),
        "desktop npm build scripts should not pass package.json as an explicit electron-builder config file"
    );
    assert!(
        smoke.contains("--config package.json"),
        "desktop smoke checks should guard against reintroducing the invalid config flag"
    );
}

#[test]
fn desktop_linux_deb_package_metadata_is_configured() {
    // Desktop Release 27558290907 reached the Linux matrix but electron-builder
    // stopped before producing .deb assets because the app manifest lacked the
    // homepage, author email, and Linux maintainer fields required for Debian
    // package metadata. Keep those fields explicit so Linux assets do not
    // disappear from future releases.
    let package_json = fs::read_to_string(format!(
        "{}/../desktop/package.json",
        env!("CARGO_MANIFEST_DIR")
    ))
    .unwrap();
    let package: serde_json::Value =
        serde_json::from_str(&package_json).expect("desktop/package.json should be valid JSON");

    let homepage = package
        .get("homepage")
        .and_then(serde_json::Value::as_str)
        .unwrap_or_default();
    assert!(
        homepage.starts_with("https://"),
        "desktop/package.json should expose an https homepage for electron-builder Linux metadata"
    );

    let author_email = package
        .get("author")
        .and_then(|author| author.get("email"))
        .and_then(serde_json::Value::as_str)
        .unwrap_or_default();
    assert!(
        author_email.contains('@'),
        "desktop/package.json should include author.email for electron-builder Linux metadata"
    );

    let maintainer = package
        .get("build")
        .and_then(|build| build.get("linux"))
        .and_then(|linux| linux.get("maintainer"))
        .and_then(serde_json::Value::as_str)
        .unwrap_or_default();
    assert!(
        maintainer.contains('<') && maintainer.contains('@') && maintainer.contains('>'),
        "desktop/package.json build.linux.maintainer should be an RFC-822 style maintainer for .deb output"
    );
}

#[test]
fn desktop_macos_package_uses_vk_bot_signing_configuration() {
    // PR #487 follow-up: the latest macOS DMG can download but opens as
    // "damaged" on a real Mac. The working vk-bot-desktop release path does not
    // merely disable certificate discovery; it enables hardened runtime,
    // entitlements, notarization for Developer ID builds, and an explicit
    // ad-hoc signing hook for no-Apple-account builds.
    let manifest_dir = concat!(env!("CARGO_MANIFEST_DIR"), "/..");
    let package_json = fs::read_to_string(format!("{manifest_dir}/desktop/package.json")).unwrap();
    let package: serde_json::Value =
        serde_json::from_str(&package_json).expect("desktop/package.json should be valid JSON");
    let mac = package
        .get("build")
        .and_then(|build| build.get("mac"))
        .expect("desktop/package.json should configure build.mac");

    assert_eq!(
        mac.get("hardenedRuntime")
            .and_then(serde_json::Value::as_bool),
        Some(true),
        "macOS builds should enable hardened runtime like vk-bot-desktop"
    );
    assert_eq!(
        mac.get("notarize").and_then(serde_json::Value::as_bool),
        Some(true),
        "macOS Developer ID builds should opt into notarization; CI can disable it only for the ad-hoc fallback"
    );
    assert_eq!(
        mac.get("entitlements").and_then(serde_json::Value::as_str),
        Some("build/entitlements.mac.plist"),
        "macOS builds should use the explicit entitlements file copied from the working reference"
    );
    assert_eq!(
        mac.get("entitlementsInherit")
            .and_then(serde_json::Value::as_str),
        Some("build/entitlements.mac.plist"),
        "macOS child processes should inherit the same entitlements"
    );

    let entitlements = fs::read_to_string(format!(
        "{manifest_dir}/desktop/build/entitlements.mac.plist"
    ))
    .expect("macOS entitlements file should exist");
    assert!(entitlements.contains("com.apple.security.cs.allow-jit"));
    assert!(entitlements.contains("com.apple.security.cs.disable-library-validation"));

    let signer = fs::read_to_string(format!("{manifest_dir}/desktop/scripts/adhoc-sign-mac.cjs"))
        .expect("macOS ad-hoc signing hook should exist");
    for required in [
        "require('@electron/osx-sign')",
        "node:child_process",
        "MACOS_ADHOC_SIGN",
        "identity: '-'",
        "identityValidation: false",
        "timestamp: 'none'",
        "/usr/bin/codesign",
        "--force",
        "--timestamp=none",
        "--deep",
        "--options",
        "runtime",
        "upstreamOptionsForFile(appPath)",
        "--entitlements",
        "--verify",
    ] {
        assert!(
            signer.contains(required),
            "ad-hoc macOS signer should contain {required}"
        );
    }
}

#[test]
fn desktop_release_workflow_signs_and_smoke_tests_macos_artifacts() {
    // The PR feedback included a real macOS "damaged and can't be opened"
    // dialog. Guard against publishing that class of broken artifact by copying
    // vk-bot-desktop's two-path macOS build: Developer ID + notarization when
    // secrets are present, explicit ad-hoc signing otherwise, then verify the
    // produced DMG before upload.
    let workflow = desktop_release_workflow();
    let build = job_block(&workflow, "build");

    let secrets = workflow_step_block(build, "Check macOS signing secrets");
    for required in [
        "matrix.ebflag == '--mac'",
        "MAC_CSC_LINK: ${{ secrets.MAC_CSC_LINK }}",
        "MAC_CSC_KEY_PASSWORD: ${{ secrets.MAC_CSC_KEY_PASSWORD }}",
        "APPLE_API_KEY: ${{ secrets.APPLE_API_KEY }}",
        "APPLE_API_KEY_ID: ${{ secrets.APPLE_API_KEY_ID }}",
        "APPLE_API_ISSUER: ${{ secrets.APPLE_API_ISSUER }}",
        "has_secrets=true",
        "mode=signed",
        "mode=adhoc",
    ] {
        assert!(
            secrets.contains(required),
            "macOS secret check should contain {required}"
        );
    }

    let signed = workflow_step_block(build, "Package desktop app (macOS signed)");
    for required in [
        "steps.mac_secrets.outputs.has_secrets == 'true'",
        "CSC_LINK: ${{ secrets.MAC_CSC_LINK }}",
        "CSC_KEY_PASSWORD: ${{ secrets.MAC_CSC_KEY_PASSWORD }}",
        "APPLE_API_KEY: ${{ secrets.APPLE_API_KEY }}",
        "APPLE_API_KEY_ID: ${{ secrets.APPLE_API_KEY_ID }}",
        "APPLE_API_ISSUER: ${{ secrets.APPLE_API_ISSUER }}",
        "DEBUG: electron-builder,electron-notarize*",
        "bash scripts/package-macos-with-retry.sh ${{ matrix.ebflag }} --publish never",
    ] {
        assert!(
            signed.contains(required),
            "signed macOS build should contain {required}"
        );
    }

    let adhoc = workflow_step_block(build, "Package desktop app (macOS ad-hoc)");
    for required in [
        "steps.mac_secrets.outputs.has_secrets != 'true'",
        "CSC_IDENTITY_AUTO_DISCOVERY: \"false\"",
        "MACOS_ADHOC_SIGN: \"1\"",
        "DEBUG: electron-builder,electron-osx-sign*",
        "bash scripts/package-macos-with-retry.sh ${{ matrix.ebflag }} --publish never",
        "-c.mac.notarize=false",
        // Issue #479: electron-builder 26 only reaches the custom `mac.sign`
        // hook when an identity resolves. With no Apple certificate the sole
        // surviving branch is the ad-hoc `mac.identity == "-"` qualifier, so the
        // flag is mandatory -- without it signing is skipped and the produced
        // .app ships with no _CodeSignature/CodeResources envelope.
        "-c.mac.identity=-",
        "-c.mac.sign=./scripts/adhoc-sign-mac.cjs",
    ] {
        assert!(
            adhoc.contains(required),
            "ad-hoc macOS build should contain {required}"
        );
    }

    let smoke = workflow_step_block(build, "Smoke test macOS release artifacts");
    for required in [
        "matrix.ebflag == '--mac'",
        "MACOS_BUILD_MODE: ${{ steps.mac_secrets.outputs.mode }}",
        "hdiutil attach",
        "formal-ai Desktop.app",
        "Contents/_CodeSignature/CodeResources",
        "codesign --verify --deep --strict --verbose=2",
        "spctl --assess --type execute --verbose=4",
        "xcrun stapler validate",
        "Signature=adhoc",
    ] {
        assert!(
            smoke.contains(required),
            "macOS smoke test should contain {required}"
        );
    }

    let smoke_index = build
        .find("- name: Smoke test macOS release artifacts")
        .expect("macOS smoke step should exist");
    let upload_index = build
        .find("- name: Upload assets to release")
        .expect("release upload step should exist");
    assert!(
        smoke_index < upload_index,
        "macOS artifacts should be smoke-tested before they are uploaded to the release"
    );
}

#[test]
fn desktop_linux_artifact_names_are_normalized_for_download_contract() {
    // Electron Builder renders Linux x64 artifacts with target-specific aliases:
    // AppImage uses x86_64 and Debian uses amd64. The download page, checksum
    // tests, and release resolver all use the cross-platform x64 contract, so
    // the release workflow normalizes the files before checksums and upload.
    match Command::new("node").arg("--version").output() {
        Ok(output) if output.status.success() => {}
        _ => {
            eprintln!("skipping: node not available");
            return;
        }
    }

    let manifest_dir = concat!(env!("CARGO_MANIFEST_DIR"), "/..");
    let script = format!("{manifest_dir}/desktop/scripts/normalize-artifacts.mjs");
    let tmp = std::env::temp_dir().join(format!(
        "formal-ai-desktop-artifacts-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |duration| duration.as_nanos())
    ));
    fs::create_dir_all(&tmp).expect("create scratch release dir");

    let source_names = [
        "formal-ai-desktop-linux-x86_64-9.9.9.AppImage",
        "formal-ai-desktop-linux-x86_64-9.9.9.AppImage.blockmap",
        "formal-ai-desktop-linux-amd64-9.9.9.deb",
        "formal-ai-desktop-linux-x64-9.9.9.tar.gz",
        "formal-ai-desktop-linux-arm64-9.9.9.deb",
    ];
    for name in source_names {
        fs::write(tmp.join(name), b"artifact").expect("seed scratch release artifact");
    }
    fs::write(
        tmp.join("latest-linux.yml"),
        "files:\n  - url: formal-ai-desktop-linux-x86_64-9.9.9.AppImage\n  - url: formal-ai-desktop-linux-amd64-9.9.9.deb\npath: formal-ai-desktop-linux-x86_64-9.9.9.AppImage\n",
    )
    .expect("seed scratch update metadata");

    let output = Command::new("node")
        .arg(&script)
        .arg(&tmp)
        .output()
        .expect("run desktop artifact normalizer");
    let status_ok = output.status.success();
    let stdout = String::from_utf8_lossy(&output.stdout).into_owned();
    let stderr = String::from_utf8_lossy(&output.stderr).into_owned();

    let expected_names = [
        "formal-ai-desktop-linux-x64-9.9.9.AppImage",
        "formal-ai-desktop-linux-x64-9.9.9.AppImage.blockmap",
        "formal-ai-desktop-linux-x64-9.9.9.deb",
        "formal-ai-desktop-linux-x64-9.9.9.tar.gz",
        "formal-ai-desktop-linux-arm64-9.9.9.deb",
    ];
    let missing = expected_names
        .iter()
        .filter(|name| !tmp.join(name).exists())
        .copied()
        .collect::<Vec<_>>();
    let stale = [
        "formal-ai-desktop-linux-x86_64-9.9.9.AppImage",
        "formal-ai-desktop-linux-x86_64-9.9.9.AppImage.blockmap",
        "formal-ai-desktop-linux-amd64-9.9.9.deb",
    ]
    .iter()
    .filter(|name| tmp.join(name).exists())
    .copied()
    .collect::<Vec<_>>();
    let metadata =
        fs::read_to_string(tmp.join("latest-linux.yml")).expect("read normalized update metadata");
    let _ = fs::remove_dir_all(&tmp);

    assert!(
        status_ok,
        "normalizer exited with {status:?}\nstdout: {stdout}\nstderr: {stderr}",
        status = output.status
    );
    assert!(
        missing.is_empty(),
        "normalizer should create every download-contract artifact, missing {missing:?}\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert!(
        stale.is_empty(),
        "normalizer should remove Electron Builder alias names, still present {stale:?}\nstdout: {stdout}\nstderr: {stderr}"
    );
    assert!(
        stdout.contains("x86_64") && stdout.contains("amd64") && stdout.contains("x64"),
        "normalizer should log the Linux x64 alias rewrites, got stdout:\n{stdout}"
    );
    assert!(
        metadata.contains("formal-ai-desktop-linux-x64-9.9.9.AppImage")
            && metadata.contains("formal-ai-desktop-linux-x64-9.9.9.deb")
            && !metadata.contains("linux-x86_64")
            && !metadata.contains("linux-amd64"),
        "normalizer should rewrite latest-linux.yml to the uploaded x64 asset names, got:\n{metadata}"
    );
}

#[test]
fn release_scripts_check_configured_release_artifacts() {
    let release_check = fs::read_to_string(format!(
        "{}/../scripts/check-release-needed.rs",
        env!("CARGO_MANIFEST_DIR")
    ))
    .unwrap();
    let wait_for_crate = fs::read_to_string(format!(
        "{}/../scripts/wait-for-crate.rs",
        env!("CARGO_MANIFEST_DIR")
    ))
    .unwrap();
    let release_script = fs::read_to_string(format!(
        "{}/../scripts/create-github-release.rs",
        env!("CARGO_MANIFEST_DIR")
    ))
    .unwrap();

    assert!(
        release_check.contains("check_docker_hub_tag"),
        "release-needed check should verify configured Docker Hub tags"
    );
    assert!(
        release_check.contains("check_docker_hub_tag(image, \"latest\")"),
        "release-needed check should verify Docker Hub latest tags as part of completeness"
    );
    assert!(
        release_check.contains("check_github_release"),
        "release-needed check should verify GitHub release artifacts"
    );
    assert!(
        release_check.contains("crate_published"),
        "release-needed check should output whether the crate already exists"
    );
    assert!(
        wait_for_crate.contains("crates.io/api/v1/crates"),
        "release workflow should wait for crates.io visibility before image publishing"
    );
    assert!(
        wait_for_crate.contains("example-sum-package-name")
            && wait_for_crate.contains("crate_available\", \"skipped\""),
        "crate availability wait should preserve template-safe publishing skips"
    );
    assert!(
        release_script.contains("--ghcr-url"),
        "GitHub release creation should accept a GHCR package URL"
    );
    assert!(
        release_script.contains("fn ghcr_badge"),
        "GitHub release notes should include GHCR badge support"
    );
    assert!(
        release_script.contains("--docker-hub-url"),
        "GitHub release creation should accept a Docker Hub URL"
    );
    assert!(
        release_script.contains("fn docker_hub_badge"),
        "GitHub release notes should include Docker Hub badge support"
    );
}
