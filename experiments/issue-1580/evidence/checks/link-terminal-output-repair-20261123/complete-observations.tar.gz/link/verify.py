import datetime,json,os,subprocess,time
from pathlib import Path
out=Path('/tmp/issue-1580-research/security-contract-comparison')
commands=[('maintained-observations',['node','--max-old-space-size=192','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])]
for gate in ['workflows','check-runner-labels','check-ci-speed','check-file-size','check-file-size-js-twin','check-readable-code','check-changelog-fragment-js-twin','check-required-documentation','check-tests-as-docs','check-tests-as-documentation-javascript-twin']:
 commands.append(('gate-'+gate,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]))
commands.append(('requirement-status-readonly',['node','scripts/check-requirement-status.mjs']))
rows=[]
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=192'}
for label,command in commands:
 start=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
  result=subprocess.run(command,env=env,stdout=stdout,stderr=stderr)
 row={'label':label,'command':command,'exitCode':result.returncode,'seconds':time.monotonic()-start,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 rows.append(row);(out/'verification.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
(out/'verification-outcome.json').write_text(json.dumps({'pass':all(row['exitCode']==0 for row in rows),'commands':len(rows),'nativeBuildExecuted':False,'hostedRepairExecuted':False,'fullIssueComplete':False},indent=2)+'\n')
