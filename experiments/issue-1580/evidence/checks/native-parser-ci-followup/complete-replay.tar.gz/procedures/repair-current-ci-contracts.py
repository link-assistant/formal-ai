from pathlib import Path
import subprocess

assert subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip() == 'issue-1580-8d61a32a61e1'
root = Path('/tmp/issue-1580-research/current-ci-contract-repairs')
root.mkdir(exist_ok=True)
parser = Path('rust/src/rule_interpreter/parser.rs')
before = (root / 'parser.rs.before').read_text() if (root / 'parser.rs.before').exists() else parser.read_text()
marker = '#[cfg(test)]\nmod reference_list_tests {\n'
assert before.count(marker) == 1
prefix, body = before.split(marker)
assert body.endswith('}\n')
target = Path('rust/tests/unit/rule_interpreter_reference_lists.rs')
assert not target.exists() or parser.read_text().endswith('mod reference_list_tests;\n')
target.write_text(''.join(line[4:] if line.startswith('    ') else line for line in body[:-2].splitlines(keepends=True)))
(root / 'parser.rs.before').write_text(before)
parser.write_text(prefix + '#[cfg(test)]\n#[path = "../../tests/unit/rule_interpreter_reference_lists.rs"]\nmod reference_list_tests;\n')

policy = Path('rust/tests/web/default-branch-build-policy.test.mjs')
before = policy.read_text()
(root / 'default-branch-build-policy.test.mjs.before').write_text(before)
first = 'cargo test --manifest-path rust/Cargo.toml --locked --lib solver_unknown_reasoning::tests:: -- --test-threads=1 || regression_status=$?'
new = ['cargo test --manifest-path rust/Cargo.toml --locked --lib ' + name + ' -- --test-threads=1 || regression_status=$?'
       for name in ['solver_helpers::code::javascript_program_tests::', 'rule_interpreter::parser::reference_list_tests::']]
assert before.count(first) == 2
after = ''.join(line + ''.join(line.replace(first, command) for command in new)
                if first in line else line for line in before.splitlines(keepends=True))
assert all(after.count(line) == 2 for line in new)
start = after.index('  // Run the actual shell body against a finite stub:')
end = after.index('  } finally { rmSync(directory, {recursive:true, force:true}); }', start)
replacement = '''    // Execute every regression after any sibling fails, retaining the final
    // nonzero status. Every case runs the actual workflow shell body.
    const directory = mkdtempSync(join(tmpdir(), 'native-replay-failures-'));
    try {
      const stub = join(directory, 'cargo');
      writeFileSync(stub, [
        '#!/bin/sh',
        'printf "%s\\\\n" "$*" >> "$REPLAY_CALLS"',
        'case "$*" in',
        '  *"solver_unknown_reasoning::tests::"*) exit "$REPLAY_UNKNOWN_STATUS";;',
        '  *"solver_helpers::code::javascript_program_tests::"*) exit "$REPLAY_JAVASCRIPT_STATUS";;',
        '  *"rule_interpreter::parser::reference_list_tests::"*) exit "$REPLAY_PARSER_STATUS";;',
        '  *"--test any_language "*) exit "$REPLAY_SPANISH_STATUS";;',
        '  *) exit 99;;',
        'esac',
        '',
      ].join('\\n'), {mode: 0o755});
      for (const [unknown, javascript, parser, spanish, expected] of [
        [0,0,0,0,0], [1,0,0,0,1], [0,2,0,0,2],
        [0,0,3,0,3], [0,0,0,4,4], [1,2,3,4,4],
      ]) {
        const calls = join(directory, `calls-${unknown}-${javascript}-${parser}-${spanish}.txt`);
        const result = spawnSync('bash', ['-e', '-c', binding.run], {encoding:'utf8', timeout:5000,
          env:{...process.env, PATH:directory+':'+process.env.PATH, REPLAY_CALLS:calls,
            REPLAY_UNKNOWN_STATUS:String(unknown), REPLAY_JAVASCRIPT_STATUS:String(javascript),
            REPLAY_PARSER_STATUS:String(parser), REPLAY_SPANISH_STATUS:String(spanish)}});
        assert.equal(result.status, expected, result.stderr);
        const commands = read(calls).trim().split('\\n');
        assert.equal(commands.length, 4);
        assert.match(commands[0], /--lib solver_unknown_reasoning::tests::/u);
        assert.match(commands[1], /--lib solver_helpers::code::javascript_program_tests::/u);
        assert.match(commands[2], /--lib rule_interpreter::parser::reference_list_tests::/u);
        assert.match(commands[3], /--test any_language/u);
      }
'''
replacement = ''.join(line[2:] if line.startswith('  ') else line for line in replacement.splitlines(keepends=True))
after = after[:start] + replacement + after[end:]
policy.write_text(after)
subprocess.run(['rustfmt', '--edition', '2024', str(parser), str(target)], check=True)
print('Moved the existing parser regression under tests/unit, preserved its module filter, updated both workflow allowlists, and added six independent failure-preservation cases.')
