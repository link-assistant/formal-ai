from pathlib import Path
import json, os, subprocess, sys

root=Path('/tmp/issue-1580-research/current-ci-repair-checks-v2')
if len(sys.argv)==1:
 root.mkdir(exist_ok=False)
 with (root/'worker.log').open('w') as log:
  process=subprocess.Popen([sys.executable,__file__,'--worker'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (root/'pid').write_text(str(process.pid)+'\n')
 print(json.dumps({'pid':process.pid,'root':str(root)}))
 raise SystemExit
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
files=['rust/src/calculation/currency.rs','rust/src/how_to_guide/extract.rs','rust/src/how_to_guide.rs',
 'rust/src/solver_handlers/documentation_method.rs','rust/src/rule_interpreter/parser.rs',
 'rust/tests/unit/rule_interpreter_reference_lists.rs']
checks=[('rustfmt',['rustfmt','--edition','2024','--check',*files]),
 ('typescript-projection',['node','scripts/translate-es.mjs','--check'])]
tests=[('workflow-policy','rust/tests/web/default-branch-build-policy.test.mjs'),
 ('source-test-placement','rust/tests/web/source-test-placement-twin.test.mjs'),
 ('native-seed-data','rust/tests/web/issue-1580-native-seed-data.test.mjs'),
 ('native-group-registration','experiments/issue-1580/native-regression-groups.test.mjs'),
 ('typescript-runtime','rust/tests/web/typescript-runtime.test.mjs')]
checks += [(name,['timeout','600','node','--test','--test-concurrency=1','--test-reporter=tap',file]) for name,file in tests]
checks += [('diff-check',['git','diff','--check'])]
records=[]
for label,command in checks:
 with (root/f'{label}.log').open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 record={'name':label,'command':command,'exitCode':result.returncode}
 records.append(record)
 (root/'status.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 assert result.returncode==0,record
(root/'outcome.json').write_text(json.dumps({'complete':True,'allPassed':True,'checks':records,
 'localNativeCompilation':False,'independentAuthorshipCredit':0},indent=2)+'\n')
