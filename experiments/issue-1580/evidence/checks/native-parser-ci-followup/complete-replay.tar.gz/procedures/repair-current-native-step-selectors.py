from pathlib import Path
file=Path('rust/tests/web/default-branch-build-policy.test.mjs')
before=file.read_text()
old='Verify native unresolved-language source binding'
new='Verify native source binding and canonical operand readers'
assert before.count(old)==3
file.write_text(before.replace(old,new))
source=Path('/tmp/issue-1580-research/run-current-ci-repair-checks.py').read_text()
Path('/tmp/issue-1580-research/run-current-ci-repair-checks-v2.py').write_text(source.replace("current-ci-repair-checks'", "current-ci-repair-checks-v2'"))
print('Updated all three native step selectors; retained the first full failed local run and prepared a separate verification directory.')
