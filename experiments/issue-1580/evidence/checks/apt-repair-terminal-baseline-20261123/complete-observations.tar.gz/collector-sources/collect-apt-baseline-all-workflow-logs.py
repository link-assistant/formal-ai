from pathlib import Path
import subprocess,gzip,json,hashlib,datetime,re
root=Path('/tmp/issue-1580-research');dest=root/'apt-repair-all-workflow-logs'
runs=json.loads((root/'apt-repair-head-ci/outcome.json').read_text())['runs']
records=[]
for run in runs:
 identifier=str(run['databaseId']); prior=root/'apt-repair-head-ci'/('cli-log-'+identifier+'.stdout.gz')
 target=dest/(identifier+'.log.gz');err=dest/(identifier+'.stderr')
 argv=['gh','run','view',identifier,'--repo','link-assistant/formal-ai','--attempt','1','--log']
 if prior.exists():
  target.write_bytes(prior.read_bytes());exit_code=0;err.write_bytes(b'')
 else:
  with err.open('wb') as errors,target.open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as zipped:
   process=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=errors)
   while True:
    chunk=process.stdout.read(65536)
    if not chunk: break
    zipped.write(chunk)
   process.stdout.close();exit_code=process.wait()
 digest=hashlib.sha256();count=0;candidates=[]
 pattern=re.compile(r'##\[warning\]|::warning(?:\s|:)|\bwarning:|\bWARN\b',re.I)
 with gzip.open(target,'rb') as log:
  for count,line in enumerate(log,1):
   digest.update(line);text=line.decode('utf-8',errors='replace').rstrip()
   if pattern.search(text):candidates.append({'line':count,'text':text})
 (dest/(identifier+'-warning-candidates.json')).write_text(json.dumps(candidates,indent=2)+'\n')
 row={'run':run,'attempt':1,'command':argv,'exitCode':exit_code,'lines':count,'sha256':digest.hexdigest(),'compressedBytes':target.stat().st_size,'warningCandidates':len(candidates),'stderr':err.read_text()}
 records.append(row);(dest/'progress.json').write_text(json.dumps(records,indent=2)+'\n')
 print(identifier,run['workflowName'],exit_code,count,len(candidates),flush=True)
(dest/'outcome.json').write_text(json.dumps({'complete':True,'recordCount':len(records),'records':records,'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'semanticLogReviewComplete':False,'fullIssueComplete':False},indent=2)+'\n')
print('COMPLETE',flush=True)
