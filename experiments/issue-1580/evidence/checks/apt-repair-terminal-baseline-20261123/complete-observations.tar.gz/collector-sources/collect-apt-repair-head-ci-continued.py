import datetime,gzip,json,subprocess,time,zipfile,hashlib
from pathlib import Path
root=Path('/tmp/issue-1580-research/apt-repair-head-ci')
root.mkdir(exist_ok=True)
assert not (root/'outcome.json').exists()
head='bc08222b5a5195dc9992c0459bde2b6369377b9f'
repository='link-assistant/formal-ai'
records=json.loads((root/'records.json').read_text())
def capture(label,command,required=True):
    result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    for stream,value in [('stdout',result.stdout),('stderr',result.stderr)]:
        (root/f'{label}.{stream}.gz').write_bytes(gzip.compress(value,mtime=0))
    records.append({'label':label,'command':command,'exitCode':result.returncode})
    (root/'records.json').write_text(json.dumps(records,indent=2)+'\n')
    if required and result.returncode:
        raise RuntimeError(f'{label}: {result.stderr.decode(errors="replace")[:1000]}')
    return result
def collect(run):
    identity=run['databaseId']
    jobs=capture(f'jobs-{identity}',['gh','api',f'repos/{repository}/actions/runs/{identity}/jobs','--paginate'])
    result=capture(f'cli-log-{identity}',['gh','run','view',str(identity),'--repo',repository,'--log'],False)
    if result.returncode:
        archive=root/f'available-logs-{identity}.zip'
        command=['gh','api',f'repos/{repository}/actions/runs/{identity}/logs']
        with archive.open('wb') as output:
            download=subprocess.run(command,stdout=output,stderr=subprocess.PIPE)
        (root/f'archive-{identity}.stderr.gz').write_bytes(gzip.compress(download.stderr,mtime=0))
        item={'run':identity,'command':command,'exitCode':download.returncode,'bytes':archive.stat().st_size,'sha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),'cliWholeLogUnavailable':True}
        if download.returncode==0 and zipfile.is_zipfile(archive):
            with zipfile.ZipFile(archive) as z:
                assert z.testzip() is None
                item['members']=[{'name':i.filename,'bytes':i.file_size,'crc32':i.CRC} for i in z.infolist()]
                item['availableArchiveVerified']=True
        else:
            item['availableArchiveVerified']=False
        item['missingLogsAreNotExecutionEvidence']=True
        (root/f'archive-{identity}.json').write_text(json.dumps(item,indent=2)+'\n')
        if not item['availableArchiveVerified']:
            raise RuntimeError(f'Available archive unavailable for {identity}')
    return {'id':identity,'cliWholeLogAvailable':result.returncode==0}
try:
    saved={}
    previous=None
    stable=0
    for observation in range(154,514):
        result=capture(f'observation-{observation:03}',['gh','run','list','--repo',repository,'--branch','issue-1580-8d61a32a61e1','--commit',head,'--limit','100','--json','databaseId,workflowName,status,conclusion,createdAt,updatedAt,headSha,url,event'])
        runs=json.loads(result.stdout)
        assert all(run['headSha']==head for run in runs)
        (root/'latest.json').write_text(json.dumps(runs,indent=2)+'\n')
        for run in runs:
            if run['status']=='completed' and run['conclusion'] in ['failure','cancelled','timed_out','action_required'] and run['databaseId'] not in saved:
                saved[run['databaseId']]=collect(run)
        signature=sorted((run['databaseId'],run['status'],run['conclusion']) for run in runs)
        terminal=len(runs)>=33 and all(run['status']=='completed' for run in runs)
        stable=stable+1 if terminal and signature==previous else 0
        print(json.dumps({'observation':observation,'head':head,'runs':len(runs),'pending':sum(run['status']!='completed' for run in runs),'nonpassingCollected':len(saved),'terminalStable':stable}),flush=True)
        previous=signature
        if stable>=2:
            for run in runs:
                if run['workflowName'] in ['CI/CD Pipeline','Layered CI'] and run['databaseId'] not in saved:
                    saved[run['databaseId']]=collect(run)
            capture('pull-request-checks',['gh','pr','view','1581','--repo',repository,'--json','headRefOid,isDraft,mergeStateStatus,statusCheckRollup'])
            (root/'outcome.json').write_text(json.dumps({'head':head,'complete':True,'runs':runs,'collected':saved,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
            break
        time.sleep(30)
    else:
        (root/'outcome.json').write_text(json.dumps({'head':head,'complete':False,'reason':'Bounded additional 360-observation window exhausted; unfinished workflows retain pending status','runs':runs,'collected':saved},indent=2)+'\n')
except Exception as error:
    (root/'collector-error.json').write_text(json.dumps({'head':head,'error':str(error)},indent=2)+'\n')
    raise
