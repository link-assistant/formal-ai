from pathlib import Path
import os,subprocess,json
root=Path('/tmp/issue-1580-research/credential-sparse-final-checks')
env=dict(os.environ,BASE_REF='bc08222b5a5195dc9992c0459bde2b6369377b9f')
with (root/'secret-gate.log').open('w') as stream:
 result=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--only','release#2'],env=env,stdout=stream,stderr=subprocess.STDOUT)
(root/'secret-result.json').write_text(json.dumps({'exitCode':result.returncode,'base':env['BASE_REF'],'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()})+'\n')
print('SECRET_GATE_FINISHED',result.returncode,flush=True)
