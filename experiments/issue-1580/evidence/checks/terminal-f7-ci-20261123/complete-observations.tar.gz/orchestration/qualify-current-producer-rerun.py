import datetime,gzip,hashlib,json,subprocess,time,zipfile
from pathlib import Path
research=Path('/tmp/issue-1580-research')
root=research/'current-producer-rerun-qualification'
root.mkdir(exist_ok=False)
repository='link-assistant/formal-ai'
branch='issue-1580-8d61a32a61e1'
head='f7a71cb86a16e78da0e9ca055c13710d62277739'
run=45151783306
records=[]
def capture(label,command,required=True):
 result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 for stream,value in [('stdout',result.stdout),('stderr',result.stderr)]: (root/f'{label}.{stream}.gz').write_bytes(gzip.compress(value,mtime=0))
 records.append({'label':label,'command':command,'exitCode':result.returncode,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 (root/'records.json').write_text(json.dumps(records,indent=2)+'\n')
 if required and result.returncode:raise RuntimeError(f'{label}: {result.stderr.decode(errors="replace")[:600]}')
 return result
def api(label,path):
 return json.loads(capture(label,['gh','api',f'repos/{repository}/{path}','--paginate']).stdout)
def finish(value):
 (root/'outcome.json').write_text(json.dumps({'head':head,'run':run,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),**value},indent=2)+'\n')
try:
 baseline=None
 for observation in range(180):
  p=research/'rerun-repair-head-ci/outcome.json'
  if p.exists():
   baseline=json.loads(p.read_text())
   if not baseline.get('complete'): raise RuntimeError('Original cohort did not finish within collection window; no rerun authorized by this observer')
   if any(r['conclusion'] not in ['success','skipped'] for r in baseline['runs']):
    finish({'complete':False,'rerunRequested':False,'reason':'Baseline has nonpassing workflows; collect and repair them before any rerun','baseline':baseline})
    break
   assert baseline['head']==head and len(baseline['runs'])==33
   (root/'baseline-cohort.json').write_text(json.dumps(baseline,indent=2)+'\n')
   break
  if (research/'rerun-repair-head-ci/collector-error.json').exists():raise RuntimeError('Original collector failed; no rerun')
  print(json.dumps({'phase':'waiting-for-complete-baseline','observation':observation}),flush=True)
  time.sleep(30)
 else:raise RuntimeError('Bounded original-cohort waiting window exhausted; no rerun')
 if (root/'outcome.json').exists():raise SystemExit(0)
 assert baseline is not None
 assert capture('branch',['git','branch','--show-current']).stdout.decode().strip()==branch
 assert capture('head',['git','rev-parse','HEAD']).stdout.decode().strip()==head
 pr=json.loads(capture('pull-request-head',['gh','pr','view','1581','--repo',repository,'--json','headRefOid']).stdout)
 assert pr['headRefOid']==head
 policy=capture('current-concurrency-policy',['git','show',f'{head}:.github/workflows/main.yml'],False)
 if policy.returncode:
  policy=capture('current-ci-policy',['git','show',f'{head}:.github/workflows/ci.yml'],False)
 policyfiles=capture('workflow-paths',['git','ls-tree','-r','--name-only',head,'.github/workflows']).stdout.decode().splitlines()
 found=[]
 for path in policyfiles:
  if path.endswith(('.yml','.yaml')):
   raw=subprocess.check_output(['git','show',f'{head}:{path}'])
   if b'name: CI/CD Pipeline' in raw:
    (root/'source-pipeline-workflow.yml').write_bytes(raw);found.append(path)
    assert b'github.run_attempt > 1' in raw and b'github.run_attempt == 1' in raw
 assert len(found)==1
 for status in ['in_progress','queued']:
  pending=json.loads(capture('gate-'+status,['gh','run','list','--repo',repository,'--branch',branch,'--status',status,'--limit','100','--json','databaseId,headSha,workflowName']).stdout)
  assert not pending,f'Active branch workflows before rerun: {pending}'
 before=api('run-before',f'actions/runs/{run}')
 assert before['head_sha']==head and before['run_attempt']==1 and before['status']=='completed' and before['conclusion']=='success'
 artifacts=api('artifacts-before',f'actions/runs/{run}/artifacts')
 original=next(a for a in artifacts['artifacts'] if a['id']==14807293214)
 assert not original['expired'] and '-1-' in original['name']
 request_time=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (root/'rerun-request-time.txt').write_text(request_time+'\n')
 capture('rerun-all-request',['gh','run','rerun',str(run),'--repo',repository])
 requested={'rerunRequested':True,'requestTime':request_time,'originalArtifact':original,'complete':False,'phase':'requested'}
 (root/'progress.json').write_text(json.dumps(requested,indent=2)+'\n')
 terminal=None
 for observation in range(180):
  current=api(f'observation-{observation:03}',f'actions/runs/{run}')
  assert current['head_sha']==head and current['run_attempt'] in [1,2]
  print(json.dumps({'phase':'observing-producer-rerun','observation':observation,'attempt':current['run_attempt'],'status':current['status'],'conclusion':current['conclusion']}),flush=True)
  if current['run_attempt']==2 and current['status']=='completed':
   terminal=current;break
  time.sleep(30)
 if terminal is None:
  finish({**requested,'reason':'Bounded rerun observation window exhausted; run remains unfinished'})
 else:
  jobs=api('attempt-2-jobs',f'actions/runs/{run}/attempts/2/jobs')
  artifacts_after=api('artifacts-after',f'actions/runs/{run}/artifacts')
  retained=next(a for a in artifacts_after['artifacts'] if a['id']==original['id'])
  assert retained['name']==original['name'] and retained['digest']==original['digest']
  new=[a for a in artifacts_after['artifacts'] if a['name'].startswith(f'native-contracts-{run}-2-')]
  consumers=[j for j in jobs['jobs'] if '/ Native contracts (' in j['name']]
  producer=[j for j in jobs['jobs'] if j['name'].endswith('/ Compile focused native contracts once')]
  log=capture('attempt-2-cli-log',['gh','run','view',str(run),'--repo',repository,'--attempt','2','--log'],False)
  archive_verified=False
  if log.returncode:
   archive=root/'attempt-2-available-logs.zip'
   with archive.open('wb') as out:
    zresult=subprocess.run(['gh','api',f'repos/{repository}/actions/runs/{run}/attempts/2/logs'],stdout=out,stderr=subprocess.PIPE)
   (root/'attempt-2-archive.stderr.gz').write_bytes(gzip.compress(zresult.stderr,mtime=0))
   item={'exitCode':zresult.returncode,'bytes':archive.stat().st_size,'sha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),'missingLogsAreNotExecutionEvidence':True}
   if zresult.returncode==0 and zipfile.is_zipfile(archive):
    with zipfile.ZipFile(archive) as z:
     assert z.testzip() is None
     item['members']=[{'name':i.filename,'bytes':i.file_size,'crc32':i.CRC} for i in z.infolist()]
     archive_verified=True
   item['verified']=archive_verified
   (root/'attempt-2-archive.json').write_text(json.dumps(item,indent=2)+'\n')
  capture('pull-request-checks-after',['gh','pr','view','1581','--repo',repository,'--json','headRefOid,isDraft,mergeStateStatus,statusCheckRollup'])
  finish({**requested,'complete':True,'terminal':terminal,'jobs':jobs,'newArtifacts':new,'originalArtifactStillPreserved':True,'producerJobs':producer,'consumers':consumers,'allTenConsumersPassed':len(consumers)==10 and all(j['conclusion']=='success' for j in consumers),'newProducerPassed':len(producer)==1 and producer[0]['conclusion']=='success','distinctAttemptArtifactCreated':len(new)==1 and new[0]['id']!=original['id'],'wholeLogAvailable':log.returncode==0,'fallbackLogArchiveVerified':archive_verified,'semanticLogReviewComplete':False})
except Exception as error:
 (root/'observer-error.json').write_text(json.dumps({'head':head,'error':str(error)},indent=2)+'\n')
 raise
