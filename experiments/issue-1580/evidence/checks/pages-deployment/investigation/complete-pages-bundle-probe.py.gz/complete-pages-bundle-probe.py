from pathlib import Path
import gzip, hashlib, json, os, resource, subprocess

r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/pages-bundle-probe')
pin='368f82528645a54fb793d4d04e342629a3f51346'
tree=json.loads(Path('/tmp/issue-1580-research/pages-implementation/tree.json').read_text())['tree']
records=[]
for name in ['sourcemap-register.js','index.js.map','licenses.txt']:
    source=s/name;entry=next(x for x in tree if x['path']=='dist/'+name)
    with source.open('wb') as output,(s/(name+'.download.stderr')).open('wb') as errors:
        p=subprocess.run(['gh','api','-H','Accept: application/vnd.github.raw',f'repos/actions/deploy-pages/contents/dist/{name}?ref={pin}'],stdout=output,stderr=errors)
    assert p.returncode==0
    raw=source.read_bytes();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==entry['sha']
    records.append({'path':'dist/'+name,'gitBlob':blob,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
source=s/'index.js';source.write_bytes(gzip.decompress((s/'official-index.cjs.gz').read_bytes()))
env={'PATH':os.environ['PATH'],'GITHUB_RUN_ID':'1','GITHUB_REPOSITORY':'owner/repo','GITHUB_SHA':'a'*40,'GITHUB_ACTOR':'fixture','GITHUB_ACTION':'fixture','INPUT_TOKEN':'fixture','ACTIONS_ID_TOKEN_REQUEST_URL':'https://oidc.invalid/','ACTIONS_ID_TOKEN_REQUEST_TOKEN':'fixture'}
def bounds():
    resource.setrlimit(resource.RLIMIT_CPU,(5,5));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
with (s/'complete.stdout.log').open('wb') as output,(s/'complete.stderr.log').open('wb') as errors:
    p=subprocess.run(['node','--max-old-space-size=128','--stack-size=1024','--trace-deprecation','--require',str(r/'experiments/issue-1580/pages-network-block.cjs'),str(source)],cwd=r,env=env,stdout=output,stderr=errors,timeout=5,preexec_fn=bounds)
stderr=(s/'complete.stderr.log').read_text()
result={'source':json.loads((s/'source.json').read_text()),'closure':records,'exitCode':p.returncode,'deprecationObserved':'[DEP0040]' in stderr,'networkBlocked':True,'heapMiB':128,'cpuSeconds':5,'wallSeconds':5,'hostedNode24Evidence':False,'independentAuthorshipCredit':0}
(s/'complete-result.json').write_text(json.dumps(result,indent=2)+'\n')
for name in ['index.js','index.js.map','sourcemap-register.js','licenses.txt']:
    f=s/name
    if name!='index.js':(s/(name+'.gz')).write_bytes(gzip.compress(f.read_bytes(),mtime=0))
    f.unlink()
print(json.dumps({'exitCode':p.returncode,'deprecationObserved':result['deprecationObserved'],'closureFiles':4,'networkBlocked':True}))
assert result['deprecationObserved'],stderr[-1200:]
