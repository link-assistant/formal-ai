from pathlib import Path
import json
out=Path('/tmp/issue-1580-research/pages-publication');out.mkdir(exist_ok=True)
text='''# Artifact-bound Pages retries

The existing deployment action bundles deprecated `punycode`, and a single transient creation error fails publication. The JavaScript and Python templates replace it with a dependency-free REST helper. Their retry lookup, however, uses only the source commit: two independently uploaded artifacts from the same source cannot be distinguished. The bounded probe executes both unchanged template helpers and observes artifact 41 being adopted while the caller requested artifact 42.

The local action retains the template's create/poll/cancel protocol, bounded transient retries, permanent refusal diagnostics, polling error budget, final-state checks and cancellation on SIGINT/SIGTERM. Its API build-version key hashes the repository, immutable artifact ID and complete source SHA. The source stamp remains unchanged. GitHub documents `pages_build_version` as a unique string representing the artifact version; deployment status responses contain only status, so commit-only lookup cannot prove which artifact was deployed. Actual server acceptance and publication with the new key are still unverified.

The build passes the exact upload-pages-artifact `artifact_id` output through its reusable-workflow boundary. The deployment job checks out only its own workflow's action at `github.workflow_sha`, then supplies that ID and the stamped source SHA. Complete comparisons against f967e4efb preserve all existing workflow/job fields and unrelated steps, including trust predicates, permissions, concurrency, environment, deadlines, output source SHA and live E2E commands. The staged release renderer retains all 52 operations and 104 bindings.

The adapter has 35 passing checks, including the 28 inherited template behaviors, identity dimensions, refusal boundaries, output validation and real process cancellation in bounded child probes. Six template checks run actual pinned helpers; disabling artifact binding produces two expected failures. The maintained Pages entrypoint imports deployment, workflow wiring and projection tests within the existing fast-lane file limit. Initial signal-probe failures and inventory-cap failures are retained alongside their repairs.

A bounded local execution of the complete official v5.0.1 bundle reproduces DEP0040 under Node 26.13.0. Network access is blocked before loading it; CPU/wall limits are five seconds, heap is 128 MiB and stack is 1024 KiB. The expected failed network request is not deployment evidence. All four original bundle closure identities are verified and compressed, including the initial incomplete-closure failure. The replacement loads only Node built-ins and runs with --throw-deprecation; actual hosted Node 24 deployment remains unverified.

The fresh default-branch JavaScript/Python helpers are byte-identical to the pinned reproductions at f8e30b7a00c3113eeec555edcfbaa9ef235ed273 and b497e24e5be049cad0b9840eb0e0b8d2eb6077b0. Read the latest related merged PRs (#282 / #134) and existing retry/deprecation issues. Upstream adoption reports will be linked after immutable executable evidence is published. Reporting alone does not repair either template.

The full issue remains incomplete: actual Pages publication and served identity, broader template practice comparison, original-source qualification and historical budgets, remaining warnings/dependency migrations, provenance and complete PR review remain open. Supplied commands, code and reviews earn zero independent reasoning credit.

Primary protocol references: https://docs.github.com/en/rest/pages/pages#create-a-github-pages-deployment and https://docs.github.com/en/rest/pages/pages#get-the-status-of-a-github-pages-deployment.
'''
(out/'pages-deployment-checkpoint.md').write_text(text)
for short,repo,path,pin in [('js','link-foundation/js-ai-driven-development-pipeline-template','scripts/deploy-pages.mjs','f8e30b7a00c3113eeec555edcfbaa9ef235ed273'),('python','link-foundation/python-ai-driven-development-pipeline-template','.github/actions/deploy-pages/deploy.mjs','b497e24e5be049cad0b9840eb0e0b8d2eb6077b0')]:
 body=f'''The current [Pages helper](https://github.com/{repo}/blob/{pin}/{path}) adopts a deployment by source commit after a transient creation failure. That lookup can return a different artifact uploaded by an earlier run of the same commit. The caller then reports success without deploying the requested artifact.

For example, artifact 41 is already successfully deployed from source SHA S. A rebuild/rerun uploads artifact 42 from the same S. Its first creation request fails before the server creates anything. On retry, GET `/pages/deployments/S` finds the successful deployment of artifact 41. The helper adopts it and never creates a deployment of artifact 42. Builds from identical source may differ because of dependency resolution, generated output, build inputs or environment; the requested immutable artifact still matters even when content happens to match.

A finite offline probe runs the actual unchanged helper with this API history. It observes adopted artifact 41, one failed POST, and no deployment of requested artifact 42. The same probe also covers a lost response after successful creation: the correct artifact is adopted with one POST, preserving retry safety. No GitHub deployment or writes are needed.

Reproduction and regression evidence in link-assistant/formal-ai PR https://github.com/link-assistant/formal-ai/pull/1581 at COMMIT_PLACEHOLDER:

- [Executable probe](https://github.com/link-assistant/formal-ai/blob/COMMIT_PLACEHOLDER/experiments/issue-1580/probe-pages-adoption.mjs)
- [Actual pinned helper fixtures and source identities](https://github.com/link-assistant/formal-ai/tree/COMMIT_PLACEHOLDER/experiments/issue-1580/fixtures/pages-templates)
- [Regression tests and negative control](https://github.com/link-assistant/formal-ai/blob/COMMIT_PLACEHOLDER/experiments/issue-1580/template-pages-adoption.test.mjs)

Run `node --test experiments/issue-1580/template-pages-adoption.test.mjs`. All six assertions pass, including observations of the original defects. With `ISSUE_1580_DISABLE_PAGES_BINDING=1`, two candidate assertions fail because the old artifact is adopted.

Suggested repair: derive the API build-version key from the repository, immutable artifact ID and source SHA, using the same key for creation and retry lookup. Keep the real source SHA in the artifact's provenance stamp. GitHub documents `pages_build_version` as a unique artifact-version string; the status API returns only status, so source-only lookup cannot verify the artifact ID. The downstream candidate passes bounded mocked tests; real hosted publication with the new key has not yet been verified.

Acceptance: a failed pre-creation attempt for artifact 42 must never adopt artifact 41 from the same source. A lost response after creation of artifact 42 should still adopt 42 without another POST. Preserve permanent-error refusal, bounded retry/polling, cancellation and output behavior.
'''
 (out/(short+'-adoption-report.md')).write_text(body)
print('Drafted checkpoint and two concrete shared-defect reports; no external write.')
