from pathlib import Path
import json, shutil
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'data/benchmarks/fast-pull-request-javascript-tests.json'
s=p.read_text()
for name in ['pages-deployment','pages-artifact-trust','staged-pages-projection']:
 line='    "rust/tests/web/'+name+'.test.mjs",\n'
 assert line in s,name
 s=s.replace(line,'',1)
p.write_text(s)
p=r/'rust/tests/web/pages-live-rate-budget.test.mjs'
s=p.read_text()
imports="// Keep the complete Pages contract in one existing fast-lane admission.\nimport './pages-deployment.test.mjs';\nimport './pages-artifact-trust.test.mjs';\nimport './staged-pages-projection.test.mjs';\n\n"
assert "import './pages-deployment.test.mjs'" not in s
p.write_text(imports+s)
s=Path('/tmp/issue-1580-research/pages-checks'); archive=s/'first-incomplete';archive.mkdir(exist_ok=True)
for p in s.glob('*-sealed.*'):
 shutil.move(str(p),archive/p.name)
for name in ['sealed-results.json']:
 p=s/name
 if p.exists():shutil.move(str(p),archive/p.name)
worker=Path('/tmp/issue-1580-research/run-pages-related-checks.py')
s=worker.read_text().replace('import json, os, subprocess','import json, os, subprocess, sys')
anchor="env=dict(os.environ);env.pop('NODE_OPTIONS',None)"
replacement="""if '--worker' not in sys.argv:
    with (s/'worker.log').open('ab') as output:
        p=subprocess.Popen([sys.executable,__file__,'--worker'],cwd=r,stdin=subprocess.DEVNULL,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
    (s/'pid').write_text(str(p.pid)+'\\n');print('Started focused checks',p.pid,flush=True);sys.exit(0)
env=dict(os.environ);env.pop('NODE_OPTIONS',None)"""
assert anchor in s
worker.write_text(s.replace(anchor,replacement))
print('Preserved every Pages check inside the existing admitted entrypoint; prior capacity failures retained.')
