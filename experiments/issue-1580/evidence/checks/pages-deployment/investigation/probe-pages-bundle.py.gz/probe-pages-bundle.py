from pathlib import Path
import gzip, hashlib, json, os, resource, subprocess

r=Path('/tmp/gh-issue-solver-1794900398048')
s=Path('/tmp/issue-1580-research/pages-bundle-probe');s.mkdir(exist_ok=False)
pin='368f82528645a54fb793d4d04e342629a3f51346'
tree=json.loads(Path('/tmp/issue-1580-research/pages-implementation/tree.json').read_text())['tree']
entry=next(x for x in tree if x['path']=='dist/index.js')
source=s/'index.cjs'
with source.open('wb') as output, (s/'download.stderr').open('wb') as errors:
    p=subprocess.run(['gh','api','-H','Accept: application/vnd.github.raw',f'repos/actions/deploy-pages/contents/dist/index.js?ref={pin}'],stdout=output,stderr=errors)
assert p.returncode==0
raw=source.read_bytes();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert blob==entry['sha']
env={'PATH':os.environ['PATH'],'GITHUB_RUN_ID':'1','GITHUB_REPOSITORY':'owner/repo','GITHUB_SHA':'a'*40,'GITHUB_ACTOR':'fixture','GITHUB_ACTION':'fixture','INPUT_TOKEN':'fixture','ACTIONS_ID_TOKEN_REQUEST_URL':'https://oidc.invalid/','ACTIONS_ID_TOKEN_REQUEST_TOKEN':'fixture'}
command=['node','--max-old-space-size=128','--stack-size=1024','--trace-deprecation','--require',str(r/'experiments/issue-1580/pages-network-block.cjs'),str(source)]
def bounds():
    resource.setrlimit(resource.RLIMIT_CPU,(5,5))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
timed_out=False
with (s/'stdout.log').open('wb') as output,(s/'stderr.log').open('wb') as errors:
    try:p=subprocess.run(command,cwd=r,env=env,stdout=output,stderr=errors,timeout=5,preexec_fn=bounds)
    except subprocess.TimeoutExpired:timed_out=True
stderr=(s/'stderr.log').read_text()
result={'repository':'actions/deploy-pages','commit':pin,'path':'dist/index.js','gitBlob':blob,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'runtime':subprocess.check_output(['node','--version'],text=True).strip(),'exitCode':None if timed_out else p.returncode,'timedOut':timed_out,'deprecationObserved':'[DEP0040]' in stderr,'networkBlocked':True,'heapMiB':128,'cpuSeconds':5,'wallSeconds':5,'hostedNode24Evidence':False,'independentAuthorshipCredit':0}
(s/'source.json').write_text(json.dumps(result,indent=2)+'\n')
(s/'official-index.cjs.gz').write_bytes(gzip.compress(raw,mtime=0))
source.unlink()
print(json.dumps(result))
assert not timed_out and result['deprecationObserved'],stderr[-1500:]
