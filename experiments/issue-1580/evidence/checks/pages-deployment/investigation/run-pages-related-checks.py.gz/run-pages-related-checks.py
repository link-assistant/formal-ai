from pathlib import Path
import json, os, subprocess, sys

r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/pages-checks')
if '--worker' not in sys.argv:
    with (s/'worker.log').open('ab') as output:
        p=subprocess.Popen([sys.executable,__file__,'--worker'],cwd=r,stdin=subprocess.DEVNULL,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
    (s/'pid').write_text(str(p.pid)+'\n');print('Started focused checks',p.pid,flush=True);sys.exit(0)
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
results=[]
files=['pages-deployment','pages-artifact-trust','staged-pages-projection','pages-live-rate-budget','issue-1580-template-observations','fast-pull-request-production-profile','native-release-workflow','relocated-build-stage-controls','native-workflow-cache-bindings','ci-speed','default-branch-build-policy','documentation-only-ci-policy']
for name in files:
    with (s/(name+'-sealed.stdout')).open('wb') as output,(s/(name+'-sealed.stderr')).open('wb') as errors:
        p=subprocess.run(['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs'],cwd=r,env=env,stdout=output,stderr=errors)
    results.append([name,p.returncode]);print(name,p.returncode,flush=True)
(s/'sealed-results.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(code==0 for _,code in results)
