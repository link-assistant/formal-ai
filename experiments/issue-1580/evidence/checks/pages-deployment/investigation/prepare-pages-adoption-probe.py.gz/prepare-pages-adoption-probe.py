from pathlib import Path
import hashlib, json, shutil

r=Path('/tmp/gh-issue-solver-1794900398048')
s=Path('/tmp/issue-1580-research/templates')
manifest=json.loads((s/'manifest.json').read_text())
base=r/'experiments/issue-1580/fixtures/pages-templates'
base.mkdir(exist_ok=False)
specs={
 'js':['scripts/deploy-pages.mjs','scripts/github-api.mjs','LICENSE'],
 'python':['.github/actions/deploy-pages/deploy.mjs','LICENSE'],
}
rows=[]
for language,paths in specs.items():
    entry=next(t for t in manifest if t['repo'].split('/')[1].startswith(language+'-'))
    tree=json.loads((s/(language+'-tree.json')).read_text())
    tree=tree['tree'] if isinstance(tree,dict) else tree
    lookup={f['path']:f['sha'] for f in tree}
    files=[]
    for name in paths:
        source=s/(language+'-complete')/name
        raw=source.read_bytes()
        blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        assert blob==lookup[name],(name,blob,lookup[name])
        target=base/language/name;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(source,target)
        files.append({'path':name,'gitBlob':blob,'sha256':hashlib.sha256(raw).hexdigest()})
    rows.append({'language':language,'repository':entry['repo'],'commit':entry['sha'],'files':files})
(base/'source.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Verified and retained five exact pinned source/license blobs for offline Pages adoption probes.')
