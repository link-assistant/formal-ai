from pathlib import Path
import hashlib, json, subprocess

r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/pages-related-work')
specs={'js':['scripts/deploy-pages.mjs','scripts/github-api.mjs'],'python':['.github/actions/deploy-pages/deploy.mjs']}
rows=[]
for language,paths in specs.items():
    head=json.loads((s/(language+'-head.json')).read_text())['sha'];repo=f'link-foundation/{language}-ai-driven-development-pipeline-template'
    for path in paths:
        p=subprocess.run(['gh','api','-H','Accept: application/vnd.github.raw',f'repos/{repo}/contents/{path}?ref={head}'],capture_output=True,cwd=r)
        assert p.returncode==0,p.stderr.decode()[-500:]
        target=s/(language+'-current-'+path.replace('/','_'));target.write_bytes(p.stdout)
        previous=(r/'experiments/issue-1580/fixtures/pages-templates'/language/path).read_bytes()
        rows.append({'repository':repo,'commit':head,'path':path,'bytes':len(p.stdout),'sha256':hashlib.sha256(p.stdout).hexdigest(),'unchangedFromProbeFixture':p.stdout==previous})
    for pr in json.loads((s/(language+'-pages-pulls.json')).read_text()):
        if pr['number'] == (282 if language=='js' else 134):
            (s/(language+'-related-pull.md')).write_text(pr['url']+'\n\n'+pr['title']+'\n\n'+pr['body']+'\n')
    issues=json.loads((s/(language+'-issues.json')).read_text())
    for issue in issues:
        if issue['number'] in ([277,250] if language=='js' else [130,114]):
            (s/(language+'-related-issue-'+str(issue['number'])+'.md')).write_text(issue['html_url']+'\n\n'+issue['title']+'\n\n'+issue['body']+'\n')
(s/'current-source-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
assert all(row['unchangedFromProbeFixture'] for row in rows)
