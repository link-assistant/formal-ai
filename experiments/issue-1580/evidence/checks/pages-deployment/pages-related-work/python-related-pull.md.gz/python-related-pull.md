https://github.com/link-foundation/python-ai-driven-development-pipeline-template/pull/134

fix(ci): retry Pages deploys, schedule the link checker, audit npm locks

Fixes #133
Fixes #130
Fixes #131
Fixes #132

## Changes

### #130: Pages deploy retries transient failures without deploying twice
- New dependency-free local action `.github/actions/deploy-pages` (`deploy.mjs`, `index.mjs`, `action.yml`). It replaces `actions/deploy-pages@v5`.
  - It uses the same REST protocol: an OIDC token, `POST /repos/{repo}/pages/deployments`, polling with ×1.5 backoff capped at 30 s, an error budget of 10 polls, a 10-minute timeout followed by a cancel, a cancel on SIGINT/SIGTERM, and the `page_url` output. The status messages match upstream.
  - A transient HTTP 5xx, 429, lost connection or request timeout while creating the deployment is retried up to 3 times, 10 s and then 20 s apart.
  - Before each retry the action calls `GET .../pages/deployments/{sha}`. It adopts that deployment unless it is in a final failed state, so a response lost after the server created the deployment never leads to a second deployment of the same commit.
  - Any other 4xx fails at once, without a retry. The message includes the status, the `x-github-request-id`, the response body, and a hint: for 401/403 it names the `pages: write` / `id-token: write` permissions, and for 404 it links the Pages settings.
- `docs.yml`:
  - The Pages upload step has `id: pages-artifact`, and the build job outputs `pages-artifact-id`.
  - The deploy job runs `uses: $/.github/actions/deploy-pages` with `artifact_id: ${{ needs.build.outputs.pages-artifact-id }}`, so it publishes exactly that artifact.
  - The `NODE_OPTIONS: --disable-warning=DEP0040` workaround is removed. The action has no npm dependencies, so there is no bundled `punycode`.
- `.github/actionlint.yaml`: the self-repository `$/` exception now also covers the `deploy-pages` path.

### #131: link checker
- `links.yml` runs every Monday at 06:00 UTC (`schedule`).
- The new step "Name today's link cache" outputs `date -u +%F`. The cache uses `key: cache-lychee-<day>-<sha>` and `restore-keys: cache-lychee-<day>-`, so only a cache saved the same UTC day is restored. lychee accepts such a cache under `--max-cache-age 1d`, so `[WARN] Cache is too old` cannot occur.

### #132: npm lockfile security
- **glob GHSA-3g3m-2fjr-6pw4 / minimatch GHSA-g3hv-75wg-m249:**
  - The artifact action now pins `glob` 14.0.3 (via the `archiver-utils` override) and `minimatch` 11.0.4 (direct dependency plus `"minimatch": "$minimatch"` override).
  - `npm audit` reports 0 vulnerabilities.
  - `@actions/glob` 0.7.0, the latest release, calls `Minimatch#matchOne`, which minimatch 11 removed. `files.mjs` therefore matches upload paths with minimatch 11 directly and keeps the `@actions/glob` rules:
    - one pattern per line, with `#` comments and `!` exclusions;
    - every file under a matched directory is included;
    - hidden entries and symlinks are skipped.
  - `experiments/find_files_differential.mjs` checks this: 42 cases gave output identical to the old `@actions/glob` implementation.
  - `dist/` is rebuilt, and the rebuild is reproducible.
- **Security workflow:** the new job "Audit npm Lockfiles" runs `scripts/audit-npm-locks.sh`. It runs `npm audit --package-lock-only --audit-level=moderate` for every tracked `package-lock.json`, and on failure prints a `::error file=…` annotation with how to fix it. The job is part of the Pipeline Status gate and runs on pushes, PRs and the weekly schedule.
- **Dependabot:** new `.github/dependabot.yml` with `github-actions` for `/` and `npm` for `/.github/actions/artifact`. Both run weekly with `cooldown: default-days: 7` and grouped updates.
- **Dependabot and `dist/`:** Dependabot does not rebuild `dist/`. "Verify committed action bundle" now fails with an explicit annotation listing the rebuild commands, and this is documented in `dependabot.yml` and `docs/ci-evidence.md`.

### Docs and changelog
- README ("Deploying API documentation", Lychee section) and `docs/ci-evidence.md` are updated.
- Changelog fragment: `changelog.d/20261102_issue_133_ci_reliability.md`.

## How to reproduce the original problems
- **#130:** with `actions/deploy-pages@v5`, a single HTTP 500 from `POST /pages/deployments` fails the job with no retry. `tests/deploy-pages.test.mjs` scripts exactly this with a mocked API.
  - Mutation check: with adoption disabled, 2 tests fail; with `attempts = 1`, 10 tests fail.
- **#131:** before this change, `restore-keys: cache-lychee-` restored a cache of any age, and lychee logged `[WARN] Cache is too old` and discarded it. `links.yml` also had no `schedule`.
- **#132:** `npm audit --package-lock-only` on the old `.github/actions/artifact/package-lock.json` reports the glob and minimatch advisories. `scripts/audit-npm-locks.sh` exits 1 on a fixture repository containing that lock.

## Tests
- `node --throw-deprecation --test tests/deploy-pages.test.mjs`: 28 tests, all passing, covering:
  - 500/502/503/504/429 retried with exactly one deployment created;
  - network errors and timeouts retried;
  - 400/401/403/404/409/422 failing on the first call, reporting the status and request ID;
  - retries exhausted after 3 attempts;
  - adoption of a queued, in-progress or succeeded deployment;
  - a new deployment when the earlier one failed;
  - every final state;
  - temporary states and poll errors;
  - backoff, the interval cap, cancel after too many errors, and cancel on timeout;
  - artifact ID validation;
  - `githubApi`, `oidcToken`, and `main` writing `page_url`.
- These tests run in the Workflows pipeline ("Test Pages deployment retries and refusals"). `tests/*.test.mjs` is added to its path filters.
- `node --throw-deprecation --test tests/artifact.test.mjs`: 21 tests, all passing, including the new `findFiles` semantics test and the lockfile version assertions.
- `tests/test_issue_133_workflows.py` covers:
  - the build output, the deploy wiring, and the action interface with no dependencies;
  - the weekly schedule and the UTC-day cache key/restore-keys;
  - the npm-audit job and its gate;
  - the audit script listing every tracked lockfile;
  - the Dependabot ecosystems, directories, weekly interval and cooldown;
  - the stale-bundle error;
  - patched lockfile versions.
- Updated `tests/test_issue_118_workflows.py`: the cache key test, and the DEP0040 test is replaced by an assertion that no `NODE_OPTIONS` remain.
- Updated `tests/test_workflows.py`: the deploy-pages pin and the checkout count (27).
- Local checks:
  - actionlint 1.7.12 (the pinned image) is clean.
  - zizmor 1.30.1 (regular and pedantic, as in CI) reports no findings.
  - shellcheck 0.11.0.1 is clean.
  - `ruff check` and `ruff format --check` pass.

## Notes
- Adoption identifies a deployment by commit SHA (`pages_build_version`), which is what the Pages API's `GET /pages/deployments/{sha}` exposes. Adoption is only attempted on a retry within the same job, so the adopted deployment is normally the one the lost response created. The API cannot tell apart a deployment of the same commit that an earlier run created and that has not failed; such a deployment would also be adopted, and it publishes a site built from the same commit.
- The two moderate Dependabot alerts GitHub reports on `main` are the glob/minimatch advisories that this PR fixes.

