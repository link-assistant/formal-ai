https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/114

actions/deploy-pages@v5 prints the punycode DEP0040 deprecation on every Pages deployment

## Problem

`actions/deploy-pages@v5` still bundles a dependency that calls Node's built-in `punycode` module. Every successful Pages deployment therefore prints:

```
(node:2182) [DEP0040] DeprecationWarning: The `punycode` module is deprecated. Please use a userland alternative instead.
```

Where: `.github/workflows/docs.yml` line 111. The latest docs run of this template ([37585861682](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/actions/runs/37585861682)) did not reach a deploy step. The same action version prints the warning in the JS template ([run 38049674017](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/actions/runs/38049674017)) and in link-foundation/lfs ([run 39744445318](https://github.com/link-foundation/lfs/actions/runs/39744445318)).

The step succeeds, so the warning is noise that teaches readers to skip warnings. Upstream tracks it in actions/deploy-pages#434 and actions/deploy-pages#413, and both are still open with no fixed release.

## Reproduce

```sh
node -e 'require("punycode")'                                            # prints DEP0040
NODE_OPTIONS=--disable-warning=DEP0040 node -e 'require("punycode")'     # silent
```

A script that also proves other deprecations still get through is [`experiments/issue-3-dep0040-node-options.sh`](https://github.com/link-foundation/lfs/blob/issue-3-ec8fb15100d3/experiments/issue-3-dep0040-node-options.sh) in link-foundation/lfs#4.

## Suggested fix / workaround

Silence only DEP0040, only on the deploy step. Do not use `--no-warnings`, which would also hide new warnings. Remove the env once deploy-pages ships a fix.

```yaml
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v5
        # actions/deploy-pages@v5 bundles a dependency that still calls Node's
        # deprecated built-in punycode module (actions/deploy-pages#434).
        env:
          NODE_OPTIONS: --disable-warning=DEP0040
```

Applied, with a regression test, in link-foundation/lfs#4 (link-foundation/lfs#3).

