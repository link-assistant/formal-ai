https://github.com/link-foundation/js-ai-driven-development-pipeline-template/pull/282

fix: retry Pages deploys, recheck links weekly, report all npm advisories, rerun unacquired runners

This PR fixes the four CI infrastructure issues tracked in #281 in one PR. Generated repositories inherited each one: a transient Pages 500 failed the deploy, links were only rechecked when Markdown changed and the lychee cache was always discarded, moderate npm advisories passed silently, and a job GitHub never found a runner for was reported as a code failure.

Fixes #277
Fixes #278
Fixes #279
Fixes #280
Fixes #281

## #277: Pages deployment retries a transient failure, without deploying twice

`actions/deploy-pages@v5` does not retry a failure to create the deployment (`Failed to create deployment (status: 500)`). Wrapping the action in a retry loop is not safe, because a lost response can hide a deployment that was created.

- `scripts/deploy-pages.mjs` speaks the action's REST protocol with plain `fetch`: OIDC token, `POST /pages/deployments`, poll, and cancel when abandoned. The deploy job no longer runs `npm ci` and needs no npm dependencies.
  - **Retries:** HTTP 429, 5xx, timeouts and network errors are retried up to 3 times with a growing delay.
  - **Permanent errors:** 400/401/403/404/422 fail at once. The message names the method, the path, the status and the `x-github-request-id`.
  - **Never twice:** before every retry, the script reads `GET /pages/deployments/{sha}`. If an earlier attempt's deployment exists and has not failed, the script adopts it, so a lost response never leads to a second deployment of the same commit.
  - **Polling:** it polls until a final state. On timeout, on too many polling errors, on a permanent polling error, or on SIGINT/SIGTERM (job cancelled), it cancels the deployment.
- `web-build` outputs the `artifact-id` of the Pages upload, and `pages-deploy` publishes exactly that artifact.
- Removing the action also removes the punycode adapter it needed: `scripts/check-pages-punycode.mjs`, `.github/actions/artifact-transport/punycode.mjs` and the `punycode` dependency.
- `scripts/github-api.mjs` holds the dependency-free REST client that the deploy and rerun scripts share.
- `tests/deploy-pages.test.js` has 17 tests against a scripted API: a 500 followed by success (exactly one `POST`), retries on 429, network failure and timeout, each permanent status, retry exhaustion, adoption after a lost response, an earlier failed deployment of the same commit, every final failed state, polling errors and timeout followed by a cancel, and the OIDC request.

## #278: Weekly link recheck and a day-scoped lychee cache

- `links.yml` also runs on `schedule: '0 6 * * 1'`, so link rot is detected without commits.
- The cache key is `cache-lychee-<os>-<UTC date>-<sha>`, and the restore key is `cache-lychee-<os>-<UTC date>-`. Only a cache saved the same UTC day is restored, and that is younger than lychee's `--max-cache-age 1d`.
- `tests/links-workflow.test.js` asserts both.
- Hosted evidence: [Broken Link Checker run 41528788321](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/actions/runs/41528788321) logged `Cache restored from key: cache-lychee-Linux-2026-11-02-…`, and its log has no `Cache is too old` line.

## #279: Every npm advisory is reported, and fixable moderate ones fail the weekly run

- `scripts/npm-audit-report.mjs` runs `npm audit --package-lock-only --json` once per lock.
  - **Reporting:** it emits one annotation per advisory (GHSA), not per package. Advisories below the gate are warnings and failing ones are errors. It also writes a table of all of them to the step summary.
  - **Gates:** pull requests and pushes still fail at `high`. The weekly run also fails on a `moderate` advisory that `npm audit fix` resolves without `--force`.
  - **Fails closed:** a registry error or unparsable output fails the job.
- The artifact SDK's `glob` override moves to 14.0.3, which fixes GHSA-3g3m-2fjr-6pw4.
- One moderate advisory remains: GHSA-g3hv-75wg-m249, in `minimatch@10`. It has no non-breaking fix. `minimatch` 11 removes `makeRe`, `regexp` and `AST`, and eslint, `@actions/glob` and `readdir-glob` all require `^10`. It is now reported as a warning annotation and in the summary, not hidden. Once a patched 10.x exists, the weekly run fails until the lock is updated.
- Tested by `tests/npm-audit-report.test.js`, which uses a fixture of real audit output, and by `tests/security-workflow.test.js`. `docs/CONTRIBUTING.md` documents the policy.

## #280: Jobs GitHub never acquired a runner for

When GitHub gives up with "The job was not acquired by Runner of type hosted even after multiple attempts", the job ends `cancelled` or `failure` with an empty `runner_name` and no steps.

- **Status gates name the cause.**
  - All five `Pipeline Status` gates get `GH_TOKEN` and job-level `actions: read`. The workflow default stays `contents: read`.
  - When a required job failed or was cancelled, `scripts/check-pipeline-status.sh` lists the attempt's jobs and adds `::error title=Hosted runner not acquired::<jobs>. GitHub could not provide a runner, so no code ran.`
  - The gate stays red, because nothing was tested. If the jobs cannot be listed, it warns and still reports the original failure.
- **Automatic rerun.** `.github/workflows/rerun-unacquired.yml` runs `scripts/rerun-unacquired.mjs`.
  - **Trigger:** `workflow_run`, `completed`, on every top-level workflow, for a run that concluded `failure` with `run_attempt < 3`.
  - **Action:** it calls `POST /actions/runs/{id}/rerun-failed-jobs`, which also reruns the dependent gates and release.
  - **When it reruns:** only when the failure is fully explained by unacquired jobs. It skips a run where any job that ran steps failed (status gates excepted), a run someone already reran, and a run that a newer run of the same workflow, branch and event supersedes.
  - **Permissions:** `actions: write` is granted to that one job only. It never checks out the inspected run's commit, which is why `dangerous-triggers` is ignored inline.
  - `workflow_run` fires only for workflow files on the default branch, so it takes effect after merge.
- **Optional macOS `continue-on-error`:** not applied. Releases still require every runtime on every OS. The trade-off (`needs.test.result` would report success for a failed macOS leg) is documented in the README's new "Hosted Runner Capacity" section.
- **Tests:**
  - `tests/rerun-unacquired.test.js`: detection, pagination, rerun, real failure, attempt limit, already rerun, superseded run, a refused rerun, and the workflow's trigger, permissions and concurrency.
  - `tests/pipeline-status.test.js`: the gate annotation from an injected `JOBS_JSON`, no API call on green runs, the listing-failure warning, the no-token path, and `GH_TOKEN`/`actions: read` in every gate.

## How to reproduce

- **#277:** in `tests/deploy-pages.test.js`, the scripted API answers the first `POST /pages/deployments` with a 500. The old action failed on it. The script retries and publishes once.
- **#278:** before this PR, the Broken Link Checker logs showed `[WARN] Cache is too old`, and the workflow had no `schedule`.
- **#279:** `npm audit --package-lock-only --audit-level=high` in `.github/actions/artifact-transport` exits 0 and says nothing about the moderate advisories. `tests/fixtures/npm-audit-moderate.json` is that lock's audit output.
- **#280:** give one job an unavailable runner label, or wait for a macOS capacity event. Then compare the gate's annotation with the fixture in `tests/pipeline-status.test.js`.

## Verification

- `npm test`: 1108 pass, 0 fail.
- The changed test files pass on Bun and Deno.
- `npm run check` (eslint, prettier, jscpd, line limits) passes.
- `node scripts/check-ci-workflows.mjs` and `node scripts/check-status-gate-covers-all-jobs.mjs` pass.
- `zizmor==1.30.1 --min-confidence low --persona regular` reports no findings.
- Hosted CI on final revision `10159d0` passes all six workflows, including all nine OS/runtime test legs and macOS desktop packaging:
  - [Checks and release 41529561414](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/actions/runs/41529561414)
  - [Example app 41529561417](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/actions/runs/41529561417)
  - [Security 41529561351](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/actions/runs/41529561351)
  - [Workflows 41529561367](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/actions/runs/41529561367)
  - [Broken Link Checker 41529561465](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/actions/runs/41529561465)
  - [JavaScript-first mixed-language example 41529561334](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/actions/runs/41529561334)

## What CI on this pull request cannot exercise

Two paths only run after merge, so pull request CI covers them with unit tests and workflow assertions only:

- `pages-deploy` runs only on a push to `main`, in the `github-pages` environment.
- `rerun-unacquired.yml` runs only from the default branch.

The first push to `main` after merging will run the real Pages deployment.

