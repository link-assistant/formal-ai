from pathlib import Path
import subprocess,json,gzip,hashlib,time,os
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');o=r/'experiments/issue-1580/evidence/checks/pages-deployment';rows=json.loads((o/'records.json').read_text())
renamed=[]
for row in rows:
 p=o/row['file']
 if p.name.startswith('src__'):
  q=p.with_name(p.name.replace('src__','source__',1));p.rename(q);row['file']=str(q.relative_to(o));renamed.append({'from':str(p.relative_to(o)),'to':row['file']})
(o/'records.json').write_text('[\n'+',\n'.join(json.dumps(x,separators=(',',':')) for x in rows)+'\n]\n')
checks=[('pages-entrypoint-final',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/pages-live-rate-budget.test.mjs'],0),('pages-proof-final',['node','experiments/issue-1580/verify-pages-migration.mjs'],0),('artifact-frozen-proof-final',['node','experiments/issue-1580/verify-artifact-migration.mjs','--revision','f400d7ab2'],0),('artifact-current-refusal-final',['node','experiments/issue-1580/verify-artifact-migration.mjs'],1),('abbreviations-final',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations'],0)]
results=[]
for name,args,want in checks:
 with (s/'pages-checks'/f'{name}.stdout').open('wb') as out,(s/'pages-checks'/f'{name}.stderr').open('wb') as err:
  start=time.monotonic();p=subprocess.run(args,cwd=r,stdout=out,stderr=err,env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256'))
 results.append({'name':name,'command':args,'status':p.returncode,'expected':want,'seconds':round(time.monotonic()-start,3)})
 print(results[-1],flush=True)
(s/'pages-checks/final-results.json').write_text(json.dumps({'archiveRenames':renamed,'checks':results,'independentAuthorshipCredit':0},indent=2)+'\n')
assert all(x['status']==x['expected'] for x in results)
