from pathlib import Path
import subprocess, os, json, datetime
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/rerun-policy-validation')
tasks=json.loads((out/'tasks.json').read_text())
env=dict(os.environ)
env['NODE_OPTIONS']='--max-old-space-size=256'
results=[]
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
for i,t in enumerate(tasks):
    record=dict(t,startedAt=stamp(),index=i)
    print(json.dumps(dict(event='start',**record)),flush=True)
    with (out/(t['name']+'.log')).open('wb') as log:
        done=subprocess.run(t['command'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    record.update(exitCode=done.returncode,finishedAt=stamp())
    results.append(record)
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(dict(event='finish',**record)),flush=True)
outcome=dict(finishedAt=stamp(),total=len(results),failed=[r for r in results if r['exitCode']!=0],results=results)
(out/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
