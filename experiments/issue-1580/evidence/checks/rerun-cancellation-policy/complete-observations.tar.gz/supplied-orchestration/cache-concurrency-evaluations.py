from pathlib import Path
p=Path('/tmp/gh-issue-solver-1794900398048/experiments/issue-1580/workflow-concurrency.test.mjs')
text=p.read_text()
old="const evaluate=(source,context)=>typeof source!=='string'?source:new Script(source.replace(/^\\$\\{\\{\\s*|\\s*\\}\\}$/gu,'').replace(/\\.([a-zA-Z_][a-zA-Z0-9_-]*)/gu,(_,key)=>'['+JSON.stringify(key)+']')).runInNewContext({...context,format:(pattern,...values)=>pattern.replace(/\\{(\\d+)\\}/gu,(_,i)=>String(values[Number(i)]))},{timeout:100});"
new="""// Workflow policies repeat the same expressions across jobs. Evaluate each
// immutable expression/context pair once rather than creating thousands of VMs.
const evaluatedExpressions = new Map();
const evaluate = (source, context) => {
  if (typeof source !== 'string') return source;
  const key = JSON.stringify([source, context]);
  if (!evaluatedExpressions.has(key)) {
    const expression = source.replace(/^\\$\\{\\{\\s*|\\s*\\}\\}$/gu, '')
      .replace(/\\.([a-zA-Z_][a-zA-Z0-9_-]*)/gu, (_, field) => '[' + JSON.stringify(field) + ']');
    const result = new Script(expression).runInNewContext({...context,
      format: (pattern, ...values) => pattern.replace(/\\{(\\d+)\\}/gu, (_, index) => String(values[Number(index)])),
    }, {timeout: 100});
    evaluatedExpressions.set(key, result);
  }
  return evaluatedExpressions.get(key);
};"""
assert text.count(old)==1
p.write_text(text.replace(old,new))
print('Memoized deterministic expression/context evaluations; retained the 100ms VM boundary and 60s test boundary.')
