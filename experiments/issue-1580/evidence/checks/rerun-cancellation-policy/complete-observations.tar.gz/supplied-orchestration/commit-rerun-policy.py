from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
branch=subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()
assert branch=='issue-1580-8d61a32a61e1',branch
tracked=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
new=['experiments/issue-1580/native-rerun-concurrency.test.mjs','changelog.d/20261123_085500_native_rerun_cancellation.md']
assert len(tracked)==50,len(tracked)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--',*tracked,*new],cwd=root,check=True)
subprocess.run(['git','commit','-m','fix: isolate rerun attempts from current CI cancellation groups'],cwd=root,check=True)
print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip())
