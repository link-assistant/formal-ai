from pathlib import Path
import json, subprocess, os, datetime
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/rerun-policy-validation-followup')
out.mkdir(exist_ok=True)
tasks=[
 {'name':'workflow-concurrency','command':['timeout','600','node','--test','--test-concurrency=1','experiments/issue-1580/workflow-concurrency.test.mjs']},
 {'name':'native-workflow-cache-bindings','command':['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/native-workflow-cache-bindings.test.mjs']},
 {'name':'rustfmt','command':['rustfmt','--check','rust/tests/unit/ci-cd/workflow_fixtures.rs','rust/tests/unit/ci-cd/box_language_release_legs.rs']},
 {'name':'workflows-gate','command':['node','experiments/formal_ai_subagent/local-gates.mjs','--only','workflows']},
 {'name':'diff-check','command':['git','diff','--check']}]
worker=out/'worker.py'
worker.write_text('''from pathlib import Path
import subprocess, os, json, datetime
root=Path(%r)
out=Path(%r)
tasks=json.loads((out/'tasks.json').read_text())
env=dict(os.environ)
env.pop('NODE_OPTIONS',None)
results=[]
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
for i,t in enumerate(tasks):
    record=dict(t,startedAt=stamp(),index=i)
    print(json.dumps(dict(event='start',**record)),flush=True)
    with (out/(t['name']+'.log')).open('wb') as log:
        done=subprocess.run(t['command'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    record.update(exitCode=done.returncode,finishedAt=stamp())
    results.append(record)
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\\n')
    print(json.dumps(dict(event='finish',**record)),flush=True)
(out/'outcome.json').write_text(json.dumps(dict(finishedAt=stamp(),total=len(results),failed=[r for r in results if r['exitCode']!=0],results=results),indent=2)+'\\n')
''' % (str(root),str(out)))
(out/'tasks.json').write_text(json.dumps(tasks,indent=2)+'\n')
with (out/'worker.log').open('wb') as log:
    process=subprocess.Popen(['python3',str(worker)],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
receipt=dict(pid=process.pid,startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),tasks=len(tasks),root=str(out))
(out/'started.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
