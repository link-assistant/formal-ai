from pathlib import Path
import subprocess, json, re, datetime, hashlib
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research')
files=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
suffix="${{ (github.event_name != 'pull_request' || github.event.action != 'synchronize') && format('-{0}', github.run_id) || '' }}"
next_suffix="${{ (github.event_name != 'pull_request' || github.event.action != 'synchronize' || github.run_attempt > 1) && format('-{0}-{1}', github.run_id, github.run_attempt) || '' }}"
cancel="${{ github.event_name == 'pull_request' && github.event.action == 'synchronize' }}"
next_cancel="${{ github.event_name == 'pull_request' && github.event.action == 'synchronize' && github.run_attempt == 1 }}"
comments="# Reruns retain their original PR action. A failed-job rerun of an older head\n# must not cancel a newer synchronize run (45136124038, issue #1580).\n"
records=[]
for path in files:
    if not path.startswith('.github/workflows/'): continue
    before=subprocess.check_output(['git','show','HEAD:'+path],cwd=root,text=True)
    after=(root/path).read_text()
    expected=before.replace(suffix,next_suffix).replace(cancel,next_cancel)
    if path=='.github/workflows/native-type-check.yml':
        assert after.count(comments)==1
        after=after.replace(comments,'')
    assert after==expected,path
    assert before.count(suffix)==before.count(cancel),(path,'mismatched policy fields')
    records.append(dict(path=path,changedPolicies=before.count(suffix),sha256=hashlib.sha256((root/path).read_bytes()).hexdigest(),otherWorkflowBytesPreserved=True))
assert len(records)==31,len(records)
report=dict(sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),checkedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),workflows=len(records),policies=sum(r['changedPolicies'] for r in records),records=records)
(out/'rerun-workflow-conservation.json').write_text(json.dumps(report,indent=2)+'\n')
initial=json.loads((out/'rerun-policy-validation/outcome.json').read_text())
followup=json.loads((out/'rerun-policy-validation-followup/outcome.json').read_text())
assert not followup['failed'],followup['failed']
replacements={'test-workflow-concurrency.test':'workflow-concurrency','test-native-workflow-cache-bindings.test':'native-workflow-cache-bindings'}
resolved=[]
for record in initial['results']:
    name=record['name']
    if record['exitCode']:
        assert name in replacements,name
        replacement=next(r for r in followup['results'] if r['name']==replacements[name])
        log=out/'rerun-policy-validation-followup'/(replacement['name']+'.log')
    else:
        replacement=None
        log=out/'rerun-policy-validation'/(name+'.log')
    text=log.read_text(errors='replace')
    tests=re.findall(r'(?:\u2139|#)\s+tests\s+(\d+)',text)
    passed=re.findall(r'(?:\u2139|#)\s+pass\s+(\d+)',text)
    failed=re.findall(r'(?:\u2139|#)\s+fail\s+(\d+)',text)
    row=dict(name=name,initialExitCode=record['exitCode'],finalExitCode=0,correctedInvocation=replacement,log=str(log.relative_to(out)))
    if tests:
        row.update(tests=int(tests[-1]),passed=int(passed[-1]),failed=int(failed[-1]))
        assert row['failed']==0,row
    if name.startswith('gate-'):
        assert re.search(r'^PASS ',text,re.M),name
        row['gateExecuted']=True
    resolved.append(row)
summary=dict(checkedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),allCurrentAffectedChecksPassed=True,initialFailuresRetained=True,workflowPolicies=report['policies'],checks=resolved,followup=followup['results'],independentAuthorshipCredit=0,hostedQualification='pending; initial current native run cancelled by historical rerun')
(out/'rerun-validation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(workflows=report['workflows'],policies=report['policies'],checks=len(resolved),tests=[{k:r[k] for k in ['name','tests','passed','failed']} for r in resolved if 'tests' in r],gates=sum(bool(r.get('gateExecuted')) for r in resolved)),indent=2))
