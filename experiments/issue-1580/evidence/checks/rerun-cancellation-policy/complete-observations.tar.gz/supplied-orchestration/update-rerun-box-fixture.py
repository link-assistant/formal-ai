from pathlib import Path
p=Path('/tmp/gh-issue-solver-1794900398048/rust/tests/unit/ci-cd/box_language_release_legs.rs')
s=p.read_text()
old="github.event.action == 'synchronize' }}"
new="github.event.action == 'synchronize' && github.run_attempt == 1 }}"
assert s.count(old)==1
p.write_text(s.replace(old,new))
print('Updated the actual release job policy assertion in the bounded native CI fixture.')
