from pathlib import Path
import json
root=Path('/tmp/issue-1580-research')
old_group="(github.event_name != 'pull_request' || github.event.action != 'synchronize') && format('-{0}', github.run_id)"
new_group="(github.event_name != 'pull_request' || github.event.action != 'synchronize' || github.run_attempt > 1) && format('-{0}-{1}', github.run_id, github.run_attempt)"
old_cancel="github.event_name == 'pull_request' && github.event.action == 'synchronize'"
new_cancel=old_cancel+" && github.run_attempt == 1"
paths=list(Path('.github/workflows').glob('*.yml'))+[Path('scripts/check-workflow-concurrency.mjs'),Path('rust/tests/unit/ci-cd/workflow_fixtures.rs')]+list(Path('rust/tests/web').glob('*.test.mjs'))
changed=[]
for p in paths:
    before=p.read_text()
    after=before.replace(old_group,new_group)
    after=after.replace(new_cancel,'RERUN_CANCELLATION_ALREADY_REPAIRED').replace(old_cancel,new_cancel).replace('RERUN_CANCELLATION_ALREADY_REPAIRED',new_cancel)
    if before!=after:
        p.write_text(after);changed.append(str(p))
p=Path('scripts/check-workflow-concurrency.mjs')
s=p.read_text().replace('// Only repeated synchronize checks may supersede one another. Keep manual,\n// ready-for-review and push observations independent even for the same SHA.','// Only initial synchronize checks may supersede one another. Reruns retain the\n// original action, so bind their groups to run and attempt before cancellation.')
s=s.replace('check cancellation must be restricted to pull_request synchronize','check cancellation must be restricted to the initial pull_request synchronize attempt')
p.write_text(s)
p=Path('rust/tests/web/fast-pull-request-production-profile.test.mjs')
s=p.read_text().replace('github: {event_name:event,ref,event:', 'github: {event_name:event,ref,run_attempt:1,event:')
p.write_text(s)
p=Path('rust/tests/web/documentation-only-ci-policy.test.mjs')
s=p.read_text().replace('github:{event_name:event,event:{action},ref}', 'github:{event_name:event,event:{action},ref,run_attempt:1}')
p.write_text(s)
p=Path('rust/tests/web/desktop-release-source-attribution.test.mjs')
s=p.read_text().replace('(==|!=|&&|', '(==|!=|>|&&|').replace("'!=':3}","'!=':3,'>':4}")
s=s.replace("op==='=='?left===right:left!==right", "op==='=='?left===right:op==='>'?left>right:left!==right")
s=s.replace("run_id:run,event:{action", "run_id:run,run_attempt:1,event:{action")
p.write_text(s)
p=Path('experiments/issue-1580/workflow-concurrency.test.mjs')
s=p.read_text().replace('context=(event,action,run,shard=1)=>','context=(event,action,run,shard=1,attempt=1)=>').replace("run_id:run,repository:","run_id:run,run_attempt:attempt,repository:")
old="""        const first=context(event,action,10),second=context(event,action,11);
        const allowed=event==='pull_request'&&action==='synchronize',label=file+'/'+scope+'/'+event+'/'+action;
        assert.equal(evaluate(policy['cancel-in-progress'],first),allowed,label+' cancellation');
        assert.equal(template(policy.group,first)===template(policy.group,second),allowed,label+' independent group');"""
new="""        for (const attempt of [1, 2, 3, '2']) {
          const first=context(event,action,10,1,attempt),second=context(event,action,11,1,attempt);
          const allowed=event==='pull_request'&&action==='synchronize'&&Number(attempt)===1;
          const label=file+'/'+scope+'/'+event+'/'+action+'/attempt-'+attempt;
          assert.equal(evaluate(policy['cancel-in-progress'],first),allowed,label+' cancellation');
          assert.equal(template(policy.group,first)===template(policy.group,second),allowed,label+' independent group');
          if (Number(attempt)>1) {
            assert.notEqual(template(policy.group,first),template(policy.group,context(event,action,10)),
              label+' historical rerun must not share the current initial group');
            assert.notEqual(template(policy.group,first),template(policy.group,context(event,action,10,1,4)),
              label+' distinct rerun attempts must not share a group');
          }
        }"""
assert old in s
p.write_text(s.replace(old,new))
Path('changelog.d/20261123_085500_native_rerun_cancellation.md').write_text('''### Fixed

- Keep historical CI reruns separate from current pull request checks, while allowing a newer commit to cancel superseded initial checks.
''')
(root/'rerun-policy-migration.json').write_text(json.dumps({'changed':changed,'rule':'Preserve initial synchronization groups; isolate every replay by run ID and attempt. Serialized writers with cancellation false remain unchanged.','independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps({'changed':changed},indent=2))
