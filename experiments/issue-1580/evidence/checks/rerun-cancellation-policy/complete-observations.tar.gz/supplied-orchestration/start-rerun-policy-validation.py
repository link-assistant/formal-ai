from pathlib import Path
import subprocess, os, json, datetime
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/rerun-policy-validation')
out.mkdir(exist_ok=True)
tests=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
tests=[p for p in tests if p.endswith('.test.mjs')]
for p in ['experiments/issue-1580/native-rerun-concurrency.test.mjs']:
    if p not in tests: tests.append(p)
gates=['workflows','check-file-size','check-readable-code','check-required-documentation','check-tests-as-docs','check-tests-as-documentation-javascript-twin','check-changelog-fragment-js-twin','check-specification-in-javascript','check-ci-speed']
tasks=[{'name':'test-'+Path(p).stem,'command':['timeout','600','node','--test','--test-concurrency=1',p]} for p in tests]
tasks += [{'name':'gate-'+g,'command':['node','experiments/formal_ai_subagent/local-gates.mjs','--only',g]} for g in gates]
tasks += [{'name':'rustfmt-workflow-fixtures','command':['rustfmt','--check','rust/tests/unit/ci-cd/workflow_fixtures.rs']}]
tasks += [{'name':'staged-release-currency','command':['node','scripts/generate-staged-release.mjs','--check-deployed']}]
worker=out/'worker.py'
worker.write_text('''from pathlib import Path
import subprocess, os, json, datetime
root=Path(%r)
out=Path(%r)
tasks=json.loads((out/'tasks.json').read_text())
env=dict(os.environ)
env['NODE_OPTIONS']='--max-old-space-size=256'
results=[]
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
for i,t in enumerate(tasks):
    record=dict(t,startedAt=stamp(),index=i)
    print(json.dumps(dict(event='start',**record)),flush=True)
    with (out/(t['name']+'.log')).open('wb') as log:
        done=subprocess.run(t['command'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    record.update(exitCode=done.returncode,finishedAt=stamp())
    results.append(record)
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\\n')
    print(json.dumps(dict(event='finish',**record)),flush=True)
outcome=dict(finishedAt=stamp(),total=len(results),failed=[r for r in results if r['exitCode']!=0],results=results)
(out/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\\n')
''' % (str(root),str(out)))
(out/'tasks.json').write_text(json.dumps(tasks,indent=2)+'\n')
with (out/'worker.log').open('wb') as log:
    process=subprocess.Popen(['python3',str(worker)],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
receipt=dict(pid=process.pid,startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),tasks=len(tasks),root=str(out))
(out/'started.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
