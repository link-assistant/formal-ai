from pathlib import Path
import gzip, hashlib, json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'lexeme-native-registry-refresh'
assert json.loads((out / 'outcome.json').read_text())['passed']
archive = root / 'experiments/issue-1580/evidence/checks/lexeme-native-registry-refresh'
archive.mkdir(exist_ok=False)
entries = []
inputs = [*[p for p in out.iterdir() if p.is_file() and p.name != 'worker.log'], scratch / 'refresh-lexeme-native-registry.py', scratch / 'refresh-lexeme-native-registry.log', scratch / 'inspect-source-warning-ci-failure.py', scratch / 'inspect-source-warning-ci-failure-refined.log', scratch / 'source-warning-ci-failure-excerpts.txt', Path(__file__)]
for path in sorted(inputs):
    raw = path.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    target = archive / (path.name + '.gz')
    target.write_bytes(packed)
    entries.append({'file': target.name, 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
(archive / 'records.json').write_text(json.dumps({'entries': entries, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
fragment = root / 'changelog.d/issue-1580-computer-use-content.md'
fragment.write_text(fragment.read_text() + '\nRegenerate native constant witnesses after the lexeme module extraction; preserve every generated program value and algorithm.\n')
plan = root / 'experiments/issue-1580/work-plan.md'
plan.write_text(plan.read_text() + '\n- Diagnose current-head Layered CI run 44821502922: aggregate log lines 9711 and 10758–10787 report the generated native registry freshness failure. Reproduce it locally with the unchanged maintained generator --check. Regenerate through the maintained JavaScript generator; compare all 158 programs and prove the only changes are the three lexeme constant owner hashes and source offsets, with identical declaration bytes, values and algorithms. The existing complete generated-program regression and four source gates now pass. This repairs one actionable hosted failure; remaining current-head runs and wider issue acceptance are pending. Independent credit remains zero.\n')
selected = ['scripts/lib/generated-native-programs.mjs', archive.relative_to(root).as_posix(), fragment.relative_to(root).as_posix(), plan.relative_to(root).as_posix()]
def run(name, argv):
    result = subprocess.run(argv, cwd=root, env={**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}, capture_output=True)
    (out / (name + '.stdout')).write_bytes(result.stdout)
    (out / (name + '.stderr')).write_bytes(result.stderr)
    print(name, result.returncode, flush=True)
    assert result.returncode == 0
    return result.stdout.decode()
assert not run('index-before-commit', ['git', 'diff', '--cached', '--name-only']).strip()
run('stage', ['git', 'add', '--', *selected])
paths = []
for relative in selected:
    path = root / relative
    paths.extend(p.relative_to(root).as_posix() for p in sorted(path.rglob('*')) if p.is_file()) if path.is_dir() else paths.append(relative)
run('secrets', ['bash', 'scripts/check-secrets.sh', *paths])
run('whitespace', ['git', 'diff', '--cached', '--check'])
run('commit', ['git', 'commit', '-m', 'fix: refresh native constant witnesses after lexeme extraction'])
head = run('head', ['git', 'rev-parse', 'HEAD']).strip()
(out / 'commit-outcome.json').write_text(json.dumps({'head': head, 'passed': True, 'pushExecuted': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
