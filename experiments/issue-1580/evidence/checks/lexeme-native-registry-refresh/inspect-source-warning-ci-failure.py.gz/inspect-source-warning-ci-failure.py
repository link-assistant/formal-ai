from pathlib import Path
import gzip, json, re

base = Path('/tmp/gh-issue-solver-1794900398048/experiments/issue-1580/evidence/ci/native-families-f8b372ad')
raw = gzip.decompress((base / 'failed-run-44821502922.stdout.gz').read_bytes()).decode()
lines = raw.splitlines()
pattern = re.compile(r'##\[error\]|\bnot ok\b|✖|AssertionError|error\[|ℹ fail [1-9]')
chosen = set()
for index, line in enumerate(lines):
    if pattern.search(line):
        chosen.update(range(max(0, index-2), min(len(lines), index+4)))
rendered = '\n'.join(str(index+1) + ': ' + lines[index] for index in sorted(chosen)) + '\n'
target = Path('/tmp/issue-1580-research/source-warning-ci-failure-excerpts.txt')
target.write_text(rendered)
print(json.dumps({'file': str(base / 'failed-run-44821502922.stdout.gz'), 'sourceLines': len(lines), 'selectedLines': len(chosen), 'excerpts': str(target)}))
