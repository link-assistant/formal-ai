from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'lexeme-native-registry-refresh'
if len(sys.argv) == 1:
    out.mkdir(exist_ok=False)
    with (out / 'worker.log').open('wb') as stream:
        worker = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': worker.pid, 'finiteWorker': True}))
    sys.exit(0)
records = []
def run(name, argv, expected=0):
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=root, env={**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}, stdout=stdout, stderr=stderr)
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == expected, name
    return (out / (name + '.stdout')).read_bytes()

assert json.loads((scratch / 'surface-and-html-helper-extraction/commit-outcome.json').read_text())['passed']
assert not run('index-before', ['git', 'diff', '--cached', '--name-only']).strip()
registry = root / 'scripts/lib/generated-native-programs.mjs'
old_registry = registry.read_bytes()
(out / 'registry-before.mjs.gz').write_bytes(gzip.compress(old_registry, mtime=0))
read_programs = "import {GENERATED_NATIVE_PROGRAMS as programs} from './scripts/lib/generated-native-programs.mjs'; console.log(JSON.stringify(programs));"
before = json.loads(run('programs-before', ['node', '--input-type=module', '-e', read_programs]))
run('reproduce-stale-registry', ['node', 'scripts/lib/generate-native-specification-programs.mjs', '--check'], 1)
assert 'generated registry is stale' in (out / 'reproduce-stale-registry.stderr').read_text()
run('maintained-regeneration', ['node', 'scripts/lib/generate-native-specification-programs.mjs'])
after = json.loads(run('programs-after', ['node', '--input-type=module', '-e', read_programs]))
owner = 'rust/src/lexeme_import.rs'
old_source = run('old-owner-source', ['git', 'show', '9fd9360d88d084aeee109ebf8375cde3cd816ff1:' + owner]).decode()
new_source = (root / owner).read_text()
hash_text = lambda text: hashlib.sha256(text.encode()).hexdigest()
old_hash, new_hash = map(hash_text, [old_source, new_source])
assert len(before) == len(after)
normalized = json.loads(json.dumps(after))
changed = []
for old, new, normalized_new in zip(before, after, normalized):
    assert old['path'] == new['path']
    if old == new:
        continue
    witnesses = [(i, value) for i, value in enumerate(old.get('sourceWitnesses', [])) if value['path'] == owner]
    assert len(witnesses) == 1
    index, witness = witnesses[0]
    assert witness['sha256'] == old_hash
    assert new['sourceWitnesses'][index] == {'path': owner, 'sha256': new_hash}
    normalized_new['sourceWitnesses'][index]['sha256'] = old_hash
    old_span, new_span = old['sourceSpan'], new['sourceSpan']
    old_declaration = old_source[old_span['start']:old_span['end']]
    new_declaration = new_source[new_span['start']:new_span['end']]
    assert old_declaration == new_declaration
    normalized_new['sourceSpan'] = old_span
    changed.append({'path': old['path'], 'oldSourceSpan': old_span, 'newSourceSpan': new_span, 'unchangedDeclarationSha256': hash_text(old_declaration)})
assert normalized == before and len(changed) == 3
assert {row['path'].split('::')[-1] for row in changed} == {'PART_OF_SPEECH', 'GRAMMATICAL_NUMBER', 'DEFINED_BY'}
(out / 'semantic-delta-proof.json').write_text(json.dumps({'observedAt': datetime.now(timezone.utc).isoformat(), 'programCount': len(before), 'owner': owner, 'oldOwnerSha256': old_hash, 'newOwnerSha256': new_hash, 'changed': changed, 'allProgramValuesAndAlgorithmsUnchanged': True, 'completeRegistryEqualsBeforeAfterNormalizingReviewedWitnessesAndSpans': True, 'localRustExecution': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
run('generated-registry-current', ['node', 'scripts/lib/generate-native-specification-programs.mjs', '--check'])
run('generated-registry-regression', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/rust-specification-generated-programs.test.mjs'])
run('source-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code'])
(out / 'outcome.json').write_text(json.dumps({'passed': True, 'programCount': len(before), 'changedPrograms': changed, 'pushExecuted': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
