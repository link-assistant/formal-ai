// Proof requests, weekday reasoning, calendar event creation with its ICS and
// Google Calendar links, and concept rendering.
// Loaded by ../formal_ai_worker.js.
function startsWithProofVerb(normalized, verb) {
  if (!normalized.startsWith(verb)) return false;
  const tail = normalized.slice(verb.length);
  if (!tail) return true;
  return !/[\p{L}\p{N}]/u.test(tail.charAt(0));
}

function hasProofRequestShape(normalized) {
  const text = String(normalized || "").trim();
  if (!text) return false;
  // A proof request is recognised structurally from the meaning lexicon, not
  // from words baked into this file: a clause-initial bare directive verb
  // (proof_directive, with the verb-boundary check), a request-frame lead in any
  // language that needs no `that` clause (proof_request_lead), or a mid-prompt
  // proof assertion marker in any language (proof_marker).
  return (
    bareLiterals(ROLE_PROOF_DIRECTIVE).some((verb) => startsWithProofVerb(text, verb)) ||
    prefixLiterals(ROLE_PROOF_REQUEST_LEAD).some((lead) => text.startsWith(lead)) ||
    lexiconMentionsRoleSubstring(ROLE_PROOF_MARKER, text)
  );
}

function extractProofClaim(normalized) {
  const trimmed = String(normalized || "").trim();
  // The claim scaffolds (each ending in the … slot) come from the
  // proof_claim_scaffold role in declaration order, so the first matching
  // prefix wins exactly as before — every that/что/कि variant is listed ahead
  // of its shorter sibling in the lexicon. Comma variants are absent: the
  // normaliser rewrites the comma to a space, making them unreachable here.
  const prefixes = prefixLiterals(ROLE_PROOF_CLAIM_SCAFFOLD);
  for (const prefix of prefixes) {
    if (trimmed.startsWith(prefix)) {
      return stripProofClaimNoise(trimmed.slice(prefix.length));
    }
  }
  for (const prefix of prefixes) {
    const index = trimmed.indexOf(prefix);
    if (index <= 0) continue;
    const before = trimmed.charAt(index - 1);
    if (isProofIntroBoundary(before)) {
      return stripProofClaimNoise(trimmed.slice(index + prefix.length));
    }
  }
  return trimmed;
}
// Issue #1487: a proof-library keyword only retrieves a theorem; the negation cues around it bind the request to the
// theorem, its negation, or nothing (Rust `proof_engine::claim_binding`, `refuted_negation`).
function proofClaimBinding(claim) {
  const crate = crateModule("crate/theorem_claim_binding.mjs"), text = String(claim || "").toLowerCase(), match = crate.theoremMatch(text);
  return match && { theorem: match.theorem, binding: crate.bindTheoremClaim(text, match.keyword), slugs: crate.ClaimBinding };
}
// A seeded theorem's statement, steps and conclusion in `language` (Rust `proof_engine::library::build_proof`).
function proofLibraryTheoremProof(id, language) {
  const section = parseLinoTree(seedRawText(SEED_RAW, "proof-library.lino")).children.find((child) => child.name === "proof_library");
  const theorem = section && section.children.find((child) => child.name === "theorem" && child.value === id);
  const surface = (name) => { const node = theorem && theorem.children.find((child) => child.name === name); return node ? proofLibrarySurface(node, language) : ""; };
  const steps = theorem ? theorem.children.filter((child) => child.name === "step").map((step) => ({ kind: step.value, text: proofLibrarySurface(step, language) })) : [];
  return { method: theorem ? theorem.children.find((child) => child.name === "method").value : "contradiction", statement: surface("statement"), steps, conclusion: surface("conclusion") };
}
// The theorem's proof is the refutation, never a success for the negated claim: Rust `refuted_negation`, rendered as
// `render_outcome_with_config` renders `ProofOutcome::Disproven` and compacted as `enforce_questions` compacts it, so
// no "Proof (" heading presents the request as proven.
function euclidNegationRefutationBody(language) {
  const proof = proofLibraryTheoremProof("euclid_infinitude_of_primes", language);
  const counterexample = proofLibraryText("negated-theorem-refuted", language, { statement: proof.statement });
  const core = `${proofPresenterMethodLine("disproof_heading", language, proof.method)}\n\n${proofLibraryText("counterexample_label", language)}: ${counterexample}\n\n${proofPresenterSteps(proof.steps, language)}\n${proof.conclusion}`;
  return numberConstraintCompactBody(`${proofPresenterInterpretation(false, proof.statement, language, proof.method)}\n\n${core}\n\n${proofPresenterDisprovenFollowUps(language)}`);
}
// The theorem's proof, rendered as `render_outcome_with_config` renders `ProofOutcome::Proven`; with no question to
// authorize, `enforce_questions` leaves it uncompacted.
function euclidPrimeProofBody(language) {
  const proof = proofLibraryTheoremProof("euclid_infinitude_of_primes", language);
  const core = `${proofPresenterMethodLine("proof_heading", language, proof.method)}\n\n${proofLibraryText("statement_label", language)}: ${proof.statement}\n${proofPresenterSteps(proof.steps, language)}\n${proof.conclusion}`;
  return `${proofPresenterInterpretation(true, proof.statement, language, proof.method)}\n\n${core}`;
}

function genericProofPlanBody(prompt, language) {
  if (language === "ru") {
    return [
      "Как я понял запрос: утверждение нужно доказать, но для финального исполнения не хватает выбранной формальной системы.",
      "",
      "План доказательства (метод: формализация и проверка).",
      "",
      `Утверждение: ${String(prompt || "").trim()}`,
      "1. Зафиксировать систему аксиом, например PA для арифметики, ZFC для теории множеств или конкретную теорию предметной области.",
      "2. Перевести утверждение в закрытую формулу этой системы.",
      "3. Выбрать тактику relative-meta-logic: rewrite, induction, contradiction или поиск контрпримера.",
      "4. Проверить каждый шаг и вернуть либо сертификат доказательства, либо контрпример.",
      "",
      "Чтобы выполнить доказательство полностью, нужен явный набор аксиом и точная формулировка утверждения.",
    ].join("\n");
  }
  if (language === "hi") {
    return [
      "मैंने प्रश्न को कैसे समझा: यह प्रमाण का अनुरोध है, पर अंतिम निष्पादन के लिए चुनी हुई औपचारिक प्रणाली चाहिए।",
      "",
      "प्रमाण योजना (विधि: औपचारिकरण और सत्यापन)।",
      "",
      `कथन: ${String(prompt || "").trim()}`,
      "1. कोई अभिगृहीत प्रणाली चुनें, जैसे arithmetic के लिए PA, set theory के लिए ZFC, या किसी क्षेत्र-विशेष की theory।",
      "2. कथन को उस प्रणाली के बंद सूत्र में अनुवादित करें।",
      "3. relative-meta-logic की tactic चुनें: rewrite, induction, contradiction, या counterexample search।",
      "4. प्रत्येक चरण जाँचें और proof certificate या counterexample लौटाएँ।",
      "",
      "प्रमाण पूरा करने के लिए सटीक axiom set और closed statement चाहिए।",
    ].join("\n");
  }
  if (language === "zh") {
    return [
      "对问题的理解: 该提示要求证明, 但最终执行需要选定的形式系统。",
      "",
      "证明计划 (方法: 形式化与验证)。",
      "",
      `命题: ${String(prompt || "").trim()}`,
      "1. 固定一个公理系统, 例如 arithmetic 用 PA, set theory 用 ZFC, 或某个领域专用理论。",
      "2. 将命题翻译成该系统中的闭公式。",
      "3. 选择 relative-meta-logic 策略: rewrite、induction、contradiction 或 counterexample search。",
      "4. 检查每一步, 并返回证明证书或反例。",
      "",
      "要完成证明, 需要精确的 axiom set 和 closed statement。",
    ].join("\n");
  }
  return [
    "How I interpreted the request: the prompt asks for a proof, but final execution needs a chosen formal system.",
    "",
    "Proof plan (method: formalization and verification).",
    "",
    `Statement: ${String(prompt || "").trim()}`,
    "1. Fix an axiom system, for example PA for arithmetic, ZFC for set theory, or a domain-specific theory.",
    "2. Translate the claim into a closed formula in that system.",
    "3. Choose a relative-meta-logic tactic: rewrite, induction, contradiction, or counterexample search.",
    "4. Check each step and return either a proof certificate or a counterexample.",
    "",
    "To finish the proof, provide the exact axiom set and a closed statement.",
  ].join("\n");
}

function tryProofRequest(prompt, normalized, language) {
  const lead = splitLeadingGreetingCompoundPrompt(prompt);
  if (lead && isGreetingPrompt(normalizePrompt(lead.greeting), lead.greeting)) normalized = normalizePrompt(lead.remainder);
  if (!hasProofRequestShape(normalized)) return null;
  const claim = extractProofClaim(normalized);
  const bound = proofClaimBinding(claim), bindingEvidence = bound ? [`proof_binding:${bound.binding}`] : [];
  const refuted = Boolean(bound) && bound.binding === bound.slugs.Negated && bound.theorem.refutesNegation;
  if (bound && bound.theorem.id === "euclid_infinitude_of_primes" && (refuted || bound.binding === bound.slugs.Affirmed)) {
    return {
      intent: "proof_request",
      content: refuted ? euclidNegationRefutationBody(language) : euclidPrimeProofBody(language),
      confidence: 0.85,
      evidence: ["policy:proof_request", "pipeline:planned:relative-meta-logic", ...bindingEvidence,
        refuted ? "proof_outcome:disproven" : "proof_outcome:proven", "proof_method:contradiction", `language:${language}`],
    };
  }
  return {
    intent: "proof_request",
    content: genericProofPlanBody(prompt, language),
    confidence: 0.6,
    evidence: [
      "policy:proof_request",
      "pipeline:planned:relative-meta-logic",
      ...bindingEvidence,
      "proof_outcome:partial_plan",
      `language:${language}`,
    ].concat(claimEvidenceStatedClaim(claim) ? [] : ["proof_request:refusal:no stated claim"]), // #1175 R3
  };
}

// WEEKDAY_CYCLE is the seven-day cycle by slug. Issue #386: the recognition
// words live as the `calendar_*` meanings of data/seed/meanings-calendar.lino;
// issue #918: the names an answer prints, with the Russian case each
// direction phrase takes, are the `calendar_weekday_label` table of
// data/seed/handler-rules.lino. Mirrors src/solver_handlers/calendar.rs.
const WEEKDAY_CYCLE = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
  .map((slug) => ({ slug }));

/**
 * The weekday's name in `form` (a language, or a language and direction such
 * as `ru.next`), or null (Rust `Weekday::label`).
 * @param {{slug: string}} weekday
 * @param {string} form
 * @returns {string|null}
 */
function calendarWeekdayForm(weekday, form) {
  return handlerRulesTableValue("calendar_weekday_label", `${weekday.slug}.${form}`);
}

/** The weekday's plain name in `language`, else English (Rust `weekday_label`). */
function calendarWeekdayLabel(language, weekday) {
  return calendarWeekdayForm(weekday, language) || calendarWeekdayForm(weekday, "en") || weekday.slug;
}

/** The weekday in the case its direction phrase takes (Rust `weekday_direction_label`). */
function calendarWeekdayDirectionLabel(language, operation, weekday) {
  return calendarWeekdayForm(weekday, `${language}.${operation}`) || calendarWeekdayLabel(language, weekday);
}

/**
 * The seeded template of `intent` in `language`, else the English one, with
 * the language its weekday names take (Rust `template_for`).
 * @returns {{language: string, template: string}}
 */
function calendarTemplateFor(intent, language) {
  const own = handlerRulesResponseFor(intent, language);
  return own ? { language, template: own } : { language: "en", template: handlerRulesResponseFor(intent, "en") || "" };
}

function hasCalendarCjkCharacter(term) {
  return /[\u4e00-\u9fff]/u.test(term);
}

function isCalendarWordCharacter(character) {
  return /[\p{L}\p{N}_]/u.test(character);
}

function containsCalendarTerm(text, term) {
  if (hasCalendarCjkCharacter(term)) {
    return String(text || "").includes(term);
  }
  let index = String(text || "").indexOf(term);
  while (index !== -1) {
    const before = index > 0 ? Array.from(text.slice(0, index)).pop() : "";
    const after = Array.from(text.slice(index + term.length))[0] || "";
    if (
      (!before || !isCalendarWordCharacter(before)) &&
      (!after || !isCalendarWordCharacter(after))
    ) {
      return true;
    }
    index = text.indexOf(term, index + term.length);
  }
  return false;
}

// Issue #386: calendar recognition is driven entirely by the self-describing
// `calendar_*` meanings (see data/seed/meanings-calendar.lino, embedded in
// MEANINGS_LINO). day-reference / today / weekday words match with the
// boundary-aware containsCalendarTerm; direction and question words match as
// loose substrings (parity with raw `str::contains` in calendar.rs). The
// boundary vs. substring split per role mirrors the Rust handler exactly.
function mentionsWeekdayContext(normalized) {
  return wordsForRole(ROLE_CALENDAR_DAY_REFERENCE).some((word) =>
    containsCalendarTerm(normalized, word),
  );
}

function mentionsCurrentDayQuestion(normalized) {
  const mentionsToday = wordsForRole(ROLE_CALENDAR_TODAY).some((word) =>
    containsCalendarTerm(normalized, word),
  );
  if (!mentionsToday) return false;
  const asksForDay = wordsForRole(ROLE_CALENDAR_DAY_REFERENCE).some((word) =>
    containsCalendarTerm(normalized, word),
  );
  const questionLike = wordsForRole(ROLE_CALENDAR_QUESTION).some((word) =>
    normalized.includes(word),
  );
  return asksForDay && questionLike;
}

function detectWeekdayOperation(normalized) {
  const hasNext = wordsForRole(ROLE_CALENDAR_DIRECTION_NEXT).some((marker) =>
    normalized.includes(marker),
  );
  const hasPrevious = wordsForRole(ROLE_CALENDAR_DIRECTION_PREVIOUS).some(
    (marker) => normalized.includes(marker),
  );
  if (hasNext && !hasPrevious) return "next";
  if (hasPrevious && !hasNext) return "previous";
  return null;
}

function detectWeekday(normalized) {
  for (const meaning of meaningsWithRole(ROLE_CALENDAR_WEEKDAY)) {
    if (meaning.words.some((word) => containsCalendarTerm(normalized, word))) {
      const entry = WEEKDAY_CYCLE.find((weekday) => weekday.slug === meaning.slug);
      if (entry) return entry;
    }
  }
  return null;
}

function shiftWeekday(weekday, operation) {
  const index = WEEKDAY_CYCLE.indexOf(weekday);
  const offset = operation === "next" ? 1 : -1;
  return WEEKDAY_CYCLE[(index + offset + WEEKDAY_CYCLE.length) % WEEKDAY_CYCLE.length];
}

function validCalendarTimeZone(candidate) {
  const timeZone = cleanContextValue(candidate);
  if (!timeZone) return "";
  try {
    new Intl.DateTimeFormat("en-US", { timeZone }).format(new Date(0));
    return timeZone;
  } catch (_error) {
    return "";
  }
}

function resolvedCalendarTimeZone(userContext) {
  const fromContext = validCalendarTimeZone(userContext && userContext.timeZone);
  if (fromContext) return fromContext;
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "";
  } catch (_error) {
    return "";
  }
}

function calendarDateInTimeZone(date, timeZone) {
  const options = {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  };
  if (timeZone) options.timeZone = timeZone;
  const parts = new Intl.DateTimeFormat("en-CA", options).formatToParts(date);
  const value = (type) => parts.find((part) => part.type === type)?.value || "";
  const year = Number(value("year"));
  const month = Number(value("month"));
  const day = Number(value("day"));
  if (!Number.isFinite(year) || !Number.isFinite(month) || !Number.isFinite(day)) {
    return null;
  }
  const iso = `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
  const dayIndex = new Date(Date.UTC(year, month - 1, day)).getUTCDay();
  const weekday = WEEKDAY_CYCLE[(dayIndex + 6) % 7];
  return { iso, weekday };
}

function currentCalendarDate(userContext) {
  const reference = new Date();
  const timeZone = resolvedCalendarTimeZone(userContext);
  return {
    timeZone: timeZone || "local",
    date: calendarDateInTimeZone(reference, timeZone),
  };
}

function renderCurrentDay(language, weekday, isoDate, timeZone) {
  const own = calendarTemplateFor("calendar_current_day", language);
  return handlerRulesFillOnce(own.template, {
    weekday: calendarWeekdayLabel(own.language, weekday),
    date: isoDate,
    time_zone: timeZone,
  });
}

function renderWeekdayRelation(language, operation, source, result) {
  const own = calendarTemplateFor(`calendar_weekday_relation_${operation}`, language);
  return handlerRulesFillOnce(own.template, {
    source: calendarWeekdayDirectionLabel(own.language, operation, source),
    result: calendarWeekdayLabel(own.language, result),
    source_plain: calendarWeekdayLabel(own.language, source),
    delta: operation === "next" ? "+1" : "-1",
  });
}

// --- Issue #404: tryCalendarCreateEvent (full parallel of Rust try_calendar_create_event).
// Must be defined before tryCalendarReasoning. All recognition uses wordsForRole(ROLE_*)
// + containsCalendarTerm (or the documented loose includes for directions/questions/fallbacks)
// exactly like mentionsWeekdayContext etc. Base date for rollover uses a UTC mirror of
// Rust current_utc_date (create does not inherit the browser userContext tz used only by
// the "today" path). Returns the same {intent, content, confidence, evidence} shape.
function calendarCreateRequestSpan(text) {
  const cues = (handlerRulesTables()["calendar-request-cue"]?.rows || []);
  const candidates = unitConversionClauses(text.toLowerCase()).filter(clause => {
    const normalized = normalizePrompt(clause);
    const anchor = wordsForRole(ROLE_CALENDAR_RELATIVE_DATE).some(w => containsCalendarTerm(normalized, w)) ||
      wordsForRole(ROLE_CALENDAR_WEEKDAY).some(w => containsCalendarTerm(normalized, w)) ||
      extractClockTime(normalized) !== null ||
      wordsForRole(ROLE_CALENDAR_TIME).some(w => containsCalendarTerm(normalized, w)) ||
      wordsForRole(ROLE_CALENDAR_DAY_REFERENCE).some(w => {
        const at = normalized.indexOf(w);
        return at >= 0 && /[0-9]+\s*$/u.test(normalized.slice(0, at));
      });
    if (!anchor) return false;
    let request = clause;
    const prefix = cues.find(([word, position]) => position === "prefix" && request.startsWith(word) && containsCalendarTerm(request, word));
    if (prefix) request = request.slice(prefix[0].length).replace(/^[,，]\s*/u, "").trimStart();
    const dateLed = /^[0-9]/u.test(request) || [ROLE_CALENDAR_RELATIVE_DATE, ROLE_CALENDAR_WEEKDAY]
      .some(role => wordsForRole(role).some(word => request.startsWith(word) && containsCalendarTerm(request, word)));
    const action = cues.some(([word, position]) => {
      const tail = request.slice(word.length).trimStart();
      const starts = request.startsWith(word) && containsCalendarTerm(request, word) && !/^[:：]/u.test(tail) &&
        !cues.some(([fact, mode]) => mode === "fact" && tail.startsWith(fact) && containsCalendarTerm(tail, fact));
      const article = cues.find(([lead, mode]) => mode === "object-prefix" && tail.startsWith(lead) && containsCalendarTerm(tail, lead));
      const object = article ? tail.slice(article[0].length).trimStart() : tail;
      const eventObject = position === "object" && starts && wordsForRole(ROLE_CALENDAR_EVENT).some(event => object.startsWith(event) && containsCalendarTerm(object, event));
      return position === "object" ? starts && eventObject : position === "start" ? starts : position === "date" ? starts || (dateLed && containsCalendarTerm(request, word)) :
        position === "end" && request.endsWith(word) && containsCalendarTerm(request, word);
    });
    return action || (prefix && extractClockTime(normalized) !== null && resolveTimezone(normalized) !== null && extractParticipantTitle(normalized) !== null);
  });
  return candidates.length === 1 ? candidates[0] : null;
}

function mentionsCalendarCreateRequest(text) {
  return calendarCreateRequestSpan(text) !== null;
}

function extractDayNumber(normalized) {
  for (const word of wordsForRole(ROLE_CALENDAR_DAY_REFERENCE)) {
    if (!containsCalendarTerm(normalized, word)) continue;
    const pos = normalized.indexOf(word);
    if (pos !== -1) {
      const prefix = normalized.slice(0, pos).trimEnd();
      let digits = "";
      for (let i = prefix.length - 1; i >= 0; i--) {
        const ch = prefix[i];
        if (/\d/.test(ch)) digits = ch + digits;
        else break;
      }
      const n = parseInt(digits, 10);
      if (n >= 1 && n <= 31) return n;
    }
  }
  // bare leading number
  let num = "";
  for (const ch of normalized.trimStart()) {
    if (/\d/.test(ch)) num += ch;
    else if (num) break;
    else return null;
  }
  const suffix = normalized.trimStart().slice(num.length).trimStart();
  if (unitMentions(suffix).some(mention => mention.position === 0)) return null;
  const n = parseInt(num, 10);
  if (n >= 1 && n <= 31) return n;
  return null;
}

function computeTargetDateWithRollover(base, day) {
  let y = base.year,
    m = base.month,
    d = day;
  if (d < base.day) {
    m += 1;
    if (m > 12) {
      m = 1;
      y += 1;
    }
  }
  const maxDay = m === 2 ? 28 : [4, 6, 9, 11].includes(m) ? 30 : 31;
  if (d > maxDay) d = maxDay;
  return [y, m, d];
}

// Resolve a relative-date word to a whole-day offset from today. The surfaces
// and their languages live in data/seed/meanings-calendar.lino; this code knows
// only the role and the stable English meaning slugs that name the offset
// (calendar_tomorrow → +1 day, calendar_day_after_tomorrow → +2 days). Mirrors
// the Rust relative_date_offset (issue #435).
function relativeDateOffset(normalized) {
  for (const meaning of meaningsWithRole(ROLE_CALENDAR_RELATIVE_DATE)) {
    const matches = meaning.words.some((word) =>
      containsCalendarTerm(normalized, word),
    );
    if (!matches) continue;
    if (meaning.slug === "calendar_tomorrow") return 1;
    if (meaning.slug === "calendar_day_after_tomorrow") return 2;
    return null;
  }
  return null;
}

// Apply a whole-day offset to a {year, month, day} base via UTC date math.
// Mirrors date_from_unix_days(base.days_since_unix_epoch + offset) in Rust.
function offsetCalendarDate(base, offset) {
  const d = new Date(Date.UTC(base.year, base.month - 1, base.day + offset));
  return [d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate()];
}

// Fallback title built from the matched event noun ("созвон" → "Созвон",
// "meeting" → "Meeting") when no explicit "на <subject>" / "for <subject>"
// phrase was given. Mirrors the Rust extract_event_title (issue #435).
function extractEventTitle(normalized) {
  for (const word of wordsForRole(ROLE_CALENDAR_EVENT)) {
    if (containsCalendarTerm(normalized, word)) return capitalizeFirst(word);
  }
  return null;
}

function extractClockTime(normalized) {
  const bytes = normalized.split("");
  for (let i = 0; i < bytes.length - 2; i++) {
    if (/\d/.test(bytes[i]) && /\d/.test(bytes[i + 1])) {
      let h = parseInt(bytes[i] + bytes[i + 1], 10);
      let j = i + 2;
      if (j < bytes.length && (bytes[j] === ":" || bytes[j] === ".")) j++;
      if (j + 1 < bytes.length && /\d/.test(bytes[j]) && /\d/.test(bytes[j + 1])) {
        const min = parseInt(bytes[j] + bytes[j + 1], 10);
        if (h <= 23 && min <= 59) {
          if (h === 0) h = 0;
          if (h === 24) h = 0;
          return [h, min];
        }
      }
    }
  }
  const spoken = extractSpokenHourTime(normalized);
  if (spoken) return spoken;
  for (const lead of handlerRulesTableKeys("calendar_clock_hour_lead")) {
    const leadPos = normalized.indexOf(lead);
    if (leadPos === -1) continue;
    const tail = normalized.slice(leadPos + lead.length);
    let num = "";
    for (const ch of tail) {
      if (/\d/.test(ch)) num += ch;
      else if (num) break;
    }
    const h = parseInt(num, 10);
    if (h <= 23) return [h, 0];
  }
  return null;
}

function extractSpokenHourTime(normalized) {
  for (const marker of handlerRulesTableKeys("calendar_spoken_hour_marker")) {
    let pos = normalized.indexOf(marker);
    while (pos !== -1) {
      const before = pos > 0 ? Array.from(normalized.slice(0, pos)).pop() : "";
      const after = Array.from(normalized.slice(pos + marker.length))[0] || "";
      if (
        (!before || !isCalendarWordCharacter(before)) &&
        (!after || !isCalendarWordCharacter(after))
      ) {
        const prefixEnd = normalized.slice(0, pos).trimEnd().length;
        let start = prefixEnd;
        while (start > 0 && /\d/.test(normalized[start - 1])) {
          start -= 1;
        }
        if (
          start !== prefixEnd &&
          hasSpokenHourPrefix(normalized, start)
        ) {
          const hour = parseInt(normalized.slice(start, prefixEnd), 10);
          if (hour >= 0 && hour <= 23) return [hour, 0];
        }
      }
      pos = normalized.indexOf(marker, pos + marker.length);
    }
  }
  return null;
}

function hasSpokenHourPrefix(normalized, digitStart) {
  const prefix = normalized.slice(0, digitStart).trimEnd();
  if (!prefix) return true;
  const words = prefix.split(/\s+/).filter(Boolean);
  const last = words[words.length - 1];
  return handlerRulesTableKeys("calendar_spoken_hour_lead").includes(last);
}

// Plan 10 leaf 16 (issue #869): the zone is not a memorized alias table. A
// place mention resolves through the entity registry's `timezone` fields —
// the same seed the Rust solver reads — with the same exact / CJK-compound /
// one-edit-per-eight-characters match `suggestNameCorrection` corrects
// remembered names with, so "по Грузии" and "по Берлину" resolve in the
// browser too. A place the registry does not ground resolves to null and the
// caller records the default zone it used instead.
function resolveTimezonePlace(normalized) {
  const prompt = normalizeEntityName(normalized);
  const tokens = prompt.split(/\s+/).filter(Boolean);
  let best = null;
  for (const place of timezonePlaces()) {
    for (const surface of place.surfaces) {
      const candidate = normalizeEntityName(surface);
      if (!candidate) continue;
      let mentioned;
      if (candidate.indexOf(" ") !== -1) {
        mentioned = prompt.indexOf(candidate) !== -1;
      } else {
        mentioned = tokens.some(
          (token) =>
            token === candidate ||
            token.indexOf(candidate) !== -1 ||
            editDistance(token, candidate) <=
              Math.max(1, Math.floor(Array.from(candidate).length / 8)),
        );
      }
      if (mentioned && (!best || Array.from(surface).length > Array.from(best.surface).length)) {
        best = { slug: place.slug, zone: place.zone, surface };
      }
    }
  }
  return best;
}

function resolveTimezone(normalized) {
  const place = resolveTimezonePlace(normalized);
  return place ? place.zone : null;
}

function defaultTitle(language) {
  return handlerRulesTableValue("calendar_default_title", language) || "";
}

function capitalizeFirst(value) {
  if (!value) return value;
  return value.charAt(0).toUpperCase() + value.slice(1);
}

// Trim a candidate title down to its subject: stop at the first time/date/zone
// boundary, sentence punctuation, or day number, then capitalize. Mirrors the
// Rust tidy_title.
function tidyTitle(candidate) {
  let end = candidate.length;
  for (const boundary of handlerRulesTableKeys("calendar_title_boundary")) {
    const pos = candidate.indexOf(boundary);
    if (pos !== -1) end = Math.min(end, pos);
  }
  const punct = candidate.search(/[.!?,]/);
  if (punct !== -1) end = Math.min(end, punct);
  const digit = candidate.search(/\d/);
  if (digit !== -1) end = Math.min(end, digit);
  const trimmed = stripActionWords(candidate.slice(0, end).trim()).trim();
  if (!trimmed) return null;
  if (handlerRulesTableKeys("calendar_title_stopword").includes(trimmed)) {
    return null;
  }
  // A bare relative-date word ("завтра", "tomorrow", …) is a date cue, never a
  // title — reject it so the caller falls back to the event noun (issue #435).
  if (
    wordsForRole(ROLE_CALENDAR_RELATIVE_DATE).some(
      (word) => word.toLowerCase() === trimmed.toLowerCase(),
    )
  )
    return null;
  return capitalizeFirst(trimmed);
}

// Remove schedule-action verb fragments that can trail (Hindi is verb-final)
// or lead (Chinese has no word spaces) the subject so the .ics SUMMARY keeps
// only the event and its participant. Mirrors the Rust strip_action_words.
function stripActionWords(value) {
  let out = value;
  for (const fragment of handlerRulesTableKeys("calendar_title_action_fragment")) {
    out = out.split(fragment).join("");
  }
  return out.split(/\s+/).filter(Boolean).join(" ");
}

function extractTitle(normalized) {
  for (const marker of handlerRulesTableKeys("calendar_title_marker")) {
    const pos = normalized.indexOf(marker);
    if (pos !== -1) {
      const rest = normalized.slice(pos + marker.length).trim();
      const title = tidyTitle(rest);
      if (title) return title;
    }
  }
  const participantTitle = extractParticipantTitle(normalized);
  if (participantTitle) return participantTitle;
  for (const verb of handlerRulesTableKeys("calendar_title_verb")) {
    const pos = normalized.indexOf(verb);
    if (pos !== -1) {
      const rest = normalized.slice(pos + verb.length).trimStart();
      const title = tidyTitle(rest);
      if (title && title.length < 60) return title;
    }
  }
  return null;
}

function extractParticipantTitle(normalized) {
  let start = null;
  for (const marker of handlerRulesTableKeys("calendar_participant_marker")) {
    const inner = normalized.indexOf(` ${marker}`);
    if (inner !== -1) start = inner + 1;
    else if (normalized.startsWith(marker)) start = 0;
    if (start !== null) break;
  }
  if (start === null) return null;
  return tidyTitle(normalized.slice(start));
}

// --- Real, portable calendar artifacts (parity with Rust ScheduledEvent). ---

function pad2(value) {
  return String(value).padStart(2, "0");
}

function pad4(value) {
  return String(value).padStart(4, "0");
}

function isoDate(year, month, day) {
  return `${pad4(year)}-${pad2(month)}-${pad2(day)}`;
}

function startStamp(year, month, day, hour, minute) {
  return `${pad4(year)}${pad2(month)}${pad2(day)}T${pad2(hour)}${pad2(minute)}00`;
}

function daysInMonth(year, month) {
  if (month === 2) {
    return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0) ? 29 : 28;
  }
  return [4, 6, 9, 11].includes(month) ? 30 : 31;
}

function addMinutes(year, month, day, hour, minute, minutes) {
  const total = hour * 60 + minute + minutes;
  let dayCarry = Math.floor(total / (24 * 60));
  const newMinute = total % 60;
  const newHour = Math.floor(total / 60) % 24;
  let y = year,
    m = month,
    d = day;
  while (dayCarry > 0) {
    if (d < daysInMonth(y, m)) {
      d += 1;
    } else {
      d = 1;
      m += 1;
      if (m > 12) {
        m = 1;
        y += 1;
      }
    }
    dayCarry -= 1;
  }
  return [y, m, d, newHour, newMinute];
}

function icsEscape(value) {
  return value
    .replace(/\\/g, "\\\\")
    .replace(/;/g, "\\;")
    .replace(/,/g, "\\,")
    .replace(/\n/g, "\\n");
}

function icsDtstamp() {
  const d = new Date();
  return (
    `${pad4(d.getUTCFullYear())}${pad2(d.getUTCMonth() + 1)}${pad2(d.getUTCDate())}` +
    `T${pad2(d.getUTCHours())}${pad2(d.getUTCMinutes())}${pad2(d.getUTCSeconds())}Z`
  );
}

function buildIcs(event) {
  const start = startStamp(event.year, event.month, event.day, event.hour, event.minute);
  const [ey, em, ed, eh, emin] = addMinutes(
    event.year,
    event.month,
    event.day,
    event.hour,
    event.minute,
    event.durationMinutes,
  );
  const end = startStamp(ey, em, ed, eh, emin);
  const uid = `${start}-${event.timeZone}@formal-ai`;
  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//formal-ai//calendar//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    "BEGIN:VEVENT",
    `UID:${uid}`,
    `DTSTAMP:${icsDtstamp()}`,
    `DTSTART;TZID=${event.timeZone}:${start}`,
    `DTEND;TZID=${event.timeZone}:${end}`,
    `SUMMARY:${icsEscape(event.title)}`,
    "END:VEVENT",
    "END:VCALENDAR",
  ];
  return lines.join("\r\n") + "\r\n";
}

function buildGoogleCalendarUrl(event) {
  const start = startStamp(event.year, event.month, event.day, event.hour, event.minute);
  const [ey, em, ed, eh, emin] = addMinutes(
    event.year,
    event.month,
    event.day,
    event.hour,
    event.minute,
    event.durationMinutes,
  );
  const end = startStamp(ey, em, ed, eh, emin);
  return (
    "https://calendar.google.com/calendar/render?action=TEMPLATE" +
    `&text=${encodeURIComponent(event.title)}` +
    `&dates=${start}/${end}` +
    `&ctz=${encodeURIComponent(event.timeZone)}`
  );
}

function renderCreateConfirmation(language, event, ics, googleUrl) {
  // The seeded confirmation (issue #918), as Rust render_localized_once reads it.
  return handlerRulesFillOnce(answerFor("calendar_create_event_confirmation", language), {
    title: event.title,
    day: String(event.day),
    date: isoDate(event.year, event.month, event.day),
    time: `${pad2(event.hour)}:${pad2(event.minute)}`,
    time_zone: event.timeZone,
    minutes: String(event.durationMinutes),
    ics,
    google_url: googleUrl,
  });
}

function currentUtcCalendarBase() {
  const d = new Date();
  return { year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate() };
}

function tryCalendarCreateEvent(prompt, normalized, userContext = {}) {
  const span = calendarCreateRequestSpan(prompt);
  if (span === null) return null;
  normalized = normalizePrompt(span);
  const base = currentUtcCalendarBase();
  const language = detectLanguage(prompt);
  // A relative-date word ("завтра", "tomorrow", "послезавтра", …) anchors the
  // event to a day offset from today (issue #435). It takes priority over a
  // bare day number so "поставь созвон на завтра" lands on tomorrow rather
  // than today's date.
  const relativeOffset = relativeDateOffset(normalized);
  let year, month, d;
  if (relativeOffset !== null) {
    [year, month, d] = offsetCalendarDate(base, relativeOffset);
  } else {
    const day = extractDayNumber(normalized) || base.day;
    [year, month, d] = computeTargetDateWithRollover(base, day);
  }
  const [hour, minute] = extractClockTime(normalized) || [17, 0];
  const place = resolveTimezonePlace(normalized);
  const tz = place ? place.zone : "UTC";
  const timezoneOrigin = place
    ? `entity:${place.slug}:${place.surface}`
    : "default_utc_no_grounded_place";
  // Prefer an explicit "на <subject>" / "for <subject>" title; otherwise fall
  // back to the matched event noun ("созвон" → "Созвон") before the localized
  // default, so a title-less request still proposes a meaningful event.
  const title =
    extractTitle(normalized) ||
    extractEventTitle(normalized) ||
    defaultTitle(language);
  const event = {
    title,
    year,
    month,
    day: d,
    hour,
    minute,
    timeZone: tz,
    durationMinutes: 60,
  };
  const ics = buildIcs(event);
  const googleUrl = buildGoogleCalendarUrl(event);
  const body = renderCreateConfirmation(language, event, ics, googleUrl);
  const evidence = [
    "calendar:clock:browser",
    `calendar:intent_span:${span}`,
    `calendar:parsed_date:${isoDate(year, month, d)}`,
    `calendar:parsed_time:${pad2(hour)}:${pad2(minute)}`,
    `calendar:parsed_time_zone:${tz}`,
    `calendar:timezone_origin:${timezoneOrigin}`,
    `calendar:parsed_title:${title}`,
    `calendar:parsed_duration_minutes:${event.durationMinutes}`,
  ];
  if (relativeOffset !== null) {
    evidence.push(`calendar:parsed_relative_offset:${relativeOffset}`);
  }
  if (handlerRulesTableRow("calendar_day_number_marker", normalized) !== null) {
    evidence.push("calendar:parsed_via:day_number");
  }
  evidence.push(`calendar:ics:${ics}`);
  evidence.push(`calendar:google_calendar_url:${googleUrl}`);
  evidence.push(`language:${language}`);
  return {
    intent: "calendar_create_event",
    content: body,
    confidence: 0.95,
    evidence,
  };
}

function tryCalendarReasoning(prompt, normalized, userContext = {}) {
  // Calendar create/schedule (issue #404) must be attempted before the weekday-relation
  // gate (and before the current-day question) so that "18 число ... забей / поставь"
  // claims are handled by the action path and do not fall through to the existing
  // weekday-only logic. Mirrors src/solver_handlers/calendar.rs exactly.
  const create = tryCalendarCreateEvent(prompt, normalized, userContext);
  if (create) return create;
  if (mentionsCurrentDayQuestion(normalized)) {
    const language = detectLanguage(prompt);
    const resolved = currentCalendarDate(userContext);
    if (!resolved.date) return null;
    return {
      intent: "calendar_current_day",
      content: renderCurrentDay(
        language,
        resolved.date.weekday,
        resolved.date.iso,
        resolved.timeZone,
      ),
      confidence: 1.0,
      evidence: [
        "calendar:clock:browser",
        `calendar:today:${resolved.date.iso}`,
        `calendar:weekday:${resolved.date.weekday.slug}`,
        `calendar:time_zone:${resolved.timeZone}`,
        `language:${language}`,
      ],
    };
  }
  // Issue #1176: month offsets are read before the weekday gate (calendar.rs).
  const duration = tryCalendarDuration(prompt);
  if (duration) return duration;
  const monthOffset = tryCalendarMonthOffset(prompt, normalized);
  if (monthOffset) return monthOffset;
  // R1017: the weekday of a stated date (calendar/date_weekday.rs).
  const dateOffset = tryCalendarDateOffset(prompt, normalized);
  if (dateOffset !== null) {
    dateOffset.solverEvents = dateOffset.evidence.filter(link => link.startsWith("calendar:")).map(link => {
      const at = link.indexOf(":", 9);
      return {kind:link.slice(0, at), payload:link.slice(at + 1)};
    });
    return dateOffset;
  }
  const dateWeekday = tryCalendarDateWeekday(prompt, normalized);
  if (dateWeekday) return dateWeekday;
  if (!mentionsWeekdayContext(normalized)) return null;
  const operation = detectWeekdayOperation(normalized);
  if (!operation) return null;
  const source = detectWeekday(normalized);
  if (!source) return null;
  const language = detectLanguage(prompt);
  // Issue #1176: read the offset the prompt states ("100 days after", "2 weeks
  // before") instead of always shifting by one; a bare "the day after X"
  // states no offset and keeps the ±1 reading (detect_offset in calendar.rs).
  const offset = detectCalendarOffset(normalized, language);
  const sign = operation === "next" ? 1 : -1;
  const signed = offset ? sign * offset.total : sign;
  const result = offset ? shiftWeekdayBy(source, signed) : shiftWeekday(source, operation);
  const evidence = [
    "calendar:cycle:monday,tuesday,wednesday,thursday,friday,saturday,sunday",
    `calendar:subject_weekday:${source.slug}`,
    `calendar:operation:${operation}:${source.slug}`,
  ];
  if (offset) {
    const total = Math.abs(signed);
    evidence.push(`calendar:offset:${signed >= 0 ? "+" : ""}${signed}d`);
    evidence.push(
      `calendar:offset_derivation:${total}d = ${Math.floor(total / 7)}w + ${total % 7}d`,
    );
  }
  evidence.push(`calendar:result_weekday:${result.slug}`);
  evidence.push(`language:${language}`);
  const offsetAnswer = offset && offset.total > 1
    ? renderCalendarOffsetAnswer(language, operation, source, result, offset)
    : null;
  return {
    intent: "calendar_weekday_relation",
    content: offsetAnswer || renderWeekdayRelation(language, operation, source, result),
    confidence: 1.0,
    evidence,
  };
}

function renderConceptInContext(language, context, record) {
  const contextNormalized = normalizeConceptTerm(context);
  const contextRecord = resolveContextRecord(contextNormalized);
  const contextLabel =
    (contextRecord && contextLabelFor(contextRecord, language)) || context;
  const sameAsLabel =
    String(contextLabel).trim().toLowerCase() ===
    String(context).trim().toLowerCase();
  const intentVariant = sameAsLabel
    ? "concept_lookup_in_context_no_alias"
    : "concept_lookup_in_context";
  const variantTable = MULTILINGUAL_ANSWERS[intentVariant] || {};
  const baseTable = MULTILINGUAL_ANSWERS.concept_lookup_in_context || {};
  const templateEntry =
    variantTable[language] ||
    variantTable.en ||
    baseTable[language] ||
    baseTable.en ||
    null;
  const template = templateEntry
    ? (typeof templateEntry === "string" ? templateEntry : templateEntry.text)
    : "In the context of {context} ({context_label}), {term} ({category}) means: {summary}\n\nSource: {source} ({source_kind}).";
  const localized = localizedConceptFor(record, language);
  const term = (localized && localized.term) || record.term;
  const summary = (localized && localized.summary) || record.summary;
  const source = (localized && localized.source) || record.source;
  const sourceKind =
    (localized && localized.sourceKind) || record.sourceKind;
  const sourceMarkup = renderSourceLink(source);
  return template
    .replace(/\{context_label\}/g, contextLabel)
    .replace(/\{context\}/g, context)
    .replace(/\{term\}/g, term)
    .replace(/\{category\}/g, record.category)
    .replace(/\{summary\}/g, summary)
    .replace(/\{source\}/g, sourceMarkup)
    .replace(/\{source_kind\}/g, sourceKind);
}

function renderConceptPlain(language, record) {
  const localized = localizedConceptFor(record, language);
  const term = (localized && localized.term) || record.term;
  const summary = (localized && localized.summary) || record.summary;
  const source = (localized && localized.source) || record.source;
  const sourceKind =
    (localized && localized.sourceKind) || record.sourceKind;
  const sourceMarkup = renderSourceLink(source);
  return `${term} (${record.category}): ${summary}\n\nSource: ${sourceMarkup} (${sourceKind}).`;
}

function tryConceptLookup(prompt) {
  const query = extractConceptQuery(prompt);
  if (!query) return null;
  const evidence = [`concept_lookup:request:${query.term}`];
  if (query.context) {
    evidence.push(`concept_lookup:context:${query.context}`);
  }
  if (query.responseLanguage) {
    evidence.push(`concept_lookup:response-language:${query.responseLanguage}`);
    evidence.push(`language_to:${query.responseLanguage}`);
  }
  const lookup = lookupConceptQuery(query);
  if (!lookup) {
    // Surface the miss in evidence so the demo's trace panel can show why
    // the handler declined the prompt. Returning null lets later handlers
    // (Wikipedia lookup, fallback) still get a chance.
    return null;
  }
  const record = lookup.record;
  const language = query.responseLanguage || detectLanguage(prompt);
  const localized = localizedConceptFor(record, language);
  const effectiveSource = (localized && localized.source) || record.source;
  // Issue #21: emit the percent-decoded IRI form for the trace panel.
  const humanSource = humanizeUrl(effectiveSource);
  evidence.push(`concept_lookup:hit:${record.slug}`);
  evidence.push(`source:${humanSource}`);
  if (record.wikidata) {
    evidence.push(`wikidata:${record.wikidata}`);
  }
  if (lookup.contextMatch && lookup.context) {
    evidence.push(`concept_lookup:context-match:${lookup.context}`);
    const body = renderConceptInContext(language, lookup.context, record);
    return {
      intent: "concept_lookup_in_context",
      content: body,
      confidence: 0.9,
      evidence,
    };
  }
  if (lookup.context) {
    evidence.push(`concept_lookup:context-mismatch:${lookup.context}`);
  }
  const body = renderConceptPlain(language, record);
  return {
    intent: "concept_lookup",
    content: body,
    confidence: 0.9,
    evidence,
  };
}

function extractDefinitionMergeTerm(prompt, allowPlainConcept) {
  // The intent is two meanings together: a definition_merge_action ("merge",
  // "combine", "fuse", …) applied to a definition_artifact_request
  // ("definition", "translation", "wikipedia", …). Both are matched as raw
  // substrings of the normalized prompt, so inflected forms in every supported
  // language are caught with no per-word list in code. Mirrors
  // extract_definition_merge_term in src/solver_handlers/definition_merge.rs.
  const text = String(prompt || "");
  const normalized = normalizePrompt(text);
  const asksMerge = lexiconMentionsRoleSubstring(ROLE_DEFINITION_MERGE_ACTION, normalized);
  const asksDefinition = lexiconMentionsRoleSubstring(
    ROLE_DEFINITION_ARTIFACT_REQUEST,
    normalized,
  );
  if (!asksMerge || !asksDefinition) {
    if (allowPlainConcept) {
      const query = extractConceptQuery(text);
      if (query && !query.context) return query.term;
    }
    return null;
  }

  // The introducing phrases ("definitions of", "translation for", …) are
  // definition_merge_marker prefix word forms; the literal before each slot
  // marker is the phrase to locate. They are declared in the lexicon in the
  // original priority order, so the first prefix that appears in the prompt
  // wins and the text after it becomes the term.
  const lower = text.toLowerCase();
  for (const form of roleWordForms(ROLE_DEFINITION_MERGE_MARKER)) {
    if (form.slot !== "prefix") continue;
    const marker = form.before;
    const index = lower.indexOf(marker);
    if (index < 0) continue;
    const candidate = trimDefinitionMergeTail(text.slice(index + marker.length));
    if (candidate) return candidate.toLowerCase();
  }
  const query = extractConceptQuery(text);
  return query ? query.term : null;
}

function trimDefinitionMergeTail(value) {
  // The boundary words that end the term ("from", "using", "with", …) are
  // definition_merge_tail_boundary meanings; we reconstruct each as a
  // space-padded token and cut at the earliest one we find. Only the English
  // surface forms are consulted here: this is an English-frame heuristic, and
  // the term itself may be in any language (e.g. the Russian preposition "в" is
  // part of the term "реклама в Telegram", not a boundary). The other languages
  // remain in the seed so the meaning stays fully self-describing. The quote and
  // punctuation trim sets are typographic and stay in code. Mirrors
  // trim_definition_merge_tail in src/solver_handlers/definition_merge.rs.
  const text = String(value || "");
  const lower = text.toLowerCase();
  let end = text.length;
  for (const word of wordsForRoleInLanguages(ROLE_DEFINITION_MERGE_TAIL_BOUNDARY, ["en"])) {
    const index = lower.indexOf(` ${word} `);
    if (index >= 0) end = Math.min(end, index);
  }
  return text
    .slice(0, end)
    .trim()
    .replace(/^['"`“”«»]+|['"`“”«»]+$/g, "")
    .replace(/[?。.!,;:]+$/g, "")
    .trim();
}

function inferredSourceLanguage(source) {
  // Issue #699 batch 2: the host-to-language table moved into
  // language-detection.lino, so a new language is one seed record away.
  const value = String(source || "");
  const match = LANGUAGE_RULES.find(
    (rule) => rule && rule.sourceHost && value.includes(rule.sourceHost),
  );
  return match ? match.language : "en";
}

function normalizeDefinitionFact(value) {
  return String(value || "")
    .toLocaleLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, "");
}
