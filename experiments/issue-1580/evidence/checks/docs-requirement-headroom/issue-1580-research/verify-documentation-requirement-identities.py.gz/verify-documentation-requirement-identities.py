from pathlib import Path
import json,re,subprocess,os,difflib
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/docs-requirement-headroom');initial=json.loads((out/'outcome.json').read_text());(out/'initial-outcome.json').write_text(json.dumps(initial,indent=2)+'\n')
original=(out/'original.rs').read_text();owner=root/'rust/tests/unit/docs_requirements.rs';current=owner.read_text();boundary=original.index('fn repo_root()')
pattern=r'^fn ([a-z_][a-z_0-9]*)\(\) \{';before=re.findall(pattern,original[:boundary],re.M);after=re.findall(pattern,current,re.M);assert len(before)==14,before;assert before==after
prefix='''mod text_haystack;

use text_haystack::{
    assert_contains_all, collect_for_haystack, is_skipped_tree, read, repo_root, tracked_files,
};

'''
assert current.startswith(prefix)
expected=original[:boundary].replace('use std::path::Path;\n','',1)
assert current.removeprefix(prefix).rstrip()==expected.rstrip(),''.join(difflib.unified_diff(expected.splitlines(True),current.removeprefix(prefix).splitlines(True)))
initial['originalNativeTestNames']=before;initial['assertionBodiesExactlyConserved']=True;initial['initialEmptyIdentityControlQualified']=False;(out/'outcome.json').write_text(json.dumps(initial,indent=2)+'\n');print(json.dumps(initial))
