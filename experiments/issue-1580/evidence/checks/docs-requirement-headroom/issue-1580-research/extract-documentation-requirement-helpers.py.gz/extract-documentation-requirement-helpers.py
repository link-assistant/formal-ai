from pathlib import Path
import hashlib,json,os,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/docs-requirement-headroom')
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(json.dumps({'pid':worker.pid,'finite':True}));sys.exit(0)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=256';records=[]
def run(name,args):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:p=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'arguments':args,'exitCode':p.returncode};records.append(row);(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True);return p.returncode
try:
    owner=root/'rust/tests/unit/docs_requirements.rs';original=owner.read_text();(out/'original.rs').write_text(original)
    tests=root/'experiments/issue-1580/native-test-headroom.test.mjs';source=tests.read_text();source+='''\n\ntest('documentation requirement helpers retain headroom and the original assertion owners', () => {
  const owner = 'rust/tests/unit/docs_requirements';
  assert.deepEqual(checkListedFiles(root, new Set([owner + '.rs', owner + '/text_haystack.rs'])),
    {warnings: [], violations: [], embeddedDataViolations: []});
  const source = readFileSync(root + '/' + owner + '.rs', 'utf8');
  assert.match(source, /^mod text_haystack;$/mu);
  assert.match(source, /^fn repository_text_avoids_deferred_labels_requested_by_issue_103\(\) \{/mu);
  const helper = readFileSync(root + '/' + owner + '/text_haystack.rs', 'utf8');
  assert(helper.includes('.args(["ls-files", "-z"])'));
  assert(!helper.includes('#[test]'), 'all original documentation assertions remain in the native owner');
});
''';tests.write_text(source)
    assert run('before',['node','--test','--test-concurrency=1','--test-name-pattern=documentation requirement helpers',str(tests)])!=0
    boundary=original.index('fn repo_root()');body=original[:boundary];helpers=original[boundary:]
    prefix='''mod text_haystack;

use text_haystack::{
    assert_contains_all, collect_for_haystack, is_skipped_tree, read, repo_root, tracked_files,
};

'''
    body=body.replace('use std::path::Path;\n','',1);body=prefix+body
    helpers=re.sub(r'^fn (repo_root|read|assert_contains_all|tracked_files|is_skipped_tree|collect_for_haystack)\b',r'pub(super) fn \1',helpers,flags=re.M)
    header='//! Tracked-text readers and label scanning for the documentation contracts.\n\nuse std::fs;\nuse std::path::Path;\n\n'
    child=owner.with_suffix('')/'text_haystack.rs';owner.write_text(body);child.write_text(header+helpers)
    assert run('format',['rustfmt','--edition','2024',str(owner),str(child)])==0
    restored=child.read_text().removeprefix(header);restored=re.sub(r'^pub\(super\) fn ', 'fn ',restored,flags=re.M);assert restored==original[boundary:]
    pattern=r'^fn ([a-z_]+)\(\) \{';before_names=re.findall(pattern,original[:boundary],re.M);after_names=re.findall(pattern,owner.read_text(),re.M);assert before_names==after_names
    before_assertions=re.findall(r'\bassert(?:_eq|_ne)?!',original[:boundary]);after_assertions=re.findall(r'\bassert(?:_eq|_ne)?!',owner.read_text());assert before_assertions==after_assertions
    assert run('after',['node','--test','--test-concurrency=1',str(tests)])==0
    assert run('gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-file-size-js-twin,check-tests-as-docs,check-tests-as-documentation-javascript-twin'])==0
    summary={'complete':True,'ownerLines':len(owner.read_text().splitlines()),'childLines':len(child.read_text().splitlines()),'originalNativeTestNames':before_names,'assertionSequenceUnchanged':True,'helperBodiesExactlyConserved':True,'nativeBuildRun':False,'independentAuthorshipCredit':0,'fullIssueComplete':False};(out/'outcome.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
