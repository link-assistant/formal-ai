from pathlib import Path
import gzip,hashlib,json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'contributing-headroom';target=root/'experiments/issue-1580/evidence/checks/contributing-headroom'
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
for name in ['merge-conflict-layout.md','changelog-management.md']:
    path=root/'docs/development'/name;before=path.read_text();after=before.rstrip()+'\n';assert before==after+'\n';path.write_text(after)
note=root/'docs/case-studies/issue-1580/contributing-headroom-checkpoint.md';text=note.read_text().replace('Every moved byte is conserved after the two relative-link adjustments, with','Moved text is conserved after two relative-link adjustments and removing\nthe final empty line from each standalone guide, with');text+='\nThe final staged whitespace gate caught those two empty EOF lines; they were\nremoved and all focused checks were repeated before committing. The failed\nstaged gate and original extraction receipts remain in the evidence.\n';note.write_text(text)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
records=[]
for name,args in [('repaired-focused',['node','--test','--test-reporter=tap','--test-concurrency=1','experiments/issue-1580/documentation-headroom.test.mjs']),('repaired-push-gate',['node','--test','--test-reporter=tap','--test-concurrency=1','rust/tests/web/push-gate-rules.test.mjs']),('repaired-touched-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size,check-file-size-js-twin'])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:run=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    records.append({'name':name,'arguments':args,'exitCode':run.returncode});assert run.returncode==0,name
(out/'eof-repair.json').write_text(json.dumps({'removedOnlyFinalEmptyLines':True,'guideLines':{'merge-conflict-layout.md':69,'changelog-management.md':33},'checks':records},indent=2)+'\n')
ledger=target/'records.jsonl';rows=[json.loads(line) for line in ledger.read_text().splitlines()]
for path in [out/'final-whitespace.stdout',out/'final-whitespace.stderr',out/'eof-repair.json',scratch/'commit-contributing-headroom.log',Path(__file__),*[out/(name+suffix) for name in ['repaired-focused','repaired-push-gate','repaired-touched-gates'] for suffix in ['.stdout','.stderr']]]:
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);alias='eof-repair/'+path.name+'.gz';destination=target/alias;destination.parent.mkdir(exist_ok=True);assert not destination.exists();destination.write_bytes(packed);assert gzip.decompress(packed)==raw;rows.append({'source':str(path),'file':alias,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
ledger.write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in rows))
summary=json.loads((target/'summary.json').read_text());summary['finalEmptyLineRepair']={'removedPerGuide':1,'relativeLinkChanges':2,'allOtherMovedContentConserved':True};(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
subprocess.run(['git','add','--','docs/development/merge-conflict-layout.md','docs/development/changelog-management.md',str(note.relative_to(root)),str(target.relative_to(root))],cwd=root,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=root).decode().split('\0')[:-1];assert not any('/evidence/ci/' in path for path in staged)
for name,args in [('commit-naming',['node','scripts/measure-abbreviations.mjs','--check']),('commit-secrets',['bash','scripts/check-secrets.sh',*staged]),('commit-whitespace',['git','diff','--cached','--check'])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:run=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    assert run.returncode==0,name
with (out/'commit.stdout').open('wb') as stdout,(out/'commit.stderr').open('wb') as stderr:subprocess.run(['git','-c','gc.auto=0','commit','-m','Extract contributor guides while preserving rules and anchors'],cwd=root,stdout=stdout,stderr=stderr,check=True)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root,text=True)
result={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'committed':True,'pushed':False,'records':len(rows),'trackedWorkingTreeClean':True,'fullIssueComplete':False};(out/'commit-outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
