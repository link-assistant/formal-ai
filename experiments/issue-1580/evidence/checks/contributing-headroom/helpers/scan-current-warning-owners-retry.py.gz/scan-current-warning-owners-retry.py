from pathlib import Path
import json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-warning-owners')
with (out/'tracked-paths.nul').open('wb') as stream:
    subprocess.run(['git','ls-files','-z'],cwd=root,stdout=stream,check=True)
source="""import {checkListedFiles} from './scripts/check-file-size.mjs';
import {readFileSync} from 'node:fs';
const listed = new Set(readFileSync('/tmp/issue-1580-research/current-warning-owners/tracked-paths.nul', 'utf8').split('\\0').filter(Boolean));
console.log(JSON.stringify(checkListedFiles(process.cwd(), listed), null, 2));
"""
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
with (out/'retry-scan.json').open('wb') as stdout,(out/'retry-scan.stderr').open('wb') as stderr:
    result=subprocess.run(['node','--max-old-space-size=256','--input-type=module','-e',source],cwd=root,env=env,stdout=stdout,stderr=stderr)
assert result.returncode==0
rows=json.loads((out/'retry-scan.json').read_text());print(json.dumps({'warnings':len(rows['warnings']),'violations':len(rows['violations']),'inventoryStreaming':True}))
