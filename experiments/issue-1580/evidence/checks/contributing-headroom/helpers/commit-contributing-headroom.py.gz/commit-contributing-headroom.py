from pathlib import Path
import gzip,hashlib,json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'contributing-headroom';assert json.loads((out/'outcome.json').read_text())['complete']
target=root/'experiments/issue-1580/evidence/checks/contributing-headroom';target.mkdir(exist_ok=False);records=[]
helpers=['extract-contributing-guides.py','extract-contributing-guides.log','finish-contributing-guide-extraction.py','finish-contributing-guide-extraction.log','validate-contributing-guide-headroom.py','validate-contributing-guide-headroom.log','commit-contributing-headroom.py','scan-current-warning-owners.py','scan-current-warning-owners.log','scan-current-warning-owners-retry.py','scan-current-warning-owners-retry.log']
paths=[path for path in sorted(out.iterdir()) if path.is_file()]+[scratch/name for name in helpers]+[path for path in sorted((scratch/'current-warning-owners').iterdir()) if path.is_file() and path.name!='tracked-paths.nul']
for path in paths:
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);alias=(path.parent.name if path.parent!=scratch else 'helpers')+'/'+path.name+'.gz';destination=target/alias;destination.parent.mkdir(parents=True,exist_ok=True);assert not destination.exists();destination.write_bytes(packed);assert gzip.decompress(destination.read_bytes())==raw;records.append({'source':str(path),'file':alias,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records));(target/'summary.json').write_text((out/'extraction.json').read_text())
note=root/'docs/case-studies/issue-1580/contributing-headroom-checkpoint.md';note.write_text('''# Contributor guide headroom

The maintained scanner reproduces the 1491-line contributor-guide warning.
Two complete sections now live in linked merge-layout and changelog guides.
Every moved byte is conserved after the two relative-link adjustments, with
legacy changelog anchor IDs retained at the entry point. The entry now has
1399 lines; the unchanged scanner limits leave 77 repository warnings.

The focused regression fails before extraction and passes afterward. It checks
the real scanner, guide reachability, relative links and key instructions. All
existing push-gate documentation cases and three affected JavaScript gates pass.
Two intermediate drafts still exceeded the warning band; their failed checks
remain evidence, without passing credit. The first inventory probe exceeded
Node's default output buffer; the retry reads the Git inventory from a file.
These are development harness failures, not new production failures.

The preceding batch's 151 maintained cases retain their own source scope; this
batch executes its focused case and the existing push-gate suite. No Rust build
is run. Complete issue acceptance and independent Formal AI authorship remain
unfinished; supplied scripts and conclusions receive zero independent credit.

Evidence: `experiments/issue-1580/evidence/checks/contributing-headroom/`.
''')
fragment=root/'changelog.d/issue-1580-contributor-guide-headroom.md';fragment.write_text('''---
bump: patch
---

Extract complete merge-layout and changelog contributor guides, preserving
instructions, relative links and existing entry-point anchors.
''')
plan=root/'experiments/issue-1580/work-plan.md';source=plan.read_text().replace('bodies or scanner limits: 78 warnings remain.','bodies or scanner limits: 77 warnings remain after contributor-guide extraction.',1);source+='\n- Contributor guide extraction conserves all moved instructions and legacy anchors, removing its warning: 77 remain under unchanged limits. The focused before/after regression, existing push-gate cases and three affected gates pass. See [contributor guide checkpoint](../../docs/case-studies/issue-1580/contributing-headroom-checkpoint.md).\n';plan.write_text(source)
paths=['CONTRIBUTING.md','docs/development/merge-conflict-layout.md','docs/development/changelog-management.md','experiments/issue-1580/documentation-headroom.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs',str(target.relative_to(root)),str(note.relative_to(root)),str(fragment.relative_to(root)),str(plan.relative_to(root))];subprocess.run(['git','add','--',*paths],cwd=root,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=root).decode().split('\0')[:-1];assert not any('/evidence/ci/' in path for path in staged)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
for name,args in [('final-naming',['node','scripts/measure-abbreviations.mjs','--check']),('final-secrets',['bash','scripts/check-secrets.sh',*staged]),('final-whitespace',['git','diff','--cached','--check'])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    assert result.returncode==0,name
with (out/'commit.stdout').open('wb') as stdout,(out/'commit.stderr').open('wb') as stderr:subprocess.run(['git','-c','gc.auto=0','commit','-m','Extract contributor guides while preserving rules and anchors'],cwd=root,stdout=stdout,stderr=stderr,check=True)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root,text=True)
result={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'committed':True,'pushed':False,'records':len(records),'trackedWorkingTreeClean':True,'fullIssueComplete':False};(out/'commit-outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
