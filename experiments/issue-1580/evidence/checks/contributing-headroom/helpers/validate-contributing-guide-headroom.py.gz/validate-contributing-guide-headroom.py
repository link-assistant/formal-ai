from pathlib import Path
import hashlib,json,os,re,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/contributing-headroom');original=(out/'CONTRIBUTING.before.md').read_text();source=original;changes=[]
sections=[('## Merge conflicts are a layout bug (issue #991)','## The single push gate (issue #1191)','docs/development/merge-conflict-layout.md','''## Merge conflicts are a layout bug (issue #991)

Follow the [merge conflict layout guide](docs/development/merge-conflict-layout.md)
when adding modules, checks, requirements or generated data. It defines list
ownership, verification, regeneration and the documentation test mapping.

'''),('## Changelog Management','## Project Structure','docs/development/changelog-management.md','''## Changelog Management

Follow the [changelog guide](docs/development/changelog-management.md) for fragment
creation, categories and release collection.
<a id="creating-a-fragment"></a><a id="fragment-categories"></a><a id="during-release"></a>

''')]
for first,last,path,replacement in sections:
    start=source.index(first+'\n');end=source.index(last+'\n',start);moved=source[start:end];guide=root/path;links=[]
    def rebase(match):
        target=match.group(1)
        if re.match(r'^(?:https?:|#)',target):return match.group(0)
        revised=os.path.relpath(root/target,guide.parent);links.append({'before':target,'after':revised});return ']('+revised+')'
    body=re.sub(r'\]\(([^)]+)\)',rebase,moved);guide.write_text(body);restored=body
    for link in links:restored=restored.replace(']('+link['after']+')',']('+link['before']+')')
    assert restored==moved
    source=source[:start]+replacement+source[end:];changes.append({'path':path,'originalLines':len(moved.splitlines()),'guideLines':len(body.splitlines()),'normalizedContentConserved':True,'linkRewrites':links,'sha256':hashlib.sha256(body.encode()).hexdigest()})
assert len(source.splitlines())<=1400,len(source.splitlines());(root/'CONTRIBUTING.md').write_text(source)
entry=root/'rust/tests/web/issue-1580-template-observations.test.mjs';statement="import '../../../experiments/issue-1580/documentation-headroom.test.mjs';\n";assert statement not in entry.read_text();entry.write_text(entry.read_text()+statement)
(out/'extraction.json').write_text(json.dumps({'ownerLinesBefore':len(original.splitlines()),'ownerLinesAfter':len(source.splitlines()),'sections':changes,'allOriginalContentConserved':True,'legacyChangelogAnchorsPreserved':True,'initialDraftsStillOverWarningThreshold':True},indent=2)+'\n')
env=os.environ.copy();env.pop('NODE_OPTIONS',None);records=json.loads((out/'commands.json').read_text())
for name,args in [('after',['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','experiments/issue-1580/documentation-headroom.test.mjs']),('existing-push-gate',['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','rust/tests/web/push-gate-rules.test.mjs']),('touched-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size,check-file-size-js-twin']),('whitespace',['git','diff','--check'])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    records.append({'name':name,'args':args,'exitCode':result.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert result.returncode==0,name
result={'complete':True,'warningRemoved':True,'remainingWarnings':77,'nativeBuildRun':False,'fullIssueComplete':False,'independentAuthorshipCredit':0};(out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
