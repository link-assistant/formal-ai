from pathlib import Path
import hashlib,json,os,re,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/contributing-headroom');owner=root/'CONTRIBUTING.md';source=owner.read_text();original=(out/'CONTRIBUTING.before.md').read_text()
first='## Release Process\n';last='## Getting Help\n';start=source.index(first);end=source.index(last,start);moved=source[start:end];guide=root/'docs/development/changelog-management.md';assert moved==original[original.index(first):original.index(last,original.index(first))]
guide.write_text(guide.read_text()+moved)
replacement='''## Release Process

Follow the [release guide](docs/development/changelog-management.md#release-process)
for semantic versioning and release triggers.

'''
source=source[:start]+replacement+source[end:];assert len(source.splitlines())<=1400;owner.write_text(source)
entry=root/'rust/tests/web/issue-1580-template-observations.test.mjs';entry.write_text(entry.read_text()+"import '../../../experiments/issue-1580/documentation-headroom.test.mjs';\n")
changes=[]
for first,last,path in [('## Merge conflicts are a layout bug (issue #991)','## The single push gate (issue #1191)','docs/development/merge-conflict-layout.md'),('## Changelog Management','## Project Structure','docs/development/changelog-management.md')]:
    start=original.index(first+'\n');end=original.index(last+'\n',start);body=original[start:end];actual=(root/path).read_text();expected=re.sub(r'\]\(([^)]+)\)',lambda match:match.group(0) if re.match(r'^(?:https?:|#)',match.group(1)) else ']('+os.path.relpath(root/match.group(1),(root/path).parent)+')',body)
    assert actual.startswith(expected),path
    changes.append({'path':path,'originalSectionLines':len(body.splitlines()),'guideLines':len(actual.splitlines()),'normalizedContentConserved':True,'sha256':hashlib.sha256(actual.encode()).hexdigest()})
assert guide.read_text().endswith(moved)
(out/'extraction.json').write_text(json.dumps({'ownerLinesBefore':len(original.splitlines()),'ownerLinesAfter':len(source.splitlines()),'sections':changes,'releaseProcessContentConserved':True,'allOriginalContentConserved':True,'initialDraftStillOverWarningThreshold':True},indent=2)+'\n')
env=os.environ.copy();env.pop('NODE_OPTIONS',None);records=json.loads((out/'commands.json').read_text())
for name,args in [('after',['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','experiments/issue-1580/documentation-headroom.test.mjs']),('existing-push-gate',['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','rust/tests/web/push-gate-rules.test.mjs']),('touched-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size,check-file-size-js-twin']),('whitespace',['git','diff','--check'])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    records.append({'name':name,'args':args,'exitCode':result.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert result.returncode==0,name
result={'complete':True,'warningRemoved':True,'remainingWarnings':77,'nativeBuildRun':False,'fullIssueComplete':False,'independentAuthorshipCredit':0};(out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
