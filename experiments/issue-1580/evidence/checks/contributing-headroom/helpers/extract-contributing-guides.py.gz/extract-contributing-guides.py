from pathlib import Path
import hashlib,json,os,re,subprocess

root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/contributing-headroom');out.mkdir(exist_ok=False);records=[]
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
def run(name,args,expected=0):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    records.append({'name':name,'args':args,'exitCode':result.returncode,'expectedExitCode':expected});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert result.returncode==expected,name
test=root/'experiments/issue-1580/documentation-headroom.test.mjs';assert not test.exists()
test.write_text('''import assert from 'node:assert/strict';
import {existsSync, readFileSync} from 'node:fs';
import {dirname, resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import test from 'node:test';
import {checkListedFiles} from '../../scripts/check-file-size.mjs';

const root = fileURLToPath(new URL('../../', import.meta.url)).replace(/\\/$/u, '');
test('contributor rules retain source headroom and reachable detailed guides', () => {
  const guides = ['docs/development/merge-conflict-layout.md', 'docs/development/changelog-management.md'];
  assert.deepEqual(checkListedFiles(root, new Set(['CONTRIBUTING.md', ...guides])),
    {warnings: [], violations: [], embeddedDataViolations: []});
  const entry = readFileSync(resolve(root, 'CONTRIBUTING.md'), 'utf8');
  for (const guide of guides) {
    assert(entry.includes('](' + guide + ')'), 'contributor entry must link the detailed rule: ' + guide);
    const file = resolve(root, guide);
    const text = readFileSync(file, 'utf8');
    for (const link of text.matchAll(/\\]\\(([^)]+)\\)/gu)) {
      if (/^(?:https?:|#)/u.test(link[1])) continue;
      assert(existsSync(resolve(dirname(file), link[1].split('#')[0])), 'broken guide link: ' + link[1]);
    }
  }
  const layout = readFileSync(resolve(root, guides[0]), 'utf8');
  assert(layout.includes('Every union-merged file has a verifier.'));
  assert(layout.includes('scripts/regenerate-derived-artifacts.sh'));
  const changelog = readFileSync(resolve(root, guides[1]), 'utf8');
  assert(changelog.includes('### Creating a Fragment'));
  assert(changelog.includes('### Fragment Categories'));
  assert(changelog.includes('### During Release'));
});
''')
args=['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',str(test.relative_to(root))]
run('before',args,1)
owner=root/'CONTRIBUTING.md';original=owner.read_text();(out/'CONTRIBUTING.before.md').write_text(original);source=original;changes=[]
sections=[('## Merge conflicts are a layout bug (issue #991)','## The single push gate (issue #1191)','docs/development/merge-conflict-layout.md','''## Merge conflicts are a layout bug (issue #991)

Follow the [merge conflict layout guide](docs/development/merge-conflict-layout.md)
when adding modules, checks, requirements or generated data. It defines list
ownership, verification, regeneration and the documentation test mapping.

'''),('## Changelog Management','## Project Structure','docs/development/changelog-management.md','''## Changelog Management

Follow the [changelog guide](docs/development/changelog-management.md) for fragments
and release collection.

### Creating a Fragment

Use the [fragment creation instructions](docs/development/changelog-management.md#creating-a-fragment).

### Fragment Categories

Use the [documented fragment categories](docs/development/changelog-management.md#fragment-categories).

### During Release

Follow the [release collection rules](docs/development/changelog-management.md#during-release).

''')]
for first,last,path,replacement in sections:
    start=source.index(first+'\n');end=source.index(last+'\n',start);moved=source[start:end];guide=root/path;assert not guide.exists();links=[]
    def rebase(match):
        target=match.group(1)
        if re.match(r'^(?:https?:|#)',target):return match.group(0)
        revised=os.path.relpath(root/target,guide.parent);links.append({'before':target,'after':revised});return ']('+revised+')'
    body=re.sub(r'\]\(([^)]+)\)',rebase,moved)
    guide.write_text(body)
    restored=body
    for link in links:restored=restored.replace(']('+link['after']+')',']('+link['before']+')')
    assert restored==moved
    source=source[:start]+replacement+source[end:]
    changes.append({'path':path,'originalLines':len(moved.splitlines()),'guideLines':len(body.splitlines()),'normalizedContentConserved':True,'linkRewrites':links,'sha256':hashlib.sha256(body.encode()).hexdigest()})
owner.write_text(source);assert len(source.splitlines())<=1400
entry=root/'rust/tests/web/issue-1580-template-observations.test.mjs';entry.write_text(entry.read_text()+"import '../../../experiments/issue-1580/documentation-headroom.test.mjs';\n")
(out/'extraction.json').write_text(json.dumps({'ownerLinesBefore':len(original.splitlines()),'ownerLinesAfter':len(source.splitlines()),'sections':changes,'allOriginalContentConserved':True},indent=2)+'\n')
run('after',args)
run('existing-push-gate',['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','rust/tests/web/push-gate-rules.test.mjs'])
run('touched-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size,check-file-size-js-twin'])
run('whitespace',['git','diff','--check'])
result={'complete':True,'warningRemoved':True,'remainingWarnings':77,'nativeBuildRun':False,'fullIssueComplete':False,'independentAuthorshipCredit':0};(out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
