from pathlib import Path
import json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-warning-owners');out.mkdir(exist_ok=False)
source="""import {checkListedFiles} from './scripts/check-file-size.mjs';
import {execFileSync} from 'node:child_process';
const listed = new Set(execFileSync('git', ['ls-files', '-z'], {encoding:'utf8'}).split('\\0').filter(Boolean));
console.log(JSON.stringify(checkListedFiles(process.cwd(), listed), null, 2));
"""
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
result=subprocess.run(['node','--max-old-space-size=256','--input-type=module','-e',source],cwd=root,env=env,capture_output=True)
(out/'scan.json').write_bytes(result.stdout);(out/'scan.stderr').write_bytes(result.stderr);assert result.returncode==0
rows=json.loads(result.stdout);print(json.dumps({'warnings':len(rows['warnings']),'violations':len(rows['violations'])}))
