from pathlib import Path
import json, subprocess, sys
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/cnl-realization-extraction')
assert not (root/'rust/src/cnl_output/grammar/realization.rs').exists()
with (out/'corrected-worker.log').open('wb') as stream:
    worker = subprocess.Popen([sys.executable,'/tmp/issue-1580-research/extract-cnl-realization.py','worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
print(json.dumps({'pid':worker.pid,'finiteWorker':True}))
