from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys
root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'cnl-realization-extraction'
if len(sys.argv) == 1:
    out.mkdir(exist_ok=False)
    with (out / 'worker.log').open('wb') as stream:
        worker = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid':worker.pid,'finiteWorker':True}))
    sys.exit(0)
records = []
def run(name, argv):
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=root, env={**os.environ, 'NODE_OPTIONS':'--max-old-space-size=256'}, stdout=stdout, stderr=stderr)
    records.append({'name':name,'argv':argv,'exitCode':result.returncode})
    (out / 'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    assert result.returncode == 0,name
assert json.loads((scratch/'repair-report-and-replacement-extraction/commit-outcome.json').read_text())['passed']
parent = root/'rust/src/cnl_output/grammar.rs'
child = root/'rust/src/cnl_output/grammar/realization.rs'
original = parent.read_text()
assert len(original.splitlines()) == 966 and not child.exists()
marker = 'fn capitalized(text: &str) -> String {'
start = original.index(marker)
block = original[start:]
letter = 'static LETTER: LazyLock<Regex> =\n    LazyLock::new(|| Regex::new(r"\\p{L}").expect("fixed CNL letter grammar"));\n'
assert original.count(letter) == 1
module = 'mod realization;\n'
export = 'pub use realization::{all_pairs, realizations, realize_graph};\n'
imports = 'use super::{CompiledGrammar, Graph, SLOT, js_space};\nuse regex::Regex;\nuse std::sync::LazyLock;\n\n'
new_parent = original[:start].rstrip()+'\n'
new_parent = new_parent.replace('mod graph;\n','mod graph;\n'+module,1).replace('pub use graph::{Graph, Slots, graph_key};\n','pub use graph::{Graph, Slots, graph_key};\n'+export,1).replace(letter,'',1)
new_child = imports+letter+'\n'+block
# The first inverse attempt inserted before the comment alone and retained an
# extra blank line before LETTER; it failed before writing either source file.
restored = new_parent.replace(module,'',1).replace(export,'',1).replace('\n\n/// JavaScript `\\s`','\n'+letter+'\n/// JavaScript `\\s`',1).rstrip()+'\n\n'+new_child.removeprefix(imports+letter+'\n')
assert restored == original
(out/'original-source.rs.gz').write_bytes(gzip.compress(original.encode(),mtime=0))
parent.write_text(new_parent)
child.write_text(new_child)
inputs = {}
paths = [parent.relative_to(root).as_posix(),child.relative_to(root).as_posix()]
for index,path in enumerate(paths):
    target = out/('unformatted-'+str(index)+'.rs')
    target.write_bytes((root/path).read_bytes())
    inputs[path] = str(target)
(out/'formatting-inputs.json').write_text(json.dumps(inputs)+'\n')
run('canonical-format',['rustfmt','--edition','2024',*paths])
code = "import fs from 'node:fs'; import assert from 'node:assert/strict'; import {lex} from './scripts/self-translation/lexer.mjs'; for(const [file,old] of Object.entries(JSON.parse(fs.readFileSync(process.argv[1],'utf8')))){const tokens=s=>lex(s,'Rust').map(t=>[t.type,t.text]);assert.deepEqual(tokens(fs.readFileSync(file,'utf8')),tokens(fs.readFileSync(old,'utf8')),file);} console.log('Every Rust syntax token and comment is unchanged by formatting');"
run('format-token-equivalence',['node','--input-type=module','-e',code,str(out/'formatting-inputs.json')])
counts = [len(path.read_text().splitlines()) for path in [parent,child]]
assert all(count<900 for count in counts)
proof = {'parent':paths[0],'child':paths[1],'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'reassembledOriginalSha256':hashlib.sha256(restored.encode()).hexdigest(),'originalLines':966,'parentLines':counts[0],'childLines':counts[1],'exactOriginalReconstructionBeforeFormatting':True}
(out/'inverse-proofs.json').write_text(json.dumps({'observedAt':datetime.now(timezone.utc).isoformat(),'files':[proof],'formattingPreservesEverySyntaxTokenAndComment':True,'hostedNativeVerificationPending':True,'localRustExecution':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
run('rust-format-check',['rustfmt','--edition','2024','--check',*paths])
run('cnl-realization-javascript',['node','--test','--test-concurrency=1','rust/tests/web/cnl-grammar-matrix.test.mjs'])
run('translation-current',['node','scripts/translate-js-rust.mjs','--verify'])
run('generated-registry-current',['node','scripts/lib/generate-native-specification-programs.mjs','--check'])
run('source-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code'])
(out/'outcome.json').write_text(json.dumps({'passed':True,'files':[proof],'sourcePaths':paths,'pushExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
