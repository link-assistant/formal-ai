from pathlib import Path
p=Path('experiments/issue-1580/hosted-javascript-scheduling.test.mjs')
s=p.read_text()
s=s.replace("test('deployed JavaScript plan retains every suite and fits the retained four-worker cost model', () => {", "for (const capture of ['8d8', '9e945']) test('deployed JavaScript plan retains every suite and fits hosted costs: ' + capture, () => {")
s=s.replace("new URL('./fixtures/hosted-javascript-8d8/identity.json', import.meta.url)","new URL('./fixtures/hosted-javascript-' + capture + '/identity.json', import.meta.url)")
s=s.replace("new URL('./fixtures/hosted-javascript-8d8/durations.jsonl', import.meta.url)","new URL('./fixtures/hosted-javascript-' + capture + '/durations.jsonl', import.meta.url)")
p.write_text(s)
