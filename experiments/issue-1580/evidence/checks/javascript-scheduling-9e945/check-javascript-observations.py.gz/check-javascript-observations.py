from pathlib import Path
import subprocess,json
out=Path('/tmp/issue-1580-research/javascript-observation-refresh')
out.mkdir(exist_ok=True)
for name,command in [
 ('capture',['node','/tmp/issue-1580-research/refresh-javascript-observations.mjs','--capture-only']),
 ('before',['node','--test','--test-concurrency=1','experiments/issue-1580/hosted-javascript-scheduling.test.mjs']),
 ('refresh',['node','/tmp/issue-1580-research/refresh-javascript-observations.mjs']),
 ('after',['node','--test','--test-concurrency=1','experiments/issue-1580/hosted-javascript-scheduling.test.mjs']),
]:
 with (out/(name+'.log')).open('w') as log:
  r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env={**__import__('os').environ,'NODE_OPTIONS':'--max-old-space-size=256'})
 print(json.dumps({'stage':name,'returncode':r.returncode}),flush=True)
