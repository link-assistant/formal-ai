import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {parseTestDurations} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/ci-speed-durations.mjs';
import {durationLookup,planShards,partitionProblems} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/ci-speed-shards.mjs';
const root='/tmp/gh-issue-solver-1794900398048';
const observed=readFileSync(root+'/experiments/issue-1580/fixtures/hosted-javascript-9e945/durations.jsonl','utf8').trimEnd().split('\n').map(JSON.parse);
const files=readdirSync(root+'/rust/tests/web').filter(file=>file.endsWith('.test.mjs')).map(file=>'rust/tests/web/'+file);
const costs=durationLookup(new Map(observed.map(row=>[row.file,row.seconds])),0.34),reports={};
for(const [name,path] of [['before','/tmp/issue-1580-research/javascript-durations-before.lino'],['after',root+'/data/meta/javascript-test-durations.lino']]){
 const text=readFileSync(path,'utf8'),seconds=durationLookup(parseTestDurations(text),Number(text.match(/^ {2}default-seconds (\S+)$/mu)[1]));
 const {shards}=planShards(files,8,seconds);
 reports[name]={files:files.length,partition:partitionProblems(files,shards),modeledSeconds:shards.map(shard=>{
  const workers=[0,0,0,0];for(const file of shard){let worker=0;for(let i=1;i<4;i++)if(workers[i]<workers[worker])worker=i;workers[worker]+=costs(file);}return Math.max(...workers);
 })};
}
writeFileSync('/tmp/issue-1580-research/javascript-observation-refresh/model.json',JSON.stringify(reports,null,2)+'\n');console.log(JSON.stringify(reports));
