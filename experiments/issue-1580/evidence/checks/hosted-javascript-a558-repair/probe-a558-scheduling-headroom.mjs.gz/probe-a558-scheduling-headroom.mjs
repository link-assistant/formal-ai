import fs from 'node:fs';
import {parseTestDurations,mergeJavaScriptDurations} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/ci-speed-durations.mjs';
import {planShards,durationLookup} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/ci-speed-shards.mjs';
const root='/tmp/gh-issue-solver-1794900398048/';
const old=fs.readFileSync('/tmp/issue-1580-research/a558-layered-costs/table.before.lino','utf8');
const rows=fs.readFileSync(root+'experiments/issue-1580/fixtures/hosted-javascript-a558f834/durations.jsonl','utf8').trim().split('\n').map(row=>JSON.parse(row));
const files=fs.readdirSync(root+'rust/tests/web').filter(file=>file.endsWith('.test.mjs')).map(file=>'rust/tests/web/'+file);
const cases=[];
for(const factor of [1,1.05,1.1,1.15,1.2,1.25,1.3,1.5]) {
 const table=mergeJavaScriptDurations(old,new Map(rows.map(row=>[row.file,{...row,seconds:row.seconds*factor}])),{source:'44999044965',recordedDate:'2026-11-22',raiseOnly:true});
 const weights=parseTestDurations(table),{shards}=planShards(files,8,durationLookup(weights,.34));
 const costs=durationLookup(new Map(rows.map(row=>[row.file,row.seconds])),1);
 const loads=shards.map(shard=>{const workers=Array(4).fill(0);for(const file of shard)workers[workers.indexOf(Math.min(...workers))]+=costs(file);return Math.max(...workers);});
 cases.push({factor,loads,maximum:Math.max(...loads)});
}
console.log(JSON.stringify(cases,null,2));
