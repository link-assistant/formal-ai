from pathlib import Path
import hashlib,json
base=Path('/tmp/issue-1580-research');out=base/'bd6-collection-controller-sources';out.mkdir(exist_ok=False)
records=[]
for name in ['collect-bd6-repaired-head-ci.py','collect-bd6-repaired-producer.py']:
 path=base/name;text=path.read_text();marker="exec(compile(source,__file__,'exec'))";assert text.count(marker)==1
 namespace={'__file__':str(path)};exec(compile(text.replace(marker,''),str(path),'exec'),namespace)
 resolved=namespace['source'];compile(resolved,str(path),'exec')
 (out/name).write_text(resolved)
 records.append({'source':name,'resolvedSha256':hashlib.sha256(resolved.encode()).hexdigest(),'syntaxValid':True,'executed':False})
(out/'outcome.json').write_text(json.dumps({'records':records,'controllersExecuted':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps(records))
