from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
p=root/'rust/tests/unit/reasoning_contracts.rs'
text=p.read_text()
assert 'mod issue_1180_repository_qa;' not in text
text+='\n// Repository definition answers must follow current source after helper extractions.\n#[path = "issue_1180_repository_qa.rs"]\nmod issue_1180_repository_qa;\n'
p.write_text(text)
fragment=root/'changelog.d/1580-repository-qa-current-source.md'
fragment.write_text('### Fixed\n\n- Locate repository definition answers from current Rust sources, so moved helpers and changed line spans cannot quote an unrelated documentation comment.\n- Restore the native Link Store formatting import and avoid duplicate CodeQL boolean options in opt-in macro investigations.\n')
print('Included maintained repository QA tests in hosted reasoning contracts and added release fragment.')
