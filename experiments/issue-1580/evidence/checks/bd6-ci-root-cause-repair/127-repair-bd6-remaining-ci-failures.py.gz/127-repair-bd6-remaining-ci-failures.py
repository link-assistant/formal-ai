from pathlib import Path
import subprocess, json, hashlib
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/repository-qa-source-navigation')
test=root/'experiments/issue-1580/codeql-included-string-observation.test.mjs'
text=test.read_text()
marker="test('included string adapter preserves complete literal text"
assert text.count(marker)==1
new="""test('producer cache arguments compose with the action without duplicate boolean options', () => {
  const workflow = YAML.parse(readFileSync('.github/workflows/security.yml', 'utf8'));
  const analysis = workflow.jobs.codeql.steps.find(step => step.id === 'codeql-analyze');
  const options = JSON.parse(analysis.env.CODEQL_ACTION_EXTRA_OPTIONS.match(/'(\\{\"database\".*?\\})'/u)[1]);
  // The retained action supplies this option before appending extra options.
  // CodeQL treats its positive and negative spellings as the same option.
  const arguments_ = ['--expect-discarded-cache', ...options.database['run-queries']];
  const spellings = arguments_.filter(value => /^--(?:no-)?expect-discarded-cache$/u.test(value));
  assert.equal(spellings.length, 1, 'CodeQL rejects duplicate positive/negative boolean options');
});

"""
text=text.replace(marker,new+marker)
test.write_text(text)
with (out/'codeql-options-before.log').open('w') as stream:
    result=subprocess.run(['node','--max-old-space-size=192','--test','--test-concurrency=1',str(test.relative_to(root))],cwd=root,stdout=stream,stderr=subprocess.STDOUT)
assert result.returncode!=0
workflow=root/'.github/workflows/security.yml'
text=workflow.read_text()
assert text.count('"--no-expect-discarded-cache",')==1
text=text.replace('"--no-expect-discarded-cache",','')
text=text.replace('# Retain its stages for the following name-binding and control-flow\n          # observations; hosted execution must qualify their cache reuse.', '# Keep available cached stages for the following observations. The action\n          # supplies --expect-discarded-cache; its inverse cannot be appended.\n          # Hosted execution must qualify actual cache reuse.')
workflow.write_text(text)
text=test.read_text().replace("'--no-expect-discarded-cache', '--keep-full-cache',", "'--keep-full-cache',")
test.write_text(text)
path=root/'rust/src/link_store.rs'
text=path.read_text()
assert text.count('use std::fmt;')==1 and 'use std::fmt::Write as _;' not in text
text=text.replace('use std::fmt;', 'use std::fmt;\n#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]\nuse std::fmt::Write as _;')
path.write_text(text)
readme=root/'experiments/issue-1580/codeql-macro-contexts/README.md'
text=readme.read_text()
first=text.index('The opt-in Rust investigation retains intermediate results')
last=text.index('\nCache option contracts:',first)
text=text[:first]+'''The opt-in Rust investigation requests retention of available intermediate
results from the standard analysis and both observers. Run 44848465533 compiled
the payload query but timed out during whole-database name binding before its
control-flow result was available. Cache eviction as the cause remains an
inference. Run 44855577716 rejected the attempted inverse of the action's
`--expect-discarded-cache`: positive and negative spellings are one CLI option,
and appending the inverse is a duplicate rather than an override. No standard
SARIF or payload observation was produced by that failed Rust analysis.

The investigation now appends only `--keep-full-cache --max-disk-cache=4096`.
The action still supplies its planning expectation; retaining available cache
does not prove that the producer computes every relation needed by an observer.
Both observers retain a 4096 MiB disk cache. The four-minute step bounds, memory
policy, nine output columns and security gate still apply. Hosted execution
must qualify this repair; fixture regressions do not execute CodeQL or establish
macro semantics.
''' +text[last:]
readme.write_text(text)
print('Added failing duplicate-option regression; removed unsupported inverse; restored cfg-scoped native formatting trait.')
