from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/bd6-native-format-commit')
out.mkdir(exist_ok=False)
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).strip()
records=[]
for name,args in [('format',['rustfmt','--check','--edition','2024','rust/src/link_store.rs']),('stage',['git','add','--','rust/src/link_store.rs']),('commit',['git','commit','-m','fix: retain formatting trait in native link renderer'])]:
 r=subprocess.run(args,cwd=root,capture_output=True,text=True)
 (out/(name+'.stdout')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
 records.append({'name':name,'argv':args,'exitCode':r.returncode});assert r.returncode==0,(name,r.stderr)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
(out/'outcome.json').write_text(json.dumps({'head':head,'records':records,'pushExecuted':False,'nativeCompiled':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print(head)
