from pathlib import Path
import subprocess,json,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/bd6-feedback-preparation')
out.mkdir(exist_ok=False)
calls=[('issue',['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','body,title,state,updatedAt']),('issue-comments',['gh','api','repos/link-assistant/formal-ai/issues/1580/comments','--paginate']),('pr-comments',['gh','api','repos/link-assistant/formal-ai/issues/1581/comments','--paginate']),('inline-comments',['gh','api','repos/link-assistant/formal-ai/pulls/1581/comments','--paginate']),('reviews',['gh','api','repos/link-assistant/formal-ai/pulls/1581/reviews','--paginate'])]
records=[]
for name,args in calls:
 p=out/(name+'.json')
 with p.open('w') as stream:
  r=subprocess.run(args,cwd=root,stdout=stream,stderr=subprocess.PIPE,text=True)
 (out/(name+'.stderr')).write_text(r.stderr)
 assert r.returncode==0,(name,r.stderr)
 data=json.loads(p.read_text())
 records.append({'name':name,'argv':args,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'count':len(data) if isinstance(data,list) else None})
 print(name,flush=True)
 if isinstance(data,list):
  for row in data: print(json.dumps({key:row.get(key) for key in ['id','html_url','body','state','created_at','updated_at']},ensure_ascii=False),flush=True)
 else: print(json.dumps(data,ensure_ascii=False),flush=True)
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
