from pathlib import Path
import subprocess, json, os, hashlib
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/repository-qa-source-navigation')
commands=[
 ['rustfmt','--edition','2024','rust/src/history_context/repository_qa.rs','rust/tests/unit/issue_1180_repository_qa.rs'],
 ['node','--max-old-space-size=192','--test','--test-concurrency=1','rust/tests/web/issue-1180-repository-qa.test.mjs'],
 ['node','--max-old-space-size=192','scripts/translate-js-rust.mjs','--verify'],
 ['node','experiments/formal_ai_subagent/local-gates.mjs','--list'],
]
results=[]
for index,command in enumerate(commands):
    log=out/f'focused-{index}.log'
    with log.open('w') as stream:
        result=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
    results.append({'command':command,'status':result.returncode,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
    print(json.dumps(results[-1]),flush=True)
(out/'focused-results.json').write_text(json.dumps(results,indent=2)+'\n')
