from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,gzip,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
out=scratch/'bd6-ci-repair-preflight';out.mkdir(exist_ok=False)
records=[]
def run(name,args,parsed=False,checked=True):
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 records.append({'name':name,'argv':args,'exitCode':r.returncode});(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
 if checked:assert r.returncode==0,(name,(out/(name+'.stderr')).read_text(errors='replace')[-1500:])
 return json.loads((out/(name+'.stdout')).read_text()) if parsed else (out/(name+'.stdout')).read_text()
assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
run('fetch-main',['git','fetch','origin','main'])
main=run('main',['git','rev-parse','origin/main']).strip()
run('main-ancestor',['git','merge-base','--is-ancestor',main,'HEAD'])
counts={}
for name,endpoint in [('issue-comments','issues/1580/comments'),('pr-comments','issues/1581/comments'),('inline-comments','pulls/1581/comments'),('reviews','pulls/1581/reviews')]:
 pages=run(name,['gh','api','repos/link-assistant/formal-ai/'+endpoint,'--paginate','--slurp'],True)
 actual=[row for page in pages for row in page]
 previous=json.loads((scratch/'bd6-feedback-preparation'/(name+'.json')).read_text())
 assert actual==previous,('New or changed feedback needs complete review',name)
 counts[name]=len(actual)
pull=run('pull-request',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','title,body,isDraft,headRefOid,state,baseRefName,mergeStateStatus'],True)
assert pull['isDraft'] and pull['state']=='OPEN' and pull['baseRefName']=='main'
assert pull['headRefOid']=='bd6fe77b98aa1cb89c53bfc0667107f6afb13122'
assert pull['body'].rstrip('\n')==(scratch/'cache-warning-publication/pull-request-body.md').read_text().rstrip('\n')
for state in ['in_progress','queued']:
 assert not run(state,['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--status',state,'--limit','100','--json','databaseId,workflowName,headSha'],True)
run('complete-pull-request-diff',['gh','pr','diff','1581','--repo','link-assistant/formal-ai'],checked=False)
run('repair-source-diff',['git','diff','bd6fe77b98aa1cb89c53bfc0667107f6afb13122','--','.github/workflows/security.yml','data/benchmarks/fast-pull-request-retained-jobs.json','data/meta/js-rust-translation.lino','data/meta/translation-blockers.lino','js/agentic/crate/history_repository_qa.mjs','rust/src/history_context.rs','rust/src/history_context/repository_qa.rs','rust/src/link_store.rs','rust/tests/unit/issue_1180_repository_qa.rs','rust/tests/unit/reasoning_contracts.rs','rust/tests/web/issue-1180-repository-qa.test.mjs','rust/tests/fixtures/js-rust-translation/crate/history_repository_qa.rs','experiments/issue-1580/codeql-included-string-observation.test.mjs','experiments/issue-1580/codeql-macro-contexts/README.md'])
outcome={'observedAt':datetime.now(timezone.utc).isoformat(),'passed':True,'main':main,'feedbackCounts':counts,'emptyQueues':True,'mainAncestor':True,'isDraft':True,'previousPublishedHead':pull['headRefOid'],'fullPullRequestDiffLiterallyReviewed':False,'independentAuthorshipCredit':0,'fullIssueComplete':False}
(out/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome))
