from pathlib import Path
import json, gzip, hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
archive=root/'experiments/issue-1580/evidence/checks/bd6-ci-root-cause-repair'
manifest=json.loads((archive/'inventory.json').read_text());renames=[]
for part in manifest['parts']:
 path=archive/part['file']; rows=json.loads(path.read_text())
 for row in rows:
  if '-pr-comments' in row['file']:
   previous=row['file'];row['file']=previous.replace('-pr-comments','-pull-request-comments')
   assert not (archive/row['file']).exists()
   (archive/previous).rename(archive/row['file']);renames.append([previous,row['file']])
 raw=(json.dumps(rows,indent=2)+'\n').encode();path.write_bytes(raw);part['sha256']=hashlib.sha256(raw).hexdigest()
assert len(renames)==4
sources=[scratch/'verify-and-commit-bd6-ci-repair.log',scratch/'bd6-ci-repair-final-commits/documentation-gates.stdout',scratch/'bd6-post-archive-abbreviated-filenames.log',Path(__file__)]
rows=[]
for number,source in enumerate(sources,1):
 raw=source.read_bytes();packed=gzip.compress(raw,mtime=0);name=f'post-archive-initial-{number:02d}-'+source.name+'.gz';(archive/name).write_bytes(packed)
 rows.append({'source':str(source),'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
name='inventory-06.json';raw=(json.dumps(rows,indent=2)+'\n').encode();(archive/name).write_bytes(raw)
manifest['parts'].append({'file':name,'records':len(rows),'sha256':hashlib.sha256(raw).hexdigest()});manifest['records']+=len(rows)
(archive/'inventory.json').write_text(json.dumps(manifest,indent=2)+'\n')
p=archive/'outcome.json';outcome=json.loads(p.read_text());outcome['retainedSources']=manifest['records'];outcome['attemptFailures'].append('Post-archive abbreviation check rejected four evidence filenames containing pr; archive filenames now spell pull-request, original source names and failure logs remain preserved.')
p.write_text(json.dumps(outcome,indent=2)+'\n')
for p in [root/'docs/case-studies/issue-1580/current-source-ci-repair-checkpoint.md',root/'docs/case-studies/issue-1580/source-warning-extraction-checkpoint.md',root/'experiments/issue-1580/work-plan.md']:
 text=p.read_text();sentence='Initial failed helper and harness attempts remain\nseparate retained observations and receive no verification credit.'
 assert text.count(sentence)==1
 text=text.replace(sentence,sentence+' The post-archive\nabbreviation check also rejected four abbreviated evidence filenames; their\nfull-word renames and original failed check remain retained before retry.')
 p.write_text(text)
print(json.dumps({'renamed':renames,'records':manifest['records'],'productionCodeChanged':False,'independentAuthorshipCredit':0}))
