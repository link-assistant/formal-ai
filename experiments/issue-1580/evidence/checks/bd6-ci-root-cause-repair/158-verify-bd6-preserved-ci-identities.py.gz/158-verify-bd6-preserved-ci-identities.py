from pathlib import Path
import hashlib, gzip, json
root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/ci/native-families-bd6fe77b'
records=json.loads((base/'records.json').read_text()); count=0
for record in records:
    for key in ['stdout','stderr']:
        row=record[key]; packed=(base/row['file']).read_bytes(); raw=gzip.decompress(packed)
        assert hashlib.sha256(packed).hexdigest()==row['archiveSha256'],row['file']
        assert hashlib.sha256(raw).hexdigest()==row['rawSha256'],row['file']
        assert len(raw)==row['bytes'] and len(raw.splitlines())==row['lines'],row['file']
        count+=1
latest=json.loads((base/'latest.json').read_text()); assert latest['completed']==latest['workflowCount']==27
jobs=[]
for record in records:
    if record['name']=='jobs-44855584441':
        jobs=json.loads(gzip.decompress((base/record['stdout']['file']).read_bytes()))['jobs']
failed_native=[{'name':j['name'],'conclusion':j['conclusion'],'url':j.get('url')} for j in jobs if j['conclusion']=='failure']
summary={'head':latest['head'],'commandRecords':len(records),'verifiedStreams':count,'workflowCount':27,'success':23,'skipped':1,'failed':latest['failed'],'failedPipelineJobs':failed_native,'literalWholeLogReviewComplete':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(base/'identity-verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
