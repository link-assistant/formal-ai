from pathlib import Path
import subprocess, json, hashlib
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/bd6-draft-review/final-projections.diff')
args=['git','diff','--','data/meta/js-rust-translation.lino','data/meta/translation-blockers.lino','rust/tests/fixtures/js-rust-translation/crate/history_repository_qa.rs']
r=subprocess.run(args,cwd=root,capture_output=True,check=True)
out.write_bytes(r.stdout)
print(json.dumps({'path':str(out),'lines':len(r.stdout.splitlines()),'bytes':len(r.stdout),'sha256':hashlib.sha256(r.stdout).hexdigest()}))
