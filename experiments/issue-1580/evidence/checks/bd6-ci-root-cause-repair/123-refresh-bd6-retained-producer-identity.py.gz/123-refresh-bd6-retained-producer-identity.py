from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
code=r'''
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import YAML from 'yaml';
const file='.github/workflows/security.yml';
const old=YAML.parse(execFileSync('git',['show','HEAD:'+file],{encoding:'utf8'})).jobs.codeql;
const current=YAML.parse(fs.readFileSync(file,'utf8')).jobs.codeql;
const payload=j=>({steps:j.steps,uses:j.uses,with:j.with,strategy:j.strategy});
const hash=j=>createHash('sha256').update(JSON.stringify(payload(j))).digest('hex');
const path='data/benchmarks/fast-pull-request-retained-jobs.json';
const manifest=JSON.parse(fs.readFileSync(path,'utf8'));
const row=manifest.jobs.find(row=>row.file==='security.yml'&&row.id==='codeql');
assert.equal(row.payloadSha256,hash(old));
const before=old.steps.find(s=>s.id==='codeql-analyze');
const after=current.steps.find(s=>s.id==='codeql-analyze');
const oldOptions=before.env.CODEQL_ACTION_EXTRA_OPTIONS;
assert.equal(after.env.CODEQL_ACTION_EXTRA_OPTIONS,oldOptions.replace('"--no-expect-discarded-cache",',''));
before.env=after.env;
assert.deepEqual(current,old,'Only the rejected duplicate CLI option changes the retained producer payload');
row.payloadSha256=hash(current);
fs.writeFileSync(path,JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({payloadSha256:row.payloadSha256,onlyRejectedInverseRemoved:true,jobAdmissionUnchanged:true}));
'''
r=subprocess.run(['node','--input-type=module','-e',code],cwd=root)
raise SystemExit(r.returncode)
