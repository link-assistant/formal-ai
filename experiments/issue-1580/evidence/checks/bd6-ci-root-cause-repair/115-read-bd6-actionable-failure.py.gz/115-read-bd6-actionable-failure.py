from pathlib import Path
import gzip
import json
import re
root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/ci/native-families-bd6fe77b'
scratch = Path('/tmp/issue-1580-research')
latest = json.loads((base / 'latest.json').read_text())
print('OBSERVATION', json.dumps({key: value for key, value in latest.items() if key != 'runs'}))
for run in latest['failed']:
    path = base / ('failed-run-' + str(run['id']) + '.stdout.gz')
    if not path.exists():
        print('LOG NOT YET RETAINED', run)
        continue
    lines = gzip.decompress(path.read_bytes()).decode(errors='replace').splitlines()
    print('FULL LOG', path.relative_to(root), 'LINES', len(lines))
    pattern = re.compile(r'##\[error\]|✖|not ok \d|AssertionError|::error')
    hits = [i for i, line in enumerate(lines) if pattern.search(line)]
    selected = sorted({n for i in hits for n in range(max(0, i-4), min(len(lines), i+9))})
    target = scratch / ('actionable-' + str(run['id']) + '.txt')
    target.write_text('\n'.join(str(i+1) + ': ' + lines[i] for i in selected) + '\n')
    print('HITS', [i+1 for i in hits], 'EXTRACT', str(target), 'LINES', len(selected))
    if target.stat().st_size < 22000:
        print(target.read_text())
