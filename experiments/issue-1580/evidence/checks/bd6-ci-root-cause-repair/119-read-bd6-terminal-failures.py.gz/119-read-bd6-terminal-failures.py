from pathlib import Path
import gzip, json, re
root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/ci/native-families-bd6fe77b'
d=json.loads((base/'latest.json').read_text())
print(json.dumps({k:v for k,v in d.items() if k!='runs'},indent=2))
for run in d['failed']:
    files=list(base.glob(f'failed-run-{run["id"]}.stdout.gz'))
    if not files:
        print('PENDING LOG',run['id']);continue
    lines=gzip.decompress(files[0].read_bytes()).decode().splitlines()
    matches=[i for i,l in enumerate(lines) if any(s in l for s in ['::error::','error[E','error: could not compile','not ok ','Query timed out','query timed out','Process completed with exit code'])]
    seen=set()
    print('LOG',str(files[0]),'lines',len(lines),'matches',len(matches))
    for i in matches:
        for j in range(max(0,i-2),min(len(lines),i+4)):
            if j not in seen:
                print(f'{j+1}: {lines[j]}'); seen.add(j)
producer=Path('/tmp/issue-1580-research/collect-cache-warning-producer-reports.py').read_text().splitlines()
print('PRODUCER COLLECTOR FAILURE CONTEXT')
for i in range(70,min(108,len(producer))):print(f'{i+1}: {producer[i]}')
PY_PLACEHOLDER = None
