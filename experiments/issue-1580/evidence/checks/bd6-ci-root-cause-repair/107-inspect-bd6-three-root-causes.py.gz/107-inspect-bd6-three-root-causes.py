from pathlib import Path
import gzip, json
root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/ci/native-families-bd6fe77b'
for name,first,last in [('failed-run-44855584441.stdout.gz',43865,43891),('failed-run-44855577716.stdout.gz',1700,1961)]:
    lines=gzip.decompress((base/name).read_bytes()).decode().splitlines()
    print('SOURCE',name)
    for i in range(first-1,min(last,len(lines))):print(f'{i+1}: {lines[i]}')
for relative,first,last in [('rust/src/link_store.rs',1,68),('rust/src/link_store/record_fields.rs',1,35)]:
    print('SOURCE',relative)
    lines=(root/relative).read_text().splitlines()
    for i in range(first-1,min(last,len(lines))):print(f'{i+1}: {lines[i]}')
p=Path('/tmp/issue-1580-research/collect-cache-warning-producer-reports.py')
print('COLLECTOR')
for i,l in enumerate(p.read_text().splitlines(),1):
    if 70<=i<=100:print(f'{i}: {l}')
print('BEFORE TEST')
print(Path('/tmp/issue-1580-research/repository-qa-source-navigation/before.log').read_text())
