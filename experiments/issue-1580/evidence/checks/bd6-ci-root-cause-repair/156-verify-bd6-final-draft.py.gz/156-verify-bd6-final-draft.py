from pathlib import Path
import subprocess,os,json,sys,time,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/bd6-final-draft-validation')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('wb') as stream:
  child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':child.pid,'directory':str(out)}));sys.exit(0)
# Never overlap the CPU/memory of the existing complete sequential gate pass.
for attempt in range(100):
 try: state=Path('/proc/3552565/stat').read_text().split()[2]
 except FileNotFoundError: break
 if state=='Z': break
 time.sleep(10)
else: raise RuntimeError('Prior owned gate worker has not completed; no concurrent checks launched')
commands=[
 ('translation-writer',['node','scripts/translate-js-rust.mjs','--write','--fetch','--jobs','1','js/agentic/crate/history_repository_qa.mjs']),
 ('translation-currency',['node','scripts/translate-js-rust.mjs','--verify']),
 ('repository-qa',['node','--test','--test-concurrency=1','rust/tests/web/issue-1180-repository-qa.test.mjs']),
 ('codeql-options',['node','--test','--test-concurrency=1','experiments/issue-1580/codeql-included-string-observation.test.mjs']),
 ('strict-security',['node','--test','--test-concurrency=1','rust/tests/web/security-codeql-results.test.mjs']),
 ('production-profile',['node','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs']),
 ('rustfmt',['rustfmt','--check','--edition','2024','rust/src/link_store.rs','rust/src/history_context.rs','rust/src/history_context/repository_qa.rs','rust/tests/unit/issue_1180_repository_qa.rs','rust/tests/unit/reasoning_contracts.rs']),
 ('all-gates',['node','experiments/formal_ai_subagent/local-gates.mjs']),
 ('whitespace',['git','diff','--check']),
]
records=[]
for name,args in commands:
 start=time.monotonic(); log=out/(name+'.log')
 with log.open('w') as stream: r=subprocess.run(args,cwd=root,env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256'),stdout=stream,stderr=subprocess.STDOUT)
 record={'name':name,'argv':args,'exitCode':r.returncode,'seconds':round(time.monotonic()-start,3),'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 records.append(record);(out/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
 if r.returncode:
  (out/'outcome.json').write_text(json.dumps({'passed':False,'failed':name,'records':records,'nativeExecution':False},indent=2)+'\n');sys.exit(r.returncode)
(out/'outcome.json').write_text(json.dumps({'passed':True,'records':records,'nativeExecution':False,'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
