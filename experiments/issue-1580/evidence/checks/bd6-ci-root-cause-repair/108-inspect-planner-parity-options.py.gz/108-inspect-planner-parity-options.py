from pathlib import Path
root = Path('/tmp/gh-issue-solver-1794900398048')
for label,path,first,last in [
 ('old-native',Path('/tmp/issue-1580-research/repository-qa-source-navigation/rust_src_history_context_repository_qa.rs'),1,165),
 ('js',root/'js/agentic/crate/history_repository_qa.mjs',1,155),
 ('exports',root/'rust/src/history_context.rs',1,125),
 ('planner-check',root/'scripts/check-planner-twins.mjs',1,175),
]:
 print(label,flush=True)
 for line,text in enumerate(path.read_text().splitlines(),1):
  if first<=line<=last: print(f'{line}: {text}')
