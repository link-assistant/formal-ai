from pathlib import Path
import subprocess, os, json, time, sys, hashlib, traceback
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/bd6-ci-repair-validation-retry')
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as log:
        p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({'pid':p.pid,'out':str(out)}));sys.exit(0)
records=[]
def run(name,argv,required=True):
    started=time.monotonic(); log=out/(name+'.log')
    with log.open('w') as stream:
        r=subprocess.run(argv,cwd=root,env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=192'),stdout=stream,stderr=subprocess.STDOUT)
    records.append({'name':name,'argv':argv,'exitCode':r.returncode,'seconds':round(time.monotonic()-started,3),'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
    (out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(records[-1]),flush=True)
    if required:assert r.returncode==0,name
try:
    run('rust-format',['rustfmt','--edition','2024','rust/src/link_store.rs'])
    run('translation-writer',['node','--max-old-space-size=256','scripts/translate-js-rust.mjs','--write','--fetch','--jobs','1','js/agentic/crate/history_repository_qa.mjs'])
    run('translation-currency',['node','scripts/translate-js-rust.mjs','--verify'])
    for name,path in [('repository-qa','rust/tests/web/issue-1180-repository-qa.test.mjs'),('codeql-options','experiments/issue-1580/codeql-included-string-observation.test.mjs'),('security','rust/tests/web/security-codeql-results.test.mjs'),('profile','rust/tests/web/fast-pull-request-production-profile.test.mjs')]:
        run(name,['node','--test','--test-concurrency=1',path],required=name!='profile')
    run('diff-check',['git','diff','--check'])
    (out/'outcome.json').write_text(json.dumps({'passed':True,'nativeExecution':False,'allGatesPending':True,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc(),'records':records},indent=2)+'\n')
    traceback.print_exc();sys.exit(1)
