from pathlib import Path
import json, gzip, hashlib
root=Path('/tmp/gh-issue-solver-1794900398048')
scratch=Path('/tmp/issue-1580-research/cache-warning-producer-original-reports')
base=root/'experiments/issue-1580/evidence/ci/codeql-producer-bd6fe77b'
records=json.loads((base/'records.json').read_text())
artifact_record=next(r for r in records if r['name']=='artifacts')
pages=json.loads(gzip.decompress((base/artifact_record['stdout']['file']).read_bytes()))
artifacts=[a for page in pages for a in page['artifacts']]
copied=[]
for artifact in artifacts:
    if not artifact['name'].startswith(('codeql-results-','codeql-rust-contexts-')):continue
    destination=scratch/'download'/str(artifact['id'])
    assert destination.is_dir()
    for source in sorted(destination.rglob('*')):
        if not source.is_file():continue
        assert not source.is_symlink()
        relative=source.relative_to(destination).as_posix()
        name=('producer-'+str(artifact['id'])+'-'+relative.replace('/','_')+'.gz').replace('_temp_','_temporary_').replace('_src_','_source_')
        raw=source.read_bytes(); packed=(base/name).read_bytes()
        assert gzip.decompress(packed)==raw
        copied.append({'artifact':artifact,'relativePath':relative,'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
sarif=[r['relativePath'] for r in copied if r['relativePath'].endswith('.sarif')]
manifest={'format':'partitioned-producer-inventory','records':len(copied),'parts':[]}
for i in range(0,len(copied),20):
    name=f'producer-files-{i//20+1:02}.json';raw=(json.dumps(copied[i:i+20],indent=2)+'\n').encode()
    (base/name).write_bytes(raw);manifest['parts'].append({'file':name,'records':len(copied[i:i+20]),'sha256':hashlib.sha256(raw).hexdigest()})
(base/'producer-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
outcome={'captureComplete':True,'producerAnalysisComplete':False,'head':'bd6fe77b98aa1cb89c53bfc0667107f6afb13122','runId':44855577716,'url':'https://github.com/link-assistant/formal-ai/actions/runs/44855577716','conclusion':'failure','producerFiles':len(copied),'sarifReports':sarif,'rustSarifMissing':True,'macroObservationsMissing':True,'reason':'CLI rejected duplicate --expect-discarded-cache and --no-expect-discarded-cache before query execution','firstCollectorIncorrectlyExpectedTwoSarifReports':True,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(base/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
(scratch/'recovered-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome,indent=2))
