from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');base=scratch/'bd6-ci-repair-publication'
records=[]
def run(name,args,parsed=False):
 r=subprocess.run(args,cwd=root,capture_output=True,text=True)
 (base/(name+'.stdout')).write_text(r.stdout);(base/(name+'.stderr')).write_text(r.stderr)
 records.append({'name':name,'argv':args,'exitCode':r.returncode});(base/'publication-records.json').write_text(json.dumps(records,indent=2)+'\n')
 assert r.returncode==0,(name,r.stderr[-1500:])
 return json.loads(r.stdout) if parsed else r.stdout
assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
assert not run('status-before',['git','status','--porcelain']).strip()
head=run('head',['git','rev-parse','HEAD']).strip()
assert head==json.loads((base/'expected-head.json').read_text())['head']
assert json.loads((base/'seal.json').read_text())['passed']
assert json.loads((scratch/'bd6-final-draft-validation/outcome.json').read_text())['passed']
run('fetch-main',['git','fetch','origin','main'])
main=run('main',['git','rev-parse','origin/main']).strip()
run('main-ancestor',['git','merge-base','--is-ancestor',main,head])
for state in ['in_progress','queued']:
 assert not run(state,['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--status',state,'--limit','100','--json','databaseId,workflowName,headSha'],True)
for name,endpoint in [('issue-comments','issues/1580/comments'),('pr-comments','issues/1581/comments'),('inline-comments','pulls/1581/comments'),('reviews','pulls/1581/reviews')]:
 pages=run(name,['gh','api','repos/link-assistant/formal-ai/'+endpoint,'--paginate','--slurp'],True)
 assert [row for page in pages for row in page]==json.loads((scratch/'bd6-feedback-preparation'/(name+'.json')).read_text()),('Changed feedback',name)
previous='bd6fe77b98aa1cb89c53bfc0667107f6afb13122'
assert run('remote-before',['git','ls-remote','origin','refs/heads/issue-1580-8d61a32a61e1']).split()[0]==previous
observed=json.loads((root/'experiments/issue-1580/evidence/ci/native-families-bd6fe77b/outcome.json').read_text())
assert observed['complete'] and observed['workflowCount']==27 and observed['success']==23
assert {row['id'] for row in observed['failed']}=={44855584149,44855584441,44855577716}
pull=run('pull-request-before',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','isDraft,headRefOid,state,body'],True)
assert pull['isDraft'] and pull['state']=='OPEN' and pull['headRefOid']==previous
assert pull['body'].rstrip('\n')==(scratch/'cache-warning-publication/pull-request-body.md').read_text().rstrip('\n')
body=base/'pull-request-body.md';assert body.read_text().count('Fixes #1580')==1
run('push',['git','-c','pack.threads=1','-c','pack.windowMemory=16m','-c','pack.deltaCacheSize=16m','push','origin','HEAD:refs/heads/issue-1580-8d61a32a61e1'])
assert run('remote-after',['git','ls-remote','origin','refs/heads/issue-1580-8d61a32a61e1']).split()[0]==head
run('edit-description',['gh','pr','edit','1581','--repo','link-assistant/formal-ai','--title','Repair CI admission, release observations and source boundaries','--body-file',str(body)])
run('dispatch-security',['gh','workflow','run','security.yml','--repo','link-assistant/formal-ai','--ref','issue-1580-8d61a32a61e1','-f','codeql=true','-f','macro-contexts=true'])
assert not run('status-after',['git','status','--porcelain']).strip()
outcome={'complete':True,'head':head,'main':main,'pushExecuted':True,'manualSecurityDispatched':True,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(base/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))
