from pathlib import Path
import subprocess, os, sys, time, json, hashlib
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/bd6-all-javascript-gates')
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:
        child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({'pid':child.pid,'directory':str(out)}));sys.exit(0)
prerequisite=Path('/tmp/issue-1580-research/bd6-ci-repair-validation-retry/outcome.json')
assert prerequisite.is_file() and json.loads(prerequisite.read_text())['passed']
commands=[
 ('rustfmt',['rustfmt','--check','--edition','2024','rust/src/history_context/repository_qa.rs','rust/src/link_store.rs','rust/tests/unit/issue_1180_repository_qa.rs','rust/tests/unit/reasoning_contracts.rs']),
 ('native-groups',['node','--test','--test-concurrency=1','experiments/issue-1580/native-regression-groups.test.mjs']),
 ('all-gates',['node','experiments/formal_ai_subagent/local-gates.mjs']),
 ('whitespace',['git','diff','--check'])]
results=[]
for name,args in commands:
    start=time.monotonic();log=out/(name+'.log')
    with log.open('w') as stream:
        result=subprocess.run(args,cwd=root,env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256'),stdout=stream,stderr=subprocess.STDOUT)
    record={'name':name,'argv':args,'exitCode':result.returncode,'seconds':round(time.monotonic()-start,3),'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    results.append(record);(out/'records.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(record),flush=True)
    if result.returncode:sys.exit(result.returncode)
(out/'outcome.json').write_text(json.dumps({'passed':True,'nativeExecution':False,'javascriptHeapMiB':256,'records':results,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
