from pathlib import Path
import subprocess, json, hashlib
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/bd6-planner-parity-repair')
out.mkdir(exist_ok=False)
changed = ['js/agentic/crate/history_repository_qa.mjs','rust/src/history_context/repository_qa.rs','rust/src/history_context.rs','rust/tests/web/issue-1180-repository-qa.test.mjs','rust/tests/unit/issue_1180_repository_qa.rs']
before = {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in changed}
p = root/changed[0]
text = p.read_text()
start = text.index('// The claim halves')
end = text.index('\nimport ', start)
text = text[:start]+'''// Status and definition subjects, current-source navigation, documentation and
// answer rendering mirror the native route. Hosts supply current source modules,
// source text, formalized commits and the measured range. The historical census
// decoder remains available for diagnostics; it does not locate live definitions.
'''+text[end:]
text = text.replace('/** Current owned-source navigation, mirroring the native census_symbols lookup.', '/** Mirrors `census_symbols` for current owned-source navigation.')
text = text.replace('/** Decode historical census records for diagnostics; live lookup uses sourceSymbols. */', '/** Mirrors `census_document_symbols` for historical diagnostics only.\n * Live lookup uses sourceSymbols over current source modules.\n */')
p.write_text(text)
old = Path('/tmp/issue-1580-research/repository-qa-source-navigation/rust_src_history_context_repository_qa.rs').read_text()
start = old.index('/// The symbols one census document records under its target.')
end = old.index('/// Every symbol the self-AST census under `root` records.', start)
decoder = old[start:end].replace('/// The symbols one census document records under its target.\nfn ', '/// Decode a historical census for diagnostics, never live definition lookup.\n#[must_use]\npub fn ')
p = root/changed[1]
text = p.read_text()
marker = '/// Current source symbols below the configured Rust crate\'s `src` directory.'
assert text.count(marker)==1
p.write_text(text.replace(marker, decoder+marker))
p = root/changed[2]
text = p.read_text()
assert text.count('CensusSymbol, census_symbols, definition_answer,')==1
p.write_text(text.replace('CensusSymbol, census_symbols, definition_answer,','CensusSymbol, census_document_symbols, census_symbols, definition_answer,'))
p = root/changed[3]
text = p.read_text()
marker = '  const current = join(sourceDirectory, \'current.rs\');'
assert text.count(marker)==1
text = text.replace(marker, '''  // Legacy decoding remains compatible, but its stale positions confer no authority.
  assert.deepEqual(qa.censusDocumentSymbols(readFileSync(join(legacyDirectory, 'current.lino'), 'utf8')),
    [{ target: 'src/current.rs', kind: 'function', name: 'measured_value', start: 1, end: 1 },
      { target: 'src/current.rs', kind: 'function', name: 'historical_only', start: 8, end: 8 }]);
'''+marker)
p.write_text(text)
p = root/changed[4]
text = p.read_text()
marker = '    let current = source_directory.join("current.rs");'
assert text.count(marker)==1
text = text.replace(marker, '''    // Historical decoding is diagnostic; current navigation ignores these spans.
    let historical = history_context::census_document_symbols(
        &std::fs::read_to_string(legacy_directory.join("current.lino")).expect("legacy record"),
    );
    assert_eq!(historical.len(), 2);
    assert_eq!(historical[0].start, 1);
    assert_eq!(historical[1].name, "historical_only");
'''+marker)
p.write_text(text)
subprocess.run(['rustfmt','--edition','2024',changed[1],changed[2],changed[4]],cwd=root,check=True)
(out/'edits.json').write_text(json.dumps({'before':before,'after':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in changed},'independentAuthorshipCredit':0,'nativeExecuted':False},indent=2)+'\n')
print('Restored diagnostic parity and cited the actual live source twin; no gate exemptions or census refresh.')
