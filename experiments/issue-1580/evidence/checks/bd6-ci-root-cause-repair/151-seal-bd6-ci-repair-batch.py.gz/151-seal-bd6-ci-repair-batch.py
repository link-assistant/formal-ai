from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,gzip,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048'); scratch=Path('/tmp/issue-1580-research')
final=json.loads((scratch/'bd6-final-draft-validation/outcome.json').read_text())
assert final['passed'] and not final['nativeExecution']
ci=root/'experiments/issue-1580/evidence/ci/native-families-bd6fe77b'
identities=json.loads((ci/'identity-verification.json').read_text())
producer=root/'experiments/issue-1580/evidence/ci/codeql-producer-bd6fe77b'
assert json.loads((producer/'outcome.json').read_text())['captureComplete']
archive=root/'experiments/issue-1580/evidence/checks/bd6-ci-root-cause-repair'
archive.mkdir(exist_ok=False)
directories=['bd6-feedback-preparation','repository-qa-source-navigation','bd6-ci-repair-validation','bd6-ci-repair-validation-retry','bd6-all-javascript-gates','bd6-final-draft-validation','bd6-planner-parity-repair','bd6-draft-review','bd6-native-format-commit']
stems=['repair-repository-qa-source-navigation','check-repository-qa-source-navigation','repair-bd6-remaining-ci-failures','refresh-bd6-retained-producer-identity','include-native-repository-qa-contract','verify-bd6-ci-repairs','run-bd6-all-javascript-gates','verify-bd6-final-draft','repair-bd6-planner-parity','inspect-planner-parity-options','read-bd6-publication-inputs','review-bd6-draft-diff','finalize-bd6-producer-capture','verify-bd6-preserved-ci-identities','read-bd6-actionable-failure','read-bd6-terminal-failures','inspect-bd6-three-root-causes','seal-bd6-ci-repair-batch']
directories.append('bd6-ci-repair-preflight')
directories.append('bd6-collection-controller-sources')
stems.extend(['commit-bd6-native-format-import','preflight-bd6-repair-publication','publish-bd6-ci-repair','collect-bd6-repaired-head-ci','collect-bd6-repaired-producer','freeze-bd6-collection-controllers','record-rust-registry-latest-review','review-bd6-final-projection'])
sources=set()
for directory in directories:
 sources.update(p for p in (scratch/directory).rglob('*') if p.is_file())
for stem in stems:
 sources.update(p for p in scratch.glob(stem+'*') if p.is_file())
for name in ['repository-qa-stale-navigation.before-wrapper.log','bd6-planner-twins.log','planner-parity-options.log','planner-parity-options-retry.log','verify-bd6-preserved-ci-identities.log']:
 p=scratch/name
 if p.is_file():sources.add(p)
for name in ['failure.json','recovered-outcome.json','worker.log']:
 p=scratch/'cache-warning-producer-original-reports'/name
 if p.is_file():sources.add(p)
inventory=[]
for n,source in enumerate(sorted(sources)):
 raw=source.read_bytes();packed=gzip.compress(raw,mtime=0)
 name=f'{n+1:03d}-'+source.name.replace('_src_','_source_')+'.gz'
 (archive/name).write_bytes(packed)
 inventory.append({'source':str(source.relative_to(scratch)),'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
# Include the actual complete driver requests, responses and source identities.
for source in sorted((root/'experiments/issue-1580/evidence/commands').glob('*.json')):
 data=json.loads(source.read_text())
 if not any(stem in data.get('request','') for stem in stems):continue
 raw=source.read_bytes();packed=gzip.compress(raw,mtime=0);name='command-'+source.name+'.gz';(archive/name).write_bytes(packed)
 inventory.append({'source':str(source.relative_to(root)),'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
parts=[]
for first in range(0,len(inventory),40):
 name=f'inventory-{first//40+1:02d}.json';raw=(json.dumps(inventory[first:first+40],indent=2)+'\n').encode()
 (archive/name).write_bytes(raw);parts.append({'file':name,'records':len(inventory[first:first+40]),'sha256':hashlib.sha256(raw).hexdigest()})
(archive/'inventory.json').write_text(json.dumps({'format':'partitioned-source-inventory','records':len(inventory),'parts':parts},indent=2)+'\n')
gate_lines=(scratch/'bd6-final-draft-validation/all-gates.log').read_text().splitlines()
gate_counts={state:sum(line.startswith(state+' ') for line in gate_lines) for state in ['PASS','SKIP','FAIL']}
assert gate_counts['FAIL']==0 and sum(gate_counts.values())==141,gate_counts
outcome={'observedAt':datetime.now(timezone.utc).isoformat(),'passed':True,'gateCounts':gate_counts,'retainedSources':len(inventory),'ciHead':'bd6fe77b98aa1cb89c53bfc0667107f6afb13122','ciRunCounts':{'success':23,'skipped':1,'failure':3},'verifiedCiCommandStreams':178,'verifiedProducerPayloads':110,'rustSarifAbsent':True,'macroObservationsAbsent':True,'wholeAggregateLogsLiterallyReviewed':False,'wholePullRequestDiffReviewed':False,'localNativeExecution':False,'hostedNativeAndCodeqlRepairQualificationPending':True,'independentAuthorshipCredit':0,'independentReasoningAccepted':0,'fullIssueComplete':False,'attemptFailures':['initial helper expected undeclared tempfile dependency before edits','first quoted wrapper request did not execute verbatim','first translator pin lookup expected .git in a source archive','first native contract include used the wrong parent path','first planner diagnostic helper path did not yet exist','initial full gate pass detected two unmatched planner functions','producer collector incorrectly required two SARIF reports after a failed Rust analysis']}
(archive/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
checkpoint='''Latest fully collected published head `bd6fe77b98aa1cb89c53bfc0667107f6afb13122`
has 27 terminal workflows: 23 success, one skip and three failures. All 178
retained original/compressed command streams verify by SHA256, bytes and lines.
All 110 downloaded original producer payloads match the retained archives.
The failed Rust producer has no SARIF or macro observations. An initial
collector incorrectly required two SARIF reports despite that failure; the
preserved capture was recovered with explicit missing-report status.

[Layered CI 44855584149](https://github.com/link-assistant/formal-ai/actions/runs/44855584149)
fails at full-log lines 8391–8411: a retired committed calculation line census
quotes another function's documentation after helper extraction. The maintained
JavaScript regression fails before repair. Native lookup now reuses the
existing current owned-source walker; its JavaScript counterpart consumes the
existing host's freshly observed modules. Tests cover edits, documentation
changes, moves, deletion and an ignored stale historical symbol. Historical
decoding remains diagnostic and compatible in both languages. No persisted
line census was refreshed or promoted to semantic authority.

[Pipeline 44855584441](https://github.com/link-assistant/formal-ai/actions/runs/44855584441)
fails at full-log lines 43869–43890 with E0599: moving record-field rendering
also moved the formatting trait needed by the parent node-address renderer.
The parent now imports that trait under the renderer's existing native feature
configuration. The hosted reasoning target now includes the complete existing
repository-QA module and its new live-source regression. No native compilation
or execution was performed locally; next-head CI must qualify both repairs.

[Security 44855577716](https://github.com/link-assistant/formal-ai/actions/runs/44855577716)
rejects the query command at full-log lines 1932–1961 because positive and
negative spellings of `expect-discarded-cache` are the same CLI option. The
attempted inverse was not an override. Remove only the rejected extra inverse;
keep available cache retention and the 4096 MiB disk cap for opt-in read-only
investigation. The action still supplies its planning expectation. The exact
query, nine output columns, strict SARIF gate, 4 GiB memory policy, two threads
and four-minute step bounds remain unchanged. Cache reuse and actual query
performance remain unqualified until hosted execution succeeds.

Both before/fixed JavaScript regressions are retained. The final six QA,
three CodeQL option/adapter, 22 strict-security and 18 production-profile cases
pass sequentially. The native-group suite separately passes all 50 cases.
Official pinned translation regeneration and currency verification pass;
Rust 2024 formatting and whitespace checks pass without a build. The first
complete gate pass exposed two planner parity gaps in the draft. Restoring the
historical diagnostic twin and citing the actual live-source twin resolves
them without changing the gate. The final complete 141-entry JavaScript replay
has GATE_PASS passed and GATE_SKIP explicit skips, zero failures, with a
256 MiB JavaScript heap. Initial failed helper and harness attempts remain
separate retained observations and receive no verification credit.

The earlier `bbda05c0` Pipeline passed 573 Rust tests and eight real registry
CLI cases. That evidence does not qualify later edits. Its completed macro
profile and original standard SARIF reports remain historical observations;
all 631 original unexpanded positions still lack per-child semantic security
qualification. Current source navigation is not complete CST reconstruction.

The latest source-size scan retains 92 warnings and zero ordinary or embedded
data violations under unchanged limits. Publish-token uncertainty, two Chrono
consumers and experimental unsafe-libyaml maintenance remain unresolved.
All eight full template comparisons/practices, original budgets and live
delivery/model identity, actual Pages fallback publication and served identity,
complete aggregate review and complete PR review remain unfinished. Rust
literal review reaches 353/373 identities and 51,512 lines. Strict dated original
whole-file acceptance stays 31/53 plus 22 scoped assertion reviews. Independent
Formal AI reasoning remains 0/20; supplied scripts, patches and conclusions
earn zero independent credit. PR #1581 stays draft and unmerged.

Evidence: `experiments/issue-1580/evidence/ci/native-families-bd6fe77b/`,
`experiments/issue-1580/evidence/ci/codeql-producer-bd6fe77b/` and
`experiments/issue-1580/evidence/checks/bd6-ci-root-cause-repair/`.
'''.replace('GATE_PASS',str(gate_counts['PASS'])).replace('GATE_SKIP',str(gate_counts['SKIP']))
for relative,start,end in [('experiments/issue-1580/work-plan.md','## Current verification checkpoint\n\n','\nEarlier chronology:'),('docs/case-studies/issue-1580/source-warning-extraction-checkpoint.md','## Current repair checkpoint\n\n','\n## Earlier dated observations')]:
 p=root/relative;text=p.read_text();assert text.count(start)==text.count(end)==1
 before,rest=text.split(start,1);previous,after=rest.split(end,1)
 assert previous.startswith('Latest fully collected published head `bbda05c0')
 (archive/(p.name+'.previous.gz')).write_bytes(gzip.compress(previous.encode(),mtime=0))
 p.write_text(before+start+checkpoint+end+after)
(root/'docs/case-studies/issue-1580/current-source-ci-repair-checkpoint.md').write_text('# Current-source and CodeQL command repair\n\n'+checkpoint)
p=root/'docs/case-studies/issue-1580/README.md'
text=p.read_text();assert 'current-source-ci-repair-checkpoint.md' not in text
p.write_text(text+'\nThe [current-source and CodeQL command checkpoint](current-source-ci-repair-checkpoint.md) records all 27 terminal workflows at `bd6fe77b`, all three collected root causes, the before/fixed controls and complete final local gate replay. Hosted native and CodeQL qualification of the new repairs and the wider issue remain unfinished. Rust literal review reaches 353/373 files and independent Formal AI reasoning stays 0/20.\n')
body=(scratch/'cache-warning-publication/pull-request-body.md').read_text()
body=body.replace('- Preserve CodeQL intermediate caches only for the manual read-only Rust investigation; retain the exact query, strict security gate, memory policy and four-minute deadlines. Hosted execution must qualify the performance hypothesis.', '- Retain available CodeQL caches only for manual read-only investigation. Compose extra options with the pinned action without the rejected inverse boolean flag; keep the exact query, strict security gate, memory policy and four-minute deadlines. Hosted execution must qualify cache reuse and performance.\n- Locate repository definitions from the existing host’s current owned source so helper extraction cannot attach another function’s documentation. Preserve historical diagnostic decoding, add edit/move/delete regressions in both languages, and admit the complete native QA module to hosted reasoning contracts. Restore the parent renderer’s feature-scoped formatting trait import.')
start='Verification:\n\n';end='- PHP source review adds 98 fully read files'
before,rest=body.split(start,1);previous,after=rest.split(end,1)
verification='''- The latest fully collected head `bd6fe77b98aa1cb89c53bfc0667107f6afb13122` has 27 terminal workflows: 23 success, one skip and three failures. All 178 original/compressed command streams and 110 original producer payloads verify. [Layered CI 44855584149](https://github.com/link-assistant/formal-ai/actions/runs/44855584149), lines 8391–8411, reproduces stale source navigation; [Pipeline 44855584441](https://github.com/link-assistant/formal-ai/actions/runs/44855584441), lines 43869–43890, exposes the missing formatting trait; [Security 44855577716](https://github.com/link-assistant/formal-ai/actions/runs/44855577716), lines 1932–1961, rejects duplicate boolean options. This batch repairs all three collected causes. Hosted native compilation and CodeQL execution remain pending. The failed Rust analysis has no SARIF or macro observations; capture recovery records that absence explicitly.
- Before/fixed regressions are retained. Six QA, three CodeQL option/adapter, 22 strict-security, 18 production-profile and 50 native-group JavaScript cases pass. The final complete 141-entry JavaScript gate replay has GATE_PASS passed and GATE_SKIP explicit skips, zero failures, using a 256 MiB heap. Official pinned source projection regeneration/currency, Rust formatting and whitespace checks pass. Initial helper, collector and planner-parity failures remain retained separately. No local native build or execution occurs. [Current checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/current-source-ci-repair-checkpoint.md).
- The earlier `bbda05c0` Pipeline passed 573 Rust tests and eight actual registry CLI cases; its completed macro profile and clean standard SARIF reports remain historical evidence. Later edits, cache performance and all 631 original unexpanded positions remain unqualified. Current source navigation is not complete persisted CST reconstruction.
- The source scanner retains 92 warnings and zero ordinary/embedded-data violations under unchanged limits. Token-scope uncertainty, unsafe-libyaml and two Chrono consumers remain open. The sparse real-history release-map fixture passes all seven cases, reconstructing 961 fragments and 432 nonempty releases; its largest reaped child uses 105,172 KiB.
'''.replace('GATE_PASS',str(gate_counts['PASS'])).replace('GATE_SKIP',str(gate_counts['SKIP']))
body=before+start+verification+end+after
body=body.replace('next-head hosted native checks for the new helper extractions;','next-head hosted native checks for the helper extractions and current-source QA, and the repaired CodeQL producer;')
body=body.replace('352/373', '353/373').replace('49,166', '51,512')
assert body.count('Fixes #1580')==1
publication=scratch/'bd6-ci-repair-publication';publication.mkdir(exist_ok=False)
(publication/'pull-request-body.md').write_text(body)
(publication/'seal.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome,indent=2))
