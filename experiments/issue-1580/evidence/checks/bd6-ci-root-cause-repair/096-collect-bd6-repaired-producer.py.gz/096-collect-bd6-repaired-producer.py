from pathlib import Path
source=Path('/tmp/issue-1580-research/collect-query-import-php-producer-reports.py').read_text()
assert source.count('query-import-php-publication')==2
source=source.replace('query-import-php-publication','bd6-ci-repair-publication').replace('query-import-php-producer-original-reports','bd6-ci-repair-producer-original-reports')
old="""    assert len([row for row in copied if row['relativePath'].endswith('.sarif')]) == 2
    (base / 'producer-files.json').write_text(json.dumps(copied, indent=2) + '\\n')
"""
new="""    sarif = [row['relativePath'] for row in copied if row['relativePath'].endswith('.sarif')]
    # A failed analysis can legitimately have no Rust report. Capture that absence
    # without converting it into a successful analysis or a collection failure.
    if state['conclusion'] == 'success':
        assert len(sarif) == 2, ('Successful producer omitted standard SARIF', sarif)
    parts = []
    for first in range(0, len(copied), 20):
        name = f'producer-files-{first//20+1:02}.json'
        raw = (json.dumps(copied[first:first+20], indent=2) + '\\n').encode()
        (base / name).write_bytes(raw)
        parts.append({'file': name, 'records': len(copied[first:first+20]), 'sha256': hashlib.sha256(raw).hexdigest()})
    (base / 'producer-files.json').write_text(json.dumps({'format': 'partitioned-producer-inventory', 'records': len(copied), 'parts': parts}, indent=2) + '\\n')
"""
assert source.count(old)==1
source=source.replace(old,new)
old="'producerFiles': len(copied), 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}"
new="'producerFiles': len(copied), 'captureComplete': True, 'producerAnalysisComplete': len(sarif) == 2, 'sarifReports': sarif, 'rustSarifMissing': not any(path.endswith('rust.sarif') for path in sarif), 'macroProfileFiles': [row['relativePath'] for row in copied if row['relativePath'].endswith(('macro-contexts.json', 'included-string-payloads.json'))], 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}"
assert source.count(old)==1
source=source.replace(old,new)
exec(compile(source,__file__,'exec'))
