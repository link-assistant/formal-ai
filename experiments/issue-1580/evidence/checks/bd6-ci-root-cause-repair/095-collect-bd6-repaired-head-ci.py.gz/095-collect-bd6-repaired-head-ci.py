from pathlib import Path
source=Path('/tmp/issue-1580-research/collect-query-import-php-head-ci.py').read_text()
assert source.count('query-import-php-publication')==1
assert source.count('query-import-php-head-ci')==1
source=source.replace('query-import-php-publication','bd6-ci-repair-publication').replace('query-import-php-head-ci','bd6-ci-repair-head-ci')
exec(compile(source,__file__,'exec'))
