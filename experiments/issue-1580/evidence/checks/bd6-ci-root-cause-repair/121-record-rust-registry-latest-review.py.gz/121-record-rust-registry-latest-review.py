from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, re

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert (data['fullyReadFiles'], data['fullyReadSourceLines']) == (352, 49166)
path = 'dev/log/issues/247/pulls/248/registry-latest.json'
raw = (scratch / 'templates/rust-complete' / path).read_bytes()
names = [f'rust-registry-latest-review-{part:02d}.log' for part in range(1, 8)]
observed = []
for name in names:
    lines = (scratch / name).read_text().splitlines()
    assert lines[-1].strip() == 'Exit Code: 0', name
    for line in lines:
        match = re.fullmatch(r'   (\d+): (.*)', line)
        if match:
            observed.append((int(match[1]), match[2]))
assert [number for number, text in observed] == list(range(1, 2347))
assert ('\n'.join(text for number, text in observed) + '\n').encode() == raw
identities = {row['path']: row for row in json.loads((root / data['all373BlobIdentitiesVerifiedBy']).read_text())}
digest = hashlib.sha256(raw).hexdigest()
assert identities[path]['sha256'] == digest == 'fb1657b446f189c58075b496dd3a1d58da9619c078c6e2435f4ed6dc0b9d5865'
assert path not in {row['path'] for row in data['files']}
archive = root / 'experiments/issue-1580/evidence/checks/rust-source-review'
logs = json.loads((archive / 'logs.json').read_text())
for name in names:
    value = (scratch / name).read_bytes()
    packed = gzip.compress(value, mtime=0)
    assert not (archive / (name + '.gz')).exists()
    (archive / (name + '.gz')).write_bytes(packed)
    logs.append({'file': name + '.gz', 'rawSha256': hashlib.sha256(value).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest()})
(archive / 'logs.json').write_text(json.dumps(logs, indent=2) + '\n')
data['files'].append({'path': path, 'lines': 2346, 'sha256': digest, 'readLogs': [name + '.gz' for name in names], 'literalReadRanges': [[1, 2346]], 'literalReadLines': 2346, 'literalSourceFullyRead': True, 'formalAiPracticeImplementationVerified': False, 'reviewNote': 'One tool display of lines 1201–1600 was truncated; the omitted release-body span was reread completely from the retained log, lines 1506–1563. No complete-file credit was assigned before all seven original source ranges and the omitted span were read.'})
data['files'].sort(key=lambda row: row['path'])
data['fullyReadFiles'] = len(data['files'])
data['fullyReadSourceLines'] = sum(row['literalReadLines'] for row in data['files'])
assert (data['fullyReadFiles'], data['fullyReadSourceLines']) == (353, 51512)
data['observedAt'] = datetime.now(timezone.utc).isoformat()
data['practiceDecisions'].append({'practice': 'Check runtime and runner compatibility before adopting registry and action updates', 'templateEvidence': [path], 'assessment': 'The complete 2,346-line pinned historical registry snapshot is literally read and reassembled to its original SHA256. Cargo rust_version fields, nullable engine declarations, npm Node minimum patch requirements, Python requirement markers and optional extras, and action release notes are separate compatibility inputs. The historical dependency-review major upgrade explicitly requires an Actions Runner minimum; a CodeQL bundle release tag is not the same artifact as a CodeQL action release. Preserve registry snapshot provenance and check actual resolved consumers, runtime/runner pins, immutable action identities and application versus script dependencies before applying updates. This historical snapshot establishes neither current latest versions nor current package safety, release success or complete template-practice adoption.', 'status': 'literal-source-comparison-and-current-consumer-verification-pending'})
ledger.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps({'fullyReadFiles': 353, 'fullyReadSourceLines': 51512, 'remainingIdentities': 20, 'practiceDecisions': len(data['practiceDecisions']), 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}))
