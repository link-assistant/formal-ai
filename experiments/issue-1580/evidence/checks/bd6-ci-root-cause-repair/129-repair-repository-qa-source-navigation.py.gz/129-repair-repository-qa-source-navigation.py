from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research/repository-qa-source-navigation')
scratch.mkdir(exist_ok=True)
assert not list(scratch.iterdir()), 'Do not overwrite a previous successful draft'
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip() == 'issue-1580-8d61a32a61e1'
before_result = subprocess.run(['node', '--max-old-space-size=192', '--test', '--test-concurrency=1', 'rust/tests/web/issue-1180-repository-qa.test.mjs'], cwd=root, stdout=(scratch / 'before.log').open('w'), stderr=subprocess.STDOUT)
assert before_result.returncode != 0, 'Retain a failing regression before editing'
paths = ['rust/src/history_context/repository_qa.rs',
         'js/agentic/crate/history_repository_qa.mjs',
         'rust/tests/web/issue-1180-repository-qa.test.mjs',
         'rust/tests/unit/issue_1180_repository_qa.rs']
before = {}
for relative in paths:
    raw = (root / relative).read_bytes()
    before[relative] = hashlib.sha256(raw).hexdigest()
    (scratch / relative.replace('/', '_')).write_bytes(raw)

path = root / paths[0]
text = path.read_text()
start = text.index('/// The symbols one census document records under its target.')
end = text.index('/// The documentation comment directly above line', start)
text = text[:start] + '''/// Current source symbols below the configured Rust crate's `src` directory.
///
/// The historical public name remains compatible, but committed line-number
/// inventories confer no authority. Read the current source on each lookup so
/// edits, extractions and moves cannot attach another item's documentation.
#[must_use]
pub fn census_symbols(root: &Path, rules: &HistoryRules) -> Vec<CensusSymbol> {
    let source_root = root.join(&rules.repository_qa.source_root).join("src");
    let Ok(workspace) = crate::self_ast_census::WorkspaceCensus::of_directory(&source_root) else {
        return Vec::new();
    };
    workspace
        .modules
        .into_iter()
        .flat_map(|module| {
            let target = format!("src/{}", module.path);
            module.symbols.into_iter().map(move |symbol| CensusSymbol {
                target: target.clone(),
                kind: symbol.kind,
                name: symbol.name,
                start: symbol.start_line,
                end: symbol.end_line,
            })
        })
        .collect()
}

''' + text[end:]
text = text.replace('identifier-shaped token the self-AST census records.', 'identifier-shaped token the current owned source records.')
text = text.replace('the definition needs a census symbol.', 'the definition needs a current source symbol.')
text = text.replace('/// The most census symbols one definition answer describes.', '/// The most source symbols one definition answer describes.')
text = text.replace('/// One symbol the self-AST census records.', '/// One navigation symbol derived from the current source.')
text = text.replace("/// The census target, relative to the seed's `source_root`.", "/// The current source path, relative to the seed's `source_root`.")
text = text.replace('/// Describe one census symbol from its source, documentation and lineage.', '/// Describe one current source symbol from its documentation and lineage.')
path.write_text(text)

path = root / paths[1]
text = path.read_text()
text = text.replace('// formalized commits and the measured range.', '// formalized commits and the measured range. Live navigation uses sourceSymbols\n// over the host\'s current source modules; the legacy census decoder is diagnostic.')
marker = '/** Mirrors `census_document_symbols`. */'
assert text.count(marker) == 1
text = text.replace(marker, '''/** Current owned-source navigation, mirroring the native census_symbols lookup.
 * The caller supplies modules freshly observed by the existing source host.
 * These spans navigate actual content; they are not persisted source models.
 */
export function sourceSymbols(modules) {
  return modules.flatMap(module => module.symbols.map(symbol => ({
    target: module.path, kind: symbol.kind, name: symbol.name,
    start: symbol.start_line, end: symbol.end_line,
  })));
}

/** Decode historical census records for diagnostics; live lookup uses sourceSymbols. */''')
path.write_text(text)

path = root / paths[2]
text = path.read_text()
text = text.replace('// native route. Git\n// stays native, so the measured range and the commits are handed in.', '// native route. Git\n// stays native, so the measured range and the commits are handed in.')
text = text.replace("import { readFileSync } from 'node:fs';", "import { mkdirSync, mkdtempSync, readFileSync, renameSync, rmSync, unlinkSync, writeFileSync } from 'node:fs';\nimport { tmpdir } from 'node:os';\nimport { join } from 'node:path';\nimport { fileURLToPath } from 'node:url';")
text = text.replace("import { installNodeHost } from '../../../js/agentic/node-host.mjs';", "import { censusDocuments, installNodeHost } from '../../../js/agentic/node-host.mjs';")
old = """test('the census locates evaluate_calculation and the answer quotes its documentation', () => {
  const census = readFileSync(new URL('data/meta/self-ast/src/calculation.lino', ROOT), 'utf8');
  const symbol = qa.censusDocumentSymbols(census).find((found) => found.name === 'evaluate_calculation');"""
new = """test('current source locates evaluate_calculation and the answer quotes its documentation', () => {
  const modules = censusDocuments(fileURLToPath(ROOT)).map(document => document.module);
  const symbol = qa.sourceSymbols(modules).find((found) => found.name === 'evaluate_calculation');"""
assert text.count(old) == 1
text = text.replace(old, new)
marker = "test('the status answer reads the floor and the target from the ledger', () => {"
assert text.count(marker) == 1
test = '''test('source edits, moves and deletion supersede stale committed symbol positions', t => {
  const repository = mkdtempSync(join(tmpdir(), 'formal-ai-qa-current-source-'));
  t.after(() => rmSync(repository, { recursive: true, force: true }));
  const sourceDirectory = join(repository, 'rust/src');
  const legacyDirectory = join(repository, 'data/meta/self-ast/src');
  mkdirSync(sourceDirectory, { recursive: true });
  mkdirSync(legacyDirectory, { recursive: true });
  writeFileSync(join(legacyDirectory, 'current.lino'),
    'self_ast_census\\n  target src/current.rs\\n  symbols\\n    function measured_value 1 1\\n    function historical_only 8 8\\n');
  const current = join(sourceDirectory, 'current.rs');
  writeFileSync(current, '/// Current contract.\\nfn measured_value() {}\\n');
  const observe = () => qa.sourceSymbols(censusDocuments(repository).map(document => document.module));
  assert.deepEqual(observe(), [{ target: 'src/current.rs', kind: 'function', name: 'measured_value', start: 2, end: 2 }]);
  const edited = '// Added framing: नमस्ते.\\n\\n/// Edited contract.\\nfn measured_value() {}\\n';
  writeFileSync(current, edited);
  assert.deepEqual(observe(), [{ target: 'src/current.rs', kind: 'function', name: 'measured_value', start: 4, end: 4 }]);
  assert.equal(qa.symbolDoc(edited, observe()[0].start, rules), 'Edited contract.');
  const moved = join(sourceDirectory, 'moved.rs');
  renameSync(current, moved);
  assert.deepEqual(observe(), [{ target: 'src/moved.rs', kind: 'function', name: 'measured_value', start: 4, end: 4 }]);
  unlinkSync(moved);
  assert.deepEqual(observe(), []);
});

'''
text = text.replace(marker, test + marker)
path.write_text(text)

path = root / paths[3]
text = path.read_text().replace("//! repository's history and its self-AST census.", "//! repository's history and its current source navigation.")
text = text.replace('//! `data/meta/self-ast`, quoting its documentation comment from the source,', '//! the live owned source, quoting its documentation comment from that source,')
marker = '#[test]\nfn chat_answers_what_a_function_does_from_the_census() {'
assert text.count(marker) == 1
test = '''#[test]
fn source_edits_moves_and_deletion_supersede_stale_census_positions() {
    struct Fixture(PathBuf);
    impl Drop for Fixture {
        fn drop(&mut self) {
            let _ = std::fs::remove_dir_all(&self.0);
        }
    }
    let unique = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .expect("clock")
        .as_nanos();
    let directory = Fixture(std::env::temp_dir().join(format!(
        "formal-ai-qa-current-source-{}-{unique}", std::process::id()
    )));
    let root = &directory.0;
    let rules = HistoryRules::load(None);
    let source_directory = root.join(&rules.repository_qa.source_root).join("src");
    let legacy_directory = root.join(&rules.repository_qa.census_dir);
    std::fs::create_dir_all(&source_directory).expect("source directory");
    std::fs::create_dir_all(&legacy_directory).expect("legacy directory");
    std::fs::write(
        legacy_directory.join("current.lino"),
        "self_ast_census\\n  target src/current.rs\\n  symbols\\n    function measured_value 1 1\\n    function historical_only 8 8\\n",
    )
    .expect("stale navigation fixture");
    let current = source_directory.join("current.rs");
    std::fs::write(&current, "/// Current contract.\\nfn measured_value() {}\\n")
        .expect("current source");
    let expected = |target: &str, start| CensusSymbol {
        target: target.to_owned(),
        kind: "function".to_owned(),
        name: "measured_value".to_owned(),
        start,
        end: start,
    };
    assert_eq!(history_context::census_symbols(root, &rules), vec![expected("src/current.rs", 2)]);
    let edited = "// Added framing: नमस्ते.\\n\\n/// Edited contract.\\nfn measured_value() {}\\n";
    std::fs::write(&current, edited).expect("edited source");
    assert_eq!(history_context::census_symbols(root, &rules), vec![expected("src/current.rs", 4)]);
    assert_eq!(symbol_doc(edited, 4, &rules), Some("Edited contract.".to_owned()));
    let moved = source_directory.join("moved.rs");
    std::fs::rename(&current, &moved).expect("move source");
    assert_eq!(history_context::census_symbols(root, &rules), vec![expected("src/moved.rs", 4)]);
    std::fs::remove_file(moved).expect("remove source");
    assert_eq!(history_context::census_symbols(root, &rules), Vec::new());
}

'''
text = text.replace(marker, test + marker)
path.write_text(text)

for relative in paths:
    print(relative, 'before', before[relative], 'after', hashlib.sha256((root / relative).read_bytes()).hexdigest())
(scratch / 'draft.json').write_text(json.dumps({'observedAt': datetime.now(timezone.utc).isoformat(), 'paths': paths, 'beforeSha256': before, 'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'independentAuthorshipCredit': 0, 'nativeExecutionPending': True}, indent=2) + '\n')
