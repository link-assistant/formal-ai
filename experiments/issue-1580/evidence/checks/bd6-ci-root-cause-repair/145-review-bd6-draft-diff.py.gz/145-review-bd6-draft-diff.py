from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/bd6-draft-review')
out.mkdir(exist_ok=False)
groups=[('security',['.github/workflows/security.yml','data/benchmarks/fast-pull-request-retained-jobs.json','experiments/issue-1580/codeql-included-string-observation.test.mjs','experiments/issue-1580/codeql-macro-contexts/README.md']),('qa-native',['rust/src/history_context.rs','rust/src/history_context/repository_qa.rs','rust/src/link_store.rs','rust/tests/unit/issue_1180_repository_qa.rs','rust/tests/unit/reasoning_contracts.rs']),('qa-javascript',['js/agentic/crate/history_repository_qa.mjs','rust/tests/web/issue-1180-repository-qa.test.mjs']),('projections',['data/meta/js-rust-translation.lino','data/meta/translation-blockers.lino','rust/tests/fixtures/js-rust-translation/crate/history_repository_qa.rs'])]
for name,paths in groups:
 r=subprocess.run(['git','diff','--']+paths,cwd=root,capture_output=True,text=True,check=True)
 (out/(name+'.diff')).write_text(r.stdout)
 print(name,len(r.stdout.splitlines()),len(r.stdout.encode()),flush=True)
print(json.dumps({'completePullRequestDiffReviewed':False,'newDraftDiffsCaptured':True}))
