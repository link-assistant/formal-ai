from pathlib import Path
import subprocess,json,datetime
r=Path('/tmp/issue-1580-research/secretlint-locked-closure');records=[]
commands=[('actual-final',['python3','experiments/issue-1580/secretlint-locked-live.py',str(r)])]
gates=['check-file-size','check-file-size-js-twin','check-readable-code','check-required-documentation','check-tests-as-docs','check-tests-as-documentation-javascript-twin','check-changelog-fragment-js-twin','release#1','check-closure-audit','check-generated-files','layered-ci#1']
commands.extend(('gate-'+gate,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]) for gate in gates)
for label,command in commands:
 with (r/(label+'.log')).open('w') as stream:
  result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
 row={'label':label,'command':command,'exitCode':result.returncode};records.append(row);print(json.dumps(row),flush=True)
(r/'gates-result.json').write_text(json.dumps({'records':records,'allPassed':all(row['exitCode']==0 for row in records),'complete':True,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+chr(10))
