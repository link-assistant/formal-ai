from pathlib import Path
import subprocess,json
r=Path('/tmp/issue-1580-research/secretlint-locked-closure');cmd=['node','--test','--test-concurrency=1','experiments/issue-1580/secretlint-locked-install.test.mjs']
with (r/'before-tests.log').open('w') as out:p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
(r/'before-result.json').write_text(json.dumps({'command':cmd,'exitCode':p.returncode,'productionUnchanged':True},indent=2)+'\n')
