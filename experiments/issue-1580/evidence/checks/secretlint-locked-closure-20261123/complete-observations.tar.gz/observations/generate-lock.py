from pathlib import Path
import subprocess,json
r=Path('/tmp/issue-1580-research/secretlint-locked-closure')
cmd=['npm','install','--package-lock-only','--ignore-scripts','--no-audit','--no-fund','--prefix','.github/secretlint']
p=subprocess.run(cmd,capture_output=True,text=True);(r/'lock-generation.log').write_text(p.stdout+p.stderr);(r/'lock-generation-result.json').write_text(json.dumps({'command':cmd,'exitCode':p.returncode},indent=2)+'\n')
