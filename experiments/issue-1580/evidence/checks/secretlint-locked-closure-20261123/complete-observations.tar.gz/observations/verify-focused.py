from pathlib import Path
import subprocess,json,datetime
r=Path('/tmp/issue-1580-research/secretlint-locked-closure');records=[]
commands=[('locked-install',['node','--test','--test-concurrency=1','experiments/issue-1580/secretlint-locked-install.test.mjs']),('boundaries',['node','--test','--test-concurrency=1','rust/tests/web/bounded-subprocess-boundaries.test.mjs']),('fast-profile',['node','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs']),('shell-syntax',['bash','-n','scripts/check-secrets.sh']),('whitespace',['git','diff','--check'])]
for label,cmd in commands:
 with (r/(label+'.log')).open('w') as out:p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 records.append({'label':label,'command':cmd,'exitCode':p.returncode});print(json.dumps(records[-1]),flush=True)
(r/'focused-result.json').write_text(json.dumps({'records':records,'complete':True,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
