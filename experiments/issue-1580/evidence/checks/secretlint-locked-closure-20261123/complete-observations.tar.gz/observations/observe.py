from pathlib import Path
import subprocess,json
r=Path('/tmp/issue-1580-research/secretlint-locked-closure')
cmd=['npm','view','secretlint@14.0.0','version','engines','dependencies','dist','--json']
p=subprocess.run(cmd,capture_output=True,text=True);(r/'registry-metadata.json').write_text(p.stdout);(r/'registry-metadata.stderr').write_text(p.stderr);(r/'metadata-result.json').write_text(json.dumps({'command':cmd,'exitCode':p.returncode},indent=2)+'\n')
