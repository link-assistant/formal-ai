from pathlib import Path
import subprocess,json,base64
root=Path('/tmp/gh-issue-solver-1794900398048')
for name in ['rust/tests/web/native-test-artifact.test.mjs','.github/actions/upload-artifact-with-retry/action.yml','experiments/issue-1580/artifact-transport-roundtrip.py','data/benchmarks/fast-pull-request-javascript-tests.json']:
 p=root/name
 if name.startswith('data/'):
  value=json.loads(p.read_text());print('INVENTORY TYPE',type(value).__name__);print(str(value)[:4000]);continue
 print('FILE',name,'LINES',len(p.read_text().splitlines()));print(p.read_text())
result=subprocess.run(['gh','api','repos/actions/download-artifact/contents/package.json?ref=9000827ccba6bdab643e8b6fd33ac0654aef8333','--jq','.content'],cwd=root,capture_output=True,check=True)
print('PINNED PACKAGE');print(base64.b64decode(result.stdout).decode())
