from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
p=root/'rust/tests/web/fast-pull-request-production-profile.test.mjs';text=p.read_text()
needle='/experiments/issue-1580/evidence/ci/native-families-7fce5c19/job-136011692528.stdout.gz\\n'
assert text.count(needle)==1
addition=''.join(f'/experiments/issue-1580/evidence/ci/native-families-1d7ba479/job-{job}.stdout.gz\\n' for job in [136489959548,136489959657,136489959672])
p.write_text(text.replace(needle,needle+addition))
p=root/'experiments/issue-1580/artifact-download-retry.test.mjs';text=p.read_text().replace("import {join,resolve} from 'node:path';","import {join} from 'node:path';")
text=text.replace('cancelAfterFailure=false,corrupt=false,selection=', 'cancelAfterFailure=false,corrupt=false,resetFails=false,selection=')
text=text.replace("const ran=spawnSync('bash'", "const ran=resetFails&&step.id==='retry_second'?{status:29,stderr:'reset refused'}:spawnSync('bash'")
text+='''
test('failed archive reset refuses another transport and never extracts the stale bytes',()=>{
  const actual=replay(10,{resetFails:true});assert.equal(actual.failed,true);
  assert.equal(actual.attempts.length,1);assert.equal(actual.steps.extract.outcome,'skipped');
  assert.equal(actual.payload,null);assert.equal(actual.rawRemoved,true);
});
''';p.write_text(text)
p=root/'rust/tests/web/native-test-artifact.test.mjs';text=p.read_text().replace('/(?:tests 10|# tests 10)/u','/(?:tests 11|# tests 11)/u');p.write_text(text)
print('Updated exact three-input expectation and added a failed-reset refusal control; no checkout/deadline weakening.')
