from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
p=root/'rust/tests/web/native-test-artifact.test.mjs';text=p.read_text()
needle=" const result=spawnSync(process.execPath,['--test','--test-concurrency=1',fileURLToPath(new URL('../../../experiments/issue-1580/artifact-download-retry.test.mjs',import.meta.url))],{encoding:'utf8',maxBuffer:256*1024,env:{...process.env,NODE_OPTIONS:'--max-old-space-size=128'}});"
assert needle in text
replacement=" const env={...process.env,NODE_OPTIONS:'--max-old-space-size=128'};delete env.NODE_TEST_CONTEXT;\n const result=spawnSync(process.execPath,['--test','--test-reporter=tap','--test-concurrency=1',fileURLToPath(new URL('../../../experiments/issue-1580/artifact-download-retry.test.mjs',import.meta.url))],{encoding:'utf8',maxBuffer:256*1024,env});"
p.write_text(text.replace(needle,replacement))
print('Isolated nested Node test runner context and selected explicit TAP output for the CI wrapper.')
