from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
for name in ['experiments/issue-1580/verify-artifact-migration.mjs','rust/tests/web/issue-1328-artifact-retry.test.mjs','experiments/issue-1580/reproduce-artifact-extractor.cjs','.github/actions/download-artifact/action.yml']:
 p=root/name
 print('FILE',name,'LINES',len(p.read_text().splitlines()))
 print(p.read_text())
for args in [['rg','-n','continue-on-error|retry|attempt',' .github/actions'],['rg','-n','download-artifact/action|skip-decompress|ALLOW_EMPTY_SELECTION','rust/tests/web','experiments/issue-1580/verify-artifact-migration.mjs'],['gh','api','repos/actions/download-artifact/contents/src/download-artifact.ts?ref=9000827ccba6bdab643e8b6fd33ac0654aef8333','--jq','.content']]:
 args=[x.strip() for x in args]
 r=subprocess.run(args,cwd=root,capture_output=True)
 print('COMMAND',args,'STATUS',r.returncode)
 if args[0]=='gh' and r.returncode==0:
  import base64
  value=base64.b64decode(r.stdout).decode();(Path('/tmp/issue-1580-research')/'download-artifact-pinned.ts').write_text(value);print(value)
 else:print(r.stdout.decode());print(r.stderr.decode())
