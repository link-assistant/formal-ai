from pathlib import Path
import subprocess,gzip,re,json
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research/artifact-retry-candidate');scratch.mkdir(exist_ok=True)
with (scratch/'focused.stdout').open('wb') as out,(scratch/'focused.stderr').open('wb') as err:
 r=subprocess.run(['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/artifact-download-retry.test.mjs'],cwd=root,stdout=out,stderr=err)
print('FOCUSED STATUS',r.returncode);print((scratch/'focused.stdout').read_text());print((scratch/'focused.stderr').read_text())
raw=gzip.decompress((root/'experiments/issue-1580/evidence/ci/native-families-90b51590/failed-run-44804037844.stdout.gz').read_bytes()).decode();(scratch/'layered-full.log').write_text(raw)
lines=raw.splitlines();print('LAYERED TOTAL LINES',len(lines))
selected=set()
for i,line in enumerate(lines):
 if re.search(r'##\\[error\\]|(^|\\s)(FAIL|FAILED|Error:)|not ok|timed out|Process completed with exit|Error [A-Z_]+|error:',line,re.I):selected.update(range(max(0,i-3),min(len(lines),i+7)))
text='\n'.join(f'{i+1}: {lines[i]}' for i in sorted(selected));(scratch/'layered-diagnostics.txt').write_text(text+'\n');print(text)
(scratch/'outcome.json').write_text(json.dumps({'focusedReturnCode':r.returncode,'layeredTotalLines':len(lines),'selectedLines':len(selected),'fullIssueComplete':False},indent=2)+'\n')
