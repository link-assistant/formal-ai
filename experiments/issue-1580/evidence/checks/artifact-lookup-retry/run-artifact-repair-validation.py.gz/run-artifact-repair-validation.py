from pathlib import Path
import os,sys,subprocess,json,datetime
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research/artifact-repair-validation');scratch.mkdir(exist_ok=True)
if len(sys.argv)==1:
 with (scratch/'worker.log').open('wb') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (scratch/'pid').write_text(str(worker.pid));print('Started finite sequential validation',worker.pid);raise SystemExit()
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'};records=[]
commands=[('native-artifact',['node','--test','--test-concurrency=1','rust/tests/web/native-test-artifact.test.mjs']),('fast-profile',['node','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs']),('shard-closure',['node','--test','--test-concurrency=1','rust/tests/web/native-regression-groups.test.mjs']),('gate-list',['node','experiments/formal_ai_subagent/local-gates.mjs','--list']),('whitespace',['git','diff','--check'])]
for name,args in commands:
 with (scratch/(name+'.stdout')).open('wb') as out,(scratch/(name+'.stderr')).open('wb') as err:r=subprocess.run(args,cwd=root,env=env,stdout=out,stderr=err)
 records.append({'name':name,'args':args,'returnCode':r.returncode});(scratch/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,flush=True)
(scratch/'outcome.json').write_text(json.dumps({'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':all(r['returnCode']==0 for r in records),'fullIssueComplete':False},indent=2)+'\n')
