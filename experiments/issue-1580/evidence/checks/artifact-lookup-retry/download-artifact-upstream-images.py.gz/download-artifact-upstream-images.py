from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research/artifact-name-visibility-upstream')
token=subprocess.check_output(['gh','auth','token'],text=True).strip()
for name in ['96caccdb-d9f4-408d-9d04-61b062aa9203','cdcfad8e-9da3-4d05-a350-4a95958732c5']:
 target=scratch/(name+'.image')
 result=subprocess.run(['curl','-L','--fail','--silent','--show-error','-H','Authorization: token '+token,'-o',str(target),'https://github.com/actions/download-artifact/assets/38806447/'+name],capture_output=True)
 (scratch/(name+'.download.stderr')).write_bytes(result.stderr)
 print(name,'download status',result.returncode)
 if target.exists():
  inspect=subprocess.run(['file','--brief',str(target)],capture_output=True,text=True,check=True);(scratch/(name+'.file-type')).write_text(inspect.stdout);print(inspect.stdout)
print('No credential value retained.')
