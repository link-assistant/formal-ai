from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
p=root/'.github/actions/download-artifact/action.yml';text=p.read_text()
start=text.index('    - uses: actions/download-artifact@');end=text.index('    - name: Extract verified archives',start)
original=text[start:end]
first=original.replace('    - uses:', '    - id: download_first\n      uses:',1).replace('      env:', '      continue-on-error: true\n      env:',1)
def retry(previous,current,delay,final=False):
 reset=f'''    - name: Discard partial archives before the {current} download
      id: retry_{current}
      if: ${{{{ !cancelled() && steps.download_{previous}.outcome == 'failure' }}}}
      shell: bash
      env:
        RAW_DIRECTORY: ${{{{ steps.temporary.outputs.path }}}}
      run: |
        rm -rf -- "$RAW_DIRECTORY"
        mkdir -p -- "$RAW_DIRECTORY"
        sleep {delay}
'''
 attempt=original.replace('    - uses:', f'''    - id: download_{current}
      if: ${{{{ !cancelled() && steps.retry_{current}.outcome == 'success' }}}}
      uses:''',1)
 if not final:attempt=attempt.replace('      env:', '      continue-on-error: true\n      env:',1)
 return reset+attempt
text=text[:start]+first+retry('first','second',2)+retry('second','third',4,True)+text[end:]
text=text.replace('description: Preserve strict transport digests and extract ZIP members with Python','description: Retry raw transport within three attempts, preserve strict digests and extract ZIP members with Python')
p.write_text(text)
p=root/'rust/tests/web/native-test-artifact.test.mjs'
p.write_text(p.read_text()+'''
test('raw artifact retries recover lookup failures without extracting partial or corrupt archives', {timeout:30000},()=>{
 const result=spawnSync(process.execPath,['--test','--test-concurrency=1',fileURLToPath(new URL('../../../experiments/issue-1580/artifact-download-retry.test.mjs',import.meta.url))],{encoding:'utf8',maxBuffer:256*1024,env:{...process.env,NODE_OPTIONS:'--max-old-space-size=128'}});
 assert.equal(result.status,0,result.stdout+result.stderr);
 assert.match(result.stdout,/(?:tests 10|# tests 10)/u);
});
''')
(root/'changelog.d/issue-1580-artifact-download-retry.md').write_text('Fix Windows and other artifact consumers failing on a lookup immediately after a successful upload. Retry the pinned raw download at most three times under existing caller deadlines, discard partial archives before each retry, and preserve strict digest validation, cancellation and extraction failures.\n')
print('Updated adapter and existing CI test entrypoint; no job deadline, selector, permission or artifact producer changed.')
