from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research/artifact-name-visibility-upstream')
for number in [63,337,250]:
 for kind,url in [('issue',f'repos/actions/download-artifact/issues/{number}'),('comments',f'repos/actions/download-artifact/issues/{number}/comments')]:
  result=subprocess.run(['gh','api',url,'--paginate'],cwd=root,capture_output=True);(scratch/(f'{number}-{kind}.json')).write_bytes(result.stdout);(scratch/(f'{number}-{kind}.stderr')).write_bytes(result.stderr)
  print('RECORD',number,kind,'status',result.returncode)
  if result.returncode==0:
   values=json.loads(result.stdout);values=values if isinstance(values,list) else [values]
   for value in values:print(json.dumps({key:value.get(key) for key in ['html_url','title','state','created_at','updated_at','body']},ensure_ascii=False,indent=2))
