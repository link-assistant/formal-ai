from pathlib import Path
import subprocess,json,base64
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research/artifact-name-visibility-upstream');scratch.mkdir(exist_ok=True)
for name,query in [('download-issues','repo:actions/download-artifact "not found" upload'),('toolkit-issues','repo:actions/toolkit "Artifact not found"')]:
 r=subprocess.run(['gh','api','-X','GET','search/issues','--paginate','-f','q='+query,'-f','per_page=100'],cwd=root,capture_output=True)
 (scratch/(name+'.stdout')).write_bytes(r.stdout);(scratch/(name+'.stderr')).write_bytes(r.stderr)
 print(name,'status',r.returncode)
 if r.returncode==0:
  decoder=json.JSONDecoder();remaining=r.stdout.decode();items=[]
  while remaining.strip():value,position=decoder.raw_decode(remaining.lstrip());items+=value.get('items',[]);remaining=remaining.lstrip()[position:]
  print(json.dumps([{key:x.get(key) for key in ['number','title','state','html_url','updated_at']} for x in items],indent=2))
r=subprocess.run(['gh','api','repos/actions/toolkit/contents/packages/artifact/src/internal/find/get-artifact.ts?ref=%40actions%2Fartifact%406.3.1','--jq','.content'],cwd=root,capture_output=True)
(scratch/'pinned-client.stdout').write_bytes(r.stdout);(scratch/'pinned-client.stderr').write_bytes(r.stderr);print('pinned-client',r.returncode)
if r.returncode==0:
 content=base64.b64decode(r.stdout).decode();(scratch/'get-artifact.ts').write_text(content);print(content)
