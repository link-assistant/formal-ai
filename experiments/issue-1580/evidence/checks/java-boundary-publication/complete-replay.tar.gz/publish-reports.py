from pathlib import Path
import datetime, hashlib, json, subprocess

root = Path('/tmp/issue-1580-research/java-boundary-publication')
verification = json.loads((root / 'verified-evidence.json').read_text())
assert verification['pin'] == '44771e97373f89d4d582bc384c2fd1f8d69cd83d'
assert len(verification['verified']) == 4 and not verification['published']
old = json.loads(Path('/tmp/issue-1580-research/java-dispatch-contract/issues.json').read_text())
fresh = json.loads((root / 'issues.stdout').read_text())
assert len(old) == len(fresh) == 33
original = {i['number']: i for i in old}
assert all(all(original[i['number']].get(k) == i.get(k) for k in ['title', 'body', 'comments', 'updated_at']) for i in fresh)
repo = 'link-foundation/java-ai-driven-development-pipeline-template'
reports = [
    ('manual-dispatch', 'java-manual-dispatch-quality-report.md', 'CI: manual release dispatch skips lint but can still admit build and release'),
    ('fragment-preservation', 'java-fragment-preservation-report.md', 'Changelog collector deletes unparsed CRLF or malformed fragments while reporting success'),
]
results = []
for label, filename, title in reports:
    body = Path('experiments/issue-1580/upstream', filename).read_bytes()
    draft = root / (label + '-posted.md')
    draft.write_bytes(body)
    command = ['gh', 'issue', 'create', '--repo', repo, '--title', title, '--body-file', str(draft)]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    (root / (label + '-create.stdout')).write_text(result.stdout)
    (root / (label + '-create.stderr')).write_text(result.stderr)
    result.check_returncode()
    url = result.stdout.strip()
    number = int(url.rsplit('/', 1)[-1])
    detail = subprocess.run(['gh', 'api', f'repos/{repo}/issues/{number}'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (root / (label + '-issue.json')).write_bytes(detail.stdout)
    (root / (label + '-issue.stderr')).write_bytes(detail.stderr)
    detail.check_returncode()
    issue = json.loads(detail.stdout)
    assert issue['html_url'] == url and issue['title'] == title
    assert issue['body'].rstrip() == body.decode().rstrip()
    results.append({'label': label, 'url': url, 'number': number, 'title': title,
                    'bodySha256': hashlib.sha256(body).hexdigest(), 'bodyVerified': True})
    (root / 'published.json').write_text(json.dumps({'complete': len(results) == 2,
        'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'reports': results, 'upstreamRepairClaimed': False}, indent=2) + '\n')
print((root / 'published.json').read_text())
