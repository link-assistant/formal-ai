from pathlib import Path
import base64, hashlib, json, subprocess

root = Path('/tmp/issue-1580-research/java-boundary-publication')
root.mkdir(exist_ok=False)
records = []
def capture(label, command):
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (root / (label + '.stdout')).write_bytes(result.stdout)
    (root / (label + '.stderr')).write_bytes(result.stderr)
    records.append({'label': label, 'command': command, 'exitCode': result.returncode})
    (root / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    result.check_returncode()
    return result.stdout
repo = 'link-foundation/java-ai-driven-development-pipeline-template'
head = json.loads(capture('upstream-main', ['gh', 'api', f'repos/{repo}/commits/main']))['sha']
assert head == 'dd803a2d9fa5b3a992b435acce73162274fb9e8b', head
issues = json.loads(capture('issues', ['gh', 'api', f'repos/{repo}/issues?state=all&per_page=100', '--paginate']))
assert isinstance(issues, list)
print(json.dumps({'upstreamHead': head, 'issues': [
    {'number': i['number'], 'title': i['title'], 'updatedAt': i['updated_at'],
     'body': i['body'], 'comments': i['comments'], 'url': i['html_url']}
    for i in issues]}, indent=2))
pin = '44771e97373f89d4d582bc384c2fd1f8d69cd83d'
paths = [
    'experiments/issue-1580/template-java-boundary-controls.test.mjs',
    'experiments/issue-1580/fixtures/java-template/source.json',
    'experiments/issue-1580/fixtures/java-template/.github/workflows/release.yml',
    'experiments/issue-1580/evidence/checks/java-boundary-controls/manifest.json',
]
verified = []
for index, name in enumerate(paths):
    response = json.loads(capture(f'evidence-{index}', ['gh', 'api',
        f'repos/link-assistant/formal-ai/contents/{name}?ref={pin}']))
    data = base64.b64decode(response['content'])
    assert data == Path(name).read_bytes(), name
    verified.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
(root / 'verified-evidence.json').write_text(json.dumps({'pin': pin, 'upstreamHead': head,
    'verified': verified, 'published': False}, indent=2) + '\n')
print('All four immutable published evidence files match local bytes.')
