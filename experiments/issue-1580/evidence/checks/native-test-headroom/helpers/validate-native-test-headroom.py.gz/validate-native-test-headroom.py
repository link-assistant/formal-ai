import json, os, pathlib, subprocess, sys, traceback
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/native-test-headroom')
if len(sys.argv)==1:
    with (out/'worker.log').open('wb') as stream:
        process=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':process.pid})+'\n')
    print(json.dumps({'pid':process.pid,'finite':True}))
    sys.exit(0)
records=[]
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'}
def run(name,args):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    records.append({'name':name,'args':args,'exitCode':result.returncode})
    (out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(records[-1]),flush=True)
    return result.returncode
try:
    extraction=json.loads((out/'extraction.json').read_text())
    files=[item[key] for item in extraction['files'] for key in ['parent','child']]
    assert run('format',['rustfmt','--edition','2024','--config','skip_children=true',*files])==0
    assert run('format-check',['rustfmt','--edition','2024','--config','skip_children=true','--check',*files])==0
    for name,path in [
      ('headroom','experiments/issue-1580/native-test-headroom.test.mjs'),
      ('agentic-write','rust/tests/web/agentic-write.test.mjs'),
      ('main-only-planner-twins','rust/tests/web/main-only-planner-twins.test.mjs'),
      ('native-staged-release','rust/tests/web/native-staged-release-operation-view.test.mjs'),
      ('maintained-observations','rust/tests/web/issue-1580-template-observations.test.mjs'),
    ]:run(name,['node','--test','--test-reporter=tap','--test-concurrency=1',path])
    run('touched-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-file-size-js-twin,check-naming'])
    run('whitespace',['git','diff','--check'])
    outcome={'complete':True,'allPassed':all(row['exitCode']==0 for row in records),'commands':len(records),'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
    (out/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
    print(json.dumps(outcome),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n')
    raise
