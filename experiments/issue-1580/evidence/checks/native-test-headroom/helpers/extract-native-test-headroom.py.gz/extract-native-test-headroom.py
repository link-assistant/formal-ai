import hashlib, json, pathlib, re, subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/native-test-headroom')
rows=[]
for owner,child,start,end,imports in [
 ('rust/tests/unit/agentic-coding/agentic_general_planner','command_capture','#[test]\nfn command_capture_parent_file_is_a_real_failure_without_false_completion()',None,'use super::{\n    AgenticPlan, ChatMessage, PLAN_PATH, ToolCall, compose_general_change_plan,\n    observed_plan_tools, plan_chat_step,\n};\n\n'),
 ('rust/tests/unit/ci-cd/job_budget_fit','standalone_suites','/// Defect D14: 23 test cases that no CI job ran.',None,'use std::fs;\n\nuse super::repository_file;\n\n'),
 ('rust/tests/unit/ci-cd/pinned_tool_images','image_policy',"/// D3. The policy `.github/zizmor.yml` writes down, applied to the references",'/// D2. The audit that could not fail.','use super::{image_references, repository_file};\n\n'),
]:
 parent=root/(owner+'.rs')
 original=parent.read_text()
 baseline=subprocess.check_output(['git','show','HEAD:'+owner+'.rs'],cwd=root).decode()
 assert baseline==original
 assert original.count(start)==1
 first=original.index(start)
 last=original.index(end,first) if end else len(original)
 moved=original[first:last]
 assert 'super::' not in moved
 assert 'include_str!' not in moved and 'include!' not in moved
 newparent=original[:first]+original[last:]
 # Keep existing module names and native test filters as the parent prefix.
 insertion=newparent.index('\n\n')+2
 declaration='mod '+child+';\n\n'
 newparent=newparent[:insertion]+declaration+newparent[insertion:]
 destination=root/owner/(child+'.rs')
 destination.parent.mkdir(exist_ok=True)
 assert not destination.exists()
 destination.write_text(imports+moved)
 parent.write_text(newparent)
 # Exact inverse conservation includes every original comment and test body.
 inverse=newparent.replace(declaration,'',1)
 inverse=inverse[:first]+moved+inverse[first:]
 assert inverse==original
 assert re.findall(r'^fn (\w+)\(',original,re.M)==re.findall(r'^fn (\w+)\(',inverse,re.M)
 assert len(newparent.splitlines())<=900 and len((imports+moved).splitlines())<=900
 rows.append({'parent':owner+'.rs','child':str(destination.relative_to(root)),'beforeLines':len(original.splitlines()),'afterLines':len(newparent.splitlines()),'childLines':len((imports+moved).splitlines()),'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'movedSha256':hashlib.sha256(moved.encode()).hexdigest(),'exactInverse':True,'nativeExecutionVerified':False})
(out/'extraction.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'files':rows,'independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps(rows))
