import json, pathlib, subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/native-test-headroom')
out.mkdir(exist_ok=False)
test=root/'experiments/issue-1580/native-test-headroom.test.mjs'
assert not test.exists()
test.write_text('''// Run the maintained scanner against the native regression module owners.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import test from 'node:test';
import {checkListedFiles} from '../../scripts/check-file-size.mjs';

const root = fileURLToPath(new URL('../../', import.meta.url)).replace(/\\/$/u, '');
for (const [owner, child] of [
  ['rust/tests/unit/agentic-coding/agentic_general_planner', 'command_capture'],
  ['rust/tests/unit/ci-cd/job_budget_fit', 'standalone_suites'],
  ['rust/tests/unit/ci-cd/pinned_tool_images', 'image_policy'],
]) {
  test(owner + ' retains file-size headroom and a reachable regression group', () => {
    const files = new Set([owner + '.rs', owner + '/' + child + '.rs']);
    const result = checkListedFiles(root, files);
    assert.deepEqual(result, {warnings: [], violations: [], embeddedDataViolations: []});
    assert.match(readFileSync(root + '/' + owner + '.rs', 'utf8'), new RegExp('^mod ' + child + ';$', 'mu'));
    assert.match(readFileSync(root + '/' + owner + '/' + child + '.rs', 'utf8'), /^#\\[test\\]$/mu);
  });
}
''')
entry=root/'rust/tests/web/issue-1580-template-observations.test.mjs'
with entry.open('a') as stream:stream.write("import '../../../experiments/issue-1580/native-test-headroom.test.mjs';\n")
result=subprocess.run(['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test.relative_to(root))],cwd=root,capture_output=True)
(out/'before.stdout').write_bytes(result.stdout)
(out/'before.stderr').write_bytes(result.stderr)
assert result.returncode==1 and b'# fail 3' in result.stdout
print(json.dumps({'beforeExit':result.returncode,'regressions':3,'independentAuthorshipCredit':0}))
