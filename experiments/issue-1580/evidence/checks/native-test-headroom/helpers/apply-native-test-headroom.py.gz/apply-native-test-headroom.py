import pathlib, subprocess, sys
scratch=pathlib.Path('/tmp/issue-1580-research')
raw=(scratch/'native-test-headroom/before.stdout').read_text()
assert 'ℹ tests 3' in raw and 'ℹ pass 0' in raw and 'ℹ fail 3' in raw
assert raw.count('warnLines: 900')==3
subprocess.run([sys.executable,str(scratch/'extract-native-test-headroom.py')],check=True)
