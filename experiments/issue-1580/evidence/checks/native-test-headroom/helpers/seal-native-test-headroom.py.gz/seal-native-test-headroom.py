import datetime, gzip, hashlib, json, pathlib, re, subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
scratch=pathlib.Path('/tmp/issue-1580-research')
out=scratch/'native-test-headroom'
assert json.loads((out/'followup-outcome.json').read_text())['allPassed']
initial=json.loads((out/'records.json').read_text())
assert [row['name'] for row in initial if row['exitCode']]==['native-staged-release','touched-gates']
rows=json.loads((out/'extraction.json').read_text())
for row in rows['files']:
    original=subprocess.check_output(['git','show','HEAD:'+row['parent']],cwd=root).decode()
    assert hashlib.sha256(original.encode()).hexdigest()==row['originalSha256']
    parent=(root/row['parent']).read_text()
    child=(root/row['child']).read_text()
    # Every test/helper body survives exactly, after only the module import header.
    for line in child.splitlines():
        if line.startswith('fn '):assert line in original.splitlines(),line
    if row['child'].endswith('command_capture.rs'):start='#[test]\nfn command_capture_parent_file_is_a_real_failure_without_false_completion()';end=None
    elif row['child'].endswith('standalone_suites.rs'):start='/// Defect D14: 23 test cases that no CI job ran.';end=None
    else:start='/// D3. The policy `.github/zizmor.yml` writes down, applied to the references';end='/// D2. The audit that could not fail.'
    first=original.index(start);last=original.index(end,first) if end else len(original)
    moved=original[first:last]
    assert child[child.index(start):].rstrip()==moved.rstrip()
    module=pathlib.Path(row['child']).stem
    restored_parent=parent.replace('mod '+module+';\n\n','',1)
    expected_parent=original[:first]+original[last:]
    assert restored_parent.rstrip()==expected_parent.rstrip()
    row['postFormattingBodiesUnchanged']=True
    row['actualParentLines']=len(parent.splitlines());row['actualChildLines']=len(child.splitlines())
    assert row['actualParentLines']<=900 and row['actualChildLines']<=900
    row['parentSha256']=hashlib.sha256(parent.encode()).hexdigest();row['childSha256']=hashlib.sha256(child.encode()).hexdigest()
scanner=(root/'experiments/formal_ai_subagent/sandboxes/gates/check-file-size.log').read_text()
assert len(re.findall(r'^::warning file=',scanner,re.M))==84
target=root/'experiments/issue-1580/evidence/checks/native-test-headroom'
target.mkdir(exist_ok=False)
selected=[path for path in out.iterdir() if path.is_file()]
selected += [scratch/name for name in ['draft-native-test-headroom.py','draft-native-test-headroom.log','extract-native-test-headroom.py','apply-native-test-headroom.py','apply-native-test-headroom.log','validate-native-test-headroom.py','validate-native-test-headroom.log','recheck-native-test-headroom.py','recheck-native-test-headroom.log','seal-native-test-headroom.py']]
selected += [root/'experiments/formal_ai_subagent/sandboxes/gates'/name for name in ['check-file-size.log','check-file-size-js-twin.log','check-abbreviations.log']]
records=[]
for path in selected:
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0)
    alias=('gates/' if 'sandboxes/gates' in str(path) else 'helpers/' if path.parent==scratch else 'validation/')+path.name+'.gz'
    destination=target/alias;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed)
    records.append({'source':str(path),'file':alias,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
summary={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':rows['head'],'files':rows['files'],'before':{'tests':3,'passed':0,'failed':3},'after':{'headroom':3,'maintainedObservations':136,'agenticWrites':23,'plannerTwins':3,'releaseOperations':15},'remainingWarnings':84,'scannerLimitsUnchanged':True,'nativeExecutionVerified':False,'retainedRecords':len(records),'fullIssueComplete':False,'independentAuthorshipCredit':0}
(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
doc=root/'docs/case-studies/issue-1580/native-test-headroom-checkpoint.md'
doc.write_text('''# Native regression module headroom

Three maintained Rust test owners exceeded the unchanged 900-line warning
threshold. The actual scanner reproduces all three warnings before extraction.
Command-capture failures, standalone script-suite discovery and image policy
now live in ordinary child modules under their existing test module prefixes.
Every original test and helper body is conserved. An exact inverse reconstructs
the pre-extraction source; formatting removes only trailing blank space.

The scanner regression passes all three cases after extraction. The maintained
observation entry passes 136 cases; write-planner, planner-twin and staged-release
checks pass 23, three and 15 cases respectively. Formatting and all three touched
JavaScript gates pass. The initial reporter assertion, inherited Node options
and misspelled gate name failures remain retained as investigation harness
failures. The corrected invocation preserves the source compiler's existing
refusal of external loader options.

The source scanner reports 84 warnings and zero violations. Its 900/1400 warning
thresholds and 1000/1500 limits are unchanged. These local checks execute no Rust
compiler or native tests. Hosted qualification of these extractions, full
template/practice review and the wider issue requirements remain unfinished.
Supplied scripts earn zero independent authorship or reasoning credit.

Evidence: `experiments/issue-1580/evidence/checks/native-test-headroom/`.
''')
(root/'changelog.d/issue-1580-native-test-headroom.md').write_text('''---
bump: patch
---

Extract native command-capture, script-suite discovery and image-policy regression groups into ordinary child modules. Preserve every assertion and existing test module prefix while removing three source-size warnings under unchanged limits. Keep the scanner regression in the maintained JavaScript checks.
''')
plan=root/'experiments/issue-1580/work-plan.md'
with plan.open('a') as stream:stream.write('\n- Native test module extraction removes three more warnings under unchanged limits: 84 remain. Before-fix scanner cases fail 3/3, then pass; 136 maintained, 23 write-planner, three planner-twin and 15 release-operation cases pass. Exact inverse and unchanged bodies are retained. Native execution, full template/practice review and complete issue acceptance remain open. See [native headroom checkpoint](../../docs/case-studies/issue-1580/native-test-headroom-checkpoint.md).\n')
paths=[row[key] for row in rows['files'] for key in ['parent','child']]+['experiments/issue-1580/native-test-headroom.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs',str(target.relative_to(root)),str(doc.relative_to(root)),'changelog.d/issue-1580-native-test-headroom.md','experiments/issue-1580/work-plan.md']
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
print(json.dumps({'staged':True,'records':len(records),'remainingWarnings':84,'fullIssueComplete':False}))
