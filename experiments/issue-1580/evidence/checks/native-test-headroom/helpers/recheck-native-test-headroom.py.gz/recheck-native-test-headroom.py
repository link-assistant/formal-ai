import json, os, pathlib, subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=pathlib.Path('/tmp/issue-1580-research/native-test-headroom')
assert json.loads((out/'outcome.json').read_text())['complete']
env=dict(os.environ)
env.pop('NODE_OPTIONS',None)
records=[]
for name,args in [
 ('corrected-native-staged-release',['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','rust/tests/web/native-staged-release-operation-view.test.mjs']),
 ('corrected-touched-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-file-size-js-twin,check-abbreviations']),
]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    records.append({'name':name,'args':args,'exitCode':result.returncode})
    (out/'followup-records.json').write_text(json.dumps(records,indent=2)+'\n')
outcome={'complete':True,'allPassed':all(row['exitCode']==0 for row in records),'initialHarnessFailuresPreserved':True,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(out/'followup-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
assert outcome['allPassed'],outcome
print(json.dumps(outcome))
