from pathlib import Path
import json,os,subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/native-policy-headroom')
test=root/'experiments/issue-1580/native-test-headroom.test.mjs'
source=test.read_text()
source=source.replace("import {readFileSync} from 'node:fs';", "import {existsSync, readFileSync} from 'node:fs';\nimport {dirname, resolve} from 'node:path';")
source+='''
test('the standalone data-files Cargo target resolves its extracted helper', () => {
  const cargo = readFileSync(root + '/rust/Cargo.toml', 'utf8');
  const target = cargo.split('[[test]]').find(block => /^name = "data_files"$/mu.test(block));
  assert(target, 'the data-files target must remain registered');
  const cratePath = /^path = "([^"]+)"$/mu.exec(target)?.[1];
  assert(cratePath, 'the target must identify its real Rust crate root');
  const crateFile = resolve(root, 'rust', cratePath);
  const declaration = /(?:#\\[path = "([^"]+)"\\]\\n)?mod text_rows;/u.exec(readFileSync(crateFile, 'utf8'));
  assert(declaration, 'the crate root must retain its text-row helpers');
  const child = resolve(dirname(crateFile), declaration[1] ?? 'text_rows.rs');
  assert(existsSync(child), 'the crate-root module declaration resolves to a missing file: ' + child);
});
'''
assert 'standalone data-files Cargo target' not in test.read_text()
test.write_text(source)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
args=['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',str(test.relative_to(root))]
records=[]
def run(name,command):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        result=subprocess.run(command,cwd=root,env=env,stdout=stdout,stderr=stderr)
    records.append({'name':name,'args':command,'exitCode':result.returncode})
    return result.returncode
assert run('crate-path-before',args)!=0
parent=root/'rust/tests/unit/data_files.rs'
original=parent.read_text();assert original.count('mod text_rows;')==1
parent.write_text(original.replace('mod text_rows;','#[path = "data_files/text_rows.rs"]\nmod text_rows;',1))
assert run('crate-path-after',args)==0
assert run('crate-path-format',['rustfmt','--edition','2024','--config','skip_children=true','--check','rust/tests/unit/data_files.rs'])==0
(out/'crate-path-records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'reproducedMissingModule':True,'afterPassed':True,'nativeBuildRun':False,'records':records}))
