from pathlib import Path
import hashlib,json,os,re,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/native-policy-headroom');out.mkdir(exist_ok=True)
test=root/'experiments/issue-1580/native-test-headroom.test.mjs'
source=test.read_text();assert 'native policy module' not in source
source+='''
for (const [owner, child] of [
  ['rust/tests/unit/ci-cd/workflow_release', 'workflow_policy'],
  ['rust/tests/unit/data_files', 'text_rows'],
  ['rust/tests/unit/specification/benchmarks', 'evaluation'],
]) {
  test(owner + ' keeps native policy module headroom', () => {
    const result = checkListedFiles(root, new Set([owner + '.rs', owner + '/' + child + '.rs']));
    assert.deepEqual(result, {warnings: [], violations: [], embeddedDataViolations: []});
    assert.match(readFileSync(root + '/' + owner + '.rs', 'utf8'), new RegExp('^mod ' + child + ';$', 'mu'));
    assert.match(readFileSync(root + '/' + owner + '/' + child + '.rs', 'utf8'), /^(?:pub\\(super\\) )?fn /mu);
  });
}
'''
test.write_text(source)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
with (out/'before.stdout').open('wb') as stdout,(out/'before.stderr').open('wb') as stderr:
    result=subprocess.run(['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',str(test)],cwd=root,env=env,stdout=stdout,stderr=stderr)
assert result.returncode==1
before=(out/'before.stdout').read_text();assert '# pass 5' in before and '# fail 3' in before
rows=[]
for owner,child,marker,prefix,parent_imports,removed_imports,expose in [
 ('rust/tests/unit/ci-cd/workflow_release','workflow_policy','#[test]\nfn release_workflow_jobs_have_explicit_timeouts()',
  'use std::fs;\n\nuse super::super::workflow_fixtures::{\n    job_block, minimum_job_timeout, pages_artifact_workflow, release_workflow, workflow_job_names,\n};\n\n','',[],False),
 ('rust/tests/unit/data_files','text_rows','fn strip_lino_comment(line: &str)',
  'use std::path::Path;\n\n',
  'use text_rows::{\n    forbidden_meaning_key, lino_comment_body, path_has_component, strip_lino_comment,\n    strip_quoted_spans, wikidata_cache_path,\n};\n\n',[],True),
 ('rust/tests/unit/specification/benchmarks','evaluation','fn assert_required_domains_are_covered(suite: &BenchmarkSuite)',
  'use std::sync::{Mutex, MutexGuard, OnceLock};\n\nuse super::{\n    BTreeSet, BenchmarkCase, BenchmarkReport, BenchmarkSuite, ExecutionSurface,\n    HELD_OUT_VARIANT, PERMISSIVE_LICENSES, REQUIRED_DOMAINS, SolverConfig, UniversalSolver,\n};\n\n',
  'use evaluation::{\n    assert_case_passes_by_derivation, assert_every_case_has_a_permissive_source,\n    assert_held_out_variants_are_covered, assert_pass_count_floor_is_met,\n    assert_pass_count_floor_is_recorded, assert_required_domains_are_covered,\n    benchmark_solver, benchmark_solver_lock, render_report, run_suite,\n};\n\n',
  ['use std::sync::{Mutex, MutexGuard, OnceLock};\n'],True),
]:
    parent=root/(owner+'.rs');original=parent.read_text()
    assert original==subprocess.check_output(['git','show','HEAD:'+owner+'.rs'],cwd=root,text=True)
    assert original.count(marker)==1
    offset=original.index(marker);moved=original[offset:];remaining=original[:offset]
    assert 'super::' not in moved and 'include_str!' not in moved and 'include!' not in moved
    declaration='mod '+child+';\n\n'+parent_imports
    insertion=remaining.index('\n\n')+2
    remaining=remaining[:insertion]+declaration+remaining[insertion:]
    for line in removed_imports:
        assert remaining.count(line)==1;remaining=remaining.replace(line,'',1)
    exposed=re.sub(r'^fn ', 'pub(super) fn ',moved,flags=re.M) if expose else moved
    destination=root/owner/(child+'.rs');destination.parent.mkdir(exist_ok=True);assert not destination.exists()
    destination.write_text(prefix+exposed);parent.write_text(remaining)
    restored=remaining.replace(declaration,'',1)
    for line in removed_imports:
        next_line=original[original.index(line)+len(line):].splitlines(keepends=True)[0]
        # Restore against the untouched prefix at its original position.
        original_position=original.index(line)
        restored=restored[:original_position]+line+restored[original_position:]
    restored=restored[:offset]+moved+restored[offset:]
    assert restored==original
    assert len(remaining.splitlines())<=900 and len((prefix+exposed).splitlines())<=900
    (out/(child+'.before.rs')).write_text(original)
    rows.append({'parent':owner+'.rs','child':str(destination.relative_to(root)),'marker':marker,'offset':offset,'prefix':prefix,'expose':expose,'beforeLines':len(original.splitlines()),'afterLines':len(remaining.splitlines()),'childLines':len((prefix+exposed).splitlines()),'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'movedSha256':hashlib.sha256(moved.encode()).hexdigest(),'exactInverse':True})
(out/'extraction.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'files':rows,'nativeExecutionVerified':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps({'files':rows,'remainingWarningsExpected':81,'nativeBuildRun':False}))
