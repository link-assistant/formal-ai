from pathlib import Path
import json,os,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/native-policy-headroom')
if len(sys.argv)==1:
    with (out/'worker.log').open('wb') as stream:
        process=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':process.pid})+'\n');print(json.dumps({'pid':process.pid,'finite':True}));sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);records=[]
def run(name,args,input=None):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        result=subprocess.run(args,cwd=root,env=env,input=input,stdout=stdout,stderr=stderr)
    records.append({'name':name,'args':args,'exitCode':result.returncode});(out/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records[-1]),flush=True)
    return result.returncode
try:
    extraction=json.loads((out/'extraction.json').read_text())
    files=[item[key] for item in extraction['files'] for key in ['parent','child']]
    assert run('format',['rustfmt','--edition','2024','--config','skip_children=true',*files])==0
    assert run('format-check',['rustfmt','--edition','2024','--config','skip_children=true','--check',*files])==0
    conservation=[]
    for row in extraction['files']:
        original=(out/(Path(row['child']).stem+'.before.rs')).read_text();moved=original[row['offset']:]
        current=(root/row['child']).read_text();body=current[current.index('pub(super) fn ' if row['expose'] else '#[test]'):]
        if row['expose']:body=re.sub(r'^pub\(super\) fn ','fn ',body,flags=re.M)
        assert body==moved,(row['child'],'body changed after formatting')
        conservation.append({'path':row['child'],'bodyUnchangedAfterFormatting':True,'sha256':row['movedSha256']})
    (out/'conservation.json').write_text(json.dumps(conservation,indent=2)+'\n')
    parser="import YAML from 'yaml';import{readFileSync}from'node:fs';const w=YAML.parse(readFileSync('.github/workflows/native-type-check.yml','utf8'));process.stdout.write(JSON.stringify(w.jobs.clippy.steps.filter(s=>s.uses==='actions/checkout@v7').map(s=>s.with['sparse-checkout'])));"
    assert run('sparse-patterns',['node','--max-old-space-size=256','--input-type=module','-e',parser])==0
    patterns=json.loads((out/'sparse-patterns.stdout').read_text())
    candidates=subprocess.check_output(['git','ls-files','--','dev/log/issues/1079/pulls/1080/upstream-reports'],cwd=root,text=True).splitlines()
    assert len(candidates)==9
    sparse=[]
    for index,pattern in enumerate(patterns):
        rules=out/('sparse-rules-'+str(index));rules.write_text(pattern)
        name='sparse-selection-'+str(index)
        assert run(name,['git','sparse-checkout','check-rules','--no-cone','--rules-file',str(rules)],input=('\n'.join(candidates+['dev/log/unrelated.log'])+'\n').encode())==0
        selected=(out/(name+'.stdout')).read_text().splitlines()
        assert selected==candidates,(name,selected)
        sparse.append({'attempt':index,'fixtures':len(candidates),'allSelected':True,'unrelatedLogExcluded':True})
    (out/'sparse-selection.json').write_text(json.dumps(sparse,indent=2)+'\n')
    for name,path in [('headroom','experiments/issue-1580/native-test-headroom.test.mjs'),('data-integrity','rust/tests/web/data-integrity.test.mjs'),('native-groups','experiments/issue-1580/native-regression-groups.test.mjs'),('maintained','rust/tests/web/issue-1580-template-observations.test.mjs')]:
        if not (root/path).exists():
            records.append({'name':name,'status':'not-present','path':path});continue
        run(name,['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',path])
    run('touched-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size,check-file-size-js-twin'])
    run('whitespace',['git','diff','--check'])
    outcome={'complete':True,'allPassed':all(row.get('exitCode',0)==0 for row in records),'nativeBuildRun':False,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
    (out/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
