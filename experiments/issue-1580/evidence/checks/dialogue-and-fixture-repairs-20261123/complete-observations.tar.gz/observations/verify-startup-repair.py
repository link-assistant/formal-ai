from pathlib import Path
import subprocess,json,os,time,datetime
r=Path('/tmp/issue-1580-research/javascript-shard-headroom-7ec0')
while not (r/'final-gates-outcome.json').exists():time.sleep(5)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);records=[]
for label,file in [
 ('process-startup-after','experiments/issue-1580/process-fixture-shell-startup.test.mjs'),
 ('profile-startup-after','experiments/issue-1580/full-default-javascript-profile.test.mjs'),
 ('budget-lifetime-after','experiments/issue-1580/budget-process-lifetime.test.mjs'),
 ('deadline-lifetime-after','experiments/issue-1580/deadline-process-lifetime.test.mjs'),
 ('maintained-observations-after','rust/tests/web/issue-1580-template-observations.test.mjs')]:
 cmd=['node','--test','--test-concurrency=1',file];started=time.monotonic()
 with (r/(label+'.log')).open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 rec={'label':label,'command':cmd,'exitCode':p.returncode,'seconds':time.monotonic()-started,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 records.append(rec);(r/'startup-repair-records.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(rec),flush=True)
(r/'startup-repair-outcome.json').write_text(json.dumps({'complete':True,'allPassed':all(x['exitCode']==0 for x in records),'records':records},indent=2)+'\n')
