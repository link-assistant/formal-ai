from pathlib import Path
import subprocess,json,datetime,os,shutil,time
r=Path('/tmp/issue-1580-research/javascript-shard-headroom-7ec0')
env=os.environ.copy();env.pop('NODE_OPTIONS',None);records=[]
tests=[
 ('ownership','experiments/issue-1580/cnl-dialogue-partition.test.mjs'),
 ('historical-scheduling','experiments/issue-1580/hosted-javascript-scheduling.test.mjs'),
 ('dialogue-a','rust/tests/web/cnl-solver-dialogue.test.mjs'),
 ('dialogue-b','rust/tests/web/cnl-solver-dialogue-b.test.mjs'),
 ('dialogue-c','rust/tests/web/cnl-solver-dialogue-c.test.mjs')]
commands=[(label,['node','--test','--test-concurrency=1',file]) for label,file in tests]
commands.append(('all-javascript-gates',['node','experiments/formal_ai_subagent/local-gates.mjs']))
for label,cmd in commands:
 started=time.monotonic()
 with (r/(label+'.log')).open('wb') as log:
  p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
 record={'label':label,'command':cmd,'exitCode':p.returncode,'seconds':time.monotonic()-started,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'memoryCurrent':int(Path('/sys/fs/cgroup/memory.current').read_text())}
 records.append(record);(r/'verification-records.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
 if label=='all-javascript-gates':
  d=r/'complete-gate-outputs';d.mkdir(exist_ok=True)
  for file in Path('experiments/formal_ai_subagent/sandboxes/gates').glob('*.log'):
   if file.stat().st_mtime>=time.time()-(time.monotonic()-started)-5:shutil.copyfile(file,d/file.name)
(r/'verification-outcome.json').write_text(json.dumps({'complete':True,'allPassed':all(x['exitCode']==0 for x in records),'records':records},indent=2)+'\n')
