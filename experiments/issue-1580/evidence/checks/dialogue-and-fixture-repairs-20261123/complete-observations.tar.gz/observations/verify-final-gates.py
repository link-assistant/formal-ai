from pathlib import Path
import subprocess,json,os,time,datetime,shutil,hashlib
r=Path('/tmp/issue-1580-research/javascript-shard-headroom-7ec0')
while not (r/'followup-outcome.json').exists():time.sleep(5)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
cmd=['node','experiments/formal_ai_subagent/local-gates.mjs'];started=time.time()
inputs=['data/meta/javascript-test-durations.lino','experiments/issue-1580/hosted-javascript-scheduling.test.mjs','experiments/issue-1580/cnl-dialogue-partition.test.mjs']
hashes={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in inputs}
with (r/'final-all-javascript-gates.log').open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
assert hashes=={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in inputs}
text=(r/'final-all-javascript-gates.log').read_text()
outcome={'complete':True,'command':cmd,'exitCode':p.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.time()-started,'counts':{status:sum(line.startswith(status+' ') for line in text.splitlines()) for status in ['PASS','SKIP','FAIL']},'inputSha256':hashes}
d=r/'final-complete-gate-outputs';d.mkdir(exist_ok=True)
for file in Path('experiments/formal_ai_subagent/sandboxes/gates').glob('*.log'):
 if file.stat().st_mtime>=started-1:shutil.copyfile(file,d/file.name)
(r/'final-gates-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome),flush=True)
