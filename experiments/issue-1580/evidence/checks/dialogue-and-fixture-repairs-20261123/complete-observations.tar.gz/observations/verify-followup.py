from pathlib import Path
import subprocess,json,os,time,datetime
r=Path('/tmp/issue-1580-research/javascript-shard-headroom-7ec0')
while not (r/'verification-outcome.json').exists():time.sleep(5)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);records=[]
for label,file in [
 ('historical-scheduling-after','experiments/issue-1580/hosted-javascript-scheduling.test.mjs'),
 ('complete-profile','experiments/issue-1580/full-default-javascript-profile.test.mjs'),
 ('ci-speed-policy','rust/tests/web/ci-speed.test.mjs'),
 ('maintained-observations','rust/tests/web/issue-1580-template-observations.test.mjs')]:
 cmd=['node','--test','--test-concurrency=1',file];started=time.monotonic()
 with (r/(label+'.log')).open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 record={'label':label,'command':cmd,'exitCode':p.returncode,'seconds':time.monotonic()-started,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 records.append(record);(r/'followup-records.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
(r/'followup-outcome.json').write_text(json.dumps({'complete':True,'allPassed':all(x['exitCode']==0 for x in records),'records':records},indent=2)+'\n')
