from pathlib import Path
import subprocess,json,os,time,datetime,shutil
r=Path('/tmp/issue-1580-research/javascript-shard-headroom-7ec0')
while not (r/'startup-repair-outcome.json').exists():time.sleep(5)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
gates=['check-abbreviations','check-file-size','check-file-size-js-twin','check-minimal-core-boundary','check-minimal-core-boundary-js-twin','check-debt-ratchet-js-twin','check_debt_ratchet','check-changelog-fragment-js-twin','check-readable-code','lint-shell-scripts']
records=[];d=r/'new-files-complete-gate-outputs';d.mkdir(exist_ok=True)
for gate in gates:
 cmd=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate];start=time.monotonic()
 with (r/('new-files-'+gate+'.log')).open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 source=Path('experiments/formal_ai_subagent/sandboxes/gates')/(gate+'.log')
 if source.exists():shutil.copyfile(source,d/source.name)
 rec={'gate':gate,'exitCode':p.returncode,'seconds':time.monotonic()-start,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()};records.append(rec)
 (r/'new-files-gates-records.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(rec),flush=True)
(r/'new-files-gates-outcome.json').write_text(json.dumps({'complete':True,'allPassed':all(x['exitCode']==0 for x in records),'records':records},indent=2)+'\n')
