from pathlib import Path
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/codeql-cache-retention-repair')
path = root / 'rust/tests/web/security-codeql-results.test.mjs'
before = path.read_text()
(out / 'before.security-test.mjs').write_text(before)
old = "    assert '--threads=2' in args and '--ram=4096' in args and '--max-disk-cache=512' in args"
new = "    assert '--threads=2' in args and '--ram=4096' in args and '--max-disk-cache=4096' in args\n    assert '--keep-full-cache' in args, 'the following payload query reuses the same database cache'"
assert before.count(old) == 1
path.write_text(before.replace(old, new))
print('Updated the existing macro adapter fixture to require cache retention for the following payload observation.')
