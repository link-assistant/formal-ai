from pathlib import Path
import subprocess, json, os
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/codeql-cache-retention-repair')
out.mkdir(exist_ok=True)
test_path = root / 'experiments/issue-1580/codeql-included-string-observation.test.mjs'
before = test_path.read_text()
(out / 'before.test.mjs').write_text(before)
old = "  const gate = steps.find(step => step.name === 'Reject unresolved CodeQL findings');"
new = '''  const analysis = steps.find(step => step.id === 'codeql-analyze');
  const cacheOptions = analysis.env.CODEQL_ACTION_EXTRA_OPTIONS;
  assert.match(cacheOptions, /github.job == 'codeql-readonly'/);
  assert.match(cacheOptions, /matrix.language == 'rust' && inputs.macro-contexts/);
  const options = JSON.parse(cacheOptions.match(/'(\\{"database".*?\\})'/u)[1]);
  assert.deepEqual(options.database['run-queries'], [
    '--no-expect-discarded-cache', '--keep-full-cache', '--max-disk-cache=4096',
  ]);
  assert.match(cacheOptions, /\\|\\| '\\{\\}'/u);
''' + old
assert before.count(old) == 1
after = before.replace(old, new)
old = "elif args[:2]==['query','run']:\n    assert '--warnings=error' in args"
new = """elif args[:2]==['query','run']:
    cache=root/'completed-producer-relations'
    if '--keep-full-cache' not in args:
        cache.unlink(missing_ok=True)
    assert '--max-disk-cache=4096' in args
    assert '--warnings=error' in args"""
assert after.count(old) == 1
after = after.replace(old, new)
old = "        (root/'calls.jsonl').write_text('')\n        output=root/('output-'+mode)"
new = """        (root/'calls.jsonl').write_text('')
        cache=root/'completed-producer-relations'
        cache.write_bytes(b'original producer cache fixture')
        output=root/('output-'+mode)"""
assert after.count(old) == 1
after = after.replace(old, new)
old = "        manifest=json.loads((output/'manifest.json').read_text())"
new = "        assert cache.read_bytes()==b'original producer cache fixture',mode\n" + old
assert after.count(old) == 1
after = after.replace(old, new)
test_path.write_text(after)
env = dict(os.environ, NODE_OPTIONS='--max-old-space-size=192')
with (out / 'before-fix.stdout').open('wb') as stdout, (out / 'before-fix.stderr').open('wb') as stderr:
    result = subprocess.run(['node', '--test', '--test-concurrency=1', str(test_path.relative_to(root))], cwd=root, env=env, stdout=stdout, stderr=stderr)
assert result.returncode != 0
text = (out / 'before-fix.stdout').read_text()
assert 'CODEQL_ACTION_EXTRA_OPTIONS' in text or 'Cannot read properties of undefined' in text
(out / 'reproduced.json').write_text(json.dumps({'exitCode': result.returncode, 'cacheRegressionFailsBeforeFix': True, 'nativeExecution': False, 'actualCodeQLExecution': False, 'hostedQualificationPending': True}, indent=2) + '\n')
print((out / 'reproduced.json').read_text())
