from pathlib import Path
import gzip, hashlib, json, os, subprocess, sys, traceback
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/codeql-cache-retention-repair')
if '--worker' not in sys.argv:
    with (out / 'resume-gates.log').open('ab') as log:
        worker = subprocess.Popen([sys.executable, __file__, '--worker'], cwd=root, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': worker.pid, 'directory': str(out)})); sys.exit()
records = []
for line in (out / 'worker.log').read_text().splitlines():
    if line.startswith('{"name": '): records.append(json.loads(line))
for name in ['adapter', 'profile', 'security', 'pinned-analyze', 'pinned-codeql', 'pinned-util']:
    assert next(row for row in reversed(records) if row['name'] == name)['exitCode'] == 0
env = dict(os.environ, NODE_OPTIONS='--max-old-space-size=192')
try:
    for stream in ['stdout', 'stderr']:
        (out / ('interrupted-all-gates.' + stream)).write_bytes((out / ('all-javascript-gates.' + stream)).read_bytes())
    for name, args in [('all-javascript-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs']), ('whitespace', ['git', 'diff', '--check'])]:
        with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
            result = subprocess.run(args, cwd=root, env=env, stdout=stdout, stderr=stderr)
        record = {'name': name, 'argv': args, 'exitCode': result.returncode}; records.append(record)
        print(json.dumps(record), flush=True)
        assert result.returncode == 0, name
    archive = root / 'experiments/issue-1580/evidence/checks/codeql-cache-retention-repair'
    archive.mkdir(exist_ok=False)
    scripts = ['verify-codeql-cache-retention.py', 'draft-codeql-cache-regression.py', 'draft-codeql-cache-retention.py', 'update-macro-cache-fixture.py', 'resume-codeql-cache-gates.py']
    sources = [Path('/tmp/issue-1580-research') / name for name in scripts]
    sources += sorted(p for p in out.iterdir() if p.is_file() and p.name not in ['worker.log', 'resume-gates.log'])
    inventory = []
    for source in sources:
        raw = source.read_bytes(); name = source.name.replace('pinned-util.', 'pinned-utilities.') + '.gz'; packed = gzip.compress(raw, mtime=0)
        (archive / name).write_bytes(packed)
        inventory.append({'originalName': source.name, 'file': name, 'sha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
    (archive / 'streams.json').write_text(json.dumps(inventory, indent=2) + '\n')
    (archive / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    paths = ['.github/workflows/security.yml', 'data/benchmarks/fast-pull-request-retained-jobs.json', 'experiments/issue-1580/codeql-macro-contexts/observe.py', 'experiments/issue-1580/codeql-macro-contexts/README.md', 'experiments/issue-1580/codeql-included-string-observation.test.mjs', 'rust/tests/web/security-codeql-results.test.mjs']
    outcome = {'passed': True, 'regressionFailedBeforeFix': True, 'unchangedFourMinuteBounds': True, 'unchangedQuery': True, 'querySha256': hashlib.sha256((root / 'experiments/issue-1580/codeql-macro-contexts/IncludedStringPayloads.ql').read_bytes()).hexdigest(), 'standardSecurityGatePreserved': True, 'cacheRetentionOnlyForOptInRustInvestigation': True, 'actionRevision': '1bd86f2fdb4b86187fa4059f16f31a3202acc9ea', 'paths': [{'path': p, 'sha256': hashlib.sha256((root / p).read_bytes()).hexdigest()} for p in paths], 'actualCodeQLExecution': False, 'hostedRepairQualificationPending': True, 'rootCauseFullyQualified': False, 'interruptedReplayPreserved': True, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
    (archive / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    (out / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    print(json.dumps(outcome), flush=True)
except Exception:
    (out / 'gate-resume-failure.json').write_text(json.dumps({'records': records, 'traceback': traceback.format_exc()}, indent=2) + '\n')
    traceback.print_exc(); sys.exit(1)
