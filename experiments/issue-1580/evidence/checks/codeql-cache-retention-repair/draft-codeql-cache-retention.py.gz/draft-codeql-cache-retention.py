from pathlib import Path
import json, hashlib, subprocess
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/codeql-cache-retention-repair')
assert json.loads((out / 'reproduced.json').read_text())['cacheRegressionFailsBeforeFix']
workflow = root / '.github/workflows/security.yml'
before = workflow.read_text()
(out / 'before.security.yml').write_text(before)
old = '''      - uses: github/codeql-action/analyze@v4
        id: codeql-analyze
        with:
'''
new = '''      - uses: github/codeql-action/analyze@v4
        id: codeql-analyze
        env:
          # The following observations query the same completed Rust dataset.
          # Retain its stages rather than rebuilding name binding and control
          # flow after the action and first observer discard their caches.
          CODEQL_ACTION_EXTRA_OPTIONS: >-
            ${{ github.job == 'codeql-readonly' && matrix.language == 'rust' && inputs.macro-contexts
              && '{"database":{"run-queries":["--no-expect-discarded-cache","--keep-full-cache","--max-disk-cache=4096"]}}'
              || '{}' }}
        with:
'''
assert before.count(old) == 1
workflow.write_text(before.replace(old, new))
adapter = root / 'experiments/issue-1580/codeql-macro-contexts/observe.py'
before = adapter.read_text()
(out / 'before.observe.py').write_text(before)
old = '''                          "--threads=2", *memory_options, "--max-disk-cache=512",
'''
new = '''                          # Both observations reuse the producer's cached loading stages.
                          # A small cleanup cap here evicts them before the CFG query.
                          "--threads=2", *memory_options, "--max-disk-cache=4096",
                          "--keep-full-cache",
'''
assert before.count(old) == 1
adapter.write_text(before.replace(old, new))
readme = root / 'experiments/issue-1580/codeql-macro-contexts/README.md'
before = readme.read_text()
(out / 'before.README.md').write_text(before)
paragraph = '''
The opt-in Rust investigation retains intermediate results from the standard
analysis and both observers. Run 44848465533 compiled the payload query but
timed out rebuilding whole-database name binding before its control-flow result
was available. The standard action used `--expect-discarded-cache`, and each
observer allowed a 512 MiB cleanup. The investigation now passes
`--no-expect-discarded-cache --keep-full-cache --max-disk-cache=4096` to the
action's query evaluation and retains that cache across both observations.
The four-minute step bounds, memory policy, nine output columns and security
gate still apply. Hosted execution must qualify this cache-retention repair;
the fixture regression does not execute CodeQL or establish macro semantics.

Cache option contracts: [query run](https://docs.github.com/en/code-security/reference/code-scanning/codeql/codeql-cli-manual/query-run),
[producer action](https://github.com/github/codeql-action/blob/1bd86f2fdb4b86187fa4059f16f31a3202acc9ea/src/analyze.ts#L461),
[action argument order](https://github.com/github/codeql-action/blob/1bd86f2fdb4b86187fa4059f16f31a3202acc9ea/src/codeql.ts#L774).
'''
readme.write_text(before.rstrip() + '\n' + paragraph)
print(json.dumps({'drafted': [str(p.relative_to(root)) for p in [workflow, adapter, readme]], 'timeoutIncreased': False, 'queryChanged': False, 'hostedQualificationPending': True}))
