from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, resource, subprocess, sys, traceback

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'codeql-cache-retention-repair'
if '--worker' not in sys.argv:
    with (out / 'finish.log').open('ab') as stream:
        worker = subprocess.Popen([sys.executable, __file__, '--worker'], cwd=root,
            stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': worker.pid, 'directory': str(out)}))
    sys.exit(0)

records = json.loads((out / 'gate-resume-failure.json').read_text())['records']
assert '140/141 passed or skipped; failed: layered-ci#4' in (out / 'all-javascript-gates.stdout').read_text()
gate = root / 'experiments/formal_ai_subagent/sandboxes/gates/layered-ci#4.log'
assert 'JavaScript heap out of memory' in gate.read_text()
(out / 'source-model-192-mebibyte.log').write_bytes(gate.read_bytes())
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=192')

def run(name, argv, heap=192):
    env = dict(environment, NODE_OPTIONS='--max-old-space-size=' + str(heap))
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=root, env=env, stdout=stdout, stderr=stderr)
    row = {'name': name, 'argv': argv, 'exitCode': result.returncode,
        'nodeHeapMebibytes': heap, 'largestReapedChildRssKibibytes': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss}
    records.append(row)
    print(json.dumps(row), flush=True)
    assert result.returncode == 0, name

try:
    run('qualify-cache-wording', ['python3', str(scratch / 'qualify-cache-comment-wording.py')])
    run('terminal-ci-assessment', ['python3', str(scratch / 'assess-bbda-terminal-ci.py')])
    run('warning-inventory', ['python3', str(scratch / 'inventory-world-algorithm-warning-checkpoint.py')])
    run('source-model-256-mebibyte', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'layered-ci#4'], 256)
    (out / 'source-model-256-mebibyte.log').write_bytes(gate.read_bytes())
    run('adapter-final', ['node', '--test', '--test-concurrency=1', 'experiments/issue-1580/codeql-included-string-observation.test.mjs'])
    code = '''import fs from 'node:fs'; import assert from 'node:assert/strict'; import YAML from 'yaml';
import {createHash} from 'node:crypto';
const job=YAML.parse(fs.readFileSync('.github/workflows/security.yml','utf8')).jobs.codeql;
const value=createHash('sha256').update(JSON.stringify({steps:job.steps,uses:job.uses,with:job.with,strategy:job.strategy})).digest('hex');
const row=JSON.parse(fs.readFileSync('data/benchmarks/fast-pull-request-retained-jobs.json','utf8')).jobs.find(r=>r.file==='security.yml'&&r.id==='codeql');
assert.equal(value,row.payloadSha256); console.log(value);'''
    run('final-fingerprint-currency', ['node', '--input-type=module', '-e', code])
    archive = root / 'experiments/issue-1580/evidence/checks/codeql-cache-retention-repair'
    archive.mkdir(exist_ok=False)
    helpers = ['verify-codeql-cache-retention.py', 'draft-codeql-cache-regression.py', 'draft-codeql-cache-retention.py', 'update-macro-cache-fixture.py', 'resume-codeql-cache-gates.py', 'qualify-cache-comment-wording.py', 'finish-codeql-cache-retention.py']
    sources = [scratch / name for name in helpers]
    sources += sorted(p for p in out.iterdir() if p.is_file() and p.name not in ['worker.log', 'resume-gates.log', 'finish.log'])
    inventory = []
    for source in sources:
        raw = source.read_bytes()
        name = source.name.replace('pinned-util.', 'pinned-utilities.') + '.gz'
        packed = gzip.compress(raw, mtime=0)
        (archive / name).write_bytes(packed)
        inventory.append({'originalName': source.name, 'file': name, 'sha256': hashlib.sha256(raw).hexdigest(),
            'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
    (archive / 'streams.json').write_text(json.dumps(inventory, indent=2) + '\n')
    for name in ['check-abbreviations', 'check-file-size', 'check-readable-code']:
        run('final-' + name, ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', name])
    run('whitespace', ['git', 'diff', '--check'])
    paths = ['.github/workflows/security.yml', 'data/benchmarks/fast-pull-request-retained-jobs.json',
        'experiments/issue-1580/codeql-macro-contexts/observe.py', 'experiments/issue-1580/codeql-macro-contexts/README.md',
        'experiments/issue-1580/codeql-included-string-observation.test.mjs', 'rust/tests/web/security-codeql-results.test.mjs']
    outcome = {'passed': True, 'observedAt': datetime.now(timezone.utc).isoformat(),
        'fullReplayPassedOrSkipped': 140, 'fullReplayEntries': 141,
        'fullReplaySoleFailure': 'layered-ci#4: local 192 MiB JavaScript heap cap',
        'sourceModelFocusedReplayPassedAt256Mebibytes': True, 'allGateEntriesCovered': True,
        'regressionFailedBeforeFix': True, 'unchangedFourMinuteBounds': True, 'unchangedQuery': True,
        'querySha256': hashlib.sha256((root / 'experiments/issue-1580/codeql-macro-contexts/IncludedStringPayloads.ql').read_bytes()).hexdigest(),
        'standardSecurityGatePreserved': True, 'cacheRetentionOnlyForOptInRustInvestigation': True,
        'actionRevision': '1bd86f2fdb4b86187fa4059f16f31a3202acc9ea',
        'paths': [{'path': p, 'sha256': hashlib.sha256((root / p).read_bytes()).hexdigest()} for p in paths],
        'actualCodeQLExecution': False, 'hostedRepairQualificationPending': True, 'rootCauseFullyQualified': False,
        'interruptedReplayPreserved': True, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
    (archive / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    (archive / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    for row in records:
        if not row['name'].startswith('final-check-') and row['name'] != 'whitespace':
            continue
        for label in ['stdout', 'stderr']:
            source = out / (row['name'] + '.' + label)
            raw = source.read_bytes(); packed = gzip.compress(raw, mtime=0); name = source.name + '.gz'
            (archive / name).write_bytes(packed)
            inventory.append({'originalName': source.name, 'file': name, 'sha256': hashlib.sha256(raw).hexdigest(),
                'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
    (archive / 'streams.json').write_text(json.dumps(inventory, indent=2) + '\n')
    (out / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    print(json.dumps(outcome), flush=True)
except Exception:
    (out / 'finish-failure.json').write_text(json.dumps({'records': records, 'traceback': traceback.format_exc()}, indent=2) + '\n')
    traceback.print_exc()
    sys.exit(1)
