from pathlib import Path
root = Path('/tmp/gh-issue-solver-1794900398048')
changes = {
    '.github/workflows/security.yml': (
        '          # Retain its stages rather than rebuilding name binding and control\n          # flow after the action and first observer discard their caches.\n',
        '          # Retain its stages for the following name-binding and control-flow\n          # observations; hosted execution must qualify their cache reuse.\n'),
    'experiments/issue-1580/codeql-macro-contexts/observe.py': (
        "                          # A small cleanup cap here evicts them before the CFG query.\n",
        "                          # Avoid cache cleanup between these related observations.\n"),
    'experiments/issue-1580/codeql-macro-contexts/README.md': (
        'timed out rebuilding whole-database name binding before its control-flow result\nwas available. The standard action used `--expect-discarded-cache`, and each\nobserver allowed a 512 MiB cleanup. The investigation now passes\n',
        'timed out during whole-database name binding before its control-flow result\nwas available. Cache eviction as the cause remains an inference. The standard\naction used `--expect-discarded-cache`, and each observer used a 512 MiB cache\ncap. The investigation now passes\n'),
}
for relative, (old, new) in changes.items():
    path = root / relative
    value = path.read_text()
    assert value.count(old) == 1, relative
    path.write_text(value.replace(old, new))
print('Qualified three cache comments without claiming a demonstrated eviction cause.')
