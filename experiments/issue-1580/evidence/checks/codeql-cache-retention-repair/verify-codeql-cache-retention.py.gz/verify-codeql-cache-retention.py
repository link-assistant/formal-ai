from pathlib import Path
import gzip, hashlib, json, os, subprocess, sys, traceback
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/codeql-cache-retention-repair')
if '--worker' not in sys.argv:
    with (out / 'worker.log').open('ab') as log:
        process = subprocess.Popen([sys.executable, __file__, '--worker', *(['--resume'] if '--resume' in sys.argv else [])], cwd=root, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': process.pid, 'directory': str(out)}))
    sys.exit()
records = []
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=192')
def run(name, arguments):
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(arguments, cwd=root, env=environment, stdout=stdout, stderr=stderr)
    row = {'name': name, 'argv': arguments, 'exitCode': result.returncode}
    records.append(row)
    print(json.dumps(row), flush=True)
    assert result.returncode == 0, name
try:
    manifest = root / 'data/benchmarks/fast-pull-request-retained-jobs.json'
    if '--resume' not in sys.argv:
        (out / 'before.retained-jobs.json').write_bytes(manifest.read_bytes())
    code = '''import fs from 'node:fs'; import assert from 'node:assert/strict'; import YAML from 'yaml';
import {execFileSync} from 'node:child_process'; import {createHash} from 'node:crypto';
const old=YAML.parse(execFileSync('git',['show','HEAD:.github/workflows/security.yml'],{encoding:'utf8'})).jobs.codeql;
const current=YAML.parse(fs.readFileSync('.github/workflows/security.yml','utf8')).jobs.codeql;
const reverted=structuredClone(current), analysis=reverted.steps.find(s=>s.id==='codeql-analyze');
assert.equal(old.steps.find(s=>s.id==='codeql-analyze').env,undefined);
assert.deepEqual(Object.keys(analysis.env),['CODEQL_ACTION_EXTRA_OPTIONS']);
assert.match(analysis.env.CODEQL_ACTION_EXTRA_OPTIONS,/github.job == 'codeql-readonly' && matrix.language == 'rust' && inputs.macro-contexts/u);
delete analysis.env; assert.deepEqual(reverted,old);
const payload=j=>({steps:j.steps,uses:j.uses,with:j.with,strategy:j.strategy});
const hash=j=>createHash('sha256').update(JSON.stringify(payload(j))).digest('hex');
const path='data/benchmarks/fast-pull-request-retained-jobs.json', data=JSON.parse(fs.readFileSync(path,'utf8'));
const rows=data.jobs.filter(r=>r.file==='security.yml'&&r.id==='codeql'); assert.equal(rows.length,1);
assert.equal(rows[0].payloadSha256,hash(old)); rows[0].payloadSha256=hash(current);
fs.writeFileSync(path,JSON.stringify(data,null,2)+'\\n');
console.log(JSON.stringify({onlyOptInCacheEnvironmentAdded:true,jobAdmissionAndTimeoutsUnchanged:true,payloadSha256:rows[0].payloadSha256}));'''
    if '--resume' not in sys.argv:
        run('retained-producer-inverse', ['node', '--input-type=module', '-e', code])
    else:
        records.extend(json.loads((out / 'failure.json').read_text())['records'])
        for stream in ['stdout', 'stderr']:
            (out / ('first-security.' + stream)).write_bytes((out / ('security.' + stream)).read_bytes())
        (out / 'first-failure.json').write_bytes((out / 'failure.json').read_bytes())
    tests = [('adapter', 'experiments/issue-1580/codeql-included-string-observation.test.mjs'), ('profile', 'rust/tests/web/fast-pull-request-production-profile.test.mjs'), ('security', 'rust/tests/web/security-codeql-results.test.mjs')]
    for name, path in (tests if '--resume' not in sys.argv else tests[2:]):
        run(name, ['node', '--test', '--test-concurrency=1', path])
    revision = '1bd86f2fdb4b86187fa4059f16f31a3202acc9ea'
    for name, path in [('pinned-analyze', 'src/analyze.ts'), ('pinned-codeql', 'src/codeql.ts'), ('pinned-util', 'src/util.ts')]:
        run(name, ['gh', 'api', '-H', 'Accept: application/vnd.github.raw+json', 'repos/github/codeql-action/contents/' + path + '?ref=' + revision])
    analyze = (out / 'pinned-analyze.stdout').read_text()
    cli = (out / 'pinned-codeql.stdout').read_text()
    util = (out / 'pinned-util.stdout').read_text()
    assert 'queryFlags.push("--expect-discarded-cache")' in analyze
    assert 'getExtraOptionsFromEnv(["database", "run-queries"]' in cli
    assert '!ignoringOptions?.includes(option)' in cli
    assert 'CODEQL_ACTION_EXTRA_OPTIONS' in util
    run('all-javascript-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs'])
    run('whitespace', ['git', 'diff', '--check'])
    archive = root / 'experiments/issue-1580/evidence/checks/codeql-cache-retention-repair'
    archive.mkdir(exist_ok=False)
    sources = [Path(__file__), Path('/tmp/issue-1580-research/draft-codeql-cache-regression.py'), Path('/tmp/issue-1580-research/draft-codeql-cache-retention.py'), Path('/tmp/issue-1580-research/update-macro-cache-fixture.py')]
    sources += sorted(p for p in out.iterdir() if p.is_file() and p.name != 'worker.log')
    inventory = []
    for source in sources:
        raw = source.read_bytes(); name = source.name + '.gz'; packed = gzip.compress(raw, mtime=0)
        (archive / name).write_bytes(packed)
        inventory.append({'file': name, 'sha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
    (archive / 'streams.json').write_text(json.dumps(inventory, indent=2) + '\n')
    (archive / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    paths = ['.github/workflows/security.yml', 'data/benchmarks/fast-pull-request-retained-jobs.json', 'experiments/issue-1580/codeql-macro-contexts/observe.py', 'experiments/issue-1580/codeql-macro-contexts/README.md', 'experiments/issue-1580/codeql-included-string-observation.test.mjs', 'rust/tests/web/security-codeql-results.test.mjs']
    outcome = {'passed': True, 'regressionFailedBeforeFix': True, 'unchangedFourMinuteBounds': True, 'unchangedQuery': True, 'querySha256': hashlib.sha256((root / 'experiments/issue-1580/codeql-macro-contexts/IncludedStringPayloads.ql').read_bytes()).hexdigest(), 'standardSecurityGatePreserved': True, 'cacheRetentionOnlyForOptInRustInvestigation': True, 'actionRevision': revision, 'paths': [{'path': p, 'sha256': hashlib.sha256((root / p).read_bytes()).hexdigest()} for p in paths], 'actualCodeQLExecution': False, 'hostedRepairQualificationPending': True, 'rootCauseFullyQualified': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
    (archive / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    (out / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    print(json.dumps(outcome), flush=True)
except Exception:
    (out / 'failure.json').write_text(json.dumps({'records': records, 'traceback': traceback.format_exc()}, indent=2) + '\n')
    traceback.print_exc()
    sys.exit(1)
