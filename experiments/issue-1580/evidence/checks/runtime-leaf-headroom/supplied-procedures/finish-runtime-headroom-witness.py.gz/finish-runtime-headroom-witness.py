from pathlib import Path
import json,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'runtime-headroom-witness-continuation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':result.returncode}),flush=True);assert result.returncode==0,(name,result.returncode)
try:
 assert (scratch/'runtime-headroom-leaf-continuation/failed.txt').exists()
 registry=root/'scripts/lib/generated-native-programs.mjs';(out/'previous-generated-native-programs.mjs').write_bytes(registry.read_bytes())
 run('native-registry-generation',['node','--max-old-space-size=256','scripts/lib/generate-native-specification-programs.mjs'])
 run('native-registry-currency',['node','--max-old-space-size=256','scripts/lib/generate-native-specification-programs.mjs','--check'])
 run('reviewed-witness-refresh',['node','--max-old-space-size=256',str(scratch/'refresh-runtime-headroom-witness.mjs')])
 run('maintained-observations',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])
 run('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-abbreviations,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-changelog-fragment-js-twin,check-reconstructed-changelog'])
 run('source-warnings',['node','--max-old-space-size=256','scripts/check-file-size.mjs']);warnings=(out/'source-warnings.stdout').read_text().count('::warning file=');assert warnings==28,warnings
 run('whitespace',['git','diff','--check']);assert 'ℹ pass 282' in (out/'maintained-observations.stdout').read_text()
 result={'complete':True,'warnings':warnings,'extractedFunctions':15,'owners':14,'maintainedIssueTestsPassed':282,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
 (out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
