from pathlib import Path
import hashlib,json,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'runtime-headroom-leaf-extraction'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':result.returncode}),flush=True);assert result.returncode in allowed,(name,result.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 assert json.loads((scratch/'runtime-desktop-headroom-preservation/outcome.json').read_text())['complete']
 selections=json.loads((scratch/'runtime-headroom-leaf-selection/selection.json').read_text())
 for row in selections:
  if row['owner']=='rust/src/meta_reasoner/reasoner.rs':row['child']='reasoning_steps';row['target']='rust/src/meta_reasoner/reasoner/reasoning_steps.rs'
 test=root/'experiments/issue-1580/runtime-module-headroom.test.mjs';assert not test.exists()
 groups=[[row['owner'],row['target'],row['name']] for row in selections]
 test.write_text('''// Complete native function extraction must retain source-size headroom.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import test from 'node:test';
import {checkListedFiles} from '../../scripts/check-file-size.mjs';
const root=fileURLToPath(new URL('../../',import.meta.url)).replace(/\\/$/u,'');
for (const [owner,helper,name] of '''+json.dumps(groups,indent=2)+''') {
 test(owner+' keeps its complete function below the unchanged size warning',()=>{
  assert.deepEqual(checkListedFiles(root,new Set([owner,helper])),{warnings:[],violations:[],embeddedDataViolations:[]});
  const source=readFileSync(root+'/'+owner,'utf8'),child=readFileSync(root+'/'+helper,'utf8');
  const module=helper.split('/').at(-1).slice(0,-3);
  assert(source.includes('mod '+module+';'));
  assert(source.includes('use '+module+'::'+name+';'));
  assert(!new RegExp('fn '+name+'\\\\b','u').test(source),'the function must have one owner');
  assert(new RegExp('fn '+name+'\\\\b','u').test(child),'the original function remains reachable');
 });
}
''')
 run('headroom-before',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)],(1,))
 records=[];files=[]
 for row in selections:
  owner=root/row['owner'];source=owner.read_text();assert hashlib.sha256(source.encode()).hexdigest()==row['sourceSha256'];body=source[row['start']:row['end']];assert hashlib.sha256(body.encode()).hexdigest()==row['bodySha256']
  saved=out/'preimages'/row['owner'];saved.parent.mkdir(parents=True,exist_ok=True);saved.write_text(source)
  visibility=row['visibility'];child_visibility={'':'pub(super) ','pub(super) ':'pub(in super::super) '}.get(visibility,visibility)
  declaration=visibility+row['qualifiers']+'fn '+row['name'] if 'qualifiers' in row else visibility+'fn '+row['name']
  assert body.count(declaration)==1
  moved=body.replace(declaration,child_visibility+declaration[len(visibility):],1)
  target=root/row['target'];target.parent.mkdir(exist_ok=True);assert not target.exists()
  prelude='use super::*;\n'
  if row['name']=='render_plan_response':prelude+='use std::fmt::Write as _;\n'
  helper=prelude+'\n'+moved;target.write_text(helper)
  relative=target.relative_to(owner.parent).as_posix();module=row['child'];replacement='#[path = "'+relative+'"]\nmod '+module+';\n'+visibility+'use '+module+'::'+row['name']+';\n'
  changed=source[:row['start']]+replacement+source[row['end']:];owner.write_text(changed)
  assert changed.replace(replacement,body,1)==source
  assert helper[len(prelude)+1:].replace(child_visibility+declaration[len(visibility):],declaration,1)==body
  assert len(changed.splitlines())<=900 and len(helper.splitlines())<=900
  records.append({**row,'ownerLinesBefore':len(source.splitlines()),'ownerLinesAfter':len(changed.splitlines()),'helperLines':len(helper.splitlines()),'ownerExactInverseBeforeFormatting':True,'completeFunctionBodyAndCommentsUnchanged':True,'visibilityAncestorPreserved':True,'nativeExecutionVerified':False})
  files.extend([row['owner'],row['target']])
 (out/'conservation.json').write_text(json.dumps({'files':records,'independentAuthorshipCredit':0,'nativeExecutionVerified':False},indent=2)+'\n')
 owner=root/'rust/tests/web/issue-1580-template-observations.test.mjs';text=owner.read_text();(out/'maintained-owner-before.mjs').write_text(text);addition="import '../../../experiments/issue-1580/runtime-module-headroom.test.mjs';\n";assert addition not in text;owner.write_text(text+'\n'+addition)
 run('rustfmt',['rustfmt','--edition','2024',*files]);run('rustfmt-check',['rustfmt','--check','--edition','2024',*files])
 run('headroom-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)])
 run('projection-currency',['node','--max-old-space-size=256','scripts/translate-js-rust.mjs','--verify'])
 run('maintained-observations',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(owner)])
 run('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-abbreviations,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-changelog-fragment-js-twin,check-reconstructed-changelog'])
 run('source-warnings',['node','--max-old-space-size=256','scripts/check-file-size.mjs']);warnings=(out/'source-warnings.stdout').read_text().count('::warning file=');assert warnings==28,warnings
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'warnings':warnings,'extractedFunctions':len(records),'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
