from pathlib import Path
import hashlib,json,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'runtime-headroom-leaf-continuation';previous=scratch/'runtime-headroom-leaf-extraction'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':result.returncode}),flush=True);assert result.returncode==0,(name,result.returncode)
try:
 assert (previous/'failed.txt').exists()
 owner=root/'rust/src/agentic_coding/task_acceptance.rs';source=owner.read_text();(out/'formatted-task-acceptance-before.rs').write_text(source)
 start=source.index('/// The verdict lines a finished recipe');body=source[start:];assert body.endswith('\n}\n') and body.count('pub fn acceptance_report(')==1
 child=root/'rust/src/agentic_coding/task_acceptance/reports.rs';assert not child.exists();child.write_text('use super::*;\n\n'+body)
 replacement='#[path = "task_acceptance/reports.rs"]\nmod reports;\npub use reports::acceptance_report;\n';owner.write_text(source[:start]+replacement);assert owner.read_text().replace(replacement,body,1)==source
 test=root/'experiments/issue-1580/runtime-module-headroom.test.mjs';text=test.read_text();needle='for (const [owner,helper,name] of [';assert text.count(needle)==1;text=text.replace(needle,needle+'\n  ["rust/src/agentic_coding/task_acceptance.rs", "rust/src/agentic_coding/task_acceptance/reports.rs", "acceptance_report"],',1);test.write_text(text)
 (out/'additional-extraction.json').write_text(json.dumps({'owner':'rust/src/agentic_coding/task_acceptance.rs','helper':str(child.relative_to(root)),'name':'acceptance_report','bodySha256':hashlib.sha256(body.encode()).hexdigest(),'completeFunctionAndAttributesUnchanged':True,'ownerExactInverseBeforeFormatting':True,'reason':'rustfmt expanded existing long owner lines; extract complete report function to retain unchanged warning headroom','nativeExecutionVerified':False},indent=2)+'\n')
 files=[]
 for record in json.loads((previous/'conservation.json').read_text())['files']:files.extend([record['owner'],record['target']])
 files.append(str(child.relative_to(root)))
 run('rustfmt',['rustfmt','--edition','2024','--config','skip_children=true',str(owner),str(child)])
 run('rustfmt-check',['rustfmt','--check','--edition','2024','--config','skip_children=true',*files])
 run('headroom-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)])
 run('projection-currency',['node','--max-old-space-size=256','scripts/translate-js-rust.mjs','--verify'])
 run('maintained-observations',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])
 run('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-abbreviations,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-changelog-fragment-js-twin,check-reconstructed-changelog'])
 run('source-warnings',['node','--max-old-space-size=256','scripts/check-file-size.mjs']);warnings=(out/'source-warnings.stdout').read_text().count('::warning file=');assert warnings==28,warnings
 run('whitespace',['git','diff','--check']);result={'complete':True,'warnings':warnings,'extractedFunctions':15,'owners':14,'maintainedIssueTestsPassed':282,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
 assert 'ℹ pass 282' in (out/'maintained-observations.stdout').read_text()
 (out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');(previous/'outcome.json').write_text(json.dumps(result,indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
