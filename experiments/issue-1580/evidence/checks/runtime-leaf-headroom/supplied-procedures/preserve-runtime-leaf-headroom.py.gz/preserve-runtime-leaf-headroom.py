from pathlib import Path
import gzip,hashlib,json,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'runtime-leaf-headroom-preservation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 assert result.returncode==0,(name,result.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 final=json.loads((scratch/'runtime-headroom-witness-continuation/outcome.json').read_text());assert final['complete']
 ci=json.loads((scratch/'corrected-repair-round-hosted/outcome.json').read_text());assert ci['complete'] and ci['success']==30 and len(ci['failed'])==1
 target=root/'experiments/issue-1580/evidence/checks/runtime-leaf-headroom';target.mkdir(exist_ok=False);records=[]
 def archive(source,relative):
  raw=source.read_bytes();packed=gzip.compress(raw,mtime=0);dest=target/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed);records.append({'file':relative,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
 for name in ['runtime-headroom-leaf-extraction','runtime-headroom-leaf-continuation','runtime-headroom-witness-continuation']:
  directory=scratch/name
  for file in sorted(directory.rglob('*')):
   if file.is_file() and file.name!='pid.json':archive(file,name+'/'+str(file.relative_to(directory))+'.gz')
 helpers=['extract-runtime-headroom-leaves.py','finish-runtime-headroom-leaves.py','finish-runtime-headroom-witness.py','refresh-runtime-headroom-witness.mjs',Path(__file__).name]
 for name in helpers:archive(scratch/name,'supplied-procedures/'+name+'.gz')
 for file in sorted((root/'experiments/issue-1580/evidence/commands').glob('2026-11-21T17-*.json')):
  if any(name in json.loads(file.read_text())['request'] for name in helpers):archive(file,'formal-sessions/'+file.name+'.gz')
 for record in records:
  packed=(target/record['file']).read_bytes();raw=gzip.decompress(packed);assert hashlib.sha256(raw).hexdigest()==record['rawSha256'] and hashlib.sha256(packed).hexdigest()==record['archiveSha256'] and len(raw)==record['bytes'] and len(raw.splitlines())==record['lines']
 (target/'records.jsonl').write_text(''.join(json.dumps(record,separators=(',',':'))+'\n' for record in records));(target/'identity.json').write_text(json.dumps(final,indent=2)+'\n')
 doc=root/'docs/case-studies/issue-1580/runtime-leaf-headroom-checkpoint.md';doc.write_text('# Runtime module headroom and terminal native round\n\nFifteen complete functions, with their attributes and comments, move from\nfourteen large Rust owners into focused children. Exact inverses reconstruct\neach original owner before formatting; adjusted visibility reaches the same\nancestor. Source warnings fall from 42 to 28 under unchanged limits. Fifteen\nfocused checks, all 282 maintained issue checks, projection currency, native\nregistry currency, Rust formatting and six affected JavaScript gates pass.\n\nFormatting initially exhausted the task-acceptance owner headroom; moving its\ncomplete report function resolves that failure. The engine extraction also\ninvalidated its generated native registry witness. Official regeneration and a\nguarded whole-object baseline refresh retain all 1,189 original identities and\n221 carried programs. Only the reviewed engine hashes and unchanged constant\nspan differ. All initial failures are retained. Native execution of this batch\nis still unverified, including the separately compiled source-test copies.\n\nThe preceding published head ba01ef99 now has 32 terminal workflows: 30\nsucceeded, one skipped and Layered CI rejected the previously repaired stale\nsource witness. All nine native pipeline families passed for that published\nhead. Those results do not qualify these later local changes.\n\nEvidence: `experiments/issue-1580/evidence/checks/runtime-leaf-headroom/` and\n`experiments/issue-1580/evidence/ci/corrected-repair-round-ba01ef99/`.\nSupplied procedures receive zero independent authorship credit. Wider issue\nacceptance remains unfinished: https://github.com/link-assistant/formal-ai/pull/1581.\n')
 fragment=root/'changelog.d/20261121_1580_runtime_leaf_headroom.md';fragment.write_text('### Changed\n\n- Extract complete runtime and source-test functions into focused modules, retaining comments, visibility and all carried specification cases while reducing source-size warnings.\n')
 plan=root/'experiments/issue-1580/work-plan.md';text=plan.read_text();start=text.index('Published `ba01ef99` includes main');end=text.index('\nThe entries below',start);text=text[:start]+'''Published `ba01ef99` includes main `f574289f`; all 32 workflows are terminal:
30 succeeded, one skipped and Layered CI rejected stale governed source hashes.
All nine native pipeline families passed for that published source. The witness
failure is repaired locally; all 1,189 identities and 221 carried programs remain.
The latest local replay passes 282 tests, registry/projection currency, formatting
and affected JavaScript gates. Complete function, implementation, shell and
metadata extractions reduce source warnings to 28 under unchanged limits.
No native compilation or execution of these later local changes is claimed.

The complete template/practice comparison, remaining warnings, wider verification
and final current-head CI remain open. Independent reasoning remains 0/20.
PR #1581 remains draft and unmerged.
'''+text[end:];plan.write_text(text)
 selected=json.loads((scratch/'runtime-headroom-leaf-extraction/conservation.json').read_text())['files'];paths=[]
 for row in selected:paths.extend([row['owner'],row['target']])
 paths+=['rust/src/agentic_coding/task_acceptance/reports.rs','experiments/issue-1580/runtime-module-headroom.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs','scripts/lib/generated-native-programs.mjs','experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8',str(target.relative_to(root)),str(doc.relative_to(root)),str(fragment.relative_to(root)),str(plan.relative_to(root)),'experiments/issue-1580/evidence/ci/corrected-repair-round-ba01ef99']
 assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
 assert not run('staged-before',['git','diff','--cached','--name-only']).strip()
 run('stage',['git','add','--',*paths]);run('staged-whitespace',['git','diff','--cached','--check']);run('staged-secrets',['bash','scripts/check-secrets.sh']);run('commit',['git','commit','-m','Extract runtime leaves and conserve generated native coverage'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'head':run('head',['git','rev-parse','HEAD']).strip(),'archives':len(records),'pushed':False,'fullIssueComplete':False},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
