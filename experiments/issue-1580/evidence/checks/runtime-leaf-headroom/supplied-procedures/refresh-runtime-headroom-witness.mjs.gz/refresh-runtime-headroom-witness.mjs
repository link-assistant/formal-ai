// Supplied exact-delta review procedure; zero independent authorship credit.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {serialize,deserialize} from 'node:v8';
import {resolve,relative,isAbsolute} from 'node:path';
import {specificationCases} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/rust-specification-cases.mjs';
const root='/tmp/gh-issue-solver-1794900398048',out='/tmp/issue-1580-research/runtime-headroom-witness-continuation';
const hash=x=>createHash('sha256').update(x).digest('hex');
const file=root+'/experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8';
const raw=readFileSync(file),previous=deserialize(raw);assert.equal(hash(raw),'cda3dafe84ac80aeda7891bc8c58c58fb8bc818afd8ee8d4e408a837251d41a2');
const reader=root+'/scripts/lib/rust-specification-cases.mjs',readerHash=hash(readFileSync(reader));assert.equal(readerHash,'861c6c5b40cfc8f4e99ad0ebece2cc3c20f941c6a1103dd5e8e70813c40ee0ca');
const inventory=specificationCases(root);
for(const item of inventory.cases)for(const fixture of item.program?.fixtures??[])if(isAbsolute(fixture.file))fixture.file='repo:'+relative(root,fixture.file);
const manifest=readdirSync(root+'/rust/tests/unit/specification',{recursive:true}).map(String).filter(x=>x.endsWith('.rs')).sort().map(x=>({path:'rust/tests/unit/specification/'+x,sha256:hash(readFileSync(root+'/rust/tests/unit/specification/'+x))}));
const current={inventory,sourceManifest:manifest};assert.equal(inventory.total,1189);assert.equal(inventory.cases.length,221);assert.equal(inventory.unsupported.length,968);
assert.deepEqual(inventory.cases.map(x=>x.id),previous.inventory.cases.map(x=>x.id));
const expected=deserialize(serialize(previous));const oldHash='e32c9fd2c973c17fbb05b26438e7ad1506cf51783812c82114196d58fde48e38',newHash=hash(readFileSync(root+'/rust/src/engine.rs'));
assert.notEqual(oldHash,newHash);let replacements=0;
function refresh(value){
 if(!value||typeof value!=='object')return;
 if((value.file==='repo:rust/src/engine.rs'||value.path==='rust/src/engine.rs')&&value.sha256===oldHash){value.sha256=newHash;replacements++;}
 if(value.canonicalPath==='formal_ai::engine::DEFAULT_MODEL'){
  const actual=inventory.cases.find(x=>x.id.endsWith('::canonical_model_id_is_formal_ai')).program.steps[0].left.binding;
  assert.equal(value.value,actual.value);assert.equal(value.maintainedTranslationSha256,actual.maintainedTranslationSha256);value.sourceSpan=actual.sourceSpan;
 }
 for(const child of Object.values(value))if(Array.isArray(child))child.forEach(refresh);else refresh(child);
}
refresh(expected);assert.equal(replacements,2);assert.deepEqual(current,expected,'only reviewed engine source hashes and the unchanged constant declaration span may change');
writeFileSync(out+'/previous.v8',raw);writeFileSync(out+'/review.json',JSON.stringify({previousWitnessSha256:hash(raw),readerSha256:readerHash,oldEngineSha256:oldHash,newEngineSha256:newHash,replacements,total:1189,carried:221,unsupported:968,completeObjectDeltaReviewed:true,nativeExecutionVerified:false},null,2)+'\n');
const args=['--max-old-space-size=256','rust/tests/web/rust-specification-unicode-identifiers.test.mjs','--refresh-reviewed-baseline','--reviewed-reader-sha='+readerHash,'--previous-baseline-sha='+hash(raw)];
writeFileSync(out+'/refresh.stdout',execFileSync(process.execPath,args,{cwd:root,maxBuffer:1024*1024}));assert.deepEqual(deserialize(readFileSync(file)),expected);
console.log('Retained all 1189 identities and 221 carried programs; only two engine source hashes and the unchanged constant span differ.');
