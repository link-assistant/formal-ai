from pathlib import Path
p=Path('experiments/issue-1580/worker-receipt-regeneration.test.mjs');text=p.read_text()
marker="test('worker manifest preserves only actual compiler dependencies while the receipt binds metadata',()=>{"
head,tail=text.split(marker)
assert r'\\n' in tail
tail=tail.replace(r'\\n',r'\n');p.write_text(head+marker+tail)
print('Corrected fixture newline encoding; production code unchanged')
