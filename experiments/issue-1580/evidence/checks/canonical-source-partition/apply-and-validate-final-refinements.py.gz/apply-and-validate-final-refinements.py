from pathlib import Path
import subprocess,os,time,json,sys
out=Path('/tmp/issue-1580-research/final-ci-refinements');out.mkdir(exist_ok=True)
if '--worker' not in sys.argv:
 for helper in ['refine-worker-manifest-closure.py','fix-final-source-readability.py']:
  subprocess.run([sys.executable,'/tmp/issue-1580-research/'+helper],check=True)
 with (out/'worker.log').open('w') as log:
  p=subprocess.Popen([sys.executable,__file__,'--worker'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid}),flush=True);sys.exit(0)
env={**os.environ};env.pop('NODE_OPTIONS',None);rows=[]
commands=[('worker-receipt',['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/worker-receipt-regeneration.test.mjs']),('production-profile',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs']),('canonical-source',['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/canonical-release-source.test.mjs']),('readability-gate',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-readable-code']),('projection',['node','--max-old-space-size=256','scripts/generate-staged-release.mjs','--check-deployed']),('whitespace',['git','diff','--check'])]
for name,command in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 row={'stage':name,'command':command,'returncode':r.returncode,'seconds':round(time.monotonic()-start,3)};rows.append(row)
 print(json.dumps(row),flush=True);(out/'partial.json').write_text(json.dumps(rows,indent=2)+'\n')
(out/'outcome.json').write_text(json.dumps(rows,indent=2)+'\n')
