from pathlib import Path
p=Path('scripts/staged-caller-authority.mjs');text=p.read_text()
old="""    retained.push(
      ...(retainedSourceProof.physicalSourceFiles === undefined ? [{path:prefix+'original-release-workflow.yml',sha256:sha(canonical)}] : (()=>{assert.equal(assembleCanonicalSource(retainedSourceProof.physicalSourceFiles),canonical);return retainedSourceProof.physicalSourceFiles.map(({path,text})=>({path,sha256:sha(text)}));})()),
"""
new="""    const physicalFiles = retainedSourceProof.physicalSourceFiles;
    let physicalDigests;
    if (physicalFiles === undefined) {
      physicalDigests = [{path:prefix+'original-release-workflow.yml',sha256:sha(canonical)}];
    } else {
      assert.equal(assembleCanonicalSource(physicalFiles),canonical);
      physicalDigests = physicalFiles.map(({path,text})=>({path,sha256:sha(text)}));
    }
    retained.push(
      ...physicalDigests,
"""
assert text.count(old)==1;text=text.replace(old,new);p.write_text(text)
p=Path('rust/tests/web/release-workflow-scope-controls.test.mjs')
text=p.read_text();text=text.replace('all five outputs','all seven outputs');p.write_text(text)
print('Split source authentication expression without changing receipt semantics')
