from pathlib import Path
import subprocess,json,gzip,hashlib
prefix='experiments/formal_ai_subagent/evidence/specification-delivery-1188/dormant-staged-release/'
canonical=prefix+'original-release-workflow.yml'
out=Path('/tmp/issue-1580-research/canonical-source-partition');out.mkdir(exist_ok=True)
raw=Path(canonical).read_bytes();(out/'original-source.yml.gz').write_bytes(gzip.compress(raw,mtime=0))
print(json.dumps({'beforeBytes':len(raw),'beforeLines':len(raw.splitlines()),'sha256':hashlib.sha256(raw).hexdigest()}),flush=True)
assert len(raw.splitlines())>1000
Path('scripts/canonical-release-source.mjs').write_bytes(Path('/tmp/issue-1580-research/canonical-release-source.mjs').read_bytes())
def edit(name,changes):
 p=Path(name);s=p.read_text();(out/(name.replace('/','--')+'.before.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
 for a,b in changes:
  assert a in s,(name,a);s=s.replace(a,b)
 p.write_text(s)
def imp(name,names="readCanonicalSource"):
 p=Path(name);p.write_text("import {"+names+"} from './canonical-release-source.mjs';\n"+p.read_text())
edit('scripts/generate-staged-release.mjs',[
 ("const source = readFileSync(join(root, deployed ? evidence + 'original-release-workflow.yml' : '.github/workflows/release.yml'), 'utf8');","const retained=readCanonicalSource(root);\n  const source = deployed ? retained.text : readFileSync(join(root,'.github/workflows/release.yml'),'utf8');"),
 ("assert.equal(readFileSync(join(root, evidence, 'original-release-workflow.yml'), 'utf8'), source);","assert.equal(readCanonicalSource(root).text, source);"),
 ("[evidence + 'original-release-workflow.yml', source],","...partitionCanonicalSource(source).map(({path,text})=>[path,text]),")])
imp('scripts/generate-staged-release.mjs','readCanonicalSource,partitionCanonicalSource')
edit('scripts/checked-release-operation-view.mjs',[
 ("const retained=fs.readFileSync(path.join(root,evidence,'original-release-workflow.yml'),'utf8');","const canonicalSource=readCanonicalSource(root),retained=canonicalSource.text;"),
 ("assert.equal(fs.readFileSync(path.join(root,evidence,'original-release-workflow.yml'),'utf8'),retained);","assert.deepEqual(readCanonicalSource(root),canonicalSource);"),
 ])
imp('scripts/checked-release-operation-view.mjs')
edit('scripts/self-authored-publication-source.mjs',[
 ("const canonical = readFileSync(join(cwd, evidence, 'original-release-workflow.yml'), 'utf8');","const canonicalSource=readCanonicalSource(cwd),canonical=canonicalSource.text;"),
 ("originalSource: canonical, packetSource","originalSource: canonical, physicalSourceFiles:canonicalSource.files, packetSource")])
imp('scripts/self-authored-publication-source.mjs')
edit('scripts/staged-caller-authority.mjs',[
 ("assert.deepEqual(Object.keys(retainedSourceProof).sort(), ['originalSource', 'packetSource']);","assert.deepEqual(Object.keys(retainedSourceProof).sort(), retainedSourceProof.physicalSourceFiles === undefined ? ['originalSource','packetSource'] : ['originalSource','packetSource','physicalSourceFiles']);"),
 ("{path: prefix + 'original-release-workflow.yml', sha256: sha(canonical)},","...(retainedSourceProof.physicalSourceFiles === undefined ? [{path:prefix+'original-release-workflow.yml',sha256:sha(canonical)}] : (()=>{assert.equal(assembleCanonicalSource(retainedSourceProof.physicalSourceFiles),canonical);return retainedSourceProof.physicalSourceFiles.map(({path,text})=>({path,sha256:sha(text)}));})()),"),
 ("contract.sources.length===4?8:3","contract.sources.length===2?3:8")])
imp('scripts/staged-caller-authority.mjs','assembleCanonicalSource')
edit('scripts/governed-github-command-provider.mjs',[
 ("sourcePaths.length===2 || sourcePaths.length===4","sourcePaths.length===2 || sourcePaths.length===4 || sourcePaths.length===6"),
 ("if(sourcePaths.length===4)assert.deepEqual(sourcePaths.filter(file=>!workflows.includes(file)).sort(),[retained+'original-release-workflow.yml',retained+'stage-source-coverage.json'].sort());","if(sourcePaths.length!==2)assert.deepEqual(sourcePaths.filter(file=>!workflows.includes(file)).sort(),[...(sourcePaths.length===6?CANONICAL_FILES:[CANONICAL_SOURCE]),retained+'stage-source-coverage.json'].sort());"),
 ("maximumRequests:sourcePaths.length===4?17:12,requiredRequests:sourcePaths.length===4?17:10","maximumRequests:sourcePaths.length===2?12:13+sourcePaths.length,requiredRequests:sourcePaths.length===2?10:13+sourcePaths.length")])
imp('scripts/governed-github-command-provider.mjs','CANONICAL_FILES,CANONICAL_SOURCE')
edit('scripts/maintained-staged-authority.mjs',[
 ("const paths={canonical:evidence+'original-release-workflow.yml',deployedCaller", "const canonicalSource=readCanonicalSource(root);\n  const paths={canonical:evidence+'original-release-workflow.yml',canonicalReader:'scripts/canonical-release-source.mjs',...Object.fromEntries(canonicalSource.files.slice(1).map((file,n)=>['canonicalPart'+n,file.path])),deployedCaller"),
 ("buildStagedReleaseProjection(bytes.canonical,packet)","buildStagedReleaseProjection(canonicalSource.text,packet)"),
 ("canonical:bytes.canonical,callerDraft:bytes.callerDraft,staged:bytes.staged,packet,YAML,retainedSourceProof:{originalSource:bytes.canonical,packetSource:bytes.packet}","canonical:canonicalSource.text,callerDraft:bytes.callerDraft,staged:bytes.staged,packet,YAML,retainedSourceProof:{originalSource:canonicalSource.text,physicalSourceFiles:canonicalSource.files,packetSource:bytes.packet}")])
imp('scripts/maintained-staged-authority.mjs')
edit('experiments/issue-1580/refresh-staged-caller.mjs',[("const original = read(prefix + 'original-release-workflow.yml');","const original = readCanonicalSource(process.cwd()).text;")])
p=Path('experiments/issue-1580/refresh-staged-caller.mjs');p.write_text("import {readCanonicalSource} from '../../scripts/canonical-release-source.mjs';\n"+p.read_text())
edit('scripts/ci-pull-request-admission.mjs',[("const NATIVE_REGRESSION_INPUTS = new Set([","const NATIVE_REGRESSION_INPUTS = new Set([\n  'scripts/canonical-release-source.mjs',\n  ...CANONICAL_PARTS,")])
imp('scripts/ci-pull-request-admission.mjs','CANONICAL_PARTS')
p=Path('.github/workflows/native-type-check.yml');s=p.read_text();needle='            /'+canonical+'\n';assert s.count(needle)==6;s=s.replace(needle,needle+''.join('            /'+prefix+f'original-release-workflow.part-{n}.txt\n' for n in [1,2]));p.write_text(s)
subprocess.run(['node','--input-type=module','-e',"import {readFileSync,writeFileSync} from 'node:fs';import {partitionCanonicalSource,CANONICAL_SOURCE} from './scripts/canonical-release-source.mjs';for(const {path,text} of partitionCanonicalSource(readFileSync(CANONICAL_SOURCE,'utf8')))writeFileSync(path,text);"],check=True)
print('live source partition drafted; tests not yet adapted',flush=True)
