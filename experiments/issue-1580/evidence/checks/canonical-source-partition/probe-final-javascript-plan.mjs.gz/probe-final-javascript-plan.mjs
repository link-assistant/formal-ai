import {readFileSync,readdirSync} from 'node:fs';
import {readTestDurations} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/ci-speed-durations.mjs';
import {durationLookup,planShards} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/ci-speed-shards.mjs';
const text=readFileSync('data/meta/javascript-test-durations.lino','utf8');
const seconds=durationLookup(readTestDurations('data/meta/javascript-test-durations.lino'),Number(text.match(/^  default-seconds (\S+)$/mu)[1]));
const items=readdirSync('rust/tests/web').filter(n=>n.endsWith('.test.mjs')).map(n=>'rust/tests/web/'+n);
const plan=planShards(items,8,seconds);
console.log(JSON.stringify({count:items.length,groups:plan.shards.map((shard,i)=>({group:i+1,total:plan.load[i],workers:planShards(shard,4,seconds).load,largest:shard.slice(0,8).map(path=>({path,seconds:seconds(path)}))}))},null,2));
console.log(readFileSync('experiments/issue-1580/hosted-javascript-scheduling.test.mjs','utf8'));
