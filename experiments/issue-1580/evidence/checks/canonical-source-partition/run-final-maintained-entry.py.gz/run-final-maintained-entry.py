from pathlib import Path
import subprocess,os,json,sys,time
out=Path('/tmp/issue-1580-research/final-maintained-entry');out.mkdir(exist_ok=True)
if '--worker' not in sys.argv:
 with (out/'worker.log').open('w') as log:p=subprocess.Popen([sys.executable,__file__,'--worker'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid}));sys.exit(0)
command=['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'];env={**os.environ};env.pop('NODE_OPTIONS',None);start=time.monotonic()
with (out/'maintained-entry.log').open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
result={'command':command,'returncode':r.returncode,'seconds':round(time.monotonic()-start,3)};(out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
