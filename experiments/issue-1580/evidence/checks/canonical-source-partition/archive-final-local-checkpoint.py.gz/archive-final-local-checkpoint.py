from pathlib import Path
import gzip,json,hashlib,re
root=Path.cwd();scratch=Path('/tmp/issue-1580-research');out=root/'experiments/issue-1580/evidence/checks/canonical-source-partition'
result=json.loads((scratch/'final-maintained-entry/outcome.json').read_text());assert result['returncode']==0
log=(scratch/'final-maintained-entry/maintained-entry.log').read_text();assert re.search(r'tests 331\b',log) and re.search(r'pass 331\b',log) and re.search(r'fail 0\b',log)
focused=json.loads((scratch/'final-ci-refinements/outcome.json').read_text());assert all(r['returncode']==0 for r in focused if r['stage']!='worker-receipt')
worker=(scratch/'final-worker-regression-driver.log').read_text();assert 'pass 4' in worker and 'fail 0' in worker and 'Exit Code: 0' in worker
for directory in ['complete-ci-batch-checks','final-ci-refinements','final-maintained-entry']:
 for p in (scratch/directory).iterdir():
  if p.is_file():(out/(directory+'--'+p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for name in ['final-worker-regression-driver.log','refine-worker-manifest-closure.py','fix-worker-regression-newlines.py','fix-final-source-readability.py','apply-and-validate-final-refinements.py','run-final-maintained-entry.py','archive-final-local-checkpoint.py']:
 p=scratch/name;(out/(name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
gates=(scratch/'complete-ci-batch-checks/all-javascript-gates.log').read_text().splitlines();counts={tag:sum(line.startswith(tag+' ') for line in gates) for tag in ['PASS','FAIL','SKIP']};assert counts=={'PASS':87,'FAIL':1,'SKIP':53},counts
note='''
Final local checkpoint (2026-11-21): the complete 141-entry local inventory
recorded 87 passes, 53 explicit hosted-only exclusions and one readability
failure. Splitting the new 303-character expression fixed that failure; the
unchanged readability gate then passed. The combined result is 88 applicable
passes and 53 exclusions, not 141 locally executed checks. Both file-size
JavaScript gates pass with their unchanged limits. No warning exemption was added.

The separate production-profile run first encountered a 100 ms VM execution
timeout. Its isolated unchanged retry passed all 21 cases. The new worker receipt
fixture then caught a double-escaped newline in its supplied draft; correcting
only that fixture made all four worker cases pass. The final maintained entry
passes all 331 cases. Both initial failures and corrected results are archived.
The source projection check and whitespace check pass. Hosted native execution,
worker regeneration and actual new-head wall times remain pending.
'''
p=root/'docs/case-studies/issue-1580/canonical-release-source.md';text=p.read_text();text=text.replace('\nPull request:',note+'\nPull request:');p.write_text(text)
p=root/'docs/case-studies/issue-1580/hosted-worker-regeneration.md';text=p.read_text();text=text.replace('\nPull request:','\nAll four focused JavaScript cases and the 331-case maintained entry pass locally.\nThese are admission and manifest regressions, not evidence of hosted compilation.\n\nPull request:');p.write_text(text)
p=root/'experiments/issue-1580/work-plan.md';text=p.read_text();text+='''

### 2026-11-21: final canonical-source and worker-bootstrap local checkpoint

- Preserve the actual 81,026-byte canonical release input as a strict index and
  two authenticated parts; generated workflows/packet remain byte-identical,
  retaining all 52 operations and 104 bindings. Publication hashes all six actual
  physical sources. Legacy one-file layouts still pass the maintained paths.
- Complete local inventory: 87 initial passes, 53 hosted-only exclusions and one
  new readability failure; the corrected unchanged gate passes. Effective result
  is 88 applicable passes, 53 explicit exclusions. Preserve the initial failure.
- Final maintained regression entry: 331/331 pass. The production-profile suite
  passes 21/21 on isolated retry after a retained 100 ms VM timeout. Worker receipt
  admission and compiler-input separation pass 4/4 after a retained fixture escape
  correction. No timeout, threshold, inventory or production assertion relaxed.
- Activate the explicit read-only hosted worker regeneration exception, under the
  user's standing authorization to repair CI. Push the complete source batch to
  bootstrap the job, dispatch it, verify its actual artifact, then collect every
  actionable terminal failure before the following push. Stale worker remains an
  open hosted failure until its real regeneration passes unchanged checks.
- Evidence: `evidence/checks/canonical-source-partition/`; case studies explain
  exact source conservation, the historical-weight model and worker bootstrap.
  Supplied procedures earn zero independent authorship or reasoning credit.
- Issue-wide template/practice comparison, original failure reconciliation,
  current hosted verification and independent-authorship floor remain unfinished.

Pull request: https://github.com/link-assistant/formal-ai/pull/1581.
''';p.write_text(text)
files=[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.iterdir()) if p.is_file() and p.name!='manifest.json']
(out/'manifest.json').write_text(json.dumps({'schema':'issue-1580-canonical-partition-evidence/v1','files':files},indent=2)+'\n')
print(json.dumps({'archiveFiles':len(files),'maintainedPass':331,'localGates':counts,'readabilityCorrected':True,'nativeHostedPending':True}))
