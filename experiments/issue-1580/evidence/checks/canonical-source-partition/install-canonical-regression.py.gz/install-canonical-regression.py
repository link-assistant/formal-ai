from pathlib import Path
import shutil
Path('scripts/canonical-release-source.mjs').write_bytes(Path('/tmp/issue-1580-research/canonical-release-source.mjs').read_bytes())
Path('experiments/issue-1580/canonical-release-source.test.mjs').write_bytes(Path('/tmp/issue-1580-research/canonical-release-source.test.mjs').read_bytes())
p=Path('experiments/issue-1580/fixtures/canonical-release-source');p.mkdir(exist_ok=True)
shutil.copyfile('/tmp/issue-1580-research/canonical-source-partition/original-source.yml.gz',p/'original-source.yml.gz')
p=Path('rust/tests/web/issue-1580-template-observations.test.mjs');p.write_text(p.read_text()+"import '../../../experiments/issue-1580/canonical-release-source.test.mjs';\n")
print('four focused canonical source regressions installed',flush=True)
