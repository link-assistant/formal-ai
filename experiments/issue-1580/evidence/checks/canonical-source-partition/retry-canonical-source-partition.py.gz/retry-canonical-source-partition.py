from pathlib import Path
import gzip,runpy
out=Path('/tmp/issue-1580-research/canonical-source-partition')
for name in ['scripts/generate-staged-release.mjs','scripts/checked-release-operation-view.mjs']:
 Path(name).write_bytes(gzip.decompress((out/(name.replace('/','--')+'.before.gz')).read_bytes()))
runpy.run_path('/tmp/issue-1580-research/draft-canonical-source-partition.py')
