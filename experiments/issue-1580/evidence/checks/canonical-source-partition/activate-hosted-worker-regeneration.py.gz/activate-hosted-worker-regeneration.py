from pathlib import Path
import shutil,gzip
proposal=Path('experiments/issue-1580/proposals/hosted-wasm-regeneration')
out=Path('/tmp/issue-1580-research/hosted-worker-activation');out.mkdir(exist_ok=True)
for p in proposal.iterdir():
 if p.is_file():(out/(p.name+'.proposal.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
s=(proposal/'regenerate.mjs').read_text().replace('// Inactive proposal: invoke only after approval of the documented policy exception.','// Explicit hosted maintenance: compile the selected browser worker and preserve actual receipts.')
s=s.replace("'../../../../scripts/build-selected-wasm.mjs'","'./build-selected-wasm.mjs'").replace("'../../../../scripts/wasm-worker-inputs.mjs'","'./wasm-worker-inputs.mjs'")
s=s.replace("new URL('../../../../',import.meta.url)","new URL('../',import.meta.url)")
s=s.replace("  assert.equal(environment.GITHUB_REPOSITORY,'link-assistant/formal-ai');", "  assert.equal(environment.GITHUB_REPOSITORY,'link-assistant/formal-ai');\n  for(const key of ['GITHUB_RUN_ID','GITHUB_RUN_ATTEMPT'])assert.match(environment[key]??'',/^[1-9][0-9]*$/u,'actual workflow identity required');")
Path('scripts/regenerate-worker-receipt.mjs').write_text(s)
job=(proposal/'job.yml').read_text().split('regenerate-worker-receipt:',1)[1]
job='  regenerate-worker-receipt:'+''.join('  '+line+'\n' for line in job.splitlines())[2:]
job=job.replace('experiments/issue-1580/proposals/hosted-wasm-regeneration/regenerate.mjs','scripts/regenerate-worker-receipt.mjs')
job=job.replace('    permissions:\n',"    concurrency:\n      group: source-worker-receipt-${{ github.ref }}\n      cancel-in-progress: false\n    env:\n      CARGO_BUILD_JOBS: '2'\n      CARGO_INCREMENTAL: '0'\n    permissions:\n",1)
job=job.replace('run: node --max-old-space-size=256 scripts/regenerate-worker-receipt.mjs','run: bash scripts/run-with-budget-warning.sh 420 "Explicit worker receipt regeneration" node --max-old-space-size=256 scripts/regenerate-worker-receipt.mjs')
p=Path('.github/workflows/layered-ci.yml');s=p.read_text();(out/'layered-ci.before.yml.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0))
s=s.replace("description: 'checks: normal checks; regenerate-translations: explicit source-only repair'", "description: 'checks: normal checks; regenerate-translations: explicit source or worker receipt repair'")
s=s.replace('options: [translations, specification-witness, debug-owner-baseline, module-projection]','options: [translations, specification-witness, debug-owner-baseline, module-projection, worker-receipt]')
needle="    if: ${{ github.event_name == 'workflow_dispatch' && inputs.mode == 'regenerate-translations' }}";assert s.count(needle)==1
s=s.replace(needle,"    if: ${{ github.event_name == 'workflow_dispatch' && inputs.mode == 'regenerate-translations' && inputs.regeneration-target != 'worker-receipt' }}")
s=s.replace('\n  changes:\n','\n'+job+'\n  changes:\n',1);p.write_text(s)
p=Path('docs/ci-cd/default-branch-builds.md');s=p.read_text();s=s.replace('  never compile Cargo packages, Docker images, WASM or applications, and never\n  deploy Pages.', '  never compile production Cargo packages, Docker images, WASM or applications,\n  and never deploy Pages, except for the explicit focused maintenance exceptions below.')
needle='- Production builds run on the current default branch, main.';assert needle in s
s=s.replace(needle,'''- An explicit `workflow_dispatch` on Layered CI with
  `mode=regenerate-translations` and `regeneration-target=worker-receipt` may
  regenerate the selected browser worker and its actual compiler/input receipts
  on a feature branch (#1580). This maintenance exception implements
  CONTRIBUTING.md's hosted WASM regeneration requirement. It verifies the exact
  dispatched commit, repository, run and attempt, retains the generated worker,
  selected-source receipt and input manifest for one day, and grants no release
  authority. It has read-only contents, no persisted checkout credentials, no
  cache writes and no publication or deployment. Ordinary pushes, PRs and check
  dispatches never select this job. The source-only regeneration job excludes
  this target so it cannot substitute a source projection for compiled output.
'''+needle,1);p.write_text(s)
s=(proposal/'admission.test.mjs').read_text().replace("from './regenerate.mjs'","from '../../scripts/regenerate-worker-receipt.mjs'")
s=s.replace("GITHUB_REPOSITORY:'link-assistant/formal-ai'","GITHUB_REPOSITORY:'link-assistant/formal-ai',GITHUB_RUN_ID:'123',GITHUB_RUN_ATTEMPT:'1'")
s=s.replace("['GITHUB_REPOSITORY','someone/fork']", "['GITHUB_REPOSITORY','someone/fork'],['GITHUB_RUN_ID',''],['GITHUB_RUN_ATTEMPT','0']")
s=s.replace("test('proposed job selects only the explicit regeneration target'", "test('hosted worker job selects only the explicit regeneration target'")
s=s.replace("YAML.parse(readFileSync(new URL('./job.yml',import.meta.url),'utf8'))['regenerate-worker-receipt']", "YAML.parse(readFileSync(new URL('../../.github/workflows/layered-ci.yml',import.meta.url),'utf8')).jobs['regenerate-worker-receipt']")
s=s.replace("assert.equal(job.steps.find(step=>step.run).env.FORMAL_AI_REGENERATION_TARGET,'worker-receipt');", "assert.equal(job.steps.find(step=>step.run).env.FORMAL_AI_REGENERATION_TARGET,'worker-receipt');\n  assert.equal(job['timeout-minutes'],10);\n  assert.equal(job.steps.find(step=>step.run).run,'bash scripts/run-with-budget-warning.sh 420 \\\"Explicit worker receipt regeneration\\\" node --max-old-space-size=256 scripts/regenerate-worker-receipt.mjs');")
Path('experiments/issue-1580/worker-receipt-regeneration.test.mjs').write_text(s)
p=Path('rust/tests/web/issue-1580-template-observations.test.mjs');p.write_text(p.read_text()+"import '../../../experiments/issue-1580/worker-receipt-regeneration.test.mjs';\n")
Path('changelog.d/20261121_1580_worker_receipt.md').write_text('Allow explicit hosted browser worker receipt regeneration, verifying the actual dispatched source and compiler output before preserving the worker and input manifest. Ordinary pull request checks retain their build restrictions.\n')
shutil.rmtree(proposal)
print('explicit hosted regeneration activated under the issue repair authorization; no compiler invoked locally',flush=True)
