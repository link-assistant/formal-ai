from pathlib import Path
prefix='experiments/formal_ai_subagent/evidence/specification-delivery-1188/dormant-staged-release/'
p=Path('scripts/ci-pull-request-admission.mjs');s=p.read_text();s=s.replace("import {CANONICAL_PARTS} from './canonical-release-source.mjs';\n",'');s=s.replace('  ...CANONICAL_PARTS,', ''.join("  '"+prefix+f"original-release-workflow.part-{n}.txt',\n" for n in [1,2]).rstrip());p.write_text(s)
p=Path('scripts/generate-staged-release.mjs');s=p.read_text();s=s.replace('buildStagedReleaseProjection(source,packet);','buildStagedReleaseProjection(source,packet,{partitioned:retained.files.length===3});',1)
needle='export function buildStagedReleaseProjection(source, packet)'
if needle not in s:needle='export function buildStagedReleaseProjection(source,packet)'
assert needle in s;s=s.replace(needle,needle[:-1]+', {partitioned=true}={})',1)
s=s.replace('...partitionCanonicalSource(source).map(({path,text})=>[path,text])',"...(partitioned?partitionCanonicalSource(source):[{path:evidence+'original-release-workflow.yml',text:source}]).map(({path,text})=>[path,text])")
p.write_text(s)
for name in ['scripts/checked-release-operation-view.mjs','scripts/maintained-staged-authority.mjs']:
 p=Path(name);s=p.read_text();s=s.replace('buildStagedReleaseProjection(retained,packet);','buildStagedReleaseProjection(retained,packet,{partitioned:canonicalSource.files.length===3});');s=s.replace('buildStagedReleaseProjection(canonicalSource.text,packet);','buildStagedReleaseProjection(canonicalSource.text,packet,{partitioned:canonicalSource.files.length===3});');p.write_text(s)
for name in ['scripts/maintained-staged-authority.mjs','scripts/generate-staged-release.mjs','experiments/issue-1580/verify-pages-migration.mjs']:
 print('FILE '+name,flush=True)
 lines=Path(name).read_text().splitlines()
 for n,l in enumerate(lines[:60],1):print(f'{n}: {l}',flush=True)
print('admission keeps its original sparse dependency closure; legacy physical fixtures retain their source layout',flush=True)
