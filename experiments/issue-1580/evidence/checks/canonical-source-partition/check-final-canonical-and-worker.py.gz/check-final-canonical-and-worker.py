from pathlib import Path
import subprocess,os,time,json,sys
out=Path('/tmp/issue-1580-research/final-canonical-and-worker');out.mkdir(exist_ok=True)
if '--worker' not in sys.argv:
 with (out/'worker.log').open('w') as log:p=subprocess.Popen([sys.executable,__file__,'--worker'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid}),flush=True);sys.exit(0)
files=['experiments/issue-1580/worker-receipt-regeneration.test.mjs','rust/tests/web/fast-pull-request-production-profile.test.mjs','rust/tests/web/maintained-staged-authority.test.mjs','rust/tests/web/staged-release-activation-transition.test.mjs','rust/tests/web/native-staged-release-operation-view.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs']
env={**os.environ};env.pop('NODE_OPTIONS',None);records=[]
for file in files:
 name=Path(file).stem;start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(['node','--max-old-space-size=256','--test','--test-concurrency=1',file],stdout=log,stderr=subprocess.STDOUT,env=env)
 row={'stage':name,'returncode':r.returncode,'seconds':round(time.monotonic()-start,3)};records.append(row);print(json.dumps(row),flush=True)
 (out/'partial.json').write_text(json.dumps(records,indent=2)+'\n')
(out/'outcome.json').write_text(json.dumps(records,indent=2)+'\n')
