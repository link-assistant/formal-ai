from pathlib import Path
p=Path('scripts/maintained-staged-authority.mjs');s=p.read_text();old='  const paths = {\n    canonical:';assert old in s;s=s.replace(old,"  const canonicalSource=readCanonicalSource(root);\n  const paths = {\n    canonicalReader:'scripts/canonical-release-source.mjs',\n    ...Object.fromEntries(canonicalSource.files.map((file,n)=>['retainedSource'+n,file.path])),\n    canonical:",1);p.write_text(s)
p=Path('experiments/issue-1580/verify-pages-migration.mjs');s=p.read_text();s="import {readCanonicalSource,CANONICAL_SOURCE} from '../../scripts/canonical-release-source.mjs';\n"+s;s=s.replace("const current=file=>readFileSync(root+file,'utf8');","const current=file=>file===CANONICAL_SOURCE?readCanonicalSource(root).text:readFileSync(root+file,'utf8');");p.write_text(s)
p=Path('rust/tests/web/staged-release-activation-transition.test.mjs');s=p.read_text();s+='''
test('legacy single-file inline and deployed source fixtures retain checked generation',()=>{
 const value=fixture();try{
  const retained=path.join(value.directory,evidence,'original-release-workflow.yml');
  fs.writeFileSync(retained,value.original);
  assert.equal(check(value.directory,'--check').status,0);
  fs.writeFileSync(path.join(value.directory,'.github/workflows/release.yml'),value.projection.outputs.get(evidence+'candidate-release-caller.yml'));
  assert.equal(check(value.directory,'--check-deployed').status,0);
 }finally{fs.rmSync(value.directory,{recursive:true,force:true});}
});
''';p.write_text(s)
print('inline and deployed receipts bind all consumed physical inputs; explicit legacy format control added',flush=True)
