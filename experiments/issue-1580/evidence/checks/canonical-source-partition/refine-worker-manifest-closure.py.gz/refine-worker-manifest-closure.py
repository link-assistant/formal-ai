from pathlib import Path
p=Path('scripts/regenerate-worker-receipt.mjs');text=p.read_text()
text=text.replace("import {execFileSync} from 'node:child_process';","import {execFileSync} from 'node:child_process';\nimport {createHash} from 'node:crypto';")
text=text.replace("{copyFileSync,mkdirSync,writeFileSync}","{copyFileSync,mkdirSync,writeFileSync,readFileSync}")
text=text.replace("{resolve} from 'node:path'","{relative,resolve,sep} from 'node:path'")
text=text.replace("{buildSelectedWasm,verifySelectedWasm}","{buildSelectedWasm,verifySelectedWasm,dependencyPaths}")
marker='export function regenerate(root,environment=process.env) {'
function="""// The worker manifest describes compiler dependencies. Package and recipe
// metadata remain bound in the producer receipt without causing false drift.
export function compilerInputManifest(root,record,dependencyInfo) {
  assert.equal(createHash('sha256').update(dependencyInfo).digest('hex'),record.dependencyInfoSha256);
  const paths=[...new Set(dependencyPaths(dependencyInfo.toString('utf8'))
    .map(path=>relative(root,resolve(root,path)).split(sep).join('/')))].sort();
  const inputs=paths.map(path=>{const input=record.inputs.find(file=>file.path===path);
    assert(input,'compiler dependency missing from verified receipt: '+path);return {path,sha256:input.sha256};});
  return renderManifest({worker:record.output,compiler:compilerIdentity(record.compiler),inputs});
}

"""
assert text.count(marker)==1;text=text.replace(marker,function+marker)
old="""  const manifest=renderManifest({worker:result.record.output,compiler:compilerIdentity(result.record.compiler),
    inputs:result.record.inputs.map(({path,sha256})=>({path,sha256}))});"""
assert text.count(old)==1;text=text.replace(old,"  const manifest=compilerInputManifest(root,result.record,readFileSync(resolve(root,'js/formal_ai_worker.d')));")
p.write_text(text)
p=Path('experiments/issue-1580/worker-receipt-regeneration.test.mjs');text=p.read_text()
text=text.replace("import {admission} from '../../scripts/regenerate-worker-receipt.mjs';","import {admission,compilerInputManifest} from '../../scripts/regenerate-worker-receipt.mjs';\nimport {createHash} from 'node:crypto';\nimport {parseManifest} from '../../scripts/wasm-worker-inputs.mjs';")
text += r"""
test('worker manifest preserves only actual compiler dependencies while the receipt binds metadata',()=>{
  const dependencyInfo=Buffer.from('js/formal_ai_worker.wasm: js/wasm-worker/src/lib.rs rust/src/../src/solver.rs\\n');
  const record={dependencyInfoSha256:createHash('sha256').update(dependencyInfo).digest('hex'),
    output:{bytes:8,sha256:'a'.repeat(64)},compiler:'rustc 1.100.0\\ncommit-hash: '+'b'.repeat(40)+'\\n',
    inputs:['js/wasm-worker/src/lib.rs','rust/src/solver.rs','rust/Cargo.toml','js/wasm-worker/build.sh']
      .map(path=>({path,sha256:'c'.repeat(64)}))};
  const manifest=parseManifest(compilerInputManifest('/source',record,dependencyInfo));
  assert.deepEqual(manifest.inputs.map(input=>input.path),['js/wasm-worker/src/lib.rs','rust/src/solver.rs']);
  assert.equal(record.inputs.length,4,'the producer receipt retains its metadata bindings');
  const metadataChanged=structuredClone(record);metadataChanged.inputs[2].sha256='d'.repeat(64);
  assert.equal(compilerInputManifest('/source',metadataChanged,dependencyInfo),compilerInputManifest('/source',record,dependencyInfo));
  assert.throws(()=>compilerInputManifest('/source',record,Buffer.concat([dependencyInfo,Buffer.from('drift')])));
  assert.throws(()=>compilerInputManifest('/source',{...record,inputs:record.inputs.slice(1)},dependencyInfo));
});
"""
p.write_text(text)
p=Path('docs/case-studies/issue-1580/hosted-worker-regeneration.md');text=p.read_text();text=text.replace('and uploads the\nworker, receipt and manifest for one day.','and uploads the\nworker, receipt and manifest for one day. The manifest keeps only the actual\ncompiler dependency closure; package/version and build-recipe metadata stay bound\nin the producer receipt. This preserves existing drift semantics when a release\nchanges package metadata without changing worker inputs.')
text=text.replace('checks negative\nadmission, exact job permissions and budget, and complete job selection on both','checks compiler dependency/metadata separation, negative\nadmission, exact job permissions and budget, and complete job selection on both');p.write_text(text)
print('Refined manifest closure without changing producer receipt metadata bindings')
