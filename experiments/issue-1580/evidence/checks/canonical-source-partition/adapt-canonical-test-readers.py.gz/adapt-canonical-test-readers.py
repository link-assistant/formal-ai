from pathlib import Path
prefix='experiments/formal_ai_subagent/evidence/specification-delivery-1188/dormant-staged-release/'
module="import {readCanonicalSource} from '../../../scripts/canonical-release-source.mjs';\n"
def edit(stem,changes,add=True):
 p=Path('rust/tests/web')/(stem+'.test.mjs');s=p.read_text()
 for old,new in changes:
  assert old in s,(stem,old);s=s.replace(old,new)
 p.write_text((module if add else '')+s)
for stem in ['release-preflight-checkout','staged-pages-projection']:
 edit(stem,[("read(evidence+'original-release-workflow.yml')","readCanonicalSource(root).text"),("read(evidence + 'original-release-workflow.yml')","readCanonicalSource(root).text")] if stem=='staged-pages-projection' else [("read(evidence+'original-release-workflow.yml')","readCanonicalSource(root).text")]) if False else None
edit('release-preflight-checkout',[("read(evidence+'original-release-workflow.yml')","readCanonicalSource(root).text")])
edit('staged-pages-projection',[("read(evidence + 'original-release-workflow.yml')","readCanonicalSource(root).text")])
edit('staged-release-secret-authority',[("fs.readFileSync(new URL(evidence + 'original-release-workflow.yml', root), 'utf8')","readCanonicalSource(root).text")])
edit('release-stage-transfer',[("readFileSync(new URL('original-release-workflow.yml', evidence), 'utf8')","readCanonicalSource(repository).text")])
edit('release-recovery-ordinary-path',[("fs.readFileSync(new URL(prefix + 'original-release-workflow.yml', import.meta.url), 'utf8')","readCanonicalSource(new URL('../../../',import.meta.url)).text")])
edit('maintained-staged-authority',[("fs.readFileSync(path.join(directory,evidence,'original-release-workflow.yml'),'utf8')","readCanonicalSource(directory).text"),
 ("'original-release-workflow.yml'].map", "'original-release-workflow.yml','original-release-workflow.part-1.txt','original-release-workflow.part-2.txt'].map"),
 ("'scripts/lib/ci-speed-workflows.mjs',", "'scripts/lib/ci-speed-workflows.mjs','scripts/canonical-release-source.mjs',")])
edit('staged-release-activation-transition',[("fs.readFileSync(path.join(root,evidence,'original-release-workflow.yml'),'utf8')","readCanonicalSource(root).text"),
 ("'original-release-workflow.yml'].map", "'original-release-workflow.yml','original-release-workflow.part-1.txt','original-release-workflow.part-2.txt'].map"),
 ("'scripts/lib/ci-speed-workflows.mjs',", "'scripts/lib/ci-speed-workflows.mjs','scripts/canonical-release-source.mjs',"),
 ("fs.writeFileSync(retainedPath,value.original+'\\n# retained drift\\n');", "const retainedIndex=fs.readFileSync(retainedPath,'utf8');fs.writeFileSync(retainedPath,retainedIndex+'\\n# retained drift\\n');"),
 ("fs.writeFileSync(retainedPath,value.original);", "fs.writeFileSync(retainedPath,retainedIndex);")])
edit('native-staged-release-operation-view',[("readFileSync(root+evidence+'original-release-workflow.yml','utf8')","readCanonicalSource(root).text"),
 ("'original-release-workflow.yml','candidate-release-caller.yml'", "'original-release-workflow.yml','original-release-workflow.part-1.txt','original-release-workflow.part-2.txt','candidate-release-caller.yml'"),
 ("'scripts/lib/ci-speed-workflows.mjs',", "'scripts/lib/ci-speed-workflows.mjs','scripts/canonical-release-source.mjs',")])
edit('release-workflow-scope-controls',[("'original-release-workflow.yml', 'stage-source-coverage.json'", "'original-release-workflow.yml','original-release-workflow.part-1.txt','original-release-workflow.part-2.txt', 'stage-source-coverage.json'")],False)
edit('release-current-group-membership',[
 ("const canonical=read(evidence+'original-release-workflow.yml'),packetSource", "const physical=readCanonicalSource(root),canonical=physical.text,packetSource"),
 ("originalSource:canonical,packetSource", "originalSource:canonical,physicalSourceFiles:physical.files,packetSource"),
 ("contract.sources.length,4", "contract.sources.length,6"),
 ("const bodies=[callerDraft,staged,canonical,packetSource];", "const physical=readCanonicalSource(root);const bodies=[callerDraft,staged,...physical.files.map(file=>file.text),packetSource];"),
 ("calls.length,9", "calls.length,11")])
edit('hive-delivery-admission',[("YAML.parse(read(name)).jobs['hive-source-provenance']", "YAML.parse(name===retained+'original-release-workflow.yml'?readCanonicalSource(new URL('../../../',import.meta.url)).text:read(name)).jobs['hive-source-provenance']")])
edit('default-branch-build-policy',[
 ("'candidate-release-caller.yml', 'original-release-workflow.yml',", "'candidate-release-caller.yml', 'original-release-workflow.yml','original-release-workflow.part-1.txt','original-release-workflow.part-2.txt',"),
 ('"'+prefix+'original-release-workflow.yml",','"'+prefix+'original-release-workflow.yml",\n    "'+prefix+'original-release-workflow.part-1.txt",\n    "'+prefix+'original-release-workflow.part-2.txt",'),
 ("'"+prefix+"original-release-workflow.yml',", "'"+prefix+"original-release-workflow.yml',\n    '"+prefix+"original-release-workflow.part-1.txt',\n    '"+prefix+"original-release-workflow.part-2.txt',")],False)
print('canonical source test readers and physical copy closures adapted',flush=True)
