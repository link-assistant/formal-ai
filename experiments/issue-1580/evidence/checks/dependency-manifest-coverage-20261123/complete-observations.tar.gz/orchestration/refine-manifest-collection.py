from pathlib import Path
root=Path.cwd()
p=root/'scripts/check-dependencies-latest.rs'
text=p.read_text()
start=text.index('    let coverage = Command::new("node")')
end=text.index('\n    let snapshot = ', start)
text=text[:start]+r'''    let npm_manifests = manifest_collection::tracked_npm_paths(&repo).unwrap_or_else(|error| {
        eprintln!("check-dependencies-latest: {error}");
        std::process::exit(EXIT_UNVERIFIABLE);
    });
    let dependencies = collect(&repo, Some(&npm_manifests)).unwrap_or_else(|error| {
        eprintln!("check-dependencies-latest: {error}");
        std::process::exit(EXIT_UNVERIFIABLE);
    });
''' +text[end:]
start=text.index('fn collect_cargo(')
end=text.index('\nfn collect_npm(',start)
cargo=text[start:end].replace('fn collect_cargo(', 'pub(super) fn collect_cargo(',1)
text=text[:start]+text[end:]
text=text.replace('pub fn collect(repo: &Path) -> Result<Vec<Dependency>, String> {',
'''pub fn collect(repo: &Path, npm_manifests: Option<&[PathBuf]>) -> Result<Vec<Dependency>, String> {''')
text=text.replace('    collect_cargo(repo, &mut dependencies)?;\n    collect_npm(repo, &mut dependencies);',
'''    manifest_collection::collect_cargo(repo, &mut dependencies)?;
    if let Some(manifests) = npm_manifests {
        collect_npm_manifests(manifests, &mut dependencies)?;
    } else {
        collect_npm(repo, &mut dependencies)?;
    }''')
old='''fn collect_npm(repo: &Path, dependencies: &mut Vec<Dependency>) {
    let mut manifests = Vec::new();
    walk_for(repo, "package.json", &mut manifests);
    manifests.sort();
    for manifest_path in manifests {
        let Ok(text) = fs::read_to_string(&manifest_path) else {
            continue;
        };'''
new='''fn collect_npm(repo: &Path, dependencies: &mut Vec<Dependency>) -> Result<(), String> {
    let mut manifests = Vec::new();
    walk_for(repo, "package.json", &mut manifests);
    manifests.sort();
    collect_npm_manifests(&manifests, dependencies)
}

fn collect_npm_manifests(manifests: &[PathBuf], dependencies: &mut Vec<Dependency>) -> Result<(), String> {
    for manifest_path in manifests {
        let text = fs::read_to_string(manifest_path)
            .map_err(|error| format!("{}: {error}", manifest_path.display()))?;'''
assert text.count(old)==1
text=text.replace(old,new)
needle='''    }
}

/// The exact versions a directory's lockfile resolves'''
assert text.count(needle)==1
text=text.replace(needle,'''    }
    Ok(())
}

/// The exact versions a directory's lockfile resolves''')
needle='''/// Every dependency the repository declares, across all five ecosystems.'''
assert text.count(needle)==1
text=text.replace(needle,'''#[path = "check-dependencies-manifests.rs"]
mod manifest_collection;

/// Every dependency the repository declares, across all five ecosystems.''')
p.write_text(text)
(root/'scripts/check-dependencies-manifests.rs').write_text(r'''//! Manifest coverage shared by the maintained dependency updater.
use super::*;

#[cfg(not(test))]
pub(super) fn tracked_npm_paths(repo: &Path) -> Result<Vec<PathBuf>, String> {
    let output = Command::new("node")
        .arg(repo.join("scripts/dependency-manifest-inventory.mjs"))
        .arg("--repo")
        .arg(repo)
        .output()
        .map_err(|error| format!("cannot observe complete manifest coverage: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "cannot observe complete manifest coverage: {}",
            String::from_utf8_lossy(&output.stderr)
        ));
    }
    let inventory: serde_json::Value = serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("invalid manifest inventory: {error}"))?;
    inventory["npm"]
        .as_array()
        .ok_or_else(|| "manifest inventory requires npm paths".to_string())?
        .iter()
        .map(|value| {
            value.as_str().map(|name| repo.join(name))
                .ok_or_else(|| "npm manifest entries must be paths".to_string())
        })
        .collect()
}

''' +cargo+'\n')
p=root/'rust/tests/unit/issue_1169_dependency_currency.rs'
text=p.read_text().replace('collect(&root)', 'collect(&root, None)').replace('collect(repository)', 'collect(repository, None)')
text+=r'''

#[test]
fn checked_npm_inventory_excludes_untracked_packages_and_refuses_missing_tracked_files() {
    let root = fixture_tree("checked-npm");
    full_fixture(&root);
    write(&root.join("untracked/package.json"), r#"{"dependencies":{"surprise":"1"}}"#);
    assert!(collect(&root, None).expect("legacy walk").iter().any(|item| item.name == "surprise"));
    let paths = [root.join("package.json")];
    let tracked = collect(&root, Some(&paths)).expect("checked npm inventory");
    assert!(!tracked.iter().any(|item| item.name == "surprise"));
    fs::remove_file(&paths[0]).expect("remove tracked manifest");
    assert!(collect(&root, Some(&paths)).expect_err("lost file is not a clean observation").contains("package.json"));
    let _ = fs::remove_dir_all(root);
}
'''
p.write_text(text)
p=root/'scripts/check-dependencies-latest-tests.rs'
text=p.read_text()
assert text.count('collect_npm(&root, &mut dependencies);')==1
p.write_text(text.replace('collect_npm(&root, &mut dependencies);','collect_npm(&root, &mut dependencies).expect("complete npm collection");'))
print('Drafted tracked-only npm collection, fallible reads, and two native collection regressions; no native execution.')
