import json, re, subprocess
from pathlib import Path
root=Path.cwd()
out=Path('/tmp/issue-1580-research/dependency-manifest-coverage')
records=[]
def run(label,args,cwd=root):
    with (out/(label+'.stdout')).open('wb') as output, (out/(label+'.stderr')).open('wb') as errors:
        result=subprocess.run(args,cwd=cwd,stdout=output,stderr=errors)
    record={'label':label,'command':args,'cwd':str(cwd),'exitCode':result.returncode}
    records.append(record)
    (out/'checks.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    return result.returncode
old=(out/'.github__workflows__dependencies-latest.yml.before').read_text()
new=(root/'.github/workflows/dependencies-latest.yml').read_text()
before=re.search(r'- name: Re-resolve the Rust lockfile from the rewritten manifest\n        working-directory: rust\n        run: ([^\n]+)',old)
after=re.search(r'- name: Re-resolve the Rust lockfiles from the rewritten manifests\n        run: \|\n(.*?)(?=\n      (?:#|- name:))',new,re.S)
assert before and after
recorder='cargo() { printf "cargo:%s:%s\\n" "$PWD" "$*"; }\n'
assert run('before-actual-rust-resolution',['bash','-c',recorder+before[1]],root/'rust')==0
assert run('after-actual-rust-resolution',['bash','-c',recorder+re.sub(r'^          ','',after[1],flags=re.M)])==0
before_lines=(out/'before-actual-rust-resolution.stdout').read_text().splitlines()
after_lines=(out/'after-actual-rust-resolution.stdout').read_text().splitlines()
assert len(before_lines)==1 and len(after_lines)==3
assert any('--manifest-path experiments/issue-1580/release-registry/Cargo.toml' in line for line in after_lines)
assert not any('historical' in line or 'quadratic' in line or 'lindera' in line for line in after_lines)
commands=[
('maintenance-controls',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/dependencies-maintenance-workflow.test.mjs']),
('currency-workflow-controls',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1169-dependencies-latest-workflow.test.mjs']),
('actual-tracked-manifest-inventory',['node','--max-old-space-size=256','scripts/dependency-manifest-inventory.mjs']),
('typescript-currency',['node','--max-old-space-size=256','scripts/translate-es.mjs','--check']),
('native-source-format',['rustfmt','--edition','2024','--config','skip_children=true','--check','scripts/check-dependencies-latest.rs','rust/tests/unit/issue_1169_dependency_currency.rs','rust/tests/unit/workflow_contracts.rs']),
('local-gate-inventory',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--list']),
('file-size-gate',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size']),
('readable-code-gate',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-readable-code']),
]
for label,args in commands:
    run(label,args)
(out/'outcome.json').write_text(json.dumps({'complete':True,'checks':records,'allPassed':all(row['exitCode']==0 for row in records),'nativeExecuted':False,'independentAuthorshipCredit':0},indent=2)+'\n')
