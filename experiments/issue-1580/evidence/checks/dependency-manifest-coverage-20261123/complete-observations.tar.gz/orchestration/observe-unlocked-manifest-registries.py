import json, subprocess, hashlib
from pathlib import Path
root=Path('/tmp/issue-1580-research/dependency-manifest-coverage')
results=[]
for name in ['regex','serde_json']:
    args=['curl','--fail','--silent','--show-error','--location','--user-agent','formal-ai-issue-1580-maintenance-review',f'https://crates.io/api/v1/crates/{name}']
    result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (root/(name+'-registry.json')).write_bytes(result.stdout)
    (root/(name+'-registry.stderr')).write_bytes(result.stderr)
    result.check_returncode()
    crate=json.loads(result.stdout)['crate']
    results.append({'crate':name,'maxStable':crate['max_stable_version'],'sha256':hashlib.sha256(result.stdout).hexdigest(),'command':args,'exitCode':result.returncode})
(root/'unlocked-manifest-registry-observations.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
