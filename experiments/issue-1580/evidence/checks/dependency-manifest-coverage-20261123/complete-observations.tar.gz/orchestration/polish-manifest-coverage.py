import json, shutil, subprocess
from pathlib import Path
root=Path.cwd()
out=Path('/tmp/issue-1580-research/dependency-manifest-coverage')
harness=root/'experiments/issue-1558/rust-module-harness/Cargo.toml'
before=harness.read_text()
(out/'issue-1558-Cargo.toml.before').write_text(before)
for observation in json.loads((out/'unlocked-manifest-registry-observations.json').read_text()):
    old=observation['crate']+' = "1"'
    new=observation['crate']+' = "'+observation['maxStable']+'"'
    assert before.count(old)==1, old
    before=before.replace(old,new)
harness.write_text(before)
unit=root/'rust/tests/unit/issue_1169_dependency_currency.rs'
text=unit.read_text()
old='    let dependencies = collect(repository, None).expect("complete manifest collection");'
new='''    let workflow = fs::read_to_string(repository.join(".github/workflows/dependencies-latest.yml"))
        .expect("read the maintained workflow independently of the dependency collector");
    let checkout = workflow
        .lines()
        .find_map(|line| line.trim().strip_prefix("- uses: actions/checkout@"))
        .expect("the maintained workflow checks out the repository")
        .trim_start_matches('v');
    let dependencies = collect(repository, None).expect("complete manifest collection");'''
assert text.count(old)==1
text=text.replace(old,new)
old='(Ecosystem::GitHubAction, "zizmorcore/zizmor-action", "0.6.4")'
assert text.count(old)==1
text=text.replace(old,'(Ecosystem::GitHubAction, "actions/checkout", checkout)')
unit.write_text(text)
fragment=root/'changelog.d/20261123_035800_dependency_manifest_coverage.md'
assert not fragment.exists()
fragment.write_text('''---
bump: patch
---

### Fixed

- Cover all active Cargo projects and tracked npm manifests in dependency maintenance. Reject incomplete inventories and unclassified manifests, preserve historical reproducers explicitly, and resolve each active Rust lockfile with its owning manifest.
''')
doc=root/'docs/case-studies/issue-1580/dependency-manifest-coverage-20261123.md'
assert not doc.exists()
doc.write_text('''# Dependency manifest coverage, 2026-11-23

Issue #1580 requires applying the complete template practices, including current dependencies throughout the maintained projects. The existing collector read only rust/Cargo.toml and the dependency workflow re-resolved only rust/Cargo.lock. Two active isolated Rust projects were omitted. The npm collector walked the filesystem, included untracked manifests, and silently skipped manifest read errors.

The new scripts/dependency-manifests.json policy classifies all six tracked files whose exact basename is Cargo.toml: three active projects, two preserved historical reproducers, and one intentionally empty path-classification fixture. Historical manifests retain their issue-linked reproduction purpose. Archived evidence files ending in -Cargo.toml are source observations, not additional packages.

The checked Git inventory also identifies all fourteen tracked package.json files. A failed or partial Git listing, malformed policy, unclassified Cargo manifest, missing classified manifest, duplicate classification, unexplained preservation, nonempty empty fixture, or unreadable npm manifest fails the observation. Production collection uses the checked npm list; untracked files cannot silently extend the dependency set. Missing files after inventory also fail collection.

The Rust collector reads each active project's own manifest and adjacent lockfile. An unlocked project's declared minimum is checked instead of being silently omitted. Fresh official crates.io responses observed regex 1.13.2 and serde_json 1.0.154; those minimums replace the issue-1558 harness's broad major-only declarations. The two historical reproducers retain their original dependencies.

The maintained workflow first completes the manifest inventory, then invokes Cargo separately for each active project. Replaying the actual previous shell step with a recording Cargo function produced one invocation. Replaying the new shell step with the real inventory and the same recording function produced three invocations, including the release-registry producer. This experiment records command selection; it does not execute Cargo resolution or compilation.

The initial focused run passed nine manifest-maintenance JavaScript controls and six neighboring dependency-workflow controls. The controls exercise tracked coverage, missing classifications and files, duplicate entries, failed and incomplete Git listings, and refusal to start any resolver after an inventory failure. The complete source changes receive another focused run before commit. Native collector regressions are included in the maintained workflow-contract target and require the next hosted run. The newly included existing ecosystem test derives its checkout anchor from the current workflow rather than an obsolete action.

The original captured streams, the failed-before command-selection observation, registry responses, and final check records will be retained with this checkpoint. A local command recorder does not establish a successful hosted maintenance run, complete repository dependency currency, or acceptance of the other issue requirements. Supplied controller and source changes receive zero independent-authorship credit.

Related pull request: https://github.com/link-assistant/formal-ai/pull/1581.
''')
plan=root/'experiments/issue-1580/work-plan.md'
with plan.open('a') as stream:
    stream.write('''
## Tracked dependency manifest follow-up, 2026-11-23

- [x] Inventory exact tracked Cargo.toml and package.json basenames: six Cargo and fourteen npm manifests.
- [x] Reproduce the old actual resolver step selecting only the primary crate; replay the new step selecting all three active crates with real inventory and a recording Cargo function.
- [x] Draft complete manifest classification, checked production npm collection, per-project Cargo collection and resolution, and failure on incomplete observations.
- [x] Preserve two issue-linked historical reproducers and the intentionally empty classification fixture.
- [x] Refresh the unlocked active issue-1558 harness minimums from retained official registry responses.
- [x] Run the initial fifteen focused JavaScript controls successfully.
- [ ] Verify the final source batch, retain original evidence, and run the complete clean local JavaScript gate set.
- [ ] Verify the newly admitted native dependency controls on the corrected hosted head.
- [ ] Verify an actual maintained dependency run and every remaining original acceptance criterion; command-selection replay alone does not establish these outcomes.
''')
round2=out/'round-2'
round2.mkdir(exist_ok=False)
shutil.copyfile(out/'.github__workflows__dependencies-latest.yml.before',round2/'.github__workflows__dependencies-latest.yml.before')
script=Path('/tmp/issue-1580-research/check-dependency-manifest-coverage.py').read_text()
assert script.count("out=Path('/tmp/issue-1580-research/dependency-manifest-coverage')")==1
script=script.replace("out=Path('/tmp/issue-1580-research/dependency-manifest-coverage')","out=Path('/tmp/issue-1580-research/dependency-manifest-coverage/round-2')")
old="'scripts/check-dependencies-latest.rs','rust/tests/unit/"
assert old in script
script=script.replace(old,"'scripts/check-dependencies-latest.rs','scripts/check-dependencies-manifests.rs','scripts/check-dependencies-latest-tests.rs','rust/tests/unit/")
assert "('local-gate-inventory'," in script
script=script.replace("('local-gate-inventory',","('native-artifact-controls',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/native-test-artifact.test.mjs']),\n('local-gate-inventory',")
Path('/tmp/issue-1580-research/check-dependency-manifest-coverage-round2.py').write_text(script)
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','scripts/check-dependencies-latest.rs','scripts/check-dependencies-manifests.rs','scripts/check-dependencies-latest-tests.rs','rust/tests/unit/issue_1169_dependency_currency.rs','rust/tests/unit/workflow_contracts.rs'],check=True)
paths=['.github/workflows/dependencies-latest.yml','rust/tests/unit/issue_1169_dependency_currency.rs','rust/tests/unit/workflow_contracts.rs','rust/tests/web/dependencies-maintenance-workflow.test.mjs','rust/tests/web/issue-1169-dependencies-latest-workflow.test.mjs','scripts/check-dependencies-latest-tests.rs','scripts/check-dependencies-latest.rs','scripts/check-dependencies-manifests.rs','scripts/dependency-manifest-inventory.mjs','scripts/dependency-manifests.json',str(harness.relative_to(root)),str(fragment.relative_to(root)),str(doc.relative_to(root)),str(plan.relative_to(root))]
subprocess.run(['git','add','--',*paths],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
print(json.dumps({'stagedPaths':paths,'nativeExecuted':False}))
