import json
from pathlib import Path
root=Path.cwd()
out=Path('/tmp/issue-1580-research/dependency-manifest-coverage')
out.mkdir(exist_ok=False)
paths=['scripts/check-dependencies-latest.rs','rust/tests/unit/issue_1169_dependency_currency.rs','rust/tests/unit/workflow_contracts.rs','.github/workflows/dependencies-latest.yml','rust/tests/web/issue-1169-dependencies-latest-workflow.test.mjs','rust/tests/web/dependencies-maintenance-workflow.test.mjs']
for name in paths:
    (out/(name.replace('/','__')+'.before')).write_bytes((root/name).read_bytes())
policy={'schemaVersion':1,'activeCargo':['rust/Cargo.toml','experiments/issue-1558/rust-module-harness/Cargo.toml','experiments/issue-1580/release-registry/Cargo.toml'],'preservedCargo':{
'experiments/issue-1017-meta-language-quadratic/Cargo.toml':{'kind':'historical-reproducer','reason':'Preserve the exact dependency that reproduces the quadratic parser defect.','issue':'https://github.com/link-assistant/formal-ai/issues/1017'},
'experiments/lindera-docsrs-repro/Cargo.toml':{'kind':'historical-reproducer','reason':'Preserve the published lindera-jieba docs.rs failure for upstream reproduction.','issue':'https://github.com/lindera/lindera/issues/750'},
'experiments/issue-1021-php/sample/Cargo.toml':{'kind':'empty-fixture','reason':'This intentionally empty file is a path-classification fixture, not a Cargo package.','issue':'https://github.com/link-assistant/formal-ai/issues/1021'}}}
(root/'scripts/dependency-manifests.json').write_text(json.dumps(policy,indent=2)+'\n')
(root/'scripts/dependency-manifest-inventory.mjs').write_text(r'''#!/usr/bin/env node
// Every tracked Cargo manifest is active or has a specific preserved purpose.
import {spawnSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

export function dependencyManifests(repository, git = spawnSync) {
  const result = git('git', ['ls-files', '-z'], {cwd: repository, encoding: 'utf8', maxBuffer: 32 * 1024 * 1024});
  if (result.error || result.status !== 0) {
    throw new Error('Cannot enumerate complete tracked dependency manifests: ' + (result.error?.message ?? result.stderr ?? result.status));
  }
  const raw = result.stdout;
  if (typeof raw !== 'string' || (raw && !raw.endsWith('\0'))) throw new Error('Incomplete tracked-file inventory');
  const files = raw ? raw.slice(0, -1).split('\0') : [];
  if (new Set(files).size !== files.length) throw new Error('Duplicate tracked-file inventory');
  const tracked = new Set(files);
  const policy = JSON.parse(readFileSync(path.join(repository, 'scripts/dependency-manifests.json'), 'utf8'));
  if (policy.schemaVersion !== 1 || !Array.isArray(policy.activeCargo) ||
      !policy.preservedCargo || typeof policy.preservedCargo !== 'object' || Array.isArray(policy.preservedCargo)) {
    throw new Error('Malformed dependency manifest policy');
  }
  const active = policy.activeCargo;
  const preserved = Object.keys(policy.preservedCargo);
  const classified = [...active, ...preserved];
  if (!active.length || new Set(classified).size !== classified.length) throw new Error('Empty or duplicate Cargo classification');
  for (const name of classified) {
    if (typeof name !== 'string' || path.posix.isAbsolute(name) || name.includes('\\') ||
        name.split('/').some(part => !part || part === '.' || part === '..') ||
        path.posix.basename(name) !== 'Cargo.toml' || !tracked.has(name)) {
      throw new Error('Invalid or untracked Cargo classification: ' + name);
    }
    readFileSync(path.join(repository, name));
  }
  for (const name of preserved) {
    const entry = policy.preservedCargo[name];
    if (!entry || !['historical-reproducer', 'empty-fixture'].includes(entry.kind) ||
        typeof entry.reason !== 'string' || !entry.reason.trim() ||
        typeof entry.issue !== 'string' || !/^https:\/\/github\.com\/[^/]+\/[^/]+\/issues\/[1-9][0-9]*$/u.test(entry.issue)) {
      throw new Error('Preserved manifest requires its purpose and issue: ' + name);
    }
    if (entry.kind === 'empty-fixture' && readFileSync(path.join(repository, name), 'utf8').trim()) {
      throw new Error('Formerly empty fixture needs reclassification: ' + name);
    }
  }
  const cargo = files.filter(name => path.posix.basename(name) === 'Cargo.toml').sort();
  const covered = new Set(classified);
  const missing = cargo.filter(name => !covered.has(name));
  if (missing.length) throw new Error('Unclassified Cargo manifests: ' + missing.join(', '));
  const npm = files.filter(name => path.posix.basename(name) === 'package.json').sort();
  for (const name of npm) JSON.parse(readFileSync(path.join(repository, name), 'utf8'));
  return {activeCargo: [...active].sort(), preservedCargo: [...preserved].sort(), npm, cargo};
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const args = process.argv.slice(2);
    let repository = process.cwd();
    let cargoOnly = false;
    while (args.length) {
      const flag = args.shift();
      if (flag === '--cargo') cargoOnly = true;
      else if (flag === '--repo' && args.length) repository = path.resolve(args.shift());
      else throw new Error('Usage: dependency-manifest-inventory.mjs [--repo directory] [--cargo]');
    }
    const result = dependencyManifests(repository);
    process.stdout.write(cargoOnly ? result.activeCargo.join('\n') + '\n' : JSON.stringify(result, null, 2) + '\n');
  } catch (error) {
    console.error('dependency manifest coverage: ' + error.message);
    process.exitCode = 1;
  }
}
''')
p=root/'scripts/check-dependencies-latest.rs'
text=p.read_text()
old='    let dependencies = collect(&repo);'
assert text.count(old)==1
text=text.replace(old,r'''    let coverage = Command::new("node")
        .arg(repo.join("scripts/dependency-manifest-inventory.mjs"))
        .arg("--repo")
        .arg(&repo)
        .status();
    if !coverage.is_ok_and(|status| status.success()) {
        eprintln!("check-dependencies-latest: complete manifest coverage is required");
        std::process::exit(EXIT_UNVERIFIABLE);
    }
    let dependencies = collect(&repo).unwrap_or_else(|error| {
        eprintln!("check-dependencies-latest: {error}");
        std::process::exit(EXIT_UNVERIFIABLE);
    });''')
start=text.index('pub fn collect(repo: &Path) -> Vec<Dependency> {')
end=text.index('\nfn collect_npm(',start)
text=text[:start]+r'''pub fn collect(repo: &Path) -> Result<Vec<Dependency>, String> {
    let mut dependencies = Vec::new();
    collect_cargo(repo, &mut dependencies)?;
    collect_npm(repo, &mut dependencies);
    collect_workflows(repo, &mut dependencies);
    collect_dockerfile(repo, &mut dependencies);
    collect_rust_version(repo, &mut dependencies);
    Ok(dependencies)
}

fn collect_cargo(repo: &Path, dependencies: &mut Vec<Dependency>) -> Result<(), String> {
    let policy_path = repo.join("scripts/dependency-manifests.json");
    let manifests = match fs::read_to_string(&policy_path) {
        Ok(text) => {
            let policy: serde_json::Value = serde_json::from_str(&text)
                .map_err(|error| format!("{}: {error}", policy_path.display()))?;
            policy["activeCargo"].as_array()
                .ok_or_else(|| "manifest policy requires activeCargo".to_string())?
                .iter()
                .map(|value| value.as_str().map(PathBuf::from)
                    .ok_or_else(|| "activeCargo entries must be paths".to_string()))
                .collect::<Result<Vec<_>, _>>()?
        }
        // Existing isolated parser fixtures have no repository policy.
        Err(error) if error.kind() == std::io::ErrorKind::NotFound
            && !repo.join("scripts/check-dependencies-latest.rs").exists() => {
                vec![PathBuf::from("rust/Cargo.toml")]
            }
        Err(error) => return Err(format!("{}: {error}", policy_path.display())),
    };
    for manifest in manifests {
        let manifest_path = repo.join(&manifest);
        let text = fs::read_to_string(&manifest_path)
            .map_err(|error| format!("{}: {error}", manifest_path.display()))?;
        let lock_path = manifest_path.with_file_name("Cargo.lock");
        let lock_versions = match fs::read_to_string(&lock_path) {
            Ok(text) => parse_cargo_lock(&text),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => BTreeMap::new(),
            Err(error) => return Err(format!("{}: {error}", lock_path.display())),
        };
        for (name, declared, line, blocked) in parse_cargo_manifest(&text) {
            let resolved = lock_versions.get(&name).cloned()
                .unwrap_or_else(|| base_version(&declared).to_string());
            dependencies.push(Dependency {
                ecosystem: Ecosystem::CratesIo,
                name,
                declared: Some(declared),
                resolved,
                path: manifest_path.clone(),
                line,
                blocked,
            });
        }
    }
    Ok(())
}
''' +text[end:]
p.write_text(text)
p=root/'rust/tests/unit/issue_1169_dependency_currency.rs'
text=p.read_text()
assert text.count('collect(&root);')==2 and text.count('collect(repository);')==1
text=text.replace('collect(&root);','collect(&root).expect("complete manifest collection");').replace('collect(repository);','collect(repository).expect("complete manifest collection");')
text+=r'''

#[test]
fn active_nested_cargo_manifests_are_collected_without_rewriting_preserved_reproducers() {
    let root = fixture_tree("nested-cargo-policy");
    full_fixture(&root);
    write(&root.join("scripts/dependency-manifests.json"), r#"{
        "activeCargo": ["rust/Cargo.toml", "tools/registry/Cargo.toml", "tools/unlocked/Cargo.toml"]
    }"#);
    write(&root.join("tools/registry/Cargo.toml"), "[dependencies]\nregex = \"1\"\n");
    write(&root.join("tools/registry/Cargo.lock"), "[[package]]\nname = \"regex\"\nversion = \"1.12.9\"\n");
    write(&root.join("tools/unlocked/Cargo.toml"), "[dependencies]\nserde_json = \"1\"\n");
    write(&root.join("historical/Cargo.toml"), "[dependencies]\nold = \"0.1\"\n");
    let dependencies = collect(&root).expect("all active manifests");
    let nested = dependencies.iter().find(|item| item.path == root.join("tools/registry/Cargo.toml")).expect("nested registry dependency");
    assert_eq!(nested.name, "regex");
    assert_eq!(nested.resolved, "1.12.9");
    assert!(dependencies.iter().any(|item| item.name == "serde_json" && item.resolved == "1"));
    assert!(!dependencies.iter().any(|item| item.name == "old"));
    fs::remove_file(root.join("tools/registry/Cargo.toml")).expect("remove active manifest");
    assert!(collect(&root).expect_err("missing active manifest is not clean").contains("tools/registry/Cargo.toml"));
    let _ = fs::remove_dir_all(root);
}
'''
p.write_text(text)
p=root/'rust/tests/unit/workflow_contracts.rs'
p.write_text(p.read_text()+r'''

// Keep the dependency updater's collection and parser controls in focused CI.
#[allow(dead_code)]
#[path = "issue_1169_dependency_currency.rs"]
mod dependency_currency;
''')
p=root/'.github/workflows/dependencies-latest.yml'
text=p.read_text()
old='''      - name: Re-resolve the Rust lockfile from the rewritten manifest
        working-directory: rust
        run: cargo update --workspace'''
assert text.count(old)==1
text=text.replace(old,'''      - name: Re-resolve the Rust lockfiles from the rewritten manifests
        run: |
          set -euo pipefail
          manifests="$(node scripts/dependency-manifest-inventory.mjs --cargo)"
          while IFS= read -r manifest; do
            cargo update --workspace --manifest-path "$manifest"
          done <<< "$manifests"''')
p.write_text(text)
p=root/'rust/tests/web/issue-1169-dependencies-latest-workflow.test.mjs'
text=p.read_text()
assert text.count("position('run: cargo update --workspace')")==1
p.write_text(text.replace("position('run: cargo update --workspace')",'''position('cargo update --workspace --manifest-path "$manifest"')'''))
print(json.dumps({'drafted':True,'activeCargo':policy['activeCargo'],'nativeExecuted':False,'independentAuthorshipCredit':0}))
