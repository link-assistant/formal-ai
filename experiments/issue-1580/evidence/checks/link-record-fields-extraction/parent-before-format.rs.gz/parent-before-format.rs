//! Swappable Links Notation and link-cli storage boundary.
//!
//! Default native builds embed link-cli's file-mapped `doublets-rs` store and
//! transaction-recovery log through the `doublets-native` feature. The
//! human-reviewable `.lino` memory and bundle formats remain the deterministic
//! export/import projection, and native callers can still compile with
//! `--no-default-features` to use the [`crate::memory::MemoryStore`] Links
//! Notation projection directly. Browser builds expose the same shape via the
//! `IndexedDB` mirror in `js/memory.js`.

#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
use std::collections::BTreeMap;
use std::error::Error;
use std::fmt;
use std::path::{Path, PathBuf};
#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
use std::sync::atomic::{AtomicU64, Ordering};

use lino_objects_codec::format::parse_indented;

use crate::engine::{KNOWLEDGE_SCHEMA_VERSION, stable_id};
use crate::memory::{BUNDLE_HEADER, MemoryEvent, MemoryStore, ROOT_HEADER, import_full_memory};

/// A single doublet edge in the canonical `from -> to` projection.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DoubletLink {
    pub index: String,
    pub from: String,
    pub to: String,
}

/// One content-addressed record and its reducible doublet projection.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LinkRecord {
    pub stable_id: String,
    pub schema_version: String,
    pub record_type: String,
    pub source_id: String,
    pub links: Vec<DoubletLink>,
}

/// Physical backend selected for a build or surface.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LinkStoreBackend {
    LinoProjection,
    LinkCli,
    DoubletsWeb,
}

/// Import or backend failure for a link store.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum LinkStoreError {
    IllFormedLinksNotation(String),
    Backend(String),
}

impl fmt::Display for LinkStoreError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::IllFormedLinksNotation(message) => {
                write!(formatter, "ill-formed Links Notation: {message}")
            }
            Self::Backend(message) => write!(formatter, "link-store backend error: {message}"),
        }
    }
}

impl Error for LinkStoreError {}

#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
mod node_addresses;
#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
mod orphans;
#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
mod projection_sync;
#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
mod staging;
mod record_fields;
use record_fields::{
    canonical_memory_event, ensure_event_id, event_source_id, push_doublet, push_optional_field,
};
mod validation;

#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
pub use projection_sync::synchronize_memory_events;

#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
use node_addresses::{node_address_path, read_node_addresses};
#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
use staging::{
    cleanup_link_cli_files, link_cli_debug_enabled, replace_file, replacement_path,
    stage_without_per_entry_sync,
};
use validation::validate_demo_memory_document;

/// Store abstraction used by memory and event-log projections.
pub trait LinkStore {
    /// Returns the active physical backend.
    fn backend(&self) -> LinkStoreBackend;

    /// Append a memory event and return the stable record id assigned to it.
    fn append_memory_event(&mut self, event: MemoryEvent) -> Result<String, LinkStoreError>;

    /// Strictly import a `.lino` memory or bundle document.
    fn import_memory_links_notation(&mut self, text: &str) -> Result<usize, LinkStoreError>;

    /// Export the current memory projection as Links Notation.
    fn export_memory_links_notation(&self) -> String;

    /// Return every stored record as doublet-reducible metadata.
    fn records(&self) -> Vec<LinkRecord>;
}

/// Select the backend implied by this build.
#[must_use]
pub const fn selected_link_store_backend() -> LinkStoreBackend {
    if cfg!(target_arch = "wasm32") {
        LinkStoreBackend::DoubletsWeb
    } else if cfg!(feature = "doublets-native") {
        LinkStoreBackend::LinkCli
    } else {
        LinkStoreBackend::LinoProjection
    }
}

#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
pub type DefaultNativeLinkStore = LinkCliLinkStore;

#[cfg(any(target_arch = "wasm32", not(feature = "doublets-native")))]
pub type DefaultNativeLinkStore = MemoryStore;

/// Create the default Rust-side link store for this build.
///
/// Native default builds return `LinkCliLinkStore`. Builds compiled with
/// `--no-default-features` keep the explicit `.lino` projection fallback.
pub fn default_native_link_store() -> Result<DefaultNativeLinkStore, LinkStoreError> {
    #[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
    {
        LinkCliLinkStore::new()
    }

    #[cfg(any(target_arch = "wasm32", not(feature = "doublets-native")))]
    {
        Ok(MemoryStore::new())
    }
}

/// Validate that a memory import is a syntactically valid supported `.lino`
/// document before mutating the store.
pub fn validate_memory_links_notation(text: &str) -> Result<(), LinkStoreError> {
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return Err(LinkStoreError::IllFormedLinksNotation(String::from(
            "document is empty",
        )));
    }
    parse_indented(trimmed)
        .map_err(|error| LinkStoreError::IllFormedLinksNotation(format!("{error:?}")))?;
    let header = trimmed.lines().find(|line| !line.trim().is_empty());
    match header.map(str::trim) {
        Some(ROOT_HEADER) => validate_demo_memory_document(trimmed),
        Some(BUNDLE_HEADER) => Ok(()),
        Some(other) => Err(LinkStoreError::IllFormedLinksNotation(format!(
            "expected {ROOT_HEADER} or {BUNDLE_HEADER}, got {other}"
        ))),
        None => Err(LinkStoreError::IllFormedLinksNotation(String::from(
            "document is empty",
        ))),
    }
}

/// Project memory events into content-addressed records.
#[must_use]
pub fn memory_events_to_link_records(events: &[MemoryEvent]) -> Vec<LinkRecord> {
    events
        .iter()
        .enumerate()
        .map(|(index, event)| memory_event_to_link_record(event, index))
        .collect()
}

/// Project one memory event into a `Type -> SubType -> Value` doublet graph.
#[must_use]
pub fn memory_event_to_link_record(event: &MemoryEvent, sequence: usize) -> LinkRecord {
    let canonical = canonical_memory_event(event);
    let source_id = event_source_id(event, sequence, &canonical);
    let record_id = stable_id(
        "memory_event",
        &format!("{sequence}:{}:{canonical}", source_id.as_str()),
    );
    let subtype = event
        .kind
        .as_deref()
        .or(event.role.as_deref())
        .or(event.intent.as_deref())
        .unwrap_or("memory_event");

    let mut links = Vec::new();
    push_doublet(&mut links, &record_id, "Type");
    push_doublet(&mut links, "Type", "MemoryEvent");
    push_doublet(&mut links, "MemoryEvent", "SubType");
    push_doublet(&mut links, "SubType", subtype);
    push_doublet(&mut links, subtype, "Value");
    push_doublet(&mut links, &record_id, &source_id);
    push_doublet(
        &mut links,
        &record_id,
        &format!("schema_version:{KNOWLEDGE_SCHEMA_VERSION}"),
    );
    push_optional_field(&mut links, &record_id, "id", Some(source_id.as_str()));
    push_optional_field(&mut links, &record_id, "kind", event.kind.as_deref());
    push_optional_field(&mut links, &record_id, "role", event.role.as_deref());
    push_optional_field(&mut links, &record_id, "intent", event.intent.as_deref());
    push_optional_field(&mut links, &record_id, "tool", event.tool.as_deref());
    push_optional_field(&mut links, &record_id, "inputs", event.inputs.as_deref());
    push_optional_field(&mut links, &record_id, "outputs", event.outputs.as_deref());
    push_optional_field(&mut links, &record_id, "content", event.content.as_deref());
    push_optional_field(&mut links, &record_id, "sentAt", event.sent_at.as_deref());
    push_optional_field(
        &mut links,
        &record_id,
        "demoLabel",
        event.demo_label.as_deref(),
    );
    push_optional_field(
        &mut links,
        &record_id,
        "conversationId",
        event.conversation_id.as_deref(),
    );
    push_optional_field(
        &mut links,
        &record_id,
        "conversationTitle",
        event.conversation_title.as_deref(),
    );
    for evidence in &event.evidence {
        push_optional_field(&mut links, &record_id, "evidence", Some(evidence));
    }
    let access_count = event.access_count.to_string();
    if event.access_count > 0 {
        push_optional_field(&mut links, &record_id, "accessCount", Some(&access_count));
    }
    let write_count = event.write_count.max(1).to_string();
    push_optional_field(&mut links, &record_id, "writeCount", Some(&write_count));

    LinkRecord {
        stable_id: record_id,
        schema_version: String::from(KNOWLEDGE_SCHEMA_VERSION),
        record_type: String::from("MemoryEvent"),
        source_id,
        links,
    }
}

impl LinkStore for MemoryStore {
    fn backend(&self) -> LinkStoreBackend {
        LinkStoreBackend::LinoProjection
    }

    fn append_memory_event(&mut self, mut event: MemoryEvent) -> Result<String, LinkStoreError> {
        ensure_event_id(&mut event, self.len());
        let id = event.id.clone();
        self.append(event);
        Ok(id)
    }

    fn import_memory_links_notation(&mut self, text: &str) -> Result<usize, LinkStoreError> {
        validate_memory_links_notation(text)?;
        let parsed = import_full_memory(text);
        let count = parsed.events.len();
        for event in parsed.events {
            self.append_memory_event(event)?;
        }
        Ok(count)
    }

    fn export_memory_links_notation(&self) -> String {
        Self::export_links_notation(self)
    }

    fn records(&self) -> Vec<LinkRecord> {
        memory_events_to_link_records(self.events())
    }
}

impl MemoryStore {
    /// Strictly import a `.lino` memory document, rejecting malformed input.
    pub fn try_import_links_notation(&mut self, text: &str) -> Result<usize, LinkStoreError> {
        <Self as LinkStore>::import_memory_links_notation(self, text)
    }

    /// Strictly replace current memory from a `.lino` document.
    pub fn try_replace_from_links_notation(&mut self, text: &str) -> Result<(), LinkStoreError> {
        validate_memory_links_notation(text)?;
        let parsed = import_full_memory(text);
        let mut replacement = Self::new();
        for event in parsed.events {
            replacement.append_memory_event(event)?;
        }
        *self = replacement;
        Ok(())
    }

    /// Return the doublet-reducible projection of every memory event.
    #[must_use]
    pub fn link_records(&self) -> Vec<LinkRecord> {
        memory_events_to_link_records(self.events())
    }
}

#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
type NativeLinkCliStorage = link_cli::DoubletsStorage<usize, link_cli::FileMappedUnitStore<usize>>;

#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
type NativeLinkCliTransactions = link_cli::GenericTransactionsDecorator<
    usize,
    NativeLinkCliStorage,
    link_cli::FileTransitionLog,
>;

#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
#[derive(Clone)]
struct LinkStoreSnapshot {
    events: Vec<MemoryEvent>,
    records: Vec<LinkRecord>,
    nodes: BTreeMap<String, usize>,
}

/// Persistent native link-cli store used by Rust builds and the HTTP server.
///
/// The binary database is link-cli's file-mapped `doublets-rs` store. Every
/// mutation passes through `GenericTransactionsDecorator`, whose sidecar log
/// recovers an interrupted write on the next open. String-to-address mappings
/// and the reviewable events stay in memory because `.lino` is their portable
/// source projection; [`Self::replace_memory_events_transactionally`] rebuilds
/// the complete binary graph from that source in one transaction.
#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
pub struct LinkCliLinkStore {
    database: PathBuf,
    database_lock: Option<link_cli::FileLock>,
    events: Vec<MemoryEvent>,
    records: Vec<LinkRecord>,
    nodes: BTreeMap<String, usize>,
    transactions: Option<NativeLinkCliTransactions>,
    transaction_snapshot: Option<LinkStoreSnapshot>,
    temporary_database: Option<PathBuf>,
}

/// Backwards-compatible name for embedders that used the pre-link-cli type.
#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
pub type DoubletsLinkStore = LinkCliLinkStore;

#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
impl LinkCliLinkStore {
    /// Create an empty temporary link-cli store.
    pub fn new() -> Result<Self, LinkStoreError> {
        static NEXT_TEMPORARY_STORE: AtomicU64 = AtomicU64::new(0);
        let sequence = NEXT_TEMPORARY_STORE.fetch_add(1, Ordering::Relaxed);
        let database = std::env::temp_dir().join(format!(
            "formal-ai-link-cli-{}-{sequence}.links",
            std::process::id()
        ));
        let mut store = Self::open_at(&database)?;
        store.temporary_database = Some(database);
        Ok(store)
    }

    /// Open or create a file-mapped link-cli database with an exclusive lock.
    pub fn open_at(database: &Path) -> Result<Self, LinkStoreError> {
        // Issue #1109: before taking the lock, collect what dead processes left.
        let swept = orphans::sweep_dead_replacements(database);
        if swept > 0 && link_cli_debug_enabled() {
            crate::diagnostic!("debug"; "[link-cli] removed {swept} orphaned replacement file(s)");
        }
        let database_lock = link_cli::FileLock::acquire(
            link_cli::lock_file_path(database),
            link_cli::LockMode::Exclusive,
        )
        .map_err(LinkStoreError::from)?;
        let transactions = open_link_cli_transactions(database)?;
        Ok(Self {
            database: database.to_path_buf(),
            database_lock: Some(database_lock),
            events: Vec::new(),
            records: Vec::new(),
            nodes: BTreeMap::new(),
            transactions: Some(transactions),
            transaction_snapshot: None,
            temporary_database: None,
        })
    }

    /// Build a temporary native store from a `.lino` memory or bundle document.
    pub fn from_links_notation(text: &str) -> Result<Self, LinkStoreError> {
        let mut store = Self::new()?;
        store.import_memory_links_notation(text)?;
        Ok(store)
    }

    /// Rebuild `database` from scratch so that `links` is its whole content.
    ///
    /// Issue #1085 (D1.2): the seed links network is mirrored this way beside
    /// the memory store when the server starts; the previous mirror is
    /// discarded first, so a restart never accumulates duplicates.
    ///
    /// # Errors
    ///
    /// Returns the backend error when the store cannot be opened or written.
    pub fn rebuild_with_doublets(
        database: &Path,
        links: &[DoubletLink],
    ) -> Result<Self, LinkStoreError> {
        cleanup_link_cli_files(database);
        let mut store = Self::open_at(database)?;
        store.begin_transaction()?;
        for link in links {
            if let Err(error) = store.append_native_doublet(&link.from, &link.to) {
                let _ = store.rollback_transaction();
                return Err(error);
            }
        }
        store.commit_transaction()?;
        Ok(store)
    }

    /// Return the imported or appended memory events in append order.
    #[must_use]
    pub fn events(&self) -> &[MemoryEvent] {
        &self.events
    }

    /// Number of memory events projected into link-cli.
    #[must_use]
    pub const fn len(&self) -> usize {
        self.events.len()
    }

    /// Whether this native store currently has no memory events.
    #[must_use]
    pub const fn is_empty(&self) -> bool {
        self.events.is_empty()
    }

    /// Number of raw native links, including point nodes.
    #[must_use]
    pub fn native_link_count(&self) -> usize {
        use link_cli::LinksStorage as _;
        self.transactions().inner().links_count()
    }

    /// Begin one explicit transaction spanning both the local projection and
    /// link-cli's binary store.
    pub fn begin_transaction(&mut self) -> Result<(), LinkStoreError> {
        if self.transaction_snapshot.is_some() {
            return Err(LinkStoreError::Backend(String::from(
                "nested link-cli transactions are not supported",
            )));
        }
        self.transactions_mut()
            .begin_transaction()
            .map_err(LinkStoreError::from)?;
        self.transaction_snapshot = Some(self.snapshot());
        Ok(())
    }

    /// Commit and `fsync` the current transaction and recovery log.
    pub fn commit_transaction(&mut self) -> Result<(), LinkStoreError> {
        self.transactions_mut()
            .commit()
            .map_err(LinkStoreError::from)?;
        self.transaction_snapshot = None;
        self.transactions_mut()
            .flush()
            .map_err(LinkStoreError::from)
    }

    /// Roll back the current transaction and restore its in-memory projection.
    pub fn rollback_transaction(&mut self) -> Result<(), LinkStoreError> {
        self.transactions_mut()
            .rollback()
            .map_err(LinkStoreError::from)?;
        if let Some(snapshot) = self.transaction_snapshot.take() {
            self.restore_snapshot(snapshot);
        }
        self.transactions_mut()
            .flush()
            .map_err(LinkStoreError::from)
    }

    /// Transactionally append events the open database does not yet hold.
    ///
    /// [`Self::replace_memory_events_transactionally`] rebuilds the whole graph,
    /// which is the right recovery behaviour when opening a database whose
    /// `.lino` source may be ahead of it. It is the wrong behaviour on the
    /// steady-state write path: issue #1106 measured a chat completion against a
    /// 400-event store taking 78 seconds, because every appended event rebuilt
    /// all 400 from scratch, and the cost grows with the square of the history.
    ///
    /// This method is that write path. The caller states how many leading events
    /// the database already holds; only the remainder is appended, inside one
    /// transaction whose rollback restores the in-memory projection. When the
    /// claim does not hold -- a shorter database, or a divergent prefix -- there
    /// is nothing to append onto, and the caller is told to rebuild instead.
    pub fn append_memory_events_transactionally(
        &mut self,
        events: &[MemoryEvent],
        already_projected: usize,
    ) -> Result<(), LinkStoreError> {
        if self.transaction_snapshot.is_some() {
            return Err(LinkStoreError::Backend(String::from(
                "cannot append memory inside an open link-cli transaction",
            )));
        }
        if already_projected > events.len() {
            return Err(LinkStoreError::Backend(String::from(
                "link-cli projection does not extend the recorded memory prefix",
            )));
        }
        if already_projected == events.len() {
            return Ok(());
        }
        // A freshly-opened store holds the database's doublets on disk but an
        // empty in-memory projection. Appending needs both: the sequence
        // numbers must continue past the prefix, and `node_id` must resolve a
        // string that the prefix already created to that same address rather
        // than minting a second one. Restoring those two maps writes nothing to
        // the database.
        if self.events.len() < already_projected {
            self.restore_projected_prefix(&events[..already_projected])?;
        } else if self.events.len() != already_projected {
            return Err(LinkStoreError::Backend(String::from(
                "link-cli projection does not extend the recorded memory prefix",
            )));
        }
        self.begin_transaction()?;
        for event in events[already_projected..].iter().cloned() {
            if let Err(error) = self.append_memory_event_in_open_transaction(event) {
                let rollback = self.rollback_transaction();
                return rollback.and(Err(error));
            }
        }
        self.commit_transaction()?;
        self.write_node_addresses()
    }

    /// Restore the in-memory maps for a prefix the database already stores.
    ///
    /// Only one thing here cannot be recomputed from the events: the
    /// string-to-address map, whose addresses were handed out by link-cli when
    /// the prefix was written. Recomputing it by replaying the prefix through a
    /// scratch database is what the first attempt at issue #1106 did, and it
    /// measured 46.8 seconds of a 47.2-second projection -- the whole rebuild,
    /// merely relocated. So the map is saved when the projection is written and
    /// read back here; the records and events, which are pure functions of the
    /// events, are still derived.
    ///
    /// A missing or unreadable sidecar is not an error. It means the addresses
    /// are unknown, and the caller falls back to a full rebuild.
    fn restore_projected_prefix(&mut self, prefix: &[MemoryEvent]) -> Result<(), LinkStoreError> {
        let nodes = read_node_addresses(&node_address_path(&self.database)).ok_or_else(|| {
            LinkStoreError::Backend(String::from(
                "link-cli node addresses are unavailable for the recorded prefix",
            ))
        })?;
        let mut events = Vec::with_capacity(prefix.len());
        let mut records = Vec::with_capacity(prefix.len());
        for (sequence, event) in prefix.iter().enumerate() {
            let mut event = event.clone();
            ensure_event_id(&mut event, sequence);
            records.push(memory_event_to_link_record(&event, sequence));
            events.push(event);
        }
        // Every string the prefix projected must have a recorded address; if one
        // is missing the sidecar does not describe this database, and appending
        // onto it would mint a second address for an existing node.
        for record in &records {
            for link in &record.links {
                if !nodes.contains_key(&link.from) || !nodes.contains_key(&link.to) {
                    return Err(LinkStoreError::Backend(String::from(
                        "link-cli node addresses do not cover the recorded prefix",
                    )));
                }
            }
        }
        self.events = events;
        self.records = records;
        self.nodes = nodes;
        Ok(())
    }

    /// Save the string-to-address map so a later append can resume from it.
    fn write_node_addresses(&self) -> Result<(), LinkStoreError> {
        let mut rendered = String::new();
        for (node, address) in &self.nodes {
            // Node strings are arbitrary content, and this format is line-based,
            // so newlines are escaped -- and the escape character with them,
            // without which a node containing a literal backslash-n would read
            // back as a newline.
            let encoded = node.replace('\\', "\\\\").replace('\n', "\\n");
            let _ = writeln!(rendered, "{address}\t{encoded}");
        }
        let path = node_address_path(&self.database);
        let temporary = replacement_path(&path, "nodes");
        std::fs::write(&temporary, rendered)
            .and_then(|()| replace_file(&temporary, &path))
            .map_err(|error| LinkStoreError::Backend(error.to_string()))
    }

    /// Transactionally build and atomically publish a complete replacement.
    ///
    /// This is the server synchronization boundary. Rebuilding makes the
    /// `.lino` projection a deterministic recovery source even if a previous
    /// process stopped between writing it and opening link-cli. Building a new
    /// graph instead of deleting the old graph also avoids invalidating the
    /// usage indexes that link-cli's underlying tree decorators maintain.
    pub fn replace_memory_events_transactionally(
        &mut self,
        events: &[MemoryEvent],
    ) -> Result<(), LinkStoreError> {
        if self.transaction_snapshot.is_some() {
            return Err(LinkStoreError::Backend(String::from(
                "cannot replace memory inside an open link-cli transaction",
            )));
        }
        let replacement_database = replacement_path(&self.database, "database");
        let replacement_log = server_link_transition_log_path(&replacement_database);
        cleanup_link_cli_files(&replacement_database);

        let mut replacement = match Self::open_at(&replacement_database) {
            Ok(replacement) => replacement,
            Err(error) => {
                cleanup_link_cli_files(&replacement_database);
                return Err(error);
            }
        };
        // The replacement is scratch until the rename below publishes it, so
        // its transitions do not need to be individually durable; one flush
        // before publishing gives the served path the same guarantee for a
        // fraction of the cost.
        if let Some(transactions) = replacement.transactions.as_mut() {
            stage_without_per_entry_sync(transactions);
        }
        if let Err(error) = replacement.begin_transaction() {
            drop(replacement);
            cleanup_link_cli_files(&replacement_database);
            return Err(error);
        }
        for event in events.iter().cloned() {
            if let Err(error) = replacement.append_memory_event_in_open_transaction(event) {
                let rollback = replacement.rollback_transaction();
                drop(replacement);
                cleanup_link_cli_files(&replacement_database);
                return rollback.and(Err(error));
            }
        }
        if let Err(error) = replacement.commit_transaction() {
            drop(replacement);
            cleanup_link_cli_files(&replacement_database);
            return Err(error);
        }
        if let Err(error) = replacement.flush_staged_log() {
            drop(replacement);
            cleanup_link_cli_files(&replacement_database);
            return Err(error);
        }
        let snapshot = replacement.snapshot();
        drop(replacement);

        // Close the old memory map while retaining the explicit sidecar lock.
        // Install the fully-applied recovery log first: either database is a
        // valid baseline for that log because it contains no pending replay.
        let _ = self.transactions.take();
        let replacement_result = replace_file(
            &replacement_log,
            &server_link_transition_log_path(&self.database),
        )
        .and_then(|()| replace_file(&replacement_database, &self.database))
        .map_err(|error| {
            let path = self.database.display().to_string();
            let detail = error.to_string();
            let message = crate::seed::render_response(
                "link-cli-publish-failed",
                "en",
                &[("path", &path), ("error", &detail)],
            )
            .unwrap_or_else(|| ["link-cli-publish-failed", &path, &detail].join(":"));
            LinkStoreError::Backend(message)
        });

        let reopen_result = open_link_cli_transactions(&self.database);
        cleanup_link_cli_files(&replacement_database);
        self.transactions = Some(reopen_result?);
        replacement_result?;
        self.restore_snapshot(snapshot);
        // Record the addresses this rebuild handed out, so the next write can
        // append onto it instead of rebuilding again (issue #1106).
        self.write_node_addresses()
    }

    /// `fsync` the staged transitions log once, before the replacement is
    /// published.
    ///
    /// Pairs with [`stage_without_per_entry_sync`]: the staged log skipped
    /// per-append syncing, so this is where its entries reach stable storage.
    /// Calling it on a log that already syncs every append is harmless.
    ///
    /// # Errors
    ///
    /// Returns the backend error when the log cannot be flushed.
    fn flush_staged_log(&mut self) -> Result<(), LinkStoreError> {
        use link_cli::TransitionLogStore as _;
        let Some(transactions) = self.transactions.as_mut() else {
            return Ok(());
        };
        transactions
            .log_store_mut()
            .flush_log()
            .map_err(LinkStoreError::from)
    }

    fn append_memory_event_in_open_transaction(
        &mut self,
        mut event: MemoryEvent,
    ) -> Result<String, LinkStoreError> {
        ensure_event_id(&mut event, self.events.len());
        let id = event.id.clone();
        let record = memory_event_to_link_record(&event, self.events.len());
        self.insert_record(record)?;
        self.events.push(event);
        Ok(id)
    }

    fn insert_record(&mut self, record: LinkRecord) -> Result<(), LinkStoreError> {
        for link in &record.links {
            self.append_native_doublet(&link.from, &link.to)?;
        }
        self.records.push(record);
        Ok(())
    }

    fn append_native_doublet(&mut self, from: &str, to: &str) -> Result<(), LinkStoreError> {
        let source = self.node_id(from)?;
        let target = self.node_id(to)?;
        self.transactions_mut()
            .create(source, target)
            .map_err(LinkStoreError::from)?;
        Ok(())
    }

    fn node_id(&mut self, node: &str) -> Result<usize, LinkStoreError> {
        if let Some(id) = self.nodes.get(node) {
            return Ok(*id);
        }
        let id = self
            .transactions_mut()
            .create(0, 0)
            .map_err(LinkStoreError::from)?;
        self.nodes.insert(node.to_owned(), id);
        Ok(id)
    }

    const fn transactions(&self) -> &NativeLinkCliTransactions {
        self.transactions
            .as_ref()
            .expect("link-cli transactions remain present until drop")
    }

    const fn transactions_mut(&mut self) -> &mut NativeLinkCliTransactions {
        self.transactions
            .as_mut()
            .expect("link-cli transactions remain present until drop")
    }

    fn snapshot(&self) -> LinkStoreSnapshot {
        LinkStoreSnapshot {
            events: self.events.clone(),
            records: self.records.clone(),
            nodes: self.nodes.clone(),
        }
    }

    fn restore_snapshot(&mut self, snapshot: LinkStoreSnapshot) {
        self.events = snapshot.events;
        self.records = snapshot.records;
        self.nodes = snapshot.nodes;
    }
}

#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
impl LinkStore for LinkCliLinkStore {
    fn backend(&self) -> LinkStoreBackend {
        LinkStoreBackend::LinkCli
    }

    fn append_memory_event(&mut self, event: MemoryEvent) -> Result<String, LinkStoreError> {
        let owns_transaction = self.transaction_snapshot.is_none();
        if owns_transaction {
            self.begin_transaction()?;
        }
        let result = self.append_memory_event_in_open_transaction(event);
        if !owns_transaction {
            return result;
        }
        match result {
            Ok(id) => {
                self.commit_transaction()?;
                Ok(id)
            }
            Err(error) => {
                let rollback = self.rollback_transaction();
                rollback.and(Err(error))
            }
        }
    }

    fn import_memory_links_notation(&mut self, text: &str) -> Result<usize, LinkStoreError> {
        validate_memory_links_notation(text)?;
        let parsed = import_full_memory(text);
        let count = parsed.events.len();
        self.begin_transaction()?;
        for event in parsed.events {
            if let Err(error) = self.append_memory_event_in_open_transaction(event) {
                let rollback = self.rollback_transaction();
                return rollback.and(Err(error));
            }
        }
        self.commit_transaction()?;
        Ok(count)
    }

    fn export_memory_links_notation(&self) -> String {
        crate::memory::export_links_notation(&self.events)
    }

    fn records(&self) -> Vec<LinkRecord> {
        self.records.clone()
    }
}

#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
impl Drop for LinkCliLinkStore {
    fn drop(&mut self) {
        if self.transaction_snapshot.is_some() {
            let _ = self.rollback_transaction();
        }
        let _ = self.transactions.take();
        let _ = self.database_lock.take();
        let Some(database) = self.temporary_database.take() else {
            return;
        };
        let _ = std::fs::remove_file(server_link_transition_log_path(&database));
        let _ = std::fs::remove_file(link_cli::lock_file_path(&database));
        let _ = std::fs::remove_file(database);
    }
}

/// Conventional transition-log path used by the embedded link-cli store.
#[must_use]
pub fn server_link_transition_log_path(database: &Path) -> PathBuf {
    let stem = database
        .file_stem()
        .and_then(|name| name.to_str())
        .unwrap_or_default();
    let filename = format!("{stem}.transitions.links");
    database
        .parent()
        .filter(|parent| !parent.as_os_str().is_empty())
        .map_or_else(|| PathBuf::from(&filename), |parent| parent.join(&filename))
}

#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
impl From<link_cli::LinkError> for LinkStoreError {
    fn from(error: link_cli::LinkError) -> Self {
        Self::Backend(error.to_string())
    }
}

#[cfg(all(not(target_arch = "wasm32"), feature = "doublets-native"))]
fn open_link_cli_transactions(
    database: &Path,
) -> Result<NativeLinkCliTransactions, LinkStoreError> {
    let storage = NativeLinkCliStorage::open(database).map_err(LinkStoreError::from)?;
    let transition_log =
        link_cli::FileTransitionLog::open(server_link_transition_log_path(database))
            .map_err(LinkStoreError::from)?;
    link_cli::GenericTransactionsDecorator::new(
        storage,
        transition_log,
        link_cli::LogRetentionPolicy::default(),
        link_cli::CommitMode::Sync,
        link_cli_debug_enabled(),
    )
    .map_err(LinkStoreError::from)
}
