`scripts/create-github-release.rs` writes the complete JSON request to a piped
`gh` stdin before it starts draining the child's piped stdout and stderr. A
child that fills either output pipe before reading the request can block with
the parent indefinitely: the parent waits for stdin capacity, and the child
waits for output capacity. Capping release notes does not remove this cycle.

The ordering is visible at [lines 322–345 of the reviewed source](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/blob/260ae6f826d6bff0cbfe2280098c287a4c09b3f4/scripts/create-github-release.rs#L322).

A bounded POSIX reproduction needs no GitHub credentials or release writes:

1. Substitute a `gh` fixture that writes 131,072 bytes to stdout, then reads
   stdin. Repeat with stderr instead of stdout.
2. Supply a release payload larger than the stdin pipe capacity.
3. Run the actual release creator under a two-second process-group deadline.
   Kill and reap the process group on expiry. Both streams must remain finite.
4. The existing write-then-drain ordering can deadlock. Concurrent request
   writing and output draining should finish and preserve the complete payload,
   stdout, stderr and exit status.

Related work is in [Formal AI PR #1581](https://github.com/link-assistant/formal-ai/pull/1581).
Its local bounded OS-pipe controls reproduce the sequential/concurrent
distinction. Those local controls execute Python processes; they do not claim
execution of this template's Rust binary. The compiled regression harness for
Formal AI is awaiting hosted CI.

Please drain both output streams while the request is written, close stdin at
EOF, wait for the child and join the writer. Preserve request-write failures
instead of treating a success or duplicate diagnostic as proof that the
complete request was delivered. Add finite tests for stdout and stderr before
stdin, a child closing stdin early, and an unchanged short request.
