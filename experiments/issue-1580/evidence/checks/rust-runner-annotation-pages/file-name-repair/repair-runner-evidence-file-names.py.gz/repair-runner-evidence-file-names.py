from pathlib import Path
import gzip,hashlib,json,os,re,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'rust-runner-annotation-validation';target=root/'experiments/issue-1580/evidence/checks/rust-runner-annotation-pages'
ledger=target/'records.jsonl';rows=[json.loads(line) for line in ledger.read_text().splitlines()];renames=[]
for row in rows:
    before=target/row['file'];name=re.sub(r'-pr(?=[-.])','-pull-request',before.name)
    if name!=before.name:
        after=before.with_name(name);assert not after.exists();before.rename(after);renames.append({'from':row['file'],'to':str(after.relative_to(target))});row['file']=str(after.relative_to(target))
assert len(renames)==11,renames
(out/'evidence-renames.json').write_text(json.dumps(renames,indent=2)+'\n')
for path in [out/'final-naming.stdout',out/'final-naming.stderr',out/'evidence-renames.json',scratch/'commit-rust-runner-annotation-replay.log',scratch/'repair-runner-evidence-file-names.py']:
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);alias='file-name-repair/'+path.name+'.gz';destination=target/alias;destination.parent.mkdir(exist_ok=True);assert not destination.exists();destination.write_bytes(packed);rows.append({'source':str(path),'file':alias,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
ledger.write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in rows))
for row in rows:
    packed=(target/row['file']).read_bytes();raw=gzip.decompress(packed);assert hashlib.sha256(packed).hexdigest()==row['archiveSha256'];assert hashlib.sha256(raw).hexdigest()==row['rawSha256'];assert len(raw)==row['bytes'];assert len(raw.splitlines())==row['lines']
note=root/'docs/case-studies/issue-1580/rust-runner-annotation-pages-checkpoint.md';source=note.read_text().replace('Its published body was fetched again and compared with the exact draft.','Its published body was fetched again and compared with the exact draft. The\nfirst final naming check rejected eleven abbreviated evidence filenames; full\nEnglish renames preserve all archived bytes and the failed check is retained.');note.write_text(source)
subprocess.run(['git','add','--',str(target.relative_to(root)),str(note.relative_to(root))],cwd=root,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=root).decode().split('\0')[:-1];assert not any('/evidence/ci/' in path for path in staged)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
for name,args in [('renamed-naming',['node','scripts/measure-abbreviations.mjs','--check']),('final-secrets',['bash','scripts/check-secrets.sh',*staged]),('final-whitespace',['git','diff','--cached','--check'])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    assert result.returncode==0,name
with (out/'commit.stdout').open('wb') as stdout,(out/'commit.stderr').open('wb') as stderr:subprocess.run(['git','-c','gc.auto=0','commit','-m','Reproduce upstream runner annotation pagination false negatives'],cwd=root,stdout=stdout,stderr=stderr,check=True)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root,text=True)
result={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'committed':True,'pushed':False,'records':len(rows),'trackedWorkingTreeClean':True,'fullIssueComplete':False};(out/'commit-outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
