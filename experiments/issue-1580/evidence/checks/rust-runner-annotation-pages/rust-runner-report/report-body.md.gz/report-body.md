`scripts/unacquired-jobs.py` at commit `5f1e7a96acbf7a93b567195443cf6e5158fbbf1f` paginates workflow jobs, but its check-run annotation request at line 88 reads only the default first page. A structurally unstarted job whose runner-acquisition message appears after the first 30 annotations is therefore omitted by `fetch_unacquired`.

This is a controlled false-negative reproduction in the recovery added by #227, rather than evidence that any particular live run exhausted hosted capacity. The required conjunction of a finished failure/cancellation, no runner, no steps and an acquisition annotation should remain intact.

After checking out the pinned commit, run this finite offline example from the repository root. It performs no network calls or reruns:

```python
import importlib.util

spec = importlib.util.spec_from_file_location('recovery', 'scripts/unacquired-jobs.py')
recovery = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recovery)
job = {'id': 314, 'name': 'native-tests', 'conclusion': 'failure',
       'runner_name': '', 'steps': []}
messages = [{'message': 'unrelated diagnostic'} for _ in range(101)]
messages[100] = {'message': 'The job was not acquired by Runner of type hosted even after multiple attempts'}

def fake_gh_json(*args):
    endpoint = args[-1]
    if '/jobs?' in endpoint:
        return [{'jobs': [job]}]
    assert '/annotations' in endpoint
    size = 100 if 'per_page=100' in endpoint else 30
    if '--paginate' in args:
        assert '--slurp' in args
        return [messages[i:i + size] for i in range(0, len(messages), size)]
    return messages[:size]

recovery.gh_json = fake_gh_json
assert recovery.fetch_unacquired('example/repository', 81, 1) == ['native-tests']
```

Observed: the assertion fails because the helper returns `[]`. Expected: it returns `['native-tests']` after inspecting all annotation pages. A message at zero-based position 30 also reproduces the default-page boundary; position 100 checks that increasing `per_page` alone would not repair the issue.

The following candidate passes both boundaries while retaining the existing structural checks:

```diff
-            found = gh_json('api', f"repos/{repository}/check-runs/{job['id']}/annotations")
-            annotations[job['id']] = [item.get('message', '') for item in found or []]
+            pages = gh_json('api', '--paginate', '--slurp',
+                            f"repos/{repository}/check-runs/{job['id']}/annotations?per_page=100")
+            found = [item for page in pages or [] for item in page]
+            annotations[job['id']] = [item.get('message', '') for item in found]
```

Found while auditing https://github.com/link-assistant/formal-ai/issues/1580 in https://github.com/link-assistant/formal-ai/pull/1581. A pinned fixture and six-case maintained replay cover first annotation, position 29, position 30, position 100, absent acquisition message and a real code failure. All six candidate cases pass; disabling candidate pagination makes five checks fail, while the real code failure remains excluded. The full maintained observation entry passes 151 cases. These are offline candidate results; upstream production adoption and complete downstream issue acceptance remain unfinished.
