from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/rust-runner-report');validation=Path('/tmp/issue-1580-research/rust-runner-annotation-validation')
assert json.loads((validation/'outcome.json').read_text())['complete']
assert '# pass 151\n# fail 0' in (validation/'maintained.stdout').read_text()
assert '# pass 1\n# fail 5' in (validation/'negative-control.stdout').read_text()
body=out/'report-body.md';raw=body.read_bytes()
for name,args in [('current-main',['gh','api','repos/link-foundation/rust-ai-driven-development-pipeline-template/commits/main','--jq','.sha']),('create-report',['gh','issue','create','--repo','link-foundation/rust-ai-driven-development-pipeline-template','--title','Runner recovery misses acquisition annotations beyond the first API page','--body-file',str(body)])]:
    assert not (out/(name+'.stdout')).exists(),name
    result=subprocess.run(args,cwd=root,capture_output=True);(out/(name+'.stdout')).write_bytes(result.stdout);(out/(name+'.stderr')).write_bytes(result.stderr);assert result.returncode==0,(name,result.stderr.decode())
url=(out/'create-report.stdout').read_text().strip();assert url.startswith('https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/')
result={'url':url,'reportBodySha256':hashlib.sha256(raw).hexdigest(),'candidateVerified':True,'productionFixed':False,'independentAuthorshipCredit':0,'fullIssueComplete':False};(out/'publication.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
