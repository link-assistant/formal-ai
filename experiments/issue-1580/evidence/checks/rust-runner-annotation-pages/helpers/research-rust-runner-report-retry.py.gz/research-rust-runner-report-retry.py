from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/rust-runner-report');records=[]
tasks=[('pagination-retry',['gh','api','search/issues','--method','GET','--paginate','-f','q=repo:link-foundation/rust-ai-driven-development-pipeline-template pagination','-f','per_page=100']),('annotations-retry',['gh','api','search/issues','--method','GET','--paginate','-f','q=repo:link-foundation/rust-ai-driven-development-pipeline-template annotations','-f','per_page=100']),('related-merged',['gh','pr','list','--repo','link-foundation/rust-ai-driven-development-pipeline-template','--state','merged','--search','runner','--limit','10','--json','number,title,mergedAt,url'])]
for name,args in tasks:
    result=subprocess.run(args,cwd=root,capture_output=True);(out/(name+'.stdout')).write_bytes(result.stdout);(out/(name+'.stderr')).write_bytes(result.stderr);records.append({'name':name,'args':args,'exitCode':result.returncode});(out/'retry-commands.json').write_text(json.dumps(records,indent=2)+'\n');assert result.returncode==0,name
print(json.dumps({'complete':True,'records':len(records),'initialSearchInvalid':True}))
