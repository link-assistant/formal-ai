from pathlib import Path
import hashlib,json,os,subprocess,sys,traceback

root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/rust-runner-annotation-validation')
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:
        process=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':process.pid})+'\n')
    print(json.dumps({'pid':process.pid,'finite':True}));sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);records=[]
def run(name,args,extra=None,expected=0):
    process_env=env.copy();process_env.update(extra or {})
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        result=subprocess.run(args,cwd=root,env=process_env,stdout=stdout,stderr=stderr)
    row={'name':name,'args':args,'extraEnvironment':extra or {},'exitCode':result.returncode,'expectedExitCode':expected}
    records.append(row);(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert result.returncode==expected,name
try:
    fixture=root/'experiments/issue-1580/fixtures/rust-runner-recovery/unacquired-jobs.py'
    pin=json.loads(fixture.with_name('pin.json').read_text())
    assert hashlib.sha256(fixture.read_bytes()).hexdigest()==pin['sha256']
    file='experiments/issue-1580/template-rust-runner-annotations.test.mjs'
    args=['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',file]
    run('focused',args)
    run('negative-control',args,{'ISSUE_1580_DISABLE_ANNOTATION_PAGINATION':'1'},1)
    run('maintained',['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])
    run('touched-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size,check-file-size-js-twin'])
    run('whitespace',['git','diff','--check'])
    result={'complete':True,'candidateCasesPassed':6,'baselineCases':6,'upstreamProductionFixed':False,'nativeBuildRun':False,'independentAuthorshipCredit':0,'fullIssueComplete':False}
    (out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
