from pathlib import Path
import gzip,hashlib,json,os,subprocess

root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'rust-runner-annotation-validation';report=scratch/'rust-runner-report'
assert json.loads((out/'outcome.json').read_text())['complete']
published=json.loads((report/'publication.json').read_text())
result=subprocess.run(['gh','issue','view',published['url'],'--json','number,title,body,state,url'],cwd=root,capture_output=True)
(report/'published-verification.stdout').write_bytes(result.stdout);(report/'published-verification.stderr').write_bytes(result.stderr);assert result.returncode==0
remote=json.loads(result.stdout);assert remote['body'].strip()==(report/'report-body.md').read_text().strip();assert remote['url']==published['url']
target=root/'experiments/issue-1580/evidence/checks/rust-runner-annotation-pages';target.mkdir(exist_ok=False);records=[]
directories=[out,report,scratch/'rust-runner-annotation-pages']
helpers=['probe-rust-runner-annotation-pages.py','probe-rust-runner-annotation-pages.log','draft-rust-runner-annotation-regression.py','draft-rust-runner-annotation-regression.log','validate-rust-runner-annotations.py','validate-rust-runner-annotations.log','research-rust-runner-report.py','research-rust-runner-report.log','research-rust-runner-report-retry.py','research-rust-runner-report-retry.log','read-rust-runner-origin-pr.py','read-rust-runner-origin-pr.log','publish-rust-runner-report.py','publish-rust-runner-report.log','commit-rust-runner-annotation-replay.py']
paths=[path for directory in directories for path in sorted(directory.iterdir()) if path.is_file()]+[scratch/name for name in helpers]
for path in paths:
    assert path.is_file(),path
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);alias=(path.parent.name if path.parent in directories else 'helpers')+'/'+path.name+'.gz';destination=target/alias;destination.parent.mkdir(parents=True,exist_ok=True);assert not destination.exists();destination.write_bytes(packed);assert gzip.decompress(destination.read_bytes())==raw
    records.append({'source':str(path),'file':alias,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
summary={'upstreamIssue':published['url'],'pinnedCommit':'5f1e7a96acbf7a93b567195443cf6e5158fbbf1f','candidateCasesPassed':6,'negativeControlPassed':1,'negativeControlFailed':5,'maintainedCasesPassed':151,'productionFixed':False,'fullIssueComplete':False,'independentAuthorshipCredit':0};(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
note=root/'docs/case-studies/issue-1580/rust-runner-annotation-pages-checkpoint.md';note.write_text('''# Rust template runner annotation pagination

The current pinned upstream helper paginates workflow jobs but reads only the
first check-run annotation page. The finite offline replay uses 101 annotations
and places the acquisition message at positions 0, 29, 30 and 100. The original
helper misses positions 30 and 100. A candidate uses `--paginate --slurp` and
flattens every annotation page; all six cases pass, including missing-message
and actual-code-failure exclusions. Disabling pagination fails five checks and
keeps the actual-code-failure exclusion passing. No request reruns a real job.

The fixture is copied byte-for-byte from upstream commit
`5f1e7a96acbf7a93b567195443cf6e5158fbbf1f`, with its MIT license and SHA256.
The candidate is confined to the replay and is not an upstream production fix.
Issue #226, merged recovery PR #227 and all three PR feedback endpoints were
read. An initial malformed CLI search failed; corrected paginated searches and
the failed request remain retained. No pagination issue was found before filing
[upstream issue #257](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/257).
Its published body was fetched again and compared with the exact draft.

All 151 maintained observation cases, the six focused cases and three affected
JavaScript gates pass. No Rust build or live runner-capacity claim is made. The
current downstream queue is not explained by this controlled reproduction.
Full template equivalence, adoption, native qualification of pending local
refactors and complete issue acceptance remain unfinished. Supplied scripts,
patches and conclusions receive zero independent authorship or reasoning credit.

Evidence: `experiments/issue-1580/evidence/checks/rust-runner-annotation-pages/`.
''')
fragment=root/'changelog.d/issue-1580-rust-runner-annotation-pages.md';fragment.write_text('''---
bump: patch
---

Retain a pinned six-case upstream runner-recovery pagination replay, including
negative controls and exclusions for actual code failures.
''')
plan=root/'experiments/issue-1580/work-plan.md';source=plan.read_text();source=source.replace('hosted native compilation/execution of these local edits remains pending.','All 151 maintained cases pass after adding the six-case upstream annotation\npagination replay; its tested candidate is reported in Rust template issue #257.\nHosted native compilation/execution of these local edits remains pending.',1);source+='\n- Confirmed and reported Rust runner annotation pagination false negatives at positions 30 and 100: upstream issue #257. Six candidate cases, 151 maintained cases and three touched gates pass. Upstream production adoption remains unfinished. See [runner annotation checkpoint](../../docs/case-studies/issue-1580/rust-runner-annotation-pages-checkpoint.md).\n';plan.write_text(source)
paths=['experiments/issue-1580/fixtures/rust-runner-recovery','experiments/issue-1580/rust-runner-annotation-replay.py','experiments/issue-1580/template-rust-runner-annotations.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs',str(target.relative_to(root)),str(note.relative_to(root)),str(fragment.relative_to(root)),str(plan.relative_to(root))]
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=root).decode().split('\0')[:-1];assert not any('/evidence/ci/' in path for path in staged)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
for name,args in [('final-naming',['node','scripts/measure-abbreviations.mjs','--check']),('final-secrets',['bash','scripts/check-secrets.sh',*staged]),('final-whitespace',['git','diff','--cached','--check'])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:completed=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    assert completed.returncode==0,name
with (out/'commit.stdout').open('wb') as stdout,(out/'commit.stderr').open('wb') as stderr:subprocess.run(['git','-c','gc.auto=0','commit','-m','Reproduce upstream runner annotation pagination false negatives'],cwd=root,stdout=stdout,stderr=stderr,check=True)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root,text=True)
result={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'committed':True,'pushed':False,'records':len(records),'trackedWorkingTreeClean':True,'fullIssueComplete':False};(out/'commit-outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
