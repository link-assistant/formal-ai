from pathlib import Path
import hashlib,json,shutil

root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/rust-runner-annotation-pages');fixture=root/'experiments/issue-1580/fixtures/rust-runner-recovery';fixture.mkdir(exist_ok=False)
raw=(out/'unacquired-jobs.before.py').read_bytes();assert hashlib.sha256(raw).hexdigest()=='cc9acc34a63b60a7193132ea59215c22a9de38542720c3722d501a743227c076'
(fixture/'unacquired-jobs.py').write_bytes(raw)
license_path=Path('/tmp/issue-1580-research/templates/rust-complete/LICENSE');assert license_path.exists();shutil.copyfile(license_path,fixture/'LICENSE')
(fixture/'pin.json').write_text(json.dumps({'repository':'link-foundation/rust-ai-driven-development-pipeline-template','commit':'5f1e7a96acbf7a93b567195443cf6e5158fbbf1f','path':'scripts/unacquired-jobs.py','sha256':hashlib.sha256(raw).hexdigest(),'license':'LICENSE','purpose':'Read-only upstream classification reproduction; no production retry or publication'},indent=2)+'\n')
(root/'experiments/issue-1580/rust-runner-annotation-replay.py').write_text('''from pathlib import Path
import json,os,types

source=(Path(__file__).parent/'fixtures/rust-runner-recovery/unacquired-jobs.py').read_text()
old=\'''            found = gh_json('api', f"repos/{repository}/check-runs/{job['id']}/annotations")
            annotations[job['id']] = [item.get('message', '') for item in found or []]\'''
new=\'''            pages = gh_json('api', '--paginate', '--slurp',
                            f"repos/{repository}/check-runs/{job['id']}/annotations?per_page=100")
            found = [item for page in pages or [] for item in page]
            annotations[job['id']] = [item.get('message', '') for item in found]\'''
assert source.count(old)==1
candidate=source if os.environ.get('ISSUE_1580_DISABLE_ANNOTATION_PAGINATION')=='1' else source.replace(old,new)
results=[]
cases=[('first-annotation',0,'',[]),('default-page-boundary',29,'',[]),
       ('second-default-page',30,'',[]),('second-full-page',100,'',[]),
       ('no-acquisition-message',None,'',[]),
       ('actual-code-failure',100,'runner-1',[{'name':'test','conclusion':'failure'}])]
for implementation,text in [('baseline',source),('candidate',candidate)]:
    module=types.ModuleType('unacquired_'+implementation)
    exec(compile(text,'pinned-unacquired-jobs.py','exec'),module.__dict__)
    for label,position,runner,steps in cases:
        job={'id':314,'name':'native-tests','conclusion':'failure','runner_name':runner,'steps':steps}
        messages=[{'message':'unrelated diagnostic '+str(i)} for i in range(101)]
        if position is not None:messages[position]={'message':'The job was not acquired by Runner of type hosted even after multiple attempts'}
        calls=[]
        def fake(*args):
            calls.append(list(args));endpoint=args[-1]
            if '/jobs?' in endpoint:return [{'jobs':[job]}]
            assert '/annotations' in endpoint
            page_size=100 if 'per_page=100' in endpoint else 30
            if '--paginate' in args:
                assert '--slurp' in args
                return [messages[i:i+page_size] for i in range(0,len(messages),page_size)]
            return messages[:page_size]
        module.gh_json=fake
        names=module.fetch_unacquired('example/repository',81,1)
        results.append({'implementation':implementation,'case':label,'observed':names,'calls':calls})
print(json.dumps(results))
''')
(root/'experiments/issue-1580/template-rust-runner-annotations.test.mjs').write_text('''import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import test from 'node:test';
import {fileURLToPath} from 'node:url';

const directory = new URL('./', import.meta.url);
const pin = JSON.parse(readFileSync(new URL('fixtures/rust-runner-recovery/pin.json', directory), 'utf8'));
const source = readFileSync(new URL('fixtures/rust-runner-recovery/unacquired-jobs.py', directory));
assert.equal(createHash('sha256').update(source).digest('hex'), pin.sha256);
const run = spawnSync('python3', [fileURLToPath(new URL('rust-runner-annotation-replay.py', directory))],
  {encoding: 'utf8', maxBuffer: 65536});
assert.equal(run.status, 0, run.stderr);
const rows = JSON.parse(run.stdout);
for (const name of ['first-annotation', 'default-page-boundary', 'second-default-page',
  'second-full-page', 'no-acquisition-message', 'actual-code-failure']) {
  test('Rust upstream runner classification: ' + name, {timeout: 30000}, () => {
    const baseline = rows.find(row => row.implementation === 'baseline' && row.case === name);
    const candidate = rows.find(row => row.implementation === 'candidate' && row.case === name);
    assert(baseline && candidate);
    const recognized = !['no-acquisition-message', 'actual-code-failure'].includes(name);
    const expected = recognized ? ['native-tests'] : [];
    const missing = ['second-default-page', 'second-full-page'].includes(name);
    assert.deepEqual(baseline.observed, missing ? [] : expected);
    assert.deepEqual(candidate.observed, expected);
    if (name === 'actual-code-failure') {
      assert.equal(candidate.calls.length, 1, 'running code failures must not fetch acquisition annotations');
    } else {
      const request = candidate.calls.find(args => args.at(-1).includes('/annotations'));
      assert(request.includes('--paginate') && request.includes('--slurp'));
    }
  });
}
''')
entry=root/'rust/tests/web/issue-1580-template-observations.test.mjs';source=entry.read_text();assert 'template-rust-runner-annotations' not in source;entry.write_text(source+"import '../../../experiments/issue-1580/template-rust-runner-annotations.test.mjs';\n")
print(json.dumps({'drafted':True,'cases':6,'upstreamProductionFixed':False,'independentAuthorshipCredit':0}))
