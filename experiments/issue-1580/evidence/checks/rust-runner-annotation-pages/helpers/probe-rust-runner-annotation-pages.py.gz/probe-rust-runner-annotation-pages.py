from pathlib import Path
import base64,hashlib,json,subprocess,types

root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/rust-runner-annotation-pages');out.mkdir(exist_ok=False)
repo='link-foundation/rust-ai-driven-development-pipeline-template';pin='5f1e7a96acbf7a93b567195443cf6e5158fbbf1f'
commands=[]
def gh(name,args):
    result=subprocess.run(['gh',*args],cwd=root,capture_output=True)
    (out/(name+'.stdout')).write_bytes(result.stdout);(out/(name+'.stderr')).write_bytes(result.stderr)
    commands.append({'name':name,'args':['gh',*args],'exitCode':result.returncode});(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');assert result.returncode==0,name
    return json.loads(result.stdout)
remote=gh('current-pinned-helper',['api',f'repos/{repo}/contents/scripts/unacquired-jobs.py?ref={pin}'])
raw=base64.b64decode(remote['content']);source=raw.decode();(out/'unacquired-jobs.before.py').write_bytes(raw)
previous=(Path('/tmp/issue-1580-research/templates/rust-complete/scripts/unacquired-jobs.py')).read_bytes()
assert raw==previous
gh('existing-reports',['api','--paginate','-X','GET','search/issues','-f',f'q=repo:{repo} annotation pagination','-f','per_page=100'])
old='''            found = gh_json('api', f"repos/{repository}/check-runs/{job['id']}/annotations")
            annotations[job['id']] = [item.get('message', '') for item in found or []]'''
new='''            pages = gh_json('api', '--paginate', '--slurp',
                            f"repos/{repository}/check-runs/{job['id']}/annotations?per_page=100")
            found = [item for page in pages or [] for item in page]
            annotations[job['id']] = [item.get('message', '') for item in found]'''
assert source.count(old)==1
candidate=source.replace(old,new);(out/'unacquired-jobs.candidate.py').write_text(candidate)
results=[]
for name,text in [('before',source),('candidate',candidate)]:
    module=types.ModuleType('unacquired_'+name);exec(compile(text,str(out/('unacquired-jobs.'+name+'.py')),'exec'),module.__dict__)
    for label,position,runner,steps in [('early-annotation',0,'',[]),('second-page-annotation',30,'',[]),('no-acquisition-message',None,'',[]),('actual-code-failure',30,'runner-1',[{'name':'test','conclusion':'failure'}])]:
        job={'id':314,'name':'native-tests','conclusion':'failure','runner_name':runner,'steps':steps};messages=[{'message':'unrelated diagnostic '+str(i)} for i in range(31)]
        if position is not None:messages[position]={'message':'The job was not acquired by Runner of type hosted even after multiple attempts'}
        calls=[]
        def fake(*args):
            calls.append(list(args));endpoint=args[-1]
            if '/jobs?' in endpoint:return [{'jobs':[job]}]
            assert '/annotations' in endpoint
            return [messages[:30],messages[30:]] if '--paginate' in args else messages[:30]
        module.gh_json=fake
        names=module.fetch_unacquired('example/repository',81,1)
        expected=['native-tests'] if label in ['early-annotation','second-page-annotation'] else []
        results.append({'implementation':name,'case':label,'observed':names,'expected':expected,'matchesExpected':names==expected,'calls':calls})
assert [r['case'] for r in results if not r['matchesExpected']]==['second-page-annotation']
summary={'repository':repo,'sourceCommit':pin,'sourceSha256':hashlib.sha256(raw).hexdigest(),'unchangedFromEarlierReviewedSource':True,'controlledCases':results,'candidatePasses':4,'baselineFalseNegatives':1,'githubRunnerFailureObserved':False,'upstreamProductionFixed':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'reproduced':True,'baselineFalseNegatives':1,'candidatePasses':4,'upstreamProductionFixed':False}))
