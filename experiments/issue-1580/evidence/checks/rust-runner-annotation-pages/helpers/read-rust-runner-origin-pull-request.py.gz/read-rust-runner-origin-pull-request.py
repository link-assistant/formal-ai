from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/rust-runner-report');records=[]
tasks=[('origin-pr',['gh','pr','view','227','--repo','link-foundation/rust-ai-driven-development-pipeline-template','--json','number,title,body,mergedAt,url']),('origin-pr-conversation',['gh','api','repos/link-foundation/rust-ai-driven-development-pipeline-template/issues/227/comments','--paginate']),('origin-pr-inline',['gh','api','repos/link-foundation/rust-ai-driven-development-pipeline-template/pulls/227/comments','--paginate']),('origin-pr-reviews',['gh','api','repos/link-foundation/rust-ai-driven-development-pipeline-template/pulls/227/reviews','--paginate'])]
for name,args in tasks:
    result=subprocess.run(args,cwd=root,capture_output=True);(out/(name+'.stdout')).write_bytes(result.stdout);(out/(name+'.stderr')).write_bytes(result.stderr);records.append({'name':name,'args':args,'exitCode':result.returncode});(out/'origin-pr-commands.json').write_text(json.dumps(records,indent=2)+'\n');assert result.returncode==0,name
print(json.dumps({'complete':True,'records':len(records)}))
