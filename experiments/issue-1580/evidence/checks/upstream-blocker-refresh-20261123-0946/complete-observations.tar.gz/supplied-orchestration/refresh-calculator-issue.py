from pathlib import Path
import subprocess,json,datetime
r=Path('/tmp/issue-1580-research/upstream-refresh-20261123-0950')
p=subprocess.run(['gh','api','repos/link-assistant/calculator/issues/265'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(r/'calculator-jiff-issue.stdout.json').write_bytes(p.stdout)
(r/'calculator-jiff-issue.stderr.txt').write_bytes(p.stderr)
p.check_returncode()
d=json.loads(p.stdout)
print(json.dumps({k:d.get(k) for k in ['state','updated_at','html_url','title','body']},indent=2))
p=subprocess.run(['gh','api','repos/link-assistant/calculator/issues/265/comments','--paginate','--slurp'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(r/'calculator-jiff-comments.stdout.json').write_bytes(p.stdout)
(r/'calculator-jiff-comments.stderr.txt').write_bytes(p.stderr)
p.check_returncode()
print(p.stdout.decode())
