from pathlib import Path
import subprocess,json,datetime
r=Path('/tmp/issue-1580-research/upstream-refresh-20261123-0950')
items={}
for name,endpoint in [('command-stream-jiff-corrected','repos/link-foundation/command-stream/pulls/240'),('calculator-jiff-corrected','repos/link-assistant/calculator/pulls/265')]:
 p=subprocess.run(['gh','api',endpoint],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (r/(name+'.stdout.json')).write_bytes(p.stdout)
 (r/(name+'.stderr.txt')).write_bytes(p.stderr)
 if p.returncode: items[name]={'exitCode':p.returncode};continue
 d=json.loads(p.stdout)
 items[name]={key:d.get(key) for key in ['state','merged','merged_at','updated_at','html_url','body']}
(r/'corrected-summary.json').write_text(json.dumps({'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'initialWrongRepositoryLookupsHaveNoVerificationCredit':True,'observations':items},indent=2)+'\n')
print((r/'corrected-summary.json').read_text())
