from pathlib import Path
import subprocess,json,datetime,urllib.request
r=Path('/tmp/issue-1580-research/upstream-refresh-20261123-0950')
r.mkdir(exist_ok=False)
items={}
for name,endpoint in [
('command-stream-jiff','repos/link-assistant/command-stream/pulls/240'),
('calculator-jiff','repos/link-assistant/link-calculator/pulls/265'),
('codeql-contexts','repos/github/codeql/issues/23198'),
('hive-serving-identity','repos/link-assistant/hive-mind/issues/3909'),
('main','repos/link-assistant/formal-ai/commits/main')]:
    result=subprocess.run(['gh','api',endpoint],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (r/(name+'.stdout.json')).write_bytes(result.stdout)
    (r/(name+'.stderr.txt')).write_bytes(result.stderr)
    if result.returncode: items[name]={'exitCode':result.returncode};continue
    data=json.loads(result.stdout)
    items[name]={key:data.get(key) for key in ['state','merged','merged_at','updated_at','html_url','sha']}
for crate in ['command-stream','link-calculator']:
    try:
        with urllib.request.urlopen(urllib.request.Request('https://crates.io/api/v1/crates/'+crate,headers={'User-Agent':'formal-ai-issue-1580-read-only-research'})) as response: body=response.read()
        (r/(crate+'.crate.json')).write_bytes(body)
        data=json.loads(body)
        items[crate+'-published']={key:data['crate'].get(key) for key in ['max_version','newest_version','updated_at']}
    except Exception as error: items[crate+'-published']={'error':str(error)}
(r/'summary.json').write_text(json.dumps({'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observations':items},indent=2)+'\n')
print((r/'summary.json').read_text())
