from pathlib import Path
import gzip, hashlib, json, shutil

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
sealed = scratch / 'sealed-macro-observation-batch-corrected'
result = json.loads((sealed / 'outcome.json').read_text())
assert result['passed'] and result['complete']
selected = json.loads((sealed / 'staged-selection.json').read_text())
assert len(selected) == 631
for row in selected:
    raw = (root / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
for name in ('check-abbreviations', 'check-file-size-js-twin', 'check-file-size', 'evidence-check-1'):
    source = root / 'experiments/formal_ai_subagent/sandboxes/gates' / (name + '.log')
    if source.is_file():
        shutil.copyfile(source, sealed / (name + '.detailed.log'))
base = root / 'experiments/issue-1580/evidence/checks/macro-observation-batch-seal'
base.mkdir(exist_ok=False)
records = []
def capture(name, path):
    raw = path.read_bytes(); packed = gzip.compress(raw, mtime=0)
    target = base / (name + '.gz'); target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(packed)
    assert gzip.decompress(packed) == raw
    records.append({'file': name + '.gz', 'rawSha256': hashlib.sha256(raw).hexdigest(),
                    'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
for folder in ['sealed-macro-observation-batch', 'sealed-macro-observation-batch-corrected']:
    for path in sorted((scratch / folder).rglob('*')):
        if path.is_file():
            capture(folder + '/' + path.relative_to(scratch / folder).as_posix(), path)
for stem in ['seal-next-repair-batch', 'seal-macro-observation-batch', 'seal-macro-observation-batch-corrected',
             'correct-macro-archive-paths', 'record-current-hosted-and-runtime-checkpoint',
             'document-terminal-bootstrap-head', 'archive-macro-batch-sealing']:
    for suffix in ['.py', '.log']:
        path = scratch / (stem + suffix)
        if path.is_file() and path.stat().st_size:
            capture('helpers/' + path.name, path)
(base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- Final macro/runtime evidence seal passes all four archive/naming/size gates, the exact 631-input compressed-content secret selection and staged whitespace. Preserve the initial six-name failure and its path-only correction with unchanged captured hashes; the 90-name ceiling remains unchanged. All three runtime failure controls and 42 focused passing groups are retained. Archive this seal, separately scan its newly added evidence and updated work plan, then commit and publish only after another empty current-head queue/main-ancestry check. Actual next-head query/runtime execution and all broader unfinished criteria remain required.\n')
body = scratch / 'macro-batch-publication/pull-request-body.md'
text = body.read_text()
needle = 'No local Rust/QL compilation runs.'
assert text.count(needle) == 1
text = text.replace(needle, needle + ' Four final archive/naming/size gates, the real engine on all 631 staged inputs and staged whitespace pass. Six archive filenames are spelled in full with all original/compressed bytes preserved and the unchanged naming ceiling; the initial failed gate is retained. Newly sealed evidence is separately scanned before the evidence commit.')
body.write_text(text)
print('Archived sealing records:', len(records), '; source selection verified:', len(selected), '; peak child KiB:', result['peakChildRssKiB'])
