from pathlib import Path
import hashlib, json, os, resource, subprocess, sys, time

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path(os.environ.get('SEALING_DIRECTORY', '/tmp/issue-1580-research/sealed-next-repair-batch'))
if len(sys.argv) == 1:
    base.mkdir(exist_ok=False)
    with (base / 'worker.log').open('wb') as stream:
        child = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root,
            stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    (base / 'pid').write_text(str(child.pid) + '\n')
    print('Started sequential sealing worker:', child.pid)
    sys.exit(0)

env = dict(os.environ)
env.pop('BASE_REF', None)
env['NODE_OPTIONS'] = '--max-old-space-size=256'
rows = []
def run(name, argv):
    start = time.monotonic()
    with (base / (name + '.stdout')).open('wb') as out, (base / (name + '.stderr')).open('wb') as err:
        result = subprocess.run(argv, cwd=root, env=env, stdout=out, stderr=err)
    rows.append({'name':name, 'argv':argv, 'exitCode':result.returncode,
        'seconds':round(time.monotonic()-start,3)})
    print(name, result.returncode, rows[-1]['seconds'], flush=True)
    if result.returncode:
        raise RuntimeError(name + ' failed')
try:
    branch = subprocess.check_output(['git','branch','--show-current'], cwd=root, text=True).strip()
    assert branch == 'issue-1580-8d61a32a61e1'
    run('stage', ['git','add','--all'])
    selected = subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=ACMRT','-z'],cwd=root)
    paths = [x.decode() for x in selected.split(b'\0') if x]
    (base/'staged-selection.json').write_text(json.dumps([{'path':p,
        'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest(), 'bytes':(root/p).stat().st_size}
        for p in paths],indent=2)+'\n')
    print('Exact staged paths:', len(paths), flush=True)
    run('gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only',
        'check-abbreviations,check-file-size-js-twin,check-file-size,evidence-check#1'])
    run('secrets',['bash','scripts/check-secrets.sh', *paths])
    run('whitespace',['git','diff','--cached','--check'])
finally:
    (base/'outcome.json').write_text(json.dumps({'complete':len(rows)==4,
        'passed':len(rows)==4 and all(x['exitCode']==0 for x in rows), 'commands':rows,
        'peakChildRssKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
        'localRustExecution':False,'independentReasoningCredit':0},indent=2)+'\n')
