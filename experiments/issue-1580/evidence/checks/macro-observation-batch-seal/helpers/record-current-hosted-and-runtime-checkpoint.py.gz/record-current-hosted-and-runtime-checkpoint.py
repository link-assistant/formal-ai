from pathlib import Path
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
build = json.loads((root / 'experiments/issue-1580/evidence/ci/buildkit-bootstrap-3bb3083b/assessment.json').read_text())
assert build['artifactStreamsVerified'] == 25 and build['actualCanonicalPullFailureCount'] == 1
assert len(build['observations']) == 2 and all(row['actualDockerBootVerified'] for row in build['observations'])
review = json.loads((root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json').read_text())
assert len(review['files']) == 309
checkpoint = root / 'docs/case-studies/issue-1580/buildkit-bootstrap-identity-checkpoint.md'
text = checkpoint.read_text().replace('Actual hosted daemon startup and\nmirror recovery remain pending on the next published commit; local adapter\npasses do not grant that credit.', 'Actual hosted daemon startup and\nmirror recovery are now verified on published head 3bb3083b, as recorded below.\nLocal adapter passes alone do not grant that credit.')
text += '''

## Actual hosted observation on 3bb3083b

[Workflows run 44764893157](https://github.com/link-assistant/formal-ai/actions/runs/44764893157)
boots two real BuildKit v0.35.1 daemons. The first uses the canonical immutable
image; the second follows one deliberately failed canonical pull and executes
the official setup action with the mirror image at the identical digest. Both
actual containers are running and bind to the same image ID
`sha256:d0ff8587a88d8adf2744704927bc567a23f4e8a1f4e732b579d673623a8a0fb2`.
RepoDigests, selected container image, builder identity and successful Docker
inspection commands are verified against all 25 original artifact streams.

The tested merge is `4ed185a09e8afaa07a949b0b71cb69e5ccca4deb`, whose parents
include published head `3bb3083ba9d91dbb3b45386083875a1adb9a92f2`. The wrapper,
workflow and probe bytes match that published source exactly. Original and
compressed hashes, source binding and the initial paginated-response assessment
failure followed by the corrected Git commit endpoint are retained under
`experiments/issue-1580/evidence/ci/buildkit-bootstrap-3bb3083b/`.

This verifies daemon bootstrap and recovery only. Application image builds,
publication and runtime on every advertised architecture remain unverified.
'''
checkpoint.write_text(text)
checkpoint = root / 'docs/case-studies/issue-1580/macro-observation-and-runtime-budget-checkpoint.md'
checkpoint.write_text(checkpoint.read_text().replace('308/373 files and 36,982 literal lines;\n65 files', '309/373 files and 37,626 literal lines;\n64 files'))
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- Published 3bb3083b hosted BuildKit startup and actual mirror recovery are verified against two running containers, the same immutable image ID, all 25 original artifact streams and byte-identical merge/head sources. Original CodeQL extracts all 2,576 expected paths, including all 105 formerly context-free paths; the 631 informational macro records still lack semantic qualification. Two local atomic commits preserve three demonstrated runtime regressions and the default-off observer; query compilation and actual hosted rows remain pending. No application publication or broad completion credit.\n')

base = root / 'experiments/issue-1580/evidence/checks/current-hosted-and-runtime-repair-research'
base.mkdir(exist_ok=False)
records = []
def capture(name, path):
    raw = path.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    target = base / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(packed)
    assert gzip.decompress(packed) == raw
    records.append({'file': name + '.gz', 'rawSha256': hashlib.sha256(raw).hexdigest(),
                    'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
for folder in ['hosted-buildkit-3bb3083b', 'runtime-source-commits', 'macro-batch-feedback', 'native-finish-observation']:
    for path in sorted((scratch / folder).rglob('*')):
        if path.is_file():
            capture(folder + '/' + path.relative_to(scratch / folder).as_posix(), path)
for stem in ['collect-hosted-buildkit-result', 'verify-hosted-buildkit-evidence',
             'assess-next-security-reports-and-paths', 'record-rust-dependency-guide',
             'observe-native-finish-and-record-toml', 'document-macro-and-runtime-repairs',
             'prepare-runtime-source-commits', 'commit-runtime-source-step',
             'refresh-macro-batch-feedback', 'record-current-hosted-and-runtime-checkpoint']:
    for suffix in ['.py', '.log']:
        path = scratch / (stem + suffix)
        if path.is_file() and path.stat().st_size:
            capture('helpers/' + path.name, path)
for path in sorted(scratch.glob('commit-runtime-source-step-*.log')):
    capture('helpers/' + path.name, path)
(base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print('Archived supplied research records:', len(records), '; full issue remains unfinished')
