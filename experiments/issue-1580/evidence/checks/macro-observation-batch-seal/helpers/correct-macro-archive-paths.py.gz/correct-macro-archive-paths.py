from pathlib import Path
import gzip, hashlib, json, shutil

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
failed = scratch / 'sealed-macro-observation-batch'
for name in ('check-abbreviations', 'check-file-size-js-twin', 'check-file-size', 'evidence-check-1'):
    source = root / 'experiments/formal_ai_subagent/sandboxes/gates' / (name + '.log')
    if source.is_file():
        shutil.copyfile(source, failed / (name + '.detailed.log'))
shutil.copyfile(scratch / 'macro-abbreviation-list.txt', failed / 'abbreviation-list.txt')
base = root / 'experiments/issue-1580/evidence/checks/codeql-macro-source-investigation'
manifest = base / 'files.json'
rows = json.loads(manifest.read_text())
assert isinstance(rows, list)
renames = []
for row in rows:
    before = row['file']
    after = before.replace('element-impl.', 'element-implementation.').replace('init-action.', 'initialize-action.')
    if before == after:
        continue
    source, target = base / before, base / after
    packed = source.read_bytes()
    assert hashlib.sha256(packed).hexdigest() == row['archiveSha256']
    assert hashlib.sha256(gzip.decompress(packed)).hexdigest() == row['rawSha256']
    source.rename(target)
    assert target.read_bytes() == packed
    row['file'] = after
    renames.append({'before': before, 'after': after, 'originalBytesUnchanged': True})
assert len(renames) == 6
manifest.write_text(json.dumps(rows, indent=2) + '\n')
(base / 'path-only-correction.json').write_text(json.dumps(renames, indent=2) + '\n')
print('Spelled six archive filenames in full; all original and compressed bytes unchanged.')
