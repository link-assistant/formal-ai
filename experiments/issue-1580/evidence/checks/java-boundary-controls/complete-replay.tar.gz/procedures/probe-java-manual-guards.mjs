import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {resolve} from 'node:path';
import {Script} from 'node:vm';

const require=createRequire(resolve('package.json'));
const YAML=require('yaml');
const path='/tmp/issue-1580-research/java-dispatch-contract/release.yml';
const bytes=readFileSync(path);
assert.equal(createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex'),
  '15fbed88c68753227e4d12abbbc3eb3ad23b7bff');
assert.equal(createHash('sha256').update(bytes).digest('hex'),
  '0736b24479c96110729f681b95545ea15c8b565905ca3169c5b9a34a86b6672b');
const jobs=YAML.parse(bytes.toString()).jobs;
function admitted(job,{event='workflow_dispatch',results={},outputs={},mode='instant',cancelled=false}={}){
  const needs=Object.fromEntries((job.needs??[]).map(name=>[name,
    {result:results[name]??'success',outputs:outputs[name]??{}}]));
  const source=String(job.if??'true').trim().replace(/^\$\{\{\s*|\s*\}\}$/gu,'')
    .replace(/\.([\w]+-[\w-]+)/gu,(_,name)=>`['${name}']`);
  const success=()=>!cancelled&&Object.values(needs).every(x=>x.result==='success');
  const explicitStatus=/\b(?:always|success|failure|cancelled)\s*\(/u.test(source);
  const value=new Script(source).runInNewContext({github:{event_name:event,event:{inputs:{release_mode:mode}}},
    needs,always:()=>true,cancelled:()=>cancelled,success,
    failure:()=>Object.values(needs).some(x=>x.result==='failure')},{timeout:1000});
  return Boolean(value)&&(explicitStatus||success());
}
const lint=jobs.lint;
assert.equal(admitted(jobs['detect-changes']),false);
assert.equal(admitted(lint,{results:{'detect-changes':'skipped'}}),false);
assert.equal(admitted(jobs.test,{results:{'detect-changes':'skipped','changeset-check':'skipped'}}),true);
assert.equal(admitted(jobs.build,{results:{lint:'skipped',test:'success'}}),true);
for(const mode of ['instant','changeset']){
  assert.equal(admitted(jobs[`manual-release-${mode}`],{mode,results:{build:'success'}}),true);
  for(const result of ['failure','cancelled','skipped'])
    assert.equal(admitted(jobs[`manual-release-${mode}`],{mode,results:{build:result}}),false);
}
const lintCandidate={...lint,if:`!cancelled() && (github.event_name == 'workflow_dispatch' ||
  (needs.detect-changes.result == 'success' && (${lint.if.trim()})))`};
const buildCandidate={...jobs.build,if:`!cancelled() && needs.test.result == 'success' &&
  (needs.lint.result == 'success' || (github.event_name != 'workflow_dispatch' && needs.lint.result == 'skipped'))`};
assert.equal(admitted(lintCandidate,{results:{'detect-changes':'skipped'}}),true);
assert.equal(admitted(lintCandidate,{results:{'detect-changes':'skipped'},cancelled:true}),false);
assert.equal(admitted(buildCandidate),true);
for(const result of ['failure','cancelled','skipped'])
  assert.equal(admitted(buildCandidate,{results:{lint:result}}),false);
for(const result of ['failure','cancelled','skipped'])
  assert.equal(admitted(buildCandidate,{results:{test:result}}),false);
for(const event of ['push','pull_request']){
  assert.equal(admitted(lintCandidate,{event}),admitted(lint,{event}));
  for(const result of ['failure','cancelled','skipped'])
    assert.equal(admitted(lintCandidate,{event,results:{'detect-changes':result}}),false);
  assert.equal(admitted(buildCandidate,{event,results:{lint:'skipped'}}),true);
  for(const flag of ['java','pom','mjs','docs','workflow']){
    const context={event,outputs:{'detect-changes':{[`${flag}-changed`]:'true'}}};
    assert.equal(admitted(lint,context),true);
    assert.equal(admitted(lintCandidate,context),true);
  }
}
const result={sourceCommit:'dd803a2d9fa5b3a992b435acce73162274fb9e8b',
  sourceGitBlob:'15fbed88c68753227e4d12abbbc3eb3ad23b7bff',
  classification:'bounded offline expression model; no hosted workflow or publication',
  original:{manualDetectSkipped:true,manualLintSkipped:true,testAdmitted:true,
    buildAdmitsSkippedLint:true,bothManualReleaseModesAdmittedAfterSuccessfulBuild:true},
  candidate:{manualLintAdmitted:true,manualBuildRequiresSuccessfulLintAndTests:true,
    cancellationRetained:true,pushAndPullRequestControlsRetained:true},
  documentedDefaultStatusRule:'https://docs.github.com/en/actions/reference/workflows-and-actions/expressions#status-check-functions',
  hostedManualRunsAvailable:0,independentAuthorshipCredit:0};
writeFileSync('/tmp/issue-1580-research/java-dispatch-contract/guard-model.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
