from pathlib import Path
import json, os, subprocess

root=Path('/tmp/issue-1580-research/java-remaining-boundary-checks-tap')
root.mkdir(exist_ok=False)
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
file='experiments/issue-1580/template-java-boundary-controls.test.mjs'
checks=[('original-candidates',['timeout','600','node','--test','--test-concurrency=1','--test-reporter=tap',file],1),
        ('repaired-candidates',['timeout','600','node','--test','--test-concurrency=1','--test-reporter=tap',file],0),
        ('existing-release-commit',['timeout','600','node','--test','--test-concurrency=1','--test-reporter=tap',
          'experiments/issue-1580/template-java-release-integrity.test.mjs'],0),
        ('existing-project-version',['timeout','600','node','--test','--test-concurrency=1','--test-reporter=tap',
          'experiments/issue-1580/template-java-project-version.test.mjs'],0),
        ('source-identities',['timeout','600','node','--test','--test-concurrency=1','--test-reporter=tap',
          'experiments/issue-1580/template-source-identities.test.mjs'],0),
        ('inventory-integrity',['timeout','600','node','--test','--test-concurrency=1','--test-reporter=tap',
          'experiments/issue-1580/template-inventory-integrity.test.mjs'],0),
        ('diff-check',['git','diff','--check'],0)]
records=[]
for label,command,expected in checks:
    actualEnv=dict(env)
    if label=='original-candidates':
        actualEnv.update(ISSUE_1580_JAVA_KEEP_ORIGINAL_DISPATCH_GUARD='1',
                         ISSUE_1580_JAVA_KEEP_ORIGINAL_FRAGMENT_READER='1')
    with (root/f'{label}.log').open('w')as output:
        result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,env=actualEnv)
    record={'name':label,'command':command,'exitCode':result.returncode,'expectedExitCode':expected}
    records.append(record)
    (root/'status.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    assert result.returncode==expected,record
    if label=='original-candidates':
        text=(root/f'{label}.log').read_text()
        assert '# tests 5' in text and '# pass 3' in text and '# fail 2' in text
(root/'outcome.json').write_text(json.dumps({'complete':True,'allExpected':True,'checks':records,
    'nativeExecution':False,'hostedManualRelease':False,'independentAuthorshipCredit':0},indent=2)+'\n')
