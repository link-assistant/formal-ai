import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {copyFileSync,existsSync,mkdtempSync,mkdirSync,readFileSync,rmSync,writeFileSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {tmpdir} from 'node:os';
import {spawnSync} from 'node:child_process';

const fixture=resolve('experiments/issue-1580/fixtures/java-template');
const metadata=JSON.parse(readFileSync(join(fixture,'source.json'),'utf8'));
const row=metadata.files.find(x=>x.path==='scripts/collect-changelog.mjs');
const source=readFileSync(join(fixture,row.path),'utf8');
assert.equal(createHash('sha1').update(`blob ${Buffer.byteLength(source)}\0`).update(source).digest('hex'),row.gitBlob);
assert.equal(createHash('sha256').update(source).digest('hex'),row.sha256);
const original="const content = readFileSync(filePath, 'utf-8');";
assert.equal(source.split(original).length,2);
const validation=""+
  "      if (!description) {\n"+
  "        throw new Error('Invalid or empty changeset: ' + basename(path));\n"+
  "      }\n";
const candidate=source.replace(original,"const content = readFileSync(filePath, 'utf-8').replace(/\\r\\n/g, '\\n');")
  .replace('    if (description) {',validation+'    if (description) {');
assert.notEqual(candidate,source);
const cases=[
  {name:'valid LF',text:'---\n"my-package": patch\n---\nPreserved real release note.\n',valid:true},
  {name:'valid CRLF',text:'---\r\n"my-package": patch\r\n---\r\nPreserved real release note.\r\n',valid:true},
  {name:'missing frontmatter',text:'Preserved real release note.\n',valid:false},
  {name:'empty description',text:'---\n"my-package": patch\n---\n\n',valid:false},
];
const baseline='# Changelog\n\n<!-- changelog-insert-here -->\n\nExisting release notes.\n';
const observations=[];
for(const item of cases)for(const mode of ['original','candidate']){
  const directory=mkdtempSync(join(tmpdir(),'issue-1580-java-fragment-'));
  try{
    mkdirSync(join(directory,'scripts'));mkdirSync(join(directory,'.changeset'));
    writeFileSync(join(directory,'scripts/collect-changelog.mjs'),mode==='original'?source:candidate);
    copyFileSync(join(fixture,'scripts/github-actions-log.mjs'),join(directory,'scripts/github-actions-log.mjs'));
    writeFileSync(join(directory,'CHANGELOG.md'),baseline);
    writeFileSync(join(directory,'.changeset/note.md'),item.text);
    writeFileSync(join(directory,'.changeset/README.md'),'Retain this guide.\n');
    const result=spawnSync(process.execPath,['scripts/collect-changelog.mjs','--version','1.2.4'],
      {cwd:directory,encoding:'utf8',maxBuffer:65536});
    assert.equal(result.error,undefined);
    const changelog=readFileSync(join(directory,'CHANGELOG.md'),'utf8');
    const exists=existsSync(join(directory,'.changeset/note.md'));
    assert.equal(existsSync(join(directory,'.changeset/README.md')),true);
    const observation={name:item.name,mode,exitCode:result.status,fragmentExists:exists,
      changelogUnchanged:changelog===baseline,descriptionRetained:changelog.includes('Preserved real release note.'),
      stdout:result.stdout,stderr:result.stderr};
    if(mode==='original'){
      assert.equal(result.status,0);assert.equal(exists,false);
      assert.equal(observation.descriptionRetained,item.name==='valid LF');
    }else if(item.valid){
      assert.equal(result.status,0);assert.equal(exists,false);assert.equal(observation.descriptionRetained,true);
    }else{
      assert.notEqual(result.status,0);assert.equal(exists,true);assert.equal(changelog,baseline);
      assert.equal(readFileSync(join(directory,'.changeset/note.md'),'utf8'),item.text);
    }
    observations.push(observation);
  }finally{rmSync(directory,{recursive:true,force:true});}
}
const output={sourceCommit:metadata.commit??metadata.sourceCommit,source:row,observations,
  classification:'Actual complete pinned CLI in eight finite disposable local directories; no Maven or publication',
  independentAuthorshipCredit:0};
writeFileSync('/tmp/issue-1580-research/java-dispatch-contract/fragment-preservation.json',JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify(observations.map(({stdout,stderr,...item})=>item),null,2));
