from pathlib import Path
import json

file=Path('docs/case-studies/issue-1580/templates/java-active-semantic-review.json')
document=json.loads(file.read_text())
rows={row['path']:row for row in document['files']}
rows['.github/workflows/release.yml']['decision'] += ' Continuation 2026-11-22: the exact pinned YAML now has a bounded expression-model reproduction of skipped manual lint followed by eligible build/release. Candidate guards require successful lint and test on dispatch while retaining push/PR change controls. No hosted Java dispatch is claimed. See java-boundary-controls-20261122.md.'
rows['scripts/collect-changelog.mjs']['decision'] += ' Continuation 2026-11-22: the unchanged complete collector CLI now reproduces deletion of CRLF, malformed and empty inputs without their notes. Disposable candidate copies retain valid LF/CRLF notes and preserve every input plus the changelog when any fragment is invalid; mixed good/bad batches are covered. See java-boundary-controls-20261122.md.'
document['continuationVerification20261122']={
 'scope':'Two previously unexecuted observations, not complete repository semantic/runtime qualification.',
 'regression':'experiments/issue-1580/template-java-boundary-controls.test.mjs',
 'originalCandidateControls':{'tests':5,'pass':3,'expectedFailure':2},
 'candidateControls':{'tests':5,'pass':5,'failure':0},
 'otherFocusedPositiveCases':11,
 'hostedManualRelease':False,'mavenExecution':False,'completeRepositorySemanticReview':False,
 'formalAiComparison':[
  'release.yml uses explicit status functions and successful native/build/preflight/secret prerequisites; current aggregate failure is observed, but main manual-release execution remains unqualified.',
  'scripts/changelog-files.rs snapshots all reads and verifies every fragment before removal; collect-changelog.rs accepts CRLF and plain descriptions. Formal AI allows plain fragments, so Java frontmatter validation is not copied. Mixed empty batches are not qualified by the new Java reproduction.'
 ],
 'independentAuthorshipCredit':0}
file.write_text(json.dumps(document,indent=2,ensure_ascii=False)+'\n')

doc=Path('docs/case-studies/issue-1580/templates/java-boundary-controls-20261122.md')
doc.write_text('''# Java manual quality checks and fragment preservation

Two earlier source observations now have bounded executable controls at unchanged
template source `dd803a2d9fa5b3a992b435acce73162274fb9e8b`. This adds evidence to
the active review; complete template semantic and runtime qualification remain open.

The copied 610-line workflow has Git blob
`15fbed88c68753227e4d12abbbc3eb3ad23b7bff` and SHA256
`0736b24479c96110729f681b95545ea15c8b565905ca3169c5b9a34a86b6672b`.
The test evaluates its actual guards with GitHub's documented default `success()`
rule. Manual detection is skipped, lint consequently skips, while the explicit
build guard accepts skipped lint. Both manual release guards can then accept a
successful build. This is an expression-model result, not an observed hosted
dispatch. Candidate lint/build guards require both quality jobs on dispatch;
five push/PR change flags and failure, skip and cancellation controls remain.

The unchanged complete collector CLI has Git blob
`659ecc112fe75039abd66af0ac61bdb9849c84ad` and SHA256
`afefed46692d3f56e122c13328810d7a26e7448b38656ba0c6fc0920ae41017a`.
Actual isolated Node processes show exit zero and fragment deletion for valid
CRLF, malformed and empty descriptions whose text is omitted. A mixed valid and
malformed batch loses the malformed input too. Disposable candidate copies
normalize CRLF and reject invalid descriptions before writes: valid LF/CRLF
notes survive in the changelog, while rejected batches preserve the exact input
bytes and original changelog. README preservation is checked in every case.

Run `node --test --test-concurrency=1 experiments/issue-1580/template-java-boundary-controls.test.mjs`.
All five cases pass. Restoring both original candidates with
`ISSUE_1580_JAVA_KEEP_ORIGINAL_DISPATCH_GUARD=1` and
`ISSUE_1580_JAVA_KEEP_ORIGINAL_FRAGMENT_READER=1` yields the expected two failures
and three passes. Eleven adjacent release-integrity, project-version and
inventory/source-identity cases also pass. Tests run sequentially; no Maven,
hosted dispatch or publication is executed. Full streams, source identities and
the two original script failures are retained in the accompanying evidence archive.

Formal AI already uses explicit status functions and successful native, build,
preflight and secret prerequisites in its relevant release guards. Its aggregate
correctly fails the current native compile error, which does not qualify a main
manual release. Its native collector reads a complete snapshot, validates that
every source is unchanged before removal and accepts CRLF/plain descriptions.
Java requires frontmatter and Formal AI permits plain fragments; preserve those
different formats. The Java reproduction does not establish Formal AI's behavior
for every mixed empty-fragment batch. Native execution remains hosted-only.

The report drafts are under `experiments/issue-1580/upstream/`. Publish immutable
executable evidence before filing. Supplied code and analysis earn zero independent
Formal AI authorship or accepted-reasoning credit.
''')

reports=Path('experiments/issue-1580/upstream')
(reports/'java-manual-dispatch-quality-report.md').write_text('''Manual release dispatch can bypass lint in the current release workflow.

Reviewed source: `dd803a2d9fa5b3a992b435acce73162274fb9e8b`, `.github/workflows/release.yml`, Git blob `15fbed88c68753227e4d12abbbc3eb3ad23b7bff`.

`detect-changes` excludes `workflow_dispatch` (line 44). `lint` needs that job (line 80), but its guard at lines 87–94 has no status function. GitHub supplies the default `success()` check, so a skipped detection dependency skips lint despite the dispatch event branch. The test job has an explicit status function, and the build guard (lines 191–196) accepts successful tests with skipped lint. Both manual release modes can then accept a successful build.

This is a bounded expression-model reproduction against the exact pinned YAML, not an observed hosted release. The model implements the documented implicit status rule: https://docs.github.com/en/actions/reference/workflows-and-actions/expressions#status-check-functions . The current manual-run query returned no runs; it supplies no execution evidence.

The executable reproduction in Formal AI PR #1581 is `experiments/issue-1580/template-java-boundary-controls.test.mjs`. Run `node --test --test-concurrency=1 experiments/issue-1580/template-java-boundary-controls.test.mjs`: five cases pass. The original dispatch guards reproduce skipped lint followed by eligible build/release. A disposable guard candidate uses explicit `!cancelled()` for lint and requires successful lint plus tests on dispatch. Push/PR behavior retains all five change flags, failed/skipped/cancelled detection controls and existing non-dispatch skipped-lint admission. Failed, cancelled or skipped quality jobs cannot admit a manual candidate build.

Setting `ISSUE_1580_JAVA_KEEP_ORIGINAL_DISPATCH_GUARD=1` reproduces the candidate regression failure. Other cases remain positive. No workflow dispatch, Maven build, hosted publication or upstream source modification is performed by these tests. The candidate is a local proposal and does not establish an upstream repair.
''')
(reports/'java-fragment-preservation-report.md').write_text('''The changelog collector deletes skipped release fragments while reporting success.

Reviewed source: `dd803a2d9fa5b3a992b435acce73162274fb9e8b`, `scripts/collect-changelog.mjs`, Git blob `659ecc112fe75039abd66af0ac61bdb9849c84ad`.

The unchanged complete CLI matches frontmatter with LF-only separators. Valid CRLF fragments are treated as unparsed; malformed frontmatter and empty descriptions are also skipped. It nevertheless deletes every discovered changeset after updating the changelog. Consequently it exits zero, loses the input file and omits its release note. A mixed valid/malformed batch writes the valid note and deletes the malformed fragment too.

Bounded offline reproduction:

1. Create a temporary directory with the exact pinned collector and `github-actions-log.mjs`, a baseline `CHANGELOG.md`, and `.changeset/README.md`.
2. Add a patch changeset with CRLF separators and a nonempty description. Run `node scripts/collect-changelog.mjs --version 1.2.4`.
3. Observe exit zero, deletion of the fragment and omission of its description from the changelog. Repeat with missing frontmatter, an empty description and a mixed valid/malformed batch.

The executable reproduction in Formal AI PR #1581 is `experiments/issue-1580/template-java-boundary-controls.test.mjs`. Run `node --test --test-concurrency=1 experiments/issue-1580/template-java-boundary-controls.test.mjs`: five cases pass. A disposable candidate normalizes CRLF and rejects missing/empty descriptions before writes. Positive LF and CRLF controls retain the note in the changelog. Every rejected batch preserves the original changelog and all fragment bytes, including the valid sibling. README is preserved throughout.

Setting `ISSUE_1580_JAVA_KEEP_ORIGINAL_FRAGMENT_READER=1` reproduces the candidate regression failure on the valid CRLF case. Actual collector invocations use bounded isolated Node processes with cleanup. No Maven build, Git push, hosted workflow or GitHub publication occurs. The candidate exists only in disposable copies; no upstream repair is claimed.
''')
print('Documented both newly reproduced Java boundaries, retained historical decisions and full-scope limitations, and drafted two distinct upstream reports.')
