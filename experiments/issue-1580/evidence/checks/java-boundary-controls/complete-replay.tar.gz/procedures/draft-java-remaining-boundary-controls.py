from pathlib import Path
import hashlib, json, subprocess

scratch=Path('/tmp/issue-1580-research')
fixture=Path('experiments/issue-1580/fixtures/java-template')
source=(scratch/'java-dispatch-contract/release.yml').read_bytes()
assert hashlib.sha1(f'blob {len(source)}\0'.encode()+source).hexdigest()=='15fbed88c68753227e4d12abbbc3eb3ad23b7bff'
target=fixture/'.github/workflows/release.yml'
target.parent.mkdir(parents=True,exist_ok=True)
assert not target.exists()
target.write_bytes(source)
path=fixture/'source.json'
metadata=json.loads(path.read_text())
assert metadata['commit']=='dd803a2d9fa5b3a992b435acce73162274fb9e8b'
metadata['files'].append({'path':'.github/workflows/release.yml',
    'gitBlob':'15fbed88c68753227e4d12abbbc3eb3ad23b7bff',
    'sha256':hashlib.sha256(source).hexdigest()})
path.write_text(json.dumps(metadata,indent=2)+'\n')
target=Path('experiments/issue-1580/template-java-boundary-controls.test.mjs')
assert not target.exists()
target.write_text((scratch/'new-java-boundary-controls.test.mjs').read_text())
entry=Path('rust/tests/web/issue-1580-template-observations.test.mjs')
with entry.open('a')as out:
    out.write("\nimport '../../../experiments/issue-1580/template-java-boundary-controls.test.mjs';\n")
subprocess.run(['git','diff','--check'],check=True)
print('Drafted five Java boundary controls, exact pinned workflow fixture and maintained CI registration.')
