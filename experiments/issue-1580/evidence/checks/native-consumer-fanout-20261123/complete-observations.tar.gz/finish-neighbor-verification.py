from pathlib import Path
import subprocess,json,datetime,os
r=Path('/tmp/issue-1580-research/native-unrestricted-fanout-20261123')
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
cmd=['node','--test','--test-concurrency=1','rust/tests/web/default-branch-build-policy.test.mjs']
with (r/'default-branch-build-policy.test.log').open('wb') as log: p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
row={'command':cmd,'exitCode':p.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':'default-branch-build-policy.test.log'}
records=json.loads((r/'neighbor-records.json').read_text());records.append(row)
(r/'neighbor-records.json').write_text(json.dumps(records,indent=2)+'\n')
(r/'neighbor-outcome.json').write_text(json.dumps({'complete':True,'allPassed':all(x['exitCode']==0 for x in records),'records':records},indent=2)+'\n')
print(json.dumps(row),flush=True)
