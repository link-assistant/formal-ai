from pathlib import Path
import subprocess,json,datetime,os
r=Path('/tmp/issue-1580-research/native-unrestricted-fanout-20261123')
env=os.environ.copy();env.pop('NODE_OPTIONS',None);records=[]
gates=['workflows','check-ci-speed','check-abbreviations','check-file-size','check-file-size-js-twin','check-minimal-core-boundary','check-minimal-core-boundary-js-twin','check-debt-ratchet-js-twin','check_debt_ratchet','check-changelog-fragment-js-twin']
for gate in gates:
 cmd=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]
 with (r/(gate+'.log')).open('wb') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
 row={'gate':gate,'command':cmd,'exitCode':p.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()};records.append(row)
 (r/'gate-records.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(row),flush=True)
(r/'gate-outcome.json').write_text(json.dumps({'complete':True,'allPassed':all(x['exitCode']==0 for x in records),'records':records},indent=2)+'\n')
