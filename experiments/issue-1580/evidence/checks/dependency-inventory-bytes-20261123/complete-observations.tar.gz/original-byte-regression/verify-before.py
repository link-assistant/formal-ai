from pathlib import Path
import os,json,subprocess,datetime
root=Path('/tmp/issue-1580-research/dependency-inventory-utf8')
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/'before.log').open('wb') as out:
 p=subprocess.run(['node','--test','--test-concurrency=1','experiments/issue-1580/dependency-lock-literal-paths.test.mjs'],stdout=out,stderr=subprocess.STDOUT,env=env)
(root/'before-result.json').write_text(json.dumps({'exit':p.returncode,'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
