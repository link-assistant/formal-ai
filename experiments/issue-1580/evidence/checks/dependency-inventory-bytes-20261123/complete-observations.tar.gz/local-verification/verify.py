from pathlib import Path
import datetime,json,os,subprocess
root=Path('/tmp/issue-1580-research/negative-controls-repair-batch')
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
records=[]
tests=[
('utf8-focused','experiments/issue-1580/dependency-lock-literal-paths.test.mjs'),
('dependencies-maintained','rust/tests/web/dependencies-maintenance-workflow.test.mjs'),
('dependencies-neighbor','rust/tests/web/issue-1169-dependencies-latest-workflow.test.mjs'),
('boundaries-maintained','rust/tests/web/bounded-subprocess-boundaries.test.mjs'),
('security-neighbor','rust/tests/web/security-codeql-results.test.mjs'),
('profile-neighbor','rust/tests/web/fast-pull-request-production-profile.test.mjs')]
checks=[(label,['node','--test','--test-concurrency=1',path]) for label,path in tests]
checks+=[(gate,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]) for gate in [
'check-abbreviations','check-file-size','check-file-size-js-twin','check-minimal-core-boundary',
'check-minimal-core-boundary-js-twin','check-debt-ratchet-js-twin','check_debt_ratchet']]
checks+=[('inventory',['node','scripts/dependency-manifest-inventory.mjs']),('diff-check',['git','diff','--check'])]
for label,command in checks:
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (root/(label+'.log')).open('wb') as out:
  result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,env=env)
 record={'label':label,'command':command,'exitCode':result.returncode,'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 records.append(record);(root/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
(root/'outcome.json').write_text(json.dumps({'records':records,'allChecksPassed':all(row['exitCode']==0 for row in records),'fullIssueComplete':False},indent=2)+'\n')
