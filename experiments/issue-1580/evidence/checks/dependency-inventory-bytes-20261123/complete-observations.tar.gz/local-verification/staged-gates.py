from pathlib import Path
import datetime,json,os,subprocess
root=Path('/tmp/issue-1580-research/negative-controls-repair-batch/staged-gates');root.mkdir(exist_ok=True)
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
records=[]
for gate in ['check-abbreviations','check-file-size','check-file-size-js-twin','check-minimal-core-boundary','check-minimal-core-boundary-js-twin','check-debt-ratchet-js-twin','check_debt_ratchet','check-changelog-fragment-js-twin']:
 command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (root/(gate+'.log')).open('wb') as out:result=subprocess.run(command,env=env,stdout=out,stderr=subprocess.STDOUT)
 row={'gate':gate,'command':command,'exitCode':result.returncode,'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 records.append(row);(root/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
(root/'outcome.json').write_text(json.dumps({'allPassed':all(row['exitCode']==0 for row in records),'records':records},indent=2)+'\n')
