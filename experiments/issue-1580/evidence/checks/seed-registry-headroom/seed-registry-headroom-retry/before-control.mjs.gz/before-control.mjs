import assert from 'node:assert/strict';
import {checkListedFiles} from "file:///tmp/gh-issue-solver-1794900398048/scripts/check-file-size.mjs";
const result=checkListedFiles("/tmp/formal-ai-seed-headroom-before-fr8fxzmi",new Set(['rust/src/seed/embedded_registry.rs','rust/src/seed/embedded_files.rs']));
console.log(JSON.stringify(result));
assert.deepEqual(result,{warnings:[],violations:[],embeddedDataViolations:[]});
