from pathlib import Path
import json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/seed-registry-headroom')
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(json.dumps({'pid':worker.pid,'finite':True}));sys.exit(0)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=256';records=[]
def run(name,args,expected=0):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:r=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'arguments':args,'exitCode':r.returncode};records.append(row);(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True);assert (r.returncode==0)==(expected==0),row
try:
    original=(root/'rust/src/seed/embedded_registry.rs').read_text();(out/'original.rs').write_text(original)
    test=root/'rust/tests/web/seed-registry-headroom.test.mjs';test.write_text(r'''import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import test from 'node:test';
import {checkListedFiles} from '../../../scripts/check-file-size.mjs';

const root=fileURLToPath(new URL('../../../',import.meta.url));
test('generated seed inventory retains headroom and a reachable complete bundle function',()=>{
  const files=['rust/src/seed/embedded_registry.rs','rust/src/seed/embedded_files.rs'];
  assert.deepEqual(checkListedFiles(root,new Set(files)),{warnings:[],violations:[],embeddedDataViolations:[]});
  const parent=readFileSync(root+files[0],'utf8'),child=readFileSync(root+files[1],'utf8');
  assert.match(parent,/^include!("embedded_files.rs");$/mu);
  assert.doesNotMatch(parent,/^pub fn seed_files(/mu);
  assert.match(child,/^pub fn seed_files() -> Vec<(&'static str, &'static str)> {$/mu);
});
''')
    run('before',['node','--test','--test-concurrency=1',str(test)],1)
    js=root/'scripts/generate-seed-registry.mjs';s=js.read_text();s=s.replace("const WEB_TARGET = 'js/seed-files.js';","const WEB_TARGET = 'js/seed-files.js';\nconst RUST_FILES_TARGET = 'src/seed/embedded_files.rs';")
    start=s.index("  out += '\\n/// Embedded copy of every Links Notation seed file.")
    end=s.index("  out += '\\n/// The registered set of multilingual-response files",start)
    block=s[start:end];s=s[:start]+'''  out += '\\ninclude!("embedded_files.rs");\\n';
'''+s[end:]
    declaration='''export function renderRustFiles(registry) {
  const embeddedSeeds = registry.seeds.filter(embedded);
  let out = '// Generated bundle inventory from data/meta/seed-registry.lino; do not edit by hand.\\n';
'''+block+'''  return out;
}

'''
    marker='export function renderWeb(registry) {';assert s.count(marker)==1;s=s.replace(marker,declaration+marker)
    s=s.replace("  if (!sourceBytes.equals(Buffer.from(renderRust(registry)))) throw new Error('generated declaration source drift');","""  if (!sourceBytes.equals(Buffer.from(renderRust(registry)))) throw new Error('generated declaration source drift');
  const includedSourcePath = 'rust/' + RUST_FILES_TARGET;
  const includedSourceBytes = regularBytes(includedSourcePath);
  if (!includedSourceBytes.equals(Buffer.from(renderRustFiles(registry)))) throw new Error('generated bundle source drift');""")
    s=s.replace("if (!regularBytes(REGISTRY).equals(registryBytes) || !regularBytes(sourcePath).equals(sourceBytes))","if (!regularBytes(REGISTRY).equals(registryBytes) || !regularBytes(sourcePath).equals(sourceBytes) || !regularBytes(includedSourcePath).equals(includedSourceBytes))")
    s=s.replace('sourceSha256: digest(sourceBytes), declarations};','sourceSha256: digest(sourceBytes), includedSourcePath, includedSourceSha256: digest(includedSourceBytes), declarations};')
    s=s.replace("    [RUST_TARGET, join(root, 'rust', RUST_TARGET), renderRust(registry)],","    [RUST_TARGET, join(root, 'rust', RUST_TARGET), renderRust(registry)],\n    [RUST_FILES_TARGET, join(root, 'rust', RUST_FILES_TARGET), renderRustFiles(registry)],")
    s=s.replace('// rust/src/seed/embedded_registry.rs and js/seed-files.js from it.','// rust/src/seed/{embedded_registry,embedded_files}.rs and js/seed-files.js from it.')
    js.write_text(s)
    rust=root/'scripts/generate-seed-registry.rs';s=rust.read_text();s=s.replace('const WEB_TARGET: &str = "js/seed-files.js";','const WEB_TARGET: &str = "js/seed-files.js";\n#[cfg(not(test))]\nconst RUST_FILES_TARGET: &str = "src/seed/embedded_files.rs";')
    start=s.index('    out.push_str(\n        "\\n/// Embedded copy of every Links Notation seed file.')
    end=s.index('    out.push_str(\n        "\\n/// The registered set of multilingual-response files',start)
    block=s[start:end];s=s[:start]+'    out.push_str("\\ninclude!(\\\"embedded_files.rs\\\");\\n");\n\n'+s[end:]
    declaration='''fn render_rust_files(registry: &Registry) -> String {
    let embedded: Vec<&Seed> = registry.seeds.iter().filter(|seed| seed.embedded()).collect();
    let mut out = String::from(
        "// Generated bundle inventory from data/meta/seed-registry.lino; do not edit by hand.\\n",
    );
'''+block+'''    out
}

'''
    marker='fn render_web(registry: &Registry) -> String {';assert s.count(marker)==1;s=s.replace(marker,declaration+marker)
    s=s.replace('        (RUST_TARGET, root.join("rust").join(RUST_TARGET), render_rust(&registry)),','        (RUST_TARGET, root.join("rust").join(RUST_TARGET), render_rust(&registry)),\n        (RUST_FILES_TARGET, root.join("rust").join(RUST_FILES_TARGET), render_rust_files(&registry)),')
    s=s.replace('//!     `seed_files()`, `RESPONSE_FILES`, `MEANING_FILES`. It is `include!`d by','//!     `RESPONSE_FILES`, `MEANING_FILES` and an include of `embedded_files.rs`.\n//!   * `src/seed/embedded_files.rs` -- the complete `seed_files()` function.\n//!     Both are `include!`d by')
    rust.write_text(s)
    provenance=root/'rust/tests/web/generated-seed-owner-provenance.test.mjs';s=provenance.read_text();s=s.replace('parseRegistry, renderRust, sourceQualifiedSeedOwners','parseRegistry, renderRust, renderRustFiles, sourceQualifiedSeedOwners')
    marker="  fs.writeFileSync(path.join(root,'rust/src/seed/embedded_registry.rs'),renderRust(canonicalize(parseRegistry(registry))));";assert marker in s;s=s.replace(marker,marker+"\n  fs.writeFileSync(path.join(root,'rust/src/seed/embedded_files.rs'),renderRustFiles(canonicalize(parseRegistry(registry))));")
    s=s.replace("  for(const mutation of [","""  for(const mutation of [
    root=>fs.appendFileSync(path.join(root,'rust/src/seed/embedded_files.rs'),'// drift\\n'),
    root=>fs.unlinkSync(path.join(root,'rust/src/seed/embedded_files.rs')),
    root=>{const file=path.join(root,'rust/src/seed/embedded_files.rs');fs.renameSync(file,file+'.retained');fs.symlinkSync(file+'.retained',file);},
    root=>fs.writeFileSync(path.join(root,'rust/src/seed/embedded_files.rs'),Buffer.alloc(1024*1024+1)),""")
    marker="  assert.equal(proof.declarations.length,1);assert.match(proof.sourceSha256,/^[0-9a-f]{64}$/u);";assert marker in s;s=s.replace(marker,marker+"\n  assert.equal(proof.includedSourcePath,'rust/src/seed/embedded_files.rs');assert.match(proof.includedSourceSha256,/^[0-9a-f]{64}$/u);")
    provenance.write_text(s)
    parity=root/'rust/tests/web/bundled-seed-source-parity.test.mjs';s=parity.read_text();marker="    const functions=collect(parsed.tree,node=>node.term==='function_item'&&node.children.some(child=>child.field==='name'&&render(child)==='seed_files'));";assert marker in s
    s=s.replace(marker,"""    assert.match(source,/^include!\\("embedded_files\\.rs"\\);$/mu);
    const bundleSource=readFileSync(new URL('../../../rust/src/seed/embedded_files.rs',import.meta.url),'utf8');
    const bundleParsed=runtime.forSource('rust/src/seed/embedded_files.rs','Rust').parse(bundleSource,'Rust');
    const renderBundle=node=>node.tokenIndex===undefined?node.children.map(renderBundle).join(''):bundleParsed.tokens[node.tokenIndex].text;
    const functions=collect(bundleParsed.tree,node=>node.term==='function_item'&&node.children.some(child=>child.field==='name'&&renderBundle(child)==='seed_files'));""")
    s=s.replace("const paths=collect(functions[0],node=>node.term==='string_literal').map(node=>JSON.parse(render(node)));","const paths=collect(functions[0],node=>node.term==='string_literal').map(node=>JSON.parse(renderBundle(node)));")
    parity.write_text(s)
    run('format',['rustfmt','--edition','2024',str(rust)])
    run('generate',['node','scripts/generate-seed-registry.mjs','--write'])
    parent=(root/'rust/src/seed/embedded_registry.rs').read_text();child=(root/'rust/src/seed/embedded_files.rs').read_text();header='// Generated bundle inventory from data/meta/seed-registry.lino; do not edit by hand.\n';assert parent.replace('\ninclude!("embedded_files.rs");\n',child.removeprefix(header))==original
    for name,args in [('headroom',['node','--test','--test-concurrency=1',str(test)]),('provenance',['node','--test','--test-concurrency=1',str(provenance)]),('parity',['node','--test','--test-concurrency=1',str(parity)]),('binding',['node','--test','--test-concurrency=1','rust/tests/web/requirement-seed-target-binding.test.mjs']),('role-registry',['node','--test','--test-concurrency=1','rust/tests/web/generate-role-registry-js.test.mjs'])]:run(name,args)
    summary={'complete':True,'parentLines':len(parent.splitlines()),'childLines':len(child.splitlines()),'inverseExactlyOriginal':True,'declarationOwnerPathsUnchanged':True,'nativeBuildRun':False,'independentAuthorshipCredit':0,'fullIssueComplete':False};(out/'outcome.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
