from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
script=root/'scripts/generate-seed-registry.rs';source=script.read_text();marker='    #[test]\n    fn the_browser_list_holds_exactly_the_web_seeds() {'
assert source.count(marker)==1
addition=r'''    #[test]
    fn the_complete_bundle_function_is_reachable_without_moving_declaration_owners() {
        let registry = sample();
        let declarations = render_rust(&registry);
        let files = render_rust_files(&registry);
        assert!(declarations.contains("\ninclude!(\"embedded_files.rs\");\n"));
        assert!(!declarations.contains("pub fn seed_files("));
        assert!(files.contains("pub fn seed_files() -> Vec<(&'static str, &'static str)> {"));
        assert!(files.contains("(\"data/seed/concepts.lino\", CONCEPTS_LINO),"));
        assert!(files.contains("(\"data/seed/meanings-units.lino\", MEANINGS_UNITS_LINO),"));
        assert!(declarations.contains("pub const CONCEPTS_LINO: &str ="));
    }

    #[test]
    fn the_bundle_include_does_not_admit_web_only_or_lexicon_only_seeds() {
        let registry = canonicalize(parse_registry(
            "seed_registry\n  seed bundled\n    bundle true\n  seed browser-only\n    web true\n  seed lexicon-only\n    lexicon meaning\n",
        ));
        let files = render_rust_files(&registry);
        assert!(files.contains("(\"data/seed/bundled.lino\", BUNDLED_LINO),"));
        assert!(!files.contains("BROWSER_ONLY_LINO"));
        assert!(!files.contains("LEXICON_ONLY_LINO"));
        assert!(render_rust(&registry).contains("pub const LEXICON_ONLY_LINO: &str ="));
    }

'''
script.write_text(source.replace(marker,addition+marker))
target=root/'rust/tests/unit/workflow_contracts.rs';source=target.read_text();source+='''
// Compile the canonical generator and its bundle/include contracts before merge.
#[allow(dead_code)]
#[path = "../../../scripts/generate-seed-registry.rs"]
mod generate_seed_registry;
''';target.write_text(source)
test=root/'rust/tests/web/seed-registry-headroom.test.mjs';source=test.read_text();source+='''
test('the canonical Rust seed generator runs through hosted workflow contracts',()=>{
  const owner=readFileSync(root+'rust/tests/unit/workflow_contracts.rs','utf8');
  assert(owner.includes('#[path = "../../../scripts/generate-seed-registry.rs"]'));
  assert(owner.includes('mod generate_seed_registry;'));
  assert(readFileSync(root+'scripts/ci-native-regressions.sh','utf8').includes('--test workflow_contracts'));
});
''';test.write_text(source)
print('Registered the canonical generator and two native contract regressions; no Rust compiler ran.')
