from pathlib import Path
import json,os,subprocess,tempfile,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'seed-registry-headroom-retry';out.mkdir(exist_ok=False)
environment=os.environ.copy();environment['NODE_OPTIONS']='--max-old-space-size=256';records=[]
def run(name,arguments,expected=0):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(arguments,cwd=root,env=environment,stdout=stdout,stderr=stderr)
    records.append({'name':name,'arguments':arguments,'exitCode':result.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records[-1]),flush=True);assert (result.returncode==0)==(expected==0),records[-1]
try:
    test=root/'rust/tests/web/seed-registry-headroom.test.mjs';source=test.read_text();lines=source.splitlines()
    lines=[("  assert(parent.split('\\n').includes('include!(\"embedded_files.rs\");'));" if 'assert.match(parent,' in line else "  assert(!parent.includes('pub fn seed_files('));" if 'assert.doesNotMatch(parent,' in line else '  assert(child.includes("pub fn seed_files() -> Vec<(&\\x27static str, &\\x27static str)> {"));' if 'assert.match(child,' in line else line) for line in lines]
    test.write_text('\n'.join(lines)+'\n')
    parity=root/'rust/tests/web/bundled-seed-source-parity.test.mjs';source=parity.read_text();source=source.replace('    assert.match(source,/^include!("embedded_files.rs");$/mu);','    assert(source.split("\\n").includes(\'include!("embedded_files.rs");\'));')
    parity.write_text(source)
    # The earlier before/after drafts had invalid regular expressions and get
    # no negative-control credit. Replay the original scanner against a thin,
    # isolated copy so no working-tree file or concurrent collector is changed.
    with tempfile.TemporaryDirectory(prefix='formal-ai-seed-headroom-before-') as temporary:
        fixture=Path(temporary);parent=fixture/'rust/src/seed/embedded_registry.rs';parent.parent.mkdir(parents=True);parent.write_bytes((scratch/'seed-registry-headroom/original.rs').read_bytes())
        script=out/'before-control.mjs';script.write_text("import assert from 'node:assert/strict';\nimport {checkListedFiles} from "+json.dumps((root/'scripts/check-file-size.mjs').as_uri())+";\nconst result=checkListedFiles("+json.dumps(str(fixture))+",new Set(['rust/src/seed/embedded_registry.rs','rust/src/seed/embedded_files.rs']));\nconsole.log(JSON.stringify(result));\nassert.deepEqual(result,{warnings:[],violations:[],embeddedDataViolations:[]});\n")
        run('before-scanner',['node',str(script)],1)
        assert '983' in (out/'before-scanner.stdout').read_text()
    for name,path in [('headroom','seed-registry-headroom'),('provenance','generated-seed-owner-provenance'),('parity','bundled-seed-source-parity'),('binding','requirement-seed-target-binding'),('role-registry','generate-role-registry-js')]:
        run(name,['node','--test','--test-concurrency=1','rust/tests/web/'+path+'.test.mjs'])
    run('naming-list',['node','scripts/measure-abbreviations.mjs','--list','file-names'])
    parent=(root/'rust/src/seed/embedded_registry.rs').read_text();child=(root/'rust/src/seed/embedded_files.rs').read_text();header='// Generated bundle inventory from data/meta/seed-registry.lino; do not edit by hand.\n'
    assert parent.replace('\ninclude!("embedded_files.rs");\n',child.removeprefix(header))==(scratch/'seed-registry-headroom/original.rs').read_text()
    result={'complete':True,'parentLines':len(parent.splitlines()),'childLines':len(child.splitlines()),'inverseExactlyOriginal':True,'initialSyntaxFailuresQualified':False,'nativeBuildRun':False,'independentAuthorshipCredit':0,'fullIssueComplete':False};(out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
