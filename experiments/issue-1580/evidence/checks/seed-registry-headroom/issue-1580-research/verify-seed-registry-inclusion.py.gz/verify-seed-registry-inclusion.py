from pathlib import Path
import json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'seed-registry-headroom-final'
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(json.dumps({'pid':worker.pid,'finite':True}));sys.exit(0)
environment=os.environ.copy();environment['NODE_OPTIONS']='--max-old-space-size=256';records=[]
def run(name,arguments):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(arguments,cwd=root,env=environment,stdout=stdout,stderr=stderr)
    records.append({'name':name,'arguments':arguments,'exitCode':result.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records[-1]),flush=True);assert result.returncode==0,records[-1]
try:
    test=root/'rust/tests/web/generated-seed-owner-provenance.test.mjs';source=test.read_text();source=source.replace("  const [navigation]=censusDocuments(root);","  const navigation=censusDocuments(root).find(row=>row.path==='rust/src/seed/embedded_registry.rs');\n  assert(navigation, 'the original declaration owner remains in the census');");test.write_text(source)
    for name,path in [('provenance','generated-seed-owner-provenance'),('parity','bundled-seed-source-parity'),('binding','requirement-seed-target-binding'),('role-registry','generate-role-registry-js')]:run(name,['node','--test','--test-concurrency=1','rust/tests/web/'+path+'.test.mjs'])
    run('gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-seed-registry,check-seed-registry-js-twin,check-file-size,check-file-size-js-twin'])
    run('format',['rustfmt','--check','--edition','2024','scripts/generate-seed-registry.rs'])
    parent=(root/'rust/src/seed/embedded_registry.rs').read_text();child=(root/'rust/src/seed/embedded_files.rs').read_text();header='// Generated bundle inventory from data/meta/seed-registry.lino; do not edit by hand.\n';assert parent.replace('\ninclude!("embedded_files.rs");\n',child.removeprefix(header))==(scratch/'seed-registry-headroom/original.rs').read_text()
    result={'complete':True,'parentLines':len(parent.splitlines()),'childLines':len(child.splitlines()),'inverseExactlyOriginal':True,'initialSyntaxFailuresQualified':False,'nativeBuildRun':False,'independentAuthorshipCredit':0,'fullIssueComplete':False};(out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
