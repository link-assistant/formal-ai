from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'seed-registry-headroom-commit-retry'
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(json.dumps({'pid':worker.pid,'finite':True}));sys.exit(0)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH'];commands=[]
def run(name,args):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'arguments':args,'exitCode':result.returncode};commands.append(row);(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(row),flush=True);assert result.returncode==0,row
try:
    verified=json.loads((scratch/'seed-registry-headroom-final/outcome.json').read_text());assert verified['complete'] and verified['inverseExactlyOriginal']
    assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
    run('format',['rustfmt','--check','--config','skip_children=true','--edition','2024','scripts/generate-seed-registry.rs','rust/tests/unit/workflow_contracts.rs'])
    run('headroom',['node','--test','--test-concurrency=1','rust/tests/web/seed-registry-headroom.test.mjs'])
    note='docs/case-studies/issue-1580/seed-registry-headroom-checkpoint.md';(root/note).write_text('''# Generated seed inventory retains headroom

The generated registry owner had 983 lines and a real scanner warning.
Both canonical Rust and JavaScript generators now emit its complete bundle
function into a 361-line include. The declaration owner remains at 625 lines;
its constants, meaning order and response order retain their original location.
An exact inverse reconstructs the original complete owner byte for byte.

Ownership verification now checks the generated include as well as the original
declaration owner. Eight provenance cases reject missing, changed, oversized
and symbolic-link includes. Bundle parity compares the complete parsed native
inventory with the JavaScript inventory. Seven requirement binding cases and
role registry checks pass. Two headroom contracts pass, and the canonical Rust
generator contracts are registered with the hosted workflow-contract target.
The real pre-extraction warning control fails as expected. Initial malformed
test drafts and the first navigation assertion failure receive no verification
credit; their outputs remain available alongside the successful checks.

The source warning inventory is reduced from 75 to 74 without changing either
threshold. No native compiler ran locally. Hosted native execution and full
issue acceptance remain unfinished. Supplied work receives zero independent
authorship or reasoning credit.

Evidence: experiments/issue-1580/evidence/checks/seed-registry-headroom/.
''')
    fragment='changelog.d/issue-1580-seed-registry-headroom.md';(root/fragment).write_text('''---
bump: patch
---

Generate the complete native seed bundle inventory in a verified include while
preserving declaration ownership and meaning priority.
''')
    plan=root/'experiments/issue-1580/work-plan.md';plan.write_text(plan.read_text()+'\n- Generated seed inventory extraction preserves the complete bundle function and all declaration owners byte for byte. Eight provenance cases, complete bundle parity, seven binding cases, role checks and two headroom contracts pass; canonical generator tests are registered with hosted workflow contracts. Both scanner thresholds stay unchanged and 74 warnings remain. Hosted execution and full issue acceptance remain open. See [seed registry headroom](../../docs/case-studies/issue-1580/seed-registry-headroom-checkpoint.md).\n')
    run('final-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-seed-registry,check-file-size,check-file-size-js-twin,check-readable-code,check-changelog-fragment-js-twin,check-fragment-release-map'])
    evidence=root/'experiments/issue-1580/evidence/checks/seed-registry-headroom';evidence.mkdir(exist_ok=False);archived=[];sources=[]
    for name in ['seed-registry-headroom','seed-registry-headroom-retry','seed-registry-headroom-final','seed-registry-headroom-commit',out.name]:
        parent=scratch/name;sources.extend((parent,file) for file in sorted(parent.rglob('*')) if file.is_file() and file.name not in ['worker.log','pid.json'])
    for name in ['draft-seed-registry-headroom.py','repair-headroom-validation-drafts.py','verify-seed-registry-inclusion.py','register-seed-generator-contracts.py',Path(__file__).name]:sources.append((scratch,scratch/name))
    for parent,file in sources:
        raw=file.read_bytes();packed=gzip.compress(raw,mtime=0);alias=parent.name+'/'+str(file.relative_to(parent))+'.gz';destination=evidence/alias;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed);assert gzip.decompress(destination.read_bytes())==raw
        archived.append({'file':alias,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
    (evidence/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in archived))
    files=['scripts/generate-seed-registry.mjs','scripts/generate-seed-registry.rs','rust/src/seed/embedded_registry.rs','rust/src/seed/embedded_files.rs','rust/tests/unit/workflow_contracts.rs','rust/tests/web/generated-seed-owner-provenance.test.mjs','rust/tests/web/bundled-seed-source-parity.test.mjs','rust/tests/web/seed-registry-headroom.test.mjs',str(evidence.relative_to(root)),note,fragment,'experiments/issue-1580/work-plan.md']
    run('stage',['git','add','--',*files]);run('naming',['node','scripts/measure-abbreviations.mjs','--check'])
    staged=subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=ACMRT','-z'],cwd=root).decode().split('\0')[:-1];assert not any('/evidence/ci/' in name for name in staged)
    run('secrets',['bash','scripts/check-secrets.sh',*staged]);run('whitespace',['git','diff','--cached','--check']);run('commit',['git','-c','gc.auto=0','commit','-m','Generate seed bundle inventory in a verified include'])
    result={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'records':len(archived),'pushed':False,'fullIssueComplete':False};(out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
