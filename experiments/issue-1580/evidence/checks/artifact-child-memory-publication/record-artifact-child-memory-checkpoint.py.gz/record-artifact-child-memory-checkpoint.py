from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, re

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
ci = root / 'experiments/issue-1580/evidence/ci/native-families-90b51590'
result = json.loads((ci / 'assessment.json').read_text())
assert result['terminalWorkflows'] == 27 and result['successfulWorkflows'] == 24
assert {row['id'] for row in result['failedWorkflows']} == {44804037588, 44804037844}
assert not result['failedPipelineJobs'] and result['nativeRustFailingTests'] == 0
archive = root / 'experiments/issue-1580/evidence/checks/artifact-child-memory-publication'
archive.mkdir(exist_ok=False)
files = []
for directory in ['macro-loading-heap-publication', 'artifact-repair-seal', 'published-evidence-filename-seal', 'codeql-child-memory-seal-corrected', 'feedback-after-child-memory-repair', 'time-dependency-publications-after-90b51590', 'completed-current-hive-jobs']:
    files.extend(path for path in (scratch / directory).rglob('*') if path.is_file() and path.name != 'pid')
for name in ['publish-macro-loading-heap-batch', 'seal-artifact-repair', 'commit-published-evidence-filenames', 'seal-codeql-child-memory-policy', 'refresh-issue-feedback-after-memory-repair', 'refresh-time-dependency-publications-after-90b51590', 'read-remaining-rust-cargo-parents', 'record-rust-parent-constraints-review', 'read-rust-codeql-release-metadata', 'record-rust-codeql-release-review', 'inspect-current-heap-producer-progress', 'inspect-completed-current-hive-jobs', 'collect-macro-loading-heap-head-ci', 'assess-artifact-and-child-memory-parent-ci']:
    for suffix in ['.py', '.log']:
        path = scratch / (name + suffix)
        if path.is_file(): files.append(path)
files.append(scratch / 'macro-loading-heap-head-ci/worker.log')
entries = []
for path in sorted(set(files)):
    relative = path.relative_to(scratch).as_posix()
    destination = re.sub(r'(?<=[/-])pr(?=[.-])', 'pull-request', relative)
    destination = archive / (destination + '.gz')
    destination.parent.mkdir(parents=True, exist_ok=True)
    value = path.read_bytes()
    packed = gzip.compress(value, mtime=0)
    assert not destination.exists()
    destination.write_bytes(packed)
    entries.append({'source': relative, 'file': destination.relative_to(archive).as_posix(), 'bytes': len(value), 'lines': len(value.splitlines()), 'rawSha256': hashlib.sha256(value).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest()})
parts = []
for offset in range(0, len(entries), 90):
    name = 'records-part-' + str(offset // 90 + 1) + '.json'
    raw = (json.dumps(entries[offset:offset+90], indent=2) + '\n').encode()
    assert len(raw.splitlines()) < 1400
    (archive / name).write_bytes(raw)
    parts.append({'file': name, 'entries': len(entries[offset:offset+90]), 'sha256': hashlib.sha256(raw).hexdigest()})
(archive / 'records.json').write_text(json.dumps({'schema': 'issue-1580-artifact-child-memory-publication/v1', 'parts': parts, 'entries': len(entries), 'allAggregateLinesLiterallyRead': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
checkpoint = f'''# Artifact transport and child-memory publication checkpoint

PR: https://github.com/link-assistant/formal-ai/pull/1581

Published `90b5159008da68c5c73534a5b5a4963b81deb04a` has 27 terminal
workflows: 24 successful, one explicitly skipped and two failed. All
{result['verifiedStreams']} retained command streams pass compressed/raw hashes,
byte lengths and line counts. The pipeline has no failing job and passes
{result['nativeRustPassingTests']} Rust cases plus eight actual registry CLI cases.
All three Hive shards pass within their unchanged twenty-minute clocks.
Per-job durations and original summary locations remain in the exact-head
assessment; this does not restore unmet original budgets or live acceptance.

## Complete observed failure batch

[Workflows 44804037588](https://github.com/link-assistant/formal-ai/actions/runs/44804037588)
uploads the Windows artifact successfully, then its first matching-name lookup
fails 1.073 seconds after finalization. Backend visibility delay is an inference,
not a proven service cause. The bounded adapter repair retries actual pinned
raw transport at most three times, resetting partial output before retries.
Digest, selector, cancellation, extraction and terminal failure boundaries stay
strict. Seven controls fail before repair. All 17 final artifact controls pass.
Actual next-head Windows, macOS and Linux behavior remains to be observed.

[Layered CI 44804037844](https://github.com/link-assistant/formal-ai/actions/runs/44804037844)
rejects an exact sparse-checkout expectation that omitted three newly consumed
timing inputs. Update only that expectation: all 18 profile and 50 shard/checkout
cases pass; production checkout already includes the three actual files.

The original manual Security producer succeeds with clean strict SARIF but
retains the 1,800 MB query-loading warning. The explicit launcher heap was
ineffective because query execution resolves a child evaluator. The candidate
retains a 4 GiB total allowance, resolves the actual dataset with zero off-heap,
requires a 2–4 GiB heap, and rejects retained runtime diagnostic lines before
decoding. The changed policy control fails before repair, and all 19 groups
pass afterward. The bounded 128 MiB configuration probes are not hosted query
execution. Actual resolved allocation and warning elimination remain pending.
See the [child-memory evidence](codeql-child-memory-checkpoint.md).

The final seal also finds thirteen abbreviated evidence filenames introduced
by the previous publication. Rename physical archives and their manifest paths,
preserving every original/compressed hash and historical source label. The
existing ninety-name ratchet is unchanged. Gates run after exact staging so
new files are included; retain the earlier failed gate and its correction.

## Remaining acceptance

Full pinned Rust literal review reaches 347/373 text identities and 44,421
original lines. The complete 1,433-line Cargo parent response distinguishes
compatible semver, platform, feature and dependency-kind constraints. All 267
original CodeQL release-metadata lines are read through five exact byte ranges,
then reassembled and hash-verified. Historical release claims establish no
present runtime or publication result. One binary image is reviewed separately.
Twenty-six identities and every unqualified practice remain open.

Fresh registry responses still show mandatory Chrono in command-stream 1.13.0
and link-calculator 0.24.0. A closed upstream issue is not a published migration.
Complete issue and PR conversation/inline/review feedback is retained. The failed
attempt to retrieve a completed Hive job log while its workflow was still
running is preserved separately from the eventual terminal downloads.

Strict original whole-source acceptance stays 31/53 with 22 separate scoped
assertion reviews. Remaining size/token/dependency warnings, all eight complete
template/practice comparisons, macro child semantics, actual Pages fallback and
publication, served/runtime/model identities, production Docker delivery,
independent reasoning and complete PR review remain unfinished. No local Rust
build or test runs. Supplied automation earns zero independent authorship;
accepted reasoning remains 0/20. Keep this PR draft and unmerged.
'''
(root / 'docs/case-studies/issue-1580/artifact-child-memory-publication-checkpoint.md').write_text(checkpoint)
plan = root / 'experiments/issue-1580/work-plan.md'
plan.write_text(plan.read_text() + f'''
### Terminal artifact and child-memory batch

- [x] Collect all 27 published 90b51590 workflows: 24 successes, one skip and both actionable failures. Verify all {result['verifiedStreams']} command streams and {result['nativeRustPassingTests']} Rust plus eight actual CLI cases; all three Hive shards pass without extending their clocks.
- [x] Commit bounded artifact retries, complete checkout expectations, thirteen physical evidence-name corrections and actual child-memory policy. Preserve failing-before controls and all failed probes. Rust literal review reaches 347/373 identities and 44,421 lines; current published Chrono consumers remain mandatory.
- [ ] Seal this complete batch after staging exact evidence, refresh main/feedback/empty queues, push only the prepared branch and collect actual next-head three-platform transport and child-memory producer execution.
- [ ] Complete every original, warning, template/practice, semantic, live delivery/publication, provenance and independent-reasoning criterion. Strict source acceptance remains 31/53 plus 22 separate scoped reviews; independent reasoning remains 0/20 and full issue completion is false.
''')
publication = scratch / 'artifact-child-memory-publication'
publication.mkdir(exist_ok=False)
body = (scratch / 'macro-loading-heap-publication/pull-request-body.md').read_text()
old = '- Set an explicit 3 GiB Java heap for the optional macro query after measured 2/3/4 GiB evaluator requests still produce undersized loading heaps. Retain the 4 GiB evaluator allowance, original SARIF gates, two threads, disk-cache limit and four-minute command budgets.'
assert old in body
body = body.replace(old, '- Resolve the optional macro query memory against its actual dataset before execution. Retain the 4 GiB total allowance with zero off-heap allocation, require a resolved 2–4 GiB heap and fail visibly on retained runtime diagnostics. Preserve original SARIF gates, two threads, disk-cache limit and command budgets. The previous launcher override did not survive child evaluator sizing.')
body = body.replace('Verification:\n', '''- Retry actual pinned raw artifact transport at most three times after an observed Windows matching-name lookup failure. Reset partial output before retrying; preserve strict digests, selectors, cancellation, validated extraction and terminal failure propagation. Complete the sparse-checkout expectation for its three consumed timing inputs.

Verification:

'''+f'''- Latest published `90b51590` has 27 terminal workflows: 24 success, one skip and two failures. [CI/CD Pipeline 44804037828](https://github.com/link-assistant/formal-ai/actions/runs/44804037828) passes {result['nativeRustPassingTests']} Rust plus eight actual CLI cases, including all three Hive shards within unchanged deadlines. All {result['verifiedStreams']} command streams are identity-verified. Workflows fails a Windows artifact lookup after successful upload; Layered CI fails an incomplete sparse-checkout expectation. Both local repairs are committed with 17 artifact, 18 profile and 50 shard controls passing, seven touched gates and retained failing-before evidence. Actual next-head transport and required checks remain pending. [Complete batch checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/artifact-child-memory-publication-checkpoint.md).
- [Manual Security 44804016891](https://github.com/link-assistant/formal-ai/actions/runs/44804016891) retains all 124 original producer files and clean strict SARIF, but the launcher override still leaves a 1,800 MB loading warning. All 631 original note positions match unexpanded contexts among 122,534 rows; per-child security/dataflow semantics remain unqualified. The corrected actual-dataset resolver policy has a failing-before control, 19 passing security groups and bounded configuration-only probes. New-head allocation and warning-free query execution remain pending. [Child memory checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/codeql-child-memory-checkpoint.md).

''')
body = body.replace('345/373 files and 42,721 lines', '347/373 files and 44,421 lines')
body = body.replace('next-head hosted checks for the new Hive partition and explicit macro Java heap', 'next-head hosted checks for bounded artifact retries, complete checkout expectations and actual CodeQL child allocation')
body = body.replace('Hosted execution of the new partition and loading-warning elimination remain unverified.', 'The published new Hive partition passes; corrected child allocation and loading-warning elimination require the next producer.')
body = body.replace('the explicit Java heap change requires its own fresh producer run.', 'the later explicit Java heap run also retains the warning; actual child resolution now requires its own fresh producer run.')
assert body.count('Fixes #1580') == 1
(publication / 'pull-request-body.md').write_text(body)
print(json.dumps({'archivedPayloads': len(entries), 'manifestParts': len(parts), 'templateFiles': 347, 'templateLines': 44421, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}))
