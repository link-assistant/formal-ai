from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,re
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
names=['rust-cargo-parent-review-first.log','rust-cargo-parent-review-second.log','rust-cargo-parent-review-third.log']
path='dev/log/issues/247/pulls/248/cargo-parent-requirements.json';raw=(scratch/'templates/rust-complete'/path).read_bytes();lines=raw.decode().splitlines();numbered={}
for name in names:
    for line in (scratch/name).read_text().splitlines():
        match=re.match(r'   (\d+): (.*)$',line)
        if match:
            number=int(match[1]);assert number not in numbered;numbered[number]=match[2]
assert sorted(numbered.items())==list(enumerate(lines,1)) and len(lines)==1433
ledger=root/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json';data=json.loads(ledger.read_text());assert (data['fullyReadFiles'],data['fullyReadSourceLines'])==(345,42721)
identities={row['path']:row for row in json.loads((root/data['all373BlobIdentitiesVerifiedBy']).read_text())}
digest=hashlib.sha256(raw).hexdigest();assert identities[path]['sha256']==digest
assert path not in {row['path'] for row in data['files']}
archive=root/'experiments/issue-1580/evidence/checks/rust-source-review';logs=json.loads((archive/'logs.json').read_text())
for name in names:
    value=(scratch/name).read_bytes();packed=gzip.compress(value,mtime=0);filename=name+'.gz';assert not (archive/filename).exists();(archive/filename).write_bytes(packed)
    logs.append({'file':filename,'rawSha256':hashlib.sha256(value).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
(archive/'logs.json').write_text(json.dumps(logs,indent=2)+'\n')
data['files'].append({'path':path,'lines':len(lines),'sha256':digest,'readLogs':[name+'.gz' for name in names],'literalReadRanges':[[1,1433]],'literalReadLines':1433,'literalSourceFullyRead':True,'formalAiPracticeImplementationVerified':False})
data['files'].sort(key=lambda row:row['path']);data['fullyReadFiles']=len(data['files']);data['fullyReadSourceLines']=sum(row['literalReadLines'] for row in data['files']);assert (data['fullyReadFiles'],data['fullyReadSourceLines'])==(346,44154)
data['observedAt']=datetime.now(timezone.utc).isoformat()
data['practiceDecisions'].append({'practice':'Resolve current compatible dependency parents and target features before removing older lock entries','templateEvidence':[path],'assessment':'All 1,433 original lines and the pinned blob digest are verified. The historical registry response distinguishes normal, build and development edges, platform cfg conditions, optional dependencies and default-feature settings. Ring still requires getrandom ^0.2.10; newer getrandom uses different backend/platform and WebAssembly feature constraints. Windows consumers require separate windows-sys ranges, including ^0.52 and ranges admitting 0.61; removing older versions solely because a newer number exists would break valid parent constraints. Proc-macro families constrain syn versions/features separately. Preserve the exact wasm-bindgen shared-version coupling. This historical metadata is not a current registry response, actual consumer execution, dependency removal or complete-practice qualification.','status':'literal-source-comparison-and-current-consumer-verification-pending'})
ledger.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'fullyReadFiles':346,'fullyReadSourceLines':44154,'remainingIdentities':27,'runtimeExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}))
