from pathlib import Path
import json,subprocess,gzip
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research/current-heap-producer-progress');scratch.mkdir(exist_ok=True)
latest=json.loads((root/'experiments/issue-1580/evidence/ci/native-families-90b51590/latest.json').read_text())
for run in latest['runs']:
 if run['status']=='completed':continue
 args=['gh','run','view',str(run['databaseId']),'--repo','link-assistant/formal-ai','--json','jobs']
 result=subprocess.run(args,cwd=root,capture_output=True);(scratch/(str(run['databaseId'])+'.stdout')).write_bytes(result.stdout);(scratch/(str(run['databaseId'])+'.stderr')).write_bytes(result.stderr)
 print('RUN',run['databaseId'],run['workflowName'],run['status'],'job lookup',result.returncode)
 if result.returncode==0:
  for job in json.loads(result.stdout)['jobs']:
   if job['status']!='completed' or job['conclusion'] not in ['success','skipped']:
    print(json.dumps({'id':job['databaseId'],'name':job['name'],'status':job['status'],'conclusion':job['conclusion'],'startedAt':job['startedAt'],'steps':[(step['name'],step['status'],step['conclusion']) for step in job['steps'] if step['status']!='completed' or step['conclusion']=='failure']},ensure_ascii=False))
