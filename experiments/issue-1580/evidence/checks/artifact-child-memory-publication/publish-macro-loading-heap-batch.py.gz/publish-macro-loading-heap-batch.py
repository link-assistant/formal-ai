from pathlib import Path
import json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/macro-loading-heap-publication')
body = base / 'pull-request-body.md'
assert body.read_text().count('Fixes #1580') == 1
records = []
def run(name, argv, parsed=False):
    result = subprocess.run(argv, cwd=root, capture_output=True)
    for label in ['stdout', 'stderr']:
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (base / 'publication-records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, (name, result.stderr.decode(errors='replace')[-2000:])
    return json.loads(result.stdout) if parsed else result.stdout.decode()
assert run('branch', ['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
assert not run('status-before', ['git', 'status', '--porcelain']).strip()
head = run('head', ['git', 'rev-parse', 'HEAD']).strip()
assert head == json.loads((base / 'expected-head.json').read_text())['head']
run('fetch-main', ['git', 'fetch', 'origin', 'main'])
main = run('main', ['git', 'rev-parse', 'origin/main']).strip()
run('main-ancestor', ['git', 'merge-base', '--is-ancestor', main, head])
for state in ['in_progress', 'queued']:
    rows = run(state, ['gh', 'run', 'list', '--repo', 'link-assistant/formal-ai', '--branch',
        'issue-1580-8d61a32a61e1', '--status', state, '--limit', '100', '--json',
        'databaseId,workflowName,headSha'], True)
    assert not rows, (state, rows)
assert run('remote-before', ['git', 'ls-remote', 'origin', 'refs/heads/issue-1580-8d61a32a61e1']).split()[0] == '1d7ba479b92fed6c1d6735b442579af9190a6b28'
latest = json.loads((root / 'experiments/issue-1580/evidence/ci/native-families-1d7ba479/outcome.json').read_text())
assert latest['complete'] and latest['workflowCount'] == 27 and not latest['failed']
pull = run('pull-request-before', ['gh', 'pr', 'view', '1581', '--repo', 'link-assistant/formal-ai',
    '--json', 'isDraft,headRefOid,state'], True)
assert pull['isDraft'] and pull['state'] == 'OPEN' and pull['headRefOid'] == latest['head']
run('edit-description', ['gh', 'pr', 'edit', '1581', '--repo', 'link-assistant/formal-ai', '--title',
    'Repair CI admission, release observations and container bootstrap', '--body-file', str(body)])
run('push', ['git', 'push', 'origin', 'HEAD:refs/heads/issue-1580-8d61a32a61e1'])
assert run('remote-after', ['git', 'ls-remote', 'origin', 'refs/heads/issue-1580-8d61a32a61e1']).split()[0] == head
run('dispatch-security', ['gh', 'workflow', 'run', 'security.yml', '--repo', 'link-assistant/formal-ai',
    '--ref', 'issue-1580-8d61a32a61e1', '-f', 'codeql=true', '-f', 'macro-contexts=true'])
assert not run('status-after', ['git', 'status', '--porcelain']).strip()
outcome = {'complete': True, 'head': head, 'main': main, 'pushExecuted': True,
    'manualSecurityDispatched': True, 'fullIssueComplete': False, 'independentReasoningCredit': 0}
(base / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
print(json.dumps(outcome))
