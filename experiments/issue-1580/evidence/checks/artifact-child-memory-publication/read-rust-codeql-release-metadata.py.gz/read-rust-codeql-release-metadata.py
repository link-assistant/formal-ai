from pathlib import Path
import hashlib,json,sys
path=Path('/tmp/issue-1580-research/templates/rust-complete/dev/log/issues/247/pulls/248/codeql-releases.json')
raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()=='095f996188323037448228c5c82bd83ccfdd168c3e476086f1eb6a6567ef33b1'
first,last=map(int,sys.argv[1:]);assert 0<=first<last<=len(raw) and last-first<=10000
print('FILE dev/log/issues/247/pulls/248/codeql-releases.json BYTES',len(raw),'RANGE',first,last,'SHA256',hashlib.sha256(raw).hexdigest())
print('RAW-CHUNK '+json.dumps(raw[first:last].decode(),ensure_ascii=True))
