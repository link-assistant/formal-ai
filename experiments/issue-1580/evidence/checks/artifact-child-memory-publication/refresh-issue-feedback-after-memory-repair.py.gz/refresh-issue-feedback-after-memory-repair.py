from pathlib import Path
import json, subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/feedback-after-child-memory-repair');out.mkdir(exist_ok=True)
requests=[('issue',['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','title,body,updatedAt']),('issue-comments',['gh','api','repos/link-assistant/formal-ai/issues/1580/comments','--paginate']),('pull-comments',['gh','api','repos/link-assistant/formal-ai/issues/1581/comments','--paginate']),('inline-comments',['gh','api','repos/link-assistant/formal-ai/pulls/1581/comments','--paginate']),('reviews',['gh','api','repos/link-assistant/formal-ai/pulls/1581/reviews','--paginate'])]
for name,args in requests:
    result=subprocess.run(args,cwd=root,capture_output=True)
    (out/(name+'.stdout')).write_bytes(result.stdout);(out/(name+'.stderr')).write_bytes(result.stderr)
    assert result.returncode==0,(name,result.stderr.decode())
    value=json.loads(result.stdout)
    if isinstance(value,dict):
        print(name,value['updatedAt'],value['title']);print(value['body'])
    else:
        print(name,len(value))
        for row in value:
            print(json.dumps({key:row.get(key) for key in ['id','html_url','updated_at','submitted_at','state','path','line','body']},ensure_ascii=False))
