from pathlib import Path
import hashlib,sys
path=Path('/tmp/issue-1580-research/templates/rust-complete/dev/log/issues/247/pulls/248/cargo-parent-requirements.json')
raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()=='82ff44e4230b3e8d598cb73f66e9d9ca1de6fd4036cb1653e608a1f9835ae3cc'
lines=raw.decode().splitlines();first,last=map(int,sys.argv[1:]);assert 1<=first<=last<=len(lines) and last-first<1500
print('FILE dev/log/issues/247/pulls/248/cargo-parent-requirements.json LINES',len(lines),'RANGE',first,last,'SHA256',hashlib.sha256(raw).hexdigest())
for number in range(first,last+1):print(str(number)+': '+lines[number-1])
