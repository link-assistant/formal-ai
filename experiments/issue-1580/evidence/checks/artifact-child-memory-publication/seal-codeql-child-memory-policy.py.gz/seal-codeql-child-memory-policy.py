from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/codeql-child-memory-seal-corrected');out.mkdir(exist_ok=True)
if len(sys.argv)==1:
    with (out/'worker.log').open('wb') as stream:
        child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid').write_text(str(child.pid));print('Started finite source/evidence seal',child.pid);raise SystemExit()
records=[]
def run(name,args):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        result=subprocess.run(args,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},stdout=stdout,stderr=stderr)
    records.append({'name':name,'argv':args,'exitCode':result.returncode})
    (out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,flush=True);assert result.returncode==0,name
    return (out/(name+'.stdout')).read_text()
assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
selected=['experiments/issue-1580/codeql-macro-contexts/observe.py','rust/tests/web/security-codeql-results.test.mjs','experiments/issue-1580/work-plan.md','docs/case-studies/issue-1580/codeql-child-memory-checkpoint.md','changelog.d/issue-1580-codeql-child-memory.md','experiments/issue-1580/evidence/checks/codeql-child-memory-policy','experiments/issue-1580/evidence/ci/codeql-producer-90b51590']
identities=[]
for name in selected:
    path=root/name
    for item in (sorted(path.rglob('*')) if path.is_dir() else [path]):
        if item.is_file():identities.append({'path':item.relative_to(root).as_posix(),'sha256':hashlib.sha256(item.read_bytes()).hexdigest()})
(out/'selection.json').write_text(json.dumps(identities,indent=2)+'\n')
run('stage',['git','add','--',*selected])
run('gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code'])
run('secret-selection',['bash','scripts/check-secrets.sh',*[row['path'] for row in identities]])
run('source-diff',['git','diff','--','experiments/issue-1580/codeql-macro-contexts/observe.py','rust/tests/web/security-codeql-results.test.mjs'])
run('whitespace',['git','diff','--check'])
for row in identities:assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256']
run('staged-whitespace',['git','diff','--cached','--check'])
run('commit',['git','commit','-m','fix: resolve CodeQL child heap within the retained memory budget'])
head=run('head',['git','rev-parse','HEAD']).strip()
(out/'outcome.json').write_text(json.dumps({'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'passed':True,'pushExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
