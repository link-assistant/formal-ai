from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
names = ['rust-codeql-release-review-' + part + '.log' for part in ['first', 'second', 'third', 'fourth', 'fifth']]
path = 'dev/log/issues/247/pulls/248/codeql-releases.json'
raw = (scratch / 'templates/rust-complete' / path).read_bytes()
chunks = []
for name in names:
    records = [line.removeprefix('   RAW-CHUNK ') for line in (scratch / name).read_text().splitlines() if line.startswith('   RAW-CHUNK ')]
    assert len(records) == 1
    chunks.append(json.loads(records[0]).encode())
assert b''.join(chunks) == raw
assert len(raw.splitlines()) == 267
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert (data['fullyReadFiles'], data['fullyReadSourceLines']) == (346, 44154)
identities = {row['path']: row for row in json.loads((root / data['all373BlobIdentitiesVerifiedBy']).read_text())}
digest = hashlib.sha256(raw).hexdigest()
assert identities[path]['sha256'] == digest
assert path not in {row['path'] for row in data['files']}
archive = root / 'experiments/issue-1580/evidence/checks/rust-source-review'
logs = json.loads((archive / 'logs.json').read_text())
for name in names:
    value = (scratch / name).read_bytes()
    packed = gzip.compress(value, mtime=0)
    filename = name + '.gz'
    assert not (archive / filename).exists()
    (archive / filename).write_bytes(packed)
    logs.append({'file': filename, 'rawSha256': hashlib.sha256(value).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest()})
(archive / 'logs.json').write_text(json.dumps(logs, indent=2) + '\n')
data['files'].append({'path': path, 'lines': 267, 'sha256': digest, 'readLogs': [name + '.gz' for name in names], 'literalReadRanges': [[1, 267]], 'literalReadLines': 267, 'literalSourceFullyRead': True, 'formalAiPracticeImplementationVerified': False})
data['files'].sort(key=lambda row: row['path'])
data['fullyReadFiles'] = len(data['files'])
data['fullyReadSourceLines'] = sum(row['literalReadLines'] for row in data['files'])
assert (data['fullyReadFiles'], data['fullyReadSourceLines']) == (347, 44421)
data['observedAt'] = datetime.now(timezone.utc).isoformat()
data['practiceDecisions'].append({'practice': 'Qualify release-specific CodeQL compatibility and diagnostics against the actual pinned producer', 'templateEvidence': [path], 'assessment': 'All 41,525 original bytes and 267 original lines are literally reviewed through five contiguous escaped-byte ranges with exact reassembly and pinned digest verification. The historical action notes distinguish path normalization, checkout path consistency, unsupported platform and CLI versions, overlay fallback and cache behavior, query-pack and per-language bundle compatibility, diagnostic filename collisions, SARIF polling and database-upload retries, remote configuration precedence and token/registry checks. Preserve those compatibility and transport distinctions. These historical release notes do not prove the current 2.27.5 producer allocation, complete semantic coverage, successful publication or adoption of every practice; use actual pinned runtime observations and focused controls.', 'status': 'literal-source-comparison-and-current-consumer-verification-pending'})
ledger.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps({'fullyReadFiles': 347, 'fullyReadSourceLines': 44421, 'remainingIdentities': 26, 'runtimeExecuted': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}))
