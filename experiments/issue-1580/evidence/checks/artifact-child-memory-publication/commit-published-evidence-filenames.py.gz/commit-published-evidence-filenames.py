from pathlib import Path
import json,subprocess,os
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/published-evidence-filename-seal');out.mkdir(exist_ok=True)
records=[]
def run(name,args):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:r=subprocess.run(args,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},stdout=stdout,stderr=stderr)
    records.append({'name':name,'argv':args,'exitCode':r.returncode});(out/'records.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0,name
    return (out/(name+'.stdout')).read_text()
assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
selected=run('selection',['git','diff','--cached','--name-only','--diff-filter=ACMRT']).splitlines()
assert len(selected)==25,len(selected)
run('abbreviations',['node','scripts/measure-abbreviations.mjs','--check'])
run('secrets',['bash','scripts/check-secrets.sh',*selected]);run('whitespace',['git','diff','--cached','--check'])
run('commit',['git','commit','-m','fix: preserve evidence identities with full archive filenames'])
(out/'outcome.json').write_text(json.dumps({'head':run('head',['git','rev-parse','HEAD']).strip(),'passed':True,'pushExecuted':False,'fullIssueComplete':False},indent=2)+'\n')
print('Committed the isolated thirteen-path filename repair after unchanged ratchet, secrets and whitespace checks.')
