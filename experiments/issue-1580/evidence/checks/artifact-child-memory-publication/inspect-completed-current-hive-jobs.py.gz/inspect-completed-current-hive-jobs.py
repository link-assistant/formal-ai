from pathlib import Path
import json,subprocess,re,datetime
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/completed-current-hive-jobs');out.mkdir(exist_ok=True)
result=subprocess.run(['gh','run','view','44804037828','--repo','link-assistant/formal-ai','--json','jobs'],cwd=root,capture_output=True);assert result.returncode==0
(out/'jobs.stdout').write_bytes(result.stdout);(out/'jobs.stderr').write_bytes(result.stderr)
for job in json.loads(result.stdout)['jobs']:
    if '(hive-' not in job['name'] or job['status']!='completed':continue
    result=subprocess.run(['gh','run','view','44804037828','--repo','link-assistant/formal-ai','--job',str(job['databaseId']),'--log'],cwd=root,capture_output=True)
    (out/(str(job['databaseId'])+'.stdout')).write_bytes(result.stdout);(out/(str(job['databaseId'])+'.stderr')).write_bytes(result.stderr);assert result.returncode==0
    print(job['name'],job['conclusion'],job['startedAt'],job['completedAt'])
    for step in job['steps']:
        if step['startedAt'] and step['completedAt']:
            start=datetime.datetime.fromisoformat(step['startedAt'].replace('Z','+00:00'));end=datetime.datetime.fromisoformat(step['completedAt'].replace('Z','+00:00'))
            print('STEP',step['name'],(end-start).total_seconds())
    for number,line in enumerate(result.stdout.decode().splitlines(),1):
        if re.search(r'test result:|hive.+(elapsed|finished)|seconds.*(passed|failed)|test .*\.\.\.',line):print(str(number)+': '+line)
