from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'artifact-child-memory-batch-seal'
out.mkdir(exist_ok=True)
if len(sys.argv) == 1:
    with (out / 'worker.log').open('wb') as stream:
        process = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    (out / 'pid').write_text(str(process.pid))
    print('Started finite evidence seal', process.pid)
    raise SystemExit()
records = []
def run(name, argv):
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        process = subprocess.run(argv, cwd=root, env={**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}, stdout=stdout, stderr=stderr)
    records.append({'name': name, 'argv': argv, 'exitCode': process.returncode})
    (out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, process.returncode, flush=True)
    assert process.returncode == 0, name
    return (out / (name + '.stdout')).read_text()
assert run('branch', ['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
archive = root / 'experiments/issue-1580/evidence/checks/artifact-child-memory-publication'
manifest = json.loads((archive / 'records.json').read_text())
verified = 0
for part in manifest['parts']:
    value = (archive / part['file']).read_bytes()
    assert hashlib.sha256(value).hexdigest() == part['sha256']
    entries = json.loads(value)
    assert len(entries) == part['entries']
    for row in entries:
        packed = (archive / row['file']).read_bytes()
        raw = gzip.decompress(packed)
        assert hashlib.sha256(packed).hexdigest() == row['archiveSha256']
        assert hashlib.sha256(raw).hexdigest() == row['rawSha256']
        assert len(raw) == row['bytes'] and len(raw.splitlines()) == row['lines']
        verified += 1
assert verified == manifest['entries']
for path in ['record-artifact-child-memory-checkpoint.py', 'record-artifact-child-memory-checkpoint.log', 'seal-artifact-child-memory-batch.py']:
    value = (scratch / path).read_bytes()
    packed = gzip.compress(value, mtime=0)
    (archive / (path + '.gz')).write_bytes(packed)
extras = []
for path in ['record-artifact-child-memory-checkpoint.py', 'record-artifact-child-memory-checkpoint.log', 'seal-artifact-child-memory-batch.py']:
    raw = (scratch / path).read_bytes()
    packed = (archive / (path + '.gz')).read_bytes()
    extras.append({'file': path + '.gz', 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
(archive / 'checkpoint-helper-records.json').write_text(json.dumps(extras, indent=2) + '\n')
selected = ['experiments/issue-1580/work-plan.md', 'docs/case-studies/issue-1580/artifact-child-memory-publication-checkpoint.md', 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json', 'experiments/issue-1580/evidence/checks/rust-source-review/logs.json', 'experiments/issue-1580/evidence/checks/artifact-child-memory-publication', 'experiments/issue-1580/evidence/ci/native-families-90b51590']
for prefix in ['rust-cargo-parent-review-', 'rust-codeql-release-review-']:
    selected.extend(path.relative_to(root).as_posix() for path in sorted((root / 'experiments/issue-1580/evidence/checks/rust-source-review').glob(prefix + '*.log.gz')))
identities = []
for relative in selected:
    path = root / relative
    for item in sorted(path.rglob('*')) if path.is_dir() else [path]:
        if item.is_file(): identities.append({'path': item.relative_to(root).as_posix(), 'sha256': hashlib.sha256(item.read_bytes()).hexdigest()})
(out / 'selection.json').write_text(json.dumps(identities, indent=2) + '\n')
run('stage', ['git', 'add', '--', *selected])
run('gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code'])
run('secrets', ['bash', 'scripts/check-secrets.sh', *[row['path'] for row in identities]])
run('whitespace', ['git', 'diff', '--cached', '--check'])
for row in identities: assert hashlib.sha256((root / row['path']).read_bytes()).hexdigest() == row['sha256']
run('commit', ['git', 'commit', '-m', 'docs: preserve terminal CI and complete repair-batch evidence'])
head = run('head', ['git', 'rev-parse', 'HEAD']).strip()
assert not run('status', ['git', 'status', '--porcelain']).strip()
(out / 'outcome.json').write_text(json.dumps({'head': head, 'passed': True, 'verifiedArchivedPayloads': verified, 'selectedFiles': len(identities), 'completedAt': datetime.now(timezone.utc).isoformat(), 'pushExecuted': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
(scratch / 'artifact-child-memory-publication/expected-head.json').write_text(json.dumps({'head': head}) + '\n')
