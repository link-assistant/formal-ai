import gzip
import json
import pathlib
import subprocess
import time

out=pathlib.Path('/tmp/issue-1580-research/bootstrap-source-fixes')
out.mkdir(exist_ok=True)
names=['rust/tests/web/ci-speed.test.mjs','rust/tests/web/native-test-artifact.test.mjs','experiments/issue-1580/ci-source-transport.test.mjs','.github/workflows/native-type-check.yml','.github/workflows/layered-ci.yml']
for name in names:
    (out/(name.replace('/','__')+'.before.gz')).write_bytes(gzip.compress(pathlib.Path(name).read_bytes(),mtime=0))
transport=pathlib.Path(names[2])
text=transport.read_text()
old='  assert.equal(files.length, 2);'
assert text.count(old)==1
text=text.replace(old,"  const captures = JSON.parse(read('experiments/issue-1580/fixtures/immutable-source-captures.json'));\n  files.push(...captures.map(row => row.archivePath));\n  assert.equal(files.length, 10);")
transport.write_text(text)
rows=[]
def run(label,args):
    start=time.monotonic()
    with (out/(label+'.log')).open('w') as stream:
        result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
    row={'label':label,'command':args,'exit':result.returncode,'seconds':round(time.monotonic()-start,3)}
    rows.append(row);print(json.dumps(row),flush=True)
    return result.returncode
node=['node','--max-old-space-size=256','--test','--test-concurrency=1']
assert run('sparse-before',node+[names[2]])==1

speed=pathlib.Path(names[0]);text=speed.read_text()
old="  assert.equal(shards[selected][0], behavior);"
assert text.count(old)==1
text=text.replace(old,"  // Four workers start together; newer measured suites may legitimately sort ahead.\n  assert(shards[selected].indexOf(behavior) < 4, 'the observed parent must start in the first worker wave');")
text=text.replace("observed behavior-range parent suites start separately without counting nested cases twice","observed behavior-range parent suites start in the first worker wave on a separate heavy shard")
speed.write_text(text)
artifact=pathlib.Path(names[1]);text=artifact.read_text()
old="assert.equal(consumers,98,'retain all 97 production transfers plus hosted qualification');"
assert text.count(old)==1
artifact.write_text(text.replace(old,"assert.equal(consumers,99,'retain all 97 production transfers, hosted qualification and native contract reuse');"))
native=pathlib.Path(names[3]);text=native.read_text()
old='      - uses: actions/download-artifact@v8\n'
assert text.count(old)==1
native.write_text(text.replace(old,'      - uses: ./.github/actions/download-artifact\n'))
layered=pathlib.Path(names[4]);text=layered.read_text()
needle='            /experiments/issue-1580/evidence/checks/native-coding-budget/*.stdout.gz\n'
assert text.count(needle)==1
captures=json.loads(pathlib.Path('experiments/issue-1580/fixtures/immutable-source-captures.json').read_text())
text=text.replace(needle,needle+''.join('            /'+row['archivePath']+'\n' for row in captures))
layered.write_text(text)
for name in [names[0],names[1],names[2],'experiments/issue-1580/immutable-source-captures.test.mjs']:
    assert run(pathlib.Path(name).stem+'-after',node+[name])==0
assert run('whitespace',['git','diff','--check'])==0
(out/'outcome.json').write_text(json.dumps(rows,indent=2)+'\n')
