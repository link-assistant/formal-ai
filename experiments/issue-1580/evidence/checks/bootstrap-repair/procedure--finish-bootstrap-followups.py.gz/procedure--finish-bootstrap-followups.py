from pathlib import Path
import gzip,subprocess,json,time,os
root=Path.cwd();out=Path('/tmp/issue-1580-research/bootstrap-followup-checks');out.mkdir(exist_ok=True)
path=root/'rust/tests/web/fast-pull-request-production-profile.test.mjs'
(out/'production-profile.before.gz').write_bytes(gzip.compress(path.read_bytes(),mtime=0))
text=path.read_text();old="/experiments/issue-1580/evidence/checks/native-coding-budget/*.stdout.gz\\n');"
new="/experiments/issue-1580/evidence/checks/native-coding-budget/*.stdout.gz\\n' +\n    JSON.parse(read('experiments/issue-1580/fixtures/immutable-source-captures.json'))\n      .map(row => '/' + row.archivePath + '\\n').join(''));"
assert text.count(old)==1;text=text.replace(old,new);path.write_text(text)
rows=[]
for label,args in [
 ('production-profile-after',['node','--test','--test-concurrency=1',str(path.relative_to(root))]),
 ('worker-currency',['node','--test','--test-concurrency=1','experiments/issue-1580/local-worker-currency.test.mjs']),
 ('source-transport',['node','--test','--test-concurrency=1','experiments/issue-1580/ci-source-transport.test.mjs']),
 ('whitespace',['git','diff','--check']),
]:
 start=time.monotonic()
 with (out/(label+'.log')).open('w') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'})
 row={'label':label,'command':args,'exit':r.returncode,'seconds':round(time.monotonic()-start,3)};rows.append(row);print(json.dumps(row),flush=True)
 (out/'outcome.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert r.returncode==0,label
