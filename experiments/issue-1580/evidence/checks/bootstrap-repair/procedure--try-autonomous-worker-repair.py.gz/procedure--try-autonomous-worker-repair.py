from pathlib import Path
import subprocess,json,shutil
root=Path.cwd();scratch=Path('/tmp/issue-1580-research');out=scratch/'autonomous-worker-import-repair';out.mkdir(exist_ok=True)
sandbox=root/'experiments/formal_ai_subagent/sandboxes/issue-1580-worker-import';sandbox.mkdir(parents=True,exist_ok=False)
for name in ['js/wasm-worker/src/lib.rs','js/wasm-worker/src/dialogue_rendering.rs']:
 target=sandbox/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,target);shutil.copyfile(root/name,out/(Path(name).name+'.before'))
shutil.copyfile(scratch/'bootstrap-hosted-round/44950896428-worker.log',sandbox/'compiler-failure.log')
request='Repair the browser worker compiler failure in compiler-failure.log. Inspect the relevant Rust source and its callers, then make the smallest source correction that preserves fact-check behavior. Keep the compiler warning policy. Do not compile or execute Rust locally.'
(out/'request.txt').write_text(request+'\n')
command=['node','--max-old-space-size=256','experiments/js_dogfood/drive.mjs','--dir',str(sandbox),'--steps','8',request]
with (out/'session.log').open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
changed=[]
for name in ['js/wasm-worker/src/lib.rs','js/wasm-worker/src/dialogue_rendering.rs']:
 raw=(sandbox/name).read_bytes();(out/(Path(name).name+'.after')).write_bytes(raw)
 if raw!=(root/name).read_bytes():changed.append(name)
(out/'outcome.json').write_text(json.dumps({'runtimeCommand':command,'returncode':r.returncode,'changed':changed,'independentlyAccepted':False,'nativeExecution':False},indent=2)+'\n');print((out/'outcome.json').read_text())
