import pathlib
import subprocess
import json

out=pathlib.Path('/tmp/issue-1580-research/local-worker-currency-checks')
test=pathlib.Path('experiments/issue-1580/local-worker-currency.test.mjs')
test.write_text(test.read_text().replace('\\\\n','\\n'))
runner=pathlib.Path('experiments/formal_ai_subagent/local-gates.mjs')
text=runner.read_text();needle="run: gate.run.replace(SCRIPT_TESTS, ''),"
assert text.count(needle)==1
text=text.replace(needle,"// Main rebuilds before diffing this binary; locally check recorded inputs without compiling.\n    run: jsOnly && gate.name === 'check-wasm-worker-current'\n      ? 'node scripts/wasm-worker-inputs.mjs --check'\n      : gate.run.replace(SCRIPT_TESTS, ''),")
runner.write_text(text)
node=['node','--max-old-space-size=256','--test','--test-concurrency=1']
rows=[]
for name in [str(test),'rust/tests/web/pull-request-1188-subagent-folder.test.mjs','rust/tests/web/pull-request-1188-working-rules.test.mjs','rust/tests/web/push-gate-rules.test.mjs']:
    with (out/(pathlib.Path(name).stem+'-after.log')).open('w') as stream:result=subprocess.run(node+[name],stdout=stream,stderr=subprocess.STDOUT)
    rows.append({'file':name,'exit':result.returncode})
    print(json.dumps(rows[-1]),flush=True)
    assert result.returncode==0
(out/'outcome.json').write_text(json.dumps(rows,indent=2)+'\n')
print(subprocess.run(['rg','-n','native-contract-artifact.test|hosted-worker-regeneration.test','rust/tests/web','experiments/issue-1580','-g','*.mjs'],text=True,capture_output=True).stdout)
