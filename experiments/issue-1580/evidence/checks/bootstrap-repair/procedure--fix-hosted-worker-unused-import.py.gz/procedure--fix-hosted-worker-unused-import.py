from pathlib import Path
import subprocess,json,gzip,hashlib,time,os
root=Path.cwd();scratch=Path('/tmp/issue-1580-research');out=scratch/'worker-unused-import-checks';out.mkdir(exist_ok=True)
p=root/'js/wasm-worker/src/lib.rs';before=p.read_bytes();needle=b'use dialogue_rendering::serialize_dialogue_answer;\n\n';assert before.count(needle)==1
(out/'lib.rs.before.gz').write_bytes(gzip.compress(before,mtime=0));p.write_bytes(before.replace(needle,b''))
assert (root/'js/wasm-worker/src/dialogue_rendering.rs').read_text().count('serialize_dialogue_answer(&content, &statements)')==1
env={**os.environ};env.pop('NODE_OPTIONS',None);rows=[]
commands=[('rustfmt',['rustfmt','--check','--edition','2024','--config','skip_children=true','js/wasm-worker/src/lib.rs']),('headroom',['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/final-native-headroom.test.mjs']),('worker-current',['node','--max-old-space-size=256','scripts/wasm-worker-inputs.mjs','--check']),('whitespace',['git','diff','--check'])]
for name,command in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 rows.append({'stage':name,'command':command,'returncode':r.returncode,'seconds':round(time.monotonic()-start,3)})
print(json.dumps(rows,indent=2));(out/'outcome.json').write_text(json.dumps(rows,indent=2)+'\n')
r=subprocess.run(['rg','-l','build-selected-wasm','rust/tests/web','experiments/issue-1580','--glob','*.mjs'],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);print('Existing worker recipe regressions:\n'+r.stdout)
