import json
import os
import pathlib
import subprocess
import sys
import time

out=pathlib.Path('/tmp/issue-1580-research/bootstrap-repair-validation')
out.mkdir(exist_ok=True)
if len(sys.argv)==1:
    entry=pathlib.Path('rust/tests/web/issue-1580-template-observations.test.mjs')
    text=entry.read_text();line="import '../../../experiments/issue-1580/local-worker-currency.test.mjs';\n"
    assert line not in text
    entry.write_text(text+line)
    with (out/'driver.log').open('w') as stream:
        process=subprocess.Popen([sys.executable,__file__,'worker'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({'pid':process.pid,'log':str(out/'driver.log')}));sys.exit()
rows=[]
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'}
commands=[
    ('all-local-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs']),
    ('maintained-entry',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs']),
    ('production-profile',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs']),
    ('rust-format',['rustfmt','--check','--edition','2024','--config','skip_children=true','js/wasm-worker/src/lib.rs']),
    ('whitespace',['git','diff','--check']),
]
for label,args in commands:
    start=time.monotonic()
    if not pathlib.Path(args[-1]).exists() and label=='production-profile':
        candidates=list(pathlib.Path('rust/tests/web').glob('*production*profile*.test.mjs'))
        assert len(candidates)==1,candidates
        args[-1]=str(candidates[0])
    with (out/(label+'.log')).open('w') as stream:
        result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,env=env)
    row={'label':label,'command':args,'exit':result.returncode,'seconds':round(time.monotonic()-start,3)}
    rows.append(row);print(json.dumps(row),flush=True)
    (out/'outcome.json').write_text(json.dumps(rows,indent=2)+'\n')
print('COMPLETE',flush=True)
