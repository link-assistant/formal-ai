from pathlib import Path
import gzip,hashlib,json,re,datetime
root=Path.cwd();scratch=Path('/tmp/issue-1580-research');out=root/'experiments/issue-1580/evidence/checks/bootstrap-repair'
out.mkdir(exist_ok=True)
results=json.loads((scratch/'bootstrap-repair-validation/outcome.json').read_text())
assert len(results)==5 and results[0]['exit']==1 and all(row['exit']==0 for row in results[1:] if row['label']!='production-profile'),results
followups=json.loads((scratch/'bootstrap-followup-checks/outcome.json').read_text())
assert len(followups)==4 and all(row['exit']==0 for row in followups)
gates=(scratch/'bootstrap-repair-validation/all-local-gates.log').read_text().splitlines()
counts={tag:sum(line.startswith(tag+' ') for line in gates) for tag in ['PASS','FAIL','SKIP']}
assert counts=={'PASS':87,'FAIL':1,'SKIP':53},counts
assert [line.split()[1] for line in gates if line.startswith('FAIL ')]==['check-wasm-worker-current']
entry=(scratch/'bootstrap-repair-validation/maintained-entry.log').read_text()
assert re.search(r'tests 332\b',entry) and re.search(r'pass 332\b',entry) and re.search(r'fail 0\b',entry)
companions=json.loads((scratch/'native-companion-repair/outcome.json').read_text())
assert companions[0]['exit']!=0 and all(row['exit']==0 for row in companions[1:])
rows=[]
def archive(path,label):
 raw=path.read_bytes();target=out/(label+'.gz');compressed=gzip.compress(raw,mtime=0);target.write_bytes(compressed)
 rows.append({'file':target.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'compressedBytes':len(compressed),'compressedSha256':hashlib.sha256(compressed).hexdigest()})
for directory in ['bootstrap-source-reproductions','bootstrap-source-fixes','local-worker-currency-checks','bootstrap-repair-validation','bootstrap-followup-checks','native-companion-repair','autonomous-worker-import-repair','worker-unused-import-checks','current-size-results']:
 for p in sorted((scratch/directory).iterdir()):
  if p.is_file():archive(p,directory+'--'+p.name)
for p in sorted((root/'experiments/formal_ai_subagent/sandboxes/gates').glob('*.log')):archive(p,'local-gate--'+p.name)
for name in ['fix-hosted-worker-unused-import.py','fix-bootstrap-source-failures.py','finish-bootstrap-source-fixes.py','draft-local-worker-currency-regression.py','fix-local-worker-currency.py','finish-local-worker-currency.py','validate-bootstrap-repairs.py','fix-native-contract-companions.py','finish-bootstrap-followups.py','archive-bootstrap-repair-checkpoint.py','try-autonomous-worker-repair.py','inspect-current-size-checks-driver.log','inspect-native-companion-failure-driver.log','review-current-source-batch-driver.log','collect-current-interface-failure-driver.log','fix-native-contract-companions-driver.log','fix-native-contract-companions-retry-driver.log','finish-bootstrap-followups-driver.log']:
 p=scratch/name
 if p.exists():archive(p,'procedure--'+name)
parts=[]
for offset in range(0,len(rows),100):
 name=f'manifest-files-{offset//100+1}.json';raw=(json.dumps(rows[offset:offset+100],indent=2)+'\n').encode();(out/name).write_bytes(raw)
 parts.append({'file':name,'files':len(rows[offset:offset+100]),'sha256':hashlib.sha256(raw).hexdigest()})
(out/'manifest.json').write_text(json.dumps({'schema':'issue-1580-bootstrap-repair-evidence/v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fileCount':len(rows),'parts':parts,'localGates':counts,'maintainedBeforeCompanionRepair':332,'autonomousAuthorshipCredit':0},indent=2)+'\n')
note='''# Bootstrap CI repair checkpoint

The first hosted worker regeneration at source `d1d11e603` failed under the
existing `-D warnings` policy: an unused forwarding import remained after its
serializer moved into the dialogue-rendering child module. Remove that dead
import; the actual serializer and its caller remain unchanged. The complete
selected-source WASM regression passes 18 cases without compiling Rust locally.
Actual worker compilation and its generated receipt remain required.

Layered CI run 44950901905 found three additional source-level defects. The
behavior-range suite still begins in the first four-worker wave when a newer,
measured heavier suite sorts before it; retain the longest-first order, complete
partition, heavy-suite separation and reverse-input determinism. Route the new
native artifact consumer through the existing strict raw-download adapter,
including its extraction closure in both checkout attempts. The actual hosted
direct downloader emitted DEP0005 at coding-1 job log line 621; no suppression
is added. Preserve the eight consumed immutable source captures explicitly in
the sparse checkout, while leaving unrelated historical archives excluded.

The local gate runner also had a real false negative: main rebuilds the worker
before its binary diff, while the local runner only diffed the unchanged binary.
Use the maintained input/byte manifest checker locally without compiling. A
finite real-Git fixture passes clean inputs, fails changed source inputs, and
fails changed binary bytes. The source-change case failed before this repair
because the old runner returned success. The canonical main gate is unchanged.

The first native artifact interface execution passed 77 cases and failed its
standalone wrapper launch at `with_formal_ai.rs:809`. The artifact selected three
test executables and `formal-ai`, but discarded the actual Cargo-produced
`with-formal-ai` executable. Select, hash, transport, verify and restore both
companion binaries. Reject either missing executable or changed bytes before
execution; preserve the existing source/compiler/run/attempt/recipe binding,
strict Cargo argument adapter and original native integration assertion. The
compiler-JSON regression fails before the repair. A small executable fixture
launches the restored standalone wrapper afterward; no local Rust build runs.

The full 141-entry local inventory records 87 passes, 53 explicit hosted-only
exclusions and one genuine stale-worker failure. The maintained entry before
the companion repair passes 332 cases; the repaired artifact module is checked
separately. Both actual file-size checks report zero warnings under unchanged
limits. Earlier nonzero warning totals in the chronological plan are historical.
All initial failures, fixture corrections and passing retries are retained in
`experiments/issue-1580/evidence/checks/bootstrap-repair/` with byte hashes.
The strict production-checkout expectation initially passed 20 of 21 cases;
adding those same eight consumed fixture paths restores all 21 passes without
relaxing checkout, permission, duration or unrelated-history assertions.

An actual small autonomous request to repair the unused import returned an
unsupported declared-create response and changed no source. The complete request,
response and before/after files are retained. Supplied procedures and conclusions
earn zero independent Formal AI authorship or reasoning credit; the 20 percent
authorship floor is still unmet. Template/practice reconciliation and exact-head
hosted verification remain separately unfinished. The pull request stays draft.

Pull request: https://github.com/link-assistant/formal-ai/pull/1581.
'''
(root/'docs/case-studies/issue-1580/bootstrap-ci-repair.md').write_text(note)
(root/'changelog.d/20261121_1580_bootstrap_ci_repairs.md').write_text('''### Fixed

- Reject stale worker inputs in local JavaScript gates without compiling Rust;
  remove an unused worker import that stopped warnings-as-errors compilation.
- Preserve consumed immutable fixtures in sparse CI checkouts and use the strict
  artifact extraction adapter for native contracts.
- Retain first-wave scheduling for measured heavy suites and transport both
  receipt-bound native companion binaries required by existing integration tests.
''')
path=root/'experiments/issue-1580/work-plan.md'
with path.open('a') as stream:stream.write('''

### 2026-11-21: complete bootstrap failure batch

- Repair the worker's actual unused-import compiler error without changing its
  serializer or caller. Hosted recompilation and receipt acceptance stay open.
- Reproduce and repair first-wave scheduling, strict native artifact transport,
  and the eight missing consumed sparse-checkout captures. Preserve all prior
  partition, inventory, digest and unrelated-history exclusion assertions.
- The corrected local worker gate now exposes stale inputs: 87 local passes,
  53 hosted-only exclusions, one genuine stale-worker failure. The finite fixture
  fails before repair and passes for clean/changed-source/changed-binary cases.
- Before the later companion repair, all 332 maintained observations pass. The
  current file-size gates report zero warnings with unchanged limits; earlier
  warning counts are historical. No source-warning exemption was introduced.
- The real hosted interface group passes 77 and fails one missing standalone
  companion. Transport and restore both actual compiler-selected binaries with
  complete receipt binding; keep the original integration assertion intact.
- Retain the failed autonomous request and supplied repair separately, with zero
  authorship/reasoning credit. The independent-authorship floor and wider original
  issue acceptance remain unfinished. See the bootstrap CI repair case study.

Pull request: https://github.com/link-assistant/formal-ai/pull/1581.
''')
print(json.dumps({'archived':len(rows),'localGates':counts,'maintainedBeforeCompanion':332,'workerHostedStillRequired':True}))
