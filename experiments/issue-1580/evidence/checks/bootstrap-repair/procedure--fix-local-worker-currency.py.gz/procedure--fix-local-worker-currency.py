import gzip
import json
import pathlib
import subprocess

out=pathlib.Path('/tmp/issue-1580-research/local-worker-currency-checks')
out.mkdir(exist_ok=True)
test=pathlib.Path('experiments/issue-1580/local-worker-currency.test.mjs')
text=test.read_text();needle="  const run = () => spawnSync(process.execPath, [runner, '--only', 'check-wasm-worker-current'], {"
assert text.count(needle)==1
text=text.replace(needle,"  for (const args of [['init', '-q'], ['add', '.'], ['-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.invalid', 'commit', '-qm', 'Worker fixture']]) {\n    const result = spawnSync('git', args, {cwd: directory, encoding: 'utf8'});\n    assert.equal(result.status, 0, result.stdout + result.stderr);\n  }\n"+needle)
test.write_text(text)
def run(label,args):
    with (out/(label+'.log')).open('w') as stream:result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
    print(json.dumps({'label':label,'command':args,'exit':result.returncode}),flush=True)
    return result.returncode
node=['node','--max-old-space-size=256','--test','--test-concurrency=1']
assert run('before',node+[str(test)])==1
runner=pathlib.Path('experiments/formal_ai_subagent/local-gates.mjs')
(out/'local-gates.mjs.before.gz').write_bytes(gzip.compress(runner.read_bytes(),mtime=0))
text=runner.read_text();needle='      run: gate.run.replace(SCRIPT_TESTS, \'\'),'
assert text.count(needle)==1
text=text.replace(needle,"      // Main rebuilds before diffing this binary; locally check the recorded inputs without compiling.\n      run: jsOnly && gate.name === 'check-wasm-worker-current'\n        ? 'node scripts/wasm-worker-inputs.mjs --check'\n        : gate.run.replace(SCRIPT_TESTS, ''),")
runner.write_text(text)
assert run('after',node+[str(test)])==0
for name in ['rust/tests/web/pull-request-1188-subagent-folder.test.mjs','rust/tests/web/pull-request-1188-working-rules.test.mjs','rust/tests/web/push-gate-rules.test.mjs']:
    assert run(pathlib.Path(name).stem,node+[name])==0
print(subprocess.run(['rg','-n','native-contract-artifact.test|hosted-worker-regeneration.test','rust/tests/web','experiments/issue-1580','-g','*.mjs'],text=True,capture_output=True).stdout)
