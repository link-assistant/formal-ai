import json
import pathlib
import subprocess
import time

out=pathlib.Path('/tmp/issue-1580-research/bootstrap-source-fixes')
native=pathlib.Path('.github/workflows/native-type-check.yml')
text=native.read_text();head,tail=text.split('  contract-family:\n',1)
old='          sparse-checkout: |\n            /*\n'
assert tail.count(old)==2
tail=tail.replace(old,old+'            /.github/actions/download-artifact/\n            /scripts/extract-artifacts.py\n')
native.write_text(head+'  contract-family:\n'+tail)
rows=[]
for name in ['rust/tests/web/native-test-artifact.test.mjs','experiments/issue-1580/ci-source-transport.test.mjs','experiments/issue-1580/immutable-source-captures.test.mjs','experiments/issue-1580/native-contract-artifact.test.mjs']:
    assert pathlib.Path(name).exists(),name
    args=['node','--max-old-space-size=256','--test','--test-concurrency=1',name]
    start=time.monotonic()
    with (out/(pathlib.Path(name).stem+'-final.log')).open('w') as stream:
        result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
    rows.append({'file':name,'command':args,'exit':result.returncode,'seconds':round(time.monotonic()-start,3)})
    print(json.dumps(rows[-1]),flush=True)
    assert result.returncode==0
(out/'final-outcome.json').write_text(json.dumps(rows,indent=2)+'\n')
print(subprocess.run(['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--list'],text=True,capture_output=True).stdout)
