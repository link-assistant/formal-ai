from pathlib import Path
import subprocess,gzip,json,time,os
root=Path.cwd();out=Path('/tmp/issue-1580-research/native-companion-repair');out.mkdir(exist_ok=True)
prior=json.loads(Path('/tmp/issue-1580-research/bootstrap-repair-validation/outcome.json').read_text())
assert len(prior)==5 and all(row['exit']==0 for row in prior[1:] if row['label']!='production-profile'),prior
script=root/'scripts/native-contract-artifact.mjs';test=root/'experiments/issue-1580/native-contract-artifact.test.mjs'
for path in [script,test]: (out/(path.name+'.before.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
text=test.read_text()
text=text.replace("three actual targets and the companion binary", "three actual targets and both actual companion binaries")
old="{reason:'compiler-artifact',target:{name:'formal-ai',kind:['bin']},profile:{test:false},executable:join(root,'rust/target/debug/formal-ai')}];"
new="...['formal-ai','with-formal-ai'].map(name=>({reason:'compiler-artifact',target:{name,kind:['bin']},profile:{test:false},executable:join(root,'rust/target/debug',name)}))];"
assert old in text;text=text.replace(old,new)
old="assert.deepEqual(Object.keys(selectContractExecutables(text(records),root)).sort(),[...CONTRACT_TARGETS,'formal-ai'].sort());"
new="assert.deepEqual(Object.keys(selectContractExecutables(text(records),root)).sort(),[...CONTRACT_TARGETS,'formal-ai','with-formal-ai'].sort());\n  assert.throws(()=>selectContractExecutables(text(records.slice(0,-1)),root),'missing standalone companion must fail before upload');"
assert old in text;text=text.replace(old,new);test.write_text(text)
rows=[]
def run(label,args):
 start=time.monotonic()
 with (out/(label+'.log')).open('w') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'})
 row={'label':label,'command':args,'exit':r.returncode,'seconds':round(time.monotonic()-start,3)};rows.append(row);print(json.dumps(row),flush=True)
 (out/'outcome.json').write_text(json.dumps(rows,indent=2)+'\n');return r.returncode
before=run('selector-before',['node','--test','--test-concurrency=1','--test-name-pattern=compiler JSON','experiments/issue-1580/native-contract-artifact.test.mjs']);assert before!=0
text=script.read_text()
text=text.replace("// Reuse only this workflow run's three focused native contract executables.","// Reuse only this workflow run's focused contracts and their actual companion binaries.")
needle="export const CONTRACT_TARGETS=Object.freeze(['coding_contracts','reasoning_contracts','interface_contracts']);"
assert needle in text;text=text.replace(needle,needle+"\nexport const COMPANION_BINARIES=Object.freeze(['formal-ai','with-formal-ai']);\nconst ARTIFACT_EXECUTABLES=Object.freeze([...CONTRACT_TARGETS,...COMPANION_BINARIES]);")
text=text.replace("targets:CONTRACT_TARGETS}","targets:CONTRACT_TARGETS,companions:COMPANION_BINARIES}")
text=text.replace("name==='formal-ai'&&row.target.kind.includes('bin')&&!row.profile.test?'formal-ai':null", "COMPANION_BINARIES.includes(name)&&row.target.kind.includes('bin')&&!row.profile.test?name:null")
text=text.replace("[...CONTRACT_TARGETS,'formal-ai'].sort()","[...ARTIFACT_EXECUTABLES].sort()")
text=text.replace("for(const name of [...CONTRACT_TARGETS,'formal-ai'])", "for(const name of ARTIFACT_EXECUTABLES)")
old="  const binary=resolve(cwd,'rust/target/debug/formal-ai');mkdirSync(resolve(cwd,'rust/target/debug'),{recursive:true});\n  copyFileSync(join(directory,'formal-ai'),binary);chmodSync(binary,0o755);"
new="  mkdirSync(resolve(cwd,'rust/target/debug'),{recursive:true});\n  for(const name of COMPANION_BINARIES) {\n    const binary=resolve(cwd,'rust/target/debug',name);\n    copyFileSync(join(directory,name),binary);chmodSync(binary,0o755);\n  }"
assert old in text;text=text.replace(old,new);script.write_text(text)
text=test.read_text().replace("function artifact(t) {", "function artifact(t,interfaceProgram) {")
text=text.replace("[...CONTRACT_TARGETS,'formal-ai']", "[...CONTRACT_TARGETS,'formal-ai','with-formal-ai']")
old="writeFileSync(file,'#!/usr/bin/env node\\nif(process.argv.includes(\"fail::case\"))process.exit(17);\\nconsole.log(JSON.stringify(process.argv.slice(2)));\\n');"
new="writeFileSync(file,name==='interface_contracts'&&interfaceProgram?interfaceProgram:'#!/usr/bin/env node\\nif(process.argv.includes(\"fail::case\"))process.exit(17);\\nconsole.log(JSON.stringify(process.argv.slice(2)));\\n');"
assert old in text;text=text.replace(old,new)
text+='''
test('the interface executable can launch its receipt-bound standalone wrapper', {timeout:5000}, t=>{
  const program=`#!/usr/bin/env node
import {spawnSync} from 'node:child_process';import {resolve} from 'node:path';
const result=spawnSync(resolve(process.cwd(),'rust/target/debug/with-formal-ai'),['--no-start-server'],{stdio:'inherit'});
if(result.error)throw result.error;process.exit(result.status??1);
`;
  const {root,directory,identity}=artifact(t,program);
  assert.equal(runContractArtifact(directory,identity,invocation('interface_contracts',['--test-threads=1','--nocapture']),root),0);
  for(const name of ['formal-ai','with-formal-ai'])assert.deepEqual(readFileSync(join(root,'rust/target/debug',name)),readFileSync(join(directory,name)));
  writeFileSync(join(directory,'with-formal-ai'),'tampered standalone wrapper');
  assert.throws(()=>runContractArtifact(directory,identity,invocation('interface_contracts',['--test-threads=1','--nocapture']),root),/artifact bytes changed: with-formal-ai/u);
});
'''
test.write_text(text)
assert run('native-artifact-after',['node','--test','--test-concurrency=1','experiments/issue-1580/native-contract-artifact.test.mjs'])==0
assert run('whitespace',['git','diff','--check'])==0
