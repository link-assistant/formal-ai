from pathlib import Path
import json,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');p=r/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json';a=json.loads(p.read_text());print('VISUAL',json.dumps(a['visualSourceReviews'],indent=2));print('LOG_MANIFEST',json.dumps(a['readLogManifest'],indent=2))
for x in json.loads(Path('/tmp/issue-1580-research/rust-final-evidence-index.json').read_text()):
 if x['contentKind']!='text':print('NON_TEXT',x['path'],x['contentKind'],x.get('logicalLines'))
for job in ['136236555877','136236555927']:
 p=subprocess.run(['gh','api','repos/link-assistant/formal-ai/actions/jobs/'+job],cwd=r,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert p.returncode==0,p.stderr;d=json.loads(p.stdout);print('CURRENT_NATIVE_JOB',json.dumps({k:d.get(k)for k in ['id','name','status','conclusion','started_at','completed_at','runner_name']}));print('STEPS',json.dumps([{k:s.get(k)for k in ['name','status','conclusion','started_at','completed_at']}for s in d['steps']]))
