from pathlib import Path
import json,gzip,hashlib,subprocess,datetime
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/ci/codeql-producer-1fd0c4fd';e=r/'experiments/issue-1580/evidence/checks/codeql-optional-context-publication';p=b/'producer-files.json';rows=json.loads(p.read_text());changes=[]
for row in rows:
 old=row['file']
 if '_temp_codeql-rust-contexts_' not in old:continue
 new=old.replace('_temp_codeql-rust-contexts_','temporary-rust-analysis-contexts-');raw=(b/old).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['archiveSha256'];assert hashlib.sha256(gzip.decompress(raw)).hexdigest()==row['rawSha256'];assert not(b/new).exists();(b/old).rename(b/new);row['file']=new;changes.append({'previousFile':old,'file':new,'rawSha256':row['rawSha256'],'archiveSha256':row['archiveSha256'],'producerRelativePathRetained':row['relativePath']})
assert len(changes)==9;p.write_text(json.dumps(rows,indent=2)+'\n')
for f in ['abbreviation-diagnostic.log']:
 raw=(e/f).read_bytes();(e/(f+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
receipt={'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cause':'Nine saved artifact filenames copied the producer temporary-directory abbreviation into maintained evidence filenames. The filename count rose from the unchanged baseline 90 to 99.','repair':'Spell the archive path prefix in full. Preserve every original compressed and decompressed byte, producer-relative path, artifact identity and hash. No ratchet or source threshold is changed.','renamed':changes,'initialFailedGate':'check-abbreviations.log.gz','initialFullDiagnostic':'abbreviation-diagnostic.log.gz','fullIssueComplete':False,'independentCredit':0};(e/'filename-correction.json').write_text(json.dumps(receipt,indent=2)+'\n')
subprocess.run(['git','add','--',str(b.relative_to(r)),str(e.relative_to(r))],cwd=r,check=True)
print('RENAMED_ARCHIVES_WITH_IDENTICAL_BYTES',len(changes))
