from pathlib import Path
import json
r=Path('/tmp/gh-issue-solver-1794900398048')
f='rust/tests/web/security-codeql-results.test.mjs';a=(r/f).read_text().splitlines();print('SOURCE',f,'LINES',len(a))
for i,s in enumerate(a,1):print(i,s)
b=Path('/tmp/issue-1580-research/rust-codeql-context-early-failure/contexts/_temp/codeql-rust-contexts/221d9a76c8fceaaa');m=json.loads((b/'metadata.json').read_text());messages=[json.loads(s)for s in(b/'build.jsonl').read_text().splitlines()]
built={v['package_id']for v in messages if v['reason']=='compiler-artifact'}
for p in m['packages']:
 node=next(n for n in m['resolve']['nodes']if n['id']==p['id'])
 if p['name'].startswith('serde')or any('serde_core@'in d['pkg']for d in node['deps']):
  print('OBSERVED_DEPENDENCY',json.dumps({'id':p['id'],'built':p['id']in built,'features':node['features'],'deps':node['deps'],'declaredDependencies':p['dependencies']}))
