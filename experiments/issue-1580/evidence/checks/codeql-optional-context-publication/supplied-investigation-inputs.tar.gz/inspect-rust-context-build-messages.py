from pathlib import Path
import json
b=Path('/tmp/issue-1580-research/rust-codeql-context-early-failure/contexts/_temp/codeql-rust-contexts/221d9a76c8fceaaa')
for name in ['Cargo.toml','build.jsonl','build.jsonl.stderr','metadata.json.stderr']:
 p=b/name;a=p.read_text().splitlines();print('FILE',name,'LINES',len(a))
 for n,s in enumerate(a,1):print(n,s)
x=json.loads((b/'metadata.json').read_text());print('ROOT',x['resolve']['root']);print('METADATA PACKAGES')
for p in x['packages']:
 print(json.dumps({k:p[k]for k in ['id','name','version','targets']}))
print('RESOLVE NODES');print(json.dumps(x['resolve']['nodes'],indent=2))
