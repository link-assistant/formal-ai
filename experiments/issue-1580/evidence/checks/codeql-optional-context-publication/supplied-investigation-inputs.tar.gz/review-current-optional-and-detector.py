from pathlib import Path
import subprocess,json
r=Path('/tmp/gh-issue-solver-1794900398048')
print('BRANCH',subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip())
print(subprocess.check_output(['git','status','--short','--untracked-files=normal'],cwd=r,text=True))
print('UNCOMMITTED_PRODUCTION_DIFF')
print(subprocess.check_output(['git','diff','--','scripts/codeql-rust-projects.py','rust/tests/web/security-codeql-results.test.mjs'],cwd=r,text=True))
print('LOCAL_DETECTOR_COMMIT')
print(subprocess.check_output(['git','show','--format=fuller','--stat','HEAD'],cwd=r,text=True))
print('ADAPTER_CURRENT_COMPLETE')
for i,line in enumerate((r/'scripts/codeql-rust-projects.py').read_text().splitlines(),1):print(f'{i}: {line}')
