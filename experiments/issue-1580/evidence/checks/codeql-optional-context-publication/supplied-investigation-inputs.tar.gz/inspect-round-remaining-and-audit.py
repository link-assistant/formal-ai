from pathlib import Path
import json,gzip,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');base=r/'experiments/issue-1580/evidence/ci/native-families-1fd0c4fd';a=json.loads((base/'latest.json').read_text())
for row in a['runs']:
 if row['status']=='completed':continue
 print('UNFINISHED',json.dumps(row))
 p=subprocess.run(['gh','run','view',str(row['databaseId']),'--repo','link-assistant/formal-ai','--json','jobs,status,conclusion,headSha'],stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert p.returncode==0,p.stderr
 result=json.loads(p.stdout);Path('/tmp/issue-1580-research/remaining-run-'+str(row['databaseId'])+'.json').write_bytes(p.stdout)
 for j in result['jobs']:print('JOB',j['databaseId'],j['name'],j['status'],j['conclusion'])
b=r/'experiments/issue-1580/evidence/ci/codeql-producer-1fd0c4fd';log=gzip.decompress((b/'job-136233430466.stdout.gz').read_bytes()).decode().splitlines()
print('AUDIT_ACTUAL_OUTPUT')
for n in range(520,min(len(log),548)+1):print(n,log[n-1])
