from pathlib import Path
import subprocess,json,hashlib,gzip,datetime
r=Path('/tmp/gh-issue-solver-1794900398048');e=r/'experiments/issue-1580/evidence/checks/codeql-active-optional-dependencies'
assert subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip()=='issue-1580-8d61a32a61e1'
a=json.loads((e/'validation.json').read_text())
for path,expected in a['sources'].items():assert hashlib.sha256((r/path).read_bytes()).hexdigest()==expected,path
for gate in ['release#1','check-changelog-fragment-js-twin']:
 with(e/(gate.replace('#','-')+'.log')).open('w')as out:ret=subprocess.run(['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only',gate],cwd=r,stdout=out,stderr=subprocess.STDOUT)
 print(gate,ret.returncode,flush=True);assert ret.returncode==0
receipts=[]
for log in sorted(e.glob('*.log')):
 raw=log.read_bytes();packed=gzip.compress(raw,mtime=0);dest=log.with_suffix(log.suffix+'.gz');dest.write_bytes(packed)
 receipts.append({'file':dest.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
(e/'log-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
a.update(recordedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),review={'completeCurrentAdapterRead':True,'completeAddedRegressionTestsAndDiffRead':True,'wholePullRequestReviewed':False,'independentReasoningCredit':0},additionalLocalChecks={'release#1':'pass','check-changelog-fragment-js-twin':'pass'})
(e/'validation.json').write_text(json.dumps(a,indent=2)+'\n')
paths=list(a['sources'])+[str(e.relative_to(r))]
subprocess.run(['git','add','--',*paths],cwd=r,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=r,check=True)
subprocess.run(['git','diff','--cached','--stat'],cwd=r,check=True)
ret=subprocess.run(['git','commit','-m','Honor optional dependency activation in Rust CodeQL contexts'],cwd=r,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);print(ret.stdout);assert ret.returncode==0
print('LOCAL_COMMIT',subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip());print('NOT_PUSHED_REMOTE_HEAD_CI_STILL_ACTIVE')
