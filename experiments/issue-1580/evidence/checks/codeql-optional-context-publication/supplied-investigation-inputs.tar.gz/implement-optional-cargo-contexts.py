from pathlib import Path
import subprocess,json,hashlib,datetime
r=Path('/tmp/gh-issue-solver-1794900398048');assert subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip()=='issue-1580-8d61a32a61e1'
e=r/'experiments/issue-1580/evidence/checks/codeql-active-optional-dependencies';before=(e/'before.log').read_text();assert 'ℹ fail 2' in before and 'Build script output absent' in before
p=r/'scripts/codeql-rust-projects.py';s=p.read_text();anchor='def dependency_graph(metadata, messages, host):\n';assert s.count(anchor)==1
helper='''def active_optional_dependencies(package, features):
    """Expand Cargo features without turning weak dep?/feature forwarding on."""
    pending, visited, active = list(features), set(), set()
    definitions = package.get("features", {})
    while pending:
        feature = pending.pop()
        if feature in visited:
            continue
        visited.add(feature)
        if feature.startswith("dep:"):
            active.add(feature[4:].replace("-", "_"))
        elif "/" in feature:
            dependency = feature.split("/", 1)[0]
            if not dependency.endswith("?"):
                active.add(dependency.replace("-", "_"))
        else:
            pending.extend(definitions.get(feature, []))
    return active


'''
s=s.replace(anchor,helper+anchor)
old='''    def normal_deps(pid):
        # --filter-platform already discards dependencies for other platforms.
        return [d for d in nodes[pid]["deps"] if any(k["kind"] is None for k in d["dep_kinds"])]
'''
new='''    def normal_deps(pid):
        # Cargo metadata retains inactive optional edges, even with platform filtering.
        # Resolve activation from the owning package, not from a dependency that
        # another build unit happened to compile (weak forwarding is not activation).
        package = packages.get(pid, {})
        active = active_optional_dependencies(package, nodes[pid]["features"])
        dependencies = []
        for dep in nodes[pid]["deps"]:
            targets = {k["target"] for k in dep["dep_kinds"] if k["kind"] is None}
            if not targets:
                continue
            declared = [d for d in package.get("dependencies", [])
                        if d["kind"] is None and d["target"] in targets
                        and (d.get("rename") or d["name"]).replace("-", "_") == dep["name"].replace("-", "_")]
            optional = declared and all(d["optional"] for d in declared)
            if not optional or dep["name"].replace("-", "_") in active:
                dependencies.append(dep)
        return dependencies
'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
p=r/'changelog.d/1580-codeql-optional-dependencies.md';assert not p.exists();p.write_text('bump: patch\n\nHonor Cargo feature activation when constructing standalone Rust CodeQL contexts, including renamed optional dependencies and weak feature forwarding.\n')
for label,cmd in [('after',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/security-codeql-results.test.mjs']),('diff-check',['git','diff','--check'])]:
 with(e/(label+'.log')).open('w')as out:ret=subprocess.run(cmd,cwd=r,stdout=out,stderr=subprocess.STDOUT)
 print(label,ret.returncode,flush=True);assert ret.returncode==0
sources=['scripts/codeql-rust-projects.py','rust/tests/web/security-codeql-results.test.mjs','rust/tests/fixtures/codeql/hosted-inactive-optional-dependency.json.gz','changelog.d/1580-codeql-optional-dependencies.md']
record={'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'cause':'Cargo metadata contains the inactive serde_core optional edge of toml_datetime, while cargo check correctly builds 13 dependency libraries without serde_core. The adapter had treated every normal metadata edge as active.','negativeControl':'15 existing groups pass and both new groups fail before the change; original captured metadata reproduces Build script output absent for serde_core 1.0.229.','localValidation':'All 17 groups pass after the change, including the unchanged SARIF gate, exact original Cargo metadata/build graph replay, seven feature/alias cases and refusal when required or activated build output is missing.','sourceCoverage':'No source file, finding or diagnostic exclusion; active required and optional dependencies retain their original build-output checks.','nativeBuildPerformedLocally':False,'hostedProducerVerification':'pending a new head after all current-head failures are collected','fullIssueComplete':False,'independentFormalAiReasoningCredit':0,'sources':{f:hashlib.sha256((r/f).read_bytes()).hexdigest()for f in sources}}
(e/'validation.json').write_text(json.dumps(record,indent=2)+'\n')
print('OPTIONAL_DEPENDENCY_ADAPTER_FIXED')
