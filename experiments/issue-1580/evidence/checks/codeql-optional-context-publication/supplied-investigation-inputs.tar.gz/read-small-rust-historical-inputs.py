from pathlib import Path
import json,hashlib
root=Path('/tmp/issue-1580-research/templates/rust-complete');rows=json.loads(Path('/tmp/issue-1580-research/rust-final-evidence-index.json').read_text());selected=sorted([x for x in rows if x['contentKind']=='text'and int(x['lines'])<=70],key=lambda x:x['path'])
for item in selected:
 raw=(root/item['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==item['sha256'];a=raw.decode().splitlines();print('FILE',item['path'],'LINES',len(a),'SHA256',item['sha256'])
 for n,s in enumerate(a,1):print(f'{n}: {s}')
