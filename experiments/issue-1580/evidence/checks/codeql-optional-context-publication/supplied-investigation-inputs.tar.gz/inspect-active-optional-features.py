from pathlib import Path
import json
b=Path('/tmp/issue-1580-research/rust-codeql-context-early-failure/contexts/_temp/codeql-rust-contexts/221d9a76c8fceaaa');m=json.loads((b/'metadata.json').read_text())
for p in m['packages']:
 if p['name']=='toml_datetime':print(json.dumps({k:p[k]for k in ['name','features','dependencies']},indent=2))
