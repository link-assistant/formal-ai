from pathlib import Path
import json,gzip,hashlib,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');b=Path('/tmp/issue-1580-research/rust-codeql-context-early-failure/contexts/_temp/codeql-rust-contexts/221d9a76c8fceaaa')
fixture={'metadata':json.loads((b/'metadata.json').read_text()),'messages':[json.loads(s)for s in(b/'build.jsonl').read_text().splitlines()]}
f=r/'rust/tests/fixtures/codeql/hosted-inactive-optional-dependency.json.gz';f.parent.mkdir(parents=True,exist_ok=True);assert not f.exists();raw=(json.dumps(fixture,sort_keys=True,separators=(',',':'))+'\n').encode();f.write_bytes(gzip.compress(raw,mtime=0))
p=r/'rust/tests/web/security-codeql-results.test.mjs';s=p.read_text();anchor="test('direct-rustc worker context uses the real WASM target and source paths'";i=s.index(anchor)
extra=r'''test('Cargo metadata inactive optionals preserve the exact hosted compiled dependency graph', {timeout: 20000}, () => {
  checkPython(String.raw`
import gzip
fixture = json.loads(gzip.decompress(pathlib.Path('rust/tests/fixtures/codeql/hosted-inactive-optional-dependency.json.gz').read_bytes()))
metadata, messages = fixture['metadata'], fixture['messages']
graph, dependencies = a.dependency_graph(metadata, messages, 'x86_64-unknown-linux-gnu')
root_id = metadata['resolve']['root']
compiled = {m['target']['name'] for m in messages if m['reason'] == 'compiler-artifact' and m['package_id'] != root_id}
assert len(graph) == 13
assert {c['display_name'] for c in graph} == compiled
assert 'serde_core' not in compiled
assert 'serde_core' in {p['name'] for p in metadata['packages']}
datetime = next(c for c in graph if c['display_name'] == 'toml_datetime')
assert datetime['cfg'] == ['feature="alloc"', 'feature="default"', 'feature="std"']
assert datetime['deps'] == []
assert {d['name'] for d in dependencies} == {'regex', 'toml_edit'}
for crate in graph:
    assert all(0 <= d['crate'] < len(graph) for d in crate['deps'])
`);
});

test('optional aliases and feature forwarding retain activated dependencies and required build data', {timeout: 20000}, () => {
  checkPython(String.raw`
import gzip, copy
fixture = json.loads(gzip.decompress(pathlib.Path('rust/tests/fixtures/codeql/hosted-inactive-optional-dependency.json.gz').read_bytes()))
for label, enabled, definitions, alias, expected in [
    ('weak only', ['std'], {'std': ['serde_core?/std']}, None, False),
    ('explicit dep', ['serde'], {'serde': ['dep:serde_core']}, None, True),
    ('strong forwarding', ['serde'], {'serde': ['serde_core/std']}, None, True),
    ('nested feature', ['serialization'], {'serialization': ['serde'], 'serde': ['dep:serde_core']}, None, True),
    ('renamed inactive', ['std'], {'std': ['serialization?/std']}, 'serialization', False),
    ('renamed active', ['serde'], {'serde': ['dep:serialization']}, 'serialization', True),
    ('hyphenated alias', ['serde'], {'serde': ['dep:serialization-data']}, 'serialization-data', True),
]:
    metadata = copy.deepcopy(fixture['metadata'])
    messages = copy.deepcopy(fixture['messages'])
    parent = next(p for p in metadata['packages'] if p['name'] == 'toml_datetime')
    node = next(n for n in metadata['resolve']['nodes'] if n['id'] == parent['id'])
    parent['features'], node['features'] = definitions, enabled
    if alias:
        parent['dependencies'][0]['rename'] = alias
        node['deps'][0]['name'] = alias.replace('-', '_')
    optional = next(p for p in metadata['packages'] if p['name'] == 'serde_core')
    # Even if another build unit compiled this package, a weak optional edge stays inactive.
    messages.append(dict(reason='build-script-executed',package_id=optional['id'],cfgs=['generated'],env=[],out_dir='/fixture/generated'))
    graph, _ = a.dependency_graph(metadata, messages, 'x86_64-unknown-linux-gnu')
    assert ('serde_core' in {c['display_name'] for c in graph}) == expected, label
    if expected:
        crate = next(c for c in graph if c['display_name'] == 'serde_core')
        assert 'generated' in crate['cfg']
        assert crate['env']['OUT_DIR'] == '/fixture/generated'
        messages.pop()
        try:
            a.dependency_graph(metadata, messages, 'x86_64-unknown-linux-gnu')
            raise AssertionError('activated optional build data silently lost: ' + label)
        except ValueError as error:
            assert 'Build script output absent' in str(error), str(error)
# A required dependency cannot disappear because its feature name is absent.
metadata = copy.deepcopy(fixture['metadata'])
parent = next(p for p in metadata['packages'] if p['name'] == 'toml_datetime')
parent['dependencies'][0]['optional'] = False
try:
    a.dependency_graph(metadata, fixture['messages'], 'x86_64-unknown-linux-gnu')
    raise AssertionError('required dependency silently lost')
except ValueError as error:
    assert 'Build script output absent' in str(error)
`);
});

'''
s=s[:i]+extra+s[i:];p.write_text(s)
e=r/'experiments/issue-1580/evidence/checks/codeql-active-optional-dependencies';e.mkdir(parents=True,exist_ok=True)
(e/'fixture-origin.json').write_text(json.dumps({'run':44720120798,'head':'1fd0c4fd131e318593299cfe05d0167f6efd35fc','job':136233430159,'artifact':14621054940,'artifactSha256':'844aef3f30f2dcbce12eb625b80d7eee987023008c804a77f187f41894accc3f','fixture':str(f.relative_to(r)),'fixtureRawSha256':hashlib.sha256(raw).hexdigest(),'fixtureGzipSha256':hashlib.sha256(f.read_bytes()).hexdigest(),'inputs':{name:hashlib.sha256((b/name).read_bytes()).hexdigest()for name in ['metadata.json','build.jsonl']},'transformation':'Parse both original files; combine the complete metadata and complete JSON build-message stream in a single object, serialize canonically and gzip. No metadata nodes or messages are omitted.','fullIssueComplete':False,'independentFormalAiReasoningCredit':0},indent=2)+'\n')
with (e/'before.log').open('w')as out:ret=subprocess.run(['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/security-codeql-results.test.mjs'],cwd=r,stdout=out,stderr=subprocess.STDOUT)
print('NEGATIVE_CONTROL_EXIT',ret.returncode);assert ret.returncode!=0
for n,line in enumerate((e/'before.log').read_text().splitlines(),1):
 if any(t in line for t in ['✖','Build script output absent','AssertionError','ℹ pass','ℹ fail']):print(n,line)
