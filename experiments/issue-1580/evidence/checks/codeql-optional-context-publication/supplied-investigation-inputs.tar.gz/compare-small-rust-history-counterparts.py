from pathlib import Path
import subprocess
r=Path('/tmp/gh-issue-solver-1794900398048')
for args in [['rg','-n','skip-decompress|deploy-pages|moby/buildkit|rhysd/actionlint|extract-artifacts|DEP0040|DEP0005','.github','scripts'],['rg','-n','js/|working-directory','js/.github/workflows/js.yml','.github/workflows/js.yml']]:
 p=subprocess.run(args,cwd=r,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);print('SEARCH',args,'EXIT',p.returncode);print(p.stdout)
for f in ['.github/actions/download-artifact/action.yml','scripts/extract-artifacts.py']:
 p=r/f;print('FILE',f,'EXISTS',p.exists())
 if p.exists():
  for i,s in enumerate(p.read_text().splitlines(),1):print(f'{i}: {s}')
