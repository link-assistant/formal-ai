from pathlib import Path
import subprocess,json,gzip,hashlib,os,datetime,tarfile,io
r=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');base=r/'experiments/issue-1580/evidence/checks/codeql-optional-context-publication';base.mkdir(exist_ok=False)
paths=['docs/case-studies/issue-1580/codeql-optional-dependency-checkpoint.md','docs/case-studies/issue-1580/README.md','docs/case-studies/issue-1580/templates/rust-source-review-progress.json','experiments/issue-1580/work-plan.md','experiments/issue-1580/evidence/checks/native-detector-admission','experiments/issue-1580/evidence/checks/rust-source-review','experiments/issue-1580/evidence/checks/production-diff-review-1fd0c4fd','experiments/issue-1580/evidence/ci/codeql-producer-1fd0c4fd']
subprocess.run(['git','add','--',*paths],cwd=r,check=True)
logs=[];env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'}
commands=[('documentation-policy',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/documentation-only-ci-policy.test.mjs']),('production-profile',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs'])]+[(gate,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate])for gate in ['check-abbreviations','check-file-size','check-file-size-js-twin']]+[('diff-check',['git','diff','--cached','--check'])]
for name,argv in commands:
 log=base/(name+'.log')
 with log.open('wb')as out:p=subprocess.run(argv,cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
 raw=log.read_bytes();packed=gzip.compress(raw,mtime=0);(base/(name+'.log.gz')).write_bytes(packed);logs.append({'name':name,'argv':argv,'exitCode':p.returncode,'file':name+'.log.gz','bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()});(base/'checks.json').write_text(json.dumps(logs,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0
helpers=['review-current-optional-and-detector.py','read-small-rust-historical-inputs.py','compare-small-rust-history-counterparts.py','inspect-rust-visual-and-review-manifest.py','record-small-rust-historical-review.py','draft-optional-context-checkpoint.py','commit-optional-dependency-fix.py','draft-optional-cargo-context-regression.py','implement-optional-cargo-contexts.py','assess-rust-context-producer-round.py','fetch-rust-context-failure-artifact.py','inspect-rust-context-build-messages.py','read-codeql-build-graph-regressions.py','inspect-active-optional-features.py','inspect-round-remaining-and-audit.py','validate-optional-context-publication-evidence.py']
contents=io.BytesIO();rows=[]
with tarfile.open(fileobj=contents,mode='w')as tar:
 for name in helpers:
  raw=(scratch/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;tar.addfile(info,io.BytesIO(raw));rows.append({'file':name,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
packed=gzip.compress(contents.getvalue(),mtime=0);(base/'supplied-investigation-inputs.tar.gz').write_bytes(packed);(base/'supplied-investigation-inputs.json').write_text(json.dumps({'files':rows,'archiveSha256':hashlib.sha256(packed).hexdigest(),'independentFormalAiReasoningCredit':0},indent=2)+'\n')
subprocess.run(['git','add','--',str(base.relative_to(r))],cwd=r,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=r,check=True)
subprocess.run(['git','diff','--cached','--stat'],cwd=r,check=True)
print('STAGED_EVIDENCE_VALIDATED_NO_PUSH')
