from pathlib import Path
import subprocess,json,zipfile,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');b=Path('/tmp/issue-1580-research/rust-codeql-context-early-failure')
p=subprocess.run(['gh','api','repos/link-assistant/formal-ai/actions/runs/44720120798/artifacts','--paginate'],cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(b/'early-artifacts.json').write_bytes(p.stdout);assert p.returncode==0,p.stderr
for a in json.loads(p.stdout)['artifacts']:
 print('ARTIFACT',a['id'],a['name'],a['size_in_bytes'])
 if not a['name'].startswith('codeql-rust-contexts-'):continue
 dest=b/(str(a['id'])+'.zip')
 with dest.open('wb')as out:ret=subprocess.run(['gh','api','repos/link-assistant/formal-ai/actions/artifacts/'+str(a['id'])+'/zip'],stdout=out,stderr=subprocess.PIPE)
 assert ret.returncode==0,ret.stderr;print('ARCHIVE_SHA256',hashlib.sha256(dest.read_bytes()).hexdigest())
 z=zipfile.ZipFile(dest);members=z.namelist();print('MEMBERS',json.dumps(members));z.extractall(b/'contexts')
for f in ['scripts/codeql-rust-projects.py','rust/tests/web/security-codeql-results.test.mjs']:
 p=r/f;a=p.read_text().splitlines();print('SOURCE',f,'LINES',len(a))
 if f.endswith('.py'):
  for n,s in enumerate(a,1):print(n,s)
