from pathlib import Path
import json,gzip,hashlib,collections,subprocess,datetime
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/ci/codeql-producer-1fd0c4fd';latest=json.loads((b/'latest.json').read_text());rows=json.loads((b/'records.json').read_text());files=json.loads((b/'producer-files.json').read_text());verified=0
for row in rows:
 for stream in ['stdout','stderr']:
  meta=row[stream];packed=(b/meta['file']).read_bytes();raw=gzip.decompress(packed);assert hashlib.sha256(packed).hexdigest()==meta['archiveSha256'];assert hashlib.sha256(raw).hexdigest()==meta['rawSha256'];assert len(raw)==meta['bytes'];assert len(raw.splitlines())==meta['lines'];verified+=1
for meta in files:
 packed=(b/meta['file']).read_bytes();raw=gzip.decompress(packed);assert hashlib.sha256(packed).hexdigest()==meta['archiveSha256'];assert hashlib.sha256(raw).hexdigest()==meta['rawSha256'];assert len(raw)==meta['bytes'];assert len(raw.splitlines())==meta['lines'];verified+=1
print('VERIFIED_ARCHIVE_STREAMS',verified)
print('FINAL_JOBS')
for job in latest['jobs']:print(json.dumps({k:job[k]for k in ['databaseId','name','conclusion']}))
summaries=[]
for meta in files:
 if not meta['relativePath'].endswith('.sarif'):continue
 sarif=json.loads(gzip.decompress((b/meta['file']).read_bytes()));summary={'artifact':meta['artifact']['id'],'file':meta['file'],'rawSha256':meta['rawSha256'],'bytes':meta['bytes'],'version':sarif['version'],'runs':[]}
 for run in sarif['runs']:
  notifications=[n for i in run.get('invocations',[])for k in ['toolExecutionNotifications','toolConfigurationNotifications']for n in i.get(k,[])]
  value={'tool':run['tool']['driver']['name'],'version':run['tool']['driver'].get('semanticVersion'),'results':run.get('results',[]),'successfulInvocations':[i.get('executionSuccessful')for i in run.get('invocations',[])],'notificationsByLevel':dict(collections.Counter(n.get('level','unspecified')for n in notifications)),'notificationIds':dict(collections.Counter(n.get('descriptor',{}).get('id','unspecified')for n in notifications))}
  summary['runs'].append(value)
 summaries.append(summary);print('SARIF_SUMMARY',json.dumps(summary))
e=r/'experiments/issue-1580/evidence/checks/codeql-active-optional-dependencies';assessment={'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run':44720120798,'head':'1fd0c4fd131e318593299cfe05d0167f6efd35fc','verifiedArchiveStreams':verified,'sarif':summaries,'jobs':[{k:j[k]for k in ['databaseId','name','conclusion']}for j in latest['jobs']],'rustAcceptance':'open: context preparation failed before init/analysis; no Rust SARIF exists','fullIssueComplete':False,'independentFormalAiReasoningCredit':0};(e/'hosted-round-assessment.json').write_text(json.dumps(assessment,indent=2)+'\n')
for name in ['job-136233430592.stdout.gz','job-136233430466.stdout.gz']:
 p=b/name;a=gzip.decompress(p.read_bytes()).decode().splitlines();print('DIAGNOSTICS',name,'LINES',len(a))
 for n,s in enumerate(a,1):
  if any(t in s.lower()for t in ['error','warning','codeql gate','validated sarif','advisories found','vulnerabilit']):print(n,s[:1300])
