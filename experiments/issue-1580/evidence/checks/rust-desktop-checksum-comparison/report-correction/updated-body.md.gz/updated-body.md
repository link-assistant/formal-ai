The desktop checksum step can hash the manifest it is currently writing. Fresh-output self-inclusion races directory enumeration; a pre-existing current output is deterministically included. When included, its recorded digest differs from the completed file. Reusing `desktop-dist` also includes checksum fragments left by earlier runs.

Observed on current default-branch commit `309387f761f9f0f1b2ea15bfe181cb51f5a9a1fb`, workflow blob `ecab57bcb89b29cf3d62f85137f461393630c170`, in [Create checksum fragment](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/blob/309387f761f9f0f1b2ea15bfe181cb51f5a9a1fb/.github/workflows/desktop-release.yml). The source remains unchanged in a fresh check on 2026-11-20. I reviewed the paginated issue inventory, including the original desktop workflow request #117, and did not find this checksum defect already reported.

Reproduction with two tiny local assets:

```sh
mkdir desktop-dist
printf 'first asset\n' > desktop-dist/app.zip
printf 'second asset\n' > 'desktop-dist/second asset.exe'
export MATRIX_LABEL=fixture
bash -e -o pipefail -c '
  cd desktop-dist
  if command -v sha256sum >/dev/null; then
    find . -type f -print0 | sort -z | xargs -0 sha256sum
  else
    find . -type f -exec shasum -a 256 {} +
  fi | sed "s#  \./#  #" > "SHA256SUMS-$MATRIX_LABEL.partial"
'
(cd desktop-dist && sha256sum -c SHA256SUMS-fixture.partial)
```

Actual: generation returns 0 and both asset checksums match. If the fresh redirected output is created before `find` enumerates, `SHA256SUMS-fixture.partial` also appears and fails its own verification; that ordering is not guaranteed across pipeline processes. To reproduce self-inclusion deterministically, create `desktop-dist/SHA256SUMS-fixture.partial` before running the unchanged command. Both the GNU `sha256sum` path and the `shasum -a 256` fallback include that pre-existing output. Adding a preexisting `SHA256SUMS-previous.partial` also makes the older fragment appear in the new manifest.

Expected: only produced asset files appear, each digest matches the file's final bytes, and checksum outputs are excluded on both branches even if the directory is reused.

A disposable candidate that excludes `SHA256SUMS-*.partial` from both `find` commands passes all four branch × clean/reused-directory controls. This is a proposed selection change, not an upstream repair. Building into a separate output location and moving it into place afterward is another possible approach, provided stale checksum fragments are excluded too.

The [reproduction and three regression controls](https://github.com/link-assistant/formal-ai/blob/c550990ec6f79948fc5795346d3b2f47313c5c5c/experiments/issue-1580/template-rust-desktop-checksums.test.mjs) and [source-bound probe](https://github.com/link-assistant/formal-ai/blob/c550990ec6f79948fc5795346d3b2f47313c5c5c/experiments/issue-1580/probe-rust-desktop-checksums.mjs) retain exact workflow/command identities. [Validation evidence](https://github.com/link-assistant/formal-ai/blob/c550990ec6f79948fc5795346d3b2f47313c5c5c/experiments/issue-1580/evidence/checks/rust-desktop-checksum-comparison/validation.json) includes the unchanged-source observations and the candidate-disabled failure. No Rust compilation or hosted release was needed for this finite reproduction. This was found while comparing templates for [formal-ai #1580](https://github.com/link-assistant/formal-ai/issues/1580).


Updated verification: the [eight-case fixture](https://github.com/link-assistant/formal-ai/blob/5bbbd91e39761a8e7163148b72a890b97c3d64b3/experiments/issue-1580/template-rust-desktop-checksums.test.mjs) distinguishes fresh and pre-existing current output, older-fragment absence/presence, and both hash implementations. It permits either fresh-output schedule for the unchanged command and requires exact asset-only digests for the candidate in every case. [Local verification](https://github.com/link-assistant/formal-ai/blob/5bbbd91e39761a8e7163148b72a890b97c3d64b3/experiments/issue-1580/evidence/checks/package-identity-and-checksum-race/verification.json) retains the passing fixture and candidate-disabled failure. Hosted confirmation of the updated fixture is pending.
