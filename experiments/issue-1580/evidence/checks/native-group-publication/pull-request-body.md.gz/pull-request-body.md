CI omitted native test inputs and allowed source ownership failures to pass unnoticed. This draft repairs those boundaries, task composition and retained-source behavior, and adds focused native replays. Issue #1580 remains unfinished; keep this PR draft and unmerged.

Fixes #1580

Changes:

- Preserve quoted task passages, request-local constraints, selected-child provenance and unresolved status for unverified drafts. Reuse source-bound calculation and counting evidence.
- Preserve multilingual lookup, explanation, calendar and controlled-language grammar behavior; regenerate maintained JavaScript, TypeScript, Rust and embedded projections through their official writers.
- Admit complete native reasoning, interface, Hive, workflow, benchmark and fixture source closures. Give expensive native contract families independent jobs with two concurrent matrix runners, preserving all 14 targets, single Rust test threads, failure propagation and the existing 20-minute clocks. The default complete runner remains available.
- Accept canonical IPv4 web operands while excluding attachment metadata. Keep equivalent domain-label boundaries in native and browser paths.
- Keep routine wrapper diagnostics in files unless wrapper verbosity is explicit. Forward client flags independently, and retain the original empty-stderr contract.
- Open closed-program sequence search using bounded atoms derived from actual ranked fragment types. Preserve actual IR content IDs and rejection stages when fragments, typing, backends or lowering fail; an empty frontier creates no attempt. Verification requirements remain intact.
- Replay current dialog and Hive physical fixtures while retaining real Git operations, failed-verifier evidence and original success/no-leak assertions.
- Reject failed or partial Git lockfile inventories before any Cargo audit. Preserve strict primary/experiment audit policies and missing-checkout failures.
- Retain pinned template comparisons, executable negative controls and linked upstream reports. Reporting a defect does not establish an upstream repair.

Verification:

- Published `e627fa30` completed 23 workflows: 22 succeeded, including [Layered CI](https://github.com/link-assistant/formal-ai/actions/runs/44648187871); the [pipeline](https://github.com/link-assistant/formal-ai/actions/runs/44648187857) was cancelled when native runtime reached its 20-minute job limit. Compilation succeeded in 4m21s, all 32 coding cases passed in 637.27s, and reasoning was still progressing at cancellation. No assertion failure was established by that run. Buffered background results and later skipped steps receive no credit.
- Native partition regression: 6 pass / 10 fail before the repair, then all 16 pass. The maintained build-policy entrypoint passes 69 tests; stale required-status checks pass all six. ShellCheck and shell parsing pass. All ten touched JavaScript gates pass, including file size, abbreviations, runner labels, CI speed and changelog reconstruction. No local Rust build runs. Hosted execution at `7fce5c19a7297a121d92eb09e7fefa99ca649eaf` remains pending.
- Java project-version release reproduction runs the unchanged pinned CLI against four disposable local Git repositories. Three parent/comment cases report success while the actual project version stays unchanged. A disposable candidate passes all four complete-byte preservation controls; disabling it reproduces the regression (1 pass / 1 fail). Both focused tests and all 54 tests in the maintained template entrypoint pass. No Maven build or hosted publication is claimed.
- The selected production review now covers all 106 selected diffs, with source/diff identities reverified. This is not a complete review of the whole PR. Java's exact 207-file pinned applicability map is complete (62 active, 145 historical); applicable practice implementation and runtime/dependency acceptance remain separate and unfinished.

Focused reproduction:

```sh
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/native-regression-groups.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-java-project-version.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/default-branch-build-policy.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/attachment-url-scope.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/rust-specification-unicode-identifiers.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/rust-specification-fixture-integrity.test.mjs
node experiments/formal_ai_subagent/local-gates.mjs
```

Hosted native CI executes `coding_contracts`, the original linked-list named-gap regression, wrapper flag-scope checks and the retained interface/Hive contracts. Rejected IR tests assert actual IDs, exact stages and absence of a selected artifact; the admission test fails before its source closure is added.

Earlier browser source-binding evidence uses a labeled production-worker harness with external requests blocked:

![Before: the Spanish definition frame is skipped](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/screenshots/issue-1580/meaning-hydration-before.png?raw=true)

![After: the definition routes to search and the unresolved sibling answer remains intact](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/screenshots/issue-1580/meaning-hydration-after.png?raw=true)

Unfinished acceptance is tracked in the [work plan](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/experiments/issue-1580/work-plan.md) and [case study](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/README.md): current-head hosted CI, the remaining original native and budget contracts, all eight complete template comparisons/applicability decisions, dependency migrations and warnings, historical cache/Docker evidence, live delivery/model identity, general binding/provenance and complete PR review. The strict original-source replay union remains 27/53; the completed cases in the cancelled run add no new qualifying original-source replay. Independently accepted Formal AI reasoning remains 0/20; supplied commands, patches and reviews earn no independent credit.
