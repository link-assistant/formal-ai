from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/computer-use-content-extraction')
if len(sys.argv) == 1:
    out.mkdir(exist_ok=False)
    with (out / 'worker.log').open('wb') as stream:
        worker = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print('Started finite source extraction checks', worker.pid)
    raise SystemExit()
records = []
def run(name, argv):
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=root, env={**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}, stdout=stdout, stderr=stderr)
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == 0, name
    return (out / (name + '.stdout')).read_text()
assert run('branch', ['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
parent = root / 'rust/src/computer_use/executor.rs'
child = parent.with_name('executor_content.rs')
assert not child.exists()
original = parent.read_text()
assert len(original.splitlines()) == 903
marker = 'fn filter_csv(content: &str, column: &str, expected: &str) -> Result<String, String> {'
assert original.count(marker) == 1
prefix, suffix = original.split(marker)
suffix = marker + suffix
assert suffix.count('\nfn ') == 4
imports = '#[path = "executor_content.rs"]\nmod content;\n\nuse content::{filter_csv, query_html, unique_csv};\n'
anchor = 'static SESSION_SEQUENCE: AtomicU64 = AtomicU64::new(0);'
assert prefix.count(anchor) == 1
new_parent = prefix.replace(anchor, imports + '\n' + anchor).rstrip() + '\n'
new_child = suffix
for name in ['filter_csv', 'unique_csv', 'query_html']:
    assert new_child.count('fn ' + name + '(') == 1
    new_child = new_child.replace('fn ' + name + '(', 'pub(super) fn ' + name + '(')
restored_child = new_child.replace('pub(super) fn ', 'fn ')
restored_parent = new_parent.replace(imports + '\n', '') + '\n'
assert restored_parent + restored_child == original
parent.write_text(new_parent)
child.write_text(new_child)
(out / 'original-executor.rs.gz').write_bytes(gzip.compress(original.encode(), mtime=0))
proof = {'observedAt': datetime.now(timezone.utc).isoformat(), 'parent': str(parent.relative_to(root)), 'child': str(child.relative_to(root)), 'originalSha256': hashlib.sha256(original.encode()).hexdigest(), 'originalLines': len(original.splitlines()), 'parentLines': len(new_parent.splitlines()), 'childLines': len(new_child.splitlines()), 'reassembledOriginalSha256': hashlib.sha256((restored_parent + restored_child).encode()).hexdigest(), 'exactOriginalReconstruction': True, 'behaviorChanges': False, 'localRustExecution': False, 'hostedNativeVerificationPending': True, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
assert proof['parentLines'] < 900 and proof['childLines'] < 900
(out / 'inverse-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
selected = [str(path.relative_to(root)) for path in [parent, child]]
run('stage-source', ['git', 'add', '--', *selected])
run('rust-format', ['rustfmt', '--edition', '2024', '--check', *selected])
run('computer-use-javascript', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/agentic-computer-use.test.mjs'])
run('translation-verify', ['node', 'scripts/translate-js-rust.mjs', '--verify'])
run('size-and-readability-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code'])
run('source-whitespace', ['git', 'diff', '--cached', '--check'])
(out / 'outcome.json').write_text(json.dumps({'passed': True, 'originalLines': 903, 'parentLines': proof['parentLines'], 'childLines': proof['childLines'], 'exactOriginalReconstruction': True, 'localRustExecution': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
