from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'computer-use-content-extraction-seal'
if len(sys.argv) == 1:
    out.mkdir(exist_ok=False)
    with (out / 'worker.log').open('wb') as stream:
        worker = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print('Started finite source evidence seal', worker.pid)
    raise SystemExit()
records = []
def run(name, argv):
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=root, env={**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}, stdout=stdout, stderr=stderr)
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == 0, name
    return (out / (name + '.stdout')).read_text()
source = scratch / 'computer-use-content-extraction'
assert json.loads((source / 'outcome.json').read_text())['passed']
commands = json.loads((source / 'commands.json').read_text())
assert len(commands) == 7 and all(command['exitCode'] == 0 for command in commands)
assert 'tests 13' in (source / 'computer-use-javascript.stdout').read_text()
archive = root / 'experiments/issue-1580/evidence/checks/computer-use-content-extraction'
archive.mkdir(exist_ok=False)
entries = []
files = [scratch / 'extract-computer-use-content.py', scratch / 'extract-computer-use-content.log', Path(__file__), *[path for path in source.iterdir() if path.is_file()]]
for path in sorted(files):
    raw = path.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    target = archive / (path.name + '.gz')
    assert not target.exists()
    target.write_bytes(packed)
    entries.append({'file': target.name, 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
(archive / 'records.json').write_text(json.dumps({'entries': entries, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
fragment = root / 'changelog.d/issue-1580-computer-use-content.md'
fragment.write_text('Keep the computer-use executor below its source-size warning threshold by moving its unchanged CSV/HTML fixture helpers into a private module. Preserve exact source reconstruction evidence and existing permission, workspace and verification behavior.\n')
plan = root / 'experiments/issue-1580/work-plan.md'
plan.write_text(plan.read_text() + '\n- Split the 903-line computer-use executor into 820-line execution and 87-line private content modules. Exact inverse reconstruction reproduces the original SHA-256 with unchanged helper bodies. Thirteen existing JavaScript computer-use cases, the current translation projection check, Rust formatting and four size/readability gates pass. No local Rust execution occurs; next-head hosted validation and every broader warning/issue criterion remain pending. Supplied work earns zero independent credit.\n')
selected = ['rust/src/computer_use/executor.rs', 'rust/src/computer_use/executor_content.rs', str(archive.relative_to(root)), str(fragment.relative_to(root)), str(plan.relative_to(root))]
assert run('branch', ['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
run('stage-source-evidence', ['git', 'add', '--', *selected])
run('archive-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code'])
inputs = []
for name in selected:
    path = root / name
    if path.is_dir():
        inputs.extend(item.relative_to(root).as_posix() for item in sorted(path.rglob('*')) if item.is_file())
    else:
        inputs.append(name)
run('secrets', ['bash', 'scripts/check-secrets.sh', *inputs])
run('whitespace', ['git', 'diff', '--cached', '--check'])
run('commit', ['git', 'commit', '-m', 'refactor: split private computer-use content helpers below size warning'])
head = run('head', ['git', 'rev-parse', 'HEAD']).strip()
(out / 'outcome.json').write_text(json.dumps({'passed': True, 'head': head, 'completedAt': datetime.now(timezone.utc).isoformat(), 'pushExecuted': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
