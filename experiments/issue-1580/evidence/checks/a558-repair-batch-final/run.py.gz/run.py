from pathlib import Path
import subprocess,json,datetime,os
s=Path('/tmp/issue-1580-research/a558-final-local-gates');r=Path('/tmp/gh-issue-solver-1794900398048')
with (s/'full-local-gates-after.log').open('w') as out:p=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs'],cwd=r,stdout=out,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'})
(s/'result.json').write_text(json.dumps({'exitCode':p.returncode,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':'node experiments/formal_ai_subagent/local-gates.mjs','localRustExecution':False,'autonomousAuthorshipCredit':0},indent=2)+'\n')
print('FULL_LOCAL_GATES_COMPLETED',p.returncode,flush=True)
