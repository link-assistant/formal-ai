from pathlib import Path
import os,subprocess,json,time
r=Path("/tmp/issue-1580-research/desktop-practice27-review-20261123")
checks=[("maintained-observations",["node","--max-old-space-size=192","--test","--test-concurrency=1","rust/tests/web/issue-1580-template-observations.test.mjs"]),("affected-gates",["node","--max-old-space-size=192","experiments/formal_ai_subagent/local-gates.mjs","--only","check-status-render,check-render-status-js-twin,check-generate-requirement-status-js-twin,check-required-documentation,check-readable-code,check-file-size,check-file-size-js-twin,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-changelog-fragment-js-twin"])]
head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
environment=dict(os.environ);environment.pop("NODE_OPTIONS",None);rows=[]
for name,cmd in checks:
 start=time.monotonic()
 with (r/(name+".stdout")).open("w") as out,(r/(name+".stderr")).open("w") as err:p=subprocess.run(cmd,env=environment,stdout=out,stderr=err)
 rows.append({"name":name,"command":cmd,"exitCode":p.returncode,"seconds":time.monotonic()-start})
 (r/"followup-checks.json").write_text(json.dumps(rows,indent=2)+"\n")
(r/"followup-outcome.json").write_text(json.dumps({"complete":True,"passed":all(x["exitCode"]==0 for x in rows),"head":head,"checks":rows},indent=2)+"\n")
