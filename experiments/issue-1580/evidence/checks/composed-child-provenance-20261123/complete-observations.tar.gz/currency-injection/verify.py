from pathlib import Path
import os,subprocess,json,time
r=Path('/tmp/issue-1580-research/calendar-currency-fixture-20261123')
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
cmd=['node','--max-old-space-size=192','--test','--test-concurrency=1','rust/tests/web/issue-1589-calendar-currency.test.mjs']
start=time.monotonic()
with (r/'after.stdout').open('w') as out,(r/'after.stderr').open('w') as err:p=subprocess.run(cmd,env=env,stdout=out,stderr=err)
(r/'after.json').write_text(json.dumps({'command':cmd,'exitCode':p.returncode,'seconds':time.monotonic()-start},indent=2)+'\n')
