from pathlib import Path
import os,subprocess,json,time,resource
r=Path('/tmp/issue-1580-research/calendar-currency-fixture-20261123')
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
cmd=['node','--max-old-space-size=512','--test','--test-concurrency=1','rust/tests/web/issue-1589-calendar-currency.test.mjs']
start=time.monotonic()
with (r/'after-measured.stdout').open('w') as out,(r/'after-measured.stderr').open('w') as err:
 p=subprocess.Popen(cmd,env=env,stdout=out,stderr=err)
 _,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
(r/'after-measured.json').write_text(json.dumps({'command':cmd,'exitCode':p.returncode,'seconds':time.monotonic()-start,'peakChildRssKiB':usage.ru_maxrss,'initial192MiBFailurePreserved':True},indent=2)+'\n')
