from pathlib import Path
import subprocess,json,os,time
root=Path('/tmp/issue-1580-research/composed-child-provenance-20261123')
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
checks=[
 ('governed-source-integrity',['node','--max-old-space-size=512','--test','--test-concurrency=1','rust/tests/web/rust-specification-unicode-identifiers.test.mjs']),
 ('gates-corrected',['node','--max-old-space-size=512','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-file-size-js-twin,check-hardcoded-language,check-hardcoded-language-js-twin,check-twin-citations,check-specification-in-javascript,check-runtime-feature-inventory,check-self-translation,check-readable-code,check-prompt-specialization,check-changelog-fragment-js-twin,release#1'])
]
results=[]
for name,cmd in checks:
 start=time.time()
 with (root/(name+'.stdout')).open('w') as out,(root/(name+'.stderr')).open('w') as err:
  r=subprocess.run(cmd,stdout=out,stderr=err,env=env)
 results.append({'name':name,'command':cmd,'exitCode':r.returncode,'durationSeconds':time.time()-start});(root/'corrected-checks.json').write_text(json.dumps(results,indent=2)+'\n')
(root/'corrected-outcome.json').write_text(json.dumps({'complete':True,'allPassed':all(x['exitCode']==0 for x in results),'checks':results},indent=2)+'\n')
