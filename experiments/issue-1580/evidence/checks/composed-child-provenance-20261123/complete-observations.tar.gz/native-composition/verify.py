from pathlib import Path
import subprocess,json,os,time,resource
root=Path('/tmp/issue-1580-research/composed-child-provenance-20261123')
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
checks=[
 ('rustfmt',['rustfmt','--edition','2024','--check','rust/src/solver_synthesis.rs','rust/tests/fixtures/synthesis-parent-tests.rs']),
 ('procedural-runtime-parity',['node','--max-old-space-size=512','--test','--test-concurrency=1','rust/tests/web/procedural-runtime-parity.test.mjs']),
 ('template-identities',['node','--max-old-space-size=192','--test','--test-concurrency=1','experiments/issue-1580/template-source-identities.test.mjs']),
 ('source-projection',['node','--max-old-space-size=512','scripts/translate-js-rust.mjs','--verify']),
 ('procedural-integration',['node','--max-old-space-size=512','experiments/issue-1580/review-procedural-main-integration.mjs']),
 ('gates',['node','--max-old-space-size=512','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-hardcoded-language,check-twin-citations,check-specification-in-javascript,check-runtime-feature-inventory,check-self-translation,check-readable-code,check-prompt-specialization,check-changelog-fragment'])
]
results=[]
for name,cmd in checks:
 started=time.time()
 with (root/(name+'.stdout')).open('w') as out,(root/(name+'.stderr')).open('w') as err:
  run=subprocess.run(cmd,stdout=out,stderr=err,env=env)
 result={'name':name,'command':cmd,'exitCode':run.returncode,'durationSeconds':time.time()-started}
 results.append(result);(root/'checks.json').write_text(json.dumps(results,indent=2)+'\n')
(root/'outcome.json').write_text(json.dumps({'complete':True,'allPassed':all(x['exitCode']==0 for x in results),'checks':results},indent=2)+'\n')
