from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'unknown-reasoning-text-extraction'
if len(sys.argv) == 1:
    out.mkdir(exist_ok=False)
    with (out / 'worker.log').open('wb') as stream:
        worker = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print('Started finite reasoning source extraction', worker.pid)
    raise SystemExit()
records = []
def run(name, argv):
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=root, env={**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}, stdout=stdout, stderr=stderr)
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == 0, name
    return (out / (name + '.stdout')).read_text()
assert not run('index-before', ['git', 'diff', '--cached', '--name-only']).strip()
assert run('branch', ['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
parent = root / 'rust/src/solver_unknown_reasoning.rs'
child = parent.with_name('solver_unknown_reasoning_text.rs')
assert not child.exists()
original = parent.read_text()
assert len(original.splitlines()) == 932
start = original.index('fn extract_memory_fact(text: &str) -> Option<(String, String)> {')
end = original.index('#[cfg(test)]', start)
block = original[start:end]
assert block.count('\nfn ') == 4 and block.endswith('\n\n')
new_child = block[:-1]
for name in ['extract_memory_fact', 'clean_focus', 'normalize_fact_subject', 'normalize_search_surface']:
    assert new_child.count('fn ' + name + '(') == 1
    new_child = new_child.replace('fn ' + name + '(', 'pub(super) fn ' + name + '(')
imports = '#[path = "solver_unknown_reasoning_text.rs"]\nmod text;\n\nuse text::{\n    clean_focus, extract_memory_fact, normalize_fact_subject, normalize_search_surface,\n};\n\n'
anchor = 'const FOCUS_PLACEHOLDER: &str = concat!("{", "focus", "}");'
assert original.count(anchor) == 1
new_parent = (original[:start] + original[end:]).replace(anchor, imports + anchor)
restored_child = new_child.replace('pub(super) fn ', 'fn ') + '\n'
restored_parent = new_parent.replace(imports, '')
assert restored_parent.count('#[cfg(test)]') == 1
restored = restored_parent.replace('#[cfg(test)]', restored_child + '#[cfg(test)]')
assert restored == original
parent.write_text(new_parent)
child.write_text(new_child)
proof = {'observedAt': datetime.now(timezone.utc).isoformat(), 'originalSha256': hashlib.sha256(original.encode()).hexdigest(), 'reassembledOriginalSha256': hashlib.sha256(restored.encode()).hexdigest(), 'originalLines': 932, 'parentLines': len(new_parent.splitlines()), 'childLines': len(new_child.splitlines()), 'exactOriginalReconstruction': True, 'testModulePathUnchanged': True, 'localRustExecution': False, 'hostedNativeVerificationPending': True, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
assert proof['parentLines'] < 900 and proof['childLines'] < 900
(out / 'inverse-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
(out / 'original-source.rs.gz').write_bytes(gzip.compress(original.encode(), mtime=0))
source_paths = [str(path.relative_to(root)) for path in [parent, child]]
run('rust-format', ['rustfmt', '--edition', '2024', '--check', *source_paths])
run('unknown-language-javascript', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/worker-unknown-language.test.mjs'])
archive = root / 'experiments/issue-1580/evidence/checks/unknown-reasoning-text-extraction'
archive.mkdir(exist_ok=False)
entries = []
for path in sorted([Path(__file__), *[path for path in out.iterdir() if path.is_file() and path.name != 'worker.log']]):
    raw = path.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    target = archive / (path.name + '.gz')
    target.write_bytes(packed)
    entries.append({'file': target.name, 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
(archive / 'records.json').write_text(json.dumps({'entries': entries, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
fragment = root / 'changelog.d/issue-1580-computer-use-content.md'
fragment.write_text(fragment.read_text() + '\nMove unchanged unknown-reasoning text and memory-fact helpers into a private module, preserving the original native test module path and source reconstruction.\n')
plan = root / 'experiments/issue-1580/work-plan.md'
plan.write_text(plan.read_text() + '\n- Remove the 932-line unknown-reasoning source warning by moving five unchanged text/memory helpers into a private module. Exact inverse reconstruction restores every original byte and the existing native test path stays unchanged. Focused JavaScript unknown-language checks and Rust formatting pass; native compilation and the unchanged captured-source tests remain required on the next published head. No wider issue completion or independent reasoning credit.\n')
selected = [*source_paths, str(archive.relative_to(root)), str(fragment.relative_to(root)), str(plan.relative_to(root))]
run('stage-source-evidence', ['git', 'add', '--', *selected])
run('size-and-readability-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code'])
inputs = []
for relative in selected:
    path = root / relative
    inputs.extend(item.relative_to(root).as_posix() for item in sorted(path.rglob('*')) if item.is_file()) if path.is_dir() else inputs.append(relative)
run('secrets', ['bash', 'scripts/check-secrets.sh', *inputs])
run('whitespace', ['git', 'diff', '--cached', '--check'])
run('commit', ['git', 'commit', '-m', 'refactor: split unknown-reasoning text helpers below size warning'])
head = run('head', ['git', 'rev-parse', 'HEAD']).strip()
(out / 'outcome.json').write_text(json.dumps({'passed': True, 'head': head, 'parentLines': proof['parentLines'], 'childLines': proof['childLines'], 'pushExecuted': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
