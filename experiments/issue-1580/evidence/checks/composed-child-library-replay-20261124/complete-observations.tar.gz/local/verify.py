from pathlib import Path
import datetime,json,os,resource,subprocess,time
root=Path('/tmp/issue-1580-research/composed-child-library-replay-20261124')
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
checks=[
 ('native-groups',['node','--max-old-space-size=512','--test','--test-concurrency=1','experiments/issue-1580/native-regression-groups.test.mjs']),
 ('native-policy',['node','--max-old-space-size=512','--test','--test-concurrency=1','rust/tests/web/default-branch-build-policy.test.mjs']),
 ('workflow-gates',['node','--max-old-space-size=512','experiments/formal_ai_subagent/local-gates.mjs','--only','check-ci-speed,check-runner-labels,workflows,check-changelog-fragment-js-twin,check-file-size,check-file-size-js-twin,check-readable-code,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-required-documentation,check-twin-citations'])
]
records=[]
for name,command in checks:
 start=time.monotonic()
 with (root/(name+'.stdout')).open('wb') as out,(root/(name+'.stderr')).open('wb') as err:
  result=subprocess.run(command,stdout=out,stderr=err,env=env)
 records.append({'name':name,'command':command,'exitCode':result.returncode,'seconds':time.monotonic()-start,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 (root/'checks.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(records[-1]),flush=True)
(root/'outcome.json').write_text(json.dumps({'complete':True,'passed':all(r['exitCode']==0 for r in records),'checks':len(records),'noLocalRustBuild':True},indent=2)+'\n')
