from pathlib import Path
import subprocess,json
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/compressed-secrets')
for suffix in ['stdout','stderr','json']:
 p=s/('changed-evidence-audit.'+suffix);target=s/('profiler-enabled-failed-audit.'+suffix)
 assert p.is_file() and not target.exists();target.write_bytes(p.read_bytes())
worker=s/'audit-profiler-disabled.py'
text=Path('/tmp/issue-1580-research/audit-compressed-changed-evidence.py').read_text()
text=text.replace("'scope':'existing BASE_REF=main selection; sequential pinned engine with bounded decompression'", "'scope':'existing BASE_REF=main selection; sequential pinned engine with bounded decompression; supported profiler disabled'")
worker.write_text(text)
with (s/'repaired-supervisor.log').open('wb') as output:
 p=subprocess.Popen(['python3',str(worker)],cwd=r,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
(s/'repaired-audit.pid').write_text(str(p.pid)+'\n');print(json.dumps({'pid':p.pid,'worker':str(worker)}))
