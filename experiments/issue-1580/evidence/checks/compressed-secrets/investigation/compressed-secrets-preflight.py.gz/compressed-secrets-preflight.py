from pathlib import Path
import subprocess,json,struct,hashlib,os
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/compressed-secrets');s.mkdir(exist_ok=True)
paths=subprocess.check_output(['git','diff','--name-only','--diff-filter=ACMRT','-z','origin/main...HEAD'],cwd=r).decode().split('\0')
sizes=[]
for name in paths:
 p=r/name
 if name.lower().endswith(('.gz','.tgz')) and p.is_file():
  with p.open('rb') as f:f.seek(-4,2);size=struct.unpack('<I',f.read(4))[0]
  sizes.append({'path':name,'compressedBytes':p.stat().st_size,'trailerSize':size})
report={'scope':'changed compressed files versus origin/main; gzip trailer sizes are untrusted lower-bound inventory only, not validated inflation','files':len(sizes),'trailerBytes':sum(x['trailerSize'] for x in sizes),'compressedBytes':sum(x['compressedBytes'] for x in sizes),'largest':sorted(sizes,key=lambda x:x['trailerSize'],reverse=True)[:12]}
(s/'inventory.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
repo='link-foundation/js-ai-driven-development-pipeline-template'
for name,args in [('head',['repos/'+repo+'/commits/main']),('decoder',['repos/'+repo+'/contents/scripts/check-secrets.mjs?ref=main']),('license',['repos/'+repo+'/contents/LICENSE?ref=main'])]:
 p=subprocess.run(['gh','api',*args],capture_output=True,cwd=r);(s/(name+'.json')).write_bytes(p.stdout);(s/(name+'.stderr')).write_bytes(p.stderr);assert p.returncode==0
print('Current primary source and license responses retained.',flush=True)
