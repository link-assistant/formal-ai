from pathlib import Path
import subprocess,os,json,time,resource
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/compressed-secrets');env=dict(os.environ,BASE_REF='main',NODE_OPTIONS='--max-old-space-size=256')
start=time.monotonic()
with (s/'changed-evidence-audit.stdout').open('wb') as out,(s/'changed-evidence-audit.stderr').open('wb') as err:
 p=subprocess.run(['bash','scripts/check-secrets.sh'],cwd=r,env=env,stdout=out,stderr=err)
report={'status':p.returncode,'seconds':round(time.monotonic()-start,3),'childrenPeakRssKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'scope':'existing BASE_REF=main selection; sequential pinned engine with bounded decompression'}
(s/'changed-evidence-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
