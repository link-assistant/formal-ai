from pathlib import Path
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/compressed-secrets')
source=(s/'current-decoder.mjs').read_text()
decoder=source[source.index('export const MAX_DECOMPRESSED_BYTES'):source.index('function runScanner')]
decoder=decoder.replace('      content,\n    });','      content,\n      metadata: header,\n    });')
decoder=decoder.replace('      const memberName = `${name}/${entry.name}`;','      const memberName = `${name}/${entry.name}`;\n      scan(`${memberName}.metadata.txt`, entry.metadata);')
(r/'scripts/lib/compressed-secrets.mjs').write_text('''// SPDX-License-Identifier: Unlicense
// Adapted from link-foundation/js-ai-driven-development-pipeline-template
// f8e30b7a00c3113eeec555edcfbaa9ef235ed273, scripts/check-secrets.mjs.
// Bound aggregate inflation and metadata; never extract archive paths to disk.
import {gunzipSync} from 'node:zlib';
'''+decoder)
(r/'scripts/check-secrets-files.mjs').write_text('''#!/usr/bin/env node
// One pinned scanner/configuration, sequential inputs, no extracted files.
import {accessSync,constants,readFileSync,realpathSync,statSync,existsSync} from 'node:fs';
import {delimiter,dirname,join,resolve} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {randomUUID} from 'node:crypto';
import {MAX_DECOMPRESSED_BYTES,scanCompressed} from './lib/compressed-secrets.mjs';

function packageVersion(file,name) {
  for(let directory=dirname(file);;) {
    const manifest=join(directory,'package.json');
    if(existsSync(manifest)) {
      const value=JSON.parse(readFileSync(manifest,'utf8'));
      if(value.name===name)return value.version;
    }
    const parent=dirname(directory);if(parent===directory)throw Error('Scanner package identity unavailable');
    directory=parent;
  }
}
export function scannerModule(version,searchPath=process.env.PATH??'') {
  let binary;
  for(const directory of searchPath.split(delimiter)) {
    if(!directory)continue;
    const candidate=join(directory,process.platform==='win32'?'secretlint.cmd':'secretlint');
    try {accessSync(candidate,constants.X_OK);binary=realpathSync(candidate);break;}catch{}
  }
  if(!binary)throw Error('Pinned secretlint executable unavailable');
  const require=createRequire(pathToFileURL(binary));
  const engine=require.resolve('@secretlint/node');
  const preset=require.resolve('@secretlint/secretlint-rule-preset-recommend');
  for(const [file,name] of [[binary,'secretlint'],[engine,'@secretlint/node'],[preset,'@secretlint/secretlint-rule-preset-recommend']]) {
    if(packageVersion(file,name)!==version)throw Error('Pinned scanner package version mismatch: '+name);
  }
  return pathToFileURL(engine).href;
}

// NUL transport keeps filenames out of npm's generated shell command/argument limits.
export async function* filenames(stream) {
  let pending=Buffer.alloc(0),count=0;
  for await(const chunk of stream) {
    pending=Buffer.concat([pending,Buffer.from(chunk)]);
    let end;
    while((end=pending.indexOf(0))!==-1) {
      if(end===0||end>32768)throw Error('Invalid filename in scanner inventory');
      const name=pending.subarray(0,end).toString('utf8');pending=pending.subarray(end+1);
      count++;yield name;
    }
    if(pending.length>32768)throw Error('Scanner inventory filename size limit exceeded');
  }
  if(pending.length)throw Error('Unterminated scanner inventory');
  if(!count)throw Error('Empty scanner inventory; no scan performed');
}

export async function checkFiles(files,engine,write=value=>process.stdout.write(value)) {
  let count=0,compressed=0,failed=false;
  const accept=result=> {
    if(result.output)write(result.output+'\\n');
    if(!result.ok)failed=true;
  };
  for await(const file of files) {
    const status=statSync(file);if(!status.isFile())throw Error('Selected scanner input is not a file');
    count++;
    if(!/\\.(gz|tgz)$/iu.test(file)) {
      accept(await engine.executeOnFiles({filePathList:[resolve(file)]}));continue;
    }
    compressed++;
    if(status.size>MAX_DECOMPRESSED_BYTES)throw Error('Compressed input exceeds 128 MiB scan limit');
    if(process.env.FORMAL_AI_SECRETS_DEBUG==='1')console.error('[check-secrets] archive '+JSON.stringify(file));
    const entries=[];
    scanCompressed(file,readFileSync(file),(name,bytes)=>entries.push({name,bytes}));
    for(const {name,bytes} of entries) {
      if(!bytes.length)continue; // Empty, successfully decoded content contains no credential.
      accept(await engine.executeOnContent({content:bytes.toString('utf8'),filePath:resolve(name)}));
    }
  }
  if(!count)throw Error('Empty scanner inventory; no scan performed');
  return {ok:!failed,files:count,compressedFiles:compressed};
}

if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  const token='secret-scan-'+randomUUID();
  console.log('::stop-commands::'+token);
  try {
    const version=process.env.SECRETLINT_VERSION??'13.0.5';
    const {createEngine}=await import(scannerModule(version));
    const engine=await createEngine({cwd:process.cwd(),formatter:'stylish',color:false,maskSecrets:true});
    const result=await checkFiles(filenames(process.stdin),engine);
    console.log(JSON.stringify({secretsScan:result}));
    if(!result.ok)process.exitCode=1;
  } catch(error) {
    console.error(JSON.stringify({secretsScan:'failed',reason:String(error.message)}));
    process.exitCode=1;
  } finally {console.log('::'+token+'::');}
}
''')
p=r/'scripts/check-secrets.sh';text=p.read_text();start=text.index('# npm expands each batch')
text=text[:start]+'''# Feed the exact existing selection through stdin rather than interpolating paths
# into npm's shell command. The pinned API is loaded once for all archive members.
export SECRETLINT_VERSION
printf '%s\\0' "${files[@]}" |
  npx --yes \\
    -p "secretlint@${SECRETLINT_VERSION}" \\
    -p "@secretlint/secretlint-rule-preset-recommend@${SECRETLINT_VERSION}" \\
    node scripts/check-secrets-files.mjs

echo "No secrets found."
'''
p.write_text(text)
print('Bounded decoder and sequential pinned engine drafted; selection remains unchanged.')
