from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, re, subprocess

r = Path('/tmp/gh-issue-solver-1794900398048')
s = Path('/tmp/issue-1580-research')
gate = json.loads((s/'all-artifact-gates/result.json').read_text())
assert gate['exitCode'] == 0
checks = s/'all-artifact-checks'
results = json.loads((checks/'sealed-results.json').read_text())
assert len(results) == 14 and all(code == 0 for _, code in results)
counts = {}
for name, _ in results:
    text = (checks/(name+'-sealed.stdout')).read_text()
    passed = re.search(r'^ℹ pass (\d+)$', text, re.M)
    failed = re.search(r'^ℹ fail (\d+)$', text, re.M)
    assert passed and failed and failed[1] == '0', name
    counts[name] = int(passed[1])
semantics = json.loads((checks/'migration-semantics.json').read_text())
assert (semantics['workflows'], semantics['transfers'], semantics['addedCheckouts'], semantics['expandedSparseCheckouts']) == (19, 97, 10, 4)
target = r/'experiments/issue-1580/evidence/checks/artifact-consumers'
target.mkdir(exist_ok=False)
paths = [p for p in checks.iterdir() if p.is_file()]
paths += [p for p in (s/'all-artifact-gates').iterdir() if p.is_file()]
paths += [p for p in (r/'experiments/formal_ai_subagent/sandboxes/gates').glob('*.log')]
names = [
    'migrate-all-artifact-consumers', 'check-artifact-migration',
    'read-artifact-protocol-locations', 'review-artifact-protocol-locations',
    'finish-artifact-contracts', 'check-artifact-witnesses',
    'refresh-artifact-witnesses', 'fix-empty-artifact-selections',
    'check-final-artifact-source', 'run-all-artifact-gates',
    'run-all-artifact-gates-background',
]
for name in names:
    paths += [s/(name+suffix) for suffix in ('.py', '.mjs', '.log') if (s/(name+suffix)).is_file()]
rows = []
for p in paths:
    raw = p.read_bytes()
    name = p.parent.name+'--'+p.name+'.gz'
    assert not (target/name).exists(), name
    packed = gzip.compress(raw, mtime=0)
    (target/name).write_bytes(packed)
    rows.append({'file':name, 'source':str(p.relative_to(s)) if p.is_relative_to(s) else str(p.relative_to(r)),
                 'rawSha256':hashlib.sha256(raw).hexdigest(), 'archiveSha256':hashlib.sha256(packed).hexdigest(),
                 'bytes':len(raw), 'lines':len(raw.splitlines())})
(target/'records.json').write_text(json.dumps(rows, indent=2)+'\n')
aggregate = (s/'all-artifact-gates/aggregate.log').read_text()
assessment = {
    'observedAt':datetime.now(timezone.utc).isoformat(), 'baseline':semantics['baseline'],
    'workflowSemanticComparison':{'workflows':19, 'transfers':97, 'addedCheckouts':10, 'expandedSparseCheckouts':4},
    'focusedTestPasses':counts, 'totalFocusedTestPasses':sum(counts.values()), 'actualPythonZipCases':8,
    'gates':{'exitCode':0, 'passed':len(re.findall(r'^PASS ', aggregate, re.M)),
             'skipped':len(re.findall(r'^SKIP ', aggregate, re.M)), 'seconds':gate['seconds']},
    'negativeControls':['unmigrated workflow consumers', 'caller Python environment mutation',
                        'local download timing classified as other', 'legitimate empty pattern selection refused'],
    'compatibility':['all original selectors, predicates and unrelated workflow fields compared',
                     'trusted workflow checkouts supply complete local adapter closure',
                     '52 governed staged-release operations and 104 output bindings retained',
                     'caller interpreter selection preserved', 'empty pattern/all selection creates no files'],
    'helperFailuresPreserved':['YAML module resolution outside workspace', 'scalar step handling',
                               'deployed projection regenerated in dependency order', 'quoted sparse-checkout newline repair',
                               'partial migration and witness assertions', 'invalid JavaScript literal corrected',
                               'native cache source-compiler proof rejects inherited NODE_OPTIONS',
                               'first full-gate attempt exceeded the shell tool command budget'],
    'hostedMigrationExecuted':False, 'historicalSelectedSourceRendererQualified':False,
    'pagesDeprecationFixed':False, 'independentAuthorshipCredit':0, 'fullIssueComplete':False,
}
(target/'assessment.json').write_text(json.dumps(assessment, indent=2)+'\n')
for row in rows:
    packed = (target/row['file']).read_bytes()
    raw = gzip.decompress(packed)
    assert hashlib.sha256(raw).hexdigest() == row['rawSha256']
    assert hashlib.sha256(packed).hexdigest() == row['archiveSha256']

checkpoint = '''# Artifact consumer checkpoint, 20 November 2026

[PR #1581](https://github.com/link-assistant/formal-ai/pull/1581) remains draft and unfinished.

All 97 remaining direct workflow artifact downloads across nineteen workflows use the shared raw-download adapter. Artifact names, IDs, patterns, cross-run credentials, destinations, merge settings, conditions and unrelated job/workflow fields are compared against published `aca32b1aa27aee55f1d9443f54d6a1c08f77ccb0`. The [complete semantic comparison](../../../experiments/issue-1580/verify-artifact-migration.mjs) also checks ten new small workflow-owned checkouts and four sparse-checkout expansions. Existing protocol checkouts supply the adapter to Desktop, Hive and staged-release jobs. New checkouts explicitly disable credential persistence. No workflow-level DEP0005 suppression remains.

The generator and canonical retained source are changed together, then the deployed staged projection is regenerated through its official compiler. All 52 governed operations and 104 output bindings remain. Two retained-job hashes and the public-download downstream byte witness are refreshed only after the whole-workflow comparison; the exact before/after hashes are preserved. This is a review of the transport change, not independent authorship or execution evidence.

Two compatibility cases are repaired. Python setup does not update the caller's PATH; extraction uses the selected interpreter by its explicit output. An all-artifact or pattern query may legitimately match nothing, just as the pinned official action allows. That case creates no destination files. Named/ID selection still requires a real archive; missing directories, corrupt archives and empty ZIPs still fail. The original official download source and MIT license are retained with its exact source identity. Historical selected-source renderer actions still require execution qualification.

Local adapter step names now retain transfer attribution in the CI timing collector, including the unnamed artifact step immediately before an image load. The new timing case fails before the classifier repair and passes afterward; unrelated names remain unclassified. The empty-selection regression and caller-environment contract also fail before their changes. No assertions or suites are removed.

All fourteen focused JavaScript files pass (''' + str(sum(counts.values())) + ''' test groups), including eight actual Python ZIP cases, nine release-workflow cases, sixty relocated-stage controls, nineteen original delivery cases, forty public-download cases, twelve actual cache/source-compiler cases, and the existing policy/security/renderer suites. The full local JavaScript gate run passes ''' + str(assessment['gates']['passed']) + ''' gates, with ''' + str(assessment['gates']['skipped']) + ''' native or CI-context exclusions. No local Rust build is run. The first full-gate attempt was interrupted by the shell tool's sixty-second budget; the complete sequential detached run supplies the result. Its complete logs and the earlier helper/test failures are retained in [the evidence archive](../../../experiments/issue-1580/evidence/checks/artifact-consumers/).

Hosted CI on `aca32b1a` covers the previously published shared adapter, optional-dependency context fix and native detector admission. It does not execute this later 97-consumer migration. The new migration has no hosted execution credit until its own published head runs. Pages DEP0040, the actual source-size warnings and dependency migrations, all remaining template comparisons and practice qualifications, original historical budgets, live delivery/identity, publication certainty and whole-PR review remain open. Strict original acceptance remains 31/53; independently accepted Formal AI reasoning remains 0/20. Supplied commands, code and reviews earn zero independent credit. Full issue completion remains false.
'''
(r/'docs/case-studies/issue-1580/artifact-consumer-checkpoint.md').write_text(checkpoint)
for name, addition in [
    ('docs/case-studies/issue-1580/README.md', '\nThe [artifact consumer checkpoint](artifact-consumer-checkpoint.md) records all 97 direct workflow migrations, their complete semantic comparison, preserved staged-release operations, empty-selection and interpreter compatibility, timing regression and complete local gates. Hosted execution of this later batch and wider acceptance remain unfinished.\n'),
    ('experiments/issue-1580/work-plan.md', '\n## 20 November: complete direct artifact-consumer migration\n\n- [x] Migrate every remaining direct workflow download (97 transfers / 19 workflows); compare complete workflow payloads against aca32b1a and verify all local adapter checkout closures.\n- [x] Regenerate staged release without removing its 52 operations or 104 bindings; preserve and review two retained-job hash changes and public-download byte witness.\n- [x] Preserve caller Python selection and empty pattern/all-artifact queries; reproduce and repair CI timing classification. Fourteen focused files and all available JavaScript gates pass.\n- [ ] Verify this migration on its published hosted head; the earlier aca32b1a run cannot supply that credit. Historical selected-source renderer execution remains unqualified.\n- [ ] Continue Pages/dependency/source-size warning repairs, full eight-template practice review, all original historical budgets, actual delivery/identity/publication, provenance and whole-PR review. Full issue completion remains false; independent accepted reasoning remains 0/20.\n'),
]:
    p = r/name
    p.write_text(p.read_text()+addition)
(r/'changelog.d/1580-artifact-consumers.md').write_text('Update every workflow artifact consumer to verified raw transport and streaming extraction, preserve caller Python and empty pattern selections, and retain transfer timing for local adapters.\n')
print(json.dumps({'archivedStreams':len(rows), **assessment}, indent=2), flush=True)
