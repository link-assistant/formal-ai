import fs from 'node:fs';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
const YAML=createRequire('/tmp/gh-issue-solver-1794900398048/package.json')('yaml');
const base='aca32b1aa27aee55f1d9443f54d6a1c08f77ccb0';
const old=file=>execFileSync('git',['show',base+':'+file],{encoding:'utf8',maxBuffer:2*1024*1024});
const sha=value=>createHash('sha256').update(value).digest('hex');
const proof=JSON.parse(fs.readFileSync('/tmp/issue-1580-research/all-artifact-checks/migration-semantics.json','utf8'));
assert.equal(proof.transfers,97);assert.equal(proof.baseline,base);
const p='data/benchmarks/fast-pull-request-retained-jobs.json',manifest=JSON.parse(fs.readFileSync(p,'utf8')),deltas=[];
const payload=job=>JSON.stringify({steps:job.steps,uses:job.uses,with:job.with,strategy:job.strategy});
for(const row of manifest.jobs){
 const file='.github/workflows/'+row.file,before=YAML.parse(old(file)).jobs[row.id],after=YAML.parse(fs.readFileSync(file,'utf8')).jobs[row.id];
 assert.equal(row.payloadSha256,sha(payload(before)),row.file+'/'+row.id+' current witness baseline');
 const updated=sha(payload(after));
 if(updated!==row.payloadSha256){assert(proof.sources.some(source=>source.file===file));deltas.push({file:row.file,id:row.id,before:row.payloadSha256,after:updated});row.payloadSha256=updated;}
}
manifest.scope+=' Artifact transport now uses the reviewed raw adapter; original selectors, predicates and non-transport payloads remain independently compared to aca32b1a.';
fs.writeFileSync(p,JSON.stringify(manifest,null,2)+'\n');
const f='rust/tests/web/verify-public-release-downloads.test.mjs';let text=fs.readFileSync(f,'utf8');
const publicFile='.github/workflows/verify-release-downloads.yml';
const downstream=source=>{const index=source.indexOf('\n  all-public-bytes:\n');assert(index>=0);return source.slice(index).replaceAll('runs-on: ubuntu-24.04','runs-on: ubuntu-latest');};
const expected='11977c67b61a050577b42afa0ea0f0f37bc321e03601bd66e1b5e03d3b8f4018';assert.equal(sha(downstream(old(publicFile))),expected);
assert(proof.sources.some(source=>source.file===publicFile));const updated=sha(downstream(fs.readFileSync(publicFile,'utf8')));assert.equal(text.split(expected).length,2);
text=text.replace(expected,updated).replace('// Issue #1571 pinned the runner image; that is the only change since the baseline.','// Issue #1571 pinned the runner image. Issue #1580 replaces only the two artifact adapters\n  // and their suppression; the complete workflow comparison is retained by verify-artifact-migration.mjs.');fs.writeFileSync(f,text);
fs.writeFileSync('/tmp/issue-1580-research/all-artifact-checks/witness-deltas.json',JSON.stringify({retainedJobs:deltas,publicDownload:{before:expected,after:updated},transfers:proof.transfers},null,2)+'\n');
console.log(JSON.stringify({retainedJobs:deltas,publicDownloadSha256:updated}));
