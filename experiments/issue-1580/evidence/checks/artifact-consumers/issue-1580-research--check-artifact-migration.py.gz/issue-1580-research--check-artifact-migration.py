from pathlib import Path
import os,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/all-artifact-checks');e=dict(os.environ);e.pop('NODE_OPTIONS',None)
p=r/'experiments/issue-1580/verify-artifact-migration.mjs';p.write_bytes(Path('/tmp/issue-1580-research/verify-artifact-migration.mjs').read_bytes())
x=subprocess.run(['node','--max-old-space-size=256',str(p)],cwd=r,env=e,capture_output=True)
(s/'migration-semantics.json').write_bytes(x.stdout);(s/'migration-semantics.stderr').write_bytes(x.stderr)
print(x.returncode,x.stderr.decode(),flush=True);assert x.returncode==0
