from pathlib import Path
import gzip, hashlib, json, os, subprocess

r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');b=r/'experiments/issue-1580/evidence/checks/artifact-consumers'
def run(name,args,env=None):
    p=subprocess.run(args,cwd=r,env=env,capture_output=True)
    (s/(name+'.stdout')).write_bytes(p.stdout);(s/(name+'.stderr')).write_bytes(p.stderr)
    print(name,p.returncode,p.stdout.decode()[-1800:],p.stderr.decode()[-1000:],flush=True)
    assert p.returncode==0,name
    return p.stdout.decode().strip()
assert run('artifact-consumer-branch',['git','branch','--show-current'])=='issue-1580-8d61a32a61e1'
run('artifact-consumer-diff-check',['git','diff','--check'])
run('artifact-consumer-doc-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-changelog-fragment-js-twin,check-runner-labels,check-file-size-js-twin,check-file-size'],dict(os.environ,NODE_OPTIONS='--max-old-space-size=256'))
rows=json.loads((b/'records.json').read_text())
for p in [s/'record-artifact-consumer-batch.py',s/'record-artifact-consumer-batch.log',s/'finish-artifact-consumer-commit.py',s/'artifact-consumer-doc-gates.stdout',s/'artifact-consumer-doc-gates.stderr']:
    raw=p.read_bytes();name=p.name+'.gz';packed=gzip.compress(raw,mtime=0);assert not (b/name).exists();(b/name).write_bytes(packed)
    rows.append({'file':name,'source':p.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
(b/'records.json').write_text('[\n'+',\n'.join('  '+json.dumps(row) for row in rows)+'\n]\n')
changed=run('artifact-consumer-changed',['git','diff','--name-only']).splitlines()
production=[x for x in changed if not x.startswith('docs/') and x!='experiments/issue-1580/work-plan.md']
production += ['experiments/issue-1580/verify-artifact-migration.mjs','changelog.d/1580-artifact-consumers.md']
assert len(production)==39,len(production)
run('artifact-consumer-stage',['git','add','--',*production])
run('artifact-consumer-commit',['git','commit','-m','Migrate workflow artifact consumers to verified raw extraction'])
run('artifact-consumer-evidence-stage',['git','add','--','docs/case-studies/issue-1580/README.md','docs/case-studies/issue-1580/artifact-consumer-checkpoint.md','experiments/issue-1580/work-plan.md','experiments/issue-1580/evidence/checks/artifact-consumers'])
run('artifact-consumer-evidence-commit',['git','commit','-m','Preserve full artifact migration comparison and regression results'])
run('artifact-consumer-current-status',['git','status','--short'])
print('Local commits complete; no push attempted while published-head workflows remain active.',flush=True)
