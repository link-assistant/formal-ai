from pathlib import Path
import json, os, subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/all-artifact-checks')
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
def run(label,args):
 p=subprocess.run(args,cwd=r,env=env,capture_output=True)
 (s/(label+'.stdout')).write_bytes(p.stdout);(s/(label+'.stderr')).write_bytes(p.stderr)
 print(label,p.returncode,flush=True);return p.returncode
p=r/'rust/tests/web/ci-phase-timing.test.mjs';t=p.read_text();anchor="test('recorded delivery baseline:"
addition="""test('local artifact adapters retain transfer timing and the unnamed image-load fallback', () => {
  for (const action of ['./.github/actions/download-artifact', './.hive-protocol/.github/actions/download-artifact', './_protocol/.github/actions/download-artifact']) {
    const name = 'Run ' + action;
    assert.equal(classifyStep(name), 'transfer', name);
    const record = measureRun({run: run(3, 'Original Hive Mind three-client delivery'), jobs: [{
      name: 'leg', conclusion: 'success', created_at: at(0), started_at: at(1), completed_at: at(41), steps: [
        step(1, name, 1, 11), step(2, 'Load and reverify same-run source-bound task image', 11, 21),
        step(3, name, 21, 41),
      ],
    }]});
    assert.equal(record.phase['image-transfer'].seconds, 10);
    assert.equal(record.phase.transfer.seconds, 20);
    assert.equal(record.phase.other.seconds, 0);
    assert.equal(classifyStep('Post ' + name), 'runner');
  }
  for (const name of ['Run ./download-artifact', 'Run ./.github/actions/download-artifact-other', 'Run ./.github/actions/download-artifact/unrelated']) {
    assert.equal(classifyStep(name), 'other', name);
  }
});

"""
assert t.count(anchor)==1;t=t.replace(anchor,addition+anchor);p.write_text(t)
assert run('timing-before',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/ci-phase-timing.test.mjs'])==1
p=r/'scripts/lib/ci-phase-timing.mjs';t=p.read_text();t=t.replace('const RULES = [',"const DOWNLOAD_ACTION = /^Run (?:actions\\/download-artifact@\\S+|\\.(?:\\/[.\\w-]+)*\\/\\.github\\/actions\\/download-artifact)$/u;\nconst RULES = [",1)
old="  ['transfer', /^(Run actions\\/download-artifact@|Download |Restore source)/u],"
assert t.count(old)==1;t=t.replace(old,"  ['transfer', DOWNLOAD_ACTION],\n  ['transfer', /^(Download |Restore source)/u],")
old="/^Run actions\\/download-artifact@/u.test(step.name)";assert t.count(old)==1;t=t.replace(old,'DOWNLOAD_ACTION.test(step.name)');p.write_text(t)
results=[]
for f in ['ci-phase-timing','native-workflow-cache-bindings']:
 results.append([f,run(f+'-final',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+f+'.test.mjs'])])
(s/'contract-results.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(code==0 for _,code in results)
