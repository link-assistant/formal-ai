import fs from 'node:fs';import {createRequire} from 'node:module';const YAML=createRequire('/tmp/gh-issue-solver-1794900398048/package.json')('yaml');import {createHash} from 'node:crypto';import {spawnSync} from 'node:child_process';
const root='/tmp/gh-issue-solver-1794900398048';process.chdir(root);
const special=new Set(['container-images.yml','publish-source-networks.yml','work-item-qualification.yml']);
function migrate(text,file){
 const doc=YAML.parseDocument(text),changes=[];let count=0;
 for(const entry of doc.get('jobs',true).items){const id=entry.key.value,job=entry.value,steps=job.get('steps',true);if(!Array.isArray(steps?.items))continue;const downloads=steps.items.filter(step=>step.get('uses')?.startsWith('actions/download-artifact@'));if(!downloads.length)continue;
  let prefix='';
  if(file==='hive-original-delivery.yml')prefix='.hive-protocol/';
  else if(file==='release-staged.yml')prefix='_protocol/';
  else if(file==='desktop-release.yml'&&['native','build','cli','vscode'].includes(id))prefix='.formal-ai-protocol-source/';
  else if(special.has(file)||(file==='desktop-release.yml'&&id==='finalize'))prefix='.formal-ai-artifact-protocol/';
  const local='./'+prefix+'.github/actions/download-artifact';
  if(prefix==='.formal-ai-protocol-source/'){
   const checkout=steps.items.find(step=>step.get('uses')?.startsWith('actions/checkout@')&&step.get('with',true)?.get('path')==='.formal-ai-protocol-source');const sparse=checkout.get('with',true).get('sparse-checkout',true);assert(sparse.value==='scripts\ndesktop/scripts');
   const start=text.lastIndexOf('\n',sparse.range[0])+1;const fragment=text.slice(sparse.range[0],sparse.range[1]);assert(fragment.includes('desktop/scripts'));changes.push([sparse.range[0],sparse.range[1],fragment.replace('desktop/scripts','desktop/scripts\n            .github/actions/download-artifact')]);
  }
  const prior=steps.items.slice(0,steps.items.indexOf(downloads[0]));
  const hasRoot=prior.some(step=>step.get('uses')?.startsWith('actions/checkout@')&&!step.get('with',true)?.get('path')&&!step.get('with',true)?.get('repository'));
  if(prefix==='.formal-ai-artifact-protocol/'||(!prefix&&!hasRoot)){
   const at=text.lastIndexOf('\n',downloads[0].range[0])+1;
   const block='      - name: Check out workflow-owned artifact extraction\n        uses: actions/checkout@v7\n        with:\n          ref: ${{ github.workflow_sha }}\n'+(prefix?'          path: '+prefix.slice(0,-1)+'\n':'')+'          persist-credentials: false\n          fetch-depth: 1\n          filter: blob:none\n          sparse-checkout: |\n            /.github/actions/download-artifact/\n            /scripts/extract-artifacts.py\n          sparse-checkout-cone-mode: false\n';
   const indent=text.slice(at).match(/^ */u)[0].length;
   changes.push([at,at,block.split('\n').map(line=>line?' '.repeat(indent)+line.slice(6):line).join('\n')]);
  }
  for(const step of downloads){const value=step.get('uses',true);changes.push([value.range[0],value.range[1],local]);
   const environment=step.items.find(pair=>pair.key.value==='env');
   if(environment){
    assert(environment.value.items.length===1&&environment.value.get('NODE_OPTIONS')==='--disable-warning=DEP0005');
    let start=environment.key.range[0],end=environment.value.range[2];
    if(step.flow){while(/\s/u.test(text[start-1]))start--;assert(text[start-1]===',');start--;end=environment.value.range[1];}
    else start=text.lastIndexOf('\n',start)+1;
    changes.push([start,end,'']);
   }
   count++;
  }
 }
 for(const [start,end,value]of changes.sort((a,b)=>b[0]-a[0]))text=text.slice(0,start)+value+text.slice(end);
 text=text.replaceAll('          digest-mismatch: error\n','');
 text=text.replace(/^[ \t]*# (?:v8's bundled[^\n]*|that reviewed upstream diagnostic[^\n]*|https:\/\/github[.]com\/actions\/download-artifact\/issues\/484|actions\/download-artifact\/issues\/484:[^\n]*)\n/gmu,'');
 assert(YAML.parseDocument(text).errors.length===0);
 return {text,count};
}
function assert(value){if(!value)throw new Error('Unexpected artifact consumer source');}
let migrated=0;for(const file of fs.readdirSync('.github/workflows').filter(x=>x.endsWith('.yml'))){if(['release.yml','release-staged.yml'].includes(file))continue;const path='.github/workflows/'+file;const result=migrate(fs.readFileSync(path,'utf8'),file);if(result.count){fs.writeFileSync(path,result.text);migrated+=result.count;console.log(file,result.count);}}
const generator='scripts/generate-staged-release.mjs';let code=fs.readFileSync(generator,'utf8');const needle='uses: actions/download-artifact@v8\\n        env:\\n          NODE_OPTIONS: --disable-warning=DEP0005\\n';assert(code.split(needle).length===3);code=code.replaceAll(needle,'uses: ./_protocol/.github/actions/download-artifact\\n');code=code.replaceAll('          digest-mismatch: error\\n','');fs.writeFileSync(generator,code);
const base='experiments/formal_ai_subagent/evidence/specification-delivery-1188/dormant-staged-release/';const canonical=base+'original-release-workflow.yml',packetPath=base+'stage-source-coverage.json';let packet=JSON.parse(fs.readFileSync(packetPath,'utf8'));const before=fs.readFileSync(canonical,'utf8');assert(createHash('sha256').update(before).digest('hex')===packet.workflowSha256);const result=migrate(before,'release.yml');assert(result.count===1);migrated+=result.count;packet.workflowSha256=createHash('sha256').update(result.text).digest('hex');fs.writeFileSync(canonical,result.text);fs.writeFileSync(packetPath,JSON.stringify(packet,null,2)+'\n');
const {buildStagedReleaseProjection}=await import(root+'/scripts/generate-staged-release.mjs');
const projection=buildStagedReleaseProjection(result.text,packet);assert(projection.operations===52&&projection.binding.length===104);
for(const [path,bytes] of projection.outputs)fs.writeFileSync(path,bytes);
fs.writeFileSync('.github/workflows/release.yml',projection.outputs.get(base+'candidate-release-caller.yml'));
const check=spawnSync(process.execPath,['scripts/generate-staged-release.mjs','--check-deployed'],{encoding:'utf8'});console.log(check.stdout,check.stderr);assert(check.status===0);
const generated=YAML.parse(fs.readFileSync('.github/workflows/release-staged.yml','utf8'));let staged=0;for(const job of Object.values(generated.jobs))for(const step of job.steps||[])if(step.uses==='./_protocol/.github/actions/download-artifact')staged++;
console.log('Migrated',migrated,'direct callers plus',staged,'generated callers');assert(migrated+staged===97);
const action='.github/actions/download-artifact/action.yml';let a=fs.readFileSync(action,'utf8');a=a.replace('    - uses: actions/setup-python@v6\n      with:\n        python-version:',"    - uses: actions/setup-python@v6\n      id: python\n      with:\n        update-environment: false\n        python-version:");a=a.replace('        ACTION_DIRECTORY:','        ARTIFACT_PYTHON: ${{ steps.python.outputs.python-path }}\n        ACTION_DIRECTORY:');a=a.replace('      run: python "$ACTION_DIRECTORY/','      run: |\n        ".REPLACE_INTERPRETER." "$ACTION_DIRECTORY/').replace('".REPLACE_INTERPRETER."','"$ARTIFACT_PYTHON"');fs.writeFileSync(action,a);
