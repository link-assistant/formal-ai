from pathlib import Path
import subprocess,os
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/all-artifact-checks');env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
import json
(s/'partial-layout-draft.diff').write_bytes(subprocess.check_output(['git','diff','--','.github/workflows'],cwd=r))
for name in sorted({row['file'] for row in json.loads((Path('/tmp/issue-1580-research/direct-artifact-callers/inventory.json')).read_text())}):
 (r/name).write_bytes(subprocess.check_output(['git','show','HEAD:'+name],cwd=r))
base='experiments/formal_ai_subagent/evidence/specification-delivery-1188/dormant-staged-release/'
for name in ['.github/actions/download-artifact/action.yml','scripts/generate-staged-release.mjs',*[base+x for x in ['original-release-workflow.yml','stage-source-coverage.json','candidate-release-caller.yml','candidate-output-bindings.json']]]:
 (r/name).write_bytes(subprocess.check_output(['git','show','HEAD:'+name],cwd=r))
p=subprocess.run(['node','/tmp/issue-1580-research/migrate-all-artifact-consumers.mjs'],cwd=r,env=env,capture_output=True);(s/'migration-complete.stdout').write_bytes(p.stdout);(s/'migration-complete.stderr').write_bytes(p.stderr);print(p.stdout.decode(),p.stderr.decode(),flush=True);assert p.returncode==0
p=subprocess.run(['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/native-test-artifact.test.mjs'],cwd=r,env=env,capture_output=True);(s/'after-complete.stdout').write_bytes(p.stdout);(s/'after-complete.stderr').write_bytes(p.stderr);print('AFTER',p.returncode,flush=True);print(p.stdout.decode()[-6000:],p.stderr.decode(),flush=True);assert p.returncode==0
