from pathlib import Path
import os,subprocess,json
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/all-artifact-checks');env=dict(os.environ);env.pop('NODE_OPTIONS',None)
def change(file,old,new,count=1):
 p=r/file;t=p.read_text();assert t.count(old)==count,(file,t.count(old));p.write_text(t.replace(old,new))
def check(label):
 p=subprocess.run(['python3','experiments/issue-1580/artifact-extraction-fixtures.py'],cwd=r,env=env,capture_output=True)
 (s/(label+'.stdout')).write_bytes(p.stdout);(s/(label+'.stderr')).write_bytes(p.stderr);print(label,p.returncode,flush=True);return p.returncode
change('experiments/issue-1580/artifact-extraction-fixtures.py','    def test_single_archive_bytes_and_existing_regular_overwrite(self):', '''    def test_empty_pattern_selection_preserves_no_artifact_behavior(self):
        result = self.module.extract_artifacts(self.raw, self.destination, allow_empty_selection=True)
        self.assertEqual(result, self.destination.resolve())
        self.assertFalse(self.destination.exists(), "an empty selection creates no files")
        with self.assertRaises(ValueError):
            self.module.extract_artifacts(self.raw / "missing", self.destination, allow_empty_selection=True)
        path = self.raw / "artifact"
        path.write_bytes(b"not an archive")
        with self.assertRaises(zipfile.BadZipFile):
            self.module.extract_artifacts(self.raw, self.destination, allow_empty_selection=True)
        with zipfile.ZipFile(path, "w"):
            pass
        with self.assertRaises(ValueError):
            self.module.extract_artifacts(self.raw, self.destination, allow_empty_selection=True)
        self.assertFalse(self.destination.exists())

    def test_single_archive_bytes_and_existing_regular_overwrite(self):''')
assert check('empty-selection-before')!=0
change('scripts/extract-artifacts.py','def raw_archives(raw):','def raw_archives(raw, allow_empty=False):')
change('scripts/extract-artifacts.py','    if not sources or (len(sources) > 1 and any(not prefix.parts for prefix, _ in sources)):', '    if (not sources and not allow_empty) or (len(sources) > 1 and any(not prefix.parts for prefix, _ in sources)):')
change('scripts/extract-artifacts.py','def extract_artifacts(raw, destination, merge_multiple=False):','def extract_artifacts(raw, destination, merge_multiple=False, allow_empty_selection=False):')
change('scripts/extract-artifacts.py','    planned, files, directories = [], set(), set()','    sources = raw_archives(Path(raw), allow_empty_selection)\n    if not sources:\n        return root  # The upstream pattern/all-artifact query matched nothing.\n    planned, files, directories = [], set(), set()')
change('scripts/extract-artifacts.py','        for prefix, source in raw_archives(Path(raw)):', '        for prefix, source in sources:')
change('scripts/extract-artifacts.py','    options = parser.parse_args()\n    destination = extract_artifacts(options.raw, options.destination, options.merge_multiple == "true")', '    parser.add_argument("--allow-empty-selection", choices=("true", "false"), default="false")\n    options = parser.parse_args()\n    destination = extract_artifacts(options.raw, options.destination, options.merge_multiple == "true",\n                                    options.allow_empty_selection == "true")')
change('scripts/extract-artifacts.py','    print(f"Extracted verified artifact archives to {destination}")','    print(f"Artifact extraction destination: {destination}")')
change('.github/actions/download-artifact/action.yml','        MERGE_MULTIPLE: ${{ inputs.merge-multiple }}','        MERGE_MULTIPLE: ${{ inputs.merge-multiple }}\n        ALLOW_EMPTY_SELECTION: ${{ inputs.name == \'\' && inputs.artifact-ids == \'\' }}')
change('.github/actions/download-artifact/action.yml','--merge-multiple "$MERGE_MULTIPLE"','--merge-multiple "$MERGE_MULTIPLE" --allow-empty-selection "$ALLOW_EMPTY_SELECTION"')
change('rust/tests/web/native-test-artifact.test.mjs','assert.match(result.stderr,/Ran 7 tests/u);','assert.match(result.stderr,/Ran 8 tests/u);')
change('rust/tests/web/native-test-artifact.test.mjs'," assert.equal(extraction['working-directory'],'${{ github.workspace }}');", " assert.equal(extraction['working-directory'],'${{ github.workspace }}');\n assert.equal(extraction.env.ALLOW_EMPTY_SELECTION,\"${{ inputs.name == '' && inputs.artifact-ids == '' }}\");\n assert.match(extraction.run,/--allow-empty-selection \\\"\\$ALLOW_EMPTY_SELECTION\\\"/u);")
assert check('empty-selection-after')==0
p=subprocess.run(['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/native-test-artifact.test.mjs'],cwd=r,env=env,capture_output=True)
(s/'native-test-artifact-final.stdout').write_bytes(p.stdout);(s/'native-test-artifact-final.stderr').write_bytes(p.stderr);print('native-test-artifact-final',p.returncode,flush=True);assert p.returncode==0
