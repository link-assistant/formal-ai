from pathlib import Path
import subprocess,os,json
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/all-artifact-checks');e=dict(os.environ);e.pop('NODE_OPTIONS',None)
p=r/'rust/tests/web/native-test-artifact.test.mjs';t=p.read_text();lines=t.splitlines();bad=[line for line in lines if 'assert.match(extraction.run,/--allow-empty-selection' in line];assert len(bad)==1
t=t.replace(bad[0],''' assert.ok(extraction.run.includes('--allow-empty-selection "$ALLOW_EMPTY_SELECTION"'));''');p.write_text(t)
files=['native-test-artifact','native-release-workflow','relocated-build-stage-controls','hive-original-delivery-evidence','verify-public-release-downloads','hive-mind-draft-workflow','native-workflow-cache-bindings','release-web','default-branch-build-policy','security-codeql-results','fast-pull-request-production-profile','documentation-only-ci-policy','ci-speed','ci-phase-timing']
results=[]
for f in files:
 p=subprocess.run(['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+f+'.test.mjs'],cwd=r,env=e,capture_output=True)
 (s/(f+'-sealed.stdout')).write_bytes(p.stdout);(s/(f+'-sealed.stderr')).write_bytes(p.stderr);results.append([f,p.returncode]);print(f,p.returncode,flush=True)
(s/'sealed-results.json').write_text(json.dumps(results,indent=2)+'\n');assert all(code==0 for _,code in results)
