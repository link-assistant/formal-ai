from pathlib import Path
import json,os,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/all-artifact-checks');env=dict(os.environ);env.pop('NODE_OPTIONS',None)
p=subprocess.run(['node','/tmp/issue-1580-research/refresh-artifact-witnesses.mjs'],cwd=r,env=env,capture_output=True)
(s/'witness-refresh.stdout').write_bytes(p.stdout);(s/'witness-refresh.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr
results=[]
for f in ['verify-public-release-downloads','fast-pull-request-production-profile']:
 p=subprocess.run(['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+f+'.test.mjs'],cwd=r,env=env,capture_output=True)
 (s/(f+'-final.stdout')).write_bytes(p.stdout);(s/(f+'-final.stderr')).write_bytes(p.stderr);results.append([f,p.returncode]);print(f,p.returncode,flush=True)
(s/'witness-results.json').write_text(json.dumps(results,indent=2)+'\n');assert all(code==0 for _,code in results)
