from pathlib import Path
import os,subprocess,time,json,hashlib,sys
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/all-artifact-gates');s.mkdir(exist_ok=True)
if '--worker' not in sys.argv:
 with (s/'worker.log').open('ab') as output:
  p=subprocess.Popen([sys.executable,__file__,'--worker'],cwd=r,stdin=subprocess.DEVNULL,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
 (s/'pid').write_text(str(p.pid)+'\n');print('Started sequential gate worker',p.pid,flush=True);sys.exit(0)
old=s/'aggregate.log'
if old.exists():old.replace(s/'aborted-at-command-budget.log')
e=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
args=['node','experiments/formal_ai_subagent/local-gates.mjs'];start=time.monotonic()
with (s/'aggregate.log').open('wb') as output:
 p=subprocess.run(args,cwd=r,env=e,stdout=output,stderr=subprocess.STDOUT)
b=(s/'aggregate.log').read_bytes();(s/'result.json').write_text(json.dumps({'command':args,'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3),'aggregateSha256':hashlib.sha256(b).hexdigest(),'nativeBuild':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print((s/'result.json').read_text(),flush=True);assert p.returncode==0
