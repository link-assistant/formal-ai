import json
from pathlib import Path
r=Path('/tmp/issue-1580-research')
d=json.loads(Path('docs/case-studies/issue-1580/templates/rust-source-review-progress.json').read_text())
print('UNREAD RUST FILES')
for x in d['files']:
 if not x.get('literalSourceFullyRead'):print(json.dumps(x))
print('TOP KEYS',list(d))
for name in ['aggregate-final-production-review/inventory.json','aggregate-final-production-review/review-coverage-20261123.json','later-production-review-aaac/inventory.json']:
 data=json.loads((r/name).read_text())
 print(name)
 for k,v in data.items():
  if isinstance(v,list):print(k,len(v),str(v[:2])[:800])
  elif isinstance(v,dict):print(k,str(v)[:1200])
  else:print(k,v)
print('ROOT RESEARCH RUST RELEVANT')
for p in sorted(r.iterdir()):
 if any(x in p.name for x in ['rust-template','rust-source','rust-practice','aggregate','maintained']): print(str(p),p.is_dir())
