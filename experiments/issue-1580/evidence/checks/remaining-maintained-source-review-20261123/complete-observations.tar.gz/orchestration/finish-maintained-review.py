import json,datetime
from pathlib import Path
root=Path('/tmp/issue-1580-research')
review=root/'remaining-maintained-diff-review-8190'
p=review/'review-coverage.json'
data=json.loads(p.read_text())
assert len(list((review/'compact-chunks').glob('chunk-*.diff')))==56
data['compactLiteralChunksRead']=list(range(56))
data['remainingMaintainedReviewComplete']=True
data['completeAggregateReview']=False
data['updatedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
data['notes'].update({
'compact-0-4':'Reviewed lightweight gates, bounded process groups, actual native catalog staging, generator byte parity, live publisher controls, translation fixture attribution, unresolved child aggregation, health probe custody, extracted CLI resume arguments and separate TUI diagnostics.',
'compact-5-8':'Read the complete deleted and extracted solver implementation and surrounding translation extraction. Public constructors, history and probability stores, intent caching, decomposition, policy ordering, specialist routing, diagnostic behavior and recorded search behavior are conserved by the move.',
'compact-44-47':'Reviewed Pages exact source/artifact identity and bounded lifecycle controls; safe picomatch patch; explicit CI-only gates; publisher source IDs; quoted recipe boundaries; complete per-tool receipts; exact canonical release bindings and transfer adapters. Mocked API controls do not certify a live deployment.',
'compact-48-51':'Reviewed bounded opt-in cache diagnostics and safe workflow tokens, complete SARIF decoding, real read-only CodeQL context admission, bounded macro observer, seed partition conservation, arithmetic event origins, separate health transport logs and exact OpenCode path attribution. Empty semantic contexts remain unfinished.',
'compact-52-55':'Reviewed canonical source reassembly and staged projections, actual publisher and TypeScript worker boundaries, full prompt obligations, named program execution, fail-closed seed readers, localized response language, Unicode boundaries, structured NPM updates, complete real-Git change detection fixtures and exact moved numeric program bodies.'
})
p.write_text(json.dumps(data,indent=2)+'\n')
runs=json.loads((root/'rerun-repair-head-ci/latest.json').read_text())
print(json.dumps({'review':{k:data[k] for k in ['source','base','remainingMaintainedReviewComplete','completeAggregateReview','updatedAt']},'reviewedCompactChunks':len(data['compactLiteralChunksRead']),'ci':{'runs':len(runs),'pending':[r['workflowName'] for r in runs if r['status']!='completed'],'nonpassing':[{k:r[k] for k in ['databaseId','workflowName','conclusion']} for r in runs if r['status']=='completed' and r['conclusion'] not in ['success','skipped']] }},indent=2))
for folder in ['aggregate-final-production-review','later-production-review-aaac','remaining-maintained-diff-review-8190']:
 print(folder)
 print('\n'.join(str(p.relative_to(root)) for p in (root/folder).glob('*.json')))
