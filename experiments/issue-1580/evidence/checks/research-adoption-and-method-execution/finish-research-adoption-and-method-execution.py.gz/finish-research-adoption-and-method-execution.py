from pathlib import Path
import sys, subprocess, json

scratch = Path('/tmp/issue-1580-research')
out = scratch/'research-adoption-and-method-execution-corrected'
if len(sys.argv) == 1:
    with (out/'finish-worker.log').open('wb') as stream:
        worker = subprocess.Popen([sys.executable,__file__,'worker'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({'pid':worker.pid,'finiteWorker':True}))
    sys.exit(0)
template = (scratch/'extract-solver-config-and-command-allowlist.py').read_text()
preamble = template[:template.index("parent = root/'rust/src/solver.rs'")]
preamble = preamble.replace('solver-config-and-command-allowlist','research-adoption-and-method-execution-corrected')
exec(compile(preamble,__file__,'exec'))

# Recheck exact inverse proofs independently of the formatted source files.
def retain(parent,child,original,updated,child_text,restored,label):
    assert restored==original,label
    assert original.encode()==subprocess.check_output(['git','show','HEAD:'+parent.relative_to(root).as_posix()],cwd=root)
    pair=[parent.relative_to(root).as_posix(),child.relative_to(root).as_posix()]
    paths.extend(pair)
    proofs.append({'parent':pair[0],'child':pair[1],'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'reassembledOriginalSha256':hashlib.sha256(restored.encode()).hexdigest(),'originalLines':len(original.splitlines()),'exactOriginalReconstructionBeforeFormatting':True})
source = (scratch/'extract-research-adoption-and-method-execution.py').read_text()
section = source[source.index("parent = root/'rust/src/coding_research_learning.rs'"):source.index('tail = template[')]
section = section.replace('original = parent.read_text()',"original = gzip.decompress((out/('research-adoption-original.rs.gz' if 'coding_research' in str(parent) else 'method-execution-original.rs.gz')).read_bytes()).decode()")
section = section.replace("marker = 'fn try_learned_method('","marker = '/// Execute one adopted learned method as the recipe program its learned'")
exec(compile(section,__file__,'exec'))

# rustfmt only reorders the two newly inserted reexports. Preserve its failed
# strict comparison, and explicitly normalize this declaration order alone.
inputs=json.loads((out/'formatting-inputs.json').read_text())
parent='rust/src/coding_research_learning.rs'
old='pub use adoption::{DecomposedProcedureSource, adopt_extracted_procedure};\n#[cfg(feature = "meta-language")]\npub use adoption::adopt_decomposed_procedure;\n'
new='#[cfg(feature = "meta-language")]\npub use adoption::adopt_decomposed_procedure;\npub use adoption::{DecomposedProcedureSource, adopt_extracted_procedure};\n'
baseline=Path(inputs[parent]).read_text()
assert baseline.count(old)==1
normalized=out/'normalized-coding-parent.rs'
normalized.write_text(baseline.replace(old,new,1))
inputs[parent]=str(normalized)
(out/'accepted-formatting-inputs.json').write_text(json.dumps(inputs)+'\n')
code="import fs from 'node:fs'; import assert from 'node:assert/strict'; import {lex} from './scripts/self-translation/lexer.mjs'; for(const [file,old] of Object.entries(JSON.parse(fs.readFileSync(process.argv[1],'utf8')))){const tokens=s=>lex(s,'Rust').map(t=>[t.type,t.text]);assert.deepEqual(tokens(fs.readFileSync(file,'utf8')),tokens(fs.readFileSync(old,'utf8')),file);} console.log('Every Rust syntax token and comment is preserved apart from the declared order of two new reexports');"
run('accepted-format-token-equivalence',['node','--input-type=module','-e',code,str(out/'accepted-formatting-inputs.json')])
for proof in proofs:
    proof['parentLines']=len((root/proof['parent']).read_text().splitlines())
    proof['childLines']=len((root/proof['child']).read_text().splitlines())
    assert max(proof['parentLines'],proof['childLines'])<900
(out/'inverse-proofs.json').write_text(json.dumps({'files':proofs,'formattingPreservesSyntaxAndCommentsExceptTwoNewReexportOrder':True,'localRustExecution':False,'hostedNativeVerificationPending':True,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
tail=template[template.index("run('rust-format-check'"):]
tail=tail.replace("run('repository-workspace-runners-javascript',['node','--test','--test-concurrency=1','rust/tests/web/repository-workspace-runners.test.mjs'])","run('research-acceptance-javascript',['node','--test','--test-concurrency=1','rust/tests/web/coding-research-acceptance-state.test.mjs'])\nrun('solver-event-origin-javascript',['node','--test','--test-concurrency=1','rust/tests/web/solver-event-origin.test.mjs'])")
exec(compile(tail,__file__,'exec'))
