from pathlib import Path
import difflib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
source = Path('/tmp/issue-1580-research/extract-research-adoption-and-method-execution.py').read_text()
section = source[source.index("parent = root/'rust/src/meta_method_dispatch.rs'"):source.index("tail = template[")]
def retain(parent, child, original, updated, child_text, restored, label):
    print(json.dumps({'label':label,'originalBytes':len(original.encode()),'restoredBytes':len(restored.encode()),'exact':original==restored}))
    print(''.join(difflib.unified_diff(original.splitlines(True), restored.splitlines(True), fromfile='original', tofile='reassembled', n=3)))
exec(compile(section, __file__, 'exec'))
