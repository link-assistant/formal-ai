from pathlib import Path

template = Path('/tmp/issue-1580-research/extract-solver-config-and-command-allowlist.py').read_text()
preamble = template[:template.index("parent = root/'rust/src/solver.rs'")]
preamble = preamble.replace('solver-config-and-command-allowlist', 'research-adoption-and-method-execution')
exec(compile(preamble, __file__, 'exec'))

parent = root/'rust/src/coding_research_learning.rs'
child = root/'rust/src/coding_research_learning/adoption.rs'
original = parent.read_text()
assert len(original.splitlines()) == 941
marker = '/// Accept an extracted procedure as a second typed input shape, under the same'
start = original.index(marker)
block = original[start:]
addition = 'mod adoption;\n'
export = 'pub use adoption::{DecomposedProcedureSource, adopt_extracted_procedure};\n#[cfg(feature = "meta-language")]\npub use adoption::adopt_decomposed_procedure;\n'
anchor = 'const SEARCH_PAGE_LIMIT: usize = 3;'
updated = original[:start].rstrip()+'\n'
updated = updated.replace(anchor,addition+export+'\n'+anchor,1)
imports = 'use super::{\n    CodingResearchApproval, CodingResearchError, CodingResearchExecution, ResearchedCodingProcedure,\n    error,\n};\n\n'
child_text = imports+block
restored = updated.replace(addition+export+'\n','',1).rstrip()+'\n\n'+child_text.removeprefix(imports)
retain(parent,child,original,updated,child_text,restored,'research-adoption')

parent = root/'rust/src/meta_method_dispatch.rs'
child = root/'rust/src/meta_method_dispatch/execution.rs'
original = parent.read_text()
assert len(original.splitlines()) == 998
marker = 'fn try_learned_method('
start = original.index(marker)
block = original[start:]
addition = 'mod execution;\nuse execution::{\n    MethodRuntime, record_contextual_method_answer, record_method_answer, try_attributed_runtime,\n    try_learned_method,\n};\n\n'
trait_import = 'use std::fmt::Write as _;\n\n'
assert original.count(trait_import)==1
updated = original[:start].replace(trait_import,addition,1).rstrip()+'\n'
visibility = [
    ('fn try_learned_method(', 'pub(super) fn try_learned_method('),
    ('struct MethodRuntime {', 'pub(super) struct MethodRuntime {'),
    ('    proof_render_config: ProofRenderConfig,', '    pub(super) proof_render_config: ProofRenderConfig,'),
    ('    self_awareness_runtime: SelfAwarenessRuntime,', '    pub(super) self_awareness_runtime: SelfAwarenessRuntime,'),
    ('    const fn new(config: SolverConfig)', '    pub(super) const fn new(config: SolverConfig)'),
    ('fn try_attributed_runtime(', 'pub(super) fn try_attributed_runtime('),
    ('fn record_method_answer(', 'pub(super) fn record_method_answer('),
    ('fn record_contextual_method_answer(', 'pub(super) fn record_contextual_method_answer('),
]
for old,new in visibility:
    assert block.count(old)==1,old
    block = block.replace(old,new,1)
imports = 'use super::{\n    CapabilityRuntime, EventLog, IntentFormalization, MethodExecution, MethodRegistry,\n    MethodRuntimeKind, ProofRenderConfig, SelfAwarenessRuntime, SolverConfig, SymbolicAnswer,\n    UniversalSolver, answer_links_notation, append_diagnostic_trace, build_evidence_links,\n    try_behavior_rules_with_runtime, try_feature_capability, try_natural_language_tool_request,\n    try_playwright_script,\n};\nuse std::fmt::Write as _;\n\n'
child_text = imports+block
restored_block = child_text.removeprefix(imports)
for old,new in reversed(visibility): restored_block = restored_block.replace(new,old,1)
restored = updated.replace(addition,trait_import,1).rstrip()+'\n\n'+restored_block
retain(parent,child,original,updated,child_text,restored,'method-execution')

tail = template[template.index("(out/'formatting-inputs.json').write_text"):]
tail = tail.replace("run('repository-workspace-runners-javascript',['node','--test','--test-concurrency=1','rust/tests/web/repository-workspace-runners.test.mjs'])", "run('research-acceptance-javascript',['node','--test','--test-concurrency=1','rust/tests/web/coding-research-acceptance-state.test.mjs'])\nrun('solver-event-origin-javascript',['node','--test','--test-concurrency=1','rust/tests/web/solver-event-origin.test.mjs'])")
exec(compile(tail, __file__, 'exec'))
