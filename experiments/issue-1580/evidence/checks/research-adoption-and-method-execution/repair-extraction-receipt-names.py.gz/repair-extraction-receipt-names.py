from pathlib import Path
import gzip, hashlib, json, os, subprocess, sys
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/research-adoption-and-method-execution-corrected')
if len(sys.argv)==1:
    with (out/'receipt-repair-worker.log').open('wb') as stream:
        process=subprocess.Popen([sys.executable,__file__,'worker'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({'pid':process.pid,'finiteWorker':True}));sys.exit(0)
archive=root/'experiments/issue-1580/evidence/checks/solver-config-and-command-allowlist'
index=archive/'records.json';document=json.loads(index.read_text())
renames=[]
for row in document['entries']:
    old=row['file']
    if '-solver-config-' not in old:continue
    new=old.replace('-solver-config-','-solver-configuration-')
    packed=(archive/old).read_bytes()
    assert hashlib.sha256(packed).hexdigest()==row['archiveSha256']
    assert hashlib.sha256(gzip.decompress(packed)).hexdigest()==row['rawSha256']
    assert not (archive/new).exists()
    (archive/old).rename(archive/new)
    row['file']=new
    renames.append({'before':old,'after':new,'archiveSha256':row['archiveSha256'],'rawSha256':row['rawSha256']})
assert len(renames)==3
index.write_text(json.dumps(document,indent=2)+'\n')
(out/'receipt-owner-renames.json').write_text(json.dumps({'renames':renames,'payloadsUnchanged':True,'ratchetCeilingsUnchanged':True,'reason':'Three archived helper names created after the earlier gate retained the abbreviation config.'},indent=2)+'\n')
(out/'abbreviation-ratchet-failure.log').write_bytes((root/'experiments/formal_ai_subagent/sandboxes/gates/check-abbreviations.log').read_bytes())
argv=['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code']
result=subprocess.run(argv,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},capture_output=True)
(out/'repaired-source-gates.stdout').write_bytes(result.stdout);(out/'repaired-source-gates.stderr').write_bytes(result.stderr)
assert result.returncode==0,result.stdout
proof=json.loads((out/'inverse-proofs.json').read_text())
(out/'outcome.json').write_text(json.dumps({'passed':True,'files':proof['files'],'sourcePaths':[p for row in proof['files'] for p in [row['parent'],row['child']]],'registryChanged':False,'artifactOwnerRenamePaths':[archive.relative_to(root).as_posix()],'pushExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print('Four source gates pass; three receipt owners renamed, payloads and ratchet ceilings unchanged.')
