from pathlib import Path
import json, subprocess, sys
out = Path('/tmp/issue-1580-research/research-adoption-and-method-execution-corrected')
assert not (out/'first-launch-failure.log').exists()
(out/'first-launch-failure.log').write_bytes((out/'worker.log').read_bytes())
with (out/'worker.log').open('wb') as stream:
    process = subprocess.Popen([sys.executable,'/tmp/issue-1580-research/retry-research-adoption-and-method-execution.py','worker'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
print(json.dumps({'pid':process.pid,'finiteWorker':True}))
