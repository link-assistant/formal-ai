from pathlib import Path
import gzip, hashlib, json, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
failed = Path('/tmp/issue-1580-research/research-adoption-and-method-execution')
parent = root/'rust/src/coding_research_learning.rs'
child = root/'rust/src/coding_research_learning/adoption.rs'
original = gzip.decompress((failed/'research-adoption-original.rs.gz').read_bytes())
assert len(original.splitlines()) == 941
if len(sys.argv) == 1:
    assert parent.read_bytes() == (failed/'unformatted-0.rs').read_bytes()
    assert child.read_bytes() == (failed/'unformatted-1.rs').read_bytes()
    parent.write_bytes(original)
    child.unlink()
    (failed/'restoration.json').write_text(json.dumps({'originalSha256':hashlib.sha256(original).hexdigest(),'restoredBeforeRetry':True,'fullIssueComplete':False})+'\n')
else:
    assert parent.read_bytes() == original and not child.exists()
source = Path('/tmp/issue-1580-research/extract-research-adoption-and-method-execution.py').read_text()
source = source.replace("'research-adoption-and-method-execution')", "'research-adoption-and-method-execution-corrected')",1)
source = source.replace("marker = 'fn try_learned_method('", "marker = '/// Execute one adopted learned method as the recipe program its learned'")
exec(compile(source, __file__, 'exec'))
