from pathlib import Path
import json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-main-integration-validation')
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('w') as stream:
        worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);commands=[]
def run(name,args,allowed=[0]):
    with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
        result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'arguments':args,'exitCode':result.returncode};commands.append(row)
    (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert result.returncode in allowed,row
try:
    run('staged-release-projection',['node','--max-old-space-size=256','scripts/generate-staged-release.mjs','--check-deployed'])
    for name in ['default-branch-build-policy','typescript-runtime','release-stage-transfer','release-pending-pipeline','procedural-runtime-parity']:
        run(name,['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs'],[0,1])
    run('native-input-checkout',['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/native-checkout-retry.test.mjs'],[0,1])
    run('full-javascript-profile',['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/full-default-javascript-profile.test.mjs'],[0,1])
    env['NODE_OPTIONS']='--max-old-space-size=256'
    run('all-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs'],[0,1])
    (out/'outcome.json').write_text(json.dumps({'allPassing':all(row['exitCode']==0 for row in commands),'commands':commands,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
