from pathlib import Path
import re,json,subprocess,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-main-integration');out.mkdir(exist_ok=False)
pattern=re.compile(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> origin/main\n',re.M|re.S)
records=[]
for name in ['.github/workflows/native-type-check.yml','rust/tests/web/default-branch-build-policy.test.mjs','rust/tests/web/typescript-runtime.test.mjs']:
    file=root/name;source=file.read_text();matches=list(pattern.finditer(source));records.append({'path':name,'conflicts':len(matches)})
    def choose(match):
        ours,theirs=match.groups()
        if name.endswith('default-branch-build-policy.test.mjs'):
            if 'function evaluate(' in theirs:
                signature=theirs.strip()
                return re.sub(r'function evaluate[^\n]*',lambda _:signature,ours,count=1)
            if "main release depends on package" in theirs:
                return theirs[:theirs.index('// Issue #1569')]+ours
        if name.endswith('native-type-check.yml'):
            if 'id: report-http' in theirs:
                return theirs+ours[ours.index('        if:'):]
            if 'id: bun' in theirs:
                return '        id: bun\n'+ours
        return ours
    source=pattern.sub(choose,source)
    if name.endswith('native-type-check.yml'):
        marker='            /experiments/js_dogfood/**\n'
        assert source.count(marker)==2
        source=source.replace(marker,marker+'            /experiments/issue_859_codex_e2e/**\n')
    if name.endswith('default-branch-build-policy.test.mjs'):
        source=source.replace("  const gatewayReplay =", "  const codexReplay = 'bash experiments/issue_859_codex_e2e/run.sh';\n  const gatewayReplay =",1)
        marker="    'node --test --test-concurrency=1 rust/tests/web/issue-1396-native.test.mjs',\n"
        assert source.count(marker)==1
        source=source.replace(marker,marker+'    codexReplay,\n')
        marker="      '/experiments/dynamic-meta/**', '/experiments/js_dogfood/**',\n"
        assert source.count(marker)==1
        source=source.replace(marker,marker+"      '/experiments/issue_859_codex_e2e/**',\n")
    assert not pattern.search(source) and '<<<<<<<' not in source
    file.write_text(source)
evidence=root/'experiments/formal_ai_subagent/evidence/specification-delivery-1188/dormant-staged-release'
workflow=evidence/'original-release-workflow.yml';sha=hashlib.sha256(workflow.read_bytes()).hexdigest()
for name,key in [('candidate-output-bindings.json','originalSourceSha256'),('stage-source-coverage.json','workflowSha256')]:
    file=evidence/name;source=pattern.sub(lambda match:match[1],file.read_text())
    source=re.sub('("'+key+r'": ")[a-f0-9]{64}(")',lambda match:match[1]+sha+match[2],source,count=1)
    assert json.loads(source)[key]==sha
    file.write_text(source)
(out/'resolution.json').write_text(json.dumps({'paths':records,'originalReleaseSourceSha256':sha,'preservedNewCodexReplay':True,'preservedIndependentNativeFamilies':True,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
subprocess.run(['git','add','--',*[row['path'] for row in records],str(evidence/'candidate-output-bindings.json'),str(evidence/'stage-source-coverage.json')],cwd=root,check=True)
print((out/'resolution.json').read_text())
