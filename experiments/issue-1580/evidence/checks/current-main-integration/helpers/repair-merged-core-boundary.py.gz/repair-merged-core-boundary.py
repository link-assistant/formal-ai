from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-main-core-boundary-repair');out.mkdir(exist_ok=False)
owner=root/'rust/src/solver_handlers/web_search_intent.rs';caller=root/'rust/src/protocol_policy.rs'
before=owner.read_text();old_caller=caller.read_text()
for path in [owner,caller]:(out/(path.name+'.before')).write_bytes(path.read_bytes())
wrapper='pub(crate) fn explicit_web_search_requested(prompt: &str, normalized: &str) -> bool {\n    extract_explicit_web_search_query(&prompt.to_lowercase()).is_some()\n        || extract_explicit_web_search_query(normalized).is_some()\n}\n\n'
assert before.count(wrapper)==1
after=before.replace(wrapper,'').replace('fn extract_explicit_web_search_query(normalized: &str) -> Option<String> {','pub(crate) fn extract_explicit_web_search_query(normalized: &str) -> Option<String> {')
assert len(before.splitlines())-len(after.splitlines())==5
new_caller=old_caller.replace('use crate::solver_handlers::web_search_intent::explicit_web_search_requested;','use crate::solver_handlers::web_search_intent::extract_explicit_web_search_query;')
old_condition='if explicit_web_search_requested(prompt, &normalized) {'
new_condition='if extract_explicit_web_search_query(&prompt.to_lowercase()).is_some()\n        || extract_explicit_web_search_query(&normalized).is_some()\n    {'
assert new_caller.count(old_condition)==1;new_caller=new_caller.replace(old_condition,new_condition)
for name in ['check-minimal-core-boundary','check-minimal-core-boundary-js-twin']:
    original=root/'experiments/formal_ai_subagent/sandboxes/gates'/(name+'.log')
    (out/(name+'.before.log')).write_bytes(original.read_bytes())
owner.write_text(after);caller.write_text(new_caller)
assert wrapper.replace('explicit_web_search_requested','unused',1).split('\n')[1:3]==['    extract_explicit_web_search_query(&prompt.to_lowercase()).is_some()','        || extract_explicit_web_search_query(normalized).is_some()']
record={'reason':'Use the existing query parser directly at the sole policy caller; preserve evaluation order and short-circuit behavior without a redundant five-line handler wrapper.','handlerLinesBefore':len(before.splitlines()),'handlerLinesAfter':len(after.splitlines()),'ceilingChanged':False,'parserBodyUnchanged':True,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(out/'repair.json').write_text(json.dumps(record,indent=2)+'\n')
with (out/'rustfmt.stdout').open('w') as stdout,(out/'rustfmt.stderr').open('w') as stderr:
    result=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--check',str(owner),str(caller)],cwd=root,stdout=stdout,stderr=stderr)
assert result.returncode==0,result.returncode
print(json.dumps(record))
