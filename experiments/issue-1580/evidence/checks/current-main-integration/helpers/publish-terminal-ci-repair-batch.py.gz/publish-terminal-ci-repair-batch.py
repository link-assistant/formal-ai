from pathlib import Path
import json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
out=scratch/'terminal-ci-repair-publication'
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('w') as stream:
        worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
records=[]
def run(name,args):
    with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
        result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
    records.append({'name':name,'arguments':args,'exitCode':result.returncode})
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    assert result.returncode==0,(name,result.returncode)
    return (out/(name+'.stdout')).read_text()
try:
    committed=json.loads((scratch/'terminal-ci-repair-commit/outcome.json').read_text());assert committed['allPassing']
    branch=run('branch',['git','branch','--show-current']).strip();assert branch=='issue-1580-8d61a32a61e1'
    assert not run('working-tree',['git','status','--porcelain']).strip()
    run('fetch-main',['git','fetch','origin','main'])
    run('main-is-ancestor',['git','merge-base','--is-ancestor','origin/main','HEAD'])
    for status in ['in_progress','queued']:
        runs=json.loads(run('runs-'+status,['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--status',status,'--limit','100','--json','databaseId,workflowName,headSha']))
        assert not runs,runs
    prior=json.loads(run('pull-request-before',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','title,body,headRefOid,isDraft,url']))
    body=prior['body'].replace('902-file','903-file')
    begin=body.index('Verification and limits:')
    end=body.index('Upstream reproductions:')
    latest='''Verification and limits:

- The preceding ff6b097f head completed all 26 workflows: 23 succeeded, one was skipped, and two failed. Their complete logs are retained before this push.
- Repair all twelve extracted helper module paths, with a failing-before path-resolution fixture, fifteen passing headroom cases and unchanged native assertion bodies.
- Isolate offline fixture source caches; prove polluted caller-cache replay, clean shipped-baseline execution and caller restoration with a real cache regression. Existing CI deadlines stay unchanged.
- Update stale release, TypeScript and notation assertions with negative controls. Preserve all response records and the exact ordered runtime/bootstrap body while splitting the primary response seed.
- Local validation: all 141 gates attempted, 88 passed and 53 explicitly require hosted execution. All 158 maintained issue cases, focused affected tests and post-path-change specification/documentation checks pass. The governed witness retains 221 cases and 968 unsupported items. No local native build was run.
- Current source-size warnings: 64, under unchanged limits. The complete 903-file JavaScript suite and native compilation/execution must still pass on this head. Full template/practice and original issue acceptance remain open; this PR remains draft and unmerged.

The actual CodeQL producer run 44879033589 retains both original standard
SARIF reports, 2,180 included-string rows and 122,579 macro-context rows.
Complete child-macro semantic qualification, main-only/live acceptance,
original workflow qualification and remaining dependency observations stay
open. Independent Formal AI reasoning remains 0/20 and the independent
authorship acceptance floor is unmet; supplied work receives no credit.

The [latest checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/terminal-ci-repair-checkpoint.md),
[work plan](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/experiments/issue-1580/work-plan.md)
and [case study](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/README.md)
retain the complete requirement/evidence mapping and dated head scopes.

'''
    body=body[:begin]+latest+body[end:]
    assert 'Fixes #1580' in body
    (out/'body.md').write_text(body)
    run('edit-pull-request',['gh','pr','edit','1581','--repo','link-assistant/formal-ai','--title','fix: repair complete CI coverage and preserve failure evidence','--body-file',str(out/'body.md')])
    run('push',['git','push','origin','HEAD:refs/heads/'+branch])
    after=json.loads(run('pull-request-after',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','title,body,headRefOid,isDraft,url']))
    assert after['headRefOid']==committed['head'] and after['isDraft']
    (out/'outcome.json').write_text(json.dumps({'head':committed['head'],'published':True,'url':after['url'],'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
    print((out/'outcome.json').read_text())
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
