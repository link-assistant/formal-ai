from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
expression=lambda value:chr(36)+'{{ '+value+' }}'
old=expression("!cancelled() && inputs.compile-inputs-changed && steps.native-lint.outcome == 'success'")
guard=expression("!cancelled() && inputs.compile-inputs-changed && steps.native-lint.outcome == 'success' && steps.bun.outcome == 'success'")
file=root/'.github/workflows/native-type-check.yml';source=file.read_text()
source=source.replace("        if: "+expression("!cancelled() && steps.bun.outcome == 'success'"),"        if: "+guard,1)
marker='      - name: Replay dynamic meta authorization and receipts through the native gateway\n        if: '+old
assert source.count(marker)==1
source=source.replace(marker,marker.replace(old,guard))
file.write_text(source)
file=root/'rust/tests/web/default-branch-build-policy.test.mjs';source=file.read_text()
source=source.replace('  assert.equal(later.length, 7);','  assert.equal(later.length, 8);',1)
source=source.replace("lint = 'success', cancelled = false", "lint = 'success', bun = 'success', cancelled = false",1)
source=source.replace("steps: {'native-lint': {outcome: lint}}","steps: {'native-lint': {outcome: lint}, bun: {outcome: bun}}",1)
source=source.replace('    assert.equal(step.if, "'+old+'");','    assert.equal(step.if, step.run === gatewayReplay ? "'+guard+'" : "'+old+'");',1)
marker="  assert.equal(job.steps.find(step => step.name === 'Type-check and lint the library and binaries').id, 'native-lint');"
assert source.count(marker)==1
source=source.replace(marker,"  for (const step of later.filter(step => step.run === 'bash experiments/issue_859_codex_e2e/run.sh' || step.name?.startsWith('Replay dynamic meta'))) {\n    for (const bun of ['failure', 'skipped']) assert.equal(selected(step, {bun}), false);\n  }\n"+marker)
file.write_text(source)
print('Preserved independent Codex replay, compile-input/lint admission and successful Bun dependency.')
