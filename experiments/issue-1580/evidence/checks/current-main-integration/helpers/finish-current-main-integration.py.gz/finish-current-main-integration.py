from pathlib import Path
import gzip,hashlib,json,os,re,subprocess,sys,time,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
out=scratch/'current-main-integration-commit-retry'
evidence=root/'experiments/issue-1580/evidence/checks/current-main-integration'
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('w') as stream:
        worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0'
env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
commands=[]
def run(name,args):
    with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
        result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'exitCode':result.returncode};commands.append(row)
    (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert result.returncode==0,row
    return (out/(name+'.stdout')).read_text()
try:
    validation=scratch/'current-main-integration-validation'
    while not (validation/'outcome.json').exists():
        assert not (validation/'failure.json').exists()
        time.sleep(5)
    initial=json.loads((validation/'outcome.json').read_text())
    failures=[row['name'] for row in initial['commands'] if row['exitCode']!=0]
    assert failures==['default-branch-build-policy','all-local-gates'],failures
    full=(validation/'all-local-gates.stdout').read_text()
    counts={key:len(re.findall('^'+key+r' ',full,re.M)) for key in ['PASS','SKIP','FAIL']}
    assert counts=={'PASS':86,'SKIP':53,'FAIL':2},counts
    run('default-branch-build-policy-retry',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/default-branch-build-policy.test.mjs'])
    run('handler-inventory',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-0918-handler-inventory.test.mjs'])
    run('affected-gates-retry',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-minimal-core-boundary-js-twin,check-minimal-core-boundary,check-generated-files,check_js_rust_translation,check-specification-in-javascript,check-tests-as-documentation-javascript-twin,check-tests-as-docs'])
    run('whitespace-before-archive',['git','diff','--check'])
    assert not run('unmerged-paths',['git','diff','--name-only','--diff-filter=U']).strip()
    assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
    main=run('integrated-main',['git','rev-parse','MERGE_HEAD']).strip()
    assert main=='665795fec29076837d1459410dda11fe3297417b'
    note=root/'docs/case-studies/issue-1580/current-main-integration-checkpoint.md'
    note.write_text('''# Current main integration checkpoint

Merge main 665795fe into the complete CI repair batch. Preserve its new Codex
Default-mode reporting replay and independent staged-release admission. Keep
the independent native contract families, checked sparse retries, exact input
closure and complete 903-file JavaScript suite from this pull request.

The first focused policy check reports one stale seven-replay assertion after
main adds an eighth replay. Update the inventory and require successful Bun
setup for the Codex and dynamic-meta steps. Negative controls reject failed
or skipped Bun setup, failed native lint, unchanged inputs and cancellation.
The corrected complete policy file passes.

All 141 JavaScript gates run against the combined source: 86 pass, 53
explicitly require hosted execution and two expose a five-line handler-ceiling
conflict. The sole caller now uses the existing explicit-query parser directly,
preserving short-circuit order and the parser body. Both affected gates and the
generation, translation, specification and documentation checks pass afterward.
No handler ceiling is raised. TypeScript runtime, staged-release source
projection, artifact transfer, pending-pipeline policy, procedural parity,
sparse-checkout retry and complete JavaScript profile checks pass. The initial
focused failure and successful retry remain separate observations.

The earlier publication preflight correctly refuses to push when origin/main
advances; no remote write occurred in that attempt. This merge addresses that
observation. Next-head native compilation and complete hosted suite execution
remain required. The remaining warnings and wider issue acceptance stay open;
the pull request remains draft and unmerged. Supplied commands and edits earn
zero independent-authorship or reasoning credit.

Evidence: experiments/issue-1580/evidence/checks/current-main-integration/.
PR: https://github.com/link-assistant/formal-ai/pull/1581
''')
    plan=root/'experiments/issue-1580/work-plan.md'
    plan.write_text(plan.read_text()+'\n- Merge current main 665795fe after publication preflight detects its advance. Preserve the added Codex replay and independent release admission; correct the eight-replay inventory and verify Bun prerequisites with negative controls. The full 141-gate run reports 86 passes, 53 explicit hosted-only skips and two handler-ceiling conflicts. Reuse the existing query parser at its sole policy caller without raising ceilings; both failed gates and affected generation, translation, specification and documentation gates pass afterward. Initial failures remain separate from successful retries. Hosted execution, remaining warnings and complete original acceptance stay open. See [current main integration](../../docs/case-studies/issue-1580/current-main-integration-checkpoint.md).\n')
    evidence.mkdir(exist_ok=False);records=[]
    def archive(alias,file):
        raw=file.read_bytes();packed=gzip.compress(raw,mtime=0)
        target=evidence/(alias+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(packed)
        records.append({'file':alias+'.gz','bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
    for name in ['current-main-integration','current-main-integration-validation','terminal-ci-repair-publication','current-main-core-boundary-repair','current-main-integration-commit']:
        for file in sorted((scratch/name).rglob('*')):
            if file.is_file():archive(name+'/'+str(file.relative_to(scratch/name)),file)
    for name in ['resolve-current-main-integration.py','complete-codex-replay-integration.py','verify-current-main-integration.py','publish-terminal-ci-repair-batch.py','finish-current-main-integration.py','repair-merged-core-boundary.py']:
        archive('helpers/'+name,scratch/name)
    for suffix in ['stdout','stderr']:archive('default-branch-build-policy-retry.'+suffix,out/('default-branch-build-policy-retry.'+suffix))
    for name in ['handler-inventory','affected-gates-retry']:
        for suffix in ['stdout','stderr']:archive(name+'.'+suffix,out/(name+'.'+suffix))
    for file in sorted((root/'experiments/formal_ai_subagent/sandboxes/gates').iterdir()):
        if file.is_file():archive('local-gate-logs/'+file.name,file)
    (evidence/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
    run('stage-tracked',['git','add','-u'])
    run('stage-evidence',['git','add','--',str(evidence.relative_to(root)),str(note.relative_to(root))])
    run('naming',['node','scripts/measure-abbreviations.mjs','--check'])
    staged=subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=ACMRT','-z'],cwd=root).decode().split('\0')[:-1]
    run('secrets',['bash','scripts/check-secrets.sh',*staged])
    run('whitespace',['git','diff','--cached','--check'])
    run('commit',['git','-c','gc.auto=0','commit','-m','Merge current main and preserve independent Codex replay checks'])
    head=run('committed-head',['git','rev-parse','HEAD']).strip()
    (out/'outcome.json').write_text(json.dumps({'head':head,'integratedMain':main,'allPassing':True,'localGates':counts,'pushed':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
