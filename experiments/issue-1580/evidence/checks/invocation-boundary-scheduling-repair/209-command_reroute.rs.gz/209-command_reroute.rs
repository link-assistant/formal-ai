//! Route command-bearing symbolic answers through an agentic CLI's real tools.
//!
//! The ordinary solver can return a code artifact with a typed execution recipe.
//! On an API request from an agentic harness, the client owns its workspace,
//! permission prompts, sandbox, and audit trail. This adapter lowers the recipe
//! into a write -> command(s) -> final tool loop. It is generic over language,
//! command, file name, and client tool names and never scrapes rendered prose.

use serde_json::json;
use std::fmt::Write as _;

use crate::engine::{ExecutionRecipe, SymbolicAnswer};
use crate::protocol::ChatMessage;

use super::capability_router::is_workspace_creation_tool;
use super::git_commit::{self, CommitTarget};
use super::planner::{
    AgenticPlan, Capability, PlannedToolCall, tool_capability, tool_for, write_arguments,
};

/// Plan the next client-side step for a typed source-and-command artifact.
///
/// Both a file-write and command-execution tool must be advertised. This
/// preserves ordinary text behavior for non-agentic clients and never invents a
/// tool that the harness cannot execute.
#[must_use]
pub fn plan_symbolic_command_reroute(
    messages: &[ChatMessage],
    tool_names: &[&str],
    symbolic_answer: &SymbolicAnswer,
) -> Option<AgenticPlan> {
    plan_symbolic_command_reroute_for_objective(
        messages,
        tool_names,
        symbolic_answer,
        &crate::protocol::latest_user_request(messages).unwrap_or_default(),
    )
}

pub(super) fn plan_symbolic_command_reroute_for_objective(
    messages: &[ChatMessage],
    tool_names: &[&str],
    symbolic_answer: &SymbolicAnswer,
    objective: &str,
) -> Option<AgenticPlan> {
    recipe_step(messages, tool_names, symbolic_answer, objective, false)
}

pub(super) fn plan_owned_recipe_recovery(
    messages: &[ChatMessage],
    tool_names: &[&str],
    symbolic_answer: &SymbolicAnswer,
    objective: &str,
) -> Option<AgenticPlan> {
    recipe_step(messages, tool_names, symbolic_answer, objective, true)
}

#[path = "command_reroute/recipe_execution.rs"]
mod recipe_execution;
use recipe_execution::recipe_step;

fn recipe_file_matches(
    observation: &super::progress::Progress,
    path: &str,
    source: &str,
    supporting_paths: &[&str],
) -> bool {
    if let Some(index) = observation.latest_source_mutation_index(path)
        && let Some(attempt) = observation.research_attempts().get(index)
        && attempt.succeeded
        && let Some(arguments) = attempt.arguments.as_deref()
    {
        let expected = match attempt.capability {
            Capability::Write if super::progress::write_matches(arguments, path, source) => {
                serde_json::from_str(arguments).ok()
            }
            Capability::Edit
                if attempt
                    .tool
                    .as_deref()
                    .is_some_and(is_workspace_creation_tool)
                    && !source.is_empty()
                    && source.ends_with('\n')
                    && crate::protocol_responses::apply_patch_input(&write_arguments(
                        path, source,
                    ))
                    .as_deref()
                        == Some(arguments) =>
            {
                Some(serde_json::Value::String(arguments.to_owned()))
            }
            _ => None,
        };
        if let Some(expected) = expected
            && observation
                .latest_attempt_for(attempt.capability, &expected)
                .is_some_and(|frame| {
                    frame.binding == super::qualified_tool_observation::Binding::Exact
                        && frame.succeeded
                })
        {
            return true;
        }
    }
    if super::recipe_resume::recipe_source_matches(observation, path, source) {
        return true;
    }
    super::recipe_resume::recipe_source_preimage(observation, path, supporting_paths)
        .is_some_and(|before| !before.absent && before.source.as_deref() == Some(source))
}

fn recipe_workflow(
    recipe: &ExecutionRecipe,
    objective: &str,
    versions: &std::cell::OnceCell<crate::version_resolution::VersionSet>,
) -> Option<String> {
    let mut expected = recipe.clone();
    expected.supporting_files.clear();
    super::ci_workflow::attach_with(&mut expected, objective, || {
        versions.get_or_init(crate::version_resolution::VersionSet::for_generation)
    });
    let workflow = expected.supporting_files.first()?;
    if !recipe
        .supporting_files
        .iter()
        .any(|file| file.path == workflow.path && file.source == workflow.source)
    {
        return None;
    }
    workflow
        .source
        .lines()
        .find_map(|line| line.strip_prefix("name: ").map(str::to_owned))
}

fn one_call(tool: &str, arguments: String) -> AgenticPlan {
    AgenticPlan::ToolCalls(vec![PlannedToolCall {
        tool: tool.to_owned(),
        arguments,
    }])
}

impl ExecutionRecipe {
    /// The harness-voice completion: artifact, fence, commands, actual output.
    /// Shared with the literal-file general plan a resolved work item composes
    /// (issue #1133), so every drive that ends in a harness-executed artifact
    /// reports through one voice.
    pub(super) fn final_answer(
        &self,
        outputs: &[String],
        committed: Option<&CommitTarget>,
    ) -> String {
        // With a commit step the last output is the push's; the verification
        // output the claim rests on is the one before it.
        let (verification_outputs, commit_output) = match committed {
            Some(_) if outputs.len() > self.commands.len() => (
                &outputs[..self.commands.len()],
                outputs.get(self.commands.len()),
            ),
            _ => (outputs, None),
        };
        let outputs = verification_outputs;
        let mut answer = format!(
            "Created and verified `{}` through the agentic CLI harness.\n\n```{}\n{}\n```\n\nCommands executed by the harness:\n",
            self.path, self.language, self.source
        );
        for file in &self.supporting_files {
            let _ = write!(
                answer,
                "\n`{}`\n\n```text\n{}\n```\n",
                file.path, file.source
            );
        }
        for command in &self.commands {
            let _ = writeln!(answer, "- `{command}`");
        }
        let actual = outputs
            .iter()
            .rev()
            .find(|output| !output.trim().is_empty())
            .map_or("(command completed without output)", |output| output.trim());
        let _ = write!(answer, "\nActual tool output:\n\n```text\n{actual}\n```");
        if let (Some(target), Some(output)) = (committed, commit_output) {
            // Issue #1157: an unchanged tree after a repeated or resumed run is
            // a success, stated in a sentence rather than left as a marker.
            let marker = super::work_item_steps::fill("commit_nothing_marker", &[]);
            if output.lines().any(|line| line.trim() == marker) {
                let _ = write!(
                    answer,
                    "\n\n{}",
                    super::work_item_steps::fill(
                        "commit-unchanged-report",
                        &[(concat!("{", "branch}"), target.push_ref())],
                    )
                );
            }
            let _ = write!(
                answer,
                "\n\nCommitted and pushed to `{}` for {}:\n\n```text\n{}\n```",
                target.push_ref(),
                target.reference,
                output.trim()
            );
        }
        answer
    }
}

/// Whether the actual history is at the first inferred check after all source writes.
pub fn optional_check_stage(
    messages: &[ChatMessage],
    tools: &[&str],
    recipe: &ExecutionRecipe,
) -> bool {
    let Some(write_tool) = tool_for(tools, Capability::Write).or_else(|| {
        tools
            .iter()
            .copied()
            .find(|name| is_workspace_creation_tool(name))
    }) else {
        return false;
    };
    let progress =
        RecipeProgress::after_latest_user(messages, write_tool, recipe, &recipe.commands, false);
    progress.files_written == 1 + recipe.supporting_files.len() && progress.commands_done == 0
}

#[derive(Default)]
struct RecipeProgress {
    files_written: usize,
    commands_done: usize,
    command_outputs: Vec<String>,
    failure: Option<StepFailure>,
    repair_rung: u8,
    source_checked: std::collections::BTreeSet<String>,
    source_preimages: std::collections::BTreeMap<String, super::recipe_resume::RecipeSourceResult>,
    source_invalidated: bool,
    failure_index: Option<usize>,
    last_command_index: Option<usize>,
}

/// A step the harness reported as failed, kept with the evidence that makes the
/// verdict checkable: the exit code the harness stated (when it stated one) and
/// whether the step was a command run rather than the file write.
struct StepFailure {
    reported: String,
    exit_code: Option<i32>,
    from_run: bool,
}

impl StepFailure {
    /// Report the failed step to the caller.
    ///
    /// The exit code is named when the harness gave one, and the step is named
    /// by the command that produced it: a harness that ran the command exactly
    /// as asked did not itself fail, so the report never says it did
    /// (issue #908).
    fn report(&self, messages: &[ChatMessage], path: &str, step: &str) -> String {
        const STEP_PLACEHOLDER: &str = "{step}";
        const PATH_PLACEHOLDER: &str = "{path}";
        const CODE_PLACEHOLDER: &str = "{code}";
        const REPORT_PLACEHOLDER: &str = "{report}";

        let language = crate::language::detect(
            &crate::protocol::latest_user_request(messages).unwrap_or_default(),
        )
        .slug();
        let intent = if self.exit_code.is_some() {
            "agentic_step_failed_with_exit_code"
        } else {
            "agentic_step_failed"
        };
        let code = self
            .exit_code
            .map(|code| code.to_string())
            .unwrap_or_default();
        crate::seed::localized_response(intent, language)
            .unwrap_or_default()
            .replace(STEP_PLACEHOLDER, step)
            .replace(PATH_PLACEHOLDER, path)
            .replace(CODE_PLACEHOLDER, &code)
            .replace(REPORT_PLACEHOLDER, self.reported.trim())
    }
}

impl RecipeProgress {
    fn after_latest_user(
        messages: &[ChatMessage],
        write_tool: &str,
        recipe: &ExecutionRecipe,
        expected_commands: &[String],
        resume: bool,
    ) -> Self {
        let start = super::planner::evidence_window_start(messages);
        let mut progress = Self::default();
        let files: Vec<(&str, &str)> =
            std::iter::once((recipe.path.as_str(), recipe.source.as_str()))
                .chain(
                    recipe
                        .supporting_files
                        .iter()
                        .map(|file| (file.path.as_str(), file.source.as_str())),
                )
                .collect();
        let supporting_paths: Vec<&str> = recipe
            .supporting_files
            .iter()
            .map(|file| file.path.as_str())
            .collect();
        let batch_command = (supporting_paths.len() > 1)
            .then(|| super::recipe_resume::recipe_sources_command(&supporting_paths));
        let mut observed_ids = std::collections::BTreeSet::new();
        for (index, message) in messages.iter().enumerate().skip(start) {
            if message.role != "tool" {
                continue;
            }
            let Some(call_id) = message.tool_call_id.as_deref() else {
                continue;
            };
            let Some(call) = messages[start..index]
                .iter()
                .rev()
                .flat_map(|prior| &prior.tool_calls)
                .find(|call| call.id == call_id)
                .filter(|_| observed_ids.insert(call_id))
            else {
                continue;
            };
            let result_tool = call.function.name.as_str();
            if message
                .name
                .as_deref()
                .is_some_and(|name| !name.eq_ignore_ascii_case(result_tool))
            {
                continue;
            }
            let capability = tool_capability(result_tool);
            let matches_write = files
                .get(progress.files_written)
                .is_some_and(|(path, source)| {
                    (result_tool.eq_ignore_ascii_case(write_tool)
                        && super::progress::write_matches(&call.function.arguments, path, source))
                        || (capability == Some(Capability::Edit)
                            && is_workspace_creation_tool(result_tool)
                            && !source.is_empty()
                            && source.ends_with('\n')
                            && crate::protocol_responses::apply_patch_input(&write_arguments(
                                path, source,
                            ))
                            .as_deref()
                                == Some(call.function.arguments.as_str()))
                });
            let matches_run = capability == Some(Capability::Run)
                && progress.files_written == files.len()
                && run_command_of(&messages[start..index], Some(call_id)).is_some_and(|command| {
                    expected_commands
                        .get(progress.commands_done)
                        .is_some_and(|expected| {
                            command == *expected
                                || command
                                    .split_once("\n# __formal_ai_prerequisite_retry\n")
                                    .is_some_and(|(_, retry)| retry == expected)
                        })
                });
            let matches_batch = resume
                && progress.files_written == 1
                && capability == Some(Capability::Run)
                && batch_command.as_ref().is_some_and(|expected| {
                    super::tool_result::command_argument(&call.function.arguments).as_ref()
                        == Some(expected)
                });
            let probe_path = files.get(progress.files_written).filter(|(path, _)| {
                resume
                    && capability == Some(Capability::Run)
                    && super::tool_result::command_argument(&call.function.arguments).is_some_and(
                        |command| command == super::recipe_resume::recipe_source_command(path),
                    )
            });
            let update_command = files
                .get(progress.files_written)
                .and_then(|(path, source)| {
                    progress.source_preimages.get(*path).and_then(|before| {
                        super::recipe_resume::recipe_source_update_command(path, source, before)
                    })
                });
            let matches_update = resume
                && capability == Some(Capability::Run)
                && update_command.as_deref().is_some_and(|expected| {
                    super::tool_result::command_argument(&call.function.arguments).as_deref()
                        == Some(expected)
                });
            if !matches_write
                && !matches_run
                && probe_path.is_none()
                && !matches_update
                && !matches_batch
            {
                continue;
            }
            let output = message.content.plain_text();
            if matches_batch {
                let observed = super::progress::Progress::scan(&messages[start..=index]);
                let results = batch_command
                    .as_deref()
                    .and_then(|command| {
                        super::recipe_resume::recipe_source_receipt(&observed, command)
                    })
                    .and_then(|receipt| {
                        super::recipe_resume::recipe_sources_result(receipt, &supporting_paths)
                    });
                if let Some(results) = results {
                    progress.failure = None;
                    for (path, before) in supporting_paths.iter().zip(results) {
                        progress.source_checked.insert((*path).to_owned());
                        progress.source_preimages.insert((*path).to_owned(), before);
                    }
                    while let Some((path, source)) = files.get(progress.files_written) {
                        if !super::recipe_resume::recipe_source_preimage(
                            &observed,
                            path,
                            &supporting_paths,
                        )
                        .is_some_and(|before| {
                            !before.absent && before.source.as_deref() == Some(*source)
                        }) {
                            break;
                        }
                        progress.files_written += 1;
                    }
                } else {
                    progress.failure_index = Some(index);
                    progress.failure = Some(StepFailure {
                        reported: output,
                        exit_code: None,
                        from_run: false,
                    });
                }
                continue;
            }
            if matches_update {
                let (path, _) = files[progress.files_written];
                let observation = super::progress::Progress::scan(&messages[start..=index]);
                let receipt = super::recipe_resume::recipe_source_receipt(
                    &observation,
                    update_command.as_deref().unwrap_or(""),
                );
                if receipt.is_some_and(|receipt| {
                    super::recipe_resume::recipe_source_update_result(receipt, path)
                }) {
                    progress.source_checked.remove(path);
                    progress.source_preimages.remove(path);
                } else {
                    progress.failure_index = Some(index);
                    progress.failure = Some(StepFailure {
                        reported: output,
                        exit_code: None,
                        from_run: false,
                    });
                }
                continue;
            }
            if let Some((path, source)) = probe_path {
                let observation = super::progress::Progress::scan(&messages[start..=index]);
                let command = super::recipe_resume::recipe_source_command(path);
                let result = super::recipe_resume::recipe_source_receipt(&observation, &command)
                    .and_then(|receipt| super::recipe_resume::recipe_source_result(receipt, path));
                if let Some(result) = result {
                    progress.failure = None;
                    progress.source_checked.insert((*path).to_owned());
                    progress
                        .source_preimages
                        .insert((*path).to_owned(), result.clone());
                    if !result.absent && result.source.as_deref() == Some(*source) {
                        progress.files_written += 1;
                    }
                } else {
                    progress.failure_index = Some(index);
                    progress.failure = Some(StepFailure {
                        reported: output.clone(),
                        exit_code: reported_exit_code(&output),
                        from_run: false,
                    });
                }
                continue;
            }
            if message.is_error {
                if matches_run {
                    progress.repair_rung = progress.repair_rung.saturating_add(1);
                }
                let exit_code = reported_exit_code(&output);
                progress.failure_index = Some(index);
                progress.failure = Some(StepFailure {
                    reported: output,
                    exit_code,
                    from_run: matches_run,
                });
                continue;
            }
            if let Some(failure) =
                StepFailure::from_result(output.clone(), capability == Some(Capability::Run))
            {
                if matches_run {
                    progress.repair_rung = progress.repair_rung.saturating_add(1);
                }
                progress.failure_index = Some(index);
                progress.failure = Some(failure);
                continue;
            }
            // Only this still-pending action can match above. A later bound
            // successful retry clears its failure; unrelated setup or a future
            // verification result cannot. The failed observation stays in the
            // transcript, so interrupted recovery replays without hidden state.
            progress.failure = None;
            match capability {
                _ if matches_write => {
                    progress.files_written += 1;
                    let observed = super::progress::Progress::scan(&messages[start..=index]);
                    while let Some((path, source)) = files.get(progress.files_written) {
                        if !super::recipe_resume::recipe_source_preimage(
                            &observed,
                            path,
                            &supporting_paths,
                        )
                        .is_some_and(|before| {
                            !before.absent && before.source.as_deref() == Some(*source)
                        }) {
                            break;
                        }
                        progress.files_written += 1;
                    }
                }
                Some(Capability::Run) => {
                    progress.commands_done += 1;
                    progress.last_command_index = Some(index);
                    // Quote what the command printed, not the harness envelope
                    // it arrived in (issues #905 and #908).
                    let text = super::tool_result::shell_step(&output)
                        .map_or(output, |step: super::tool_result::ShellStep| step.text);
                    progress.command_outputs.push(text);
                }
                _ => {}
            }
        }
        if resume {
            let observation = super::progress::Progress::scan(messages);
            // A contradictory callback invalidates every owner from its shared receipt.
            // Completed writes retain their own exact mutation evidence below.
            let pending = files.get(progress.files_written).map(|(path, _)| *path);
            for path in progress.source_checked.clone() {
                if super::recipe_resume::recipe_source_preimage(
                    &observation,
                    &path,
                    &supporting_paths,
                )
                .is_some()
                {
                    continue;
                }
                progress.source_checked.remove(&path);
                progress.source_preimages.remove(&path);
                if pending == Some(path.as_str()) {
                    progress.source_invalidated = true;
                }
            }
            for (index, (path, source)) in files.iter().take(progress.files_written).enumerate() {
                if !recipe_file_matches(&observation, path, source, &supporting_paths) {
                    progress.files_written = index;
                    progress.source_checked.remove(*path);
                    progress.source_invalidated = true;
                    break;
                }
            }
        }
        progress
    }
}

/// Values a labelled field carries when the harness means "there was none".
const ABSENT_FIELD_VALUES: [&str; 8] = [
    "",
    "-",
    "none",
    "(none)",
    "empty",
    "(empty)",
    "no output",
    "(no output)",
];

/// The exit code the harness stated for the process, when it stated one.
///
/// Every harness in use reports it in a fixed `Exit Code: <n>` field, so this
/// is a read rather than an inference.
fn reported_exit_code(output: &str) -> Option<i32> {
    super::tool_result::reported_exit_code(output).and_then(|value| i32::try_from(value).ok())
}

impl StepFailure {
    /// Judge one tool result.
    ///
    /// The exit code the harness reported is the primary signal (issue #908):
    /// `0` is a success even when the command printed nothing and the envelope
    /// spells out an empty `Error:` field, and a non-zero code is a failure even
    /// when the command printed output that reads like a result (#905). Prose
    /// markers decide only when the harness reported no exit code at all, and
    /// silence is never a failure by itself.
    fn from_result(reported: String, from_run: bool) -> Option<Self> {
        if let Some(exit_code) = reported_exit_code(&reported) {
            return (exit_code != 0).then_some(Self {
                reported,
                exit_code: Some(exit_code),
                from_run,
            });
        }
        // The Agent CLI's shell tool hands the model only the process text and
        // keeps the status in metadata it never sends, so `/bin/sh: 1: scala:
        // not found` arrived with no code at all and was counted as a success
        // -- "Created and verified", with the failure quoted underneath (issue
        // #1133). The seed's failure lexicon already judges such text for the
        // narration path; a verification command's text is judged the same way.
        // Nested JSON event fields are data, not the surrounding process's own prose.
        let prose = reported
            .lines()
            .filter(|line| serde_json::from_str::<serde_json::Value>(line).is_err())
            .collect::<Vec<_>>()
            .join("\n");
        if super::tool_result::failure_message(&reported, false, false).is_some()
            || super::tool_result::failure_message(&prose, false, from_run).is_some()
        {
            return Some(Self {
                exit_code: super::tool_result::reported_exit_code(&reported)
                    .and_then(|code| i32::try_from(code).ok()),
                reported,
                from_run,
            });
        }
        reports_failure_in_prose(&prose).then_some(Self {
            reported,
            exit_code: None,
            from_run,
        })
    }
}

/// Fallback verdict for a harness that reported no exit code at all.
fn reports_failure_in_prose(output: &str) -> bool {
    let normalized = output.to_ascii_lowercase();
    if [
        "command timed out",
        "command terminated without an exit status",
        "permission denied",
        "no such file or directory",
    ]
    .iter()
    .any(|marker| normalized.contains(marker))
    {
        return true;
    }
    // `Error:` and `Failed:` head a field whose *contents* decide the verdict:
    // harnesses print the label unconditionally and fill it with a placeholder
    // when nothing went wrong (issue #908).
    normalized.lines().any(|line| {
        ["error:", "failed:"].iter().any(|marker| {
            line.split_once(marker)
                .is_some_and(|(_, rest)| !ABSENT_FIELD_VALUES.contains(&rest.trim()))
        })
    })
}

/// The `command` argument of the shell call a result answers.
fn run_command_of(messages: &[ChatMessage], call_id: Option<&str>) -> Option<String> {
    let call_id = call_id?;
    let call = messages
        .iter()
        .flat_map(|message| &message.tool_calls)
        .find(|call| call.id == call_id)?;
    super::tool_result::command_argument(&call.function.arguments)
}

/// The recipe saved as the file the request names (`… in add.py`), and --
/// when the request runs the function with stated arguments (`run it with 2
/// and 3`) -- ending with the call that prints its result (PR #1188
/// dogfooding). A recipe with supporting files already binds its own path.
fn requested_recipe(request: &str, recipe: &ExecutionRecipe) -> ExecutionRecipe {
    let mut next = recipe.clone();
    let extension = std::path::Path::new(&recipe.path)
        .extension()
        .and_then(|value| value.to_str());
    if let Some(target) =
        extension.and_then(|extension| super::write_request::typed_write_target(request, extension))
        && target != recipe.path
        && recipe.supporting_files.is_empty()
    {
        next.commands = recipe
            .commands
            .iter()
            .map(|command| command.replace(&recipe.path, &target))
            .collect();
        next.path = target;
    }
    if let Some(call) = crate::coding::program_contract::function_call_command(
        &next.language,
        &next.path,
        &next.source,
        &stated_call_arguments(request),
    ) && !next.commands.contains(&call)
    {
        next.commands.push(call);
    }
    next
}

/// The numbers and quoted literals after the request's last seeded run verb,
/// in order; a quoted literal becomes a JSON string literal.
fn stated_call_arguments(request: &str) -> Vec<String> {
    let verbs = crate::seed::terminal_command_vocabulary().run_verbs;
    let tokens = super::write_request::tokens(request);
    let Some(start) = tokens.iter().rposition(|token| {
        verbs.contains(&super::shell_command_policy::normalize_command_word(
            token.text,
        ))
    }) else {
        return Vec::new();
    };
    let from = tokens[start].end;
    let quoted: Vec<_> = crate::normal_markov::quoted_segment_spans(request)
        .into_iter()
        .filter(|segment| segment.start >= from)
        .collect();
    let mut found: Vec<(usize, String)> = Vec::new();
    for token in &tokens[start + 1..] {
        if quoted
            .iter()
            .any(|segment| token.start >= segment.start && token.end <= segment.end)
        {
            continue;
        }
        let value = token.text.trim_end_matches([',', '.', ';', ':', '!', '?']);
        if is_decimal(value) {
            found.push((token.start, value.to_owned()));
        }
    }
    for segment in quoted {
        found.push((
            segment.start,
            serde_json::Value::String(segment.text).to_string(),
        ));
    }
    found.sort_by_key(|(at, _)| *at);
    found.into_iter().map(|(_, value)| value).collect()
}

/// An optional minus sign, digits, and an optional fraction of digits.
fn is_decimal(value: &str) -> bool {
    let digits = value.strip_prefix('-').unwrap_or(value);
    let (whole, fraction) = digits
        .split_once('.')
        .map_or((digits, None), |(whole, fraction)| (whole, Some(fraction)));
    let all_digits =
        |part: &str| !part.is_empty() && part.bytes().all(|byte| byte.is_ascii_digit());
    all_digits(whole) && fraction.is_none_or(all_digits)
}
