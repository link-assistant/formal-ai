//! The workflow a work item asks for beside the program (issue #1133).
//!
//! Every Hello World issue Hive Mind dispatches ends with the same requirement:
//! a GitHub Actions workflow that runs the program on every push and pull
//! request. The program's execution recipe already knows the commands that
//! verify it, so the workflow is those commands, nothing more -- the same
//! sequence the harness ran, in CI. It rides along as a supporting file of the
//! recipe, so it is written, committed and pushed with the program.

use crate::engine::{ExecutionRecipe, ExecutionRecipeFile};
use crate::intent_formalization::{ObligationKind, request_demands};

/// Where the workflow is written.
#[allow(clippy::literal_string_with_formatting_args, dead_code)] // not yet read by the work-item steps
pub(super) fn workflow_path() -> String {
    super::work_item_steps::fill("workflow_path", &[])
}

/// Whether the work item asks for a CI workflow, in any seeded language.
///
/// Read from the formalized request (issue #1166 R1166-3): a clause of the
/// obligation graph demands the workflow, so a role word that only appears
/// inside a quoted literal is data the request carries, not a demand.
pub(super) fn requested_in(objective: &str) -> bool {
    request_demands(objective, ObligationKind::CiWorkflow)
}

/// Add the workflow to `recipe` as a supporting file, once.
#[allow(clippy::literal_string_with_formatting_args)]
pub(super) fn attach(recipe: &mut ExecutionRecipe, objective: &str) {
    attach_using(recipe, objective, render);
}

/// Attach with the caller's one generation snapshot, including its provenance.
pub(super) fn attach_with<'a>(
    recipe: &mut ExecutionRecipe,
    objective: &str,
    versions: impl FnOnce() -> &'a crate::version_resolution::VersionSet,
) {
    attach_using(recipe, objective, |recipe| render_with(recipe, versions()));
}

#[allow(clippy::literal_string_with_formatting_args)]
fn attach_using(
    recipe: &mut ExecutionRecipe,
    objective: &str,
    render_workflow: impl FnOnce(&ExecutionRecipe) -> String,
) {
    let name: String = std::path::Path::new(&recipe.path)
        .file_stem()
        .and_then(|value| value.to_str())
        .unwrap_or("run")
        .chars()
        .map(|value| {
            if value.is_ascii_alphanumeric() || value == '-' || value == '_' {
                value
            } else {
                '-'
            }
        })
        .collect();
    let binding = super::git_commit::request_target_binding(
        objective,
        "workflow-binding-patterns",
        super::git_commit::valid_workflow_target,
    );
    let path = match binding {
        super::git_commit::RequestTargetBinding::Bound(value) => value,
        super::git_commit::RequestTargetBinding::Absent => suggested_workflow_path(objective)
            .unwrap_or_else(|| {
                super::work_item_steps::fill("workflow_path_named", &[("{name}", &name)])
            }),
        super::git_commit::RequestTargetBinding::Refused => {
            recipe.commands.insert(
                0,
                super::work_item_steps::fill("target_binding_refused_command", &[]),
            );
            return;
        }
    };
    if recipe.supporting_files.iter().any(|file| file.path == path) {
        return;
    }
    let source = render_workflow(recipe);
    recipe
        .supporting_files
        .push(ExecutionRecipeFile { path, source });
}

/// The file name the request suggests for its workflow ("a meaningful name
/// like `test-hello-world.yml`"), placed in the workflow directory (issue
/// #1162). A suggestion is not a directive, so an invalid or ambiguous one
/// falls back to the program-stem default.
pub(super) fn suggested_workflow_path(objective: &str) -> Option<String> {
    match super::git_commit::request_target_binding(
        objective,
        "workflow-name-binding-patterns",
        super::git_commit::valid_workflow_file_name,
    ) {
        super::git_commit::RequestTargetBinding::Bound(file) => Some(super::work_item_steps::fill(
            "workflow-path-file",
            &[("{file}", &file)],
        )),
        _ => None,
    }
}

/// The workflow text over the generation-time version set.
///
/// Every third-party pin the workflow carries -- the `uses:` refs and the
/// toolchain versions -- is resolved at generation time rather than shipped
/// from the template, and wherever a pin came from something other than a
/// live lookup, the workflow says so in a comment (issue #1168).
pub(super) fn render(recipe: &ExecutionRecipe) -> String {
    render_with(
        recipe,
        &crate::version_resolution::VersionSet::for_generation(),
    )
}

/// The workflow text: checkout, then the recipe's commands in order.
///
/// Every pin is filled from the injected `versions`, so a parity lane renders
/// the same workflow in both runtimes from one offline version set (issue
/// #1168 R1168-8); `render` injects the generation-time set.
#[must_use]
#[allow(clippy::literal_string_with_formatting_args)]
pub fn render_with(
    recipe: &ExecutionRecipe,
    versions: &crate::version_resolution::VersionSet,
) -> String {
    let template = super::work_item_steps::fill("workflow_template", &[("{path}", &recipe.path)]);
    let setup = crate::coding::program_contract::runtime_step_template(&recipe.language);
    let placed = format!("{template}{}", setup.as_deref().unwrap_or_default());
    let mut out = String::new();
    for note in versions.provenance_note_for(&placed) {
        out.push_str("# ");
        out.push_str(&note);
        out.push('\n');
    }
    out.push_str(&template);
    // Filling versions trims the fragment's final newline; each fragment is a
    // whole line block, so it is restored before the next one is appended.
    out = crate::version_resolution::fill_workflow_versions(&out, versions);
    out.push('\n');
    if let Some(setup) = setup {
        out.push_str(&crate::version_resolution::fill_workflow_versions(
            &setup, versions,
        ));
        out.push('\n');
    }
    for command in &recipe.commands {
        out.push_str(&super::work_item_steps::fill(
            "workflow_command_step",
            &[("{command}", command)],
        ));
    }
    out
}
