from pathlib import Path
import subprocess, json, datetime

scratch=Path('/tmp/issue-1580-research')
out=scratch/'next-batch-validation'
result=json.loads((out/'result.json').read_text())
failures=[row['name'] for row in result['checks'] if row['status']]
assert failures==['all-local-gates'], failures
lines=(out/'all-local-gates.log').read_text().splitlines()
failed=[line for line in lines if line.startswith('FAIL ')]
assert len(failed)==2 and {line.split()[1] for line in failed}=={'check-abbreviations','check-worker-crate-modules'}, failed
old=Path('rust/tests/web/write-str-boundaries.test.mjs')
new=old.with_name('write-string-boundaries.test.mjs')
assert old.exists() and not new.exists()
old.rename(new)
(out/'naming-repair.json').write_text(json.dumps({'before':str(old),'after':str(new),'reason':'Use full English words without increasing the abbreviation ratchet.','beforeGateFailures':failed,'substantiveTestBytesChanged':False,'autonomousAuthorshipCredit':0},indent=2)+'\n')

# Preserve the initial complete gate replay; run only checks affected by this
# filename and maintained browser projection repairs. No duration data changes.
checks=[]
for name,command in [
 ('boundaries-renamed',['node','--test','--test-concurrency=1',str(new)]),
 ('abbreviations-renamed',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations']),
 ('worker-projection-write',['node','scripts/generate-worker-crate-modules.mjs','--write']),
 ('worker-projection-check',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-worker-crate-modules']),
 ('translation-currency-final',['node','scripts/translate-js-rust.mjs','--verify']),
 ('whitespace-final',['git','diff','--check'])]:
 with (out/(name+'.log')).open('w') as log:
  r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 checks.append({'name':name,'status':r.returncode,'command':command})
 assert r.returncode==0,(name,r.returncode)
(out/'naming-repair-result.json').write_text(json.dumps({'checks':checks,'allPassed':True,'originalFullReplayPassCount':sum(line.startswith('PASS ') for line in lines),'originalFullReplaySkipCount':sum(line.startswith('SKIP ') for line in lines),'originalFullReplayFailures':failed,'allApplicableGatesPassAcrossOriginalAndFocusedRepair':True},indent=2)+'\n')

timing=scratch/'bbc-layered-costs/report.json'
before=timing.read_bytes()
(timing.parent/'report-initial-missing-wall-metadata.json').write_bytes(before)
report=json.loads(before)
jobs=json.loads((scratch/'bbc-current-jobs/45006097030.json').read_text())['jobs']
def instant(value): return datetime.datetime.fromisoformat(value.replace('Z','+00:00'))
for row in report['jobs']:
 job=next(job for job in jobs if job['name']==row['job'])
 step=next(step for step in job['steps'] if step['name']=='Run this shard of the JavaScript suites')
 row['wallSeconds']=(instant(step['completedAt'])-instant(step['startedAt'])).total_seconds()
 row['overheadSeconds']=row['wallSeconds']-row['modeledSeconds']
 assert row['wallSeconds']>0
report['metadataCorrection']='Use the actual gh run view camelCase startedAt/completedAt step keys. The original null-valued draft is preserved separately.'
timing.write_text(json.dumps(report,indent=2)+'\n')

for label,args in [
 ('repository-status-final',['git','status','--short']),
 ('repository-stat-final',['git','diff','--stat']),
 ('tracked-test-reference-matches',['rg','-n','refs/tags/v1\\.2\\.4|symbolic-ref.*HEAD','rust/tests/web'])]:
 with (out/(label+'.log')).open('w') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0,(label,r.returncode)
print('DRAFT_READY',json.dumps({'gatePassesBeforeNamingRepair':sum(line.startswith('PASS ') for line in lines),'checks':len(checks),'nativeExecuted':False}))
