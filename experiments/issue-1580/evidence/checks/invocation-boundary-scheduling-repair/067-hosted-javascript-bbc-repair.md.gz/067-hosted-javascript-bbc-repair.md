# Current timing replay and boundary copying

Layered CI run 45006097030 at `bbc0ac4d` passed, but its fifth JavaScript shard
took 319 seconds. The complete log retains the 270-second warning at line 5979.
The maintained parser preserves 914 unique complete file timings; the dialogue
file without its own summary remains unobserved. The previous plan models a
296.99-second shard before runner overhead. The new replay fails on those weights.

The bounded reserve comparison preserves every earlier floor and the exact
receipt-bound observation. A 50% draft passes the current measured replay but
fails the existing conservative 360-second queue control. A 30% draft meets the
duration limits but fails an existing provenance separation control. A 35%
reserve passes all eight historical/current scheduling cases and all 27 CI-speed
controls. The fixed warning remains 270 seconds, the hard limit 360 seconds and
the runner allowance 30 seconds. The largest current measured replay remains
239.32 seconds; this is a scheduling model, not execution of the repaired head.

A separate local protocol replay first exceeded its unchanged 120-second limit
for Agent after Claude and Codex passed. A focused 96-second CPU profile, sampled
every 10 milliseconds, attributes 47.68% of samples to `trimEndMatches`. Both
boundary helpers materialize and join the complete body even when only one
boundary character needs inspection. Repeated calls during planning multiply
that copying. The repair scans matching Unicode code points at the boundary and
returns a slice, preserving predicate order, surrogate pairs, unmatched text and
Rust whitespace semantics. Rust already uses its standard string primitives.

The small bounded-work regression fails before the change after enumerating
10,242 body characters and passes afterward. A separate semantic test compares
the previous character-array behavior, including empty text and unpaired UTF-16
surrogates. The initial timeout, profiles and unsuccessful scheduling drafts
remain evidence. Full protocol replay, shared-data gates and new hosted
execution are recorded separately as they finish; none is implied by a model.
Supplied scripts receive zero autonomous-authorship credit. Wider issue #1580
acceptance remains unfinished in [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581).
