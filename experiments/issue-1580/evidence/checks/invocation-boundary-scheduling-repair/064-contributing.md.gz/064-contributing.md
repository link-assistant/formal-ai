# Contributing to formal-ai

## Development through Formal AI

Follow [VISION.md](VISION.md): perform all development task actions through JavaScript Formal AI, including exploration, shell commands, tests and verification as well as edits. Give small natural-language tasks, let it execute actual tools, add focused regressions for observed failures, repair reusable causes and retry unchanged tasks before increasing difficulty.
Retain requests, runtime and source identities, tool calls, failures, diffs and independent checks.
Supplied patches, scripts, generators and literal replacements earn zero autonomous-authorship credit. Target at least 5% independently accepted Formal AI reasoning units per development batch: decompose tasks, compare strategies, research trusted public sources and fact-check against fresh evidence. Freeze the substantive unit list before outcomes; report attempted and accepted shares separately, retain failures and count supplied conclusions as zero. Retain complete responses and route traces for scored reasoning attempts. An ambiguity control passes only when the answer identifies what is unresolved or gives a justified conditional answer; an unrelated numeric result is a failure even when it avoids the target verdict. This reporting target does not add a release gate; see the reasoning contract in docs/requirements/doctrine-standing-doctrine-work-delegated-to-formal-ai-2026-10-07.md.
Report unsupported work and terminal effects honestly; record externally authored bootstraps separately.
Preserve readable CST, comments and unrelated content; verify JavaScript, TypeScript and Rust parity. Before pushing requirement changes, run the maintained JavaScript assembly, ledger-generation/schema and status-renderer checks: `node scripts/assemble-requirements.mjs`, `node scripts/generate-requirement-status.mjs`, `node scripts/check-requirement-status.mjs`, `node scripts/render-status.mjs --check`, and `node scripts/render-progressive-plan.mjs --check`. Every `.github/workflows/release.yml` change, including non-staged jobs such as Fast Linux, requires `node scripts/generate-staged-release.mjs --check-deployed`; if stale, perform a source-grounded canonical workflow/packet refresh and regenerate projections with the maintained JavaScript generator. Never hand-edit derived outputs or relax assertions. After changing covered crate modules, run the cheap source/projection currency check `node scripts/translate-js-rust.mjs --verify`; run upstream parser/WASM regeneration in hosted CI, with no local Rust execution.
Use at most three subagents plus the coordinator; batch verified changes, bound retries and prioritize release delivery.
Run only necessary JavaScript checks locally, sequentially; Rust compilation and tests run exclusively in CI. For HTTP client trials, pin `FORMAL_AI_SOURCE_USAGE_RUST_GRAMMAR=false` in the private server environment; direct host installation alone does not register the HTTP initializer policy.

The [default-branch build policy](docs/ci-cd/default-branch-builds.md) governs
CI changes: no application, Cargo or Docker builds or deployments on PRs, even
through branch dispatch or legacy full-PR controls. Run necessary local JS tests
one at a time; do not build or test Rust locally.


For documentation-only changes, heavy push/PR workflows and automatic releases
are filtered by `scripts/documentation-only-ci-policy.mjs`. Run its `--write` mode after
adding a heavy workflow, then its targeted JavaScript regression. The policy
preserves comments, retained job bodies and explicit manual controls. Root
Markdown, `docs/**`, nested README/CHANGELOG files and changelog fragments are
documentation; other Markdown may be runtime input. Mixed changes run normal CI.
See [issue #1455 requirements](docs/requirements/issue-1455-documentation-and-evidence.md).

Before merging during production delivery, follow the
[release handoff guide](docs/ci-cd/release-handoff.md). Version preparation is not
publication: freshness is checked again after compilation and before later
release effects. Keep main stable through the active release and verify its
consumers before merging routine changes. Draft fixes while CI runs; do not
weaken a freshness check or rerun a superseded producer to force publication.

Live issue drafting selects current Formal AI and Hive Mind sources once per
attempt, reuses those exact commits across jobs, and records their runtime
identities. Never silently fall back to an older runtime. Maintained Hive Mind
CLI checks use its latest published package. Historical replay pins remain
historical evidence, not proof of current-version behavior.

Thank you for your interest in contributing! This document provides guidelines and instructions for contributing to this project.

**Read [VISION.md](VISION.md) first**, and the architect's notes it is kept up to date from, in [docs/architect-notes/](docs/architect-notes/). It is the standing guideline, in the architect's
own words: the goal is the meta algorithm; code is held in the meta language and Rust is one emission
target of it; self-modification is an action the user approves; algorithms are arrived at by
deduplication; and no task is rated hard -- split it until each leaf is directly solvable. Where any
other document, gate or requirement contradicts that page, the other one is wrong and must be fixed.

## How we develop Formal AI: drive the Agent CLI, never defer

**Bound retries (issue #1328).** Every retry loop needs a finite attempt ceiling; external IO also needs a finite deadline or cancellation boundary. Count repeated client-owned calls from the transcript, preserving namespace identity and complete failure metadata, even when results are missing or unrecognized. Invalid arguments and local refspec/permission errors require a strategy change or an honest terminal report. Preserve existing safety controls and add a regression that reaches the limit. See [the retry requirement and audit](docs/requirements/issue-1328-bounded-retries.md).

**Method: progressive JPEG (R1188-U28 to R1188-U30).** Every problem and every pull request is attacked the way a progressive JPEG loads: first the whole at low resolution, then sharper passes over all of it, the lowest level first. JavaScript goes first, and the other roots follow by automated translation, with recorded temporary workarounds where the meta language cannot translate yet. See [`docs/progressive-delivery.md`](docs/progressive-delivery.md); [`docs/progressive-plan.md`](docs/progressive-plan.md) is the generated next pass.

**From issue #538 forward, this is the only way we develop the Formal AI
system.** We do not solve a task by editing code and data by hand and we do not
solve it partway and defer the rest to a roadmap. We solve it by **driving Formal
AI through its own [Agent CLI](https://github.com/link-assistant/agent)** (the
in-repo agentic driver in `rust/src/agentic_coding/`, running against the
OpenAI-compatible `formal-ai serve` server), and we get *every* requirement done
in the same pull request.

This section is the development policy and target workflow, not a claim that
the repository is already autonomously self-coded. When an existing tool gap
forces a manual tool extension, record that boundary plainly, retry a smallest
leaf through Formal AI, and measure only genuinely session-authored lines. A
reviewed task decomposition must name its smallest leaves; the acceptance floor
is at least one real Formal-AI/Agent-CLI-authored leaf out of every five (20%),
with a captured session and paired commit trailers. Raise that measured share
over time; never relabel manual work as self-authored.

Concretely, every change must follow these rules:

1. **The tool authors the change, not you.** Drive the Agent CLI + Formal AI to
   produce the change. Where the output lands in the repo (e.g. seed data), a
   test must assert that the committed artifact is **byte-for-byte** what the
   Agent-CLI-driven recipe produces, so the tool — not a hand-edit — is the
   author and cannot silently regress. See the issue #538 case study
   ([`docs/case-studies/issue-538/`](docs/case-studies/issue-538/)) for the
   pattern and the committed `agent-cli-session*.json` sessions.
2. **No pre-emptive deferral, no refusals, no follow-ups.** "This is large or
   hard" is never a reason to ship a slice and route the rest to a roadmap. Find
   the smallest real, tested, reproducible slice of *each* requirement and
   execute it now, in this PR. Read
   [`docs/case-studies/issue-538/refusal-anti-pattern.md`](docs/case-studies/issue-538/refusal-anti-pattern.md)
   before opening a PR — it is the failed reasoning we do not repeat, and we do
   not teach Formal AI to refuse or defer like that.
3. **When the tool can't do it, extend the tool, then retry.** Falling back to a
   manual edit is allowed only after you have proven the Agent CLI / Formal AI
   cannot yet do it — and then you must immediately improve the Agent CLI /
   Formal AI so it *can* in general, and re-run through the tool.
4. **Prove generality with different words each time.** Use a *different* natural
   language request for each case so a passing run proves the solution is truly
   general, not hardcoded to one phrasing (issue #538 drives tomato and potato
   with two differently-worded requests).
5. **Report faithfully.** State what is done and verified plainly. Honesty means
   reporting results accurately; it is never a license to stop early or to dress
   a refusal as an "honest scope" section.
6. **Real Agent-CLI E2E tests in CI, plus a per-requirement test and a
   whole-task test.** Every change that touches the agentic path must add (or
   update) a real end-to-end test that boots `formal-ai serve` and drives it
   with the actual `@link-assistant/agent` CLI over the OpenAI-compatible
   endpoint — no mocks or in-process shortcuts. Keep the round-trip green in CI
   (see `test-agent-cli-e2e` in `.github/workflows/release.yml` and the driver
   script `experiments/agent_cli_e2e/run_agent_cli.sh`). In addition, ship one
   unit/integration test **per requirement in the issue** and one test that
   exercises the **whole task** end-to-end so a regression on any single
   requirement — or on the composition of all of them — breaks the build.
7. **Hardcoded cases only in tests; production code stays general.** A test may
   hardcode inputs and expected outputs (that is what a test is *for*), but the
   engine, planner, seed loader, and Agent-CLI-driven recipes never branch on a
   specific concept, phrase, or URL. If the only way to make a green case pass
   is a match-on-literal in `rust/src/`, extend the general routing table (`concept
   registry`, `capability classifier`, `plan_chat_step`) so future concepts get
   the same treatment for free.
8. **Real logs in the case study, not synthesized ones.** When a case study
   claims the Agent CLI drove the change, it must ship the real captured log of
   the round-trip (see `docs/case-studies/issue-538/agent-cli-e2e-run.log`), and
   the committed session JSON must be reproducible byte-for-byte by
   `cargo test`.
9. **Commit in small, atomic steps.** Every commit should be independently
   useful and reviewable — one logical change per commit, buildable in
   isolation. Interrupted work stays preserved in the PR because each commit
   already stands on its own; do not batch a day of unrelated edits into one
   commit.

### Work through the readable source model

Follow [the source-model doctrine](docs/requirements/doctrine-readable-recursive-source-and-comment-meta-language-2026-10-18.md) and [source-model guide](docs/source-representation.md). Use complete recursive Links Notation CSTs with actual UTF-8 text and language-neutral semantic concepts. Preserve comments, whitespace and language-specific syntax. Formalize comment meanings and independently naturalize English documentation; retained text alone is not understanding. Describe parse, emit, synchronization and transformation rules in the meta language, with explicit ambiguity and refusal. Extend the shared meta language where required.

Validate persisted source-free reconstruction, independent reparsing and semantic checks, meaningful held-out edits, exact inverses and cross-language behavior. Remove count-only self-AST fixture maintenance; source content and rules are authoritative. Old signature/histogram tests are historical partial controls and must migrate with their consumers. Prefer the useful invariants researched in meta-language PR #201 and Router PR #761; their numeric serializers and flat token stores are not substitutes for this contract. Keep Rust compilation in CI, source generation bounded, and changes through the authorized Formal AI development loop.

### Verify code, requirements and multilingual documentation together

Use our source and documentation as the core formalization/naturalization corpus. Bind formalized comment/document claims to actual code contracts and evidence, and evaluate them through dependency-aware relative meta logic. Preserve conditional assumptions and shared premises; dependent observations do not become independent support by being counted twice. The same model must support local code/docs and trusted public sources, with explicit unavailable, stale and conflicting evidence.

Formal AI produces English, Russian, Hindi and Chinese documentation through shared meanings. Select wording jointly for measured round-trip meaning survival across every ordered pair, for parts and whole documents; preserve unknown terms, scope, quantifiers, polarity and the original evaluation denominator. CI checks code/doc consistency and formalized requirement delivery. A requirement conflict follows the latest authoritative instruction for that scope, with history retained; a new unrelated instruction does not erase an earlier obligation. Update documentation to match verified requirement-conforming code, and repair code that violates the current requirement. Regenerate and reverify every affected source/document projection after a contradiction-driven edit.

### Testing external agentic CLIs

When validating `codex`, `opencode`, `gemini`, or the `agent` CLI against a
local Formal AI server, follow
[`docs/testing/agentic-cli-tools.md`](docs/testing/agentic-cli-tools.md). The
guide defines the fixture markers, logging proxy assertions, phrasing matrices,
and CI shape needed to prove that a result came from Formal AI and that the
client actually executed the expected tools.

### Spawn a reference assistant when you need a natural-language target

When a change is about *how Formal AI talks* to the user — narration before a
tool runs, an error explanation, the wording of a question — it helps to see how
a strong conversational assistant would phrase the same step. Spinning up a free
model in `claude`, `codex`, or `opencode` on the *identical* prompt and reading
its reply gives a concrete, natural target to match, and is a recommended way to
calibrate tone before writing the seed catalog text and its tests. Treat those
transcripts as reference examples only: the phrasing you ship still lives in the
`.lino` seed data (never hardcoded in the solver), and every user-visible string
must be asserted by a test. Issue #819's narration rewrite was tuned this way —
the desirable "Let me look on your Desktop for …" shape came from comparing
Formal AI's output against `claude` and `codex` on the reported request.

### Replaying the self-coding loop

```bash
cargo build --manifest-path rust/Cargo.toml --release --bin formal-ai
rust/examples/self-coding/run.sh
cargo test --manifest-path rust/Cargo.toml self_coding_session_replays
```

For a real GitHub issue, run `rust/examples/self-coding/run.sh --live ISSUE_URL`,
which invokes the command below — Hive Mind drives the Agent CLI, which drives
the local Formal AI server:

```bash
solve ISSUE_URL --tool agent --model formal-ai --attach-logs --verbose
```

### Formal AI as a subagent on its own requirements (R1026)

Keep what you produce while working on Formal AI in the repository, not in a
private scratchpad, whenever it is worth keeping: probe tools, the gaps found
by probing, task prompts, claims and sandboxes. Formal AI can then read, edit
and run it like any other workspace file. The shared folder is
`experiments/formal_ai_subagent/`, and its `README.md` describes the loop:

1. Delegate a small edit with
   `node experiments/js_dogfood/drive.mjs --dir <sandbox-or-repo-root> "<instruction>"`.
2. When it fails, probe the cause with `experiments/formal_ai_subagent/probe.mjs`.
3. Fix the cause generally in both roots, add a regression test, and have
   Formal AI record the result in the dogfood ledger.

Formal AI keeps its own gap list (`gaps.md`) there too.

### Delegate the next commit to Formal AI: task issue, bot branch, review, merge

The replay above runs the loop by hand on one machine. The loop we actually
develop by is the same one driven from GitHub Actions, so that no local
resources are spent and every step leaves reviewable evidence. Each commit we
would otherwise write by hand becomes a task Formal AI performs for us, and the
share of hand-written commits falls over time.

The target chain is our own products end to end: **GitHub Actions -> Hive Mind
-> Agent CLI -> Formal AI**. The action compiles Formal AI from the sources on
the branch under review and takes everything else from packages or containers,
so a run always exercises the meta algorithm as it exists on that branch, spends
no local resources, and can be adjusted by an ordinary reviewed change to the
branch.

Today `.github/workflows/self-authored-pull-request.yml` runs
**Actions -> Agent CLI -> Formal AI**: it drives the pinned
`@link-assistant/agent` against a locally built `formal-ai serve` directly,
because `solve --model formal-ai` used to commit none of the trailers or the
evidence bundle the self-hosting metric attributes
([hive-mind#2229](https://github.com/link-assistant/hive-mind/issues/2229)).
Hive Mind fixed that in
[hive-mind#2230](https://github.com/link-assistant/hive-mind/pull/2230),
released in v2.24.0; this repository still pins 2.15.1 in
`.github/workflows/agent-cli-e2e.yml`. Moving the authoring step onto
`solve … --tool agent --model formal-ai --attach-logs --verbose` behind the
updated pin is the remaining step, and it belongs in this loop like any other:
raise the pin, run one task through it, and compare the commit it produces with
what the direct path produces.

The steps, in order:

1. **Write the task as an issue.** Small and self-contained: one behaviour, one
   file where possible. Label it `formal-ai-solve` and give it the contract
   `.github/workflows/self-authored-pull-request.yml` reads, which is documented
   in that workflow's header (`task:`, `seed:`, `produces:`, `into:`,
   `contains:`, `message:`). Make it a sub-issue of the pull request's issue so
   the delegation is visible from the work it belongs to.
2. **Let the action author it.** Labelling the issue starts the run. It opens a
   draft pull request under `github-actions[bot]` first, so the authored commit
   can name it in its `Formal-AI-Pull-Request` trailer, and it targets the
   branch the run checked out — the pull request we are working in, not `main`.
   Then it drives the pinned Agent CLI against a locally built `formal-ai
   serve` and pushes one commit carrying the four trailers and its evidence
   bundle. No human commit goes on that branch; a human commit there is the one
   thing that invalidates the claim.
3. **Judge the quality on that branch, not in the abstract.** The bot pull
   request runs the full CI of the repository. Read the diff and the session
   evidence: did Formal AI make the change asked for, or answer around it? Did
   it stop after the first clause of a two-part task? Did it route the request
   somewhere unrelated? The branch is disposable, so this is a cheap experiment.
4. **If the quality is poor, fix the meta algorithm, not the commit.** Do not
   hand-correct the bot's work and merge it. Close the branch, record what the
   session actually did as evidence, file the defect, and improve and generalise
   Formal AI so the same class of task succeeds — then run the task again. The
   defects found this way are the point of the exercise, not a detour:
   [#1095](https://github.com/link-assistant/formal-ai/issues/1095),
   [#1096](https://github.com/link-assistant/formal-ai/issues/1096),
   [#1099](https://github.com/link-assistant/formal-ai/issues/1099) and
   [#1101](https://github.com/link-assistant/formal-ai/issues/1101) were all
   found by running tasks this way and reading what came back.
5. **When satisfied, merge the bot pull request into the working pull request.**
   Its commits arrive with their trailers intact, so the self-hosting metric
   attributes them, and the work reaches `main` through the ordinary review of
   the pull request they merged into.

A draft is finished in one of exactly two ways: **merged**, or **closed with the
defect it exposed filed** against the meta algorithm. Leaving it open is
neither, and it is the failure mode this loop falls into by default — seven bot
pull requests were opened on 2026-09-08 and none was merged. The
`Self-authored backlog` workflow reports every open one daily with its age, its
check state and how far its base has moved, and fails once one has been open
more than three days. Merging the green ones is what turns the loop into
commits Formal AI wrote; reading the red ones is what improves it.

Two rules keep the loop honest. Process record is not authored behaviour: the
changelog fragment a source change needs is written by the bootstrap commit that
opens the bot pull request, because `changelog.d/` is one of the trees the
metric excludes from both sides of the share. And the base a run authors against
must be current — a bot branch cut before a fix on the working branch fails for
that fix's absence, so rerun the task rather than pushing the fix onto the bot
branch.

[#1103](https://github.com/link-assistant/formal-ai/pull/1103) is the worked
example: two commits, both by `github-actions[bot]`, one of them Formal AI's own
change to the self-hosting metric with its session evidence beside it.

#### The action is installable in other repositories

The loop is worth as much to our other repositories as to this one, and it is
worth most where the volume of new issues is highest. The target is that any
repository can install one action and have Formal AI open a draft attempt at
every new issue — Hive Mind first, whose issues are the ones we read most often.
A draft that is wrong is not waste: it fails in public, on a branch nobody
depends on, and the failure is the input the next improvement is made from. Fail
fast to learn fast.

The loop therefore lives in `.github/actions/author-with-formal-ai`, a composite
action, and this repository's `self-authored-pull-request.yml` is its first
consumer rather than a separate implementation. Three inputs are what make it
installable elsewhere:

- **`formal-ai-source`** — `container` by default, pulling the binary out of
  `ghcr.io/link-assistant/formal-ai`, so a consuming repository spends no
  compile. This repository passes `source`, because a change to the meta
  algorithm has to be measured by the branch making it, not by the last release.
- **`require-contract`** — `true` demands the `task:`/`seed:`/`produces:`/
  `into:`/`message:` lines. `false` derives the task from the issue title and
  body, which is what a repository attempting *every new issue* wants: a draft
  that fails is the evidence it asked for, not an error.
- **`formal-ai-ref`** — where the shared scripts come from. They are fetched
  from this repository rather than vendored into the action, so there is one
  copy of each to fix; the repository that owns them runs its own branch's
  copies, so a change to them is testable in the pull request making it.

Every script the action runs is staged into `RUNNER_TEMP` before anything
switches branches. That is not tidiness: run 34224940281 failed on a bug its own
head had already fixed, because after `git checkout` of the bot branch the
script it ran came off that branch. The CI contract tests read
`.github/actions/**` as well as `.github/workflows/**` for the same reason — the
shell CI executes is the same shell whichever directory it sits in.

[hive-mind#2233](https://github.com/link-assistant/hive-mind/issues/2233) asks
for the first outside installation, on `issues: opened`, so every new issue
there gets a draft attempt. The drafts it opens are read the same way as here:
judge the quality on the branch, and when it is poor, improve the meta
algorithm.

#### A branch pays for what it changed

Use [the current CI policy](docs/ci-cd/default-branch-builds.md): link parser regressions run by default and full live-link audits remain main-only opt-ins. A historical push to a feature branch
cost about 310 job-minutes across 16 workflows, and a day of iterating on one
branch cost roughly 4,600 — a budget every self-authored draft competes for.
Two rules keep that down, and both are measured in
[#1107](https://github.com/link-assistant/formal-ai/issues/1107):

- **Build the binary once per source change, not once per workflow.** Seven
  workflows compiled the same `formal-ai` release binary on every push, two to
  five minutes each. `.github/actions/formal-ai-binary` keys a cache by the
  content of `src`, `Cargo.toml`, `Cargo.lock` and `build.rs`, so a push that
  changed none of them reuses the build and installs no toolchain at all. Use
  it from any workflow that only needs to *run* the binary.
- **Gate the heavy jobs on the files they execute.** `detect-changes` publishes
  `pipeline-changed` beside `workflow-changed`: the former is true only for the
  pipeline's own definition, a composite action it calls, or a script those run.
  The macOS archive, the Docker check, the six box images and the 25-minute
  agent end-to-end run are gated on it, so editing an unrelated workflow no
  longer buys them.

- **Do not run a check twice on identical inputs.** `detect-changes` compares
  the whole pull-request range, so a branch that once touched `rust/src/` used to
  re-run every Rust check on every later docs-only push. Eight heavy checks
  now consult `.github/actions/green-ledger`: the content of the check's
  inputs is hashed (the same key `formal-ai-binary` uses), and a marker saved
  under that hash by a previous *successful* job means the job announces
  "already green" in its log and step summary and finishes without running
  its body. The marker rides on `actions/cache`, whose post step runs only on
  success, so a failing job can never record itself green; `main` never skips.
  To force a check, edit its workflow file (always part of its inputs) or run
  it by `workflow_dispatch`. `rust/tests/unit/ci-cd/issue_1107_green_ledger.rs`
  pins the contract.

Neither rule may become a silent skip. A job that does not run on a branch is
reported as not-run, never as passed, and `main` still runs everything.

### Always run automated `solve` sessions with `--attach-logs --verbose`

Every automated session started against this repository — by hand or by a
maintainer's dispatcher — must carry both flags:

```bash
solve https://github.com/link-assistant/formal-ai/issues/905 \
  --tool agent --model formal-ai --attach-logs --verbose
```

Both are load-bearing, and neither substitutes for the other:

- **`--attach-logs`** publishes the session log to the pull request, so a
  failure leaves behind evidence rather than a single line in a comment.
- **`--verbose`** is what makes the Agent adapter dump the **raw JSON** of every
  error record and every fatal startup log record
  ([link-assistant/hive-mind#2143](https://github.com/link-assistant/hive-mind/pull/2143)).
  That raw record is what survives a future payload shape the renderer does not
  know about.

This is not a style preference; it is a precondition of the self/auto-learning
loop this repository is built around. On 2026-08-04 a run on PR #927 failed
after 22 seconds and recorded its whole reason as `[object Object]`, with no log
attached — a failure that is unlearnable by construction, because the next
iteration has nothing to act on. The container is gone and that cause is
unrecoverable. The full timeline, root causes, and raw evidence are in
[`docs/case-studies/issue-973/README.md`](docs/case-studies/issue-973/README.md).

`rust/tests/issue_973_solve_flags.rs` enforces the policy: it scans the guides and
scripts this repository publishes and fails when any `solve` invocation drops
either flag. Recorded history under `docs/case-studies/`, `dev/log/`, and
`experiments/` is exempt — a past run stays as it happened.

### Recording self-authorship

The release metric counts a commit as Formal AI-authored only when its commit
message records the first two trailers below. A contribution intended to
satisfy the per-release self-development floor must record all three:

```text
Formal-AI-Session: <session-id>
Formal-AI-Evidence: <repo-relative committed evidence path>
Formal-AI-Pull-Request: https://github.com/<owner>/<repo>/pull/<number>
```

The evidence path must exist in that commit. It may name one evidence file or a
directory bundle; one file at or below the path must contain both `formal-ai`
and the exact session id. Add one pair per session when multiple sessions
authored a commit. Do not add these trailers to a human-authored or manually
corrected commit. The pull-request reference counts toward the release floor
only when Git history proves that the same commit object reached the matching
GitHub merge commit; a direct commit carrying a claimed PR URL does not count.
A pull request counts for the work Formal AI did in it, not for what else rode
along with it: at least one commit it introduced must carry valid session
evidence, and every attributed commit it introduced must name that same pull
request. A trailer pointing at a different pull request is not evidence about
this one, and it disqualifies the pull request that introduced it. Self-authored
work therefore needs no pull request of its own -- it may ride along inside
ordinary review beside human commits, which stay unattributed and stay in the
denominator of the metric.

A trailer that turns out to be wrong cannot be corrected in place: this
repository's ruleset forbids non-fast-forward pushes on every branch with no
bypass actors, so a pushed commit message is permanent. A later commit in the
same measured range withdraws the claim instead:

```text
Formal-AI-Retract: <full 40-character sha of the commit being withdrawn>
```

The retracted commit stops being attributed, in the pull-request metric and in
the release floor alike. The trailer only ever moves a commit *out* of the
numerator, so it cannot inflate the measured share; use it to disown a
mis-trailered commit, never to claim one. It must name a full sha that is
inside the range being measured, and it may not name the commit carrying it.

The reviewed prospective policy in `data/meta/self-development-policy.lino`
sets `presence-mode` to `report` while self-hosting matures. Missing authored
work remains visible with its actual counts and `floorSatisfied=false`; it does
not block iteration or grant supplied recipes authorship credit. A reviewed diff
setting `presence-mode` to `enforce` raises the presence criterion again and
retains the existing pull-request relaxation after more than 24 hours. Invalid
claimed attribution, configuration, Git errors, and independent debt checks still
fail in either mode. This policy is separate from the numerical share target:
`target_override_basis_points` on the newest comparable self-hosting ledger row
is the existing reviewed lever for lowering that target, without changing
historical measurements. The independent strict command
`rust-script scripts/self-hosting-metric.rs --check-ratchet <base>` requires
that the candidate projected trailing share must not decrease relative to
`<base>` over the same latest-tag release range; a lower candidate returns an
error. Presence reporting does not change that numerical comparison. Actual
release recording independently uses Report and records regressions honestly.
Reproduce measured additions plus deletions from non-merge commits, excluding
binary files, with
`rust-script scripts/self-hosting-metric.rs --since <previous-tag>`.

Before checking the pull-request ratchet locally, fetch annotated release tags
with `git fetch origin --tags`; without the latest tag, the check reports a skip.

## Contribution rights and external material

By intentionally submitting a contribution to this repository, you represent
that you have the authority to submit it and offer your copyrightable
contribution under the repository's [Unlicense](LICENSE), including its
public-domain dedication and permissive fallback terms. If you do not own the
rights or cannot make that offer, do not submit the material.

Third-party material remains subject to its own license and terms. Identify the
source, exact revision, license, required notices, and any naming or use
conditions in the pull request and repository provenance record. Public access,
zero price, AI generation, or appearance in an issue does not remove those
conditions. Follow [LEGAL-COMPLIANCE.md](LEGAL-COMPLIANCE.md) and complete
[`docs/legal/source-review.md`](docs/legal/source-review.md) before using any
external material for training or distillation.

Never paste or attach any of the following to issues, pull requests,
discussions, logs, fixtures, or commits:

- leaked material or proprietary source code;
- a paid or access-controlled dataset without redistribution permission;
- a large verbatim copyrighted work or bulk model output;
- credentials, private keys, confidential information, or trade secrets; or
- real personal data.

For debugging or critique, use the smallest lawful excerpt, link to the
authorized source, record provenance, and redact unrelated content. Maintainers
may remove, redact, or quarantine suspect material and its downstream copies
while a rights, privacy, safety, or Terms-of-Service concern is investigated.
Removal from a public thread is not approval to retain another copy.

## Development Setup

1. **Fork and clone the repository**

   ```bash
   git clone https://github.com/YOUR-USERNAME/formal-ai.git
   cd formal-ai
   ```

2. **Install Rust**

   Install Rust using rustup (if not already installed):

   ```bash
   curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
   ```

3. **Install development tools**

   ```bash
   rustup component add rustfmt clippy
   cargo install rust-script
   ```

4. **Install pre-commit hooks** (optional but recommended)

   ```bash
   pip install pre-commit
   pre-commit install
   ```

5. **Build the project**

   The repository has three source roots — `rust/` (the crate), `js/` (the
   hand-iterated web surface) and `ts/` (generated from `js/`); see
   [docs/source-roots.md](docs/source-roots.md). From the repository root,
   Cargo commands address the crate through its manifest:

   ```bash
   cargo build --manifest-path rust/Cargo.toml
   ```

## Development Workflow

1. **Create a feature branch**

   ```bash
   git checkout -b feature/my-feature
   ```

2. **Make your changes**

   - Write code following the project's style guidelines
   - Add tests for any new functionality
   - Update documentation as needed

3. **Run quality checks**

   ```bash
   # Format code
   cargo fmt --manifest-path rust/Cargo.toml

   # Lint executable test targets; compile-check examples without linking 100+ binaries
   cargo clippy --manifest-path rust/Cargo.toml --lib --bins --tests --all-features
   cargo check --manifest-path rust/Cargo.toml --examples --all-features

   # Check file sizes (requires rust-script)
   rust-script scripts/check-file-size.rs

   # Check for hardcoded natural language in rust/src/ (R379, requires rust-script)
   rust-script scripts/check-hardcoded-language.rs

   # Run all checks together
   cargo fmt --manifest-path rust/Cargo.toml --check && cargo clippy --manifest-path rust/Cargo.toml --lib --bins --tests --all-features && cargo check --manifest-path rust/Cargo.toml --examples --all-features && rust-script scripts/check-file-size.rs && rust-script scripts/check-hardcoded-language.rs
   ```

4. **Run tests in CI**

   Rust commands below document CI usage. On the workstation, run only one
   necessary JavaScript test file at a time; never run Rust builds or tests.

   ```bash
   # Run all tests
   cargo test --manifest-path rust/Cargo.toml

   # Run tests with verbose output
   cargo test --manifest-path rust/Cargo.toml --verbose

   # Run doc tests
   cargo test --manifest-path rust/Cargo.toml --doc

   # Run a specific test
   cargo test --manifest-path rust/Cargo.toml test_name

   # Run the browser unit suite (the site's production JavaScript)
   npm run test:web
   ```

   CI job budgets are explicit and workflow-specific; acquisition and setup must leave room for the unchanged test deadline. Rust's built-in `cargo test` runner does not provide a portable global per-test timeout, so wrap long-running network, IO, or async tests with explicit test-level deadlines. If a repository adopts `cargo nextest`, configure runner deadlines with options such as `--slow-timeout` and `--leak-timeout`.

   **Work in bulk; verify selectively.** Draft the whole change set — tests
   and code together — before running anything, then let it fail in its
   entirety and fix the failures with as few CI/CD runs as possible.
   Small-change iteration multiplies CI runs; a batch fixed once is
   cheaper than ten steps each verified alone. Three rules follow from
   that:

   - Every plan is drafted in tests and code first. If the drafting is
     not finished, continue drafting — do not start fixing half a plan.
   - Run only the specific tests you changed locally (the filter
     arguments above); rely on CI/CD for everything else. The
     workstation is a notebook: full suites belong to CI, and
     sub-agents or helper scripts must never run them locally either.
   - On long batches, commit at least once every four hours, and push
     only after re-reading the issue, the pull request, and the diff
     one more time.
   - One test at a time on the workstation (R1018): run a single test
     file (`node --test --test-concurrency=1 <file>`, after any running
     `node --test` finishes). When test processes overload the machine,
     never kill the owner's processes; fix the cause (unbounded
     concurrency, a runaway runner) instead.
   - Rust is verified by pushing (R1020): no local `cargo` build, test or
     clippy. Artifacts that need a Rust build come from CI — the WASM
     worker from the release workflow's `formal-ai-worker-wasm` artifact,
     `ts/` from `scripts/translate-es.mjs`.
   - Keep requirement status current (R1021): a batch that changes what is
     delivered updates its requirement rows and regenerates the assembled
     register and the status ledger in the same push.
   - Never idle-wait on CI (R1022): while a run is in flight, keep drafting
     the open requirement rows and re-verifying the planned ones. A pull
     request is finished only when every planned requirement is drafted,
     CI/CD is green and the release is deliverable.
   - Decide, don't ask (R1023): open technical choices are settled from the
     best available practices (researched online when needed), not put to
     the owner as questions.

   **Use the fast PR / production-main profile (2026-10-28).** Bulk draft related
   fixes and their tests, requirement updates, vision and guidelines in one PR.
   Keep essential Linux coding, question-answering and failure-reporting checks
   on PRs. Retain heavy native, packaging, Docker and integration/E2E jobs rather
   than deleting them. Production builds, application packaging and Pages deployment
   run only on main (including its independently authorized release consumers).
   FORMAL_AI_FULL_PR_CI cannot restore compilation on a PR or branch dispatch.
   Main still builds and verifies production releases. Full Coding Ladder measurement is main-only opt-in (full-ladder=true or FORMAL_AI_FULL_CODING_LADDER=run); keep its fast consistency gate mandatory and award no deferred measurement credit. Collect complete bounded
   redacted CI logs, derive small behavioral unit fixtures with negative cases,
   and fix all available failures before the next push. Never grant execution
   credit to skipped suites or claim that offline emulation proves a live solve.
   Real GitHub effects require FORMAL_AI_REAL_GITHUB_E2E=true or explicit dispatch;
   preserve single-owner custody and trusted outcome-aware cleanup. Run only one
   necessary JavaScript test locally at a time; no Rust builds or tests locally.
   Regenerate canonical data mirrors with node scripts/mirror-package-data.mjs
   --write and commit them; fast lint checks byte equality before merge.
   Use the ordered runner: Node CLI discovery may sort duration-ranked files alphabetically.
   Prove execution order with isolated fixtures; retain per-file logs, coverage, concurrency and deadlines.
   Delivery includes green main CI and verified configured release artifacts.
   Keep the implementation, regression fixtures, requirements, vision, guidelines
   and handoff in the same working PR. Verify its exact current head before merge;
   record the resulting source commit, actual release version and immutable public
   artifact identities after merge. Earlier releases do not prove this delivery.
   Reuse the authenticated same-run complete source-history artifact across
   release consumers; keep the pinned protocol and independent stable-tag and
   ancestry checks. Explicitly advertise detached source history when negotiating
   a fetch. Do not retry large redundant downloads or raise their budgets to hide
   duplication. Missing console evidence after packaging starts remains a failure;
   record unacquired runners with structured annotations and no execution credit.
   Exclude private repository source and build outputs from desktop dependencies;
   verify captured exclusions with the installed packager and audit actual ASAR
   metadata before installer creation. Preserve required browser/native resources.
   Refresh governed source witnesses through their reviewed JavaScript generator
   when referenced files change; run the cheap source-integrity check before push.
   See [CI speed](docs/ci-cd/speed.md) and the
   [current requirements](docs/requirements/doctrine-fast-pull-request-production-ci.md).

   **The three-root cycle is js-first.** Rust, JavaScript and TypeScript
   are all full implementation roots — client and backend — kept
   equivalent through the meta language rather than by shrinking any
   root out (standing doctrine of 2026-09-24, R992-R996; it supersedes
   the 2026-08-04 interfacing-only-JavaScript boundary). Because
   JavaScript executes faster than Rust compiles, author and test a
   change in `js/` first when the change touches shared logic, then
   translate outward rather than hand-porting. The conversion follows
   the practices of `link-foundation/meta-language` (PR #196) and
   `link-foundation/relative-meta-logic` (R1024):

   ```bash
   formal-ai translate --list                  # every direction and its status
   formal-ai translate --from rust --to meta --input rust/src/module.rs
   node scripts/self-translate.mjs --to rust js/agentic/crate/module.mjs
   node scripts/self-translate.mjs --report    # the twins against their Rust
   node scripts/check-twin-citations.mjs       # every twin cites a live Rust item
   ```

   `node scripts/self-translate.mjs` is the JavaScript-first self-translation
   copied from meta-language PR #196: a provenance header, every top-level
   item translated or carried with the reason
   `data/meta/self-translation/constructs.lino` gives, and a round trip that
   restores the source byte for byte (`--to js` reads a translation back,
   `--to meta` prints the links IR). To widen the fragment, add the construct
   map row, a case and its `(call ...)` rows to
   `rust/tests/fixtures/self-translation/cases.lino`, then run
   `node scripts/self-translate.mjs --write`; never hand-edit the expected
   files. Both runtimes run every call of that one corpus, the practice of
   relative-meta-logic's `test-corpus/`. What was adopted and why is
   [docs/case-studies/pull-request-1188/conversion-best-practices.md](docs/case-studies/pull-request-1188/conversion-best-practices.md).

   Translation in any direction goes through the meta pivot
   (`rust/src/meta_translate.rs`); a leg that is not materialized yet
   names the plan-16 leaf that owes it
   ([plan 16](docs/case-studies/issue-1138/plans/16-js-ts-rust-cycle.md))
   instead of silently producing nothing. Today only `rust → meta` is
   live, so the cycle's practical form is still rust-authored; do not
   claim the closed js-first loop until plan 16 L4 (path-filtered CI)
   and L5 (CST-equal round trip) land.

   **Delegate to Opus sub-agents only.** Sub-agents are always run on
   the Opus model; the Fable model must never be used as a sub-agent
   (project owner directive, 2026-09-15). Keep the agent count low —
   the workstation is a notebook, and a fleet of agents competes with
   the build for the same memory: at most two or three sub-agents at
   once (R1019), each told the same disk, RAM and CPU limits. Sub-agents
   only make code changes; they run the JavaScript Formal AI only when
   absolutely necessary and never run builds or full suites.

   **Classify CI failures before touching them.** A branch with
   tracked, owner-assigned reds (an allowlisted failing test, an
   evidence gate awaiting a later wave, a rustfmt item already
   assigned) is not an emergency; fix only failure classes that are
   new to the branch, and record new standing reds in the owning plan
   instead of churning the same site twice.

   **Recover requirements from session transcripts.** When auditing
   that every user directive made it into the requirements, recover
   the user's messages from the session `.jsonl` transcripts with
   `experiments/issue_1138_feedback_recovery/collect_user_feedback.py`
   (it strips harness wrappers, agent reports, and cron echoes) and
   diff the recovered directives against `docs/requirements/` — new
   process or architecture notes discovered this way are recorded in
   this file or the requirements shards, not left in chat history.

5. **Add a changelog fragment**

   For any user-facing changes, create a changelog fragment:

   ```bash
   # Create a new file in changelog.d/
   # Format: YYYYMMDD_HHMMSS_description.md
   touch changelog.d/$(date +%Y%m%d_%H%M%S)_my_change.md
   ```

   Edit the file to document your changes:

   ```markdown
   ### Added
   - Description of new feature

   ### Fixed
   - Description of bug fix
   ```

   **Why fragments?** This prevents merge conflicts in CHANGELOG.md when multiple PRs are open simultaneously.

6. **Commit your changes**

   ```bash
   git add .
   git commit -m "feat: add new feature"
   ```

   Pre-commit hooks will automatically run and check your code.

7. **Push and create a Pull Request**

   ```bash
   git push origin feature/my-feature
   ```

   Then create a Pull Request on GitHub.

## Code Style Guidelines

This project uses:

- **rustfmt** for code formatting
- **Clippy** for linting, with `all`/`pedantic`/`nursery` enabled in `Cargo.toml`'s `[lints.clippy]` (a few noisy lints are explicitly allowed there)
- **cargo test** for testing

### Code Standards

- Follow Rust idioms and best practices
- Use documentation comments (`///`) for all public APIs
- Write tests for all new functionality
- Keep functions focused and reasonably sized
- Keep Rust files under 1000 lines (`.lino` files and the browser worker JavaScript are capped at 1500); all limits are enforced by `rust-script scripts/check-file-size.rs`
- Name things in full English words (`index`, not `idx`; `arguments`, not `args`) in code and in the links notation we own, and name files and directories after what they hold, never with numbered parts (R1188-U4, R1188-U5)
- In the links notation we own, prefer `-` over `_` in names, keep it human readable, and state shared structure once and reference it (R1188-U6, R1188-U7; `docs/links-notation-style.md`)
- Generalize, don't specialize: fix a failing case with the smallest universal rule that covers its class, so specific tests pass through shared code (R1188-U1), and follow [code-architecture-principles](https://github.com/link-foundation/code-architecture-principles) (R1188-U2)
- Make bulk changes by rules, such as a substitution pass or a generator with `--check`, not by hand (R1188-U8)

### Documentation Format

Use Rust documentation comments:

```rust
/// Brief description of the function.
///
/// Longer description if needed.
///
/// # Arguments
///
/// * `left` - Description of left
/// * `right` - Description of right
///
/// # Returns
///
/// Description of return value
///
/// # Errors
///
/// Description of when errors are returned
///
/// # Examples
///
/// ```
/// use my_package::example_function;
/// let result = example_function(1, 2);
/// assert_eq!(result, 3);
/// ```
pub fn example_function(left: i32, right: i32) -> i32 {
    left + right
}
```

## Testing Guidelines

- Run the suite through `scripts/cargo-test.sh` rather than `cargo test`
  directly. It takes the same arguments and adds two things a workstation
  needs:

  ```bash
  scripts/cargo-test.sh                          # whole suite
  scripts/cargo-test.sh --test unit issue_907    # one module
  ```

  **Fast local iteration on one test binary.** The test profile ships with
  `incremental = false` (`Cargo.toml`) — a deliberate CI choice — so every
  one-line source edit recompiles the whole crate: measured 2m43s for
  `cargo test --manifest-path rust/Cargo.toml --test unit --no-run` after `touch rust/src/lib.rs` on the
  reference notebook (2 jobs, opt-level 2, `debug = 0` already set). Turning
  incremental compilation back on locally, in its own target directory so
  the checked-in profile and the shared cache stay untouched:

  ```bash
  CARGO_TARGET_DIR=/tmp/formal-ai-target-incr \
  CARGO_PROFILE_TEST_INCREMENTAL=true CARGO_PROFILE_DEV_INCREMENTAL=true \
  CARGO_BUILD_JOBS=2 cargo test --manifest-path rust/Cargo.toml --offline --test unit -- <filters>
  ```

  measured **1m11s** for the same touch — a 2.3x faster edit-compile loop —
  after one 7m05s cold build, with the directory holding ~4.8 GB against
  ~9.7 GB for the non-incremental one. Keep one directory, not both, when
  disk is tight, and remember the filters follow `--`
  (`cargo test --manifest-path rust/Cargo.toml --test unit -- filter_a filter_b`): placed before it, cargo
  reads them as bin arguments and errors out.

  **macOS runs platform tests, not the whole suite.** No code in `rust/src/` branches
  on macOS versus Linux — all eight conditionals are `cfg(unix)`, true on both —
  so pure Rust logic cannot behave differently there. Every macOS-only failure
  this repository has recorded came from the environment instead: GNU coreutils
  absent (`timeout`), bash 3.2 without `mapfile`, subprocess and path handling.

  Running everything twice cost real time: 2895 tests moved a 916 MB archive to
  each of eight runners, 7 GB per run, and two of those downloads failed
  outright. The macOS lane now runs the 139 tests whose behaviour can differ —
  about ten seconds on one runner.

  **When something does behave differently on macOS, add its module to
  `data/meta/macos-platform-tests.lino`** with a line saying what differs. Do
  not widen the filter back to everything; the file is the list of what macOS is
  actually for, and `step_budgets_within_job_clocks::the_macos_lane_selects_a_non_empty_set_of_tests`
  fails if it empties out.

  **Start the longest work first.** Whenever work is split across parallel
  workers -- test partitions, matrix legs, anything fanned out -- the long tasks
  must be scheduled first and the short ones packed in behind them. A long task
  started last runs alone on a machine everything else has already finished
  waiting for, and that tail is pure serial time on the critical path.

  This is longest-processing-time-first, and it is not a preference: measured on
  run 32591020809 (2895 tests, 4704s of work over eight partitions), splitting
  by test index gave a **870s** worst partition against a **588s** ideal, while
  LPT hit 588s exactly. 282s of the critical path, spent idling.

  `scripts/plan-test-partition.rs` implements it for the macOS test slices from
  the durations recorded in `data/meta/test-durations.lino`, and the
  `check-test-partition-balance` CI gate fails when the plan drifts out of
  balance -- so a regression back to index order cannot land quietly. Apply the
  same rule to any new fan-out: sort by cost, descending, before assigning.

  **Use the whole machine on CI.** An ephemeral runner is billed for the minutes
  it is alive, so leaving cores idle only makes the wait longer. Do not add
  `max-parallel`, and do not cap test threads on CI; the local half-CPU cap
  below exists for a shared laptop, not for a runner.

  **Half the CPUs locally, all of them on CI.** A bare `cargo test` starts one
  compile job *and* one test thread per core, which pins the whole machine for
  the length of the run. The wrapper caps both at half the cores unless `CI` is
  set, so an ephemeral runner still uses everything it is paying for. Override
  with `CARGO_TEST_JOBS=<n>`.

  **The cache keeps one build, not every build.** Cargo never removes anything,
  so `target/` accumulates artifacts from every branch and dependency version
  and reaches several gigabytes within days. The wrapper prunes to the artifacts
  the latest build produced, and CI does the same after its test step so the
  saved actions cache carries one build rather than a growing pile. Run
  `scripts/prune-build-cache.sh` on its own to reclaim space at any time, or set
  `CARGO_TEST_NO_PRUNE=1` to keep everything for a debugging session.

  **Every commit sweeps.** The `prune-build-cache` pre-commit hook runs on every
  commit, not only Rust ones -- a docs-only commit leaves the previous build's
  artifacts on disk just the same. Disk is reclaimed as a matter of course
  rather than when someone remembers.

  ```bash
  cargo install cargo-sweep   # strongly recommended
  ```

  With cargo-sweep installed the pruner asks cargo *which artifacts the current
  build actually references* and removes the rest, so a dependency the next
  build still needs survives even if it was compiled weeks ago. Without it the
  pruner falls back to comparing modification times, which cannot tell a stale
  artifact from a current one that simply did not need rebuilding -- it deletes
  live dependencies and the next build recompiles them. Both keep the cache
  small; only cargo-sweep keeps it *useful*.

  `CARGO_TARGET_MAX_SIZE_MB` caps the tree after the sweep, defaulting to 4096
  (4GB) locally and to no ceiling on CI, where the runner is billed for the
  rebuild rather than the disk.

- Write tests for all new features
- Maintain or improve test coverage — this is enforced, not requested. CI
  measures two separate denominators, Rust and browser, against the reviewed
  floors in `coverage/baseline.json` and fails on a decrease. Raising a floor is
  a one-liner; lowering one requires an explicit reviewed justification recorded
  in the file. See [docs/design/coverage-ratchet.md](docs/design/coverage-ratchet.md).

  ```bash
  # Browser denominator
  npm run coverage:web && npm run coverage:ratchet -- --only browser

  # Rust denominator
  cargo llvm-cov --all-features --lcov --output-path lcov.info
  npm run coverage:ratchet -- --only rust

  # Lock in a gain
  npm run coverage:ratchet -- --only browser --update-baseline
  ```
- Use descriptive test names
- Organize tests in modules when appropriate
- Use `#[cfg(test)]` for test-only code

Example test structure:

```rust
#[cfg(test)]
mod tests {
    use super::*;

    mod my_feature_tests {
        use super::*;

        #[test]
        fn test_basic_functionality() {
            assert_eq!(my_function(), expected_result);
        }

        #[test]
        fn test_edge_case() {
            assert_eq!(my_function(edge_case_input), expected_result);
        }
    }
}
```

## Self-maintained dependencies and patches

When a build step, the translator, or a layer check needs a feature a
self-maintained dependency has not released, the workaround is a
`[patch]`-style source install — and the debt it creates is tracked where
debt belongs:

- Every `[patch]` or source-install entry in `Cargo.toml` carries a comment
  beside it referencing, by URL, the issue that lists what is patched and
  what blocks using the latest release. The gate
  `rust/tests/unit/ci-cd/issue_1138_dependency_patches.rs` fails the build when
  an entry appears without one, and when the lockfile resolves git sources
  the manifest does not declare.
- One issue per dependency — not one issue per patch. The issue stays open
  until the last patch for that dependency is gone.
- Issues filed against dependencies are written **generally**: state the
  general case the dependency is missing, not what Formal AI happens to
  need. The general case moves into the dependency; this repository's own
  code shrinks. A patch is a bridge, and its issue is the plan to remove
  it — an untracked patch is invisible debt, because nothing fails when
  the upstream release lands and nothing ever removes it.

The same rule governs *held-back releases* (issue #1169): every dependency
must sit at its publisher's latest release, and `rust-script
scripts/check-dependencies-latest.rs` fails when one does not. The one
sanctioned way to hold a dependency back is a same-line annotation naming
the issue that tracks the hold-back — `links-notation = "0.16.1" # blocked:
https://github.com/link-foundation/lino-objects-codec/issues/60` in
`Cargo.toml` (the URL may be bare or `<…>`-bracketed), or a `"<name>//":
"blocked: <url> (reason)"` note key in the same `package.json`. The
annotation must open with an issue URL, or with the GitHub security advisory
(`https://github.com/advisories/GHSA-…`) when the hold-back waits on an
unpatched vulnerability; a hold-back without one is not a decision, only
drift, and the gate fails on it. The daily
`dependencies-latest` workflow re-checks every registry and opens one pull
request with everything that moved, so the gate being green is a fact about
yesterday's registries, not a permanent state anyone achieves once.

## GitHub credentials

Tokens are **optional in all cases** (issue #1187). Nothing needs
configuring for the workflows to run; when a credential exists, more work
happens unattended.

- **One resolver.** Every workflow that writes to GitHub takes its token
  from `.github/actions/automation-token` — never from a directly read
  secret. Three layers, first available wins: a GitHub App
  (`AUTOMATION_APP_ID` + `AUTOMATION_APP_PRIVATE_KEY`, one app may serve
  every repository of the organization), then one secret named
  `AUTOMATION_TOKEN` — the same name in every repository, so one
  organization secret serves them all — then the built-in `github.token`.
  The layer that resolved is printed to the log and the job summary. No
  other token secret name may appear in a workflow
  (`rust/tests/unit/issue_1187_credentials.rs` fails the build on one).
- **Checks without approval.** A `pull_request` workflow run whose PR was
  opened by `GITHUB_TOKEN` waits for approval — that is GitHub's rule, not
  ours. When the resolver reports layer `default`, the workflow that
  pushed the branch calls `.github/actions/dispatch-checks`, which
  dispatches every `pull_request` workflow on the head commit; dispatch
  runs need no approval.
- **Isolation without tokens.** A workload needing a separate tree tests on
  an orphan branch of this repository (`e2e/<purpose>/<run_id>/<name>`,
  `.github/workflows/e2e-isolation.yml`), with an `e2e-task` issue and a
  pull request based on that branch, closed and deleted at the end. A
  separate repository is used only when the resolver reports
  `can-create-repositories: true` (the App layer).
- **Cross-repository work degrades, never fails.** Filing an issue in
  another repository at layer `default` is not possible; the workload
  writes its findings into its report (`docs/status.md`, the case study)
  and keeps one tracking issue here listing what to file.

## Manual confirmation is aspirational (issue #1090)

The manual-confirmation column of
[docs/requirements-traceability.md](docs/requirements-traceability.md) is
**aspirational**: `not yet confirmed` is the honest resting state of a row
whose automated test pins the machinery while nobody has yet watched it run
by hand, and it carries no debt and gates nothing. Two rules follow:

- **No new manual-confirmation ledger may be introduced until an existing one is complete.**
  A second parallel column would dilute the one surface that exists;
  finishing beats starting.
- The way the column fills is the finish branch of #1090: replayed session
  captures from the agentic-CLI matrix, cited per row. Until a capture
  exists for a row, the row stays `not yet confirmed` — that is the
  recorded truth, not a gap to paper over.

## Project Conventions (recurring maintainer recommendations)

These conventions recur in almost every issue review. They are collected here so
contributors — human and AI — can apply them up front instead of rediscovering
them in review. They reflect the project's vision: a deterministic, symbolic
agent whose every answer is a projection of an append-only event log, with no
hardcoded prompt→answer tables.

1. **Mirror parity (Rust ↔ JS worker).** Every reasoning path in the Rust engine
   (`rust/src/*.rs`) has a twin in the browser worker (`js/worker/formal_ai_worker.js`
   loader plus the `js/worker/formal_ai_worker_*.js` shards),
   so the CLI, library, HTTP server, Telegram bot, and website all answer the
   same prompt identically. A behavioural change in one **must** be mirrored in
   the other in the same PR. Name and comment the twin so the parity is obvious
   (e.g. "Mirrors `try_x` in `rust/src/solver_handler_x.rs`").
   **JavaScript first (REQUIREMENTS.md R997-R1000, 2026-10-06).** Implement
   and test a requirement in the JavaScript worker first (`npm run test:web`
   runs in seconds); Rust follows by translation through the meta language,
   or by a port that names its JavaScript original. Never land a new
   `null` ("native surface only") registry row: `scripts/check-js-parity.mjs`
   ratchets their count down. A worker module's line ceiling may rise for a
   JavaScript twin of a native handler, with the keys named in the shard's
   rationale (R999). Write new handler modules in the portable subset
   (top-level functions with JSDoc types, `const`/`let`, tagged unions
   dispatched by `switch`, no classes or destructuring) so they translate
   mechanically. Regenerate `ts/` with `node scripts/translate-es.mjs
   --write`; leave Rust compilation to CI — a push is the build.

2. **Data-driven seed, no hardcoded natural language in code (issues #386,
   #513).** Natural language is *data*, never a string literal in the engine.
   This applies to **both directions** of every reasoning path:
   - **Triggers / detection.** All multilingual phrases, surfaces, run verbs,
     shell tokens, concept summaries, and the tool registry live in
     `data/seed/*.lino`. Recognisers ask the lexicon for a *meaning* by role
     (`lexicon().meanings_with_role(ROLE_…)`) or load a named vocabulary
     (e.g. `seed::terminal_command_vocabulary()`); they never hardcode
     per-language phrase arrays or branch on literal user phrasings.
   - **Responses / output.** Every user-facing answer string is a template in
     `data/seed/multilingual-responses.lino` looked up by intent
     (`seed::response_for(intent, lang)` in Rust, `answerFor(...)` in the
     worker). Code fills placeholders like `{command}`; it does not embed the
     surrounding prose.
   - **Web front-end (React).** Every string the user sees in `js/app.js`
     — permission-panel titles, button labels, status words, onboarding copy,
     system messages — is a catalog entry in `js/i18n-catalog.lino`, looked
     up at render time via `t("<key>", params)` (the `window.FormalAiI18n`
     engine). Never pass a prose string literal as a child of `h(...)`; route it
     through `t(...)` so it follows the active UI language and fills placeholders
     like `{granted}/{total}`.

   The principle is **meanings ↔ naturalization**: a *meaning* (a slug grounded
   in seed data) can be *naturalized* into a natural-language surface, and any
   natural-language word can be *formalized* back into a meaning. Code only ever
   moves meanings around; the words live in the seed. Add a new cue or answer by
   editing the `.lino` file and declaring the role/intent — not by typing a
   phrase into `rust/src/*.rs` or `formal_ai_worker.js`.

   This is enforced by CI, not just convention:
   - **Total reference-closure gate** (`rust/tests/unit/total_closure.rs` →
     `scripts/audit-total-closure.py`, run by `cargo test --manifest-path rust/Cargo.toml --tests`). Every bare
     value token in any `data/seed/*.lino` must resolve to a defined meaning, a
     declared role, a cached dictionary lemma, or a Wikidata id. New vocabulary
     that resolves to nothing fails the build. Ground new tokens by running
     `python3 scripts/close-total.py` (idempotent; emits each unresolved token
     as a first-class meaning under `data/seed/closure-generated-*.lino`) until
     `python3 scripts/audit-total-closure.py` reports `unresolved_distinct: 0`.
     Those shards are **content-addressed**: each meaning lands in the shard
     picked by `sha256(slug) % SHARD_COUNT`, so a new token rewrites exactly one
     file and leaves the others byte-identical. Do not re-sort them into
     alphabetical files — filling shards sequentially makes every shard depend
     on the size of everything before it, which is what made `data/seed`
     conflict in almost every pull request. `SHARD_COUNT` is fixed rather than
     derived from the corpus, because changing it reshuffles every shard once;
     raise it only when a shard approaches the 1500-line data-file limit.
     `./experiments/issue-909-seed-shard-conflict-blast-radius.sh` asserts the
     property by adding one token and counting the files it dirties.
   - **Worker seed parity checks.** Where the JS worker consumes a generated web
     seed copy, a `--check` guard fails the build on loader regressions and on
     drift in a present mirror (e.g. the “Check terminal vocabulary worker seed
     wiring” CI step runs
     `node experiments/issue-513-sync-worker-terminal.mjs --check`). Refresh
     the web seed copy with `scripts/sync-seed.sh` or by running the same script
     without `--check`.
   - **Web-UI hardcoded-string guard (#511).** `npm --prefix rust/tests/e2e run
     check:web-hardcoded-ui` parses every `h(...)` call in `js/app.js` and
     fails the build when a child argument is a bare prose string literal, so new
     English text cannot leak into the UI. `npm --prefix rust/tests/e2e run check:i18n`
     asserts every required key exists in all four locales and that sample
     interpolations render. When you add a web-UI string: add the key + all four
     translations in `js/i18n-catalog.lino`, register it in `REQUIRED_KEYS`
     in `rust/tests/e2e/scripts/check-i18n-catalog.mjs`, and render it with `t(...)`.

   See `docs/design/no-hardcoded-natural-language.md` for the full rationale,
   the meanings ↔ naturalization model, and a worked example.

3. **Roles are declared, then generated.** When you add a meaning with a new
   `role`, declare it as a `ROLE_*` constant in `rust/src/seed/roles/*.rs`, re-export
   it from `rust/src/seed.rs`, and regenerate the registry with
   `python3 scripts/generate-role-registry.py` (keeps `data/seed/roles.lino` in
   lockstep; enforced by `reference_closure` tests).

4. **Supported-language coverage.** New conversational cues should cover the
   project's supported languages (currently en, ru, hi, zh). The
   `rust/tests/e2e/scripts/check-*.mjs` guards fail a one-language change.
   Translation changes have the stricter issue #526 rule: add or update
   round-trip tests that prove language-to-meta-to-same-language survival and
   every supported language-pair path through the meta language. Code
   translation changes must preserve a `meaning:` link across the source ->
   target -> source round trip (for example Rust <-> JavaScript), not just render
   plausible syntax.

5. **Fix everywhere, not just the reported spot.** If a defect has more than one
   site (most do, because of mirror parity), fix all of them in the one PR.

6. **Reproduce first, then fix.** Add a failing test that reproduces the issue
   before implementing the fix; a bug fix without a reproducing regression test
   is treated as incomplete.

   **Benchmark anti-memorization.** A coding-benchmark improvement must come
   from a reusable task shape, operation meaning, sourced part, or verified
   composition—not from an upstream case id, entry-point name, or copied task
   sentence. When the upstream HumanEval/MBPP payloads are cached, run
   `cargo test --manifest-path rust/Cargo.toml --test unit coding_discovery::no_memorization -- --nocapture`;
   the gate scans `rust/src/` and `data/seed/` against the downloaded slice. A
   skipped cache is reported explicitly and is not evidence that the gate
   passed. Generic language/library words need a narrow, reviewed allowlist.

7. **When data is insufficient, add tracing.** If there is not enough signal to
   find a root cause, add debug output / a verbose mode (default **off**) and
   keep it in the code so the next iteration has the data.

8. **Case study per issue.** Download the issue's logs and data into
   `docs/case-studies/issue-{id}/` (raw JSON under `raw-data/`) and write a
   `README.md` that reconstructs the timeline, enumerates every requirement,
   finds the root cause(s), surveys prior art / existing libraries, and records
   the implemented fix and its verification.

9. **Report upstream when relevant.** If an issue is rooted in another
   repository we can file against, open an issue there with a reproducible
   example, a workaround, and a suggested fix.

10. **One PR per issue.** Plan and execute everything for an issue in a single
    pull request; commit atomic, individually useful steps so interrupted work
    stays preserved.

11. **Prefer the meta algorithm; drive Formal AI to solve its own tasks
    (direction set by issue #538).** The long-term way we develop this project is
    to treat every task as a message formalized into the meta language and to let
    Formal AI — driven through its own Agent CLI
    (<https://github.com/link-assistant/agent>) — reason about and solve the task
    by editing its own data (memory) and meta algorithm (reasoning), rather than
    a human hand-coding each answer. When Formal AI cannot yet perform a step,
    the goal is to improve the meta algorithm just enough that it can, verifying
    generality by phrasing the same request different ways and by reproducing the
    change in a clean repository copy driven by the Agent CLI.

    **Honest current status.** This is not aspirational: from issue #538 forward
    it is how changes are produced (see the top-of-file rules 1–5). The Agent CLI
    drives real, byte-for-byte-reproducible changes today — the self-hosting loop
    (spawn a Formal AI server, hand it the task, capture the Agent-CLI session JSON
    that reproduces the change) is what wrote the #538 seed data, the potato
    enrichment, and the generated recipe diagrams; `scripts/reproduce-issue-538.sh`
    regenerates all three on a clean checkout. What is honestly *not yet built* is
    autonomous handling of the sweeping, open-ended axes (e.g. a full CST/AST-in-
    data round trip, or one-shot handling of an arbitrary unseen issue). Those are
    **not** parked on a roadmap: each names its smallest real, testable next slice
    in [`docs/case-studies/issue-538/requirements.md`](docs/case-studies/issue-538/requirements.md)
    and is executed the same way — by extending Formal AI / the Agent CLI until the
    tool can do it and a test goes red on regression (rule 3), never by hand-editing
    and deferring. When a task's requirements genuinely conflict (as issue #538's
    small concrete ask sits inside a much larger vision), surface the contradiction
    explicitly and still deliver a real, tested slice of *each* axis — never dress
    "did part of everything" as an honest scope cut.

12. **Declare issue disposition explicitly (issue #960; later owner release-iteration requirement R1207-9).** Fully accepted work uses a GitHub [recognised closing keyword](https://docs.github.com/en/issues/tracking-your-work-with-issues/using-issues/linking-a-pull-request-to-an-issue), preferably `Fixes https://github.com/link-assistant/formal-ai/issues/146`. An issue whose original acceptance remains unfinished must stay open: use a separate whole line `Related (acceptance pending): https://github.com/link-assistant/formal-ai/issues/146` and state the remaining acceptance. This explicit pending disposition does not claim delivery or close the issue. Ambiguous substitutes such as *Addresses*, *Relates to*, *Part of* and *Refs* still fail `scripts/check-pull-request-link.rs`. Never add a false closing claim just to pass CI.

13. **Case study per pull request.** Alongside the per-issue case study
    (rule 8), a case study that documents a *pull request* — its review
    conversation, CI history, and the decisions taken in it — lives in
    `docs/case-studies/pull-request-{id}/`, mirroring the `issue-{id}` layout
    (raw JSON under `raw-data/`). Keep issue-driven and PR-driven narratives in
    their own directories so neither is buried inside the other.

14. **The 1500-line Links Notation cap covers cached data too (issue #960).**
    `scripts/check-file-size.rs` and `rust/tests/unit/data_files.rs` apply the cap to
    every `.lino` file in the repository, `data/cache/wikidata/` included.
    Generated-but-committed is not a reason to be exempt; it is the reason to be
    measured, because the generator is what can breach the cap. When a fetched
    response would exceed it, split it into `<bucket>-partN.lino` the way
    `rust/examples/refresh_translation_cache.rs` already does.

15. **Budget cache buckets: 128 records each (issue #960).**
    `MAX_SEED_RECORDS_PER_BUCKET` in `rust/src/translation/cache.rs` is enforced, not
    merely recorded: `scripts/check-cache-budget.rs` fails when a bucket under
    `data/cache/` holds more than 128 records (a record is a file stem, so
    `Q1860.json` and `Q1860.lino` count once). Bucket or trim instead of growing
    past the cap. The three buckets whose size is *forced* by the total-closure
    gate — `wikidata/entity`, `wordnet/en`, `wiktionary/en`, where every record
    exists because a seed token references it — are listed as
    `CLOSURE_DRIVEN_BUCKETS` with a written reason, and pay for the exemption
    with a stricter invariant: the check fails if any of their records is an
    orphan nothing references.

16. **Tests are documentation: assert the exact answer (issue #960).** A
    behavioural or conversational test should show the reader what the system
    says, not merely that the reply is not empty. Assert the answer verbatim
    (`assert_eq!(response.answer, "…")`, or membership in an explicit list of
    exact answers) and keep looser `contains` guards only as extra checks
    *after* the exact one. `scripts/check-tests-as-docs.rs` enforces this as a
    burn-down ratchet: existing loose-only tests are recorded in
    `scripts/tests-as-docs-allowlist.txt`, new ones fail the build, and a row
    that has been made explicit must be pruned (`--write` regenerates the list).

17. **Pin invariants with containment, not byte-equality (R1085-16).** A test
    that pins a structural invariant — "this generated document must satisfy
    property X" — should assert containment or membership (`assert!(text.contains(…))`,
    `assert!(VALID_VALUES.contains(&actual))`) rather than comparing the whole
    generated document byte-for-byte. Byte-equality is right only when the bytes
    themselves are the contract (a content-addressed artifact, a wire format, a
    fixture the regeneration pipeline must reproduce exactly). For everything else,
    pin the observable invariant and leave room for unrelated regeneration to change
    the surrounding document without breaking the test.

## Merge conflicts are a layout bug (issue #991)

Follow the [merge conflict layout guide](docs/development/merge-conflict-layout.md)
when adding modules, checks, requirements or generated data. It defines list
ownership, verification, regeneration and the documentation test mapping.

## The single push gate (issue #1191)

Every push starts the whole pull-request matrix again. A push that fixes only
some of the previous run's failures pays that cost once per round trip.
Pull request #1188 needed 100 commits and 11 `CI/CD Pipeline` runs, and none of
them was green. Human and AI contributors therefore follow one push gate, which
[AGENTS.md](AGENTS.md) restates for agents:

1. **Drafting sub-agents never push.** They commit locally or hand back a diff.
2. **One CI/CD agent pushes, once per round.** That agent first collects every
   actionable failure of the latest run on the current head
   (`gh run list --branch <branch>`, then `gh run view <id> --log-failed`). It
   fixes all of them in one batch and pushes once.
3. **Never push while a run is in progress on the branch.**
   `gh run list --branch <branch> --status in_progress` and `--status queued`
   must both be empty, unless you are deliberately superseding an older head.
   The protected-main and superseded-pull-request concurrency groups stay as
   they are; this rule keeps them from being used as a retry loop.
4. **Run the JavaScript checks locally before the push.** Run the test files
   next to the change one at a time
   (`timeout 600 node --test --test-concurrency=1 <file>`). Also run the
   JavaScript twins of the gates the change touches
   (`node experiments/formal_ai_subagent/local-gates.mjs --only <gate>`). Run
   the whole set, without `--only`, before a push that changes shared data.
5. **No full local Rust build unless the change is Rust-only.** CI compiles
   Rust: the focused `native-type-check` job on pull requests, and the full
   matrix on main. `rustfmt --check <file>` needs no build.
6. **When a Rust-only change has to be built locally, keep the build bounded.**
   - Share one target directory across worktrees and agents
     (`CARGO_TARGET_DIR=$HOME/.cache/formal-ai-target`).
   - Turn off the incremental cache (`CARGO_INCREMENTAL=0`).
   - Limit the jobs (`CARGO_BUILD_JOBS=2`, or `CARGO_TEST_JOBS=2` for
     `scripts/cargo-test.sh`).
   - Prune old artifacts afterwards (`scripts/prune-build-cache.sh`). The
     script follows `CARGO_TARGET_DIR` and caps the tree at 4 GB locally.

When main fails after a green pull request, record the failure in
[`data/meta/main-only-regressions.lino`](data/meta/main-only-regressions.lino)
together with the narrowest pre-merge check that now replays it.
`rust/tests/web/main-only-regression-ledger.test.mjs` keeps each named check in
the fast pull-request lane.

## Pull Request Process

1. Run only the tests next to your change locally (`node --test <file>`) and
   the JavaScript twins of the gates it touches
   (`node experiments/formal_ai_subagent/local-gates.mjs --only <gate>`); do
   not build Rust locally. CI runs everything else, and its failures are fixed
   in bulk (R1188-U24, R1188-U25).
2. Check the change against the review checklist in
   [`docs/architecture/principles.md`](docs/architecture/principles.md), which
   maps every code-architecture principle to the gate that enforces it
   (R1188-U2), and update documentation if needed
3. Add a changelog fragment (see step 5 in Development Workflow)
4. Ensure the PR description clearly describes the changes
5. Declare each issue's disposition. Completed acceptance uses `Fixes #146` or its full GitHub issue URL.
   Unfinished original acceptance uses the explicit whole-line record `Related (acceptance pending): <issue reference>`.
   Keep unfinished acceptance pending under R1207-9; close an issue only when its acceptance is complete.
   Ambiguous substitutes such as `Addresses #146`, `Relates to #146`, or `Part of #146` do not satisfy the check.
   Verify locally before opening the PR:

   ```bash
   PR_BODY="$(gh pr view <number> --json body --jq .body)" \
     rust-script scripts/check-pull-request-link.rs
   ```

   CI runs the same check on every pull request.
6. Put any case study *about the pull request itself* in
   `docs/case-studies/pull-request-{id}/` (issue case studies stay in
   `docs/case-studies/issue-{id}/`)
7. Wait for CI checks to pass
8. Address any review feedback

## Changelog Management

Follow the [changelog guide](docs/development/changelog-management.md) for fragment
creation, categories and release collection.
<a id="creating-a-fragment"></a><a id="fragment-categories"></a><a id="during-release"></a>

## Project Structure

The top-level layout is in
[docs/development/project-structure.md](docs/development/project-structure.md).

## Release Process

This project uses semantic versioning (MAJOR.MINOR.PATCH):

- **MAJOR**: Breaking changes
- **MINOR**: New features (backward compatible)
- **PATCH**: Bug fixes (backward compatible)

Releases are managed through GitHub releases. To trigger a release:

1. Manually trigger the release workflow with a version bump type
2. Or: Update the version in Cargo.toml and push to main

## Getting Help

- Open an issue for bugs or feature requests
- Use discussions for questions and general help
- Check existing issues and PRs before creating new ones

## Code of Conduct

- Be respectful and inclusive
- Provide constructive feedback
- Focus on what is best for the community
- Show empathy towards other community members

Thank you for contributing!

Prefer maintained generators, declarative transformations and bulk automation for source and documentation changes. Ask actual Formal AI to perform tasks it can solve. When it cannot, retain the failed ask and record the missing general capability with its independent expected outcome; improve that capability instead of silently substituting a hand-authored per-task answer. Supplied controllers and recipes remain automation with zero autonomous-authorship credit. Follow the [fast source governance guideline](docs/guidelines/fast-source-governance.md) for seed contracts and PR preflight policy. Follow the [issue planning guideline](docs/guidelines/issue-planning.md) for issue types, native blockers, parent issues and status wording.
