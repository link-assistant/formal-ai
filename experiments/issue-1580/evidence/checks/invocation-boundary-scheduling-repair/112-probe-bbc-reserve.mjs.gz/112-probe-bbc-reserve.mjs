import fs from 'node:fs';
import {mergeJavaScriptDurations,parseTestDurations} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/ci-speed-durations.mjs';
import {planShards,durationLookup} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/ci-speed-shards.mjs';
const root='/tmp/gh-issue-solver-1794900398048/';
const scratch='/tmp/issue-1580-research/bbc-layered-costs/';
const before=fs.readFileSync(scratch+'table.before.lino','utf8');
const observations=fs.readFileSync(scratch+'observations.jsonl','utf8').trim().split('\n').map(row=>JSON.parse(row));
const files=fs.readdirSync(root+'rust/tests/web').filter(file=>file.endsWith('.test.mjs')).map(file=>'rust/tests/web/'+file);
function model(shards,costs){return shards.map(shard=>{const lanes=Array(4).fill(0);for(const file of shard)lanes[lanes.indexOf(Math.min(...lanes))]+=costs(file);return Math.max(...lanes);});}
const rows=[];
for(const factor of [1,1.2,1.25,1.3,1.35,1.4,1.45,1.5]){
 const after=mergeJavaScriptDurations(before,new Map(observations.map(row=>[row.file,{...row,seconds:row.seconds*factor}])),{source:'45006097030',recordedDate:'2026-11-22',raiseOnly:true});
 const costs=durationLookup(parseTestDurations(after),Number(after.match(/^  default-seconds (\S+)/m)[1]));
 const {shards}=planShards(files,8,costs);
 const measured=model(shards,durationLookup(new Map(observations.map(row=>[row.file,row.seconds])),0.34));
 rows.push({factor,measuredMaximum:Math.max(...measured),measuredWithOverhead:Math.max(...measured)+30,weightedMaximum:Math.max(...model(shards,costs))});
}
fs.writeFileSync(scratch+'reserve-comparison.json',JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify(rows,null,2));
