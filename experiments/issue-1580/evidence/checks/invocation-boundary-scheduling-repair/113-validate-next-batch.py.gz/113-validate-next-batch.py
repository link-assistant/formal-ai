from pathlib import Path
import subprocess,os,json,sys,datetime,traceback
out=Path('/tmp/issue-1580-research/next-batch-validation');out.mkdir(exist_ok=True)
if len(sys.argv)==1:
 with (out/'worker.log').open('w') as log:p=subprocess.Popen([sys.executable,__file__,'worker'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid').write_text(str(p.pid)+'\n');print('STARTED',p.pid);sys.exit(0)
checks=[]
def run(name,command):
 print('START',name,flush=True)
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=512'})
 checks.append({'name':name,'command':command,'status':r.returncode});(out/'progress.json').write_text(json.dumps(checks,indent=2)+'\n');print('END',name,r.returncode,flush=True)
try:
 for name,file in [('boundaries','rust/tests/web/write-str-boundaries.test.mjs'),('version-resolution','rust/tests/web/issue-1168-version-resolution-parity.test.mjs'),('source-callbacks','rust/tests/web/recipe-source-callbacks.test.mjs'),('protocol-resume','rust/tests/web/recipe-resume-protocols.test.mjs'),('scheduling','experiments/issue-1580/hosted-javascript-scheduling.test.mjs'),('ci-speed','rust/tests/web/ci-speed.test.mjs')]:
  run(name,['node','--test','--test-concurrency=1',file])
 run('rust-format',['rustfmt','--edition','2024','--check','rust/src/agentic_coding/ci_workflow.rs','rust/src/agentic_coding/command_reroute.rs','rust/src/agentic_coding/command_reroute/recipe_execution.rs'])
 run('all-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs'])
 run('whitespace',['git','diff','--check'])
 (out/'result.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'allPassed':all(row['status']==0 for row in checks),'nativeExecuted':False,'memoryMegabytes':512},indent=2)+'\n')
except BaseException:
 (out/'failure.txt').write_text(traceback.format_exc());traceback.print_exc();sys.exit(1)
