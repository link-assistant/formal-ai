from pathlib import Path
import subprocess,json,hashlib
out=Path('/tmp/issue-1580-research/6903-next-batch-review');out.mkdir(exist_ok=True)
names=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
rows=[]
for name in names:
 if name in ['docs/status.md','experiments/issue-1580/work-plan.md']:continue
 data=subprocess.check_output(['git','diff','--',name]);target=out/(str(len(rows)+1).zfill(3)+'-'+name.replace('/','--')+'.diff');target.write_bytes(data)
 rows.append({'source':name,'diff':str(target),'lines':len(data.splitlines()),'sha256':hashlib.sha256(data).hexdigest(),'sourceSha256':hashlib.sha256(Path(name).read_bytes()).hexdigest()})
(out/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:print(row['source'],row['lines'],row['diff'])
print(subprocess.check_output(['git','branch','--show-current'],text=True))
