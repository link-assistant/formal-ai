from pathlib import Path
import subprocess,os
out=Path('/tmp/issue-1580-research/6903-source-batch-projection');out.mkdir(exist_ok=True)
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'}
for name,args in [('generate',['node','scripts/translate-es.mjs','--write']),('currency',['node','scripts/translate-es.mjs','--check']),('nested-receipts',['node','--test','--test-concurrency=1','rust/tests/web/recipe-source-callbacks.test.mjs'])]:
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 print(name,p.returncode,flush=True)
 assert p.returncode==0,(name,(out/(name+'.log')).read_text()[-4000:])
