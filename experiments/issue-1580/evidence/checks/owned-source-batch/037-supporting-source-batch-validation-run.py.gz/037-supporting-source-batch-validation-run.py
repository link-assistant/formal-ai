from pathlib import Path
import subprocess,json,os,time
out=Path('/tmp/issue-1580-research/supporting-source-batch-validation')
commands=[('source-callbacks',['node','--test','--test-concurrency=1','rust/tests/web/recipe-source-callbacks.test.mjs']),('hive-consumer',['node','--test','--test-concurrency=1','rust/tests/web/hive-work-item-consumer.test.mjs']),('source-protocols',['node','--test','--test-concurrency=1','rust/tests/web/recipe-resume-protocols.test.mjs']),('connector-receipts',['node','--test','--test-concurrency=1','rust/tests/web/connector-work-item-receipts.test.mjs']),('native-projection',['node','scripts/translate-js-rust.mjs','--verify'])]
rows=[]
for name,args in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','FORMAL_AI_OFFLINE':'1','FORMAL_AI_LIVE_FETCH':'0'})
 rows.append({'name':name,'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3)})
 (out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
(out/'outcome.json').write_text(json.dumps({'complete':True,'passed':all(x['exitCode']==0 for x in rows),'checks':rows},indent=2)+'\n')
