from pathlib import Path
import subprocess
out=Path('/tmp/issue-1580-research/supporting-source-batch-validation');out.mkdir(exist_ok=True)
for name,args in [('mirror',['node','scripts/mirror-package-data.mjs','--write']),('browser-seed',['bash','scripts/sync-seed.sh']),('status',['node','scripts/render-status.mjs','--write'])]:
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
 print(name,p.returncode)
 if p.returncode:raise SystemExit(p.returncode)
