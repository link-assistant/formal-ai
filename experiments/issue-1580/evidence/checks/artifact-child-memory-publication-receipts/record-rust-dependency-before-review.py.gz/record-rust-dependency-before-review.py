from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert (data['fullyReadFiles'], data['fullyReadSourceLines']) == (349, 44423)
path = 'dev/log/issues/247/pulls/248/dependencies-before.json'
raw = (scratch / 'templates/rust-complete' / path).read_bytes()
names = ['rust-dependencies-before-review-' + part + '.log' for part in ['first', 'second', 'third', 'fourth']]
chunks = []
for name in names:
    entries = [line.removeprefix('   RAW-CHUNK ') for line in (scratch / name).read_text().splitlines() if line.startswith('   RAW-CHUNK ')]
    assert len(entries) == 1
    chunks.append(json.loads(entries[0]).encode())
assert b''.join(chunks) == raw and len(raw.splitlines()) == 1510
identities = {row['path']: row for row in json.loads((root / data['all373BlobIdentitiesVerifiedBy']).read_text())}
digest = hashlib.sha256(raw).hexdigest()
assert identities[path]['sha256'] == digest
assert path not in {row['path'] for row in data['files']}
archive = root / 'experiments/issue-1580/evidence/checks/rust-source-review'
logs = json.loads((archive / 'logs.json').read_text())
for name in names:
    value = (scratch / name).read_bytes()
    packed = gzip.compress(value, mtime=0)
    assert not (archive / (name + '.gz')).exists()
    (archive / (name + '.gz')).write_bytes(packed)
    logs.append({'file': name + '.gz', 'rawSha256': hashlib.sha256(value).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest()})
(archive / 'logs.json').write_text(json.dumps(logs, indent=2) + '\n')
data['files'].append({'path': path, 'lines': 1510, 'sha256': digest, 'readLogs': [name + '.gz' for name in names], 'literalReadRanges': [[1, 1510]], 'literalReadLines': 1510, 'literalSourceFullyRead': True, 'formalAiPracticeImplementationVerified': False})
data['files'].sort(key=lambda row: row['path'])
data['fullyReadFiles'] = len(data['files'])
data['fullyReadSourceLines'] = sum(row['literalReadLines'] for row in data['files'])
assert (data['fullyReadFiles'], data['fullyReadSourceLines']) == (350, 45933)
data['observedAt'] = datetime.now(timezone.utc).isoformat()
data['practiceDecisions'].append({'practice': 'Keep manifest ranges, resolved locks, standalone script dependencies and historical dependency snapshots distinct', 'templateEvidence': [path], 'assessment': 'The complete 1,510-line historical before-update inventory is literally reviewed through four contiguous byte slices and reassembled to its pinned original identity. Cargo application and standalone script versions differ, and the historical syn duplicate and TOML API generations cannot be treated as one current application dependency graph. npm policy and secretlint lock transitives are separate from root manifest declarations; action tags, immutable commit references and empty detected-tool arrays carry different evidence. Preserve complete inventory collection and exact current lock/manifest checks rather than using this historical snapshot as current package, security or tool availability proof. Current published transitive consumers and release execution remain unverified by this source review.', 'status': 'literal-source-comparison-and-current-consumer-verification-pending'})
ledger.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps({'fullyReadFiles': 350, 'fullyReadSourceLines': 45933, 'remainingIdentities': 23, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}))
