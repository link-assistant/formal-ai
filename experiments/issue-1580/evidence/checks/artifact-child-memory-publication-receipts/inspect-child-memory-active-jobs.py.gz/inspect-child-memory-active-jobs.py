from pathlib import Path
from datetime import datetime, timezone
import json, subprocess

directory = Path('/tmp/issue-1580-research/child-memory-active-job-observation')
directory.mkdir(exist_ok=False)
for run_id in [44813110048, 44813086995]:
    argv = ['gh', 'run', 'view', str(run_id), '--repo', 'link-assistant/formal-ai', '--json', 'status,conclusion,headSha,jobs,url,createdAt,updatedAt']
    result = subprocess.run(argv, capture_output=True)
    (directory / (str(run_id) + '.stdout')).write_bytes(result.stdout)
    (directory / (str(run_id) + '.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0, result.stderr
    state = json.loads(result.stdout)
    assert state['headSha'] == '9fd9360d88d084aeee109ebf8375cde3cd816ff1'
    print(json.dumps({'observedAt': datetime.now(timezone.utc).isoformat(), 'run': run_id, 'status': state['status'], 'conclusion': state['conclusion'], 'jobs': [{'id': job['databaseId'], 'name': job['name'], 'status': job['status'], 'conclusion': job['conclusion'], 'startedAt': job['startedAt'], 'steps': [{'name': step['name'], 'status': step['status'], 'conclusion': step['conclusion']} for step in job['steps'] if step['status'] != 'completed' or step['conclusion'] not in ['success', 'skipped']]} for job in state['jobs']]}))
