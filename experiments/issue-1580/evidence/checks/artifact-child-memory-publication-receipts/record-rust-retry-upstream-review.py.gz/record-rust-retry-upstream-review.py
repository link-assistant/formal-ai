from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert (data['fullyReadFiles'], data['fullyReadSourceLines']) == (347, 44421)
identities = {row['path']: row for row in json.loads((root / data['all373BlobIdentitiesVerifiedBy']).read_text())}
archive = root / 'experiments/issue-1580/evidence/checks/rust-source-review'
logs = json.loads((archive / 'logs.json').read_text())
paths = []
for subject, parts in [('lychee', ['first', 'second']), ('buildx', ['first', 'second', 'third'])]:
    path = 'dev/log/issues/247/pulls/248/' + subject + '-upstream.json'
    raw = (scratch / 'templates/rust-complete' / path).read_bytes()
    names = ['rust-' + subject + '-upstream-review-' + part + '.log' for part in parts]
    chunks = []
    for name in names:
        entries = [line.removeprefix('   RAW-CHUNK ') for line in (scratch / name).read_text().splitlines() if line.startswith('   RAW-CHUNK ')]
        assert len(entries) == 1
        chunks.append(json.loads(entries[0]).encode())
    assert b''.join(chunks) == raw and len(raw.splitlines()) == 1
    digest = hashlib.sha256(raw).hexdigest()
    assert identities[path]['sha256'] == digest
    assert path not in {row['path'] for row in data['files']}
    for name in names:
        value = (scratch / name).read_bytes()
        packed = gzip.compress(value, mtime=0)
        assert not (archive / (name + '.gz')).exists()
        (archive / (name + '.gz')).write_bytes(packed)
        logs.append({'file': name + '.gz', 'rawSha256': hashlib.sha256(value).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest()})
    data['files'].append({'path': path, 'lines': 1, 'sha256': digest, 'readLogs': [name + '.gz' for name in names], 'literalReadRanges': [[1, 1]], 'literalReadLines': 1, 'literalSourceFullyRead': True, 'formalAiPracticeImplementationVerified': False})
    paths.append(path)
(archive / 'logs.json').write_text(json.dumps(logs, indent=2) + '\n')
data['files'].sort(key=lambda row: row['path'])
data['fullyReadFiles'] = len(data['files'])
data['fullyReadSourceLines'] = sum(row['literalReadLines'] for row in data['files'])
assert (data['fullyReadFiles'], data['fullyReadSourceLines']) == (349, 44423)
data['observedAt'] = datetime.now(timezone.utc).isoformat()
data['practiceDecisions'].append({'practice': 'Distinguish transient connection phases and registry bootstrap boundaries before adding bounded workflow retries', 'templateEvidence': paths, 'assessment': 'Both complete historical upstream issue bodies and every captured comment are literally reviewed through contiguous exact byte ranges; each original one-line JSON blob is reassembled and identity-verified. Lychee 2297 distinguishes connect/TLS resets, established requests and wrapped io::Error kinds; the captured maintainer independently reproduces the HTTPS reset but reports different HTTP behavior. Raising a retry count does not repair a classifier that never enters retries. The complete Docker setup-buildx 510 workflow and daemon log locate failure at the action bootstrap pull; maintainer feedback warns that action-local backoff can worsen registry throttling and later points to PR 609. Formal AI retains a bounded actual-setup mirror recovery with pinned image identity rather than assuming a pre-pull bypasses bootstrap. Existing finite shared-budget link rechecks preserve permanent-status failures. These historical issue states and claims do not establish current upstream publication, all present runtime cases, successful application image delivery or complete-practice qualification.', 'status': 'literal-source-comparison-and-current-consumer-verification-pending'})
ledger.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps({'fullyReadFiles': 349, 'fullyReadSourceLines': 44423, 'remainingIdentities': 24, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}))
