from pathlib import Path
import json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
old = Path('/tmp/issue-1580-research/feedback-after-child-memory-repair')
out = Path('/tmp/issue-1580-research/artifact-child-memory-publication/fresh-feedback')
out.mkdir(exist_ok=False)
requests = [('issue', ['gh', 'issue', 'view', 'https://github.com/link-assistant/formal-ai/issues/1580', '--json', 'title,body,updatedAt']), ('issue-comments', ['gh', 'api', 'repos/link-assistant/formal-ai/issues/1580/comments', '--paginate']), ('pull-comments', ['gh', 'api', 'repos/link-assistant/formal-ai/issues/1581/comments', '--paginate']), ('inline-comments', ['gh', 'api', 'repos/link-assistant/formal-ai/pulls/1581/comments', '--paginate']), ('reviews', ['gh', 'api', 'repos/link-assistant/formal-ai/pulls/1581/reviews', '--paginate'])]
for name, args in requests:
    result = subprocess.run(args, cwd=root, capture_output=True)
    (out / (name + '.stdout')).write_bytes(result.stdout)
    (out / (name + '.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0
    actual = json.loads(result.stdout)
    previous = json.loads((old / (name + '.stdout')).read_text())
    assert actual == previous, 'New feedback requires literal review: ' + name
    print(name, 'unchanged', len(actual) if isinstance(actual, list) else actual['updatedAt'])
