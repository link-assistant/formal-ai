from pathlib import Path
import json, re, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
directory = Path('/tmp/issue-1580-research/current-size-warning-inventory-second')
directory.mkdir(exist_ok=False)
inventory = subprocess.run(['git', 'ls-files', '-z'], cwd=root, capture_output=True, check=True)
(directory / 'tracked-files.bin').write_bytes(inventory.stdout)
code = "import {checkListedFiles} from './scripts/check-file-size.mjs'; import {readFileSync} from 'node:fs'; const listed=new Set(readFileSync('/tmp/issue-1580-research/current-size-warning-inventory-second/tracked-files.bin','utf8').split('\\0').filter(Boolean)); process.stdout.write(JSON.stringify(checkListedFiles(process.cwd(),listed)));"
result = subprocess.run(['node', '--max-old-space-size=256', '--input-type=module', '-e', code], cwd=root, capture_output=True)
(directory / 'stdout.json').write_bytes(result.stdout)
(directory / 'stderr.log').write_bytes(result.stderr)
assert result.returncode == 0, result.stderr
data = json.loads(result.stdout)
assert not data['violations'] and not data['embeddedDataViolations']
for row in data['warnings']:
    path = root / row['file']
    text = path.read_text()
    cfg = [index for index, line in enumerate(text.splitlines(), 1) if line == '#[cfg(test)]']
    print(row['lines'], row['file'], 'test-module-lines=' + str(cfg))
print(json.dumps({'warnings': len(data['warnings']), 'violations': 0, 'fullIssueComplete': False}))
