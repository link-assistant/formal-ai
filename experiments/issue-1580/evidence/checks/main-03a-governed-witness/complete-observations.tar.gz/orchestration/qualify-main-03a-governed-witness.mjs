// Supplied reviewed merge qualification; zero independent authorship credit.
import assert from 'node:assert/strict';
import {execFileSync,spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync} from 'node:fs';
import {deserialize} from 'node:v8';
import {gunzipSync} from 'node:zlib';
const dir='/tmp/issue-1580-research/main-03a-governed-witness';
const file='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8';
const sha=x=>createHash('sha256').update(x).digest('hex');
const beforeBytes=gunzipSync(readFileSync(dir+'/stage-2.v8.gz')),before=deserialize(beforeBytes);
const candidateBytes=readFileSync(dir+'/candidate.v8'),after=deserialize(candidateBytes);
const keyed=JSON.parse(readFileSync(dir+'/keyed-difference-report.json'));
const inventory=structuredClone(after.inventory);
assert.equal(sha(readFileSync(file)),sha(beforeBytes));
const hashes=new Map([
 ['repo:rust/tests/unit/specification/chat_surface.rs',['460bc846ff0e7fe419315c433e9fcf4bc20c4a2e8eeb18e2dae240792e9bb5dc','dd73a316f6992dfc213d44381781c1cf8be22e4fcf2502a8f16d482e72f4cd46',6]],
 ['repo:rust/Cargo.toml',['2ebef87d696cd4f5e39c03d48e949ef6c50b9e73cf3a7f2d4020c49857e24007','56756d4b598a1b22ae1cb0ffd9ba4e4926e9a8eb308e635d6e9f1be6172575b5',4]]
]);
const counts=new Map();
for(let i=0;i<inventory.cases.length;i++)for(let j=0;j<(inventory.cases[i].program?.fixtures??[]).length;j++){
 const old=before.inventory.cases[i].program.fixtures[j],fixture=inventory.cases[i].program.fixtures[j];
 if(fixture.sha256===old.sha256)continue;
 const approved=hashes.get(fixture.file);assert.ok(approved);assert.equal(old.file,fixture.file);
 assert.equal(old.sha256,approved[0]);assert.equal(fixture.sha256,approved[1]);
 assert.equal(sha(readFileSync(fixture.file.slice(5))),approved[1]);
 fixture.sha256=old.sha256;counts.set(fixture.file,(counts.get(fixture.file)??0)+1);
}
for(const [name,approved] of hashes)assert.equal(counts.get(name),approved[2]);
const ids=new Map([
 ['rust/tests/unit/specification/chat_surface.rs::self_facts_answer_includes_model_id_and_strategy','rust/tests/unit/specification/chat_surface/rule_details.rs::self_facts_answer_includes_model_id_and_strategy'],
 ['rust/tests/unit/specification/chat_surface.rs::behavior_rule_detail_uses_describe_prefix','rust/tests/unit/specification/chat_surface/rule_details.rs::behavior_rule_detail_uses_describe_prefix'],
 ['rust/tests/unit/specification/chat_surface.rs::behavior_rule_detail_uses_read_rule_prefix','rust/tests/unit/specification/chat_surface/rule_details.rs::behavior_rule_detail_uses_read_rule_prefix'],
 ['rust/tests/unit/specification/debug_session.rs::calculator_folding_retains_each_origin_and_clears_it_between_clusters','rust/tests/unit/specification/debug_session/calculator_origins.rs::calculator_folding_retains_each_origin_and_clears_it_between_clusters']
]);
assert.equal(keyed.removedUnsupported.length,4);assert.equal(keyed.addedUnsupported.length,4);
const reverse=new Map([...ids].map(([a,b])=>[b,a]));
for(const item of inventory.unsupported)if(reverse.has(item.id))item.id=reverse.get(item.id);
const sort=x=>[...x].sort((a,b)=>a.id.localeCompare(b.id));
assert.deepEqual(sort(inventory.unsupported),sort(before.inventory.unsupported));
inventory.unsupported=before.inventory.unsupported;
assert.deepEqual(inventory,before.inventory,'No supported or unsupported behavior object may change');
assert.deepEqual(keyed.sourceChanges.map(x=>x.after.path),[
 'rust/tests/unit/specification/chat_surface.rs','rust/tests/unit/specification/chat_surface/rule_details.rs',
 'rust/tests/unit/specification/debug_session.rs','rust/tests/unit/specification/debug_session/calculator_origins.rs']);
const oldSources=new Map(before.sourceManifest.map(x=>[x.path,x]));
assert.equal(after.sourceManifest.length,before.sourceManifest.length+2);
for(const source of after.sourceManifest){
 assert.equal(source.sha256,sha(readFileSync(source.path)));
 if(!keyed.sourceChanges.some(x=>x.after.path===source.path))assert.deepEqual(source,oldSources.get(source.path));
}
const test='rust/tests/web/rust-specification-unicode-identifiers.test.mjs';
function run(label,args){
 const result=spawnSync(process.execPath,['--max-old-space-size=256',...args],{encoding:'utf8',maxBuffer:4*1024*1024});
 writeFileSync(dir+'/'+label+'.stdout',result.stdout??'');writeFileSync(dir+'/'+label+'.stderr',result.stderr??'');
 return result;
}
const failed=run('before',['--test','--test-concurrency=1',test]);assert.notEqual(failed.status,0);
const readerSha=sha(readFileSync('scripts/lib/rust-specification-cases.mjs'));
assert.equal(readerSha,'861c6c5b40cfc8f4e99ad0ebece2cc3c20f941c6a1103dd5e8e70813c40ee0ca');
assert.equal(run('refresh',[test,'--refresh-reviewed-baseline','--reviewed-reader-sha='+readerSha,'--previous-baseline-sha='+sha(beforeBytes)]).status,0);
assert.deepEqual(deserialize(readFileSync(file)),after);
assert.equal(run('after',['--test','--test-concurrency=1',test]).status,0);
const proof={mainVersionOnlyOccurrences:4,supportedCasesPreserved:before.inventory.cases.length,unsupportedCasesPreserved:before.inventory.unsupported.length,approvedFixtureHashOccurrences:Object.fromEntries(counts),movedUnsupportedIdentities:[...ids],sourceChanges:keyed.sourceChanges,otherCompleteObjectsUnchanged:true,regressionFailsBefore:true,regressionPassesAfter:true,beforeSha256:sha(beforeBytes),afterSha256:sha(readFileSync(file)),readerSha256:readerSha,independentAuthorshipCredit:0,nativeBehaviorVerified:false};
writeFileSync(dir+'/complete-conservation.json',JSON.stringify(proof,null,2)+'\n');
console.log(JSON.stringify(proof,null,2));
