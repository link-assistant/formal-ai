import {readFileSync,writeFileSync} from 'node:fs';
import {deserialize} from 'node:v8';
import {gunzipSync} from 'node:zlib';
const root='/tmp/issue-1580-research/main-03a-governed-witness';
const a=deserialize(gunzipSync(readFileSync(root+'/stage-2.v8.gz'))),b=deserialize(readFileSync(root+'/candidate.v8'));
const fixtureChanges=[];
for(let i=0;i<a.inventory.cases.length;i++)for(let j=0;j<(a.inventory.cases[i].program?.fixtures??[]).length;j++){
 const old=a.inventory.cases[i].program.fixtures[j],value=b.inventory.cases[i].program.fixtures[j];
 if(JSON.stringify(old)!==JSON.stringify(value))fixtureChanges.push({case:a.inventory.cases[i].id,index:i,fixture:j,before:old,after:value});
}
const oldSources=new Map(a.sourceManifest.map(x=>[x.path,x]));
const sourceChanges=b.sourceManifest.filter(x=>JSON.stringify(oldSources.get(x.path))!==JSON.stringify(x)).map(x=>({before:oldSources.get(x.path)??null,after:x}));
const oldIds=new Set(a.inventory.unsupported.map(x=>x.id)),newIds=new Set(b.inventory.unsupported.map(x=>x.id));
const value={fixtureChanges,sourceChanges,removedUnsupported:a.inventory.unsupported.filter(x=>!newIds.has(x.id)),addedUnsupported:b.inventory.unsupported.filter(x=>!oldIds.has(x.id)),inventoryKeys:Object.keys(a.inventory)};
writeFileSync(root+'/keyed-difference-report.json',JSON.stringify(value,null,2)+'\n');console.log(JSON.stringify(value,null,2));
