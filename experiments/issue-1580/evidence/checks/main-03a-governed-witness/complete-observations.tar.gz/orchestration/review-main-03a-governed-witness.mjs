// Supplied merge review procedure; zero independent authorship credit.
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {mkdirSync,readFileSync,readdirSync,writeFileSync} from 'node:fs';
import {isAbsolute,relative,resolve} from 'node:path';
import {deserialize,serialize} from 'node:v8';
import {gzipSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
const root=process.cwd();
const out='/tmp/issue-1580-research/main-03a-governed-witness';
mkdirSync(out,{recursive:false});
const {specificationCases}=await import(pathToFileURL(resolve(root,'scripts/lib/rust-specification-cases.mjs')));
const {scalarDifferenceReport}=await import(pathToFileURL(resolve(root,'scripts/lib/regenerate-governed-specification.mjs')));
const {validateVersionWitness}=await import(pathToFileURL(resolve(root,'scripts/refresh-release-specification-witness.mjs')));
const file='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8';
const git=(...args)=>execFileSync('git',args,{maxBuffer:8*1024*1024});
const hash=x=>createHash('sha256').update(x).digest('hex');
const base=git('merge-base','HEAD','MERGE_HEAD').toString().trim();
const before=[1,2,3].map(stage=>git('show',':'+stage+':'+file));
for(let i=0;i<3;i++)writeFileSync(resolve(out,'stage-'+(i+1)+'.v8.gz'),gzipSync(before[i],{mtime:0}));
const versionChanges=validateVersionWitness(before[0],before[2],git('show',base+':rust/Cargo.toml').toString(),git('show','MERGE_HEAD:rust/Cargo.toml').toString());
const inventory=specificationCases(root),cases=structuredClone(inventory.cases);
for(const item of cases)for(const fixture of item.program?.fixtures??[])if(isAbsolute(fixture.file)){
 const name=relative(root,fixture.file);assert(!name.startsWith('..'));fixture.file='repo:'+name;
}
const sourceManifest=readdirSync(resolve(root,'rust/tests/unit/specification'),{recursive:true}).map(String).filter(x=>x.endsWith('.rs')).sort().map(name=>{
 const path='rust/tests/unit/specification/'+name;return {path,sha256:hash(readFileSync(resolve(root,path)))};
});
const candidate={inventory:{...inventory,cases},sourceManifest};
writeFileSync(resolve(out,'candidate.v8'),serialize(candidate));
const report={base,versionChanges,stageSha256:before.map(hash),candidateSha256:hash(serialize(candidate)),oursToCandidate:scalarDifferenceReport(deserialize(before[1]),candidate),oursCases:deserialize(before[1]).inventory.cases.length,candidateCases:cases.length,oursSources:deserialize(before[1]).sourceManifest.length,candidateSources:sourceManifest.length,independentAuthorshipCredit:0};
writeFileSync(resolve(out,'complete-difference-report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
