from pathlib import Path
import gzip, re

path = Path('/tmp/gh-issue-solver-1794900398048/experiments/issue-1580/evidence/ci/native-families-27e895c1/failed-run-44860043349.stdout.gz')
lines = gzip.decompress(path.read_bytes()).decode().splitlines()
print(f'Original complete log: {len(lines)} lines; selected failure contexts follow')
selected = set()
pattern = re.compile(r'##\[error\]|not ok|AssertionError|Error:|FAIL(?:ED)?|✗|❌')
for index, line in enumerate(lines):
    if pattern.search(line):
        selected.update(range(max(0, index - 7), min(len(lines), index + 18)))
for index in sorted(selected):
    print(f'{index + 1}: {lines[index]}')
