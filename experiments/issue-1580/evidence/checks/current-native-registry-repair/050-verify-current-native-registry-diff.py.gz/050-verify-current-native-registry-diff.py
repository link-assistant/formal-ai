from pathlib import Path
import hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/current-native-registry-repair')
registry = 'scripts/lib/generated-native-programs.mjs'
before = subprocess.check_output(['git', 'show', 'HEAD:' + registry], cwd=root)
after = (root / registry).read_bytes()
source = 'rust/src/history_context.rs'
old_digest = '5c25bf3d437bcc38706cfa4df26646c387d28b2fb6125490aebd4fb105a1f6d2'
new_digest = hashlib.sha256((root / source).read_bytes()).hexdigest()
assert new_digest == 'fa172c224884ab204307d90a936a6a8cbe446615a34ecc1dbd06c633a73497cc'
assert before.count(old_digest.encode()) == 2
assert before.replace(old_digest.encode(), new_digest.encode()) == after
assert (out / 'registry-before.mjs').read_bytes() == before
history = subprocess.check_output(['git', 'log', '-5', '--format=%H %s', '--', source, registry], cwd=root)
(out / 'source-history.stdout').write_bytes(history)
(out / 'regeneration.json').write_text(json.dumps({'generator': ['node', '--max-old-space-size=256', 'scripts/lib/generate-native-specification-programs.mjs'], 'generatorExitCode': 0, 'source': source, 'oldRegistrySha256': hashlib.sha256(before).hexdigest(), 'newRegistrySha256': hashlib.sha256(after).hexdigest(), 'oldSourceWitnessSha256': old_digest, 'newSourceWitnessSha256': new_digest, 'sourceWitnessChanges': 2, 'onlySourceDigestChanged': True, 'initialPublicRootHypothesisRejected': True, 'failedHelperAttemptsRetained': True, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
print((out / 'regeneration.json').read_text())
