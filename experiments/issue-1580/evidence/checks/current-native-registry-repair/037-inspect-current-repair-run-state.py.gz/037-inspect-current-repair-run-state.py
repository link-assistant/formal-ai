from pathlib import Path
from datetime import datetime, timezone
import json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/current-native-registry-repair')
for rid in [44860043477, 44860038851]:
    result = subprocess.run(['gh', 'run', 'view', str(rid), '--repo', 'link-assistant/formal-ai', '--json', 'headSha,status,conclusion,jobs,url'], cwd=root, capture_output=True)
    (out / f'run-state-{rid}.stdout').write_bytes(result.stdout)
    (out / f'run-state-{rid}.stderr').write_bytes(result.stderr)
    assert result.returncode == 0
    state = json.loads(result.stdout)
    assert state['headSha'] == '27e895c1103926b4f73862c0eb15fa77fb505089'
    print(json.dumps({'observedAt': datetime.now(timezone.utc).isoformat(), 'url': state['url'], 'status': state['status'], 'conclusion': state['conclusion'], 'jobs': [{'name': job['name'], 'status': job['status'], 'conclusion': job['conclusion'], 'activeStep': [step['name'] for step in job['steps'] if step['status'] == 'in_progress']} for job in state['jobs']]}))
