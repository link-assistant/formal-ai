from pathlib import Path
import json, subprocess, hashlib

root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/current-native-registry-repair')
assert (out / 'reproduction.json').exists()
assert 'generated registry is stale' in (out / 'before-currency.stderr').read_text()
registry = root / 'scripts/lib/generated-native-programs.mjs'
before = registry.read_bytes()
(out / 'registry-before.mjs').write_bytes(before)
command = ['node', '--max-old-space-size=256', 'scripts/lib/generate-native-specification-programs.mjs']
result = subprocess.run(command, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(out / 'generate.stdout').write_bytes(result.stdout)
(out / 'generate.stderr').write_bytes(result.stderr)
assert result.returncode == 0
after = registry.read_bytes()
diff = subprocess.check_output(['git', 'diff', '--', 'scripts/lib/generated-native-programs.mjs'], cwd=root)
(out / 'registry.diff').write_bytes(diff)
source = root / 'rust/src/lib.rs'
old = subprocess.check_output(['git', 'show', 'bd6fe77b:rust/src/lib.rs'], cwd=root)
old_digest = hashlib.sha256(old).hexdigest()
new_digest = hashlib.sha256(source.read_bytes()).hexdigest()
assert old_digest != new_digest
assert old_digest.encode() in before
assert before.replace(old_digest.encode(), new_digest.encode()) == after
(out / 'regeneration.json').write_text(json.dumps({'command': command, 'exitCode': result.returncode, 'oldRegistrySha256': hashlib.sha256(before).hexdigest(), 'newRegistrySha256': hashlib.sha256(after).hexdigest(), 'oldPublicRootSha256': old_digest, 'newPublicRootSha256': new_digest, 'publicRootWitnessChanges': before.count(old_digest.encode()), 'onlyPublicRootDigestChanged': True, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
print((out / 'regeneration.json').read_text())
