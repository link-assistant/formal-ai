from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'current-native-registry-repair'
archive = root / 'experiments/issue-1580/evidence/checks/current-native-registry-repair'
assert not archive.exists()
proof = json.loads((out / 'regeneration.json').read_text())
assert proof['onlySourceDigestChanged'] and proof['sourceWitnessChanges'] == 2
before = json.loads((out / 'reproduction.json').read_text())
assert next(row for row in before['records'] if row['name'] == 'before-currency')['exitCode'] == 1
assert 'ℹ pass 5' in (out / 'focused-suite.log').read_text()
stems = ['inspect-repaired-layered-failure', 'reproduce-current-native-registry',
         'regenerate-current-native-registry', 'verify-current-native-registry-diff',
         'commit-current-native-registry', 'inspect-current-repair-run-state',
         'seal-current-native-registry-repair']
sources = {p for p in out.iterdir() if p.is_file()}
for stem in stems:
    sources.update(p for p in scratch.glob(stem + '*') if p.is_file())
for name in ['repaired-layered-failure-context.log', 'reproduce-current-native-registry-retry.log',
             'regenerate-current-native-registry-retry.log']:
    p = scratch / name
    if p.is_file():
        sources.add(p)
for p in (root / 'experiments/issue-1580/evidence/commands').glob('*.json'):
    command = json.loads(p.read_text())
    if any(stem in command.get('request', '') for stem in stems):
        sources.add(p)
archive.mkdir()
inventory = []
for number, p in enumerate(sorted(sources), 1):
    raw = p.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    name = f'{number:03d}-' + p.name + '.gz'
    (archive / name).write_bytes(packed)
    assert gzip.decompress((archive / name).read_bytes()) == raw
    inventory.append({'source': str(p), 'file': name, 'bytes': len(raw),
                      'lines': len(raw.splitlines()),
                      'rawSha256': hashlib.sha256(raw).hexdigest(),
                      'archiveSha256': hashlib.sha256(packed).hexdigest()})
parts = []
for first in range(0, len(inventory), 35):
    name = f'inventory-{first // 35 + 1:02d}.json'
    raw = (json.dumps(inventory[first:first + 35], indent=2) + '\n').encode()
    (archive / name).write_bytes(raw)
    parts.append({'file': name, 'records': len(inventory[first:first + 35]),
                  'sha256': hashlib.sha256(raw).hexdigest()})
outcome = {'observedAt': datetime.now(timezone.utc).isoformat(),
           'publishedHead': '27e895c1103926b4f73862c0eb15fa77fb505089',
           'localRepairHead': '858943eb676fe2e68dc51b7cccefa157169c21a0',
           'failedRun': 44860043349, 'beforeCurrencyExit': 1,
           'onlySourceWitnessesChanged': True, 'witnesses': 2,
           'focusedTestsPassed': 5, 'retainedSources': len(inventory),
           'allArchiveIdentitiesVerified': True,
           'wholeFailureLogLiterallyReviewed': False,
           'localNativeExecution': False, 'hostedRepairQualificationPending': True,
           'initialFailedHelpersRetained': True,
           'independentAuthorshipCredit': 0, 'fullIssueComplete': False}
(archive / 'inventory.json').write_text(json.dumps({'records': len(inventory), 'parts': parts}, indent=2) + '\n')
(archive / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
checkpoint = '''# Generated native source witness repair

At published head `27e895c1103926b4f73862c0eb15fa77fb505089`,
[Layered CI 44860043349](https://github.com/link-assistant/formal-ai/actions/runs/44860043349)
fails its existing generated-program currency assertion. Full-log lines
7015–7023 and 8073–8102 identify the generator check, rather than a native
compiler failure. The original 12,774-line log remains retained; only targeted
contexts have been literally reviewed.

The previous current-source QA repair changed `rust/src/history_context.rs`.
Two generated source witnesses still referenced its earlier digest. The
maintained generator's `--check` reproduces the failure before repair. Its
normal generation changes exactly those two hashes in
`scripts/lib/generated-native-programs.mjs`, with no program or public-root
change. An exact before/after substitution proof and original registry are
retained. The existing generated-program suite then passes all five cases,
including currency, substitutions, literal refusal and semantic contracts.
The focused run takes 16.272 seconds, with a 256 MiB JavaScript heap.

An initial search incorrectly required a match; another helper read its
dependency before the earlier command completed. A provisional public-root
hypothesis was rejected by the actual diff. The first archive helper also
expected an absent summary key before reading the retained record structure.
These failed helper attempts are
retained separately. They provide no product-failure or independent-reasoning
credit. The local repair commit is
`858943eb676fe2e68dc51b7cccefa157169c21a0`; it has not been pushed while the
remaining workflows on the published head are running. Hosted repair
qualification, full template practice comparison and the wider issue remain
unfinished. No native build or execution was performed locally.

Evidence: `experiments/issue-1580/evidence/checks/current-native-registry-repair/`.
'''
(root / 'docs/case-studies/issue-1580/generated-native-registry-repair-checkpoint.md').write_text(checkpoint)
p = root / 'experiments/issue-1580/work-plan.md'
text = p.read_text()
marker = '## Current verification checkpoint\n\n'
assert text.count(marker) == 1
text = text.replace(marker, marker + 'New local repair: [generated source witness checkpoint](../../docs/case-studies/issue-1580/generated-native-registry-repair-checkpoint.md). The current published head is `27e895c1`; its final Pipeline and Security results are still being collected before the next push. The fully collected prior-head account follows.\n\n', 1)
p.write_text(text)
print(json.dumps(outcome, indent=2))
