from pathlib import Path
import json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/current-native-registry-repair')
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip() == 'issue-1580-8d61a32a61e1'
proof = json.loads((out / 'regeneration.json').read_text())
assert proof['onlySourceDigestChanged'] and proof['sourceWitnessChanges'] == 2
log = (out / 'focused-suite.log').read_text()
assert 'ℹ pass 5' in log and 'ℹ fail 0' in log and log.rstrip().endswith('Exit Code: 0')
for name, command in [
    ('whitespace', ['git', 'diff', '--check']),
    ('stage', ['git', 'add', '--', 'scripts/lib/generated-native-programs.mjs']),
    ('commit', ['git', 'commit', '-m', 'fix: refresh native history constant source witnesses']),
]:
    result = subprocess.run(command, cwd=root, capture_output=True)
    (out / (name + '.stdout')).write_bytes(result.stdout)
    (out / (name + '.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0, (name, result.stderr.decode(errors='replace'))
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
(out / 'commit.json').write_text(json.dumps({'head': head, 'pushed': False, 'focusedTestsPassed': 5, 'fullIssueComplete': False}, indent=2) + '\n')
print((out / 'commit.json').read_text())
