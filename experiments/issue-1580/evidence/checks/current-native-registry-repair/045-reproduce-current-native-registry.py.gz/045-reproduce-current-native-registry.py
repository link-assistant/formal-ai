from pathlib import Path
import hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/current-native-registry-repair')
out.mkdir(exist_ok=True)
commands = [
    ('source-and-gate-search', ['rg', '-n', 'generate-native-specification|generated-native-programs|native-registry', 'experiments/formal_ai_subagent/local-gates.mjs', 'scripts/lib/native-record-registry.mjs', 'scripts/lib/native-scalar-registry.mjs', 'scripts/lib/native-option-registry.mjs', 'scripts/lib/native-constant-registry.mjs']),
    ('before-currency', ['node', '--max-old-space-size=256', 'scripts/lib/generate-native-specification-programs.mjs', '--check']),
]
records = []
for name, command in commands:
    result = subprocess.run(command, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    for stream in ['stdout', 'stderr']:
        (out / (name + '.' + stream)).write_bytes(getattr(result, stream))
    records.append({'name': name, 'command': command, 'exitCode': result.returncode})
assert records[0]['exitCode'] in (0, 1)
assert records[1]['exitCode'] != 0
assert b'generated registry is stale' in (out / 'before-currency.stderr').read_bytes()
(out / 'reproduction.json').write_text(json.dumps({'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'records': records, 'oldRegistrySha256': hashlib.sha256((root / 'scripts/lib/generated-native-programs.mjs').read_bytes()).hexdigest()}, indent=2) + '\n')
print(json.dumps(records))
