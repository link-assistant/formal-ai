import gzip, hashlib, json, re, subprocess
from pathlib import Path
root=Path('/tmp/issue-1580-research')
directory=root/'observation-repair-head-ci'
pattern=re.compile(r'(test_(?:waiter|fragment|invalid_fragment|each_output|version_check|collect_and_bump|release_change|release_cli)|(?:insertion|collection)_ignores_fenced|strict.*heading|heading.*offset|Ran [0-9]+ tests|test result:)')
observations=[]
for path in sorted(directory.glob('*.gz')):
    if path.name.startswith(('complete-jobs','failed-jobs','pull-request-checks','runs-')):continue
    rows=[]
    with gzip.open(path,'rt',errors='replace') as stream:
        for number,line in enumerate(stream,1):
            if pattern.search(line):
                rows.append({'line':number,'text':line.rstrip('\n')})
    if rows:
        observations.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'observations':rows})
output=root/'hosted-practice-qualification-observations.json'
output.write_text(json.dumps(observations,indent=2)+'\n')
print(json.dumps(observations,indent=2))
