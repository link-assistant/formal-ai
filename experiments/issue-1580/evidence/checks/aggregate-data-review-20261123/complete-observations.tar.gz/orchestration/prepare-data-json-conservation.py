from pathlib import Path
import collections,hashlib,json,subprocess
r=Path('/tmp/issue-1580-research');o=r/'aggregate-data-review-bc08'
inv=json.loads((o/'inventory.json').read_text())
def nodup(pairs):
 d={}
 for k,v in pairs:
  if k in d:raise ValueError('Duplicate JSON key: '+k)
  d[k]=v
 return d
def delta(a,b,path=''):
 if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
 if isinstance(a,dict):
  out=[]
  for k in sorted(a.keys()|b.keys()):
   p=path+'/'+k
   if k not in a:out.append({'path':p,'after':b[k],'added':True})
   elif k not in b:out.append({'path':p,'before':a[k],'removed':True})
   else:out+=delta(a[k],b[k],p)
  return out
 if a!=b:return [{'path':path,'before':a,'after':b}]
 return []
proof=[]
for path in inv['paths']:
 if not path.endswith('.json'):continue
 a=subprocess.run(['git','show',inv['base']+':'+path],capture_output=True)
 b=subprocess.check_output(['git','show',inv['source']+':'+path])
 if a.returncode:continue
 av=json.loads(a.stdout,object_pairs_hook=nodup);bv=json.loads(b,object_pairs_hook=nodup)
 changes=delta(av,bv)
 proof.append({'path':path,'duplicateKeysRejected':True,'oldBytesSha256':hashlib.sha256(a.stdout).hexdigest(),'newBytesSha256':hashlib.sha256(b).hexdigest(),'canonicalStructureEqual':av==bv,'changes':changes})
(o/'json-conservation.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n')
target='data/parity/issue-1584-cnl-infeasible.json'
item=next(x for x in proof if x['path']==target)
print('JSON_CNL',json.dumps(item,ensure_ascii=False))
ls=(o/'compact.diff').read_text().splitlines(keepends=True);new=[];hide=False
for s in ls:
 if s.startswith('diff --git '):
  hide=(' a/'+target+' b/'+target+'\n') in s
  if hide:new.append(' [JSON structural conservation: '+target+'; full exact leaf changes in json-conservation.json]\n')
 if not hide:new.append(s)
(o/'compact-v2.diff').write_text(''.join(new))
for i in range(0,len(new),300):(o/('v2-%03d.diff'%(i//300))).write_text(''.join(new[i:i+300]))
print('V2_LINES',len(new),'CHUNKS',(len(new)+299)//300)
for i,s in enumerate(new):
 if s.startswith('diff --git '):print('SECTION',i//300,s.strip())
print('CI');print('\n'.join((r/'apt-repair-head-ci-worker-restart.log').read_text().splitlines()[-2:]))
