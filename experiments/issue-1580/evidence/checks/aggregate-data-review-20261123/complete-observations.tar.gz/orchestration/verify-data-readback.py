from pathlib import Path
import collections,hashlib,json,re,subprocess
root=Path('/tmp/issue-1580-research/aggregate-data-review-bc08')
inv=json.loads((root/'inventory.json').read_text())
proof=json.loads((root/'conservation-proof.json').read_text())
base,head=inv['base'],inv['source']
cache={}
def show(rev,path,missing=False):
 key=(rev,path)
 if key not in cache:
  p=subprocess.run(['git','show',rev+':'+path],capture_output=True)
  if p.returncode:
   if missing:return None
   raise RuntimeError('git show failed '+rev+':'+path)
  cache[key]=p.stdout
 return cache[key]
def sha(b):return hashlib.sha256(b).hexdigest()
paths=inv['paths']
assert len(paths)==len(set(paths))==51
complete=subprocess.check_output(['git','diff','--no-ext-diff','--unified=3',base,head,'--',*paths])
assert complete==(root/'complete.diff').read_bytes()
assert len(complete)==inv['bytes'] and sha(complete)==inv['sha256']
bindings=[]
for path in paths:
 before=show(base,path,True);after=show(head,path)
 bindings.append({'path':path,'oldSha256':sha(before) if before is not None else None,'newSha256':sha(after)})
def record(rev,item):
 ls=show(rev,item['path']).decode().splitlines(keepends=True)
 start,end=item['start']-1,item['end']
 assert 0<=start<end<=len(ls)
 assert re.match(r'^  [^ #]',ls[start])
 parent=None
 for line in ls[:start]:
  text=line.rstrip('\r\n')
  if text and not text.startswith((' ','#')):parent=text
 raw=''.join(ls[start:end]).encode()
 assert len(raw)==item['bytes'] and sha(raw)==item['sha256']
 assert end==len(ls) or (ls[end].strip() and not ls[end].startswith('#') and (not ls[end].startswith(' ') or re.match(r'^  [^ #]',ls[end])))
 assert not any(line.strip() and not line.startswith('#') and (not line.startswith(' ') or re.match(r'^  [^ #]',line)) for line in ls[start+1:end])
 return parent,raw
oldmap={};newmap={};ids=set()
for p in proof['records']:
 assert p['id'] not in ids;ids.add(p['id'])
 a,b=record(base,p['old']),record(head,p['new'])
 assert a==b and a[0]==p['root'] and p['old']['path']!=p['new']['path'] and p['exactBytesEqual']
 for item,mapping in [(p['old'],oldmap),(p['new'],newmap)]:
  for line in range(item['start'],item['end']+1):
   key=(item['path'],line)
   assert key not in mapping
   mapping[key]=p['id']
# Rebuild every omitted diff line from independently verified intervals.
compact=[];oldpath=newpath='';ol=nl=0;pending=None;covered=0
def flush():
 global pending
 if pending is not None:
  compact.append(' [EXACT COMPLETE SEED RECORD %s; %s diff lines; see conservation-proof.json]\n'%pending)
  pending=None
for line in complete.decode().splitlines(keepends=True):
 if line.startswith('--- a/'):oldpath=line[6:].rstrip('\n')
 if line.startswith('+++ b/'):newpath=line[6:].rstrip('\n')
 match=re.match(r'^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@',line)
 if match:ol,nl=map(int,match.groups())
 identity=None
 if line.startswith('-') and not line.startswith('---'):
  identity=oldmap.get((oldpath,ol));ol+=1
 elif line.startswith('+') and not line.startswith('+++'):
  identity=newmap.get((newpath,nl));nl+=1
 elif line.startswith(' '):ol+=1;nl+=1
 if identity is None:flush();compact.append(line)
 else:
  covered+=1
  if pending is not None and pending[0]==identity:pending=(identity,pending[1]+1)
  else:flush();pending=(identity,1)
flush()
assert covered==proof['coveredDiffLines']==7338
assert ''.join(compact).encode()==(root/'compact.diff').read_bytes()
def reject_duplicates(pairs):
 result={}
 for key,value in pairs:
  assert key not in result
  result[key]=value
 return result
jsonpath='data/parity/issue-1584-cnl-infeasible.json'
assert json.loads(show(base,jsonpath),object_pairs_hook=reject_duplicates)==json.loads(show(head,jsonpath),object_pairs_hook=reject_duplicates)
namespace={'re':re,'json':json}
exec((root/'cnl-representation-transform.py').read_text(),namespace)
cnl=[]
for path in paths:
 if '/cnl-language-' not in path:continue
 before,after=show(base,path),show(head,path)
 reconstructed=namespace['migrate'](before.decode()).encode()
 assert reconstructed==after
 cnl.append({'path':path,'beforeSha256':sha(before),'afterSha256':sha(after),'wholeFileReconstructed':True})
assert len(cnl)==5
final=[];hide=False
for line in compact:
 if line.startswith('diff --git '):
  hide='/cnl-language-' in line or (' a/'+jsonpath+' b/'+jsonpath+'\n') in line
  if hide:final.append(' [COMPLETE DATA CONSERVATION: '+line.strip()+'; see JSON/CNL proofs]\n')
 if not hide:final.append(line)
assert ''.join(final).encode()==(root/'compact-final.diff').read_bytes()
chunks=[]
for i in range(0,len(final),200):
 path=root/('final-%03d.diff'%(i//200))
 raw=path.read_bytes()
 assert raw==''.join(final[i:i+200]).encode()
 chunks.append({'path':path.name,'lines':len(raw.decode().splitlines()),'bytes':len(raw),'sha256':sha(raw),'literalReadComplete':True})
assert len(chunks)==18 and len(final)==3445
out={'base':base,'source':head,'paths':bindings,'completeDiff':{'lines':inv['lines'],'bytes':len(complete),'sha256':sha(complete)},'exactMovedRecords':len(proof['records']),'coveredDiffLines':covered,'cnlWholeFileReconstruction':cnl,'jsonStructuralConservation':jsonpath,'compactChunks':chunks,'compactReviewComplete':True,'completeAggregateReview':False,'runtimeAcceptanceClaimed':False,'independentReasoningAccepted':0,'fullIssueComplete':False}
(root/'independent-readback-and-coverage.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['paths','cnlWholeFileReconstruction','compactChunks']},indent=2))
print('CNL_FILES',len(cnl),'COMPACT_CHUNKS',len(chunks))
