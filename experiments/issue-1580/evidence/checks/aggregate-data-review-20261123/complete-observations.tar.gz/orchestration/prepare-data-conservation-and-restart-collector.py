from pathlib import Path
import collections,difflib,hashlib,json,re,subprocess
r=Path('/tmp/issue-1580-research')
src=(r/'collect-rerun-repair-head-ci.py').read_text().replace('rerun-repair-head-ci','apt-repair-head-ci').replace('f7a71cb86a16e78da0e9ca055c13710d62277739','bc08222b5a5195dc9992c0459bde2b6369377b9f')
assert "root=Path('/tmp/issue-1580-research/apt-repair-head-ci')" in src
worker=r/'collect-apt-repair-head-ci.py';worker.write_text(src)
with (r/'apt-repair-head-ci-worker-restart.log').open('wb') as f:
 p=subprocess.Popen(['python3',str(worker)],stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
(r/'apt-repair-head-ci-pid').write_text(str(p.pid)+'\n')
print('CORRECTED_COLLECTOR',p.pid,flush=True)
o=r/'aggregate-data-review-bc08';inv=json.loads((o/'inventory.json').read_text())
base=inv['base'];head=inv['source'];paths=[p for p in inv['paths'] if p.startswith('data/seed/')]
def blocks(rev,path):
 q=subprocess.run(['git','show',rev+':'+path],capture_output=True)
 if q.returncode:return []
 ls=q.stdout.decode().splitlines(keepends=True);root='';starts=[]
 for i,s in enumerate(ls):
  t=s.rstrip('\r\n')
  if t and not t.startswith((' ','#')):root=t
  elif re.match(r'^  [^ #]',t):starts.append((i,root))
 result=[]
 for i,root in starts:
  end=i+1
  while end<len(ls):
   t=ls[end].rstrip('\r\n')
   if t and not t.startswith('#') and (not t.startswith(' ') or re.match(r'^  [^ #]',t)):break
   end+=1
  raw=''.join(ls[i:end])
  if raw.count('\n')>=6:result.append({'path':path,'root':root,'start':i+1,'end':end,'raw':raw,'bytes':len(raw.encode()),'sha256':hashlib.sha256(raw.encode()).hexdigest()})
 return result
old=collections.defaultdict(list);new=collections.defaultdict(list)
for path in paths:
 for b in blocks(base,path):old[(b['root'],b['raw'])].append(b)
 for b in blocks(head,path):new[(b['root'],b['raw'])].append(b)
proof=[];oldmap={};newmap={}
for key in old.keys()&new.keys():
 a=old[key];b=new[key]
 if len(a)!=1 or len(b)!=1 or a[0]['path']==b[0]['path']:continue
 x,y=a[0],b[0];assert x['raw']==y['raw']
 identity=len(proof)
 proof.append({'id':identity,'root':x['root'],'old':{k:v for k,v in x.items() if k!='raw'},'new':{k:v for k,v in y.items() if k!='raw'},'exactBytesEqual':True})
 for item,m in [(x,oldmap),(y,newmap)]:
  for i in range(item['start'],item['end']+1):m[(item['path'],i)]=identity
raw=(o/'complete.diff').read_text().splitlines(keepends=True);compact=[];oldpath=newpath='';ol=nl=0;covered=0;pending=None
def flush():
 global pending
 if pending:compact.append(' [EXACT COMPLETE SEED RECORD %s; %s diff lines; see conservation-proof.json]\n'%(pending[0],pending[1]));pending=None
for s in raw:
 if s.startswith('--- a/'):oldpath=s[6:].rstrip('\n')
 if s.startswith('+++ b/'):newpath=s[6:].rstrip('\n')
 m=re.match(r'^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@',s)
 if m:ol=int(m[1]);nl=int(m[2])
 identity=None
 if s.startswith('-') and not s.startswith('---'):
  identity=oldmap.get((oldpath,ol));ol+=1
 elif s.startswith('+') and not s.startswith('+++'):
  identity=newmap.get((newpath,nl));nl+=1
 elif s.startswith(' '):ol+=1;nl+=1
 if identity is not None:
  covered+=1
  if pending and pending[0]==identity:pending=(identity,pending[1]+1)
  else:flush();pending=(identity,1)
 else:flush();compact.append(s)
flush()
(o/'conservation-proof.json').write_text(json.dumps({'scope':'Exact complete indentation-delimited seed records with their original parent; unique one-to-one cross-file byte matches. Structural conservation only, not runtime acceptance.','records':proof,'coveredDiffLines':covered},indent=2)+'\n')
(o/'compact.diff').write_text(''.join(compact))
for i in range(0,len(compact),300):(o/('compact-%03d.diff'%(i//300))).write_text(''.join(compact[i:i+300]))
print('CONSERVATION',len(proof),'covered',covered,'compactLines',len(compact),'chunks',(len(compact)+299)//300)
