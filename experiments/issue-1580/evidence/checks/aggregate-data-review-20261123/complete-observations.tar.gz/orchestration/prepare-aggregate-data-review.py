from pathlib import Path
import collections,hashlib,json,subprocess
r=Path('/tmp/issue-1580-research');o=r/'aggregate-data-review-bc08';o.mkdir(exist_ok=False)
d=json.loads((r/'current-aggregate-uncovered-paths.json').read_text())
print('INVENTORY_TYPE',type(d).__name__, list(d)[:5] if isinstance(d,dict) else len(d))
rows=d['uncovered'] if isinstance(d,dict) and 'uncovered' in d else d
if isinstance(rows,dict):print('KEYS',list(rows));raise SystemExit(2)
paths=[x['path'] for x in rows if x['path'].startswith('data/')]
assert len(paths)==51,len(paths)
raw=subprocess.check_output(['git','diff','--no-ext-diff','--unified=3','03a636334975cd7ca5cedff119e2dd0efbc8579f','bc08222b5a5195dc9992c0459bde2b6369377b9f','--',*paths])
(o/'complete.diff').write_bytes(raw)
lines=raw.decode().splitlines(keepends=True)
for i in range(0,len(lines),300):(o/('chunk-%03d.diff'%(i//300))).write_text(''.join(lines[i:i+300]))
inv={'base':'03a636334975cd7ca5cedff119e2dd0efbc8579f','source':'bc08222b5a5195dc9992c0459bde2b6369377b9f','paths':paths,'lines':len(lines),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'chunks':(len(lines)+299)//300,'allRead':False}
(o/'inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
print('DATA_REVIEW',json.dumps(inv))
print('SEED_EXAMPLE');print('\n'.join(Path('data/seed/meanings-response-intents-additional.lino').read_text().splitlines()[:45]))
print('CI');print('\n'.join((r/'apt-repair-head-ci-worker.log').read_text().splitlines()[-3:]))
