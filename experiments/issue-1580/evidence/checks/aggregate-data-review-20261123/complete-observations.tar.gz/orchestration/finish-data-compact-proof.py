from pathlib import Path
import collections,hashlib,json,re,subprocess
r=Path('/tmp/issue-1580-research');o=r/'aggregate-data-review-bc08'
(o/'conservation-proof-v1.json').write_bytes((o/'conservation-proof.json').read_bytes())
p=(r/'prepare-data-conservation-and-restart-collector.py').read_text()
section=p[p.index("o=r/'aggregate-data-review-bc08'"):]
section=section.replace("raw.count('\\n')>=6","raw.count('\\n')>=4")
assert "raw.count('\\n')>=4" in section
exec(section)
ls=(o/'compact.diff').read_text().splitlines(keepends=True);out=[];hide=False
target='data/parity/issue-1584-cnl-infeasible.json'
for line in ls:
 if line.startswith('diff --git '):
  hide='/cnl-language-' in line or (' a/'+target+' b/'+target+'\n') in line
  if hide:out.append(' [COMPLETE DATA CONSERVATION: '+line.strip()+'; see JSON/CNL proofs]\n')
 if not hide:out.append(line)
(o/'compact-final.diff').write_text(''.join(out))
for i in range(0,len(out),200):(o/('final-%03d.diff'%(i//200))).write_text(''.join(out[i:i+200]))
print('FINAL_LINES',len(out),'CHUNKS',(len(out)+199)//200)
print('CI');print('\n'.join((r/'apt-repair-head-ci-worker-restart.log').read_text().splitlines()[-2:]))
