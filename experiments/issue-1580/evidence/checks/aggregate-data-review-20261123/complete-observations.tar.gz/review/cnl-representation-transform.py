def forms(s):return '('+' '.join(json.dumps(x,ensure_ascii=False) for x in s.split('|'))+')'
def migrate(text):
 out=[]
 for line in text.splitlines(keepends=True):
  nl='\n' if line.endswith('\n') else ''
  line=line.rstrip('\n')
  m=re.fullmatch(r'  (prime|list|tier) "([^:]+): (.*)"',line)
  if m:out+=['  '+m[1]+' '+json.dumps(m[2],ensure_ascii=False)+'\n','    forms '+forms(m[3])+nl];continue
  m=re.fullmatch(r'  template "(\S+) (\S+) (.*)"',line)
  if m:out+=['  template '+json.dumps(m[1]+' '+m[3],ensure_ascii=False)+'\n','    styles '+forms(m[2])+nl];continue
  m=re.fullmatch(r'(\s+)(keys|grammar|copula|pronouns|fillers|typos|loose|input|forms|primes|precise|ste|special|basic) "(.*)"',line)
  if m and '|' in m[3]:out.append(m[1]+m[2]+' '+forms(m[3])+nl);continue
  out.append(line+nl)
 return ''.join(out)
