from pathlib import Path
import json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/native-reasoning-shards-validation')
base.mkdir(exist_ok=False)
environment = dict(os.environ)
environment.pop('NODE_OPTIONS', None)
records = []
def run(name, argv):
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
    for label in ['stdout', 'stderr']:
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, (name, result.stdout.decode(errors='replace')[-4000:], result.stderr.decode(errors='replace')[-1000:])
for name, path in [
    ('default-branch-policy', 'rust/tests/web/default-branch-build-policy.test.mjs'),
    ('retained-production-profile', 'rust/tests/web/fast-pull-request-production-profile.test.mjs')]:
    run(name, ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-reporter=tap',
        '--test-concurrency=1', path])
run('shellcheck', ['shellcheck', 'scripts/ci-native-regressions.sh'])
run('whitespace', ['git', 'diff', '--check'])
print('Native workflow policy, retained production profile, shell diagnostics and whitespace pass.')
