from pathlib import Path
import hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/reasoning-cancelled-api-39196d1f')
base.mkdir(exist_ok=False)
job = json.loads(Path('/tmp/issue-1580-research/reasoning-cancelled-39196d1f/job.json').read_text())
result = subprocess.run(['gh', 'api', 'repos/link-assistant/formal-ai/actions/jobs/' + str(job['databaseId']) + '/logs'],
    cwd=root, capture_output=True)
(base / 'log.stdout').write_bytes(result.stdout)
(base / 'log.stderr').write_bytes(result.stderr)
print('Completed job API log exit:', result.returncode, '; bytes:', len(result.stdout), '; lines:', len(result.stdout.splitlines()))
assert result.returncode == 0, result.stderr.decode()
for step in job['steps']:
    print(json.dumps(step))
for number, line in enumerate(result.stdout.decode(errors='replace').splitlines(), 1):
    if any(word in line for word in ['::error', 'panicked at', 'FAILED', 'error:', 'test result:', 'test failed', 'timeout', 'timed out', 'running for over']):
        print(str(number) + ': ' + line)
(base / 'identity.json').write_text(json.dumps({'sha256': hashlib.sha256(result.stdout).hexdigest(),
    'bytes': len(result.stdout), 'lines': len(result.stdout.splitlines()),
    'head': '39196d1fb218d0ef492f90915270f9ae3ac28ba1', 'runId': 44775337494,
    'jobId': job['databaseId']}, indent=2) + '\n')
