from pathlib import Path
import gzip, json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/native-reasoning-shards')
base.mkdir(exist_ok=False)
source = Path('/tmp/issue-1580-research/reasoning-cancelled-raw-39196d1f/log.stdout')
archive = root / 'experiments/issue-1580/evidence/checks/native-reasoning-budget/job-136423862321.stdout.gz'
archive.parent.mkdir(exist_ok=True)
archive.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
assert gzip.decompress(archive.read_bytes()) == source.read_bytes()

derive = '''#!/usr/bin/env python3
"""Project sequential hosted reasoning observations into reproducible shard weights."""
import argparse
from datetime import datetime
import gzip
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
LOG = ROOT / 'experiments/issue-1580/evidence/checks/native-reasoning-budget/job-136423862321.stdout.gz'
OUTPUT = ROOT / 'scripts/ci-native-reasoning-durations.lino'


def measured_text():
    previous = None
    durations = {}
    summary = None
    for line in gzip.decompress(LOG.read_bytes()).decode().splitlines():
        timestamp, _, message = line.partition(' ')
        if not timestamp.endswith('Z'):
            continue
        if re.fullmatch(r'running 148 tests', message):
            previous = datetime.fromisoformat(timestamp)
        match = re.fullmatch(r'test ([A-Za-z0-9_:]+) \\.{3} ok', message)
        if match:
            assert previous is not None
            now = datetime.fromisoformat(timestamp)
            name = match[1]
            assert name not in durations and '::' in name
            assert not name.startswith(('benchmarks::', 'issue_1133_hive_mind_three_runs::'))
            durations[name] = max((now - previous).total_seconds(), 0.001)
            previous = now
        if message.startswith('test result:'):
            summary = message
    assert len(durations) == 148 and summary is not None
    assert summary.startswith('test result: ok. 148 passed; 0 failed; 0 ignored;')
    rows = ['test_durations', '  source_run 44775337494',
            '  source_job 136423862321',
            '  source_sha 39196d1fb218d0ef492f90915270f9ae3ac28ba1',
            '  recorded 2026-11-20', '  unit seconds', '  default-seconds 60',
            '  purpose "All 148 sequential cases passed before the job clock expired; unseen cases weigh 60 seconds."',
            '  regenerate "python3 experiments/issue-1580/derive-native-reasoning-durations.py --write"']
    for name, seconds in sorted(durations.items(), key=lambda row: (-row[1], row[0])):
        rows.extend([f'  test "{name}"', f'    seconds {seconds:.3f}'])
    return '\\n'.join(rows) + '\\n'


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--write', action='store_true')
    mode.add_argument('--check', action='store_true')
    options = parser.parse_args()
    text = measured_text()
    if options.write:
        OUTPUT.write_text(text)
    elif options.check:
        assert OUTPUT.read_text() == text, 'hosted reasoning duration projection is stale'
    else:
        print(text, end='')
'''
(root / 'experiments/issue-1580/derive-native-reasoning-durations.py').write_text(derive)
result = subprocess.run(['python3', 'experiments/issue-1580/derive-native-reasoning-durations.py', '--write'], cwd=root, capture_output=True)
(base / 'derive.stdout').write_bytes(result.stdout)
(base / 'derive.stderr').write_bytes(result.stderr)
assert result.returncode == 0, result.stderr

test_path = root / 'experiments/issue-1580/native-regression-groups.test.mjs'
text = test_path.read_text()
text = text.replace("coding: ['coding_contracts'], reasoning: ['reasoning_contracts'], hive: ['reasoning_contracts'],", "coding: ['coding_contracts'], reasoning: ['reasoning_contracts'], hive: ['reasoning_contracts'],\n  'reasoning-1': ['reasoning_contracts'], 'reasoning-2': ['reasoning_contracts'],")
text = text.replace("!name.startsWith('hive-')", "!name.startsWith('hive-') && !name.startsWith('reasoning-')")
text = text.replace("!['core', 'hive'].includes(group)", "!['core', 'hive', 'reasoning'].includes(group)")
insert = '''
const reasoningNames = [
  'issue_1157_idempotent_commit::the_commit_names_its_files_and_a_repeated_run_is_a_clean_no_op',
  'issue_1160_regular_prompt::the_regular_prompt_delivers_a_ready_pull_request',
  'reasoning_loop::a_future_case', 'reasoning_loop::another_future_case',
  'tool_workspace::process_observation_tests::nonzero_exit_marks_failure_and_preserves_both_streams',
];
function executedReasoningShard(observed) {
  const names = executedShard(observed, 'reasoning');
  assert(names.every(name => !name.startsWith('benchmarks::') &&
    !name.startsWith('issue_1133_hive_mind_three_runs::')));
  return names;
}
test('the two native reasoning shards cover every live case exactly once', {timeout: 15000}, () => {
  const actual = [1, 2].flatMap(index => executedReasoningShard(
    observe(['reasoning-' + index], 0, {names: reasoningNames})));
  assert.deepEqual(actual.toSorted(), reasoningNames.toSorted());
  assert.equal(new Set(actual).size, actual.length);
});
test('reasoning shard selection is stable under a reordered listing', {timeout: 15000}, () => {
  for (const index of [1, 2]) {
    assert.deepEqual(executedReasoningShard(observe(['reasoning-' + index], 0, {names: reasoningNames})),
      executedReasoningShard(observe(['reasoning-' + index], 0, {names: [...reasoningNames].reverse()})));
  }
});
for (const index of [1, 2]) {
  test(`reasoning shard ${index} propagates listing and execution failures`, {timeout: 15000}, () => {
    const listing = observe(['reasoning-' + index], 0, {names: reasoningNames, listStatus: 19});
    assert.equal(listing.result.status, 19, listing.result.stderr);
    assert.equal(listing.invocations.length, 1);
    const execution = observe(['reasoning-' + index], 17, {names: reasoningNames});
    assert.equal(execution.result.status, 17, execution.result.stderr);
    assert.equal(execution.invocations.length, 2);
  });
}
for (const names of [[], [reasoningNames[0]], [reasoningNames[0], reasoningNames[0]],
  ['benchmarks::case', reasoningNames[0]], [hiveNames[0], reasoningNames[0]], ['invalid name', reasoningNames[0]]]) {
  test('reasoning rejects incomplete or foreign listings: ' + JSON.stringify(names), {timeout: 15000}, () => {
    const observed = observe(['reasoning-2'], 0, {names});
    assert.notEqual(observed.result.status, 0);
    assert.equal(observed.invocations.length, 1);
  });
}
test('reasoning weights reproduce all 148 completed hosted observations', {timeout: 15000}, () => {
  const observed = spawnSync('python3', ['experiments/issue-1580/derive-native-reasoning-durations.py', '--check'],
    {encoding: 'utf8', timeout: 10000, maxBuffer: 65536});
  assert.equal(observed.status, 0, observed.stderr);
  assert.equal(admission(['scripts/ci-native-reasoning-durations.lino'])['native-type-check'], true);
});
'''
text = text.replace('function executedShard(observed) {', "function executedShard(observed, family = 'hive') {")
text = text.replace("  assert.deepEqual(list.slice(-4), ['--', '--list', '--format', 'terse']);\n  assert.equal(list[list.indexOf('--test') + 2], 'issue_1133_hive_mind_three_runs::');", "  assert.deepEqual(list.slice(-3), ['--list', '--format', 'terse']);\n  if (family === 'hive') {\n    assert.equal(list[list.indexOf('--test') + 2], 'issue_1133_hive_mind_three_runs::');\n  } else {\n    assert.deepEqual(list.slice(list.indexOf('--') + 1), ['--skip', 'benchmarks::',\n      '--skip', 'issue_1133_hive_mind_three_runs::', '--list', '--format', 'terse']);\n  }")
text = text.replace("test('native Hive duration weights reproduce", insert + "\ntest('native Hive duration weights reproduce", 1)
test_path.write_text(text)
environment = dict(os.environ)
environment.pop('NODE_OPTIONS', None)
result = subprocess.run(['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-concurrency=1',
    '--test-name-pattern=the two native reasoning shards', str(test_path)], cwd=root, env=environment, capture_output=True)
(base / 'negative-control.stdout').write_bytes(result.stdout)
(base / 'negative-control.stderr').write_bytes(result.stderr)
assert result.returncode != 0, 'the original unsharded runner unexpectedly passed'
assert b'not ok' in result.stdout and b'Usage:' in result.stdout
print('Retained complete hosted log and derived 148 weights; original runner fails the exact-coverage regression as expected.')
