from pathlib import Path
import json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/native-reasoning-shards')
negative = (base / 'negative-control.stdout').read_text()
assert 'Usage: ci-native-regressions.sh' in negative and 'fail 1' in negative
assert not (base / 'negative-control.stderr').read_bytes()

path = root / 'scripts/ci-native-regressions.sh'
text = path.read_text()
text = text.replace('[all|core|coding|reasoning|hive|', '[all|core|coding|reasoning|reasoning-1|reasoning-2|hive|')
start = text.index('  hive-1|hive-2|hive-3)')
end = text.index('  coding|reasoning|hive|benchmarks|interfaces)', start)
replacement = '''  hive-1|hive-2|hive-3|reasoning-1|reasoning-2)
    # Whole-family clocks expired after successful cases in runs 44652802985
    # (Hive) and 44775337494 (reasoning). Plan the actual compiled listing
    # using those sequential observations, keeping every original test once.
    runner_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
    family="${group%-*}"
    if [[ "$family" == hive ]]; then
      shard_count=3
      listing="$(cargo test --manifest-path rust/Cargo.toml --locked --no-fail-fast \\
        --test reasoning_contracts issue_1133_hive_mind_three_runs:: -- --list --format terse)"
    else
      shard_count=2
      listing="$(cargo test --manifest-path rust/Cargo.toml --locked --no-fail-fast \\
        --test reasoning_contracts -- --skip benchmarks:: --skip issue_1133_hive_mind_three_runs:: --list --format terse)"
    fi
    names="$(printf '%s\\n' "$listing" | sed -n 's/: test$//p')"
    all_names=()
    while IFS= read -r name; do
      valid=false
      if [[ "$family" == hive ]]; then
        [[ "$name" == issue_1133_hive_mind_three_runs::* ]] && valid=true
      elif [[ "$name" =~ ^([[:alnum:]_]+::)+[[:alnum:]_]+$ &&
        "$name" != benchmarks::* && "$name" != issue_1133_hive_mind_three_runs::* ]]; then
        valid=true
      fi
      if [[ "$valid" != true ]]; then
        echo "::error::The native $family listing is empty or contains a foreign test." >&2
        exit 1
      fi
      all_names+=("$name")
    done <<< "$names"
    if [[ "${#all_names[@]}" -lt "$shard_count" ]] ||
      ! printf '%s\\n' "${all_names[@]}" | awk 'seen[$0]++ { exit 1 }'; then
      echo "::error::The native $family listing must contain at least $shard_count distinct tests." >&2
      exit 1
    fi
    planner="$runner_root/scripts/plan-test-shards.mjs"
    weights="$runner_root/scripts/ci-native-$family-durations.lino"
    printf '%s\\n' "$names" | node "$planner" --of "$shard_count" --durations "$weights" --check
    selected="$(printf '%s\\n' "$names" | node "$planner" --of "$shard_count" --durations "$weights" --shard "${group##*-}")"
    selected_names=()
    while IFS= read -r name; do
      [[ -n "$name" ]] && selected_names+=("$name")
    done <<< "$selected"
    [[ "${#selected_names[@]}" -gt 0 ]] || { echo "::error::The native $family shard is empty." >&2; exit 1; }
    cargo test --manifest-path rust/Cargo.toml --locked --no-fail-fast --test reasoning_contracts \\
      -- --exact "${selected_names[@]}" --test-threads=1 --nocapture
    exit "$?"
    ;;
'''
text = text[:start] + replacement + text[end:]
# The compatibility groups still execute the original complete families.
assert '  coding|reasoning|hive|benchmarks|interfaces)' in text
path.write_text(text)

path = root / '.github/workflows/native-type-check.yml'
text = path.read_text()
assert text.count('group: [coding, reasoning, benchmarks, interfaces, hive-1, hive-2, hive-3]') == 1
path.write_text(text.replace('group: [coding, reasoning, benchmarks, interfaces, hive-1, hive-2, hive-3]',
    'group: [coding, reasoning-1, reasoning-2, benchmarks, interfaces, hive-1, hive-2, hive-3]'))
path = root / 'scripts/ci-pull-request-admission.mjs'
text = path.read_text().replace("  'scripts/ci-native-hive-durations.lino',", "  'scripts/ci-native-hive-durations.lino',\n  'scripts/ci-native-reasoning-durations.lino',")
path.write_text(text)

evidence = 'experiments/issue-1580/evidence/checks/native-reasoning-budget/job-136423862321.stdout.gz'
path = root / '.github/workflows/layered-ci.yml'
text = path.read_text()
anchor = '            /experiments/issue-1580/evidence/ci/native-families-7fce5c19/job-136011692528.stdout.gz\n'
assert text.count(anchor) == 1
path.write_text(text.replace(anchor, anchor + '            /' + evidence + '\n'))
path = root / 'experiments/issue-1580/native-regression-groups.test.mjs'
text = path.read_text()
text = text.replace("retains only the Hive weight evidence it consumes", "retains only the native weight evidence it consumes")
text = text.replace("  const unrelated = 'experiments/issue-1580/evidence/ci/unrelated-historical.log.gz';",
    "  const reasoningEvidence = '" + evidence + "';\n  const unrelated = 'experiments/issue-1580/evidence/ci/unrelated-historical.log.gz';")
text = text.replace("for (const path of [evidence, 'scripts/ci-native-hive-durations.lino',\n      'experiments/issue-1580/derive-native-hive-durations.py'])", "for (const path of [evidence, reasoningEvidence, 'scripts/ci-native-hive-durations.lino',\n      'scripts/ci-native-reasoning-durations.lino', 'experiments/issue-1580/derive-native-reasoning-durations.py',\n      'experiments/issue-1580/derive-native-hive-durations.py'])")
text = text.replace("    assert(!existsSync(join(directory, unrelated))", "    assert(existsSync(join(directory, reasoningEvidence)), 'the reasoning observation must survive the real checkout');\n    assert(!existsSync(join(directory, unrelated))")
text = text.replace("run('python3', ['experiments/issue-1580/derive-native-hive-durations.py', '--check']);", "run('python3', ['experiments/issue-1580/derive-native-hive-durations.py', '--check']);\n    run('python3', ['experiments/issue-1580/derive-native-reasoning-durations.py', '--check']);")
needle = "test('reasoning weights reproduce all 148 completed hosted observations'"
insert = '''test('the measured 148-case reasoning inventory remains a complete two-shard partition', {timeout: 15000}, () => {
  const names = [...readFileSync('scripts/ci-native-reasoning-durations.lino', 'utf8')
    .matchAll(/^  test "([^"]+)"$/gmu)].map(match => match[1]);
  assert.equal(names.length, 148);
  const actual = [1, 2].flatMap(index => executedReasoningShard(
    observe(['reasoning-' + index], 0, {names})));
  assert.deepEqual(actual.toSorted(), names.toSorted());
  assert.equal(new Set(actual).size, actual.length);
});
'''
assert needle in text
text = text.replace(needle, insert + needle)
path.write_text(text)

environment = dict(os.environ)
environment.pop('NODE_OPTIONS', None)
records = []
def run(name, argv, stdin=None):
    result = subprocess.run(argv, cwd=root, env=environment, input=stdin, capture_output=True)
    for label in ['stdout', 'stderr']:
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, (name, result.stdout.decode(errors='replace')[-4000:], result.stderr.decode(errors='replace')[-1000:])
run('shell-syntax', ['bash', '-n', 'scripts/ci-native-regressions.sh'])
run('focused-groups', ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-reporter=tap',
    '--test-concurrency=1', 'experiments/issue-1580/native-regression-groups.test.mjs'])
names = [line.split('"')[1] for line in (root / 'scripts/ci-native-reasoning-durations.lino').read_text().splitlines() if line.startswith('  test "')]
run('measured-plan', ['node', '--max-old-space-size=256', 'scripts/plan-test-shards.mjs', '--of', '2',
    '--durations', 'scripts/ci-native-reasoning-durations.lino', '--report'], ('\n'.join(names) + '\n').encode())
print('Two exact reasoning shards implemented; focused coverage, negative control, original Hive behavior, sparse checkout and shell checks pass.')
