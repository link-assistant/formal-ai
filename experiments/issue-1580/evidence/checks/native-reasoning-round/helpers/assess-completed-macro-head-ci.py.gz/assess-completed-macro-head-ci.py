from pathlib import Path
import gzip, hashlib, json, re, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/completed-macro-head-ci-assessment')
base.mkdir(exist_ok=False)
evidence = root / 'experiments/issue-1580/evidence/ci/native-families-39196d1f'
outcome = json.loads((evidence / 'outcome.json').read_text())
assert outcome['complete'] and outcome['head'] == '39196d1fb218d0ef492f90915270f9ae3ac28ba1'
records = json.loads((evidence / 'records.json').read_text())
for row in records:
    for label in ['stdout', 'stderr']:
        item = row[label]
        packed = (evidence / item['file']).read_bytes()
        raw = gzip.decompress(packed)
        assert hashlib.sha256(packed).hexdigest() == item['archiveSha256']
        assert hashlib.sha256(raw).hexdigest() == item['rawSha256']
        assert len(raw) == item['bytes'] and len(raw.splitlines()) == item['lines']
jobs = json.loads(gzip.decompress((evidence / 'jobs-44775337494.stdout.gz').read_bytes()))['jobs']
summaries = []
for job in jobs:
    if 'Native type and lint check /' not in job['name']:
        continue
    filename = 'job-' + str(job['databaseId']) + '.stdout.gz'
    lines = gzip.decompress((evidence / filename).read_bytes()).decode().splitlines()
    results = [{'line': number, 'text': line} for number, line in enumerate(lines, 1)
        if re.search(r'test result: (?:ok|FAILED)\.', line)]
    summaries.append({key: job[key] for key in ['databaseId', 'name', 'conclusion', 'startedAt', 'completedAt']} |
        {'file': filename, 'results': results})
(base / 'native-results.json').write_text(json.dumps(summaries, indent=2) + '\n')
reasoning = next(row for row in summaries if '(reasoning)' in row['name'])
assert reasoning['conclusion'] == 'cancelled' and len(reasoning['results']) == 1
assert '148 passed; 0 failed;' in reasoning['results'][0]['text']
for name, arguments in [
    ('reasoning-job-api', ['gh', 'api', 'repos/link-assistant/formal-ai/actions/jobs/136423862321']),
    ('recent-runs', ['gh', 'run', 'list', '--repo', 'link-assistant/formal-ai', '--branch',
        'issue-1580-8d61a32a61e1', '--limit', '5', '--json', 'databaseId,conclusion,createdAt,headSha'])]:
    result = subprocess.run(arguments, cwd=root, capture_output=True)
    (base / (name + '.stdout')).write_bytes(result.stdout)
    (base / (name + '.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0, result.stderr
job = json.loads((base / 'reasoning-job-api.stdout').read_text())
check_id = job['check_run_url'].rsplit('/', 1)[1]
result = subprocess.run(['gh', 'api', 'repos/link-assistant/formal-ai/check-runs/' + check_id + '/annotations',
    '--paginate'], cwd=root, capture_output=True)
(base / 'reasoning-annotations.stdout').write_bytes(result.stdout)
(base / 'reasoning-annotations.stderr').write_bytes(result.stderr)
assert result.returncode == 0, result.stderr
print('Verified', len(records), 'retained command records and every stream identity.')
for row in summaries:
    print(row['name'], row['conclusion'], row['startedAt'], row['completedAt'])
    for result in row['results']:
        print(' ', result['line'], result['text'].partition('test result:')[2])
print('Reasoning annotations:', result.stdout.decode())
(base / 'outcome.json').write_text(json.dumps({'complete': True, 'source': outcome['head'],
    'archiveRecordsVerified': len(records), 'fullIssueComplete': False}, indent=2) + '\n')
