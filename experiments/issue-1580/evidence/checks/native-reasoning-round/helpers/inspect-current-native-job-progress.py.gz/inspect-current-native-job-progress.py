from pathlib import Path
import datetime, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/native-job-progress-39196d1f')
base.mkdir(exist_ok=False)
result = subprocess.run(['gh', 'run', 'view', '44775337494', '--repo', 'link-assistant/formal-ai',
    '--json', 'headSha,status,conclusion,jobs,url,updatedAt'], cwd=root, capture_output=True)
(base / 'pipeline.stdout').write_bytes(result.stdout)
(base / 'pipeline.stderr').write_bytes(result.stderr)
assert result.returncode == 0
data = json.loads(result.stdout)
assert data['headSha'] == '39196d1fb218d0ef492f90915270f9ae3ac28ba1'
print(datetime.datetime.now(datetime.timezone.utc).isoformat(), data['status'])
for job in data['jobs']:
    if job['name'].startswith('native-'):
        print(json.dumps({key: job[key] for key in ['name', 'status', 'conclusion', 'startedAt', 'completedAt', 'databaseId']}))
