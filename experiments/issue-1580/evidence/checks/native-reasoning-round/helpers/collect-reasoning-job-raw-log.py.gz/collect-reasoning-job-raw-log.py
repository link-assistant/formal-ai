from pathlib import Path

source = Path('/tmp/issue-1580-research/collect-completed-reasoning-job-api-log.py').read_text()
source = source.replace('reasoning-cancelled-api-39196d1f', 'reasoning-cancelled-raw-39196d1f')
source = source.replace("['gh', 'api', 'repos/", "['gh', 'api', '--allow-escape-sequences', 'repos/")
generated = Path('/tmp/issue-1580-research/collect-reasoning-job-raw-log-worker.py')
generated.write_text(source)
exec(compile(source, str(generated), 'exec'))
