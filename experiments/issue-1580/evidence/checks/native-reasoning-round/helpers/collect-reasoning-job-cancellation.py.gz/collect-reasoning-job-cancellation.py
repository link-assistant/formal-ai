from pathlib import Path
import gzip, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/reasoning-cancelled-39196d1f')
base.mkdir(exist_ok=False)
saved = json.loads(Path('/tmp/issue-1580-research/native-job-progress-39196d1f/pipeline.stdout').read_text())
job = next(row for row in saved['jobs'] if row['name'].endswith('Native contracts (reasoning)'))
assert job['conclusion'] == 'cancelled'
(base / 'job.json').write_text(json.dumps(job, indent=2) + '\n')
result = subprocess.run(['gh', 'run', 'view', '44775337494', '--repo', 'link-assistant/formal-ai',
    '--job', str(job['databaseId']), '--log'], cwd=root, capture_output=True)
(base / 'log.stdout').write_bytes(result.stdout)
(base / 'log.stderr').write_bytes(result.stderr)
print('Log command exit:', result.returncode, '; bytes:', len(result.stdout), '; lines:', len(result.stdout.splitlines()))
assert result.returncode == 0, result.stderr.decode()
for step in job['steps']:
    print(json.dumps(step))
for number, line in enumerate(result.stdout.decode(errors='replace').splitlines(), 1):
    if any(word in line for word in ['::error', 'panicked at', 'FAILED', 'error:', 'test result:', 'test failed', 'timeout', 'timed out', 'running for over']):
        print(str(number) + ': ' + line)
(base / 'identity.json').write_text(json.dumps({'sha256': hashlib.sha256(result.stdout).hexdigest(),
    'bytes': len(result.stdout), 'lines': len(result.stdout.splitlines()), 'head': saved['headSha'],
    'runId': 44775337494, 'jobId': job['databaseId']}, indent=2) + '\n')
