from pathlib import Path
import json, os, shutil, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/native-reasoning-shards-final-checks')
base.mkdir(exist_ok=False)
path = root / 'rust/tests/web/fast-pull-request-production-profile.test.mjs'
text = path.read_text()
anchor = '/experiments/issue-1580/evidence/ci/native-families-7fce5c19/job-136011692528.stdout.gz\\n'
assert text.count(anchor) == 1
path.write_text(text.replace(anchor, anchor +
    '/experiments/issue-1580/evidence/checks/native-reasoning-budget/job-136423862321.stdout.gz\\n'))
environment = dict(os.environ)
environment.pop('NODE_OPTIONS', None)
records = []
def run(name, argv):
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
    for label in ['stdout', 'stderr']:
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, (name, result.stdout.decode(errors='replace')[-4000:], result.stderr.decode(errors='replace')[-1000:])
run('retained-profile', ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-reporter=tap',
    '--test-concurrency=1', 'rust/tests/web/fast-pull-request-production-profile.test.mjs'])
run('shellcheck', ['shellcheck', 'scripts/ci-native-regressions.sh'])
run('touched-gates', ['node', '--max-old-space-size=256', 'experiments/formal_ai_subagent/local-gates.mjs',
    '--only', 'check-ci-speed,check-readable-code,check-file-size,check-file-size-js-twin,check-abbreviations,check-tests-as-docs,check-runner-labels'])
for name in ['check-ci-speed', 'check-readable-code', 'check-file-size', 'check-file-size-js-twin',
    'check-abbreviations', 'check-tests-as-docs', 'check-runner-labels']:
    candidate = root / 'experiments/formal_ai_subagent/sandboxes/gates' / (name + '.log')
    if candidate.exists():
        shutil.copyfile(candidate, base / (name.replace('tests-as-docs', 'tests-as-documentation') + '.log'))
run('whitespace', ['git', 'diff', '--check'])
print('Retained exact checkout projection, seven touched gates, shell diagnostics and whitespace pass.')
