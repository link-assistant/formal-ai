from pathlib import Path
import gzip, hashlib, json, os, re, shutil, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
base = scratch / 'reasoning-budget-evidence'
base.mkdir(exist_ok=False)
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
manifest = root / data['readLogManifest']
records = json.loads(manifest.read_text())
for row in records:
    old = row['file']
    if not old.startswith('package-root-history-pr-'):
        continue
    new = old.replace('package-root-history-pr-', 'package-root-history-pull-request-', 1)
    original = (manifest.parent / old).read_bytes()
    (manifest.parent / old).rename(manifest.parent / new)
    assert hashlib.sha256(original).hexdigest() == row['archiveSha256']
    assert (manifest.parent / new).read_bytes() == original
    row['file'] = new
    for item in data['files']:
        item['readLogs'] = [new if name == old else name for name in item['readLogs']]
manifest.write_text(json.dumps(records, indent=2) + '\n')
ledger.write_text(json.dumps(data, indent=2) + '\n')

assessment = scratch / 'completed-macro-head-ci-assessment'
annotations = json.loads((assessment / 'reasoning-annotations.stdout').read_text())
assert any(row['annotation_level'] == 'failure' and row['message'] ==
    'The job has exceeded the maximum execution time of 20m0s' for row in annotations)
native = json.loads((assessment / 'native-results.json').read_text())
assert len(native) == 9 and sum(row['conclusion'] == 'cancelled' for row in native) == 1
assert all(row['conclusion'] in ['success', 'cancelled'] for row in native)
count = sum(int(re.search(r'(\d+) passed;', result['text'])[1])
    for row in native for result in row['results'])
assert count == 528, count
(assessment / 'outcome.json').write_text(json.dumps({'complete': True,
    'source': '39196d1fb218d0ef492f90915270f9ae3ac28ba1', 'archiveRecordsVerified': 148,
    'passedNativeCaseExecutions': count, 'reasoningJobSuccessful': False,
    'timeoutAnnotationConfirmed': True, 'fullIssueComplete': False}, indent=2) + '\n')

doc = root / 'docs/case-studies/issue-1580/native-reasoning-job-budget.md'
doc.write_text('''# Native reasoning job budget

At source `39196d1fb218d0ef492f90915270f9ae3ac28ba1`, all 27 branch workflows
finish: 24 succeed, one is skipped, Layered CI fails its reviewed CodeQL payload
fingerprint, and CI/CD is cancelled because the reasoning matrix job expires.
The separate pipeline status correctly rejects that cancellation.

The [actual reasoning job](https://github.com/link-assistant/formal-ai/actions/runs/44775337494/job/136423862321)
starts at 16:39:05 UTC and ends at 16:59:06. Its check annotation explicitly says
`The job has exceeded the maximum execution time of 20m0s`. The actual sequential
test result is successful: 148 passed, zero failed or ignored, 972.81 seconds.
Setup and almost three minutes of compilation consume the remaining job clock.
Passing test output does not turn this cancelled job into a successful check.

The complete original stream is retained at
`experiments/issue-1580/evidence/checks/native-reasoning-budget/job-136423862321.stdout.gz`.
It has 1,564 lines: the 148-test start is line 1,334; the successful summary is
line 1,484. Four cases dominate the recorded sequential durations:

| Original case | Observed seconds |
| --- | ---: |
| issue_1157_idempotent_commit / repeated clean commit | 271.174 |
| issue_1160_regular_prompt / restart with stray Kotlin jar | 266.325 |
| issue_1158_pull_request_steps / feedback, title, description and ready | 163.735 |
| issue_1160_regular_prompt / ordinary ready pull request | 137.328 |

These intervals are measured between completed sequential cases, including each
case's subprocess work. They are observations from one hosted run, not estimates
of every future runner's speed or proof that an external tool was independently
authored. No local Rust compilation is performed.

The existing longest-first planner now divides the actual live non-Hive,
non-benchmark listing into `reasoning-1` and `reasoning-2`. Frozen observations
project to 74 cases and approximately 486 seconds per job. Compilation still runs
on each hosted runner. The job timeout remains 20 minutes, matrix parallelism
remains two, each Rust test process has one test thread, and existing complete
`reasoning` and default invocations remain available. New tests receive the
existing 60-second default weight. Empty, duplicate, foreign or insufficient
listings and Cargo failures are rejected before a shard can run unintended tests.

The minimal negative control fails against the original runner with unsupported
`reasoning-1`. The repaired 49-case JavaScript file checks the five-case future
inventory and all 148 actual observed names as exact once-only partitions,
listing reorder stability, failed listing/execution propagation, both measured
weight regenerators and Git's real sparse checkout. The checkout adds only the
one consumed reasoning archive; unrelated historical archives remain excluded.
The expanded native policy file passes 111 cases and the retained production
profile passes 18 cases. Its exact sparse-checkout projection is updated to match
the consumed operand. The initial stale projection failure is preserved.

All three Hive jobs on the old head pass: 20 cases in 325.36 seconds, ten in
795.53 seconds, and seven in 454.09 seconds. Coding, interfaces and benchmarks
also pass. Across the nine native jobs, 528 case executions pass, but the
reasoning job's cancellation still makes that pipeline unsuccessful. This
observation does not qualify the still-unexecuted new split script suites or
the new reasoning matrix. Those require the next published head's hosted CI.

The complete issue remains unfinished. Template comparisons, original-contract
qualification, release and served identity, macro semantic coverage, shared
upstream reports and independent Formal AI delivery retain their existing open
criteria. All supplied reasoning and commands receive zero independent credit.
''')
(root / 'changelog.d/issue-1580-reasoning-job-budget.md').write_text('''---
bump: patch
---

Split the native reasoning contract listing into two measured, exact test shards
so compilation and cleanup retain room inside the existing 20-minute job limit.
Keep every case, failure status, single test thread and complete runner entry point.
''')
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('''
- Published head `39196d1f` has 27 terminal workflows: 24 successes, one skip,
  one Layered fingerprint failure and one CI/CD cancellation. All 528 observed
  native cases pass, but GitHub explicitly reports the reasoning job exceeded
  20 minutes. Its 148-case execution takes 972.81 seconds after setup/compilation.
  Draft two measured shards with an unchanged 20-minute timeout and 74/74 cases
  at about 486 seconds each. The original unsupported-shard negative control
  fails; 49 runner cases, 111 policy cases and 18 retained-profile cases pass.
  The real sparse checkout retains only the new consumed evidence operand.
  Next-head native execution remains pending; overall acceptance remains open.
''')
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
result = subprocess.run(['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only',
    'check-abbreviations,check-file-size,check-file-size-js-twin,check-readable-code'],
    cwd=root, env=environment, capture_output=True)
(base / 'archive-gates.stdout').write_bytes(result.stdout)
(base / 'archive-gates.stderr').write_bytes(result.stderr)
assert result.returncode == 0, result.stdout.decode()
print('Confirmed explicit 20-minute timeout annotation, 528 passing case executions and unchanged archive identities; four archive gates pass.')
