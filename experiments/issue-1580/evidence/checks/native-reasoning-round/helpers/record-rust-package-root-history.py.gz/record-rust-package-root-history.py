from pathlib import Path
import datetime, gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
source = Path('/tmp/issue-1580-research/templates/rust-complete')
paths = ['docs/case-studies/issue-19/pr-114-data/' + name for name in
    ['pr-commits.json', 'pr-conversation-comments.json', 'pr-details.json']]
identities = {row['path']: row for row in json.loads((root /
    'experiments/issue-1580/evidence/checks/rust-template-first-gate/pinned-file-identities.json').read_text())}
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert data['fullyReadFiles'] == 317
manifest = root / data['readLogManifest']
records = json.loads(manifest.read_text())
for path in paths:
    assert path not in {row['path'] for row in data['files']}
    raw = (source / path).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == identities[path]['sha256'] and len(raw.decode().splitlines()) == 1
    name = 'package-root-history-' + Path(path).name + '.read.txt.gz'
    read = ('FILE ' + path + ' LINES 1 SHA256 ' + digest + '\n1: ' + raw.decode().rstrip('\n') + '\n').encode()
    packed = gzip.compress(read, mtime=0)
    assert not (manifest.parent / name).exists()
    (manifest.parent / name).write_bytes(packed)
    records.append({'file': name, 'rawSha256': hashlib.sha256(read).hexdigest(),
        'archiveSha256': hashlib.sha256(packed).hexdigest()})
    data['files'].append({'path': path, 'lines': 1, 'sha256': digest, 'readLogs': [name],
        'literalReadRanges': [[1, 1]], 'literalReadLines': 1, 'literalSourceFullyRead': True,
        'formalAiPracticeImplementationVerified': False})
manifest.write_text(json.dumps(records, indent=2) + '\n')
data['files'].sort(key=lambda row: row['path'])
data['fullyReadFiles'] = len(data['files'])
data['fullyReadSourceLines'] = sum(row['literalReadLines'] for row in data['files'])
data['observedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
data['practiceDecisions'].append({
    'practice': 'Resolve package roots explicitly and preserve the caller working directory',
    'templateEvidence': paths,
    'assessment': 'Read all four historical commits, four conversation comments and complete merged PR details. A virtual command-stream cd changed process.cwd permanently, so later js/package.json became js/js/package.json. The first repair restored cwd; later feedback expanded the solution to shared JavaScript/Rust root discovery, root-before-language-subfolder precedence, explicit CLI/environment overrides and six caller migrations. The PR records syntax and language-subfolder checks but leaves CI and single-language manual qualification unchecked. Preserve the distinction between a merged claim and verified root/cwd behavior; the historical snapshot does not prove current Formal AI release publication. Its linked older requests are comparison evidence, not required sub-issues of #1580.',
    'status': 'complete-historical-package-root-records-read-current-runtime-qualification-open',
    'formalAiPaths': ['scripts/rust-paths.rs', 'scripts/cargo-package.rs',
        'rust/tests/unit/ci-cd/workspace_manifest_resolution.rs'], 'verification': None})
ledger.write_text(json.dumps(data, indent=2) + '\n')
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- Complete pinned Rust package-root PR commit, discussion and detail records are read and hash-verified: 320/373 files, 37,637 literal lines, 53 remaining. The original virtual-cd failure and expanded root-discovery feedback are distinct from syntax-only checks and current release qualification; no new runtime or independent reasoning credit.\n')
print('Literal pinned review: 320/373 files; 37,637 lines; 53 remain.')
