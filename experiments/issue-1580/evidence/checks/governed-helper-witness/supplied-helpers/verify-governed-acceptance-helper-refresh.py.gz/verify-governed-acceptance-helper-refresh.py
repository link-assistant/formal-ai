from pathlib import Path
import hashlib,json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/governed-acceptance-helper-verification')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(worker.pid);sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
 assert result.returncode in allowed,(name,result.returncode)
 print(json.dumps({'check':name,'status':result.returncode}),flush=True)
 return result.returncode
try:
 witness=root/'experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8'
 before=Path('/tmp/issue-1580-research/governed-acceptance-helper-refresh/previous.v8').read_bytes();after=witness.read_bytes()
 assert before!=after
 files=['rust/tests/web/rust-specification-fixture-integrity.test.mjs','rust/tests/web/rust-specification-unicode-identifiers.test.mjs']
 try:
  witness.write_bytes(before)
  for i,name in enumerate(files):run('regression-before-'+str(i+1),['node','--max-old-space-size=256','--test','--test-concurrency=1',name],(1,))
 finally:witness.write_bytes(after)
 for i,name in enumerate(files):run('regression-after-'+str(i+1),['node','--max-old-space-size=256','--test','--test-concurrency=1',name])
 owner=root/'rust/tests/web/issue-1580-template-observations.test.mjs';source=owner.read_text()
 for name in files:
  addition="import './"+Path(name).name+"';\n";assert addition not in source;source+='\n'+addition
 owner.write_text(source)
 run('maintained-observations',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(owner)])
 run('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size,check-changelog-fragment-js-twin,check-reconstructed-changelog'])
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'previousWitnessSha256':hashlib.sha256(before).hexdigest(),'currentWitnessSha256':hashlib.sha256(after).hexdigest(),'regressionsFailBeforePassAfter':True,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
