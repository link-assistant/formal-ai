from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys, traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'governed-witness-repair-preservation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 assert result.returncode==0,(name,result.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 prior=root/'experiments/issue-1580/evidence/checks/layered-and-native-repairs';index=prior/'records.jsonl';rows=[json.loads(line) for line in index.read_text().splitlines()];renamed=[]
 for row in rows:
  old=row['file'];new=old
  for a,b in [('github-pr-diff','github-pull-request-diff'),('pr-current','pull-request-current'),('staged-stat.','staged-statistics.')]:new=new.replace(a,b)
  if new==old:continue
  raw=(prior/old).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['archiveSha256'];assert not (prior/new).exists();(prior/old).rename(prior/new);row['file']=new
  assert hashlib.sha256((prior/new).read_bytes()).hexdigest()==row['archiveSha256'];renamed.append({'before':old,'after':new,'unchangedArchiveSha256':row['archiveSha256']})
 assert len(renamed)==6
 index.write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in rows));(out/'archive-renames.json').write_text(json.dumps(renamed,indent=2)+'\n')
 for row in rows:
  packed=(prior/row['file']).read_bytes();raw=gzip.decompress(packed)
  assert hashlib.sha256(packed).hexdigest()==row['archiveSha256'] and hashlib.sha256(raw).hexdigest()==row['rawSha256'] and len(raw)==row['bytes'] and len(raw.splitlines())==row['lines']
 review=json.loads((scratch/'governed-acceptance-helper-refresh/review.json').read_text())
 assert review['total']==1189 and review['carried']==221 and review['unsupported']==968
 verification=scratch/'governed-acceptance-helper-verification'
 assert 'ℹ pass 253' in (verification/'maintained-observations.stdout').read_text()
 doc=root/'docs/case-studies/issue-1580/governed-helper-witness-checkpoint.md'
 doc.write_text('# Governed helper witness repair\n\nLayered CI at ba01ef99 rejected stale governed source hashes in its fourth\nand fifth JavaScript groups. The source reader and its assertions correctly\nreported the earlier assertion-body extractions; they were not weakened.\n\nThe guarded refresh follows a complete object comparison: fifteen already\nunsupported test diagnostics now name conserved helper calls; one carried\nfixture hash and eight source-manifest entries change. All 1,189 native test\nidentities, 221 carried programs and 968 unsupported identities remain. Each\nmoved complete assertion body has identical lexical tokens to its prior owner.\n\nBoth existing integrity suites fail with the previous witness and pass with\nthe reviewed witness. Both are now imported by the maintained issue suite,\nwhose 253 tests pass. The first affected-gate replay found six abbreviated\nevidence filenames; their spelling and archive index were corrected without\nchanging any compressed bytes. Full original logs and intermediate failures\nare retained, with raw and archive hashes, byte counts and line counts.\n\nNo native execution or independent authorship is claimed. Hosted qualification\nand the wider issue remain unfinished. PR #1581 remains draft and unmerged:\nhttps://github.com/link-assistant/formal-ai/pull/1581.\n')
 fragment=root/'changelog.d/20261121_1580_governed_helper_witness.md';fragment.write_text('### Fixed\n\n- Verify the governed native-test source witness during the issue replay, preserving every test identity and carried program after helper extraction.\n')
 run('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size,check-changelog-fragment-js-twin,check-reconstructed-changelog'])
 run('whitespace',['git','diff','--check'])
 target=root/'experiments/issue-1580/evidence/checks/governed-helper-witness';target.mkdir(exist_ok=False);archives=[]
 def archive(source,relative):
  raw=source.read_bytes();packed=gzip.compress(raw,mtime=0);dest=target/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed)
  archives.append({'file':relative,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
 for name in ['governed-acceptance-extraction-delta','governed-acceptance-helper-refresh','governed-acceptance-helper-verification']:
  for source in sorted((scratch/name).rglob('*')):
   if source.is_file() and source.name!='pid.json':archive(source,name+'/'+str(source.relative_to(scratch/name))+'.gz')
 for source in sorted(out.glob('*')):
  if source.is_file() and source.name not in ['worker.log','pid.json']:archive(source,'final-verification/'+source.name+'.gz')
 helpers=['analyze-governed-extraction-delta.mjs','refresh-governed-acceptance-helper-witness.mjs','verify-governed-acceptance-helper-refresh.py',Path(__file__).name]
 for name in helpers:archive(scratch/name,'supplied-helpers/'+name+'.gz')
 for source in sorted((root/'experiments/issue-1580/evidence/commands').glob('*.json')):
  if source.name[:19]<'2026-11-21T16-50-00':continue
  data=json.loads(source.read_text())
  if any(name in data['request'] for name in helpers) or 'measure-abbreviations.mjs --list' in data['request']:archive(source,'formal-sessions/'+source.name+'.gz')
 (target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in archives))
 (target/'identity.json').write_text(json.dumps({**review,'maintainedIssueTestsPassed':253,'evidenceArchiveNamesCorrected':6,'previousEvidenceArchivesReverified':len(rows),'verificationAt':datetime.now(timezone.utc).isoformat()},indent=2)+'\n')
 plan=root/'experiments/issue-1580/work-plan.md';text=plan.read_text();start=text.index('## Current verification checkpoint');end=text.index('The entries below',start)
 text=text[:start]+'''## Current verification checkpoint

Published `ba01ef99` includes main `f574289f`; 31 of 32 workflows are terminal.
Layered CI rejects stale governed source hashes; its complete object delta is
reviewed and repaired locally. Both integrity suites fail before and pass after
the guarded refresh; the maintained replay now includes them and passes all
253 tests. All 1,189 test identities and 221 carried programs remain.
Six abbreviated archive names were corrected with every archive byte unchanged.
Nine additional conserved acceptance-helper extractions reduce source warnings
to 46. No native compilation or execution is claimed locally.

The still-running Pipeline must finish and every actionable failure must be
collected before the next push. The complete template/practice comparison,
remaining warnings, wider verification and final current-head CI remain open.
Independent reasoning remains 0/20. PR #1581 remains draft and unmerged.

'''+text[end:];plan.write_text(text)
 paths=[str(target.relative_to(root)),str(doc.relative_to(root)),str(fragment.relative_to(root)),'experiments/issue-1580/work-plan.md','experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8','rust/tests/web/issue-1580-template-observations.test.mjs',str(prior.relative_to(root))]
 assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
 assert run('preexisting-staged',['git','diff','--cached','--name-only']).strip()==''
 run('stage',['git','add','--',*paths]);run('staged-whitespace',['git','diff','--cached','--check']);run('staged-secret-scan',['bash','scripts/check-secrets.sh'])
 for row in archives:
  packed=(target/row['file']).read_bytes();raw=gzip.decompress(packed)
  assert hashlib.sha256(packed).hexdigest()==row['archiveSha256'] and hashlib.sha256(raw).hexdigest()==row['rawSha256'] and len(raw)==row['bytes'] and len(raw.splitlines())==row['lines']
 run('commit',['git','commit','-m','Refresh the reviewed native source witness and replay its integrity checks'])
 (out/'outcome.json').write_text(json.dumps({'committed':True,'head':run('committed-head',['git','rev-parse','HEAD']).strip(),'archives':len(archives),'maintainedTestsPassed':253,'pushed':False,'fullIssueComplete':False},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
