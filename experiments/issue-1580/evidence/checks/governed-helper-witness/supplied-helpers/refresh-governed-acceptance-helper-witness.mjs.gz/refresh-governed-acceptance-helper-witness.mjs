// Supplied review procedure; zero independent authorship credit.
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {deserialize,serialize} from 'node:v8';
import {specificationCases,tokenize,testFunctions} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/rust-specification-cases.mjs';
const root='/tmp/gh-issue-solver-1794900398048',out='/tmp/issue-1580-research/governed-acceptance-helper-refresh';
mkdirSync(out,{recursive:true});
const sha=value=>createHash('sha256').update(value).digest('hex');
const witness='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8';
const previousRaw=readFileSync(root+'/'+witness),previous=deserialize(previousRaw);
assert.equal(sha(previousRaw),'e0d0a26aacd53f4e5fe50097cd89e30e1a2074c1bac37e2177c205eb33112dd0');
const reader='scripts/lib/rust-specification-cases.mjs',readerSha=sha(readFileSync(root+'/'+reader));
assert.equal(readerSha,'861c6c5b40cfc8f4e99ad0ebece2cc3c20f941c6a1103dd5e8e70813c40ee0ca');
const priorRevision='8c15185e617f0a0a38edc991224163ae281b1b42';
const extraction=JSON.parse(readFileSync('/tmp/issue-1580-research/native-acceptance-headroom/extraction.json','utf8'));
const groups=extraction.files.filter(row=>row.owner.startsWith('rust/tests/unit/specification/'));
assert.equal(groups.length,4);
const candidate=deserialize(readFileSync('/tmp/issue-1580-research/governed-acceptance-extraction-delta/current.v8'));
const currentInventory=specificationCases(root);
assert.deepEqual(currentInventory.cases.map(x=>x.id),candidate.inventory.cases.map(x=>x.id));
const expected=deserialize(serialize(previous));
const manifest=new Map(expected.sourceManifest.map(x=>[x.path,x.sha256]));
const originalUnsupported=new Map(previous.inventory.unsupported.map((x,index)=>[x.id,{item:x,index}]));
const reviewed=[];let fixtureChanges=0;
for(const row of groups){
 const before=execFileSync('git',['show',priorRevision+':'+row.owner],{cwd:root,encoding:'utf8'});
 assert.equal(sha(before),manifest.get(row.owner));
 const after=readFileSync(root+'/'+row.owner,'utf8'),child=readFileSync(root+'/'+row.child,'utf8');
 const oldTests=testFunctions(tokenize(before)),currentTests=testFunctions(tokenize(after));
 assert.deepEqual(currentTests.map(x=>x.name),oldTests.map(x=>x.name),'every original native test remains');
 const helpers=testFunctions(tokenize(child.replace(/^pub\(super\) fn /gmu,'#[test]\nfn ')));
 assert.deepEqual(helpers.map(x=>x.name),row.names);
 const module=row.child.split('/').at(-1).slice(0,-3);
 for(const name of row.names){
  const original=oldTests.find(x=>x.name===name),helper=helpers.find(x=>x.name===name),wrapper=currentTests.find(x=>x.name===name);
  assert.deepEqual(helper.body,original.body,'the complete lexical assertion body is conserved: '+name);
  assert.deepEqual(wrapper.body,tokenize(module+'::'+name+'();'));
  const id=row.owner+'::'+name,entry=originalUnsupported.get(id);assert(entry,'a carried case must never be replaced by a wrapper');
  expected.inventory.unsupported[entry.index]={...entry.item,reason:'unsupported native call '+module+'::'+name,legacyReason:module+' : : '+name};
  reviewed.push({id,helper:row.child,completeAssertionTokensConserved:true});
 }
 for(const item of expected.inventory.cases)for(const fixture of item.program?.fixtures??[]){
  if(fixture.file!=='repo:'+row.owner)continue;
  assert.equal(fixture.sha256,sha(before));fixture.sha256=sha(after);fixtureChanges++;
 }
 assert(!manifest.has(row.child));manifest.set(row.owner,sha(after));manifest.set(row.child,sha(child));
}
expected.sourceManifest=[...manifest].sort(([a],[b])=>a<b?-1:a>b?1:0).map(([path,sha256])=>({path,sha256}));
assert.equal(reviewed.length,15);assert.equal(fixtureChanges,1);
assert.deepEqual(candidate,expected,'only the reviewed source hashes and unsupported helper-call diagnostics may change');
assert.deepEqual(candidate.inventory.cases.map(x=>x.id),previous.inventory.cases.map(x=>x.id));
assert.deepEqual(candidate.inventory.unsupported.map(x=>x.id),previous.inventory.unsupported.map(x=>x.id));
assert.equal(candidate.inventory.total,1189);assert.equal(candidate.inventory.cases.length,221);assert.equal(candidate.inventory.unsupported.length,968);
writeFileSync(out+'/previous.v8',previousRaw);
const args=['--max-old-space-size=256','rust/tests/web/rust-specification-unicode-identifiers.test.mjs','--refresh-reviewed-baseline','--reviewed-reader-sha='+readerSha,'--previous-baseline-sha='+sha(previousRaw)];
writeFileSync(out+'/refresh.stdout',execFileSync(process.execPath,args,{cwd:root,maxBuffer:1024*1024}));
const afterRaw=readFileSync(root+'/'+witness);assert.deepEqual(deserialize(afterRaw),expected);
writeFileSync(out+'/review.json',JSON.stringify({priorRevision,previousWitnessSha256:sha(previousRaw),currentWitnessSha256:sha(afterRaw),readerSha256:readerSha,
 total:1189,carried:221,unsupported:968,reviewed,fixtureChanges,sourceManifestChangedOwners:4,sourceManifestAddedHelpers:4,
 completeObjectDeltaReviewed:true,allNativeTestIdentitiesRetained:true,carriedCaseIdentitiesUnchanged:true,nativeExecutionVerified:false,independentAuthorshipCredit:0,fullIssueComplete:false},null,2)+'\n');
console.log('Reviewed 15 conserved assertion bodies, one fixture hash and eight source manifest identities; retained all 1189 original test identities and 221 carried programs.');
