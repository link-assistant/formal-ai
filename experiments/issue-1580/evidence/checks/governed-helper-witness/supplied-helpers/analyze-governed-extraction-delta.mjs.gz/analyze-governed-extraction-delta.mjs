import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,readdirSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {deserialize,serialize} from 'node:v8';
import {resolve,relative,isAbsolute} from 'node:path';
import {specificationCases} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/rust-specification-cases.mjs';
const root='/tmp/gh-issue-solver-1794900398048';
const out='/tmp/issue-1580-research/governed-acceptance-extraction-delta';mkdirSync(out,{recursive:true});
const witness=resolve(root,'experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8');
const hash=value=>createHash('sha256').update(value).digest('hex');
const previousRaw=readFileSync(witness),previous=deserialize(previousRaw),inventory=specificationCases(root);
for(const item of inventory.cases)for(const fixture of item.program?.fixtures??[])if(isAbsolute(fixture.file)){
 const path=relative(root,fixture.file);assert(!path.startsWith('..'));fixture.file='repo:'+path;
}
const sourceManifest=readdirSync(resolve(root,'rust/tests/unit/specification'),{recursive:true}).map(String).filter(x=>x.endsWith('.rs')).sort().map(x=>{
 const path='rust/tests/unit/specification/'+x;return{path,sha256:hash(readFileSync(resolve(root,path)))};
});
const current={inventory,sourceManifest};writeFileSync(out+'/previous.v8',previousRaw);writeFileSync(out+'/current.v8',serialize(current));
const changes=[];
function compare(a,b,path){
 if(Object.is(a,b))return;
 if(a&&b&&typeof a==='object'&&typeof b==='object'&&Array.isArray(a)===Array.isArray(b)){
  for(const key of new Set([...Object.keys(a),...Object.keys(b)]))compare(a[key],b[key],path.concat(key));
 }else changes.push({path,before:a,after:b});
}
// Use source identities for the manifest so inserted children cannot shift unrelated records.
compare(previous.inventory,current.inventory,['inventory']);
compare(Object.fromEntries(previous.sourceManifest.map(x=>[x.path,x.sha256])),Object.fromEntries(current.sourceManifest.map(x=>[x.path,x.sha256])),['sourceManifest']);
const report={previousWitnessSha256:hash(previousRaw),readerSha256:hash(readFileSync(resolve(root,'scripts/lib/rust-specification-cases.mjs'))),
 before:{total:previous.inventory.total,cases:previous.inventory.cases.length,unsupported:previous.inventory.unsupported.length},
 after:{total:inventory.total,cases:inventory.cases.length,unsupported:inventory.unsupported.length},changes};
writeFileSync(out+'/delta.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
