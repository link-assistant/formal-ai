from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
verify=json.loads((scratch/'php-pipe-annotation-verification/outcome.json').read_text());assert verify['allExpectedResults']
assert json.loads((scratch/'php-pipe-observations/outcome.json').read_text())['originalCurrentBytesIdentical']
target=root/'experiments/issue-1580/evidence/checks/php-pipe-and-annotation-readiness';target.mkdir(exist_ok=False)
sources=[]
for directory,names in {
 'php-pipe-observations':['focused.stdout','focused.stderr','outcome.json','precise-duplicate-review.txt'],
 'php-pipe-maintained-check':['outcome.json','entry.stdout','entry.stderr'],
 'php-pipe-annotation-verification':['outcome.json','old-warning.stdout','old-warning.stderr','maintained-entry.stdout','maintained-entry.stderr','verify.py','old-wrapper.sh','old-boundary.test.mjs'],
}.items():
 for name in names:sources.append((scratch/directory/name,directory+'--'+name))
for name in ['draft-php-pipe-observations.py','repair-annotation-fixture-readiness.py','verify-php-pipe-and-annotation-round.py','seal-php-pipe-and-annotation-evidence.py']:
 sources.append((scratch/name,'helper--'+name))
for name in ['Process.php','ProcessResult.php']:
 sources.append((root/'experiments/issue-1580/fixtures/php-template/scripts/src'/name,'fixture--'+name))
records=[]
for source,name in sources:
 raw=source.read_bytes();packed=gzip.compress(raw,mtime=0);filename=name+'.gz';(target/filename).write_bytes(packed)
 records.append({'source':str(source),'file':filename,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
(target/'records.json').write_text(json.dumps({'records':records,'allHashesVerified':True,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
for item in records:
 packed=(target/item['file']).read_bytes();raw=gzip.decompress(packed)
 assert hashlib.sha256(raw).hexdigest()==item['rawSha256'] and hashlib.sha256(packed).hexdigest()==item['archiveSha256']
ledger_path=root/'docs/case-studies/issue-1580/templates/php-current-delta-review.json'
ledger=json.loads(ledger_path.read_text());ledger['openObservations']=[
 'Confirmed at current b61e3347: Process::run blocks on finite stderr-first output because stdout is drained first; it also drops literal zero strings through PHP truthiness. Three maintained tests exercise the original source, a disposable concurrent-reader candidate and positive controls. Upstream report remains pending.',
 'Complete 608-file practice adoption and historical coverage remain incomplete.'
]
ledger['processPipeObservations']={'testFile':'experiments/issue-1580/template-php-pipe-integrity.test.mjs','testsPassed':3,'actualPhp':True,'perProcessMemoryLimitMiB':32,'outerProcessGroupDeadlineSeconds':2,'bytesPerStream':131072,'currentSourceSha256':'97a1b126035a71434739ecc962d73c74b44ea8ea802263b74031e04332b43bbf','originalCurrentBytesIdentical':True,'upstreamRepairApplied':False,'upstreamReport':None,'evidence':str(target.relative_to(root))}
ledger_path.write_text(json.dumps(ledger,indent=2)+'\n')
doc=root/'docs/case-studies/issue-1580/php-process-and-annotation-checkpoint.md'
doc.write_text('''# PHP process observations and annotation fixture readiness

The current PHP template at `b61e3347` retains the same `Process.php` bytes as
the original pinned fixture. Its SHA256 is
`97a1b126035a71434739ecc962d73c74b44ea8ea802263b74031e04332b43bbf`.
The helper drains stdout completely before reading stderr. A finite child that
writes 131072 stderr bytes first cannot finish while that pipe is full, and the
parent cannot finish reading stdout. A second defect converts literal `"0"`
output into an empty string through PHP's `?:` truthiness.

The three maintained tests execute the actual PHP helper and a disposable
candidate that drains both nonblocking streams with `stream_select`. The
original is killed as a process group after two seconds in the deadlock case;
the candidate preserves all 262144 bytes. Literal zero, small outputs and exit
codes 0 and 7 have explicit controls. Each PHP process has a 32 MiB limit and
captured output has a 524288-byte bound. This candidate has not been applied to
the upstream repository. Its existing issues were checked for pipe/deadlock
duplicates; the upstream report is pending publication of this evidence.

The first 119-case maintained run passed 118 cases and exposed a race in the
annotation warning fixture. A whole-second warning threshold could be reached
before Node wrote its partial stderr. The fixture now waits for the stderr
write callback before the initial liveness probe. Production wrapper behavior,
its one-second budget and the existing test timeouts are unchanged. The revised
fixture fails against the old wrapper because the annotation follows partial
stderr without a newline. The complete current maintained entry passes all
119 cases in 87.8 seconds. Both the initial failure and the expected old-wrapper
failure are retained alongside the successful current run.

Evidence is in `experiments/issue-1580/evidence/checks/php-pipe-and-annotation-readiness/`.
Every retained compressed stream verifies against its raw and archive hashes.
These supplied probes receive zero independent Formal AI authorship credit.
All eight complete template comparisons and full issue acceptance remain open.
PR: https://github.com/link-assistant/formal-ai/pull/1581
''')
plan=root/'experiments/issue-1580/work-plan.md'
with plan.open('a') as stream:stream.write('''

## Current PHP process defects and annotation fixture control

- [x] Confirm current PHP Process pipe deadlock and literal-zero loss with the
  actual pinned helper, a disposable repair and three bounded maintained tests.
- [x] Preserve the initial 118/119 fixture-order failure; synchronize partial
  stderr readiness without changing production budgets or test timeouts.
- [x] Demonstrate expected failure against the old wrapper and 119/119 success
  against the current source, with every retained evidence hash verified.
- [ ] Publish the evidence and report the PHP Process defects upstream.
- [ ] Finish all full-template/practice, original workflow and live acceptance
  requirements. No complete acceptance is inferred from these focused probes.
''')
paths=['experiments/issue-1580/template-php-pipe-integrity.test.mjs','experiments/issue-1580/budget-annotation-boundaries.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs',str(target.relative_to(root)),str(ledger_path.relative_to(root)),str(doc.relative_to(root)),'experiments/issue-1580/work-plan.md']
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
subprocess.run(['git','commit','-m','test: reproduce PHP process pipe failures and stabilize annotation probe'],cwd=root,check=True)
print(json.dumps({'retainedRecords':len(records),'maintainedTestsPassed':119,'fullIssueComplete':False,'pushExecuted':False}))
