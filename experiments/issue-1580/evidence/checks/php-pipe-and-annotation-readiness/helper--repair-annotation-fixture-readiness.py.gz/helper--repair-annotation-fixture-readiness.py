from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
path=root/'experiments/issue-1580/budget-annotation-boundaries.test.mjs';source=path.read_text()
source=source.replace("import {fileURLToPath} from 'node:url';", "import {fileURLToPath} from 'node:url';\nimport {mkdtempSync,writeFileSync,rmSync,existsSync} from 'node:fs';\nimport {tmpdir} from 'node:os';\nimport {join} from 'node:path';")
old='''test('budget warning starts a fresh line after partial stderr', {timeout: 12000}, () => {
  const result = run('1', "process.stderr.write('partial child stderr');setTimeout(()=>{},2200)",
    {TEST_BUDGET_ENFORCE: 'false'});
  assert.equal(result.status, 0, result.stderr);
  assert.match(result.stderr, /partial child stderr\\n::warning title=/u);
  assert.doesNotMatch(result.stderr, /::error/u);
});'''
new='''test('budget warning starts a fresh line after partial stderr', {timeout: 12000}, t => {
  const directory = mkdtempSync(join(tmpdir(), 'annotation-boundary-'));
  t.after(() => rmSync(directory, {recursive: true, force: true}));
  const ready = join(directory, 'ready');
  const environment = join(directory, 'environment.sh');
  // The warning clock may cross its first whole second before Node starts.
  // Hold only the fixture's initial liveness probe until stderr is flushed.
  writeFileSync(environment, `kill() {
    if [ "\\${1:-}" = '-0' ]; then
      for ((attempt=0; attempt<100; attempt++)); do
        [ -f "$ANNOTATION_BOUNDARY_READY" ] && break
        sleep 0.01
      done
      [ -f "$ANNOTATION_BOUNDARY_READY" ] || exit 126
    fi
    builtin kill "$@"
  }\\n`);
  const result = run('1',
    "process.stderr.write('partial child stderr',()=>require('node:fs').writeFileSync(process.env.ANNOTATION_BOUNDARY_READY,''));setTimeout(()=>{},2200)",
    {TEST_BUDGET_ENFORCE: 'false', BASH_ENV: environment, ANNOTATION_BOUNDARY_READY: ready});
  assert.equal(result.status, 0, result.stderr);
  assert.ok(existsSync(ready), 'partial stderr was flushed before observing the warning');
  assert.match(result.stderr, /partial child stderr\\n::warning title=/u);
  assert.doesNotMatch(result.stderr, /::error/u);
});'''
assert old in source;path.write_text(source.replace(old,new))
out=scratch/'annotation-readiness-repair';out.mkdir(exist_ok=False)
r=subprocess.run(['node','--test','--test-concurrency=1',str(path.relative_to(root))],cwd=root,capture_output=True)
(out/'focused.stdout').write_bytes(r.stdout);(out/'focused.stderr').write_bytes(r.stderr)
print(json.dumps({'exitCode':r.returncode,'budgetChanged':False,'testTimeoutChanged':False,'productionWrapperChanged':False}));assert r.returncode==0
