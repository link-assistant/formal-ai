from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
out=scratch/'php-pipe-observations';out.mkdir(exist_ok=False)
original=root/'experiments/issue-1580/fixtures/php-template/scripts/src/Process.php'
current=scratch/'current-php-focused-checks/source/scripts/src/Process.php'
assert original.read_bytes()==current.read_bytes()
test=root/'experiments/issue-1580/template-php-pipe-integrity.test.mjs';test.write_bytes((scratch/test.name).read_bytes())
entry=root/'rust/tests/web/issue-1580-template-observations.test.mjs'
entry.write_text(entry.read_text()+"import '../../../experiments/issue-1580/template-php-pipe-integrity.test.mjs';\n")
result=subprocess.run(['node','--test','--test-concurrency=1',str(test.relative_to(root))],cwd=root,capture_output=True)
(out/'focused.stdout').write_bytes(result.stdout);(out/'focused.stderr').write_bytes(result.stderr)
for name,args in [('existing-issues',['gh','issue','list','--repo','link-foundation/php-ai-driven-development-pipeline-template','--state','all','--limit','100','--json','number,title,body,url']),('current-tree',['gh','api','repos/link-foundation/php-ai-driven-development-pipeline-template/git/trees/b61e334703d93a15e08bf1a278e0df0a9d6e98a8','--paginate'])]:
 r=subprocess.run(args,cwd=root,capture_output=True);(out/(name+'.json')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);assert r.returncode==0
record={'focusedExitCode':result.returncode,'actualPhpMemoryLimitMiB':32,'finiteChildBytesPerStream':131072,'outerProcessGroupDeadlineSeconds':2,'currentCommit':'b61e334703d93a15e08bf1a278e0df0a9d6e98a8','sourceSha256':hashlib.sha256(current.read_bytes()).hexdigest(),'originalCurrentBytesIdentical':True,'upstreamRepairApplied':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(out/'outcome.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));assert result.returncode==0
