from pathlib import Path
import subprocess,json,sys
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'php-pipe-annotation-verification';out.mkdir(exist_ok=False)
worker=out/'verify.py';worker.write_text('''from pathlib import Path
import subprocess,json,time
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/php-pipe-annotation-verification');results=[]
source=(root/'experiments/issue-1580/budget-annotation-boundaries.test.mjs').read_text()
old=subprocess.check_output(['git','show','d490cd6e6bc70a590129c6aae6a0121c94a1bffb^:scripts/run-with-budget-warning.sh'],cwd=root)
(out/'old-wrapper.sh').write_bytes(old)
line="const wrapper = fileURLToPath(new URL('../../scripts/run-with-budget-warning.sh', import.meta.url));"
assert line in source
(out/'old-boundary.test.mjs').write_text(source.replace(line,'const wrapper = '+json.dumps(str(out/'old-wrapper.sh'))+';'))
commands=[('old-warning',['node','--test','--test-concurrency=1','--test-name-pattern','budget warning',str(out/'old-boundary.test.mjs')],1),('maintained-entry',['node','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'],0)]
for name,args,expected in commands:
 start=time.monotonic()
 with (out/(name+'.stdout')).open('w') as log,(out/(name+'.stderr')).open('w') as error:r=subprocess.run(args,cwd=root,stdout=log,stderr=error)
 row={'name':name,'exitCode':r.returncode,'expectedExitCode':expected,'seconds':round(time.monotonic()-start,3)};results.append(row);print(json.dumps(row),flush=True)
(out/'outcome.json').write_text(json.dumps({'results':results,'allExpectedResults':all(r['exitCode']==r['expectedExitCode'] for r in results),'fullIssueComplete':False},indent=2)+'\\n')
''')
with (out/'worker.log').open('wb') as log:p=subprocess.Popen([sys.executable,str(worker)],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print(json.dumps({'pid':p.pid,'finiteChecks':2}))
