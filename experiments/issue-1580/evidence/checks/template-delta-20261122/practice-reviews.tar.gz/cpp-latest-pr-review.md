https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/pull/40
Require complete evidence before passing the pipeline gate
Fixes #39

## Summary

- Use cancellation policy rows only after the reader exits successfully. Failed reads leave the policy unreadable, and the gate rejects the cancellation.
- Require a nonempty needs object with valid job IDs and completed results. Preserve successful and skipped jobs, failure reporting, and the existing superseded-cancellation exception.
- Add a patch changelog fragment for the automatic release.

## Reproduction and verification

- Run `NEEDS_JSON='{}' bash scripts/check-pipeline-status.sh`. The original gate exited 0 and printed `Pipeline passed.`. The repaired gate exits 1 and reports an invalid needs object.
- Place a copy of the gate beside an executable reader that prints `build\ttrue\n` and exits 29. Provide an existing workflow file, a cancelled build job, and distinct run and branch-head SHAs. The original gate exited 0. The repaired gate exits 1 and reports an unreadable policy.
- `python3 -m pytest -q scripts/tests/test_check_pipeline_status.py scripts/tests/test_unacquired_jobs.py scripts/tests/test_audit_dependencies.py` passed all 90 tests. The offline regressions reproduce both false successes on the original script and cover invalid needs records, legitimate superseded cancellations, current-head cancellations, and ordinary job results. Release Script Tests runs the regression suite in CI.
- Shell syntax and `git diff --check` passed.

## GitHub Actions

All four workflows triggered for `524fd69` passed. The CI/CD run includes 530 passing script tests, the OS/compiler matrix, packaging, and the final Pipeline Status check. [CI/CD Pipeline](https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/actions/runs/44965945556) · [Docs](https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/actions/runs/44965945538) · [Security](https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/actions/runs/44965945587) · [Broken Link Checker](https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/actions/runs/44965945639)

The latest default-branch Security failure predates this fix. Its native audit reports the missing repository secret `CONAN_AUDIT_PROVIDER_TOKEN_CONANCENTER` and supplies registration and setup instructions. [Default-branch Security run](https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/actions/runs/44673933081)
