https://github.com/link-foundation/go-ai-driven-development-pipeline-template/pull/24
fix(ci): reject malformed pipeline observations
## Summary

Require the pipeline status gate to receive a nonempty needs object. Each job record must provide a completed result of `success`, `failure`, `cancelled`, or `skipped`. The gate rejects malformed observations and identifies invalid job records in the log. Successful or skipped jobs still pass on PRs, and push and manual release events still require their existing checks and selected writer to succeed.

Fixes #23

The patch changeset supplies the existing release workflow's version-bump trigger.

## Reproduction and verification

Run from the repository root with Node. The original gate reports success for this empty payload and exits 0. The fixed gate reports that needs must be a nonempty object and exits 1.

```sh
node --input-type=module <<'NODE'
import { evaluate } from './scripts/ci/check-pipeline-status.mjs';
process.exitCode = evaluate({
  needs: {},
  event: 'pull_request',
  jobs: () => [],
  classify: () => [],
  githubActions: false,
});
NODE
```

- `bun test ./scripts/ci/runner-acquisition.test.mjs` passed all 31 tests. The 14 malformed-input cases failed against the original gate and pass with the fix. The suite also covers valid PR outcomes, push requirements, both manual release modes, and runner diagnostics.
- `bun scripts/validate-changeset.mjs`, `bun scripts/check-file-size.mjs`, and `git diff --check` passed.
- [Hosted Workflow checks](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/actions/runs/44964298736) passed on `757c869`, including all 82 script tests.
- [Hosted CI/CD Pipeline](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/actions/runs/44964298719) passed on `757c869`, including Linux, macOS, Windows, Build and Pipeline Status. Release jobs were skipped as expected on the PR event.
