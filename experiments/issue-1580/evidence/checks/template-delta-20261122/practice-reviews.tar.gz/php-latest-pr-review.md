https://github.com/link-foundation/php-ai-driven-development-pipeline-template/pull/35
Verify PR evidence, preserve UTF-8 release notes, and fix process capture
Fixes #34
Fixes #31
Fixes #32
Fixes #33

## Changes and verification

| Issue | Requirement and implementation | Regression coverage |
| --- | --- | --- |
| #31 | Require a successful fetch, a verified base commit, and a successful tree lookup. Use a temporary Git ref so pre-existing tracking refs and concurrent fetches cannot substitute other evidence. Permit a first manifest only when the verified base tree lacks the path and the head is a valid JSON object. | `PullRequestGuardsTest` runs the actual PHP CLI with disposable local Git repositories. It covers missing and stale refs after a failed fetch, a base branch with no tracking ref, a directory at the base manifest path, and valid and invalid bootstrap cases. |
| #31 | Require a readable head manifest and JSON objects on both sides of an existing-manifest comparison. Allow an absent version as a distinct state and reject a present non-string version on either side. Compare strictly so version addition, removal, and editing fail, while reformatting and leaving a version absent on both sides pass. | The CLI tests cover missing head files, malformed JSON, non-object documents, null and other non-string versions, version transitions, and the non-PR skip. |
| #31, related gate | Apply the same checked-fetch and comparison behavior to the changelog-fragment gate. Existing fragments can satisfy local validation. A PR needs a verified comparison and an added fragment. | The changelog CLI tests cover valid SHA and branch comparisons, an empty comparison, an unavailable SHA, a failed fetch, and the local mode. |
| #32 | Keep the default 120,000-byte limit and preserve complete UTF-8 characters in the body and notice. Clip the notice at a UTF-8 boundary when the cap is too small to fit it. | `ReleaseNotesTest` checks the exact default boundary, every partial and complete cut in two-, three-, and four-byte characters in both body and notice, caps of 0, 1, 7, and the notice boundary, plus ASCII and short Unicode controls. |
| #33 | Give stdout and stderr separate temporary streams, close stdin, and reap the child before reading both outputs. Distinguish read failures from valid string data and close the capture streams on every path. | `ProcessTest` checks a child that writes 131,072 bytes to stderr before writing the same amount to stdout. A process-group deadline bounds the regression. The tests also assert literal zero on both streams, exit codes 0 and 7, empty stderr, and binary output. |

The patch changelog fragment supplies the automated release trigger. The active PHP guard, release-note builder, and shared process helper were audited along with their callers. The sibling-language trees under the case study are captured upstream snapshots.

## Alternatives reviewed

- **Version guard.** Composer's schema validation can check manifest shape and types, and Composer documents when a version may be omitted. The guard uses PHP's exception-based JSON decoding and checked Git tree/blob reads so it can compare the PR with a verified base and run before Composer is installed. A temporary fetch ref scopes Git evidence to the current comparison. [Composer version schema](https://getcomposer.org/doc/04-schema.md#version) · [PHP JSON decoding](https://www.php.net/manual/en/function.json-decode.php) · [Git fetch](https://git-scm.com/docs/git-fetch) · [Git ls-tree](https://git-scm.com/docs/git-ls-tree) · [Git cat-file](https://git-scm.com/docs/git-cat-file)
- **Release notes.** `mb_strcut()` provides byte-based cuts when mbstring is available. The native implementation uses the first omitted byte to find a complete character boundary in valid UTF-8, using the same code for the body and notice and requiring no extra extension. [PHP mb_strcut](https://www.php.net/manual/en/function.mb-strcut.php)
- **Process capture.** Symfony Process offers separate output streams and platform-specific capture. Nonblocking pipes with `stream_select()` are an option on POSIX. PHP documents that selecting process pipes fails on Windows. Temporary files keep synchronous capture dependency-free and require writable temporary storage. [Symfony Process](https://symfony.com/doc/current/components/process.html) · [PHP stream_select](https://www.php.net/manual/en/function.stream-select.php) · [PHP proc_open](https://www.php.net/manual/en/function.proc-open.php) · [PHP tmpfile](https://www.php.net/manual/en/function.tmpfile.php)

## Reproduction and checks

Run the three test classes below against the pre-fix implementation at `b61e334` with the regression test files applied. The finite stderr-first child reaches its group deadline, literal zero becomes empty output, malformed or missing comparison evidence passes the version guard, and the exact default UTF-8 cut produces invalid bytes. The fixtures are local and the large-output probe is capped at 32 MiB of PHP memory.

```sh
php vendor/bin/phpunit --filter 'PullRequestGuardsTest|ReleaseNotesTest|ProcessTest'
```

The focused regression run passes 57 tests and 138 assertions on PHP 8.5.11. PHP-CS-Fixer and PHPStan pass on all changed PHP files. Strict Composer validation, local changeset validation, and the PHP file-size check also pass.

[Hosted PR checks](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/pull/35/checks)

All hosted checks triggered for `3796233` passed. The PHP 8.5.12 job passed 203 tests and 1,071 assertions, and the Changeset Check ran both the version and fragment gates. The release jobs were skipped as expected for a pull request. [PHP test job](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/actions/runs/44923018357/job/136903018715) · [Changeset Check](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/actions/runs/44923018357/job/136903018701)
