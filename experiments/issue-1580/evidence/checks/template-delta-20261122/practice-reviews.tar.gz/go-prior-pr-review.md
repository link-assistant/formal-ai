https://github.com/link-foundation/go-ai-driven-development-pipeline-template/pull/22
fix(ci): enforce release checks, Git comparisons, and pin integrity
## Summary

Bound workflow jobs, require release checks and publication to succeed, and fail when Git comparisons or pin integrity checks cannot establish their results. This PR covers all four sub-issues. The patch changeset supplies the existing release workflow's version-bump trigger.

Fixes #17
Fixes #18
Fixes #19
Fixes #20
Fixes #21

## Requirements, alternatives, and verification

### #17 · Give every job a timeout and enforce it in policy

The original `release.yml` has only one `timeout-minutes` entry, leaving eight jobs at GitHub's 360-minute default. The latest successful job records sampled from runs [41541261144](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/actions/runs/41541261144) and [41540240201](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/actions/runs/41540240201) show detection and changeset validation at 11–40 seconds, lint and tests at 26–146 seconds, and build at 21 seconds. The job limits are 5 minutes for detection, changeset validation and status, 15 minutes for lint, each test leg and build, and 30 minutes for each release writer to allow time for proxy verification and publication. Job-level limits also cover setup steps. The policy test enumerates all jobs across all workflow files and requires a positive job-level timeout below the platform default. [GitHub job timeout reference](https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax#jobsjob_idtimeout-minutes)

### #18 · Run both manual release modes after checks and reject unexpected skips

The original dispatch skips detection. GitHub applies implicit `success()` to lint, which propagates that skip to build and publication. The same dependency issue also skipped Build and Auto Release after a successful push in run [41541261144](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/actions/runs/41541261144), where changeset validation was intentionally skipped. Running detection on dispatch would add a job for an unused comparison. The workflow instead admits that specific dispatch skip and requires successful direct prerequisites for build and every release writer. Both manual writers fail if versioning produces no release commit. The terminal gate requires the selected writer and its checks on manual dispatch and requires the automatic writer and its checks on main pushes. Auto Release retains its normal no-op for pushes with nothing to publish. [GitHub dependency rules](https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax#jobsjob_idneeds) · [GitHub status functions](https://docs.github.com/en/actions/reference/workflows-and-actions/expressions#status-check-functions)

The workflow-policy tests assert the prerequisite expressions, and terminal status tests exercise successful, failed, cancelled, skipped and missing required results for both manual modes. An offline scheduling probe evaluated the original and updated workflow expressions with GitHub’s expression library. It reproduced all three skipped writers on the baseline, admitted only the selected writer after successful checks, and verified that each failed or cancelled prerequisite blocks the writer and fails terminal status. Both versioning modes also created and pushed the expected version commit and tag to disposable local Git remotes. Verification used offline scheduling and regular PR CI, with no live release dispatch. [GitHub Actions expression library](https://github.com/actions/languageservices/tree/main/expressions)

### #19 · Require the complete Git comparison and fail when it is unavailable

The original detector returns empty stdout after Git exits nonzero. A PR with missing comparison data can then look docs-only and skip checks, and a genuine initial commit can be misclassified. The detector and changeset validator share the PR merge-base-to-head comparison. A push uses its event's pre-push SHA and the checked-out head. Tree enumeration is reserved for a genuinely parentless commit. Failed or incomplete comparisons stop the relevant check before emitting change flags or accepting local changesets. Versioning also treats only Git's staged-diff exit status 1 as a change. [Git diff reference](https://git-scm.com/docs/git-diff) · [GitHub comparison rules](https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax#git-diff-comparisons)

GitHub path filters and [paths-filter](https://github.com/dorny/paths-filter) can classify changed files. The shared Git helper lets both scripts use one local comparison and retains the current output contract and added-changeset validation. Real temporary Git repositories reproduce the broken PR comparison, a missing merge base, a shallow checkout, an initial commit, and a multi-commit push. Additional controls exercise successful docs-only and code PRs, and a mocked staged-diff error verifies that versioning never reaches commit, tag or push.

### #20 · Apply integrity checks independently of the freshness policy

The original stale branch bypasses immutable ref verification. Both the action SHA and the container digest are now verified against the declared release even if the version is stale. Verification caches include the declared version, so a valid use of a ref cannot conceal another version's mismatch. Dependabot continues to propose updates, and GitHub immutable pinning complements the existing checker that verifies the release-to-ref mapping. [GitHub secure use reference](https://docs.github.com/en/actions/reference/security/secure-use#using-third-party-actions) · [Dependabot version updates](https://docs.github.com/en/code-security/how-tos/secure-your-supply-chain/secure-your-dependencies/configure-version-updates)

The regression injects current and stale releases and valid and invalid refs for both actions and containers, then runs the actual reporter on push, schedule, dispatch and PR events. Staleness alone remains a warning on non-PR events. Every integrity mismatch fails. A real PR-mode check also confirmed all 38 configured pins against upstream after refreshing Bun to 1.4.5, Go to 1.27.4, and setup-go to v7.1.0.

## Checks

- `bun test ./scripts` · 66 passed. The regression suite reproduced the reported failures against the unmodified branch.
- `actionlint -ignore queue` · passed with the repository's existing suppression. [actionlint](https://github.com/rhysd/actionlint)
- `bun scripts/check-file-size.mjs` and `git diff --check` · passed.
- `GITHUB_EVENT_NAME=pull_request bun scripts/ci/check-dependencies.mjs` · all 38 pins verified.

- [Hosted workflow checks for `bcb483e`](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/actions/runs/44679552778) · passed.
- [Hosted CI/CD Pipeline for `bcb483e`](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/actions/runs/44679552804) · passed, including Linux, macOS, Windows, Build and Pipeline Status. Release jobs were skipped as expected on the PR event.


https://github.com/link-foundation/go-ai-driven-development-pipeline-template/pull/16
fix(ci): warn on upstream releases outside PRs; rerun and explain jobs that never got a hosted runner
## Summary

This PR fixes both open issues. A newer upstream release no longer turns `main` red, and a job that never got a hosted runner is now labelled as an infrastructure failure and rerun automatically.

Fixes #15
Fixes #13
Fixes #14

## #13: Dependency-freshness gate keeps `main` red

**Root cause:** `scripts/ci/check-dependencies.mjs` exited 1 for any error on every event. A newer upstream release is external state: it is a fact about the world, not about the commit (CI/CD best-practices principle 17).

**Fix**
- `checkDependencies` now returns `{ stale, message }`. The new `report()` function decides the exit code by event:
  - `pull_request` and local runs: stale pins **fail** (exit 1).
  - `push`, `schedule` and `workflow_dispatch`: stale pins produce a `::warning` annotation plus a `$GITHUB_STEP_SUMMARY` section, and the step exits 0.
  - Pin-integrity mismatches, malformed pins and registry or lookup failures still **fail on every event**.
- The Go version from go.dev is now validated against the exact-version pattern, like the other upstream versions.
- New `.github/dependabot.yml` covers the `github-actions` ecosystem with a weekly schedule, a 7-day cooldown, and all bumps grouped into one PR. Dependabot updates the SHA and its `# vX.Y.Z` comment together, which keeps the integrity check passing. Tool pins Dependabot cannot see (Bun, Go, staticcheck, the actionlint digest, runner images) stay with the scheduled warning.
- `changeset-check` now skips PRs opened by `dependabot[bot]`. Otherwise every Dependabot PR would be red: workflow files count as code changes, and a CI-only pin bump publishes nothing.
- Bumped the pins that are stale today (Bun 1.4.2 → 1.4.4, Go 1.27.1 → 1.27.3, staticcheck 2026.2.1 → 2026.2.2), along with the README and CONTRIBUTING mentions. This PR touches `.github/**`, so its own PR gate would otherwise fail, as designed.

**Reproduce (before):** `GITHUB_EVENT_NAME=push bun scripts/ci/check-dependencies.mjs` with Bun pinned at 1.4.2 exited 1.
**After:** the same command exits 0 with `::warning title=Newer CI dependency releases::11 pinned CI dependencies …` and a step summary. With `GITHUB_EVENT_NAME=pull_request` it exits 1. I ran both live against upstream before bumping the pins.

**Tests** (`scripts/ci/check-dependencies.test.mjs`)
- a stale pin exits 1 on `pull_request` and on local runs
- a stale pin exits 0 with a warning and a summary on `push`, `schedule` and `workflow_dispatch`
- integrity failures exit 1 on every event
- current pins pass quietly

## #14: A macOS job that never gets a hosted runner fails the release gate and is never retried

The three numbered items below follow the issue's suggested fix.

1. **Automatic rerun.** New `.github/workflows/rerun-unacquired.yml` (`workflow_run` on "CI/CD Pipeline", `conclusion == 'failure'`, same repository only) runs `scripts/ci/rerun-unacquired.mjs`.
   - A job counts as unacquired only if it has **no runner, no steps, and** GitHub's `was not acquired by Runner` check-run annotation. Without the annotation check, jobs cancelled by a newer push or by a maintainer would also qualify.
   - The script runs `gh run rerun --failed`, which also reruns the dependent build, release and status jobs. It does this only when the unacquired jobs (plus the status gate) are the only failures.
   - **A job that ran steps and failed is never rerun.** Such a run is left alone, with a notice.
   - At most 3 attempts (two reruns). After that the script fails with `::error` and prints the `gh run rerun … --failed` command.
   - Permissions are `actions: write`, `checks: read` and `contents: read`. The workflow checks out only the default branch with `persist-credentials: false` and never runs code from the triggering run.
2. **Terminal status gate.** New `Pipeline Status` job (`if: always()`, needs every job) runs `scripts/ci/check-pipeline-status.mjs`. It fails when any needed job failed or was cancelled. Each unsuccessful job of the run is reported as one of:
   - **"Hosted runner not acquired"** (infrastructure, not code)
   - "Failed while running its steps"
   - "Cancelled before a runner picked it up"

   The report appears in annotations and in the step summary. If the API cannot be read, the gate still fails.
3. **Optional non-blocking macOS leg.** Not enabled, because it would hide real macOS failures from `needs.test.result`. The README documents the `continue-on-error: ${{ matrix.os == 'macos-15' }}` opt-in and its trade-off.

Shared classification lives in `scripts/ci/runner-acquisition.mjs`. Set the repository variable `CI_VERBOSE=true` to trace it (off by default).

**Tests** (`scripts/ci/runner-acquisition.test.mjs`)
- The fixtures use the real job shape from links-notation run 41477660740 (`kotlin / ios`: `cancelled`, `steps: []`, `runner_name: ""`).
- Rerun decisions are covered for each outcome: rerun, give up after the attempt limit, blocked by a real failure, nothing to do for superseded cancellations.
- Gate reporting is covered for infrastructure failures, code failures, and an unreadable API.
- `gh` pagination calls are checked.
- New workflow-policy tests check that:
  - the gate needs every job and has the right permissions;
  - the rerun workflow triggers on the right workflow name, only for failed same-repository runs, with minimal permissions and no checkout of the triggering ref;
  - Dependabot is configured and exempt from the changeset requirement.

**Live verification (read-only):** `experiments/issue-14-live-dry-run.sh` ran both scripts against the real links-notation run 41477660740.
- `kotlin / ios` was classified as `not-acquired`, and the gate printed `Hosted runner not acquired`.
- That run also had real failures, so the rerun script correctly declined to rerun it.
- With those jobs marked as gates, it printed `Dry run: gh run rerun 41477660740 --failed --repo link-foundation/links-notation`.

**Limitation:** `workflow_run` workflows only run from the default branch, so `rerun-unacquired.yml` cannot run on this PR. It takes effect after merge. Its logic is covered by the unit tests and the live dry run above, and it passes actionlint.

## Verification
- `bun test ./scripts`: 50 pass, 0 fail
- actionlint 1.7.12 (pinned digest, `-ignore queue`): no findings
- `GITHUB_EVENT_NAME=pull_request bun scripts/ci/check-dependencies.mjs`: `All 32 CI dependency pins match current stable releases`

