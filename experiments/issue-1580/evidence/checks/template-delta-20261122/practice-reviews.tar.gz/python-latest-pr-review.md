https://github.com/link-foundation/python-ai-driven-development-pipeline-template/pull/168
fix(ci): protect changelog fragments and run JavaScript checks
## Requirements and verification

| Issue | Implementation | Verification |
| --- | --- | --- |
| #165 | Preserve existing fragments regardless of modification time. Apply the description only when a single new Markdown fragment matches the path reported by Scriv. Return a failure when no fragment can be identified or when concurrent creation makes the result ambiguous. Keep the generated draft when no description is supplied. | Test future-dated history, normal creation with and without a description, zero and multiple new files, a concurrent writer as the sole new file, and a report naming an existing fragment. Run the actual CLI with Scriv 1.8.1 to verify its reported path. |
| #166 | Count `.js`, `.mjs`, and `.cjs` as code for push and pull-request comparisons, including the production helpers under `scripts/` and `.github/actions/`. Add recursive helper filters to both Workflows triggers. Preserve existing code classifications and the documentation, changelog, development-log, example, and experiment exclusions. | Run real Git comparisons for each extension as the only changed path. Assert both output values, check the named production helpers and excluded paths in root and `python/` layouts, and inspect both workflow triggers. |
| #167 | Resolve both native sub-issues in this pull request and include a closing keyword for each issue. | Confirm the native sub-issue list, read both reports and their comments, and verify all three closing references below. |

The patch release is prepared as `0.1.1` in the manifest, lockfile, package version, and release notes. Both fixes also have fragments for the PR changelog gate.

## Alternatives considered

- **Scriv.** Comparing the before and after path sets handles timestamp skew and detects multiple new files. A path-set comparison alone can still select the sole file from another writer after Scriv's editor discards its draft. Scriv 1.8.1 reports its intended path on stderr before creating the fragment. Matching that report to a new file lets this wrapper use Scriv's existing naming and configuration. Generating the file in Python would require duplicating Scriv's naming, template, and Git settings. [Scriv CLI documentation](https://scriv.readthedocs.io/en/1.6.1/commands.html) · [Scriv 1.8.1 source](https://github.com/nedbat/scriv/blob/1.8.1/src/scriv/create.py)
- **JavaScript gates.** Git already supplies complete changed paths in both event modes. The existing classifier can recognize the three Node.js extensions, and native Actions path filters can match them recursively before Workflows starts. The `dorny/paths-filter` action can route jobs after a workflow starts, but applying it here would duplicate the Git comparison and still require an event trigger. [Node.js package documentation](https://nodejs.org/api/packages.html) · [GitHub Actions filter syntax](https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax#filter-pattern-cheat-sheet) · [dorny/paths-filter](https://github.com/dorny/paths-filter)

## Reproduction and checks

Run these regressions with the project's locked development environment.

```sh
pytest tests/test_create_manual_changeset.py tests/test_detect_code_changes.py tests/test_workflows.py
```

With the original source, a future-dated fragment was overwritten, a successful Scriv process could overwrite history even when it created no file, JavaScript-only Git comparisons emitted `any-code-changed=false`, and the Workflows filters omitted script helpers. The added checks reproduced those failures before implementation.

The focused Python suite passed 309 tests with one existing layout-dependent skip. Ruff lint and formatting, the lockfile check, and the committed changelog fragment check passed.

The first full CI run exposed two manual-release tests that copied the live `pyproject.toml` and changelog while assuming a starting version of `0.1.0`. The tests now use a fixed fixture. All 34 release-script tests passed locally, and the full Python suite and package build passed on `ab9c850`. [Initial Python failure](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/actions/runs/44963993644/job/137028897715) · [Successful CI/CD run after the fixture fix](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/actions/runs/44964265206)

The Workflows transport test received a GitHub artifact lookup error immediately after finalization. Its retry then collided with the artifact from the first attempt. Both round-trip uploads and their matching lookups now include the current run attempt so reruns use their own evidence. [Workflows run and retry](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/actions/runs/44964265262)

The existing main-branch preflight already reports PyPI's `422 invalid-publisher` with the required trusted-publisher settings. The same response is advisory in PR checks. Actual publication requires a PyPI maintainer to configure a trusted publisher for this repository and `release.yml`. [Main-branch preflight](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/actions/runs/44857673625/job/136703566359)

All five workflows passed on `0cae045`. The Python job reported 978 passed and one layout-dependent skip. The artifact regression passed on both runs, including the deliberate same-run retry. [CI/CD Pipeline](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/actions/runs/44964565719) · [Workflows retry](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/actions/runs/44964565727/attempts/2) · [Security](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/actions/runs/44964565710) · [Docs](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/actions/runs/44964565714) · [Broken Link Checker](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/actions/runs/44964565801)

Fixes #165
Fixes #166
Fixes #167
