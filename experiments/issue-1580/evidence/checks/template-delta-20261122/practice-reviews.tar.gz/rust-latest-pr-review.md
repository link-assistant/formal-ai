https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/pull/260
fix(ci): align test timeout docs and paginate runner annotations
Fixes #259
Fixes #256
Fixes #257

## Changes

- **#256**. Document the workflow's 30-minute per-matrix-job backstop and 900-second (15-minute) test execution budget. Keep the existing guidance on explicit Cargo test-level timeouts. The budget regression reads both values from the release workflow and checks the README.
- **#257**. Read every check-run annotation page in the helper shared by automatic recovery and Pipeline Status. A job qualifies only when it finished with failure or cancellation, has no runner and no steps, and has an acquisition annotation. Reruns still require the newest workflow run for its branch and event and obey the configured attempt limit.
- Add a patch changelog fragment for the template's release pipeline.

## Implementation choices

For #256, the workflow configuration is the source of truth. Updating the README with a consistency regression is simpler than generating the documentation from workflow YAML. Changing the workflow to ten minutes would change the runner backstop and leave too little time for the existing 900-second test budget. [GitHub Actions job timeout](https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax#jobsjob_idtimeout-minutes)

For #257, GitHub returns 30 annotations per page by default and supports up to 100. The CLI already used by the helper follows pagination links and packages the returned pages as JSON with `--paginate --slurp`. Increasing the page size alone would still lose a match on annotation 101. An explicit Link-header loop or Octokit's pagination plugin could also fetch every page, with more code or an extra runtime dependency. [Check-run annotations API](https://docs.github.com/en/rest/checks/runs#list-check-run-annotations) · [GitHub CLI](https://cli.github.com/manual/gh_api) · [Octokit pagination](https://github.com/octokit/plugin-paginate-rest.js)

## Reproduction and verification

| Issue | Before | Regression |
| --- | --- | --- |
| #256 | Compare the README's 10-minute claim with `jobs.test.timeout-minutes` and the `Run tests` budget in `.github/workflows/release.yml`. | `readme_matches_the_ci_test_matrix_timeout_and_budget` fails against the old README and passes with the documented 30-minute backstop and 900-second budget. |
| #257 | Put the acquisition message at annotation 31 or 101 of a failed or cancelled job with no steps or runner. The old helper omits the job. | `python3 experiments/issue-226-regressions.py -v` covers annotations 31, 101, and 201, both callers, and negative cases including real failures and cancellations without an acquisition annotation. The fake CLI uses only local fixtures. |

The local JavaScript-first gate detected a Rust-only root. The existing Rust and Python CI suites include the regressions. A read-only smoke test against the recorded capacity failure still identifies `Build macos-arm64`. [Recorded capacity failure](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/actions/runs/40954664492)

All five workflows passed on `cd96c109014bf7c5e5387f134c106c28a5d70414`. The hosted Rust matrix and Release Script Tests logs confirm that both new regressions ran. [CI/CD Pipeline](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/actions/runs/44962967171) · [README regression](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/actions/runs/44962967171/job/137026130080) · [Runner recovery regressions](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/actions/runs/44962967171/job/137026130086) · [Workflows](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/actions/runs/44962967157) · [Desktop Release](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/actions/runs/44962967169) · [Security](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/actions/runs/44962967170) · [Broken Link Checker](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/actions/runs/44962967185)
