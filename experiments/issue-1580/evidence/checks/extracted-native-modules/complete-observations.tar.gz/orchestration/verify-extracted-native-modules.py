from pathlib import Path
import datetime,json,subprocess
out=Path("/tmp/issue-1580-research/extracted-native-local-checks")
out.mkdir(exist_ok=False)
commands=[
("headroom-regression",["timeout","600","node","--max-old-space-size=256","--test","--test-concurrency=1","rust/tests/web/issue-1580-source-warning-headroom.test.mjs"]),
("native-checkout-contracts",["timeout","600","node","--max-old-space-size=256","--test","--test-concurrency=1","rust/tests/web/default-branch-build-policy.test.mjs"]),
("affected-gates",["node","--max-old-space-size=256","experiments/formal_ai_subagent/local-gates.mjs","--only","check-file-size,check-file-size-js-twin,check-readable-code,check-abbreviations,check-changelog-fragment-js-twin,check-required-documentation,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-specification-in-javascript"]),
]
records=[]
for label,command in commands:
 with (out/(label+".log")).open("wb") as stream:
  p=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
 record={"label":label,"command":command,"exitCode":p.returncode,"finishedAt":datetime.datetime.now(datetime.timezone.utc).isoformat()}
 records.append(record)
 (out/"records.json").write_text(json.dumps(records,indent=2)+"\n")
 print(json.dumps(record),flush=True)
print(json.dumps({"allPassed":all(x["exitCode"]==0 for x in records),"fullIssueComplete":False}),flush=True)
raise SystemExit(any(x["exitCode"] for x in records))
