from pathlib import Path
import datetime,gzip,json,subprocess
r=Path("/tmp/issue-1580-research")
out=r/"extracted-native-prepush"
out.mkdir(exist_ok=False)
records=[]
def run(label,args):
 result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (out/(label+".stdout")).write_bytes(result.stdout)
 (out/(label+".stderr")).write_bytes(result.stderr)
 records.append({"label":label,"command":args,"exitCode":result.returncode})
 (out/"records.json").write_text(json.dumps(records,indent=2)+"\n")
 result.check_returncode()
 return result.stdout
branch=run("branch",["git","branch","--show-current"]).decode().strip()
assert branch=="issue-1580-8d61a32a61e1"
head=run("head-before",["git","rev-parse","HEAD"]).decode().strip()
assert head=="4f6b611d6a4e158647dbe04b34e73fd7d149f9d3"
run("source-whitespace",["git","diff","--cached","--check"])
run("source-diff",["git","diff","--cached","--no-ext-diff","--no-color"])
run("fetch-main",["git","fetch","origin","main"])
main=run("current-main",["git","rev-parse","origin/main"]).decode().strip()
run("main-ancestor",["git","merge-base","--is-ancestor",main,"HEAD"])
repo="link-assistant/formal-ai"
run("issue",["gh","issue","view","https://github.com/link-assistant/formal-ai/issues/1580","--json","number,title,body,updatedAt,state,url"])
for label,endpoint in [
 ("issue-comments","issues/1580/comments"),
 ("pr-comments","issues/1581/comments"),
 ("inline-comments","pulls/1581/comments"),
 ("reviews","pulls/1581/reviews")]:
 raw=run(label,["gh","api","repos/"+repo+"/"+endpoint,"--paginate","--slurp"])
 pages=json.loads(raw); values=[value for page in pages for value in page]
 print(json.dumps({"label":label,"count":len(values),"latest":[{"id":v["id"],"updatedAt":v.get("updated_at"),"body":v.get("body")} for v in values[-2:]]}),flush=True)
run("pr",["gh","pr","view","1581","--repo",repo,"--json","headRefOid,baseRefOid,isDraft,title,body,mergeStateStatus,statusCheckRollup"])
for status in ["in_progress","queued"]:
 value=json.loads(run("runs-"+status,["gh","run","list","--repo",repo,"--branch",branch,"--status",status,"--limit","100","--json","databaseId,workflowName,headSha,createdAt"]))
 assert not [item for item in value if item["headSha"]==head],value
print(json.dumps({"head":head,"main":main,"freshMetadataComplete":True,"at":datetime.datetime.now(datetime.timezone.utc).isoformat()}),flush=True)
