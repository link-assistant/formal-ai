from pathlib import Path
import datetime,json,subprocess
out=Path("/tmp/issue-1580-research/extracted-native-local-checks")
command=["node","--max-old-space-size=256","experiments/formal_ai_subagent/local-gates.mjs","--only","check-file-size,check-file-size-js-twin,check-readable-code,check-abbreviations,check-changelog-fragment-js-twin,check-required-documentation,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-specification-in-javascript"]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/"affected-gates-complete.log").open("wb") as stream:
 result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
record={"command":command,"exitCode":result.returncode,"startedAt":started,"finishedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"nine affected JavaScript gates; full issue remains unfinished"}
(out/"affected-gates-outcome.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record),flush=True)
raise SystemExit(result.returncode)
