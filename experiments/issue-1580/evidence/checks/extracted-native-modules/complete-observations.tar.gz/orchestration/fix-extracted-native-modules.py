from pathlib import Path
import re,subprocess
root=Path.cwd()
assert subprocess.check_output(["git","branch","--show-current"],text=True).strip()=="issue-1580-8d61a32a61e1"
assert subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()=="4f6b611d6a4e158647dbe04b34e73fd7d149f9d3"
changes=[
("rust/tests/unit/specification/chat_surface.rs","mod behavior_rule_grammar;",'#[path = "chat_surface/behavior_rule_grammar.rs"]\nmod behavior_rule_grammar;'),
("rust/tests/unit/specification/chat_surface.rs","mod rule_details;",'#[path = "chat_surface/rule_details.rs"]\nmod rule_details;'),
("rust/tests/unit/specification/debug_session.rs","mod calculator_origins;",'#[path = "debug_session/calculator_origins.rs"]\nmod calculator_origins;'),
("scripts/check-dependencies-latest.rs","pub use snapshot_io::{read_snapshot, render_lino, write_snapshot};",'pub use snapshot_io::{read_snapshot, write_snapshot};\n\n/// Render dependency findings through the shared snapshot implementation.\npub fn render_lino(findings: &[Finding], unverifiable: &[String]) -> String {\n    snapshot_io::render_lino(findings, unverifiable)\n}'),
("scripts/check-dependencies-snapshot.rs","#[cfg_attr(test, allow(dead_code))]\npub fn render_lino","pub fn render_lino"),
]
for path,before,after in changes:
 p=root/path; text=p.read_text();assert text.count(before)==1,(path,before);p.write_text(text.replace(before,after))
p=root/"scripts/check-dependencies-latest-tests.rs"
text=p.read_text()
assert "fn rendered_dependency_findings_preserve_all_observations" not in text
text += r'''
#[test]
fn rendered_dependency_findings_preserve_all_observations() {
    let finding = Finding {
        dependency: Dependency {
            ecosystem: Ecosystem::CratesIo,
            name: "drifting-crate".to_owned(),
            declared: Some("1.0".to_owned()),
            resolved: "1.0.0".to_owned(),
            path: PathBuf::from("rust/Cargo.toml"),
            line: 7,
            blocked: None,
        },
        latest: "1.1.0".to_owned(),
    };
    let output = render_lino(&[finding], &["unknown-crate".to_owned()]);
    assert_eq!(
        output,
        "currency_finding\n  ecosystem \"crates_io\"\n  name \"drifting-crate\"\n  resolved \"1.0.0\"\n  latest \"1.1.0\"\n  path \"rust/Cargo.toml\"\n  line 7\n  blocked false\n\nunverifiable_dependency\n  name \"unknown-crate\"\n\n"
    );
    assert!(render_lino(&[], &[]).is_empty());
}
'''
p.write_text(text)
p=root/"changelog.d/20261123_065000_extracted_native_modules.md"
assert not p.exists()
p.write_text("bump: patch\n\nFix child module paths in focused native reasoning tests and retain the dependency finding renderer without an unused re-export. Preserve all extracted test cases and verify renderer output through the native workflow contracts.\n")
print("Updated three child-module declarations, preserved the renderer API, and added output coverage.")
