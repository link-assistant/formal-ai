from pathlib import Path
import subprocess,json,re,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/archive-warning-consumer-review');out.mkdir(exist_ok=False)
log=(Path('/tmp/issue-1580-research/remaining-source-warning-paths/check-file-size.log')).read_text();paths=re.findall(r'^::warning file=([^:]+)::',log,re.M);assert len(paths)==9
records=[]
for name in paths:
 p=root/name;raw=p.read_bytes();terms=[p.name,str(Path(name).parent)]
 record={'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'lines':len(raw.splitlines()),'searches':[]};print('CAPTURE',name)
 for term in terms:
  r=subprocess.run(['rg','--hidden','-l','-F','--glob','!*.gz',term,'scripts','rust','js','experiments','docs','data','.github'],cwd=root,text=True,capture_output=True);assert r.returncode in (0,1)
  matches=r.stdout.splitlines();active=[q for q in matches if '/evidence/' not in q]
  record['searches'].append({'term':term,'allMatches':matches,'nonEvidenceMatches':active});print('TERM',term,'ALL',len(matches),'NON_EVIDENCE',active)
 records.append(record)
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
