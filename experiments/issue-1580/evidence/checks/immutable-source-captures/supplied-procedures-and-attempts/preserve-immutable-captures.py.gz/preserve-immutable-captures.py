from pathlib import Path
import subprocess,json,gzip,hashlib,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'immutable-capture-preservation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(p.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==0,(name,r.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 assert json.loads((scratch/'immutable-warning-archive-validation/outcome.json').read_text())['passed']
 assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
 target=root/'experiments/issue-1580/evidence/checks/immutable-source-captures';target.mkdir(exist_ok=False);records=[]
 def archive(raw,name):
  packed=gzip.compress(raw,mtime=0);dest=target/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed);assert gzip.decompress(packed)==raw
  records.append({'path':str(dest.relative_to(target)),'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
 for dirname in ['immutable-warning-archive-validation','archive-warning-consumer-review','immutable-warning-consumers','remaining-source-warning-paths']:
  for p in sorted((scratch/dirname).rglob('*')):
   if p.is_file():archive(p.read_bytes(),dirname+'/'+str(p.relative_to(scratch/dirname)))
 for name in ['archive-immutable-warning-captures.py','review-archive-warning-consumers.py','inventory-immutable-warning-consumers.py',Path(__file__).name,'archive-immutable-warning-captures-driver.log','review-archive-warning-consumers-driver.log','inventory-immutable-warning-consumers-driver.log']:
  p=scratch/name
  if p.exists():archive(p.read_bytes(),'supplied-procedures-and-attempts/'+name)
 (target/'records.jsonl').write_text(''.join(json.dumps(r,separators=(',',':'))+'\n' for r in records))
 plan=root/'experiments/issue-1580/work-plan.md';s=plan.read_text().replace('Nine retained source-capture size warnings\nremain under unchanged limits.','Eight immutable source captures are losslessly archived with a consumed complete-byte\nconservation regression; one live canonical workflow size warning remains under\nunchanged limits.');plan.write_text(s)
 run('documentation-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-changelog-fragment-js-twin,check-reconstructed-changelog,check-file-size'])
 rows=json.loads((root/'experiments/issue-1580/fixtures/immutable-source-captures.json').read_text());paths=[s for r in rows for s in [r['originalPath'],r['archivePath']]]
 paths+=['experiments/issue-1580/fixtures/immutable-source-captures.json','experiments/issue-1580/immutable-source-captures.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs','changelog.d/20261121_1580_lossless_source_captures.md','docs/case-studies/issue-1580/immutable-source-captures.md',str(target.relative_to(root)),str(plan.relative_to(root))]
 run('stage',['git','add','--',*paths]);run('whitespace',['git','diff','--cached','--check']);run('commit',['git','commit','-m','Preserve complete historical captures in lossless archives'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'head':run('head',['git','rev-parse','HEAD']).strip(),'pushed':False,'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
except BaseException:traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
