from pathlib import Path
import json,gzip,hashlib,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'immutable-warning-archive-validation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(p.pid);sys.exit(0)
def run(name,args,expect=0):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode,'expected':expect}),flush=True);assert r.returncode==expect,(name,r.returncode)
try:
 inputs=json.loads((scratch/'archive-warning-consumer-review/records.json').read_text());inputs=[r for r in inputs if '/dormant-staged-release/' not in r['path']];assert len(inputs)==8
 rows=[]
 for row in inputs:
  p=root/row['path'];raw=p.read_bytes();assert len(raw)==row['bytes'];assert hashlib.sha256(raw).hexdigest()==row['sha256'];assert not Path(str(p)+'.gz').exists()
  rows.append({'originalPath':row['path'],'archivePath':row['path']+'.gz','rawBytes':len(raw),'rawSha256':row['sha256'],'lines':row['lines']})
 fixture=root/'experiments/issue-1580/fixtures/immutable-source-captures.json';fixture.write_text(json.dumps(rows,indent=2)+'\n')
 test=root/'experiments/issue-1580/immutable-source-captures.test.mjs';test.write_text('''import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync, existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
const captures=JSON.parse(readFileSync(new URL('./fixtures/immutable-source-captures.json',import.meta.url)));
test('all eight historical source captures retain their original complete bytes',()=>{
 assert.equal(captures.length,8);
 assert.equal(new Set(captures.map(row=>row.originalPath)).size,8);
 for(const row of captures){
  assert.equal(row.archivePath,row.originalPath+'.gz');
  const raw=gunzipSync(readFileSync(row.archivePath));
  assert.equal(raw.length,row.rawBytes,row.originalPath);
  assert.equal(createHash('sha256').update(raw).digest('hex'),row.rawSha256,row.originalPath);
  assert.equal(raw.toString().split('\\n').length-(raw.at(-1)===10?1:0),row.lines,row.originalPath);
  assert.equal(existsSync(row.originalPath),false,row.originalPath);
 }
});
''')
 run('conservation-before',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test.relative_to(root))],1)
 for row in rows:
  p=root/row['originalPath'];raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);Path(str(p)+'.gz').write_bytes(packed);assert gzip.decompress(packed)==raw;p.unlink()
 run('conservation-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test.relative_to(root))])
 entry=root/'rust/tests/web/issue-1580-template-observations.test.mjs';s=entry.read_text();needle="import '../../../experiments/issue-1580/traceability-partition.test.mjs';";assert s.count(needle)==1;s=s.replace(needle,needle+"\nimport '../../../experiments/issue-1580/immutable-source-captures.test.mjs';");entry.write_text(s)
 (root/'changelog.d/20261121_1580_lossless_source_captures.md').write_text('Archive eight immutable historical source captures losslessly, preserving their\noriginal paths and digests in a consumed conservation fixture.\n')
 doc=root/'docs/case-studies/issue-1580/immutable-source-captures.md';doc.write_text('''# Complete historical capture conservation

Eight historical source captures exceeded the existing maintained-source warning
thresholds. They are now gzip archives beside their former paths. The consumed
fixture `experiments/issue-1580/fixtures/immutable-source-captures.json` records
every original logical path, complete byte count, line count and SHA-256 digest.
`gzip -dc <original-path>.gz` recovers the exact original bytes.

The focused conservation regression fails before archival and passes afterward.
It verifies all eight complete contents against the pre-change digests. The
archive and original bytes were also compared directly during the change.
No source-size limit, warning threshold or historical transcript was weakened.

Exact-name and parent-directory searches found historical transcript/index
references for these captures. One historical verifier refers to a former
`/private/tmp/` workspace, rather than consuming the retained repository file;
its original script is retained unchanged. The canonical dormant staged workflow
has live consumers, so it remains a separate, unfinished size warning.

These transport changes earn zero independent Formal AI authorship credit. The
wider issue is unfinished. Pull request:
https://github.com/link-assistant/formal-ai/pull/1581.
''')
 run('size-gate',['node','--max-old-space-size=256','scripts/check-file-size.mjs'])
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'passed':True,'archivedCaptures':8,'remainingSourceWarnings':1,'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
except BaseException:traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
