from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/immutable-warning-consumers');out.mkdir(exist_ok=False)
names=['original-release-workflow.txt','project-parity-pre-repair-observations.json','reconstructed-statistics','preimage-web_search_intent','reconstructed-web_search_intent','preimage-statistics','original-release-workflow.yml','archive-selection']
rows=[]
for term in names:
 r=subprocess.run(['rg','-l','-F','--glob','!*.gz','--glob','!commands/**',term,'scripts','rust','js','experiments','docs','data','.github'],cwd=root,text=True,capture_output=True);paths=r.stdout.splitlines();assert r.returncode in (0,1)
 rows.append({'term':term,'consumerPaths':paths});print(term,'consumers',len(paths));print('\n'.join(paths))
(out/'consumers.json').write_text(json.dumps(rows,indent=2)+'\n')
