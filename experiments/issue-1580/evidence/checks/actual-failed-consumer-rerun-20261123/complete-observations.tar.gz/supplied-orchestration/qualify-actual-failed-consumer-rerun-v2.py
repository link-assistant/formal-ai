from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,time
r=Path('/tmp/issue-1580-research')
root=r/'failed-consumer-rerun-qualification'
repo='link-assistant/formal-ai'
run=45085971679
before=json.loads((root/'before-summary.json').read_text())
records=json.loads((root/'records.json').read_text())
def capture(label,argv,compress=False):
    p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    for stream,raw in [('stdout',p.stdout),('stderr',p.stderr)]:
        (root/(label+'.'+stream+('.gz' if compress else ''))).write_bytes(gzip.compress(raw,mtime=0) if compress else raw)
    records.append({'label':label,'command':argv,'exitCode':p.returncode,'stdoutSha256':hashlib.sha256(p.stdout).hexdigest(),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    (root/'records.json').write_text(json.dumps(records,indent=2)+'\n')
    p.check_returncode()
    return p.stdout
def api(label,endpoint,pages=False):
    argv=['gh','api','--allow-escape-sequences',endpoint]
    if pages:argv+=['--paginate','--slurp']
    return json.loads(capture(label,argv))
try:
    assert before['sourceDeltaEmpty'] and before['comparedArtifactPaths']
    assert before['attempt']==1 and before['status']=='completed' and before['conclusion']=='failure'
    artifact=[a for a in before['artifacts'] if a['id']==14778573986]
    assert len(artifact)==1 and not artifact[0]['expired']
    artifact=artifact[0]
    request=[r for r in records if r['label']=='request-rerun-failed']
    assert len(request)==1 and request[0]['exitCode']==0
    requested_at=datetime.datetime.fromisoformat(request[0]['at'])
    def reexecuted(job):
        return bool(job.get('started_at')) and datetime.datetime.fromisoformat(job['started_at'].replace('Z','+00:00')) >= requested_at
    for observation in range(240):
        value=api(f'observation-{observation:03}',f'repos/{repo}/actions/runs/{run}')
        assert value['head_sha']==before['source'] and value['run_attempt']<=2,value
        print(json.dumps({'observation':observation,'attempt':value['run_attempt'],'status':value['status'],'conclusion':value['conclusion']}),flush=True)
        if value['run_attempt']==2 and value['status']=='completed':break
        time.sleep(30)
    else:raise RuntimeError('Bounded failed-consumer observation count exhausted')
    pages=api('attempt-2-jobs',f'repos/{repo}/actions/runs/{run}/attempts/2/jobs?per_page=100',True)
    jobs=[j for page in pages for j in page['jobs']]
    pages=api('attempt-2-artifacts',f'repos/{repo}/actions/runs/{run}/artifacts?per_page=100',True)
    artifacts=[a for page in pages for a in page['artifacts']]
    retained=[a for a in artifacts if a['id']==artifact['id']]
    assert len(retained)==1 and not retained[0]['expired']
    assert not [a for a in artifacts if a['name'].startswith(f'native-contracts-{run}-2-')]
    assert not [j for j in jobs if 'Compile focused native contracts once' in j['name'] and reexecuted(j)]
    native=[j for j in jobs if 'Native contracts (' in j['name'] and reexecuted(j)]
    before_native={j['name']:j['id'] for j in before['failedJobs'] if 'Native contracts (' in j['name']}
    assert len(native)==3 and {j['name'] for j in native}==set(before_native)
    log_receipts=[]
    for job in native:
        assert job['id']!=before_native[job['name']]
        raw=capture('attempt-2-job-'+str(job['id']),['gh','api','--allow-escape-sequences',f'repos/{repo}/actions/jobs/{job["id"]}/logs'],True)
        log=raw.decode()
        assert artifact['name'] in log and str(artifact['id']) in log,(job['id'],'original artifact not observed')
        assert 'test result:' in log,(job['id'],'native tests not executed')
        log_receipts.append({'jobId':job['id'],'name':job['name'],'conclusion':job['conclusion'],'originalArtifactNameObserved':True,'originalArtifactIdObserved':True,'nativeTestExecutionObserved':True})
    capture('attempt-2-complete-log',['gh','run','view',str(run),'--attempt','2','--repo',repo,'--log'],True)
    result={'complete':True,'run':run,'source':before['source'],'attempt':2,'operation':'gh run rerun --failed','producerReran':False,'reexecutionBound':requested_at.isoformat(),'reusedJobRecords':[{'jobId':j['id'],'name':j['name'],'startedAt':j['started_at']} for j in jobs if not reexecuted(j)],'originalArtifactId':artifact['id'],'originalArtifactName':artifact['name'],'originalProducerArtifactRetained':True,'newProducerUploadObserved':False,'nativeConsumers':log_receipts,'conclusion':value['conclusion'],'artifactSourcesEqualCurrentHead':before['comparedArtifactPaths'],'scope':'Actual rerun of previously failed consumers on preserved historical source. Existing semantic assertion failures may repeat. This proves prior-producer lookup and execution only, not current-source native success or full issue acceptance.','nativeArchiveDownloadedLocally':False,'independentAuthorshipCredit':0,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (root/'outcome.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
except Exception as error:
    (root/'error.json').write_text(json.dumps({'error':str(error),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
    raise
