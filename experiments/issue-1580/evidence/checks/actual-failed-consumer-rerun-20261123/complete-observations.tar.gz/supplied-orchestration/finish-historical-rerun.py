from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,zipfile
root=Path('/tmp/issue-1580-research/failed-consumer-rerun-qualification')
before=json.loads((root/'before-summary.json').read_text())
records=json.loads((root/'records.json').read_text())
request=[r for r in records if r['label']=='request-rerun-failed']
assert len(request)==1 and request[0]['exitCode']==0
requested_at=datetime.datetime.fromisoformat(request[0]['at'])
def replay(label):
 return gzip.decompress((root/(label+'.stdout.gz')).read_bytes()) if (root/(label+'.stdout.gz')).exists() else (root/(label+'.stdout')).read_bytes()
jobs=[j for page in json.loads(replay('attempt-2-jobs')) for j in page['jobs']]
artifacts=[a for page in json.loads(replay('attempt-2-artifacts')) for a in page['artifacts']]
original=[a for a in before['artifacts'] if a['id']==14778573986]
assert len(original)==1
artifact=original[0]
retained=[a for a in artifacts if a['id']==artifact['id']]
assert len(retained)==1 and not retained[0]['expired']
assert not [a for a in artifacts if a['name'].startswith('native-contracts-45085971679-2-')]
def reran(j):return bool(j.get('started_at')) and datetime.datetime.fromisoformat(j['started_at'].replace('Z','+00:00'))>=requested_at
assert not [j for j in jobs if 'Compile focused native contracts once' in j['name'] and reran(j)]
native=[j for j in jobs if 'Native contracts (' in j['name'] and reran(j)]
previous={j['name']:j['id'] for j in before['failedJobs'] if 'Native contracts (' in j['name']}
assert len(native)==3 and {j['name'] for j in native}==set(previous)
receipts=[]
for j in native:
 raw=replay('attempt-2-job-'+str(j['id']));s=raw.decode()
 assert artifact['name'] in s and str(artifact['id']) in s and 'test result:' in s and j['id']!=previous[j['name']]
 lines=s.splitlines()
 selected=[{'line':i+1,'text':line} for i,line in enumerate(lines) if 'test result:' in line or artifact['name'] in line or str(artifact['id']) in line or 'FAILED' in line or 'panicked at' in line]
 receipts.append({'jobId':j['id'],'name':j['name'],'conclusion':j['conclusion'],'startedAt':j['started_at'],'completedAt':j['completed_at'],'originalArtifactNameObserved':True,'originalArtifactIdObserved':True,'nativeTestExecutionObserved':True,'logSha256':hashlib.sha256(raw).hexdigest(),'selectedLogLines':selected})
archive=root/'attempt-2-available-logs.zip'
assert not archive.exists()
cmd=['gh','api','repos/link-assistant/formal-ai/actions/runs/45085971679/attempts/2/logs']
with archive.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.PIPE)
(root/'attempt-2-available-logs.stderr.txt').write_bytes(p.stderr)
p.check_returncode()
assert zipfile.is_zipfile(archive)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 members=[{'name':i.filename,'bytes':i.file_size,'crc32':i.CRC} for i in z.infolist()]
result={'complete':True,'run':45085971679,'source':before['source'],'attempt':2,'operation':'gh run rerun --failed','producerReran':False,'reexecutionBound':requested_at.isoformat(),'originalArtifactId':artifact['id'],'originalArtifactName':artifact['name'],'originalProducerArtifactRetained':True,'newProducerUploadObserved':False,'nativeConsumers':receipts,'conclusion':'failure','artifactSourcesEqualComparedHead':before['comparedArtifactPaths'],'scope':'Actual rerun of previously failed consumers on preserved historical source. Repeated semantic assertion failures are not current-source failures. This proves prior-producer lookup and execution only, not current-source native success or full issue acceptance.','nativeArchiveDownloadedLocally':False,'wholeCliLogFailed':True,'fallbackAvailableLogArchive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),'members':members,'roundTripVerified':True},'missingLogMembersAreNotExecutionEvidence':True,'independentAuthorshipCredit':0,'fullIssueAcceptance':False,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(root/'outcome.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
