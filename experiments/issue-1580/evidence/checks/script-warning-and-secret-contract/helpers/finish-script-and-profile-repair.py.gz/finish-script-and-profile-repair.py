from pathlib import Path
import gzip, hashlib, json, os, resource, subprocess, sys, time

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/script-size-repair-final')
if len(sys.argv) == 1:
    base.mkdir(exist_ok=False)
    with (base / 'worker.log').open('wb') as stream:
        child = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root,
                                 stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': child.pid, 'directory': str(base)}))
    sys.exit(0)

env = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
rows = []
def check(name, argv, expected=0, data=None):
    started = time.monotonic()
    with (base / (name + '.stdout')).open('wb') as out, (base / (name + '.stderr')).open('wb') as err:
        result = subprocess.run(argv, cwd=root, env=env, input=data, stdout=out, stderr=err)
    rows.append({'name': name, 'argv': argv, 'status': result.returncode,
                 'expectedStatus': expected, 'seconds': round(time.monotonic() - started, 3)})
    (base / 'results.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == expected, name

profile = 'rust/tests/web/fast-pull-request-production-profile.test.mjs'
check('profile-before', ['timeout', '600', 'node', '--max-old-space-size=256', '--test',
      '--test-concurrency=1', '--test-name-pattern=secrets scanning retains full history', profile], 1)
failure = (base / 'profile-before.stdout').read_text()
assert 'full reviewed secret selection/guard lost: git ls-files -z | exclude' in failure
path = root / profile
source = path.read_text()
old = "    'git diff --name-only --diff-filter=ACMRT -z \"$merge_base\" HEAD',\n    'git ls-files -z | exclude','SECRETLINT_VERSION:-13.0.5',"
new = "    'read_inventory git diff --name-only --diff-filter=ACMRT -z \"$merge_base\" HEAD',\n    'read_inventory git ls-files -z','if ! wait \"$producer\"; then',\n    'SECRETLINT_VERSION:-13.0.5',"
assert source.count(old) == 1
path.write_text(source.replace(old, new))

files = [f'scripts/{name}{suffix}.rs' for name in ('assemble-requirements', 'normalize-ordered-lists')
         for suffix in ('', '-tests')] + ['scripts/self-hosting-metric.rs', 'scripts/self-hosting-metric-cli.rs']
for name in files[-2:]:
    (base / (Path(name).name + '.before-format.gz')).write_bytes(gzip.compress((root / name).read_bytes(), mtime=0))
check('format-write', ['rustfmt', '--edition', '2024', '--config', 'skip_children=true', *files])
parent = (root / files[-2]).read_text()
cli = (root / files[-1]).read_text().split('use super::*;\n\n', 1)[1].rstrip() + '\n'
declaration = '#[path = "self-hosting-metric-cli.rs"]\nmod cli;\n'
assert parent.count(declaration) == 1
reconstructed = parent.replace(declaration, cli.replace('pub(super) fn run()', 'fn run()', 1), 1)
reconstructed = reconstructed.replace('if let Err(error) = cli::run() {', 'if let Err(error) = run() {', 1)
original = subprocess.check_output(['git', 'show', 'HEAD:scripts/self-hosting-metric.rs'], cwd=root)
def formatted(data):
    return subprocess.check_output(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=data, cwd=root)
before, after = formatted(original), formatted(reconstructed.encode())
assert before == after
(base / 'cli-formatted-inverse.json').write_text(json.dumps({
    'source': files[-2], 'cliModule': files[-1], 'normalizedExactInverse': True,
    'formattedOriginalSha256': hashlib.sha256(before).hexdigest(),
    'parentLines': len(parent.splitlines()), 'moduleLines': len((root / files[-1]).read_text().splitlines()),
    'independentAuthorshipCredit': 0}, indent=2) + '\n')
check('format-check', ['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--check', *files])
for name, test_file in [
    ('profile-after', profile),
    ('subprocess-boundaries', 'rust/tests/web/bounded-subprocess-boundaries.test.mjs'),
    ('script-twins', 'rust/tests/web/scripts-js-twins.test.mjs'),
    ('ordered-module-lists', 'rust/tests/web/issue-1569-ordered-module-lists.test.mjs'),
    ('metric-policy', 'rust/tests/web/self-development-presence-policy.test.mjs'),
    ('metric-ledger', 'rust/tests/web/self-hosting-ledger-storage.test.mjs'),
]:
    check(name, ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-concurrency=1', test_file])
check('assembly', ['node', 'scripts/assemble-requirements.mjs'])
check('touched-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only',
      'check-file-size,check-file-size-js-twin,check-secrets,check-self-development-release'])
check('whitespace', ['git', 'diff', '--check'])
(base / 'outcome.json').write_text(json.dumps({'complete': True, 'results': rows,
    'childrenPeakRssKiB': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
    'localRustExecution': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
