from pathlib import Path
import json, os, subprocess, time, resource
root=Path('/tmp/gh-issue-solver-1794900398048')
base=Path('/tmp/issue-1580-research/script-size-repair-final')
checks=[('corrected-touched-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only',
    'check-file-size,check-file-size-js-twin,check-assemble-requirements-js-twin']),
    ('whitespace',['git','diff','--check'])]
rows=[]
for name,argv in checks:
    start=time.monotonic()
    with (base/(name+'.stdout')).open('wb') as out,(base/(name+'.stderr')).open('wb') as err:
        result=subprocess.run(argv,cwd=root,env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256'),stdout=out,stderr=err)
    rows.append({'name':name,'argv':argv,'status':result.returncode,'seconds':round(time.monotonic()-start,3)})
    assert result.returncode==0,name
    print(name,result.returncode,flush=True)
prior=json.loads((base/'results.json').read_text())
assert prior[-1]['name']=='touched-gates' and prior[-1]['status']==1
assert all(row['status']==row['expectedStatus'] for row in prior[:-1])
(base/'outcome.json').write_text(json.dumps({'complete':True,'results':prior+rows,
    'invalidGateInvocationRetained':True,'childrenPeakRssKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
    'localRustExecution':False,'independentAuthorshipCredit':0},indent=2)+'\n')
