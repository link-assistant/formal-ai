from pathlib import Path
import gzip, hashlib, json, subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
scratch=Path('/tmp/issue-1580-research')
base=root/'experiments/issue-1580/evidence/checks/script-warning-and-secret-contract'
base.mkdir(exist_ok=False)
records=[]
sources=[]
for folder in ('script-size-repair','script-size-repair-final'):
    sources += [(folder+'/'+p.name,p) for p in sorted((scratch/folder).iterdir()) if p.is_file() and p.suffix!='.pid']
for name in ('extract-script-test-modules','validate-script-size-repair','format-script-size-repair',
             'extract-self-hosting-cli','finish-script-and-profile-repair','validate-final-script-gates'):
    for suffix in ('.py','.log'):
        p=scratch/(name+suffix)
        assert p.is_file(),p
        sources.append(('helpers/'+p.name,p))
sources.append(('helpers/'+Path(__file__).name,Path(__file__)))
for relative,path in sources:
    original=path.read_bytes()
    raw=gzip.decompress(original) if path.suffix=='.gz' else original
    packed=original if path.suffix=='.gz' else gzip.compress(raw,mtime=0)
    name=relative if relative.endswith('.gz') else relative+'.gz'
    target=base/name
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(packed)
    assert gzip.decompress(target.read_bytes())==raw
    records.append({'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),
                    'archiveSha256':hashlib.sha256(packed).hexdigest(),
                    'bytes':len(raw),'lines':len(raw.splitlines())})
(base/'records.json').write_text(json.dumps(records,indent=2)+'\n')
outcome=json.loads((scratch/'script-size-repair-final/outcome.json').read_text())
assert outcome['complete']
for source in ('assemble-requirements','normalize-ordered-lists','self-hosting-metric'):
    assert len((root/'scripts'/(source+'.rs')).read_text().splitlines())<=900
checkpoint=root/'docs/case-studies/issue-1580/script-warning-and-secret-contract-checkpoint.md'
checkpoint.write_text('''# CI script sizes and complete secret-inventory contracts

Pull request: https://github.com/link-assistant/formal-ai/pull/1581

The published 76371322 Layered CI run fails one source assertion at
`rust/tests/web/fast-pull-request-production-profile.test.mjs:442`.
The complete retained log has 12,590 lines; lines 5,987–6,003 identify its
expectation of the former `git ls-files -z | exclude` spelling. The repaired
scanner uses `read_inventory` to wait for the actual producer, rejecting partial
Git output. The profile now requires both selection calls through this helper
and the producer-status check. History depth, acquisition, permissions, selection
filters, tool versions and finite job phases remain asserted.

The unchanged source assertion fails locally before the update and all 18
production-profile cases pass afterward. The separate subprocess suite exercises
actual shell selection with partial failing all-files, base-diff and uncommitted
inventories, plus a valid empty selection. It also retains the real compressed
secret and invalid-gzip controls. The assertion repair grants no clean-inventory
credit to an unsuccessful producer.

Three scripts previously exceeded the 900-line Rust warning threshold:

| Script | Before | After | Companion |
| --- | ---: | ---: | --- |
| assemble-requirements.rs | 989 | 724 | 289 lines / 22 unchanged tests |
| normalize-ordered-lists.rs | 960 | 684 | 308 lines / 17 unchanged tests |
| self-hosting-metric.rs | 903 | 772 | 136-line CLI module |

The first two move their entire existing test module into a companion admitted
through the same `#[cfg(test)]` declaration. The third moves command-line parsing
and dispatch into a private child module; its entry point is visible only to its
parent. Existing public measurement APIs and all CLI branches remain present.
The exact inverse before formatting and the formatter-normalized inverse after
formatting reproduce every original source byte. No file-size limit or exclusion
changes, and all six files pass rustfmt checks without compiling Rust locally.

Six focused JavaScript files pass one at a time: production-profile, subprocess
boundaries, script twins, ordered module lists, metric policy and metric ledger.
Requirements assembly and all three relevant JavaScript gates pass. The first
rustfmt failure and a rejected invocation naming two nonexistent gates are
retained with their corrected results. These failures are not counted as passes.
The corrected gate run peaks at 143,708 KiB child RSS; no local Rust build or test
is executed. Hosted native execution for these structural changes remains open.

All helper sources, actual traces, outputs, reconstruction proofs and failed
attempts are compressed under
`experiments/issue-1580/evidence/checks/script-warning-and-secret-contract/`.
The manifest binds original/compressed hashes, byte counts and line counts.
Supplied commands and patches earn zero independent authorship or reasoning
credit. This scoped repair leaves the remaining warnings and every broader
unverified original acceptance criterion unfinished; PR #1581 remains draft.
''')
# Record measured final lengths rather than relying on the draft prose.
text=checkpoint.read_text()
cli_lines=len((root/'scripts/self-hosting-metric-cli.rs').read_text().splitlines())
text=text.replace('136-line CLI module',str(cli_lines)+'-line CLI module')
checkpoint.write_text(text)
(root/'changelog.d/issue-1580-script-warning-and-secret-contract.md').write_text(
    'Split three CI Rust scripts below the existing source-size warning threshold while preserving all tests and behavior; update the secret-scan production contract to require complete, error-checked file inventories.\n')
with (root/'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- Published 76371322 Layered CI exposes one stale secret-scan source assertion (original log lines 5,987–6,003). Reproduce it before updating the profile to require both error-checked inventory selections and producer status. All 18 profile cases and five other focused JavaScript files pass, as do requirements assembly, six-file rustfmt and three touched gates. Preserve failed formatting and invalid gate-name attempts. Three structural script splits retain complete exact/formatter-normalized inverse proofs and all 39 existing tests; native execution remains pending. No push while current-head CI is active, and every broader issue criterion stays open.\n')
for row in records:
    packed=(base/row['file']).read_bytes();raw=gzip.decompress(packed)
    assert hashlib.sha256(raw).hexdigest()==row['rawSha256']
    assert hashlib.sha256(packed).hexdigest()==row['archiveSha256']
print('Archived and verified',len(records),'records; final CLI lines:',cli_lines)
