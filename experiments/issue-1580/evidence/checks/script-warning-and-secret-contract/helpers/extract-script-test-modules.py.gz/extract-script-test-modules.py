from pathlib import Path
import subprocess, hashlib, json, re

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/script-size-repair')
base.mkdir(exist_ok=False)
rows = []
for name in ('assemble-requirements', 'normalize-ordered-lists'):
    path = root / 'scripts' / (name + '.rs')
    original = path.read_text()
    marker = '#[cfg(test)]\nmod tests {\n'
    assert original.count(marker) == 1 and original.endswith('}\n')
    production, body = original.split(marker)
    body = body[:-2]
    assert all(not line or line.startswith('    ') for line in body.splitlines())
    extracted = ''.join(line[4:] if line.startswith('    ') else line for line in body.splitlines(keepends=True))
    target = path.with_name(name + '-tests.rs')
    assert not target.exists()
    target.write_text(extracted)
    path.write_text(production + '#[cfg(test)]\n#[path = "' + target.name + '"]\nmod tests;\n')
    # Exact inverse demonstrates that no assertion, fixture or production byte was dropped.
    restored = production + marker + ''.join('    ' + line if line.strip() else line for line in extracted.splitlines(keepends=True)) + '}\n'
    assert restored == original
    assert len(path.read_text().splitlines()) <= 900 and len(extracted.splitlines()) <= 900
    rows.append({'source': str(path.relative_to(root)), 'testModule': str(target.relative_to(root)),
                 'originalSha256': hashlib.sha256(original.encode()).hexdigest(),
                 'productionPrefixSha256': hashlib.sha256(production.encode()).hexdigest(),
                 'testCount': len(re.findall(r'^    #\[test\]$', body, re.M)),
                 'beforeLines': len(original.splitlines()), 'afterLines': len(path.read_text().splitlines()),
                 'testModuleLines': len(extracted.splitlines()), 'exactInverse': True})
(base / 'extraction.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows), flush=True)
