from pathlib import Path
import subprocess, json, gzip, hashlib
root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/script-size-repair')
files = [f'scripts/{name}{suffix}.rs' for name in ('assemble-requirements', 'normalize-ordered-lists') for suffix in ('', '-tests')]
for name in files:
    (base / (Path(name).name + '.before-format.gz')).write_bytes(gzip.compress((root / name).read_bytes(), mtime=0))
subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', *files], cwd=root, check=True)
# Compare the formatter's output for the complete original inline module with
# the formatter's output for the reconstructed external module. This permits
# formatting changes while detecting any lost Rust source or test body.
rows = []
for name in ('assemble-requirements', 'normalize-ordered-lists'):
    path = root / 'scripts' / (name + '.rs')
    target = path.with_name(name + '-tests.rs')
    original = subprocess.check_output(['git', 'show', 'HEAD:scripts/' + name + '.rs'], cwd=root)
    current = path.read_text()
    marker = '#[cfg(test)]\n#[path = "' + target.name + '"]\nmod tests;\n'
    assert current.count(marker) == 1
    body = target.read_text()
    reconstructed = current.replace(marker, '#[cfg(test)]\nmod tests {\n' + ''.join('    ' + line if line.strip() else line for line in body.splitlines(keepends=True)) + '}\n')
    def formatted(raw):
        return subprocess.check_output(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--emit', 'stdout'], input=raw, cwd=root)
    before = formatted(original)
    after = formatted(reconstructed.encode())
    assert before == after, name
    rows.append({'source': str(path.relative_to(root)), 'normalizedExactInverse': True,
                 'formattedOriginalSha256': hashlib.sha256(before).hexdigest(),
                 'productionLines': len(current.splitlines()), 'testModuleLines': len(body.splitlines())})
(base / 'formatted-extraction.json').write_text(json.dumps(rows, indent=2) + '\n')
with (base / 'format-after.stdout').open('wb') as out, (base / 'format-after.stderr').open('wb') as err:
    subprocess.run(['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--check', *files], cwd=root, stdout=out, stderr=err, check=True)
print('Formatting passes; complete original modules reconstruct identically:', json.dumps(rows))
