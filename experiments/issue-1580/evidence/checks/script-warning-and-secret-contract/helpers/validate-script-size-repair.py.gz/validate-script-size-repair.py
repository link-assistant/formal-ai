from pathlib import Path
import subprocess, os, sys, json, time, resource
root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/script-size-repair')
if len(sys.argv) == 1:
    with (base / 'validation-supervisor.log').open('wb') as stream:
        child = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root,
                                 stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    (base / 'validation.pid').write_text(str(child.pid) + '\n')
    print('Sequential script validation:', child.pid)
    sys.exit(0)
env = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
rows = []
checks = [
    ('twin-tests', ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-concurrency=1', 'rust/tests/web/scripts-js-twins.test.mjs']),
    ('ordered-list-tests', ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-concurrency=1', 'rust/tests/web/issue-1569-ordered-module-lists.test.mjs']),
    ('assembly', ['node', 'scripts/assemble-requirements.mjs']),
    ('touched-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-file-size,check-file-size-js-twin,check-ordered-lists-are-canonical']),
    ('format', ['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--check',
                'scripts/assemble-requirements.rs', 'scripts/assemble-requirements-tests.rs',
                'scripts/normalize-ordered-lists.rs', 'scripts/normalize-ordered-lists-tests.rs']),
]
for name, argv in checks:
    start = time.monotonic()
    with (base / (name + '.stdout')).open('wb') as out, (base / (name + '.stderr')).open('wb') as err:
        result = subprocess.run(argv, cwd=root, env=env, stdout=out, stderr=err)
    rows.append({'name': name, 'argv': argv, 'status': result.returncode, 'seconds': round(time.monotonic() - start, 3)})
    print(name, result.returncode, flush=True)
    if result.returncode:
        break
(base / 'validation.json').write_text(json.dumps({'complete': len(rows) == len(checks), 'results': rows,
    'childrenPeakRssKiB': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss}, indent=2) + '\n')
