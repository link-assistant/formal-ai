from pathlib import Path
import subprocess, hashlib, json
root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/script-size-repair')
path = root / 'scripts/self-hosting-metric.rs'
original = path.read_text()
start = original.index('#[derive(Debug)]\nstruct Options {\n')
end = original.index('\nfn main() {\n', start)
body = original[start:end]
assert body.count('fn run() -> Result<(), String> {') == 1
target = path.with_name('self-hosting-metric-cli.rs')
assert not target.exists()
target.write_text('//! Command-line parsing and execution for the release authorship metric.\nuse super::*;\n\n' + body.replace('fn run() -> Result<(), String> {', 'pub(super) fn run() -> Result<(), String> {', 1) + '\n')
declaration = '#[path = "self-hosting-metric-cli.rs"]\nmod cli;\n'
current = original[:start] + declaration + original[end:]
assert current.count('if let Err(error) = run() {') == 1
current = current.replace('if let Err(error) = run() {', 'if let Err(error) = cli::run() {', 1)
path.write_text(current)
restored_body = target.read_text().split('use super::*;\n\n', 1)[1].removesuffix('\n').replace('pub(super) fn run()', 'fn run()', 1)
restored = current.replace(declaration, restored_body, 1).replace('if let Err(error) = cli::run() {', 'if let Err(error) = run() {', 1)
assert restored == original
assert len(current.splitlines()) <= 900 and len(target.read_text().splitlines()) <= 900
row = {'source': str(path.relative_to(root)), 'cliModule': str(target.relative_to(root)),
       'originalSha256': hashlib.sha256(original.encode()).hexdigest(), 'exactInverse': True,
       'beforeLines': len(original.splitlines()), 'afterLines': len(current.splitlines()),
       'cliModuleLines': len(target.read_text().splitlines()), 'independentAuthorshipCredit': 0}
(base / 'cli-extraction.json').write_text(json.dumps(row, indent=2) + '\n')
print(json.dumps(row))
