from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path('/tmp/issue-1580-research/aggregate-fixtures-review-bc08')
inv=json.loads((r/'inventory.json').read_text())
def digest(raw):return hashlib.sha256(raw).hexdigest()
def unique(pairs):
 out={}
 for k,v in pairs:
  assert k not in out,('duplicate key',k)
  out[k]=v
 return out
def parse(raw):return json.loads(raw,object_pairs_hook=unique)
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True)
def before(path):return parse(subprocess.check_output(['git','show',inv['base']+':'+path]))
def after(path):return parse(Path(path).read_bytes())
parts=[]
for c in inv['chunks']:
 raw=(r/c['path']).read_bytes()
 assert len(raw)==c['bytes'] and digest(raw)==c['sha256']
 parts.append(raw)
raw=b''.join(parts)
assert raw==(r/'complete.diff').read_bytes()
assert len(raw)==inv['diffBytes'] and len(raw.splitlines())==inv['diffLines'] and digest(raw)==inv['diffSha256']
assert raw==subprocess.check_output(['git','diff','--no-ext-diff','--no-color','--no-renames',inv['base'],inv['source'],'--',*inv['paths']])
for path in inv['paths']:
 assert Path(path).read_bytes()==subprocess.check_output(['git','show',inv['source']+':'+path]),path
 for_json=path.endswith('.json')
 if for_json:after(path)
provenance='rust/tests/fixtures/source-fetch-provenance.json'
assert canonical(before(provenance))==canonical(after(provenance))
executor='rust/tests/fixtures/meta-executor-parity.json'
a=before(executor);b=after(executor)
assert canonical(a['cases'])==canonical(b['cases'][:len(a['cases'])])
assert canonical({k:v for k,v in a.items() if k!='cases'})==canonical({k:v for k,v in b.items() if k!='cases'})
formal='rust/tests/fixtures/formalization-native-parity.json'
f0=before(formal);f1=after(formal)
assert canonical(f0['counts'])==canonical(f1['counts'])
assert canonical(f0['vocabulary'])==canonical(f1['vocabulary'][:len(f0['vocabulary'])])
compressed=Path('rust/tests/fixtures/codeql/hosted-inactive-optional-dependency.json.gz')
with gzip.open(compressed,'rb') as stream:decompressed=stream.read(1024*1024+1)
assert len(decompressed)<=1024*1024
snapshot=parse(decompressed)
projection=parse((r/'codeql-fixture-structure.json').read_bytes())
rows=[parse(line) for line in (r/'codeql-fixture-packages.jsonl').read_text().splitlines()]
assert rows==projection['packages']
assert digest(decompressed)==projection['decompressedSha256']
assert len(decompressed)==projection['decompressedBytes'] and compressed.stat().st_size==projection['compressedBytes']
metadata=snapshot['metadata'];messages=snapshot['messages']
nodes={n['id']:n for n in metadata['resolve']['nodes']}
assert len(nodes)==len(metadata['resolve']['nodes'])
packages={p['id']:p for p in metadata['packages']}
assert len(packages)==len(metadata['packages'])==len(rows)==15
dep_keys=['name','req','kind','optional','uses_default_features','features','target','rename']
artifact_keys=['reason','features','executable','target','filenames','manifest_path','profile']
for row in rows:
 p=packages[row['id']];node=nodes[row['id']]
 assert all(row[k]==p[k] for k in ['id','name','version','source','features'])
 assert row['declaredDependencies']==[{k:d[k] for k in dep_keys} for d in p['dependencies']]
 assert row['resolvedFeatures']==node['features'] and row['resolvedDependencies']==node['deps']
 artifacts=[m for m in messages if m.get('package_id')==row['id'] and m['reason']=='compiler-artifact']
 assert row['artifacts']==[{k:m[k] for k in artifact_keys} for m in artifacts]
assert projection['root']==metadata['resolve']['root']
assert projection['workspaceMembers']==metadata['workspace_members']
assert projection['buildFinished']==[m for m in messages if m['reason']=='build-finished']==[{'reason':'build-finished','success':True}]
inactive=[row['name'] for row in rows if not row['artifacts']]
assert inactive==['serde_core']
result={'paths':len(inv['paths']),'literalDiffChunks':len(parts),'diffBytes':len(raw),'diffLines':len(raw.splitlines()),'diffSha256':digest(raw),'allWorkingFilesEqualBoundSource':True,'strictJsonDuplicateKeyRejection':True,'sourceFetchCasesUnchanged':len(after(provenance)),'priorExecutorCasesUnchanged':len(a['cases']),'addedExecutorCases':len(b['cases'])-len(a['cases']),'formalizationPriorCountsAndVocabularyPreserved':True,'codeqlCompressedBytes':compressed.stat().st_size,'codeqlDecompressedBytes':len(decompressed),'codeqlDecompressedSha256':digest(decompressed),'codeqlMetadataPackages':len(packages),'codeqlResolveNodes':len(nodes),'codeqlCompilerArtifacts':sum(m['reason']=='compiler-artifact' for m in messages),'codeqlInactiveMetadataPackage':inactive,'projectionExactlyMatchesSelectedSourceFields':True,'descriptiveCargoMetadataNotLiteralReview':True,'newBuildExecutionCredit':0,'fullAggregateReviewComplete':False}
(r/'conservation-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
