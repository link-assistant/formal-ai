from pathlib import Path
import gzip, hashlib, json, os, shutil, subprocess, sys, traceback

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
base = scratch / 'sealed-native-reasoning-round'
if len(sys.argv) == 1:
    base.mkdir(exist_ok=False)
    with (base / 'worker.log').open('wb') as stream:
        process = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root,
            stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': process.pid, 'scratch': str(base)}))
    sys.exit(0)
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
records = []
def run(name, argv):
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
    for label in ['stdout', 'stderr']:
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, (name, result.stdout.decode(errors='replace')[-3000:], result.stderr.decode(errors='replace')[-1000:])
    return result.stdout
try:
    gate_names = ['check-ci-speed', 'check-readable-code', 'check-file-size', 'check-file-size-js-twin',
        'check-abbreviations', 'check-tests-as-docs', 'check-runner-labels']
    run('gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', ','.join(gate_names)])
    for name in gate_names:
        source = root / 'experiments/formal_ai_subagent/sandboxes/gates' / (name + '.log')
        if source.exists():
            shutil.copyfile(source, base / (name.replace('tests-as-docs', 'tests-as-documentation') + '.log'))
    run('whitespace', ['git', 'diff', '--check'])
    modified = run('modified-selection', ['git', 'diff', '--name-only', '--diff-filter=ACMRTUXB', '-z']).split(b'\0')
    untracked = run('untracked-selection', ['git', 'ls-files', '--others', '--exclude-standard', '-z']).split(b'\0')
    paths = sorted({item.decode() for item in modified + untracked if item})
    assert paths
    identities = [{'path': path, 'sha256': hashlib.sha256((root / path).read_bytes()).hexdigest()}
        for path in paths]
    (base / 'selection.json').write_text(json.dumps(identities, indent=2) + '\n')
    run('secrets', ['bash', 'scripts/check-secrets.sh', *paths])
    for row in identities:
        assert hashlib.sha256((root / row['path']).read_bytes()).hexdigest() == row['sha256']
    seal = root / 'experiments/issue-1580/evidence/checks/native-reasoning-seal'
    seal.mkdir(exist_ok=False)
    seal_records = []
    selected = [path for path in sorted(base.iterdir()) if path.is_file() and path.name != 'worker.log']
    selected += [scratch / 'archive-native-reasoning-budget-round.py',
        scratch / 'archive-native-reasoning-budget-round.log', Path(__file__)]
    for path in selected:
        raw = path.read_bytes()
        packed = gzip.compress(raw, mtime=0)
        target = seal / (path.name + '.gz')
        assert not target.exists()
        target.write_bytes(packed)
        assert gzip.decompress(packed) == raw
        seal_records.append({'file': target.name, 'rawSha256': hashlib.sha256(raw).hexdigest(),
            'archiveSha256': hashlib.sha256(packed).hexdigest()})
    (seal / 'records.json').write_text(json.dumps(seal_records, indent=2) + '\n')
    seal_paths = [path.relative_to(root).as_posix() for path in sorted(seal.iterdir())]
    run('seal-secrets', ['bash', 'scripts/check-secrets.sh', *seal_paths])
    branch = run('branch', ['git', 'branch', '--show-current']).decode().strip()
    assert branch == 'issue-1580-8d61a32a61e1'
    native_paths = ['.github/workflows/layered-ci.yml', '.github/workflows/native-type-check.yml',
        'scripts/ci-native-regressions.sh', 'scripts/ci-pull-request-admission.mjs',
        'scripts/ci-native-reasoning-durations.lino', 'experiments/issue-1580/derive-native-reasoning-durations.py',
        'experiments/issue-1580/native-regression-groups.test.mjs',
        'rust/tests/web/fast-pull-request-production-profile.test.mjs',
        'changelog.d/issue-1580-reasoning-job-budget.md',
        'docs/case-studies/issue-1580/native-reasoning-job-budget.md',
        'experiments/issue-1580/evidence/checks/native-reasoning-budget',
        'experiments/issue-1580/evidence/checks/native-reasoning-round',
        'experiments/issue-1580/evidence/checks/native-reasoning-seal',
        'experiments/issue-1580/evidence/ci/native-families-39196d1f']
    run('stage-native', ['git', 'add', '--', *native_paths])
    run('staged-native-whitespace', ['git', 'diff', '--cached', '--check'])
    run('commit-native', ['git', 'commit', '-m', 'ci: shard native reasoning within the existing job clock'])
    native_head = run('native-head', ['git', 'rev-parse', 'HEAD']).decode().strip()
    review_paths = ['docs/case-studies/issue-1580/templates/rust-source-review-progress.json',
        'experiments/issue-1580/evidence/checks/rust-source-review/logs.json',
        'experiments/issue-1580/work-plan.md']
    review_paths += [path.relative_to(root).as_posix() for path in
        sorted((root / 'experiments/issue-1580/evidence/checks/rust-source-review').glob('package-root-history-pull-request-*.gz'))]
    assert len(review_paths) == 6
    run('stage-package-root-review', ['git', 'add', '--', *review_paths])
    run('staged-review-whitespace', ['git', 'diff', '--cached', '--check'])
    run('commit-package-root-review', ['git', 'commit', '-m', 'docs: retain complete historical package root review'])
    head = run('head', ['git', 'rev-parse', 'HEAD']).decode().strip()
    status = run('status', ['git', 'status', '--porcelain']).decode()
    assert not status, status
    (base / 'outcome.json').write_text(json.dumps({'complete': True, 'passed': True,
        'nativeHead': native_head, 'head': head, 'selectedFilesScanned': len(paths),
        'pushExecuted': False, 'fullIssueComplete': False}, indent=2) + '\n')
    print('Seven gates, exact input and seal scans, two staged whitespace checks and two local commits pass; clean tree, no push.', flush=True)
except BaseException:
    traceback.print_exc()
    (base / 'failure.json').write_text(json.dumps({'complete': False, 'traceback': traceback.format_exc()}) + '\n')
    sys.exit(1)
