from pathlib import Path
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
base = root / 'experiments/issue-1580/evidence/checks/native-reasoning-round'
base.mkdir(exist_ok=False)
records = []
def capture(name, path):
    raw = path.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    target = base / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists(), target
    target.write_bytes(packed)
    records.append({'file': target.relative_to(base).as_posix(),
        'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(),
        'bytes': len(raw), 'lines': len(raw.splitlines())})
for folder in ['native-reasoning-shards', 'native-reasoning-shards-validation',
    'native-reasoning-shards-final-checks', 'reasoning-budget-evidence',
    'completed-macro-head-ci-assessment', 'reasoning-cancelled-39196d1f',
    'reasoning-cancelled-api-39196d1f', 'reasoning-cancelled-raw-39196d1f',
    'native-job-progress-39196d1f', 'macro-observation-head-ci']:
    directory = scratch / folder
    assert directory.exists(), folder
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            capture(folder + '/' + path.relative_to(directory).as_posix(), path)
for stem in ['draft-native-reasoning-shards', 'implement-native-reasoning-shards',
    'implement-native-reasoning-shards-v2', 'validate-native-reasoning-shards',
    'finish-native-reasoning-shard-checks', 'finish-reasoning-budget-evidence',
    'assess-completed-macro-head-ci', 'inspect-current-native-job-progress',
    'collect-reasoning-job-cancellation', 'collect-completed-reasoning-job-api-log',
    'collect-reasoning-job-raw-log', 'collect-reasoning-job-raw-log-worker',
    'record-rust-package-root-history', 'collect-macro-observation-head-ci']:
    for suffix in ['.py', '.log']:
        path = scratch / (stem + suffix)
        if path.exists():
            capture('helpers/' + path.name, path)
for start in range(0, len(records), 100):
    selected = records[start:start + 100]
    raw = (json.dumps(selected, indent=2) + '\n').encode()
    assert len(raw.splitlines()) <= 1400
    (base / ('records-part-' + str(start // 100 + 1) + '.json')).write_bytes(raw)
parts = [{'file': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    for path in sorted(base.glob('records-part-*.json'))]
(base / 'records.json').write_text(json.dumps({'records': len(records), 'parts': parts,
    'independentAuthorshipCredit': 0, 'fullIssueComplete': False}, indent=2) + '\n')
for row in records:
    packed = (base / row['file']).read_bytes()
    assert hashlib.sha256(packed).hexdigest() == row['archiveSha256']
    raw = gzip.decompress(packed)
    assert hashlib.sha256(raw).hexdigest() == row['rawSha256']
    assert len(raw) == row['bytes'] and len(raw.splitlines()) == row['lines']
print('Retained', len(records), 'verified records, including all failed harnesses and first gate failures; no push.')
