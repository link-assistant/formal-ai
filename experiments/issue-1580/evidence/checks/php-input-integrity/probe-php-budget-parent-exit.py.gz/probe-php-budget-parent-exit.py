from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
source = Path('/tmp/issue-1580-research/templates/php-complete')
out = root / 'experiments/issue-1580/evidence/checks/php-budget-parent-exit'
out.mkdir(exist_ok=False)
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
probe = root / 'experiments/issue-1580/probe-budget-process-lifetime.py'
observations = []
cases = [('expired-parent-success', 124), ('expired-parent-failure', 124),
         ('term-resistant', 124), ('short-success', 0), ('short-failure', 7),
         ('warning-only', 0), ('inspection-unavailable', 125)]
for label, wrapper in [('pinned-php', source / 'scripts/run-with-budget-warning.sh'),
                       ('current-formal-ai', root / 'scripts/run-with-budget-warning.sh')]:
    identity = hashlib.sha256(wrapper.read_bytes()).hexdigest()
    for case, expected in cases:
        destination = out / (label + '-' + case + '.json')
        argv = ['python3', str(probe), str(wrapper), str(destination), '--case', case]
        result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
        streams = {}
        for name, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
            filename = label + '-' + case + '.' + name + '.gz'
            packed = gzip.compress(raw, mtime=0)
            (out / filename).write_bytes(packed)
            streams[name] = {'file': filename, 'bytes': len(raw), 'lines': len(raw.splitlines()),
                'sha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest()}
        assert result.returncode == 0, result.stderr.decode(errors='replace')
        observed = json.loads(destination.read_text())
        passed = observed['exitCode'] == expected and not observed['workerRunningWhenWrapperExited']
        observations.append({'implementation': label, 'sourceSha256': identity, 'case': case,
            'expectedExitCode': expected, 'exitCode': observed['exitCode'],
            'workerRunningWhenWrapperExited': observed['workerRunningWhenWrapperExited'],
            'pass': passed, 'observation': destination.name, 'argv': argv, 'streams': streams})
        print(json.dumps(observations[-1]), flush=True)
assert all(row['pass'] for row in observations if row['implementation'] == 'current-formal-ai')
assert any(not row['pass'] for row in observations if row['implementation'] == 'pinned-php')
summary = {'complete': True, 'repository': 'link-foundation/php-ai-driven-development-pipeline-template',
    'commit': '3a034b27a56067971ca74dd4c74c7707056b215d',
    'observedAt': datetime.now(timezone.utc).isoformat(), 'source': 'scripts/run-with-budget-warning.sh',
    'observations': observations, 'upstreamFixApplied': False, 'fullIssueComplete': False,
    'independentAuthorshipCredit': 0}
(out / 'verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'complete': True, 'cases': len(observations),
    'pinnedPhpPassing': sum(row['pass'] for row in observations if row['implementation'] == 'pinned-php'),
    'formalAiPassing': sum(row['pass'] for row in observations if row['implementation'] == 'current-formal-ai')}))
