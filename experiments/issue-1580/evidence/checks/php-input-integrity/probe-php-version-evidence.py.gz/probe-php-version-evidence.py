from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, shutil, subprocess, tempfile

root = Path('/tmp/gh-issue-solver-1794900398048')
source = Path('/tmp/issue-1580-research/templates/php-complete')
out = root / 'experiments/issue-1580/evidence/checks/php-version-evidence'
out.mkdir(exist_ok=False)
records = []
def run(name, argv, cwd=root, env=None, checked=True):
    result = subprocess.run(argv, cwd=cwd, env=env, capture_output=True)
    record = {'name': name, 'argv': argv, 'cwd': str(cwd), 'exitCode': result.returncode}
    for label, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
        filename = name + '.' + label + '.gz'
        packed = gzip.compress(raw, mtime=0)
        (out / filename).write_bytes(packed)
        record[label] = {'file': filename, 'sha256': hashlib.sha256(raw).hexdigest(),
            'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())}
    records.append(record)
    (out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    if checked:
        assert result.returncode == 0, result.stderr.decode(errors='replace')
    return result
php = shutil.which('php')
if php is None:
    (out / 'unavailable.json').write_text(json.dumps({'available': False, 'reason': 'No PHP executable; no runtime credit'}) + '\n')
    print('PHP unavailable; source finding remains unverified')
    raise SystemExit(0)
run('php-identity', [php, '--version'])
for issue_name, query in [('budget-existing', 'budget OR timeout OR child'),
                          ('version-existing', 'version OR fetch OR composer')]:
    run(issue_name, ['gh', 'issue', 'list', '--repo', 'link-foundation/php-ai-driven-development-pipeline-template',
        '--state', 'all', '--search', query, '--limit', '100', '--json', 'number,title,url,state,body'])
files = ['scripts/bootstrap.php', 'scripts/check-version-modification.php']
files += ['scripts/src/' + name + '.php' for name in ['Actions', 'Process', 'ProcessResult', 'Project']]
identities = [{'path': name, 'sha256': hashlib.sha256((source / name).read_bytes()).hexdigest()} for name in files]
base = {'name': 'link-foundation/example-package-name', 'version': '1.2.3'}
observations = []
for case in ['unchanged', 'changed', 'removed', 'invalid', 'new-file', 'unavailable-base']:
    with tempfile.TemporaryDirectory(prefix='issue-1580-php-version-') as temporary:
        work = Path(temporary)
        for name in files:
            target = work / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((source / name).read_bytes())
        manifest = work / 'composer.json'
        if case != 'new-file':
            manifest.write_text(json.dumps(base) + '\n')
        (work / 'base-marker.txt').write_text('Finite local fixture\n')
        environment = dict(os.environ, GIT_AUTHOR_NAME='Fixture', GIT_AUTHOR_EMAIL='fixture@example.invalid',
            GIT_COMMITTER_NAME='Fixture', GIT_COMMITTER_EMAIL='fixture@example.invalid',
            GITHUB_BASE_REF='main', GIT_TERMINAL_PROMPT='0', GIT_CONFIG_NOSYSTEM='1')
        run(case + '-init', ['git', 'init', '--initial-branch=main', '--quiet'], work, environment)
        run(case + '-add', ['git', 'add', '.'], work, environment)
        run(case + '-commit', ['git', 'commit', '--quiet', '-m', 'Finite local version fixture'], work, environment)
        origin = str(work / 'missing-local-remote') if case == 'unavailable-base' else str(work)
        run(case + '-origin', ['git', 'remote', 'add', 'origin', origin], work, environment)
        if case in ['changed', 'unavailable-base', 'new-file']:
            head = dict(base, version='9.9.9')
        elif case == 'removed':
            head = {'name': base['name']}
        else:
            head = base
        manifest.write_text('{invalid json\n' if case == 'invalid' else json.dumps(head) + '\n')
        result = run(case + '-guard', [php, '-d', 'memory_limit=64M', 'scripts/check-version-modification.php'], work, environment, False)
        observations.append({'case': case, 'exitCode': result.returncode,
            'stdout': result.stdout.decode(), 'stderr': result.stderr.decode(),
            'originalManifest': None if case == 'new-file' else base,
            'headManifestText': manifest.read_text()})
expected = {'unchanged': 0, 'changed': 1, 'removed': 0, 'invalid': 0, 'new-file': 0, 'unavailable-base': 0}
assert {row['case']: row['exitCode'] for row in observations} == expected, observations
summary = {'complete': True, 'repository': 'link-foundation/php-ai-driven-development-pipeline-template',
    'commit': '3a034b27a56067971ca74dd4c74c7707056b215d',
    'observedAt': datetime.now(timezone.utc).isoformat(), 'sourceIdentities': identities,
    'observations': observations, 'allGitOriginsLocal': True, 'runtimeDependenciesInstalled': False,
    'templateRepaired': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
(out / 'verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'complete': True, 'observations': observations}))
