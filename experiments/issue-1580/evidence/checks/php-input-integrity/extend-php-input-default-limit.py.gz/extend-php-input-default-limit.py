from pathlib import Path
import gzip, json, os, subprocess
root = Path('/tmp/gh-issue-solver-1794900398048')
path = root / 'experiments/issue-1580/template-php-input-integrity.test.mjs'
source = path.read_text()
old = "      base64_decode($argv[2], true), 'fixture/repo', 'v1', (int) $argv[3]);`;"
new = "      file_get_contents('php://stdin'), 'fixture/repo', 'v1', (int) $argv[2]);`;"
assert source.count(old) == 1
source = source.replace(old, new)
old = "    Buffer.from(body).toString('base64'),String(max)],{timeout:5000,maxBuffer:131072});"
new = "    String(max)],{input:Buffer.from(body),timeout:5000,maxBuffer:131072});"
assert source.count(old) == 1
source = source.replace(old, new)
source += r'''
test('the default 120000-byte release cap also produces invalid UTF-8 before the candidate',
  {timeout:15000},t=>{
    const max=120000,budget=max-Buffer.byteLength(notice);
    const prefix='x'.repeat(budget-Buffer.byteLength('é'));
    const body=prefix+'é'+'z'.repeat(1000);
    const original=notes(t,{body,max});
    assert.ok(original.length<=max);
    assert.throws(()=>decode.decode(original),TypeError);
    const repaired=notes(t,{body,max,repaired:true});
    assert.equal(repaired.length,max);
    assert.equal(decode.decode(repaired),prefix+'é'+notice);
  });
'''
path.write_text(source)
out = root / 'experiments/issue-1580/evidence/checks/php-input-integrity'
argv = ['node', '--max-old-space-size=256', '--test', '--test-reporter=tap', '--test-concurrency=1', str(path.relative_to(root))]
result = subprocess.run(argv, cwd=root, env=dict(os.environ, NODE_OPTIONS='--max-old-space-size=256'), capture_output=True)
for label, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
    (out / ('default-limit-run.' + label + '.gz')).write_bytes(gzip.compress(raw, mtime=0))
(out / 'default-limit-run.json').write_text(json.dumps({'argv': argv, 'exitCode': result.returncode,
    'independentAuthorshipCredit': 0, 'templateRepaired': False}, indent=2) + '\n')
print(result.stdout.decode())
print(result.stderr.decode())
assert result.returncode == 0
