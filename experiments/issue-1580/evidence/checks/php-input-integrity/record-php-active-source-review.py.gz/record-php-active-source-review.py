from pathlib import Path
from collections import defaultdict
from datetime import datetime,timezone
import gzip,hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');source=scratch/'php-active-source-review-pages'
out=root/'experiments/issue-1580/evidence/checks/php-active-source-review';out.mkdir(exist_ok=False)
pages=json.loads((source/'pages.json').read_text());inventory=json.loads(gzip.decompress((source/'inventory.json.gz').read_bytes()))
read_pages=[1,2,3,4,*range(170,188)];ranges=defaultdict(list);page_records=[]
for number in read_pages:
    row=pages[number-1];raw=(source/row['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256']
    (out/(row['file']+'.gz')).write_bytes(gzip.compress(raw,mtime=0));page_records.append({**row,'archive':row['file']+'.gz','literalReadComplete':True})
    for span in row['ranges']:ranges[span['path']].append([span['start'],span['end']])
decisions={
 'scripts/check-version-modification.php':'Unchecked base fetch/show, JSON parse failure and missing/non-string versions can collapse to successful unchanged/bootstrap decisions. Fifteen maintained bounded input-integrity tests include original/candidate failures and positive controls; upstream is not repaired.',
 'scripts/src/ReleaseNotes.php':'The trailing-byte algorithm removes continuation bytes but leaves the leading byte, including at a complete multibyte boundary. The default 120000-byte cap reproduces invalid UTF-8. Limits smaller than the notice are exceeded. Disposable candidates cover these cases; upstream is not repaired.',
 'scripts/run-with-budget-warning.sh':'Seven bounded process-group controls all leave a live worker at wrapper exit in the pinned template; all seven existing Formal AI counterpart cases pass. Closed upstream issue 15 requires the additional evidence, rather than a duplicate report.',
 'tests/Pipeline/PipelineShellScriptsTest.php':'The existing background-worker test expects success while the worker remains alive, then kills it itself. This assertion hides ownership failure. The retained bounded subreaper fixture checks actual process-group liveness before its own cleanup.',
 'scripts/check-pipeline-status.php':'Unknown and failed outcomes fail closed under the explicit cancelled-job policy. This is source review, not live runtime qualification.',
 'scripts/preflight-release.php':'Mixed verified/unknown probes may continue according to an explicit policy. A read-only probe cannot prove future publication. Live release qualification remains open.',
 'scripts/src/ChangesetValidator.php':'A failed diff can become an empty result and accept an existing fragment. This candidate remains unqualified until a bounded behavioral reproduction distinguishes genuine emptiness from command failure.',
 'scripts/src/FileSize.php':'Newline count plus one and failed-open-to-zero handling need behavioral qualification. No accepted defect is inferred from source shape alone.',
 'scripts/src/Http.php':'Redirect handling appears to inspect the first status line; a targeted redirect response control is still required.',
 'scripts/src/Packagist.php':'Non-200 responses become an empty package set. Observation failure versus proven absence requires a bounded control.',
 'scripts/src/WorkflowConcurrency.php':'A flow mapping may be read as disabled rather than unknown; actual flow-YAML parser controls are still required.',
 'scripts/wait-for-packagist.php':'The polling deadline warns and exits zero before later release effects. Required publication identity qualification remains open.',
 'tests/Pipeline/ReleaseNotesTest.php':'Existing ASCII controls do not reach the newly reproduced multibyte truncation failure.',
 'tests/Pipeline/WorkflowPolicyTest.php':'String/policy checks do not prove prerequisite result admission; the separate quality-bypass reproduction is filed upstream already.',
}
reviewed=[]
for item in inventory:
    if item['path'] not in ranges:continue
    spans=sorted(ranges[item['path']]);covered=set()
    for start,end in spans:covered.update(range(start,end+1))
    complete=len(covered)==item['lines'] and (not covered or min(covered)==1 and max(covered)==item['lines'])
    reviewed.append({**item,'literalReadRanges':spans,'literalSourceReadComplete':complete,
        'decision':decisions.get(item['path'],'Literal source ranges reviewed for current/nested template inputs, pinned dependencies, status handling and existing regression coverage. This entry does not certify behavior or complete a source comparison.'),
        'runtimeQualified':False,'completeFormalAiComparison':False})
(out/'pages.json').write_text(json.dumps(page_records,separators=(',',':'))+'\n')
(out/'source-review.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in reviewed))
(out/'inventory.json.gz').write_bytes((source/'inventory.json.gz').read_bytes())
fresh=scratch/'php-budget-version-upstream'
for path in sorted(fresh.rglob('*')):
    if not path.is_file():continue
    raw=path.read_bytes();relative=path.relative_to(fresh).as_posix().replace('/','_')
    (out/('upstream-'+relative+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
summary={'repository':'link-foundation/php-ai-driven-development-pipeline-template','commit':'3a034b27a56067971ca74dd4c74c7707056b215d','observedAt':datetime.now(timezone.utc).isoformat(),'totalFiles':608,'previouslyReviewedFiles':17,'literalPagesRead':len(read_pages),'newFullyReadFiles':sum(r['literalSourceReadComplete'] for r in reviewed),'newFilesWithRanges':len(reviewed),'readPages':read_pages,'completeTemplateComparison':False,'runtimeQualified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'README.md').write_text('''# PHP source and runtime evidence

These 22 bounded pages were read in full. Their original pinned Git blobs and
SHA-256 identities are retained. Partial composer.lock ranges remain partial;
the other 165 pages, five image inputs, historical blobs and complete runtime
qualification remain open. Four nested source trees are current CI inputs.

The separate php-input-integrity archive retains 15 automated original/candidate
cases without package installation or network Git calls. Candidates are disposable;
they have not repaired the upstream repository. Fresh upstream observations at
b61e334703d93a15e08bf1a278e0df0a9d6e98a8 confirm the three relevant files are
unchanged from the pinned source. Existing closed issue 15 is not evidence of a
fixed process-group ownership contract. New reports await immutable evidence links.

Formal AI's version admission has strict missing-version/base-identity controls;
its native release-note helper uses Rust character boundaries. Those source
observations do not substitute for new native Unicode execution. All supplied
work retains zero independent authorship or reasoning credit.
''')
print(json.dumps(summary))
