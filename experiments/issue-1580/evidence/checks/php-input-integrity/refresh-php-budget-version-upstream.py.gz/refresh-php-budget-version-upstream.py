from pathlib import Path
import base64, gzip, hashlib, json, subprocess, textwrap
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/php-budget-version-upstream')
out.mkdir(exist_ok=False)
repo = 'link-foundation/php-ai-driven-development-pipeline-template'
records = []
def get(name, endpoint, paginate=False):
    argv = ['gh', 'api', endpoint] + (['--paginate', '--slurp'] if paginate else [])
    result = subprocess.run(argv, cwd=root, capture_output=True)
    for label, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
        (out / (name + '.' + label + '.gz')).write_bytes(gzip.compress(raw, mtime=0))
    assert result.returncode == 0, result.stderr.decode()
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode,
        'stdoutSha256': hashlib.sha256(result.stdout).hexdigest()})
    return json.loads(result.stdout)
head = get('head', 'repos/' + repo + '/commits/HEAD')['sha']
issue = get('issue-15', 'repos/' + repo + '/issues/15')
comments = [row for page in get('comments-15', 'repos/' + repo + '/issues/15/comments', True) for row in page]
issues = [row for page in get('issues-all', 'repos/' + repo + '/issues?state=all&per_page=100', True) for row in page if 'pull_request' not in row]
source_identities = []
for name in ['scripts/run-with-budget-warning.sh', 'scripts/check-version-modification.php', 'scripts/src/ReleaseNotes.php']:
    blob = get('source-' + name.replace('/', '_'), 'repos/' + repo + '/contents/' + name + '?ref=' + head)
    raw = base64.b64decode(blob['content'])
    (out / name.replace('/', '_')).write_bytes(raw)
    source_identities.append({'path': name, 'gitBlob': blob['sha'], 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)})
readable = ['REPOSITORY ' + repo + '\nHEAD ' + head + '\n', 'ISSUE 15\n' + issue['title'] + '\n' + issue['body'] + '\n']
for row in comments:
    readable.append('COMMENT ' + row['html_url'] + '\n' + row['created_at'] + '\n' + row['body'] + '\n')
(out / 'issue-15-readable.txt').write_text('\n'.join(readable))
(out / 'issues-index.json').write_text(json.dumps([{key: row[key] for key in ['number', 'title', 'state', 'html_url']} for row in issues], indent=2) + '\n')
summary = {'complete': True, 'head': head, 'issue15State': issue['state'], 'comments15': len(comments),
    'sourceIdentities': source_identities, 'allIssues': len(issues), 'independentAuthorshipCredit': 0}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(summary))
