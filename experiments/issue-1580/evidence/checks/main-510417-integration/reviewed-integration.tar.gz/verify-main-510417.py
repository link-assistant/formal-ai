from pathlib import Path
import subprocess,os,json,time
r=Path('/tmp/gh-issue-solver-1794900398048');os.chdir(r)
out=Path('/tmp/issue-1580-research/main-510417-integration');out.mkdir(exist_ok=False)
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='3479d01bd88a731b48c4f9bd2f3efb927320dfbc'
assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],text=True).strip()=='51041744901d15b9ada67ebe3df2d408e5a27f78'
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'}
results=[]
def run(name,args):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 row={'name':name,'command':args,'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3)};results.append(row)
 (out/'checks.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 return p.returncode
script=Path('/tmp/issue-1580-research/inspect-main-664e03-governed-witness.mjs').read_text().replace("out='/tmp/issue-1580-research/main-664e03-governed-witness'","out='/tmp/issue-1580-research/main-510417-governed-witness'")
Path('/tmp/issue-1580-research/inspect-main-510417-governed-witness.mjs').write_text(script)
assert run('governed-complete-object-witness',['node','/tmp/issue-1580-research/inspect-main-510417-governed-witness.mjs'])==0
witness=json.loads(Path('/tmp/issue-1580-research/main-510417-governed-witness/report.json').read_text())
assert not witness['parents']['ours']['changedCases'] and not witness['parents']['ours']['changedUnsupported']
compare="import assert from 'node:assert/strict';import{readFileSync}from'node:fs';import{deserialize}from'node:v8';const candidate=deserialize(readFileSync(process.argv[1])),canonical=deserialize(readFileSync(process.argv[2]));assert.deepStrictEqual(candidate,canonical);console.log(JSON.stringify({completeObjectsEqual:true,nativeExecuted:false}));"
assert run('baseline-complete-object-equality',['node','--input-type=module','-e',compare,'/tmp/issue-1580-research/main-510417-governed-witness/candidate.v8','experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8'])==0
commands=[
 ('seed-registry-write',['node','scripts/generate-seed-registry.mjs','--write']),
 ('worker-crate-write',['node','scripts/generate-worker-crate-modules.mjs','--write']),
 ('runtime-feature-write',['node','scripts/generate-runtime-feature-inventory.mjs','--write']),
 ('structured-output-http',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/issue-1586-structured-output.test.mjs']),
 ('seed-headroom',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/seed-registry-headroom.test.mjs']),
 ('native-format',['rustfmt','--edition','2024','--check','rust/src/protocol/structured_output.rs','rust/src/protocol/structured_schema.rs']),
 ('translation-currency',['node','scripts/translate-js-rust.mjs','--verify']),
 ('status-render',['node','scripts/render-status.mjs','--write']),
 ('progressive-plan',['node','scripts/render-progressive-plan.mjs','--write']),
]
for name,args in commands:run(name,args)
report={'head':'3479d01bd88a731b48c4f9bd2f3efb927320dfbc','main':'51041744901d15b9ada67ebe3df2d408e5a27f78','allFocusedChecksPassed':all(row['exitCode']==0 for row in results),'nativeExecuted':False,'autonomousAuthorshipCredit':0}
(out/'outcome.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
