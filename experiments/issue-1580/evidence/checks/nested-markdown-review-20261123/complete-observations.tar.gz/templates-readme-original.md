# Complete template inventory and CI review

Source trees were pinned, downloaded completely and verified against every Git blob before comparison. Same-name matches are review aids; they do not establish behavioral equivalence. All file roles, including application source, documentation and historical evidence, remain visible in the TSV inventories.

| Language | Source commit | Blobs | Workflows | CI candidates |
| --- | --- | ---: | ---: | ---: |
| js | [74de898dd6ce](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/tree/74de898dd6ce548af5bcb9359e1dae75fd4ebd75) | 561 | 8 | 233 |
| rust | [309387f761f9](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/tree/309387f761f9f0f1b2ea15bfe181cb51f5a9a1fb) | 373 | 8 | 124 |
| python | [c532c173801d](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/tree/c532c173801dfb12e681b0730c4abbf93aefd0ca) | 329 | 6 | 150 |
| php | [3a034b27a560](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/tree/3a034b27a56067971ca74dd4c74c7707056b215d) | 608 | 6 | 78 |
| csharp | [a5b9a1a46686](https://github.com/link-foundation/csharp-ai-driven-development-pipeline-template/tree/a5b9a1a46686cfe844f9afa2ace030094969e766) | 337 | 6 | 117 |
| java | [dd803a2d9fa5](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/tree/dd803a2d9fa5b3a992b435acce73162274fb9e8b) | 207 | 4 | 33 |
| cpp | [3769fa70a1bc](https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/tree/3769fa70a1bc30ce9516e01f78bcd7edea3b3f80) | 550 | 7 | 94 |
| go | [65c686846d73](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/tree/65c686846d7327d8c835a0d30b1a76cc6345cfc6) | 42 | 3 | 32 |

## Policy comparison and current decisions

The current Hive Mind `docs/CI-CD-BEST-PRACTICES.md` was read in full. Its recommendations are evaluated against this repository's explicit default-branch build policy; adopting a template does not authorize PR application builds, Docker execution, deployments or weaker verdicts.

| Topic | Formal AI application / review status |
| --- | --- |
| Pinned runners and native architecture | Keep pinned `ubuntu-24.04`; recovered browser runner follows the pinned policy. Native ARM release paths remain; do not introduce QEMU. |
| Change detection and required checks | Documentation-only PRs now emit required contexts without compiling. Unknown/failed detection triggers the check. Never filter production seed data as generic non-production `data/`. |
| Size, lint and formatting | Full local JS twins pass; existing warning inventory remains open. Keep global thresholds. |
| Changelog and publication identity | Patch fragment is the existing release trigger; retain trusted publication/OIDC and pre-publication freshness checks. |
| Merge checks and machine writers | Missing required main contexts are a real failure. Configure only with a verified bypass/PR design for automated ledger writers; compatibility is not yet established. |
| Serialized default-branch writers | Preserve non-cancelling write concurrency, immutable source identity and explicit GH006/GH013 failures; do not retry a protected-branch refusal as a network outage. |
| External secrets and publication preflight | Preserve verified/failed/unknown states. PRs may report unavailable external publication without claiming it succeeded; main must fail with the concrete action required. Token presence alone is not verification. |
| Workflow lint tools | Existing actionlint, ShellCheck, runner labels and security checks remain. Local ShellCheck used the verified v0.11.0 binary; no Rust build was performed. |
| Scheduled dependency checks | Latest dependencies run still exposes real source-size warnings. A successful install is not full runtime validation. |
| Download retries | Local OSV/source download fixes retain finite bounds. The C++ Doxygen archive command lacks all-error retry coverage; bounded real-curl regression and upstream #35 document it. |
| Retry classification and cleanup | Duration collection uses bounded retry and propagates unread/incomplete evidence; invalid credentials, refspecs and immutable 409 conflicts must remain terminal. |
| Input defaults, skip notices and verdict guards | Recovered draft and current context-reporting controls preserve explicit skip/failure states. Successful scope gates are not capability evidence. |
| Real GitHub end-to-end qualification | Keep opt-in live effects and default-off verbose tracing. Docker remains prohibited on PRs; the failing live qualification requires real pull diagnostics. |
| Packaging warnings | Retain extension runtime files; the Playwright external package cannot be removed solely to silence VSIX file-count warnings. Resolution remains open. |

## Review boundaries

`*-files.tsv` covers every blob. `*-ci-files.jsonl` conservatively selects workflows, composite actions, scripts/tests and build/policy metadata. `*-workflows.jsonl` preserves each complete parsed workflow document and Git blob identity, including action inputs, environment/default/service/container fields, outputs and reusable workflow bindings; its smaller job/step fields are only a search index. Three integrity regressions reject dropped execution fields and tampered source blobs. These generated records do not substitute for resolving shell/package-script/configuration references and reviewing their behavior. That semantic/transitive review remains unfinished and must be completed in this PR.

The latest related C++ merged change, PR #34, was reviewed before filing #35; it refreshes dependencies and release configuration but does not repair truncated-transfer retry. The Go pipeline-status helper was read; its failure/cancelled classification is not reported as a bug without evidence. Java already retries the OSV download with `--retry-all-errors`; it is not included in the C++ finding.

Reproduction tooling: `experiments/issue-1580/templates.mjs` selects source identities, `full-template-trees.py` fetches complete archives and verifies every Git blob, and `compare-template-trees.mjs` generates these inventories. Run against the pinned manifest to retain historical reproducibility; selecting current heads intentionally creates a new comparison checkpoint.

## Executed cross-template observations

`rust/tests/web/issue-1580-template-observations.test.mjs` is in the fast PR inventory. The Git-observation and Go-integrity checkpoint passed eleven local tests; the Java checkpoint passed sixteen; the C# checkpoint passed twenty-five; the current suite passes twenty-nine with Python fragment-preservation coverage, with no runtime skips. The unmodified Go, Java, Python and PHP detectors all returned exit 0 with negative code-change outputs when the selected Git comparison/repository was unavailable. Code/docs/empty controls separate the defect from legitimate negative observations. Java/Python also fail their first-commit mock, while PHP's legitimate initial-tree fallback succeeds; PHP still misclassifies an entirely unknown repository. A real initial Go Git repository reproduces its false negative. The production Formal AI detector now propagates errors and permits a tree fallback only for an established initial commit.

The Go workflow model also reproduces skipped lint/build/selected release for both manual modes, followed by success from the unchanged terminal helper. This is modeled dependency propagation using the pinned YAML and the real helper, not hosted release execution. A candidate model repair admits both modes and still blocks release after forced lint/test/build failures. Python #18/#19 already fixed its analogous dispatch admission and are not reported again. Java #29 already tracks its missing aggregate status job. Latest merged related changes (Go #16, Java #25, Python #152 and PHP #24) were reviewed before preparing the five distinct upstream reports. Their report bodies, source identities and limitations are preserved in `experiments/issue-1580/upstream/`; filing URLs belong in `filed-issues.txt`.

The five reports are now filed with public executable evidence at commit `71e1dee442fd74589df20a1d6f33710b6dec0d18`: [Go manual dispatch #18](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/18), [Go Git observation #19](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/19), [Java #30](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/30), [Python #156](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/156), and [PHP #26](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/26). They are reports, not claims that the template repositories have applied fixes.

## Static reference review aid

`trace-template-ci.mjs` follows literal local actions, reusable workflows, package commands and source/configuration references from all 48 workflow roots. Its compressed per-language graphs retain commands, reference reasons and unresolved paths. The graphs deliberately include conservative directory/package expansions and can contain irrelevant literal/document references. They are lexical inventories, not complete execution closures or semantic verification. Dynamic/glob paths, command working directories and implicit tool configuration still require source review. Every visited file is checked against the pinned Git blob. Five bounded regressions cover local and self-repository actions, reusable workflows, nested JavaScript phases/helpers, unresolved paths and transitive source tampering. Full semantic review remains unfinished.

## Complete Go source review

[`go-semantic-review.json`](go-semantic-review.json) records every one of the pinned Go tree's 42 blobs, its verified identity, role, corresponding Formal AI paths and transfer decision. All three workflows and their local helpers/tests/configuration were read completely. The review preserves default-branch build restrictions, publication/source receipts, expected optional skips, bounded retries and conservative runner-acquisition classification. Missing Go workflow timeouts already have upstream issue #17. Seven other complete semantic reviews remain unfinished; lexical graphs do not complete them.

The new fifth Go regression executes the unchanged dependency checker and reporter. A current invalid pin invokes verification and fails all four events. A stale invalid pin bypasses verification and passes push/schedule/dispatch, failing only PR freshness policy. Removing just the early `continue` in a disposable copy restores integrity failure for both versions while retaining intended stale-only warnings. Registry/tag results are injected: this proves the control-flow defect, not a real remote tag mismatch or a hosted workflow result. Full logs and hashes are indexed in `experiments/issue-1580/evidence/checks/go-pin-integrity.json`. The report is filed as [Go #20](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/20) with executable evidence at `a4053def4bd4b921001fdf84a026ae35deebfc39`. Its posted body and identity are retained under `experiments/issue-1580/upstream/`. No upstream repair is claimed.

## Java active source review and failed-commit regression

[`java-active-semantic-review.json`](java-active-semantic-review.json) records per-file decisions for all 62 active Java CI/application/configuration/documentation files, including four workflows and the entire 1872-line POM. All 207 tree blobs are hash verified. The 145 `dev/log` historical reports, registry/API responses, logs and earlier source snapshots remain inventoried with their identities; their full semantic contents are explicitly unreviewed. This active source review does not complete the Java repository review or the seven outstanding complete semantic reviews.

The new five-case Java release regression executes the unchanged pinned `version-and-commit.mjs` and its local helpers against real temporary Git repositories and disposable local bare remotes. A pre-commit hook rejecting the release commit still yields exit 0 and `released=true`, and pushes `v1.2.4` pointing at the old `1.2.3` source. Both changeset and instant modes reproduce it. Removing only the commit-error fallback in a disposable copy stops before tag creation/publication; four successful-release controls preserve the updated version in the local remote. The maintained fast-PR entrypoint now passes sixteen tests with no skips. This is local Git execution, not a hosted release or an upstream repair. Formal AI already exits on a failed release commit and tags only after pushing the release source successfully; those checks are retained.

Java #29 already covers its missing aggregate status and #28 its CRLF wrapper checkout. Its manual lint skip and version-writer parent/comment mismatch remain labeled source observations, without an executed claim. The failed-commit finding is filed as [Java #31](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/31) with immutable executable evidence at `ff5d883b15aeda06c07e509a73a0a436f10799b7`. The posted report and source identity are retained in `experiments/issue-1580/upstream/`. Full regression logs and hashes are indexed in `experiments/issue-1580/evidence/checks/java-release-integrity.json`.

## Self-repository reference correction

GitHub supports [`$/` references to the running repository and commit](https://github.blog/changelog/2026-07-30-reference-same-repository-actions-with-self-repository-syntax/), including nested actions and reusable workflows. The C# workflow uses this valid syntax; its scoped actionlint compatibility exception already refers to upstream actionlint #711. The local review graph recognized only `./` and omitted explicit `$/` attribution. Three new cases fail before the repair; all five focused cases and the maintained 21-test entrypoint pass afterward. Missing, dynamic and escaping paths stay unresolved, and pinned-blob tampering still fails.

Regenerating all eight graphs at the same source pins adds one C# and twelve Python self-repository edges. It adds no files to the real inventories: their target files were already present through other conservative paths. Complete logs, intermediate test-control correction, hashes and the exact edge delta are retained in `experiments/issue-1580/evidence/checks/self-repository-references.json`. This is an inventory repair, not hosted execution or completion of semantic review.

## C# active source review and valid-input changeset loss

[`csharp-partial-semantic-review.json`](csharp-partial-semantic-review.json) verifies all 337 pinned blobs and records all 158 active files as fully read (18,327 of 18,327 active lines), including six workflows and their active transitive helpers, tests, configuration and application source. Per-file decisions preserve runtime limits and distinguish unexecuted source questions from reproduced defects. All 179 historical blobs remain semantically unread; the complete C# repository review and upstream runtime/publication acceptance remain unfinished.

The unchanged merge helper reproduces a distinct data-loss defect: a randomly chosen output filename can equal a valid pending input. The write overwrites it, and cleanup deletes the output along with the other input, reporting success with no changesets left. The preservation regression fails before a disposable exclusive-create guard and passes afterward. Four tests also preserve noncollision major-bump/description order and malformed-input rejection; the maintained entrypoint passes 25 tests without skips. This is bounded Node execution, without .NET, Bun, provider APIs, publication or upstream hosted execution. Full logs, source hashes, harness-output corrections and upstream duplicate/source checks are indexed in `experiments/issue-1580/evidence/checks/csharp-changeset-integrity.json`.

The finding is filed as [C# #111](https://github.com/link-foundation/csharp-ai-driven-development-pipeline-template/issues/111) with immutable executable evidence at `0f90c0a7a3bdd77b7d31c276a180d5ee297e57f6`. Reporting does not establish an upstream repair. Existing C# #78/#83 address invalid parsing, while #60/#62 address untrusted log output. The latest source PR #83 and all its conversation comments/reviews were read. Other source observations, including preflight GitHub request deadlines and Formal AI timestamp fragment creation with nonexclusive writes, remain unexecuted questions, without new defect or safety claims. All broad issue acceptance criteria remain active.

## Partial Python active review and manual fragment loss

[`python-partial-semantic-review.json`](python-partial-semantic-review.json) records 24 fully read active files and one partial file, 4,064/44,284 active lines and all six workflows. All 329 blobs are reverified. The remaining active helpers/tests/configuration/application source, generated bundles/locks and 126 historical blobs remain semantically unread. Per-file decisions retain Formal AI's default-branch build/effect policy and distinguish source observations from execution.

The complete pinned `create_manual_changeset.py --no-scriv` entrypoint loses an earlier fragment when the same Git identity/branch creates two entries during one second. Both commands return success; the later file replaces the first category and description. A disposable exclusive-create guard rejects the collision and preserves the prior exact bytes. Four focused cases and the maintained 29-case entrypoint pass, without skips; the negative preservation control fails once before the guard. Distinct timestamps and invalid arguments retain intended results. Original source/Unlicense identities, full logs, the initial default-reporter parsing correction and current-main/duplicate checks are retained in `experiments/issue-1580/evidence/checks/python-fragment-integrity.json`. Related validator #100/#101, release-recovery #148 and dependency-locking #152 address different boundaries. The evidence is published and [upstream report #157](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/157) is filed. No upstream fix, full Python runtime suite or native Formal AI fragment execution is claimed.

## Python review, audit coverage and release-note preservation

The Python review now fully reads 199 active files (21,394/44,284 active lines), through corrected pages 1-54 and separately read release/helper tests. The four unread active files include both generated bundles and both lockfiles; all 126 historical blobs remain unread. Hash verification is separate from semantic reading and source reading is separate from execution.

All 24 workflows passed on `1cc2d536ac11e26602cc55a40dffb61716233aa6`. Full Layered CI run 44116797181 and hashes are retained under `experiments/issue-1580/evidence/ci/1cc2d536a/`. Log lines 4954-4956 confirm all three Python npm inventory observations executed; lines 4948-4951 confirm all four fragment cases. The dedicated Formal AI audit tests were missing from the explicit fast inventory; this batch adds their complete ten-case file and a failing-before selection assertion. Main-only native, benchmark, publication and live-identity criteria remain unfinished.

The repaired Formal AI JavaScript dependency helper checks one successful lockfile inventory before auditing; all ten local regressions pass and existing retry/threshold behavior is retained. The matching Python defect is filed as [upstream #158](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/158), against published evidence at `1cc2d536a`. The exact posted body, fresh duplicate inventory and real-Git reproduction are retained under `experiments/issue-1580/evidence/checks/audit-inventory-boundary/`. Reporting does not repair the upstream helper.

The full unchanged Python release-formatting CLI rewrites literal `\n`, `\r` and escaped quotes in code examples and submits the corrupted body with success. A disposable candidate removes those three rewrites; four focused observations preserve escape bytes, Unicode, badge insertion, idempotence and fatal API read/write errors. The preservation case fails when that candidate is disabled; the maintained entrypoint passes 38 cases without skips. Complete logs, source identities and the distinct report draft are under `experiments/issue-1580/evidence/checks/python-release-formatting/` and `experiments/issue-1580/upstream/python-release-formatting-report.md`. The GitHub CLI is an offline stand-in; no hosted release, upstream repair or full Python suite is claimed. Publish immutable evidence before filing. Independent Formal AI reasoning remains 0/20 accepted.

The initial complete local gate run records 83 pass, 52 native/context exclusions and three failures: two supplied 128 MiB Node-heap exhaustion failures and an old-name spelling in a gate-selection negative control. That control now uses a different typo and its focused suite passes; no policy is relaxed. Main advanced to 512ce428029a92687628b4180309ee5ab660fe08 during validation. Merge it without losing either fast-test addition, reconcile the duplicate Chrono advisory documentation, then revalidate the combined shared data under a measured 256 MiB Node cap before the single push. Hosted execution of the ten selected audit cases and formatter observations remains pending.

Fresh main head 512ce428 has two failed workflows, fully archived with current timestamps and exact hashes. Its six JavaScript assertions now pass in four complete focused suites (15/20/11/2 cases, no skips). The browser test also gains a cooperative reaper after a bounded probe proves an exited PID-1 zombie; timeout status and exact ESRCH assertions are unchanged. A new generated-file inventory regression fails with the original full-file retention and passes all eight cases after twelve-line, one-file-at-a-time reading under a 96 MiB heap cap. The 35 native failing tests and full-shard-5 1080-second timeout are inventoried and remain unverified on the branch. Final full local gates, single-push preflight and hosted execution of the newly selected audit/formatter observations remain pending. All supplied work has zero independent Formal AI authorship credit.

The distinct standalone formatter corruption is filed as [Python template #159](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/159), with complete immutable source and four-case regression evidence at da712fadd and the posted report at d0b8b8956. Immediately before filing, all 158 current issue/PR entries are compared with the prior full inventory (zero changed bodies or new items), current main c532c173 source/helper bytes are verified unchanged, and GitHub-hosted evidence bytes are compared with the local published objects. The exact posted body hash and metadata are retained under evidence/checks/python-release-formatting/publication/. This is an upstream report, not an upstream repair or completion of the wider issue.

## Java complete file comparison, 2026-11-20

[`java-complete-file-comparison.json`](java-complete-file-comparison.json) completes the pinned Java file applicability map: 62 active files and 145 historical files form the exact 207-blob tree. Every blob identity and every Formal AI comparison path is reverified. All active applicability decisions and the eight historical practice groups are reviewed. This dated receipt supersedes earlier partial file counts; the original records remain unchanged.

This completes source comparison for Java. Applicable practice implementation, Maven/runtime compatibility, live dispatch/publication and current dependency safety remain separate and unfinished. The release commit failure is reported as [Java #31](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/31). Source observations about manual dispatch and malformed fragment consumption remain unexecuted. The parent/comment POM writer defect is now reproduced by four finite Git-only release cases: three report success with the project version unchanged. The local candidate passes all four byte-preservation cases, and the maintained template entrypoint passes 54 tests; no Maven or hosted publication was executed. See [`java-project-version/validation.json`](../../../../experiments/issue-1580/evidence/checks/java-project-version/validation.json). No additional native or independent reasoning credit is awarded.

The distinct project-version writer defect is reported as [Java #32](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/32). The upstream source was still at the pinned head when the report was filed. Reporting does not establish an upstream repair.

## Rust workflow review and desktop checksum reproduction, 2026-11-20

[`rust-source-review-progress.json`](rust-source-review-progress.json) records 122/373 files and 20,175 literal source lines; all eight workflows are read. All 373 pinned blob identities were reverified; four unchanged upstream JavaScript prerequisite suites pass 43 tests. The receipt records exact reviewed ranges and incomplete practice decisions. The complete Rust tree and Formal AI integration comparison remain unfinished.

The pinned desktop workflow can enumerate its own incomplete checksum fragment in both GNU and `shasum` branches and includes previous fragments. A fresh output races directory enumeration; self-inclusion is deterministic when the output already exists. The original four-case receipt is historical. Eight current fixtures cover clean/pre-existing outputs, with/without an older fragment, on both hashing implementations; candidate selection must emit only exact asset digests in every case. Formal AI's actual desktop shell step already selects only assets and updater manifests and passes both directory controls. The focused negative control has two passes and one expected failure; all three candidate/comparison tests and the 57-test maintained template entrypoint pass. Source identities, complete logs, observations and the corrected report-writer harness failure are retained in [`rust-desktop-checksum-comparison/validation.json`](../../../../experiments/issue-1580/evidence/checks/rust-desktop-checksum-comparison/validation.json). No Rust build, hosted publication or upstream repair is claimed.

The Rust desktop checksum defect is reported as [upstream #251](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/251). The pinned/current workflow can include a newly created output manifest, always includes a pre-existing output manifest, and includes stale fragments on both hashing branches. Published finite controls establish the defect and a disposable candidate, not an upstream repair.


## Cargo package identity and checkout recovery, 2026-11-20

The pinned Rust template scopes release identity to the package table and refuses inherited versions. Formal AI's previous whole-file regex could read a dependency's identity or update its version first. The shared [`cargo-package.rs`](../../../../scripts/cargo-package.rs) now parses the actual table and replaces only the original version token, preserving CRLF, Unicode, comments and unrelated bytes. Workspace selection reads actual member/publish configuration. Release badges retain name-only lookup even when the version is inherited. Nine physical manifest cases, the manual bump regression and the existing workspace cases enter the focused native lane. The release script retains its regression in its existing rust-script suite. Local admission, formatting and policy checks do not establish native runtime behavior; hosted confirmation is pending.

The coding job at `11c0bd05` failed before compilation: [job 136080809086](https://github.com/link-assistant/formal-ai/actions/runs/44673787597/job/136080809086) records a promisor-blob transfer abort (`curl 28`, bad pack header) at raw log lines 140–142. Both focused native jobs now draft one checkout retry inside the unchanged four-minute checkout allowance and twenty-minute job clock. The terminal guard fails unless an actual attempt succeeds. Local tests exercise that real shell guard, exact retry eligibility and preserved sparse-checkout/security settings; they do not perform hosted checkout or network recovery.

The local receipts for this batch are [`package-identity-and-checksum-race/verification.json`](../../../../experiments/issue-1580/evidence/checks/package-identity-and-checksum-race/verification.json) and [`bounded-native-checkout-retry/verification.json`](../../../../experiments/issue-1580/evidence/checks/bounded-native-checkout-retry/verification.json). Every wider template comparison, practice disposition and original acceptance criterion remains required; this batch earns zero independent reasoning or authorship credit.

Exact-head hosted [core evidence](../../../../experiments/issue-1580/evidence/ci/native-families-11c0bd05/early-completed-jobs.json) confirms four fragment ownership and seven fallible-output tests within 60 passing workflow contracts. The parsed package changes remain pending hosted execution, and the changelog collector now also delegates to the parsed package version, with hosted native execution pending.

A further 14 Rust regression sources (928 lines) are fully read and hash-bound in the [source review ledger](rust-source-review-progress.json), bringing literal coverage to 122/373 files and 20,175 lines. Their release, registry, analyzer, link-recovery and cancellation contracts still require counterpart comparison and applicable verification.

The collector package-version consumer now has its own physical manifest regression in the focused native target. Its [local receipt](../../../../experiments/issue-1580/evidence/checks/changelog-package-reader/verification.json) records the original-reader admission failure, 32 focused and 92 maintained passing checks, formatting and 10 gates. Actual native execution and separate fragment I/O practices remain unfinished. The completed prior-head [CI assessment](../../../../experiments/issue-1580/evidence/ci/native-families-11c0bd05/assessment.json) identifies both failures and the passing 37-case Hive replay without claiming unchanged-original acceptance.

Nine further pinned Rust regression sources (2,148 lines) bring literal coverage to 131/373 files and 22,323 lines. Their security, credential preflight, delivery, documentation and process-budget assertions still need Formal AI counterpart comparison and behavioral verification. The checksum [upstream correction](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/251#issuecomment-7031138172) now records both fresh-output race outcomes and deterministic stale output inclusion; its publication receipt is in `experiments/issue-1580/evidence/checks/rust-desktop-checksum-comparison/report-correction/`.

The pinned Rust release-I/O regression adds 145 fully read lines: literal review now covers 132/373 files and 22,468 lines, leaving 241 files plus behavioral comparison. Its fallible inventory practice is adopted in Formal AI's bump selection, standalone collection and version-preparation collection. Actual filesystem regressions are admitted to focused native CI; hosted execution of this new batch remains pending. Hash-verified source review is not completion of the full template comparison.

## Complete Rust file comparison, 2026-11-21

The [current 374-file receipt](rust-complete-file-comparison.json) compares every
blob at `5f1e7a96acbf7a93b567195443cf6e5158fbbf1f`: 362 unchanged sources
carry their pinned review and 12 changed files retain the separate delta review.
The [per-file decisions](rust-complete-files.jsonl) bind Git/SHA256 identities,
comparison methods and actual Formal AI paths. The final 17 historical artifacts
use complete structured log/JSON/history comparison and an existing verified
visual review; they do not inflate the earlier 356-file literal-read count.
All files now have source applicability decisions. The 74 practice assessments,
applicable behavior verification and wider issue acceptance remain unfinished.
Quoted solution-draft output and historical failures supply context; neither is
a present workflow result. Earlier partial receipts remain dated evidence.

## Complete C# file comparison, 2026-11-21

The [339-file receipt](csharp-complete-file-comparison.json) binds every blob at
`a0f2a171dc1ab02ad5d68147656660562f6e1504`: 331 unchanged files carry their
verified identities and eight changed sources retain the separate delta review.
The [per-file decisions](csharp-complete-files.jsonl) give actual Formal AI
counterparts and applicability limits. The earlier 158 active files / 18,327
literal lines remain a dated review; they are not relabeled as current runtime
evidence. The remaining 179 historical files use 78 complete log traversals,
79 recursive JSON/state reviews, twenty literal reads and two catalog traversals.
All 104 distinct diagnostic messages were reviewed with their 310 original
locations retained. Historical failures and passing snapshots retain their dates.
The earlier eighteen actual upstream Bun tests remain narrowly attributed.
Applicable practice implementation, current hosted CI and wider issue acceptance
remain unfinished. Supplied procedures and conclusions earn zero independent
authorship credit.

## Python complete source applicability map

[`python-complete-file-comparison.json`](python-complete-file-comparison.json) binds all 338 pinned blobs. The per-file receipt distinguishes unchanged reviewed source, current deltas, complete structured historical records, the universal Python lock, and actual hosted generated-byte comparison. The historical catalogs preserve parent constraints, runner ABI selection, bounded retries, strict warning checks and external publisher observations; those are compared with actual Formal AI counterparts. This completes the file map, while final-source CI and the broader implementation acceptance remain open.

## PHP complete file applicability map

`php-complete-file-comparison.json` binds all 608 current pinned blobs. All 114 active root files reuse retained complete literal reviews only at exact content hashes. The 229 captured-template files include four current executable CI inputs plus their comparison manifests; they are distinguished from 265 historical records. Complete structured practice/declaration/JSON observations support each captured or historical comparison, without claiming literal rereading or current runtime proof. All applicable-practice execution and full issue acceptance remain separate.

## JavaScript and C++ complete applicability maps

`javascript-complete-file-comparison.json` (566 blobs) and `cpp-complete-file-comparison.json` (552 blobs) complete the pinned per-file maps for all eight requested templates. Each record preserves exact Git/SHA-256 identity, Formal AI counterpart paths, a source applicability decision and its review method. Complete structured source observations remain distinct from retained literal reviews and current literal delta reviews. The maps do not certify runtime behavior or full applicable-practice acceptance. Actual-source annotation pagination reproductions are reported as [C++ #41](https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/issues/41) and [C# #114](https://github.com/link-foundation/csharp-ai-driven-development-pipeline-template/issues/114).
