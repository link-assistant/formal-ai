from pathlib import Path
from datetime import datetime,timezone
import os,subprocess,sys,time,json
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/final-warning-merge-verification')
if '--worker' not in sys.argv:
 assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
 assert subprocess.run(['git','merge-base','--is-ancestor','43b31443025d6b632d3352f86512e01abb8f658a','HEAD'],cwd=root).returncode==0
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('wb') as log:p=subprocess.Popen([sys.executable,__file__,'--worker'],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':p.pid})+'\n');print('WORKER',p.pid)
else:
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();results=[]
 focused=['rust/tests/web/container-node-runtime.test.mjs','rust/tests/web/default-branch-build-policy.test.mjs','rust/tests/web/native-workflow-cache-bindings.test.mjs','rust/tests/web/prepared-release-factory.test.mjs','desktop/scripts/service-control.test.mjs','desktop/scripts/shared-memory-path.test.mjs','experiments/issue-1580/sccache-outage-fallback.test.mjs','experiments/issue-1580/ordered-javascript-test-runner.test.mjs','experiments/issue-1580/hosted-javascript-scheduling.test.mjs']
 commands=[('focused-'+str(i+1),['node','--test','--test-concurrency=1',file]) for i,file in enumerate(focused)]
 commands += [('rust-format',['rustfmt','--edition','2024','--config','skip_children=true','--check','scripts/create-changelog-fragment.rs','scripts/collect-changelog.rs','scripts/version-changelog.rs','scripts/lib/release-changelog.rs']),('all-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs']),('whitespace',['git','diff','--check'])]
 for name,command in commands:
  start=time.monotonic()
  with (out/(name+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'},stdout=log,stderr=subprocess.STDOUT)
  row={'name':name,'command':command,'exit':r.returncode,'seconds':time.monotonic()-start,'log':name+'.log'};results.append(row)
  (out/'checkpoint.json').write_text(json.dumps({'head':head,'results':results},indent=2)+'\n')
  print(name,r.returncode,flush=True)
 lines=(out/'all-local-gates.log').read_text().splitlines()
 report={'at':datetime.now(timezone.utc).isoformat(),'head':head,'headUnchanged':head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'workingTreeClean':not subprocess.check_output(['git','status','--porcelain'],cwd=root),'checks':results,'passedGates':sum(x.startswith('PASS ') for x in lines),'skippedGates':sum(x.startswith('SKIP ') for x in lines),'failedGates':[x for x in lines if x.startswith('FAIL ')],'fileSizeWarnings':[x for x in lines if 'WARNING' in x and ('1387' in x or '1419' in x)],'rustCompiledLocally':False,'allIssueAcceptanceComplete':False}
 (out/'outcome.json').write_text(json.dumps(report,indent=2)+'\n')
