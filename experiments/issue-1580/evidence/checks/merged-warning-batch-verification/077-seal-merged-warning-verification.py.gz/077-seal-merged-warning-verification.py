from pathlib import Path
from datetime import datetime, timezone
import subprocess,json,gzip,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)==' M docs/status.md\n'
full=json.loads((scratch/'final-warning-merge-verification/outcome.json').read_text());corrected=json.loads((scratch/'final-warning-focused-corrected/outcome.json').read_text());status=json.loads((scratch/'final-warning-status-repair/outcome.json').read_text())
assert full['head']==corrected['head']==status['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert full['passedGates']==88 and full['skippedGates']==53 and len(full['failedGates'])==1 and 'check-status-render' in full['failedGates'][0]
assert all(r['exit']==0 for r in corrected['checks']+status['checks'])
assert full['headUnchanged'] and full['workingTreeClean'] and not full['fileSizeWarnings']
inventory=json.loads((scratch/'final-warning-batch-review/inventory.json').read_text());assert len(inventory['selectedMaintainedPaths'])==33
base=root/'experiments/issue-1580/evidence/checks/merged-warning-batch-verification';base.mkdir(exist_ok=False);records=[]
sources=[]
for directory in ['final-warning-merge-verification','final-warning-focused-corrected','final-warning-status-repair','final-warning-batch-review']:
 sources += [p for p in sorted((scratch/directory).iterdir()) if p.is_file() and p.name not in ['pid.json']]
for name in ['merge.log','resolved.diff','witness-refresh.log','witness-review.json']:
 sources.append(scratch/'merge-current-main-warning-batch'/name)
for name in ['verify-final-warning-merge.py','rerun-final-warning-focused.py','refresh-merged-warning-status.py','check-merged-warning-status.py','collect-final-warning-batch-review.py','resolve-current-main-warning-batch.py','refresh-warning-main-witness.mjs','seal-merged-warning-verification.py']:
 sources.append(scratch/name)
for i,p in enumerate(sources,1):
 raw=p.read_bytes();packed=gzip.compress(raw,compresslevel=6,mtime=0);name=f'{i:03d}-{p.name}.gz';(base/name).write_bytes(packed)
 assert gzip.decompress((base/name).read_bytes())==raw
 records.append({'source':str(p.relative_to(scratch)),'file':name,'bytes':len(raw),'lines':len(raw.splitlines()),'sha256':hashlib.sha256(raw).hexdigest(),'compressedSha256':hashlib.sha256(packed).hexdigest()})
manifest={'at':datetime.now(timezone.utc).isoformat(),'sourceHead':full['head'],'mainMerged':'43b31443025d6b632d3352f86512e01abb8f658a','fullInventory':{'pass':88,'skip':53,'fail':1,'failedGate':'check-status-render','workingTreeCleanAtStartAndEnd':True},'statusRepair':{'changedPath':'docs/status.md','maintainedRenderer':'node scripts/render-status.mjs --write','focusedChecksPassed':['check-status-render','check-render-status-js-twin']},'combinedRemainingGateFailures':0,'cleanFullInventoryAfterStatusRepairClaimed':False,'initialFocusedWrapperMistakesRetained':5,'correctedFocusedCommandsPassed':5,'totalFocusedJavaScriptFilesPassingAcrossOriginalAndCorrectedRuns':9,'rustFormattingPassed':True,'rustCompiledLocally':False,'selectedMaintainedPatchesReadCompletely':33,'selectedPatchLines':sum(row['lines'] for row in inventory['selectedMaintainedPaths']),'wholePullRequestReviewComplete':False,'governedWitnessScope':'Only the four reviewed Cargo fixture hash replacements; complete-object equality for every other object. Native execution and independent authorship are not established.','independentAuthorshipCredit':0,'allIssueAcceptanceComplete':False,'files':records}
lines=['{']+[f'  {json.dumps(k)}: {json.dumps(v,separators=(",",":"))},' for k,v in manifest.items() if k!='files']+['  "files": [']+['    '+json.dumps(r,separators=(',',':'))+(',' if i+1<len(records) else '') for i,r in enumerate(records)]+['  ]','}']
text='\n'.join(lines)+'\n';assert json.loads(text)==manifest and len(lines)<1500;(base/'manifest.json').write_text(text)
section='''

## Merged warning batch verification, 2026-11-22

- [x] Merge main `43b31443025d6b632d3352f86512e01abb8f658a` (v0.356.5). Resolve the native workflow and policy conflicts without losing the branch's regression runner, pinned Node version, offline scope or diagnostic switch. The maintained witness refresher changes exactly four reviewed Cargo fixture hashes; complete-object comparisons preserve every other object.
- [x] Run the complete 142-entry JavaScript inventory on clean, unchanged `1fdadb2452d7bc7c916f6043108b92fb43fa47e5`: 88 pass, 53 hosted-only entries skip, one generated-status check fails. The final 1,387-line scheduling table emits no size warning. The stale page contains both pre-merge ledger counts; regenerate it with `scripts/render-status.mjs --write`. Both the status gate and renderer twin pass after that document-only repair. Combined remaining failures are zero; a clean full replay after the status repair is not claimed.
- [x] Pass all nine focused JavaScript files across the original and corrected runs, plus changed-file Rust formatting. Preserve all five original wrapper mistakes: NODE_OPTIONS violated the checked compiler environment in two files, two test paths were wrong and one rustfmt path was wrong. Correct those commands and pass the five reruns; do not weaken the environment guard or relabel the earlier results.
- [x] Fully read all 33 selected maintained-source patches between published c90f94ca and the merged head, preserving 810 changed-path inventory and per-patch hashes. No additional defect found in this batch review. Raw fixtures, upstream data and the remaining aggregate comparison keep their separate review limits.
- [ ] Publish this verified batch once, collect every exact-head hosted result and restore the temporary diagnostic repository variable after all jobs finish. Qualify the new native cases, actual file observations and scheduling wall times; identify the compiler cache backend response before claiming a repair.
- [ ] Finish the newly identified crate-wait identity and changelog-inventory error regressions, complete applicable template practices, whole-PR review and every original runtime/authorship acceptance criterion. These remain active work; source findings, supplied controllers and partial CI earn zero independent-authorship credit.

Evidence: [the merged batch verification manifest](evidence/checks/merged-warning-batch-verification/manifest.json). Earlier failed and intermediate gate rounds remain retained separately.
'''
p=root/'experiments/issue-1580/work-plan.md';p.write_text(p.read_text()+section)
p=root/'docs/case-studies/issue-1580/c90-terminal-warnings-and-file-telemetry.md';p.write_text(p.read_text()+'''

The merged source `1fdadb2452d7bc7c916f6043108b92fb43fa47e5` ran the complete
142-entry local inventory: 88 pass, 53 hosted-only entries skip, and the generated
status page fails. The maintained renderer repairs the merge's duplicated ledger
counts; both focused status checks then pass. There are zero combined remaining
gate failures and no file-size warning. This is not a claim of a clean full replay
after the document repair. All nine focused JavaScript files and changed-file
Rust formatting pass across the original and corrected commands. The five
verification-wrapper mistakes and their successful reruns remain retained in
`experiments/issue-1580/evidence/checks/merged-warning-batch-verification/`.
New-source hosted execution and all broader acceptance remain unfinished.
''')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
paths=[str(base.relative_to(root)),'experiments/issue-1580/work-plan.md','docs/case-studies/issue-1580/c90-terminal-warnings-and-file-telemetry.md','docs/status.md']
subprocess.run(['git','add','--',*paths],cwd=root,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
subprocess.run(['git','commit','-m','docs: retain merged warning verification and refresh status'],cwd=root,check=True,stdout=subprocess.DEVNULL)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2));print('ARCHIVED',len(records),'RAW_BYTES',sum(r['bytes'] for r in records));print('HEAD',subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip())
