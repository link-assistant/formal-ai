from pathlib import Path
from datetime import datetime,timezone
import os,subprocess,sys,time,json
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/final-warning-focused-corrected')
if '--worker' not in sys.argv:
 assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1';assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
 print('SOURCE COMPILER GUARD', '\n'.join((root/'scripts/checked-release-operation-view.mjs').read_text().splitlines()[:46]))
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('wb') as log:p=subprocess.Popen([sys.executable,__file__,'--worker'],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':p.pid})+'\n');print('WORKER',p.pid)
else:
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();results=[];env=dict(os.environ);env.pop('NODE_OPTIONS',None)
 files=['rust/tests/web/native-workflow-cache-bindings.test.mjs','rust/tests/web/prepared-release-factory.test.mjs','rust/tests/web/sccache-outage-fallback.test.mjs','rust/tests/web/ordered-javascript-test-runner.test.mjs']
 commands=[('focused-'+str(i+1),['node','--max-old-space-size=256','--test','--test-concurrency=1',file]) for i,file in enumerate(files)]
 commands+=[('rust-format',['rustfmt','--edition','2024','--config','skip_children=true','--check','scripts/create-changelog-fragment.rs','scripts/collect-changelog.rs','scripts/version-changelog.rs','scripts/release-changelog.rs'])]
 for name,command in commands:
  start=time.monotonic()
  with (out/(name+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  results.append({'name':name,'command':command,'exit':r.returncode,'seconds':time.monotonic()-start,'log':name+'.log'});(out/'checkpoint.json').write_text(json.dumps(results,indent=2)+'\n')
  print(name,r.returncode,flush=True)
 report={'at':datetime.now(timezone.utc).isoformat(),'head':head,'headUnchanged':head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'workingTreeClean':not subprocess.check_output(['git','status','--porcelain'],cwd=root),'checks':results,'rustCompiledLocally':False,'allIssueAcceptanceComplete':False};(out/'outcome.json').write_text(json.dumps(report,indent=2)+'\n')
