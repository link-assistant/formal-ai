from pathlib import Path
import subprocess, json, os
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/final-warning-status-repair');out.mkdir(exist_ok=False)
print('BRANCH',subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip())
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
print('CONTRIBUTING', (root/'CONTRIBUTING.md').read_text())
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
commands=[('write',['node','--max-old-space-size=256','scripts/render-status.mjs','--write']),('list',['node','experiments/formal_ai_subagent/local-gates.mjs','--list'])]
for name,command in commands:
 with (out/(name+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0,(name,r.returncode)
print((out/'write.log').read_text())
print('\n'.join(line for line in (out/'list.log').read_text().splitlines() if 'status' in line))
diff=subprocess.check_output(['git','diff','--','docs/status.md'],cwd=root)
(out/'status.patch').write_bytes(diff);print(diff.decode())
