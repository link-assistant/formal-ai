from pathlib import Path
import subprocess,json,time,os
from datetime import datetime,timezone
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/final-warning-status-repair')
env=dict(os.environ);env['NODE_OPTIONS']='--max-old-space-size=256'
results=[]
for gate in ['check-status-render','check-render-status-js-twin']:
 command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate];start=time.monotonic()
 with (out/(gate+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append({'gate':gate,'command':command,'exit':r.returncode,'seconds':time.monotonic()-start,'log':gate+'.log'})
 print((out/(gate+'.log')).read_text())
 assert r.returncode==0,gate
report={'at':datetime.now(timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'changes':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),'checks':results,'rustCompiledLocally':False,'allIssueAcceptanceComplete':False}
(out/'outcome.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
