from pathlib import Path
import subprocess,json,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/final-warning-batch-review');out.mkdir(exist_ok=False)
base='c90f94cabecb5e995ff45c37e5baf7ef76d93fe8'
paths=subprocess.check_output(['git','diff','--name-only',base,'HEAD'],cwd=root,text=True).splitlines()
selected=[]
for p in paths:
 if p.startswith(('.github/','scripts/','rust/','desktop/')) or p in ['Dockerfile','compose.yaml'] or (p.startswith('experiments/issue-1580/') and ('/evidence/' not in p and '/fixtures/' not in p and not p.endswith('work-plan.md'))):
  raw=subprocess.check_output(['git','diff','--no-ext-diff',base,'HEAD','--',p],cwd=root);name=f'{len(selected)+1:03d}.patch';(out/name).write_bytes(raw);selected.append({'path':p,'file':name,'lines':len(raw.splitlines()),'sha256':hashlib.sha256(raw).hexdigest()})
(out/'inventory.json').write_text(json.dumps({'base':base,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'totalChangedPaths':len(paths),'selectedMaintainedPaths':selected,'completePullRequestReview':False},indent=2)+'\n')
print(json.dumps({'totalChangedPaths':len(paths),'selected':len(selected),'lines':sum(r['lines'] for r in selected),'paths':selected},indent=2))
