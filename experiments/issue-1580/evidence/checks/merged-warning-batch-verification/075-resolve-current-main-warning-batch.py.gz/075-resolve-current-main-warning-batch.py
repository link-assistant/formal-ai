from pathlib import Path
import subprocess,re,json,os
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/merge-current-main-warning-batch')
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
for name in ['.github/workflows/native-type-check.yml','rust/tests/web/default-branch-build-policy.test.mjs']:
 p=root/name;s=p.read_text();s,n=re.subn(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> origin/main\n?',lambda m:m[1],s,flags=re.M|re.S);assert n==1,name;p.write_text(s)
subprocess.run(['node','--max-old-space-size=256','/tmp/issue-1580-research/refresh-warning-main-witness.mjs'],cwd=root,check=True)
with (out/'resolved.diff').open('wb') as f:subprocess.run(['git','diff','HEAD','--','.github/workflows/native-type-check.yml','rust/tests/web/default-branch-build-policy.test.mjs','rust/Cargo.toml','rust/Cargo.lock'],cwd=root,stdout=f,check=True)
print((out/'resolved.diff').read_text());print('All upstream native profile changes were already present in the branch; keep the branch regression runner, offline scoping, pinned Node setup and new cache diagnostics.')
subprocess.run(['git','add','--','.github/workflows/native-type-check.yml','rust/tests/web/default-branch-build-policy.test.mjs','experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8'],cwd=root,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
subprocess.run(['git','commit','-m','Merge main through v0.356.5 and preserve native regression policy'],cwd=root,check=True,stdout=subprocess.DEVNULL)
print('HEAD',subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip());print('STATUS',subprocess.check_output(['git','status','--short'],cwd=root,text=True))
