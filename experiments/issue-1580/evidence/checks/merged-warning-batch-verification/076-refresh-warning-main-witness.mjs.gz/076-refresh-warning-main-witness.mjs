import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {deserialize} from 'node:v8';
import {createHash} from 'node:crypto';
const path='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8';
const out='/tmp/issue-1580-research/merge-current-main-warning-batch';
const git=(...args)=>execFileSync('git',args,{maxBuffer:8*1024*1024});
const hash=b=>createHash('sha256').update(b).digest('hex');
const oursRaw=git('show',':2:'+path),theirsRaw=git('show',':3:'+path),baseRaw=git('show',':1:'+path);
const base=deserialize(baseRaw),theirs=deserialize(theirsRaw),expectedTheirs=structuredClone(base);
const source='rust/Cargo.toml';
const beforeHash=hash(git('show','HEAD:'+source)),baseSource=git('merge-base','HEAD','origin/main').toString().trim();
const baseHash=hash(git('show',baseSource+':'+source)),theirsHash=hash(git('show','origin/main:'+source));
let upstreamChanges=0;
for(const c of expectedTheirs.inventory.cases)for(const f of c.program?.fixtures??[])if(f.file==='repo:'+source){assert.equal(f.sha256,baseHash);f.sha256=theirsHash;upstreamChanges++;}
assert.equal(upstreamChanges,4);assert.deepEqual(theirs,expectedTheirs,'upstream witness must only refresh four reviewed Cargo fixture hashes');
writeFileSync(out+'/ours-before.v8',oursRaw);writeFileSync(out+'/main-before.v8',theirsRaw);writeFileSync(path,oursRaw);
const before=deserialize(oursRaw),expected=structuredClone(before),afterHash=hash(readFileSync(source));let changes=0;
assert.notEqual(beforeHash,afterHash);
for(const c of expected.inventory.cases)for(const f of c.program?.fixtures??[])if(f.file==='repo:'+source){assert.equal(f.sha256,beforeHash);f.sha256=afterHash;changes++;}
assert.equal(changes,4);
const readerSha=hash(readFileSync('scripts/lib/rust-specification-cases.mjs'));
assert.equal(readerSha,'861c6c5b40cfc8f4e99ad0ebece2cc3c20f941c6a1103dd5e8e70813c40ee0ca');
const args=['--max-old-space-size=256','rust/tests/web/rust-specification-unicode-identifiers.test.mjs','--refresh-reviewed-baseline','--reviewed-reader-sha='+readerSha,'--previous-baseline-sha='+hash(oursRaw)];
writeFileSync(out+'/witness-refresh.log',execFileSync(process.execPath,args,{maxBuffer:2*1024*1024}));
const afterRaw=readFileSync(path);assert.deepEqual(deserialize(afterRaw),expected);
const report={source,baseHash,beforeHash,upstreamHash:theirsHash,afterHash,upstreamChanges,mergedChanges:changes,beforeWitnessSha256:hash(oursRaw),afterWitnessSha256:hash(afterRaw),readerSha256:readerSha,completeObjectComparison:true,nativeExecutionVerified:false,independentAuthorshipCredit:0};
writeFileSync(out+'/witness-review.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
