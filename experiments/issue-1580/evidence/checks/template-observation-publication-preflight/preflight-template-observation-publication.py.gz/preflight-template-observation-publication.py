from pathlib import Path
import json,os,subprocess,sys,time
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/template-observation-publication-preflight')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('wb') as stream:worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(json.dumps({'pid':worker.pid}));raise SystemExit(0)
results=[]
def run(name,args,environment=None,input_bytes=None):
 start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  result=subprocess.run(args,cwd=root,env=environment,input=input_bytes,stdout=stdout,stderr=stderr)
 row={'name':name,'argv':args,'exitCode':result.returncode,'seconds':round(time.monotonic()-start,3)};results.append(row)
 (out/'partial.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 return result.returncode
assert run('branch',['git','branch','--show-current'])==0
assert (out/'branch.stdout').read_text().strip()=='issue-1580-8d61a32a61e1'
assert run('head',['git','rev-parse','HEAD'])==0
assert run('status',['git','status','--short'])==0
assert (out/'status.stdout').stat().st_size==0
assert run('changed-files',['git','diff','--name-only','-z','adeb4ff46c4bb162a82aacbeb0c38bbe9aeebd1a','HEAD'])==0
changed=(out/'changed-files.stdout').read_bytes();assert changed
environment={**os.environ,'SECRETLINT_VERSION':'14.0.0','PATH':'/tmp/issue-1580-research/secretlint-built-in-migration/dependencies/node_modules/.bin:'+os.environ['PATH']}
assert run('actual-secretlint',['node','--max-old-space-size=256','scripts/check-secrets-files.mjs'],environment,changed)==0
assert run('archive-abbreviations',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations'])==0
assert run('whitespace',['git','diff','--check','adeb4ff46c4bb162a82aacbeb0c38bbe9aeebd1a','HEAD'])==0
assert run('fetch',['git','fetch','origin','main','issue-1580-8d61a32a61e1'])==0
assert run('main-merged',['git','merge-base','--is-ancestor','origin/main','HEAD'])==0
assert run('remote-head',['git','rev-parse','origin/issue-1580-8d61a32a61e1'])==0
assert (out/'remote-head.stdout').read_text().strip()=='adeb4ff46c4bb162a82aacbeb0c38bbe9aeebd1a'
repo=['--repo','link-assistant/formal-ai']
commands=[('recent-runs',['gh','run','list',*repo,'--branch','issue-1580-8d61a32a61e1','--limit','5','--json','databaseId,conclusion,createdAt,headSha']),
 ('all-runs',['gh','run','list',*repo,'--branch','issue-1580-8d61a32a61e1','--limit','100','--json','databaseId,status,conclusion,createdAt,headSha,workflowName,url']),
 ('issue',['gh','issue','view','1580',*repo,'--json','title,body,url,updatedAt']),
 ('issue-comments',['gh','api','repos/link-assistant/formal-ai/issues/1580/comments','--paginate']),
 ('conversation-comments',['gh','api','repos/link-assistant/formal-ai/issues/1581/comments','--paginate']),
 ('inline-comments',['gh','api','repos/link-assistant/formal-ai/pulls/1581/comments','--paginate']),
 ('reviews',['gh','api','repos/link-assistant/formal-ai/pulls/1581/reviews','--paginate']),
 ('pull-request',['gh','pr','view','1581',*repo,'--json','title,body,isDraft,headRefOid,baseRefOid,mergeStateStatus,url']),
 ('in-progress',['gh','run','list',*repo,'--branch','issue-1580-8d61a32a61e1','--status','in_progress','--limit','100','--json','databaseId,workflowName,headSha']),
 ('queued',['gh','run','list',*repo,'--branch','issue-1580-8d61a32a61e1','--status','queued','--limit','100','--json','databaseId,workflowName,headSha'])]
for name,args in commands:assert run(name,args)==0
assert json.loads((out/'in-progress.stdout').read_text())==[]
assert json.loads((out/'queued.stdout').read_text())==[]
assert run('local-source-diff',['git','diff','adeb4ff46c4bb162a82aacbeb0c38bbe9aeebd1a','HEAD','--',':(exclude)**/*.gz',':(exclude)**/records.json'])==0
(out/'outcome.json').write_text(json.dumps({'head':(out/'head.stdout').read_text().strip(),'results':results,'allPassed':True,'changedFiles':len(changed.split(b'\0'))-1,'compressedStreams':sum(path.endswith(b'.gz') for path in changed.split(b'\0')),'pushExecuted':False,'fullIssueComplete':False},indent=2)+'\n')
