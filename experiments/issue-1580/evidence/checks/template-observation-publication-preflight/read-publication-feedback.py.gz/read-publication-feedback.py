from pathlib import Path
import json
out=Path('/tmp/issue-1580-research/template-observation-publication-preflight')
for name in ['issue-comments','conversation-comments']:
 rows=json.loads((out/(name+'.stdout')).read_text())
 text='\n\n'.join(f"{row['html_url']} {row['updated_at']}\n{row['body']}" for row in rows)
 (out/(name+'.txt')).write_text(text+'\n')
 print(json.dumps({'name':name,'count':len(rows),'bodyLines':len(text.splitlines())}))
issue=json.loads((out/'issue.stdout').read_text());(out/'issue.txt').write_text(issue['title']+'\n'+issue['body']+'\n')
pr=json.loads((out/'pull-request.stdout').read_text());print(json.dumps({key:value for key,value in pr.items() if key!='body'}))
metadata=json.loads((out/'outcome.json').read_text());print(json.dumps({key:value for key,value in metadata.items() if key!='results'}))
