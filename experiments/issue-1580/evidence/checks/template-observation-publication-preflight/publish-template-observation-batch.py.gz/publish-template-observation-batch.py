from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys,time
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
source=scratch/'template-observation-publication-preflight';out=scratch/'template-observation-publication'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('wb') as stream:worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(json.dumps({'pid':worker.pid}));raise SystemExit(0)
steps=[]
def run(name,args,environment=None,input_bytes=None):
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  result=subprocess.run(args,cwd=root,env=environment,input=input_bytes,stdout=stdout,stderr=stderr)
 row={'name':name,'exitCode':result.returncode};steps.append(row);(out/'steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert result.returncode==0,row
 return (out/(name+'.stdout')).read_bytes()
preflight=json.loads((source/'outcome.json').read_text());assert preflight['allPassed']
assert run('branch',['git','branch','--show-current']).decode().strip()=='issue-1580-8d61a32a61e1'
assert run('head-before',['git','rev-parse','HEAD']).decode().strip()==preflight['head']
assert run('status-before',['git','status','--short'])==b''
target=root/'experiments/issue-1580/evidence/checks/template-observation-publication-preflight';target.mkdir(exist_ok=False);records=[]
for path in sorted(source.iterdir()):
 if not path.is_file():continue
 raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);name=path.name+'.gz';(target/name).write_bytes(packed)
 records.append({'source':str(path),'file':name,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
for path in [scratch/'preflight-template-observation-publication.py',scratch/'read-publication-feedback.py',Path(__file__)]:
 raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);name=path.name+'.gz';(target/name).write_bytes(packed)
 records.append({'source':str(path),'file':name,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
for row in records:
 packed=(target/row['file']).read_bytes();assert hashlib.sha256(packed).hexdigest()==row['archiveSha256'] and hashlib.sha256(gzip.decompress(packed)).hexdigest()==row['rawSha256']
(target/'records.json').write_text(json.dumps({'records':records,'allHashesVerified':True,'scannedFilesBeforeThisArchive':594,'scannedCompressedStreamsBeforeThisArchive':569,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
plan=root/'experiments/issue-1580/work-plan.md';text=plan.read_text().replace('- [ ] Qualify the final retained archives and terminal preceding-head hosted\n  logs before the next single push. Current source-size warnings remain 91.','- [x] Qualify the terminal preceding-head hosted logs and final retained\n  archives: actual Secretlint 14 passes all 594 changed paths / 569 compressed\n  streams before the publication preflight archive. Source warnings remain 91.')
plan.write_text(text)
checkpoint=root/'docs/case-studies/issue-1580/terminal-template-observation-checkpoint.md'
with checkpoint.open('a') as stream:stream.write('''

The publication preflight scans all 594 changed files, including 569 compressed
streams, with actual Secretlint 14. The final abbreviation gate retains its
unchanged 90 ceiling. The default branch is merged; issue comments, PR
conversation comments, inline comments and reviews are refreshed and read.
There are one, eleven, zero and zero respectively, with no new feedback.
The complete 1934-line source/metadata diff for this batch is reviewed;
compressed records are checked by identity rather than called literal review.
The full PR-wide review remains open. These preflight observations precede
their own archive, which is scanned again before the single branch push.
''')
run('stage',['git','add','--',str(target.relative_to(root)),str(plan.relative_to(root)),str(checkpoint.relative_to(root))])
run('commit',['git','commit','-m','docs: preserve final template publication preflight'])
head=run('head',['git','rev-parse','HEAD']).decode().strip()
changed=run('changed-files',['git','diff','--name-only','-z','adeb4ff46c4bb162a82aacbeb0c38bbe9aeebd1a','HEAD'])
environment={**os.environ,'SECRETLINT_VERSION':'14.0.0','PATH':'/tmp/issue-1580-research/secretlint-built-in-migration/dependencies/node_modules/.bin:'+os.environ['PATH']}
run('actual-secretlint',['node','--max-old-space-size=256','scripts/check-secrets-files.mjs'],environment,changed)
run('abbreviations',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations'])
run('whitespace',['git','diff','--check','adeb4ff46c4bb162a82aacbeb0c38bbe9aeebd1a','HEAD'])
assert run('clean-tree',['git','status','--short'])==b''
run('fetch',['git','fetch','origin','main','issue-1580-8d61a32a61e1'])
run('main-merged',['git','merge-base','--is-ancestor','origin/main','HEAD'])
assert run('remote-head',['git','rev-parse','origin/issue-1580-8d61a32a61e1']).decode().strip()=='adeb4ff46c4bb162a82aacbeb0c38bbe9aeebd1a'
for state in ['in_progress','queued']:
 value=run(state,['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--status',state,'--limit','100','--json','databaseId,workflowName,headSha'])
 assert json.loads(value)==[]
body=json.loads((source/'pull-request.stdout').read_text())['body']
needle='Verification:\n\n';assert needle in body
addition='''- Published __BT__adeb4ff4__BT__ has all 26 normal workflows terminal: 25 success, one skip, no failed workflow. All eight native families and release-registry checks pass. Three failure annotations survive successful retries/negative controls and remain explicit investigation items alongside 91 source warnings and publish-token uncertainty. [Terminal checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/terminal-template-observation-checkpoint.md).
- This batch passes all 126 maintained observation cases, with zero skips, plus affected JavaScript gates and the direct documentation checker. Actual Secretlint 14 passes 594 changed files / 569 compressed streams before preflight archival, followed by a fresh scan of the entire final publication batch. Its hosted qualification remains pending at publication.
- The current Python pin has 33/35 changed files completely read. Its hosted clean install and actual ncc rebuild match the bundle/licenses, 51 artifact/deployment mock cases pass, two real transport round trips pass, and the npm audit/deprecation inventory is clean. All 247 lock identities/engines/licenses are reviewed; literal minified bundle/lock and full template/practice acceptance remain open. [Python checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/python-current-findings-checkpoint.md).

'''.replace('__BT__',chr(96))
body=body.replace(needle,needle+addition,1)
needle='Upstream reproductions and reports:\n\n';assert needle in body
reports='''- Current PHP finite pipe deadlock and literal-zero loss: [PHP #33](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/33), three actual-helper cases with a disposable concurrent-reader candidate.
- Current Python Scriv fragment data loss: [Python #165](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/165), four actual-Python cases with the external producer mocked. JavaScript-only production helpers bypass code outputs: [Python #166](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/166), three actual-Python/Git cases across pushes and PRs. These reports establish no upstream repair.
'''
body=body.replace(needle,needle+reports,1)
body=body.replace('next-head verification of Secretlint 14 and the annotation line-boundary repair;','next-head hosted verification of the new PHP/Python observation cases; investigation of the three retained failure annotations;')
assert body.count('Fixes #1580')==1
(out/'body.md').write_text(body)
run('edit-pull-request',['gh','pr','edit','1581','--repo','link-assistant/formal-ai','--title','fix: repair CI evidence, release validation and native contracts','--body-file',str(out/'body.md')])
run('push',['git','push','origin','HEAD:issue-1580-8d61a32a61e1'])
pr=json.loads(run('published-pull-request',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','headRefOid,isDraft,url']))
assert pr['headRefOid']==head and pr['isDraft']
for repo,number,file in [
 ('link-foundation/php-ai-driven-development-pipeline-template','33','template-php-pipe-integrity.test.mjs'),
 ('link-foundation/python-ai-driven-development-pipeline-template','165','template-python-scriv-integrity.test.mjs'),
 ('link-foundation/python-ai-driven-development-pipeline-template','166','template-python-javascript-detection.test.mjs')]:
 url='https://github.com/link-assistant/formal-ai/blob/'+head+'/experiments/issue-1580/'+file
 comment=out/('upstream-'+number+'.md');comment.write_text('The maintained finite regression source is now published: '+url+' .\n\nThe complete local template-observation entry passes all 126 cases with zero skips. The observations execute the pinned helpers and disposable candidate controls; no upstream repair is claimed. They are included in https://github.com/link-assistant/formal-ai/pull/1581 .\n')
 run('upstream-'+number,['gh','issue','comment',number,'--repo',repo,'--body-file',str(comment)])
assert run('final-clean-tree',['git','status','--short'])==b''
(out/'outcome.json').write_text(json.dumps({'complete':True,'head':head,'pushExecuted':True,'pullRequest':pr['url'],'draft':True,'newUpstreamRegressionLinks':3,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
