from pathlib import Path
import hashlib, json, subprocess, urllib.request

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/time-dependency-publications-current')
base.mkdir(exist_ok=False)
for repository, number in [('link-foundation/command-stream', 238), ('link-assistant/calculator', 265)]:
    name = repository.replace('/', '--') + '-' + str(number)
    result = subprocess.run(['gh', 'issue', 'view', str(number), '--repo', repository,
        '--json', 'number,title,state,body,comments,updatedAt,url'], cwd=root, capture_output=True)
    (base / (name + '.json')).write_bytes(result.stdout)
    (base / (name + '.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0
    data = json.loads(result.stdout)
    print(repository, number, data['state'], data['updatedAt'], 'comments', len(data['comments']), flush=True)
for crate in ['command-stream', 'link-calculator']:
    def fetch(suffix, name):
        request = urllib.request.Request('https://crates.io/api/v1/crates/' + crate + suffix,
            headers={'User-Agent': 'formal-ai-issue-1580-publication-verification'})
        with urllib.request.urlopen(request) as response:
            raw = response.read(2 * 1024 * 1024)
        (base / (crate + '-' + name + '.json')).write_bytes(raw)
        return json.loads(raw)
    data = fetch('', 'registry')
    version = data['crate']['max_version']
    dependencies = fetch('/' + version + '/dependencies', 'dependencies')
    selected = [row for row in dependencies['dependencies'] if row['crate_id'] in ['chrono', 'jiff', 'time']]
    print(json.dumps({'crate': crate, 'publishedLatest': version, 'timeDependencies': selected}), flush=True)
print('Fresh immutable version dependency responses retained; no version or lockfile mutation.', flush=True)
