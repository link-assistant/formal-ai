from pathlib import Path
import hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/rust-historical-preview-image')
base.mkdir(exist_ok=False)
url = 'https://github.com/konard/vk-bot-desktop/blob/issue-51-60ec0489f01f/site/assets/app-preview-en-light.png?raw=true'
command = 'curl -L -H "Authorization: token $(gh auth token)" -o ' + str(base / 'preview.png') + ' "' + url + '"'
result = subprocess.run(['bash', '-c', command], cwd=root, capture_output=True)
for label in ('stdout', 'stderr'):
    (base / ('download.' + label)).write_bytes(getattr(result, label))
assert result.returncode == 0
result = subprocess.run(['file', str(base / 'preview.png')], capture_output=True)
(base / 'file-type.stdout').write_bytes(result.stdout)
(base / 'file-type.stderr').write_bytes(result.stderr)
raw = (base / 'preview.png').read_bytes()
outcome = {'url': url, 'downloadExitCode': result.returncode, 'validPng': raw.startswith(b'\x89PNG\r\n\x1a\n'),
    'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw), 'literalTemplateSource': False,
    'currentFormalAiVisualAcceptance': False}
(base / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
print(result.stdout.decode())
print(json.dumps(outcome))
