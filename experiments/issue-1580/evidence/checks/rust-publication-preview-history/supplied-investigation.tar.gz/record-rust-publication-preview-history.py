from pathlib import Path
import datetime, gzip, hashlib, io, json, tarfile

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
source = scratch / 'templates/rust-complete'
paths = ['docs/case-studies/issue-38/raw-data/' + name for name in [
    'issue-38.json', 'main-runs.json', 'downstream-meta-ontology-pr-4.json']]
paths.append('docs/case-studies/issue-52/raw-data/vk-bot-desktop-pr-52.json')
inventory = json.loads((root / 'experiments/issue-1580/evidence/checks/rust-template-first-gate/pinned-file-identities.json').read_text())
identities = {row['path']: row for row in inventory}
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert data['fullyReadFiles'] == 320
manifest = root / data['readLogManifest']
records = json.loads(manifest.read_text())
for index, path in enumerate(paths):
    assert path not in {row['path'] for row in data['files']}
    raw = (source / path).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == identities[path]['sha256'] and len(raw.decode().splitlines()) == 1
    name = 'publication-preview-history-' + str(index + 1) + '.read.txt.gz'
    read = ('FILE ' + path + ' LINES 1 SHA256 ' + digest + '\n1: ' + raw.decode().rstrip('\n') + '\n').encode()
    packed = gzip.compress(read, mtime=0)
    assert not (manifest.parent / name).exists()
    (manifest.parent / name).write_bytes(packed)
    records.append({'file': name, 'rawSha256': hashlib.sha256(read).hexdigest(),
        'archiveSha256': hashlib.sha256(packed).hexdigest()})
    data['files'].append({'path': path, 'lines': 1, 'sha256': digest, 'readLogs': [name],
        'literalReadRanges': [[1, 1]], 'literalReadLines': 1, 'literalSourceFullyRead': True,
        'formalAiPracticeImplementationVerified': False})
manifest.write_text(json.dumps(records, indent=2) + '\n')
data['files'].sort(key=lambda row: row['path'])
data['fullyReadFiles'] = len(data['files'])
data['fullyReadSourceLines'] = sum(row['literalReadLines'] for row in data['files'])
data['observedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
data['practiceDecisions'].append({'practice': 'Preserve documentation after publication failure and qualify actual screenshot refresh',
    'templateEvidence': paths,
    'assessment': 'Read the complete original issue, ten dated main runs, downstream documentation PR and all desktop preview PR details/comments. Historical publication failures must not suppress validated documentation. The current counterpart and advancing-main identity defect now have five failing controls before repair and 13 passing focused controls after it, but the retained release dependencies still wait for terminal publishers and actual Pages delivery remains open. The merged preview PR generates English/Russian light/dark screenshots and checks 270 tests; its post-merge main/no-op checklist remains unchecked. Authenticated English/light PNG is format-verified and visually read. The pinned empty-assets desktop screenshot is also format-verified and viewed; neither image proves current Formal AI release or preview publication. Embedded historical issue links are comparison evidence, not required sub-issues of #1580.',
    'status': 'complete-historical-publication-preview-records-read-current-publication-open',
    'formalAiPaths': ['scripts/generate-staged-release.mjs', '.github/workflows/pages-artifact.yml',
        'experiments/issue-1580/pages-release-failure.test.mjs', '.github/workflows/desktop-release.yml'],
    'verification': 'docs/case-studies/issue-1580/pages-release-failure-checkpoint.md'})
ledger.write_text(json.dumps(data, indent=2) + '\n')
destination = root / 'experiments/issue-1580/evidence/checks/rust-publication-preview-history'
destination.mkdir(exist_ok=False)
selected = [Path(__file__), scratch / 'download-historical-preview-image.py',
    scratch / 'download-historical-preview-image.log', scratch / 'refresh-time-dependency-publications.py',
    scratch / 'refresh-time-dependency-publications.log']
for folder in ['rust-historical-preview-image', 'time-dependency-publications-current']:
    selected.extend(path for path in (scratch / folder).rglob('*') if path.is_file())
buffer = io.BytesIO()
rows = []
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for path in sorted(selected):
        raw = path.read_bytes()
        name = path.relative_to(scratch).as_posix()
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
        archive.addfile(entry, io.BytesIO(raw))
        rows.append({'file': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
raw = buffer.getvalue()
packed = gzip.compress(raw, mtime=0)
(destination / 'supplied-investigation.tar.gz').write_bytes(packed)
(destination / 'supplied-investigation.json').write_text(json.dumps({'files': rows,
    'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(),
    'independentAuthorshipCredit': 0, 'fullIssueComplete': False}, indent=2) + '\n')
(destination / 'assessment.json').write_text(json.dumps({
    'historicalPreview': {'source': 'https://github.com/konard/vk-bot-desktop/blob/issue-51-60ec0489f01f/site/assets/app-preview-en-light.png?raw=true',
        'sha256': '7b72b5b656f59bfdb7da70b2bb65f8db0494679f886addfd646be1272b235066',
        'bytes': 69451, 'verifiedMime': 'PNG', 'viewed': True,
        'assessment': 'English/light VK Bot, Local/Remote controls, Start, empty token field, six checked features and empty logs. Historical static visual only.',
        'currentFormalAiRuntimeProof': False},
    'freshPublishedDependencies': {'command-stream': {'version': '1.13.0', 'chrono': '^0.4.45',
        'upstreamIssueState': 'CLOSED'}, 'link-calculator': {'version': '0.24.0', 'chrono': '^0.4',
        'upstreamIssueState': 'OPEN'}, 'bothChronoDependenciesUnconditional': True,
        'publishedJiffMigrationVerified': False},
    'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- Four complete pinned Rust publication/preview history records are read and identity-verified: 324/373 literal files, 37,641 lines; binary visual review is tracked separately. The authenticated preview PNG and empty-assets screenshot are format-verified and viewed, without current delivery credit. Fresh registry responses still show mandatory Chrono in command-stream 1.13.0 and link-calculator 0.24.0 despite the first upstream issue closing; published removal remains unverified. All broader requirements remain open.\n')
print('Literal pinned Rust review: 324/373 files; 37,641 lines. Historical images and fresh publication limits retained.')
