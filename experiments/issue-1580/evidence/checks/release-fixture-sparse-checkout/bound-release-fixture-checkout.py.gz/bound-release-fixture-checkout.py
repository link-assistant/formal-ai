from pathlib import Path
import gzip, hashlib, json, os, resource, shutil, subprocess
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/release-fixture-sparse-checkout')
out.mkdir(exist_ok=False)
owned = Path('/tmp/issue-738-release-qlfo9b')
assert owned.name.startswith('issue-738-release-') and owned.parent == Path('/tmp')
if owned.exists(): shutil.rmtree(owned)
stop = {'gate': 'check-fragment-release-map', 'workerPid': 3535283, 'ownedClonePid': 3536250, 'observedCloneRssKiB': 770528, 'sharedMemoryCurrentBeforeTermination': 3132772352, 'sharedMemoryLimit': 3135369216, 'signal': 'SIGTERM', 'reason': 'The full worktree checkout approached the shared cgroup limit.', 'source': 'Externally observed process and cgroup snapshots; zero autonomous credit', 'completedGateRun': False}
(out / 'interrupted-full-gates.json').write_text(json.dumps(stop, indent=2) + '\n')
prior = Path('/tmp/issue-1580-research/codeql-cache-retention-repair')
for name in ['all-javascript-gates.stdout', 'all-javascript-gates.stderr', 'worker.log']:
    (out / ('interrupted-' + name)).write_bytes((prior / name).read_bytes())
path = root / 'experiments/issue_738_fragment_release_map.test.mjs'
before = path.read_text(); (out / 'before.test.mjs').write_text(before)
assert before.count('  copyFileSync,') == 1
after = before.replace('  copyFileSync,', '  copyFileSync,\n  existsSync,')
old = '    execFileSync("git", ["clone", "--shared", "--quiet", source, repo]);'
new = '''    // History is shared for the real release reconstruction. Only its input
    // paths need a worktree; checking out unrelated evidence copies the repo.
    execFileSync("git", [
      "clone", "--shared", "--no-checkout", "--quiet",
      "--config", "core.deltaBaseCacheLimit=16m", source, repo,
    ]);
    execFileSync("git", ["-C", repo, "sparse-checkout", "set", "--no-cone", "--stdin"], {
      input: [
        "/CHANGELOG.md", "/changelog.d/", "/docs/changelog/",
        "/docs/case-studies/issue-711/fragment-release-map.tsv",
        "/experiments/issue_711_rebuild_changelog.mjs", "",
      ].join("\\n"),
    });
    execFileSync("git", ["-C", repo, "checkout", "--quiet", "HEAD"]);
    assert.equal(existsSync(join(repo, "rust/src/lib.rs")), false);
    assert.equal(existsSync(join(repo, "experiments/issue-1580/evidence")), false);'''
assert after.count(old) == 1
after = after.replace(old, new); path.write_text(after)
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=192')
with (out / 'focused.stdout').open('wb') as stdout, (out / 'focused.stderr').open('wb') as stderr:
    result = subprocess.run(['node', '--test', '--test-concurrency=1', str(path.relative_to(root))], cwd=root, env=environment, stdout=stdout, stderr=stderr)
status = {'exitCode': result.returncode, 'largestReapedChildMaxRssKiB': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss, 'remainingMemory': int(Path('/sys/fs/cgroup/memory.current').read_text())}
(out / 'focused-result.json').write_text(json.dumps(status, indent=2) + '\n')
assert result.returncode == 0, status
assert status['largestReapedChildMaxRssKiB'] < 384 * 1024, status
archive = root / 'experiments/issue-1580/evidence/checks/release-fixture-sparse-checkout'
archive.mkdir(exist_ok=False)
inventory = []
for source in [Path(__file__), *sorted(out.iterdir())]:
    raw = source.read_bytes(); packed = gzip.compress(raw, mtime=0); name = source.name + '.gz'
    (archive / name).write_bytes(packed)
    inventory.append({'file': name, 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
(archive / 'streams.json').write_text(json.dumps(inventory, indent=2) + '\n')
outcome = {'passed': True, 'historyRetained': True, 'actualReleaseReconstruction': True, 'unrelatedSourceAndEvidenceAbsent': True, **status, 'testPath': str(path.relative_to(root)), 'testSha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
(archive / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
print(json.dumps(outcome))
