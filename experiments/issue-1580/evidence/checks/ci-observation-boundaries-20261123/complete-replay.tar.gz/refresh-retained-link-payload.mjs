import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {resolve} from 'node:path';
const require=createRequire(resolve('package.json')),YAML=require('yaml');
const sha=x=>createHash('sha256').update(x).digest('hex');
const payload=job=>JSON.stringify({steps:job.steps,uses:job.uses,with:job.with,strategy:job.strategy});
const file='data/benchmarks/fast-pull-request-retained-jobs.json', before=readFileSync(file,'utf8'),manifest=JSON.parse(before);
const changes=[];
for(const row of manifest.jobs) {
  const current=YAML.parse(readFileSync('.github/workflows/'+row.file,'utf8')).jobs[row.id];
  const after=sha(payload(current));
  if(after===row.payloadSha256)continue;
  assert.equal(row.file,'links.yml');assert.equal(row.id,'link-checker');
  const previousSource=execFileSync('git',['show','6b9574039^:.github/workflows/links.yml'],{encoding:'utf8'});
  const previous=YAML.parse(previousSource).jobs[row.id];
  assert.equal(sha(payload(previous)),row.payloadSha256,'exact preceding job matches the retained witness');
  assert.equal(after,'38984c2f728fb8c4738af9034a3c9a2e0a7a09318cd97a46127c9f7da3a614f6');
  changes.push({file:row.file,job:row.id,before:row.payloadSha256,after,reviewedCommit:'6b957403972952ab07e58c8b88d7ba25bdf9b801',reason:'Require actual successful link observations and complete failure reports; retain the original checker and production dispatch predicates'});
  row.payloadSha256=after;
}
assert.equal(changes.length,1);
writeFileSync('/tmp/issue-1580-research/retained-link-payload-refresh.json',JSON.stringify({comparedJobs:manifest.jobs.length,changes},null,2)+'\n');
writeFileSync(file,JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({comparedJobs:manifest.jobs.length,changes}));
