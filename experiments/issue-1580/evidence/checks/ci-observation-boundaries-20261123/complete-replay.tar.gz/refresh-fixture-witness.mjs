import assert from 'node:assert/strict';
import {readFileSync, writeFileSync, readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {deserialize, serialize} from 'node:v8';
import {resolve, relative, isAbsolute} from 'node:path';
import {pathToFileURL} from 'node:url';
const root = process.cwd();
const file = 'experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8';
const sha = value => createHash('sha256').update(value).digest('hex');
const beforeBytes = readFileSync(file), before = deserialize(beforeBytes);
const {specificationCases} = await import(pathToFileURL(resolve('scripts/lib/rust-specification-cases.mjs')));
const inventory = specificationCases(root), cases = structuredClone(inventory.cases);
for(const item of cases)for(const fixture of item.program?.fixtures??[])if(isAbsolute(fixture.file)) {
  const path=relative(root,fixture.file);assert(!path.startsWith('..'));fixture.file='repo:'+path;
}
const sourceManifest = readdirSync('rust/tests/unit/specification',{recursive:true}).map(String).filter(name=>name.endsWith('.rs')).sort().map(name=> {
  const path='rust/tests/unit/specification/'+name;return {path,sha256:sha(readFileSync(path))};
});
const after = {inventory:{...inventory,cases},sourceManifest}, normalized = structuredClone(after), changes=[];
for(let i=0;i<cases.length;i++)for(let j=0;j<(cases[i].program?.fixtures??[]).length;j++) {
  const previous=before.inventory.cases[i]?.program?.fixtures?.[j], current=normalized.inventory.cases[i].program.fixtures[j];
  assert.equal(current.file,previous.file);
  if(current.sha256!==previous.sha256) {
    assert.equal(current.file,'repo:rust/tests/unit/mod.rs');
    assert.equal(previous.sha256,'010246547aa7eafb25a6ddf0d5491575c3b1fbb1120c18888ab3aefd051fc51b');
    assert.equal(current.sha256,sha(readFileSync('rust/tests/unit/mod.rs')));
    changes.push({case:cases[i].id,file:current.file,before:previous.sha256,after:current.sha256});
    current.sha256=previous.sha256;
  }
}
assert(changes.length>0);
assert.deepEqual(normalized,before,'No case, assertion, unsupported scope, source manifest or other complete object may change');
const afterBytes=serialize(after);
assert.equal(sha(readFileSync(file)),sha(beforeBytes));
writeFileSync('/tmp/issue-1580-research/fixture-witness-before.v8',beforeBytes);
writeFileSync('/tmp/issue-1580-research/fixture-witness-after.v8',afterBytes);
const report={total:inventory.total,cases:cases.length,unsupported:inventory.unsupported.length,before:sha(beforeBytes),after:sha(afterBytes),changes,completeObjectComparison:true};
writeFileSync('/tmp/issue-1580-research/fixture-witness-refresh.json',JSON.stringify(report,null,2)+'\n');
if(process.argv.includes('--write'))writeFileSync(file,afterBytes);
console.log(JSON.stringify(report));
