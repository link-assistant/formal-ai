from pathlib import Path
import sys

root = Path.cwd()
scratch = Path('/tmp/issue-1580-research/audit-observation-boundary')
scratch.mkdir(exist_ok=True)
test = root / 'rust/tests/web/cargo-audit-inventory.test.mjs'
script = root / 'scripts/check-rust-dependencies.sh'
if sys.argv[1] == 'tests':
    (scratch / 'before.sh').write_bytes(script.read_bytes())
    (scratch / 'before.test.mjs').write_bytes(test.read_bytes())
    source = test.read_text()
    source = source.replace('inventoryBytes = null, quotePaths = true, untracked = [], stagedOnly = []} = {}) {',
        'inventoryBytes = null, quotePaths = true, untracked = [], stagedOnly = [], auditOutput = {}} = {}) {')
    source = source.replace("process.exit(Number(JSON.parse(process.env.AUDIT_FAILURES)[path] ?? 0));", """const observations = JSON.parse(process.env.AUDIT_OUTPUT)[path] ?? [];
const count = fs.readFileSync(process.env.CARGO_TRACE, 'utf8').split('\\n').filter(Boolean)
  .map(JSON.parse).filter(call => call[call.indexOf('--file') + 1] === path).length;
const observation = observations[Math.min(count - 1, observations.length - 1)];
if (observation) {
  process.stdout.write(observation.stdout ?? '');
  process.stderr.write(observation.stderr ?? '');
}
process.exit(Number(observation?.status ?? JSON.parse(process.env.AUDIT_FAILURES)[path] ?? 0));""")
    source = source.replace("CARGO_TRACE:trace, AUDIT_FAILURES:JSON.stringify(failures)}", "CARGO_TRACE:trace, AUDIT_FAILURES:JSON.stringify(failures), AUDIT_OUTPUT:JSON.stringify(auditOutput)}")
    source = source.replace("const trace = join(directory, 'cargo-calls.jsonl');", """// Retry delay is recorded by the real wrapper but skipped in this finite fixture.
    writeFileSync(join(directory, 'bin/sleep'), '#!/bin/sh\\nexit 0\\n', {mode:0o755});
    const trace = join(directory, 'cargo-calls.jsonl');""")
    source += """

const reset = "error: couldn't check if the package is yanked: registry: error decoding response body\\nCaused by:\\n  -> connection reset\\n";
for (const path of [primary, 'extra/Cargo.lock']) {
  test(`a zero-exit incomplete yank observation stays fatal for ${path}`, {timeout:10000}, () => {
    const result = observe({paths:[primary,'extra/Cargo.lock'], auditOutput:{[path]:[{stderr:reset}]}});
    assert.equal(result.status, 1, result.stdout + result.stderr);
    assert.equal(result.calls.filter(call => call.includes(path)).length, 3);
    assert.ok(result.calls.some(call => call.includes('extra/Cargo.lock')));
    assert.match(result.stdout + result.stderr, /connection reset/u);
    assert.match(result.stdout + result.stderr, /observation incomplete after 3 attempts/u);
  });
}
test('only a later complete audit recovers an incomplete registry observation', {timeout:10000}, () => {
  const result = observe({auditOutput:{[primary]:[{stderr:reset},{stdout:'complete audit\\n'}]}});
  assert.equal(result.status, 0, result.stdout + result.stderr);
  assert.equal(result.calls.length, 2);
  assert.match(result.stdout, /complete audit/u);
  assert.match(result.stdout, /connection reset/u);
});
test('an ANSI colored zero-exit runtime error cannot become an audit success', {timeout:10000}, () => {
  const result = observe({auditOutput:{[primary]:[{stderr:'\\u001b[31merror:\\u001b[0m invalid registry response\\n'}]}});
  assert.equal(result.status, 1, result.stdout + result.stderr);
  assert.equal(result.calls.length, 1);
});
test('independent unmaintained notices keep their existing warning-only policy', {timeout:10000}, () => {
  const result = observe({paths:[primary,'extra/Cargo.lock'], auditOutput:{'extra/Cargo.lock':[
    {stderr:'Warning: unmaintained\\nwarning: 1 allowed warning found\\n'}]}});
  assert.equal(result.status, 0, result.stdout + result.stderr);
  assert.equal(result.calls.length, 2);
  assert.match(result.stdout + result.stderr, /unmaintained/u);
});
"""
    assert source != test.read_text()
    test.write_text(source)
elif sys.argv[1] == 'repair':
    source = script.read_text()
    source = source.replace("trap 'rm -f -- \"$lock_inventory\"' EXIT", """audit_log_dir="$(mktemp -d)"
trap 'rm -f -- "$lock_inventory"; rm -rf -- "$audit_log_dir"' EXIT

# cargo-audit 0.22.2 can print registry errors and still exit zero. Keep the
# complete original stream and require a complete observation. Retry only the
# positively identified transient yank-check failure, at most three times;
# ordinary findings retain their status and are never retried as transport errors.
run_audit() {
  local attempt observed_status errors
  for attempt in 1 2 3; do
    observed_status=0
    timeout 120 "$@" > "$audit_log_dir/output" 2>&1 || observed_status=$?
    cat "$audit_log_dir/output"
    sed -E $'s/\\\\x1b\\\\[[0-9;]*[[:alpha:]]//g' "$audit_log_dir/output" > "$audit_log_dir/plain"
    errors="$(grep -E '^[[:space:]]*error:' "$audit_log_dir/plain" || true)"
    if [[ -z "$errors" ]]; then return "$observed_status"; fi
    if [[ "$observed_status" -eq 0 ]]; then observed_status=1; fi
    if grep -Evq "^[[:space:]]*error: couldn't check if the package is yanked:" <<< "$errors" ||
       ! grep -Eq 'connection reset|connection refused|timed out|timeout|temporarily unavailable' "$audit_log_dir/plain"; then
      echo "::error::Cargo audit emitted an error; the dependency observation is incomplete." >&2
      return "$observed_status"
    fi
    if [[ "$attempt" -eq 3 ]]; then
      echo "::error::Cargo audit registry observation incomplete after 3 attempts." >&2
      return "$observed_status"
    fi
    echo "Cargo audit registry observation incomplete; retrying after attempt $attempt."
    sleep "$((attempt * 2))"
  done
}
""")
    source = source.replace('  cargo audit --file "$lock" --deny warnings || audit_status=$?',
                            '  run_audit cargo audit --file "$lock" --deny warnings || audit_status=$?')
    source = source.replace('  cargo audit --file "$each" --deny unsound --deny yanked || {',
                            '  run_audit cargo audit --file "$each" --deny unsound --deny yanked || {')
    assert source != script.read_text()
    assert source.count('run_audit cargo audit --file') == 2
    script.write_text(source)
else:
    raise ValueError(sys.argv[1])
