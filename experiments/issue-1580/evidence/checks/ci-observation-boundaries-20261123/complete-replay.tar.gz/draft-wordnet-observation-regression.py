from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
p=root/'rust/tests/unit/solver/issue_1138_self_use_concept_lookup.rs'
s=p.read_text()
anchor='''        for (source, status) in [
            ("github", "unbound_template"),
            ("wikidata", "unbound_template"),
            ("wiktionary", "offline_cache_miss"),
            ("wordnet", "unbound_template"),
'''
replacement='''        // WordNet's declared English endpoint is bindable. An empty offline
        // cache reports the actual attempted lookup; other locales remain unbound.
        let wordnet_status = if case.language == "en" {
            "offline_cache_miss"
        } else {
            "unbound_template"
        };
        for (source, status) in [
            ("github", "unbound_template"),
            ("wikidata", "unbound_template"),
            ("wiktionary", "offline_cache_miss"),
            ("wordnet", wordnet_status),
'''
assert s.count(anchor)==1
s=s.replace(anchor,replacement)
anchor='''        let trail = answer
            .split("attempts=")'''
replacement='''        if case.language == "en" {
            assert!(
                answer.contains("https://en-word.net/api/lemma/isogram"),
                "the English refusal must retain the actual bound WordNet endpoint: {answer}"
            );
        }
        let trail = answer
            .split("attempts=")'''
assert s.count(anchor)==1
p.write_text(s.replace(anchor,replacement))
p=root/'rust/tests/web/issue-1138-concept-lookup.test.mjs'
s=p.read_text()
s+='''
test("empty offline WordNet outcomes retain the declared English language boundary", async () => {
  const context = await bootWorker(new Map());
  for (const language of ["en", "ru", "hi", "zh", "es"]) {
    const result = await lookup(context, HELD_OUT_WORD, language, { offline: true });
    const wordnet = result.outcomes.find(row => row.sourceId === "wordnet");
    assert.ok(wordnet, language + " must retain every consulted source");
    assert.equal(wordnet.status, language === "en" ? "offline_cache_miss" : "unbound_template", language);
    if (language === "en") assert.ok(wordnet.detail.includes("https://en-word.net/api/lemma/isogram"), wordnet.detail);
    assert.equal(wordnet.items, 0);
  }
});
'''
p.write_text(s)
