import json, subprocess, datetime
from pathlib import Path
root=Path('/tmp/issue-1580-research/boundary-focused-tests')
root.mkdir(exist_ok=True)
files=[
 'rust/tests/web/procedural-runtime-parity.test.mjs',
 'rust/tests/web/issue-1138-concept-lookup.test.mjs',
 'rust/tests/web/cargo-audit-inventory.test.mjs',
 'rust/tests/web/issue-1571-workflow-diagnostics.test.mjs',
 'rust/tests/web/issue-991-how-to-synthesis.test.mjs',
]
records=[]
for name in files:
    command=['node','--max-old-space-size=384','--test','--test-concurrency=1',name]
    label=Path(name).stem
    with (root/(label+'.log')).open('wb') as out:
        result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
    records.append({'file':name,'command':command,'status':result.returncode,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    (root/'progress.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(records[-1]),flush=True)
(root/'outcome.json').write_text(json.dumps({'complete':True,'allPassed':all(x['status']==0 for x in records),'records':records},indent=2)+'\n')
