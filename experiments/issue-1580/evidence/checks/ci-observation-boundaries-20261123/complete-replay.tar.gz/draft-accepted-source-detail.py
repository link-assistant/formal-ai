from pathlib import Path
import sys
root = Path('/tmp/gh-issue-solver-1794900398048')
mode = sys.argv[1]
if mode == 'test':
    p = root / 'rust/tests/web/procedural-runtime-parity.test.mjs'
    s = p.read_text()
    anchor = 'test("the browser uses a matching archival capture for the short Russian question after a live request fails", async () => {'
    new = '''test("a recovered procedure reports the accepted article after rejecting an unrelated capture", async () => {
  const unrelated = JSON.parse(RUSSIAN_CAPTURE);
  unrelated.parse.title = "Домашние растения";
  const title = "хорошо покакать";
  const matching = wikiParse(title);
  const captures = new Map([
    [RUSSIAN_API, { body: JSON.stringify(unrelated) }],
    [wikiSearch(title), searchCapture(title)],
    [matching, { body: RUSSIAN_CAPTURE }],
  ]);
  const answer = await answerRussian(await bootWorker(captures));
  assert.equal(answer.guide.steps.length, 2, answer.content);
  assert.ok(answer.guide.steps.every(step => step.sourceUrl === matching));
  assert.ok(!answer.content.includes(RUSSIAN_API), answer.content);
  const outcome = answer.guide.outcomes.find(row => row.sourceId === "wikihow");
  assert.equal(outcome.status, "contributed");
  assert.ok(outcome.detail.includes(matching), outcome.detail);
});

'''
    assert s.count(anchor) == 1
    p.write_text(s.replace(anchor, new + anchor))
elif mode == 'fix':
    p = root / 'rust/src/how_to_guide.rs'
    s = p.read_text()
    anchor = '''            Payload::OpenSearch { .. } | Payload::Search { .. } => {}
        }
        read
'''
    replacement = '''            Payload::OpenSearch { .. } | Payload::Search { .. } => {}
        }
        // A later relevant capture replaces the rejected page's outcome detail.
        // The accepted steps retain their own capture URL and digest.
        if !read.items.is_empty() {
            read.detail = Some(capture.source_url().to_owned());
        }
        read
'''
    assert s.count(anchor) == 1
    p.write_text(s.replace(anchor, replacement))
    p = root / 'js/worker/formal_ai_worker_how_to_guide.js'
    s = p.read_text()
    anchor = '  items.forEach((item, index) => { item.position = produced + index + 1; });\n'
    assert s.count(anchor) == 1
    p.write_text(s.replace(anchor, '  if (items.length > 0) detail = capture.url;\n' + anchor))
else:
    raise ValueError(mode)
