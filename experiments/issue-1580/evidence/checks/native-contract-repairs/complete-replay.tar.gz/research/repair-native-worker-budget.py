from pathlib import Path
p = Path('data/meta/worker-line-budget/formal_ai_worker_handler_rules.lino')
text = p.read_text()
assert text.count('  ceiling 808\n') == 1
assert len(Path('js/worker/formal_ai_worker_handler_rules.js').read_text().splitlines()) == 819
text = text.replace('  ceiling 808\n', '  ceiling 819\n')
note = ' Issue #1580 adds eleven measured lines (808 to 819) for balanced reference-list operands: the shared handler tokenizer retains grouped quotes and spaces so actual policy and table readers consume canonical references in parity with Rust. No module or handler is excluded.'
assert text.endswith('"\n')
p.write_text(text[:-2] + note + '"\n')
print('Recorded only the eleven measured generic tokenizer lines.')
