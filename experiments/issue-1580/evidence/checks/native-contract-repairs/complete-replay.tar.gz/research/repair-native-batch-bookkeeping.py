from pathlib import Path

ledger = Path('data/meta/core-boundary-ledger.lino')
text = ledger.read_text()
assert text.count('  source_lines_max 36699\n') + text.count('  source_lines_max 36718\n') == 1
assert text.count('  outside_core_lines_max 17677\n') + text.count('  outside_core_lines_max 17692\n') == 1
text = text.replace('  source_lines_max 36699\n', '  source_lines_max 36718\n')
text = text.replace('  outside_core_lines_max 17677\n', '  outside_core_lines_max 17692\n')
for name, before, after in [('fact_live_answer', 380, 384), ('program_synthesis', 196, 211)]:
    original = f'  source rust/src/solver_handlers/{name}.rs\n'
    start = text.index(original)
    end = text.find('\n  source ', start + len(original))
    section = text[start:end]
    assert section.count(f'    baseline_lines {before}\n') + section.count(f'    baseline_lines {after}\n') == 1
    assert len(Path(f'rust/src/solver_handlers/{name}.rs').read_text().splitlines()) == after
    text = text[:start] + section.replace(f'    baseline_lines {before}\n', f'    baseline_lines {after}\n') + text[end:]
note = '  note "Issue #1580 retains a formalized lookup request in fact_live_answer.rs (380 to 384 lines) and the actual current-call source outcomes in refused synthesis (program_synthesis.rs 196 to 211). The exact census adds nineteen source lines and fifteen outside-core lines; every existing file count, disposition and promotion decision stays binding. No source result or executable draft is fabricated."\n'
if note not in text:
    text = text.replace('core_boundary_ledger\n', 'core_boundary_ledger\n' + note, 1)
ledger.write_text(text)

workflow = Path('.github/workflows/native-type-check.yml')
text = workflow.read_text()
old = next(line for line in text.splitlines(keepends=True) if line.strip().startswith('cargo test --manifest-path rust/Cargo.toml --locked --lib solver_unknown_reasoning::tests::'))
assert text.count(old) == 1
indent = old[:len(old) - len(old.lstrip())]
text = text.replace(old, old + indent + 'cargo test --manifest-path rust/Cargo.toml --locked --lib solver_helpers::code::javascript_program_tests:: -- --test-threads=1 || regression_status=$?\n' + indent + 'cargo test --manifest-path rust/Cargo.toml --locked --lib rule_interpreter::parser::reference_list_tests:: -- --test-threads=1 || regression_status=$?\n')
text = text.replace('name: Verify native unresolved-language source binding\n', 'name: Verify native source binding and canonical operand readers\n')
workflow.write_text(text)
print('Updated two measured handler budgets and registered both native library regressions without changing job budgets.')
