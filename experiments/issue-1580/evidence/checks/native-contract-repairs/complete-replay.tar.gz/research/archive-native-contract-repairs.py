from pathlib import Path
import gzip, hashlib, json, subprocess, tarfile

root = Path.cwd()
scratch = Path('/tmp/issue-1580-research')
destination = root / 'experiments/issue-1580/evidence/checks/native-contract-repairs'
destination.mkdir(exist_ok=False)
paths = {}
for folder in ['registration-head-ci', 'registration-native-job', 'native-seed-focused', 'native-contract-checks-final']:
    for file in sorted((scratch / folder).rglob('*')):
        if file.is_file():
            paths[str(file.relative_to(scratch))] = file
patterns = ['registration-*-complete.log', 'registration-*-qualification.json',
            'native-contract-witness*', 'native-seed-regression*.log']
for pattern in patterns:
    for file in scratch.glob(pattern):
        if file.is_file():
            paths['research/' + file.name] = file
names = [
    'registration-terminal-summary.json', 'registration-native-failure-contexts.log',
    'registration-reasoning-1-failure-summary.log', 'registration-reasoning-2-failure-summary.json',
    'registration-layered-failure-summary.log', 'native-terminal-qualification.log',
    'native-extractor-hosted-qualification.log', 'native-seed-complete-semantic-comparison-final.log',
    'canonical-complete-data.log', 'native-batch-precommit-format.log',
    'native-batch-gate-failures.log', 'native-library-lane-regression.log',
    'native-budget-and-generated-status-final.log', 'native-final-lane-review.log',
    'repair-native-batch-bookkeeping.py', 'repair-native-worker-budget.py',
    'register-native-library-lane-test.py', 'archive-native-contract-repairs.py',
    'latest-issue-1580.json', 'latest-issue-comments.json', 'latest-pr-conversation.json',
    'latest-pr-inline.json', 'latest-pr-reviews.json', 'latest-feedback-readable.json',
]
for name in names:
    paths['research/' + name] = scratch / name
for name in ['check-minimal-core-boundary-js-twin', 'check-minimal-core-boundary',
             'check-notation', 'check-package-self-containment',
             'check-worker-line-budget-js-twin', 'check-worker-line-budget']:
    paths['gate-failures/' + name + '.log'] = root / 'experiments/formal_ai_subagent/sandboxes/gates' / (name + '.log')
archive = destination / 'complete-replay.tar.gz'
payloads = []
with tarfile.open(archive, 'w:gz', compresslevel=1) as tar:
    for name, file in sorted(paths.items()):
        raw = file.read_bytes()
        payloads.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
        tar.add(file, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    for row in payloads:
        raw = tar.extractfile(row['path']).read()
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
(destination / 'payloads.json.gz').write_bytes(gzip.compress((json.dumps(payloads, indent=2) + '\n').encode(), mtime=0))
manifest = {
    'publishedHead': 'e6943875bb39f1d7edee84fa716d7fbcffee96c4',
    'localRepairsHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'publishedCohort': {'terminal': 33, 'success': 30, 'failure': 2, 'explicitSkip': 1},
    'initialCompleteLocalGates': {'pass': 83, 'failure': 6, 'hostedOnlySkip': 54,
                                 'sourceMutatedDuringRun': True},
    'focusedJavascriptCasesPassed': 184,
    'canonicalDataFilesParsed': 4329,
    'nativeLocalExecution': False,
    'nextHeadHostedQualification': 'pending',
    'independentAuthorshipCredit': 0,
    'broaderIssueAcceptance': 'unfinished',
    'payloadCount': len(payloads),
    'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'roundTripVerified': True,
}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'payloadCount': len(payloads), 'archiveSha256': manifest['archiveSha256'],
                  'archiveBytes': archive.stat().st_size}), flush=True)
