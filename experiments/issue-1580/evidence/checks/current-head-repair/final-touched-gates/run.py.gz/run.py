from pathlib import Path
import subprocess,os,json,time,resource,shutil
root=Path('/tmp/gh-issue-solver-1794900398048');base=Path('/tmp/issue-1580-research/final-repair-touched-gates')
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
start=time.monotonic()
with (base/'aggregate.log').open('wb') as output:
 p=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size-js-twin,check-file-size,lint-shell-scripts,evidence-check#1,release#2'],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
rows=[];logs=base/'gates';logs.mkdir(exist_ok=True)
for name in 'check-abbreviations,check-file-size-js-twin,check-file-size,lint-shell-scripts,evidence-check#1,release#2'.split(','):
 source=root/'experiments/formal_ai_subagent/sandboxes/gates'/(name+'.log')
 shutil.copyfile(source,logs/source.name)
(base/'result.json').write_text(json.dumps({'status':p.returncode,'seconds':round(time.monotonic()-start,3),'childrenPeakRssKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss},indent=2)+'\n')
