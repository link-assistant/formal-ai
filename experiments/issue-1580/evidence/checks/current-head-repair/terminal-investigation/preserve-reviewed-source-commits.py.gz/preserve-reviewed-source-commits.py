from pathlib import Path
import subprocess, json, hashlib, datetime
root=Path('/tmp/gh-issue-solver-1794900398048')
base=Path('/tmp/issue-1580-research/current-head-repair')
def command(name,args):
    result=subprocess.run(args,cwd=root,capture_output=True)
    (base/(name+'.stdout')).write_bytes(result.stdout)
    (base/(name+'.stderr')).write_bytes(result.stderr)
    if result.returncode:raise SystemExit(name+' failed: '+str(result.returncode))
    return result.stdout.decode().strip()
assert command('branch-before-source-commits',['git','branch','--show-current'])=='issue-1580-8d61a32a61e1'
command('fresh-main-fetch',['git','fetch','origin','main'])
main=command('fresh-main-identity',['git','rev-parse','origin/main'])
ancestor=subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],cwd=root).returncode
if ancestor:raise SystemExit('Fresh main is not an ancestor; merge and reverify before source commits')
first=['.github/workflows/layered-ci.yml','rust/tests/integration/with_formal_ai/fixture_env.rs','rust/tests/unit/ci-cd/workflow_release.rs','rust/tests/web/ci-fast-critical-profile.test.mjs','rust/tests/web/default-branch-build-policy.test.mjs','rust/tests/web/fast-pull-request-production-profile.test.mjs','experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8']
second=['scripts/check-secrets.sh','scripts/check-secrets-files.mjs','scripts/lib/compressed-secrets.mjs','experiments/issue-1580/compressed-secrets.test.mjs','experiments/issue-1580/probe-compressed-secrets.mjs','experiments/issue-1580/probe-secretlint-profiler.mjs','rust/tests/web/bounded-subprocess-boundaries.test.mjs','changelog.d/20261120_141000_issue_1580_archive_secrets_and_ci.md']
identities=[{'file':path,'sha256':hashlib.sha256((root/path).read_bytes()).hexdigest()}for path in first+second]
(base/'reviewed-source-identities.json').write_text(json.dumps({'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main':main,'files':identities,'autonomousAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
command('source-final-whitespace',['git','diff','--check'])
command('source-final-staged-whitespace',['git','diff','--cached','--check'])
commits=[]
for name,message,paths in [('current-head-ci-repair','Repair sparse fixture acquisition and current CI contracts',first),('compressed-secret-scan','Scan compressed evidence and reject incomplete secret inventories',second)]:
    command(name+'-stage',['git','add','--',*paths])
    command(name+'-commit',['git','commit','--only','-m',message,'--',*paths])
    commits.append({'sha':command(name+'-identity',['git','rev-parse','HEAD']),'message':message})
(base/'source-commits.json').write_text(json.dumps(commits,indent=2)+'\n')
print(json.dumps({'commits':commits,'defaultBranchAncestor':main,'pushed':False,'fullIssueComplete':False}),flush=True)
