from pathlib import Path
import subprocess, os, json
root=Path('/tmp/gh-issue-solver-1794900398048')
p=root/'rust/tests/web/bounded-subprocess-boundaries.test.mjs'
assert 'secret scanner refuses a failed or partial Git inventory' not in p.read_text()
with p.open('a') as f:
    f.write('''

test('secret scanner refuses a failed or partial Git inventory before scanning', {timeout: 30000}, async t => {
  const os = await import('node:os');
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'secret-inventory-'));
  t.after(() => fs.rmSync(directory, {recursive: true, force: true}));
  const receipt = path.join(directory, 'scanner-called');
  fs.writeFileSync(path.join(directory, 'git'), `#!${process.execPath}
const command=process.argv[2],mode=process.env.SECRET_INVENTORY_CASE;
if(command==='rev-parse'||command==='merge-base'){console.log('fixture-commit');process.exit(0);}
if(command==='diff'||command==='ls-files'){
  if(mode==='empty')process.exit(0);
  process.stdout.write('partial inventory.txt'+String.fromCharCode(0));
  if(command==='diff'||mode==='all')process.exit(17);
  process.exit(0);
}
process.exit(18);
`, {mode: 0o755});
  fs.writeFileSync(path.join(directory, 'npx'), `#!${process.execPath}
require('node:fs').writeFileSync(process.env.SECRET_INVENTORY_RECEIPT,'called');
`, {mode: 0o755});
  for (const mode of ['all', 'uncommitted', 'base', 'empty']) {
    fs.rmSync(receipt, {force: true});
    const result = await boundedCommand('bash', [path.join(root, 'scripts/check-secrets.sh'),
      ...(['all', 'empty'].includes(mode) ? ['--all'] : [])], {
      cwd: root, timeout: 5000, maxBuffer: 65536,
      env: {...process.env, PATH: `${directory}${path.delimiter}${process.env.PATH}`,
        BASE_REF: mode === 'base' ? 'main' : '', SECRET_INVENTORY_CASE: mode,
        SECRET_INVENTORY_RECEIPT: receipt},
    });
    assert.equal(result.error, undefined, mode);
    assert.equal(result.cleanup_complete, true, mode);
    assert.equal(result.status === 0, mode === 'empty', mode+' must preserve inventory failure');
    assert.equal(fs.existsSync(receipt), false, mode+' must not scan an incomplete inventory');
    if (mode === 'empty') assert.match(result.stdout.toString(), /No files to scan/u);
    else assert.doesNotMatch(result.stdout.toString(), /No secrets found/u);
  }
});
''')
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
base=Path('/tmp/issue-1580-research/current-head-repair')
with (base/'secret-inventory-before.stdout').open('wb') as out, (base/'secret-inventory-before.stderr').open('wb') as err:
    result=subprocess.run(['timeout','600','node','--test','--test-concurrency=1','--test-name-pattern','secret scanner refuses a failed or partial Git inventory','rust/tests/web/bounded-subprocess-boundaries.test.mjs'],cwd=root,env=env,stdout=out,stderr=err)
(base/'secret-inventory-before.json').write_text(json.dumps({'status':result.returncode,'expectedFailure':True})+'\n')
print('Before inventory repair status:',result.returncode,flush=True)
if result.returncode==0:raise SystemExit('Expected regression did not fail')
