from pathlib import Path
import subprocess, shutil, json, hashlib, os, datetime

root=Path('/tmp/gh-issue-solver-1794900398048')
base=Path('/tmp/issue-1580-research/current-repair-gates')
saved=base/'first-complete-round'
saved.mkdir(exist_ok=True)
for name in ('aggregate.log','result.json','run.py','supervisor.log'):
    shutil.copyfile(base/name,saved/name)
logs=saved/'gates';logs.mkdir(exist_ok=True)
for source in (root/'experiments/formal_ai_subagent/sandboxes/gates').glob('*.log'):
    shutil.copyfile(source,logs/source.name)
identities=[]
for source in sorted(saved.rglob('*')):
    if source.is_file() and source.name!='identities.json':
        raw=source.read_bytes()
        identities.append({'file':str(source.relative_to(saved)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
(saved/'identities.json').write_text(json.dumps(identities,indent=2)+'\n')
print('Preserved complete first gate round:',len(identities),'files',flush=True)
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
with (base/'abbreviations-after-archive-rename.log').open('wb') as output:
    p=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations'],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
print('Archive filename correction gate:',p.returncode,flush=True)
(base/'abbreviations-after-archive-rename.json').write_text(json.dumps({'status':p.returncode,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
if p.returncode:raise SystemExit(p.returncode)
for helper in ('collect-current-completed-native-jobs.py','collect-running-pipeline-status.py'):
    with (Path('/tmp/issue-1580-research')/(helper+'.log')).open('wb') as output:
        p=subprocess.run(['python3',str(Path('/tmp/issue-1580-research')/helper)],cwd=root,stdout=output,stderr=subprocess.STDOUT)
    print(helper,p.returncode,flush=True)
    if p.returncode:raise SystemExit(p.returncode)
