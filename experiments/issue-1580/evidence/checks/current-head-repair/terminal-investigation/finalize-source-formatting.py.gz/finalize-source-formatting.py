from pathlib import Path
import shutil, subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');base=Path('/tmp/issue-1580-research/current-head-repair')
for name in ('source-final-staged-whitespace.stdout','source-final-staged-whitespace.stderr'):
    source=base/name
    shutil.copyfile(source,base/('first-'+name))
shutil.copyfile('/tmp/issue-1580-research/preserve-reviewed-source-commits.log',base/'first-source-commit-preflight.log')
p=root/'scripts/lib/compressed-secrets.mjs';p.write_text(p.read_text().rstrip('\n')+'\n')
p=root/'changelog.d/20261120_141000_issue_1580_archive_secrets_and_ci.md'
text=p.read_text();text=text.replace('Reject malformed archives and disable unnecessary API profiling as the upstream CLI does.','Reject malformed archives and incomplete Git inventories; disable unnecessary API profiling as the upstream CLI does.')
p.write_text(text)
subprocess.run(['git','add','--','scripts/lib/compressed-secrets.mjs','changelog.d/20261120_141000_issue_1580_archive_secrets_and_ci.md'],cwd=root,check=True)
subprocess.run(['python3','/tmp/issue-1580-research/preserve-reviewed-source-commits.py'],cwd=root,check=True)
