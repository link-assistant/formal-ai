from pathlib import Path
import subprocess, json, datetime
root=Path('/tmp/gh-issue-solver-1794900398048');base=Path('/tmp/issue-1580-research/current-head-repair')
for helper in ('collect-current-completed-native-jobs.py','collect-running-pipeline-status.py'):
    target=base/(datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+helper+'.log')
    with target.open('wb') as out:
        p=subprocess.run(['python3','/tmp/issue-1580-research/'+helper],cwd=root,stdout=out,stderr=subprocess.STDOUT)
    print(target.name,p.returncode,flush=True)
    print(target.read_text(),flush=True)
    if p.returncode:raise SystemExit(p.returncode)
name=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-exact-head-runs'
p=subprocess.run(['gh','api','repos/link-assistant/formal-ai/actions/runs?branch=issue-1580-8d61a32a61e1&head_sha=8c712eb980e777b9fe16beaca4d9d78d649be2bb&per_page=100','--paginate'],cwd=root,capture_output=True)
(base/(name+'.stdout')).write_bytes(p.stdout);(base/(name+'.stderr')).write_bytes(p.stderr)
if p.returncode:raise SystemExit(p.returncode)
d=json.loads(p.stdout)
for run in d['workflow_runs']:
    print(run['id'],run['name'],run['status'],run['conclusion'],run['created_at'],run['head_sha'],flush=True)
print('total',d['total_count'],len(d['workflow_runs']),flush=True)
