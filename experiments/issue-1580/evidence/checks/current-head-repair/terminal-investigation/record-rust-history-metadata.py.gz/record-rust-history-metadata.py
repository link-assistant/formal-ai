from pathlib import Path
import re,json,gzip,hashlib,datetime
root=Path('/tmp/gh-issue-solver-1794900398048');base=Path('/tmp/issue-1580-research')
log=base/'rust-history-metadata.read.txt';rows={};current=None
for line in log.read_text().splitlines():
    match=re.fullmatch(r'FILE (\S+) LINES (\d+) SHA256 ([0-9a-f]{64})',line)
    if match:
        current=match[1];rows[current]={'lines':int(match[2]),'sha256':match[3],'numbered':{}};continue
    match=re.fullmatch(r'(\d+): (.*)',line)
    if match and current:rows[current]['numbered'][int(match[1])]=match[2]
assert len(rows)==28
target=root/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json';data=json.loads(target.read_text())
assert (data['fullyReadFiles'],data['fullyReadSourceLines'])==(253,34829)
known={row['path']for row in data['files']}
for path,row in rows.items():
    raw=(base/'templates/rust-complete'/path).read_bytes();lines=raw.decode().splitlines()
    assert path not in known and hashlib.sha256(raw).hexdigest()==row['sha256']
    assert len(lines)==row['lines'] and sorted(row['numbered'].items())==list(enumerate(lines,1))
    data['files'].append({'path':path,'lines':len(lines),'sha256':row['sha256'],'readLogs':[log.name+'.gz'],'literalReadRanges':[[1,len(lines)]],'literalReadLines':len(lines),'literalSourceFullyRead':True,'formalAiPracticeImplementationVerified':False})
archive=root/'experiments/issue-1580/evidence/checks/rust-source-review'/(log.name+'.gz');assert not archive.exists()
raw=log.read_bytes();packed=gzip.compress(raw,mtime=0);archive.write_bytes(packed)
manifest=root/data['readLogManifest'];records=json.loads(manifest.read_text());records.append({'file':archive.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()});manifest.write_text(json.dumps(records,indent=2)+'\n')
data['files'].sort(key=lambda row:row['path']);data['fullyReadFiles']=len(data['files']);data['fullyReadSourceLines']=sum(row['literalReadLines']for row in data['files']);data['observedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
data['practiceDecisions'].append({'practice':'Historical artifact extraction, bounded BuildKit recovery and scoped audit evidence','templateEvidence':list(rows),'assessment':'All 28 complete historical metadata texts are read and identity-verified. The archived upstream artifact report traces DEP0005 to the old extraction chain and requires strict deprecation plus digest-preserving raw transport; Formal AI now has the owned transport and three-OS hosted adapter proof, while all 97 later consumer paths and actual production effects still need their appropriate qualification. The archived Buildx pull retry change and search results establish historical context, not a current immutable BuildKit identity or full recovery proof. Audit scopes are 53, 39 and 16 dependencies; the latter two omit database commit/update identity, so their clean results are not current security/freshness proof. Empty searches, review arrays and a bare clean zizmor array establish no producer coverage. Historical draft metadata and documentation-release separation are not final publication evidence. No new current template defect is inferred from these historical records.','status':'literal-history-reviewed-broader-runtime-and-identity-open','formalAiPaths':['.github/actions/download-artifact/action.yml','scripts/github-artifact.mjs','.github/actions/setup-buildx-resilient/action.yml','scripts/check-cargo-audit.sh','.github/workflows/release.yml'],'verification':None})
assert (data['fullyReadFiles'],data['fullyReadSourceLines'])==(281,34857)
target.write_text(json.dumps(data,indent=2)+'\n')
with (root/'experiments/issue-1580/work-plan.md').open('a') as file:
    file.write('\n- Twenty-eight further complete Rust historical metadata texts are read with exact source identities (281/373 files, 34,857 lines; 92 remain). Artifact/BuildKit upstream history, scoped audits, empty reports and draft-release metadata earn no additional current runtime or immutable-tool credit.\n')
print('Rust literal review:',data['fullyReadFiles'],'/',data['treeBlobs'],'files;',data['fullyReadSourceLines'],'lines. Full acceptance remains open.',flush=True)
