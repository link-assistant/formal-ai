from pathlib import Path
import subprocess,json,gzip,hashlib,os,datetime
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
ledger=root/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json';data=json.loads(ledger.read_text())
for row in data['practiceDecisions'][-2:]:
    row['formalAiPaths']=[{'scripts/github-artifact.mjs':'scripts/extract-artifacts.py','scripts/check-cargo-audit.sh':'scripts/check-rust-dependencies.sh'}.get(path,path)for path in row['formalAiPaths']]
    assert all((root/path).exists()for path in row['formalAiPaths'])
ledger.write_text(json.dumps(data,indent=2)+'\n')
destination=root/'experiments/issue-1580/evidence/checks/current-head-repair/local-gate-round'
destination.mkdir(exist_ok=False);records=[]
first=scratch/'current-repair-gates/first-complete-round'
for source in sorted(first.rglob('*')):
    if not source.is_file():continue
    relative=str(source.relative_to(first)).replace('check-tests-as-docs','check-tests-as-documentation')
    raw=source.read_bytes();packed=gzip.compress(raw,mtime=0);target=destination/(relative+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(packed)
    records.append({'file':str(target.relative_to(destination)),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw)})
(destination/'records.json').write_text('[\n'+',\n'.join(json.dumps(row,separators=(',',':'))for row in records)+'\n]\n')
p=root/'docs/case-studies/issue-1580/current-head-repair-checkpoint.md'
with p.open('a') as f:
    f.write('\nA separate negative control proves that mapfile discarded a failed Git producer status and the scanner reported clean after receiving a partial inventory. The shell now waits for the producer, stops on either producer/filter failure and scans only complete inventories. The full subprocess suite verifies all-files, base-diff and uncommitted failures before scanner invocation, plus a valid empty selection. ShellCheck and syntax checks pass. The original failure is retained.\n\nThe complete first 140-entry gate run finishes with 86 passes, 53 explicit native/context exclusions and one evidence-filename failure in 558.641 seconds. Its complete aggregate and 87 detailed gate logs are preserved before any overwrite. Renaming only six archival filenames fixes the unchanged abbreviation gate; a separate recheck passes. This is a failed full run followed by a passing focused correction, rather than a claimed wholly green first run. Final touched gates and exact new-head hosted verification remain pending.\n')
with (root/'experiments/issue-1580/work-plan.md').open('a') as f:
    f.write('\n- The complete local run finishes: 86 passes / 53 explicit exclusions / one archive-filename failure, 558.641 seconds. All 87 detailed logs and the aggregate are preserved. The unchanged abbreviation gate passes after six path-only renames. A further real shell regression reproduces partial Git inventory being accepted as clean; all three selection failures and the valid-empty control pass after waiting for the actual producer. Full subprocess suite and ShellCheck pass. Repairs are preserved in fd5a9bd9 and 231d7af1; no push has run. Final touched gates, completed old-head CI collection and new-head hosted verification remain pending.\n')

# Reuse the maintained investigation's existing exact-head collector; it is read-only.
publication=scratch/'current-repair-publication';publication.mkdir(exist_ok=False)
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/issue-1580-8d61a32a61e1'],cwd=root,text=True).split()[0]
assert remote=='8c712eb980e777b9fe16beaca4d9d78d649be2bb'
(publication/'outcome.json').write_text(json.dumps({'complete':True,'pushExecuted':True,'head':remote,'scope':'previous published head; no new push'})+'\n')
source=(scratch/'collect-optional-context-ci.py').read_text()
source=source.replace('optional-context-publication','current-repair-publication').replace('optional-context-ci','current-repair-head-ci')
source=source.replace('range(360)','range(60)')
worker=scratch/'collect-current-repair-head-ci.py';assert not worker.exists();worker.write_text(source)
result=subprocess.run(['python3',str(worker)],cwd=root,capture_output=True)
(scratch/'launch-current-repair-collector.stdout').write_bytes(result.stdout);(scratch/'launch-current-repair-collector.stderr').write_bytes(result.stderr)
assert result.returncode==0,result.stderr.decode();print(result.stdout.decode(),flush=True)
g=scratch/'final-repair-touched-gates';g.mkdir(exist_ok=False)
gate_names='check-abbreviations,check-file-size-js-twin,check-file-size,lint-shell-scripts,evidence-check#1,release#2'
worker=g/'run.py'
worker.write_text('''from pathlib import Path
import subprocess,os,json,time,resource,shutil
root=Path('/tmp/gh-issue-solver-1794900398048');base=Path('/tmp/issue-1580-research/final-repair-touched-gates')
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
start=time.monotonic()
with (base/'aggregate.log').open('wb') as output:
 p=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--only',GATE_NAMES],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
rows=[];logs=base/'gates';logs.mkdir(exist_ok=True)
for name in GATE_NAMES.split(','):
 source=root/'experiments/formal_ai_subagent/sandboxes/gates'/(name+'.log')
 shutil.copyfile(source,logs/source.name)
(base/'result.json').write_text(json.dumps({'status':p.returncode,'seconds':round(time.monotonic()-start,3),'childrenPeakRssKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss},indent=2)+'\\n')
'''.replace('GATE_NAMES',repr(gate_names)))
paths=['docs/case-studies/issue-1580','experiments/issue-1580/evidence/checks/current-head-repair','experiments/issue-1580/evidence/checks/rust-source-review','experiments/issue-1580/work-plan.md']
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
with (g/'supervisor.log').open('wb') as out:
    child=subprocess.Popen(['python3',str(worker)],cwd=root,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
(g/'pid').write_text(str(child.pid)+'\n')
print('Final touched gate worker:',child.pid,'; archived first-round files:',len(records),flush=True)
