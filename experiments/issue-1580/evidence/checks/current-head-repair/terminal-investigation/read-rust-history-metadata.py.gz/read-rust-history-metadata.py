from pathlib import Path
import hashlib, json
root=Path('/tmp/gh-issue-solver-1794900398048');source=Path('/tmp/issue-1580-research/templates/rust-complete')
directory='dev/log/issues/247/pulls/248/'
names=['cargo-audit.json','create-changelog-fragment-audit.json','create-github-release-audit.json','create-pr-action-ref.json','sub-issues.json','zizmor.json','pr-review-comments.json','pr-reviews.json','branch-runs-before.json','buildx-retry-pr.json','buildx-retry-search.json','artifact-fix-upstream.json','artifact-upstream-search.json','artifact-upstream.json','audit-upstream-search.json','codeql-upstream-search.json','buildx-upstream-search.json','pr-initial.json']
paths=[directory+name for name in names]+['docs/case-studies/issue-19/pr-114-data/pr-review-comments.json','docs/case-studies/issue-19/pr-114-data/pr-reviews.json','docs/case-studies/issue-38/raw-data/pr-39-conversation-comments.json','docs/case-studies/issue-38/raw-data/pr-39-review-comments.json','docs/case-studies/issue-38/raw-data/pr-39-reviews.json','docs/case-studies/issue-38/raw-data/pr-39.json','docs/case-studies/issue-38/raw-data/pr-branch-runs.json','docs/case-studies/issue-38/raw-data/js-template-issue-search.json','docs/case-studies/issue-38/raw-data/rust-template-issue-search.json','docs/case-studies/issue-52/raw-data/issue-52-comments.json']
known={row['path']for row in json.loads((root/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json').read_text())['files']}
identities={row['path']:row for row in json.loads((root/'experiments/issue-1580/evidence/checks/rust-template-first-gate/pinned-file-identities.json').read_text())}
out=[]
for path in paths:
    assert path not in known
    raw=(source/path).read_bytes();digest=hashlib.sha256(raw).hexdigest();assert digest==identities[path]['sha256']
    lines=raw.decode().splitlines();out.append(f'FILE {path} LINES {len(lines)} SHA256 {digest}')
    out.extend(f'{index}: {line}'for index,line in enumerate(lines,1))
target=Path('/tmp/issue-1580-research/rust-history-metadata.read.txt');target.write_text('\n'.join(out)+'\n')
print('Read log prepared with complete numbered bytes:',len(paths),'files',sum(len((source/path).read_text().splitlines())for path in paths),'source lines',target.stat().st_size,'bytes',flush=True)
