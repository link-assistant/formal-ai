from pathlib import Path
import subprocess, os, json, time
root=Path('/tmp/gh-issue-solver-1794900398048')
p=root/'scripts/check-secrets.sh'
text=p.read_text()
old="""exclude() {
  grep -zv -e '^docs/case-studies/.*\\.log$' -e '^dev/log/.*ci-logs/.*\\.log$' || true
}
"""
new="""exclude() {
  local status=0
  grep -zv -e '^docs/case-studies/.*\\.log$' -e '^dev/log/.*ci-logs/.*\\.log$' || status=$?
  # grep's no-match status means a valid empty selection; actual errors fail.
  [ "$status" -le 1 ]
}

# mapfile alone loses the exit status of a process substitution. Wait for the
# producer before accepting either an empty or a partially emitted inventory.
read_inventory() {
  local descriptor producer
  exec {descriptor}< <("$@" | exclude)
  producer=$!
  mapfile -d '' files <&"$descriptor"
  exec {descriptor}<&-
  if ! wait "$producer"; then
    echo 'Unable to collect complete scanner inventory; no scan performed.' >&2
    return 1
  fi
}

uncommitted_files() {
  git diff --name-only --diff-filter=ACMRT -z HEAD &&
    git ls-files -z --others --exclude-standard
}
"""
assert text.count(old)==1
text=text.replace(old,new)
old="  mapfile -d '' files < <(git ls-files -z | exclude)"
assert text.count(old)==1;text=text.replace(old,'  read_inventory git ls-files -z')
old="  mapfile -d '' files < <(git diff --name-only --diff-filter=ACMRT -z \"$merge_base\" HEAD | exclude)"
assert text.count(old)==1;text=text.replace(old,'  read_inventory git diff --name-only --diff-filter=ACMRT -z "$merge_base" HEAD')
old="""  mapfile -d '' files < <(
    { git diff --name-only --diff-filter=ACMRT -z HEAD; git ls-files -z --others --exclude-standard; } | exclude
  )"""
assert text.count(old)==1;text=text.replace(old,'  read_inventory uncommitted_files')
p.write_text(text)
base=Path('/tmp/issue-1580-research/current-head-repair')
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
results=[]
commands=[('secret-inventory-after',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/bounded-subprocess-boundaries.test.mjs']),('secret-inventory-shellcheck',['shellcheck','scripts/check-secrets.sh']),('secret-inventory-bash-syntax',['bash','-n','scripts/check-secrets.sh'])]
for name,command in commands:
    start=time.monotonic()
    with (base/(name+'.stdout')).open('wb') as out,(base/(name+'.stderr')).open('wb') as err:
        result=subprocess.run(command,cwd=root,env=env,stdout=out,stderr=err)
    results.append({'name':name,'status':result.returncode,'seconds':round(time.monotonic()-start,3)})
    print(results[-1],flush=True)
(base/'secret-inventory-repair-results.json').write_text(json.dumps(results,indent=2)+'\n')
if any(row['status'] for row in results):raise SystemExit(1)
