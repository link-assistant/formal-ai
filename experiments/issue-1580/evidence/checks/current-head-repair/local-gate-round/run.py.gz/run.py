from pathlib import Path
import subprocess,os,json,time,resource
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/current-repair-gates');env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
start=time.monotonic()
with (s/'aggregate.log').open('wb') as output:
 p=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs'],cwd=r,env=env,stdout=output,stderr=subprocess.STDOUT)
(s/'result.json').write_text(json.dumps({'status':p.returncode,'seconds':round(time.monotonic()-start,3),'childrenPeakRssKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss},indent=2)+'\n')
