from pathlib import Path
import subprocess,json,hashlib,os
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/current-head-repair');env=dict(os.environ);env.pop('NODE_OPTIONS',None)
for name,args in [('native-compile-original',['gh','api','--allow-escape-sequences','repos/link-assistant/formal-ai/actions/jobs/136317612472/logs']),('original-rust-reports',['gh','run','download','44745009703','--repo','link-assistant/formal-ai','--name','codeql-results-rust-codeql-readonly','--dir',str(s/'original-rust-reports')]),('fast-profile-complete',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs'])]:
 p=subprocess.run(args,cwd=r,env=env,capture_output=True)
 (s/(name+'.stdout')).write_bytes(p.stdout);(s/(name+'.stderr')).write_bytes(p.stderr);print(name,p.returncode,flush=True)
 if name=='original-rust-reports' and p.returncode==0:
  for file in (s/'original-rust-reports').glob('*.sarif'):
   data=json.loads(file.read_bytes());report={'file':file.name,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'runs':[]}
   for run in data['runs']:
    report['runs'].append({'results':run.get('results',[]),'invocationSuccess':[i.get('executionSuccessful') for i in run.get('invocations',[])]})
   (s/(file.name+'.findings.json')).write_text(json.dumps(report,indent=2)+'\n')
