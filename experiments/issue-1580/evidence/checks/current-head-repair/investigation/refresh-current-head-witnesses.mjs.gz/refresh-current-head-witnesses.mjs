import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {deserialize} from 'node:v8';
import {execFileSync} from 'node:child_process';
import YAML from '/tmp/gh-issue-solver-1794900398048/node_modules/yaml/dist/index.js';
const out='/tmp/issue-1580-research/current-head-repair/';
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const file='.github/workflows/benchmark-corpus-gate.yml';
const old=YAML.parse(execFileSync('git',['show','f400d7ab2^:'+file],{encoding:'utf8'}));
const current=YAML.parse(readFileSync(file,'utf8'));
const reviewed=structuredClone(old.jobs['corpus-shard']);
const download=reviewed.steps.find(step=>step.name==='Download the corpus gate executable');
assert.equal(download.uses,'actions/download-artifact@v8');
assert.deepEqual(download.env,{NODE_OPTIONS:'--disable-warning=DEP0005'});
download.uses='./.github/actions/download-artifact';delete download.env;
assert.deepEqual(current.jobs['corpus-shard'],reviewed,'complete shard job may differ only by reviewed extraction transport');
assert.deepEqual(current.jobs['corpus-build'],old.jobs['corpus-build']);
const normalize=job=>JSON.stringify({...job,'runs-on':'ubuntu-latest'});
assert.equal(hash(normalize(old.jobs['corpus-shard'])),'d158657d57b95d845031893a4258b3f7ce2220031616c99583b07e57d28afdf2');
const newHash=hash(normalize(reviewed));
let test=readFileSync('rust/tests/web/ci-fast-critical-profile.test.mjs','utf8');
assert(test.includes('d158657d57b95d845031893a4258b3f7ce2220031616c99583b07e57d28afdf2'));
test=test.replace('// Issue #1571 pinned the runner image; that is the only change to either reviewed gate.',
  '// Reviewed changes: #1571 pins the runner; #1580 replaces only the shard download transport and removes its warning suppression.');
writeFileSync('rust/tests/web/ci-fast-critical-profile.test.mjs',test.replace('d158657d57b95d845031893a4258b3f7ce2220031616c99583b07e57d28afdf2',newHash));
const witness='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8';
const before=readFileSync(witness),readerHash=hash(readFileSync('scripts/lib/rust-specification-cases.mjs'));
execFileSync(process.execPath,['--max-old-space-size=256','rust/tests/web/rust-specification-unicode-identifiers.test.mjs',
  '--refresh-reviewed-baseline','--reviewed-reader-sha='+readerHash,'--previous-baseline-sha='+hash(before)],{stdio:['ignore','pipe','pipe'],maxBuffer:1024*1024});
const after=readFileSync(witness),left=deserialize(before),right=deserialize(after);
assert.deepEqual(left.sourceManifest,right.sourceManifest);
const beforeCargo=execFileSync('git',['show','2a22edff^:rust/Cargo.toml'],{encoding:'utf8'});
const afterCargo=readFileSync('rust/Cargo.toml','utf8');
assert.equal(beforeCargo.replace('web-capture = { version = "0.3.37"','web-capture = { version = "0.5.3"'),afterCargo);
const changes=[];let pairs=0;const seen=new WeakMap();
function walk(a,b,path='') {
  if(Object.is(a,b))return;
  assert.equal(typeof a,typeof b,path);
  if(a===null||b===null||typeof a!=='object') {
    assert(path.startsWith('/inventory/cases/')&&path.endsWith('/sha256'),path);
    assert.equal(a,hash(beforeCargo));assert.equal(b,hash(afterCargo));
    changes.push({path,before:a,after:b});return;
  }
  if(seen.get(a)?.has(b))return;
  if(!seen.has(a))seen.set(a,new WeakSet());seen.get(a).add(b);
  assert(++pairs<=200000);assert.equal(Object.getPrototypeOf(a),Object.getPrototypeOf(b));
  assert.deepEqual(Object.keys(a),Object.keys(b),path);
  for(const k of Object.keys(a))walk(a[k],b[k],path+'/'+k);
}
walk(left,right);assert(changes.length>0);
const report={beforeSha256:hash(before),afterSha256:hash(after),readerHash,pairs,changes,
  supported:right.inventory.cases.length,unsupported:right.inventory.unsupported.length,
  nativeSourceManifestUnchanged:true,corpusShard:{before:hash(normalize(old.jobs['corpus-shard'])),after:newHash,
  completeJobComparison:'only local download action selection and removal of DEP0005 suppression changed'},
  limitation:'complete source-witness comparison; no native execution'};
writeFileSync(out+'complete-witness-review.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
