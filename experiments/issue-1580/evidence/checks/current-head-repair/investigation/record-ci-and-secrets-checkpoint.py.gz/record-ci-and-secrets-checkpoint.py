from pathlib import Path
import subprocess,json,hashlib,gzip
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/current-head-repair')
plan=r/'experiments/issue-1580/work-plan.md'
with plan.open('a') as file:file.write('''

## 20 November: exact-head CI repair and compressed-evidence scanning

- [x] Collect Layered CI 44744820945 and explicit security producer 44745009703 for exact head 8c712eb9. Retain original terminal logs and Rust SARIF. Root causes: two excluded tracked fixture logs, the reviewed artifact-consumer witness, four manifest-only governed witness hashes, two stale native Pages-action selectors and an environment-variable-name assertion diagnostic.
- [x] Reproduce the sparse acquisition failure through real Git rules, add its regression and retain the two exact fixture inclusions. Compare all 7,022 governed object pairs: only four Cargo.toml fixture hashes change; 221 supported and 968 unsupported cases and the entire native source manifest remain intact. Compare the complete corpus job before updating its transport-only witness.
- [x] Preserve the native Pages trust, immutable artifact/source and 600,000 ms polling assertions against the actual owned action. Replace the unnecessary dynamic credential-name diagnostic with constant text while retaining credential-removal behavior. Formatting and translation currency pass; hosted native/CodeQL repair validation remains pending.
- [x] Reproduce the old pinned scanner accepting compressed synthetic credentials and corrupt gzip. Add bounded gzip/tar content and metadata inspection, sequential pinned API execution, NUL filename transport and masked output. Twelve focused groups, the existing subprocess entrypoint, all four real scanner controls and the production profile pass.
- [x] Preserve the first bounded audit's profiler-retention OOM. Follow the pinned upstream CLI's supported default-off profiler control; a finite real-engine probe retains 6,610 marks before and zero after. The repaired unchanged BASE_REF=main selection scans 25,802 files including 23,434 archives cleanly in 61.274 seconds, peak child RSS 324,392 KiB, with a 256 MiB JS heap. No archive is excluded to obtain the result.
- [x] Publish reproducible Pages adoption reports JavaScript #310 and Python #163 against immutable f8718c44 evidence. These reports establish no upstream repair or hosted Pages publication.
- [ ] Finish all current-head native jobs; download/review every failed stream and all actual diagnostics. Run and inspect the complete local gate inventory after these drafts, preserve fresh feedback and source identities, then batch all actionable repairs through the single push gate.
- [ ] Obtain exact new-head hosted native and CodeQL results; complete all broader original/template/runtime/publication/provenance requirements. Full issue completion remains false. Independently accepted reasoning remains 0/20; supplied work receives zero credit.
''')
(r/'changelog.d/20261120_141000_issue_1580_archive_secrets_and_ci.md').write_text('''## CI correctness and compressed evidence

- Inspect bounded gzip/tar contents and metadata with the pinned secret scanner, retaining masked output, exact file selection and sequential resource use. Reject malformed archives and disable unnecessary API profiling as the upstream CLI does.
- Acquire the two tracked component-test logs in the fast JavaScript lane, refresh only reviewed transport/manifest witnesses, and retain native Pages artifact/source and timeout assertions against the owned deployment action.
- Preserve credential-removal assertions with a fixed diagnostic that does not interpolate credential-related identifiers.
''')
# Record literal complete producer summaries; no source/fixture equality is native credit.
observations=[]
for path in sorted(s.glob('native-*.stdout')):
 lines=path.read_text(errors='replace').splitlines()
 for index,line in enumerate(lines,1):
  if any(marker in line for marker in ['test result:', 'component_boundaries::', 'DEP0005', 'DEP0040', 'warning:', 'error:']):
   observations.append({'file':path.name,'line':index,'text':line})
(s/'native-observations.json').write_text(json.dumps(observations,indent=2)+'\n')
for name,args in [('draft-source-secrets',['bash','scripts/check-secrets.sh']),('gate-list',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--list'])]:
 p=subprocess.run(args,cwd=r,capture_output=True);(s/(name+'.stdout')).write_bytes(p.stdout);(s/(name+'.stderr')).write_bytes(p.stderr);print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
