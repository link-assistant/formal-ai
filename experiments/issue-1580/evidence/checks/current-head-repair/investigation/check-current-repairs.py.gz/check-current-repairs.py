from pathlib import Path
import subprocess,os,json,time
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/current-head-repair');env=dict(os.environ);env.pop('NODE_OPTIONS',None)
checks=[('compressed-secrets',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/compressed-secrets.test.mjs']),('compressed-secrets-real',['node','--max-old-space-size=128','experiments/issue-1580/probe-compressed-secrets.mjs'])]
checks += [(name,['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs']) for name in ['default-branch-build-policy','ci-fast-critical-profile','rust-specification-fixture-integrity','rust-specification-unicode-identifiers','bounded-subprocess-boundaries','fast-pull-request-production-profile']]
results=[]
for name,args in checks:
 start=time.monotonic();p=subprocess.run(args,cwd=r,env=env,capture_output=True)
 (s/(name+'-after.stdout')).write_bytes(p.stdout);(s/(name+'-after.stderr')).write_bytes(p.stderr)
 result={'name':name,'status':p.returncode,'seconds':round(time.monotonic()-start,3)};results.append(result)
 (s/'after-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(result),flush=True)
 if p.returncode:break
assert len(results)==len(checks) and all(x['status']==0 for x in results),'review retained failure output before continuing'
