from pathlib import Path
import subprocess,json,os
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/current-head-repair')
p=r/'rust/tests/web/default-branch-build-policy.test.mjs';text=p.read_text()
anchor="  for (const fixture of inputs.filter(path => path.startsWith('docs/'))) assert(readFileSync(fixture).length > 0, fixture);"
addition="""  // Check acquisition before reading fixtures: a complete local checkout hid this CI failure.
  const directory = mkdtempSync(join(tmpdir(), 'search-fixture-checkout-'));
  try {
    const rules = join(directory, 'rules');
    writeFileSync(rules, workflow('layered-ci.yml').jobs.js.steps.find(step => step.with?.['sparse-checkout']).with['sparse-checkout']);
    const excluded = ['docs/case-studies/unrelated/large.log', 'docs/case-studies/unrelated/large.gz'];
    const result = spawnSync('git', ['sparse-checkout', 'check-rules', '--no-cone', '--rules-file', rules, '-z'], {
      input: Buffer.from([...inputs, ...excluded].join('\\0') + '\\0'), timeout: 5000,
      maxBuffer: 1024 * 1024, encoding: 'utf8',
    });
    assert.equal(result.status, 0, result.stderr);
    assert.deepEqual(result.stdout.split('\\0').filter(Boolean), inputs, 'the hosted sparse checkout must acquire every consumed fixture');
  } finally { rmSync(directory, {recursive: true, force: true}); }
"""
assert text.count(anchor)==1;p.write_text(text.replace(anchor,addition+anchor))
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
args=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','--test-name-pattern=published search component','rust/tests/web/default-branch-build-policy.test.mjs']
before=subprocess.run(args,cwd=r,env=env,capture_output=True)
(s/'checkout-negative-before.stdout').write_bytes(before.stdout);(s/'checkout-negative-before.stderr').write_bytes(before.stderr)
assert before.returncode!=0,'new acquisition control must fail before checkout repair'
p=r/'.github/workflows/layered-ci.yml';text=p.read_text();anchor='            /docs/case-studies/issue-717/e2e-npm-ci.log\n'
assert text.count(anchor)==1
p.write_text(text.replace(anchor,anchor+'            /docs/case-studies/issue-896/self-hosting-authorship/agent-cli.log\n            /docs/case-studies/issue-896/self-hosting-authorship/formal-ai.log\n'))
print('Sparse acquisition regression fails before the two exact fixture inclusions.',flush=True)
