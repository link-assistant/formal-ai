from pathlib import Path
import subprocess,json,os
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/current-head-repair')
for name,args in [
 ('pipeline-state-1358',['gh','api','repos/link-assistant/formal-ai/actions/runs/44744821046']),
 ('pipeline-jobs-1358',['gh','api','repos/link-assistant/formal-ai/actions/runs/44744821046/jobs','--paginate']),
 ('checks-1358',['gh','pr','checks','1581','--repo','link-assistant/formal-ai','--json','name,state,link']),
]:
 p=subprocess.run(args,cwd=r,capture_output=True);(s/(name+'.stdout')).write_bytes(p.stdout);(s/(name+'.stderr')).write_bytes(p.stderr)
 print(name,p.returncode,flush=True)

def replace(file,old,new):
 p=r/file;text=p.read_text();assert text.count(old)==1,(file,old,text.count(old));p.write_text(text.replace(old,new))
replace('rust/tests/web/fast-pull-request-production-profile.test.mjs',
 '/docs/case-studies/issue-717/e2e-npm-ci.log\\n/docs/case-studies/issue-932/',
 '/docs/case-studies/issue-717/e2e-npm-ci.log\\n/docs/case-studies/issue-896/self-hosting-authorship/agent-cli.log\\n/docs/case-studies/issue-896/self-hosting-authorship/formal-ai.log\\n/docs/case-studies/issue-932/')
replace('rust/tests/unit/ci-cd/workflow_release.rs','assert!(deploy_demo.contains("actions/deploy-pages@v5"));',
 '''assert!(deploy_demo.contains("uses: ./.formal-ai-pages-protocol/.github/actions/deploy-pages"));
    assert!(deploy_demo.contains("ref: '${{ github.workflow_sha }}'"));
    assert!(deploy_demo.contains("artifact_id: ${{ needs.build-pages.outputs.artifact_id }}"));
    assert!(deploy_demo.contains("source_sha: ${{ needs.build-pages.outputs.pages_sha }}"));''')
replace('rust/tests/unit/ci-cd/workflow_release.rs','.split("actions/deploy-pages@v5")',
 '.split("uses: ./.formal-ai-pages-protocol/.github/actions/deploy-pages")')
replace('rust/tests/unit/ci-cd/workflow_release.rs',
 '/// `actions/deploy-pages` accepts at most a 600 000 ms wait. On `main` run',
 '/// The owned Pages protocol preserves the original 600 000 ms polling budget.\n/// With `actions/deploy-pages` on `main` run')
replace('rust/tests/unit/ci-cd/workflow_release.rs',
 '/// false positive. Pin the documented maximum rather than supplying the\n/// unsupported 1 200 000 ms value that the action silently clamps, and keep\n/// the job\'s own budget above it.',
 '/// false positive. Keep the explicit polling budget when selecting the owned\n/// artifact-bound protocol, and keep the job\'s own budget above it.')
replace('rust/tests/integration/with_formal_ai/fixture_env.rs',
 '"{key} must be cleared before a fake client can observe it"',
 '"client credentials and command overrides must be cleared before fake client execution"')

# Disable the profiler exactly as the pinned upstream CLI does; scan rules stay enabled.
replace('scripts/check-secrets-files.mjs',
 '// NUL transport keeps filenames out of npm\'s generated shell command/argument limits.',
 '''export async function createScanner(version,searchPath) {
  const module=scannerModule(version,searchPath);
  const profiler=createRequire(module).resolve('@secretlint/profiler');
  if(packageVersion(profiler,'@secretlint/profiler')!==version)throw Error('Pinned scanner profiler version mismatch');
  const {secretLintProfiler}=await import(pathToFileURL(profiler).href);
  // Match secretlint's CLI default. The API otherwise retains per-rule/file marks.
  secretLintProfiler.setEnabled(false);
  const {createEngine}=await import(module);
  return createEngine({cwd:process.cwd(),formatter:'stylish',color:false,maskSecrets:true});
}

// NUL transport keeps filenames out of npm's generated shell command/argument limits.''')
replace('scripts/check-secrets-files.mjs',
 '''    const {createEngine}=await import(scannerModule(version));
    const engine=await createEngine({cwd:process.cwd(),formatter:'stylish',color:false,maskSecrets:true});''',
 '''    const engine=await createScanner(version);''')
replace('experiments/issue-1580/compressed-secrets.test.mjs','{checkFiles,filenames,scannerModule}',
 '{checkFiles,filenames,scannerModule,createScanner}')
replace('experiments/issue-1580/compressed-secrets.test.mjs',
 "test('engine import is bound to the pinned CLI, API and preset versions',t=>{",
 "test('engine identity and default-off profiling retain masking and rule execution',async t=>{")
replace('experiments/issue-1580/compressed-secrets.test.mjs',
 "['secretlint','@secretlint/node','@secretlint/secretlint-rule-preset-recommend']",
 "['secretlint','@secretlint/node','@secretlint/profiler','@secretlint/secretlint-rule-preset-recommend']")
replace('experiments/issue-1580/compressed-secrets.test.mjs',
 "JSON.stringify({name,version:'13.0.5',main:'index.js'})",
 "JSON.stringify({name,version:'13.0.5',main:'index.js',type:'module'})")
replace('experiments/issue-1580/compressed-secrets.test.mjs',
 "  assert(scannerModule('13.0.5',bin).endsWith('/@secretlint/node/index.js'));",
 '''  writeFileSync(join(directory,'node_modules/@secretlint/profiler/index.js'),
    'export const secretLintProfiler={isEnabled:true,setEnabled(value){this.isEnabled=value;}};');
  writeFileSync(join(directory,'node_modules/@secretlint/node/index.js'),
    "import {secretLintProfiler} from '@secretlint/profiler';export const createEngine=config=>({config,profiling:secretLintProfiler.isEnabled});");
  assert(scannerModule('13.0.5',bin).endsWith('/@secretlint/node/index.js'));
  const scanner=await createScanner('13.0.5',bin);
  assert.equal(scanner.profiling,false);
  assert.deepEqual(scanner.config,{cwd:process.cwd(),formatter:'stylish',color:false,maskSecrets:true});
  const profilerManifest=join(directory,'node_modules/@secretlint/profiler/package.json');
  writeFileSync(profilerManifest,JSON.stringify({name:'@secretlint/profiler',version:'13.0.4',type:'module'}));
  await assert.rejects(()=>createScanner('13.0.5',bin),/profiler version mismatch/u);''')

(r/'experiments/issue-1580/probe-secretlint-profiler.mjs').write_text('''// Bounded real-engine probe: no credentials, 100 tiny inputs, no Rust build.
import assert from 'node:assert/strict';
import {performance} from 'node:perf_hooks';
import {createRequire} from 'node:module';
import {resolve} from 'node:path';
import {setImmediate} from 'node:timers/promises';
import {scannerModule,createScanner} from '../../scripts/check-secrets-files.mjs';
const baseline=process.argv.includes('--baseline');
const module=scannerModule('13.0.5');
const engine=baseline?await (await import(module)).createEngine({cwd:process.cwd(),maskSecrets:true}):await createScanner('13.0.5');
for(let index=0;index<100;index++) {
  const result=await engine.executeOnContent({content:'ordinary evidence\\n',filePath:resolve('profile-control.txt')});
  assert.equal(result.ok,true);
}
await setImmediate();
const {secretLintProfiler}=await import(createRequire(module).resolve('@secretlint/profiler'));
const marks=performance.getEntriesByType('mark').length;
console.log(JSON.stringify({inputs:100,baseline,profilerEnabled:secretLintProfiler.isEnabled,retainedMarks:marks}));
if(baseline)assert(marks>100);else assert.equal(marks,0);
''')
print('Drafted minimal workflow/security diagnostics repairs and pinned profiler initialization',flush=True)
