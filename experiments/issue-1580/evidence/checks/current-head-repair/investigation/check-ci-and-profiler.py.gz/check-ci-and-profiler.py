from pathlib import Path
import subprocess,os,json,time
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/current-head-repair')
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
commands=[
 ('compressed-secrets-profiler-unit',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/compressed-secrets.test.mjs']),
 ('fast-profile-repaired',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs']),
 ('bounded-subprocess-profiler',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/bounded-subprocess-boundaries.test.mjs']),
 ('compressed-real-profiler',['timeout','600','node','--max-old-space-size=256','experiments/issue-1580/probe-compressed-secrets.mjs']),
 ('real-profiler-baseline',['npx','--yes','-p','secretlint@13.0.5','-p','@secretlint/secretlint-rule-preset-recommend@13.0.5','node','--max-old-space-size=256','experiments/issue-1580/probe-secretlint-profiler.mjs','--baseline']),
 ('real-profiler-repaired',['npx','--yes','-p','secretlint@13.0.5','-p','@secretlint/secretlint-rule-preset-recommend@13.0.5','node','--max-old-space-size=256','experiments/issue-1580/probe-secretlint-profiler.mjs']),
 ('rustfmt-repaired',['rustfmt','--edition','2024','--config','skip_children=true','--check','rust/tests/unit/ci-cd/workflow_release.rs','rust/tests/integration/with_formal_ai/fixture_env.rs']),
 ('secret-shell-syntax',['bash','-n','scripts/check-secrets.sh']),
]
results=[]
for name,args in commands:
 start=time.monotonic();p=subprocess.run(args,cwd=r,env=env,capture_output=True)
 (s/(name+'.stdout')).write_bytes(p.stdout);(s/(name+'.stderr')).write_bytes(p.stderr)
 results.append({'name':name,'status':p.returncode,'seconds':round(time.monotonic()-start,3)})
 (s/'profiler-repair-results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,p.returncode,flush=True)
