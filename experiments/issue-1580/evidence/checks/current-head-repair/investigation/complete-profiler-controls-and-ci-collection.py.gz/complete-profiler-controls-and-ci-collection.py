from pathlib import Path
import subprocess,json,os
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/current-head-repair');env=dict(os.environ);env.pop('NODE_OPTIONS',None)
p=r/'experiments/issue-1580/probe-secretlint-profiler.mjs';text=p.read_text();old="createEngine({cwd:process.cwd(),maskSecrets:true})";assert text.count(old)==1
p.write_text(text.replace(old,"createEngine({cwd:process.cwd(),formatter:'stylish',color:false,maskSecrets:true})"))
p=r/'experiments/issue-1580/probe-compressed-secrets.mjs';text=p.read_text();old='try {assert.equal(result.signal,null);assert.equal(actual,expected,name);}'
assert text.count(old)==1;text=text.replace(old,"try {assert.equal(result.signal,null);assert.equal(actual,expected,name);assert(result.stdout.includes('Scanning 1 file(s)'));assert(!((result.stdout??'')+(result.stderr??'')).includes(token));}")
p.write_text(text)
commands=[
 ('real-profiler-baseline-corrected',['npx','--yes','-p','secretlint@13.0.5','-p','@secretlint/secretlint-rule-preset-recommend@13.0.5','node','--max-old-space-size=256','experiments/issue-1580/probe-secretlint-profiler.mjs','--baseline']),
 ('real-profiler-repaired-confirmed',['npx','--yes','-p','secretlint@13.0.5','-p','@secretlint/secretlint-rule-preset-recommend@13.0.5','node','--max-old-space-size=256','experiments/issue-1580/probe-secretlint-profiler.mjs']),
 ('compressed-real-masking-asserted',['timeout','600','node','--max-old-space-size=256','experiments/issue-1580/probe-compressed-secrets.mjs']),
 ('translator-projection-currency',['node','--max-old-space-size=256','scripts/translate-js-rust.mjs','--verify']),
 ('latest-run-list',['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','5','--json','databaseId,conclusion,createdAt,headSha,status,workflowName']),
 ('pipeline-jobs-1408',['gh','api','repos/link-assistant/formal-ai/actions/runs/44744821046/jobs','--paginate']),
 ('issue-comments-1408',['gh','api','repos/link-assistant/formal-ai/issues/1580/comments','--paginate']),
 ('pr-comments-1408',['gh','api','repos/link-assistant/formal-ai/issues/1581/comments','--paginate']),
 ('pr-review-comments-1408',['gh','api','repos/link-assistant/formal-ai/pulls/1581/comments','--paginate']),
 ('pr-reviews-1408',['gh','api','repos/link-assistant/formal-ai/pulls/1581/reviews','--paginate']),
]
results=[]
for name,args in commands:
 p=subprocess.run(args,cwd=r,env=env,capture_output=True);(s/(name+'.stdout')).write_bytes(p.stdout);(s/(name+'.stderr')).write_bytes(p.stderr)
 results.append([name,p.returncode]);print(name,p.returncode,flush=True)
(s/'profiler-controls-and-ci-results.json').write_text(json.dumps(results,indent=2)+'\n')
jobs=json.loads((s/'pipeline-jobs-1408.stdout').read_text())['jobs']
for j in jobs:
 if j['status']!='completed' or j['conclusion']=='skipped' or 'Native contracts' not in j['name']:continue
 name='native-'+str(j['id']);p=subprocess.run(['gh','api','--allow-escape-sequences','repos/link-assistant/formal-ai/actions/jobs/'+str(j['id'])+'/logs'],cwd=r,capture_output=True)
 (s/(name+'.stdout')).write_bytes(p.stdout);(s/(name+'.stderr')).write_bytes(p.stderr);print(name,j['name'],j['conclusion'],p.returncode,flush=True)
