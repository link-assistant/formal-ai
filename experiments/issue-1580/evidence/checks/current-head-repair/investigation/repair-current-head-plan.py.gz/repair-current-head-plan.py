from pathlib import Path
import json, subprocess, os
r=Path('/tmp/gh-issue-solver-1794900398048')
s=Path('/tmp/issue-1580-research/current-head-repair');s.mkdir(exist_ok=True)
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
files=['default-branch-build-policy','ci-fast-critical-profile','rust-specification-fixture-integrity','rust-specification-unicode-identifiers']
results=[]
for name in files:
 p=subprocess.run(['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs'],cwd=r,env=env,capture_output=True)
 (s/(name+'-before.stdout')).write_bytes(p.stdout);(s/(name+'-before.stderr')).write_bytes(p.stderr)
 results.append([name,p.returncode]);print(name,p.returncode,flush=True)
(s/'before-results.json').write_text(json.dumps(results,indent=2)+'\n')
baseline=r/'experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8'
(s/'previous-governed-baseline.v8').write_bytes(baseline.read_bytes())
