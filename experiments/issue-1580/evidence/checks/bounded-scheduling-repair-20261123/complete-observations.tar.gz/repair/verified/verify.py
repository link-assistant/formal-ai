from pathlib import Path
import subprocess,json,os,time,datetime,shutil,hashlib
r=Path('/tmp/issue-1580-research/scheduling-contracts-53816/verified')
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
commands=[
 ('existing-ci-speed-contracts',['node','--test','--test-concurrency=1','rust/tests/web/ci-speed.test.mjs']),
 ('historical-costs-and-probe',['node','--test','--test-concurrency=1','experiments/issue-1580/hosted-javascript-scheduling.test.mjs']),
 ('dialogue-ownership',['node','--test','--test-concurrency=1','experiments/issue-1580/cnl-dialogue-partition.test.mjs']),
 ('maintained-template-observations',['node','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs']),
 ('all-javascript-gates',['node','experiments/formal_ai_subagent/local-gates.mjs'])]
records=[]
try:
 for name,cmd in commands:
  started=time.time()
  with(r/(name+'.log')).open('wb')as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
  record={'name':name,'command':cmd,'exitCode':p.returncode,'seconds':time.time()-started,
   'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  records.append(record)
  if name=='all-javascript-gates':
   text=(r/(name+'.log')).read_text()
   record['counts']={status:sum(line.startswith(status+' ')for line in text.splitlines())for status in ['PASS','SKIP','FAIL']}
   d=r/'complete-gate-outputs';d.mkdir(exist_ok=True)
   for file in Path('experiments/formal_ai_subagent/sandboxes/gates').glob('*.log'):
    if file.stat().st_mtime>=started-1:shutil.copyfile(file,d/file.name)
  if name=='capture-exact-source' and p.returncode==0:
   fixture=Path('experiments/issue-1580/fixtures/hosted-javascript-e46254ac')
   record['byteIdenticalFields']=[]
   for field in ['durations.jsonl','run-observation.json','prior-scheduling-floor.lino']:
    assert (r/'recaptured-fixture'/field).read_bytes()==(fixture/field).read_bytes(),field
    record['byteIdenticalFields'].append(field)
  (r/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
  assert p.returncode==0,name+' failed'
 (r/'outcome.json').write_text(json.dumps({'complete':True,'success':True,'records':records},indent=2)+'\n')
except BaseException as e:
 (r/'outcome.json').write_text(json.dumps({'complete':True,'success':False,'error':str(e),'records':records},indent=2)+'\n')
 raise
