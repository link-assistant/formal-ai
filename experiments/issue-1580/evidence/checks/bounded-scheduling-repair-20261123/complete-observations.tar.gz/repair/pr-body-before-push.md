Fixes #1580

CI could accept malformed Git path bytes after silently replacing them, and successful JavaScript shards could exceed their runtime warning budget. This PR preserves the observations and adds regression coverage while repairing admission, fixture, scheduling and native-workflow failures.

The latest terminal source, 53816c9eb4bd11729a8be347ccd9497d07042660, has 31 successful workflows, one failed Layered CI workflow and one explicit skip. Its complete Layered log reproduces the unchanged provenance-ordering assertion at line 9314 and conservative queue assertion at line 9333. The rejected uniform 65% scheduling reserve caused both failures.

The replacement changes only three dialogue owner allowances, preserving all previous scheduling floors and the explicit fallback. A finite 66-candidate probe reproduces the selected weights and policy byte for byte against eleven historical cohorts and one explicitly partial observation. It also separates the original fifteen Meta Reasoner callbacks into two bounded isolated processes; the original 254.556-second owner could not fit the unchanged warning-plus-overhead model through file repartitioning alone. All original assertions and two skip controls remain. Nine shards, four workers, the 270-second warning and 360-second deadline remain unchanged.

Verification of this repair:

- The existing scheduling suite reproduces 25 passes and two failures before the repair; all 28 cases pass afterward, including a new regression for fallback loss on empty and known-file-only imports.
- Twelve historical/probe tests, four dialogue ownership cases and four Meta Reasoner partition controls pass.
- The actual Meta Reasoner owner passes locally in 157.190 seconds: thirteen original cases pass and two retain their existing capture-dependent skips. The maintained observation entry passes in 215.317 seconds.
- The complete JavaScript gate replay is in progress. Exact-source hosted qualification of the replacement remains pending. No local Rust build runs.
- The preceding 53816 cohort passes all ten native contract groups, totaling 441 tests, and confirms its actual tested merge 7655c52f107242efef5307daa905f651110cbbd5. Its real-Git malformed UTF-8, BOM and multibyte admission controls pass. Earlier decoder verification retains six real-Git cases and 184 maintained admission cases.

Reproduction commands, original failures and timing boundaries are in [admission path encoding](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/admission-path-encoding.md), [bounded scheduling repair](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/hosted-shard-cost-refresh.md), and the [terminal 53816 cohort](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/terminal-53816-ci.md). The terminal receipt preserves all 33 complete available CLI streams, paginated jobs, exact commands and diagnostic inventories in a round-trip-verified archive.

The six current platform warnings remain explicit: one overloaded JavaScript group, two source-size warnings, two low OpenSSF scores and unknown crates.io publication authority. The local runtime and source-size repairs require hosted qualification; dependency acceptance and publication authority remain unfinished. Historical unsafe-libyaml maintenance is still in scope. The partial failed-run fixture preserves 819 observed file durations and all 103 unexecuted file identities; missing executions are never reported as passing.

Complete dated comparison covers eight template trees: 3,028 blobs, 2,993 unchanged identities and 35 reviewed changes. Scoped aggregate reviews cover 218 root Markdown files and four nested reports. Full aggregate review and implementation/execution of every applicable practice remain unfinished. Main 03a636334975cd7ca5cedff119e2dd0efbc8579f is included. The [requirements and verification plan](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/experiments/issue-1580/work-plan.md) retains the full scope and feedback.

This PR remains **draft and unmerged**. Complete template adoption, strict style and source-size debt, original workflow families and full-suite budgets, main-only publication/delivery, cache reliability, live useful delivery, serving identity, trusted cross-request epochs, CodeQL semantics, dependency migrations and original artifact retention remain unfinished. Green CI, explicit skips, fixtures, source comparisons and upstream reports do not complete those criteria. Supplied work receives zero independent authorship or reasoning credit.

The whole-producer rerun passes all ten consumers against attempt-2 artifact 14822114800, but original artifact 14812694215 metadata returns 404. [Retention evidence](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/native-producer-rerun.md) remains unfinished. Related upstream work: [artifact retention #585](https://github.com/actions/upload-artifact/issues/585), [command-stream PR 240](https://github.com/link-foundation/command-stream/pull/240), [calculator #265](https://github.com/link-assistant/calculator/issues/265), [CodeQL #23198](https://github.com/github/codeql/issues/23198), [Hive Mind #3909](https://github.com/link-assistant/hive-mind/issues/3909), and Java template [manual dispatch #34](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/34) and [fragment preservation #35](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/35).

Earlier visual verification uses the labeled production-worker harness with external requests blocked:

![Before: Spanish definition frame skipped](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/screenshots/issue-1580/meaning-hydration-before.png?raw=true)

![After: definition routes to search and the unresolved sibling remains intact](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/screenshots/issue-1580/meaning-hydration-after.png?raw=true)
