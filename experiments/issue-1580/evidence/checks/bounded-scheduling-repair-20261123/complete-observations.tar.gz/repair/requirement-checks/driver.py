from pathlib import Path
import subprocess,time,datetime,json
root=Path('/tmp/issue-1580-research/scheduling-contracts-53816/requirement-checks')
commands=[['node','scripts/assemble-requirements.mjs'],['node','scripts/generate-requirement-status.mjs'],['node','scripts/check-requirement-status.mjs'],['node','scripts/render-status.mjs','--check'],['node','scripts/render-progressive-plan.mjs','--check']]
records=[]
for i,command in enumerate(commands):
 start=time.monotonic()
 with (root/(str(i)+'.log')).open('wb') as out: result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 record={'command':command,'exitCode':result.returncode,'seconds':time.monotonic()-start}
 records.append(record);print(json.dumps(record),flush=True)
(root/'outcome.json').write_text(json.dumps({'complete':True,'success':all(x['exitCode']==0 for x in records),'records':records,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
