from pathlib import Path
import subprocess,json,os,time,datetime,shutil
root=Path('/tmp/issue-1580-research/scheduling-contracts-53816/documentation-recheck')
gates=['check-requirement-coverage', 'check-assemble-requirements-js-twin', 'check-generated-files', 'check-file-size-js-twin', 'check-file-size', 'check-ci-speed', 'check-required-documentation', 'check-tests-as-docs', 'check-tests-as-documentation-javascript-twin', 'check-changelog-fragment-js-twin']
started=time.time()
command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',','.join(gates)]
with (root/'gates.log').open('wb') as stream:result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
log=(root/'gates.log').read_text()
outputs=root/'complete-gate-outputs';outputs.mkdir()
for p in Path('experiments/formal_ai_subagent/sandboxes/gates').glob('*.log'):
 if p.stat().st_mtime>=started-1:shutil.copyfile(p,outputs/p.name)
record={'command':command,'exitCode':result.returncode,'seconds':time.time()-started,'counts':{s:sum(line.startswith(s+' ')for line in log.splitlines())for s in ['PASS','SKIP','FAIL']},'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(root/'outcome.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
