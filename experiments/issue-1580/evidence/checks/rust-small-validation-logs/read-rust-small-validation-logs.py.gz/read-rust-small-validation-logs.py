from pathlib import Path
import gzip,hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048')
src=Path('/tmp/issue-1580-research/templates/rust-complete')
dst=Path('/tmp/issue-1580-research/rust-small-validation-logs');dst.mkdir(exist_ok=False)
inventory={r['path']:r for r in json.loads((root/'experiments/issue-1580/evidence/checks/rust-template-first-gate/pinned-file-identities.json').read_text())}
names=['batch-2-script-validation.log.gz','candidate-validation.log.gz','rust-full-validation.log.gz','script-tests.log.gz']
rows=[]
for name in names:
 path='dev/log/issues/247/pulls/248/evidence/'+name
 packed=(src/path).read_bytes();assert hashlib.sha256(packed).hexdigest()==inventory[path]['sha256']
 raw=gzip.decompress(packed);lines=raw.decode().splitlines()
 out=dst/name.removesuffix('.gz');out.write_bytes(raw)
 chunks=[]
 for start in range(0,len(lines),100):
  chunk=name+f'.{start+1:05d}.txt'
  (dst/chunk).write_text(f'PINNED {path} decoded lines {start+1}-{min(start+100,len(lines))}\n'+'\n'.join(f'{i+1}: {s}' for i,s in enumerate(lines[start:start+100],start))+'\n')
  chunks.append(chunk)
 rows.append({'path':path,'sha256':hashlib.sha256(packed).hexdigest(),'rawSha256':hashlib.sha256(raw).hexdigest(),'decodedLines':len(lines),'decodedBytes':len(raw),'chunks':chunks})
(dst/'identities.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
