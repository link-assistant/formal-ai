from pathlib import Path
import datetime,gzip,hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048')
src=Path('/tmp/issue-1580-research/templates/rust-complete')
reads=Path('/tmp/issue-1580-research/rust-small-validation-logs')
rows=json.loads((reads/'identities.json').read_text())
ledger=root/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data=json.loads(ledger.read_text());assert data['fullyReadFiles']==339
manifest=root/data['readLogManifest'];records=json.loads(manifest.read_text())
for row in rows:
 assert row['path'] not in {r['path'] for r in data['files']}
 packed=(src/row['path']).read_bytes();raw=gzip.decompress(packed)
 assert hashlib.sha256(packed).hexdigest()==row['sha256']
 assert hashlib.sha256(raw).hexdigest()==row['rawSha256']
 lines=raw.decode().splitlines();assert len(lines)==row['decodedLines']
 observed=[]
 for name in row['chunks']:
  text=(reads/name).read_text().splitlines()
  for line in text[1:]:
   number,value=line.split(': ',1);observed.append((int(number),value))
 assert observed==list(enumerate(lines,1))
 name='small-validation-'+Path(row['path']).name
 (manifest.parent/name).write_bytes(gzip.compress(raw,mtime=0))
 retained=(manifest.parent/name).read_bytes()
 records.append({'file':name,'rawSha256':row['rawSha256'],'archiveSha256':hashlib.sha256(retained).hexdigest()})
 data['files'].append({'path':row['path'],'lines':len(lines),'sha256':row['sha256'],
  'sourceEncoding':'gzip','decodedSha256':row['rawSha256'],'readLogs':[name],
  'literalReadRanges':[[1,len(lines)]],'literalReadLines':len(lines),
  'literalSourceFullyRead':True,'formalAiPracticeImplementationVerified':False})
data['files'].sort(key=lambda r:r['path']);data['fullyReadFiles']=len(data['files'])
data['fullyReadSourceLines']=sum(r['literalReadLines'] for r in data['files'])
assert (data['fullyReadFiles'],data['fullyReadSourceLines'])==(343,41542)
data['observedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
data['practiceDecisions'].append({'practice':'Read complete archived validation streams and preserve warnings after successful tests',
 'templateEvidence':[r['path'] for r in rows],
 'assessment':'All 2,526 decoded lines from four immutable gzip streams were literally read. The full validation stream passes two CLI tests, three integration tests and 296 unit tests; it also records checks, documentation and zero-case targets. The three script streams pass their listed standalone Rust, Python and JavaScript suites while still emitting unused serde, chrono and ureq dependency warnings; batch two additionally warns on regex in two scripts. Candidate validation passes 124 JavaScript controls and eight JavaScript-first Rust/doc cases, but its final package upload explicitly aborts due to dry run. These are historical fixtures, not present Formal AI execution or published package proof. Preserve strict warning gates, exact selected revision and prerequisite evidence; current adoption, external publication, all warnings and the remaining template comparison stay open.',
 'status':'complete-literal-decoded-log-review-current-practice-runtime-open'})
manifest.write_text(json.dumps(records,indent=2)+'\n');ledger.write_text(json.dumps(data,indent=2)+'\n')
dst=root/'experiments/issue-1580/evidence/checks/rust-small-validation-logs';dst.mkdir(exist_ok=False)
captured=[]
for p in [Path(__file__),Path('/tmp/issue-1580-research/read-rust-small-validation-logs.py'),reads/'identities.json']:
 raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);name=p.name+'.gz';(dst/name).write_bytes(packed)
 captured.append({'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
(dst/'records.json').write_text(json.dumps(captured,indent=2)+'\n')
(dst/'assessment.json').write_text(json.dumps({'literalPinnedFilesRead':343,'literalDecodedLinesRead':41542,
 'newHistoricalLogLines':2526,'newSourceRecords':rows,'historicalTestsEstablishCurrentRuntime':False,
 'allTemplatePracticesAdopted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
with (root/'experiments/issue-1580/work-plan.md').open('a') as f:f.write('\n- Read all 2,526 decoded lines in four pinned Rust historical validation gzip streams: 343/373 identities and 41,542 literal text lines now reviewed. Passing script tests retain explicit unused-dependency warnings; candidate package upload was a dry run. Preserve this evidence without current runtime/publication or complete-practice credit.\n')
print(json.dumps({'literalFilesRead':343,'literalTextLinesRead':41542,'remainingIdentities':30,'fullIssueComplete':False,'independentAuthorshipCredit':0}))
