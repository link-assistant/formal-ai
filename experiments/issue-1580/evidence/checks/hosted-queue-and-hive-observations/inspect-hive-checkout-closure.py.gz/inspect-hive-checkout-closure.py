from pathlib import Path
import gzip,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
for name,start,stop in [('experiments/issue-1580/native-regression-groups.test.mjs',250,330),('.github/workflows/native-type-check.yml',1,300)]:
 lines=(root/name).read_text().splitlines();print('FILE',name)
 for i in range(start,min(stop,len(lines))+1):print(i,lines[i-1])
base=root/'experiments/issue-1580/evidence/ci/native-families-1d7ba479'
for run,line in [(44794246311,541),(44794225675,529)]:
 lines=gzip.decompress((base/f'full-run-{run}.stdout.gz').read_bytes()).decode().splitlines();print('AUDIT',run)
 for i in range(line-35,line+8):print(i,lines[i-1])
