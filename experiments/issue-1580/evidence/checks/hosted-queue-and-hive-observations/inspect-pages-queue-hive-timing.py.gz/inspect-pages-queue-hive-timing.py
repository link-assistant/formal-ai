from pathlib import Path
import gzip,hashlib,json,re,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
base=Path('/tmp/issue-1580-research/pages-queue-hive-timing');base.mkdir(exist_ok=False)
argv=['gh','run','view','44794246520','--repo','link-assistant/formal-ai','--job','136489959657','--log']
result=subprocess.run(argv,cwd=root,capture_output=True)
for label in ['stdout','stderr']:(base/label).write_bytes(getattr(result,label))
assert result.returncode==0,result.stderr
lines=result.stdout.decode().splitlines()
selected=[]
for index,line in enumerate(lines,1):
 if re.search(r'##\[|Finished |test result:|running \d+ tests|test .* \.\.\.|elapsed|Timeout|timeout|time limit|seconds|sparse checkout|Retry failed|Native contract family|Native targets|Preparing|Compiling .*formal',line):
  selected.append({'line':index,'text':line})
(base/'selected.json').write_text(json.dumps(selected,indent=2)+'\n')
print(json.dumps({'bytes':len(result.stdout),'lines':len(lines),'sha256':hashlib.sha256(result.stdout).hexdigest(),'selected':len(selected)}))
for row in selected:print(json.dumps(row))
