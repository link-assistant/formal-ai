from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
dst=Path('/tmp/issue-1580-research/warning-evidence-consumers-focused');dst.mkdir(exist_ok=False)
paths=[line.split(' ',2)[2] for line in Path('/tmp/issue-1580-research/open-review-and-size-warnings-corrected/size-warning-paths.txt').read_text().splitlines() if line.split(' ',2)[2].startswith('experiments/')]
argv=['git','grep','-n','-I','-F']
for path in paths:argv+=['-e',path]
argv+=['--','scripts','rust/tests','js','ts','.github','docs','experiments/issue-1580',':!experiments/issue-1580/evidence']
result=subprocess.run(argv,cwd=root,capture_output=True)
(dst/'stdout').write_bytes(result.stdout);(dst/'stderr').write_bytes(result.stderr)
assert result.returncode in [0,1],result.stderr
lines=result.stdout.decode().splitlines()
print(json.dumps({'patterns':paths,'matches':len(lines),'scope':'tracked maintained code, tests, documentation and issue experiment sources; excludes all evidence subtrees'}),flush=True)
for line in lines:print(line[:500],flush=True)
