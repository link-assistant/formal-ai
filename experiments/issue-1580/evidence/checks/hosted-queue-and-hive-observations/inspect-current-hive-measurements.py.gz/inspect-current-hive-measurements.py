from pathlib import Path
import gzip,json,re,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048')
for name in ['scripts/lib/ci-speed-durations.mjs','scripts/lib/ci-speed-shards.mjs','experiments/issue-1580/work-plan.md','/tmp/issue-1580-research/seal-rust-historical-contract-docs.py']:
 p=Path(name) if name.startswith('/') else root/name
 print('\nFILE',name);print(p.read_text())
base=root/'experiments/issue-1580/evidence/ci/native-families-1d7ba479'
for job in [136489959548,136489959657,136489959672]:
 p=base/f'job-{job}.stdout.gz'; raw=gzip.decompress(p.read_bytes())
 print('\nHIVE TIMING',p.name,'sha256',hashlib.sha256(raw).hexdigest())
 for n,line in enumerate(raw.decode().splitlines(),1):
  if re.search(r'running \d+ tests|test issue_1133_hive_mind_three_runs::|test result:',line):print(n,line)
for run in [44794246311,44794225675]:
 p=base/f'full-run-{run}.stdout.gz'; lines=gzip.decompress(p.read_bytes()).decode().splitlines()
 indices=[i for i,line in enumerate(lines) if 'warning: Allowed warnings found!' in line]
 for i in indices:
  print('\nAUDIT',run,i+1)
  for j in range(max(0,i-65),min(len(lines),i+12)):print(j+1,lines[j])
