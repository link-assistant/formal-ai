from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
p=root/'experiments/issue-1580/derive-native-hive-durations.py'
s=p.read_text()
s=s.replace("LOG = ROOT / 'experiments/issue-1580/evidence/ci/native-families-7fce5c19/job-136011692528.stdout.gz'", """SOURCES = [
    (44652802985, '7fce5c19a7297a121d92eb09e7fefa99ca649eaf', 136011692528),
    (44794246520, '1d7ba479b92fed6c1d6735b442579af9190a6b28', 136489959548),
    (44794246520, '1d7ba479b92fed6c1d6735b442579af9190a6b28', 136489959657),
    (44794246520, '1d7ba479b92fed6c1d6735b442579af9190a6b28', 136489959672),
]""")
s=s.replace('def measured_text():\n    previous = None\n    durations = {}\n    for line in gzip.decompress(LOG.read_bytes()).decode().splitlines():', "def completed_durations(text):\n    previous = None\n    durations = {}\n    for line in text.splitlines():")
s=s.replace("    rows = ['test_durations', '  source_run 44652802985',\n            '  source_sha 7fce5c19a7297a121d92eb09e7fefa99ca649eaf',", """    return durations


def measured_text():
    durations = {}
    for run, head, job in SOURCES:
        path = ROOT / f'experiments/issue-1580/evidence/ci/native-families-{head[:8]}/job-{job}.stdout.gz'
        observed = completed_durations(gzip.decompress(path.read_bytes()).decode())
        for name, seconds in observed.items():
            # Retain the slowest completed observation; fresh faster runs must
            # not erase an earlier measured scheduling cost.
            durations[name] = max(durations.get(name, 0), seconds)
    rows = ['test_durations']
    for run, head, job in SOURCES:
        rows.extend([f'  source_run {run}', f'  source_sha {head}', f'  source_job {job}'])
    rows.extend([""")
s=s.replace("'  purpose \"Only completed sequential hosted cases are measured; unseen cases weigh 60 seconds.\"',", "'  purpose \"Maximum completed sequential hosted duration per case; unseen cases weigh 60 seconds.\"',")
s=s.replace("--write\"']", "--write\"'])")
p.write_text(s)
test=root/'experiments/issue-1580/native-regression-groups.test.mjs'
s=test.read_text().replace("import {admission}","import {parseTestDurations} from '../../scripts/lib/ci-speed-durations.mjs';\nimport {planShards, durationLookup, partitionProblems} from '../../scripts/lib/ci-speed-shards.mjs';\nimport {admission}")
needle="test('the native lane admits changes to the complete Hive planner input closure', () => {"
addition="""test('completed Hive timings isolate the eleven-minute workflow case without losing coverage', () => {
  const weights = parseTestDurations(readFileSync('scripts/ci-native-hive-durations.lino', 'utf8'));
  const names = [...new Set([1, 2, 3].flatMap(index => {
    const jobs = [136489959548, 136489959657, 136489959672];
    const log = gunzipSync(readFileSync('experiments/issue-1580/evidence/ci/native-families-1d7ba479/job-' + jobs[index - 1] + '.stdout.gz')).toString();
    return [...log.matchAll(/test (issue_1133_hive_mind_three_runs::\\S+) \\.{3} ok/g)].map(match => match[1]);
  }))];
  assert.equal(names.length, 37);
  const slow = 'issue_1133_hive_mind_three_runs::repository_workflows_include_runtime_setup_and_output_verification';
  assert(weights.get(slow) > 672, 'the actual long case must not fall back to sixty seconds');
  assert(weights.get('issue_1133_hive_mind_three_runs::extended::a_workflow_requirement_adds_the_workflow_in_every_language') >= 160.854,
    'a faster fresh observation must preserve the earlier measured cost');
  const {shards, load} = planShards(names, 3, durationLookup(weights, 60));
  assert.deepEqual(partitionProblems(names, shards), {missing: [], repeated: [], extra: []});
  assert.deepEqual(shards.find(shard => shard.includes(slow)), [slow]);
  assert(Math.max(...load) < 700, 'the completed observations fit below twelve test minutes per shard');
});

"""
s=s.replace("import YAML from 'yaml';", "import YAML from 'yaml';\nimport {gunzipSync} from 'node:zlib';")
assert needle in s;s=s.replace(needle,addition+needle);test.write_text(s)
subprocess.run(['python3',str(p),'--write'],cwd=root,check=True)
fragment=root/'changelog.d/issue-1580-hive-duration-refresh.md'
fragment.write_text('Refresh the native Hive shard weights from all 37 completed hosted cases, keeping the maximum prior duration per case. The previously unmeasured eleven-minute workflow replay now receives its own shard; every test remains covered once under the unchanged twenty-minute job deadline.\n')
print('Drafted maximum-observation weights and focused partition regression; supplied code earns zero independent authorship credit.')
