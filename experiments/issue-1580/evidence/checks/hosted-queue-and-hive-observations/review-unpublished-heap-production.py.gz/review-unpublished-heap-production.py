from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
dst=Path('/tmp/issue-1580-research/heap-production-review');dst.mkdir(exist_ok=False)
base='1d7ba479b92fed6c1d6735b442579af9190a6b28'
commands={
 'names':['git','diff','--name-only',base,'--','.github','scripts','rust','js','ts','data','experiments/issue-1580/codeql-macro-contexts','changelog.d'],
 'diff':['git','diff',base,'--','experiments/issue-1580/codeql-macro-contexts/observe.py','experiments/issue-1580/codeql-macro-contexts/README.md','rust/tests/web/security-codeql-results.test.mjs','changelog.d/issue-1580-macro-query-memory.md']}
for name,argv in commands.items():
 result=subprocess.run(argv,cwd=root,capture_output=True)
 (dst/(name+'.stdout')).write_bytes(result.stdout);(dst/(name+'.stderr')).write_bytes(result.stderr)
 assert result.returncode==0,result.stderr
 print(name,hashlib.sha256(result.stdout).hexdigest(),len(result.stdout),'bytes')
 print(result.stdout.decode())
