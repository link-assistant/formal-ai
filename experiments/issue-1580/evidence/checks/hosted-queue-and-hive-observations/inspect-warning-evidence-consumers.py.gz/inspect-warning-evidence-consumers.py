from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
dst=Path('/tmp/issue-1580-research/warning-evidence-consumers');dst.mkdir(exist_ok=False)
allrows=[]
for line in Path('/tmp/issue-1580-research/open-review-and-size-warnings-corrected/size-warning-paths.txt').read_text().splitlines():
 count,threshold,path=line.split(' ',2)
 if not path.startswith('experiments/'):continue
 argv=['rg','-n','--fixed-strings','--max-columns','400',path,'.','--glob','!**/evidence/commands/**']
 result=subprocess.run(argv,cwd=root,capture_output=True)
 (dst/(str(len(allrows))+'.stdout')).write_bytes(result.stdout)
 (dst/(str(len(allrows))+'.stderr')).write_bytes(result.stderr)
 assert result.returncode in [0,1],result.stderr
 allrows.append({'path':path,'bytes':(root/path).stat().st_size,'matches':len(result.stdout.splitlines()),'log':str(len(allrows))+'.stdout'})
 print(json.dumps(allrows[-1]))
 print(result.stdout.decode())
(dst/'inventory.json').write_text(json.dumps(allrows,indent=2)+'\n')
