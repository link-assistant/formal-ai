from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
p=root/'.github/workflows/layered-ci.yml';s=p.read_text()
old='              /experiments/issue-1580/evidence/ci/native-families-7fce5c19/job-136011692528.stdout.gz'
lines=[line for line in s.splitlines() if line.strip()=='/experiments/issue-1580/evidence/ci/native-families-7fce5c19/job-136011692528.stdout.gz']
assert len(lines)==1;old=lines[0]
new=[f'experiments/issue-1580/evidence/ci/native-families-1d7ba479/job-{job}.stdout.gz' for job in [136489959548,136489959657,136489959672]]
s=s.replace(old,old+'\n'+'\n'.join(old[:len(old)-len(old.lstrip())]+'/'+name for name in new));p.write_text(s)
p=root/'experiments/issue-1580/native-regression-groups.test.mjs';s=p.read_text()
needle="  const reasoningEvidence = 'experiments/issue-1580/evidence/checks/native-reasoning-budget/job-136423862321.stdout.gz';"
assert needle in s;s=s.replace(needle,needle+"\n  const currentHiveEvidence = [136489959548, 136489959657, 136489959672]\n    .map(job => 'experiments/issue-1580/evidence/ci/native-families-1d7ba479/job-' + job + '.stdout.gz');")
s=s.replace('for (const path of [evidence, reasoningEvidence,', 'for (const path of [evidence, ...currentHiveEvidence, reasoningEvidence,')
s=s.replace("    assert(existsSync(join(directory, evidence)), 'the real weight derivation input must be checked out');", "    for (const path of [evidence, ...currentHiveEvidence]) {\n      assert(existsSync(join(directory, path)), 'each real weight derivation input must be checked out: ' + path);\n    }")
p.write_text(s)
source=Path('/tmp/issue-1580-research/check-current-hive-weights.py').read_text()
source=source.replace('current-hive-weights-checks','current-hive-weights-corrected-checks')
start=source.index(" path=root/'scripts/ci-native-hive-durations.lino'")
stop=source.index(" run('native-groups'",start)
source=source[:start]+source[stop:]
Path('/tmp/issue-1580-research/check-current-hive-weights-corrected.py').write_text(source)
print('Added exactly three observed log inputs to real sparse acquisition and its physical Git regression; kept unrelated archives excluded.')
