from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
argv=['rg','-n','maxLines|max_lines|MAX_LINES|warningThreshold|warnThreshold|0\\.9|1000|1500','scripts/check-file-size.mjs','scripts/split-rust','scripts/split-rust.mjs','scripts/split-seeds.mjs','scripts/split-seed-files.mjs']
result=subprocess.run(argv,cwd=root,capture_output=True)
print(result.stdout.decode());print(result.stderr.decode());print('exitCode',result.returncode)
result=subprocess.run(['rg','--files','scripts','-g','*split*','-g','*partition*','-g','*size*'],cwd=root,capture_output=True)
print(result.stdout.decode());print(result.stderr.decode());assert result.returncode==0
