from pathlib import Path
import subprocess,os,json,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');base=Path('/tmp/issue-1580-research/current-hive-weights-checks')
if len(sys.argv)==1:
 base.mkdir(exist_ok=False)
 with (base/'worker.log').open('wb') as stream:
  child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':child.pid,'scratch':str(base)}));sys.exit(0)
records=[]
def run(name,argv,expected=0):
 result=subprocess.run(argv,cwd=root,env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256'),capture_output=True)
 for label in ['stdout','stderr']:(base/f'{name}.{label}').write_bytes(getattr(result,label))
 records.append({'name':name,'argv':argv,'exitCode':result.returncode});(base/'records.json').write_text(json.dumps(records,indent=2)+'\n')
 assert result.returncode==expected,(name,result.stderr[-2000:],result.stdout[-2000:]);print(name,'PASS',flush=True)
try:
 path=root/'scripts/ci-native-hive-durations.lino';fixed=path.read_bytes()
 original=subprocess.run(['git','show','HEAD:scripts/ci-native-hive-durations.lino'],cwd=root,capture_output=True,check=True).stdout
 try:
  path.write_bytes(original)
  run('before-control',['node','--test','--test-concurrency=1','--test-name-pattern=completed Hive timings isolate','experiments/issue-1580/native-regression-groups.test.mjs'],1)
  assert b'the actual long case must not fall back' in (base/'before-control.stdout').read_bytes()
 finally:path.write_bytes(fixed)
 run('native-groups',['node','--test','--test-concurrency=1','experiments/issue-1580/native-regression-groups.test.mjs'])
 run('gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-file-size-js-twin,check-readable-code,check-tests-as-docs,check-ci-speed,check-runner-labels'])
 run('whitespace',['git','diff','--check'])
 (base/'outcome.json').write_text(json.dumps({'complete':True,'beforeFailed':True,'fullIssueComplete':False,'independentAuthorshipCredit':0})+'\n')
except BaseException:
 traceback.print_exc();(base/'failure.json').write_text(json.dumps({'complete':False,'traceback':traceback.format_exc()})+'\n');sys.exit(1)
