from pathlib import Path
import datetime,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
dst=Path('/tmp/issue-1580-research/heap-batch-feedback');dst.mkdir(exist_ok=False)
commands={
 'issue-comments':['gh','api','repos/link-assistant/formal-ai/issues/1580/comments','--paginate'],
 'pr-comments':['gh','api','repos/link-assistant/formal-ai/issues/1581/comments','--paginate'],
 'pr-inline-comments':['gh','api','repos/link-assistant/formal-ai/pulls/1581/comments','--paginate'],
 'pr-reviews':['gh','api','repos/link-assistant/formal-ai/pulls/1581/reviews','--paginate'],
 'recent-runs':['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','5','--json','databaseId,conclusion,createdAt,headSha,status,workflowName'],
 'pr':['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','headRefOid,baseRefName,isDraft,state,title,body,url']}
for name,argv in commands.items():
 result=subprocess.run(argv,cwd=root,capture_output=True)
 (dst/(name+'.stdout')).write_bytes(result.stdout);(dst/(name+'.stderr')).write_bytes(result.stderr)
 assert result.returncode==0,(name,result.stderr)
 data=json.loads(result.stdout)
 if name.endswith('comments') or name=='pr-reviews':
  print(name,len(data))
  for row in data:print(json.dumps({k:row.get(k) for k in ['id','html_url','created_at','updated_at','body','state']},ensure_ascii=False))
 elif name=='recent-runs':print(json.dumps(data,indent=2))
 else:print(json.dumps({k:data[k] for k in ['headRefOid','baseRefName','isDraft','state','title','url']}))
print('Observed',datetime.datetime.now(datetime.timezone.utc).isoformat())
