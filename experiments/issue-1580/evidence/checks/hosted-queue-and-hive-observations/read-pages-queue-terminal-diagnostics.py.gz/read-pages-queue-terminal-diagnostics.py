from pathlib import Path
import datetime,gzip,json,re
root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/ci/native-families-1d7ba479'
scratch=Path('/tmp/issue-1580-research/pages-queue-terminal-diagnostics');scratch.mkdir(exist_ok=False)
assessment=json.loads((base/'assessment.json').read_text());assert assessment['verifiedStreams']==300
annotations=json.loads((base/'workflow-annotations.json').read_text())
for index,row in enumerate([r for r in annotations if not r['quotedShellSource'] and 'approaching limit of' not in r['text']]):
 lines=gzip.decompress((base/row['file']).read_bytes()).decode().splitlines()
 start=max(1,row['line']-20);stop=min(len(lines),row['line']+25)
 (scratch/f'annotation-{index}.read.txt').write_text('\n'.join(f'{i}: {lines[i-1]}' for i in range(start,stop+1))+'\n')
lines=gzip.decompress((base/'job-136489959657.stdout.gz').read_bytes()).decode().splitlines()
selected=[(i,line) for i,line in enumerate(lines,1) if re.search(r'Finished |test result:|running \d+ tests|test .* \.\.\.|elapsed|##\[warning|##\[error|Budget|budget',line)]
(scratch/'hive-2-timing.read.txt').write_text('\n'.join(f'{i}: {line}' for i,line in selected)+'\n')
diagnostics=[json.loads(line) for line in (base/'runtime-diagnostics.jsonl').read_text().splitlines()]
selected=[row for row in diagnostics if 'approaching' not in row['text']]
for start in range(0,len(selected),40):
 (scratch/f'runtime-{start+1:04d}.read.txt').write_text('\n'.join(json.dumps(row) for row in selected[start:start+40])+'\n')
print(json.dumps({'files':[p.name for p in sorted(scratch.iterdir())],'hiveTimingSelectedLines':len(selected),'runtimeDiagnostics':len(diagnostics),'nonSizeRuntimeDiagnostics':len(selected),'allAggregateLinesLiterallyRead':False}))
for row in assessment['nativeJobs']:
 start=datetime.datetime.fromisoformat(row['startedAt'].replace('Z','+00:00'));end=datetime.datetime.fromisoformat(row['completedAt'].replace('Z','+00:00'))
 print(row['name'],int((end-start).total_seconds()),'seconds',row['passed'],'tests')
