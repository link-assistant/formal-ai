from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
argv=['rg','-n','hive.*weights|weights.*hive|repository_workflows_include_runtime_setup|135\.|longest-first','experiments/issue-1580/native-regression-groups.mjs','experiments/issue-1580/native-regression-groups.test.mjs','scripts/ci-native-regressions.sh','data/benchmarks']
result=subprocess.run(argv,cwd=root,capture_output=True)
print(result.stdout.decode());print(result.stderr.decode());assert result.returncode==0
