from pathlib import Path
import datetime,json,subprocess
r=Path('/tmp/issue-1580-research')
out=r/'extracted-witness-doc-gates'
out.mkdir(exist_ok=False)
command=['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-required-documentation,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-specification-in-javascript,check-changelog-fragment-js-twin']
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'complete.log').open('wb') as stream:
 result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
record={'command':command,'exitCode':result.returncode,'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'outcome.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
raise SystemExit(result.returncode)
