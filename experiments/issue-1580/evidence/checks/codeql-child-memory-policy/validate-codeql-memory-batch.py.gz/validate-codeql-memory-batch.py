from pathlib import Path
import datetime
import json
import os
import subprocess
import sys

root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/codeql-memory-validation')
out.mkdir(exist_ok=True)
if len(sys.argv) == 1:
    with (out / 'worker.log').open('wb') as stream:
        child = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root, stdout=stream,
                                 stderr=subprocess.STDOUT, start_new_session=True)
    (out / 'pid').write_text(str(child.pid))
    print('Started finite sequential JavaScript/source-only validation', child.pid)
    raise SystemExit()
env = {**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}
env.pop('NODE_TEST_CONTEXT', None)
commands = [
    ('profile', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/fast-pull-request-production-profile.test.mjs']),
    ('gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-file-size,check-file-size-js-twin,check-readable-code,check-tests-as-docs,check-ci-speed,check-runner-labels,workflows']),
    ('actionlint', ['/tmp/issue-1580-research/actionlint-queue-negative-control/actionlint', '-color', '-shellcheck=', '-pyflakes=']),
    ('whitespace', ['git', 'diff', '--check'])
]
records = []
for name, args in commands:
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(args, cwd=root, env=env, stdout=stdout, stderr=stderr)
    records.append({'name': name, 'argv': args, 'exitCode': result.returncode})
    (out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
(out / 'outcome.json').write_text(json.dumps({'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                            'passed': all(x['exitCode'] == 0 for x in records),
                                            'fullIssueComplete': False}, indent=2) + '\n')
