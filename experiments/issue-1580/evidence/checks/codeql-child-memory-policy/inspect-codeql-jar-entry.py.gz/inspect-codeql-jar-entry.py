from pathlib import Path
import json
import struct

raw = Path('/tmp/issue-1580-research/codeql-2.27.5-launcher/central-directory.bin').read_bytes()
offset = 0
while offset < len(raw):
    item = struct.unpack_from('<4s6H3L5H2L', raw, offset)
    length, extra, comment = item[10:13]
    name = raw[offset+46:offset+46+length].decode()
    if name.endswith('codeql.jar') or 'memory' in name.lower() or name.endswith('.sh') and 'codeql' in name:
        print(json.dumps({'name': name, 'method': item[4], 'compressedBytes': item[8], 'bytes': item[9], 'localOffset': item[-1]}))
    offset += 46 + length + extra + comment
