from pathlib import Path
import gzip, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
base = root / 'experiments/issue-1580/evidence/ci/codeql-producer-90b51590'
inventory = base / 'producer-files.json'
original = inventory.read_bytes()
rows = json.loads(original)
assert isinstance(rows, list)
renames = []
for row in rows:
    old = row['file']
    new = old.replace('_temp_', '_temporary_')
    packed = (base / old).read_bytes()
    assert hashlib.sha256(packed).hexdigest() == row['archiveSha256']
    raw = gzip.decompress(packed)
    assert hashlib.sha256(raw).hexdigest() == row['rawSha256']
    assert len(raw) == row['bytes'] and len(raw.splitlines()) == row['lines']
    if new != old:
        assert not (base / new).exists()
        (base / old).rename(base / new)
        row['file'] = new
        renames.append({'old': old, 'new': new, 'archiveSha256': row['archiveSha256']})
(base / 'original-producer-inventory.json.gz').write_bytes(gzip.compress(original, mtime=0))
parts = []
for start in range(0, len(rows), 40):
    name = 'producer-files-part-' + str(start // 40 + 1) + '.json'
    content = (json.dumps(rows[start:start + 40], indent=2) + '\n').encode()
    assert len(content.splitlines()) <= 1400
    (base / name).write_bytes(content)
    parts.append({'file': name, 'records': len(rows[start:start + 40]), 'sha256': hashlib.sha256(content).hexdigest()})
inventory.write_text(json.dumps({'format': 'partitioned-producer-inventory', 'records': len(rows),
    'parts': parts, 'originalInventory': {'file': 'original-producer-inventory.json.gz',
        'rawSha256': hashlib.sha256(original).hexdigest(), 'bytes': len(original),
        'lines': len(original.splitlines())}}, indent=2) + '\n')
(base / 'archive-path-renames.json').write_text(json.dumps(renames, indent=2) + '\n')
source = (scratch / 'assess-partitioned-hosted-macro-observations.py').read_text()
assert 'codeql-producer-39196d1f' in source
source = source.replace('codeql-producer-39196d1f', 'codeql-producer-90b51590')
target = scratch / 'assess-current-explicit-heap-macro-observations.py'
target.write_text(source)
result = subprocess.run(['python3', str(target)], cwd=root, capture_output=True)
for label in ['stdout', 'stderr']:
    (scratch / ('assess-current-explicit-heap-macro-observations.' + label)).write_bytes(getattr(result, label))
assert result.returncode == 0, result.stderr
assessment = json.loads((base / 'macro-observation-assessment.json').read_text())
print(json.dumps(assessment, indent=2))
