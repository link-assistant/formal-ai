import json
import os
from pathlib import Path
import subprocess

out = Path('/tmp/issue-1580-research/codeql-2.27.5-launcher')
env = {**os.environ, 'CODEQL_DIST': str(out), 'CODEQL_PLATFORM': 'linux64'}
for name, options in [('original-3gib', ['--ram=3072']),
                      ('current-4gib', ['--ram=4096']),
                      ('heap-only-4gib', ['--ram=4096', '--off-heap-ram=0'])]:
    args = ['java', '-Xmx128m', '-Xss512k', '-cp', str(out / 'codeql.jar'),
            'com.semmle.cli2.CodeQL', 'resolve', 'ram', '--format=json', *options]
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(args, env=env, stdout=stdout, stderr=stderr)
    print(json.dumps({'name': name, 'argv': args, 'exitCode': result.returncode,
                      'scope': 'configuration calculation only; no compilation, evaluator or native execution'}))
    print('STDOUT', (out / (name + '.stdout')).read_text())
    print('STDERR', (out / (name + '.stderr')).read_text())
    if result.returncode:
        raise SystemExit(result.returncode)
