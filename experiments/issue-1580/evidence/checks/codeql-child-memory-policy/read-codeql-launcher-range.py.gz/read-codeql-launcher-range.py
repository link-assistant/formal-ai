import hashlib
import json
from pathlib import Path
import struct
import subprocess
import urllib.request
import zlib

out = Path('/tmp/issue-1580-research/codeql-2.27.5-launcher')
out.mkdir(exist_ok=True)
release = subprocess.run(['gh', 'api', 'repos/github/codeql-cli-binaries/releases/tags/v2.27.5'],
                         capture_output=True)
(out / 'release.stdout').write_bytes(release.stdout)
(out / 'release.stderr').write_bytes(release.stderr)
release.check_returncode()
assets = json.loads(release.stdout)['assets']
asset = next(x for x in assets if x['name'] == 'codeql-linux64.zip')
url, size = asset['browser_download_url'], asset['size']
print('ASSET', json.dumps({'url': url, 'bytes': size}))

def read_range(start, length):
    assert 0 <= start < size and 0 < length <= 2 * 1024 * 1024
    req = urllib.request.Request(url, headers={'Range': f'bytes={start}-{start+length-1}'})
    with urllib.request.urlopen(req) as response:
        info = {'status': response.status, 'contentRange': response.headers.get('Content-Range')}
        if response.status != 206 or not info['contentRange'].startswith(f'bytes {start}-'):
            raise RuntimeError('Server did not honor bounded range: ' + json.dumps(info))
        raw = response.read(length + 1)
        assert len(raw) == length
        print('RANGE', json.dumps({'start': start, 'length': length, 'sha256': hashlib.sha256(raw).hexdigest()}))
        return raw

tail = read_range(size - 65536, 65536)
eocd = tail.rfind(b'PK\x05\x06')
assert eocd >= 0
_, _, _, _, count, cdsize, cdoffset, _ = struct.unpack_from('<4s4H2LH', tail, eocd)
assert cdsize <= 2 * 1024 * 1024
central = read_range(cdoffset, cdsize)
(out / 'central-directory.bin').write_bytes(central)
offset = 0
entries = []
while offset < len(central):
    header = struct.unpack_from('<4s6H3L5H2L', central, offset)
    assert header[0] == b'PK\x01\x02'
    method, compressed, rawsize = header[4], header[8], header[9]
    namelen, extralen, commentlen = header[10:13]
    name = central[offset+46:offset+46+namelen].decode()
    if name in ['codeql/codeql', 'codeql/tools/codeql-launcher.sh']:
        entries.append((name, method, compressed, rawsize, header[-1]))
    offset += 46 + namelen + extralen + commentlen
print('CENTRAL', json.dumps({'entries': count, 'selected': entries}))
assert any(x[0] == 'codeql/codeql' for x in entries)
for name, method, compressed, rawsize, localoffset in entries:
    header = read_range(localoffset, 30)
    parsed = struct.unpack('<4s5H3L2H', header)
    assert parsed[0] == b'PK\x03\x04' and compressed < 65536 and rawsize < 65536
    content = read_range(localoffset + 30 + parsed[-2] + parsed[-1], compressed)
    raw = zlib.decompress(content, -15) if method == 8 else content
    assert len(raw) == rawsize
    (out / Path(name).name).write_bytes(raw)
    print('LAUNCHER', name, len(raw), hashlib.sha256(raw).hexdigest())
    print(raw.decode())
