from pathlib import Path
import hashlib
import json
import struct
import urllib.request
import zipfile
import zlib

out = Path('/tmp/issue-1580-research/codeql-2.27.5-launcher')
release = json.loads((out / 'release.stdout').read_text())
asset = next(x for x in release['assets'] if x['name'] == 'codeql-linux64.zip')
central = (out / 'central-directory.bin').read_bytes()
offset = 0
while offset < len(central):
    item = struct.unpack_from('<4s6H3L5H2L', central, offset)
    length, extra, comment = item[10:13]
    if central[offset+46:offset+46+length] == b'codeql/tools/codeql.jar':
        break
    offset += 46 + length + extra + comment
else:
    raise RuntimeError('Missing exact release jar')
assert item[4] == 8 and item[8] < 32 * 1024 * 1024 and item[9] < 32 * 1024 * 1024

def read_range(start, length):
    assert 0 < length <= 2 * 1024 * 1024
    request = urllib.request.Request(asset['browser_download_url'], headers={'Range': f'bytes={start}-{start+length-1}'})
    with urllib.request.urlopen(request) as response:
        if response.status != 206 or not response.headers.get('Content-Range', '').startswith(f'bytes {start}-'):
            raise RuntimeError('Server refused bounded range')
        raw = response.read(length + 1)
        assert len(raw) == length
        return raw

jar = out / 'codeql.jar'
if not jar.is_file():
    header = struct.unpack('<4s5H3L2H', read_range(item[-1], 30))
    start = item[-1] + 30 + header[-2] + header[-1]
    decompressor = zlib.decompressobj(-15)
    with jar.open('wb') as destination:
        for delta in range(0, item[8], 2 * 1024 * 1024):
            chunk = read_range(start + delta, min(2 * 1024 * 1024, item[8] - delta))
            destination.write(decompressor.decompress(chunk))
        destination.write(decompressor.flush())
    assert jar.stat().st_size == item[9]
digest = hashlib.sha256()
with jar.open('rb') as stream:
    for chunk in iter(lambda: stream.read(65536), b''):
        digest.update(chunk)
print('JAR', json.dumps({'bytes': jar.stat().st_size, 'sha256': digest.hexdigest(), 'execution': False}))
with zipfile.ZipFile(jar) as archive:
    selected = [name for name in archive.namelist() if name.endswith('.class') and
                any(key in name for key in ['QueryRun', 'RamOptions', 'RAMOptions', 'MemoryOptions', 'RamResolver', 'JavaHeap', 'JvmOptions'])]
    print('CLASSES', json.dumps(selected))
    warning = []
    for info in archive.infolist():
        if info.filename.endswith('.class') and info.file_size <= 1024 * 1024:
            raw = archive.read(info)
            if b'Not caching stages' in raw:
                warning.append(info.filename)
                target = out / Path(info.filename).name
                target.write_bytes(raw)
    print('WARNING_CLASSES', json.dumps(warning))
    (out / 'selected-memory-classes.json').write_text(json.dumps(selected + warning, indent=2) + '\n')
