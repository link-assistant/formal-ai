import gzip
import json
from pathlib import Path

root = Path('experiments/issue-1580/evidence/ci/codeql-producer-90b51590')
for name in ['producer-14663201503-macro-contexts_manifest.json.gz',
             'producer-14663201503-macro-contexts_query.stdout.gz',
             'producer-14663201503-macro-contexts_query.stderr.gz',
             'producer-14663201503-macro-contexts_version.stdout.gz']:
    print('FILE', name)
    raw = gzip.decompress((root / name).read_bytes()).decode()
    print(raw)
for path in sorted(root.glob('job-*.stdout.gz')):
    lines = gzip.decompress(path.read_bytes()).decode().splitlines()
    hits = [i for i, line in enumerate(lines) if any(word in line for word in
            ['Xmx', 'off-heap', 'heap size', 'resolve ram', 'Running queries', 'query-loading'])]
    if not hits:
        continue
    print('JOB', path.name, 'lines', len(lines))
    shown = set()
    for hit in hits:
        for i in range(max(0, hit - 2), min(len(lines), hit + 3)):
            if i not in shown:
                print(f'{i+1}: {lines[i]}')
                shown.add(i)
