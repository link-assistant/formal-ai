import re
from pathlib import Path

before_log = Path('/tmp/issue-1580-research/codeql-memory-policy-before.log').read_text()
assert re.search(r'(?:#|ℹ) pass 18\b', before_log)
assert re.search(r'(?:#|ℹ) fail 1\b', before_log)
assert 'CodeQL query failed with exit 1' in before_log
print('Original producer fails the one changed contract; 18 unrelated contracts pass. The earlier summary parser incorrectly assumed TAP.')

adapter = Path('experiments/issue-1580/codeql-macro-contexts/observe.py')
source = adapter.read_text()
before = '        run("version", ["version", "--format=json"])\n'
after = '''        run("version", ["version", "--format=json"])
        # query run sizes a child evaluator again; a launcher -J heap is not inherited.
        # Resolve the same real dataset policy first, preserving its authoritative output.
        memory_options = ["--ram=4096", "--off-heap-ram=0"]
        dataset = database / "db-rust"
        if not dataset.is_dir():
            raise ValueError("Missing completed Rust dataset for memory resolution")
        run("memory", ["resolve", "ram", "--format=json", "--dataset=" + str(dataset), *memory_options])
        resolved = json.loads((output / "memory.stdout").read_text())
        if not isinstance(resolved, list) or not all(isinstance(value, str) for value in resolved):
            raise ValueError("Malformed CodeQL memory resolution")
        heaps = [re.fullmatch(r"-J=?-Xmx([1-9][0-9]*)([mMgG])", value) for value in resolved]
        heaps = [match for match in heaps if match]
        heap_mib = int(heaps[0][1]) * (1024 if heaps[0][2].lower() == "g" else 1) if len(heaps) == 1 else 0
        manifest["resolvedMemory"] = {"totalMiB": 4096, "offHeapMiB": 0,
                                      "heapMiB": heap_mib, "arguments": resolved}
        if not 2048 <= heap_mib <= 4096 or any(value.startswith("--off-heap-ram=") and
                                             value != "--off-heap-ram=0" for value in resolved):
            raise ValueError("CodeQL resolved heap cannot cache loading stages inside the requested policy")
'''
assert source.count(before) == 1
source = source.replace(before, after)
before = '''                          # --ram bounds the evaluator; the CLI loading heap has its own cap.
                          "-J-Xmx3072m", "--threads=2", "--ram=4096", "--max-disk-cache=512",
'''
after = '''                          "--threads=2", *memory_options, "--max-disk-cache=512",
'''
assert source.count(before) == 1
source = source.replace(before, after)
before = '''        run("decode", ["bqrs", "decode", "--format=json", "--entities=all",
'''
after = '''        diagnostics = [line for line in (output / "query.stderr").read_text().splitlines()
                       if re.match(r"^(?:WARNING|WARN|ERROR):", line)]
        manifest["queryRuntimeDiagnostics"] = diagnostics
        if diagnostics:
            raise RuntimeError("CodeQL query emitted runtime diagnostics; see preserved query.stderr")
        run("decode", ["bqrs", "decode", "--format=json", "--entities=all",
'''
assert source.count(before) == 1
source = source.replace(before, after)
adapter.write_text(source)

test = Path('rust/tests/web/security-codeql-results.test.mjs')
source = test.read_text()
before = "    pathlib.Path(next(a.removeprefix('--output=') for a in args if a.startswith('--output='))).write_bytes(b'fixture BQRS')"
after = "    if mode=='query-warning':\n        print('WARNING: fixture runtime allocation incomplete',file=sys.stderr)\n" + before
assert source.count(before) == 1
source = source.replace(before, after)
source = source.replace("'query-failure','decode-failure','empty','malformed','missing-database','ambiguous-pack']:",
                        "'query-failure','query-warning','decode-failure','empty','malformed','missing-database','ambiguous-pack']:")
before = "        if mode=='query-failure':\n            assert result['commands']"
after = """        if mode=='query-warning':
            assert result['queryRuntimeDiagnostics']==['WARNING: fixture runtime allocation incomplete']
            assert result['commands'][-1]['name']=='query'
            assert not any(call[:2]==['bqrs','decode'] for call in calls)
            assert (output/'macro-contexts.bqrs').read_bytes()==b'fixture BQRS'
        if mode=='query-failure':
            assert result['commands']"""
assert source.count(before) == 1
source = source.replace(before, after)
source = source.replace("        if mode=='success':\n            assert result['resolvedMemory']", "        if mode=='success':\n            assert result['queryRuntimeDiagnostics']==[]\n            assert result['resolvedMemory']")
test.write_text(source)
print('Implemented one shared 4 GiB/zero-off-heap resolver policy, failure-preserving preflight and visible runtime diagnostics.')
