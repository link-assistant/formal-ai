from pathlib import Path

test = Path('rust/tests/web/security-codeql-results.test.mjs')
source = test.read_text()
Path('/tmp/issue-1580-research/security-codeql-results-before-memory-policy.test.mjs').write_text(source)
replacements = [
    ("    database.mkdir()\n    (database / 'codeql-database.yml')", "    database.mkdir()\n    (database / 'db-rust').mkdir()\n    (database / 'codeql-database.yml')"),
    ("args=sys.argv[1:]\nif args[0]=='version':", "args=sys.argv[1:]\nwith (root/'calls.jsonl').open('a') as stream:\n    print(json.dumps(args),file=stream)\nif args[0]=='version':"),
    ("elif args[:2]==['query','run']:\n    assert '--threads=2'", """elif args[:2]==['resolve','ram']:
    assert '--ram=4096' in args and '--off-heap-ram=0' in args
    assert pathlib.Path(next(a.removeprefix('--dataset=') for a in args if a.startswith('--dataset='))).name=='db-rust'
    assert '--format=json' in args
    if mode=='memory-failure':
        print('actual fixture memory failure',file=sys.stderr)
        sys.exit(6)
    values={'undersized-heap':['-J-Xmx1800M'],'excessive-heap':['-J-Xmx8G'],
            'missing-heap':[],'malformed-memory':{'heap':'unknown'},
            'nonzero-offheap':['-J-Xmx2400M','--off-heap-ram=512']}
    print(json.dumps(values.get(mode,['-J-Xmx2400M'])))
elif args[:2]==['query','run']:
    assert '--threads=2'"""),
    ("    assert '-J-Xmx3072m' in args, 'query loading needs an explicit heap inside the total evaluator budget'", "    assert '--off-heap-ram=0' in args, 'the child evaluator must resolve the same heap-only policy'\n    assert not any(a.startswith('-J') for a in args), 'launcher heap flags do not survive child sizing'"),
    ("for mode in ['success','query-failure','decode-failure','empty','malformed','missing-database','ambiguous-pack']:", "for mode in ['success','memory-failure','undersized-heap','excessive-heap','missing-heap','malformed-memory','nonzero-offheap',\n                 'query-failure','decode-failure','empty','malformed','missing-database','ambiguous-pack']:"),
    ("        (root / 'mode').write_text(mode)\n        output =", "        (root / 'mode').write_text(mode)\n        (root / 'calls.jsonl').write_text('')\n        output ="),
    ("        if mode=='query-failure':\n            assert result['commands']", """        calls=[json.loads(line) for line in (root/'calls.jsonl').read_text().splitlines()]
        if mode in ['memory-failure','undersized-heap','excessive-heap','missing-heap','malformed-memory','nonzero-offheap']:
            assert not any(call[:2]==['query','run'] for call in calls), mode
        if mode=='memory-failure':
            assert result['commands'][-1]['exitCode']==6
            assert (output/'memory.stderr').read_text()=='actual fixture memory failure\\n'
        if mode=='query-failure':
            assert result['commands']"""),
    ("        if mode=='success':\n            assert result['rows']==1", "        if mode=='success':\n            assert result['resolvedMemory']=={'totalMiB':4096,'offHeapMiB':0,'heapMiB':2400,'arguments':['-J-Xmx2400M']}\n            assert [command['name'] for command in result['commands']]==['version','memory','query','decode']\n            assert result['rows']==1")
]
for before, after in replacements:
    assert source.count(before) == 1, before
    source = source.replace(before, after)
test.write_text(source)
print('Drafted resolver, budget, failure propagation and exact dataset controls; production is unchanged.')
