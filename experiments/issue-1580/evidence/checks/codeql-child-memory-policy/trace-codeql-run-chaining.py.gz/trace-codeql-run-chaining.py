from pathlib import Path
import json
import subprocess
import zipfile

out = Path('/tmp/issue-1580-research/codeql-2.27.5-launcher')
with zipfile.ZipFile(out / 'codeql.jar') as archive:
    selected = ['com/semmle/cli2/ql/RunCommand.class']
    for info in archive.infolist():
        if info.filename.startswith('com/semmle/cli2/') and info.filename.endswith('.class') and info.file_size < 1048576:
            raw = archive.read(info)
            if b'ResolveRamCommand' in raw and not '/resolve/ResolveRamCommand' in info.filename:
                selected.append(info.filename)
for name in sorted(set(selected)):
    target = out / (name.rsplit('/', 1)[-1].removesuffix('.class') + '.javap')
    with target.open('wb') as stdout, target.with_suffix('.stderr').open('wb') as stderr:
        result = subprocess.run(['javap', '-J-Xmx128m', '-c', '-p', '-classpath', str(out / 'codeql.jar'), name.removesuffix('.class').replace('/', '.')], stdout=stdout, stderr=stderr)
    print(json.dumps({'class': name, 'exitCode': result.returncode, 'lines': sum(1 for _ in target.open())}))
    result.check_returncode()
