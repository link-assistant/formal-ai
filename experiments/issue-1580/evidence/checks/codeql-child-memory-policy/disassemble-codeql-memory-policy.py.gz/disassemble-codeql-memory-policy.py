from pathlib import Path
import json
import shutil
import subprocess

out = Path('/tmp/issue-1580-research/codeql-2.27.5-launcher')
javap = shutil.which('javap')
assert javap, 'No javap available; no package installation authorized by this probe'
for name in ['com.semmle.cli2.RamOptions', 'com.semmle.cli2.execute.ExecuteQueriesCommand']:
    destination = out / (name.rsplit('.', 1)[-1] + '.javap')
    with destination.open('wb') as stdout, destination.with_suffix('.stderr').open('wb') as stderr:
        result = subprocess.run([javap, '-J-Xmx128m', '-c', '-p', '-classpath', str(out / 'codeql.jar'), name], stdout=stdout, stderr=stderr)
    print(json.dumps({'class': name, 'exitCode': result.returncode, 'lines': sum(1 for _ in destination.open()), 'path': str(destination)}))
    result.check_returncode()
