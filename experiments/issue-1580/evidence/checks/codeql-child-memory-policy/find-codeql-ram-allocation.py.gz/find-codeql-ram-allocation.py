from pathlib import Path
import json
import subprocess
import zipfile

out = Path('/tmp/issue-1580-research/codeql-2.27.5-launcher')
with zipfile.ZipFile(out / 'codeql.jar') as archive:
    names = [n for n in archive.namelist() if n.startswith('com/semmle/cli2/') and n.endswith('.class') and
             any(k in n for k in ['RunCommand', 'Ram', 'RAM', 'JVM', 'Jvm', 'Chainer', 'Chaining'])]
    print('CANDIDATES', json.dumps(names))
    selected = []
    for name in names:
        raw = archive.read(name)
        if any(key in raw for key in [b'Xmx', b'offHeapRam', b'resolveRam', b'restartWith']):
            selected.append(name)
for name in selected:
    target = out / (name.rsplit('/', 1)[-1].removesuffix('.class') + '.javap')
    with target.open('wb') as stdout, target.with_suffix('.stderr').open('wb') as stderr:
        result = subprocess.run(['javap', '-J-Xmx128m', '-c', '-p', '-classpath', str(out / 'codeql.jar'), name.removesuffix('.class').replace('/', '.')], stdout=stdout, stderr=stderr)
    print('DISASSEMBLED', name, result.returncode, sum(1 for _ in target.open()))
    result.check_returncode()
