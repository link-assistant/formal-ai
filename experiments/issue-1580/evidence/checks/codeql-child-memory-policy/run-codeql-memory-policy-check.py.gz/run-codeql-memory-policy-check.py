import json
import os
from pathlib import Path
import subprocess
import sys

phase = sys.argv[1]
assert phase in ['before', 'after']
out = Path('/tmp/issue-1580-research')
target = out / ('codeql-memory-policy-' + phase + '.log')
env = {**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}
env.pop('NODE_TEST_CONTEXT', None)
with target.open('wb') as stream:
    result = subprocess.run(['node', '--test', '--test-concurrency=1', 'rust/tests/web/security-codeql-results.test.mjs'], env=env, stdout=stream, stderr=subprocess.STDOUT)
print(json.dumps({'phase': phase, 'exitCode': result.returncode, 'log': str(target)}))
print(target.read_text())
if phase == 'before':
    assert result.returncode == 1
    assert '# pass 18' in target.read_text() and '# fail 1' in target.read_text()
else:
    result.check_returncode()
