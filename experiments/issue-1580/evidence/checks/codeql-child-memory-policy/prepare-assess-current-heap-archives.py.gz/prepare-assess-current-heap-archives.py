from pathlib import Path
import subprocess
scratch=Path('/tmp/issue-1580-research');root=Path('/tmp/gh-issue-solver-1794900398048')
source=(scratch/'assess-pages-queue-producer.py').read_text().replace('codeql-producer-1d7ba479','codeql-producer-90b51590').replace('assess-pages-queue-macro-observations','assess-current-explicit-heap-macro-observations')
target=scratch/'assess-current-explicit-heap-archives.py';target.write_text(source)
result=subprocess.run(['python3',str(target)],cwd=root,capture_output=True)
for label in ['stdout','stderr']:(scratch/('assess-current-explicit-heap-archives.'+label)).write_bytes(getattr(result,label))
print('Archive/stream assessment status',result.returncode);print(result.stdout.decode());print(result.stderr.decode());raise SystemExit(result.returncode)
