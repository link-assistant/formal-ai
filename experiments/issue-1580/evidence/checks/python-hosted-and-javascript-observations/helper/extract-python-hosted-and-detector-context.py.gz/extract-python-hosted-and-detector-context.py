from pathlib import Path
import re, json, subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/python-current-hosted-logs')
for name,pattern in [('workflows',r'npm (ci|run build)|git diff|ncc|tests |pass |fail |Round.trip|round.trip|Upload|Download|diff -r|artifact.?id|deprecat|vulnerabil|warning|error'),('security',r'Auditing|npm audit|vulnerabil|deprecat|warning|error|found 0|GHSA|PYSEC')]:
 lines=(out/(name+'-full-log.stdout')).read_text().splitlines();selected=set()
 for index,line in enumerate(lines):
  if re.search(pattern,line,re.I):selected.update(range(max(0,index-3),min(len(lines),index+6)))
 rows=[]
 for index in sorted(selected):
  text=re.sub(r'^.*?\t[^\t]+\t\ufeff?\d{4}-\d\d-\d\dT\S+\s*','',lines[index])
  text=re.sub(r'\x1b\[[0-9;]*m','',text)
  rows.append(f'{index+1}: {text}')
 (out/(name+'-context.txt')).write_text('\n'.join(rows)+'\n')
 print(json.dumps({'name':name,'selectedLines':len(rows),'totalLines':len(lines)}))
report=Path('/tmp/issue-1580-research/python-javascript-detection');report.mkdir(exist_ok=True)
for label,args in [('issue-107',['gh','issue','view','107','--repo','link-foundation/python-ai-driven-development-pipeline-template','--json','title,body,url']),('issue-107-comments',['gh','api','repos/link-foundation/python-ai-driven-development-pipeline-template/issues/107/comments','--paginate']),('current-issues',['gh','api','repos/link-foundation/python-ai-driven-development-pipeline-template/issues?state=all&per_page=100','--paginate'])]:
 result=subprocess.run(args,cwd=root,capture_output=True);(report/(label+'.stdout')).write_bytes(result.stdout);(report/(label+'.stderr')).write_bytes(result.stderr);assert result.returncode==0
 if label=='issue-107':(report/(label+'.txt')).write_text(json.dumps(json.loads(result.stdout),indent=2)+'\n')
 if label=='current-issues':
  issues=[item for item in json.loads(result.stdout) if 'pull_request' not in item]
  (report/'all-titles.txt').write_text('\n'.join(f"{item['number']}: {item['title']}" for item in issues)+'\n')
  related=[item for item in issues if re.search(r'javascript|\.mjs|\.cjs|detect_code_changes|CODE_EXTENSIONS',item['title']+'\n'+(item['body'] or ''),re.I)]
  (report/'related-bodies.txt').write_text('\n\n'.join(f"#{item['number']} {item['title']}\n{item['body']}" for item in related)+'\n')
  print(json.dumps({'allIssueTitles':len(issues),'relatedBodies':len(related)}))
