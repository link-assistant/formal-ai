from pathlib import Path
import json, subprocess, sys, hashlib, time
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/python-current-hosted-logs')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('wb') as stream:
  process=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':process.pid})+'\n')
 print(json.dumps({'pid':process.pid,'runs':4}));raise SystemExit(0)
repository='link-foundation/python-ai-driven-development-pipeline-template'
expected='62cc393707ddfe7ceeddbc580d43cc35334636f1'
records=[]
for name,run in [('workflows',44857673628),('security',44857673553),('documentation',44857673603),('links',44857673636)]:
 arguments=['gh','run','view',str(run),'--repo',repository]
 for suffix,extra in [('metadata',['--json','headSha,status,conclusion,jobs,url,createdAt,updatedAt']),('full-log',['--log'])]:
  with (out/(name+'-'+suffix+'.stdout')).open('wb') as stdout,(out/(name+'-'+suffix+'.stderr')).open('wb') as stderr:
   result=subprocess.run(arguments+extra,cwd=root,stdout=stdout,stderr=stderr)
  record={'name':name,'kind':suffix,'runId':run,'exitCode':result.returncode}
  assert result.returncode==0,record
  data=(out/(name+'-'+suffix+'.stdout')).read_bytes()
  record.update({'bytes':len(data),'lines':len(data.splitlines()),'sha256':hashlib.sha256(data).hexdigest()})
  if suffix=='metadata':
   metadata=json.loads(data);assert metadata['headSha']==expected,metadata
   assert metadata['status']=='completed' and metadata['conclusion']=='success',metadata
   record['jobs']=[{'name':job['name'],'status':job['status'],'conclusion':job['conclusion']} for job in metadata['jobs']]
  records.append(record)
  (out/'partial.json').write_text(json.dumps(records,indent=2)+'\n')
  print(json.dumps(record),flush=True)
(out/'outcome.json').write_text(json.dumps({'head':expected,'repository':repository,'records':records,'allDownloaded':True,'fullTemplateReviewComplete':False,'fullIssueComplete':False},indent=2)+'\n')
