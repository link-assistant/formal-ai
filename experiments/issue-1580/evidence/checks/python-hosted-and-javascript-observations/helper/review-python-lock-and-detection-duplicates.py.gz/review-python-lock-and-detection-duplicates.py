from pathlib import Path
import json,re,hashlib,base64,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
source=Path('/tmp/issue-1580-research/fresh-template-delta-sources/files/python')
out=Path('/tmp/issue-1580-research/python-current-hosted-logs')
lock=json.loads((source/'.github/actions/artifact/package-lock.json').read_bytes())
manifest=json.loads((source/'.github/actions/artifact/package.json').read_bytes())
assert lock['lockfileVersion']==3
assert lock['packages']['']['dependencies']==manifest['dependencies']
assert lock['packages']['']['devDependencies']==manifest['devDependencies']
assert lock['packages']['']['engines']==manifest['engines']
rows=[];special=[]
for path,item in lock['packages'].items():
 if not path:continue
 assert re.fullmatch(r'https://registry\.npmjs\.org/.+\.tgz',item['resolved']),(path,item)
 algorithm,digest=item['integrity'].split('-',1)
 assert algorithm=='sha512' and len(base64.b64decode(digest,validate=True))==64,(path,item)
 unexpected=set(item)-{'version','resolved','integrity','license','dependencies','engines','dev','optional','funding','bin','hasInstallScript','peerDependencies','peerDependenciesMeta','deprecated','os','cpu','devOptional'}
 if unexpected or item.get('hasInstallScript') or item.get('deprecated'):
  special.append({'path':path,'unexpectedKeys':sorted(unexpected),'hasInstallScript':item.get('hasInstallScript',False),'deprecated':item.get('deprecated')})
 rows.append(f"{path}: {item['version']} | {item.get('license','UNSPECIFIED')} | node={item.get('engines',{}).get('node','unspecified')} | dependencies={len(item.get('dependencies',{}))} | {'dev' if item.get('dev') else 'runtime'}")
(out/'lock-packages.txt').write_text('\n'.join(rows)+'\n')
(out/'lock-summary.json').write_text(json.dumps({'lockVersion':3,'packages':len(rows),'rootManifestAgrees':True,'registryTarballsAndSha512':len(rows),'special':special,'allGraphEdgesSemanticallyReviewed':False,'literalLockReviewComplete':False,'fullIssueComplete':False},indent=2)+'\n')
with (out/'npm-lock-graph.stdout').open('wb') as stdout,(out/'npm-lock-graph.stderr').open('wb') as stderr:
 result=subprocess.run(['node','--max-old-space-size=256','/usr/local/lib/node_modules/npm/bin/npm-cli.js','ls','--all','--package-lock-only','--json','--prefix',str(source/'.github/actions/artifact')],cwd=root,stdout=stdout,stderr=stderr)
print(json.dumps({'packages':len(rows),'special':special,'localNpmGraphExit':result.returncode}))
report=Path('/tmp/issue-1580-research/python-javascript-detection')
issues=[item for item in json.loads((report/'current-issues.stdout').read_bytes()) if 'pull_request' not in item]
excerpts=[]
for item in issues:
 text=item['title']+'\n'+(item['body'] or '')
 matches=list(re.finditer(r'(?i)javascript|(?<![A-Za-z])\.mjs|(?<![A-Za-z])\.cjs|CODE_EXTENSIONS',text))
 if matches:excerpts.append(f"#{item['number']} {item['title']}\n"+'\n'.join(text[max(0,m.start()-160):m.end()+240] for m in matches))
(report/'narrow-duplicate-excerpts.txt').write_text('\n\n'.join(excerpts)+'\n')
item=next(item for item in issues if item['number']==145)
(report/'issue-145.txt').write_text(item['title']+'\n\n'+item['body']+'\n')
print(json.dumps({'narrowRelevantIssues':len(excerpts)}))
