from pathlib import Path
import json,os,shutil,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/python-javascript-detection')
assert json.loads((out/'focused-outcome.json').read_text())['exitCode']==0
body="""At template commit __BT__62cc393707ddfe7ceeddbc580d43cc35334636f1__BT__, JavaScript production helpers are omitted from the code-change outputs used by the release pipeline.

[The detector's extension list](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/blob/62cc393707ddfe7ceeddbc580d43cc35334636f1/scripts/detect_code_changes.py#L49) counts Python, shell, JSON, TOML and YAML, but omits __BT__.mjs__BT__, __BT__.js__BT__ and __BT__.cjs__BT__. The repository now executes JavaScript helpers, including __BT__scripts/check-deprecated-packages.mjs__BT__, __BT__.github/actions/artifact/index.mjs__BT__ and __BT__.github/actions/deploy-pages/deploy.mjs__BT__.

This is a follow-up to the fixed shell/JSON gap in #107. It is separate from #145's file-size coverage and #156's Git-failure propagation.

### Reproduce

From a checkout of the pinned template, run this finite probe of the actual classifier:

__BT____BT____BT__sh
python3 - <<'PY'
import importlib.util
spec = importlib.util.spec_from_file_location('detector', 'scripts/detect_code_changes.py')
detector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(detector)
for event in ('push', 'pull_request'):
    for path in ('scripts/check-deprecated-packages.mjs',
                 '.github/actions/artifact/index.mjs',
                 '.github/actions/deploy-pages/deploy.mjs',
                 'scripts/helper.js', 'scripts/helper.cjs'):
        print(event, path, detector.detect_change_types([path], event_name=event))
PY
__BT____BT____BT__

Every row reports __BT__{'any-code-changed': False, 'docs-changed': False}__BT__.

I also ran the actual script entrypoint with real Git, using disposable two-commit repositories and each of __BT__.mjs__BT__, __BT__.js__BT__ and __BT__.cjs__BT__ as the sole changed path. Both the push comparison and full-history pull-request comparison list the changed helper correctly, then write:

__BT____BT____BT__text
any-code-changed=false
docs-changed=false
__BT____BT____BT__

The tested source SHA256 is __BT__9e81f8022496676bb6b1f6459acef243f72fb7e39d8f47b5b2ed250843b0894f__BT__; Python 3.15.0 was used. The source and Git observations are real; no Git or detector behavior was mocked.

### Impact and fix

The release workflow uses __BT__any-code-changed__BT__ to gate changelog validation, lint, tests and build. A JavaScript-only change therefore skips those gates. Additionally, the separate Workflows workflow's path filter does not match __BT__scripts/*.mjs__BT__, so editing __BT__scripts/check-deprecated-packages.mjs__BT__ alone does not trigger that workflow either. The Security workflow still runs; this report does not claim all checks are skipped.

Add JavaScript module extensions to __BT__CODE_EXTENSIONS__BT__ and cover the JavaScript helper paths in the Workflows triggers. A disposable candidate extending only the classifier with __BT__.js__BT__, __BT__.mjs__BT__, __BT__.cjs__BT__ produces __BT__any-code-changed=true__BT__ in both real Git comparisons, preserves the existing Python/shell/JSON/TOML/YAML controls, and preserves documentation, example, experiment, changelog and development-log exclusions.

Three bounded Node regression cases cover the actual classifier, the real Git entrypoint and exclusion controls. They are committed with source/license identities in downstream PR https://github.com/link-assistant/formal-ai/pull/1581; a permanent test link will follow after its current CI round ends and the evidence is pushed. No upstream repair has been applied.
"""
body=body.replace('__BT__',chr(96));(out/'report-body.md').write_text(body)
repository='link-foundation/python-ai-driven-development-pipeline-template'
command=['gh','issue','create','--repo',repository,'--title','JavaScript-only CI helper changes produce no-code outputs and skip release checks','--body-file',str(out/'report-body.md')]
result=subprocess.run(command,cwd=root,capture_output=True)
(out/'create.stdout').write_bytes(result.stdout);(out/'create.stderr').write_bytes(result.stderr)
assert result.returncode==0,result.stderr.decode()
url=result.stdout.decode().strip();assert url.startswith('https://github.com/'+repository+'/issues/'),url
(out/'created.json').write_text(json.dumps({'url':url,'sourceCommit':'62cc393707ddfe7ceeddbc580d43cc35334636f1','upstreamRepairApplied':False,'testFile':'experiments/issue-1580/template-python-javascript-detection.test.mjs','fullIssueComplete':False},indent=2)+'\n')
print(json.dumps({'created':url}))
hosted=Path('/tmp/issue-1580-research/python-current-hosted-logs')
binary=shutil.which('npm');assert binary
with (hosted/'npm-lock-graph-retry.stdout').open('wb') as stdout,(hosted/'npm-lock-graph-retry.stderr').open('wb') as stderr:
 retry=subprocess.run(['node','--max-old-space-size=256',str(Path(binary).resolve()),'ls','--all','--package-lock-only','--json','--prefix','/tmp/issue-1580-research/fresh-template-delta-sources/files/python/.github/actions/artifact'],cwd=root,stdout=stdout,stderr=stderr)
(hosted/'npm-lock-graph-retry.json').write_text(json.dumps({'npmExecutable':binary,'realExecutable':str(Path(binary).resolve()),'exitCode':retry.returncode,'noInstallation':True,'noNativeBuild':True},indent=2)+'\n')
print(json.dumps({'npmGraphExit':retry.returncode}))
