from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
hosted=scratch/'python-current-hosted-logs';detection=scratch/'python-javascript-detection'
upstream=json.loads((detection/'created.json').read_text())['url']
assert upstream=='https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/166'
assert json.loads((detection/'focused-outcome.json').read_text())['exitCode']==0
assert json.loads((hosted/'npm-lock-graph-retry.json').read_text())['exitCode']==0
graph=json.loads((hosted/'npm-lock-graph-retry.stdout').read_bytes());nodes=0;problems=[]
def visit(value,path):
 global nodes
 if not isinstance(value,dict):return
 if value.get('version'):nodes+=1
 for key in ['problems','invalid','missing','extraneous']:
  if value.get(key):problems.append({'path':path,'key':key,'value':value[key]})
 for name,child in value.get('dependencies',{}).items():visit(child,path+'/'+name)
visit(graph,'root');assert not problems,problems
summary=json.loads((hosted/'lock-summary.json').read_text())
summary.update({'npmPackageLockOnlyGraphExit':0,'npmGraphNodesIncludingRepeatedEdges':nodes,'npmGraphProblems':problems,'packageIdentityRowsReviewed':247,'hostedCleanInstallAndBundleMatch':True,'hostedArtifactTestsPassed':21,'hostedDeploymentMockTestsPassed':30,'hostedActualArtifactRoundTrips':2,'hostedRegistryVersionsChecked':245,'hostedRegistryUnanswered':0,'hostedRegistryDeprecated':0,'hostedNpmVulnerabilities':0})
(hosted/'lock-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
target=root/'experiments/issue-1580/evidence/checks/python-hosted-and-javascript-observations';target.mkdir(exist_ok=False);records=[]
def retain(path,name):
 raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);alias=name+'.gz';destination=target/alias;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed)
 records.append({'source':str(path),'file':alias,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
for path in sorted(hosted.iterdir()):
 if path.is_file():retain(path,'hosted/'+path.name)
for name in ['current-issues.stdout','current-issues.stderr','all-titles.txt','narrow-duplicate-excerpts.txt','issue-107.txt','issue-107-comments.stdout','issue-107-comments.stderr','issue-145.txt','focused.stdout','focused.stderr','focused-outcome.json','report-body.md','create.stdout','create.stderr','created.json']:
 retain(detection/name,'detector/'+name)
for name in ['collect-python-current-hosted-logs','extract-python-hosted-and-detector-context','review-python-lock-and-detection-duplicates','draft-python-javascript-detection','publish-python-javascript-detection-report','seal-python-hosted-and-javascript-observations']:
 retain(scratch/(name+'.py'),'helper/'+name+'.py')
 if name!='seal-python-hosted-and-javascript-observations':retain(scratch/(name+'.log'),'helper/'+name+'.log')
for row in records:
 archive=(target/row['file']).read_bytes();raw=gzip.decompress(archive)
 assert hashlib.sha256(archive).hexdigest()==row['archiveSha256'] and hashlib.sha256(raw).hexdigest()==row['rawSha256']
(target/'records.json').write_text(json.dumps({'records':records,'allHashesVerified':True,'actualGitRegressionCasesPassed':3,'hostedHead':'62cc393707ddfe7ceeddbc580d43cc35334636f1','fullTemplateComparisonComplete':False,'upstreamRepairApplied':False,'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
ledger=root/'docs/case-studies/issue-1580/templates/python-current-delta-review.json';data=json.loads(ledger.read_text())
data['javascriptDetectionObservation']={'sourceSha256':'9e81f8022496676bb6b1f6459acef243f72fb7e39d8f47b5b2ed250843b0894f','testFile':'experiments/issue-1580/template-python-javascript-detection.test.mjs','testsPassed':3,'actualPython':True,'actualGit':True,'events':['push','pull_request'],'candidatePreservesExclusions':True,'upstreamReport':upstream,'upstreamRepairApplied':False}
data['hostedArtifactValidation']={'run':44857673628,'head':data['commit'],'conclusion':'success','dependencyPackages':247,'rootManifestAgrees':True,'registryTarballsAndSha512Validated':247,'actualNpmCleanInstall':True,'generatedBundleAndLicensesMatchSourceAndLock':True,'artifactTestsPassed':21,'deploymentMockTestsPassed':30,'actualArtifactRoundTrips':2,'livePagesDeploymentVerified':False}
data['hostedDependencyAudit']={'run':44857673553,'conclusion':'success','npmVulnerabilities':0,'registryVersionsChecked':245,'registryDeprecated':0,'registryUnanswered':0,'actualPythonDependencyAudit':True}
data['generatedArtifactComparisonComplete']=True
for row in data['changedFiles']:
 if row['path'].endswith('dist/index.mjs'):row['assessment']='Pinned hosted clean install and actual ncc rebuild match the committed bundle and licenses; actual byte/empty-file and Pages-tar round trips pass. Literal minified-source review remains incomplete.'
 if row['path'].endswith('package-lock.json'):row['assessment']='All 247 package identities, licenses and Node engine rows reviewed; registry tarball/SHA512 shape and manifest agreement checked; actual npm lock-only graph, hosted clean install, vulnerability audit and live deprecation inventory pass. Literal lockfile and every graph-edge semantic review remain incomplete.'
data['currentHostedEvidence']=str(target.relative_to(root));ledger.write_text(json.dumps(data,indent=2)+'\n')
doc=root/'docs/case-studies/issue-1580/python-current-findings-checkpoint.md'
with doc.open('a') as stream:stream.write("""

The current Python detector has a separate confirmed false negative: production
JavaScript module edits set both outputs false on pushes and pull requests.
Three maintained cases run the pinned classifier and real Git entrypoint,
then compare a disposable extension-list candidate and retained exclusion
controls. They pass without skips. Upstream
[issue #166](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/166)
records this follow-up to the fixed shell/JSON issue #107. JavaScript helpers
under scripts also miss the separate Workflows path filter. The Security
workflow still runs. No upstream repair is claimed.

Pinned [Workflows run 44857673628](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/actions/runs/44857673628)
provides actual generated-artifact qualification. Full-log lines 529–543 show
the 247-package clean install; lines 629–654 show ncc 0.45.0 rebuilding dist
and a successful exact Git diff, including licenses. Its 21 artifact and 30
mocked Pages-deployment cases pass. Lines 655–767 show real byte/empty-file
and Pages-tar upload/download/diff round trips with matching SHA256 receipts.
This proves artifact transport; it does not prove live Pages deployment.

All 247 lock package identity/license/Node-engine rows are reviewed. Every
resolved URL is an npm registry tarball with a correctly formed SHA512 digest;
root dependency and engine declarations agree with package.json. Actual npm
lock-only graph validation succeeds without installation. Its first attempted
invocation used an incorrect npm location; the captured failure and resolved
executable retry remain distinct. The pinned
[Security run 44857673553](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/actions/runs/44857673553)
reports zero npm vulnerabilities at lines 183–187 and all 245 registry versions
answered, none deprecated, at lines 188–213. These observations qualify this
pin, not future registry state or every dependency's behavior. Literal review
of the minified bundle and lock and every graph-edge semantic comparison remain
open. The 338-file full-template comparison remains unfinished.

Formal AI's existing composite artifact actions use upstream upload/download
actions rather than a locally bundled SDK. The maintained download composite
already enforces raw transport digests, Python extraction, three attempts and
temporary-directory cleanup; no new 247-package bundle is introduced here.
Evidence is retained under
experiments/issue-1580/evidence/checks/python-hosted-and-javascript-observations/ .
""")
plan=root/'experiments/issue-1580/work-plan.md';text=plan.read_text()
start=text.index('Latest published head ',text.index('## Current verification checkpoint'));end=text.index('\n\nLatest checkpoint:',start)
checkpoint="""Latest published head __BT__adeb4ff4__BT__ has 25 of 26 normal workflows terminal:
24 success, one skip, no failures observed; Pipeline remains in progress.
No push is permitted while a current-head workflow is queued or in progress.
The previous __BT__e06d1f18__BT__ round also has a successful separately dispatched actual
CodeQL producer. Current local observation additions retain 123 previously
passing maintained cases plus three new real-Git Python detector cases.
Full template, source-warning and original issue acceptance remain open.
See [current Python findings](../../docs/case-studies/issue-1580/python-current-findings-checkpoint.md).
""".replace('__BT__',chr(96))
text=text[:start]+checkpoint+text[end:]
text+="""

- [x] Confirm and report JavaScript code-gating false negatives in Python
  template issue #166, with three actual-Python/Git regression cases.
- [x] Retain exact-head Python hosted bundle/lock rebuild, real artifact round
  trips and dependency audit observations; review all 247 package identity rows.
- [ ] Complete literal bundle/lock and every dependency-edge semantic review,
  full current/historical template scope and original issue acceptance.
"""
plan.write_text(text)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
paths=['experiments/issue-1580/fixtures/python-current-detector','experiments/issue-1580/template-python-javascript-detection.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs',str(target.relative_to(root)),str(ledger.relative_to(root)),str(doc.relative_to(root)),str(plan.relative_to(root))]
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
with (detection/'commit.stdout').open('wb') as stdout,(detection/'commit.stderr').open('wb') as stderr:subprocess.run(['git','commit','-m','test: reproduce JavaScript gating gap and retain hosted Python validation'],cwd=root,stdout=stdout,stderr=stderr,check=True)
print(json.dumps({'recordsRetained':len(records),'regressionCasesPassed':3,'upstream':upstream,'committed':True,'pushExecuted':False,'fullIssueComplete':False}))
