At template commit `62cc393707ddfe7ceeddbc580d43cc35334636f1`, JavaScript production helpers are omitted from the code-change outputs used by the release pipeline.

[The detector's extension list](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/blob/62cc393707ddfe7ceeddbc580d43cc35334636f1/scripts/detect_code_changes.py#L49) counts Python, shell, JSON, TOML and YAML, but omits `.mjs`, `.js` and `.cjs`. The repository now executes JavaScript helpers, including `scripts/check-deprecated-packages.mjs`, `.github/actions/artifact/index.mjs` and `.github/actions/deploy-pages/deploy.mjs`.

This is a follow-up to the fixed shell/JSON gap in #107. It is separate from #145's file-size coverage and #156's Git-failure propagation.

### Reproduce

From a checkout of the pinned template, run this finite probe of the actual classifier:

```sh
python3 - <<'PY'
import importlib.util
spec = importlib.util.spec_from_file_location('detector', 'scripts/detect_code_changes.py')
detector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(detector)
for event in ('push', 'pull_request'):
    for path in ('scripts/check-deprecated-packages.mjs',
                 '.github/actions/artifact/index.mjs',
                 '.github/actions/deploy-pages/deploy.mjs',
                 'scripts/helper.js', 'scripts/helper.cjs'):
        print(event, path, detector.detect_change_types([path], event_name=event))
PY
```

Every row reports `{'any-code-changed': False, 'docs-changed': False}`.

I also ran the actual script entrypoint with real Git, using disposable two-commit repositories and each of `.mjs`, `.js` and `.cjs` as the sole changed path. Both the push comparison and full-history pull-request comparison list the changed helper correctly, then write:

```text
any-code-changed=false
docs-changed=false
```

The tested source SHA256 is `9e81f8022496676bb6b1f6459acef243f72fb7e39d8f47b5b2ed250843b0894f`; Python 3.15.0 was used. The source and Git observations are real; no Git or detector behavior was mocked.

### Impact and fix

The release workflow uses `any-code-changed` to gate changelog validation, lint, tests and build. A JavaScript-only change therefore skips those gates. Additionally, the separate Workflows workflow's path filter does not match `scripts/*.mjs`, so editing `scripts/check-deprecated-packages.mjs` alone does not trigger that workflow either. The Security workflow still runs; this report does not claim all checks are skipped.

Add JavaScript module extensions to `CODE_EXTENSIONS` and cover the JavaScript helper paths in the Workflows triggers. A disposable candidate extending only the classifier with `.js`, `.mjs`, `.cjs` produces `any-code-changed=true` in both real Git comparisons, preserves the existing Python/shell/JSON/TOML/YAML controls, and preserves documentation, example, experiment, changelog and development-log exclusions.

Three bounded Node regression cases cover the actual classifier, the real Git entrypoint and exclusion controls. They are committed with source/license identities in downstream PR https://github.com/link-assistant/formal-ai/pull/1581; a permanent test link will follow after its current CI round ends and the evidence is pushed. No upstream repair has been applied.
