from pathlib import Path
import subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
generator = root / 'scripts/generate-staged-release.mjs'
text = generator.read_text()
needle = '  // Pack short JSON fields to a readable width; preserve long data strings whole.\n'
assert text.count(needle) == 1
addition = '''  // Publication failure must not suppress a validated site's build. Keep the
  // release dependencies only to preserve a successful release's child SHA.
  const pages = workflowJobs(callerSource).find(job => job.id === 'build-pages');
  assert.ok(pages, 'source Pages build required');
  let pagesBody = pages.body;
  for (const caller of ['auto-release', 'manual-release']) {
    const prerequisite = " && needs." + caller + ".result == 'success'";
    assert.equal(pagesBody.split(prerequisite).length, 2, 'unique original publication prerequisite required');
    pagesBody = pagesBody.replace(prerequisite, '');
  }
  assert.equal(callerSource.split(pages.body).length, 2);
  callerSource = callerSource.replace(pages.body, pagesBody);
'''
generator.write_text(text.replace(needle, addition + needle))
pages = root / '.github/workflows/pages-artifact.yml'
text = pages.read_text()
needle = '''      - uses: actions/checkout@v7
        with:
          persist-credentials: false
          ref: ${{ github.ref }}
'''
replacement = '''      # A successful release may resolve a new child on the trusted branch.
      # Otherwise build the immutable triggering source, even if main advanced
      # during a publisher failure. Neither checkout executes an input ref.
      - uses: actions/checkout@v7
        if: ${{ inputs.sha != github.sha }}
        with:
          persist-credentials: false
          ref: ${{ github.ref }}
      - uses: actions/checkout@v7
        if: ${{ inputs.sha == github.sha }}
        with:
          persist-credentials: false
          ref: ${{ github.sha }}
'''
assert text.count(needle) == 1
pages.write_text(text.replace(needle, replacement))
activation = root / 'rust/tests/web/staged-release-activation-transition.test.mjs'
text = activation.read_text()
needle = "   if(!['auto-release','manual-release'].includes(id)){assert.deepEqual(caller.jobs[id],job);continue;}"
assert text.count(needle) == 1
replacement = '''   if(id==='build-pages') {
    const expected=structuredClone(job);
    expected.if=expected.if.replace(" && needs.auto-release.result == 'success'",'')
      .replace(" && needs.manual-release.result == 'success'",'');
    assert.deepEqual(caller.jobs[id],expected);continue;
   }
''' + needle
activation.write_text(text.replace(needle, replacement))
admission = root / 'rust/tests/web/pages-live-rate-budget.test.mjs'
text = admission.read_text()
needle = "import './staged-pages-projection.test.mjs';\n"
assert text.count(needle) == 1
admission.write_text(text.replace(needle, needle + "import '../../../experiments/issue-1580/pages-release-failure.test.mjs';\n"))
code = '''import {readFileSync, writeFileSync} from 'node:fs';
import {buildStagedReleaseProjection} from './scripts/generate-staged-release.mjs';
const prefix='experiments/formal_ai_subagent/evidence/specification-delivery-1188/dormant-staged-release/';
const source=readFileSync(prefix+'original-release-workflow.yml','utf8');
const packet=JSON.parse(readFileSync(prefix+'stage-source-coverage.json','utf8'));
const result=buildStagedReleaseProjection(source,packet);
for(const [file,bytes] of result.outputs)writeFileSync(file,bytes);
writeFileSync('.github/workflows/release.yml',result.outputs.get(prefix+'candidate-release-caller.yml'));
console.log(JSON.stringify({operations:result.operations,bindings:result.binding.length,outputs:result.outputs.size}));
'''
result = subprocess.run(['node', '--max-old-space-size=256', '--input-type=module', '-e', code], cwd=root, capture_output=True)
base = Path('/tmp/issue-1580-research/pages-release-failure')
for label in ('stdout', 'stderr'):
    (base / ('generation.' + label)).write_bytes(getattr(result, label))
assert result.returncode == 0, result.stderr.decode()
fragment = root / 'changelog.d/issue-1580-pages-release-failure.md'
assert not fragment.exists()
fragment.write_text('''---
bump: patch
---

Build validated main Pages sources after a package publisher fails, preserving successful release child identities and immutable fallback checkout.
''')
print('Drafted failure-independent Pages condition and trusted immutable fallback; retained all 52 original release operations and 104 output bindings.')
