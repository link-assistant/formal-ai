from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
destination = root / 'experiments/issue-1580/evidence/checks/pages-release-failure'
destination.mkdir(exist_ok=False)
names = ['draft-pages-release-failure-tests.py', 'implement-pages-release-failure.py',
    'validate-pages-release-failure.py', 'repair-pages-shell-extraction.py',
    'recheck-pages-release-failure.py', Path(__file__).name]
selected = set()
for name in names:
    selected.add(scratch / name)
    log = (scratch / name).with_suffix('.log')
    if log.is_file(): selected.add(log)
for folder in ['pages-release-failure', 'pages-release-failure-validation',
        'pages-release-failure-recheck']:
    selected.update(path for path in (scratch / folder).rglob('*') if path.is_file())
for name in ['check-abbreviations', 'check-ci-speed', 'check-file-size',
        'check-file-size-js-twin', 'check-readable-code', 'check-runner-labels', 'check-tests-as-docs']:
    source = root / 'experiments/formal_ai_subagent/sandboxes/gates' / (name + '.log')
    target = scratch / 'pages-release-failure-recheck' / (name.replace('tests-as-docs', 'tests-as-documentation') + '.log')
    target.write_bytes(source.read_bytes())
    selected.add(target)
rows = []
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for path in sorted(selected):
        raw = path.read_bytes()
        name = str(path.relative_to(scratch))
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
        archive.addfile(entry, io.BytesIO(raw))
        rows.append({'file': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
raw = buffer.getvalue()
packed = gzip.compress(raw, mtime=0)
assert gzip.decompress(packed) == raw
(destination / 'supplied-investigation.tar.gz').write_bytes(packed)
(destination / 'supplied-investigation.json').write_text(json.dumps({'files': rows,
    'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(),
    'independentAuthorshipCredit': 0, 'fullIssueComplete': False}, indent=2) + '\n')
source_files = ['.github/workflows/pages-artifact.yml', '.github/workflows/release.yml',
    'scripts/generate-staged-release.mjs', 'rust/tests/web/pages-artifact-trust.test.mjs',
    'rust/tests/web/pages-live-rate-budget.test.mjs', 'rust/tests/web/staged-release-activation-transition.test.mjs']
identities = []
for index, name in enumerate(source_files):
    before = subprocess.run(['git', 'show', 'f4588ce40023a1cc722cbed4ed7f977581fd4530:' + name], cwd=root, capture_output=True)
    assert before.returncode == 0
    after = (root / name).read_bytes()
    for label, payload in [('before', before.stdout), ('after', after)]:
        (destination / (str(index + 1) + '-' + label + '.txt.gz')).write_bytes(gzip.compress(payload, mtime=0))
    identities.append({'path': name, 'beforeSha256': hashlib.sha256(before.stdout).hexdigest(),
        'afterSha256': hashlib.sha256(after).hexdigest()})
(destination / 'source-identities.json').write_text(json.dumps(identities, indent=2) + '\n')
document = '''# Pages after a publication failure

The pinned Rust template's complete issue-38 history exposes a current counterpart: the deployed release caller requires successful package publication before building Pages. A validated main build therefore loses its documentation update when the publisher fails. Removing that predicate alone is insufficient: the reusable Pages build checks out the current branch, so an advancing main branch can reject the fallback triggering commit at the existing identity guard.

The maintained staged generator now projects the two narrow condition changes into the deployed caller and candidate. Pages still requires a successful build, a non-cancelled run and an authorised main push or instant manual release. Existing release dependencies and successful release-child resolution remain intact. This repair waits for the release jobs to finish; it does not claim independent scheduling. All 52 historical stage operations and 104 bindings remain unchanged.

The reusable workflow selects between two trusted GitHub contexts. A successful publisher's child keeps the trusted branch checkout and existing exact identity check. The fallback checks out the immutable triggering commit. Neither checkout executes an input-selected ref, both disable persisted credentials, and the original equality guard rejects a different commit.

Reproduce the failure by evaluating the actual caller condition with a successful main build and a failed automatic or instant manual publisher. The new regression initially records five failures: four failed/skipped publisher contexts and the fallback checkout selector. The other eight controls pass before the fix. Afterward all 13 cases pass, including an actual temporary Git repository running the unchanged identity-check shell against triggering and child commits.

Validation is sequential and uses a 256 MiB JavaScript heap:

- The focused regression passes 13 cases; the existing Pages admission entrypoint passes all 64, including those 13. The trust suite separately passes five cases.
- Existing staged activation, maintained authority, native operation-view and production-profile files pass 3, 5, 15 and 18 cases respectively. The generated deployed projection is current.
- All seven touched JavaScript gates and whitespace checks pass. No Rust or application build runs locally.
- Preserve the initial admission failure: its old textual shell extractor included adjacent YAML comments as shell code. Parsing the named step with the existing YAML parser repairs the extractor without changing workflow assertions. Preserve the invalid gate-name invocation too; no gates ran in that attempt. The corrected inventory passes.

Hosted execution of this new fallback, actual Pages server acceptance and served source identity remain unverified. Earlier artifact upload or native assertions cannot establish those outcomes. Full eight-template comparison, remaining applicable practices, original native contracts, dependencies, live delivery and semantic macro coverage remain open in [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581). Independently accepted Formal AI reasoning remains 0/20; supplied commands, scripts and conclusions receive zero credit.

Evidence: [complete original controls, failed attempts and passing outputs](../../../experiments/issue-1580/evidence/checks/pages-release-failure/supplied-investigation.json), [before/after source identities](../../../experiments/issue-1580/evidence/checks/pages-release-failure/source-identities.json), and [automated regression](../../../experiments/issue-1580/pages-release-failure.test.mjs).
'''
(root / 'docs/case-studies/issue-1580/pages-release-failure-checkpoint.md').write_text(document)
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- Pinned Rust issue-38 comparison reproduces a current Pages publication prerequisite and advancing-branch fallback defect. Five negative-control cases fail before; all 13 focused and 64 existing admission cases pass after the maintained projection and trusted-checkout repair. Staged 3/5/15/18 groups and seven touched gates pass. Preserve both initial harness failures and all source identities; hosted fallback publication and broader acceptance remain open, with zero independent credit.\n')
print('Retained', len(rows), 'Pages research and verification streams; historical stage operations unchanged; no publication credit.')
