from pathlib import Path
import json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/pages-release-failure-recheck')
base.mkdir(exist_ok=False)
env = dict(os.environ)
env.pop('NODE_OPTIONS', None)
rows = []
for name, argv in [
    ('trust', ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-reporter=tap', '--test-concurrency=1', 'rust/tests/web/pages-artifact-trust.test.mjs']),
    ('admission', ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-reporter=tap', '--test-concurrency=1', 'rust/tests/web/pages-live-rate-budget.test.mjs']),
    ('gates', ['node', '--max-old-space-size=256', 'experiments/formal_ai_subagent/local-gates.mjs', '--only',
        'check-abbreviations,check-ci-speed,check-file-size,check-file-size-js-twin,check-readable-code,check-runner-labels,check-tests-as-docs']),
    ('whitespace', ['git', 'diff', '--check'])]:
    result = subprocess.run(argv, cwd=root, env=env, capture_output=True)
    for label in ('stdout', 'stderr'):
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    rows.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (base / 'records.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(name, result.returncode, flush=True)
outcome = {'complete': True, 'passed': all(row['exitCode'] == 0 for row in rows), 'fullIssueComplete': False}
(base / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
assert outcome['passed']
