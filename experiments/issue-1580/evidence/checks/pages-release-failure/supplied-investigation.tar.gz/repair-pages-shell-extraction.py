from pathlib import Path

root = Path('/tmp/gh-issue-solver-1794900398048')
file = root / 'rust/tests/web/pages-artifact-trust.test.mjs'
text = file.read_text()
old = '''  const step = workflow.split('      - name: ' + name + '\\n')[1].split('\\n      - ')[0];
  return step.split('        run: |\\n')[1].split('\\n').map((line) => line.slice(10)).join('\\n');'''
new = '''  const step = YAML.parse(workflow).jobs.build.steps.find(item => item.name === name);
  assert.equal(typeof step?.run, 'string', 'named workflow shell step required');
  return step.run;'''
assert text.count(old) == 1
file.write_text(text.replace(old, new))
print('Read shell blocks from parsed workflow YAML so adjacent YAML comments cannot become shell instructions; all existing refusal assertions remain.')
