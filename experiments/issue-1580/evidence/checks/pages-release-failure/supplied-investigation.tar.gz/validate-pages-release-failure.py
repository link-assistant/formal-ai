from pathlib import Path
import json, os, subprocess, sys, traceback

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/pages-release-failure-validation')
if len(sys.argv) == 1:
    base.mkdir(exist_ok=False)
    with (base / 'worker.log').open('wb') as stream:
        process = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root,
            stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': process.pid, 'scratch': str(base)}))
    sys.exit(0)
environment = dict(os.environ)
environment.pop('NODE_OPTIONS', None)
records = []
def run(name, argv):
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
    for label in ('stdout', 'stderr'):
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    return result.returncode
try:
    for name, file in [
        ('focused', 'experiments/issue-1580/pages-release-failure.test.mjs'),
        ('pages-admission', 'rust/tests/web/pages-live-rate-budget.test.mjs'),
        ('staged-activation', 'rust/tests/web/staged-release-activation-transition.test.mjs'),
        ('staged-authority', 'rust/tests/web/maintained-staged-authority.test.mjs'),
        ('native-operation-view', 'rust/tests/web/native-staged-release-operation-view.test.mjs'),
        ('production-profile', 'rust/tests/web/fast-pull-request-production-profile.test.mjs')]:
        run(name, ['timeout', '600', 'node', '--max-old-space-size=256', '--test',
            '--test-reporter=tap', '--test-concurrency=1', file])
    run('generated-deployed', ['node', '--max-old-space-size=256', 'scripts/generate-staged-release.mjs', '--check-deployed'])
    run('touched-gates', ['node', '--max-old-space-size=256', 'experiments/formal_ai_subagent/local-gates.mjs', '--only',
        'check-abbreviations,ci-speed,check-file-size,check-file-size-js-twin,check-readable-code,runner-labels,tests-as-docs'])
    run('whitespace', ['git', 'diff', '--check'])
    outcome = {'complete': True, 'passed': all(row['exitCode'] == 0 for row in records),
        'records': len(records), 'rustCompilation': False, 'fullIssueComplete': False}
    (base / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    print(json.dumps(outcome), flush=True)
except BaseException:
    (base / 'failure.json').write_text(json.dumps({'complete': False, 'traceback': traceback.format_exc()}) + '\n')
    traceback.print_exc()
    sys.exit(1)
