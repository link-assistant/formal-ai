import datetime,json,os,subprocess,time
from pathlib import Path
out=Path('/tmp/issue-1580-research/terminal-aa84dfc2-review')
commands=[(label,['node','--max-old-space-size=192','--test','--test-concurrency=1',file]) for label,file in [('production-profile-final','rust/tests/web/fast-pull-request-production-profile.test.mjs'),('branch-policy-final','rust/tests/web/default-branch-build-policy.test.mjs')]]
for gate in ['check-file-size','check-readable-code','check-changelog-fragment-js-twin','check-required-documentation','check-tests-as-docs','check-tests-as-documentation-javascript-twin']:
 commands.append(('post-normalization-gate-'+gate,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]))
commands.append(('post-normalization-requirement-status-readonly',['node','scripts/check-requirement-status.mjs']))
rows=[]
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=192'}
for label,command in commands:
 start=time.monotonic()
 with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
  result=subprocess.run(command,env=env,stdout=stdout,stderr=stderr)
 row={'label':label,'command':command,'exitCode':result.returncode,'seconds':time.monotonic()-start,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 rows.append(row);(out/'final-verification.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
(out/'final-verification-outcome.json').write_text(json.dumps({'pass':all(row['exitCode']==0 for row in rows),'commands':len(rows),'nativeBuildExecuted':False,'hostedRepairExecuted':False,'fullIssueComplete':False},indent=2)+'\n')
