CodeQL 2.27.4 reports two `actions/cache-poisoning/poisonable-step` findings in a workflow that resolves literal trusted repositories' `main` commits once and checks out the resulting immutable SHAs. The finding describes these checkouts as PR-head sources, although neither resolver reads a PR, event input, artifact or caller-supplied revision.

Observed analysis: [link-assistant/formal-ai Security run 44374193717](https://github.com/link-assistant/formal-ai/actions/runs/44374193717), commit `53cbe4430f8b65330f47728401fc83b09977129f`, actions analysis ID `2198826017`, created `2026-11-18T18:52:33Z`. Its exported SARIF reports CodeQL semanticVersion `2.27.4` and two results. Both alerts remain open:

- https://github.com/link-assistant/formal-ai/security/code-scanning/131
- https://github.com/link-assistant/formal-ai/security/code-scanning/130

The full workflow is [pinned here](https://github.com/link-assistant/formal-ai/blob/53cbe4430f8b65330f47728401fc83b09977129f/.github/workflows/hive-mind-draft.yml). It runs on push to main or manual dispatch, has read-only job permissions and checks its own main-branch context. The Hive resolver requests the literal endpoint `repos/link-assistant/hive-mind/commits/main`; the application resolver requests `repos/$GITHUB_REPOSITORY/commits/main`. Both validate a 40-character lowercase hexadecimal response before writing an output named `sha`. The checkouts select those exact outputs with credentials persistence disabled. A later step verifies the checked-out Hive HEAD against its selected SHA.

The result source locations point to those `steps.hive-source.outputs.sha` and `steps.source.outputs.sha` checkout references. The reported downstream steps are the application resolver shell and a restore-only Cargo registry cache action. Restore-only caching is not being claimed as isolation from malicious code; the question is why these trusted main-commit resolvers become PR-head sources in the first place.

The version-matched [UntrustedCheckoutQuery.qll](https://github.com/github/codeql/blob/codeql-cli/v2.27.4/actions/ql/lib/codeql/actions/security/UntrustedCheckoutQuery.qll#L268-L293) contains this independent alternative to the taint-flow predicate:

```ql
// heuristic base on the step id and field name
exists(string value, Expression expr |
  value.regexpMatch(".*(head|sha|commit).*") and expr = this.getArgumentExpr("ref")
|
  expr.(StepsExpression).getStepId() = value
  or
  expr.(SimpleReferenceExpression).getFieldName() = value and
  not expr instanceof GitHubExpression
  // ...
)
```

The file's Git blob is `bd8ec6f035e9d1d7ac14b03ade98932661403721`, identical to the current main copy retrieved during this investigation. This appears to classify the output field name `sha` as untrusted independently of the literal main-only resolver. I have inspected the query source and the real exported findings; I have **not** run a local CodeQL query regression, so that causal attribution remains an inference from the source and locations.

A reduced candidate fixture for an upstream regression is below. This reduction has not been independently analyzed; the observed reproduction above is the full pinned workflow.

```yaml
name: Resolve trusted main once
on:
  workflow_dispatch:
permissions:
  contents: read
jobs:
  build:
    runs-on: ubuntu-24.04
    steps:
      - id: source
        env:
          GH_TOKEN: ${{ github.token }}
        run: |
          set -euo pipefail
          sha="$(gh api repos/link-assistant/hive-mind/commits/main --jq .sha)"
          [[ "$sha" =~ ^[0-9a-f]{40}$ ]] || exit 1
          printf 'sha=%s\n' "$sha" >> "$GITHUB_OUTPUT"
      - uses: actions/checkout@v6
        with:
          repository: link-assistant/hive-mind
          ref: ${{ steps.source.outputs.sha }}
          persist-credentials: false
      - run: node --version
```

Expected: a literal trusted repository/main resolver should not become a PR-head source solely because an output is named `sha`. Real PR-head and dispatch-input flows, including the TOCTOU cases discussed in #19835, should retain their findings. A fix needs a positive trusted-main fixture and negative controls for actual untrusted PR/dispatch revisions; renaming the output, suppressing the rule or excluding this workflow would hide the model problem.

This investigation comes from [link-assistant/formal-ai#1580](https://github.com/link-assistant/formal-ai/issues/1580), with work retained in [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581). No alerts have been dismissed and no query exclusions have been added.
