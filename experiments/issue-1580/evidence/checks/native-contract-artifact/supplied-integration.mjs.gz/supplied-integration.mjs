
test('all nine real runner groups reuse bound finite executables and invoke no Cargo', {timeout:30000}, t=>{
  const {root,git}=workspace(t),directory=join(root,'transport'),sources=join(root,'compiled'),bin=join(root,'bin');mkdirSync(sources);mkdirSync(bin);
  const cases={coding_contracts:['coding::one','coding::two','coding::three','coding::four'],reasoning_contracts:[
    'reasoning::one','reasoning::two','reasoning::three','reasoning::four','benchmarks::one','benchmarks::two',
    ...Array.from({length:6},(_,i)=>'issue_1133_hive_mind_three_runs::case_'+i)],interface_contracts:['interface::one','interface::two']};
  writeFileSync(join(bin,'rustc'),'#!/usr/bin/env node\nconsole.log("rustc finite-transport-fixture\\nhost: fixture-host");\n',{mode:0o755});
  writeFileSync(join(bin,'cargo'),'#!/usr/bin/env node\nconsole.error("finite transport probe: Cargo must not run");process.exit(99);\n',{mode:0o755});
  const calls=join(root,'calls.jsonl'),environment={...process.env,PATH:bin+':'+process.env.PATH,FORMAL_AI_NATIVE_CONTRACT_ARTIFACT:directory,
    NATIVE_CONTRACT_CASES:JSON.stringify(cases),NATIVE_CONTRACT_CALLS:calls};delete environment.CARGO_TARGET_DIR;
  const executables={};
  const program=`#!/usr/bin/env node
import {appendFileSync} from 'node:fs';import {basename} from 'node:path';
const target=basename(process.argv[1]),args=process.argv.slice(2);
appendFileSync(process.env.NATIVE_CONTRACT_CALLS,JSON.stringify({target,args})+'\\n');
if(args.includes('--list')){
 let names=JSON.parse(process.env.NATIVE_CONTRACT_CASES)[target];
 if(args[0]&&!args[0].startsWith('--'))names=names.filter(name=>name.includes(args[0]));
 for(let i=0;i<args.length;i++)if(args[i]==='--skip')names=names.filter(name=>!name.includes(args[i+1]));
 process.stdout.write(names.map(name=>name+': test\\n').join(''));
}
`;
  for(const name of [...CONTRACT_TARGETS,'formal-ai']){const file=join(sources,name);writeFileSync(file,program,{mode:0o755});executables[name]=file;}
  const module=new URL('../../scripts/native-contract-artifact.mjs',import.meta.url).href;
  const identity=JSON.parse(execFileSync(process.execPath,['--input-type=module','-e',`import {contractIdentity} from ${JSON.stringify(module)};process.stdout.write(JSON.stringify(contractIdentity(process.cwd())));`],{cwd:root,env:environment,encoding:'utf8'}));
  sealContractArtifact(directory,identity,executables);
  const runner=resolve('scripts/ci-native-regressions.sh');
  const before=join(root,'original-runner.sh');writeFileSync(before,gunzipSync(readFileSync(new URL('./fixtures/native-contract-artifact/original-runner.sh.gz',import.meta.url))));
  const baseline=spawnSync('bash',[before,'coding-1'],{cwd:root,env:environment,encoding:'utf8',timeout:5000});
  assert.equal(baseline.status,99,baseline.stderr);assert.match(baseline.stderr,/Cargo must not run/u);
  for(const group of ['coding-1','coding-2','reasoning-1','reasoning-2','benchmarks','interfaces','hive-1','hive-2','hive-3']){
    const result=spawnSync('bash',[runner,group],{cwd:root,env:environment,encoding:'utf8',timeout:5000,maxBuffer:65536});
    assert.equal(result.status,0,group+': '+result.stdout+result.stderr);
  }
  const rows=readFileSync(calls,'utf8').trimEnd().split('\n').map(JSON.parse),actual=[];
  for(const row of rows.filter(row=>!row.args.includes('--list'))){
    if(row.args[0]==='--exact')actual.push(...row.args.slice(1,-2).map(name=>row.target+'\t'+name));
    else actual.push(...cases[row.target].filter(name=>row.args[0].startsWith('--')||name.includes(row.args[0])).map(name=>row.target+'\t'+name));
  }
  const expected=Object.entries(cases).flatMap(([target,names])=>names.map(name=>target+'\t'+name));
  assert.deepEqual(actual.toSorted(),expected.toSorted());assert.equal(new Set(actual).size,actual.length);
  writeFileSync(join(directory,'coding_contracts'),'tampered');
  const rejected=spawnSync('bash',[runner,'coding-1'],{cwd:root,env:environment,encoding:'utf8',timeout:5000});
  assert.notEqual(rejected.status,0);assert.match(rejected.stderr,/artifact bytes changed/u);
  assert.equal(readFileSync(calls,'utf8').trimEnd().split('\n').length,rows.length,'invalid receipt must not list or execute tests');
});
