from pathlib import Path
from datetime import datetime,timezone
import hashlib,gzip,json,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/current-native-early');b=r/'experiments/issue-1580/evidence/ci/native-families-3a71f965/early-registry-proof';b.mkdir(exist_ok=True)
a=json.loads((s/'jobs.json').read_text());assert a['headSha']=='3a71f965e854893a3cb3c5470434ae9a846a3693'
j=next(j for j in a['jobs'] if j['databaseId']==136174486087);assert j['conclusion']=='success'
raw=(s/'job-136174486087.log').read_bytes();assert hashlib.sha256(raw).hexdigest()=='8e973062b61f6c5a3660e12b025b95f00a581e483127bf85c3522d30fda17730';assert b'3 passed; 0 failed' in raw and b'Ran 8 tests' in raw and b'OK' in raw
rows=[]
for name in ['job-136174486087.log','job-136174486087.log.api-stderr','jobs.json']:
 data=(s/name).read_bytes();packed=gzip.compress(data,mtime=0);(b/(name+'.gz')).write_bytes(packed);rows.append({'path':name+'.gz','rawSha256':hashlib.sha256(data).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'rawBytes':len(data)})
(b/'assessment.json').write_text(json.dumps({'head':a['headSha'],'run':44702570685,'job':j,'observedAt':datetime.now(timezone.utc).isoformat(),'helperCasesPassed':3,'actualCliCasesPassed':8,'logLineCount':len(raw.splitlines()),'literalLogRangesReviewed':[[1,230],[570,782]],'scope':'early registry result only; overall workflow remains incomplete','logTransport':'GitHub CLI requires --allow-escape-sequences to preserve this original log; earlier rejected transport is not a job failure','records':rows,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps({'registryHelper':3,'actualCli':8,'fullIssueComplete':False}));subprocess.run(['file','/tmp/issue-1580-research/templates/rust-complete/docs/screenshots/desktop-download-page.png'],check=True)
