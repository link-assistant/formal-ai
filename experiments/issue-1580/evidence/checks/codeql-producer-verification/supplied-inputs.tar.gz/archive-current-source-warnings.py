from pathlib import Path
from datetime import datetime,timezone
import hashlib,gzip,json,re
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');b=r/'experiments/issue-1580/evidence/ci/native-families-3a71f965/source-warnings';b.mkdir(exist_ok=True)
p=s/'current-native-core/job-136174240580.log';raw=p.read_bytes();text=raw.decode();rows=[]
pattern=re.compile(r'WARNING: (.+) has (\d+) lines \(approaching .+warning threshold: (\d+)\)')
for n,line in enumerate(text.splitlines(),1):
 m=pattern.search(line)
 if m:rows.append({'line':n,'path':m[1],'lines':int(m[2]),'threshold':int(m[3])})
assert len(rows)==123
old=[]
for line in (r/'experiments/issue-1580/evidence/ci/native-families-c5b68508/source-size-warning-candidates.jsonl').read_text().splitlines():
 x=json.loads(line);m=pattern.search(x['text']);assert m;old.append(m[1])
assert len(old)==124
removed=sorted(set(old)-{x['path'] for x in rows});added=sorted({x['path']for x in rows}-set(old));assert len(removed)==1 and not added
(b/'inventory.json').write_text(json.dumps(rows,indent=2)+'\n')
(b/'assessment.json').write_text(json.dumps({'observedAt':datetime.now(timezone.utc).isoformat(),'head':'3a71f965e854893a3cb3c5470434ae9a846a3693','run':44702570685,'job':136174240580,'rawLogSha256':hashlib.sha256(raw).hexdigest(),'rawLogLines':len(raw.splitlines()),'currentWarnings':len(rows),'previousWarnings':len(old),'removedPaths':removed,'addedPaths':added,'warningPolicyChanged':False,'resolution':'One workflow-test extraction removes its former warning. All 123 recorded source-size warnings remain unresolved. The passing size gate does not complete the issue acceptance.','fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps({'warnings':len(rows),'removed':removed,'added':added,'fullIssueComplete':False}))
