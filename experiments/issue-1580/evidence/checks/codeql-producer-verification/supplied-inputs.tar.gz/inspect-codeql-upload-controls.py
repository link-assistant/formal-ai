from pathlib import Path
import subprocess,base64,json,hashlib,gzip
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/codeql-upload-controls');s.mkdir(exist_ok=True)
for path in ['analyze/action.yml','src/analyze-action.ts','src/database-upload.ts']:
 p=subprocess.run(['gh','api','repos/github/codeql-action/contents/'+path+'?ref=v4'],cwd=r,capture_output=True);name=path.replace('/','-');(s/(name+'.api.stdout.gz')).write_bytes(gzip.compress(p.stdout,mtime=0));(s/(name+'.api.stderr.gz')).write_bytes(gzip.compress(p.stderr,mtime=0));assert p.returncode==0,(path,p.stderr.decode());d=json.loads(p.stdout);raw=base64.b64decode(d['content']);(s/name).write_bytes(raw);lines=raw.decode().splitlines();print('FILE',path,'BLOB',d['sha'],'LINES',len(lines),'SHA256',hashlib.sha256(raw).hexdigest())
 for n,line in enumerate(lines,1):
  if any(x in line.lower() for x in ['upload-database','uploaddatabase','uploading database','upload database','upload ===','upload ===','uploadoption','uploadoption','upload:','uploadinput']):
   for k in range(max(0,n-4),min(len(lines),n+7)):print(str(k+1)+': '+lines[k])
