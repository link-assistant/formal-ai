from pathlib import Path
import subprocess,json,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/codeql-producer-source-review');s.mkdir(exist_ok=True)
for name,args in [('commit',['git','show','--format=fuller','--stat','fcd5562703be4b19a83952ac0f404c644f9f0682']),('diff',['git','show','--format=','fcd5562703be4b19a83952ac0f404c644f9f0682']),('fetch',['git','fetch','origin','main']),('main-ancestor',['git','merge-base','--is-ancestor','origin/main','HEAD'])]:
 p=subprocess.run(args,cwd=r,capture_output=True);(s/(name+'.stdout')).write_bytes(p.stdout);(s/(name+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,(name,p.stderr.decode());print(name,p.returncode,'stdoutBytes',len(p.stdout),'stderr',p.stderr.decode())
print('DIFF',str(s/'diff.stdout'))
