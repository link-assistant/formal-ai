from pathlib import Path
import hashlib,json
r=Path('/tmp/gh-issue-solver-1794900398048');t=Path('/tmp/issue-1580-research/templates/rust-complete');ids={x['path']:x for x in json.loads((r/'experiments/issue-1580/evidence/checks/rust-template-first-gate/pinned-file-identities.json').read_text())}
for path in ['Cargo.lock','requirements-dev.txt']:
 raw=(t/path).read_bytes();lines=raw.decode().splitlines();sha=hashlib.sha256(raw).hexdigest();assert sha==ids[path]['sha256'];assert len(lines)<=1500;print('FILE',path,'LINES',len(lines),'SHA256',sha)
 for n,line in enumerate(lines,1):print(f'{n}: {line}')
