from pathlib import Path
import gzip,json
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/ci/native-families-3a71f965/all-workflow-logs'
for name,start,end in [('44702570410.stdout.log.gz',515,550),('44702570685.stdout.log.gz',2921,2946),('44702570352.stdout.log.gz',450,478)]:
 raw=gzip.decompress((b/name).read_bytes());lines=raw.decode(errors='replace').splitlines();print('FILE',name,'RANGE',start,end,'TOTAL',len(lines))
 for n in range(start,end+1):print(str(n)+': '+lines[n-1])
