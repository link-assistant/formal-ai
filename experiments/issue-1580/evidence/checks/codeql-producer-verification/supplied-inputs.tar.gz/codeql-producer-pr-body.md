CI omitted native inputs, lost task/source ownership and accepted incomplete process or Git evidence. This draft repairs those boundaries and adds focused native replays. Issue #1580 remains unfinished; keep this PR draft and unmerged.

Fixes #1580

Changes:

- Preserve quoted task passages, request-local constraints, selected-child provenance and unresolved status for unverified drafts. Reuse source-bound calculation and counting evidence; regenerate maintained language projections through their official writers.
- Preserve multilingual lookup, explanation, calendar and controlled-language grammar behavior. Accept canonical IPv4 web operands while excluding attachment metadata.
- Admit complete native reasoning, interface, Hive, workflow, benchmark and fixture source closures. Separate expensive native families with two concurrent matrix runners, preserving all 14 targets, single test threads, failure propagation and existing 20-minute clocks. Keep the complete runner available.
- Keep routine wrapper diagnostics in files unless verbosity is explicit. Forward client flags independently and retain the empty-stderr contract.
- Open closed-program sequence search using bounded atoms from actual ranked fragment types. Preserve IR content IDs and rejection stages; an empty frontier creates no attempt. Verification requirements remain intact.
- Decode appended HTTP capture records individually using their public schemas, preserving capture/privacy/ephemeral-memory assertions. Replay Hive workflow delivery in real temporary Git repositories with explicit compiler/CI fixtures; missing Git evidence or failed verification prevents commit.
- Enforce budgets until the process group finishes, including children whose parent exited. Account for Bash's coarse elapsed clock at the deadline boundary. Preserve command statuses, stdout, stderr and warning-only behavior; report unavailable process inspection.
- Reject failed/partial Git lockfile inventories before Cargo audits. Check package versions on release-prefixed PR branches instead of trusting branch names.
- Create manual changelog fragments exclusively, preserving existing files on collisions and refusing symlinks. Adopt the Rust template shared fallible Actions output writer in all six release callers; configured output failures now stop before success reporting. Add both helpers and all callers to native admission.
- Parse actual Cargo package identity and workspace configuration in release helpers. Replace only the package-version token, preserving comments, CRLF and unrelated manifest bytes; refuse missing or inherited versions before writes. Include the separate changelog collector and preserve name-only badge lookup.
- Retry a failed native checkout once within the existing four-minute checkout allowance and twenty-minute job clock; preserve sparse checkout, ref selection and credential settings. Require one actual success before compilation.
- Refuse uncertain crates.io, GitHub release and Docker tag observations before release decisions or version mutations. Bound retryable failures, stop on permanent errors and validate returned identities. Add a separate read-only native job for the actual helper and both release CLIs against local HTTP fixtures.
- Propagate fragment directory, read and cleanup errors in bump selection, standalone changelog collection and version preparation. Use the exact consumed snapshot for cleanup; retain canonical formatting and newly arrived fragments. Admit actual filesystem regression functions to focused native CI.
- Refresh JavaScript weights from complete measured events without lowering conservative historical costs; split the complete fast PR inventory into four groups with the same deadlines and eight main groups.
- Reject malformed or missing CodeQL reports, unresolved findings and unsuccessful/extraction-diagnostic invocations. Preserve the exact producer reports; stop when Rust sysroot prerequisites are incomplete. Retain both native CodeQL assertions in full and focused suites, including their complete admission inputs.
- Correct the native release fixture to include every status surface staged by the actual writer. Preserve real Git staging and the CLI assertions. Allow an explicit manual read-only CodeQL producer run on a branch, sharing the main producer steps and preserving their original reports.
- Retain pinned template comparisons, executable negative controls and upstream reports. Reporting a defect establishes no upstream repair.

Verification:

- Published predecessor `3a71f965e854893a3cb3c5470434ae9a846a3693` finishes all 23 workflows successfully. Native families pass: workflow 104, coding 32, reasoning 141, interfaces 78, benchmarks 11 and Hive 20/10/7. The shared registry helper passes 3 actual native tests and both actual release CLIs pass all 8 cases, including the repaired real Git staging path. [Complete logs and assessment](https://github.com/link-assistant/formal-ai/tree/issue-1580-8d61a32a61e1/experiments/issue-1580/evidence/ci/native-families-3a71f965) preserve 216 verified collector streams and 46 streams for all 23 workflow logs. This newly published producer-path batch still requires its own hosted CI.
- The fixture regression fails before and passes after adding the three actual status surfaces. The original CodeQL controls and focused admission controls fail before repair and pass after it. A ninth regression fails on the missing manual path and passes after adding explicit read-only branch verification with the exact production steps and no code-scanning result upload. Local validation passes 9 CodeQL groups, 97 workflow-policy cases, 18 production-profile cases, 32 documentation-policy cases and the full 140-entry gate inventory (87 pass / 53 explicit CI-only exclusions), with unchanged production source identities. No local Rust build runs. Live producer compatibility and original SARIF still require the opt-in hosted run.
- Full workflow logs contain 123 actual source-size warnings, one experimental `unsafe-libyaml` maintenance warning (Security lines 542–549) and unresolved crates.io publish-token certainty (pipeline lines 2932–2936). All remain open. Expected canary rejections and quoted shell source are distinguished from emitted failures. Extracting the CodeQL tests removes one former size warning; thresholds and dependency exceptions are unchanged.
- Main's latest inspected Security run succeeds but reports two open high-severity Actions cache-poisoning findings. CodeQL 2.27.4's trusted-main-output heuristic is reported in [CodeQL #23176](https://github.com/github/codeql/issues/23176); neither alert is dismissed or excluded. The original producer reports were not retained, and normalized API SARIF lacks invocation metadata. Live producer compatibility, complete extraction and finding resolution remain unverified. [CodeQL checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/codeql-result-checkpoint.md) separates source inference, local regression evidence and remaining hosted acceptance.
- The measured JavaScript repair retains conservative weights and four complete PR groups with existing deadlines. Its 25 timing and 18 production-profile checks pass. Registry admission and documentation-policy checks pass; historical-source admission controls fail as expected.
- Timer regressions reproduce failures before repair: two coarse-clock cases and six parent-exit/child-lifetime cases. All focused cases pass after repair, alongside maintained release/cache/template, container and native-artifact controls. Fixtures bound memory and lifetime and reap their children. ShellCheck passes; no local Rust build or native execution runs.
- Four release-prefix controls fail before repair and pass after it; the maintained policy entrypoint passes 86 checks. Legitimate manual release fragments still pass, and immutable current-base comparison remains required.
- Java's pinned project-version CLI reports success without changing the version in three parent/comment cases. Rust's pinned desktop checksum command includes stale fragments and can include its own output on GNU and shasum paths. Fresh-output self-inclusion races enumeration; pre-existing-output self-inclusion is deterministic. Local reproductions and corrected candidates are retained; 57 maintained template checks and 43 unchanged upstream prerequisite checks pass. The source-confirmed manual fragment overwrite/symlink defect is reported in [Rust #254](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/254), with template CLI execution explicitly unverified. Reports also include [Java #32](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/32), [Rust #213](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/213) and [Rust #251](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/251). Upstream repair and hosted publication remain unverified.
- Selected production review covers 106 selected diffs, with identities reverified; complete PR review remains unfinished. Java's pinned 207-file applicability map is complete, while applicable implementation/runtime acceptance remains open. Rust literal source review covers 217/373 files and 33,860 lines; 156 files and practice verification remain open. The twelve-file CodeQL/admission patch and four-file producer-path change are reviewed, while the complete PR diff remains unfinished.

Focused reproduction:

```sh
timeout 600 node --test --test-concurrency=1 rust/tests/web/hive-work-item-consumer.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/fast-pull-request-production-profile.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/native-regression-groups.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/native-checkout-retry.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/documentation-only-ci-policy.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/ci-speed.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/budget-clock-boundary.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/deadline-process-lifetime.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/default-branch-build-policy.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-java-project-version.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-rust-desktop-checksums.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/security-codeql-results.test.mjs
python3 experiments/issue-1580/release-registry/check_fixture.py
node experiments/formal_ai_subagent/local-gates.mjs
```

The hosted-only registry job runs `cargo test --manifest-path experiments/issue-1580/release-registry/Cargo.toml --locked --lib -- --test-threads=1 --nocapture` and `python3 experiments/issue-1580/release-registry/cli_regressions.py`.

Earlier browser source-binding evidence uses a labeled production-worker harness with external requests blocked:

![Before: the Spanish definition frame is skipped](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/screenshots/issue-1580/meaning-hydration-before.png?raw=true)

![After: the definition routes to search and the unresolved sibling answer remains intact](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/screenshots/issue-1580/meaning-hydration-after.png?raw=true)

Unfinished acceptance is tracked in the [work plan](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/experiments/issue-1580/work-plan.md) and [case study](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/README.md): new producer-path CI and live producer reports, remaining original native and budget contracts, all eight complete template comparisons and applicable practices, dependency migrations and warnings, historical cache/Docker evidence, live delivery/model identity, general binding/provenance and complete PR review. Strict dated original-source passing evidence is 31/53; matching names from changed fixtures alone earn no original-source acceptance. Independently accepted Formal AI reasoning remains 0/20; supplied commands, patches and reviews earn no independent credit.
