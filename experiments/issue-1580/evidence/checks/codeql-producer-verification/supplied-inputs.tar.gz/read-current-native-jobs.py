from pathlib import Path
import json,subprocess,gzip,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/ci/native-families-3a71f965';d=json.loads((b/'latest.json').read_text());row=next(x for x in d['runs']if x['workflowName']=='CI/CD Pipeline');v=subprocess.run(['gh','run','view',str(row['databaseId']),'--repo','link-assistant/formal-ai','--json','headSha,jobs,status,conclusion'],cwd=r,capture_output=True,check=True);a=json.loads(v.stdout);assert a['headSha']==d['head'];s=Path('/tmp/issue-1580-research/current-native-early');s.mkdir(exist_ok=True);(s/'jobs.json').write_bytes(v.stdout)
print('RUN',row['databaseId'],'HEAD',a['headSha'],'STATUS',a['status'])
for j in a['jobs']:
 print(j['databaseId'],j['name'],j['status'],j['conclusion'])
 if j['status']=='completed'and ('registry' in j['name'].lower()or 'native core' in j['name'].lower()):
  p=s/('job-'+str(j['databaseId'])+'.log')
  if not p.exists():
   v=subprocess.run(['gh','api','--allow-escape-sequences',f"repos/link-assistant/formal-ai/actions/jobs/{j['databaseId']}/logs"],cwd=r,capture_output=True);(s/(p.name+'.api-stderr')).write_bytes(v.stderr)
   if v.returncode:
    print('API LOG NOT AVAILABLE',v.returncode,v.stderr.decode(errors='replace'));continue
   p.write_bytes(v.stdout)
  raw=p.read_bytes();print('SAVED',str(p),'LINES',len(raw.splitlines()),'SHA256',hashlib.sha256(raw).hexdigest())
