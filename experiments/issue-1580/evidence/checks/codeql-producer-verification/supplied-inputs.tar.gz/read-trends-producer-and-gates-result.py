from pathlib import Path
import json
for name in ['rust/examples/dump_google_trends_catalog.rs','rust/src/google_trends_catalog.rs']:
 p=Path(name);rows=p.read_text().splitlines();print('FILE',name,'LINES',len(rows))
 for i,l in enumerate(rows,1): print(f'{i}: {l}')
p=Path('/tmp/issue-1580-research/google-trends-draft-validation');print('RESULT_EXISTS',(p/'result.json').exists());print((p/'worker.log').read_text()[-2000:])
