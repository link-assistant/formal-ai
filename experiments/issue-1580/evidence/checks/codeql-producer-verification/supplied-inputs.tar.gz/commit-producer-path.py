from pathlib import Path
import subprocess,json,hashlib,gzip
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/codeql-producer-commit');s.mkdir(exist_ok=False);b=r/'experiments/issue-1580/evidence/checks/codeql-producer-verification'
assert json.loads(Path('/tmp/issue-1580-research/codeql-producer-preflight/outcome.json').read_text())['complete'];rows=json.loads((b/'checked-production-identities.json').read_text())
assert subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip()=='issue-1580-8d61a32a61e1'
for row in rows:assert hashlib.sha256((r/row['path']).read_bytes()).hexdigest()==row['sha256']
args=['git','commit','--only','-m','Allow read-only CodeQL producer verification on branches','--',*[row['path']for row in rows]];v=subprocess.run(args,cwd=r,capture_output=True);(s/'commit.stdout').write_bytes(v.stdout);(s/'commit.stderr').write_bytes(v.stderr);print(v.stdout.decode());print(v.stderr.decode());assert v.returncode==0
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();(s/'outcome.json').write_text(json.dumps({'complete':True,'head':head,'pushExecuted':False,'fullIssueComplete':False})+'\n');print('HEAD',head)
