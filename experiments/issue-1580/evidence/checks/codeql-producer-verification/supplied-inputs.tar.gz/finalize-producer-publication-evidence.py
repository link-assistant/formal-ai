from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,re,subprocess,sys,os,traceback
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');b=r/'experiments/issue-1580/evidence/checks/codeql-producer-verification';ci=r/'experiments/issue-1580/evidence/ci/native-families-3a71f965';scratch=s/'producer-publication-preflight'
if len(sys.argv)==1:
 assert json.loads((s/'producer-predecessor-ci/outcome.json').read_text())['complete'];a=json.loads((ci/'assessment.json').read_text());assert a['success']==23 and not a['failed'] and a['verifiedStreams']==216
 checks=json.loads(gzip.decompress((ci/'pull-request-checks.stdout.gz').read_bytes()));assert all(x['bucket']in ['pass','skipping']for x in checks)
 diag=ci/'all-workflow-logs/diagnostics-review.json';d=json.loads(diag.read_text());assert d['allDiagnosticRecords']==270 and d['sourceSizeRecords']==246 and len(d['otherDiagnosticRecords'])==24
 for x in d['otherDiagnosticRecords']:
  t=x['text']
  if 'shellcheck-canary.yml' in t:x['classification']='Expected negative control: malformed canary rejected, delegation live; not a production linter failure'
  elif '1 allowed warning found' in t:x['classification']='UNRESOLVED actual unsafe-libyaml 0.2.11 unmaintained warning, RUSTSEC-2024-0449, experimental Cargo lock; Security log lines 542-549'
  elif '##[warning]UNKNOWN: crates.io' in t:x['classification']='UNRESOLVED crates.io credential certainty: report mode cannot establish token validity without an actual publish; pipeline log lines 2932-2936'
  else:
   assert any(z in t for z in ['echo ',"printf '"]),t
   x['classification']='Quoted command source in Actions group; this row is not an emitted error or warning'
 d['classificationPending']=False;d['remainingAcceptance']='123 actual source-size warnings, the experimental dependency warning and publish-token certainty remain open; passing jobs do not resolve them.';diag.write_text(json.dumps(d,indent=2)+'\n')
 for row in json.loads((ci/'all-workflow-logs/records.json').read_text()):
  for label in ['stdout','stderr']:
   x=row[label];packed=(ci/'all-workflow-logs'/x['file']).read_bytes();assert hashlib.sha256(packed).hexdigest()==x['archiveSha256']and hashlib.sha256(gzip.decompress(packed)).hexdigest()==x['rawSha256']
 a['verifiedAllWorkflowLogStreams']=46;a['pullRequestCheckBuckets']={key:sum(x['bucket']==key for x in checks)for key in sorted({x['bucket']for x in checks})};a['diagnosticReview']='all-workflow-logs/diagnostics-review.json';a['remainingSourceSizeWarnings']=123;a['workflowFamilyPassed']=104;a['codingPassed']=32;a['reasoningPassed']=141;a['interfacesPassed']=78;a['benchmarksPassed']=11;a['hiveFamilyPassed']=[20,10,7];a['registryHelperPassed']=3;a['actualRegistryCliPassed']=8;(ci/'assessment.json').write_text(json.dumps(a,indent=2)+'\n')
 p=r/'docs/case-studies/issue-1580/codeql-result-checkpoint.md';text=p.read_text();text+='\nPublished predecessor `3a71f965` now finishes all 23 workflows successfully, including workflow 104, coding 32, reasoning 141, interfaces 78, benchmarks 11, Hive 20/10/7 and registry helper/CLI 3/8. All 216 collector streams and 46 streams covering all 23 complete workflow logs have verified raw and archive identities. The 270 diagnostic matches comprise 246 records for 123 actual size warnings, two expected malformed-canary errors, twenty quoted shell source lines and two actual unresolved warnings: experimental `unsafe-libyaml` maintenance (Security lines 542–549) and crates.io credential certainty (pipeline lines 2932–2936). No source-size threshold or dependency exception is relaxed. These green workflows do not run the new local producer path or close the broader acceptance.\n\nRust dependency-lock review subsequently reaches 217/373 files and 33,860 lines, leaving 156 files and all unverified practice/runtime acceptance open. The CodeQL action source confirms that SARIF upload selection and database upload have separate controls; its database-upload implementation additionally refuses non-default branches. The local branch job retains read-only permissions and explicit SARIF `never` selection. No producer execution or upstream repair is inferred from this source review.\n';p.write_text(text)
 p=r/'experiments/issue-1580/work-plan.md';text=p.read_text();text+='\n- Published predecessor `3a71f965`: all 23 workflows pass; all 8 native families plus 3 helper / 8 actual CLI cases pass. Verified 216 collector streams and all 46 full-workflow log streams. Reviewed every non-size diagnostic and the 123 size-warning paths; real dependency and publish-certainty warnings remain open. Current manual producer runtime, original-source 31/53, independent 0/20, remaining 156 Rust template files and all broader unfinished acceptance stay open.\n';p.write_text(text)
 body=(s/'codeql-batch-pr-body.md').read_text();paras=body.splitlines();result=[]
 for line in paras:
  if line.startswith('- Latest completed published-head CI is '):
   line='- Published predecessor `3a71f965e854893a3cb3c5470434ae9a846a3693` finishes all 23 workflows successfully. Native families pass: workflow 104, coding 32, reasoning 141, interfaces 78, benchmarks 11 and Hive 20/10/7. The shared registry helper passes 3 actual native tests and both actual release CLIs pass all 8 cases, including the repaired real Git staging path. [Complete logs and assessment](https://github.com/link-assistant/formal-ai/tree/issue-1580-8d61a32a61e1/experiments/issue-1580/evidence/ci/native-families-3a71f965) preserve 216 verified collector streams and 46 streams for all 23 workflow logs. This newly published producer-path batch still requires its own hosted CI.'
  elif line.startswith('- The fixture regression fails before '):
   line='- The fixture regression fails before and passes after adding the three actual status surfaces. The original CodeQL controls and focused admission controls fail before repair and pass after it. A ninth regression fails on the missing manual path and passes after adding explicit read-only branch verification with the exact production steps and no code-scanning result upload. Local validation passes 9 CodeQL groups, 97 workflow-policy cases, 18 production-profile cases, 32 documentation-policy cases and the full 140-entry gate inventory (87 pass / 53 explicit CI-only exclusions), with unchanged production source identities. No local Rust build runs. Live producer compatibility and original SARIF still require the opt-in hosted run.'
  elif line.startswith('- That completed pipeline emits '):
   line='- Full workflow logs contain 123 actual source-size warnings, one experimental `unsafe-libyaml` maintenance warning (Security lines 542–549) and unresolved crates.io publish-token certainty (pipeline lines 2932–2936). All remain open. Expected canary rejections and quoted shell source are distinguished from emitted failures. Extracting the CodeQL tests removes one former size warning; thresholds and dependency exceptions are unchanged.'
  elif line.startswith('- Selected production review covers '):line=line.replace('180/373 files and 26,781 lines; 193 files','217/373 files and 33,860 lines; 156 files').replace('The current twelve-file CodeQL/admission patch is reviewed','The twelve-file CodeQL/admission patch and four-file producer-path change are reviewed')
  elif line.startswith('- Correct the native release fixture '):line+=' Allow an explicit manual read-only CodeQL producer run on a branch, sharing the main producer steps and preserving their original reports.'
  elif line.startswith('Unfinished acceptance is tracked '):line=line.replace('current-head CI,','new producer-path CI and live producer reports,')
  result.append(line)
 (s/'codeql-producer-pr-body.md').write_text('\n'.join(result)+'\n')
 for row in json.loads((b/'checked-production-identities.json').read_text()):assert hashlib.sha256((r/row['path']).read_bytes()).hexdigest()==row['sha256']
 paths=['docs/case-studies/issue-1580/codeql-result-checkpoint.md','docs/case-studies/issue-1580/templates/rust-source-review-progress.json','experiments/issue-1580/work-plan.md'];(b/'publication-document-identities.json').write_text(json.dumps([{'path':x,'sha256':hashlib.sha256((r/x).read_bytes()).hexdigest()}for x in paths],indent=2)+'\n')
 scratch.mkdir(exist_ok=False)
 with(scratch/'worker.log').open('wb')as out:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=r,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'checks':a['pullRequestCheckBuckets'],'verifiedStreams':262,'fullIssueComplete':False}));raise SystemExit(0)
rows=[]
try:
 jobs=[('documentation-policy',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/documentation-only-ci-policy.test.mjs'])]
 jobs +=[(gate,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate])for gate in ['check-abbreviations','check-file-size','check-file-size-js-twin']]
 for label,args in jobs:
  p=subprocess.run(args,cwd=r,capture_output=True,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','PYTHONDONTWRITEBYTECODE':'1'});raw=p.stdout+p.stderr;packed=gzip.compress(raw,mtime=0);name='publication-'+label+'.log.gz';(b/name).write_bytes(packed);rows.append({'name':label,'argv':args,'exitCode':p.returncode,'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()});(b/'publication-check-records.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,p.returncode,raw.decode(errors='replace')[-3000:],flush=True);assert p.returncode==0,label
 (scratch/'outcome.json').write_text(json.dumps({'complete':True,'fullIssueComplete':False})+'\n');print('COMPLETE',flush=True)
except BaseException:
 traceback.print_exc();(scratch/'failure.json').write_text(traceback.format_exc());sys.exit(1)
