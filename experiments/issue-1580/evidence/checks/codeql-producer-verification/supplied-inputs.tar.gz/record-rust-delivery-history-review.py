from pathlib import Path
from datetime import datetime,timezone
import re,json,gzip,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');t=s/'templates/rust-complete';names=['rust-case-studies-delivery-histories-read.log'];rows={}
for name in names:
 current=None
 for line in (s/name).read_text().splitlines():
  m=re.match(r'   (?:Output: )?FILE (\S+) LINES (\d+)(?: RANGE (\d+) (\d+))? SHA256 ([0-9a-f]{64})$',line)
  if m:
   current=m[1];row=rows.setdefault(current,{'lines':int(m[2]),'sha256':m[5],'numbered':{},'readLogs':[]});row['readLogs'].append(name+'.gz');continue
  m=re.match(r'   (\d+): (.*)$',line)
  if m and current:
   number=int(m[1]);assert number not in rows[current]['numbered'];rows[current]['numbered'][number]=m[2]
assert len(rows)==6,len(rows)
p=r/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json';d=json.loads(p.read_text());known={x['path']for x in d['files']};ids={x['path']:x for x in json.loads((r/d['all373BlobIdentitiesVerifiedBy']).read_text())};b=r/'experiments/issue-1580/evidence/checks/rust-source-review';total=0
for path,row in rows.items():
 raw=(t/path).read_bytes();lines=raw.decode().splitlines();sha=hashlib.sha256(raw).hexdigest();assert sha==row['sha256']==ids[path]['sha256'];assert len(lines)==row['lines'];assert sorted(row['numbered'].items())==list(enumerate(lines,1)),path;assert path not in known
 d['files'].append({'path':path,'lines':len(lines),'sha256':sha,'readLogs':row['readLogs'],'literalReadRanges':[[1,len(lines)]],'literalReadLines':len(lines),'literalSourceFullyRead':True,'formalAiPracticeImplementationVerified':False});total+=len(lines)
assert total==1016,total
lp=b/'logs.json';logs=json.loads(lp.read_text())
for name in names:
 raw=(s/name).read_bytes();packed=gzip.compress(raw,mtime=0);archive=name+'.gz';assert not any(x['file']==archive for x in logs);(b/archive).write_bytes(packed);logs.append({'file':archive,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
lp.write_text(json.dumps(logs,indent=2)+'\n');d['files'].sort(key=lambda x:x['path']);d['fullyReadFiles']=len(d['files']);d['fullyReadSourceLines']=sum(x['literalReadLines']for x in d['files']);assert(d['fullyReadFiles'],d['fullyReadSourceLines'])==(207,30713);d['observedAt']=datetime.now(timezone.utc).isoformat();d['practiceDecisions'].append({'practice':'Historical directory isolation and release delivery evidence boundaries','templateEvidence':list(rows),'assessment':'All 1,016 numbered lines in six pinned historical case-study files match immutable blob identities. Command-stream virtual directory changes need child cwd isolation or guaranteed finally restoration on success and failure; the historical try/catch example is insufficient. Preserve explicit package-root selection, prerequisite-aware skipped-job conditions, child exit-status propagation, actual package publication and authoritative registry response validation. Prefer step-scoped least-privilege publish credentials with documented dual-name fallback where required and OIDC where supported. Reject curl/grep absence inference, globally exposed tokens and treating a successful job or Git tag as proof of artifact availability. These historical reports do not verify current Formal AI end-to-end delivery or independently generated reasoning.','status':'literal-source-comparison-and-counterpart-runtime-pending'});p.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'fullyReadFiles':207,'fullyReadSourceLines':30713,'remainingFiles':166,'literalLinesAndPinnedIdentitiesVerified':True,'runtimeExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}))
