from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,tarfile,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');b=r/'experiments/issue-1580/evidence/checks/codeql-producer-verification';names=['archive-current-registry-proof.py','archive-current-registry-proof.log','read-current-native-jobs.py','current-native-jobs-post-commit.log','archive-current-native-core.py','archive-current-native-core.log','archive-current-source-warnings.py','archive-current-source-warnings.log','document-and-validate-producer-batch.py','finalize-producer-local-evidence.py','commit-producer-path.py','commit-producer-path.log','review-producer-batch-source.py','review-producer-batch-source.log','refresh-issue-feedback.py','producer-verification-feedback.log','read-rust-case-studies-range.py','record-rust-delivery-history-review.py','record-rust-delivery-history-review.log','record-rust-historical-workflow-review.py','record-rust-historical-workflow-review.log','read-rust-dependency-locks.py','record-rust-dependency-lock-review.py','record-rust-dependency-lock-review.log']
# Keep all supplied drafts and the full original negative-control transcripts, without granting model credit.
names += ['inspect-codeql-upload-controls.py','inspect-codeql-upload-controls.log','review-producer-ci-diagnostics.py','review-producer-ci-diagnostics.log','read-producer-ci-warning-context.py','read-producer-ci-warning-context.log','finalize-producer-publication-evidence.py','finalize-producer-publication-evidence.log','codeql-producer-pr-body.md','correct-producer-diagnostic-archive.py','correct-producer-diagnostic-archive.log','producer-publication-size-failure.log']
for path in sorted(s.glob('*producer*')):
 if path.is_file() and path.suffix in ['.py','.log'] and path.name != 'prepare-producer-evidence-inputs.log' and path.name not in names:names.append(path.name)
for folder in ['codeql-producer-focused','codeql-producer-full','codeql-producer-preflight','codeql-producer-commit','codeql-producer-source-review','current-feedback','codeql-upload-controls','producer-predecessor-ci','producer-publication-preflight','producer-publication-preflight-corrected']:
 for p in sorted((s/folder).iterdir()):
  if p.is_file():names.append(p.relative_to(s).as_posix())
rows=[];buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w',format=tarfile.PAX_FORMAT) as tar:
 for name in sorted(set(names)):
  p=s/name
  if not p.exists():continue
  raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(raw));rows.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
packed=gzip.compress(buffer.getvalue(),mtime=0);(b/'supplied-inputs.tar.gz').write_bytes(packed)
(b/'supplied-inputs.json').write_text(json.dumps({'observedAt':datetime.now(timezone.utc).isoformat(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'records':rows,'independentAuthorshipCredit':0,'scope':'Supplied helpers, drafts, negative controls, validation and refreshed GitHub feedback. These command-driven actions supply no independent reasoning credit.','fullIssueComplete':False},indent=2)+'\n')
print(json.dumps({'files':len(rows),'archiveBytes':len(packed),'archiveSha256':hashlib.sha256(packed).hexdigest()}))
