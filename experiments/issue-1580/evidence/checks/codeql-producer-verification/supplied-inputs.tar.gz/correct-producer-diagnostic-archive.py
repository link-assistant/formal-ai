from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,sys,os,traceback
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');b=r/'experiments/issue-1580/evidence/checks/codeql-producer-verification';ci=r/'experiments/issue-1580/evidence/ci/native-families-3a71f965';scratch=s/'producer-publication-preflight-corrected'
if len(sys.argv)==1:
 p=ci/'all-workflow-logs/diagnostics.json';raw=p.read_bytes();assert len(raw.splitlines())==1622 and len(json.loads(raw))==270;sha=hashlib.sha256(raw).hexdigest();packed=gzip.compress(raw,mtime=0);assert gzip.decompress(packed)==raw;name='diagnostics.json.gz';(p.parent/name).write_bytes(packed)
 index={'file':name,'rawSha256':sha,'archiveSha256':hashlib.sha256(packed).hexdigest(),'rawBytes':len(raw),'rawLines':len(raw.splitlines()),'records':270,'scope':'Original complete diagnostic inventory archived losslessly, using the same storage format as full workflow logs. No warning rule or actual source warning is changed.'};(p.parent/'diagnostics-archive.json').write_text(json.dumps(index,indent=2)+'\n')
 q=p.parent/'diagnostics-review.json';d=json.loads(q.read_text());assert d['rawSha256']==sha;d['sourceArchive']=name;d['sourceArchiveSha256']=index['archiveSha256'];q.write_text(json.dumps(d,indent=2)+'\n');p.unlink();q=ci/'assessment.json';d=json.loads(q.read_text());d['diagnosticArchiveIndex']='all-workflow-logs/diagnostics-archive.json';q.write_text(json.dumps(d,indent=2)+'\n')
 (b/'diagnostic-archive-correction.json').write_text(json.dumps({'observedAt':datetime.now(timezone.utc).isoformat(),'beforeGateExitCode':1,'cause':'The newly generated diagnostic array contains 1,622 lines and exceeds the existing 1,500-line maintained-text limit.','repair':index,'lineLimitChanged':False,'diagnosticRecordsChanged':False,'fullIssueComplete':False},indent=2)+'\n')
 scratch.mkdir(exist_ok=False)
 with(scratch/'worker.log').open('wb')as out:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=r,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'losslessArchiveVerified':True}));raise SystemExit(0)
rows=[]
try:
 for gate in ['check-file-size','check-file-size-js-twin']:
  args=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate];p=subprocess.run(args,cwd=r,capture_output=True,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'});raw=p.stdout+p.stderr;packed=gzip.compress(raw,mtime=0);name='corrected-publication-'+gate+'.log.gz';(b/name).write_bytes(packed);rows.append({'name':gate,'argv':args,'exitCode':p.returncode,'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()});(b/'corrected-publication-check-records.json').write_text(json.dumps(rows,indent=2)+'\n');print(gate,p.returncode,raw.decode(errors='replace'),flush=True);assert p.returncode==0,gate
 (scratch/'outcome.json').write_text(json.dumps({'complete':True,'fullIssueComplete':False})+'\n');print('COMPLETE',flush=True)
except BaseException:
 traceback.print_exc();(scratch/'failure.json').write_text(traceback.format_exc());sys.exit(1)
