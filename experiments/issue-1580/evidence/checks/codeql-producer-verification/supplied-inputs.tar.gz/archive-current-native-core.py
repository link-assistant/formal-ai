from pathlib import Path
import subprocess,json,gzip,hashlib,re
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/ci/native-families-3a71f965/early-core-proof';b.mkdir(exist_ok=True);s=Path('/tmp/issue-1580-research/current-native-core');s.mkdir(exist_ok=True)
v=subprocess.run(['gh','run','view','44702570685','--repo','link-assistant/formal-ai','--json','headSha,jobs,status,conclusion'],cwd=r,capture_output=True,check=True);a=json.loads(v.stdout);assert a['headSha']=='3a71f965e854893a3cb3c5470434ae9a846a3693';(b/'jobs.json').write_bytes(v.stdout);records=[]
for identity in [136174240580,136174486080]:
 j=next(j for j in a['jobs'] if j['databaseId']==identity);assert j['conclusion']=='success';v=subprocess.run(['gh','api','--allow-escape-sequences',f'repos/link-assistant/formal-ai/actions/jobs/{identity}/logs'],cwd=r,capture_output=True,check=True);raw=v.stdout;pack=gzip.compress(raw,mtime=0);name='job-'+str(identity)+'.log';(s/name).write_bytes(raw);(b/(name+'.gz')).write_bytes(pack);records.append({'job':j,'file':name+'.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(pack).hexdigest(),'rawLines':len(raw.splitlines()),'runtimeAcceptancePendingLiteralLogReview':True});print('JOB',identity,j['name'],'LINES',len(raw.splitlines()))
 for n,line in enumerate(raw.decode(errors='replace').splitlines(),1):
  if re.search(r'test result:|CodeQL|codeql|warning::|error::',line):print(n,line)
(b/'records.json').write_text(json.dumps(records,indent=2)+'\n')
