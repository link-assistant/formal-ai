from pathlib import Path
import subprocess,json
r=Path('/tmp/gh-issue-solver-1794900398048')
for args in [['git','branch','--show-current'],['git','status','--short'],['git','diff','HEAD','--','.github/workflows/security.yml','rust/tests/web/security-codeql-results.test.mjs','changelog.d/1580-codeql-producer-verification.md'],['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','5','--json','databaseId,conclusion,createdAt,headSha']]:
 print('COMMAND',json.dumps(args),flush=True);subprocess.run(args,cwd=r,check=True)
