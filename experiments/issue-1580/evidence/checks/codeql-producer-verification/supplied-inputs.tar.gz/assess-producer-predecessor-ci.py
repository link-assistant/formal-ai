from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,os,sys,traceback,re
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/producer-predecessor-ci');b=r/'experiments/issue-1580/evidence/ci/native-families-3a71f965';head='3a71f965e854893a3cb3c5470434ae9a846a3693'
if len(sys.argv)==1:
 outcome=json.loads((b/'outcome.json').read_text());assert outcome['complete']and outcome['success']==23 and not outcome['failed'];s.mkdir(exist_ok=False)
 with(s/'worker.log').open('wb')as out:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=r,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'scratch':str(s)}));raise SystemExit(0)
try:
 latest=json.loads((b/'latest.json').read_text());assert latest['head']==head and len(latest['runs'])==23 and all(x['conclusion']=='success'for x in latest['runs']);records=json.loads((b/'records.json').read_text());verified=[];native=[]
 for row in records:
  for stream in ['stdout','stderr']:
   x=row[stream];packed=(b/x['file']).read_bytes();raw=gzip.decompress(packed);assert hashlib.sha256(packed).hexdigest()==x['archiveSha256']and hashlib.sha256(raw).hexdigest()==x['rawSha256'];verified.append(x['file'])
  if row['name'].startswith('job-'):
   raw=gzip.decompress((b/row['stdout']['file']).read_bytes());lines=raw.decode(errors='replace').splitlines();summaries=[{'line':n,'text':text}for n,text in enumerate(lines,1)if re.search(r'test result:|Ran \d+ tests|test suites.*passed|# pass |# fail ',text)];native.append({'job':int(row['name'][4:]),'file':row['stdout']['file'],'summaries':summaries});print('JOB',native[-1],flush=True)
 # Preserve every successful workflow's log too, so warnings outside the pipeline remain inspectable.
 all_dir=b/'all-workflow-logs';all_dir.mkdir(exist_ok=True);all_records=[];diagnostics=[]
 for row in latest['runs']:
  args=['gh','run','view',str(row['databaseId']),'--repo','link-assistant/formal-ai','--log'];p=subprocess.run(args,cwd=r,capture_output=True);assert p.returncode==0,(row['workflowName'],p.stderr.decode());entry={'workflow':row['workflowName'],'run':row['databaseId'],'url':row['url'],'head':head,'conclusion':row['conclusion'],'argv':args,'exitCode':p.returncode}
  for label,raw in [('stdout',p.stdout),('stderr',p.stderr)]:
   name=str(row['databaseId'])+'.'+label+'.log.gz';packed=gzip.compress(raw,mtime=0);(all_dir/name).write_bytes(packed);entry[label]={'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())}
   if label=='stdout':
    for n,line in enumerate(raw.decode(errors='replace').splitlines(),1):
     if any(x in line for x in ['##[warning]','##[error]','WARNING:','warning:','error:']):diagnostics.append({'workflow':row['workflowName'],'run':row['databaseId'],'line':n,'text':line})
  all_records.append(entry);(all_dir/'records.json').write_text(json.dumps(all_records,indent=2)+'\n');print('ARCHIVED',row['workflowName'],entry['stdout']['lines'],'lines',flush=True)
 (all_dir/'diagnostics.json').write_text(json.dumps(diagnostics,indent=2)+'\n');assessment={'observedAt':datetime.now(timezone.utc).isoformat(),'head':head,'workflowCount':23,'success':23,'failed':[],'verifiedStreams':len(verified),'nativeJobSummaries':native,'allWorkflowLogs':len(all_records),'diagnosticRecords':len(diagnostics),'scope':'All workflows pass on this exact predecessor head. This is not original-source replay or complete issue acceptance. The unexecuted producer path is a later local commit. Source-size and any other diagnostics remain subject to explicit review and repair.','fullIssueComplete':False,'independentAuthorshipCredit':0};(b/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n');(s/'outcome.json').write_text(json.dumps({'complete':True,'verifiedStreams':len(verified),'allWorkflowLogs':len(all_records),'diagnosticRecords':len(diagnostics),'fullIssueComplete':False})+'\n');print('COMPLETE',json.dumps(assessment),flush=True)
except BaseException:
 traceback.print_exc();(s/'failure.json').write_text(traceback.format_exc());sys.exit(1)
