from pathlib import Path
import json,re,gzip,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/ci/native-families-3a71f965';p=b/'all-workflow-logs/diagnostics.json';rows=json.loads(p.read_text());other=[];size=[]
for row in rows:
 text=row['text']
 if 'warning threshold:' in text or ('##[warning]' in text and 'lines (approaching limit of' in text):size.append(row)
 else:other.append(row)
print('ALL',len(rows),'SIZE',len(size),'OTHER',len(other))
for row in other:print(row['workflow'],'RUN',row['run'],'LINE',row['line'],row['text'])
(b/'all-workflow-logs/diagnostics-review.json').write_text(json.dumps({'rawSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'allDiagnosticRecords':len(rows),'sourceSizeRecords':len(size),'otherDiagnosticRecords':other,'fullIssueComplete':False,'classificationPending':True},indent=2)+'\n')
