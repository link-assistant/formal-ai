from pathlib import Path
import subprocess
for cmd in [['rg','-n','--no-ignore','stderr|eprintln|print_error|machine_control|emit|println','rust/src/client_integrations.rs','rust/src/client_integrations','rust/src/agent_cli','rust/src/cli'],['rg','-n','--no-ignore','clear_client_environment|LOG_STDERR|FORMAL_AI_LOG_DIR|TRACE_REQUESTS','rust/tests/integration/with_formal_ai/fixture_env.rs','rust/tests/interface_contracts','scripts/ci-native-regressions.sh','.github/workflows/ci.yml']]:
 r=subprocess.run(cmd,text=True,capture_output=True);print('COMMAND',cmd);print(r.stdout,r.stderr)
for p,a,b in [('rust/src/client_integrations/server.rs',1,210),('rust/src/structured_log.rs',450,535),('rust/tests/integration/with_formal_ai/fixture_env.rs',1,155)]:
 s=Path(p).read_text().splitlines();print('\nFILE',p,'TOTAL',len(s))
 for i in range(a-1,min(b,len(s))):print(f'{i+1}: {s[i]}')
