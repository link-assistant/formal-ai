from pathlib import Path
from datetime import datetime,timezone
import re,json,gzip,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');t=s/'templates/rust-complete';names=['rust-historical-workflow-one-read.log','rust-historical-workflow-two-read.log'];rows={}
for name in names:
 current=None
 for line in (s/name).read_text().splitlines():
  m=re.match(r'   (?:Output: )?FILE (\S+) LINES (\d+)(?: RANGE (\d+) (\d+))? SHA256 ([0-9a-f]{64})$',line)
  if m:
   current=m[1];row=rows.setdefault(current,{'lines':int(m[2]),'sha256':m[5],'numbered':{},'readLogs':[]});row['readLogs'].append(name+'.gz');continue
  m=re.match(r'   (\d+): (.*)$',line)
  if m and current:
   number=int(m[1]);assert number not in rows[current]['numbered'];rows[current]['numbered'][number]=m[2]
assert len(rows)==8,len(rows)
p=r/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json';d=json.loads(p.read_text());known={x['path']for x in d['files']};ids={x['path']:x for x in json.loads((r/d['all373BlobIdentitiesVerifiedBy']).read_text())};b=r/'experiments/issue-1580/evidence/checks/rust-source-review';total=0
for path,row in rows.items():
 raw=(t/path).read_bytes();lines=raw.decode().splitlines();sha=hashlib.sha256(raw).hexdigest();assert sha==row['sha256']==ids[path]['sha256'];assert len(lines)==row['lines'];assert sorted(row['numbered'].items())==list(enumerate(lines,1)),path;assert path not in known
 d['files'].append({'path':path,'lines':len(lines),'sha256':sha,'readLogs':row['readLogs'],'literalReadRanges':[[1,len(lines)]],'literalReadLines':len(lines),'literalSourceFullyRead':True,'formalAiPracticeImplementationVerified':False});total+=len(lines)
assert total==2076,total
lp=b/'logs.json';logs=json.loads(lp.read_text())
for name in names:
 raw=(s/name).read_bytes();packed=gzip.compress(raw,mtime=0);archive=name+'.gz';assert not any(x['file']==archive for x in logs);(b/archive).write_bytes(packed);logs.append({'file':archive,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
lp.write_text(json.dumps(logs,indent=2)+'\n');d['files'].sort(key=lambda x:x['path']);d['fullyReadFiles']=len(d['files']);d['fullyReadSourceLines']=sum(x['literalReadLines']for x in d['files']);assert(d['fullyReadFiles'],d['fullyReadSourceLines'])==(215,32789);d['observedAt']=datetime.now(timezone.utc).isoformat();d['practiceDecisions'].append({'practice':'Historical workflows versus current release and download contracts','templateEvidence':list(rows),'assessment':'All 2,076 numbered lines in eight immutable historical workflow, inventory and download-page files were read. Preserve independent fast checks, cancellation propagation, explicit prerequisite outcomes, root/nested lockfile paths, trusted-publisher workflow identity, step-scoped credentials, authoritative registry validation and documentation builds independent of package publishing. Reject historical floating pins, globally exposed publish credentials, unvalidated curl/grep registry inference, interpolated free-text shell input, prefix-only version-check exemptions, ignored formatting failures and documented success without a final failure guard. Historical before/after workflows are superseded references, not runnable current Formal AI verification. The template download page uses DOM textContent, explicit fetch status and a visible empty-assets state; its screenshot shows v0.1.0 with no desktop assets, so it proves no artifact publication or checksum availability. No counterpart runtime or publication is credited.','status':'literal-source-comparison-and-counterpart-runtime-pending'});d['visualSourceReviews']=[{'path':'docs/screenshots/desktop-download-page.png','sha256':hashlib.sha256((t/'docs/screenshots/desktop-download-page.png').read_bytes()).hexdigest(),'verifiedMime':'PNG image data, 1440 x 1000, 8-bit/color RGB, non-interlaced','viewed':True,'assessment':'Desktop downloads v0.1.0 empty-assets state, with checksum and attestation guidance; no evidence of an available artifact.','runtimeExecuted':False}];p.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'fullyReadFiles':215,'fullyReadSourceLines':32789,'remainingFiles':158,'literalLinesAndPinnedIdentitiesVerified':True,'runtimeExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}))
