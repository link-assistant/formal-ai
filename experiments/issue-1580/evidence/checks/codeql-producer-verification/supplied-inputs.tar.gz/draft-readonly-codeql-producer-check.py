from pathlib import Path
import subprocess,json,gzip,hashlib,traceback,sys
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/checks/codeql-producer-verification';b.mkdir(exist_ok=False)
p=r/'rust/tests/web/security-codeql-results.test.mjs';t=p.read_text();assert "import { Script } from 'node:vm';" not in t;t=t.replace("import YAML from 'yaml';", "import YAML from 'yaml';\nimport { Script } from 'node:vm';")
t+='''

test('manual producer verification is explicit, read-only and shares the production analysis', () => {
  const workflow = YAML.parse(readFileSync('.github/workflows/security.yml', 'utf8'));
  const production = workflow.jobs.codeql;
  const verification = workflow.jobs['codeql-readonly'];
  assert.ok(verification, 'original producer reports need an opt-in branch verification path');
  assert.deepEqual(workflow.on.workflow_dispatch.inputs.codeql,
    { description: 'Run read-only CodeQL producer verification on this branch', required: false,
      default: false, type: 'boolean' });
  assert.deepEqual(verification.permissions, { actions: 'read', contents: 'read' });
  assert.deepEqual(verification.strategy, production.strategy);
  assert.deepEqual(verification.env, production.env);
  assert.deepEqual(verification.steps, production.steps,
    'the producer pin, analysis, result gate and report archive must be the same implementation');
  assert.equal(verification['timeout-minutes'], production['timeout-minutes']);
  const evaluate = (expression, github, inputs = {}) =>
    new Script(expression.trim().slice(3, -2)).runInNewContext({github, inputs}, {timeout: 100});
  for (const [event, ref, optedIn, expected] of [
    ['pull_request', 'refs/pull/1581/merge', true, false],
    ['pull_request_target', 'refs/heads/main', true, false],
    ['push', 'refs/heads/main', true, false],
    ['workflow_dispatch', 'refs/heads/main', true, false],
    ['workflow_dispatch', 'refs/heads/fix/example', false, false],
    ['workflow_dispatch', 'refs/heads/fix/example', true, true],
  ]) assert.equal(Boolean(evaluate(verification.if, {event_name: event, ref}, {codeql: optedIn})), expected,
    `${event} ${ref} codeql=${optedIn}`);
  assert.equal(Boolean(evaluate(verification.if,
    {event_name: 'workflow_dispatch', ref: 'refs/heads/fix/example'})), false,
    'existing checks-mode bot dispatch must remain light');
  const analysis = production.steps.find(step => step.uses?.startsWith('github/codeql-action/analyze@'));
  assert.equal(evaluate(analysis.with.upload, {job: 'codeql'}), 'always');
  for (const job of ['codeql-readonly', 'unexpected-job'])
    assert.equal(evaluate(analysis.with.upload, {job}), 'never', 'read-only analysis must not upload code scanning state');
  assert.ok(verification.steps.every(step => !/cache(?:@|\\/save@)|attest@/u.test(step.uses ?? '')));
  assert.equal(verification.steps.find(step => step.uses?.startsWith('actions/checkout@')).with['persist-credentials'], false);
});
'''
p.write_text(t)
args=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/security-codeql-results.test.mjs'];v=subprocess.run(args,cwd=r,capture_output=True);raw=v.stdout+v.stderr;(b/'before.log.gz').write_bytes(gzip.compress(raw,mtime=0));assert v.returncode!=0 and b'original producer reports need an opt-in branch verification path' in raw;print('BEFORE',v.returncode,raw.decode()[-1800:])
p=r/'.github/workflows/security.yml';t=p.read_text();needle="        options: [checks]\n";assert t.count(needle)==1;t=t.replace(needle,needle+"      codeql:\n        description: 'Run read-only CodeQL producer verification on this branch'\n        required: false\n        default: false\n        type: boolean\n")
needle='    env:\n      # Issue #1017 / github/codeql#19982.';assert t.count(needle)==1;t=t.replace(needle,'    env: &codeql-extractor-environment\n      # Issue #1017 / github/codeql#19982.')
start=t.index('  codeql:\n');end=t.index('  cargo-audit:\n',start);job=t[start:end];assert job.count('    steps:\n')==1;job=job.replace('    steps:\n','    steps: &codeql-analysis-steps\n');needle='          output: ${{ runner.temp }}/codeql-results\n';assert job.count(needle)==1;job=job.replace(needle,needle+"          upload: ${{ github.job == 'codeql' && 'always' || 'never' }}\n");job=job.replace('name: codeql-results-${{ matrix.language }}','name: codeql-results-${{ matrix.language }}-${{ github.job }}');t=t[:start]+job+t[end:]
readonly='''  # Explicit branch verification reuses the exact producer and keeps all tokens read-only.
  # Default PR/bot dispatches stay light; only the main job uploads code-scanning state.
  codeql-readonly:
    if: ${{ github.event_name == 'workflow_dispatch' && github.ref != 'refs/heads/main' && inputs.codeql }}
    name: CodeQL producer verification (${{ matrix.language }})
    runs-on: ubuntu-24.04
    timeout-minutes: 30
    concurrency:
      group: check-${{ github.workflow }}-${{ github.ref }}-codeql-readonly-${{ matrix.language }}
      cancel-in-progress: ${{ github.ref != 'refs/heads/main' }}
    permissions:
      actions: read
      contents: read
    strategy:
      fail-fast: false
      matrix:
        language: [rust, actions]
    env: *codeql-extractor-environment
    steps: *codeql-analysis-steps

'''
assert '  codeql-readonly:\n' not in t;t=t.replace('  cargo-audit:\n',readonly+'  cargo-audit:\n');p.write_text(t)
p=r/'changelog.d/1580-codeql-producer-verification.md';p.write_text('bump: patch\n\nAllow explicit read-only CodeQL producer verification on a branch while retaining the automatic main-only analysis and report upload.\n')
(b/'negative-control.json').write_text(json.dumps({'beforeExitCode':v.returncode,'expectedFailure':'original producer reports need an opt-in branch verification path','beforeRawSha256':hashlib.sha256(raw).hexdigest(),'readOnlyDispatchExecuted':False,'nativeCompilationExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n');print('DRAFTED: no runtime CodeQL claim')
