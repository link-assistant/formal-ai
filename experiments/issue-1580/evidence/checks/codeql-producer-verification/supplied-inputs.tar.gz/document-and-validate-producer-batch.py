from pathlib import Path
import subprocess,json,gzip,hashlib,time,os,traceback,sys
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/checks/codeql-producer-verification';s=Path('/tmp/issue-1580-research/codeql-producer-full')
if len(sys.argv)==1:
 p=r/'docs/case-studies/issue-1580/codeql-result-checkpoint.md';t=p.read_text();t+='''

## Explicit original-producer verification draft

The next draft adds an opt-in `codeql` boolean to manual workflow dispatches.
Only an opted-in branch dispatch selects `codeql-readonly`; ordinary PR and bot
checks remain light. The job grants only `actions: read` and `contents: read`.
It reuses the production environment and complete analysis steps through YAML
anchors, and its analysis explicitly sets `upload: never`. Only the existing
main production job can set `upload: always`. Report archives include the job
identity, so the two consumers cannot collide.

GitHub documents workflow anchors and aliases at
https://docs.github.com/en/actions/reference/workflows-and-actions/reusing-workflow-configurations.
The actual parsed workflow regression checks the shared steps, permissions,
all relevant event/ref/input combinations and the upload expression. It fails
against the workflow before this path exists; all nine CodeQL groups, eighteen
production-profile cases and 97 workflow-policy cases pass with the draft.
This is local contract evidence. No original producer has run through this new
path yet; extraction compatibility and all findings remain unfinished.

The additional eight pinned Rust guides bring literal review to 188/373 files
and 27,942 lines. Every numbered line and blob identity is verified. The remaining
185 files and all unverified practice/runtime requirements remain open.
''';p.write_text(t)
 p=r/'experiments/issue-1580/work-plan.md';t=p.read_text();t+='''

### Read-only original CodeQL producer verification, 2026-11-20

- [x] Draft an explicit opt-in manual branch job with read-only permissions, no code-scanning uploads and exactly shared production analysis steps/environment. Keep automatic production analysis main-only and default PR/bot dispatches light. Preserve the failing-before test, all nine passing CodeQL groups, eighteen production-profile cases and 97 workflow-policy cases. Refresh the retained main-job payload identity without removing any retained behavior.
- [x] Read eight further pinned Rust troubleshooting/release guides in full and verify every numbered line and immutable blob hash. Literal coverage is 188/373 files and 27,942 lines; the remaining 185 files and every unverified practice/runtime criterion remain unfinished.
- [ ] Run the complete local gate inventory on the final source, collect every current-head workflow and actionable failure, preserve all logs, then publish one combined batch only after the single-push gate permits it.
- [ ] Dispatch the explicit read-only producer check on the published branch. Preserve and inspect original SARIF, actual invocation/extraction diagnostics and both known Actions findings. Repair verified issues with regression evidence; an upstream report is not a completed repair.
- [ ] Complete all original acceptance criteria, strict source replay deficits, historical budgets, source-size warnings, eight template/practice comparisons, runtime/delivery, complete PR review and independent Formal AI reasoning. Keep PR #1581 draft and unmerged; supplied commands and patches earn zero independent credit.
''';p.write_text(t)
 s.mkdir(exist_ok=False)
 files=['.github/workflows/security.yml','rust/tests/web/security-codeql-results.test.mjs','data/benchmarks/fast-pull-request-retained-jobs.json','changelog.d/1580-codeql-producer-verification.md','docs/case-studies/issue-1580/codeql-result-checkpoint.md','docs/case-studies/issue-1580/templates/rust-source-review-progress.json','experiments/issue-1580/work-plan.md','experiments/issue-1580/evidence/checks/codeql-producer-verification','experiments/issue-1580/evidence/checks/rust-source-review']
 subprocess.run(['git','add','--',*files],cwd=r,check=True)
 (b/'source-identities.json').write_text(json.dumps([{'path':f,'sha256':hashlib.sha256((r/f).read_bytes()).hexdigest()}for f in files if(r/f).is_file()],indent=2)+'\n')
 with(s/'worker.log').open('wb')as out:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=r,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'scratch':str(s)}));raise SystemExit(0)
records=[]
try:
 for label,args in [('all-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs']),('diff-check',['git','diff','--check']),('staged-diff-check',['git','diff','--cached','--check'])]:
  start=time.monotonic();v=subprocess.run(args,cwd=r,capture_output=True,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','PYTHONDONTWRITEBYTECODE':'1'});raw=v.stdout+v.stderr;pack=gzip.compress(raw,mtime=0);(b/(label+'.log.gz')).write_bytes(pack);records.append({'label':label,'argv':args,'exitCode':v.returncode,'seconds':round(time.monotonic()-start,2),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(pack).hexdigest()});(b/'full-validation-records.json').write_text(json.dumps(records,indent=2)+'\n');print(label,v.returncode,raw.decode(errors='replace')[-3600:],flush=True)
  if v.returncode:raise RuntimeError(label+' failed')
 (s/'outcome.json').write_text(json.dumps({'complete':True,'fullIssueComplete':False})+'\n');print('COMPLETE',flush=True)
except BaseException:
 traceback.print_exc();(s/'failure.json').write_text(traceback.format_exc());sys.exit(1)
