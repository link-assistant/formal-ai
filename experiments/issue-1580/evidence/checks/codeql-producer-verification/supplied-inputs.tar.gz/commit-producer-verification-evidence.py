from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,gzip
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');b=r/'experiments/issue-1580/evidence/checks/codeql-producer-verification';scratch=s/'producer-evidence-commit';scratch.mkdir(exist_ok=False)
assert json.loads((s/'producer-publication-preflight-corrected/outcome.json').read_text())['complete']
assert subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip()=='issue-1580-8d61a32a61e1'
for name in ['checked-production-identities.json','publication-document-identities.json']:
 for row in json.loads((b/name).read_text()):assert hashlib.sha256((r/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
subprocess.run(['python3',str(s/'prepare-producer-evidence-inputs.py')],cwd=r,check=True)
paths=['docs/case-studies/issue-1580/codeql-result-checkpoint.md','docs/case-studies/issue-1580/templates/rust-source-review-progress.json','experiments/issue-1580/work-plan.md','experiments/issue-1580/evidence/checks/codeql-producer-verification','experiments/issue-1580/evidence/checks/rust-source-review','experiments/issue-1580/evidence/ci/native-families-3a71f965']
subprocess.run(['git','add','--',*paths],cwd=r,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=r).decode().strip('\x00').split('\x00');assert all(any(x==p or x.startswith(p+'/')for p in paths)for x in staged)
for name,args in [('diff-check',['git','diff','--check']),('staged-diff-check',['git','diff','--cached','--check']),('commit',['git','commit','-m','Record passing native CI and CodeQL producer verification checks'])]:
 v=subprocess.run(args,cwd=r,capture_output=True);(scratch/(name+'.stdout')).write_bytes(v.stdout);(scratch/(name+'.stderr')).write_bytes(v.stderr);assert v.returncode==0,(name,v.stderr.decode());print(name,v.returncode,v.stdout.decode()[-1200:],v.stderr.decode(),flush=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();status=subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True);assert status=='',status;(scratch/'outcome.json').write_text(json.dumps({'complete':True,'head':head,'files':len(staged),'pushExecuted':False,'fullIssueComplete':False,'createdAt':datetime.now(timezone.utc).isoformat()})+'\n');print('HEAD',head,'FILES',len(staged),'CLEAN',True)
