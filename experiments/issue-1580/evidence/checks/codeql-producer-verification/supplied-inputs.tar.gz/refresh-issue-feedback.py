from pathlib import Path
import subprocess,json
root=Path('/tmp/issue-1580-research/current-feedback');root.mkdir(exist_ok=True)
commands={'issue':['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','title,body,url,state'],'pr':['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','title,body,url,state,isDraft,headRefOid,mergeStateStatus'],'issue-comments':['gh','api','repos/link-assistant/formal-ai/issues/1580/comments','--paginate'],'pr-comments':['gh','api','repos/link-assistant/formal-ai/issues/1581/comments','--paginate'],'pr-inline':['gh','api','repos/link-assistant/formal-ai/pulls/1581/comments','--paginate'],'pr-reviews':['gh','api','repos/link-assistant/formal-ai/pulls/1581/reviews','--paginate'],'runs':['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','5','--json','databaseId,conclusion,createdAt,headSha,status,workflowName']}
for name,args in commands.items():
 r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(root/(name+'.json')).write_bytes(r.stdout);assert r.returncode==0,(name,r.stderr.decode());data=json.loads(r.stdout)
 if name in ['issue','pr']:print(name,json.dumps(data,ensure_ascii=False))
 elif name=='runs':print(name,json.dumps(data))
 else:
  print(name,'count',len(data))
  for item in data:print(json.dumps({k:item.get(k)for k in ['id','html_url','user','created_at','submitted_at','state','body']},ensure_ascii=False))
