from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,os,re,subprocess,sys,time,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'maintained-metadata-preservation';verified=scratch/'maintained-metadata-headroom'
if len(sys.argv)==1:
 out.mkdir(exist_ok=True)
 for name in ['worker.log','failed.txt']:
  old=out/name
  if old.exists():old.rename(out/('earlier-launch-'+name))
 with (out/'worker.log').open('w') as stream:
  child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 assert result.returncode==0,(name,result.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 for attempt in range(15):
  if (verified/'failed.txt').exists():break
  time.sleep(1)
 assert (verified/'failed.txt').exists()
 gates=(verified/'all-local-gates.stdout').read_text();failures=re.findall(r'^FAIL ([^ ]+)',gates,re.M);assert failures==['check-notation','check-status-render'],failures
 (out/'initial-notation-failure.log').write_bytes((root/'experiments/formal_ai_subagent/sandboxes/gates/check-notation.log').read_bytes())
 # Balance complete records so a tiny tail shard does not introduce a new
 # majority-valued field into the unchanged notation ratchet.
 archive=(verified/'preimages/data/meta/self-hosting-ledger-parts/0001.lino').read_text()
 header='self-hosting-ledger-archive\n';rows=['  release\n'+row for row in archive.split('  release\n')[1:]]
 candidates=[]
 from collections import Counter
 def repeated(records):
  counts=Counter(line for row in records for line in set(row.splitlines()[1:]))
  return {line for line,count in counts.items() if len(records)>=4 and count*2>len(records)}
 original=repeated(rows)
 for index in range(1,len(rows)):
  groups=[rows[:index],rows[index:]];parts=[header+''.join(group) for group in groups]
  lengths=[len(part.splitlines()) for part in parts]
  if max(lengths)<=1400 and (repeated(groups[0])|repeated(groups[1]))<=original:
   candidates.append((abs(lengths[0]-lengths[1]),index,parts))
 assert candidates
 _,boundary,parts=min(candidates)
 for index,part in enumerate(parts,1):
  file=root/f'data/meta/self-hosting-ledger-parts/{index:04}.lino'
  (out/f'unbalanced-{index:04}.lino').write_bytes(file.read_bytes());file.write_text(part)
 assert ''.join(part.removeprefix(header) for part in parts)==archive.removeprefix(header)
 (out/'balanced-archive-conservation.json').write_text(json.dumps({'boundary':boundary,'recordCounts':[boundary,len(rows)-boundary],'lines':[len(part.splitlines()) for part in parts],'completeArchiveExactInverse':True,'noNewRepeatedField':True},indent=2)+'\n')
 (out/'initial-status-render-failure.log').write_bytes((root/'experiments/formal_ai_subagent/sandboxes/gates/check-status-render.log').read_bytes())
 status=root/'docs/status.md';before=status.read_bytes();(out/'status-before.md').write_bytes(before)
 run('render-status-write',['node','--max-old-space-size=256','scripts/render-status.mjs','--write']);after=status.read_bytes();(out/'status-after.md').write_bytes(after)
 before_rows=before.decode().splitlines();after_rows=after.decode().splitlines();changed=[(a,b) for a,b in zip(before_rows,after_rows) if a!=b]
 assert len(before_rows)==len(after_rows) and len(changed)==1 and all('`data/meta/self-hosting-ledger.lino`' in value for value in changed[0]),changed
 assert int(changed[0][1].split('|')[-2])-int(changed[0][0].split('|')[-2])==1
 doc=root/'docs/case-studies/issue-1580/metadata-storage-headroom-checkpoint.md';doc.write_text('# Maintained metadata storage headroom\n\nThe rename map and release-ledger archive exceeded the unchanged 1,400-line\nwarning threshold. The existing include loader now reads the complete rename\nbody from a named shard. All rename fields, rule order, resort entries and\nexisting exclusions are unchanged; the sole added exclusion names the shard.\nThe original map is exactly reconstructible from its container and shard.\n\nThe release archive is split only between complete records. Concatenating its\nrecord bodies reconstructs the original archive exactly, and the expanded\nledger retains all records, order and inherited defaults. Both writers rotate\nnew data at 1,400 lines while retaining compatibility with legacy 1,500-line\narchives. Read bounds, canonical names, symlink rejection and exclusive writes\nremain enforced. New boundary regressions fail before and pass after repair;\nthe existing storage suite and complete maintained issue suite pass.\n\nThe full 141-entry gate replay found a stale generated status line census.\nThe maintained status generator updated just the root-ledger line count; the\nfailed replay and successful focused replay are both retained. Source scanning\nreports 44 warnings, zero violations, with unchanged thresholds. Native Rust\nformat checks pass; native execution remains for hosted CI.\n\nEvidence: `experiments/issue-1580/evidence/checks/metadata-storage-headroom/`.\nSupplied procedures receive zero independent authorship credit. Wider issue\nwork remains unfinished, and PR #1581 stays draft and unmerged:\nhttps://github.com/link-assistant/formal-ai/pull/1581.\n')
 fragment=root/'changelog.d/20261121_1580_metadata_storage_headroom.md';fragment.write_text('### Fixed\n\n- Keep rename metadata and release-ledger writes below the existing size-warning threshold without losing rules, historical records, defaults or legacy archive compatibility.\n')
 run('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-notation,check-status-render,check-render-status-js-twin,check-abbreviations,check-file-size,check-changelog-fragment-js-twin,check-reconstructed-changelog'])
 run('balanced-storage-tests',['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/metadata-storage-headroom.test.mjs'])
 run('source-warnings',['node','--max-old-space-size=256','scripts/check-file-size.mjs']);warnings=(out/'source-warnings.stdout').read_text().count('::warning file=');assert warnings==44,warnings
 run('rustfmt-check',['rustfmt','--check','--edition','2024','scripts/self-hosting-ledger.rs']);run('whitespace',['git','diff','--check'])
 summary={'complete':True,'warnings':warnings,'fullGateEntries':141,'initialGateFailures':failures,'failedGatesRepairedAndReplayed':True,'maintainedIssueTestsPassed':264,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
 assert 'ℹ pass 264' in (verified/'maintained-observations.stdout').read_text()
 (verified/'outcome.json').write_text(json.dumps(summary,indent=2)+'\n')
 target=root/'experiments/issue-1580/evidence/checks/metadata-storage-headroom';target.mkdir(exist_ok=False);records=[]
 def archive(source,relative):
  raw=source.read_bytes();packed=gzip.compress(raw,mtime=0);dest=target/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed);records.append({'file':relative,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
 for source in sorted(verified.rglob('*')):
  if source.is_file() and source.name!='pid.json':archive(source,'verification/'+str(source.relative_to(verified))+'.gz')
 for source in sorted(out.glob('*')):
  if source.is_file() and source.name not in ['worker.log','pid.json']:archive(source,'final-verification/'+source.name+'.gz')
 helpers=['repair-maintained-metadata-headroom.py',Path(__file__).name]
 for name in helpers:archive(scratch/name,'supplied-helpers/'+name+'.gz')
 for source in sorted((root/'experiments/issue-1580/evidence/commands').glob('*.json')):
  if source.name[:19]<'2026-11-21T17-00-00':continue
  if any(name in json.loads(source.read_text())['request'] for name in helpers):archive(source,'formal-sessions/'+source.name+'.gz')
 (target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records));(target/'identity.json').write_text(json.dumps(summary,indent=2)+'\n')
 paths=['data/meta/rename-map.lino','data/meta/rename-map/maintained-file-renames.lino','data/meta/self-hosting-ledger.lino','data/meta/self-hosting-ledger-parts/0001.lino','data/meta/self-hosting-ledger-parts/0002.lino','scripts/self-hosting-ledger.mjs','scripts/self-hosting-ledger.rs','rust/tests/web/self-hosting-ledger-storage.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs','experiments/issue-1580/metadata-storage-headroom.test.mjs','docs/status.md',str(doc.relative_to(root)),str(fragment.relative_to(root)),str(target.relative_to(root))]
 assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1';assert run('staged-before',['git','diff','--cached','--name-only']).strip()==''
 run('stage',['git','add','--',*paths]);run('staged-whitespace',['git','diff','--cached','--check']);run('staged-secrets',['bash','scripts/check-secrets.sh'])
 for row in records:
  packed=(target/row['file']).read_bytes();raw=gzip.decompress(packed);assert hashlib.sha256(raw).hexdigest()==row['rawSha256'] and hashlib.sha256(packed).hexdigest()==row['archiveSha256'] and len(raw)==row['bytes'] and len(raw.splitlines())==row['lines']
 run('commit',['git','commit','-m','Retain metadata headroom with lossless rename and ledger storage'])
 (out/'outcome.json').write_text(json.dumps({'committed':True,'head':run('committed-head',['git','rev-parse','HEAD']).strip(),'archives':len(records),'pushed':False,'fullIssueComplete':False},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
