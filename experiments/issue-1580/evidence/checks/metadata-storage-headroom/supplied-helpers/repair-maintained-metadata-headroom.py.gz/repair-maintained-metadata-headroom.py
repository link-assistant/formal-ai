from pathlib import Path
import hashlib,json,os,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/maintained-metadata-headroom')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:
  child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args,allowed=(0,)):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':result.returncode}),flush=True);assert result.returncode in allowed,(name,result.returncode)
 return (out/(name+'.stdout')).read_text()
def node(name,source):return run(name,['node','--max-old-space-size=256','--input-type=module','--eval',source])
try:
 paths=['data/meta/rename-map.lino','data/meta/self-hosting-ledger.lino','data/meta/self-hosting-ledger-parts/0001.lino','scripts/self-hosting-ledger.mjs','scripts/self-hosting-ledger.rs','rust/tests/web/self-hosting-ledger-storage.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs']
 for path in paths:
  dest=out/'preimages'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((root/path).read_bytes())
 snapshot='''import {loadRenameMap} from './experiments/formal_ai_subagent/rename-by-rule.mjs';
import {readLedger} from './scripts/self-hosting-ledger.mjs';
console.log(JSON.stringify({renames:loadRenameMap(),ledger:readLedger('data/meta/self-hosting-ledger.lino')}));'''
 previous=json.loads(node('semantic-before',snapshot))
 test=root/'experiments/issue-1580/metadata-storage-headroom.test.mjs'
 test.write_text('''// Maintained storage must retain source-size headroom without deleting records.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import test from 'node:test';
import {checkListedFiles} from '../../scripts/check-file-size.mjs';
import {loadRenameMap} from '../formal_ai_subagent/rename-by-rule.mjs';
import {readLedger} from '../../scripts/self-hosting-ledger.mjs';
const root=fileURLToPath(new URL('../../',import.meta.url)).replace(/\\/$/u,'');
test('the complete maintained rename map retains source-size headroom',()=>{
 const map=loadRenameMap(root);
 const files=new Set(map.exclude.filter(path=>path==='data/meta/rename-map.lino'||path.startsWith('data/meta/rename-map/')));
 assert(files.size>=3);
 assert.deepEqual(checkListedFiles(root,files),{warnings:[],violations:[],embeddedDataViolations:[]});
 assert(map.renames.some(row=>row.tree==='browser-worker-modules'));
 assert(map.renames.some(row=>row.tree==='shared-application-constants'));
});
test('the complete maintained release ledger retains source-size headroom',()=>{
 const file='data/meta/self-hosting-ledger.lino',source=readFileSync(root+'/'+file,'utf8');
 const parts=[...source.matchAll(/^  archive "([^"\\n]+)"$/gmu)].map(match=>'data/meta/'+match[1]);
 assert(parts.length>0);
 assert.deepEqual(checkListedFiles(root,new Set([file,...parts])),{warnings:[],violations:[],embeddedDataViolations:[]});
 assert(readLedger(root+'/'+file).includes('tag "v0.296.0"'));
});
''')
 ledger_test=root/'rust/tests/web/self-hosting-ledger-storage.test.mjs'
 ledger_test.write_text(ledger_test.read_text()+'''
test('new writes rotate before the unchanged 1400-line warning threshold',t=>{
 const before='self_hosting_ledger\\n'+Array.from({length:99},(_,i)=>row(i)).join('');
 const f=fixture(t,before);appendLedger(f.file,row(99));
 assert.deepEqual(records(readLedger(f.file)),records(before+row(99)));
 for(const file of [f.file,...readdirSync(f.parts).map(name=>join(f.parts,name))])
  assert(readFileSync(file,'utf8').trimEnd().split('\\n').length<=1400);
});
test('legacy archives up to the existing hard limit remain readable',t=>{
 const f=fixture(t,'self_hosting_ledger\\n  archive "self-hosting-ledger-parts/0001.lino"\\n'+row(107));mkdirSync(f.parts);
 const archive='self-hosting-ledger-archive\\n'+Array.from({length:107},(_,i)=>row(i)).join('');
 assert.equal(archive.trimEnd().split('\\n').length,1499);
 writeFileSync(join(f.parts,'0001.lino'),archive);
 assert.deepEqual(records(readLedger(f.file)),records(archive+row(107)));
});
''')
 run('headroom-before',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)],(1,))
 run('rotation-before',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(ledger_test)],(1,))
 rename=root/'data/meta/rename-map.lino';source=rename.read_text();offset=source.index('  tree browser-worker-modules\n');prefix=source[:offset];body=source[offset:]
 shard=root/'data/meta/rename-map/maintained-file-renames.lino';assert not shard.exists();shard.write_text('rename-map\n'+body);rename.write_text(prefix+'  include "data/meta/rename-map/maintained-file-renames.lino"\n')
 assert rename.read_text().replace('  include "data/meta/rename-map/maintained-file-renames.lino"\n',shard.read_text().removeprefix('rename-map\n'))==source
 first=root/'data/meta/self-hosting-ledger-parts/0001.lino';archive=first.read_text();header,body=archive.split('  release\n',1);assert header=='self-hosting-ledger-archive\n';rows=['  release\n'+row for row in body.split('  release\n')];chunks=[];chunk=header
 for row in rows:
  assert len((header+row).splitlines())<=1400
  if len((chunk+row).splitlines())>1400:chunks.append(chunk);chunk=header
  chunk+=row
 if chunk!=header:chunks.append(chunk)
 assert len(chunks)==2 and ''.join(part.removeprefix(header) for part in chunks)==archive.removeprefix(header)
 second=first.with_name('0002.lino');assert not second.exists();first.write_text(chunks[0]);second.write_text(chunks[1]);ledger=root/'data/meta/self-hosting-ledger.lino';text=ledger.read_text();directive='  archive "self-hosting-ledger-parts/0001.lino"\n';assert text.count(directive)==1;ledger.write_text(text.replace(directive,directive+'  archive "self-hosting-ledger-parts/0002.lino"\n',1))
 js=root/'scripts/self-hosting-ledger.mjs';text=js.read_text();assert text.count('LIMIT=1500')==1;text=text.replace('LIMIT=1500','READ_LIMIT=1500,WRITE_LIMIT=1400');text=text.replace('count(part)<=LIMIT','count(part)<=READ_LIMIT');text=text.replace('<=LIMIT','<=WRITE_LIMIT').replace('>LIMIT','>WRITE_LIMIT');assert 'READ_WRITE_LIMIT' not in text;js.write_text(text)
 native=root/'scripts/self-hosting-ledger.rs';text=native.read_text();assert text.count('const LIMIT: usize = 1_500;')==1;text=text.replace('const LIMIT: usize = 1_500;','const READ_LIMIT: usize = 1_500;\nconst WRITE_LIMIT: usize = 1_400;');text=text.replace('part.lines().count() > LIMIT','part.lines().count() > READ_LIMIT');text=text.replace('<= LIMIT','<= WRITE_LIMIT').replace('> LIMIT','> WRITE_LIMIT');assert 'READ_WRITE_LIMIT' not in text
 text+='''
#[cfg(test)]
mod headroom_tests {
    use super::*;
    use std::time::{SystemTime, UNIX_EPOCH};

    #[test]
    fn new_writes_retain_headroom_and_old_archives_remain_readable() {
        let nonce = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
        let directory = std::env::temp_dir().join(format!("formal-ledger-headroom-{}-{nonce}", std::process::id()));
        fs::create_dir(&directory).unwrap();
        let ledger = directory.join("self-hosting-ledger.lino");
        let row = "  release\\n    tag \\\"retained\\\"\\n";
        fs::write(&ledger, format!("self_hosting_ledger\\n{}", row.repeat(699))).unwrap();
        append(&ledger, row).unwrap();
        assert!(fs::read_to_string(&ledger).unwrap().lines().count() <= WRITE_LIMIT);
        let part = directory.join("self-hosting-ledger-parts/0001.lino");
        assert!(read_text(&part).unwrap().lines().count() <= WRITE_LIMIT);
        let legacy = format!("self-hosting-ledger-archive\\n{}", row.repeat(749));
        assert_eq!(legacy.lines().count(), 1499);
        fs::write(&part, &legacy).unwrap();
        assert!(read(&ledger).unwrap().starts_with(&legacy));
        fs::remove_dir_all(&directory).unwrap();
    }
}
''';native.write_text(text)
 current=json.loads(node('semantic-after',snapshot));expected=json.loads(json.dumps(previous));expected['renames']['exclude'].insert( len(previous['renames']['exclude'])-2,'data/meta/rename-map/maintained-file-renames.lino')
 # The include loader adds only the newly named container to exclusions; every rule and its order must remain identical.
 assert current['renames']['renames']==previous['renames']['renames'] and current['renames']['resort']==previous['renames']['resort']
 assert [item for item in current['renames']['exclude'] if item!='data/meta/rename-map/maintained-file-renames.lino']==previous['renames']['exclude']
 def normalized(value):return '\n'.join(line for line in value.splitlines() if line!='self-hosting-ledger-archive' and not line.startswith('  archive '))
 assert normalized(current['ledger'])==normalized(previous['ledger'])
 (out/'conservation.json').write_text(json.dumps({'renameRules':len(previous['renames']['renames']),'renameRuleOrderUnchanged':True,'renameFieldsUnchanged':True,'renameResortsUnchanged':True,'rootMapExactInverse':True,'ledgerArchiveExactInverse':True,'completeExpandedLedgerRecordsAndDefaultsUnchanged':True,'oldArchiveReadLimit':1500,'newWriteHeadroom':1400,'preimagesRetained':True,'nativeExecutionVerified':False,'independentAuthorshipCredit':0},indent=2)+'\n')
 owner=root/'rust/tests/web/issue-1580-template-observations.test.mjs';text=owner.read_text()
 for addition in ["import '../../../experiments/issue-1580/metadata-storage-headroom.test.mjs';\n","import './self-hosting-ledger-storage.test.mjs';\n"]:assert addition not in text;text+='\n'+addition
 owner.write_text(text)
 run('rustfmt',['rustfmt','--edition','2024',str(native)])
 run('headroom-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)])
 run('rotation-after',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(ledger_test)])
 run('rename-map-regression',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/rename-by-rule.test.mjs'])
 run('maintained-observations',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(owner)])
 run('all-local-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs'])
 run('source-warnings',['node','--max-old-space-size=256','scripts/check-file-size.mjs'])
 warnings=(out/'source-warnings.stdout').read_text().count('::warning file=');assert warnings==44,warnings
 run('rustfmt-check',['rustfmt','--check','--edition','2024',str(native)]);run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'warnings':warnings,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
