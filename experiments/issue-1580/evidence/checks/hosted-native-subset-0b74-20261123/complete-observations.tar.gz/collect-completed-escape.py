from pathlib import Path
import datetime,gzip,json,subprocess
root=Path('/tmp/issue-1580-research/0b74-native-observations')
records=[]
for job in [137805885687,137805885852,137805885912]:
 result=subprocess.run(['gh','api','repos/link-assistant/formal-ai/actions/jobs/'+str(job)],capture_output=True)
 (root/(str(job)+'.json')).write_bytes(result.stdout);assert result.returncode==0
 metadata=json.loads(result.stdout);assert metadata['conclusion']=='success'
 command=['gh','api','--allow-escape-sequences','repos/link-assistant/formal-ai/actions/jobs/'+str(job)+'/logs']
 with (root/(str(job)+'-escape.log.gz')).open('wb') as destination:
  with gzip.GzipFile(filename='',mode='wb',fileobj=destination,mtime=0) as packed:
   process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   while True:
    chunk=process.stdout.read(65536)
    if not chunk:break
    packed.write(chunk)
   error=process.stderr.read();code=process.wait()
 (root/(str(job)+'-escape.stderr')).write_bytes(error)
 records.append({'job':job,'logExitCode':code,'name':metadata['name'],'conclusion':metadata['conclusion'],'completed':metadata['completed_at']});assert code==0
 print(json.dumps(records[-1]),flush=True)
(root/'outcome-escape.json').write_text(json.dumps({'records':records,'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
