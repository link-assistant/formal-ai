from pathlib import Path
import subprocess,json,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research')
for f in ['rust/tests/web/security-codeql-results.test.mjs','docs/case-studies/issue-1580/rust-codeql-context-checkpoint.md','experiments/issue-1580/work-plan.md']:
 print('DIFF',f);p=subprocess.run(['git','diff','HEAD','--',f],cwd=r,capture_output=True,text=True);assert p.returncode==0;print(p.stdout)
ledger=json.loads((r/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json').read_text());print('RUST REVIEW LEDGER SUMMARY',{k:v for k,v in ledger.items() if not isinstance(v,(list,dict))})
for name in ['codeql-producer-ad59ff56','native-families-ad59ff56']:
 b=r/'experiments/issue-1580/evidence/ci'/name;files=list(b.iterdir());print('CI ARCHIVE',name,len(files),'files',sum(p.stat().st_size for p in files if p.is_file()),'bytes')
p=subprocess.run(['rg','--files','docs/case-studies/issue-1580','experiments/issue-1580/evidence/checks'],cwd=r,capture_output=True,text=True);assert p.returncode==0;print('REVIEW CATALOG CANDIDATES')
for f in p.stdout.splitlines():
 if 'review' in f and not f.endswith(('.gz','.lino')):print(f)
