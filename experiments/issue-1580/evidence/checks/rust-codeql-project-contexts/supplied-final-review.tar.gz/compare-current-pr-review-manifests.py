from pathlib import Path
import json
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/checks/production-diff-review'
for p in sorted(b.glob('*.json')):
 d=json.loads(p.read_text());print(p.name,'TYPE',type(d).__name__)
 if isinstance(d,dict):
  print('KEYS',list(d))
  for k,v in d.items():
   if isinstance(v,list):print('LIST',k,'count',len(v),'sample',v[:1])
   elif not isinstance(v,dict): print(k,v)
 elif isinstance(d,list):print('COUNT',len(d),'SAMPLE',d[:1])
