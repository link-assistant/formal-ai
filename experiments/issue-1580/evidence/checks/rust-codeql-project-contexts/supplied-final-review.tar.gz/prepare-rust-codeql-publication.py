from pathlib import Path
import json,gzip,hashlib,tarfile,io,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');b=r/'experiments/issue-1580/evidence/checks/rust-codeql-project-contexts'
paths=json.loads((b/'final-source-identities.json').read_text());print('FINAL SOURCE IDENTITIES')
for row in paths:
 assert hashlib.sha256((r/row['file']).read_bytes()).hexdigest()==row['sha256'];print(row['file'],row['sha256'])
print('FINAL PR BODY')
print((s/'rust-codeql-context-pr-body.md').read_text())
for file in ['docs/case-studies/issue-1580/README.md','experiments/issue-1580/work-plan.md']:
 t=(r/file).read_text();print('DOC LINES',file,len(t.splitlines()))
for label,args in [('working-check',['git','diff','--check']),('cached-check',['git','diff','--cached','--check']),('status',['git','status','--short'])]:
 p=subprocess.run(args,cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr
 (s/('rust-codeql-'+label+'.log')).write_text(p.stdout+p.stderr)
 print(label,'exit',p.returncode,'lines',len(p.stdout.splitlines()))
