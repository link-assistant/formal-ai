from pathlib import Path
import subprocess,json,collections
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/whole-pr-review');s.mkdir(exist_ok=False)
p=subprocess.run(['gh','pr','diff','1581','--repo','link-assistant/formal-ai'],cwd=r,stdout=(s/'published.diff').open('wb'),stderr=(s/'published.stderr').open('wb'));print('gh pr diff',p.returncode,(s/'published.diff').stat().st_size,'bytes')
p=subprocess.run(['git','diff','--numstat','origin/main...HEAD'],cwd=r,capture_output=True,text=True);assert p.returncode==0;(s/'local-numstat.txt').write_text(p.stdout)
counts=collections.Counter();rows=[]
for line in p.stdout.splitlines():
 a,d,f=line.split('\t',2);parts=f.split('/');kind='archive' if f.endswith(('.gz','.png','.jpg','.pdf','.wasm')) else 'evidence' if 'evidence' in parts else 'source' if f.startswith(('scripts/','js/','ts/','rust/src/','.github/')) else 'tests' if '/tests/' in f or '.test.' in f else 'other';counts[kind]+=1;rows.append({'file':f,'added':a,'removed':d,'kind':kind})
(s/'file-inventory.json').write_text(json.dumps(rows,indent=2)+'\n');print('CURRENT COMMITTED DIFF',len(rows),'files',dict(counts))
p=subprocess.run(['rg','--files','experiments/issue-1580','docs/case-studies/issue-1580'],cwd=r,capture_output=True,text=True);assert p.returncode==0
for f in p.stdout.splitlines():
 if any(x in f for x in ['review','selected','diff']) and f.endswith(('.json','.jsonl')):
  print('REVIEW RECORD',f)
print('NON-ARCHIVE/NON-EVIDENCE FILES')
for row in rows:
 if row['kind']not in ['archive','evidence']:print(json.dumps(row))
