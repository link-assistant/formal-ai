from pathlib import Path
import gzip,hashlib,json,tarfile,io,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');b=r/'experiments/issue-1580/evidence/checks/rust-codeql-project-contexts'
names=['research-rust-codeql-context.py','research-codeql-manifest-mapping.py','fetch-codeql-project-json-contract.py','fetch-rust-codeql-options.py','inspect-codeql-extractor-settings.py','inspect-codeql-version-and-template-remainder.py','inspect-codeql-version-and-template-remainder-corrected.py','draft-codeql-project-contexts.py','draft-codeql-project-regressions.py','extend-codeql-project-failure-regression.py','check-codeql-project-contexts.py','check-extended-codeql-project-contexts.py','verify-codeql-project-batch.py','review-codeql-project-generator.py','collect-codeql-producer-ci.py','collect-codeql-producer-reports.py','assess-codeql-terminal-ci.py','read-rust-template-user-guidance.py','list-rust-template-unread-current.py','refresh-codeql-batch-feedback.py','read-codeql-batch-doc-state.py','inspect-original-open-replays.py','compact-original-open-replays.py','prepare-original-contract-diff-review.py','inspect-template-comparison-catalog.py','inspect-original-hive-runtime-contract.py','read-original-hive-runtime-source.py','inspect-codeql-terminal-ci-archives.py','finish-codeql-local-review.py','pin-codeql-context-target.py','recheck-codeql-target-and-diagnostics.py','read-and-stage-codeql-context-source.py','document-rust-codeql-contexts.py','validate-staged-codeql-context-batch.py','inspect-codeql-batch-publication-state.py','archive-rust-codeql-context-investigation.py','record-rust-historical-maintenance-notes.py','rust-codeql-context-pr-body.md']
selected=set()
for name in names:
 if(s/name).is_file():selected.add(name)
 p=(s/name).with_suffix('.log')
 if p.is_file():selected.add(str(p.relative_to(s)))
for folder in ['codeql-project-batch-validation','codeql-producer-ci','codeql-batch-feedback','original-contract-follow-up','rust-codeql-publication-preflight']:
 for p in(s/folder).rglob('*'):
  if p.is_file():selected.add(str(p.relative_to(s)))
rows=[];buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w')as archive:
 for name in sorted(selected):
  raw=(s/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(raw));rows.append({'file':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
raw=buffer.getvalue();packed=gzip.compress(raw,mtime=0);(b/'supplied-investigation.tar.gz').write_bytes(packed);(b/'supplied-investigation.json').write_text(json.dumps({'files':rows,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
print('Retained',len(rows),'investigation inputs and complete outputs;',len(raw),'original bytes;',len(packed),'compressed bytes.')
a=json.loads((r/'experiments/issue-1580/evidence/ci/native-families-ad59ff56/assessment.json').read_text());a['registryCliFixture']={'job':136201211171,'summaryLine':762,'cases':8,'passed':True,'successLine':764};(r/'experiments/issue-1580/evidence/ci/native-families-ad59ff56/assessment.json').write_text(json.dumps(a,indent=2)+'\n')
p=subprocess.run(['git','diff','--cached','--stat'],cwd=r,capture_output=True,text=True);assert p.returncode==0;(s/'rust-codeql-staged-stat.log').write_text(p.stdout);print('Staged diff summary:',p.stdout.splitlines()[-1])
