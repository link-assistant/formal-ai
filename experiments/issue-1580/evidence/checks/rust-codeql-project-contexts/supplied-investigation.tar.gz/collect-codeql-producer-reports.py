from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,gzip,hashlib,time,traceback,os,sys
root=Path('/tmp/gh-issue-solver-1794900398048');os.chdir(root)
scratch=Path('/tmp/issue-1580-research/codeql-producer-reports');hosted=Path('/tmp/issue-1580-research/codeql-producer-hosted')
if len(sys.argv)==1:
 scratch.mkdir(exist_ok=False)
 with (scratch/'worker.log').open('wb') as stream:p=subprocess.Popen([sys.executable,__file__,'worker'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid}));sys.exit(0)
base=root/'experiments/issue-1580/evidence/ci/codeql-producer-ad59ff56';base.mkdir(exist_ok=False);records=[]
def run(name,args,parsed=False,checked=True):
 r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE);row={'name':name,'argv':args,'exitCode':r.returncode,'observedAt':datetime.now(timezone.utc).isoformat()}
 for label,raw in [('stdout',r.stdout),('stderr',r.stderr)]:
  f=name+'.'+label+'.gz';packed=gzip.compress(raw,mtime=0);(base/f).write_bytes(packed);row[label]={'file':f,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())}
 records.append(row);(base/'records.json').write_text(json.dumps(records,separators=(',',':'))+'\n')
 if checked:assert r.returncode==0,(name,r.stderr.decode(errors='replace')[-2000:])
 return json.loads(r.stdout) if parsed else r.stdout.decode(errors='replace')
try:
 for attempt in range(60):
  if (hosted/'selected-run.json').exists():break
  time.sleep(10)
 else:raise RuntimeError('Dispatched producer identity not available')
 selected=json.loads((hosted/'selected-run.json').read_text());rid=selected['databaseId'];head=selected['headSha'];assert head=='ad59ff56dafe3377f48ebf7739526d89642198fd'
 done=False
 for tick in range(360):
  state=run(f'observation-{tick:03}',['gh','run','view',str(rid),'--repo','link-assistant/formal-ai','--json','headSha,status,conclusion,jobs,url,createdAt,updatedAt'],True);assert state['headSha']==head
  (base/'latest.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps({'tick':tick,'head':head,'runId':rid,'status':state['status'],'conclusion':state['conclusion'],'jobs':[{k:j[k] for k in ['databaseId','name','status','conclusion']}for j in state['jobs']]}),flush=True)
  if state['status']=='completed':done=True;break
  time.sleep(30)
 assert done,'Producer observation bound exhausted'
 run('full-log',['gh','run','view',str(rid),'--repo','link-assistant/formal-ai','--log'])
 for job in state['jobs']:
  run('job-'+str(job['databaseId']),['gh','run','view',str(rid),'--repo','link-assistant/formal-ai','--job',str(job['databaseId']),'--log'])
 artifacts=run('artifacts',['gh','api',f'repos/link-assistant/formal-ai/actions/runs/{rid}/artifacts','--paginate'],True)['artifacts'];copied=[]
 for artifact in artifacts:
  if not artifact['name'].startswith('codeql-results-'):continue
  assert not artifact['expired'];destination=scratch/'download'/str(artifact['id']);destination.mkdir(parents=True)
  run('download-'+str(artifact['id']),['gh','run','download',str(rid),'--repo','link-assistant/formal-ai','--name',artifact['name'],'--dir',str(destination)])
  for source in sorted(destination.rglob('*')):
   if not source.is_file():continue
   assert not source.is_symlink();raw=source.read_bytes();relative=source.relative_to(destination).as_posix();name='producer-'+str(artifact['id'])+'-'+relative.replace('/','_')+'.gz';packed=gzip.compress(raw,mtime=0);(base/name).write_bytes(packed)
   copied.append({'artifact':artifact,'relativePath':relative,'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())});print('ARTIFACT',json.dumps(copied[-1]),flush=True)
 (base/'producer-files.json').write_text(json.dumps(copied,indent=2)+'\n')
 outcome={'complete':True,'head':head,'runId':rid,'conclusion':state['conclusion'],'url':state['url'],'producerFiles':len(copied),'independentAuthorshipCredit':0,'fullIssueComplete':False}
 (base/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');(scratch/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome),flush=True)
except BaseException:
 traceback.print_exc();(scratch/'failure.json').write_text(json.dumps({'complete':False,'traceback':traceback.format_exc()},indent=2)+'\n');sys.exit(1)
