from pathlib import Path
import shutil,json
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research')
src=(s/'codeql-rust-projects.py').read_text().replace('def dependency_graph(metadata, messages, host, target_dir):','def dependency_graph(metadata, messages, host, target_dir):').replace('            args = prefix + ["cargo", "--manifest-path"]\n','')
# Script env! expansions need the same Cargo package environment as the declared context.
src=src.replace('        for source in group["sources"]:\n', '''        root_package = {"name": "codeql-context-" + identity, "version": "0.1.0", "manifest_path": str(manifest)}
        for source in group["sources"]:
''').replace('                          "env": {}, "target": host, "is_workspace_member": True,','                          "env": rustc_environment(root_package, Path(source).stem), "target": host, "is_workspace_member": True,')
(r/'scripts/codeql-rust-projects.py').write_text(src)
p=r/'.github/workflows/security.yml';text=p.read_text();start=text.index('      # Issue #1017 / github/codeql#19982.');end=text.index('    steps: &codeql-analysis-steps',start)
text=text[:start]+'''      # CodeQL CLI 2.27.4 vendors ra_ap 0.0.358 and selects Rust 1.99.0.
      # Original producer run 44710630318 proved that the old 1.94.0 sysroot
      # also supplies an incompatible proc-macro server: 406 macro failures.
      # Keep binary sysroot, rust-src and compiled dependency macros on the
      # extractor's compiler ABI; revalidate original SARIF when upgrading it.
      CODEQL_RUST_SYSROOT_TOOLCHAIN: '1.99.0'
'''+text[end:]
needle='      - uses: github/codeql-action/init@v4\n';assert text.count(needle)==1
text=text.replace(needle,'''      - name: Prepare standalone Rust analysis contexts
        if: matrix.language == 'rust'
        run: python3 scripts/codeql-rust-projects.py --output "${{ runner.temp }}/codeql-rust-contexts"

'''+needle)
needle='  # Explicit branch verification reuses the exact producer';assert text.count(needle)==1
text=text.replace(needle,'''      - name: Preserve Rust analysis contexts
        if: ${{ !cancelled() && matrix.language == 'rust' }}
        uses: actions/upload-artifact@v7
        with:
          name: codeql-rust-contexts-${{ github.job }}
          path: |
            ${{ runner.temp }}/codeql-rust-contexts/contexts.json
            ${{ runner.temp }}/codeql-rust-contexts/rustc-version.txt*
            ${{ runner.temp }}/codeql-rust-contexts/**/*.json
            ${{ runner.temp }}/codeql-rust-contexts/**/*.json.stderr
            ${{ runner.temp }}/codeql-rust-contexts/**/*.jsonl*
            ${{ runner.temp }}/codeql-rust-contexts/**/Cargo.toml
            ${{ runner.temp }}/codeql-rust-contexts/**/Cargo.lock
            scripts/rust-project.json
            js/wasm-worker/rust-project.json
          if-no-files-found: warn

'''+needle)
needle='    permissions:\n      actions: read\n      contents: read\n    strategy:';assert text.count(needle)==1;text=text.replace(needle,'    permissions:\n      actions: read\n      contents: read\n      security-events: read\n    strategy:')
p.write_text(text)
p=r/'rust/tests/web/security-codeql-results.test.mjs';text=p.read_text();assert "{ actions: 'read', contents: 'read' });" in text;text=text.replace("{ actions: 'read', contents: 'read' });","{ actions: 'read', contents: 'read', 'security-events': 'read' });");p.write_text(text)
(r/'changelog.d/1580-rust-codeql-project-contexts.md').write_text('''---
bump: patch
---

Match CodeQL 2.27.4's Rust compiler ABI and preserve separate declared dependency contexts for standalone scripts and the direct-rustc WASM worker during security analysis. Keep branch producer verification read-only while allowing its status API reads.
''')
print(json.dumps({'drafted':['scripts/codeql-rust-projects.py','.github/workflows/security.yml','rust/tests/web/security-codeql-results.test.mjs','changelog.d/1580-rust-codeql-project-contexts.md'],'hostedVerification':False,'fullIssueComplete':False}))
