from pathlib import Path
import subprocess,json,gzip,hashlib,os,sys,traceback,time
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/codeql-project-batch-validation');b=r/'experiments/issue-1580/evidence/checks/rust-codeql-project-contexts'
if len(sys.argv)==1:
 s.mkdir(exist_ok=False)
 code="""import fs from 'node:fs';import YAML from 'yaml';import{createHash}from'node:crypto';const path='data/benchmarks/fast-pull-request-retained-jobs.json';const d=JSON.parse(fs.readFileSync(path));const j=YAML.parse(fs.readFileSync('.github/workflows/security.yml','utf8')).jobs.codeql;const row=d.jobs.find(x=>x.file==='security.yml'&&x.id==='codeql');if(!row)throw Error('missing retained job');const old=row.payloadSha256;row.payloadSha256=createHash('sha256').update(JSON.stringify({steps:j.steps,uses:j.uses,with:j.with,strategy:j.strategy})).digest('hex');fs.writeFileSync(path,JSON.stringify(d,null,2)+'\\n');process.stdout.write(JSON.stringify({previous:old,current:row.payloadSha256,implementationChanged:true,hostedVerification:false})+'\\n');"""
 p=subprocess.run(['node','--max-old-space-size=256','--input-type=module','-e',code],cwd=r,capture_output=True);assert p.returncode==0,p.stderr.decode();(b/'retained-main-payload-transition.json').write_bytes(p.stdout);print(p.stdout.decode(),flush=True)
 with(s/'worker.log').open('wb')as f:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=r,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'scratch':str(s)}));raise SystemExit(0)
records=[]
try:
 for label,args in [('production-profile-corrected',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs']),('complete-local-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs'])]:
  now=time.monotonic();p=subprocess.run(args,cwd=r,capture_output=True,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','PYTHONDONTWRITEBYTECODE':'1'});raw=p.stdout+p.stderr;packed=gzip.compress(raw,mtime=0);(b/(label+'.log.gz')).write_bytes(packed);row={'label':label,'argv':args,'exitCode':p.returncode,'seconds':round(time.monotonic()-now,3),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()};records.append(row);(b/'batch-validation.json').write_text(json.dumps(records,indent=2)+'\n');print(label,p.returncode,raw.decode(errors='replace')[-8000:],flush=True)
  if p.returncode:raise RuntimeError(label+' failed; inspect complete compressed log')
 (s/'outcome.json').write_text(json.dumps({'complete':True,'checks':records,'hostedCodeqlVerified':False,'fullIssueComplete':False})+'\n')
except BaseException:
 traceback.print_exc();(s/'failure.json').write_text(json.dumps({'complete':False,'traceback':traceback.format_exc()})+'\n');sys.exit(1)
