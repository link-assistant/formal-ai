from pathlib import Path
import subprocess,json,gzip,re
base=Path('/tmp/issue-1580-research/codeql-rust-extractor-context');base.mkdir(exist_ok=True)
for name in ['Cargo.toml','rust/Cargo.toml','.github/codeql/codeql-config.yml','rust/src/source_fetch/cache_budget.rs','js/wasm-worker/Cargo.toml','scripts/audit-seed-metadata.rs']:
 p=Path(name)
 if not p.exists():print('ABSENT',name);continue
 ls=p.read_text().splitlines();print('FILE',name,len(ls))
 limit=100 if name.endswith('.rs')else 240
 for n,l in enumerate(ls[:limit],1):print(f'{n:04} {l}')
for directory in ['rust/extractor/src','rust/autobuild','rust']:
 args=['gh','api',f'repos/github/codeql/contents/{directory}?ref=codeql-cli/v2.27.4'];p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(base/(directory.replace('/','_')+'.json.gz')).write_bytes(gzip.compress(p.stdout,mtime=0));print('DIRECTORY',directory,p.returncode)
 if p.returncode:print(p.stderr.decode()[:1000]);continue
 print(json.dumps([{'path':x['path'],'type':x['type'],'sha':x['sha']}for x in json.loads(p.stdout)],indent=2))
ls=gzip.decompress(Path('experiments/issue-1580/evidence/ci/codeql-producer-ad59ff56/job-136201098870.stdout.gz').read_bytes()).decode(errors='replace').splitlines()
for a,b in [(1640,1705),(2080,2140),(3180,3205)]:
 print('JOB_RANGE',a,b)
 for n in range(a-1,b):print(f'{n+1:04} {ls[n]}')
