from pathlib import Path
import gzip,subprocess,re
for name in ['.github/workflows/security.yml','experiments/formal_ai_subagent/sandboxes/gates/check-file-size.log','experiments/formal_ai_subagent/sandboxes/gates/check-file-size-js-twin.log']:
 p=Path(name);lines=p.read_text().splitlines();print('FILE',name,len(lines))
 if 'workflow' in name:
  for n,line in enumerate(lines,1):print(f'{n:04} {line}')
 else:
  for n,line in enumerate(lines,1):
   if re.search(r'(error|exceeds|1500|FAIL|original-producer|main-source)',line,re.I):print(n,line[:1200])
p=Path('experiments/issue-1580/evidence/ci/codeql-producer-ad59ff56/job-136201098870.stdout.gz');lines=gzip.decompress(p.read_bytes()).decode(errors='replace').splitlines()
for a,b in [(1450,1550),(lines.__len__()-50,lines.__len__())]:
 print('JOB_CHUNK',a,b)
 for n in range(max(0,a-1),b):print(f'{n+1:04} {lines[n]}')
args=['gh','api','repos/github/codeql/contents/rust/extractor'];p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE);print('UPSTREAM_DIRECTORY',p.returncode,p.stdout.decode()[:12000],p.stderr.decode())
