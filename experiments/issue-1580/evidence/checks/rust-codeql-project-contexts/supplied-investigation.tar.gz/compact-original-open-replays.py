from pathlib import Path
import json,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');d=json.loads((r/'experiments/issue-1580/evidence/ci/native-families-03ff3a8e/original-native-replay-union.json').read_text())
for row in d['tests']:
 if not row['hasPublishedPassingReplay']:
  print(json.dumps({k:row.get(k)for k in ('originalTest','currentPublishedReplay')},ensure_ascii=False))
