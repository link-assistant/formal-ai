from pathlib import Path
import json,gzip,re
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/ci/native-families-ad59ff56'
w=json.loads(gzip.decompress((b/'diagnostic-candidates.json.gz').read_bytes()))
size=[];other=[]
for row in w:
 (size if re.search(r'WARNING: .* has \d+ lines \(approaching',row['text']) else other).append(row)
print('DIAGNOSTIC COUNTS',len(w),len(size),len(other))
for row in other: print(json.dumps(row,ensure_ascii=False))
p=r/'experiments/issue-1580/evidence/checks/rust-codeql-project-contexts/complete-local-gates.log.gz';t=gzip.decompress(p.read_bytes()).decode()
print('GATE FINAL LINES')
print('\n'.join(t.splitlines()[-12:]))
print('GATE COUNTS',len(re.findall(r'\[PASS\]',t)),len(re.findall(r'\[SKIP\]',t)))
for file in ['scripts/codeql-rust-projects.py','rust/tests/web/security-codeql-results.test.mjs']:
 lines=(r/file).read_text().splitlines(); hits=[i for i,x in enumerate(lines) if 'check' in x and ('--lib' in x or 'assert' in x or 'cargo' in x.lower())]
 for hit in hits:
  print(file,hit+1)
  for n in range(max(0,hit-6),min(len(lines),hit+12)): print(f'{n+1}: {lines[n]}')
records=json.loads((b/'records.json').read_text())
for row in records:
 if row['name']=='job-136201211171':
  lines=gzip.decompress((b/row['stdout']['file']).read_bytes()).decode().splitlines()
  for i,line in enumerate(lines):
   if any(x in line for x in ['cases', 'regressions', 'CLI', 'test result:']):
    if 'Run ' not in line: print(f'CLI {i+1}: {line}')
