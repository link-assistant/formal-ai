from pathlib import Path
import subprocess
r=Path('/tmp/gh-issue-solver-1794900398048')
for name in ('scripts/codeql-rust-projects.py','rust/tests/web/security-codeql-results.test.mjs'):
 p=r/name
 print('SOURCE',name,flush=True)
 for n,line in enumerate(p.read_text().splitlines(),1): print(f'{n}: {line}',flush=True)
p=subprocess.run(['git','status','--short'],cwd=r,capture_output=True,text=True);print(p.stdout)
