from pathlib import Path
from datetime import datetime,timezone
import re,json,gzip,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');t=s/'templates/rust-complete';names=['rust-historical-maintenance-notes-read.log'];rows={}
for name in names:
 current=None
 for line in (s/name).read_text().splitlines():
  m=re.match(r'   (?:Output: )?FILE (\S+) LINES (\d+)(?: RANGE (\d+) (\d+))? SHA256 ([0-9a-f]{64})$',line)
  if m:
   current=m[1];row=rows.setdefault(current,{'lines':int(m[2]),'sha256':m[5],'numbered':{},'readLogs':[]});row['readLogs'].append(name+'.gz');continue
  m=re.match(r'   (\d+): (.*)$',line)
  if m and current:
   number=int(m[1]);assert number not in rows[current]['numbered'];rows[current]['numbered'][number]=m[2]
assert len(rows)==20,len(rows)
p=r/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json';d=json.loads(p.read_text());known={x['path']for x in d['files']};ids={x['path']:x for x in json.loads((r/d['all373BlobIdentitiesVerifiedBy']).read_text())};b=r/'experiments/issue-1580/evidence/checks/rust-source-review';total=0
for path,row in rows.items():
 raw=(t/path).read_bytes();lines=raw.decode().splitlines();sha=hashlib.sha256(raw).hexdigest();assert sha==row['sha256']==ids[path]['sha256'];assert len(lines)==row['lines'];assert sorted(row['numbered'].items())==list(enumerate(lines,1)),path;assert path not in known
 d['files'].append({'path':path,'lines':len(lines),'sha256':sha,'readLogs':row['readLogs'],'literalReadRanges':[[1,len(lines)]],'literalReadLines':len(lines),'literalSourceFullyRead':True,'formalAiPracticeImplementationVerified':False});total+=len(lines)
assert total==653,total
lp=b/'logs.json';logs=json.loads(lp.read_text())
for name in names:
 raw=(s/name).read_bytes();packed=gzip.compress(raw,mtime=0);archive=name+'.gz';assert not any(x['file']==archive for x in logs);(b/archive).write_bytes(packed);logs.append({'file':archive,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
lp.write_text(json.dumps(logs,indent=2)+'\n');d['files'].sort(key=lambda x:x['path']);d['fullyReadFiles']=len(d['files']);d['fullyReadSourceLines']=sum(x['literalReadLines']for x in d['files']);assert(d['fullyReadFiles'],d['fullyReadSourceLines'])==(237,34513);d['observedAt']=datetime.now(timezone.utc).isoformat();d['practiceDecisions'].append({'practice':'Historical maintenance investigations, strict extraction and dependency migrations','templateEvidence':list(rows),'assessment':'Read all 653 numbered lines in twenty pinned historical maintenance notes and report records. Preserve exact revision and run attribution, full failed logs, Cargo graph validation before auditing, extraction warning rejection and production compilation regressions for inline Rust scripts. Reuse upstream-supported HTTP retry/configuration APIs and document transitive constraints; a submitted report does not prove upstream repair. Historical version claims and external authorization rules are evidence about that investigation, not current Formal AI pins or instructions. Counterpart applicability and actual runtime acceptance remain open.','status':'literal-source-comparison-and-counterpart-runtime-pending'});p.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'fullyReadFiles':237,'fullyReadSourceLines':34513,'remainingFiles':136,'literalLinesAndPinnedIdentitiesVerified':True,'runtimeExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}))
