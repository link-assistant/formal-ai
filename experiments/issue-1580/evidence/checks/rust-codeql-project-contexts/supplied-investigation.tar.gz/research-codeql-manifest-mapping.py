from pathlib import Path
import subprocess,hashlib,json
base=Path('/tmp/issue-1580-research/codeql-rust-extractor-context')
for name in ['rust/extractor/src/main.rs','rust/Cargo.lock','rust/extractor/src/bin/rust-autobuild.rs']:
 p=subprocess.run(['gh','api','-H','Accept: application/vnd.github.raw+json',f'repos/github/codeql/contents/{name}?ref=codeql-cli/v2.27.4'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 print('FETCH',name,'EXIT',p.returncode)
 if p.returncode: print(p.stderr.decode()[:600]);continue
 path=base/name.replace('/','_');path.write_bytes(p.stdout)
 ls=p.stdout.decode().splitlines();print('LINES',len(ls),'SHA256',hashlib.sha256(p.stdout).hexdigest())
 if name.endswith('main.rs'):
  for i,l in enumerate(ls):print(f'{i+1:04} {l}')
 else:
  for i,l in enumerate(ls):
   if 'ra_ap_project_model' in l:
    print('\n'.join(ls[max(0,i-2):i+12]))
for cmd in [['git','branch','--show-current'],['git','status','--short'],['rg','--files','docs/case-studies/issue-1580'],['sed','-n','1,200p','scripts/test-scripts.sh']]:
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);print('CMD',cmd,'EXIT',p.returncode,'\n',p.stdout.decode())
