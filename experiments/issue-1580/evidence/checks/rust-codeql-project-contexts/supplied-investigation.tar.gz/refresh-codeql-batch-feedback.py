from pathlib import Path
import subprocess,json
s=Path('/tmp/issue-1580-research/codeql-batch-feedback');s.mkdir(exist_ok=False)
for name,args in [('issue',['issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','number,title,body,updatedAt,url']),('issue-comments',['api','repos/link-assistant/formal-ai/issues/1580/comments','--paginate']),('pr-comments',['api','repos/link-assistant/formal-ai/issues/1581/comments','--paginate']),('pr-inline',['api','repos/link-assistant/formal-ai/pulls/1581/comments','--paginate']),('pr-reviews',['api','repos/link-assistant/formal-ai/pulls/1581/reviews','--paginate']),('pr',['pr','view','1581','--repo','link-assistant/formal-ai','--json','title,body,headRefOid,isDraft,updatedAt,statusCheckRollup'])]:
 p=subprocess.run(['gh',*args],capture_output=True);(s/(name+'.json')).write_bytes(p.stdout);(s/(name+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,name
 d=json.loads(p.stdout)
 print('RESPONSE',name,flush=True)
 if name=='pr':
  print(json.dumps({k:v for k,v in d.items() if k not in ('body','statusCheckRollup')}));continue
 if isinstance(d,list):
  print('COUNT',len(d))
  for row in d: print(json.dumps({k:row.get(k)for k in ('id','html_url','created_at','updated_at','submitted_at','state','body')},ensure_ascii=False),flush=True)
 else:print(json.dumps(d,ensure_ascii=False),flush=True)
