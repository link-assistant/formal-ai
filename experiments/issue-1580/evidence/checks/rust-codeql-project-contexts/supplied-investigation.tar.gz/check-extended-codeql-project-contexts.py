from pathlib import Path
import subprocess,json,gzip,hashlib,os
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/checks/rust-codeql-project-contexts';records=[]
for label,file in [('projects-final','rust/tests/web/security-codeql-results.test.mjs'),('retained-main-policy','rust/tests/web/default-branch-build-policy.test.mjs'),('production-profile','rust/tests/web/fast-pull-request-production-profile.test.mjs')]:
 args=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',file];p=subprocess.run(args,cwd=r,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});raw=p.stdout+p.stderr;(b/(label+'.log.gz')).write_bytes(gzip.compress(raw,mtime=0));records.append({'label':label,'argv':args,'exitCode':p.returncode,'rawSha256':hashlib.sha256(raw).hexdigest()});print('VALIDATION',label,'EXIT',p.returncode,raw.decode()[-6000:],flush=True)
(b/'focused-validation.json').write_text(json.dumps(records,indent=2)+'\n');print('ALL_PASS',all(row['exitCode']==0 for row in records));
