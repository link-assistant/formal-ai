from pathlib import Path
import json
r=Path('/tmp/gh-issue-solver-1794900398048');t=Path('/tmp/issue-1580-research/templates/rust-complete')
d=json.loads((r/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json').read_text());known={x['path']for x in d['files']};ids=json.loads((r/d['all373BlobIdentitiesVerifiedBy']).read_text())
for row in ids:
 if row['path'] not in known:
  p=t/row['path'];raw=p.read_bytes();print(row['path'],len(raw),len(raw.splitlines()))
