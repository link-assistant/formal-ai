from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');b=r/'experiments/issue-1580/evidence/checks/rust-codeql-project-contexts'
assert json.loads((b/'host-target-validation.json').read_text())['exitCode']==0
assert all(x['exitCode']==0 for x in json.loads((b/'batch-validation.json').read_text()))
producer=r/'experiments/issue-1580/evidence/ci/codeql-producer-ad59ff56';ci=r/'experiments/issue-1580/evidence/ci/native-families-ad59ff56'
a=json.loads((ci/'assessment.json').read_text());assert a['automaticWorkflowsSucceeded']==23 and a['allRecordedStreamsVerified']==286
text='''# Original CodeQL producer reports and Rust project contexts

Checkpoint: 2026-11-20. Issue #1580 and PR #1581 remain unfinished. This
supersedes the earlier checkpoint's statement that producer reports had not yet
been obtained; it does not turn the current source repairs into hosted evidence.

## Published-head observations

Head `ad59ff56dafe3377f48ebf7739526d89642198fd` completed all 23 automatic
workflows successfully. The explicit read-only Security producer run
[44710630318](https://github.com/link-assistant/formal-ai/actions/runs/44710630318)
failed both its Actions and Rust CodeQL gates. Its Cargo audit passed. All 24
workflow logs, native job logs and collection responses are retained in
[`native-families-ad59ff56`](../../../experiments/issue-1580/evidence/ci/native-families-ad59ff56/).
All 286 stdout/stderr streams have verified compressed and original identities,
byte lengths and line counts. The collector is terminal before this checkpoint.

The automatic native jobs pass the workflow (104), coding (32), reasoning (141),
interfaces (78), benchmark (11) and Hive (20/10/7) suites. The registry helper
passes three native tests, and its actual release CLI fixture passes eight cases
(job 136201211171, lines 742–764). These observations do not establish all
original-source contracts: the strict dated replay denominator remains 31/53.

The original reports are retained byte-for-byte, compressed, in
[`codeql-producer-ad59ff56`](../../../experiments/issue-1580/evidence/ci/codeql-producer-ad59ff56/):

| Producer report | Original bytes | Original SHA-256 |
| --- | ---: | --- |
| Rust, artifact 14617183486 | 5,499,579 | `afc98984294a56e1e69fcf06a91c89a8b887bce6aef88d83a7c81c3d6d04a91c` |
| Actions, artifact 14616259795 | 2,459,242 | `7020757b8bdbda622e8742bf1778f6eaeee09f52c1ff340b585dd2080237bb2e` |

Both are SARIF 2.1.0 from CodeQL 2.27.4 with successful execution metadata.
Actions contains two unresolved cache-poisoning findings. Rust contains no
reported findings but **511 extraction warnings**: 406 macro-expansion failures
and 105 files without a discovered manifest (101 scripts and four WASM files).
A finding-free Rust report therefore does not establish complete analysis.
The strict result gate correctly rejects it; no diagnostic is suppressed.

The same full automatic workflow logs contain 123 actual source-size warnings.
The other 33 warning candidates are quoted shell source, including cache
fallback commands, rather than emitted warnings. The first investigation filter
was too broad; both its output and the corrected classification are retained.
No source-size warning is resolved by this classification.

## Source repairs requiring the next hosted producer

The Actions repair binds initial source selection to literal `refs/heads/main`
checkouts with credentials disabled. The job verifies the checked-out HEAD
against the checkout's main tracking ref before executing draft source, records
that exact SHA once, and reuses it in dependent jobs. Shell regressions use real
Git repositories to check matching heads, mismatches, missing tracking refs and
changes after sealing. Both original findings still need a fresh producer run.
[CodeQL #23176](https://github.com/github/codeql/issues/23176) records the
upstream heuristic investigation; filing it does not repair either finding.

The Rust producer log identifies compiled macros from Rust 1.99.0 but a
proc-macro server from the former 1.94.0 sysroot. The workflow now pins its
binary sysroot and rust-src to 1.99.0 for the measured CodeQL 2.27.4 extractor.
No application compiler policy changes with this security-analysis pin.

`scripts/codeql-rust-projects.py` discovers the actual standalone declarations,
including the rust-script default edition. The current source has 19 distinct
dependency contexts. Each resolves independently, preserving conflicting exact
versions, dependency aliases and features. Dependency-only collector libraries
are checked on the explicit host target with one Cargo job, no incremental
cache and no debug information. Metadata, Cargo lockfiles, build-script cfg/env,
compiled proc-macro libraries and original maintained source paths form the
combined `scripts/rust-project.json`. Helpers retain their declaring module
context. The direct-rustc worker gets its actual edition 2024 and
`wasm32-unknown-unknown` context from the maintained build script. Unsupported
manifest constructs, missing build output, failed dependency builds or existing
project files stop preparation; no synthetic replacement source is analyzed.
Both project manifests are written only after all contexts have succeeded.

The workflow preserves context receipts, Cargo inputs, compiler identity,
metadata and build logs even when later analysis fails. Its branch verification
job also has `security-events: read`, matching the producer's stated API
requirement, while result upload remains disabled on that job.

## Reproduction and verification

Run the adjacent JavaScript regression without building Rust:

```sh
timeout 600 node --test --test-concurrency=1 rust/tests/web/security-codeql-results.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/hive-mind-draft-workflow.test.mjs
node experiments/formal_ai_subagent/local-gates.mjs
```

Before repair, controls reject the old compiler pin and absent standalone
contexts. The final security regression passes 15 groups, including exact-pin
separation, aliases/features, module ownership, actual WASM target, mocked Cargo
build metadata, explicit host target and failure-before-publication behavior.
The Actions source-binding regression passes 14 groups. Retained main-policy
checks pass 97 cases and the refreshed production-profile checks pass 18.
The complete local inventory passes 87 executable gates, with 53 explicit
CI-only exclusions and no failures. Focused tests repeat after the explicit
host-target follow-up; full and focused logs remain separate. No local Rust
compilation, application build or native test execution is performed.

See the complete before/after logs and command/source identities in
[`rust-codeql-project-contexts`](../../../experiments/issue-1580/evidence/checks/rust-codeql-project-contexts/)
and [`main-source-checkout-binding`](../../../experiments/issue-1580/evidence/checks/main-source-checkout-binding/).
Supplied commands, scripts and patches earn zero autonomous-authorship credit.

## Open acceptance

A fresh exact-head hosted producer must prove that both Actions findings and
all 511 Rust warnings are resolved. Inspect original invocations, extraction
coverage for all 105 affected source files, and non-warning coverage notes as
well as finding totals. A generated context receipt or local mock cannot prove
those facts. Both hosted repair-verification flags remain false here.

The original budget/native contracts, all eight complete template comparisons
and applicable runtime practices, dependency maintenance and source-size
warnings, registry publication certainty, historical cache/Docker evidence,
live delivery/model identity, general provenance and complete PR review remain
unfinished. Rust template source review is 237/373 files and 34,513 literal
lines, with 136 files and applicable practice validation open. Independently
accepted Formal AI reasoning remains 0/20. Keep PR #1581 draft and unmerged
until the full issue acceptance inventory is verified.
'''
p=r/'docs/case-studies/issue-1580/rust-codeql-context-checkpoint.md';assert not p.exists();p.write_text(text)
p=r/'docs/case-studies/issue-1580/README.md';t=p.read_text();t+='''\nThe [2026-11-20 original CodeQL report and Rust context checkpoint](rust-codeql-context-checkpoint.md)
records all 23 automatic workflows passing on `ad59ff56`, the separate failing
producer's two Actions findings and 511 Rust extraction warnings, and source
repairs whose hosted validation is still pending. It retains all 286 verified
collector streams, the original SARIF bytes, 15 security regression groups and
the complete 87-pass/53-excluded local gate inventory. Strict original replay
acceptance remains 31/53; broader criteria and 0/20 independent reasoning stay
open. Rust literal review is 237/373 files and 34,513 lines, with 136 files and
applicable practice/runtime verification unfinished.\n''';p.write_text(t)
p=r/'experiments/issue-1580/work-plan.md';t=p.read_text();t+='''\n### 2026-11-20: original producer reports and dependency-context repair\n\n- [x] Finish collection for published `ad59ff56`: all 24 workflows terminal, 23 automatic successes and one explicit Security producer failure; verify all 286 recorded stdout/stderr streams, bytes and line counts. Registry helper 3 and actual release CLI 8 cases pass. Native workflow/coding/reasoning/interfaces/benchmark/Hive suites pass 104/32/141/78/11/20+10+7 cases. Skipped jobs remain explicit.\n- [x] Obtain the actual CodeQL 2.27.4 SARIF producer reports with invocation metadata: Actions has two unresolved findings; Rust has 406 macro-ABI and 105 missing-context extraction warnings. Preserve original bytes and artifact identities; no suppression or false clean-security credit.\n- [x] Draft and locally verify literal-main checkout/source sealing with real Git fixtures, and isolated declared Cargo dependency contexts plus the direct-rustc WASM project. Match the measured extractor's Rust 1.99.0 ABI. Pin dependency checks to the actual host target; fail before publishing contexts on preparation errors.\n- [x] Run all 140 local gates: 87 pass and 53 explicit CI-only exclusions; final host-target security regressions pass 15 groups, Actions checkout controls 14, retained policy 97 and refreshed production profile 18. No local Rust execution. Stage new files before final affected gates and archive every failed investigation.\n- [x] Correct warning candidate classification: 123 actual source-size warnings and 33 quoted shell lines; retain the initial overly broad filter and corrected output. No actual size warning is cleared.\n- [ ] Push the combined source/evidence batch only after the single push gate; run and inspect the exact-head hosted CodeQL producer, its original SARIF and actual source coverage for all 105 formerly context-free files. Both hosted repair flags remain false until then.\n- [ ] Complete every broader original requirement. Strict dated original-source passing evidence stays 31/53, independent Formal AI reasoning 0/20, and all unverified template, budget, dependency, publication, live delivery and whole-PR review criteria remain open. Rust literal review is 237/373 files and 34,513 lines; 136 files and applicable practices remain open.\n\nEvidence and reproduction: [Rust context checkpoint](../../docs/case-studies/issue-1580/rust-codeql-context-checkpoint.md). Supplied commands, helpers and patches earn no independent credit.\n''';p.write_text(t)
old=(s/'codeql-producer-publication/pull-request-body.md').read_text();new=old
new=new.replace('- Reject malformed or missing CodeQL reports, unresolved findings and unsuccessful/extraction-diagnostic invocations.', '- Bind initial Hive and Formal AI sources to verified literal-main checkouts before executing draft source, then reuse the sealed SHAs. Give standalone Rust scripts their separate declared Cargo contexts and the direct-rustc worker its actual WASM context; match CodeQL 2.27.4\'s measured Rust 1.99.0 proc-macro ABI. Preserve compiler, metadata and build provenance; preparation errors stop analysis.\n- Reject malformed or missing CodeQL reports, unresolved findings and unsuccessful/extraction-diagnostic invocations.')
a0=new.index('- Published predecessor `');a1=new.index('- The measured JavaScript repair',a0)
new=new[:a0]+'''- Published head `ad59ff56dafe3377f48ebf7739526d89642198fd` passes all 23 automatic workflows. Native workflow/coding/reasoning/interfaces/benchmark suites pass 104/32/141/78/11 cases and Hive passes 20/10/7. The actual registry helper passes 3 tests and both release CLIs pass all 8 fixture cases. [Complete logs and assessment](https://github.com/link-assistant/formal-ai/tree/issue-1580-8d61a32a61e1/experiments/issue-1580/evidence/ci/native-families-ad59ff56) retain 286 verified collector streams. The current source repairs require their own hosted run.
- The explicit read-only [CodeQL producer run 44710630318](https://github.com/link-assistant/formal-ai/actions/runs/44710630318) fails correctly: original Actions SARIF contains two unresolved cache-poisoning findings, and original Rust SARIF contains 406 proc-macro ABI warnings plus 105 missing-project-context warnings. Cargo audit passes. Both exact producer reports, invocation metadata and hashes are preserved. No finding or diagnostic is dismissed. [CodeQL #23176](https://github.com/github/codeql/issues/23176) records the upstream heuristic investigation; filing it provides no repair credit.
- Source repairs have reproducing negative controls and pass 15 security regression groups, 14 actual Git checkout-binding groups, 97 workflow-policy cases, 18 production-profile cases and the full 140-entry local inventory (87 pass / 53 explicit CI-only exclusions). The host-target follow-up repeats the 15 focused groups. No local Rust build runs. [Current CodeQL checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/rust-codeql-context-checkpoint.md) separates source repairs and mocks from pending exact-head hosted producer compatibility, finding resolution and complete extraction coverage.
- Full workflow logs contain 123 actual source-size warnings; 33 other warning candidates are quoted shell source. The initial broad classification and its correction are retained. Experimental `unsafe-libyaml` maintenance and crates.io publish-token certainty remain open. Extracting the CodeQL tests removes one former size warning; thresholds and dependency exceptions are unchanged.
''' +new[a1:]
new=new.replace('217/373 files and 33,860 lines; 156 files','237/373 files and 34,513 lines; 136 files')
new=new.replace('new producer-path CI and live producer reports, remaining original native', 'fresh hosted verification of both CodeQL source repairs and actual extraction coverage, remaining original native')
new=new.replace('timeout 600 node --test --test-concurrency=1 rust/tests/web/security-codeql-results.test.mjs\n','timeout 600 node --test --test-concurrency=1 rust/tests/web/security-codeql-results.test.mjs\ntimeout 600 node --test --test-concurrency=1 rust/tests/web/hive-mind-draft-workflow.test.mjs\n')
(s/'rust-codeql-context-pr-body.md').write_text(new)
files=['scripts/codeql-rust-projects.py','.github/workflows/security.yml','rust/tests/web/security-codeql-results.test.mjs','data/benchmarks/fast-pull-request-retained-jobs.json','changelog.d/1580-rust-codeql-project-contexts.md']
(b/'final-source-identities.json').write_text(json.dumps([{'file':f,'sha256':hashlib.sha256((r/f).read_bytes()).hexdigest()}for f in files],indent=2)+'\n')
print('WROTE checkpoint',len(text.splitlines()),'lines; updated README, work plan and concrete draft PR body; hosted criteria remain OPEN.')
