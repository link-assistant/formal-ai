from pathlib import Path
import json,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'experiments/issue-1580/evidence/ci/native-families-03ff3a8e/original-native-replay-union.json';d=json.loads(p.read_text());print(json.dumps(d,indent=2))
p=subprocess.run(['rg','--files','experiments/issue-1580','rust/tests','rust/src'],cwd=r,capture_output=True,text=True);assert p.returncode==0
for line in p.stdout.splitlines():
 if any(x in line for x in ('original','replay','native_families')): print('REPLAYFILE',line)
