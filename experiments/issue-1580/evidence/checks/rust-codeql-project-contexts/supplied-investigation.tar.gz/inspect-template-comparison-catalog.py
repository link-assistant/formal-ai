from pathlib import Path
r=Path('/tmp/gh-issue-solver-1794900398048')
for p in sorted((r/'docs/case-studies/issue-1580').glob('*.md')):
 if any(x in p.name for x in ('template','require','acceptance','inventory')): print(p.relative_to(r),len(p.read_text().splitlines()))
for p in sorted((r/'docs/case-studies/issue-1580/templates').glob('*')):print(p.relative_to(r),p.stat().st_size)
