from pathlib import Path
from datetime import datetime,timezone
import gzip,json,hashlib,re
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/ci/native-families-ad59ff56';records=json.loads((b/'records.json').read_text());streams=0
for row in records:
 for field in ('stdout','stderr'):
  record=row[field];packed=(b/record['file']).read_bytes();raw=gzip.decompress(packed)
  assert hashlib.sha256(packed).hexdigest()==record['archiveSha256']
  assert hashlib.sha256(raw).hexdigest()==record['rawSha256']
  assert len(raw)==record['bytes'] and len(raw.splitlines())==record['lines'];streams+=1
latest=json.loads((b/'latest.json').read_text());assert latest['completed']==24 and latest['success']==23 and len(latest['failed'])==1
results=[];warnings=[]
for row in records:
 if not row['name'].startswith('job-'):continue
 raw=gzip.decompress((b/row['stdout']['file']).read_bytes()).decode(errors='replace')
 for n,line in enumerate(raw.splitlines(),1):
  m=re.search(r'test result: ok\. (\d+) passed; (\d+) failed;',line)
  if m: results.append({'job':int(row['name'][4:]),'line':n,'passed':int(m[1]),'failed':int(m[2]),'file':row['stdout']['file'],'rawSha256':row['stdout']['rawSha256']})
for row in records:
 if not row['name'].startswith('full-run-'):continue
 raw=gzip.decompress((b/row['stdout']['file']).read_bytes()).decode(errors='replace')
 for n,line in enumerate(raw.splitlines(),1):
  if re.search(r'::warning|(?<![A-Za-z])warning:',line,re.I):warnings.append({'file':row['stdout']['file'],'line':n,'text':line})
raw=(json.dumps(warnings,indent=2)+'\n').encode();packed=gzip.compress(raw,mtime=0);(b/'diagnostic-candidates.json.gz').write_bytes(packed)
assessment={'head':latest['head'],'observedAt':datetime.now(timezone.utc).isoformat(),'allRecordedStreamsVerified':streams,'workflowCount':24,'automaticWorkflowsSucceeded':23,'manualProducerFailures':latest['failed'],'nativeTestSummaries':results,'warningCandidateCount':len(warnings),'warningCandidates':{'file':'diagnostic-candidates.json.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()},'producerFindingsAssessment':'../codeql-producer-ad59ff56/compact-assessment.json','actionsSourceRepairHostedVerified':False,'rustContextSourceRepairHostedVerified':False,'strictOriginalSourceReplays':31,'independentReasoningAccepted':0,'fullIssueComplete':False}
(b/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n');print(json.dumps(assessment,indent=2))
print('NON-SIZE DIAGNOSTIC CANDIDATES')
for row in warnings:
 if not ('1500 lines' in row['text'] or '1,500 lines' in row['text'] or 'source file size' in row['text'].lower() or 'size threshold' in row['text'].lower() or 'exceeds' in row['text'].lower()):
  print(json.dumps({**row,'text':row['text'][:700]},ensure_ascii=False))
