from pathlib import Path
import json,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');t=s/'templates/rust-complete'
d=json.loads((r/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json').read_text());known={x['path']for x in d['files']}
for name in ('README.md','CONTRIBUTING.md','data/requirements-dev.lino'):
 if name in known: print('ALREADY',name);continue
 p=t/name
 if not p.exists(): print('ABSENT',name);continue
 raw=p.read_bytes();lines=raw.decode().splitlines();print(f'FILE {name} LINES {len(lines)} SHA256 {hashlib.sha256(raw).hexdigest()}',flush=True)
 for n,line in enumerate(lines,1): print(f'{n}: {line}',flush=True)
