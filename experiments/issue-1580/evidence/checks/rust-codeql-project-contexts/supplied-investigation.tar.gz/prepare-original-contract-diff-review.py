from pathlib import Path
import json,subprocess,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/original-contract-follow-up');s.mkdir(exist_ok=False)
d=json.loads((r/'experiments/issue-1580/evidence/ci/native-families-03ff3a8e/original-native-replay-union.json').read_text());paths=sorted({x['currentPublishedReplay']['path'] for x in d['tests'] if not x['hasPublishedPassingReplay'] and x.get('currentPublishedReplay')})
rows=[]
for n,path in enumerate(paths,1):
 p=subprocess.run(['git','diff',d['originalFailureHead'],'HEAD','--',path],cwd=r,capture_output=True);assert p.returncode==0
 name=f'{n:02d}-{Path(path).name}.diff';(s/name).write_bytes(p.stdout);row={'path':path,'file':name,'lines':len(p.stdout.splitlines()),'sha256':hashlib.sha256(p.stdout).hexdigest()};rows.append(row);print(json.dumps(row))
(s/'index.json').write_text(json.dumps(rows,indent=2)+'\n')
