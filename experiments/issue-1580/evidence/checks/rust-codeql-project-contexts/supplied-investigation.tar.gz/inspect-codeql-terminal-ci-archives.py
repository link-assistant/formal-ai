from pathlib import Path
import json,gzip,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/ci/native-families-ad59ff56'
for p in sorted(b.glob('*')):
 if p.suffix!='.gz':
  try:d=json.loads(p.read_text())
  except (ValueError,UnicodeDecodeError):continue
  print('FILE',p.name,'TYPE',type(d).__name__)
  if isinstance(d,list):print('COUNT',len(d),'FIRST',json.dumps(d[:1])[:3500])
  elif isinstance(d,dict):print('KEYS',list(d),'SUMMARY',json.dumps(d)[:2000])
for p in sorted(b.glob('jobs-*.stdout.gz')):
 d=json.loads(gzip.decompress(p.read_bytes()));print('JOBS',p.name)
 for row in d.get('jobs',[]):print(json.dumps({k:row.get(k)for k in ('databaseId','id','name','conclusion','startedAt','completedAt')}))
