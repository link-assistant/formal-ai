from pathlib import Path
import subprocess
r=Path('/tmp/gh-issue-solver-1794900398048')
files=['scripts/codeql-rust-projects.py','.github/workflows/security.yml','rust/tests/web/security-codeql-results.test.mjs','data/benchmarks/fast-pull-request-retained-jobs.json','changelog.d/1580-rust-codeql-project-contexts.md']
for f in files:
 p=subprocess.run(['git','add','--',f],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr
for f in ['scripts/codeql-rust-projects.py','changelog.d/1580-rust-codeql-project-contexts.md']:
 print('FILE',f)
 for n,line in enumerate((r/f).read_text().splitlines(),1):print(str(n)+': '+line)
p=subprocess.run(['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--list'],cwd=r,capture_output=True,text=True);assert p.returncode==0
print('RELEVANT GATES')
for line in p.stdout.splitlines():
 if any(x in line.lower() for x in ['secur','workflow','file-size','abbrev','changelog','python','format','secret','default','shell']):print(line)
print('SOURCE DIFF')
p=subprocess.run(['git','diff','--cached','--','.github/workflows/security.yml','data/benchmarks/fast-pull-request-retained-jobs.json'],cwd=r,capture_output=True,text=True);assert p.returncode==0;print(p.stdout)
