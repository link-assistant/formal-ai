from pathlib import Path
import subprocess
r=Path('/tmp/gh-issue-solver-1794900398048')
p=subprocess.run(['rg','--files','.github/workflows','rust/tests'],cwd=r,capture_output=True,text=True);assert p.returncode==0
for line in p.stdout.splitlines():
 if 'native' in line or line.startswith('.github/workflows/'): print('PATH',line)
name='rust/tests/unit/issue_1133_hive_mind_three_runs.rs';p=r/name
print('SOURCE',name)
for n,line in enumerate(p.read_text().splitlines(),1): print(f'{n}: {line}')
p=subprocess.run(['rg','-n','native-hive|ci_native_hive|hive-group|issue_1133_hive_mind_three_runs','.github/workflows','rust/tests/ci_native'],cwd=r,capture_output=True,text=True);print('SEARCH',p.returncode);print(p.stdout);print(p.stderr)
