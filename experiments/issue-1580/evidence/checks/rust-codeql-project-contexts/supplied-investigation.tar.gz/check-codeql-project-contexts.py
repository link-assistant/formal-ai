from pathlib import Path
import subprocess,json,gzip,hashlib,os
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/checks/rust-codeql-project-contexts'
args=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/security-codeql-results.test.mjs'];p=subprocess.run(args,cwd=r,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});raw=p.stdout+p.stderr;(b/'first-after.log.gz').write_bytes(gzip.compress(raw,mtime=0));(b/'first-validation.json').write_text(json.dumps({'argv':args,'exitCode':p.returncode,'rawSha256':hashlib.sha256(raw).hexdigest()})+'\n');print(raw.decode());
print('CONTEXT PLAN (no Rust or Cargo commands)')
code='import importlib.util,json,pathlib,sys;sys.dont_write_bytecode=True;s=importlib.util.spec_from_file_location("a","scripts/codeql-rust-projects.py");m=importlib.util.module_from_spec(s);s.loader.exec_module(m);g,files=m.contexts(pathlib.Path.cwd());print(json.dumps({"groups":g,"sourceFiles":files},indent=2))'
q=subprocess.run(['python3','-c',code],cwd=r,capture_output=True);(b/'context-plan.json').write_bytes(q.stdout);print('PLAN EXIT',q.returncode,'GROUPS',len(json.loads(q.stdout)['groups']) if q.returncode==0 else q.stderr.decode());assert p.returncode==0 and q.returncode==0
