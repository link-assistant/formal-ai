from pathlib import Path
import subprocess,json,hashlib
b=Path('/tmp/issue-1580-research/codeql-rust-extractor-context')
files=['rust/extractor/src/config.rs','rust/extractor/src/rust_analyzer.rs','rust/extractor/src/toolchain.rs','rust/codeql-extractor.yml','rust/README.md','rust/autobuild/src/main.rs']
for name in files:
 p=subprocess.run(['gh','api','-H','Accept: application/vnd.github.raw+json',f'repos/github/codeql/contents/{name}?ref=codeql-cli/v2.27.4'],stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert p.returncode==0,p.stderr.decode();target=b/(name.replace('/','_'));target.write_bytes(p.stdout);ls=p.stdout.decode().splitlines();print('FILE',name,'LINES',len(ls),'SHA256',hashlib.sha256(p.stdout).hexdigest())
 for i,l in enumerate(ls):
  if any(w in l for w in ['proc_macro','manifest','rust-project','toolchain','rustc','cargo_extra_env','build_script_command']):
   for n in range(max(0,i-3),min(len(ls),i+5)):print(f'{n+1:04} {ls[n]}')
