from pathlib import Path
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'rust/tests/web/security-codeql-results.test.mjs';text=p.read_text();assert 'context publication waits for verified dependency builds' not in text
text+=r'''

test('context publication waits for verified dependency builds and preserves original source paths', {timeout: 20000}, () => {
  checkPython(String.raw`
with tempfile.TemporaryDirectory(prefix='rust-context-publication-') as directory:
    base = pathlib.Path(directory)
    root = base/'checkout'
    (root/'scripts').mkdir(parents=True)
    (root/'js/wasm-worker/src').mkdir(parents=True)
    source = root/'scripts/maintained.rs'
    source.write_text('//! \x60\x60\x60cargo\n//! [dependencies]\n//! fixture="=1.2.3"\n//! \x60\x60\x60\nfn main() {}\n')
    (root/'js/wasm-worker/src/lib.rs').write_text('#![no_std]\n')
    (root/'js/wasm-worker/build.sh').write_text('rustc --edition=2024 --target wasm32-unknown-unknown --crate-type cdylib')
    original = source.read_bytes()
    rust_src = base/'rust-src'
    rust_src.mkdir()
    os.environ.update(CODEQL_RUST_SYSROOT_TOOLCHAIN='1.99.0',CODEQL_EXTRACTOR_RUST_OPTION_SYSROOT=str(base/'sysroot'),
        CODEQL_EXTRACTOR_RUST_OPTION_SYSROOT_SRC=str(rust_src))
    calls = []
    failing = True
    def command(argv, output, env):
        calls.append(argv)
        assert argv[:3] == ['rustup','run','1.99.0']
        assert env['CARGO_BUILD_JOBS'] == '1' and env['CARGO_INCREMENTAL'] == '0'
        if argv[3] == 'rustc':
            return 'host: x86_64-unknown-linux-gnu\n'
        if argv[4] == 'metadata':
            package = dict(id='fixture',name='fixture',version='1.2.3',manifest_path=str(base/'fixture/Cargo.toml'),
                targets=[dict(name='fixture',kind=['lib'],src_path=str(base/'fixture/lib.rs'),edition='2021')])
            node = dict(id='fixture',features=[],deps=[])
            return json.dumps(dict(packages=[package],resolve=dict(root='collector',nodes=[node,dict(id='collector',features=[],
                deps=[dict(pkg='fixture',name='fixture',dep_kinds=[dict(kind=None,target=None)])])])) )
        assert argv[4] == 'check' and '--locked' in argv and '--lib' in argv
        if failing:
            raise RuntimeError('fixture dependency compilation failed')
        return ''
    a.command = command
    try:
        a.prepare(root,base/'failed')
        raise AssertionError('dependency failure reported success')
    except RuntimeError as e:
        assert 'dependency compilation failed' in str(e)
    assert not (root/'scripts/rust-project.json').exists()
    assert not (root/'js/wasm-worker/rust-project.json').exists()
    assert source.read_bytes() == original
    failing = False
    a.prepare(root,base/'verified')
    project = json.loads((root/'scripts/rust-project.json').read_text())
    own = next(c for c in project['crates'] if c['is_workspace_member'])
    assert own['root_module'] == str(source)
    assert own['deps'] == [dict(crate=0,name='fixture')]
    assert own['cfg'] == ['test']
    assert pathlib.Path(own['env']['CARGO_MANIFEST_DIR']).is_dir()
    assert source.read_bytes() == original
    receipt = json.loads((base/'verified/contexts.json').read_text())
    assert len(receipt['projects']) == 2
    try:
        a.prepare(root,base/'overwrite')
        raise AssertionError('existing manifest overwritten')
    except ValueError as e:
        assert 'Refusing to overwrite' in str(e)
`);
});
'''
p.write_text(text)
p=r/'.github/workflows/security.yml';text=p.read_text();assert '          if-no-files-found: warn\n' in text;text=text.replace('          if-no-files-found: warn\n','          if-no-files-found: error\n');p.write_text(text)
p=r/'scripts/codeql-rust-projects.py';text=p.read_text();text=text.replace('    elif source.startswith("#!/") and "rust-script" in source.splitlines()[0]:','    elif re.match(r"^#![ \\t]*/", source) and "rust-script" in source.splitlines()[0]:')
# target_dir was only a call-site leftover and is not needed to resolve Cargo's absolute paths.
text=text.replace('def dependency_graph(metadata, messages, host, target_dir):','def dependency_graph(metadata, messages, host):').replace('dependency_graph(metadata, messages, host, output / "target")','dependency_graph(metadata, messages, host)');p.write_text(text)
p=r/'rust/tests/web/security-codeql-results.test.mjs';text=p.read_text();text=text.replace("a.dependency_graph(metadata,messages,'x86_64-unknown-linux-gnu',base/'target')","a.dependency_graph(metadata,messages,'x86_64-unknown-linux-gnu')").replace("a.dependency_graph(metadata,missing,'host',base/'target')","a.dependency_graph(metadata,missing,'host')").replace("a.dependency_graph(metadata,messages,'host',base/'target')","a.dependency_graph(metadata,messages,'host')");p.write_text(text)
p=r/'changelog.d/1580-rust-codeql-project-contexts.md';p.write_text(p.read_text().replace('---\nbump: patch\n---\n','bump: patch\n'))
for cmd in [['rg','--files','data/meta'],['rg','--files','experiments/issue-1580'],['rg','-n','retained|payload|snapshot','rust/tests/web/default-branch-build-policy.test.mjs']]:
 import subprocess
 q=subprocess.run(cmd,capture_output=True);ls=q.stdout.decode().splitlines();selected=[l for l in ls if any(w in l for w in ['retained','default-branch','work-plan','payload','snapshot'])];print('QUERY',cmd,'MATCHES',len(selected));print('\n'.join(selected[:50]))
print('DRAFT EXTENDED')
