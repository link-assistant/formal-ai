from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,gzip,hashlib,os,sys,time,traceback
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/rust-codeql-staged-validation');b=r/'experiments/issue-1580/evidence/checks/rust-codeql-project-contexts/staged-validation'
if len(sys.argv)==1:
 s.mkdir(exist_ok=False);b.mkdir(exist_ok=False)
 p=subprocess.run(['git','add','--all'],cwd=r,capture_output=True,text=True);assert p.returncode==0,p.stderr
 with(s/'worker.log').open('wb')as f:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=r,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'scratch':str(s)}));raise SystemExit(0)
rows=[]
def run(label,args):
 start=time.monotonic();p=subprocess.run(args,cwd=r,capture_output=True,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','PYTHONDONTWRITEBYTECODE':'1'});raw=p.stdout+p.stderr;packed=gzip.compress(raw,mtime=0);name=label+'.log.gz';(b/name).write_bytes(packed);row={'label':label,'argv':args,'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3),'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()};rows.append(row);(b/'records.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,p.returncode,raw.decode(errors='replace')[-1700:],flush=True);assert p.returncode==0,label
try:
 for file in ['hive-mind-draft-workflow.test.mjs','default-branch-build-policy.test.mjs','fast-pull-request-production-profile.test.mjs','documentation-only-ci-policy.test.mjs']:
  run(file,['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+file])
 for gate in ['check-abbreviations','check-file-size','check-file-size-js-twin','check-changelog-fragment-js-twin','release#1','release#2']:
  run(gate,['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only',gate])
 run('staged-diff-check',['git','diff','--cached','--check']);run('working-diff-check',['git','diff','--check'])
 for row in json.loads((b.parent/'final-source-identities.json').read_text()):assert hashlib.sha256((r/row['file']).read_bytes()).hexdigest()==row['sha256'],row['file']
 outcome={'complete':True,'observedAt':datetime.now(timezone.utc).isoformat(),'sourceIdentitiesUnchanged':True,'checks':rows,'hostedCodeqlRepairVerified':False,'fullIssueComplete':False};(b/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');(s/'outcome.json').write_text(json.dumps(outcome)+'\n');print('COMPLETE',flush=True)
except BaseException:
 traceback.print_exc();(s/'failure.json').write_text(json.dumps({'complete':False,'traceback':traceback.format_exc()})+'\n');sys.exit(1)
