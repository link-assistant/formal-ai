from pathlib import Path
import subprocess,hashlib,json
b=Path('/tmp/issue-1580-research/codeql-rust-extractor-context')
files=[('github/codeql','rust/extractor/Cargo.toml','codeql-cli/v2.27.4'),('rust-lang/rust-analyzer','crates/project-model/src/project_json.rs','master'),('rust-lang/rust-analyzer','docs/book/src/non_cargo_based_projects.md','master')]
for repo,name,ref in files:
 p=subprocess.run(['gh','api','-H','Accept: application/vnd.github.raw+json',f'repos/{repo}/contents/{name}?ref={ref}'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 print('FETCH',repo,name,p.returncode)
 if p.returncode:print(p.stderr.decode()[:500]);continue
 target=b/(repo.replace('/','_')+'_'+name.replace('/','_'));target.write_bytes(p.stdout);ls=p.stdout.decode().splitlines();print('LINES',len(ls),'SHA256',hashlib.sha256(p.stdout).hexdigest())
 if name.endswith('Cargo.toml') or name.endswith('.md'):
  for n,line in enumerate(ls):print(f'{n+1:04} {line}')
 else:
  for i,l in enumerate(ls):
   if l.startswith('pub struct') or 'pub ' in l or 'default' in l: print(f'{i+1:04} {l}')
print('CICOLLECTOR', '\n'.join(Path('/tmp/issue-1580-research/codeql-producer-ci/worker.log').read_text().splitlines()[-2:]))
