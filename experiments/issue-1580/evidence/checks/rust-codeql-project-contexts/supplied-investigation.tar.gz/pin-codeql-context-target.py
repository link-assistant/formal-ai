from pathlib import Path
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'scripts/codeql-rust-projects.py';t=p.read_text();old='"--target-dir", str(output / "target")], directory / "build.jsonl", env)';new='"--target", host, "--target-dir", str(output / "target")], directory / "build.jsonl", env)';assert t.count(old)==1;t=t.replace(old,new);p.write_text(t)
p=r/'rust/tests/web/security-codeql-results.test.mjs';t=p.read_text();old="        assert argv[4] == 'check' and '--locked' in argv and '--lib' in argv\n";new=old+"        assert argv[argv.index('--target') + 1] == 'x86_64-unknown-linux-gnu'\n";assert t.count(old)==1;t=t.replace(old,new);p.write_text(t)
print('Cargo dependency check now pins the same host target used by metadata filtering; regression asserts it.')
