from pathlib import Path
import subprocess
r=Path('/tmp/gh-issue-solver-1794900398048')
for args in [['rg','-n','repository_workflows_include_runtime_setup_and_output_verification|the_full_claude_code_drive_reads_builds_verifies_and_pushes_kotlin','rust/tests'],['rg','-n','native-hive|ci_native_hive|hive-group|issue_1133_hive_mind_three_runs','rust/tests/issue_1580*','.github/workflows/rust-type-check.yml','.github/workflows/ci.yml']]:
 p=subprocess.run(args,cwd=r,capture_output=True,text=True);print('COMMAND',args,'EXIT',p.returncode);print(p.stdout);print(p.stderr)
