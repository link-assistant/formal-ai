from pathlib import Path
import subprocess,json,gzip,re,collections
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');out=s/'rust-codeql-publication-preflight';out.mkdir(exist_ok=False)
steps=[('branch',['git','branch','--show-current']),('main-fetch',['git','fetch','origin','main']),('main-head',['git','rev-parse','origin/main']),('main-is-ancestor',['git','merge-base','--is-ancestor','origin/main','HEAD']),('head',['git','rev-parse','HEAD']),('remote-branch',['git','ls-remote','origin','refs/heads/issue-1580-8d61a32a61e1']),('in-progress',['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--status','in_progress','--json','databaseId,workflowName,headSha']),('queued',['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--status','queued','--json','databaseId,workflowName,headSha']),('recent-runs',['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','5','--json','databaseId,conclusion,createdAt,headSha']),('pr',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','isDraft,headRefOid,mergeStateStatus,updatedAt,title'])]
for label,args in steps:
 p=subprocess.run(args,cwd=r,capture_output=True);(out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr);print(label,p.returncode,p.stdout.decode(),p.stderr.decode());assert p.returncode==0,label
b=r/'experiments/issue-1580/evidence/ci/native-families-ad59ff56';w=json.loads(gzip.decompress((b/'diagnostic-candidates.json.gz').read_bytes()));m=collections.defaultdict(list)
for x in w:
 match=re.search(r'WARNING: (.*?) has (\d+) lines \(approaching',x['text'])
 if match:m[match[1]].append({'lines':int(match[2]),'file':x['file'],'line':x['line']})
print('UNIQUE SOURCE-SIZE WARNINGS',len(m))
for f,rows in m.items():print(json.dumps({'file':f,'occurrences':len(rows),'lines':sorted(set(x['lines']for x in rows))},ensure_ascii=False))
(out/'size-warning-inventory.json').write_text(json.dumps(m,indent=2)+'\n')
