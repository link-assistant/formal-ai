from pathlib import Path
r=Path('/tmp/gh-issue-solver-1794900398048')
for name,start,end in [('docs/case-studies/issue-1580/README.md',180,350),('experiments/issue-1580/work-plan.md',1110,1400),('.github/workflows/security.yml',1,330)]:
 print('FILE',name,flush=True)
 for n,line in enumerate((r/name).read_text().splitlines(),1):
  if start<=n<=end: print(f'{n}: {line}',flush=True)
