from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,gzip,hashlib,tarfile,io,traceback
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');b=r/'experiments/issue-1580/evidence/checks/rust-codeql-project-contexts';out=s/'rust-codeql-context-commits';out.mkdir(exist_ok=False)
assert json.loads((s/'rust-codeql-staged-validation/outcome.json').read_text())['complete'];records=[]
def run(label,args):
 p=subprocess.run(args,cwd=r,capture_output=True);raw=p.stdout+p.stderr;(out/(label+'.log')).write_bytes(raw);records.append({'label':label,'argv':args,'exitCode':p.returncode,'sha256':hashlib.sha256(raw).hexdigest()});(out/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(label,p.returncode,raw.decode(errors='replace')[-900:],flush=True);assert p.returncode==0,label
 return p.stdout.decode().strip()
try:
 assert run('branch',['git','branch','--show-current'])=='issue-1580-8d61a32a61e1'
 ids=json.loads((b/'final-source-identities.json').read_text())
 for row in ids:assert hashlib.sha256((r/row['file']).read_bytes()).hexdigest()==row['sha256']
 review={'reviewedAt':datetime.now(timezone.utc).isoformat(),'files':ids,'completeCurrentSourceAndDiffRead':True,'workflowAndTestDiffRead':True,'originalProducerFailureReproducesProblem':True,'localRustExecution':False,'hostedRepairVerified':False,'wholePrReviewComplete':False,'fullIssueComplete':False,'independentAuthorshipCredit':0};(b/'final-source-review.json').write_text(json.dumps(review,indent=2)+'\n')
 names=['review-final-codeql-context-diff.py','review-final-codeql-context-diff.log','prepare-rust-codeql-publication.py','prepare-rust-codeql-publication.log','inventory-whole-pr-review.py','inventory-whole-pr-review.log','compare-current-pr-review-manifests.py','compare-current-pr-review-manifests.log','archive-rust-codeql-context-investigation.py','archive-rust-codeql-context-investigation.log','commit-rust-codeql-context-batch.py','rust-codeql-staged-validation/worker.log','rust-codeql-staged-validation/outcome.json','whole-pr-review/published.stderr','whole-pr-review/local-numstat.txt','whole-pr-review/file-inventory.json']
 buf=io.BytesIO();rows=[]
 with tarfile.open(fileobj=buf,mode='w')as a:
  for name in names:
   raw=(s/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;a.addfile(info,io.BytesIO(raw));rows.append({'file':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
 raw=buf.getvalue();packed=gzip.compress(raw,mtime=0);(b/'supplied-final-review.tar.gz').write_bytes(packed);(b/'supplied-final-review.json').write_text(json.dumps({'files':rows,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'independentAuthorshipCredit':0},indent=2)+'\n')
 run('archive-command-records',['python3',str(s/'archive-evidence.py')]);run('stage-batch',['git','add','--all']);run('staged-check',['git','diff','--cached','--check'])
 run('commit-context-source',['git','commit','-m','Preserve declared Rust contexts for complete CodeQL analysis','--',*[x['file']for x in ids]])
 source=run('source-commit',['git','rev-parse','HEAD']);(b/'source-commit.json').write_text(json.dumps({'sourceCommit':source,'verifiedFiles':ids,'hostedRepairVerified':False,'fullIssueComplete':False},indent=2)+'\n')
 run('stage-source-receipt',['git','add','--',str(b/'source-commit.json')]);run('commit-exact-producer-evidence',['git','commit','-m','Retain original CodeQL failures and verified CI context evidence'])
 head=run('head',['git','rev-parse','HEAD']);assert run('clean-status',['git','status','--porcelain'])==''
 outcome={'complete':True,'sourceCommit':source,'head':head,'fullIssueComplete':False};(out/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome),flush=True)
except BaseException:
 traceback.print_exc();(out/'failure.json').write_text(json.dumps({'complete':False,'traceback':traceback.format_exc()})+'\n');raise
