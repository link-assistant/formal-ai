from pathlib import Path
import subprocess,json,gzip,hashlib,tarfile,io
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');b=r/'experiments/issue-1580/evidence/checks/rust-codeql-project-contexts'
p=b/'final-source-review.json';d=json.loads(p.read_text());d['completeCurrentSourceAndDiffRead']=False;d['completeCurrentImplementationSourceAndChangedDiffRead']=True;d['nonExecutableBaselineReview']='The complete one-field retained-job payload diff was read; the entire unchanged baseline document was not reread in this batch.';d['correction']='The first combined source-and-diff flag was overbroad for the non-executable baseline document. This forward correction preserves the original commit.';p.write_text(json.dumps(d,indent=2)+'\n')
names=['commit-rust-codeql-context-batch.py','commit-rust-codeql-context-batch.log','rust-codeql-context-commits/records.json','rust-codeql-context-commits/outcome.json','rust-codeql-context-commits/commit-context-source.log','rust-codeql-context-commits/commit-exact-producer-evidence.log','seal-rust-codeql-review-boundaries.py'];buf=io.BytesIO();rows=[]
with tarfile.open(fileobj=buf,mode='w')as archive:
 for name in names:
  raw=(s/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(raw));rows.append({'file':name,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
raw=buf.getvalue();packed=gzip.compress(raw,mtime=0);(b/'commit-boundary-evidence.tar.gz').write_bytes(packed);(b/'commit-boundary-evidence.json').write_text(json.dumps({'files':rows,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'independentAuthorshipCredit':0},indent=2)+'\n')
for row in json.loads((b/'final-source-identities.json').read_text()):assert hashlib.sha256((r/row['file']).read_bytes()).hexdigest()==row['sha256']
for args in [['python3',str(s/'archive-evidence.py')],['git','add','--all'],['git','diff','--cached','--check'],['git','commit','-m','Clarify the final CodeQL source review boundary'],['git','rev-parse','HEAD'],['git','status','--porcelain']]:
 q=subprocess.run(args,cwd=r,capture_output=True,text=True);print(args[:3],q.returncode,q.stdout[-1200:],q.stderr);assert q.returncode==0
 if args[:2]==['git','status']:assert q.stdout==''
