from pathlib import Path
import gzip, hashlib, json, os, subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
out=root/'experiments/issue-1580/evidence/checks/included-string-query-specialization'
out.mkdir(exist_ok=False)
records=[]
def run(name,argv):
    result=subprocess.run(argv,cwd=root,env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256'),capture_output=True)
    row={'name':name,'argv':argv,'exitCode':result.returncode}
    for label,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
        name=row['name']+'.'+label+'.gz';packed=gzip.compress(raw,mtime=0);(out/name).write_bytes(packed)
        row[label]={'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())}
    records.append(row);(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
    assert result.returncode==0,(row['name'],result.stdout.decode()[-3000:],result.stderr.decode()[-1000:])
    return result.stdout

query=root/'experiments/issue-1580/codeql-macro-contexts/IncludedStringPayloads.ql'
original=query.read_text();(out/'before.ql.gz').write_bytes(gzip.compress(original.encode(),mtime=0))
source=original.replace('import rust\n','''import rust

// Narrow helper domains before expansion, literal and control-flow joins.
private class IncludedStringCall extends MacroCall {
  IncludedStringCall() { this.fromSource() and this.getPath().getText() = "include_str" }
}
''').replace('(MacroCall call)','(IncludedStringCall call)').replace('from MacroCall call\nwhere call.fromSource() and call.getPath().getText() = "include_str"','from IncludedStringCall call')
assert source!=original and source.count('IncludedStringCall call')==4
query.write_text(source)
adapter=root/'experiments/issue-1580/codeql-macro-contexts/observe.py'
source=adapter.read_text().replace('profile="macro-contexts"):', 'profile="macro-contexts", trace_evaluation=False):')
needle='            run("query", ["query", "run", "--database=" + str(database),'
assert source.count(needle)==1
source=source.replace(needle,'''            # Opt in only for an investigation; normal observations retain quiet logs.
            trace_options = ["--evaluator-log=" + str(output / "evaluation.jsonl")] if trace_evaluation else []
            manifest["traceEvaluation"] = trace_evaluation
            run("query", ["query", "run", "--database=" + str(database),''').replace('"--warnings=error", str(installed)])','"--warnings=error", *trace_options, str(installed)])')
source=source.replace('    args = parser.parse_args()','    parser.add_argument("--trace-evaluation", action="store_true", help="Retain structured evaluator diagnostics for investigation")\n    args = parser.parse_args()').replace('args.output.resolve(), args.profile)))','args.output.resolve(), args.profile, args.trace_evaluation)))')
adapter.write_text(source)
workflow=root/'.github/workflows/security.yml';source=workflow.read_text();needle='          --profile included-string-payloads\n';assert source.count(needle)==1
workflow.write_text(source.replace(needle,'          --profile included-string-payloads --trace-evaluation\n'))
test=root/'experiments/issue-1580/codeql-included-string-observation.test.mjs';source=test.read_text()
source=source.replace('  assert.match(probe.run, /--profile included-string-payloads/);','  assert.match(probe.run, /--profile included-string-payloads --trace-evaluation/);')
source=source.replace("    assert '--warnings=error' in args","    assert '--warnings=error' in args\n    trace=[value for value in args if value.startswith('--evaluator-log=')]\n    assert bool(trace)==(mode=='traced-success')\n    if trace:\n        pathlib.Path(trace[0].split('=',1)[1]).write_text('fixture structured evaluator log\\n')")
source=source.replace("['success','empty'","['success','traced-success','empty'")
source=source.replace("'unknown' if mode=='unknown-profile' else 'included-string-payloads')","'unknown' if mode=='unknown-profile' else 'included-string-payloads',\n                      trace_evaluation=mode=='traced-success')")
source=source.replace("mode=='success'","mode in ['success','traced-success']").replace("mode!='success'","mode not in ['success','traced-success']")
needle="            assert manifest['profile']=='included-string-payloads'";assert source.count(needle)==1
source=source.replace(needle,"            assert manifest['traceEvaluation']==(mode=='traced-success')\n            assert (output/'evaluation.jsonl').exists()==(mode=='traced-success')\n"+needle)
test.write_text(source)
# Review the exact producer inverse before refreshing its single retained hash.
code='''import fs from 'node:fs';import assert from 'node:assert/strict';import YAML from 'yaml';import {execFileSync} from 'node:child_process';import {createHash} from 'node:crypto';
const file='data/benchmarks/fast-pull-request-retained-jobs.json';
const old=YAML.parse(execFileSync('git',['show','HEAD:.github/workflows/security.yml'],{encoding:'utf8'})).jobs.codeql;
const current=YAML.parse(fs.readFileSync('.github/workflows/security.yml','utf8')).jobs.codeql;
const payload=job=>({steps:job.steps,uses:job.uses,with:job.with,strategy:job.strategy});
const reverted=structuredClone(current), steps=reverted.steps.filter(step=>step.name==='Observe included Rust string payloads');assert.equal(steps.length,1);
assert.equal(steps[0]['timeout-minutes'],4);assert.equal(steps[0].if,"${{ github.job == 'codeql-readonly' && matrix.language == 'rust' && inputs.macro-contexts }}");
steps[0].run=steps[0].run.replace(' --trace-evaluation','');assert.deepEqual(reverted,old);
const manifest=JSON.parse(fs.readFileSync(file,'utf8')), rows=manifest.jobs.filter(row=>row.file==='security.yml'&&row.id==='codeql');assert.equal(rows.length,1);
const hash=job=>createHash('sha256').update(JSON.stringify(payload(job))).digest('hex');assert.equal(rows[0].payloadSha256,hash(old));rows[0].payloadSha256=hash(current);
fs.writeFileSync(file,JSON.stringify(manifest,null,2)+'\\n');console.log(JSON.stringify({onlyInvestigationTraceArgumentAdded:true,timeoutUnchanged:true,productionAdmissionUnchanged:true,payloadSha256:rows[0].payloadSha256}));'''
run('retained-producer-inverse',['node','--input-type=module','-e',code])
for label,file in [('adapter','experiments/issue-1580/codeql-included-string-observation.test.mjs'),('profile','rust/tests/web/fast-pull-request-production-profile.test.mjs'),('security','rust/tests/web/security-codeql-results.test.mjs')]:
    run(label,['node','--test','--test-reporter=tap','--test-concurrency=1',file])
run('whitespace',['git','diff','--check'])
(out/'verification.json').write_text(json.dumps({'complete':True,'failingRun':44843748460,'errorLogLine':4819,'observation':'Query compiled in 25.1 seconds; evaluation remained unfinished until the unchanged four-minute hosted step deadline. No evaluator trace was enabled in that run.','change':'Specialize all helper argument domains to source include_str calls; enable opt-in hosted evaluator tracing.','rootCauseProven':False,'hostedPerformanceVerified':False,'resultEquivalenceVerified':False,'standardSecurityAnalysisPreserved':True,'fullIssueComplete':False,'independentAuthorshipCredit':0,'documentation':['https://docs.github.com/en/code-security/reference/code-scanning/codeql/codeql-cli-manual/query-run','https://codeql.github.com/docs/writing-codeql-queries/troubleshooting-query-performance/']},indent=2)+'\n')
print('Local adapter, retained producer and security checks pass; hosted specialization and coverage remain unverified.')
