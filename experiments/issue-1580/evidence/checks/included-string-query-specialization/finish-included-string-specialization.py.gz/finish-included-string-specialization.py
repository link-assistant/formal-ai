from pathlib import Path
import gzip,json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=root/'experiments/issue-1580/evidence/checks/included-string-query-specialization'
path=root/'experiments/issue-1580/codeql-included-string-observation.test.mjs';source=path.read_text()
old=".write_text('fixture structured evaluator log\\n')";new=".write_text('fixture structured evaluator log\\\\n')";assert source.count(old)==1
path.write_text(source.replace(old,new))
# Retain the first failed adapter run; resume the same checks with a corrected fixture escape.
run_source=Path('/tmp/issue-1580-research/refine-included-string-observation.py').read_text()
prefix=run_source[:run_source.index("query=root/")].replace('out.mkdir(exist_ok=False)','assert out.is_dir()').replace('records=[]',"records=json.loads((out/'records.json').read_text())")
scope={};exec(compile(prefix,'verification-helper','exec'),scope);run=scope['run']
for label,file in [('adapter-corrected','experiments/issue-1580/codeql-included-string-observation.test.mjs'),('profile','rust/tests/web/fast-pull-request-production-profile.test.mjs'),('security','rust/tests/web/security-codeql-results.test.mjs')]:
    run(label,['node','--test','--test-reporter=tap','--test-concurrency=1',file])
run('whitespace',['git','diff','--check'])
tail=run_source[run_source.index("(out/'verification.json')"):];exec(compile(tail,'verification-summary','exec'),{'out':out,'json':json})
