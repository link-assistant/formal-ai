from pathlib import Path
import subprocess,sys,json,traceback,gzip
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'seed-head-ci-repairs'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args,expected=0):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==expected,(name,r.returncode,expected)
 return (out/(name+'.stdout')).read_text()
def change(name,old,new):
 p=root/name;text=p.read_text();assert text.count(old)==1,(name,old);(out/(p.name+'.before.gz')).write_bytes(gzip.compress(text.encode(),mtime=0));p.write_text(text.replace(old,new))
try:
 test=root/'experiments/issue-1580/ci-source-transport.test.mjs';assert not test.exists();test.write_text('''import assert from 'node:assert/strict';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { tmpdir } from 'node:os';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import test from 'node:test';
import YAML from 'yaml';
const root = fileURLToPath(new URL('../../', import.meta.url));
const read = name => readFileSync(join(root, name), 'utf8');

test('the actual layered sparse checkout retains consumed source fixtures', { timeout: 20_000 }, t => {
  const workflow = YAML.parse(read('.github/workflows/layered-ci.yml'));
  const candidates = Object.values(workflow.jobs).flatMap(job => job.steps ?? []);
  const checkout = candidates.find(step => step.with?.['sparse-checkout']?.includes('native-reasoning-budget'));
  assert.ok(checkout);
  const files = ['seed-record-readers.test.mjs', 'application-conversation-list.test.mjs'].flatMap(file => {
    const source = read('experiments/issue-1580/' + file);
    return [...source.matchAll(/new URL\\('([^']+\\.gz)'/gu)].map(match =>
      relative(root, fileURLToPath(new URL(match[1], new URL('./' + file, import.meta.url)))));
  });
  assert.equal(files.length, 2);
  const directory = mkdtempSync(join(tmpdir(), 'issue-1580-sparse-fixtures-'));
  t.after(() => rmSync(directory, { recursive: true, force: true }));
  const git = (...args) => execFileSync('git', args, { cwd: directory, stdio: 'pipe', timeout: 10_000,
    env: { ...process.env, GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: '/dev/null' } });
  git('init', '-q');git('config', 'user.name', 'Fixture');git('config', 'user.email', 'fixture@example.invalid');
  const archive = 'experiments/issue-1580/evidence/checks/unconsumed-history.log.gz';
  for (const path of [...files, archive]) {
    mkdirSync(dirname(join(directory, path)), { recursive: true });
    writeFileSync(join(directory, path), 'bounded sparse-checkout operand');
  }
  git('add', '.');git('commit', '-qm', 'Sparse fixture input');
  git('sparse-checkout', 'init', '--no-cone');
  writeFileSync(join(directory, '.git/info/sparse-checkout'), checkout.with['sparse-checkout']);
  git('read-tree', '-mu', 'HEAD');
  for (const path of files) assert.ok(existsSync(join(directory, path)), path);
  assert.equal(existsSync(join(directory, archive)), false);
});

test('the structured-output VM loads the actual seed-reader prerequisite', () => {
  const source = read('rust/tests/web/issue-1586-structured-output.test.mjs');
  const scripts = source.match(/for \\(const script of (\\[[^\\n]+\\])\\)/u)?.[1];
  assert.ok(scripts);
  const context = vm.createContext({ self: {} });
  for (const file of vm.runInNewContext(scripts)) vm.runInContext(read('js/' + file), context);
  assert.equal(typeof context.self.FormalAiSeed.parse, 'function');
  assert.equal(context.self.FormalAiSeed.parse('record').children[0].name, 'record');
});
''')
 run('transport-before',['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',str(test.relative_to(root))],1)
 targets=['release-failure-output-receipt','relocated-build-stage-controls','issue-1550-procedure-documentation','packaging-console-retention']
 for name in targets:run(name+'-before',['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs'],1)
 # Keep the writer invocation visible to the unchanged closed source recognizer.
 p=root/'scripts/desktop-release-manifest.sh';text=p.read_text();writer=text.splitlines()[-1];assert writer.startswith('node "$FORMAL_AI_NATIVE_PROTOCOL_DIR/release-producer-output-receipt.mjs"');(out/'desktop-release-manifest.sh.before.gz').write_bytes(gzip.compress(text.encode(),mtime=0));p.write_text(text[:-len(writer+'\n')])
 invocation='bash "$FORMAL_AI_NATIVE_PROTOCOL_DIR/desktop-release-manifest.sh"'
 change('.github/workflows/desktop-release.yml','          '+invocation+'\n','          '+invocation+'\n          '+writer+'\n')
 change('experiments/issue-1580/desktop-manifest-headroom.test.mjs',"assert.equal(manifest.run.trim(),'"+invocation+"');","assert.deepEqual(manifest.run.trim().split('\\n'),["+json.dumps(invocation)+','+json.dumps(writer)+']);')
 # Assert the actual preserved source owners, with their workflow transport still bound.
 p=root/'rust/tests/web/packaging-console-retention.test.mjs';text=p.read_text();(out/(p.name+'.before.gz')).write_bytes(gzip.compress(text.encode(),mtime=0));text=text.replace("  assert.match(workflow, /\\[macos-arm64\\]=\"macos-15\"/);", "  assert.ok(workflow.includes('bash \"$FORMAL_AI_NATIVE_PROTOCOL_DIR/desktop-release-manifest.sh\"'));\n  const manifest = readFileSync(new URL('../../../scripts/desktop-release-manifest.sh', import.meta.url), 'utf8');\n  assert.match(manifest, /\\[macos-arm64\\]=\"macos-15\"/);")
 text=text.replace("  assert.ok(workflow.includes('required_macos_artifacts=('));\n  assert.ok(workflow.includes('codesign --verify'));", "  assert.ok(workflow.includes('bash \"$FORMAL_AI_NATIVE_PROTOCOL_DIR/desktop-release-evidence.sh\"'));\n  const evidence = readFileSync(new URL('../../../scripts/desktop-release-evidence.sh', import.meta.url), 'utf8');\n  assert.ok(evidence.includes('required_macos_artifacts=('));\n  assert.ok(evidence.includes('codesign --verify'));")
 assert text!=p.read_text();p.write_text(text)
 change('rust/tests/web/helpers/issue-1550-procedure-documentation.mjs',"      'rust/src/meta_executor/production.rs',", "      'rust/src/meta_executor/production.rs',\n      'rust/src/meta_executor/selection.rs',")
 change('rust/tests/web/issue-1586-structured-output.test.mjs',"['parser-cache-primordials.js', 'seed_loader.js']", "['parser-cache-primordials.js', 'seed-record-readers.js', 'seed_loader.js']")
 for source,dest,testfile in [('evidence/checks/seed-record-readers/previous-loader.js.gz','fixtures/seed-record-readers/previous-loader.js.gz','seed-record-readers.test.mjs'),('evidence/checks/conversation-list-hook/application-before.jsx.gz','fixtures/conversation-list-hook/application-before.jsx.gz','application-conversation-list.test.mjs')]:
  origin=root/'experiments/issue-1580'/source;destination=root/'experiments/issue-1580'/dest;destination.parent.mkdir(parents=True,exist_ok=True);assert not destination.exists();destination.write_bytes(origin.read_bytes());assert gzip.decompress(destination.read_bytes())==gzip.decompress(origin.read_bytes());change('experiments/issue-1580/'+testfile,'./'+source,'./'+dest)
 entry=root/'rust/tests/web/issue-1580-template-observations.test.mjs';entry.write_text(entry.read_text()+"\nimport '../../../experiments/issue-1580/ci-source-transport.test.mjs';\n")
 for name in targets+['issue-1181-cli-release-assets']:run(name+'-after',['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs'])
 for name in ['ci-source-transport','desktop-manifest-headroom','seed-record-readers','application-conversation-list']:run(name+'-after',['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','experiments/issue-1580/'+name+'.test.mjs'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'repairedFailedTests':6,'wasmInputReceiptUnresolved':True,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
