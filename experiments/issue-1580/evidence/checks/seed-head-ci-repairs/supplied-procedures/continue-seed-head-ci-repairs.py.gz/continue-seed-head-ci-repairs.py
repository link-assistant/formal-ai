from pathlib import Path
import subprocess,sys,json,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'seed-head-ci-repair-continuation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 p=root/'rust/tests/web/packaging-console-retention.test.mjs';text=p.read_text();old="  assert.ok(workflow.includes('bash \"$FORMAL_AI_NATIVE_PROTOCOL_DIR/desktop-release-evidence.sh\"'));\n  const evidence = readFileSync(new URL('../../../scripts/desktop-release-evidence.sh', import.meta.url), 'utf8');\n  assert.ok(evidence.includes('required_macos_artifacts=('));\n  assert.ok(evidence.includes('codesign --verify'));";new="  assert.ok(workflow.includes('required_macos_artifacts=('));\n  assert.ok(workflow.includes('codesign --verify'));";assert old in text;p.write_text(text.replace(old,new))
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':child.pid})+'\n');print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==0,(name,r.returncode)
try:
 for name in ['packaging-console-retention','issue-1181-cli-release-assets']:run(name,['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs'])
 for name in ['ci-source-transport','desktop-manifest-headroom','seed-record-readers','application-conversation-list']:run(name,['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','experiments/issue-1580/'+name+'.test.mjs'])
 run('issue-entry',['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])
 run('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-abbreviations,check-readable-code,check-twin-citations,check-runner-labels,check-pr-timeout-budget'])
 run('whitespace',['git','diff','--check'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'sixFailedChecksRepaired':True,'wasmReceiptStillUnresolved':True,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:
 traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
