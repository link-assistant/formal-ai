from pathlib import Path
import subprocess,json,gzip,hashlib,sys,datetime
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');base=root/'experiments/issue-1580/evidence/checks/seed-head-ci-repairs';base.mkdir(parents=True,exist_ok=False)
assert json.loads((scratch/'seed-head-ci-repairs-final/outcome.json').read_text())['complete']
records=[]
def preserve(source,name):
 raw=source.read_bytes();target=base/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);packed=gzip.compress(raw,mtime=0);target.write_bytes(packed);assert gzip.decompress(packed)==raw
 records.append({'path':str(target.relative_to(base)),'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
for directory in ['seed-head-ci-repairs','seed-head-ci-repair-continuation','seed-head-ci-repairs-final']:
 for path in sorted((scratch/directory).rglob('*')):
  if path.is_file():preserve(path,directory+'/'+str(path.relative_to(scratch/directory)))
helpers=['repair-seed-head-ci.py','continue-seed-head-ci-repairs.py','finish-seed-head-ci-repairs.py','preserve-seed-head-ci-repairs.py']
for name in helpers:preserve(scratch/name,'supplied-procedures/'+name)
for name in ['transport-parser-inspection-driver.log','transport-parser-return-driver.log','transport-parser-correct-owner-driver.log','transport-parser-function-driver.log','seed-head-ci-repairs-self-review-driver.log','read-ci-repair-documentation-shape-driver.log','finish-seed-head-ci-repairs-driver.log']:
 preserve(scratch/name,'investigation/'+name)
(base/'records.json').write_text(json.dumps({'records':records,'independentAuthorshipCredit':0,'nativeCompilation':False,'fullIssueComplete':False},indent=2)+'\n')
doc=root/'docs/case-studies/issue-1580/seed-head-ci-repair-checkpoint.md';doc.write_text('''# Source transport and release receipt repairs

Layered CI run [44938456935](https://github.com/link-assistant/formal-ai/actions/runs/44938456935)
tested published source `9e945eae3f1f3a03a2b9e3302bdb81000f7820b1` and failed.
Its full-log SHA256 is `32679b18f6b87b086352a6d034d4db9a14c0cf49ec1730ab8925e0b11d07c9a4`.
The following repairs preserve the existing guards and point consumers at their
actual source owners and transport operands.

| Original log lines | Failure | Repair and verification |
| --- | --- | --- |
| 4712–4719, 4935–4957 | Receipt recognizer cannot see the writer hidden inside the extracted manifest shell script | Restore the same writer as the final inline workflow command; unchanged receipt and relocated-stage behavioral suites pass. |
| 7396–7405 | Structured-output VM omits the seed reader prerequisite | Load the actual prerequisite; a focused VM case consumes the actual suite's script list and parses a real record. Native HTTP replay remains CI-only. |
| 16486–16501 | Sparse checkout removes the archived seed reader test operand | Keep exact original bytes as a consumed test fixture. The conversation conservation operand uses the same fixture transport. A real Git sparse-checkout test uses the actual workflow patterns and excludes unrelated history. |
| 16505–16529 | Documentation lookup omits the moved Rust selection owner | Add the maintained owner to the existing source list; the procedure-documentation suite passes. |
| 27009 onward | Packaging assertion reads the former inline source owner | Read the captured manifest helper and retain the actual workflow invocation assertion; packaging and CLI release suites pass. |

All 309 maintained issue cases, the four focused source/transport suites, five
affected JavaScript gates and whitespace checks pass locally. Initial mistaken
test assertions and unsuccessful source lookups remain archived alongside the
corrected checks. No local Rust build or native execution is claimed. Supplied
edits, procedures and conclusions earn zero independent-authorship credit.

The separate failure at lines 26989–27005 remains unresolved: the committed WASM
input receipt predates the worker source extraction and requires an actual build.
Its guard is unchanged. Hosted final-head CI, complete template/practice review
and the wider issue remain unfinished. Evidence is retained under
`experiments/issue-1580/evidence/checks/seed-head-ci-repairs/`.
Pull request: https://github.com/link-assistant/formal-ai/pull/1581.
''')
fragment=root/'changelog.d/20261121_1580_ci_source_transport.md';fragment.write_text('''Fix release receipt recognition after shell extraction and keep sparse-checkout
regression fixtures, moved Rust documentation owners and seed VM prerequisites
aligned with their maintained consumers (issue #1580).
''')
plan=root/'experiments/issue-1580/work-plan.md';text=plan.read_text();start=text.index('Published `ba01ef99`');end=text.index('\nThe entries below',start)
text=text[:start]+'''Published `9e945eae` includes main `f574289f`. Layered CI records seven
failures; six source/transport checks are repaired locally with regression
coverage. All 309 maintained issue cases and five affected JavaScript gates
pass. The stale WASM worker input receipt still requires actual hosted
regeneration; an inactive, admission-tested proposal awaits the explicit build
policy exception. The published Pipeline run is still being collected.

Complete function, implementation, shell and metadata extractions reduce source
warnings to 10 under unchanged limits. No native compilation or execution of
these later local changes is claimed. Complete template/practice comparison,
remaining warnings, wider verification and final current-head CI remain open.
Independent reasoning remains 0/20. PR #1581 remains draft and unmerged.
'''+text[end:];plan.write_text(text)
paths=['.github/workflows/desktop-release.yml','scripts/desktop-release-manifest.sh','experiments/issue-1580/desktop-manifest-headroom.test.mjs','experiments/issue-1580/application-conversation-list.test.mjs','experiments/issue-1580/seed-record-readers.test.mjs','experiments/issue-1580/ci-source-transport.test.mjs','experiments/issue-1580/fixtures/conversation-list-hook','experiments/issue-1580/fixtures/seed-record-readers','rust/tests/web/helpers/issue-1550-procedure-documentation.mjs','rust/tests/web/issue-1580-template-observations.test.mjs','rust/tests/web/issue-1586-structured-output.test.mjs','rust/tests/web/packaging-console-retention.test.mjs',str(base.relative_to(root)),str(doc.relative_to(root)),str(fragment.relative_to(root)),str(plan.relative_to(root))]
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
subprocess.run(['git','commit','-m','Repair sparse source fixtures and preserve release receipt recognition'],cwd=root,check=True)
print(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'archives':len(records),'fullIssueComplete':False}))
