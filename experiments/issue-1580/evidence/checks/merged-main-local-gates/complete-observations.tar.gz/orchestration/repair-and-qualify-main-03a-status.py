from pathlib import Path
import datetime,hashlib,json,subprocess
r=Path("/tmp/issue-1580-research")
root=r/"main-03a-status-refresh"
assert not root.exists()
head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
assert head=="e3046ab36b85284eab52e9ed59fd1b9afa2b679c"
assert not subprocess.check_output(["git","status","--porcelain"],text=True).strip()
full=json.loads((r/"main-03a-source-warning-clean-full-gates/outcome.json").read_text())
assert full["complete"] and full["source"]==head and full["cleanBefore"] and full["cleanAfter"] and full["sameSourceAfter"]
assert full["counts"]=={"PASS":88,"FAIL":1,"SKIP":54}
assert [x["name"] for x in full["records"] if x["status"]=="FAIL"]==["check-status-render"]
focused=json.loads((r/"main-03a-source-warning-focused/outcome.json").read_text())
assert all(x["exitCode"]==0 for x in focused)
root.mkdir()
path=Path("docs/status.md")
before=path.read_bytes()
(root/"status.before.md").write_bytes(before)
checks=[]
def run(name,args):
 with (root/(name+".stdout")).open("wb") as out,(root/(name+".stderr")).open("wb") as err:
  p=subprocess.run(args,stdout=out,stderr=err)
 row={"name":name,"command":args,"exitCode":p.returncode}
 checks.append(row);print(json.dumps(row),flush=True);return p.returncode
assert run("before",["node","--max-old-space-size=256","scripts/render-status.mjs","--check"])==1
assert "docs/status.md" in (root/"before.stderr").read_text() or "docs/status.md" in (root/"before.stdout").read_text()
assert run("write",["node","--max-old-space-size=256","scripts/render-status.mjs","--write"])==0
assert path.read_bytes()!=before
(root/"status.after.md").write_bytes(path.read_bytes())
with (root/"status.diff").open("wb") as out:
 subprocess.run(["git","diff","--","docs/status.md"],stdout=out,check=True)
assert subprocess.check_output(["git","diff","--name-only"],text=True).splitlines()==["docs/status.md"]
assert run("after",["node","--max-old-space-size=256","scripts/render-status.mjs","--check"])==0
for gate in ["check-status-render","check-render-status-js-twin"]:
 assert run(gate,["node","--max-old-space-size=256","experiments/formal_ai_subagent/local-gates.mjs","--only",gate])==0
outcome={"sourceBefore":head,"completedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"checks":checks,"regressionFailsBefore":True,"regressionPassesAfter":True,"changedProductionFiles":["docs/status.md"],"generatorChanged":False,"beforeSha256":hashlib.sha256(before).hexdigest(),"afterSha256":hashlib.sha256(path.read_bytes()).hexdigest(),"nativeExecuted":False,"independentAuthorshipCredit":0,"fullIssueComplete":False}
(root/"outcome.json").write_text(json.dumps(outcome,indent=2)+"\n")
print(json.dumps(outcome,indent=2),flush=True)
