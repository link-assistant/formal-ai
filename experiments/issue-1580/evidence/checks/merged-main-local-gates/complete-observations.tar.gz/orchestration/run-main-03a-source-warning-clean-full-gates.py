import subprocess,json
from pathlib import Path
focused=Path('/tmp/issue-1580-research/main-03a-source-warning-focused')
focused.mkdir(exist_ok=False)
tests=['rust/tests/web/default-branch-build-policy.test.mjs','rust/tests/web/fast-pull-request-production-profile.test.mjs','rust/tests/web/issue-1580-source-warning-headroom.test.mjs','experiments/issue-1580/source-warning-headroom.test.mjs']
checks=[]
for i,path in enumerate(tests):
    command=['timeout','600','node','--test','--test-concurrency=1',path]
    with (focused/f'{i}.stdout').open('w') as out,(focused/f'{i}.stderr').open('w') as err:
        r=subprocess.run(command,stdout=out,stderr=err)
    checks.append({'file':path,'exitCode':r.returncode})
    print(json.dumps(checks[-1]),flush=True)
rust=['scripts/check-dependencies-latest.rs','scripts/check-dependencies-snapshot.rs','rust/src/coding/list_program.rs','rust/src/coding/list_program/literals.rs','rust/tests/unit/reasoning_contracts.rs','rust/tests/unit/specification/chat_surface.rs','rust/tests/unit/specification/chat_surface/rule_details.rs','rust/tests/unit/specification/debug_session.rs','rust/tests/unit/specification/debug_session/calculator_origins.rs','scripts/detect-code-changes.rs','scripts/detect-code-changes-tests.rs']
with (focused/'rustfmt.stdout').open('w') as out,(focused/'rustfmt.stderr').open('w') as err:
    r=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--check']+rust,stdout=out,stderr=err)
checks.append({'check':'rustfmt','exitCode':r.returncode,'files':rust})
(focused/'outcome.json').write_text(json.dumps(checks,indent=2)+'\n')
import datetime, hashlib, json, shutil, subprocess
from pathlib import Path
root=Path('/tmp/issue-1580-research/main-03a-source-warning-clean-full-gates')
root.mkdir(exist_ok=False)
git=lambda *args:subprocess.check_output(['git',*args],text=True).strip()
head=git('rev-parse','HEAD')
before=git('status','--porcelain')
assert not before,before
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
command=['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs']
with (root/'runner.log').open('wb') as output:
    result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
after=git('status','--porcelain')
records=[]
for line in (root/'runner.log').read_text().splitlines():
    if not line.startswith(('PASS ','FAIL ','SKIP ')):continue
    kind,name,*tail=line.split(' ')
    record={'status':kind,'name':name,'observation':line}
    if kind!='SKIP':
        source=Path('experiments/formal_ai_subagent/sandboxes/gates')/(name+'.log')
        assert source.is_file(),str(source)
        target=root/(name+'.log')
        shutil.copyfile(source,target)
        record['sha256']=hashlib.sha256(target.read_bytes()).hexdigest()
    records.append(record)
outcome={'source':head,'command':command,'exitCode':result.returncode,'complete':True,'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cleanBefore':not before,'cleanAfter':not after,'afterStatus':after,'sameSourceAfter':git('rev-parse','HEAD')==head,'counts':{status:sum(row['status']==status for row in records) for status in ['PASS','FAIL','SKIP']},'records':records,'nativeExecuted':False,'independentAuthorshipCredit':0}
(root/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps({k:v for k,v in outcome.items() if k!='records'}),flush=True)
