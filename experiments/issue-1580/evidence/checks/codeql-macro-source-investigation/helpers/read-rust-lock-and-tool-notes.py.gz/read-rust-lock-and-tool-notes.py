from pathlib import Path
import hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048');source=Path('/tmp/issue-1580-research/templates/rust-complete')
base=Path('/tmp/issue-1580-research/rust-lock-and-tool-notes');base.mkdir(exist_ok=False)
prefix='dev/log/issues/247/pulls/248/'
paths=[prefix+name for name in ['Cargo.lock.before.txt','lychee-upstream.json.txt','npm-check-updates-release.json']]
known={r['path'] for r in json.loads((root/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json').read_text())['files']}
identities={r['path']:r for r in json.loads((root/'experiments/issue-1580/evidence/checks/rust-template-first-gate/pinned-file-identities.json').read_text())}
output=[];rows=[]
for path in paths:
 assert path not in known
 raw=(source/path).read_bytes();digest=hashlib.sha256(raw).hexdigest();assert digest==identities[path]['sha256']
 lines=raw.decode().splitlines();output.append(f'FILE {path} LINES {len(lines)} SHA256 {digest}')
 output.extend(f'{i}: {line}' for i,line in enumerate(lines,1))
 rows.append({'path':path,'lines':len(lines),'sha256':digest,'decodedSha256':digest,'encoding':'utf-8'})
(base/'read.txt').write_text('\n'.join(output)+'\n');(base/'sources.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'files':len(rows),'lines':sum(r['lines'] for r in rows),'readLogLines':len(output),'bytes':(base/'read.txt').stat().st_size}))
