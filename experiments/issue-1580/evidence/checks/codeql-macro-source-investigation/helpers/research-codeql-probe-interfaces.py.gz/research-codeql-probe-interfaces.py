from pathlib import Path
import base64,json,subprocess
base=Path('/tmp/issue-1580-research/codeql-probe-interfaces');base.mkdir(exist_ok=False)
sources=[('init-action','github/codeql-action','init/action.yml','v4'),
 ('analyze-action','github/codeql-action','analyze/action.yml','v4'),
 ('ast-node','github/codeql','rust/ql/lib/codeql/rust/elements/AstNode.qll','codeql-cli/v2.27.5'),
 ('ast-node-implementation','github/codeql','rust/ql/lib/codeql/rust/elements/internal/AstNodeImpl.qll','codeql-cli/v2.27.5'),
 ('query-pack','github/codeql','rust/ql/src/qlpack.yml','codeql-cli/v2.27.5'),
 ('macro-tests','github/codeql','rust/ql/test/library-tests/macros','codeql-cli/v2.27.5')]
for name,repo,path,ref in sources:
 args=['gh','api','repos/'+repo+'/contents/'+path+'?ref='+ref,'--paginate']
 result=subprocess.run(args,capture_output=True)
 (base/(name+'.stdout')).write_bytes(result.stdout);(base/(name+'.stderr')).write_bytes(result.stderr)
 print(name,result.returncode)
 if result.returncode:continue
 data=json.loads(result.stdout)
 if isinstance(data,list):print(json.dumps([{'name':r['name'],'path':r['path']} for r in data]));continue
 raw=base64.b64decode(data['content']);(base/(name+'.decoded')).write_bytes(raw)
 print(raw.decode())
