from pathlib import Path
import gzip,hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048')
source=Path('/tmp/issue-1580-research/templates/rust-complete')
base=Path('/tmp/issue-1580-research/rust-macro-and-small-logs');base.mkdir(exist_ok=False)
prefix='dev/log/issues/247/pulls/248/'
paths=[prefix+'codeql-macros-upstream.json.txt',prefix+'rust-image.txt']
paths += [prefix+'evidence/'+name+'.log.gz' for name in ['actionlint-queue-before','audit-minimal-repro','baseline-action-test','batch-2-report-links','candidate-lints-audits','cargo-audit-before','npm-full-validation','policy-regression-before','python-full-validation','release-sync-tests','standalone-after','standalone-before','workflow-lints']]
known={r['path'] for r in json.loads((root/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json').read_text())['files']}
identities={r['path']:r for r in json.loads((root/'experiments/issue-1580/evidence/checks/rust-template-first-gate/pinned-file-identities.json').read_text())}
output=[];rows=[]
for path in paths:
 assert path not in known
 raw=(source/path).read_bytes();digest=hashlib.sha256(raw).hexdigest();assert digest==identities[path]['sha256']
 decoded=gzip.decompress(raw) if path.endswith('.gz') else raw
 lines=decoded.decode().splitlines()
 output.append(f'FILE {path} LINES {len(lines)} SHA256 {digest}')
 output.extend(f'{i}: {line}' for i,line in enumerate(lines,1))
 rows.append({'path':path,'lines':len(lines),'sha256':digest,'decodedSha256':hashlib.sha256(decoded).hexdigest(),'encoding':'gzip' if path.endswith('.gz') else 'utf-8'})
(base/'read.txt').write_text('\n'.join(output)+'\n')
(base/'sources.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'files':len(rows),'decodedLines':sum(r['lines'] for r in rows),'readLogLines':len(output),'bytes':(base/'read.txt').stat().st_size}))
