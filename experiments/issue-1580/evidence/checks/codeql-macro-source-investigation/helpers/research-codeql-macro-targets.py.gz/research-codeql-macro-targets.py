from pathlib import Path
import json,subprocess
base=Path('/tmp/issue-1580-research/codeql-macro-targets');base.mkdir(exist_ok=False)
endpoints=[('target-issue','repos/github/codeql/issues/20643'),('target-comments','repos/github/codeql/issues/20643/comments'),
 ('expansion-issue','repos/github/codeql/issues/20659'),('expansion-comments','repos/github/codeql/issues/20659/comments'),
 ('repository-root','repos/github/codeql/contents'),('rust-root','repos/github/codeql/contents/rust')]
for name,endpoint in endpoints:
 result=subprocess.run(['gh','api',endpoint,'--paginate'],capture_output=True)
 (base/(name+'.stdout')).write_bytes(result.stdout);(base/(name+'.stderr')).write_bytes(result.stderr)
 print(name,result.returncode)
 if result.returncode:continue
 data=json.loads(result.stdout)
 if name.endswith('root'):
  print([(row['name'],row['type']) for row in data])
 else:
  for row in data if isinstance(data,list) else [data]:
   print(json.dumps({'url':row.get('html_url'),'user':row.get('user',{}).get('login'),
    'state':row.get('state'),'updated':row.get('updated_at'),'body':row.get('body')},ensure_ascii=False))
