from pathlib import Path
import base64,json,subprocess
base=Path('/tmp/issue-1580-research/codeql-macro-query');base.mkdir(exist_ok=False)
for label,path in [('unresolved-query','rust/ql/src/queries/diagnostics/UnresolvedMacroCalls.ql'),
 ('quality-query','rust/ql/src/queries/diagnostics/DatabaseQuality.ql'),
 ('macro-schema','rust/ql/lib/codeql/rust/elements/internal/generated/MacroCall.qll'),
 ('diagnostic-layout','rust/ql/src/queries/diagnostics')]:
 result=subprocess.run(['gh','api','repos/github/codeql/contents/'+path+'?ref=codeql-cli/v2.27.5','--paginate'],capture_output=True)
 (base/(label+'.stdout')).write_bytes(result.stdout);(base/(label+'.stderr')).write_bytes(result.stderr)
 print(label,result.returncode)
 if result.returncode:continue
 data=json.loads(result.stdout)
 if isinstance(data,list):print([(row['name'],row['type']) for row in data])
 else:
  raw=base64.b64decode(data['content']);(base/(label+'.decoded')).write_bytes(raw);print(raw.decode())
