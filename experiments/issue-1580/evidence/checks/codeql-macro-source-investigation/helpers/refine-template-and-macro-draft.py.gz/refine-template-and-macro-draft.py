from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
tests=root/'rust/tests/web/dependencies-maintenance-workflow.test.mjs'
source=tests.read_text().replace(r'\"\$locks\"',r'"\$locks"')
tests.write_text(source)
plan=root/'experiments/issue-1580/work-plan.md'
source=plan.read_text();source=source.replace(r'\n- Pinned-template runtime comparison', '\n- Pinned-template runtime comparison').replace('verification is pending.\\n','verification is pending.\n');plan.write_text(source)
script=root/'scripts/recheck-broken-links.mjs';source=script.read_text()
source=source.replace('''      if (now() - started >= budgetMs) {''','''      const requestBudget = budgetMs - (now() - started);
      if (requestBudget <= 0) {''').replace('timeoutMs: Math.min(timeoutMs, budgetMs - (now() - started)),','timeoutMs: Math.min(timeoutMs, requestBudget),')
script.write_text(source)
tests=root/'scripts/recheck-broken-links.test.mjs';source=tests.read_text()
old='''test('a request uses only the remaining shared budget', {timeout: 1000}, async () => {
  const started = Date.now();
  const result = await recheckAll(['https://silent.example/'], {
    budgetMs: 15,
    timeoutMs: 500,
    attempts: 1,
    fetchImpl: (_url, {signal}) => new Promise((_resolve, reject) => {
      signal.addEventListener('abort', () => reject(new Error('deadline')));
    }),
  });
  assert.ok(Date.now() - started < 250, 'per-request timeout exceeded the shared budget');
  assert.equal(result.get('https://silent.example/').outcome, 'unreachable');
});'''
new='''test('a request uses only the remaining shared budget', {timeout: 1000}, async t => {
  t.mock.timers.enable({apis: ['setTimeout']});
  let requestSignal;
  const pending = recheckAll(['https://silent.example/'], {
    budgetMs: 15,
    timeoutMs: 500,
    attempts: 1,
    now: () => 0,
    fetchImpl: (_url, {signal}) => new Promise((_resolve, reject) => {
      requestSignal = signal;
      signal.addEventListener('abort', () => reject(new Error('deadline')));
    }),
  });
  t.mock.timers.tick(15);
  assert.equal(requestSignal.aborted, true, 'per-request timeout exceeded the shared budget');
  const result = await pending;
  assert.equal(result.get('https://silent.example/').outcome, 'unreachable');
});'''
assert old in source;tests.write_text(source.replace(old,new))
adapter=root/'experiments/issue-1580/codeql-macro-contexts/observe.py';source=adapter.read_text()
old='''        for name in ["codeql-pack.lock.yml", "qlpack.lock.yml"]:
            if (pack / name).is_file():
                manifest[name] = identity(pack / name)
        (output / "MacroContexts.ql").write_bytes(query.read_bytes())'''
new='''        (output / "codeql-database.yml").write_bytes((database / "codeql-database.yml").read_bytes())
        (output / "qlpack.yml").write_bytes(packs[0].read_bytes())
        for name in ["codeql-pack.lock.yml", "qlpack.lock.yml"]:
            if (pack / name).is_file():
                manifest[name] = identity(pack / name)
                (output / name).write_bytes((pack / name).read_bytes())
        (output / "MacroContexts.ql").write_bytes(query.read_bytes())'''
assert old in source;adapter.write_text(source.replace(old,new))
print('Refined shared-deadline fixture, shell matcher, and retained original CodeQL database/pack metadata.')
