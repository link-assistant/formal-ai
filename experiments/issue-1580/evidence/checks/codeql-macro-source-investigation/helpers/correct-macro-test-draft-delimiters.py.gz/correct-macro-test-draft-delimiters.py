from pathlib import Path
import subprocess
source=Path('/tmp/issue-1580-research/test-codeql-macro-observation.py').read_text()
assert source.count("source=r'''\n")==1
source=source.replace("source=r'''\n",'source=r"""\n',1)
assert source.count("\n'''\nassert \"test(")==1
source=source.replace("\n'''\nassert \"test(",'\n"""\nassert "test(',1)
target=Path('/tmp/issue-1580-research/test-codeql-macro-observation-corrected.py')
target.write_text(source)
subprocess.run(['python3',str(target)],check=True)
