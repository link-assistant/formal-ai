from pathlib import Path
import collections, gzip, hashlib, json, re, subprocess, posixpath
root=Path('/tmp/gh-issue-solver-1794900398048')
base=Path('/tmp/issue-1580-research/macro-context-classification-normalized');base.mkdir(exist_ok=False)
sarif_path=root/'experiments/issue-1580/evidence/ci/codeql-producer-76371322/producer-14638610905-rust.sarif.gz'
raw=gzip.decompress(sarif_path.read_bytes());sarif=json.loads(raw)
rows=[]
for run in sarif['runs']:
 for invocation in run.get('invocations',[]):
  for note in invocation.get('toolExecutionNotifications',[]):
   if note.get('descriptor',{}).get('id')=='rust/diagnostics/unresolved-macro-calls':
    rows.append(note)
if not rows:
 for run in sarif['runs']:
  for invocation in run.get('invocations',[]):
   for note in invocation.get('toolExecutionNotifications',[]):
    if 'Macro call was not resolved' in note.get('message',{}).get('text',''):rows.append(note)
assert len(rows)==631,len(rows)
(base/'notifications.json').write_text(json.dumps(rows,indent=2)+'\n')
print('First complete diagnostic:',json.dumps(rows[0],indent=2))
command=['rg','--json',r'include!\s*\(','rust','scripts','js/wasm-worker','-g','*.rs']
result=subprocess.run(command,cwd=root,capture_output=True)
assert result.returncode in (0,1)
(base/'include-search.stdout').write_bytes(result.stdout);(base/'include-search.stderr').write_bytes(result.stderr)
edges=[]
for line in result.stdout.splitlines():
 data=json.loads(line)
 if data['type']!='match':continue
 d=data['data'];path=d['path']['text'];text=d['lines']['text']
 for match in re.finditer(r'include!\s*\(\s*"([^"]+)"\s*\)',text):
  target=posixpath.normpath((Path(path).parent/match[1]).as_posix())
  edges.append({'parent':path,'line':d['line_number'],'target':target,'source':text.strip()})
grouped=collections.defaultdict(list)
for row in rows:
 for location in row.get('locations',[]):
  physical=location['physicalLocation'];artifact=physical['artifactLocation'];path=artifact.get('uri')
  if not path and 'index' in artifact:
   path=sarif['runs'][0]['artifacts'][artifact['index']]['location']['uri']
  path=path.removeprefix('file://').removeprefix('/home/runner/work/formal-ai/formal-ai/')
  grouped[path].append(physical.get('region',{}))
files=[]
for path,regions in sorted(grouped.items(),key=lambda pair:(-len(pair[1]),pair[0])):
 source=root/path
 text=source.read_text() if source.exists() else ''
 parents=[edge for edge in edges if edge['target']==path]
 lines=text.splitlines()
 first=regions[0].get('startLine',1)
 context=[{'line':i+1,'text':lines[i]} for i in range(max(0,first-3),min(len(lines),first+2))]
 files.append({'path':path,'count':len(regions),'regions':regions,'directIncludeParents':parents,
               'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest() if source.exists() else None,
               'firstLocationContext':context})
summary={'reportSha256':hashlib.sha256(raw).hexdigest(),'notifications':len(rows),'files':len(files),
         'directIncludedFileNotifications':sum(f['count'] for f in files if f['directIncludeParents']),
         'directIncludeEdges':edges,'sourceFiles':files,'semanticCoverageProven':False,'independentAuthorshipCredit':0}
(base/'classification.json').write_text(json.dumps(summary,indent=2)+'\n')
for row in files:
 print(json.dumps({key:row[key] for key in ['path','count','directIncludeParents','firstLocationContext']},ensure_ascii=False))
print('COUNTS',json.dumps({key:summary[key] for key in ['notifications','files','directIncludedFileNotifications','semanticCoverageProven']}))
