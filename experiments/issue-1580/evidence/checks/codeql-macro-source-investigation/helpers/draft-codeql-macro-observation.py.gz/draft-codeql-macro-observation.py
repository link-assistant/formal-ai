from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
directory=root/'experiments/issue-1580/codeql-macro-contexts';directory.mkdir(exist_ok=False)
(directory/'MacroContexts.ql').write_text('''/** Observe source macro AST nodes without changing the security query suite. */
import rust

private string expansionState(MacroCall call) {
  call.hasMacroCallExpansion() and result = "expanded"
  or
  not call.hasMacroCallExpansion() and result = "unexpanded"
}

private string enclosingState(MacroCall call) {
  call.isInMacroExpansion() and result = "inside-expansion"
  or
  not call.isInMacroExpansion() and result = "outside-expansion"
}

from MacroCall call
where call.fromSource()
select call, call.getFile().getRelativePath(), call.getLocation().getStartLine(),
  call.getLocation().getStartColumn(), call.getLocation().getEndLine(),
  call.getLocation().getEndColumn(), expansionState(call), enclosingState(call)
''')
(directory/'observe.py').write_text('''#!/usr/bin/env python3
"""Observe the existing hosted Rust database; never substitute for security checks."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def observe(codeql, databases, output):
    output.mkdir(parents=True, exist_ok=False)
    manifest = {"complete": False, "commands": [], "semanticCoverageProven": False,
                "independentAuthorshipCredit": 0}

    def run(name, arguments):
        with (output / (name + ".stdout")).open("wb") as stdout, (output / (name + ".stderr")).open("wb") as stderr:
            result = subprocess.run([str(codeql), *arguments], stdout=stdout, stderr=stderr)
        manifest["commands"].append({"name": name, "argv": [str(codeql), *arguments],
                                     "exitCode": result.returncode,
                                     "stdout": identity(output / (name + ".stdout")),
                                     "stderr": identity(output / (name + ".stderr"))})
        if result.returncode:
            raise RuntimeError(f"CodeQL {name} failed with exit {result.returncode}; see preserved streams")

    try:
        database = Path(databases["rust"])
        if not database.is_absolute() or not (database / "codeql-database.yml").is_file():
            raise ValueError("Expected the completed Rust database reported by the analyze action")
        codeql = codeql.resolve(strict=True)
        packs = sorted((codeql.parent / "qlpacks/codeql/rust-queries").glob("*/qlpack.yml"))
        if len(packs) != 1:
            raise ValueError(f"Expected one bundled Rust query pack, found {len(packs)}")
        pack = packs[0].parent
        if not re.search(r"^name: *codeql/rust-queries *$", packs[0].read_text(), re.M):
            raise ValueError("Unexpected bundled query pack identity")
        query = Path(__file__).with_name("MacroContexts.ql")
        manifest.update({"database": str(database), "databaseMetadata": identity(database / "codeql-database.yml"),
                         "codeql": identity(codeql), "query": identity(query), "queryPack": identity(packs[0])})
        for name in ["codeql-pack.lock.yml", "qlpack.lock.yml"]:
            if (pack / name).is_file():
                manifest[name] = identity(pack / name)
        (output / "MacroContexts.ql").write_bytes(query.read_bytes())
        run("version", ["version", "--format=json"])
        # Inherit the producer's exact bundled dependencies without downloading
        # a different library. The temporary query is removed even on failure.
        with tempfile.TemporaryDirectory(prefix="formal-ai-macro-contexts-", dir=pack) as temporary:
            installed = Path(temporary) / query.name
            installed.write_bytes(query.read_bytes())
            run("query", ["query", "run", "--database=" + str(database),
                          "--output=" + str(output / "macro-contexts.bqrs"),
                          "--threads=2", "--ram=2048", "--max-disk-cache=512",
                          "--warnings=error", str(installed)])
        run("decode", ["bqrs", "decode", "--format=json", "--entities=all",
                       "--output=" + str(output / "macro-contexts.json"), str(output / "macro-contexts.bqrs")])
        decoded = json.loads((output / "macro-contexts.json").read_text())
        table = decoded["#select"]
        if len(table["columns"]) != 8 or not table["tuples"] or any(len(row) != 8 for row in table["tuples"]):
            raise ValueError("Missing or malformed macro observation table")
        manifest.update({"complete": True, "rows": len(table["tuples"]),
                         "result": identity(output / "macro-contexts.json"),
                         "bqrs": identity(output / "macro-contexts.bqrs")})
    finally:
        (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\\n")
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--codeql", type=Path, required=True)
    parser.add_argument("--databases", type=json.loads, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(observe(args.codeql, args.databases, args.output.resolve())))
''')
path=root/'.github/workflows/security.yml';text=path.read_text()
old="      pull-request:\n        description: 'Pull request the dispatched checks report for'"
new="      macro-contexts:\n        description: 'Observe Rust macro AST contexts in the read-only CodeQL run'\n        required: false\n        default: false\n        type: boolean\n"+old
assert text.count(old)==1;text=text.replace(old,new)
text=text.replace('      - uses: github/codeql-action/init@v4\n','      - uses: github/codeql-action/init@v4\n        id: codeql-init\n')
text=text.replace('      - uses: github/codeql-action/analyze@v4\n','      - uses: github/codeql-action/analyze@v4\n        id: codeql-analyze\n')
anchor='      - name: Reject unresolved CodeQL findings\n'
step='''      - name: Observe Rust macro expansion contexts
        if: ${{ github.job == 'codeql-readonly' && matrix.language == 'rust' && inputs.macro-contexts }}
        timeout-minutes: 4
        env:
          CODEQL_BINARY: ${{ steps.codeql-init.outputs.codeql-path }}
          CODEQL_DATABASES: ${{ steps.codeql-analyze.outputs.db-locations }}
        run: >-
          python3 experiments/issue-1580/codeql-macro-contexts/observe.py
          --codeql "$CODEQL_BINARY" --databases "$CODEQL_DATABASES"
          --output "${{ runner.temp }}/codeql-results/macro-contexts"

'''
assert text.count(anchor)==1;text=text.replace(anchor,step+anchor);path.write_text(text)
with (root/'experiments/issue-1580/work-plan.md').open('a') as stream:
 stream.write('\n- Original 3bb3083b Security producer reports are preserved: zero findings and zero warning/error notifications; 631 informational unresolved macro records remain. Correct include-path normalization maps 342 records to included files, including all 282 production records. Add an explicit default-off, read-only hosted query observing original/expanded source AST nodes in the existing producer database, retaining the exact query/pack/version, BQRS and raw decoded table; local mocks verify transport only. Query compilation, hosted execution and macro semantic acceptance remain unverified.\n')
print('Drafted default-off hosted macro observation; actual query remains unverified')
