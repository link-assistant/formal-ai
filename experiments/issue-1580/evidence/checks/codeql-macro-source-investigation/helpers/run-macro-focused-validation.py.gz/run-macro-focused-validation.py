from pathlib import Path
import os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
path=Path('/tmp/issue-1580-research/codeql-macro-observation-tests.log')
assert not path.exists()
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
with path.open('wb') as stream:
 result=subprocess.run(['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/security-codeql-results.test.mjs'],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
print('Focused security and macro observation controls:',result.returncode,'log',str(path))
print('\n'.join(path.read_text().splitlines()[-22:]))
raise SystemExit(result.returncode)
