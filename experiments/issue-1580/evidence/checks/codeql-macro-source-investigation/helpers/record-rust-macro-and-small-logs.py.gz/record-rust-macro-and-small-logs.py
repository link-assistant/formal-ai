from pathlib import Path
import datetime,gzip,hashlib,json,re
root=Path('/tmp/gh-issue-solver-1794900398048')
base=Path('/tmp/issue-1580-research/rust-macro-and-small-logs')
log=base/'read.txt';sources=json.loads((base/'sources.json').read_text())
rows={};current=None
for line in log.read_text().splitlines():
 match=re.fullmatch(r'FILE (\S+) LINES (\d+) SHA256 ([0-9a-f]{64})',line)
 if match:
  current=match[1];rows[current]={'lines':int(match[2]),'sha256':match[3],'numbered':{}}
 else:
  match=re.fullmatch(r'(\d+): (.*)',line)
  if match and current:rows[current]['numbered'][int(match[1])]=match[2]
assert len(rows)==len(sources)==15
target=root/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data=json.loads(target.read_text());assert (data['fullyReadFiles'],data['fullyReadSourceLines'])==(289,34914)
known={row['path'] for row in data['files']};archive_name='rust-macro-and-small-logs.read.txt.gz'
for source in sources:
 path=source['path'];row=rows[path];raw=(Path('/tmp/issue-1580-research/templates/rust-complete')/path).read_bytes()
 decoded=gzip.decompress(raw) if source['encoding']=='gzip' else raw
 lines=decoded.decode().splitlines()
 assert path not in known and hashlib.sha256(raw).hexdigest()==row['sha256']==source['sha256']
 assert hashlib.sha256(decoded).hexdigest()==source['decodedSha256']
 assert sorted(row['numbered'].items())==list(enumerate(lines,1)) and len(lines)==row['lines']==source['lines']
 data['files'].append({'path':path,'lines':len(lines),'sha256':row['sha256'],'decodedSha256':source['decodedSha256'],
  'sourceEncoding':source['encoding'],'readLogs':[archive_name],'literalReadRanges':[[1,len(lines)]] if lines else [],
  'literalReadLines':len(lines),'literalSourceFullyRead':True,'formalAiPracticeImplementationVerified':False})
archive=root/'experiments/issue-1580/evidence/checks/rust-source-review'/archive_name
assert not archive.exists();raw=log.read_bytes();packed=gzip.compress(raw,mtime=0);archive.write_bytes(packed)
manifest=root/data['readLogManifest'];records=json.loads(manifest.read_text())
records.append({'file':archive.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
manifest.write_text(json.dumps(records,indent=2)+'\n')
data['files'].sort(key=lambda row:row['path']);data['fullyReadFiles']=len(data['files']);data['fullyReadSourceLines']=sum(row['literalReadLines'] for row in data['files'])
data['observedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
data['practiceDecisions'].append({'practice':'Historical extraction ABI, immutable image indexes, complete dependency inventories and literal regression evidence',
 'templateEvidence':list(rows),'assessment':'Read all 15 complete pinned files, including decoded content of 13 gzip logs; verify compressed and decoded source identities separately. Historical CodeQL reports distinguish missing sysroot, macro ABI and unbuilt proc-macro coverage failures, supporting current matched-sysroot/context work without proving the current 631 informational macro expansions. The Rust image index distinguishes six executable Linux architectures from attestation manifests; this historical tag/index does not establish current registry contents. Retain the stale trusted-publishing assertion failure, missing standalone regex dependencies, malformed-lock cargo-audit panic, dependency-policy before/after failures, scoped clean audit output and successful 16-case release-sync run as historical observations. The Python audit contains repeated cache deserialization warnings despite no known vulnerabilities; the empty workflow-lints log alone proves neither execution nor success. Current policy/format/action compatibility and full lock/CI/deployment behavior need their own current evidence; no current shared defect is established by these historical outputs.',
 'status':'literal-history-reviewed-current-runtime-open','formalAiPaths':['.github/workflows/security.yml','scripts/codeql-rust-projects.py','.github/actions/setup-buildx-resilient/action.yml','scripts/check-rust-dependencies.sh'],
 'verification':None})
assert (data['fullyReadFiles'],data['fullyReadSourceLines'])==(304,35750)
target.write_text(json.dumps(data,indent=2)+'\n')
with (root/'experiments/issue-1580/work-plan.md').open('a') as stream:
 stream.write('\n- Fifteen additional complete pinned Rust historical texts/logs are literally read and identity-verified, including decoded gzip content: 304/373 files and 35,750 lines, with 69 files remaining. Preserve extraction ABI, malformed-lock panic, stale trusted-publishing assertion, dependency-policy failures and Python cache warnings as scoped historical evidence; neither clean summaries nor an empty log establish current runtime acceptance. Every unverified practice remains open.\n')
print(json.dumps({'fullyReadFiles':data['fullyReadFiles'],'fullyReadSourceLines':data['fullyReadSourceLines'],'remaining':data['treeBlobs']-data['fullyReadFiles']}))
