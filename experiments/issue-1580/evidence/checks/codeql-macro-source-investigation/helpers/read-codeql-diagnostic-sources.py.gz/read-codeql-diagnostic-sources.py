from pathlib import Path
import base64,json,subprocess
base=Path('/tmp/issue-1580-research/codeql-diagnostic-sources');base.mkdir(exist_ok=False)
for name,argv in [
 ('source-layout',['gh','api','repos/github/codeql/contents/rust/ql/src?ref=codeql-cli/v2.27.5','--paginate']),
 ('latest-source-layout',['gh','api','repos/github/codeql/contents/rust/ql/src?ref=codeql-cli/latest','--paginate']),
 ('macro-query-search',['gh','search','code','unresolved-macro','--repo','github/codeql','--limit','30','--json','path,repository,url']),
 ('macro-implementation',['gh','api','repos/github/codeql/contents/rust/ql/lib/codeql/rust/elements/internal/MacroCallImpl.qll?ref=codeql-cli/v2.27.5'])]:
 result=subprocess.run(argv,capture_output=True)
 (base/(name+'.stdout')).write_bytes(result.stdout);(base/(name+'.stderr')).write_bytes(result.stderr)
 print(name,result.returncode)
 if result.returncode:continue
 data=json.loads(result.stdout)
 if name.endswith('layout'):print([(row['name'],row['type']) for row in data])
 elif name.endswith('implementation'):
  raw=base64.b64decode(data['content']);(base/(name+'.decoded')).write_bytes(raw);print(raw.decode())
 else:print(json.dumps(data))
token=subprocess.check_output(['gh','auth','token'],text=True).strip()
for label,identity in [('macro-quality','5ddbc077-5aed-41ae-a84a-16b1828d6011'),
 ('macro-expansion','936139b2-0daf-4b26-9d22-b0d8ddf96839')]:
 image=base/(label+'.png')
 result=subprocess.run(['curl','-L','-H','Authorization: token '+token,'-o',str(image),
  'https://github.com/user-attachments/assets/'+identity],capture_output=True)
 (base/(label+'-download.stderr')).write_bytes(result.stderr)
 print(label,'download',result.returncode)
 kind=subprocess.check_output(['file',str(image)],text=True);print(kind.strip())
 assert 'PNG image' in kind
