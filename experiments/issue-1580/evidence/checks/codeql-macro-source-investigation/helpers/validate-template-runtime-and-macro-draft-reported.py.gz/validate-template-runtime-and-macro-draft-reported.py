from pathlib import Path
import gzip,hashlib,json,os,subprocess,tempfile
root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/checks/template-runtime-and-macro-observation-verified';base.mkdir(exist_ok=False)
scratch=Path('/tmp/issue-1580-research/template-runtime-counterparts')
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
records=[]
def run(name,args,expected=0):
 result=subprocess.run(args,cwd=root,env=env,capture_output=True)
 row={'name':name,'argv':args,'exitCode':result.returncode,'expectedExitCode':expected}
 for label,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
  filename=name+'.'+label+'.gz';packed=gzip.compress(raw,mtime=0);(base/filename).write_bytes(packed)
  row[label]={'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())}
 records.append(row);(base/'records.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,result.returncode,flush=True)
 assert result.returncode==expected,(name,result.stdout.decode(errors='replace')[-3000:],result.stderr.decode(errors='replace')[-1000:])
 return result
with tempfile.TemporaryDirectory(prefix='issue-1580-before-',dir=root/'experiments') as temporary:
 temporary=Path(temporary)
 oldmodule=temporary/'recheck-before.mjs'
 oldmodule.write_text((scratch/'recheck-broken-links.before.mjs').read_text().replace("'./check-web-archive.mjs'",repr((root/'scripts/check-web-archive.mjs').as_uri())))
 before=temporary/'budget-before.test.mjs'
 before.write_text((root/'scripts/recheck-broken-links.test.mjs').read_text().replace("'./recheck-broken-links.mjs'",repr(oldmodule.as_uri())).replace("'./check-web-archive.mjs'",repr((root/'scripts/check-web-archive.mjs').as_uri())))
 result=run('budget-before',['timeout','600','node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','--test-name-pattern','retry waits stop|a request uses only',str(before)],1)
 assert b'# fail 2' in result.stdout and b'# pass 0' in result.stdout,result.stdout[-1500:]
 before=temporary/'inventory-before.test.mjs'
 source=(root/'rust/tests/web/dependencies-maintenance-workflow.test.mjs').read_text()
 source=source.replace("new URL('../../../.github/workflows/dependencies-latest.yml',import.meta.url)",repr(str(scratch/'dependencies-latest.before.yml')))
 before.write_text(source)
 result=run('inventory-before',['timeout','600','node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','--test-name-pattern','failed lock inventory stops',str(before)],1)
 assert b'# fail 1' in result.stdout and b'# pass 0' in result.stdout,result.stdout[-1500:]
for name,path in [('maintenance','rust/tests/web/dependencies-maintenance-workflow.test.mjs'),
 ('link-recheck','scripts/recheck-broken-links.test.mjs'),
 ('transient-http','scripts/recheck-transient-http.test.mjs'),
 ('security','rust/tests/web/security-codeql-results.test.mjs')]:
 result=run(name,['timeout','600','node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',path])
 print('\n'.join(result.stdout.decode().splitlines()[-9:]),flush=True)
run('gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-ci-speed,check-runner-labels,check-readable-code,check-file-size,check-abbreviations'])
run('whitespace',['git','diff','--check'])
paths=['.github/workflows/security.yml','.github/workflows/dependencies-latest.yml','scripts/recheck-broken-links.mjs',
 'rust/tests/web/dependencies-maintenance-workflow.test.mjs','scripts/recheck-broken-links.test.mjs','rust/tests/web/security-codeql-results.test.mjs',
 'experiments/issue-1580/codeql-macro-contexts/observe.py','experiments/issue-1580/codeql-macro-contexts/MacroContexts.ql']
(base/'source-identities.json').write_text(json.dumps([{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in paths],indent=2)+'\n')
print('Complete: original source fails all three new regressions; focused current tests and five gates pass. No native or QL compilation. Independent authorship credit: 0.')
