from pathlib import Path
source=Path('/tmp/issue-1580-research/validate-template-runtime-and-macro-draft.py').read_text()
source=source.replace('checks/template-runtime-and-macro-observation\'', 'checks/template-runtime-and-macro-observation-verified\'')
source=source.replace("'--test','--test-concurrency=1'", "'--test','--test-reporter=tap','--test-concurrency=1'")
target=Path('/tmp/issue-1580-research/validate-template-runtime-and-macro-draft-reported.py');assert not target.exists();target.write_text(source)
print('Preserved the first run: both old budget controls failed as intended, but its reporter format differed from the harness expectation. Corrected only the explicit test reporter and fresh evidence directory.')
