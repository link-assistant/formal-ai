from pathlib import Path
import gzip,hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
readme=root/'experiments/issue-1580/codeql-macro-contexts/README.md'
readme.write_text('''# Original Rust macro context observation

The original Rust SARIF retains 631 informational unresolved macro locations.
An unresolved source AST node alone does not establish whether its compiled
expansion is present elsewhere. This diagnostic records source macro AST nodes
and their expansion context in the database produced by the security job.

Dispatch `security.yml` on the issue branch with `codeql=true` and
`macro-contexts=true`. Both inputs default to false. Only the read-only Rust job
runs this observer, after its original analysis; the unchanged original SARIF
gate still runs after a diagnostic failure. The Actions security suite remains
unchanged, and no code scanning results are uploaded by the read-only job.

The observer uses the actual `init` binary and `analyze` database outputs. It
inherits the producer's bundled Rust query pack without resolving new libraries.
The temporary query directory is removed even when compilation fails. Retained
artifacts include the query, database metadata, pack metadata and lockfiles when
present, CLI version, command arguments, original streams/statuses, BQRS, decoded
eight-column table and hashes. The hosted step has a four-minute deadline;
query execution requests two threads, 2 GiB RAM and a 512 MiB disk cache.

Columns are the macro entity, relative source path, start/end line and column,
whether the call has an expansion, and whether it is inside another expansion.
Compare the actual rows to the original SARIF locations and compiled source
contexts before drawing a coverage conclusion. Neither a nonempty table nor
zero security findings proves complete macro semantics.

Local adapter controls use a fake CLI to exercise transport and failure
handling. They do not compile QL or establish Rust extraction coverage. Actual
hosted compilation and execution remain required. All supplied query, script
and conclusions receive zero independent Formal AI authorship credit.
''')
(root/'changelog.d/issue-1580-maintenance-and-retry-observation.md').write_text('Require a complete successful lockfile inventory before dependency maintenance resolves any package, keep transient-link request timers and retry waits within their shared budget, and add an optional read-only observation of macro contexts in the original hosted CodeQL database.\n')
base=root/'experiments/issue-1580/evidence/checks/codeql-macro-source-investigation';base.mkdir(exist_ok=False)
folders=['codeql-macro-targets','codeql-diagnostic-sources','codeql-macro-query','codeql-probe-interfaces','codeql-macro-location-interfaces','macro-context-classification','macro-context-classification-normalized']
helpers=['research-codeql-macro-targets','read-codeql-diagnostic-sources','read-codeql-macro-query','research-codeql-probe-interfaces','inspect-codeql-macro-contexts','continue-codeql-macro-investigation','inspect-codeql-macro-contexts-normalized','draft-codeql-macro-observation','test-codeql-macro-observation','correct-macro-test-draft-delimiters','test-codeql-macro-observation-corrected','run-macro-focused-validation','refresh-head-and-macro-gates','draft-template-runtime-counterparts','refine-template-and-macro-draft','validate-template-runtime-and-macro-draft','correct-runtime-validation-reporting','validate-template-runtime-and-macro-draft-reported','record-rust-dependency-guide','read-rust-macro-and-small-logs','record-rust-macro-and-small-logs','read-rust-lock-and-tool-notes','record-rust-lock-and-tool-notes']
selected=[]
for folder in folders:
 directory=scratch/folder;assert directory.is_dir(),folder
 selected.extend((p,Path(folder)/p.relative_to(directory)) for p in sorted(directory.rglob('*')) if p.is_file())
for stem in helpers:
 for extension in ['.py','.log']:
  path=scratch/(stem+extension)
  if path.exists():selected.append((path,Path('helpers')/path.name))
for name in ['run-codeql-macro-observation-tests.log','codeql-macro-observation-tests.log','document-macro-and-runtime-repairs.py']:
 path=scratch/name;assert path.is_file();selected.append((path,Path('helpers')/name))
for name in ['dependencies-latest.before.yml','recheck-broken-links.before.mjs']:
 selected.append((scratch/'template-runtime-counterparts'/name,Path('original-runtime-sources')/name))
records=[]
for path,relative in selected:
 raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);destination=base/(relative.as_posix()+'.gz');destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed)
 records.append({'file':destination.relative_to(base).as_posix(),'originalPath':str(path),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
(base/'files.json').write_text(json.dumps(records,indent=2)+'\n')
local=root/'experiments/issue-1580/evidence/checks/template-runtime-and-macro-observation-verified';records=json.loads((local/'records.json').read_text())
assert len(records)==8 and all(r['exitCode']==r['expectedExitCode'] for r in records)
for record in records:
 for stream in ['stdout','stderr']:
  item=record[stream];packed=(local/item['file']).read_bytes();raw=gzip.decompress(packed)
  assert hashlib.sha256(packed).hexdigest()==item['archiveSha256'] and hashlib.sha256(raw).hexdigest()==item['rawSha256']
  assert len(raw)==item['bytes'] and len(raw.splitlines())==item['lines']
ledger=root/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json';data=json.loads(ledger.read_text())
decision=data['practiceDecisions'][-1];assert decision['practice']=='Audit and refresh every actual committed dependency inventory without losing producer status'
decision['status']='guide-reviewed-maintenance-inventory-local-regression-verified-other-runtime-criteria-open'
decision['verification']={'path':'experiments/issue-1580/evidence/checks/template-runtime-and-macro-observation-verified/records.json','originalInventoryRegressionFailures':1,'currentMaintenanceCasesPassed':4,'nativeCompilation':False,'independentAuthorshipCredit':0}
ledger.write_text(json.dumps(data,indent=2)+'\n')
doc=root/'docs/case-studies/issue-1580/macro-observation-and-runtime-budget-checkpoint.md'
doc.write_text('''# Macro observation and runtime budget checkpoint

The dependency-maintenance workflow previously read `git ls-files` through
process substitution. A Git failure after partial output exited successfully
and could resolve an incomplete tree. Capture the complete inventory before
invoking any resolver. Its actual shell regression fails against the original
workflow and passes after repair, with all four maintenance cases passing.

The link recheck bounded each request but slept without accounting for its
remaining shared budget, then allowed a request its entire individual timeout.
Stop before a retry delay consumes the remaining budget and cap every request
at the remaining allowance. Both new controls fail against the original source
and pass after repair. Fake timers avoid wall-clock stress. All 16 existing/new
recheck cases and three real local HTTP cases pass, preserving permanent 404
failures and requiring an actual accepted response after a transient failure.

All 19 security adapter groups pass. The optional macro observer is restricted
to an explicit read-only Rust dispatch, after the existing producer analysis.
It retains original database/pack metadata, version, query, command streams,
BQRS and decoded contexts without replacing the security suite. Local mock
success only verifies adapter transport; actual QL compilation, hosted rows and
semantic interpretation remain unverified.

The original 3bb3083b Security run
[44765053281](https://github.com/link-assistant/formal-ai/actions/runs/44765053281)
preserves zero findings and zero warning/error notifications in Rust and Actions
SARIF. All 631 informational unresolved macro records remain visible. Source
include-path normalization maps 342 records to directly included files,
including all 282 production records. This source relationship is a hypothesis
to verify against actual expanded AST rows, not semantic coverage proof.

Five touched JavaScript gates and whitespace checks pass. Original-failure and
passing logs are under
`experiments/issue-1580/evidence/checks/template-runtime-and-macro-observation-verified/`.
The first evidence harness run preserved both intended failures but expected a
different default Node reporter; only the harness reporter was corrected.
Primary CodeQL sources, historical reports, full research responses, failed
drafts, corrections and original runtime source bytes are retained under
`experiments/issue-1580/evidence/checks/codeql-macro-source-investigation/`.

Pinned Rust template review now covers 308/373 files and 36,982 literal lines;
65 files and unverified counterpart practices remain open. The full issue,
other template comparisons, source warnings, dependency migrations, strict
original-native acceptance, production publication/delivery and full PR review
remain unfinished. No local Rust/QL compilation runs. Supplied work receives
zero independent Formal AI authorship/reasoning credit. The PR stays draft.
''')
with (root/'experiments/issue-1580/work-plan.md').open('a') as stream:stream.write('\n- The three new runtime regressions demonstrably fail on original bytes and pass after repair: four maintenance, 16 recheck, three actual local HTTP, and 19 security adapter groups pass, with five touched gates and whitespace. Preserve the initial reporter-format harness failure; actual macro query compilation/hosted semantic proof remains pending. Archive all research, failed drafts and original source snapshots with verified identities. No native compilation or independent reasoning credit.\n')
print('Verified 16 focused streams; archived',len(selected),'original research/helper records; wrote honest runtime/macro checkpoint and release fragment.')
