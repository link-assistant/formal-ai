from pathlib import Path
import datetime,gzip,hashlib,json,re
root=Path('/tmp/gh-issue-solver-1794900398048');base=Path('/tmp/issue-1580-research/rust-lock-and-tool-notes')
log=base/'read.txt';sources=json.loads((base/'sources.json').read_text());rows={};current=None
for line in log.read_text().splitlines():
 match=re.fullmatch(r'FILE (\S+) LINES (\d+) SHA256 ([0-9a-f]{64})',line)
 if match:
  current=match[1];rows[current]={'lines':int(match[2]),'sha256':match[3],'numbered':{}}
 else:
  match=re.fullmatch(r'(\d+): (.*)',line)
  if match and current:rows[current]['numbered'][int(match[1])]=match[2]
assert len(rows)==len(sources)==3
target=root/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json';data=json.loads(target.read_text())
assert (data['fullyReadFiles'],data['fullyReadSourceLines'])==(304,35750)
known={r['path'] for r in data['files']};name='rust-lock-and-tool-notes.read.txt.gz'
for source in sources:
 path=source['path'];row=rows[path];raw=(Path('/tmp/issue-1580-research/templates/rust-complete')/path).read_bytes();lines=raw.decode().splitlines()
 assert path not in known and hashlib.sha256(raw).hexdigest()==row['sha256']==source['sha256']
 assert sorted(row['numbered'].items())==list(enumerate(lines,1)) and len(lines)==row['lines']==source['lines']
 data['files'].append({'path':path,'lines':len(lines),'sha256':row['sha256'],'readLogs':[name],
  'literalReadRanges':[[1,len(lines)]],'literalReadLines':len(lines),'literalSourceFullyRead':True,'formalAiPracticeImplementationVerified':False})
archive=root/'experiments/issue-1580/evidence/checks/rust-source-review'/name
assert not archive.exists();raw=log.read_bytes();packed=gzip.compress(raw,mtime=0);archive.write_bytes(packed)
manifest=root/data['readLogManifest'];records=json.loads(manifest.read_text())
records.append({'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()});manifest.write_text(json.dumps(records,indent=2)+'\n')
data['files'].sort(key=lambda r:r['path']);data['fullyReadFiles']=len(data['files']);data['fullyReadSourceLines']=sum(r['literalReadLines'] for r in data['files']);data['observedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
data['practiceDecisions'].append({'practice':'Malformed-lock identity, connect-phase retry classification and updater runtime requirements',
 'templateEvidence':list(rows),'assessment':'Read the complete historical 473-line Cargo lock, including duplicate syn 3.0.10 entries and missing syn 2.0.111 references; this is invalid historical input, not a package graph to adopt. Strict actual lock validation and propagation of audit failures remain required. The complete lychee report and maintainer response distinguish an early TLS reset from a post-request reset: retries require the underlying I/O kind and the nested io::Error wrapper, while permanent HTTP errors remain failures. Formal AI already carries the targeted recheck helper; current source and runtime equivalence still need verification. npm-check-updates 23.1.1 historical metadata declares Node ^22.22.2 or ^24.15.0 or >=26.0.0 and npm >=10; a matching historical major alone does not prove actual updater compatibility. Preserve historical engine/package identities without calling these latest releases or current runtime evidence.',
 'status':'literal-history-reviewed-current-counterparts-open','formalAiPaths':['scripts/check-rust-dependencies.sh','scripts/recheck-broken-links.mjs','.github/workflows/dependencies.yml'],'verification':None})
assert (data['fullyReadFiles'],data['fullyReadSourceLines'])==(307,36722)
target.write_text(json.dumps(data,indent=2)+'\n')
with (root/'experiments/issue-1580/work-plan.md').open('a') as stream:stream.write('\n- Three more complete pinned Rust historical lock/tool files are literally read and hash-bound: 307/373 files and 36,722 lines, with 66 files remaining. Preserve the invalid duplicate/missing-version lock graph, connect-phase TLS reset versus permanent-HTTP distinction and exact historical updater engine requirements; current counterpart verification remains open.\n')
print(json.dumps({'files':data['fullyReadFiles'],'lines':data['fullyReadSourceLines'],'remaining':66}))
