from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
scratch=Path('/tmp/issue-1580-research/template-runtime-counterparts');scratch.mkdir(exist_ok=False)
workflow=root/'.github/workflows/dependencies-latest.yml'
source=workflow.read_text();(scratch/'dependencies-latest.before.yml').write_text(source)
old='''          while IFS= read -r lock; do
'''
new='''          # Finish enumeration before resolving anything: process substitution
          # loses a failed Git status, including failures after partial output.
          locks="$(git ls-files -- '*bun.lock' '*package-lock.json')"
          while IFS= read -r lock; do
'''
assert source.count(old)==1
source=source.replace(old,new).replace("          done < <(git ls-files -- '*bun.lock' '*package-lock.json')",'          done <<< "$locks"')
workflow.write_text(source)
script=root/'scripts/recheck-broken-links.mjs';source=script.read_text();(scratch/'recheck-broken-links.before.mjs').write_text(source)
old='''    if (round > 1) {
      // Doubling, so three rounds span a minute rather than ten seconds: the
      // failure this exists for is a burst, and a burst is outlasted by time.
      await sleep(waitMs * 2 ** (round - 2));
    }
'''
new='''    const remaining = budgetMs - (now() - started);
    if (remaining <= 0) break;
    if (round > 1) {
      // A retry wait spends the same budget as a request. Stop when the next
      // wait leaves no time to ask, rather than sleeping past the deadline.
      const delay = waitMs * 2 ** (round - 2);
      if (delay >= remaining) break;
      await sleep(delay);
    }
'''
assert old in source;source=source.replace(old,new)
old='''      const result = await probe(url, { fetchImpl, timeoutMs, accept });'''
new='''      const result = await probe(url, {
        fetchImpl,
        timeoutMs: Math.min(timeoutMs, budgetMs - (now() - started)),
        accept,
      });'''
assert old in source;script.write_text(source.replace(old,new))
tests=root/'rust/tests/web/dependencies-maintenance-workflow.test.mjs'
source=tests.read_text()
source=source.replace('const workflow=readFileSync(', 'const workflow=readFileSync(',1)
source=source.replace("  const loop=source.match(/          while IFS= read -r lock; do\\n([\\s\\S]*?)          done < <\\(git ls-files -- '\\*bun.lock' '\\*package-lock.json'\\)/u);", "  const loop=source.match(/          while IFS= read -r lock; do\\n([\\s\\S]*?)          done <<< \\\"\\$locks\\\"/u);")
assert 'done < <' not in source
source+='''
function observeInventory(source, failAfterOutput) {
  const step=source.match(/      - name: Re-resolve the JavaScript lockfiles from the rewritten manifests\\n        run: \\|\\n([\\s\\S]*?)(?=\\n      - name:)/u);
  assert(step, 'complete resolver step required');
  const directory=realpathSync(mkdtempSync(path.join(tmpdir(),'formal-ai-lock-observation-')));
  const shell=`git() { printf 'package-lock.json\\\\n'; return ${failAfterOutput ? 23 : 0}; }\\n`+
    'npm() { printf "resolved:%s\\\\n" "$PWD"; }\\n'+
    'bun() { printf "resolved:%s\\\\n" "$PWD"; }\\n'+step[1].replace(/^          /gmu,'');
  try {
    return spawnSync('bash',['-c',shell],{cwd:directory,encoding:'utf8',timeout:3000});
  } finally { rmSync(directory,{recursive:true,force:true}); }
}

test('failed lock inventory stops before any resolver even after partial output',()=>{
  const failed=observeInventory(workflow,true);
  assert.equal(failed.status,23,failed.stderr);
  assert.equal(failed.stdout,'','an incomplete inventory must not resolve a partial tree');
  const complete=observeInventory(workflow,false);
  assert.equal(complete.status,0,complete.stderr);
  assert.match(complete.stdout,/^resolved:/u);
});
'''
source=source.replace("import {execFileSync} from 'node:child_process';","import {execFileSync,spawnSync} from 'node:child_process';")
tests.write_text(source)
tests=root/'scripts/recheck-broken-links.test.mjs';source=tests.read_text()
source+='''
test('retry waits stop when no request would fit in the remaining budget', {timeout: 1000}, async () => {
  let clock = 0;
  const waits = [];
  let calls = 0;
  const results = await recheckAll(['https://reset.example/'], {
    budgetMs: 30,
    waitMs: 50,
    now: () => clock,
    sleep: async ms => { waits.push(ms); clock += ms; },
    fetchImpl: async () => { calls += 1; throw new Error('reset'); },
  });
  assert.equal(calls, 1);
  assert.deepEqual(waits, []);
  assert.equal(results.get('https://reset.example/').outcome, 'unreachable');
});

test('a request uses only the remaining shared budget', {timeout: 1000}, async () => {
  const started = Date.now();
  const result = await recheckAll(['https://silent.example/'], {
    budgetMs: 15,
    timeoutMs: 500,
    attempts: 1,
    fetchImpl: (_url, {signal}) => new Promise((_resolve, reject) => {
      signal.addEventListener('abort', () => reject(new Error('deadline')));
    }),
  });
  assert.ok(Date.now() - started < 250, 'per-request timeout exceeded the shared budget');
  assert.equal(result.get('https://silent.example/').outcome, 'unreachable');
});
'''
tests.write_text(source)
with (root/'experiments/issue-1580/work-plan.md').open('a') as stream:
 stream.write('\\n- Pinned-template runtime comparison found two additional concrete defects: dependency-maintenance lock enumeration hid failed Git status through process substitution, and transient-link retry waits/request timers could exceed the declared shared budget. Drafted complete-inventory-before-resolution and remaining-budget enforcement with focused regression controls; verification is pending.\\n')
print('Drafted fallible lock inventory, bounded retry waits/request timers, and focused regressions. Original producer bytes preserved in',scratch)
