from pathlib import Path
import json, os, subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
base=Path('/tmp/issue-1580-research/head-and-macro-gates');base.mkdir(exist_ok=False)
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
commands=[('pipeline',['gh','run','view','44764893448','--repo','link-assistant/formal-ai','--json','status,conclusion,jobs,url,headSha']),
 ('gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--list'])]
for name,args in commands:
 result=subprocess.run(args,cwd=root,env=env,capture_output=True)
 (base/(name+'.stdout')).write_bytes(result.stdout);(base/(name+'.stderr')).write_bytes(result.stderr)
 assert result.returncode==0,(name,result.stderr[-1000:])
 if name=='pipeline':
  data=json.loads(result.stdout)
  print(json.dumps({'status':data['status'],'conclusion':data['conclusion'],'jobs':[{k:r[k] for k in ['name','databaseId','status','conclusion','startedAt','completedAt']} for r in data['jobs'] if 'Native' in r['name'] or r['conclusion'] not in ['success','skipped']]}))
 else: print(result.stdout.decode())
