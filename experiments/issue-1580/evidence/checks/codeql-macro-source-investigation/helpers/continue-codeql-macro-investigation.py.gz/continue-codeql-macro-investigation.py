from pathlib import Path
import base64,json,posixpath,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
base=Path('/tmp/issue-1580-research/codeql-macro-location-interfaces');base.mkdir(exist_ok=False)
sources=[('element-impl','github/codeql','rust/ql/lib/codeql/rust/elements/internal/ElementImpl.qll','codeql-cli/v2.27.5'),
 ('locatable','github/codeql','rust/ql/lib/codeql/rust/elements/internal/generated/Locatable.qll','codeql-cli/v2.27.5'),
 ('location','github/codeql','rust/ql/lib/codeql/rust/Location.qll','codeql-cli/v2.27.5'),
 ('codeql-run-queries','github/codeql-action','src/queries.ts','v4')]
for name,repo,path,ref in sources:
 args=['gh','api','repos/'+repo+'/contents/'+path+'?ref='+ref,'--paginate']
 result=subprocess.run(args,capture_output=True)
 (base/(name+'.stdout')).write_bytes(result.stdout);(base/(name+'.stderr')).write_bytes(result.stderr)
 print(name,result.returncode)
 if result.returncode:continue
 data=json.loads(result.stdout)
 raw=base64.b64decode(data['content']);(base/(name+'.decoded')).write_bytes(raw)
 print('SOURCE',name,'lines',len(raw.splitlines()))
source=Path('/tmp/issue-1580-research/inspect-codeql-macro-contexts.py').read_text()
source=source.replace("import collections, gzip, hashlib, json, re, subprocess","import collections, gzip, hashlib, json, re, subprocess, posixpath")
source=source.replace('macro-context-classification','macro-context-classification-normalized')
source=source.replace("target=(Path(path).parent/match[1]).as_posix()","target=posixpath.normpath((Path(path).parent/match[1]).as_posix())")
target=Path('/tmp/issue-1580-research/inspect-codeql-macro-contexts-normalized.py');target.write_text(source)
with (base/'classification.stdout').open('wb') as out:
 subprocess.run(['python3',str(target)],cwd=root,stdout=out,stderr=subprocess.STDOUT,check=True)
data=json.loads(Path('/tmp/issue-1580-research/macro-context-classification-normalized/classification.json').read_text())
print(json.dumps({k:data[k] for k in ['notifications','files','directIncludedFileNotifications','semanticCoverageProven']}))
for row in data['sourceFiles']:
 if row['directIncludeParents']:print(row['count'],row['path'],json.dumps(row['directIncludeParents']))
