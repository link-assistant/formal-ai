import hashlib, io, json, subprocess, tarfile
from pathlib import Path

scratch = Path('/tmp/issue-1580-research')
source = scratch / 'stale-preserving-full-gates'
outcome = json.loads((source / 'outcome.json').read_text())
assert outcome['complete'] and outcome['exitCode'] == 0 and outcome['cleanBefore'] and outcome['cleanAfter']
assert outcome['counts'] == {'PASS':89, 'FAIL':0, 'SKIP':54}
assert outcome['focused']['exitCode'] == 0
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == outcome['source']
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
destination = Path('experiments/issue-1580/evidence/checks/stale-preserving-clean-replay')
destination.mkdir(parents=True, exist_ok=True)
archive = destination / 'complete-observations.tar.gz'
assert not archive.exists()
files = sorted(p for p in source.rglob('*') if p.is_file())
files += [scratch/name for name in ['run-stale-preserving-gates.py', 'current-batch-reviewed.diff',
 'stale-source-walk-neighbor.log', 'read-current-feedback.py', 'current-feedback-review.log',
 'issue-current-complete.json', 'issue-current-comments.json', 'pr-current-complete.json',
 'pr-current-inline.json', 'pr-current-conversation.json', 'pr-current-reviews.json',
 'seal-stale-preserving-replay.py']]
records=[]
with tarfile.open(archive,'w:gz',compresslevel=6) as stream:
 for file in files:
  payload=file.read_bytes(); name=str(file.relative_to(scratch))
  info=tarfile.TarInfo(name);info.size=len(payload);info.mode=0o644
  stream.addfile(info,io.BytesIO(payload))
  records.append({'path':name,'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()})
with tarfile.open(archive,'r:gz') as stream:
 assert len(stream.getmembers()) == len(records)
 for row in records:
  payload=stream.extractfile(row['path']).read()
  assert len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256']
(destination/'members.jsonl').write_text(''.join(json.dumps(row)+'\n' for row in records))
manifest={k:v for k,v in outcome.items() if k!='records'}
manifest.update({'scope':'Clean sequential full procedure suite and complete 143-entry local gate inventory; hosted exclusions are not passes.',
 'independentAuthorshipCredit':0,'roundTripVerified':True,'members':len(records),'inventory':'members.jsonl',
 'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}})
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with Path('docs/case-studies/issue-1580/ci-observation-boundaries-20261123.md').open('a') as out:
 out.write(f'''
The final clean replay on `{outcome['source']}` completes at
`{outcome['completedAt']}`: all 19 procedure cases pass, and the complete
143-entry local inventory has 89 passes, zero failures and 54 explicit hosted
exclusions. The tree is clean before and after the sequential run. Every gate
stream, full suite output, exact command and source identity is retained with
round-trip hashes in
`experiments/issue-1580/evidence/checks/stale-preserving-clean-replay/`.
The final evidence commit changes documentation and retained observations only;
native execution and the next hosted cohort remain separate qualifications.
''')
with Path('experiments/issue-1580/work-plan.md').open('a') as out:
 out.write(f'''
### Clean pre-push observation

- [x] Complete all 19 procedure cases and all 143 gates on clean `{outcome['source']}`:
  89 gates pass, zero fail, 54 explicitly require hosted execution.
- [x] Review the complete 309-line current production/test batch diff, preserve
  all three preceding local gate outcomes, and re-read current issue/PR feedback.
- [ ] Refresh main and both run queues, then push the complete repair batch once.
- [ ] Observe the new hosted head, exercise both real native artifact rerun paths,
  and complete all remaining original criteria before readiness.
''')
print(json.dumps(manifest))
