import json, subprocess
from pathlib import Path

root=Path('/tmp/issue-1580-research')
commands={
 'issue-current-complete.json':['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','title,body,state,comments'],
 'issue-current-comments.json':['gh','api','repos/link-assistant/formal-ai/issues/1580/comments','--paginate'],
 'pr-current-complete.json':['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','title,body,isDraft,headRefOid,mergeStateStatus,statusCheckRollup'],
 'pr-current-inline.json':['gh','api','repos/link-assistant/formal-ai/pulls/1581/comments','--paginate'],
 'pr-current-conversation.json':['gh','api','repos/link-assistant/formal-ai/issues/1581/comments','--paginate'],
 'pr-current-reviews.json':['gh','api','repos/link-assistant/formal-ai/pulls/1581/reviews','--paginate'],
}
for name,args in commands.items():
 with (root/name).open('wb') as out: subprocess.run(args,stdout=out,check=True)
i=json.loads((root/'issue-current-complete.json').read_text());print(i['title']);print(i['body'])
for name in ['issue-current-comments.json','pr-current-inline.json','pr-current-conversation.json','pr-current-reviews.json']:
 rows=json.loads((root/name).read_text()); print(name,len(rows))
 for row in rows:print(row.get('html_url'),row.get('created_at',row.get('submitted_at')),row.get('body'))
p=json.loads((root/'pr-current-complete.json').read_text()); (root/'pr-current-body.md').write_text(p['body'])
print('PR',{k:v for k,v in p.items() if k not in ('body','statusCheckRollup')})
