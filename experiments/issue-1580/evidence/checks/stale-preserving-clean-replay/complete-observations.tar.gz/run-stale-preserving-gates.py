import datetime, hashlib, json, shutil, subprocess
from pathlib import Path

root=Path('/tmp/issue-1580-research/stale-preserving-full-gates')
root.mkdir(exist_ok=True)
git=lambda *args:subprocess.check_output(['git',*args],text=True).strip()
head=git('rev-parse','HEAD'); before=git('status','--porcelain')
assert not before, before
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
focused=['node','--max-old-space-size=384','--test','--test-concurrency=1','rust/tests/web/procedural-runtime-parity.test.mjs']
with (root/'procedural-runtime-parity.log').open('wb') as output:
    result=subprocess.run(focused,stdout=output,stderr=subprocess.STDOUT)
focused_result={'source':head,'command':focused,'exitCode':result.returncode}
(root/'focused-outcome.json').write_text(json.dumps(focused_result,indent=2)+'\n')
assert result.returncode==0, focused_result
command=['node','--max-old-space-size=384','experiments/formal_ai_subagent/local-gates.mjs']
with (root/'runner.log').open('wb') as out:
    result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
after=git('status','--porcelain')
records=[]
for line in (root/'runner.log').read_text().splitlines():
    if not line.startswith(('PASS ','FAIL ','SKIP ')):continue
    kind,name,*tail=line.split(' ')
    record={'status':kind,'name':name,'observation':line}
    if kind!='SKIP':
        file=Path('experiments/formal_ai_subagent/sandboxes/gates')/(name+'.log')
        assert file.is_file(),str(file)
        output=root/(name+'.log');shutil.copyfile(file,output)
        record['sha256']=hashlib.sha256(output.read_bytes()).hexdigest()
    records.append(record)
outcome={'source':head,'command':command,'exitCode':result.returncode,'complete':True,
         'startedAt':started,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'cleanBefore':not before,'cleanAfter':not after,'afterStatus':after,'focused':focused_result,
         'counts':{status:sum(row['status']==status for row in records) for status in ['PASS','FAIL','SKIP']},'records':records}
(root/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps({k:v for k,v in outcome.items() if k!='records'}),flush=True)
