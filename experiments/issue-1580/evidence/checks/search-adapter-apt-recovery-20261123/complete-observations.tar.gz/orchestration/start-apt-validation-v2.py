from pathlib import Path
import subprocess,json
p=Path('rust/tests/web/agentic-search-installer.test.mjs')
s=p.read_text()
assert s.count('recoveryStatus=0,')==1
s=s.replace('recoveryStatus=0,','recoveryStatus=0,recoveryStall=false,')
needle='if(status===0)fs.rmSync(process.env.FAKE_PENDING,{force:true});process.exitCode=status;'
assert s.count(needle)==1
s=s.replace(needle,"if(process.env.FAKE_RECOVERY_STALL==='1')setInterval(()=>{},1000);else{if(status===0)fs.rmSync(process.env.FAKE_PENDING,{force:true});process.exitCode=status;}")
needle='FAKE_RECOVERY_STATUS:String(recoveryStatus),'
assert s.count(needle)==1
s=s.replace(needle,needle+"FAKE_RECOVERY_STALL:recoveryStall?'1':'0',")
s+="""\ntest('stalled interrupted-package recovery is killed by the existing last-attempt deadline',()=>{
 const r=run({interruptInstall:true,recoveryStall:true});assert.equal(r.status,124,r.stdout+r.stderr);assert(r.elapsed<7000);
 assert.deepEqual(r.records.map(x=>x.kind),['apt','apt','configure']);assert.match(r.stderr,/Attempt 2 exited 124/);
});\n"""
p.write_text(s)
old=Path('/tmp/issue-1580-research/run-apt-focused-validation.py').read_text()
old=old.replace('/after-validation','/after-validation-v2')
old=old.replace("commands=[\n['bash','-n','scripts/apt-install-with-retry.sh','scripts/prepare-ubuntu-apt-mirror.sh','scripts/install-agentic-search-tools.sh'],","commands=[\n['bash','-n','scripts/apt-install-with-retry.sh'],\n['bash','-n','scripts/prepare-ubuntu-apt-mirror.sh'],\n['bash','-n','scripts/install-agentic-search-tools.sh'],")
old=old.replace("['node','experiments/formal_ai_subagent/local-gates.mjs','--list'],","['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-readable-code,check-required-documentation,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-changelog-fragment-js-twin,lint-shell-scripts,release#1'],")
worker=Path('/tmp/issue-1580-research/run-apt-focused-validation-v2.py')
worker.write_text(old)
r=Path('/tmp/issue-1580-research/apt-recovery-repair/after-validation-v2')
r.mkdir()
log=open(r/'worker.log','wb')
process=subprocess.Popen(['python3',str(worker)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(r/'worker.pid').write_text(str(process.pid)+'\n')
print(json.dumps({'pid':process.pid,'version':2}))
