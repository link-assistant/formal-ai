from pathlib import Path
p=Path('scripts/apt-install-with-retry.sh')
s=p.read_text()
s=s.replace('#   FORMAL_AI_APT_MIRROR_LIST       regular mirror-list fixture or runner path','#   FORMAL_AI_APT_MIRROR_LIST       regular mirror-list fixture or runner path\n#   FORMAL_AI_APT_RECOVER_DPKG_ON_TIMEOUT  1 configures pending packages inside\n#                                   the next existing attempt (default 0)')
needle='mirror_list="${FORMAL_AI_APT_MIRROR_LIST:-/etc/apt/apt-mirrors.txt}"'
s=s.replace(needle,needle+'\nrecover_dpkg="${FORMAL_AI_APT_RECOVER_DPKG_ON_TIMEOUT:-0}"')
needle='for name in FORMAL_AI_APT_ATTEMPTS:$attempts'
assert s.count(needle)==1
s=s.replace(needle,'''[[ "$recover_dpkg" = 0 || "$recover_dpkg" = 1 ]] || {
  echo "interrupted dpkg recovery must be 0 or 1" >&2
  exit 2
}

'''+needle)
needle='  # The deadline runs *inside* the privilege escalation'
assert s.count(needle)==1
s=s.replace(needle,'''  recover_configuration=0
  if [ "$recover_dpkg" = 1 ] && [ "$status" -eq 124 ]; then
    recover_configuration=1
  fi
'''+needle)
needle='      use_alternate="$1"; mirror_list="$2"; mirror_script="$3"; shift 3'
assert s.count(needle)==1
s=s.replace(needle,'''      use_alternate="$1"; mirror_list="$2"; mirror_script="$3"
      recover_configuration="$4"; shift 4
      # A deadline can interrupt unpack/configure, not just a network request.
      # Keep recovery within this attempt's existing privilege and clock.
      if [ "$recover_configuration" = 1 ]; then
        echo "Configuring pending packages after the previous APT deadline."
        dpkg --configure --pending
      fi''')
needle=' "$script_directory/prepare-ubuntu-apt-mirror.sh" "$@"'
assert s.count(needle)==1
s=s.replace(needle,' "$script_directory/prepare-ubuntu-apt-mirror.sh" "$recover_configuration" "$@"')
p.write_text(s.replace('$',chr(36)))
p=Path('scripts/install-agentic-search-tools.sh')
s=p.read_text()
needle='    TEST_BUDGET_SECONDS="${TEST_BUDGET_SECONDS:-150}" \\'
assert s.count(needle.replace('$',chr(36)))==1
s=s.replace(needle.replace('$',chr(36)),('    FORMAL_AI_APT_RECOVER_DPKG_ON_TIMEOUT="${FORMAL_AI_APT_RECOVER_DPKG_ON_TIMEOUT:-1}" \\\n'+needle).replace('$',chr(36)))
p.write_text(s)
p=Path('scripts/prepare-ubuntu-apt-mirror.sh')
s=p.read_text()
needle='''awk '$1 == "http://azure.archive.ubuntu.com/ubuntu" || $1 == "http://azure.archive.ubuntu.com/ubuntu/" {
  sub(/http:\\/\\/azure\\.archive\\.ubuntu\\.com\\/ubuntu/, "https://archive.ubuntu.com/ubuntu")
} { print }' "$original" > "$staged"'''.replace('$',chr(36))
replacement='''awk '$1 == "http://azure.archive.ubuntu.com/ubuntu" || $1 == "http://azure.archive.ubuntu.com/ubuntu/" ||
  $1 ~ /^https?:\\/\\/[a-z0-9-]+\\.ec2\\.archive\\.ubuntu\\.com\\/ubuntu\\/?$/ {
  sub(/https?:\\/\\/[^/]+\\/ubuntu/, "https://archive.ubuntu.com/ubuntu")
} { print }' "$original" > "$staged"'''.replace('$',chr(36))
assert s.count(needle)==1
s=s.replace(needle,replacement)
p.write_text(s)
Path('changelog.d/20261123_104000_interrupted_search_adapter_install.md').write_text('''### Fixed
- Recover pending package configuration after a timed-out search-adapter install, and recognize official EC2 Ubuntu mirrors during the existing bounded fallback.
''')
print('Drafted APT transaction recovery and EC2 mirror fallback without increasing budgets.')
