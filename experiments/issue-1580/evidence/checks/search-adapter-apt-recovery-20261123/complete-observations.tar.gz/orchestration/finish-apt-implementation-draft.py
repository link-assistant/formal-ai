from pathlib import Path
p=Path('scripts/install-agentic-search-tools.sh')
s=p.read_text()
lines=s.splitlines(keepends=True)
matches=[i for i,line in enumerate(lines) if line.startswith('    TEST_BUDGET_SECONDS=')]
assert len(matches)==1
lines.insert(matches[0], '    FORMAL_AI_APT_RECOVER_DPKG_ON_TIMEOUT="${FORMAL_AI_APT_RECOVER_DPKG_ON_TIMEOUT:-1}" '+chr(92)+'\n')
p.write_text(''.join(lines))
old=Path('/tmp/issue-1580-research/implement-apt-recovery.py').read_text()
tail=old[old.index("p=Path('scripts/prepare-ubuntu-apt-mirror.sh')"):]
exec(compile(tail,'mirror-and-changelog-draft','exec'))
