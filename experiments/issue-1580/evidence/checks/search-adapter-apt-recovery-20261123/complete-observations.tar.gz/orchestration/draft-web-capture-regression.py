from pathlib import Path
import subprocess,json,time
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/dependency-refresh');o=r/'experiments/issue-1580/evidence/checks/artifact-consumers'
rows=json.loads((o/'records.json').read_text());renames=[]
for row in rows:
 old=row['file'];new=old.replace('-doc-gates','-documentation-gates').replace('-as-docs.','-as-documentation.')
 if old!=new:
  (o/old).rename(o/new);row['file']=new;renames.append({'from':old,'to':new})
(o/'records.json').write_text('[\n'+',\n'.join(json.dumps(x,separators=(',',':')) for x in rows)+'\n]\n')
(s/'archive-renames.json').write_text(json.dumps(renames,indent=2)+'\n')
p=r/'rust/tests/web/cargo-audit-blocked-proof.test.mjs';text=p.read_text()
fixture=r/'experiments/issue-1580/fixtures/audit-before-web-capture-upgrade.toml';fixture.write_bytes((r/'.cargo/audit.toml').read_bytes())
text=text.replace("const config=readFileSync(new URL('.cargo/audit.toml',root),'utf8');", "const config=readFileSync(new URL('.cargo/audit.toml',root),'utf8');\nconst historicalConfig=readFileSync(new URL('experiments/issue-1580/fixtures/audit-before-web-capture-upgrade.toml',root),'utf8');")
text=text.replace("const result=invoke();\n    assert.equal(result.status,0,result.stderr+result.stdout);\n    assert.deepEqual(result.calls.filter(args=>args[0]==='tree').map(args=>args.at(-1)),['fxhash@0.2.1','chrono@0.4.45']);", "const result=invoke({text:historicalConfig});\n    assert.equal(result.status,0,result.stderr+result.stdout);\n    assert.deepEqual(result.calls.filter(args=>args[0]==='tree').map(args=>args.at(-1)),['fxhash@0.2.1','chrono@0.4.45']);")
text+='''
test('the published web-capture upgrade removes fxhash and its exception while preserving strict Chrono proof', {timeout:10000},()=>{
  const lock=readFileSync(new URL('rust/Cargo.lock',root),'utf8');
  assert.doesNotMatch(lock,/^name = "fxhash"$/mu);
  assert.doesNotMatch(config,/RUSTSEC-2025-0057/u);
  withAudit(invoke=>{
    const result=invoke();
    assert.equal(result.status,0,result.stderr+result.stdout);
    assert.deepEqual(result.calls.filter(args=>args[0]==='tree').map(args=>args.at(-1)),['chrono@0.4.45']);
    assert.deepEqual(result.calls.filter(args=>args[0]==='audit'),[['audit','--file','rust/Cargo.lock','--deny','warnings']]);
  });
});
'''
p.write_text(text)
args=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',str(p.relative_to(r))]
with (s/'regression-before.stdout').open('wb') as out,(s/'regression-before.stderr').open('wb') as err:
 start=time.monotonic();p=subprocess.run(args,cwd=r,stdout=out,stderr=err)
(s/'regression-before.json').write_text(json.dumps({'command':args,'status':p.returncode,'seconds':round(time.monotonic()-start,3),'expected':'new fxhash removal regression fails; seven historical groups pass','independentAuthorshipCredit':0},indent=2)+'\n')
assert p.returncode==1
print('Preserved five archive names and historical two-advisory policy; expected regression failure recorded.')
