from pathlib import Path
p=Path('rust/tests/web/agentic-search-installer.test.mjs')
s=p.read_text()
assert s.count("recover='1'")==1
p.write_text(s.replace("recover='1'","recover=''"))
import subprocess,gzip,json,datetime,os
r=Path('/tmp/issue-1580-research/apt-recovery-repair')
(r/'after-validation').mkdir(exist_ok=True)
worker=Path('/tmp/issue-1580-research/run-apt-focused-validation.py')
worker.write_text("""from pathlib import Path
import subprocess,gzip,json,datetime
r=Path('/tmp/issue-1580-research/apt-recovery-repair/after-validation')
commands=[
['bash','-n','scripts/apt-install-with-retry.sh','scripts/prepare-ubuntu-apt-mirror.sh','scripts/install-agentic-search-tools.sh'],
['node','--test','--test-concurrency=1','rust/tests/web/agentic-search-installer.test.mjs'],
['node','--test','--test-concurrency=1','rust/tests/web/official-ubuntu-mirror-fallback.test.mjs'],
['node','--test','--test-concurrency=1','rust/tests/web/container-apt-retry.test.mjs'],
['node','--test','--test-concurrency=1','rust/tests/web/browser-ubuntu-apt-isolation.test.mjs'],
['node','--test','--test-concurrency=1','rust/tests/web/browser-engine-release-integration.test.mjs'],
['node','experiments/formal_ai_subagent/local-gates.mjs','--list'],
['git','diff','--check'],
]
records=[]
for i,command in enumerate(commands):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 result=subprocess.run(command,capture_output=True)
 for label,data in [('stdout',result.stdout),('stderr',result.stderr)]:
  with gzip.GzipFile(filename=str(r/(str(i)+'.'+label+'.gz')),mode='wb',mtime=0) as stream:stream.write(data)
 record={'command':command,'exitCode':result.returncode,'startedAt':started,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 records.append(record)
 (r/'records.json').write_text(json.dumps(records,indent=2)+'\\n')
 print(json.dumps(record),flush=True)
(r/'outcome.json').write_text(json.dumps({'complete':True,'allPassed':all(x['exitCode']==0 for x in records),'records':records},indent=2)+'\\n')
""")
log=open(r/'focused-worker.log','wb')
process=subprocess.Popen(['python3',str(worker)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(r/'focused-worker.pid').write_text(str(process.pid)+'\n')
print(json.dumps({'pid':process.pid,'checks':8}))
