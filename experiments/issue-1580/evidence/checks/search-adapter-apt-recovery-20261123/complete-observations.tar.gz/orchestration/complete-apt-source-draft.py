from pathlib import Path
p=Path('scripts/install-agentic-search-tools.sh')
lines=p.read_text().splitlines(keepends=True)
matches=[i for i,line in enumerate(lines) if line.lstrip().startswith('TEST_BUDGET_SECONDS=')]
assert len(matches)==1
i=matches[0]
indent=lines[i][:len(lines[i])-len(lines[i].lstrip())]
lines.insert(i, indent+'FORMAL_AI_APT_RECOVER_DPKG_ON_TIMEOUT="${FORMAL_AI_APT_RECOVER_DPKG_ON_TIMEOUT:-1}" '+chr(92)+'\n')
p.write_text(''.join(lines))
p=Path('scripts/prepare-ubuntu-apt-mirror.sh')
s=p.read_text()
start=s.index("\nawk '")+1
end=s.index('\n[ ! -L',start)
replacement="""awk '$1 == "http://azure.archive.ubuntu.com/ubuntu" || $1 == "http://azure.archive.ubuntu.com/ubuntu/" ||
  $1 ~ /^https?:\\/\\/[a-z0-9-]+\\.ec2\\.archive\\.ubuntu\\.com\\/ubuntu\\/?$/ {
  sub(/https?:\\/\\/[^/]+\\/ubuntu/, "https://archive.ubuntu.com/ubuntu")
} { print }' "$original" > "$staged" """
s=s[:start]+replacement.rstrip()+s[end:]
p.write_text(s)
Path('changelog.d/20261123_104000_interrupted_search_adapter_install.md').write_text('### Fixed\n- Recover pending package configuration after a timed-out search-adapter install, and recognize official EC2 Ubuntu mirrors during the existing bounded fallback.\n')
print('Completed recovery and exact EC2 URI fallback; budgets unchanged.')
