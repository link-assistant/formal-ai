from pathlib import Path
import subprocess,json,gzip,datetime
r=Path('/tmp/issue-1580-research/apt-recovery-repair')
r.mkdir(exist_ok=False)
for name in ['scripts/apt-install-with-retry.sh','scripts/prepare-ubuntu-apt-mirror.sh','scripts/install-agentic-search-tools.sh','rust/tests/web/agentic-search-installer.test.mjs','rust/tests/web/official-ubuntu-mirror-fallback.test.mjs']:
 p=Path(name);(r/(name.replace('/','--')+'.before')).write_bytes(p.read_bytes())
p=Path('rust/tests/web/agentic-search-installer.test.mjs')
s=p.read_text()
s=s.replace("function run({present=false,failures=0,stall=false,probe=0}={}){","function run({present=false,failures=0,stall=false,probe=0,interruptInstall=false,recoveryStatus=0,recover='1',mirrorText='http://azure.archive.ubuntu.com/ubuntu\\n'}={}){")
s=s.replace("writeFileSync(mirror,'http://azure.archive.ubuntu.com/ubuntu\\n');","writeFileSync(mirror,mirrorText);writeFileSync(calls,'');")
needle='  program(\'rg\','
assert s.count(needle)==1
s=s.replace(needle,'''  program('dpkg',"const fs=require('node:fs');fs.appendFileSync(process.env.FAKE_CALLS,JSON.stringify({kind:'configure',args:process.argv.slice(2)})+'\\\\n');const status=Number(process.env.FAKE_RECOVERY_STATUS);if(status===0)fs.rmSync(process.env.FAKE_PENDING,{force:true});process.exitCode=status;");
'''+needle)
needle='   "if(args.includes(\'update\')&&updates<=Number(process.env.FAKE_FAILURES)){",'
assert s.count(needle)==1
s=s.replace(needle,'''   "const pending=process.env.FAKE_PENDING;",
   "if(fs.existsSync(pending)){console.error('E: dpkg was interrupted; configure pending packages first');process.exit(100);}",
   "if(args.includes('install')&&process.env.FAKE_INTERRUPT_INSTALL==='1'&&!fs.existsSync(pending+'.started')){",
   " fs.writeFileSync(pending+'.started','1');fs.writeFileSync(pending,'1');setInterval(()=>{},1000);",
   "}",
'''+needle)
s=s.replace("FORMAL_AI_APT_MIRROR_LIST:mirror,FORMAL_AI_DEADLINE_GRACE_SECONDS:","FORMAL_AI_APT_RECOVER_DPKG_ON_TIMEOUT:recover,FORMAL_AI_APT_MIRROR_LIST:mirror,FORMAL_AI_DEADLINE_GRACE_SECONDS:")
s=s.replace("FAKE_CALLS:calls,FAKE_RG_PRESENT:","FAKE_PENDING:join(directory,'pending'),FAKE_INTERRUPT_INSTALL:interruptInstall?'1':'0',FAKE_RECOVERY_STATUS:String(recoveryStatus),\n    FAKE_CALLS:calls,FAKE_RG_PRESENT:")
s=s.replace("readFileSync(calls,'utf8').trim().split('\\n').map(JSON.parse),mirror:","readFileSync(calls,'utf8').trim().split('\\n').filter(Boolean).map(JSON.parse),mirror:")
s+='''
test('an interrupted package transaction is configured within the existing second attempt',()=>{
 const r=run({interruptInstall:true});assert.equal(r.status,0,r.stdout+r.stderr);assert(r.elapsed<7000);
 assert.match(r.stderr,/Attempt 1 exited 124/);
 assert.deepEqual(r.records.map(x=>x.kind),['apt','apt','configure','apt','apt','probe']);
 assert.deepEqual(r.records.find(x=>x.kind==='configure').args,['--configure','--pending']);
});
test('failed interrupted-package recovery keeps its error and cannot start another index or probe',()=>{
 const r=run({interruptInstall:true,recoveryStatus:73});assert.equal(r.status,73,r.stdout+r.stderr);
 assert.deepEqual(r.records.map(x=>x.kind),['apt','apt','configure']);
});
test('disabling package recovery keeps interrupted installation fatal',()=>{
 const r=run({interruptInstall:true,recover:'0'});assert.equal(r.status,100,r.stdout+r.stderr);
 assert.equal(r.records.filter(x=>x.kind==='configure'||x.kind==='probe').length,0);
});
test('invalid package-recovery configuration refuses before package-manager effects',()=>{
 const r=run({recover:'2'});assert.equal(r.status,2,r.stdout+r.stderr);assert.deepEqual(r.records,[]);
});
test('the observed EC2 mirror is replaced after the first real deadline',()=>{
 const r=run({failures:1,stall:true,mirrorText:'http://us-east-2.ec2.archive.ubuntu.com/ubuntu\\n'});
 assert.equal(r.status,0,r.stdout+r.stderr);assert.equal(r.mirror,'https://archive.ubuntu.com/ubuntu\\n');
 assert.equal(r.records.filter(x=>x.kind==='apt'&&x.args.includes('update')).length,2);
});
'''
p.write_text(s)
p=Path('rust/tests/web/official-ubuntu-mirror-fallback.test.mjs')
s=p.read_text()+'''
test('official EC2 regional mirror tokens use the exact HTTPS alternate and preserve line suffixes',()=>{
 for(const uri of ['http://us-east-2.ec2.archive.ubuntu.com/ubuntu','https://eu-west-1.ec2.archive.ubuntu.com/ubuntu/']){
  const suffix=uri.endsWith('/')?'/':'',text=uri+'\\tpriority:1 # runner region\\n';
  const r=run({text,direct:true});assert.equal(r.status,0,r.stdout+r.stderr);
  assert.equal(r.observed,'https://archive.ubuntu.com/ubuntu'+suffix+'\\tpriority:1 # runner region\\n');
 }
});
test('EC2 lookalikes, different paths and comments preserve all original bytes',()=>{
 const text='http://us-east-2.ec2.archive.ubuntu.com.evil.invalid/ubuntu\\nhttp://us-east-2.ec2.archive.ubuntu.com/ubuntu-extra\\n# http://us-east-2.ec2.archive.ubuntu.com/ubuntu\\n';
 const r=run({text,direct:true});assert.equal(r.status,0,r.stdout+r.stderr);assert.equal(r.observed,text);
});
'''
p.write_text(s)
commands=[['node','--test','--test-concurrency=1','rust/tests/web/agentic-search-installer.test.mjs'],['node','--test','--test-concurrency=1','rust/tests/web/official-ubuntu-mirror-fallback.test.mjs']]
records=[]
for i,cmd in enumerate(commands):
 x=subprocess.run(cmd,capture_output=True)
 for stream,value in [('stdout',x.stdout),('stderr',x.stderr)]: (r/f'before-{i}.{stream}.gz').write_bytes(gzip.compress(value,mtime=0))
 records.append({'command':cmd,'exitCode':x.returncode})
 print(json.dumps(records[-1]),flush=True)
(r/'before-records.json').write_text(json.dumps(records,indent=2)+'\n')
