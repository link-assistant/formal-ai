from pathlib import Path
import subprocess,gzip,json,datetime
r=Path('/tmp/issue-1580-research/apt-recovery-repair/before-current-regressions')
records=[]
for i,name in enumerate(['rust/tests/web/agentic-search-installer.test.mjs','rust/tests/web/official-ubuntu-mirror-fallback.test.mjs']):
 command=['node','--test','--test-concurrency=1',name]
 result=subprocess.run(command,cwd=r/'tree',capture_output=True)
 for label,data in [('stdout',result.stdout),('stderr',result.stderr)]:
  with gzip.GzipFile(filename=str(r/(str(i)+'.'+label+'.gz')),mode='wb',mtime=0) as stream:stream.write(data)
 record={'command':command,'exitCode':result.returncode,'base':'f7a71cb86a16e78da0e9ca055c13710d62277739'}
 records.append(record);print(json.dumps(record),flush=True)
(r/'outcome.json').write_text(json.dumps({'complete':True,'records':records},indent=2)+'\n')
