from pathlib import Path
import gzip
p=Path('scripts/apt-install-with-retry.sh')
s=p.read_text()
assert s.count("Keep recovery within this attempt's existing privilege and clock.")==1
p.write_text(s.replace("Keep recovery within this attempt's existing privilege and clock.","Keep recovery within the existing attempt privilege and clock."))
r=Path('/tmp/issue-1580-research/apt-recovery-repair/after-validation')
for name in ['0.stderr.gz','1.stderr.gz']:
 print(name+':\n'+gzip.decompress((r/name).read_bytes()).decode())
print('GATES\n'+gzip.decompress((r/'6.stdout.gz').read_bytes()).decode())
