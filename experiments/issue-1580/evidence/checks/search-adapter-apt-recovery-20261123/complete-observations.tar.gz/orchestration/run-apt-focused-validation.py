from pathlib import Path
import subprocess,gzip,json,datetime
r=Path('/tmp/issue-1580-research/apt-recovery-repair/after-validation')
commands=[
['bash','-n','scripts/apt-install-with-retry.sh','scripts/prepare-ubuntu-apt-mirror.sh','scripts/install-agentic-search-tools.sh'],
['node','--test','--test-concurrency=1','rust/tests/web/agentic-search-installer.test.mjs'],
['node','--test','--test-concurrency=1','rust/tests/web/official-ubuntu-mirror-fallback.test.mjs'],
['node','--test','--test-concurrency=1','rust/tests/web/container-apt-retry.test.mjs'],
['node','--test','--test-concurrency=1','rust/tests/web/browser-ubuntu-apt-isolation.test.mjs'],
['node','--test','--test-concurrency=1','rust/tests/web/browser-engine-release-integration.test.mjs'],
['node','experiments/formal_ai_subagent/local-gates.mjs','--list'],
['git','diff','--check'],
]
records=[]
for i,command in enumerate(commands):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 result=subprocess.run(command,capture_output=True)
 for label,data in [('stdout',result.stdout),('stderr',result.stderr)]:
  with gzip.GzipFile(filename=str(r/(str(i)+'.'+label+'.gz')),mode='wb',mtime=0) as stream:stream.write(data)
 record={'command':command,'exitCode':result.returncode,'startedAt':started,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 records.append(record)
 (r/'records.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(record),flush=True)
(r/'outcome.json').write_text(json.dumps({'complete':True,'allPassed':all(x['exitCode']==0 for x in records),'records':records},indent=2)+'\n')
