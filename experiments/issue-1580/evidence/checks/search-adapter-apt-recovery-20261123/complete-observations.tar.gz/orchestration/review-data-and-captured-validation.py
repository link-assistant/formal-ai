import gzip, hashlib, json, sys
from pathlib import Path

base = Path('/tmp/gh-issue-solver-1794900398048/experiments/issue-1580/evidence/checks/data-and-captured-native-validation')
results = json.loads((base/'results.json').read_text())
print('head', results['head'])
for row in results['checks']:
    packed=(base/row['file']).read_bytes(); raw=gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest()==row['archiveSha256']
    assert hashlib.sha256(raw).hexdigest()==row['rawSha256']
    assert len(raw.splitlines())==row['lines']
    print('CHECK', row['name'], 'exit', row['exitCode'], 'lines',row['lines'])
    if sys.argv[1]=='focused' and row['name']!='affected-local-gates':
        assert row['lines']<1500
        print(raw.decode())
    if sys.argv[1]=='gates' and row['name']=='affected-local-gates':
        print(raw.decode())
records=json.loads((base/'gate-log-manifest.json').read_text())
for row in records:
    packed=(base/'gate-logs'/row['file']).read_bytes(); raw=gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest()==row['archiveSha256']
    assert hashlib.sha256(raw).hexdigest()==row['rawSha256']
    assert len(raw.splitlines())==row['lines']
print('verified gate payloads',len(records))
print('outcome', (base/'outcome.json').read_text())

if sys.argv[1]=='record':
 import re, subprocess
 outcome=json.loads((base/'outcome.json').read_text())
 assert outcome['complete'] and outcome['allPassed'] and outcome['sourceUnchangedDuringValidation']
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==results['head']
 root=base.parents[4]
 counts={'tests':0,'pass':0,'fail':0,'skipped':0}
 for row in results['checks']:
  if row['name'] not in ['rustfmt','whitespace','affected-local-gates']:
   raw=gzip.decompress((base/row['file']).read_bytes()).decode()
   for key in counts:
    found=re.findall(r'^ℹ '+key+r' (\d+)$',raw,re.M)
    assert len(found)==1,(row['name'],key)
    counts[key]+=int(found[0])
 assert counts=={'tests':75,'pass':75,'fail':0,'skipped':0},counts
 for name,expected in results['sourceHashesBefore'].items():
  assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
 gates=gzip.decompress((base/'affected-local-gates.log.gz').read_bytes()).decode()
 gate_counts={key:len(re.findall('^'+key+r' ',gates,re.M)) for key in ['PASS','FAIL','SKIP']}
 assert gate_counts=={'PASS':11,'FAIL':0,'SKIP':0},gate_counts
 review=dict(outcome,focusedCounts=counts,gateCounts=gate_counts,allArchivedPayloadHashesVerified=True,focusedAndAggregateLogsLiterallyRead=True,detailedGatePayloadsLiterallyRead=False)
 (base/'review.json').write_text(json.dumps(review,indent=2)+'\n')
 print('RECORDED',json.dumps(review))
