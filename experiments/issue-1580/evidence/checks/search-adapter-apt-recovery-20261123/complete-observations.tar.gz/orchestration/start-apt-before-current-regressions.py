from pathlib import Path
import subprocess,json,hashlib
r=Path('/tmp/issue-1580-research/apt-recovery-repair')
assert json.loads((r/'after-validation-v2/outcome.json').read_text())['allPassed']
dest=r/'before-current-regressions'
dest.mkdir()
tree=dest/'tree'
tree.mkdir()
base='f7a71cb86a16e78da0e9ca055c13710d62277739'
bindings=[]
for name in ['scripts/apt-install-with-retry.sh','scripts/prepare-ubuntu-apt-mirror.sh','scripts/install-agentic-search-tools.sh','scripts/run-with-deadline.sh']:
 data=subprocess.check_output(['git','show',base+':'+name])
 p=tree/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);p.chmod(0o755)
 bindings.append({'path':name,'version':base,'sha256':hashlib.sha256(data).hexdigest()})
for name in ['rust/tests/web/agentic-search-installer.test.mjs','rust/tests/web/official-ubuntu-mirror-fallback.test.mjs','rust/tests/fixtures/apt/hosted-ubuntu-mirrors.txt']:
 data=Path(name).read_bytes()
 p=tree/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 bindings.append({'path':name,'version':'current test and fixture bytes','sha256':hashlib.sha256(data).hexdigest()})
(dest/'bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
worker=Path('/tmp/issue-1580-research/run-apt-before-current-regressions.py')
worker.write_text("""from pathlib import Path
import subprocess,gzip,json,datetime
r=Path('/tmp/issue-1580-research/apt-recovery-repair/before-current-regressions')
records=[]
for i,name in enumerate(['rust/tests/web/agentic-search-installer.test.mjs','rust/tests/web/official-ubuntu-mirror-fallback.test.mjs']):
 command=['node','--test','--test-concurrency=1',name]
 result=subprocess.run(command,cwd=r/'tree',capture_output=True)
 for label,data in [('stdout',result.stdout),('stderr',result.stderr)]:
  with gzip.GzipFile(filename=str(r/(str(i)+'.'+label+'.gz')),mode='wb',mtime=0) as stream:stream.write(data)
 record={'command':command,'exitCode':result.returncode,'base':'f7a71cb86a16e78da0e9ca055c13710d62277739'}
 records.append(record);print(json.dumps(record),flush=True)
(r/'outcome.json').write_text(json.dumps({'complete':True,'records':records},indent=2)+'\\n')
""")
log=open(dest/'worker.log','wb')
process=subprocess.Popen(['python3',str(worker)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(dest/'worker.pid').write_text(str(process.pid)+'\n')
print(json.dumps({'pid':process.pid,'baseline':base,'unchangedCurrentRegressions':True}))
