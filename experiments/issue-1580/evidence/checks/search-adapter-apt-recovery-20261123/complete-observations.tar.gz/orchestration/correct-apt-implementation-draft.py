from pathlib import Path
p=Path('/tmp/issue-1580-research/implement-apt-recovery.py')
s=p.read_text()
assert s.count('"$$"') == 2
p.write_text(s.replace('"$$"','"$@"'))
exec(compile(p.read_text(),str(p),'exec'))
