from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head.startswith('b2e84dd05')
source=Path('/tmp/issue-1580-research/validate-data-file-native-replay.py').read_text()
source=source.replace('data-file-native-validation','data-and-captured-native-validation')
source=source.replace("assert head=='d43bc0386409bb16535451d33dbb1af5e5e83888'",'assert head=='+repr(head))
source=source.replace("'rust-specification-unicode-identifiers.test.mjs','rust-specification-fixture-integrity.test.mjs'", "'rust-specification-unicode-identifiers.test.mjs','rust-specification-fixture-integrity.test.mjs','retrieved-concept-grounding.test.mjs'")
source=source.replace("run('whitespace'", "run('rustfmt',['rustfmt','--edition','2024','--check','rust/tests/unit/specification/unknown_reasoning.rs','rust/tests/unit/solver_unknown_reasoning_captured_sources.rs'])\n run('whitespace'")
p=Path('/tmp/issue-1580-research/validate-data-and-captured-native-replay.py')
assert not p.exists();p.write_text(source)
subprocess.run(['python3',str(p)],cwd=root,check=True)
