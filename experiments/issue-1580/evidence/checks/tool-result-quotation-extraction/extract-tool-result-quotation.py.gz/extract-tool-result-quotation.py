from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'tool-result-quotation-extraction'
if len(sys.argv) == 1:
    out.mkdir(exist_ok=False)
    with (out / 'worker.log').open('wb') as stream:
        worker = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print('Started finite quotation framing extraction', worker.pid)
    raise SystemExit()
records = []
def run(name, argv):
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=root, env={**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}, stdout=stdout, stderr=stderr)
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == 0, name
    return (out / (name + '.stdout')).read_text()
assert json.loads((scratch / 'telegram-markdown-extraction/outcome.json').read_text())['passed']
assert not run('index-before', ['git', 'diff', '--cached', '--name-only']).strip()
assert run('branch', ['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
parent = root / 'rust/src/agentic_coding/tool_result.rs'
child = root / 'rust/src/agentic_coding/tool_result/quotation.rs'
assert not child.exists()
original = parent.read_text()
assert len(original.splitlines()) == 903
start_marker = '/// How many cited lines it takes before a result counts as quoting.'
end_marker = 'pub(super) fn render('
start = original.index(start_marker)
end = original.index(end_marker, start)
block = original[start:end]
assert block.count('\nfn ') == 3 and block.endswith('\n\n')
new_parent = (original[:start] + original[end:]).replace('mod provider_result;\n', 'mod provider_result;\nmod quotation;\n', 1).replace('use result_kind::{is_listing, is_search};\n', 'use quotation::own_words;\nuse result_kind::{is_listing, is_search};\n', 1)
new_child = block[:-1].replace('\nfn own_words(', '\npub(super) fn own_words(')
restored = new_parent.replace('mod quotation;\n', '', 1).replace('use quotation::own_words;\n', '', 1).replace(end_marker, new_child.replace('pub(super) fn own_words(', 'fn own_words(') + '\n' + end_marker, 1)
assert restored == original
assert len(new_parent.splitlines()) < 900 and len(new_child.splitlines()) < 900
parent.write_text(new_parent)
child.write_text(new_child)
proof = {'observedAt': datetime.now(timezone.utc).isoformat(), 'originalSha256': hashlib.sha256(original.encode()).hexdigest(), 'reassembledOriginalSha256': hashlib.sha256(restored.encode()).hexdigest(), 'originalLines': 903, 'parentLines': len(new_parent.splitlines()), 'childLines': len(new_child.splitlines()), 'exactOriginalReconstruction': True, 'localRustExecution': False, 'hostedNativeVerificationPending': True, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
(out / 'inverse-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
(out / 'original-source.rs.gz').write_bytes(gzip.compress(original.encode(), mtime=0))
suffix = (scratch / 'extract-telegram-markdown.py').read_text().split('source_paths = ', 1)[1]
suffix = 'source_paths = ' + suffix
suffix = suffix.replace('telegram-markdown-extraction', 'tool-result-quotation-extraction')
suffix = suffix.replace("run('telegram-lines-javascript', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/mcp-telegram-lines.test.mjs'])", "run('tool-result-streams-javascript', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/tool-result-failed-streams.test.mjs'])\nrun('tool-result-outcomes-javascript', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/work-item-report-outcome.test.mjs'])")
suffix = suffix.replace('Separate the unchanged Telegram Markdown renderer into a private module, preserving the existing public entry point and HTML escaping while removing the source-size warning.', 'Separate unchanged quotation framing from tool-result normalization to remove its source-size warning while preserving status and citation interpretation.')
suffix = suffix.replace('Extract Telegram Markdown rendering without changing any function body or the public rendering path; exact inverse reconstruction matches the original source. Existing JavaScript Telegram line handling, translation projection and Rust formatting pass.', 'Extract tool-result quotation framing without changing any function body, public API or result status policy; exact inverse reconstruction matches the original source. Existing JavaScript failed-stream and report-outcome cases, translation projection and Rust formatting pass.')
suffix = suffix.replace('refactor: separate Telegram Markdown rendering below size warning', 'refactor: separate tool-result quotation framing below size warning')
exec(compile(suffix, __file__, 'exec'))
