from pathlib import Path
import datetime,json,os,subprocess
r=Path('/tmp/issue-1580-research/secretlint-locked-final-checks')
head=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()
commands=[('whitespace',['git','diff','--check']),('test-syntax',['node','--check','experiments/issue-1580/secretlint-locked-install.test.mjs']),('secrets',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','release#2'])]
records=[]
for label,command in commands:
 with (r/(label+'.log')).open('w') as stream:
  result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,env=dict(os.environ,BASE_REF='bc08222b5a5195dc9992c0459bde2b6369377b9f'))
 row={'label':label,'command':command,'exitCode':result.returncode};records.append(row);print(json.dumps(row),flush=True)
(r/'outcome.json').write_text(json.dumps({'head':head,'records':records,'complete':True,'allPassed':all(row['exitCode']==0 for row in records),'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+chr(10))
