from pathlib import Path
import datetime,gzip,hashlib,json,os,re,subprocess

root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'native-policy-headroom'
assert json.loads((out/'outcome.json').read_text())['allPassed']
assert '# pass 9\n# fail 0' in (out/'crate-path-after.stdout').read_text()
assert '# pass 8\n# fail 1' in (out/'crate-path-before.stdout').read_text()
assert '# pass 141\n# fail 0' in (out/'maintained.stdout').read_text()
rows=json.loads((out/'extraction.json').read_text())
for row in rows['files']:
    original=subprocess.check_output(['git','show',rows['head']+':'+row['parent']],cwd=root)
    assert hashlib.sha256(original).hexdigest()==row['originalSha256']
    row['actualParentLines']=len((root/row['parent']).read_text().splitlines())
    row['actualChildLines']=len((root/row['child']).read_text().splitlines())
    assert max(row['actualParentLines'],row['actualChildLines'])<=900
scanner=root/'experiments/formal_ai_subagent/sandboxes/gates/check-file-size.log'
assert len(re.findall(r'^::warning file=',scanner.read_text(),re.M))==81
target=root/'experiments/issue-1580/evidence/checks/native-policy-headroom';target.mkdir(exist_ok=False)
records=[]
def retain(path,alias):
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);destination=target/(alias+'.gz');destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed)
    records.append({'source':str(path),'file':alias+'.gz','bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
for path in sorted(out.iterdir()):
    if path.is_file():retain(path,'validation/'+path.name)
for name in ['extract-native-policy-headroom.py','extract-native-policy-headroom.log','validate-native-policy-headroom.py','validate-native-policy-headroom.log','repair-data-files-child-path.py','repair-data-files-child-path.log','commit-native-policy-headroom.py']:
    retain(scratch/name,'helpers/'+name)
for name in ['check-file-size.log','check-file-size-js-twin.log','check-abbreviations.log']:
    retain(scanner.parent/name,'gates/'+name)
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
summary={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':rows['head'],'files':rows['files'],'warningRegressionBefore':{'passed':5,'failed':3},'crateRootRegressionBefore':{'passed':8,'failed':1},'after':{'headroomCasesPassed':9,'nativeGroupCasesPassed':50,'maintainedCasesPassedBeforeFinalPathRegression':141},'sparseCheckoutAttempts':2,'actualFixturesSelectedPerAttempt':9,'remainingWarnings':81,'scannerLimitsUnchanged':True,'records':len(records),'nativeBuildRun':False,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for row in records:
    packed=(target/row['file']).read_bytes();raw=gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest()==row['archiveSha256'] and hashlib.sha256(raw).hexdigest()==row['rawSha256'] and len(raw)==row['bytes']
note=root/'docs/case-studies/issue-1580/native-policy-headroom-checkpoint.md'
note.write_text('''# Native policy helper headroom

The maintained scanner reproduced three more 900-line warnings in release
policy, data-file integrity and benchmark regression owners. Ordinary child
modules now hold release assertions, text-row helpers and benchmark evaluation
helpers. Every moved body survives byte for byte after normalizing only the
helper visibility required by its parent. Existing assertions and budgets stay
in force. The complete scanner reports 81 warnings and zero violations under
the unchanged limits.

Review also caught an extraction error before publication: Cargo registers
`data_files.rs` as a standalone crate root, so an implicit child declaration
resolved to a missing sibling file. A regression follows the real Cargo target
and resolves its module path; it fails before an explicit path attribute and
passes afterward. Nine focused cases now pass. The preceding validation passed
141 maintained observation cases, 50 native-runner cases, three touched gates,
formatting and whitespace checks. The final path repair was checked with the
nine focused cases and formatting. No local native build ran.

Actual Git sparse-checkout rule evaluation also selects all nine historical
upstream-report fixtures in both core checkout attempts and excludes an
unrelated log. This verifies selection, not native execution. Hosted native
compilation/execution of the local commits, complete template/practice review
and the wider issue requirements remain unfinished. Supplied scripts and edits
earn zero independent authorship or reasoning credit.

Evidence: `experiments/issue-1580/evidence/checks/native-policy-headroom/`.
''')
fragment=root/'changelog.d/issue-1580-native-policy-headroom.md'
fragment.write_text('''---
bump: patch
---

Extract release policy, data integrity and benchmark evaluation helpers into
ordinary native test child modules, retaining every assertion and the existing
size limits. Check standalone Cargo crate-root helper resolution before CI.
''')
plan=root/'experiments/issue-1580/work-plan.md';source=plan.read_text();start=source.index('## Current verification checkpoint\n');end=source.index('\n\nLatest checkpoint:',start)
source=source[:start]+'''## Current verification checkpoint

Published `6672bfc9` merges current main `873f1c33`; its 26 normal workflows
are still being collected. The preceding published `84e1ad85` has 25 successful
workflows and one skip, including all eight native families and registry checks.
The merged source passed all 88 executed local gates (53 explicit skips),
TypeScript generation/runtime, gateway/server checks and 133 maintained cases.

Local commits extract six Rust test/helper groups without changing their
bodies or scanner limits: 81 warnings remain. Coverage connects the original
planner, budget and image owners to the existing core/coding targets. Actual
Git sparse rules select their nine real fixtures in both core checkout attempts.
Nine focused headroom/path cases and 50 native-runner cases pass. The preceding
maintained entry passed 141 cases before the final path regression was added;
hosted native compilation/execution of these local edits remains pending.
See the [native policy checkpoint](../../docs/case-studies/issue-1580/native-policy-headroom-checkpoint.md).

Full template/practice, original budget/live, complete PR review, independent
authorship/reasoning and complete issue acceptance remain unfinished.
''' +source[end:]
plan.write_text(source)
paths=[row[key] for row in rows['files'] for key in ['parent','child']]+['experiments/issue-1580/native-test-headroom.test.mjs',str(note.relative_to(root)),str(fragment.relative_to(root)),str(plan.relative_to(root)),str(target.relative_to(root))]
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=root).decode().split('\0')[:-1]
assert not any('/evidence/ci/' in path for path in staged)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
for name,args in [('final-naming',['node','scripts/measure-abbreviations.mjs','--check']),('final-secrets',['bash','scripts/check-secrets.sh',*staged]),('final-whitespace',['git','diff','--cached','--check'])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    assert result.returncode==0,name
with (out/'commit.stdout').open('wb') as stdout,(out/'commit.stderr').open('wb') as stderr:subprocess.run(['git','-c','gc.auto=0','commit','-m','Extract native policy helpers with crate-root path regression coverage'],cwd=root,stdout=stdout,stderr=stderr,check=True)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root,text=True)
outcome={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'committed':True,'pushed':False,'trackedWorkingTreeClean':True,'records':len(records),'fullIssueComplete':False}
(out/'commit-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))
