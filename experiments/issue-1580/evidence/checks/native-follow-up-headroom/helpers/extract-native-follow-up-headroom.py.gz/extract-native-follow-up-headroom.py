from pathlib import Path
import hashlib,json,os,re,subprocess

root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/native-follow-up-headroom');out.mkdir(exist_ok=False)
test=root/'experiments/issue-1580/native-test-headroom.test.mjs'
extra='''
for (const [owner, child, names] of [
  ['rust/tests/unit/specification/reasoning_paths_procedures', 'elaboration', [
    'procedural_elaboration_followup_rebinds_to_prior_how_to',
    'procedural_elaboration_requires_a_prior_how_to',
    'procedural_elaboration_followup_covers_supported_languages',
    'procedural_elaboration_followup_covers_many_topics',
  ]],
  ['rust/tests/integration/with_formal_ai', 'global_configuration', [
    'with_formal_ai_global_configures_idempotently_and_undo_restores_backups',
  ]],
]) {
  test(owner + ' retains headroom and original native test names', () => {
    assert.deepEqual(checkListedFiles(root, new Set([owner + '.rs', owner + '/' + child + '.rs'])),
      {warnings: [], violations: [], embeddedDataViolations: []});
    const source = readFileSync(root + '/' + owner + '.rs', 'utf8');
    const extracted = readFileSync(root + '/' + owner + '/' + child + '.rs', 'utf8');
    for (const name of names) {
      assert(source.includes('#[test]\\nfn ' + name + '() {\\n    ' + child + '::' + name + '();\\n}'));
      assert(extracted.includes('pub(super) fn ' + name + '() {'));
    }
  });
}
'''
assert 'retains headroom and original native test names' not in test.read_text()
test.write_text(test.read_text()+extra)
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
args=['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',str(test.relative_to(root))]
with (out/'before.stdout').open('wb') as stdout,(out/'before.stderr').open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
assert result.returncode==1 and '# pass 9\n# fail 2' in (out/'before.stdout').read_text()
rows=[]
specs=[
    ('rust/tests/unit/specification/reasoning_paths_procedures.rs','elaboration','// ---------------------------------------------------------------------------\n// Issue #444:',None,'use formal_ai::{ConversationTurn, UniversalSolver};\n\nuse super::has_evidence;\n\n'),
    ('rust/tests/integration/with_formal_ai.rs','global_configuration','#[test]\nfn with_formal_ai_global_configures_idempotently_and_undo_restores_backups()','#[test]\nfn standalone_with_formal_ai_binary_uses_same_wrapper()','use std::process::Command;\n\nuse super::tmpdir;\n\n'),
]
for relative,module,start,end,prefix in specs:
    parent=root/relative;original=parent.read_text();first=original.index(start);last=original.index(end,first) if end else len(original);moved=original[first:last]
    names=re.findall(r'^fn (\w+)\(\) \{',moved,re.M);assert len(names)==(4 if module=='elaboration' else 1)
    assert moved.count('#[test]')==len(names)
    child=parent.with_suffix('')/(module+'.rs');child.parent.mkdir(exist_ok=True)
    body=re.sub(r'^fn (\w+)\(\) \{',r'pub(super) fn \1() {',moved.replace('#[test]\n',''),flags=re.M)
    child.write_text(prefix+body)
    wrappers='\n\n'.join('#[test]\nfn '+name+'() {\n    '+module+'::'+name+'();\n}' for name in names)+'\n\n'
    updated=original[:first]+wrappers+original[last:]
    if module=='elaboration':
        old='use formal_ai::{ConversationTurn, FormalAiEngine, SymbolicAnswer, UniversalSolver};'
        assert updated.count(old)==1;updated=updated.replace(old,'mod elaboration;\n\nuse formal_ai::{FormalAiEngine, SymbolicAnswer, UniversalSolver};')
    else:updated=updated.replace('mod fixture_env;','mod global_configuration;\nmod fixture_env;',1)
    parent.write_text(updated)
    (out/(module+'.before.rs')).write_text(original)
    rows.append({'parent':relative,'child':str(child.relative_to(root)),'module':module,'testNames':names,'beforeLines':len(original.splitlines()),'afterLines':len(updated.splitlines()),'originalSha256':hashlib.sha256(original.encode()).hexdigest(),'movedSha256':hashlib.sha256(moved.encode()).hexdigest(),'movedFirst':first,'movedLast':last,'movedBodiesUnchanged':body.replace('pub(super) fn ','fn ')==moved.replace('#[test]\n','')})
assert all(row['movedBodiesUnchanged'] for row in rows)
(out/'extraction.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'files':rows,'nativeExecutionVerified':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps({'drafted':True,'beforePassed':9,'beforeFailed':2,'nativeTestNamesPreserved':5}))
