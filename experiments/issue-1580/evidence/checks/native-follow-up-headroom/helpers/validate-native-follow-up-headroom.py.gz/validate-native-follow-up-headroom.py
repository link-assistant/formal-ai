from pathlib import Path
import json,os,re,subprocess,sys,traceback

root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/native-follow-up-headroom')
if len(sys.argv)==1:
    with (out/'worker.log').open('wb') as stream:process=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':process.pid})+'\n');print(json.dumps({'pid':process.pid,'finite':True}));sys.exit(0)
env=os.environ.copy();env.pop('NODE_OPTIONS',None);records=[]
def run(name,args):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    records.append({'name':name,'args':args,'exitCode':result.returncode});(out/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records[-1]),flush=True)
    assert result.returncode==0,name
try:
    rows=json.loads((out/'extraction.json').read_text())['files'];files=[row[key] for row in rows for key in ['parent','child']]
    run('format',['rustfmt','--edition','2024','--config','skip_children=true',*files])
    run('format-check',['rustfmt','--edition','2024','--config','skip_children=true','--check',*files])
    conservation=[]
    for row in rows:
        original=(out/(row['module']+'.before.rs')).read_text();moved=original[row['movedFirst']:row['movedLast']]
        actual=(root/row['child']).read_text();marker='// ---------------------------------------------------------------------------\n// Issue #444:' if row['module']=='elaboration' else 'pub(super) fn '
        normalized=actual[actual.index(marker):].replace('pub(super) fn ','fn ')
        assert normalized.rstrip()==moved.replace('#[test]\n','').rstrip(),row['child']
        assert len((root/row['parent']).read_text().splitlines())<=900
        conservation.append({'child':row['child'],'bodyConservedAfterFormatting':True,'nativeTestNamesPreserved':row['testNames']})
    (out/'conservation.json').write_text(json.dumps(conservation,indent=2)+'\n')
    for name,path in [('headroom','experiments/issue-1580/native-test-headroom.test.mjs'),('native-groups','experiments/issue-1580/native-regression-groups.test.mjs'),('maintained','rust/tests/web/issue-1580-template-observations.test.mjs')]:
        run(name,['node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',path])
    run('touched-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size,check-file-size-js-twin'])
    run('whitespace',['git','diff','--check'])
    outcome={'complete':True,'allPassed':True,'nativeBuildRun':False,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
    (out/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
