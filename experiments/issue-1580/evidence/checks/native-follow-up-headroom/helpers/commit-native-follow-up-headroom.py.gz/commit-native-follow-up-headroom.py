from pathlib import Path
import datetime,gzip,hashlib,json,os,re,subprocess

root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'native-follow-up-headroom'
assert json.loads((out/'outcome.json').read_text())['allPassed']
for name,total in [('headroom',11),('native-groups',50),('maintained',144)]:
    assert '# pass '+str(total)+'\n# fail 0' in (out/(name+'.stdout')).read_text()
rows=json.loads((out/'extraction.json').read_text());assert all(row['bodyConservedAfterFormatting'] for row in json.loads((out/'conservation.json').read_text()))
for row in rows['files']:
    raw=subprocess.check_output(['git','show',rows['head']+':'+row['parent']],cwd=root)
    assert hashlib.sha256(raw).hexdigest()==row['originalSha256']
    row['actualParentLines']=len((root/row['parent']).read_text().splitlines());row['actualChildLines']=len((root/row['child']).read_text().splitlines())
    assert max(row['actualParentLines'],row['actualChildLines'])<=900
assert not subprocess.check_output(['git','diff','HEAD','--','scripts/ci-native-reasoning-durations.lino'],cwd=root)
gates=root/'experiments/formal_ai_subagent/sandboxes/gates';assert len(re.findall(r'^::warning file=',(gates/'check-file-size.log').read_text(),re.M))==79
target=root/'experiments/issue-1580/evidence/checks/native-follow-up-headroom';target.mkdir(exist_ok=False);records=[]
def retain(path,alias):
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);destination=target/(alias+'.gz');destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(packed)
    records.append({'source':str(path),'file':alias+'.gz','bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
for path in sorted(out.iterdir()):
    if path.is_file():retain(path,'validation/'+path.name)
for name in ['extract-native-follow-up-headroom.py','extract-native-follow-up-headroom.log','validate-native-follow-up-headroom.py','validate-native-follow-up-headroom.log','commit-native-follow-up-headroom.py','commit-native-policy-headroom.py','commit-native-policy-headroom.log']:
    retain(scratch/name,'helpers/'+name)
for name in ['check-file-size.log','check-file-size-js-twin.log','check-abbreviations.log']:retain(gates/name,'gates/'+name)
for name in ['final-naming.stdout','final-naming.stderr','final-secrets.stdout','final-secrets.stderr','final-whitespace.stdout','final-whitespace.stderr','commit-outcome.json']:retain(scratch/'native-policy-headroom'/name,'preceding-commit/'+name)
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
summary={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':rows['head'],'files':rows['files'],'before':{'passed':9,'failed':2},'after':{'headroom':11,'nativeGroups':50,'maintained':144},'nativeTestNamesPreserved':5,'existingTimingRecordsUnchanged':True,'remainingWarnings':79,'scannerLimitsUnchanged':True,'retainedRecords':len(records),'nativeBuildRun':False,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for row in records:
    packed=(target/row['file']).read_bytes();raw=gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest()==row['archiveSha256'] and hashlib.sha256(raw).hexdigest()==row['rawSha256'] and len(raw)==row['bytes']
note=root/'docs/case-studies/issue-1580/native-follow-up-headroom-checkpoint.md';note.write_text('''# Follow-up and global configuration regression headroom

The maintained scanner reproduced two warnings in the procedural follow-up and
CLI wrapper test owners. Their assertions now live in ordinary child modules.
Five small parent wrappers preserve the original native test names and recorded
reasoning durations, using the same pattern as existing release-operation tests.
Every extracted body remains unchanged after removing only its test attribute
and adding the visibility required by the parent wrapper.

The two new scanner cases fail before repair. Afterward, all 11 focused cases,
50 native-runner cases, 144 maintained observations, three touched gates,
formatting and whitespace checks pass. The complete source scanner reports
79 warnings and zero violations under unchanged limits. No Rust compiler ran;
hosted native qualification of these local commits remains pending. The full
issue, complete template/practice review and independent authorship requirements
remain unfinished. Supplied scripts and edits earn zero independent credit.

Evidence: `experiments/issue-1580/evidence/checks/native-follow-up-headroom/`.
''')
fragment=root/'changelog.d/issue-1580-native-follow-up-headroom.md';fragment.write_text('''---
bump: patch
---

Extract procedural follow-up and global CLI configuration assertions while
preserving their original native test names, timing records and complete bodies.
''')
plan=root/'experiments/issue-1580/work-plan.md';source=plan.read_text().replace('Local commits extract six Rust test/helper groups','Local commits extract eight Rust test/helper groups').replace('bodies or scanner limits: 81 warnings remain.','bodies or scanner limits: 79 warnings remain.').replace('Nine focused headroom/path cases and 50 native-runner cases pass. The preceding\nmaintained entry passed 141 cases before the final path regression was added;','Eleven focused headroom/path cases, 50 native-runner cases and 144 maintained\nobservation cases pass;')
source+='\n- Follow-up/global-configuration extraction preserves five original native test names and existing reasoning timing records. Exact bodies and before-fix scanner failures are retained; 79 warnings remain. See [follow-up headroom](../../docs/case-studies/issue-1580/native-follow-up-headroom-checkpoint.md).\n';plan.write_text(source)
paths=[row[key] for row in rows['files'] for key in ['parent','child']]+['experiments/issue-1580/native-test-headroom.test.mjs',str(note.relative_to(root)),str(fragment.relative_to(root)),str(plan.relative_to(root)),str(target.relative_to(root))]
subprocess.run(['git','add','--',*paths],cwd=root,check=True);staged=subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=root).decode().split('\0')[:-1];assert not any('/evidence/ci/' in path for path in staged)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
for name,args in [('final-naming',['node','scripts/measure-abbreviations.mjs','--check']),('final-secrets',['bash','scripts/check-secrets.sh',*staged]),('final-whitespace',['git','diff','--cached','--check'])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    assert result.returncode==0,name
with (out/'commit.stdout').open('wb') as stdout,(out/'commit.stderr').open('wb') as stderr:subprocess.run(['git','-c','gc.auto=0','commit','-m','Preserve native test identities while extracting follow-up assertions'],cwd=root,stdout=stdout,stderr=stderr,check=True)
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=root,text=True)
outcome={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'committed':True,'pushed':False,'trackedWorkingTreeClean':True,'records':len(records),'fullIssueComplete':False};(out/'commit-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))
