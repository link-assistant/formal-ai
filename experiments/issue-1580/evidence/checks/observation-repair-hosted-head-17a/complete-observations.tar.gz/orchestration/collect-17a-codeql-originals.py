import collections
import datetime
import gzip
import hashlib
import json
import re
import subprocess
import time
import zipfile
from pathlib import Path

root = Path('/tmp/issue-1580-research/codeql-17a-originals-complete')
root.mkdir(exist_ok=True)
repo = 'link-assistant/formal-ai'
run_id = 45103329305
head = '17a3431f187c7dd5a12d71ce1aa6bcd966d62994'
repository = Path.cwd()
records = []

def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(65536), b''):
            result.update(chunk)
    return result.hexdigest()

def capture(label, arguments, parsed=False):
    destination = root / label
    with destination.open('wb') as output, (root / (label + '.stderr')).open('wb') as errors:
        result = subprocess.run(arguments, stdout=output, stderr=errors)
    records.append({'path': label, 'command': arguments, 'exitCode': result.returncode,
                    'bytes': destination.stat().st_size, 'sha256': digest(destination)})
    (root / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    result.check_returncode()
    return json.loads(destination.read_text()) if parsed else destination

try:
    for observation in range(180):
        run = capture('run.json', ['gh', 'api', '--allow-escape-sequences', f'repos/{repo}/actions/runs/{run_id}'], True)
        assert run['head_sha'] == head and run['run_attempt'] == 1
        print(observation, run['status'], run['conclusion'], flush=True)
        if run['status'] == 'completed':
            break
        time.sleep(30)
    else:
        raise RuntimeError('CodeQL producer has not completed within the observation budget')
    assert run['conclusion'] == 'success'
    jobs = capture('jobs.json', ['gh', 'api', '--allow-escape-sequences', f'repos/{repo}/actions/runs/{run_id}/jobs?per_page=100', '--paginate', '--slurp'], True)
    pages = capture('artifacts.json', ['gh', 'api', '--allow-escape-sequences', f'repos/{repo}/actions/runs/{run_id}/artifacts?per_page=100', '--paginate', '--slurp'], True)
    artifacts = [item for page in pages for item in page['artifacts']]
    selected = [item for item in artifacts if item['name'].startswith(('codeql-results-', 'codeql-rust-contexts'))]
    print('artifacts', [(item['id'], item['name'], item['size_in_bytes']) for item in selected], flush=True)
    assert len(selected) == 3
    sarif = []
    included = None
    members = []
    for artifact in selected:
        assert artifact['workflow_run']['head_sha'] == head and not artifact['expired']
        archive = capture(f'artifact-{artifact["id"]}.zip', ['gh', 'api', '--allow-escape-sequences', f'repos/{repo}/actions/artifacts/{artifact["id"]}/zip'])
        with zipfile.ZipFile(archive) as source:
            for info in source.infolist():
                assert not info.is_dir()
                hasher = hashlib.sha256()
                size = 0
                with source.open(info) as stream:
                    for chunk in iter(lambda: stream.read(65536), b''):
                        hasher.update(chunk)
                        size += len(chunk)
                assert size == info.file_size
                members.append({'artifactId': artifact['id'], 'path': info.filename,
                                'bytes': size, 'sha256': hasher.hexdigest()})
                if info.filename.endswith('.sarif'):
                    for result in json.loads(source.read(info))['runs']:
                        invocations = result.get('invocations', [])
                        levels = collections.Counter(n.get('level', 'warning') for invocation in invocations for n in invocation.get('toolExecutionNotifications', []))
                        assert invocations and all(i.get('executionSuccessful') is True for i in invocations)
                        assert not levels.get('error') and not levels.get('warning')
                        sarif.append({'artifactId': artifact['id'], 'path': info.filename,
                                      'results': len(result.get('results', [])), 'notificationLevels': dict(levels),
                                      'executionSuccessful': True})
                if info.filename.endswith('included-string-payloads.json'):
                    assert included is None
                    raw = source.read(info)
                    included = json.loads(raw)['#select']['tuples']
                    included_digest = hashlib.sha256(raw).hexdigest()
                    del raw
    assert included is not None and len(sarif) == 2
    cache = {}
    def blob(path):
        if path not in cache:
            result = subprocess.run(['git', 'show', head + ':' + path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            cache[path] = result.stdout if result.returncode == 0 else None
        return cache[path]
    counts = collections.Counter()
    comparisons = []
    for row in included:
        if row[6] != 'literal-expansion':
            continue
        file = row[1].split('/formal-ai/formal-ai/')[-1]
        if file.startswith('/') or '..' in Path(file).parts:
            counts['non-repository-location'] += 1
            continue
        original = blob(file)
        if original is None:
            counts['source-unavailable'] += 1
            continue
        text = original.decode()
        lines = text.splitlines(keepends=True)
        if not 1 <= row[2] <= len(lines):
            counts['unbound-span'] += 1
            continue
        start = sum(map(len, lines[:row[2] - 1])) + row[3] - 1
        match = re.match(r'include_str!\s*\(\s*"([^"\n]+)"\s*\)', text[start:])
        if match is None:
            counts['non-literal-or-unbound-span'] += 1
            continue
        target = (repository / file).parent / match.group(1)
        try:
            path = str(target.resolve().relative_to(repository))
        except ValueError:
            counts['outside-source-root'] += 1
            continue
        expected = blob(path)
        if expected is None:
            counts['included-source-unavailable'] += 1
            continue
        try:
            literal = json.loads(row[7])
        except (ValueError, TypeError):
            counts['literal-requires-rust-decoder'] += 1
            continue
        if not isinstance(literal, str):
            counts['non-string-token'] += 1
            continue
        observed = literal.encode()
        state = 'matches-exact-source' if observed == expected else ('empty-expansion-of-nonempty-source' if not observed and expected else 'differs-from-exact-source')
        counts[state] += 1
        comparisons.append({'file': file, 'line': row[2], 'column': row[3], 'included': path,
                            'sourceBytes': len(expected), 'sourceSha256': hashlib.sha256(expected).hexdigest(),
                            'decodedBytes': len(observed), 'decodedSha256': hashlib.sha256(observed).hexdigest(),
                            'comparison': state, 'cfg': row[8]})
    report = {'source': head, 'runId': run_id, 'attempt': 1, 'rows': len(included),
              'queryResultSha256': included_digest,
              'states': dict(collections.Counter(row[6] for row in included)),
              'controlFlow': dict(collections.Counter(row[8] for row in included)),
              'files': len({row[1] for row in included}), 'literalComparisonCounts': dict(counts),
              'sarif': sarif, 'comparisons': comparisons,
              'scope': 'Exact immutable source spans, literal relative paths and JSON-compatible tokens only; context rows are not unique calls or a security coverage percentage.',
              'semanticCoverageProven': False, 'independentAuthorshipCredit': 0}
    (root / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
    (root / 'members.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in members))
    capture('complete.log', ['gh', 'run', 'view', str(run_id), '--repo', repo, '--log'])
    with (root / 'complete.log').open('rb') as original, gzip.GzipFile(filename='', fileobj=(root / 'complete.log.gz').open('wb'), mode='wb', mtime=0) as packed:
        for chunk in iter(lambda: original.read(65536), b''):
            packed.write(chunk)
    (root / 'complete.log').unlink()
    (root / 'outcome.json').write_text(json.dumps({'complete': True, 'report': {k: v for k, v in report.items() if k != 'comparisons'}, 'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'comparisons'}), flush=True)
except BaseException as error:
    (root / 'failed.json').write_text(json.dumps({'error': str(error)}, indent=2) + '\n')
    raise
