import gzip, hashlib, json, subprocess
from pathlib import Path

root=Path('/tmp/issue-1580-research/observation-repair-audit-jobs')
root.mkdir(exist_ok=True)
records=[]
for identity in [137458927677,137458833268]:
 command=['gh','api','--allow-escape-sequences','repos/link-assistant/formal-ai/actions/jobs/'+str(identity)+'/logs']
 result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 errorfile=root/(str(identity)+'.stderr')
 if errorfile.exists():errorfile.rename(root/(str(identity)+'.first.stderr'))
 errorfile.write_bytes(result.stderr)
 result.check_returncode()
 payload=result.stdout
 (root/(str(identity)+'.log.gz')).write_bytes(gzip.compress(payload,mtime=0))
 lines=payload.decode(errors='replace').splitlines()
 selected=[{'line':i,'text':line} for i,line in enumerate(lines,1) if any(term in line for term in ['Auditing ','registry observation incomplete','emitted an error','error:','allowed warning','RUSTSEC-'])]
 row={'job':identity,'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),'lines':len(lines),'observations':selected}
 records.append(row)
 print(json.dumps(row))
(root/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
