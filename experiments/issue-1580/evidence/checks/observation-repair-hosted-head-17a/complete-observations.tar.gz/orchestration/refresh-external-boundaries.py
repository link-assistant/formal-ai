import json, subprocess
from pathlib import Path

root=Path('/tmp/issue-1580-research/external-boundaries-20261123')
root.mkdir(exist_ok=True)
for repo,number in [('link-assistant/hive-mind',3909),('link-assistant/calculator',265),('github/codeql',23198)]:
 command=['gh','issue','view',str(number),'--repo',repo,'--json','title,body,state,comments,url,updatedAt']
 result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 name=repo.replace('/','-')+'-'+str(number)
 (root/(name+'.json')).write_bytes(result.stdout)
 (root/(name+'.stderr')).write_bytes(result.stderr)
 result.check_returncode();issue=json.loads(result.stdout)
 print(issue['url'],issue['state'],issue['updatedAt'],issue['title'])
 print('BODY',issue['body'])
 for comment in issue['comments'][-3:]:print('COMMENT',comment['url'],comment['createdAt'],comment['body'])
