from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'lexeme-shard-files-extraction'
if len(sys.argv) == 1:
    out.mkdir(exist_ok=False)
    with (out / 'worker.log').open('wb') as stream:
        worker = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print('Started finite shard file source extraction', worker.pid)
    raise SystemExit()
records = []
def run(name, argv):
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=root, env={**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}, stdout=stdout, stderr=stderr)
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == 0, name
    return (out / (name + '.stdout')).read_text()
assert json.loads((scratch / 'unknown-reasoning-text-extraction-second/outcome.json').read_text())['passed']
assert not run('index-before', ['git', 'diff', '--cached', '--name-only']).strip()
assert run('branch', ['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
parent = root / 'rust/src/lexeme_import.rs'
child = root / 'rust/src/lexeme_import/shard_files.rs'
assert not child.exists()
original = parent.read_text()
assert len(original.splitlines()) == 912
start_marker = '/// Replace the complete generated shard set without leaving stale files.'
end_marker = 'fn escape_lino(text: &str) -> String {'
start = original.index(start_marker)
end = original.index(end_marker, start)
block = original[start:end]
assert block.count('pub fn ') == 1 and block.endswith('\n\n')
child_imports = 'use std::fs;\nuse std::path::Path;\n\nuse super::{Shard, diagnostic};\n\n'
new_child = child_imports + block[:-1]
new_parent = (original[:start] + original[end:]).replace('mod notation;\n', 'mod notation;\nmod shard_files;\n').replace('use cache_trim::{serialize_trimmed, trim_entity};\n', 'use cache_trim::{serialize_trimmed, trim_entity};\npub use shard_files::write_shards;\n')
restored_parent = new_parent.replace('mod shard_files;\n', '').replace('pub use shard_files::write_shards;\n', '')
restored = restored_parent.replace(end_marker, new_child.removeprefix(child_imports) + '\n' + end_marker)
assert restored == original
parent.write_text(new_parent)
child.write_text(new_child)
proof = {'observedAt': datetime.now(timezone.utc).isoformat(), 'originalSha256': hashlib.sha256(original.encode()).hexdigest(), 'reassembledOriginalSha256': hashlib.sha256(restored.encode()).hexdigest(), 'originalLines': 912, 'parentLines': len(new_parent.splitlines()), 'childLines': len(new_child.splitlines()), 'exactOriginalReconstruction': True, 'publicFunctionReexportedAtOriginalPath': 'formal_ai::lexeme_import::write_shards', 'localRustExecution': False, 'hostedNativeVerificationPending': True, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
assert proof['parentLines'] < 900 and proof['childLines'] < 900
(out / 'inverse-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
(out / 'original-source.rs.gz').write_bytes(gzip.compress(original.encode(), mtime=0))
source_paths = [str(path.relative_to(root)) for path in [parent, child]]
run('rust-format', ['rustfmt', '--edition', '2024', '--check', *source_paths])
run('lexeme-projection-javascript', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/lexeme-import-notation.test.mjs'])
archive = root / 'experiments/issue-1580/evidence/checks/lexeme-shard-files-extraction'
archive.mkdir(exist_ok=False)
entries = []
for path in sorted([Path(__file__), *[path for path in out.iterdir() if path.is_file() and path.name != 'worker.log']]):
    raw = path.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    target = archive / (path.name + '.gz')
    target.write_bytes(packed)
    entries.append({'file': target.name, 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
(archive / 'records.json').write_text(json.dumps({'entries': entries, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
fragment = root / 'changelog.d/issue-1580-computer-use-content.md'
fragment.write_text(fragment.read_text() + '\nKeep lexeme importing below its source-size warning threshold by separating unchanged shard installation and stale-file removal, with the existing public function reexported at its original path.\n')
plan = root / 'experiments/issue-1580/work-plan.md'
plan.write_text(plan.read_text() + '\n- Split unchanged lexeme shard installation into a private module and reexport `write_shards` at its existing public path. Exact source reconstruction preserves staging, rename, retained-file selection, error diagnostics and stale importer-owned removal. Existing JavaScript shard projection checks and Rust formatting pass. Native execution and remaining source warnings are still open; no broader acceptance or independent authorship credit.\n')
selected = [*source_paths, str(archive.relative_to(root)), str(fragment.relative_to(root)), str(plan.relative_to(root))]
run('stage-source-evidence', ['git', 'add', '--', *selected])
run('size-and-readability-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code'])
inputs = []
for relative in selected:
    path = root / relative
    inputs.extend(item.relative_to(root).as_posix() for item in sorted(path.rglob('*')) if item.is_file()) if path.is_dir() else inputs.append(relative)
run('secrets', ['bash', 'scripts/check-secrets.sh', *inputs])
run('whitespace', ['git', 'diff', '--cached', '--check'])
run('commit', ['git', 'commit', '-m', 'refactor: separate lexeme shard installation below size warning'])
head = run('head', ['git', 'rev-parse', 'HEAD']).strip()
(out / 'outcome.json').write_text(json.dumps({'passed': True, 'head': head, 'parentLines': proof['parentLines'], 'childLines': proof['childLines'], 'pushExecuted': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
