from pathlib import Path
import hashlib, json

source = Path('/tmp/issue-1580-research/templates/rust-complete')
base = Path('/tmp/issue-1580-research/rust-client-entropy-history')
base.mkdir(exist_ok=False)
rows = []
for name in ['getrandom-changelog.txt', 'ureq-changelog.txt']:
    path = 'dev/log/issues/247/pulls/248/' + name
    raw = (source / path).read_bytes()
    text = raw.decode()
    digest = hashlib.sha256(raw).hexdigest()
    rendered = 'FILE ' + path + ' LINES ' + str(len(text.splitlines())) + ' SHA256 ' + digest + '\n'
    rendered += ''.join(str(index) + ': ' + line + '\n' for index, line in enumerate(text.splitlines(), 1))
    target = base / (name + '.read.txt')
    target.write_text(rendered)
    rows.append({'path': path, 'sha256': digest, 'bytes': len(raw), 'sourceLines': len(text.splitlines()),
        'renderedFile': target.name})
(base / 'sources.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows, indent=2))
