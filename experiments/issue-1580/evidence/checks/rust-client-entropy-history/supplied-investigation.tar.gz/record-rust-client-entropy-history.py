from pathlib import Path
import datetime, gzip, hashlib, io, json, tarfile, tomllib

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
source = scratch / 'templates/rust-complete'
paths = ['dev/log/issues/247/pulls/248/' + name for name in ['getrandom-changelog.txt', 'ureq-changelog.txt']]
inventory = json.loads((root / 'experiments/issue-1580/evidence/checks/rust-template-first-gate/pinned-file-identities.json').read_text())
identities = {row['path']: row for row in inventory}
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert data['fullyReadFiles'] == 330
manifest = root / data['readLogManifest']
records = json.loads(manifest.read_text())
for path in paths:
    assert path not in {row['path'] for row in data['files']}
    raw = (source / path).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    lines = len(raw.decode().splitlines())
    assert digest == identities[path]['sha256']
    read = (scratch / 'rust-client-entropy-history' / (Path(path).name + '.read.txt')).read_bytes()
    assert digest in read.decode()
    name = 'client-entropy-history-' + Path(path).name + '.read.txt.gz'
    packed = gzip.compress(read, mtime=0)
    assert not (manifest.parent / name).exists()
    (manifest.parent / name).write_bytes(packed)
    records.append({'file': name, 'rawSha256': hashlib.sha256(read).hexdigest(),
        'archiveSha256': hashlib.sha256(packed).hexdigest()})
    data['files'].append({'path': path, 'lines': lines, 'sha256': digest, 'readLogs': [name],
        'literalReadRanges': [[1, lines]], 'literalReadLines': lines, 'literalSourceFullyRead': True,
        'formalAiPracticeImplementationVerified': False})
manifest.write_text(json.dumps(records, indent=2) + '\n')
data['files'].sort(key=lambda row: row['path'])
data['fullyReadFiles'] = len(data['files'])
data['fullyReadSourceLines'] = sum(row['literalReadLines'] for row in data['files'])
assert data['fullyReadFiles'] == 332 and data['fullyReadSourceLines'] == 39009
data['observedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
data['practiceDecisions'].append({'practice': 'Check dependency migrations and runtime budgets against actual consumers',
    'templateEvidence': paths,
    'assessment': 'Read all 760 getrandom and 602 ureq changelog lines. The retained getrandom history distinguishes 0.4.3 release from an unreleased 0.4.4; its 0.3 migration renames fill APIs, changes custom/JavaScript backend selection and raises target requirements. The ureq history changes status/error handling and request/agent APIs across majors, and records fixes for decompression body limits, remaining global/connect/SOCKS/TLS budgets, redirects, pooling, cancellation and credentials. These are historical source claims, not current runtime observations. Current Formal AI does not declare either crate directly; transitive lock entries are recorded separately. Do not add unused template dependencies or infer elapsed-budget/body-limit correctness from a version string. Current runtime counterparts and transitive feature qualification remain open.',
    'status': 'complete-entropy-and-http-client-history-read-runtime-adoption-open',
    'formalAiPaths': ['rust/Cargo.toml', 'rust/Cargo.lock', 'scripts/recheck-links.mjs'],
    'verification': 'experiments/issue-1580/evidence/checks/rust-client-entropy-history/assessment.json'})
ledger.write_text(json.dumps(data, indent=2) + '\n')
destination = root / 'experiments/issue-1580/evidence/checks/rust-client-entropy-history'
destination.mkdir(exist_ok=False)
selected = [Path(__file__), scratch / 'read-rust-client-entropy-history.py',
    scratch / 'read-rust-client-entropy-history.log', scratch / 'compare-client-entropy-uses.log',
    scratch / 'compare-client-entropy-uses-corrected.log']
selected += [path for path in (scratch / 'rust-client-entropy-history').rglob('*') if path.is_file()]
for name in ['rust/Cargo.toml', 'rust/Cargo.lock']:
    raw = (root / name).read_bytes()
    (destination / (Path(name).name + '.source.gz')).write_bytes(gzip.compress(raw, mtime=0))
buffer = io.BytesIO()
rows = []
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for path in sorted(selected):
        raw = path.read_bytes()
        name = path.relative_to(scratch).as_posix()
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
        archive.addfile(entry, io.BytesIO(raw))
        rows.append({'file': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
raw = buffer.getvalue()
packed = gzip.compress(raw, mtime=0)
(destination / 'supplied-investigation.tar.gz').write_bytes(packed)
(destination / 'supplied-investigation.json').write_text(json.dumps({'files': rows,
    'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(),
    'independentAuthorshipCredit': 0, 'fullIssueComplete': False}, indent=2) + '\n')
locked = tomllib.loads((root / 'rust/Cargo.lock').read_text())
packages = [{key: row[key] for key in ['name', 'version', 'source', 'checksum'] if key in row}
    for row in locked['package'] if row['name'] in ['getrandom', 'ureq']]
(destination / 'assessment.json').write_text(json.dumps({'literalPinnedFilesRead': 332,
    'literalPinnedLinesRead': 39009, 'sourceFiles': paths, 'directDeclarations': [],
    'resolvedPackages': packages, 'resolvedFeatureRuntimeQualified': False,
    'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- Complete pinned getrandom and ureq histories add 1,362 literally read lines: Rust review is 332/373 files, 39,009 lines. API/backend and global timeout/decoded body-limit changes require real consumer checks; current direct manifests do not declare either crate. Original lock identities and transitive entries are retained without feature/runtime acceptance credit. All broader work remains open.\n')
print(json.dumps({'literalFilesRead': 332, 'literalLinesRead': 39009, 'resolvedPackages': packages,
    'fullIssueComplete': False}, indent=2))
