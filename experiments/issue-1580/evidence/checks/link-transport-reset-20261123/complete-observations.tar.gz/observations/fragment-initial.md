### Tests

- Verify bounded link recovery against real early TLS and post-request connection resets, including recovery only after a later HTTP success.
