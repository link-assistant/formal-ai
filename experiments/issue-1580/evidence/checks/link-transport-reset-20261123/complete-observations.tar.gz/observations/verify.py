from pathlib import Path
import datetime,json,os,resource,subprocess,time
root=Path('/tmp/issue-1580-research/link-transport-reset-20261123')
env=os.environ.copy();env.pop('NODE_OPTIONS',None)
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
checks=[
 ('maintained-owner',['node','--max-old-space-size=512','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs']),
 ('affected-gates',['node','--max-old-space-size=512','experiments/formal_ai_subagent/local-gates.mjs','--only','check-status-render,check-render-status-js-twin,check-generate-requirement-status-js-twin,check-required-documentation,check-readable-code,check-file-size,check-file-size-js-twin,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-changelog-fragment-js-twin,check-twin-citations']),
 ('whitespace',['git','diff','--check'])
]
records=[]
for name,command in checks:
 start=time.monotonic()
 with (root/(name+'.stdout')).open('wb') as out,(root/(name+'.stderr')).open('wb') as err:
  result=subprocess.run(command,stdout=out,stderr=err,env=env)
 records.append({'name':name,'command':command,'exitCode':result.returncode,'seconds':time.monotonic()-start,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 (root/'checks.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(records[-1]),flush=True)
(root/'outcome.json').write_text(json.dumps({'complete':True,'passed':all(r['exitCode']==0 for r in records),'checks':len(records),'noLocalRustBuild':True},indent=2)+'\n')
