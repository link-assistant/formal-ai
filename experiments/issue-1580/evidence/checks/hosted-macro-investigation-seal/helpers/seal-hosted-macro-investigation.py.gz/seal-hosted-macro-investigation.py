from pathlib import Path
import hashlib, json, os, shutil, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/sealed-hosted-macro-investigation')
base.mkdir(exist_ok=False)
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
records = []
def run(name, argv):
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
    for label in ['stdout', 'stderr']:
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, (name, result.stdout.decode(errors='replace')[-3000:], result.stderr.decode(errors='replace')[-1000:])
    return result.stdout
run('gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only',
    'check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code'])
for name in ['check-abbreviations', 'check-file-size-js-twin', 'check-file-size', 'check-readable-code']:
    shutil.copyfile(root / 'experiments/formal_ai_subagent/sandboxes/gates' / (name + '.log'),
                    base / (name + '.log'))
run('whitespace', ['git', 'diff', '--check'])
modified = run('modified-selection', ['git', 'diff', '--name-only', '--diff-filter=ACMRTUXB', '-z']).split(b'\0')
untracked = run('untracked-selection', ['git', 'ls-files', '--others', '--exclude-standard', '-z']).split(b'\0')
paths = sorted({item.decode() for item in modified + untracked if item})
assert paths
rows = []
for path in paths:
    raw = (root / path).read_bytes()
    rows.append({'path': path, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
(base / 'selection.json').write_text(json.dumps(rows, indent=2) + '\n')
run('secrets', ['bash', 'scripts/check-secrets.sh', *paths])
for row in rows:
    raw = (root / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
(base / 'outcome.json').write_text(json.dumps({'complete': True, 'passed': True,
    'selectedFiles': len(rows), 'pushExecuted': False, 'fullIssueComplete': False}, indent=2) + '\n')
print('Four final archive gates, whitespace and exact', len(rows), 'input secret scan pass; no push.')
