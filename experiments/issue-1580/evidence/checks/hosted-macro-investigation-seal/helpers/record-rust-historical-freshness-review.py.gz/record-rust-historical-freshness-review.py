from pathlib import Path
import datetime, gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
source = Path('/tmp/issue-1580-research/templates/rust-complete')
paths = ['dev/log/issues/247/pulls/248/issue-comments.json',
    'dev/log/issues/247/pulls/248/issue-comments-final.json',
    'docs/case-studies/issue-52/raw-data/js-issue-62.json',
    'docs/case-studies/issue-52/raw-data/vk-bot-desktop-issue-51.json']
identities = {row['path']: row for row in json.loads((root / 'experiments/issue-1580/evidence/checks/rust-template-first-gate/pinned-file-identities.json').read_text())}
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert data['fullyReadFiles'] == 313
manifest = root / data['readLogManifest']
records = json.loads(manifest.read_text())
base = manifest.parent
for path in paths:
    assert path not in {row['path'] for row in data['files']}
    raw = (source / path).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == identities[path]['sha256'] and len(raw.decode().splitlines()) == 1
    name = 'freshness-history-' + Path(path).name + '.read.txt.gz'
    read = ('FILE ' + path + ' LINES 1 SHA256 ' + digest + '\n1: ' + raw.decode().rstrip('\n') + '\n').encode()
    packed = gzip.compress(read, mtime=0)
    assert not (base / name).exists()
    (base / name).write_bytes(packed)
    records.append({'file': name, 'rawSha256': hashlib.sha256(read).hexdigest(),
                    'archiveSha256': hashlib.sha256(packed).hexdigest()})
    data['files'].append({'path': path, 'lines': 1, 'sha256': digest, 'readLogs': [name],
        'literalReadRanges': [[1, 1]], 'literalReadLines': 1, 'literalSourceFullyRead': True,
        'formalAiPracticeImplementationVerified': False})
manifest.write_text(json.dumps(records, indent=2) + '\n')
data['files'].sort(key=lambda row: row['path'])
data['fullyReadFiles'] = len(data['files'])
data['fullyReadSourceLines'] = sum(row['literalReadLines'] for row in data['files'])
data['observedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
data['practiceDecisions'].append({'practice': 'Bind CI freshness and preview claims to actual dated observations',
    'templateEvidence': paths,
    'assessment': 'Read both complete historical issue-comment snapshots: the previously in-progress main runs later split into successful desktop/workflow examples and failed Security/CI, so initial status is not final proof. Read the complete historical JavaScript screenshot-hook proposal and original desktop request. Capture locale/theme and served visual identity from a real browser, preserve optional DOM probes, and separate release push-back from PR artifact evidence. The historical downstream closed state and upstream proposal do not prove a current template hook or current Formal AI delivery. These embedded historical issue requests are comparison evidence, not new required sub-issues of #1580. Formal AI already retains bounded browser and visual artifacts, while real release screenshot refresh/publication/served identity remain unverified.',
    'status': 'complete-historical-snapshots-read-current-runtime-qualification-open',
    'formalAiPaths': ['.github/workflows/ci.yml', '.github/workflows/desktop-release.yml',
                      'docs/screenshots/issue-1580'], 'verification': None})
ledger.write_text(json.dumps(data, indent=2) + '\n')
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- Four more complete pinned Rust historical snapshots are read and identity-verified: 317/373 files, 37,634 literal lines, 56 remaining. Preserve final-versus-running CI distinctions and browser locale/theme/served-preview provenance. Historical closed states and proposals establish no current runtime, publication or independent reasoning credit.\n')
print('Literal review:', data['fullyReadFiles'], '/373 files;', data['fullyReadSourceLines'], 'lines; 56 remain.')
