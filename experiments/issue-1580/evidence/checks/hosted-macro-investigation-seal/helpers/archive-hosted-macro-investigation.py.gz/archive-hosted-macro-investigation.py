from pathlib import Path
import gzip, hashlib, json, shutil

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
base = root / 'experiments/issue-1580/evidence/checks/hosted-macro-investigation'
base.mkdir(exist_ok=False)
records = []
def capture(name, path):
    raw = path.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    target = base / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(packed)
    assert gzip.decompress(packed) == raw
    records.append({'file': target.relative_to(base).as_posix(),
        'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(),
        'bytes': len(raw), 'lines': len(raw.splitlines())})
folders = ['macro-security-jobs', 'macro-security-dispatch-jobs', 'script-admission-batch-feedback',
    'macro-security-fingerprint', 'reviewed-security-fingerprint-commit', 'script-suite-source-commit',
    'hosted-macro-query-memory', 'hosted-macro-memory-validation', 'hosted-macro-memory-final-checks',
    'new-archive-gate-failures', 'new-producer-archive-layout', 'compiled-include-macro-contexts']
for folder in folders:
    directory = scratch / folder
    assert directory.exists(), folder
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            capture(folder + '/' + path.relative_to(directory).as_posix(), path)
helpers = ['draft-script-suite-admission-test', 'check-script-suite-negative-control',
    'implement-script-suite-admission', 'validate-script-suite-admission', 'commit-script-suite-admission',
    'observe-macro-security-jobs', 'repair-macro-security-fingerprint', 'commit-reviewed-security-fingerprint',
    'start-script-and-fingerprint-gates', 'start-macro-producer-report-collection', 'collect-macro-producer-reports',
    'inspect-macro-batch-feedback-and-queue', 'assess-hosted-macro-observations',
    'assess-hosted-macro-observations-before-default-column', 'assess-hosted-macro-observations-before-final-record',
    'assess-hosted-macro-observations-before-closing-lines', 'correct-sarif-default-column-crosswalk',
    'correct-macro-table-final-record', 'correct-macro-table-closing-lines', 'inspect-compiled-include-macro-contexts',
    'repair-hosted-macro-query-memory', 'finish-hosted-macro-memory-validation',
    'inspect-new-archive-gate-failures', 'repair-new-producer-archive-layout', 'finish-macro-memory-source-commit',
    'assess-partitioned-hosted-macro-observations', 'document-hosted-macro-results',
    'download-actionlint-template-image', 'record-rust-upstream-controls-review',
    'download-macro-template-image', 'download-macro-template-image-worker', 'record-rust-macro-report-review']
for stem in helpers:
    for suffix in ['.py', '.log', '.stdout', '.stderr']:
        path = scratch / (stem + suffix)
        if path.is_file():
            capture('helpers/' + path.name, path)
for start in range(0, len(records), 150):
    selected = records[start:start + 150]
    raw = (json.dumps(selected, indent=2) + '\n').encode()
    assert len(raw.splitlines()) <= 1400
    (base / ('records-part-' + str(start // 150 + 1) + '.json')).write_bytes(raw)
parts = [{'file': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
         for path in sorted(base.glob('records-part-*.json'))]
(base / 'records.json').write_text(json.dumps({'records': len(records), 'parts': parts,
    'independentAuthorshipCredit': 0, 'fullIssueComplete': False}, indent=2) + '\n')
for row in records:
    packed = (base / row['file']).read_bytes()
    assert hashlib.sha256(packed).hexdigest() == row['archiveSha256']
    raw = gzip.decompress(packed)
    assert hashlib.sha256(raw).hexdigest() == row['rawSha256']
    assert len(raw) == row['bytes'] and len(raw.splitlines()) == row['lines']
print('Archived and verified', len(records), 'investigation records in', len(parts), 'readable manifest parts.')
