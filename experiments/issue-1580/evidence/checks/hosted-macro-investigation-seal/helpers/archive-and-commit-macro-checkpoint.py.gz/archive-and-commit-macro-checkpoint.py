from collections import Counter
from pathlib import Path
import gzip, hashlib, json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
base = root / 'experiments/issue-1580/evidence/checks/hosted-macro-investigation-seal'
base.mkdir(exist_ok=False)
records = []
def capture(name, path):
    raw = path.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    target = base / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(packed)
    assert gzip.decompress(packed) == raw
    records.append({'file': target.relative_to(base).as_posix(), 'bytes': len(raw),
        'lines': len(raw.splitlines()), 'rawSha256': hashlib.sha256(raw).hexdigest(),
        'archiveSha256': hashlib.sha256(packed).hexdigest()})
sealed = scratch / 'sealed-hosted-macro-investigation'
assert json.loads((sealed / 'outcome.json').read_text())['passed']
for path in sorted(sealed.iterdir()):
    if path.is_file():
        capture('validation/' + path.name, path)
for stem in ['archive-hosted-macro-investigation', 'seal-hosted-macro-investigation',
             'record-rust-historical-freshness-review', 'assess-partitioned-hosted-macro-observations',
             'archive-and-commit-macro-checkpoint']:
    for suffix in ['.py', '.log']:
        path = scratch / (stem + suffix)
        if path.exists() and path.stat().st_size:
            capture('helpers/' + path.name, path)
(base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
def run(name, argv):
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
    for label in ['stdout', 'stderr']:
        (scratch / ('macro-checkpoint-' + name + '.' + label)).write_bytes(getattr(result, label))
    assert result.returncode == 0, (name, result.stdout.decode(errors='replace')[-2500:], result.stderr.decode(errors='replace')[-1000:])
    return result.stdout
ledger_path = 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
old = json.loads(run('old-ledger', ['git', 'show', 'HEAD:' + ledger_path]))
new = json.loads((root / ledger_path).read_text())
assert old['fullyReadFiles'] == 309 and new['fullyReadFiles'] == 317
by_path = {row['path']: row for row in new['files']}
assert all(by_path[row['path']] == row for row in old['files'])
assert new['practiceDecisions'][:len(old['practiceDecisions'])] == old['practiceDecisions']
old_plan = run('old-plan', ['git', 'show', 'HEAD:experiments/issue-1580/work-plan.md']).decode()
plan = (root / 'experiments/issue-1580/work-plan.md').read_text()
history = (root / 'experiments/issue-1580/work-plan-history-through-native-interface.md').read_text()
old_lines = Counter(line for line in old_plan.splitlines() if line.strip())
new_lines = Counter(line for line in (plan + '\n' + history).splitlines() if line.strip())
assert all(new_lines[line] >= count for line, count in old_lines.items())
assert run('branch', ['git', 'branch', '--show-current']).decode().strip() == 'issue-1580-8d61a32a61e1'
paths = [str(path.relative_to(root)) for path in base.rglob('*') if path.is_file()]
run('new-seal-secrets', ['bash', 'scripts/check-secrets.sh', *paths])
run('whitespace', ['git', 'diff', '--check'])
selection = json.loads((sealed / 'selection.json').read_text())
static = []
for row in selection:
    if row['path'].startswith('experiments/issue-1580/evidence/ci/native-families-39196d1f/'):
        continue
    raw = (root / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'], row['path']
    static.append(row['path'])
run('stage', ['git', 'add', '--', *static, *paths])
run('staged-whitespace', ['git', 'diff', '--cached', '--check'])
run('commit', ['git', 'commit', '-m', 'docs: retain hosted macro results and original script admission evidence'])
head = run('head', ['git', 'rev-parse', 'HEAD']).decode().strip()
(scratch / 'macro-checkpoint-commit-outcome.json').write_text(json.dumps({'complete': True,
    'head': head, 'pushExecuted': False, 'originalProsePreserved': True,
    'oldReviewEntriesPreserved': True, 'fullIssueComplete': False}, indent=2) + '\n')
print('Reviewed and committed static evidence:', head, '; active CI collector excluded; no push.')
