import json,os,pathlib,subprocess,time,hashlib
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');out=pathlib.Path('/tmp/issue-1580-research/rust-observation-validation')
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512'
commands=[('current-pipeline-jobs',['gh','api','repos/link-assistant/formal-ai/actions/runs/44887270503/jobs?per_page=100','--paginate']),('maintained',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])]
commands += [(name,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',name]) for name in ['check-abbreviations','check-file-size','check-tests-as-docs']]
commands += [('whitespace',['git','diff','--check'])]
rows=[]
for name,argv in commands:
    started=time.time()
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:run=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'argv':argv,'exitCode':run.returncode,'seconds':round(time.time()-started,3)}
    for stream in ['stdout','stderr']:
        data=(out/(name+'.'+stream)).read_bytes();row[stream]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    rows.append(row);(out/'records.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
(out/'outcome.json').write_text(json.dumps({'allPassed':all(row['exitCode']==0 for row in rows),'commands':len(rows),'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
