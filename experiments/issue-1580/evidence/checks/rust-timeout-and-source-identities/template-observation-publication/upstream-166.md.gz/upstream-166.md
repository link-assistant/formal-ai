The maintained finite regression source is now published: https://github.com/link-assistant/formal-ai/blob/84e1ad85fc70541ae64c59a8518dbce59b883e64/experiments/issue-1580/template-python-javascript-detection.test.mjs .

The complete local template-observation entry passes all 126 cases with zero skips. The observations execute the pinned helpers and disposable candidate controls; no upstream repair is claimed. They are included in https://github.com/link-assistant/formal-ai/pull/1581 .
