import json,pathlib,subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');out=pathlib.Path('/tmp/issue-1580-research/template-source-identities')
test=root/'experiments/issue-1580/template-source-identities.test.mjs'
test.write_text('''// Keep source pins usable as complete Git SHA1 identities.
import assert from 'node:assert/strict';
import {readdirSync, readFileSync} from 'node:fs';
import test from 'node:test';

test('reviewed template ledgers and the timeout fixture use complete Git commit identities', () => {
  const directory = new URL('../../docs/case-studies/issue-1580/templates/', import.meta.url);
  let checked = 0;
  for (const name of readdirSync(directory).filter(name => name.endsWith('.json'))) {
    const value = JSON.parse(readFileSync(new URL(name, directory), 'utf8'));
    if (value && !Array.isArray(value) && value.commit) {
      assert.match(value.commit, /^[a-f0-9]{40}$/, name + ' commit must be a complete SHA1');
      checked++;
    }
  }
  assert.ok(checked >= 14, 'all retained current and historical review ledgers are included');
  const fixture = JSON.parse(readFileSync(new URL('./fixtures/rust-timeout-documentation/manifest.json', import.meta.url), 'utf8'));
  assert.match(fixture.reviewedPin, /^[a-f0-9]{40}$/);
  assert.match(fixture.currentHead, /^[a-f0-9]{40}$/);
  assert.equal(fixture.reviewedPin, fixture.currentHead);
});
''')
argv=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',str(test.relative_to(root))]
with (out/'before-regression.stdout').open('wb') as stdout,(out/'before-regression.stderr').open('wb') as stderr:before=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
assert before.returncode==1
(out/'before-regression.json').write_text(json.dumps({'exitCode':before.returncode,'expectedFailure':'41-character Rust commit identifier','authorshipCredit':0},indent=2)+'\n')
proof=json.loads((out/'rust-current-tree-validation.json').read_text());pin=proof['commit'];assert len(pin)==40 and all(row['matches'] for row in proof['fileChecks'])
ledger=root/'docs/case-studies/issue-1580/templates/rust-current-delta-review.json';value=json.loads(ledger.read_text());old=value['commit'];assert old==pin+'3'
value['commit']=pin;value['identityCorrection']={'previousRecordedIdentifier':old,'verifiedCommit':pin,'gitTree':proof['tree'],'allTwelveCurrentBlobIdentitiesMatch':True,'fullTemplateComparisonComplete':False,'evidence':'experiments/issue-1580/evidence/checks/rust-timeout-and-source-identities/'};ledger.write_text(json.dumps(value,indent=2)+'\n')
manifest=root/'experiments/issue-1580/fixtures/rust-timeout-documentation/manifest.json';value=json.loads(manifest.read_text());value['reviewedPin']=pin;value['previousRecordedIdentifier']=old;manifest.write_text(json.dumps(value,indent=2)+'\n')
timeout=root/'experiments/issue-1580/template-rust-timeout-documentation.test.mjs';text=timeout.read_text();text=text.replace("import test from 'node:test';", "import test from 'node:test';\nimport YAML from 'yaml';")
text=text.replace("const job = workflow.match(/^  test:\\n([\\s\\S]*?)(?=^  [a-z][a-z-]*:)/m)?.[1];\nassert.ok(job, 'exact pinned test-job boundary exists');\nconst actualMinutes = Number(job.match(/^    timeout-minutes: (\\d+)$/m)?.[1]);\nconst budgetSeconds = Number(job.match(/^          TEST_BUDGET_SECONDS: (\\d+)$/m)?.[1]);", "const job = YAML.parse(workflow).jobs.test;\nconst testStep = job.steps.find(step => step.name === 'Run tests');\nconst actualMinutes = job['timeout-minutes'];\nconst budgetSeconds = testStep.env.TEST_BUDGET_SECONDS;")
text=text.replace('assert.match(job, /run-with-budget-warning', 'assert.match(testStep.run, /run-with-budget-warning');assert 'workflow.match' not in text;timeout.write_text(text)
entry=root/'rust/tests/web/issue-1580-template-observations.test.mjs'
with entry.open('a') as stream:stream.write("import '../../../experiments/issue-1580/template-source-identities.test.mjs';\n")
results=[]
for name,file in [('identities',test),('timeout',timeout)]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:run=subprocess.run(['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',str(file.relative_to(root))],cwd=root,stdout=stdout,stderr=stderr)
    results.append({'name':name,'exitCode':run.returncode});assert run.returncode==0
(out/'focused-outcome.json').write_text(json.dumps({'results':results,'testsPassed':3,'allTwelveBlobIdentitiesVerified':True,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
(root/'changelog.d/issue-1580-template-source-identity.md').write_text('---\nbump: patch\n---\n\nCorrect the Rust template review commit identifier against its Git tree, verify all twelve recorded file identities, and retain maintained regressions for complete source pins and the upstream timeout documentation mismatch.\n')
print(json.dumps({'beforeFailed':True,'focusedCasesPassed':3,'verifiedCommit':pin,'currentBlobIdentitiesMatched':12,'upstreamReportPending':True,'fullIssueComplete':False}))
