import json,pathlib,subprocess
out=pathlib.Path('/tmp/issue-1580-research/rust-timeout-documentation')
repo='link-foundation/rust-ai-driven-development-pipeline-template'
for number in [41,118,135,156,172,236]:
    for kind,argv in [('issue',['gh','issue','view',str(number),'--repo',repo,'--json','number,title,body,state,url']),('comments',['gh','api',f'repos/{repo}/issues/{number}/comments','--paginate'])]:
        run=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (out/(str(number)+'-'+kind+'.stdout')).write_bytes(run.stdout)
        (out/(str(number)+'-'+kind+'.stderr')).write_bytes(run.stderr)
        assert run.returncode==0
rows=[]
for path in sorted(out.glob('*-*.stdout')):
    value=json.loads(path.read_bytes())
    entries=value if isinstance(value,list) else [value]
    for row in entries:
        body=row.get('body') or ''
        matches=[]
        for i,line in enumerate(body.splitlines()):
            if any(x in line.lower() for x in ['readme','10 minute','ten minute','documentation']):matches.append({'line':i+1,'text':line})
        rows.append({'source':path.name,'url':row.get('html_url',row.get('url')),'bodyBytes':len(body.encode()),'relevantLines':matches})
(out/'prior-discussion-index.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'records':len(rows),'index':str(out/'prior-discussion-index.json')}))
