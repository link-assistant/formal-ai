import base64,hashlib,gzip,json,pathlib,subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');out=pathlib.Path('/tmp/issue-1580-research/rust-timeout-documentation')
repo='link-foundation/rust-ai-driven-development-pipeline-template'
run=subprocess.run(['gh','api',f'repos/{repo}/commits/HEAD','--jq','.sha'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(out/'current-head.stdout').write_bytes(run.stdout);(out/'current-head.stderr').write_bytes(run.stderr);assert run.returncode==0
current=run.stdout.decode().strip();pin='5f1e7a96acbf7a93b567195443cf6e5158fbbf1f3'
sources=[]
for name,path in [('readme','README.md'),('release','.github/workflows/release.yml')]:
    run=subprocess.run(['gh','api',f'repos/{repo}/contents/{path}?ref={current}'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (out/(name+'-current.api.stdout')).write_bytes(run.stdout);(out/(name+'-current.api.stderr')).write_bytes(run.stderr);assert run.returncode==0
    value=json.loads(run.stdout);raw=base64.b64decode(value['content']);assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==value['sha']
    assert raw==(out/(name+'.source')).read_bytes(),'Source changed: review fresh content before proceeding'
    sources.append({'path':path,'file':name+'.source.gz','gitBlob':value['sha'],'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
fixture=root/'experiments/issue-1580/fixtures/rust-timeout-documentation';fixture.mkdir(exist_ok=False)
for row,name in zip(sources,['readme','release']):
    packed=gzip.compress((out/(name+'.source')).read_bytes(),mtime=0);(fixture/row['file']).write_bytes(packed);row['archiveSha256']=hashlib.sha256(packed).hexdigest()
(fixture/'manifest.json').write_text(json.dumps({'repository':repo,'reviewedPin':pin,'currentHead':current,'currentSourcesByteIdentical':True,'sources':sources},indent=2)+'\n')
test=root/'experiments/issue-1580/template-rust-timeout-documentation.test.mjs'
test.write_text('''// Static documentation consistency observation; no Cargo command is executed.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import test from 'node:test';

const directory = new URL('./fixtures/rust-timeout-documentation/', import.meta.url);
const manifest = JSON.parse(readFileSync(new URL('manifest.json', directory), 'utf8'));
function source(path) {
  const row = manifest.sources.find(row => row.path === path);
  const packed = readFileSync(new URL(row.file, directory));
  assert.equal(createHash('sha256').update(packed).digest('hex'), row.archiveSha256);
  const raw = gunzipSync(packed);
  assert.equal(raw.length, row.bytes);
  assert.equal(createHash('sha256').update(raw).digest('hex'), row.sha256);
  assert.equal(createHash('sha1').update(Buffer.from('blob ' + raw.length + '\\0')).update(raw).digest('hex'), row.gitBlob);
  return raw.toString('utf8');
}
const readme = source('README.md');
const workflow = source('.github/workflows/release.yml');
const job = workflow.match(/^  test:\\n([\\s\\S]*?)(?=^  [a-z][a-z-]*:)/m)?.[1];
assert.ok(job, 'exact pinned test-job boundary exists');
const actualMinutes = Number(job.match(/^    timeout-minutes: (\\d+)$/m)?.[1]);
const budgetSeconds = Number(job.match(/^          TEST_BUDGET_SECONDS: (\\d+)$/m)?.[1]);
const declaration = /CI caps each test-matrix job at (\\d+) minutes\\./;

test('pinned Rust README cap disagrees with the actual matrix job', () => {
  const documentedMinutes = Number(readme.match(declaration)?.[1]);
  assert.deepEqual({documentedMinutes, actualMinutes, budgetSeconds}, {documentedMinutes: 10, actualMinutes: 30, budgetSeconds: 900});
  assert.notEqual(documentedMinutes, actualMinutes);
  assert.match(job, /run-with-budget-warning\\.sh "\\$TEST_BUDGET_SECONDS" "Test suite"/);
});

test('disposable wording candidate distinguishes the backstop and internal budget', () => {
  const candidate = readme.replace(declaration, 'CI gives each test-matrix job a 30-minute backstop and the test step a 900-second (15-minute) execution budget.');
  assert.notEqual(candidate, readme);
  assert.equal(Number(candidate.match(/a (\\d+)-minute backstop/)?.[1]), actualMinutes);
  assert.equal(Number(candidate.match(/a (\\d+)-second \\(15-minute\\)/)?.[1]), budgetSeconds);
  assert.match(candidate, /cargo test` does not provide a portable global per-test timeout/);
  assert.ok(!declaration.test(candidate));
});
''')
entry=root/'rust/tests/web/issue-1580-template-observations.test.mjs'
with entry.open('a') as stream:stream.write("import '../../../experiments/issue-1580/template-rust-timeout-documentation.test.mjs';\n")
with (out/'focused.stdout').open('wb') as stdout,(out/'focused.stderr').open('wb') as stderr:run=subprocess.run(['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',str(test.relative_to(root))],cwd=root,stdout=stdout,stderr=stderr)
(out/'focused-outcome.json').write_text(json.dumps({'exitCode':run.returncode,'tests':2,'actualCargoExecuted':False,'candidateAppliedUpstream':False,'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
assert run.returncode==0
print(json.dumps({'currentHead':current,'sourceIdentityUnchanged':True,'staticCasesPassed':2,'cargoExecuted':False,'upstreamReportCreated':False}))
