import base64, hashlib, json, pathlib, subprocess
out=pathlib.Path('/tmp/issue-1580-research/rust-timeout-documentation')
out.mkdir(exist_ok=True)
repo='link-foundation/rust-ai-driven-development-pipeline-template'
pin='5f1e7a96acbf7a93b567195443cf6e5158fbbf1f3'
records=[]
for name,path in [('readme','README.md'),('release','.github/workflows/release.yml')]:
    run=subprocess.run(['gh','api',f'repos/{repo}/contents/{path}?ref={pin}'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (out/(name+'.api.stdout')).write_bytes(run.stdout)
    (out/(name+'.api.stderr')).write_bytes(run.stderr)
    assert run.returncode==0
    value=json.loads(run.stdout);raw=base64.b64decode(value['content'])
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==value['sha']
    (out/(name+'.source')).write_bytes(raw)
    lines=raw.decode().splitlines()
    contexts=[]
    for i,line in enumerate(lines):
        if any(word in line.lower() for word in ['timeout','ten minute','10 minute','15 minute','30 minute']):
            contexts.append({'line':i+1,'context':[{'line':j+1,'text':lines[j]} for j in range(max(0,i-2),min(len(lines),i+3))]})
    records.append({'path':path,'pin':pin,'gitBlob':value['sha'],'sha256':hashlib.sha256(raw).hexdigest(),'contexts':contexts})
argv=['gh','api',f'repos/{repo}/issues?state=all&per_page=100','--paginate','--jq','.[] | [.number,.title,.state,.html_url] | @json']
run=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(out/'issues.stdout').write_bytes(run.stdout);(out/'issues.stderr').write_bytes(run.stderr)
assert run.returncode==0
matches=[]
for line in run.stdout.splitlines():
    row=json.loads(line)
    if any(word in row[1].lower() for word in ['timeout','ten minute','time budget','deadline']):matches.append(row)
(out/'observations.json').write_text(json.dumps({'repository':repo,'pin':pin,'sources':records,'potentialDuplicateTitles':matches,'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
print(json.dumps({'sources':len(records),'potentialDuplicateTitles':matches,'output':str(out/'observations.json')}))
