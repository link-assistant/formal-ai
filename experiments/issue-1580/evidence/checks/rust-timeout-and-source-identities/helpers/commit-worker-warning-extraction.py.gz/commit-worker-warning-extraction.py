import gzip,hashlib,json,os,pathlib,subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');scratch=pathlib.Path('/tmp/issue-1580-research')
target=root/'experiments/issue-1580/evidence/checks/worker-warning-extraction'
final=scratch/'worker-warning-corrected-preflight';assert json.loads((final/'outcome.json').read_text())['allPassed']
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
rows=[json.loads(line) for line in (target/'records.jsonl').read_text().splitlines()];known={row['file'] for row in rows}
def retain(path,alias):
    alias+='.gz'
    if alias in known:return
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);destination=target/alias;destination.parent.mkdir(exist_ok=True,parents=True);destination.write_bytes(packed)
    rows.append({'source':str(path),'file':alias,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()});known.add(alias)
for path in sorted(final.iterdir()):
    if path.is_file():retain(path,'corrected-preflight/'+path.name)
for name in ['correct-worker-evidence-names.log','commit-worker-warning-extraction.py']:retain(scratch/name,'helpers/'+name)
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in rows))
summary=json.loads((target/'summary.json').read_text());summary['retainedRecords']=len(rows);summary['correctedPostArchivePreflight']=json.loads((final/'outcome.json').read_text());summary['correctedPostArchiveScanSelection']=json.loads((final/'selection.json').read_text());(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for row in rows:
    packed=(target/row['file']).read_bytes();raw=gzip.decompress(packed)
    assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['rawSha256'] and hashlib.sha256(packed).hexdigest()==row['archiveSha256']
subprocess.run(['git','add','--',str(target.relative_to(root))],cwd=root,check=True)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']='/tmp/issue-1580-research/secretlint-built-in-migration/dependencies/node_modules/.bin:'+env['PATH']
paths=[path for path in subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=ACMRT','-z'],cwd=root).decode().split('\0') if path]
for name,argv in [('final-naming',['node','scripts/measure-abbreviations.mjs','--check']),('final-secrets',['bash','scripts/check-secrets.sh',*paths]),('final-whitespace',['git','diff','--cached','--check'])]:
    with (final/(name+'.stdout')).open('wb') as stdout,(final/(name+'.stderr')).open('wb') as stderr:run=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
    assert run.returncode==0,name
with (final/'commit.stdout').open('wb') as stdout,(final/'commit.stderr').open('wb') as stderr:subprocess.run(['git','commit','-m','refactor: extract worker notation and refactoring below size warnings'],cwd=root,stdout=stdout,stderr=stderr,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
outcome={'head':head,'stagedFiles':len(paths),'archivedEvidenceRecords':len(rows),'archiveHashesVerified':True,'committed':True,'pushed':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(final/'commit-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome))
