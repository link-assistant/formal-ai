import gzip, hashlib, json, os, pathlib, re, subprocess

root = pathlib.Path('/tmp/gh-issue-solver-1794900398048')
scratch = pathlib.Path('/tmp/issue-1580-research')
out = scratch / 'rust-observation-preflight'
assert json.loads((out / 'outcome.json').read_text())['allPassed']
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip() == 'issue-1580-8d61a32a61e1'
target = root / 'experiments/issue-1580/evidence/checks/rust-timeout-and-source-identities'
rows = [json.loads(line) for line in (target / 'records.jsonl').read_text().splitlines()]
new_files = []
def retain(path, alias):
    raw = path.read_bytes(); packed = gzip.compress(raw,mtime=0)
    destination = target / (alias+'.gz'); destination.parent.mkdir(parents=True,exist_ok=True); destination.write_bytes(packed)
    rows.append({'source':str(path),'file':alias+'.gz','bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
    new_files.append(str(destination.relative_to(root)))
for path in sorted(out.rglob('*')):
    if path.is_file(): retain(path,'preflight/'+str(path.relative_to(out)))
for name in ['seal-rust-timeout-observation.log','start-rust-observation-preflight.py','start-rust-observation-preflight.log','commit-rust-timeout-observation.py']:
    retain(scratch/name,'helpers/'+name)
(target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in rows))
summary=json.loads((target/'summary.json').read_text());summary['retainedRecords']=len(rows);summary['postArchivePreflight']=json.loads((out/'outcome.json').read_text());(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
commands=root/'experiments/issue-1580/evidence/commands'
old_index=subprocess.check_output(['git','show','HEAD:experiments/issue-1580/evidence/commands/index.jsonl'],cwd=root,text=True)
known={json.loads(line)['file'] for line in old_index.splitlines()}
verified=0
for line in (commands/'index.jsonl').read_text().splitlines():
    row=json.loads(line)
    if row['file'] in known: continue
    packed=(commands/row['file']).read_bytes();raw=gzip.decompress(packed);value=json.loads(raw)
    assert hashlib.sha256(raw).hexdigest()==row['sha256'] and hashlib.sha256(packed).hexdigest()==row['compressedSha256']
    assert row['autonomousAuthorshipCredit']==value['autonomousAuthorshipCredit']==0
    assert re.fullmatch('[a-f0-9]{40}',row['source']) and value['source']==row['source']
    assert row['status']==value['status'] and row['signal']==value['signal']
    verified+=1
(out/'new-command-archive-validation.json').write_text(json.dumps({'verifiedArchives':verified,'authorshipCredit':0,'doesNotClaimAllCommandsPassed':True},indent=2)+'\n')
subprocess.run(['git','add','--',str(target.relative_to(root))],cwd=root,check=True)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH']
for name,argv in [('final-naming',['node','scripts/measure-abbreviations.mjs','--check']),('incremental-secrets',['bash','scripts/check-secrets.sh',*new_files,str(target.relative_to(root)/'records.jsonl'),str(target.relative_to(root)/'summary.json')]),('final-whitespace',['git','diff','--cached','--check'])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
    assert result.returncode==0,name
with (out/'commit.stdout').open('wb') as stdout,(out/'commit.stderr').open('wb') as stderr:
    subprocess.run(['git','commit','-m','test: verify Rust template source pins and timeout documentation'],cwd=root,stdout=stdout,stderr=stderr,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
for name,argv in [('main-log',['git','log','--oneline','53cbe4430f8b65330f47728401fc83b09977129f..origin/main']),('main-files',['git','diff','--name-status','53cbe4430f8b65330f47728401fc83b09977129f','origin/main'])]:
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr,check=True)
result={'head':head,'committed':True,'pushed':False,'verifiedNewCommandArchives':verified,'retainedObservationRecords':len(rows),'fullIssueComplete':False,'independentAuthorshipCredit':0}
(out/'commit-outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
