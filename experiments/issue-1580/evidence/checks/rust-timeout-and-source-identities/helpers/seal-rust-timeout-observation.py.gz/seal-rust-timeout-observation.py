import gzip, hashlib, json, pathlib, re, subprocess

root = pathlib.Path('/tmp/gh-issue-solver-1794900398048')
scratch = pathlib.Path('/tmp/issue-1580-research')
target = root / 'experiments/issue-1580/evidence/checks/rust-timeout-and-source-identities'
assert not target.exists()
assert json.loads((scratch / 'rust-observation-validation/outcome.json').read_text())['allPassed']
output = (scratch / 'rust-observation-validation/maintained.stdout').read_text()
assert re.search(r'(?m)^.*tests 133$', output) and re.search(r'(?m)^.*pass 133$', output)
assert re.search(r'(?m)^.*fail 0$', output) and re.search(r'(?m)^.*skipped 0$', output)
validation = json.loads((scratch / 'template-source-identities/rust-current-tree-validation.json').read_text())
assert len(validation['fileChecks']) == 12 and all(row['matches'] for row in validation['fileChecks'])
report = json.loads((scratch / 'rust-timeout-documentation/upstream-report.json').read_text())
ledger_path = root / 'docs/case-studies/issue-1580/templates/rust-current-delta-review.json'
ledger = json.loads(ledger_path.read_text())
assert ledger['commit'] == report['pin'] == validation['commit']
ledger['relatedWork']['timeoutDocumentationDriftReport'] = report['url']
ledger['verification']['timeoutDocumentationObservationTestsPassed'] = 2
ledger['verification']['maintainedTemplateObservationTestsPassed'] = 133
ledger_path.write_text(json.dumps(ledger, indent=2) + '\n')
rows = []
target.mkdir(parents=True)
def retain(path, alias):
    raw = path.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    name = alias + '.gz'
    destination = target / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(packed)
    assert gzip.decompress(packed) == raw
    rows.append({'source':str(path),'file':name,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
for directory in ['rust-timeout-documentation','template-source-identities','rust-observation-validation','worker-warning-corrected-preflight','template-observation-publication']:
    for path in sorted((scratch / directory).rglob('*')):
        if path.is_file():
            retain(path, directory + '/' + str(path.relative_to(scratch / directory)))
for stem in ['investigate-rust-timeout-documentation','read-rust-timeout-prior-discussion','draft-rust-timeout-observation','investigate-template-source-identities','repair-template-source-identities','start-rust-observation-validation','report-rust-timeout-documentation','seal-rust-timeout-observation','commit-worker-warning-extraction']:
    for suffix in ['.py','.log']:
        path = scratch / (stem + suffix)
        if path.exists(): retain(path, 'helpers/' + path.name)
(target / 'records.jsonl').write_text(''.join(json.dumps(row, separators=(',',':'))+'\n' for row in rows))
summary = {'reviewedCommit':report['pin'],'previousRecordedIdentifier':ledger['identityCorrection']['previousRecordedIdentifier'],'verifiedGitTree':validation['tree'],'recordedCurrentFilesVerified':12,'beforeSourceIdentityRegression':'fails on the original 41-character identifier','sourceIdentityRegressionPassed':1,'timeoutDocumentationObservationsPassed':2,'maintainedTestsPassed':133,'maintainedTestsSkipped':0,'upstreamReport':report['url'],'upstreamRepairVerified':False,'retainedRecords':len(rows),'allArchiveHashesVerified':True,'localRustBuildPerformed':False,'completeCurrentSourceComparison':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(target / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
doc = root / 'docs/case-studies/issue-1580/rust-timeout-and-source-identity-checkpoint.md'
doc.write_text('''# Rust timeout documentation and source identity

The current Rust template README says every test-matrix job is capped at ten
minutes. Its parsed workflow instead gives the test job a thirty-minute
backstop and the test command a 900-second (fifteen-minute) internal budget.
Two maintained checks verify that mismatch against exact Git blobs and check
a disposable wording correction. The portable per-test Cargo limitation stays
explicit. No Cargo command or upstream workflow was executed for this check.
The reproduced drift is reported in
[Rust template issue #256](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/issues/256).
An upstream report and wording candidate do not establish an upstream repair.

The investigation also found a false source identity in our review ledger:
its recorded Rust commit had 41 hexadecimal characters. Fresh Git commit and
recursive-tree observations verify the actual 40-character commit
`5f1e7a96acbf7a93b567195443cf6e5158fbbf1f` and all twelve previously recorded
changed-file blobs. Their content identities match. The ledger now uses that
verified commit and preserves the old string as correction evidence. Historical
API responses are retained unchanged, including responses requested with the
invalid ref; those responses alone did not verify a valid commit identity.

A maintained regression fails on the original ledger and passes after the
correction. It checks complete commit syntax across fourteen review ledgers
and the timeout fixture. This does not assert that every ledger's contents or
every current and historical template source has received complete review.

All 133 cases in the maintained template-observation entry pass without skips.
The naming, file-size, tests-as-documentation and whitespace checks pass. The
preceding worker extraction separately passes all 141 local gate entries
(88 passes and 53 explicit skips) and removes four source-size warnings; 87
warnings remain under unchanged thresholds. Final worker commit and previous
publication receipts are also retained with this checkpoint.

Raw before/fixed observations, API identities, prior issue discussion, submitted
report, validation streams and helper sources are compressed with verified
original and archive SHA256 identities in
`experiments/issue-1580/evidence/checks/rust-timeout-and-source-identities/`.
Supplied implementation and commands receive zero independent authorship or
reasoning credit. Full template/practice, original budget/live, complete source
warning, security child semantics and complete issue acceptance remain open.
PR #1581 remains draft and unmerged.
''')
plan = root / 'experiments/issue-1580/work-plan.md'
text = plan.read_text().replace('45 focused tests, 130 maintained cases,','45 focused tests, 133 maintained cases,',1)
needle = 'Earlier checkpoint entries below retain their dated heads and scope.'
text = text.replace(needle,'''The [Rust timeout and source identity checkpoint](../../docs/case-studies/issue-1580/rust-timeout-and-source-identity-checkpoint.md)
adds an upstream documentation-drift report and repairs the invalid source pin
after checking all twelve changed-file Git blobs. Its before-fix regression
fails on the original identifier. No upstream repair or full-template acceptance
is inferred from the report.
''' + needle, 1)
plan.write_text(text)
subprocess.run(['git','diff','--check'], cwd=root, check=True)
print(json.dumps(summary))
