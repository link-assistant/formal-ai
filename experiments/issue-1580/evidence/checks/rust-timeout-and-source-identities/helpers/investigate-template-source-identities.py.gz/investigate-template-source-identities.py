import json,pathlib,subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');out=pathlib.Path('/tmp/issue-1580-research/template-source-identities');out.mkdir(exist_ok=True)
rows=[]
for path in sorted((root/'docs/case-studies/issue-1580/templates').glob('*.json')):
    value=json.loads(path.read_text())
    if isinstance(value,dict) and value.get('commit'):
        pin=value['commit'];rows.append({'path':str(path.relative_to(root)),'repository':value.get('repository'),'commit':pin,'length':len(pin)})
(out/'inventory.json').write_text(json.dumps(rows,indent=2)+'\n')
run=subprocess.run(['gh','api','repos/link-foundation/rust-ai-driven-development-pipeline-template/git/commits/5f1e7a96acbf7a93b567195443cf6e5158fbbf1f'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(out/'rust-commit.stdout').write_bytes(run.stdout);(out/'rust-commit.stderr').write_bytes(run.stderr);assert run.returncode==0
value=json.loads(run.stdout);assert value['sha']=='5f1e7a96acbf7a93b567195443cf6e5158fbbf1f'
run=subprocess.run(['gh','api','repos/link-foundation/rust-ai-driven-development-pipeline-template/git/trees/'+value['tree']['sha']+'?recursive=1'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(out/'rust-tree.stdout').write_bytes(run.stdout);(out/'rust-tree.stderr').write_bytes(run.stderr);assert run.returncode==0
tree=json.loads(run.stdout);assert not tree.get('truncated');blobs={row['path']:row['sha'] for row in tree['tree'] if row['type']=='blob'}
ledger=json.loads((root/'docs/case-studies/issue-1580/templates/rust-current-delta-review.json').read_text())
checks=[{'path':row['path'],'matches':blobs.get(row['path'])==row['gitBlob'],'expectedBlob':row['gitBlob'],'observedBlob':blobs.get(row['path'])} for row in ledger['files']]
assert len(checks)==12 and all(row['matches'] for row in checks)
(out/'rust-current-tree-validation.json').write_text(json.dumps({'commit':value['sha'],'tree':value['tree']['sha'],'fileChecks':checks,'fullTemplateComparisonComplete':False},indent=2)+'\n')
path=root/'experiments/issue-1580/template-inventory-integrity.test.mjs';(out/'existing-inventory-test.txt').write_bytes(path.read_bytes())
print(json.dumps({'ledgerCommitLengths':rows,'allTwelveRustCurrentBlobIdentitiesVerified':True}))
