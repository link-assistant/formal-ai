import json, pathlib, subprocess

out = pathlib.Path('/tmp/issue-1580-research/rust-observation-preflight')
out.mkdir(exist_ok=False)
program = '''import gzip,hashlib,json,os,pathlib,re,subprocess,time
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048');scratch=pathlib.Path('/tmp/issue-1580-research');out=scratch/'rust-observation-preflight'
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';env['SECRETLINT_VERSION']='14.0.0';env['PATH']=str(scratch/'secretlint-built-in-migration/dependencies/node_modules/.bin')+':'+env['PATH'];env['FORMAL_AI_GATE_LOG_DIR']=str(out/'gate-logs')
commands=[('archive-commands',['python3','experiments/issue-1580/archive-evidence.py'])]
paths=['docs/case-studies/issue-1580/templates/rust-current-delta-review.json','docs/case-studies/issue-1580/rust-timeout-and-source-identity-checkpoint.md','rust/tests/web/issue-1580-template-observations.test.mjs','changelog.d/issue-1580-template-source-identity.md','experiments/issue-1580/fixtures/rust-timeout-documentation','experiments/issue-1580/template-rust-timeout-documentation.test.mjs','experiments/issue-1580/template-source-identities.test.mjs','experiments/issue-1580/evidence/checks/rust-timeout-and-source-identities','experiments/issue-1580/work-plan.md','experiments/issue-1580/evidence/commands']
commands += [('stage',['git','add','--',*paths])]
commands += [(name,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',name]) for name in ['check-abbreviations','check-file-size','check-tests-as-docs']]
commands += [('whitespace',['git','diff','--cached','--check'])]
rows=[]
def run(name,argv):
    started=time.time()
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
    row={'name':name,'argv':argv,'exitCode':result.returncode,'seconds':round(time.time()-started,3)}
    for label in ['stdout','stderr']:
        raw=(out/(name+'.'+label)).read_bytes();row[label]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    rows.append(row);(out/'records.json').write_text(json.dumps(rows,indent=2)+'\\n');print(json.dumps(row),flush=True)
    assert result.returncode==0,name
for name,argv in commands:run(name,argv)
files=[path for path in subprocess.check_output(['git','diff','--cached','--name-only','--diff-filter=ACMRT','-z'],cwd=root,text=True).split('\\0') if path]
(out/'selection.json').write_text(json.dumps({'stagedFiles':files},indent=2)+'\\n')
run('secrets',['bash','scripts/check-secrets.sh',*files])
target=root/'experiments/issue-1580/evidence/checks/rust-timeout-and-source-identities'
archive_rows=[json.loads(line) for line in (target/'records.jsonl').read_text().splitlines()]
for row in archive_rows:
    packed=(target/row['file']).read_bytes();raw=gzip.decompress(packed)
    assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['rawSha256'] and hashlib.sha256(packed).hexdigest()==row['archiveSha256']
(out/'outcome.json').write_text(json.dumps({'allPassed':True,'commands':len(rows),'stagedFiles':len(files),'archivesVerified':len(archive_rows),'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\\n')
'''
(out / 'validate.py').write_text(program)
with (out / 'worker.log').open('wb') as stream:
    child = subprocess.Popen(['python3',str(out / 'validate.py')],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
(out / 'pid.json').write_text(json.dumps({'pid':child.pid})+'\n')
print(json.dumps({'pid':child.pid,'commands':7,'fullIssueComplete':False}))
