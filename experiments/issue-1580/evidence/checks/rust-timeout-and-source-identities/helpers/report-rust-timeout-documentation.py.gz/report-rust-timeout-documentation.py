import json, pathlib, subprocess

root = pathlib.Path('/tmp/gh-issue-solver-1794900398048')
scratch = pathlib.Path('/tmp/issue-1580-research')
out = scratch / 'rust-timeout-documentation'
pin = '5f1e7a96acbf7a93b567195443cf6e5158fbbf1f'
repo = 'link-foundation/rust-ai-driven-development-pipeline-template'
assert len(pin) == 40
assert json.loads((scratch / 'rust-observation-validation/outcome.json').read_text())['allPassed']
verified = json.loads((scratch / 'template-source-identities/rust-current-tree-validation.json').read_text())
assert verified['commit'] == pin and len(verified['fileChecks']) == 12
assert all(row['matches'] for row in verified['fileChecks'])
body = f'''The README's timeout guarantee disagrees with the actual matrix configuration at current commit `{pin}`.

The [README, line 78](https://github.com/{repo}/blob/{pin}/README.md#L78) says each test-matrix job is capped at ten minutes. The actual [`test` job](https://github.com/{repo}/blob/{pin}/.github/workflows/release.yml#L541) has `timeout-minutes: 30` at line 546. Its [Run tests step](https://github.com/{repo}/blob/{pin}/.github/workflows/release.yml#L612) sets `TEST_BUDGET_SECONDS: 900` and invokes `scripts/run-with-budget-warning.sh` with that budget. Thus the job backstop is thirty minutes, and the test execution budget is fifteen minutes.

Reproduce by checking out that commit, reading README line 78, then parsing `.github/workflows/release.yml`: inspect `jobs.test["timeout-minutes"]` and the `TEST_BUDGET_SECONDS` environment value on its `Run tests` step. The result is documented=10, actual job=30, internal budget=900 seconds. This is a static documentation inconsistency; it does not require a Cargo build.

Suggested wording: “CI gives each test-matrix job a 30-minute backstop and the test step a 900-second (15-minute) execution budget.” Keep the following explanation about Cargo lacking a portable global per-test timeout and using explicit test-level timeouts.

The downstream [Formal AI investigation](https://github.com/link-assistant/formal-ai/pull/1581) retains two passing automated checks against the exact Git-blob-verified README and workflow, plus a disposable wording candidate. All 133 tests in its maintained template-observation entry pass locally. This report and candidate do not establish an upstream repair or hosted execution of this template. Related issue #41 originally requested timeout documentation; the present report concerns drift between that documentation and today's configuration.
'''
(out / 'upstream-report.md').write_text(body)
receipt = out / 'upstream-report.json'
if not receipt.exists():
    argv = ['gh','issue','create','--repo',repo,'--title','README test-matrix timeout guarantee disagrees with 30-minute job and 900-second budget','--body-file',str(out / 'upstream-report.md')]
    with (out / 'upstream-report.stdout').open('wb') as stdout, (out / 'upstream-report.stderr').open('wb') as stderr:
        run = subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr)
    assert run.returncode == 0
    url = (out / 'upstream-report.stdout').read_text().strip()
    assert url.startswith('https://github.com/' + repo + '/issues/')
    receipt.write_text(json.dumps({'url':url,'pin':pin,'submitted':True,'upstreamRepairVerified':False,'fullIssueComplete':False},indent=2)+'\n')
print(receipt.read_text())
jobs = json.loads((scratch / 'rust-observation-validation/current-pipeline-jobs.stdout').read_text())['jobs']
summary = [{'id':job['id'],'name':job['name'],'status':job['status'],'conclusion':job['conclusion'],'startedAt':job['started_at'],'completedAt':job['completed_at']} for job in jobs]
(out / 'current-pipeline-jobs-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'pipelineJobs':summary}))
