from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
for args in [['rg','--files','scripts','-g','*change*'],['rg','-n','detect.code.changes','scripts/check-pipeline-status.sh','.github/workflows/release.yml']]:
 r=subprocess.run(args,cwd=root,capture_output=True,text=True);print(r.stdout);print(r.stderr)
