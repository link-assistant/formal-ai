from pathlib import Path
import json,hashlib,collections
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');docs=root/'docs/case-studies/issue-1580/templates';out=scratch/'csharp-current-complete-comparison';out.mkdir(exist_ok=True)
old=json.loads((docs/'csharp-partial-semantic-review.json').read_text());delta=json.loads((docs/'csharp-current-delta-review.json').read_text());tree=json.loads((scratch/'fresh-template-delta-sources/trees/csharp.json').read_text());assert not tree['truncated'] and tree['sha']==delta['commit']
previous={r['path']:r for r in old['files']};changed={r['path']:r for r in delta['files']};history={r['path']:r for r in map(json.loads,(scratch/'csharp-historical-comparison/structured-content-records.jsonl').read_text().splitlines())};assert len(previous)==337 and len(changed)==8 and len(history)==179
def comparison(name):
 low=name.lower()
 if any(term in low for term in ['changeset','bump-version','version-and-commit']):return ['scripts/create-changelog-fragment.rs','scripts/collect-changelog.rs','changelog.d']
 if any(term in low for term in ['nuget','dotnet','docfx','nuspec','vstest','xunit','mypackage','calculator','.csproj','.props','.sln','global.json']):return ['rust/Cargo.toml','CONTRIBUTING.md','.github/workflows/release.yml']
 if any(term in low for term in ['artifact','zip-archive','release-assets','toolkit-buffer','toolkit-dep0005','unzipper']):return ['scripts/download-artifact-with-retry.sh','scripts/extract-artifacts.py','scripts/native-release-artifact.mjs']
 if any(term in low for term in ['print-untrusted','output','runner-actioncommand','runner-4692','toolkit-safe-output']):return ['scripts/lib/native-process-diagnostics.mjs','scripts/github-output.rs','.github/workflows/hive-original-delivery.yml']
 if any(term in low for term in ['lychee','link','web-archive']):return ['.github/workflows/links.yml','scripts/recheck-broken-links.mjs']
 if any(term in low for term in ['runner','actionlint','zizmor','workflow','shellcheck']):return ['.github/workflows/workflows.yml','scripts/check-runner-labels.mjs','.github/workflows/recover-unacquired-runners.yml']
 if any(term in low for term in ['pipeline-gate','current-check','current-pr-check','passing-implementation-pipeline','preflight','codecov']):return ['scripts/check-pipeline-status.sh','scripts/preflight-credentials.sh','.github/workflows/coverage.yml']
 if any(term in low for term in ['audit','security','sarif','dependency','dependencies','eslint','minimatch','bun','npm','package.json','package-lock','pre-commit']):return ['.github/workflows/security.yml','.github/workflows/dependencies-latest.yml','scripts/check-codeql-results.mjs']
 if any(term in low for term in ['budget','timeout','transient','fetch-with-retries']):return ['scripts/run-with-budget-warning.sh','scripts/run-with-deadline.sh']
 if any(term in low for term in ['release','publish','naming','package-smoke','package-validation','pack.log']):return ['.github/workflows/release.yml','scripts/release-protocol.mjs','scripts/verify-public-release-downloads.mjs']
 if any(term in low for term in ['detect-code','git-input','git-push','change-detection']):return ['scripts/detect-code-changes.rs','scripts/check-pipeline-status.sh']
 return ['CONTRIBUTING.md','docs/case-studies/issue-1580/README.md']
def historical_decision(name,method):
 low=name.lower()
 if 'runner-actioncommand' in low:return 'Literal legacy runner source confirms mid-line ##[ recognition and escaped property parsing. Preserve stop/resume output framing at actual Formal AI sinks; this historical source alone does not prove all sinks safe.'
 if 'runner-images-readme' in low:return 'Literal runner policy separates weekly image updates, floating-label migration and versioned support windows. Formal AI pins labels; historical image catalogs do not establish current runner contents or authorize copying the template SDK/image choice.'
 if 'dotnet11-release' in low:return 'Complete release table/prose traversal identifies stable SDK/runtime rows and distinct preview package entries. This is historical .NET release provenance; Formal AI has no NuGet/.NET product to migrate. No current version recommendation or restore is inferred.'
 if 'alpine-releases' in low:return 'Complete HTML text/link traversal retains branch support and main/community lifecycle distinctions. Historical catalog data does not establish the current base-image or vulnerability state of Formal AI.'
 if '/upstream/' in low:return 'Read the complete original report or its exact URL. Retain the actionlint image, artifact Buffer deprecation, Bun timeout, lychee reset or runner-output report as upstream context. Apply only the corresponding shared behavior; a historical report is not a fresh reproduction or current Formal AI failure.'
 if low.endswith('/analysis.md'):return 'Read the entire root-cause analysis, including required verdicts, safe output, immutable artifact checks, locked restore and bounded retries. Transfer shared CI practices to their actual owners; keep .NET-specific tooling and historical results separate from Formal AI acceptance.'
 if low.endswith('/dependencies.md') or low.endswith('/dependency-update-practices.md'):return 'Read complete dependency coordinates and update policy: retain lockfile/parent-version constraints, pinned actions and verified registry evidence. Optional broad upgrades in this template are not automatic Formal AI requirements. Historical clean audits do not establish current safety.'
 if low.endswith('/plan.md') or low.endswith('/readme.md'):return 'Read the complete historical scope/plan and evidence index. It distinguishes full CI repair from optional broader dependency updates; preserve its own dates, repository identity and unfinished-provider limits rather than treating it as Formal AI runtime evidence.'
 if low.endswith('/actionlint-dockerfile.txt') or low.endswith('/actionlint-go.mod') or low.endswith('/bun-dependency-graph.txt'):return 'Read the complete captured dependency/build source. It explains pinned image/tool and dependency provenance; no local Docker/Go/Bun build or current registry verification follows from that source snapshot.'
 if '/registry/' in low:return 'Traverse all JSON leaves and metadata fields; retain package/action/tool identities and terminal/error values. These registry snapshots explain the historical dependency decision and do not establish current versions or require unrelated toolchains in Formal AI.'
 if any(term in low for term in ['issue.json','issue-comments','sub-issues','pr-conversation','pr-inline','pr-reviews','related-pr','recent-merged','final-pr','current-pr','pr-runs','initial-pr-runs','initial-main-runs']):return 'Traverse the full discussion/run metadata and retain every diagnostic body location and terminal-state count. These are the C# template requirements, upstream reports and dated execution snapshots; they neither add unrelated product features nor prove current Formal AI CI green.'
 if method=='complete-json-schema-and-terminal-state-traversal':return 'Traverse the complete JSON schema/leaves, terminal states and error/body diagnostics. Review exact grouped diagnostics and retain all original field locations. Passing, failing, queued and open upstream states are historical context; they are not current Formal AI runtime or publication proof.'
 return 'Traverse every log line for diagnostic candidates and review all unique exact messages with original locations retained. Distinguish controlled NuGet/lockfile/output negative probes and quoted shell commands from actual historical helper, restore, lint, provider and CodeQL failures. Apply only shared behavior at the mapped Formal AI owners; no archived result is promoted to current CI evidence.'
literal_names={'README.md','plan.md','actionlint-Dockerfile.txt','actionlint-go.mod','bun-dependency-graph.txt','analysis.md','dependencies.md','dependency-update-practices.md','runner-ActionCommand.cs.txt','runner-images-readme.md'}
rows=[];missing=collections.defaultdict(list)
for entry in sorted((r for r in tree['tree'] if r['type']=='blob'),key=lambda r:r['path']):
 name=entry['path'];p=scratch/'fresh-template-delta-sources/files/csharp'/name
 if not p.is_file():p=scratch/'templates/csharp-complete'/name
 raw=p.read_bytes();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();sha=hashlib.sha256(raw).hexdigest();assert blob==entry['sha'],name
 row={'path':name,'gitBlob':blob,'sha256':sha,'bytes':len(raw)}
 if name in changed:
  source=changed[name];assert blob==source['gitBlob'] and sha==source['sha256'];row.update(comparisonMethod='current-delta-literal-source-review',literalSourceFullyRead=True,readEvidence='csharp-current-delta-review.json',decision=source['decision'],formalAiComparison=source['formalAiComparison'])
 else:
  source=previous[name];assert blob==source['gitBlob'] and sha==source['sha256'],name
  if name in history:
   source=history[name];assert source['sha256']==sha;method=source['method'];literal=False
   if method=='requires-literal-or-specialized-content-review':
    if name.endswith('/dotnet11-release.md'):method='complete-markdown-release-catalog-traversal'
    elif name.endswith('/alpine-releases.html'):method='complete-html-text-and-link-traversal'
    else:
     assert Path(name).name in literal_names or '/upstream/' in name,name;method='complete-literal-historical-source-review';literal=True
   row.update(comparisonMethod=method,literalSourceFullyRead=literal,readEvidence='csharp-historical-comparison/structured-content-records.jsonl',decision=historical_decision(name,method),formalAiComparison=comparison(name))
  else:
   assert source['reviewStatus']=='active-source-fully-read';row.update(comparisonMethod='unchanged-pinned-literal-source-review',literalSourceFullyRead=True,readEvidence='csharp-partial-semantic-review.json',decision=source['decision'],formalAiComparison=comparison(name))
 for path in row['formalAiComparison']:
  if not (root/path).exists():missing[path].append(name)
 assert row['decision'];rows.append(row)
assert len(rows)==339 and len({r['path'] for r in rows})==339
assert not missing,dict(missing)
(out/'files.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in rows))
summary={'repository':old['repository'],'sourceCommit':tree['sha'],'baseCommit':old['commit'],'files':len(rows),'previousFiles':len(previous),'changedReviewed':len(changed),'added':[r['path'] for r in rows if r['path'] not in previous],'removed':sorted(set(previous)-{r['path'] for r in rows}),'unchangedCarried':len(rows)-len(changed),'earlierLiteralActiveFiles':158,'earlierLiteralActiveLines':18327,'historicalCompared':len(history),'methods':dict(collections.Counter(r['comparisonMethod'] for r in rows)),'allCurrentGitBlobsAndSha256Verified':True,'allFilesHaveSourceApplicabilityDecisions':True,'allComparisonPathsExist':True,'allApplicablePracticesImplementedAndVerified':False,'historicalLogsAreCurrentRuntimeProof':False,'nativeBuildExecutedLocally':False,'independentAuthorshipCredit':0,'fullIssueComplete':False}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
