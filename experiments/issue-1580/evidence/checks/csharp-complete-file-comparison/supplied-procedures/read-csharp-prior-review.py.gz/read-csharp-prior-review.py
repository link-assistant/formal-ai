from pathlib import Path
import json
base=Path('/tmp/gh-issue-solver-1794900398048/docs/case-studies/issue-1580/templates')
p=base/'csharp-partial-semantic-review.json';data=json.loads(p.read_text());print('KEYS',list(data))
for key,value in data.items():
 if isinstance(value,list):
  print('LIST',key,'COUNT',len(value));print(json.dumps(value[:2],indent=2))
 elif isinstance(value,dict):print('OBJECT',key,json.dumps(value,indent=2)[:6000])
 else:print(key,json.dumps(value))
p=base/'README.md';lines=p.read_text().splitlines();print('README lines',len(lines))
for i,line in enumerate(lines):
 if 'C#' in line or 'csharp' in line or i>len(lines)-45:print(f'{i+1}: {line}')
identities=Path('/tmp/issue-1580-research/csharp-historical-comparison/source-identities.jsonl').read_text().splitlines();print('IDENTITY SAMPLE',identities[0])
inventory=json.loads(Path('/tmp/issue-1580-research/fresh-template-delta-sources/trees/csharp.json').read_text());print('TREE BLOBS',sum(1 for r in inventory['tree'] if r['type']=='blob'))
