from pathlib import Path
import json,collections
b=Path('/tmp/issue-1580-research/csharp-historical-comparison')
a=json.loads((b/'registry-alpine-releases.html.parsed.json').read_text())
print(json.dumps({'path':a['path'],'sha256':a['sha256'],'method':a['method'],'textNodes':len(a['text']),'links':len(a['links']),'supportPolicy':a['text'][17:27],'currentBranches':a['text'][35:101],'decision':'Historical official release catalog supports template image freshness exception; it is not a Formal AI dependency manifest.'}))
d=json.loads((b/'dotnet11-release.md.parsed.json').read_text());rows=d['tableRows']
print(json.dumps({'path':d['path'],'sha256':d['sha256'],'method':d['method'],'headers':d['headers'],'allNonTableProse':d['other'],'allRows':len(rows),'columnCounts':dict(collections.Counter(len(r['cells']) for r in rows)),'versionFrequencies':dict(collections.Counter(cell for r in rows for cell in r['cells'] if cell and cell[0].isdigit() and not cell.startswith('http'))),'decision':'Historical .NET11 package/release catalog; no .NET product or NuGet release exists in Formal AI, so SDK selection is template-specific.'}))
s=[json.loads(line) for line in (b/'structured-content-records.jsonl').read_text().splitlines()]
for r in s:
 if r['method'].startswith('complete-json'):
  print(json.dumps({k:v for k,v in r.items() if k not in ['sha256','decodedLines','terminalStates']}|{'terminalStates':r.get('terminalStates',[])}))
