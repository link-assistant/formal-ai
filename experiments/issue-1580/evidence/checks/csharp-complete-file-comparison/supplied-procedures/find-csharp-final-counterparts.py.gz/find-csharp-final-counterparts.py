from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
for dirname in ['.github/workflows','.github/scripts']:
 print(dirname)
 print('\n'.join(str(p.relative_to(root)) for p in sorted(root.joinpath(dirname).glob('*')) if p.is_file()))
for term in ['stop-commands','minimatch','crc32','force-evaluate','CODECOV_TOKEN','run-with-budget-warning']:
 r=subprocess.run(['rg','-l','--glob','!*.lock',term,'scripts','.github','package.json'],cwd=root,capture_output=True,text=True);print('TERM',term);print(r.stdout)
