from pathlib import Path
import hashlib
root=Path('/tmp/issue-1580-research/templates/csharp-complete/dev/log/issues/108/pulls/109')
names=['README.md','plan.md','actionlint-Dockerfile.txt','actionlint-go.mod','bun-dependency-graph.txt']+[str(p.relative_to(root)) for p in sorted((root/'upstream').iterdir())]
for name in names:
 raw=(root/name).read_bytes();lines=raw.decode().splitlines();print('\nFILE',name,'SHA256',hashlib.sha256(raw).hexdigest(),'lines',len(lines))
 for index,line in enumerate(lines):print(str(index+1)+': '+line)
