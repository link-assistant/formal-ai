from pathlib import Path
import json,re,hashlib,collections
base=Path('/tmp/issue-1580-research/csharp-historical-comparison');groups={}
for record in [json.loads(line) for line in (base/'historical-diagnostics.jsonl').read_text().splitlines()]:
 text=record['text'];text=re.sub(r'\x1b\[[0-9;]*m','',text);text=re.sub(r'^.*?\b2026-\d\d-\d\dT\S+\s+','',text)
 # Group repeated CI annotation transport, preserving every original location.
 text=text.replace('##[error]','::error::').replace('##[warning]','::warning::')
 group=groups.setdefault(text,{'text':text,'locations':[]});group['locations'].append({key:value for key,value in record.items() if key!='text'})
records=list(groups.values());(base/'grouped-diagnostics.jsonl').write_text(''.join(json.dumps(record,separators=(',',':'))+'\n' for record in records))
print(json.dumps({'originalDiagnostics':sum(len(record['locations']) for record in records),'uniqueDiagnostics':len(records),'renderedBytes':sum(len(record['text']) for record in records),'over2000Characters':[{'sha256':hashlib.sha256(record['text'].encode()).hexdigest(),'bytes':len(record['text']),'locations':record['locations']} for record in records if len(record['text'])>2000]},indent=2))
for index,record in enumerate(records):
 print(json.dumps({'index':index,'locations':record['locations'],'text':record['text']},separators=(',',':')))
