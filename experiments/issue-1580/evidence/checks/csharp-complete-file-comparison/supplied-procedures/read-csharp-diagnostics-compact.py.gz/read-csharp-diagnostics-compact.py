from pathlib import Path
import json,sys
p=Path('/tmp/issue-1580-research/csharp-historical-comparison/grouped-diagnostics.jsonl')
rows=[json.loads(line) for line in p.read_text().splitlines()]
start=int(sys.argv[1]); end=int(sys.argv[2])
for index in range(start,min(end,len(rows))):
 row=rows[index]
 print(json.dumps({'index':index,'text':row['text'],'locationCount':len(row['locations']),'firstLocation':row['locations'][0]},ensure_ascii=False))
