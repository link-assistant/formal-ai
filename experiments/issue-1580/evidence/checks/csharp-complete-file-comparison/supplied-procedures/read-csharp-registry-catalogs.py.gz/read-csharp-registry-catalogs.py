from pathlib import Path
from html.parser import HTMLParser
import json,re,hashlib,collections
base=Path('/tmp/issue-1580-research');root=base/'templates/csharp-complete/dev/log/issues/108/pulls/109';out=base/'csharp-historical-comparison'
class Text(HTMLParser):
 def __init__(self):super().__init__();self.parts=[];self.links=[]
 def handle_data(self,text):
  if text.strip():self.parts.append(text.strip())
 def handle_starttag(self,tag,attrs):
  for key,value in attrs:
   if key=='href':self.links.append(value)
for name in ['registry/alpine-releases.html','dotnet11-release.md']:
 raw=(root/name).read_bytes();text=raw.decode();record={'path':name,'sha256':hashlib.sha256(raw).hexdigest(),'lines':len(text.splitlines())}
 if name.endswith('.html'):
  parser=Text();parser.feed(text);parser.close();record.update(method='complete-html-text-and-link-traversal',text=parser.parts,links=parser.links)
 else:
  lines=text.splitlines();headers=[{'line':i+1,'text':line} for i,line in enumerate(lines) if line.startswith('#')];rows=[{'line':i+1,'cells':[cell.strip() for cell in line.split('|')[1:-1]]} for i,line in enumerate(lines) if line.startswith('|')];other=[{'line':i+1,'text':line} for i,line in enumerate(lines) if line.strip() and not line.startswith(('|','#'))];record.update(method='complete-release-table-and-prose-traversal',headers=headers,tableRows=rows,other=other)
 (out/(name.replace('/','-')+'.parsed.json')).write_text(json.dumps(record,indent=2)+'\n')
 if name.endswith('.html'):
  print(json.dumps(record,ensure_ascii=False))
 else:
  print(json.dumps({key:value for key,value in record.items() if key!='tableRows'},ensure_ascii=False))
  print(json.dumps({'allTableRows':len(rows),'columnCounts':dict(collections.Counter(len(row['cells']) for row in rows)),'packageAndVersionIdentities':list(dict.fromkeys(tuple(cell for cell in row['cells'] if not re.search(r'https?://|^[a-f0-9]{64,}$',cell)) for row in rows))},ensure_ascii=False))
