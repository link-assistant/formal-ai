from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,gzip,hashlib,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'csharp-complete-comparison-preservation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(child.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==0,(name,r.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
 source=scratch/'csharp-current-complete-comparison';summary=json.loads((source/'summary.json').read_text());assert summary['files']==339 and summary['allFilesHaveSourceApplicabilityDecisions'] and not summary['allApplicablePracticesImplementedAndVerified']
 target=root/'experiments/issue-1580/evidence/checks/csharp-complete-file-comparison';target.mkdir(exist_ok=False);records=[]
 def archive(p,name):
  raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);dest=target/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed);assert gzip.decompress(dest.read_bytes())==raw
  records.append({'path':str(dest.relative_to(target)),'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
 for dirname in ['csharp-historical-comparison','csharp-current-complete-comparison']:
  for p in sorted((scratch/dirname).rglob('*')):
   if p.is_file():archive(p,dirname+'/'+str(p.relative_to(scratch/dirname)))
 for name in ['analyze-csharp-historical-evidence.py','summarize-csharp-historical-diagnostics.py','read-csharp-diagnostics-compact.py','read-csharp-historical-small-sources.py','read-csharp-registry-catalogs.py','read-csharp-catalog-summary.py','read-csharp-json-states-compact.py','read-csharp-prior-review.py','read-csharp-ledger-current.py','inspect-csharp-complete-inputs.py','find-csharp-final-counterparts.py','find-code-change-counterpart.py','draft-csharp-complete-comparison.py',Path(__file__).name]:archive(scratch/name,'supplied-procedures/'+name)
 logs=['csharp-historical-small-sources-driver.log','read-csharp-small-sources-repeat-driver.log','csharp-historical-dependencies-full-driver.log','csharp-historical-runner-command-full-driver.log','csharp-historical-runner-images-full-driver.log','read-csharp-diagnostics-0-52-driver.log','read-csharp-diagnostics-52-104-driver.log','read-csharp-json-states-compact-driver.log','read-csharp-catalog-summary-driver.log','read-csharp-prior-review-driver.log','read-csharp-ledger-current-driver.log','inspect-csharp-complete-inputs-driver.log','find-csharp-final-counterparts-driver.log','find-code-change-counterpart-driver.log','draft-csharp-complete-comparison-driver.log','draft-csharp-complete-comparison-corrected-driver.log','draft-csharp-complete-comparison-final-driver.log']
 for name in logs:archive(scratch/name,'review-attempts/'+name)
 (target/'records.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in records))
 docs=root/'docs/case-studies/issue-1580/templates';rows=list(map(json.loads,(source/'files.jsonl').read_text().splitlines()))
 for row in rows:
  if row['readEvidence'].startswith('csharp-historical-comparison/'):
   row['readEvidence']=str(target.relative_to(root))+'/'+row['readEvidence']+'.gz'
  assert all((root/path).exists() for path in row['formalAiComparison'])
 (docs/'csharp-complete-files.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in rows))
 result={**summary,'reviewedAt':datetime.now(timezone.utc).isoformat(),'filesReceipt':'csharp-complete-files.jsonl','scope':'Complete per-file source applicability comparison at the selected pinned current C# tree; distinct literal, unchanged-source carry, structured log/JSON and catalog methods.','verification':{'currentUpstreamBunTestsPreviouslyPassed':18,'mergedChangesetTests':2,'pipelineGateTests':16,'releaseWorkflowPolicySuiteExecuted':False,'dotnetBuildOrPublicationExecutedLocally':False},'evidence':str(target.relative_to(root)),'limits':['All 310 diagnostic occurrences were grouped into 104 exact messages and reviewed with the complete original field/line locations retained. Controlled negative probes and quoted commands are not treated as current workflow annotations.','All 79 JSON artifacts retain complete recursive schemas and terminal/error state traversal; twenty small historical sources were read literally. The .NET release table and Alpine HTML catalog use explicit structured methods rather than an inflated literal-read claim.','Large initial catalog/diagnostic previews were truncated; subsequent compact complete diagnostic/state views supply the stated review. Initial source-counterpart guesses and the int-versus-list inspection failure remain retained.','Historical NuGet provider authorization, .NET locked restore, SDK/test and registry snapshots are C# context. They do not require adding that product/toolchain to Formal AI or establish current version/security status.','The current changeset collision repair and strict pipeline gate passed eighteen actual upstream Bun tests in the earlier delta check. This is not hosted workflow, scanner, package publication or proof that every applicable practice is implemented.']}
 (docs/'csharp-complete-file-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
 readme=docs/'README.md';s=readme.read_text();s+='''\n## Complete C# file comparison, 2026-11-21\n\nThe [339-file receipt](csharp-complete-file-comparison.json) binds every blob at\n`a0f2a171dc1ab02ad5d68147656660562f6e1504`: 331 unchanged files carry their\nverified identities and eight changed sources retain the separate delta review.\nThe [per-file decisions](csharp-complete-files.jsonl) give actual Formal AI\ncounterparts and applicability limits. The earlier 158 active files / 18,327\nliteral lines remain a dated review; they are not relabeled as current runtime\nevidence. The remaining 179 historical files use 78 complete log traversals,\n79 recursive JSON/state reviews, twenty literal reads and two catalog traversals.\nAll 104 distinct diagnostic messages were reviewed with their 310 original\nlocations retained. Historical failures and passing snapshots retain their dates.\nThe earlier eighteen actual upstream Bun tests remain narrowly attributed.\nApplicable practice implementation, current hosted CI and wider issue acceptance\nremain unfinished. Supplied procedures and conclusions earn zero independent\nauthorship credit.\n''';readme.write_text(s)
 run('focused-source-identities',['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/template-source-identities.test.mjs'])
 run('evidence-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-reconstructed-changelog,check-file-size'])
 paths=[str(target.relative_to(root)),str((docs/'csharp-complete-files.jsonl').relative_to(root)),str((docs/'csharp-complete-file-comparison.json').relative_to(root)),str(readme.relative_to(root))]
 run('stage',['git','add','--',*paths]);run('staged-whitespace',['git','diff','--cached','--check']);run('commit',['git','commit','-m','Complete pinned C# template comparison with historical evidence limits'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'head':run('head',['git','rev-parse','HEAD']).strip(),'pushed':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
