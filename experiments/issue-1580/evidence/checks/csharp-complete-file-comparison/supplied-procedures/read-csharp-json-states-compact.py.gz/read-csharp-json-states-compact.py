from pathlib import Path
import json,collections
b=Path('/tmp/issue-1580-research/csharp-historical-comparison')
for r in map(json.loads,(b/'structured-content-records.jsonl').read_text().splitlines()):
 if r['method'].startswith('complete-json'):
  states=collections.Counter(str(v['value']) for v in r.get('terminalStates',[]))
  print(json.dumps({'file':r['path'],'leafCount':r['leafCount'],'topKeyCount':len(r['topKeys']),'terminalStateCounts':dict(states)},separators=(',',':')))
