from pathlib import Path
import json,hashlib,gzip,re,collections
base=Path('/tmp/issue-1580-research');root=base/'templates/csharp-complete';out=base/'csharp-historical-comparison';identities=[json.loads(line) for line in (out/'source-identities.jsonl').read_text().splitlines()];records=[];diagnostics=[];other=[]
def walk(value,path=''):
 if isinstance(value,dict):
  for key,child in value.items():yield from walk(child,path+'/'+str(key))
 elif isinstance(value,list):
  for index,child in enumerate(value):yield from walk(child,path+'/'+str(index))
 else:yield path,value
for identity in identities:
 name=identity['path'];raw=(root/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==identity['sha256'];decoded=gzip.decompress(raw) if name.endswith('.gz') else raw;text=decoded.decode();lines=text.splitlines();record={'path':name,'sha256':identity['sha256'],'decodedLines':len(lines)}
 if name.endswith('.json'):
  value=json.loads(text);leaves=list(walk(value));types=collections.Counter(type(value).__name__ for _,value in leaves);record.update(method='complete-json-schema-and-terminal-state-traversal',leafCount=len(leaves),leafTypes=dict(types),topKeys=list(value) if isinstance(value,dict) else ['array:'+str(len(value))])
  states=[{'field':field,'value':value} for field,value in leaves if re.search(r'/(conclusion|status|state|error|errors|severity|vulnerabilityCount)$',field) and isinstance(value,(str,int,bool))]
  record['terminalStates']=states
  for field,value in leaves:
   if isinstance(value,str) and re.search(r'/(body|message|description|error)$',field):
    for index,line in enumerate(value.splitlines()):
     if re.search(r'::(?:error|warning)|\b(?:NU1004|401|403|deprecated|deprecation|deadlock|false positive|false negative|unzipper|Buffer\(|force-evaluate|stop-commands)\b',line,re.I):diagnostics.append({'path':name,'field':field,'fieldLine':index+1,'text':line})
 elif name.endswith('.log') or name.startswith('ci-logs/'):
  found=[]
  for index,line in enumerate(lines):
   if re.search(r'::(?:error|warning)|\b(?:warning|error)\s*[:[]|\b(?:NU1004|401 Unauthorized|403 Forbidden|deprecated|DeprecationWarning)\b',line,re.I):
    found.append(index+1);diagnostics.append({'path':name,'line':index+1,'text':line})
  record.update(method='complete-log-diagnostic-traversal',diagnosticLines=found)
 else:record['method']='requires-literal-or-specialized-content-review';other.append({'path':name,'lines':len(lines),'bytes':len(decoded)})
 records.append(record)
(out/'structured-content-records.jsonl').write_text(''.join(json.dumps(record,separators=(',',':'))+'\n' for record in records))
(out/'historical-diagnostics.jsonl').write_text(''.join(json.dumps(record,separators=(',',':'))+'\n' for record in diagnostics))
print(json.dumps({'files':len(records),'methods':dict(collections.Counter(record['method'] for record in records)),'diagnostics':len(diagnostics),'remainingLiteral':other,'sourceComparisonComplete':False,'fullIssueComplete':False},indent=2))
