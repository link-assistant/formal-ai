from pathlib import Path
import json
root=Path('/tmp/gh-issue-solver-1794900398048/docs/case-studies/issue-1580/templates')
print('FILES',[p.name for p in root.iterdir() if 'csharp' in p.name or 'rust-complete' in p.name])
for name in ['csharp-active-comparison.json','csharp-active-file-comparison.json','csharp-active-completion.json','csharp-current-files.jsonl','rust-complete-file-comparison.json']:
 p=root/name
 if p.exists():
  raw=p.read_text();print('\nFILE',name,'lines',len(raw.splitlines()))
  if name.endswith('jsonl'):print('\n'.join(raw.splitlines()[:2]))
  else:
   data=json.loads(raw);print(json.dumps({k:v for k,v in data.items() if k not in ['files','practices']},indent=2));print('FILES SAMPLE',json.dumps(data.get('files',[])[:2],indent=2));print('PRACTICE SAMPLE',json.dumps(data.get('practices',[])[:3],indent=2))
