from pathlib import Path
import json,collections
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');docs=root/'docs/case-studies/issue-1580/templates'
for filename in ['csharp-partial-semantic-review.json','csharp-current-delta-review.json']:
 data=json.loads((docs/filename).read_text());print(filename)
 print(json.dumps({k:v for k,v in data.items() if k!='files'},indent=2)[:10000])
 rows=data['files'];print('FILE ENTRY SAMPLES',json.dumps(rows[:2],indent=2))
 if 'delta' in filename:
  for row in rows:print(json.dumps(row))
records=[json.loads(line) for line in (scratch/'csharp-historical-comparison/structured-content-records.jsonl').read_text().splitlines()]
print('HISTORY PATHS')
for row in records:print(row['method'],row['path'])
print('CURRENT SOURCE COUNTERPARTS')
terms=['changeset','nuget','artifact','release','codecov','codeql','dotnet','output','minimatch','link-check','lychee','zip','preflight','required-check','default-branch','runner-label','force','lockfile','pages']
paths=[p for p in root.joinpath('scripts').rglob('*') if p.is_file()]+list(root.joinpath('.github/workflows').glob('*'))
for term in terms:
 print(term,','.join(str(p.relative_to(root)) for p in paths if term in p.name.lower()))
