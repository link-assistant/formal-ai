from pathlib import Path
import os,subprocess,json,time
r=Path("/tmp/issue-1580-research/desktop-practice27-review-20261123")
environment=dict(os.environ);environment.pop("NODE_OPTIONS",None)
cmd=["node","--max-old-space-size=192","--test","--test-concurrency=1","rust/tests/web/release-workflow-operation-controls.test.mjs"]
start=time.monotonic()
with (r/"release-workflow-operation-controls-clean-environment.stdout").open("w") as out,(r/"release-workflow-operation-controls-clean-environment.stderr").open("w") as err:
 p=subprocess.run(cmd,stdout=out,stderr=err,env=environment)
(r/"clean-environment-outcome.json").write_text(json.dumps({"command":cmd,"exitCode":p.returncode,"elapsedSeconds":time.monotonic()-start,"NODE_OPTIONS":"absent","head":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"productionGuardUnchanged":True,"independentAuthorshipCredit":0},indent=2)+"\n")
