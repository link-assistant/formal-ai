from pathlib import Path
import subprocess,os,json,time,hashlib,resource
root=Path("/tmp/issue-1580-research/desktop-practice27-review-20261123")
head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
names=["desktop-release-source-attribution","release-workflow-operation-controls","issue-1181-cli-release-assets"]
records=[]
for name in names:
 cmd=["node","--test","--test-concurrency=1","rust/tests/web/"+name+".test.mjs"]
 started=time.monotonic()
 with (root/(name+".stdout")).open("w") as out,(root/(name+".stderr")).open("w") as err:
  p=subprocess.run(cmd,stdout=out,stderr=err,env={**os.environ,"NODE_OPTIONS":"--max-old-space-size=192"})
 records.append({"name":name,"command":cmd,"head":head,"exitCode":p.returncode,"seconds":time.monotonic()-started})
 (root/"results.json").write_text(json.dumps(records,indent=2)+"\n")
(root/"outcome.json").write_text(json.dumps({"complete":True,"passed":all(x["exitCode"]==0 for x in records),"head":head,"results":records,"hostedPublicationExecuted":False,"independentAuthorshipCredit":0},indent=2)+"\n")
