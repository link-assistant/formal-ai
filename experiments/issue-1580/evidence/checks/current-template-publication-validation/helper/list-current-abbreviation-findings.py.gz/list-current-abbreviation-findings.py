from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-template-abbreviation-repair');out.mkdir(exist_ok=False)
source="import {measureAbbreviations,fullWordPath} from './scripts/measure-abbreviations.mjs'; import {readRules} from './scripts/lib/links-notation-names.mjs'; import {readFileSync} from 'node:fs'; const rules=readRules(readFileSync('data/meta/notation-rules.lino','utf8')); console.log(JSON.stringify(measureAbbreviations().get('file-names').list.map(path=>({path,proposed:fullWordPath(path,rules.abbreviations)})),null,2));"
r=subprocess.run(['node','--max-old-space-size=256','--input-type=module','-e',source],cwd=root,capture_output=True,check=True)
(out/'all-findings.json').write_bytes(r.stdout)
changed=set(subprocess.check_output(['git','diff','--name-only','adeb4ff46c4bb162a82aacbeb0c38bbe9aeebd1a','HEAD'],cwd=root,text=True).splitlines())
new=[item for item in json.loads(r.stdout) if item['path'] in changed]
(out/'new-findings.json').write_text(json.dumps(new,indent=2)+'\n')
(out/'first-failure.log').write_bytes((root/'experiments/formal_ai_subagent/sandboxes/gates/check-abbreviations.log').read_bytes())
print(json.dumps({'newFindings':new,'allCount':len(json.loads(r.stdout))}))
