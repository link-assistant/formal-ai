from pathlib import Path
import json,subprocess,sys
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-template-findings-verification')
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('wb') as stream:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'pid.json').write_text(json.dumps({'pid':p.pid})+'\n');print(json.dumps({'pid':p.pid,'work':'maintained entry followed by six focused JavaScript checks'}));raise SystemExit(0)
import os,time
results=[]
commands=[('maintained-entry',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])]
commands += [(gate,['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]) for gate in ['check-abbreviations','check-file-size','check-readable-code','check-ci-speed','check-runner-labels']]
commands += [('tests-as-docs',['node','--max-old-space-size=256','scripts/check-tests-as-docs.mjs'])]
for name,arguments in commands:
 start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:r=subprocess.run(arguments,cwd=root,stdout=stdout,stderr=stderr)
 results.append({'name':name,'exitCode':r.returncode,'seconds':round(time.monotonic()-start,3)});print(json.dumps(results[-1]),flush=True)
 (out/'partial.json').write_text(json.dumps(results,indent=2)+'\n')
paths=subprocess.check_output(['git','diff','--name-only','-z','adeb4ff46c4bb162a82aacbeb0c38bbe9aeebd1a','HEAD'],cwd=root)
selected=[path for path in paths.split(bytes([0])) if path and (root/os.fsdecode(path)).is_file()]
(out/'selection.json').write_text(json.dumps([os.fsdecode(p) for p in selected],indent=2)+'\n')
environment={**os.environ,'SECRETLINT_VERSION':'14.0.0','PATH':'/tmp/issue-1580-research/secretlint-built-in-migration/dependencies/node_modules/.bin'+os.pathsep+os.environ['PATH']}
with (out/'secrets.stdout').open('wb') as stdout,(out/'secrets.stderr').open('wb') as stderr:r=subprocess.run(['node','--max-old-space-size=256','scripts/check-secrets-files.mjs'],cwd=root,env=environment,input=bytes([0]).join(selected)+bytes([0]),stdout=stdout,stderr=stderr)
results.append({'name':'actual-secretlint-14','exitCode':r.returncode,'selectedFiles':len(selected)})
(out/'outcome.json').write_text(json.dumps({'results':results,'allPassed':all(row['exitCode']==0 for row in results),'fullIssueComplete':False},indent=2)+'\n');print(json.dumps(results[-1]),flush=True)
