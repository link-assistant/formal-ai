from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
result=json.loads((scratch/'current-template-findings-verification/outcome.json').read_text())
assert [r['name'] for r in result['results'] if r['exitCode']!=0]==['check-abbreviations']
repair=json.loads((scratch/'current-template-abbreviation-repair/outcome.json').read_text());assert repair['retryExitCode']==0 and not repair['ratchetChanged']
assert (scratch/'current-template-findings-verification/maintained-entry.stderr').stat().st_size==0
assert 'tests 123' in (scratch/'current-template-findings-verification/maintained-entry.stdout').read_text()
target=root/'experiments/issue-1580/evidence/checks/current-template-publication-validation';target.mkdir(exist_ok=False)
records=[]
def retain(path,name):
 raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);filename=name.replace('tests-as-docs','tests-as-documentation')+'.gz';(target/filename).parent.mkdir(parents=True,exist_ok=True);(target/filename).write_bytes(packed)
 records.append({'source':str(path),'file':filename,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
for directory in ['current-template-findings-verification','current-template-abbreviation-repair','current-size-native-status']:
 for path in sorted((scratch/directory).iterdir()):
  if path.is_file():retain(path,directory+'/'+path.name)
for name in ['verify-current-template-findings','list-current-abbreviation-findings','repair-current-template-abbreviation-names','inspect-current-size-and-native-status','seal-current-template-publication-validation']:
 retain(scratch/(name+'.py'),'helper/'+name+'.py')
 if (scratch/(name+'.log')).exists() and name!='seal-current-template-publication-validation':retain(scratch/(name+'.log'),'helper/'+name+'.log')
for row in records:
 packed=(target/row['file']).read_bytes();raw=gzip.decompress(packed)
 assert hashlib.sha256(raw).hexdigest()==row['rawSha256'] and hashlib.sha256(packed).hexdigest()==row['archiveSha256']
(target/'records.json').write_text(json.dumps({'records':records,'allHashesVerified':True,'maintainedTestsPassed':123,'maintainedTestsSkipped':0,'finalTouchedChecksPassed':True,'initialFailurePreserved':True,'sourceWarningsOpen':91,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
doc=root/'docs/case-studies/issue-1580/python-current-findings-checkpoint.md'
with doc.open('a') as f:f.write('''

The complete maintained template-observation entry passes all 123 cases,
without skips, in 81.8 seconds. Four repository gates, the direct JavaScript
documentation checker and the actual Secretlint 14 engine also pass; the
abbreviation gate initially rejects five new archive aliases (95 against 90).
Renaming those aliases to full words restores 90 without changing the ratchet,
raw evidence, archive bytes or original upstream source paths. Its targeted
retry passes. All six intended checks now have successful evidence; the
initial failure is preserved separately. The actual scanner passes all 142
changed files, including 128 compressed streams, before the final validation
archives are added.

An independent source-size inventory confirms 91 warnings, zero violations
and zero embedded-data violations under unchanged limits. The first ad hoc
inventory command exceeded Node's default child-output buffer; its captured
ENOBUFS result and a successful 32 MiB bounded-buffer retry are retained.
These warnings remain unfinished. The final validation evidence is under
experiments/issue-1580/evidence/checks/current-template-publication-validation/ .
''')
with (root/'experiments/issue-1580/work-plan.md').open('a') as f:f.write('''

- [x] Complete the current maintained observation entry: 123 passed, zero
  skipped; verify touched JavaScript gates and direct documentation checker.
- [x] Preserve and repair five abbreviated archive aliases without changing
  evidence bytes or the ratchet. The targeted retry restores the 90 ceiling.
- [x] Run the actual Secretlint 14 engine on all 142 changed files / 128
  compressed streams before these final validation archives.
- [ ] Qualify the final retained archives and terminal preceding-head hosted
  logs before the next single push. Current source-size warnings remain 91.
''')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--',str(target.relative_to(root)),str(doc.relative_to(root)),'experiments/issue-1580/work-plan.md'],cwd=root,check=True)
subprocess.run(['git','commit','-m','docs: retain successful template validation and naming repair'],cwd=root,check=True)
print(json.dumps({'retainedRecords':len(records),'maintainedTestsPassed':123,'sourceWarningsOpen':91,'pushExecuted':False,'fullIssueComplete':False}))
