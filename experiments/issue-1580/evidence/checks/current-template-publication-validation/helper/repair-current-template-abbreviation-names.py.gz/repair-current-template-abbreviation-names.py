from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research/current-template-abbreviation-repair')
target=root/'experiments/issue-1580/evidence/checks/current-template-findings';manifest=target/'records.json';data=json.loads(manifest.read_text())
renames=json.loads((scratch/'new-findings.json').read_text());assert len(renames)==5
for item in renames:
 old=root/item['path'];new=root/item['proposed'];assert old.is_file() and not new.exists()
 packed=old.read_bytes();old.rename(new);assert new.read_bytes()==packed
 row=next(row for row in data['records'] if row['file']==str(old.relative_to(target)))
 row['file']=str(new.relative_to(target));assert hashlib.sha256(packed).hexdigest()==row['archiveSha256']
manifest.write_text(json.dumps(data,indent=2)+'\n')
for row in data['records']:
 packed=(target/row['file']).read_bytes();raw=gzip.decompress(packed)
 assert hashlib.sha256(raw).hexdigest()==row['rawSha256'] and hashlib.sha256(packed).hexdigest()==row['archiveSha256']
with (scratch/'retry.stdout').open('wb') as stdout,(scratch/'retry.stderr').open('wb') as stderr:r=subprocess.run(['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations'],cwd=root,stdout=stdout,stderr=stderr)
(scratch/'retry-detail.log').write_bytes((root/'experiments/formal_ai_subagent/sandboxes/gates/check-abbreviations.log').read_bytes())
(scratch/'outcome.json').write_text(json.dumps({'renamedFiles':len(renames),'retryExitCode':r.returncode,'retainedRawAndArchiveHashesUnchanged':True,'ratchetChanged':False,'fullIssueComplete':False},indent=2)+'\n')
print((scratch/'outcome.json').read_text())
assert r.returncode==0
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--',str(target.relative_to(root))],cwd=root,check=True)
subprocess.run(['git','commit','-m','chore: spell archived template evidence names in full'],cwd=root,check=True)
