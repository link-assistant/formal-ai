from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/current-size-native-status');out.mkdir(exist_ok=True)
script="import {checkListedFiles} from './scripts/check-file-size.mjs'; import {execFileSync} from 'node:child_process'; const files=new Set(execFileSync('git',['ls-files','-z','--cached','--others','--exclude-standard']).toString().split('\\0').filter(Boolean)); console.log(JSON.stringify(checkListedFiles(process.cwd(),files),null,2));"
original=subprocess.run(['node','--max-old-space-size=256','--input-type=module','-e',script],cwd=root,capture_output=True)
(out/'first-size.stdout').write_bytes(original.stdout);(out/'first-size.stderr').write_bytes(original.stderr)
assert original.returncode!=0
script=script.replace("'--exclude-standard'])","'--exclude-standard'],{maxBuffer:33554432})")
for name,args in [('size',['node','--max-old-space-size=256','--input-type=module','-e',script]),('jobs',['gh','run','view','44882210284','--repo','link-assistant/formal-ai','--json','jobs,status,conclusion,headSha'])]:
 r=subprocess.run(args,cwd=root,capture_output=True);(out/(name+'.json')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
 assert r.returncode==0,(name,r.stderr.decode()[-2000:])
 data=json.loads(r.stdout)
 if name=='size':
  (out/'warnings.txt').write_text('\n'.join(f"{item['lines']:4}/{item['warnLines']} {item['file']}" for item in data['warnings'])+'\n')
  print(json.dumps({'name':name,'warnings':len(data['warnings']),'violations':len(data['violations']),'embeddedDataViolations':len(data['embeddedDataViolations'])}))
 else:
  summary={'head':data['headSha'],'status':data['status'],'conclusion':data['conclusion'],'jobs':[{'name':j['name'],'status':j['status'],'conclusion':j['conclusion']} for j in data['jobs'] if j['conclusion']!='skipped']}
  (out/'job-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'name':name,'status':data['status'],'jobs':len(summary['jobs'])}))
