from pathlib import Path
import collections
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

root = Path.cwd()
scratch = Path('/tmp/issue-1580-research')
base = root / 'docs/case-studies/issue-1580/templates'
summary_path = base / 'current-tree-comparison-20261123.json'
summary = json.loads(summary_path.read_text())
packed = (base / summary['receipt']).read_bytes()
decoded = gzip.decompress(packed)
assert hashlib.sha256(packed).hexdigest() == summary['compressedSha256']
assert hashlib.sha256(decoded).hexdigest() == summary['decodedSha256']
rows = [json.loads(line) for line in decoded.splitlines()]
assert len(rows) == summary['totalBlobs'] == 3028
assert len({(row['language'], row['path']) for row in rows}) == len(rows)
payloads = {
    'summary.json': summary_path,
    'comparison.jsonl.gz': base / summary['receipt'],
    'reconcile.py': scratch / 'reconcile-current-template-trees.py',
    'verify-and-archive.py': Path(__file__),
    'registry-probe.py': scratch / 'refresh-registry-index-boundaries.py',
}
verification = []
for template in summary['templates']:
    language = template['language']
    short = 'js' if language == 'javascript' else language
    changed = scratch / 'fresh-template-deltas' / language / 'new-tree.json'
    source = changed if changed.exists() else scratch / 'fresh-template-delta-sources/trees' / (short + '.json')
    tree = json.loads(source.read_text())
    assert tree.get('sha') == template['head']
    assert not tree.get('truncated')
    blobs = {entry['path']: entry['sha'] for entry in tree['tree'] if entry['type'] == 'blob'}
    actual = {row['path']: row['gitBlob'] for row in rows if row['language'] == language}
    assert actual == blobs
    counts = collections.Counter(row['method'] for row in rows if row['language'] == language)
    assert counts['exact-prior-blob-applicability-carry'] == template['exactPriorBlobCarry']
    assert counts['verified-complete-delta-with-prior-comparison'] == template['verifiedCurrentDelta']
    payloads['trees/' + language + '.json'] = source
    verification.append({'language': language, 'head': template['head'], 'completePathAndBlobUnion': True, 'blobs': len(blobs)})

dependency_dir = scratch / 'current-dependency-boundaries-20261123'
observations = json.loads((dependency_dir / 'index-observation.json').read_text())
for observation in observations:
    name = observation['crate']
    raw = (dependency_dir / (name + '-index.jsonl')).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == observation['sha256']
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == observation['gitBlob']
    versions = [json.loads(line) for line in raw.splitlines()]
    stable = [entry for entry in versions if not entry['yanked'] and '-' not in entry['vers']]
    latest = max(stable, key=lambda entry: tuple(map(int, entry['vers'].split('.'))))
    assert latest['vers'] == observation['latest']
    assert latest['cksum'] == observation['checksum']
    assert any(dep['name'] == 'chrono' and dep['kind'] == 'normal' and not dep['optional'] for dep in latest['deps'])
for path in dependency_dir.iterdir():
    if path.is_file():
        payloads['registry/' + path.name] = path

verified = {'templates': verification, 'registryEntriesVerified': len(observations),
            'literalWholeFileRereadClaim': False, 'newRuntimeQualification': False}
payloads['independent-verification.json'] = (json.dumps(verified, indent=2) + '\n').encode()
destination = root / 'experiments/issue-1580/evidence/checks/current-tree-and-registry-20261123'
destination.mkdir(exist_ok=False)
inventory = []
with tarfile.open(destination / 'complete-replay.tar.gz', 'w:gz', compresslevel=1) as archive:
    for name, value in sorted(payloads.items()):
        raw = value.read_bytes() if isinstance(value, Path) else value
        member = tarfile.TarInfo(name)
        member.size = len(raw)
        archive.addfile(member, io.BytesIO(raw))
        inventory.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
with tarfile.open(destination / 'complete-replay.tar.gz') as archive:
    for member in inventory:
        assert hashlib.sha256(archive.extractfile(member['path']).read()).hexdigest() == member['sha256']
(destination / 'payloads.json.gz').write_bytes(gzip.compress((json.dumps(inventory, indent=2) + '\n').encode(), mtime=0))
manifest = {'comparisonSource': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
            'templateBlobs': len(rows), 'templates': verification, 'registryObservations': [
                {key: item[key] for key in ['crate', 'at', 'latest', 'gitBlob', 'sha256', 'checksum']}
                for item in observations],
            'payloadCount': len(inventory), 'roundTripVerified': True,
            'archiveSha256': hashlib.sha256((destination / 'complete-replay.tar.gz').read_bytes()).hexdigest(),
            'completePracticeImplementationAndVerification': False, 'fullIssueComplete': False,
            'independentAuthorshipCredit': 0}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')

doc = root / 'docs/case-studies/issue-1580/current-comparison-checkpoint-20261123.md'
doc.write_text('''# Complete source comparison and current dependency checkpoint

The selected complete trees of all eight templates now have a reconciled,
path-by-path comparison basis: **3,028 blobs**. The
[summary](templates/current-tree-comparison-20261123.json) records every selected
commit and exact count. Of these, 2,993 preserve the exact previously compared
blob; 35 have the complete reviewed current delta and prior comparison basis.
The compressed JSONL receipt preserves each decision without treating a delta
review as a new literal reading of the whole file. Both receipt hashes and every
complete tree's path/blob union were independently checked. Two Go records now
name the actual Formal AI runner-recovery workflow. Earlier dated comparison
receipts remain historical observations.

| Template | Compared blobs |
| --- | ---: |
| JavaScript | 566 |
| Rust | 374 |
| Python | 340 |
| PHP | 611 |
| C# | 339 |
| Java | 207 |
| C++ | 552 |
| Go | 39 |

Complete source comparison does not by itself establish implementation and
execution of every applicable practice. In particular, the actual native
artifact full-workflow and consumer-only reruns, the new included-string CodeQL
query, original production-only budgets and live external authorization remain
separate qualification obligations. The 74 older Rust practice observations
retain their dates; later source and hosted receipts must be consulted before
interpreting an old pending label as a current defect. Historical screenshot
examples or upstream Maven publication do not introduce unrelated Formal AI
features or require repairing another repository before its reported issue can
be considered reported.

The UTF-8 release-note counterpart already exists in
`scripts/create-github-release.rs`: it measures the complete body in bytes,
truncates only at a character boundary and reserves its notice and metrics
suffix. The actual compiled CLI fixture
`test_release_cli_preserves_unicode_byte_cap_and_metric_suffix` exercises mixed
Unicode, the complete changelog URL and the preserved suffix. Its containing
release-registry suite passed hosted job `137405085825` on source `b459d0b0`.
This is a suite/source binding; the log does not print individual method names.

At 01:23 UTC on 23 November, the public crates.io index still selects
`command-stream` 1.13.0 and `link-calculator` 0.24.0 as their latest non-yanked
stable releases. Both retain a normal, required Chrono dependency. Complete
index entries, their Git object identities, version checksums and observation
times are retained. An unpublished upstream source migration and a successful
audit under a documented exception do not establish that the vulnerable
dependency has been removed from the published dependency closure. That
criterion remains open; upgrading blindly to these versions would not resolve
it.

The [lossless checkpoint archive](../../../experiments/issue-1580/evidence/checks/current-tree-and-registry-20261123/manifest.json)
retains complete trees, registry responses and decoded indexes, procedures and
independent verification. Every archived payload was read back and hash checked.
No local Rust build ran. Supplied work earns zero independent authorship credit.
Issue #1580 remains unfinished and PR #1581 remains unmerged.
''')
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('''

## Current complete comparison checkpoint, 2026-11-23

- [x] Push the combined native/link batch as `cec9207c3` after an empty current
  queue and fresh-main ancestry check; update the actual PR title and body.
- [x] Reconcile all eight complete selected template trees: 3,028 distinct blobs,
  2,993 exact prior comparison carries and 35 reviewed current deltas. Verify
  every path/blob union and correct the two stale Go counterpart references.
- [x] Reobserve both current published crate indexes; verify exact Git objects,
  checksums and latest non-yanked stable versions. Both still require Chrono.
- [ ] Finish the current hosted cohort and read every actual failing diagnostic.
- [ ] Qualify the actual included-string CodeQL producer and both native artifact
  rerun paths; reconcile remaining practice observations with specific evidence.
- [ ] Complete all original acceptance criteria, including genuinely blocked
  external dependencies and production-only qualification. Keep the PR draft
  and unmerged while any criterion is unfinished.

See `current-comparison-checkpoint-20261123.md` for the current source checkpoint.
No new GPU feature, upstream Maven release or independent-reasoning release gate
is inferred from historical examples. Supplied work retains zero credit.
''')
subprocess.run(['git', 'diff', '--check'], check=True)
print(json.dumps({'verifiedBlobs': len(rows), 'archivedPayloads': len(inventory),
                  'registryLatest': {item['crate']: item['latest'] for item in observations},
                  'archiveBytes': (destination / 'complete-replay.tar.gz').stat().st_size}))
