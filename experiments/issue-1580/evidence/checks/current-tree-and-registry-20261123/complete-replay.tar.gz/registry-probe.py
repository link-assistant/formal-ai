from pathlib import Path
import subprocess,json,base64,hashlib,datetime
out=Path('/tmp/issue-1580-research/current-dependency-boundaries-20261123')
rows=[]
for name,path in [('command-stream','co/mm/command-stream'),('link-calculator','li/nk/link-calculator')]:
 endpoint='repos/rust-lang/crates.io-index/contents/'+path
 result=subprocess.run(['gh','api',endpoint],capture_output=True)
 (out/(name+'-index-envelope.json')).write_bytes(result.stdout)
 (out/(name+'-index.stderr')).write_bytes(result.stderr)
 record={'crate':name,'command':['gh','api',endpoint],'exitCode':result.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 if result.returncode==0:
  doc=json.loads(result.stdout);raw=base64.b64decode(doc['content'])
  assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==doc['sha']
  (out/(name+'-index.jsonl')).write_bytes(raw)
  versions=[json.loads(x) for x in raw.splitlines()]
  stable=[x for x in versions if not x['yanked'] and '-' not in x['vers']]
  latest=max(stable,key=lambda x:tuple(map(int,x['vers'].split('.'))))
  record.update(gitBlob=doc['sha'],sha256=hashlib.sha256(raw).hexdigest(),versions=len(versions),latest=latest['vers'],dependencies=latest['deps'],checksum=latest['cksum'])
 rows.append(record)
(out/'index-observation.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:
 print(json.dumps({**{k:v for k,v in row.items() if k!='dependencies'},'timeDependencies':[x for x in row.get('dependencies',[]) if x['name'] in ['chrono','jiff','time']]},ensure_ascii=False))
