from pathlib import Path
import json,gzip,hashlib,collections,datetime

root=Path.cwd()
base=root/'docs/case-studies/issue-1580/templates'
scratch=Path('/tmp/issue-1580-research')
delta=scratch/'fresh-template-deltas'
older=scratch/'fresh-template-delta-sources/trees'
changes={x['language']:x for x in json.loads((delta/'checkpoint.json').read_text())}
languages=['javascript','rust','python','php','csharp','java','cpp','go']
rows=[];summaries=[];corrections=[]
for language in languages:
 short='js' if language=='javascript' else language
 if language=='java':
  refs=['java-active-semantic-review.json','java-historical-semantic-comparison.json']
  previous=[x for name in refs for x in json.loads((base/name).read_text())['files']]
 elif language=='go':
  refs=['go-current-semantic-review.json']
  previous=json.loads((base/refs[0]).read_text())['files']
 else:
  refs=[language+'-complete-files.jsonl']
  previous=[json.loads(x) for x in (base/refs[0]).read_text().splitlines()]
 bypath={x['path']:x for x in previous};assert len(bypath)==len(previous)
 change=changes.get(language)
 if change:
  tree=json.loads((delta/language/'new-tree.json').read_text())
  altered={x['path']:x for x in json.loads((delta/language/'files.json').read_text())}
  head=change['after']
 else:
  tree=json.loads((older/(short+'.json')).read_text());altered={}
  identity=json.loads((base/(language+'-complete-file-comparison.json')).read_text())
  head=identity.get('pinnedHead',identity.get('sourceCommit'));assert head
 assert not tree.get('truncated')
 blobs={x['path']:x for x in tree['tree'] if x['type']=='blob'}
 carried=0;updated=0
 for path,blob in sorted(blobs.items()):
  old=bypath.get(path)
  if old and old['gitBlob']==blob['sha']:
   method='exact-prior-blob-applicability-carry';carried+=1
   record={'language':language,'head':head,'path':path,'gitBlob':blob['sha'],'method':method,'priorReceipt':refs,'priorPath':path,'priorSha256':old.get('sha256'),'priorDecision':old['decision'],'formalAiComparison':old.get('formalAiComparison',[]),'newRuntimeQualification':False}
  else:
   assert path in altered,(language,path)
   entry=altered[path];assert entry['after']['sha']==blob['sha']
   raw=(delta/language/(entry['envelope']+'-after.source')).read_bytes()
   assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob['sha']
   assert hashlib.sha256(raw).hexdigest()==entry['afterSha256']
   method='verified-complete-delta-with-prior-comparison';updated+=1
   record={'language':language,'head':head,'path':path,'gitBlob':blob['sha'],'sha256':entry['afterSha256'],'method':method,'priorReceipt':refs,'priorPath':path if old else None,'priorDecision':old.get('decision') if old else None,'deltaReceipt':'experiments/issue-1580/evidence/checks/template-delta-20261122/manifest.json','deltaOverview':'docs/case-studies/issue-1580/template-delta-20261122.md','literalWholeFileRereadClaim':False,'newRuntimeQualification':False}
  # Referenced Formal AI counterparts are physical paths, not name-only guesses.
  counterparts=record.get('formalAiComparison',[])
  for i,counterpart in enumerate(counterparts):
   if counterpart=='.github/workflows/rerun-unacquired.yml' and not (root/counterpart).exists():
    replacement='.github/workflows/recover-unacquired-runners.yml'
    corrections.append({'language':language,'path':path,'oldCounterpart':counterpart,'currentCounterpart':replacement,'basis':'Actual production recovery workflow; the 27-case hosted decision-policy receipt is runner-and-artifact-practices/manifest.json.'})
    counterparts[i]=replacement
   assert (root/counterparts[i]).exists(),(language,path,counterparts[i])
  rows.append(record)
 removed=sorted(set(bypath)-set(blobs))
 for path in removed:assert path in altered and altered[path]['after'] is None,(language,path)
 summaries.append({'language':language,'repository':'link-foundation/'+('js' if language=='javascript' else language)+'-ai-driven-development-pipeline-template','head':head,'blobs':len(blobs),'exactPriorBlobCarry':carried,'verifiedCurrentDelta':updated,'removed':removed,'allTreePathsHaveComparisonBasis':carried+updated==len(blobs),'treeTruncated':False,'priorReceipts':refs})

out=base/'current-tree-comparison-20261123.jsonl.gz'
raw=''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in rows).encode()
packed=gzip.compress(raw,mtime=0)
assert gzip.decompress(packed)==raw
out.write_bytes(packed)
summary={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Reconcile the already compared complete source trees with the complete reviewed 22 November deltas. Preserve exact prior decisions and distinguish delta comparison from new whole-file reading and runtime execution. Selected source identities are frozen for this checkpoint.','templates':summaries,'totalBlobs':len(rows),'allEightCompleteTreePathUnionsVerified':len(summaries)==8 and all(x['allTreePathsHaveComparisonBasis'] for x in summaries),'counterpartCorrections':corrections,'receipt':out.name,'compressedSha256':hashlib.sha256(packed).hexdigest(),'decodedSha256':hashlib.sha256(raw).hexdigest(),'completePracticeImplementationAndVerification':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(base/'current-tree-comparison-20261123.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
