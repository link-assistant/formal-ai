import datetime, json, os, subprocess, time
from pathlib import Path

root = Path('/tmp/issue-1580-research/registration-touched-gates')
root.mkdir(exist_ok=False)
env = {**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}
checks = [('native-policy', ['timeout', '600', 'node', '--test', '--test-concurrency=1', 'experiments/issue-1580/native-regression-groups.test.mjs'])]
for gate in ['check-file-size', 'check-file-size-js-twin', 'check-tests-as-docs', 'check-tests-as-documentation-javascript-twin', 'check_js_rust_translation', 'check-wasm-worker-current', 'check-minimal-core-boundary', 'check-minimal-core-boundary-js-twin', 'check-generate-module-map-js-twin', 'check-required-documentation']:
    checks.append((gate, ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', gate]))
records = []
for label, command in checks:
    started = time.monotonic()
    with (root / (label + '.log')).open('w') as output:
        completed = subprocess.run(command, env=env, stdout=output, stderr=subprocess.STDOUT)
    records.append({'label': label, 'command': command, 'exitCode': completed.returncode, 'elapsedSeconds': round(time.monotonic() - started, 3)})
    (root / 'latest.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(records[-1]), flush=True)
(root / 'outcome.json').write_text(json.dumps({'records': records, 'failed': sum(row['exitCode'] != 0 for row in records), 'rustExecuted': False, 'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2) + '\n')
