from pathlib import Path
from datetime import datetime, timezone
import json, urllib.request, hashlib

out = Path('/tmp/issue-1580-research/migration-publications-20261122-2105')
out.mkdir(exist_ok=False)
summary = []
for crate in ['command-stream', 'link-calculator']:
    def get(suffix, name):
        url = 'https://crates.io/api/v1/crates/' + crate + suffix
        request = urllib.request.Request(url, headers={'User-Agent': 'formal-ai-issue-1580-dependency-investigation'})
        with urllib.request.urlopen(request, timeout=20) as response:
            raw = response.read(2 * 1024 * 1024 + 1)
        assert len(raw) <= 2 * 1024 * 1024
        (out / name).write_bytes(raw)
        return json.loads(raw), {'url': url, 'file': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    metadata, receipt = get('', crate + '.json')
    latest = metadata['crate']['max_stable_version']
    dependencies, dependency_receipt = get('/' + latest + '/dependencies', crate + '-dependencies.json')
    chrono = [item for item in dependencies['dependencies'] if item['crate_id'] == 'chrono']
    summary.append({'crate': crate, 'latestStable': latest, 'chrono': chrono, 'metadata': receipt, 'dependencies': dependency_receipt})
record = {'checkedAt': datetime.now(timezone.utc).isoformat(), 'observations': summary, 'independentAuthorshipCredit': 0}
(out / 'summary.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2), flush=True)
