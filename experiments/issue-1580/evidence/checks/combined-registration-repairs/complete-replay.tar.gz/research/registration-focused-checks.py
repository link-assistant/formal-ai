import datetime, json, os, subprocess, time
from pathlib import Path

root = Path('/tmp/issue-1580-research/registration-focused-checks')
root.mkdir(exist_ok=False)
env = {**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}
checks = [
    ('source-placement', ['timeout', '600', 'node', '--test', '--test-concurrency=1', 'rust/tests/web/source-test-placement-twin.test.mjs']),
    ('fast-pr-profile', ['timeout', '600', 'node', '--test', '--test-concurrency=1', 'rust/tests/web/fast-pull-request-production-profile.test.mjs']),
    ('hive-complete', ['timeout', '600', 'node', '--test', '--test-concurrency=1', 'rust/tests/web/hive-work-item-consumer.test.mjs']),
    ('practical-help', ['timeout', '600', 'node', '--test', '--test-concurrency=1', 'rust/tests/web/issue-1395-practical-help.test.mjs']),
    ('rustfmt', ['rustfmt', '--edition', '2024', '--check', 'scripts/release-changelog.rs', 'rust/src/solver_helpers/code.rs', 'rust/tests/fixtures/practical-help-tests.rs', 'rust/tests/unit/reasoning_contracts.rs', 'rust/tests/unit/specification/prompt_variations_facts.rs', 'rust/tests/unit/specification/pronoun_topic_follow_up.rs', 'rust/tests/unit/specification/synthesis.rs', 'rust/tests/fixtures/fact-claims/publisher_transport.rs', 'rust/tests/unit/solver/javascript_program.rs']),
]
records = []
for label, command in checks:
    started = time.monotonic()
    with (root / (label + '.log')).open('w') as output:
        completed = subprocess.run(command, env=env, stdout=output, stderr=subprocess.STDOUT)
    records.append({'label': label, 'command': command, 'exitCode': completed.returncode, 'elapsedSeconds': round(time.monotonic() - started, 3)})
    (root / 'latest.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(records[-1]), flush=True)
(root / 'outcome.json').write_text(json.dumps({'records': records, 'failed': sum(row['exitCode'] != 0 for row in records), 'rustExecuted': False, 'completedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2) + '\n')
