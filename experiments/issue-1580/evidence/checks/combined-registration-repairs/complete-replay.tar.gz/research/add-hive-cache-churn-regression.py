from pathlib import Path

path = Path('experiments/issue-1580/native-hive-fixture-probe.mjs')
source = path.read_text()
old = "import {Capability} from '../../js/agentic/capability.mjs';"
source = source.replace(old, old + "\nimport {cachedSourceFetch} from '../../js/agentic/crate/source_cache.mjs';")
old = "const traceSourceOwners=process.argv.includes('--trace-source-owners');"
source = source.replace(old, old + "\nconst inheritedSourceCache=process.env.FORMAL_AI_SOURCE_CACHE_DIR;\nconst churnInheritedSourceCache=process.argv.includes('--churn-inherited-source-cache');\nif(churnInheritedSourceCache&&!inheritedSourceCache)throw Error('cache churn requires an explicit disposable inherited source cache');")
old = "    const started=Date.now();\n    const plan=await planChatStepResolved"
new = """    const started=Date.now();
    if(churnInheritedSourceCache&&turn===12){
      // A separate suite may update the caller cache between a write and delivery.
      // Only an explicitly supplied disposable directory is touched by this control.
      const bodies=new Map([
        ['https://api.github.com/repos/actions/checkout/releases/latest','{"tag_name":"v99.0.0"}'],
        ['https://api.github.com/repos/actions/checkout/commits/v99.0.0','{"sha":"1111111111111111111111111111111111111111"}'],
      ]);
      const fetch=cachedSourceFetch({cacheDir:inheritedSourceCache,online:true,io:{
        readText:file=>{try{return fs.readFileSync(file,'utf8');}catch{return null;}},
        readBytes:file=>{try{return new Uint8Array(fs.readFileSync(file));}catch{return null;}},
        writeBytes:fs.writeFileSync,createDirAll:folder=>fs.mkdirSync(folder,{recursive:true}),
        get:url=>bodies.has(url)?new TextEncoder().encode(bodies.get(url)):null,
      }});
      for(const url of bodies.keys())if(fetch(url)===null)throw Error('cache churn control did not write capture');
    }
    const plan=await planChatStepResolved"""
assert source.count(old) == 1
source = source.replace(old, new)
source = source.replace('console.log(JSON.stringify({sourceOwnerTrace,mode,', 'console.log(JSON.stringify({sourceOwnerTrace,churnInheritedSourceCache,mode,')
path.write_text(source)

path = Path('rust/tests/web/hive-work-item-consumer.test.mjs')
source = path.read_text().replace('function nativeFixtureProbe(language,args){', 'function nativeFixtureProbe(language,args,environment={}){')
old = "env:{...process.env,NODE_OPTIONS:'--max-old-space-size=256',FORMAL_AI_OFFLINE:'1',FORMAL_AI_LIVE_FETCH:'0'},"
assert source.count(old) == 1
source = source.replace(old, "env:{...process.env,...environment,NODE_OPTIONS:'--max-old-space-size=256',FORMAL_AI_OFFLINE:'1',FORMAL_AI_LIVE_FETCH:'0'},")
old = "test('the Codex fixture projects patch calls and observes real Git delivery with explicitly simulated CI',{timeout:65000},()=>{\n  const run=nativeFixtureProbe('Rust',[\n    '--steps=18','--physical-edits','--project-edits','--physical-delivery','--agent-cli-receipts','--trace-source-owners',\n  ]);"
new = """test('the Codex fixture projects patch calls and observes real Git delivery while inherited cache changes, with explicitly simulated CI',{timeout:65000},()=>{
  const inheritedCache=mkdtempSync(join(tmpdir(),'hive-inherited-source-cache-'));
  let run;
  try{
    run=nativeFixtureProbe('Rust',[
      '--steps=18','--physical-edits','--project-edits','--physical-delivery','--agent-cli-receipts',
      '--trace-source-owners','--churn-inherited-source-cache',
    ],{FORMAL_AI_SOURCE_CACHE_DIR:inheritedCache});
  }finally{rmSync(inheritedCache,{recursive:true,force:true});}"""
assert source.count(old) == 1
source = source.replace(old,new)
source = source.replace("import {spawnSync} from 'node:child_process';", "import {spawnSync} from 'node:child_process';\nimport {mkdtempSync,rmSync} from 'node:fs';\nimport {tmpdir} from 'node:os';\nimport {join} from 'node:path';")
path.write_text(source)
print('Added bounded cache-change reproducer to the existing Codex delivery case; production runtime remains unchanged.')
