from pathlib import Path

def replace(path, old, new):
    file = Path(path)
    source = file.read_text()
    assert source.count(old) == 1, (path, source.count(old))
    file.write_text(source.replace(old, new))

replace('scripts/release-changelog.rs',
        'pub fn first_heading_offset(content: &str) -> Option<usize> {',
        '#[allow(dead_code)] // Used by the collectors; the publishing CLI selects sections only.\npub fn first_heading_offset(content: &str) -> Option<usize> {')

old = Path('rust/src/solver_helpers/tests/javascript_program.rs')
new = Path('rust/tests/unit/solver/javascript_program.rs')
assert old.is_file() and not new.exists()
old.rename(new)
replace('rust/src/solver_helpers/code.rs',
        '#[path = "tests/javascript_program.rs"]',
        '#[path = "../../tests/unit/solver/javascript_program.rs"]')

replace('rust/tests/web/fast-pull-request-production-profile.test.mjs',
        '/docs/case-studies/issue-982/self-hosting/contract/*.gz\\n/docs/case-studies/issue-989/',
        '/docs/case-studies/issue-982/self-hosting/contract/*.gz\\n/docs/case-studies/issue-1613/evidence/formal-development/browser-cache-exclusion/generator-input.py.gz\\n/docs/case-studies/issue-1613/evidence/formal-development/promotion-oracle/coding-modification-suite.lino.gz\\n/docs/case-studies/issue-989/')

facts = Path('rust/tests/unit/specification/prompt_variations_facts.rs')
source = facts.read_text()
start = source.index('// Replay publisher entities')
end = source.index('#[test]', start)
helper = Path('rust/tests/fixtures/fact-claims/publisher_transport.rs')
assert not helper.exists()
helper.write_text('//! Physical publisher replay shared by full and isolated test targets.\n\n'
    'use formal_ai::event_log::EventLog;\n'
    'use formal_ai::source_fetch::{CachedSourceClient, FetchError, SourceTransport};\n'
    'use formal_ai::web_engine_core::normalize_prompt;\n'
    'use formal_ai::{SymbolicAnswer, live_fact_question, try_fact_lookup_with_client};\n\n'
    + source[start:end])
source = source[:start] + '#[path = "../../fixtures/fact-claims/publisher_transport.rs"]\nmod publisher_transport;\nuse publisher_transport::fact_answer;\n\n' + source[end:]
for old_import in [
    'use formal_ai::event_log::EventLog;\n',
    'use formal_ai::source_fetch::{CachedSourceClient, FetchError, SourceTransport};\n',
    'use formal_ai::web_engine_core::normalize_prompt;\n',
    'use formal_ai::{live_fact_question, try_fact_lookup_with_client};\n',
]:
    assert source.count(old_import) == 1
    source = source.replace(old_import, '')
facts.write_text(source)

replace('rust/tests/unit/specification/pronoun_topic_follow_up.rs',
        'use super::prompt_variations_facts::{FactTransport, fact_answer};',
        '#[path = "../../fixtures/fact-claims/publisher_transport.rs"]\nmod publisher_transport;\nuse publisher_transport::{FactTransport, fact_answer};')
replace('rust/tests/unit/specification/synthesis.rs',
        'const CROSS_RUNTIME_SYNTHESIS_FIXTURE:',
        '#[path = "../../fixtures/fact-claims/publisher_transport.rs"]\nmod publisher_transport;\n\nconst CROSS_RUNTIME_SYNTHESIS_FIXTURE:')
replace('rust/tests/unit/specification/synthesis.rs',
        'super::prompt_variations_facts::fact_answer(&case.prompt, "Q159")',
        'publisher_transport::fact_answer(&case.prompt, "Q159")')
replace('rust/tests/unit/reasoning_contracts.rs',
        'mod google_trends;\n',
        'mod google_trends;\nuse google_trends as issue_498_google_trends;\n')
replace('rust/tests/fixtures/practical-help-tests.rs',
        'MAX_CAPTURE_BYTES + 1', 'MAXIMUM_CAPTURE_BYTES + 1')
print('Repaired isolated native module ownership, existing size control and sparse-checkout twin; no Rust build executed.')
