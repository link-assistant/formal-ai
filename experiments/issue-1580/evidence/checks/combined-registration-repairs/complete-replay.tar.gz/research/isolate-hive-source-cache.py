from pathlib import Path

path = Path('experiments/issue-1580/native-hive-fixture-probe.mjs')
source = path.read_text()
old = "await installNodeHost(new WorkerHost());\nconst root=fs.mkdtempSync(path.join(os.tmpdir(),'hive-source-fixture-'));"
new = """const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'hive-source-fixture-'));
const root=path.join(temporary,'workspace');fs.mkdirSync(root);
// Offline still replays cached sources. Keep the fixture's source epoch private
// from sibling suites, outside Git's worktree, through delivery verification.
process.env.FORMAL_AI_SOURCE_CACHE_DIR=path.join(temporary,'source-captures');"""
assert source.count(old) == 1
source = source.replace(old, new)
source = source.replace('const steps=[];', 'const steps=[];\nconst churnedSourceUrls=[];')
source = source.replace('try {\n  if(physicalDelivery)', 'try {\n  await installNodeHost(new WorkerHost());\n  if(physicalDelivery)')
source = source.replace("for(const url of bodies.keys())if(fetch(url)===null)throw Error('cache churn control did not write capture');", "for(const url of bodies.keys()){\n        if(fetch(url)===null)throw Error('cache churn control did not write capture');\n        churnedSourceUrls.push(url);\n      }")
source = source.replace('JSON.stringify({sourceOwnerTrace,churnInheritedSourceCache,mode,', 'JSON.stringify({sourceOwnerTrace,churnInheritedSourceCache,churnedSourceUrls,mode,')
source = source.replace("}finally{fs.rmSync(root,{recursive:true,force:true});}", "}finally{fs.rmSync(temporary,{recursive:true,force:true});}")
path.write_text(source)
path = Path('rust/tests/web/hive-work-item-consumer.test.mjs')
source = path.read_text()
old = "  const patches=run.steps.filter(step=>step.call?.tool==='apply_patch');"
assert source.count(old) == 1
source = source.replace(old, """  assert.deepEqual(run.churnedSourceUrls,[
    'https://api.github.com/repos/actions/checkout/releases/latest',
    'https://api.github.com/repos/actions/checkout/commits/v99.0.0',
  ]);
""" + old)
path.write_text(source)
print('Isolated the fixture source cache outside the Git worktree; unchanged delivery and freshness checks remain active.')
