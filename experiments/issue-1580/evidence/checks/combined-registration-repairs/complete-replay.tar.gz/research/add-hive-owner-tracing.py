from pathlib import Path

path = Path('experiments/issue-1580/native-hive-fixture-probe.mjs')
source = path.read_text()
old = "import {canonicalCreation} from '../../js/agentic/qualified_tool_observation.mjs';"
assert source.count(old) == 1
source = source.replace(old, old + "\nimport {Progress,qualifiedToolAttempt} from '../../js/agentic/progress.mjs';\nimport {Capability} from '../../js/agentic/capability.mjs';")
source = source.replace("const agentCliReceipts=process.argv.includes('--agent-cli-receipts');", "const agentCliReceipts=process.argv.includes('--agent-cli-receipts');\nconst traceSourceOwners=process.argv.includes('--trace-source-owners');")
old = "  console.log(JSON.stringify({mode,agentTools,claudeTools,verifierResult,physicalEdits,projectEdits,physicalDelivery,agentCliReceipts,ceiling,"
assert source.count(old) == 1
new = """  // Opt-in diagnostics retain owner binding without changing planner evidence.
  const sourceOwnerTrace=traceSourceOwners?(()=>{
    const progress=Progress.scan(messages);
    return steps.flatMap(step=>{
      const owner=step.call?.tool==='apply_patch'?canonicalCreation(step.wireArguments):null;
      if(owner===null)return [];
      const index=progress.latestSourceMutationIndex(owner.path);
      const attempt=index===null?null:progress.attempts[index];
      const frame=attempt===null?null:qualifiedToolAttempt(progress,Capability.Edit,attempt.arguments);
      return [{path:owner.path,mutationIndex:index,capability:attempt?.capability,
        succeeded:attempt?.succeeded,binding:frame?.binding,receipt:frame?.detail,
        canonicalMatch:attempt?.arguments===step.wireArguments}];
    });
  })():undefined;
  console.log(JSON.stringify({sourceOwnerTrace,mode,agentTools,claudeTools,verifierResult,physicalEdits,projectEdits,physicalDelivery,agentCliReceipts,ceiling,"""
source = source.replace(old, new)
path.write_text(source)

path = Path('rust/tests/web/hive-work-item-consumer.test.mjs')
source = path.read_text()
source = source.replace("'--steps=18','--physical-edits','--project-edits','--physical-delivery','--agent-cli-receipts',", "'--steps=18','--physical-edits','--project-edits','--physical-delivery','--agent-cli-receipts','--trace-source-owners',")
source = source.replace('JSON.stringify({final,lastSteps:run.steps.slice(-4),outcome:run.outcome})', 'JSON.stringify({final,lastSteps:run.steps.slice(-4),sourceOwnerTrace:run.sourceOwnerTrace,outcome:run.outcome})')
path.write_text(source)
print('Added default-off fixture owner diagnostics; enabled only in the exact Codex delivery regression.')
