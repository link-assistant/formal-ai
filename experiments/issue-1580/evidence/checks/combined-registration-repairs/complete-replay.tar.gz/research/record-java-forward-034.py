from pathlib import Path
import gzip, hashlib, json

root = Path.cwd()
pages_root = Path('/tmp/issue-1580-research/java-history-pages')
page_manifest = json.loads((pages_root / 'manifest.json').read_text())
evidence = root / 'experiments/issue-1580/evidence/checks/java-historical-forward-034'
evidence.mkdir(exist_ok=False)
rows = []
for page in range(228, 238):
    name = f'page-{page:03}.log.gz'
    packed = (pages_root / name).read_bytes()
    raw = gzip.decompress(packed)
    assert f'page {page}/254'.encode() in raw
    (evidence / name).write_bytes(packed)
    rows.append({**page_manifest[page - 1], 'file': name, 'archiveSha256': hashlib.sha256(packed).hexdigest(), 'rawSha256': hashlib.sha256(raw).hexdigest(), 'completeLiteralOutputRead': True})
metadata2 = 'dev/log/issues/24/pulls/25/sources/transitive-registry-metadata-2.json'
metadata3 = 'dev/log/issues/24/pulls/25/sources/transitive-registry-metadata-3.json'
assert rows[0]['first'] == [metadata2, '232']
assert rows[-1]['last'] == [metadata3, '96.4/9']
(evidence / 'manifest.json').write_text(json.dumps({'pinnedHead': 'dd803a2d9fa5b3a992b435acce73162274fb9e8b', 'pages': rows, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
docs = root / 'docs/case-studies/issue-1580/templates'
index_path = docs / 'java-historical-review-index.json'
index = json.loads(index_path.read_text())
old = index['cumulativeSummary']
assert old['literalPages'] == 227 and old['literalLines'] == 13859
updated = {**old, 'literalPages': 237, 'literalLines': 14005, 'completeFiles': 138, 'partialFiles': 1, 'nextForwardPage': 238, 'remainingPages': 17}
# Keep the authoritative summary key names while advancing the same counters.
for key in ['completeFiles', 'partialFiles']:
    if key not in old:
        updated.pop(key)
for key in old:
    if key in ('fullyReadFiles', 'completeLiteralFiles'):
        updated[key] = 138
part = {'previousIndexSummary': old, 'pagesFullyRead': list(range(228, 238)), 'filesChangedSincePrevious': [
    {'path': metadata2, 'newReadLines': [232, 282], 'cumulativeReadLines': [1, 282], 'completeSourceRead': True},
    {'path': metadata3, 'newReadLines': [1, 95], 'cumulativeReadLines': [1, 95], 'partialNextLine': '96, parts 1–4 of 9', 'completeSourceRead': False},
], 'cumulativeSummary': updated, 'observations': ['All ten pages were literally read without truncation. They finish the second captured Maven registry inventory and continue the third through Plexus, Woodstox, CommonMark, dom4j and Jetty histories. Complete split lines are counted only after every part is read. Jetty server line 96 is partial and earns no complete-line credit yet. Historical publication lists do not establish current safety, compatibility or semantic application. Seventeen literal pages and semantic comparison remain unfinished. Supplied work earns zero independent authorship credit.']}
part_name = 'java-historical-forward-review-034.json'
raw = (json.dumps(part, indent=2) + '\n').encode()
(docs / part_name).write_bytes(raw)
index['forwardParts'].append({'file': part_name, 'sha256': hashlib.sha256(raw).hexdigest(), 'pages': list(range(228, 238))})
index['cumulativeSummary'] = updated
index_path.write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({'previous': old, 'current': updated}), flush=True)
