from pathlib import Path
import datetime, gzip, hashlib, json, subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
base=Path('/tmp/issue-1580-research/buildkit-batch-feedback');base.mkdir(exist_ok=False)
receipts=[]
def run(label,argv):
 result=subprocess.run(argv,cwd=root,capture_output=True)
 (base/(label+'.stdout')).write_bytes(result.stdout);(base/(label+'.stderr')).write_bytes(result.stderr)
 receipts.append({'label':label,'argv':argv,'exitCode':result.returncode,
  'sha256':hashlib.sha256(result.stdout).hexdigest()})
 assert result.returncode==0,result.stderr.decode()
 return result.stdout
branch=run('branch',['git','branch','--show-current']).decode().strip()
assert branch=='issue-1580-8d61a32a61e1'
run('fetch-main',['git','fetch','origin','main'])
run('main-ancestor',['git','merge-base','--is-ancestor','origin/main','HEAD'])
for state in ['in_progress','queued']:
 data=json.loads(run(state,['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,
  '--status',state,'--limit','100','--json','databaseId,workflowName,headSha,status']))
 print(state,data)
for label,endpoint in [('issue-comments','issues/1580/comments'),('conversation-comments','issues/1581/comments'),
 ('inline-comments','pulls/1581/comments'),('reviews','pulls/1581/reviews')]:
 values=json.loads(run(label,['gh','api','repos/link-assistant/formal-ai/'+endpoint,'--paginate']))
 print(label,len(values))
 for row in values:
  print(json.dumps({'id':row.get('id'),'created':row.get('created_at'),'updated':row.get('updated_at'),
   'body':row.get('body'),'url':row.get('html_url')},ensure_ascii=False))
run('pull-request',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json',
 'title,body,isDraft,url,headRefOid,mergeStateStatus'])
run('recent-runs',['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--limit','5',
 '--json','databaseId,workflowName,conclusion,createdAt,headSha'])
(base/'receipts.json').write_text(json.dumps({'observed':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'receipts':receipts},indent=2)+'\n')
