from pathlib import Path
import gzip,hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
base=root/'experiments/issue-1580/evidence/checks/next-repair-batch-seal';base.mkdir(exist_ok=False)
outcome=json.loads((scratch/'sealed-next-repair-batch-corrected/outcome.json').read_text());assert outcome['passed']
records=[]
def capture(name,path):
 raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);target=base/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(packed)
 assert gzip.decompress(packed)==raw
 records.append({'file':name+'.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
for folder in ['sealed-next-repair-batch','sealed-next-repair-batch-corrected','buildkit-batch-feedback']:
 for path in sorted((scratch/folder).rglob('*')):
  if path.is_file():capture(folder+'/'+str(path.relative_to(scratch/folder)),path)
for stem in ['seal-next-repair-batch','seal-next-repair-batch-corrected','correct-buildkit-archive-paths','refresh-buildkit-batch-feedback','next-repair-abbreviation-list']:
 for suffix in ['.py','.log']:
  path=scratch/(stem+suffix)
  if path.is_file():capture('helpers/'+path.name,path)
capture('helpers/'+Path(__file__).name,Path(__file__))
(base/'records.json').write_text(json.dumps(records,indent=2)+'\n')
with (root/'experiments/issue-1580/work-plan.md').open('a') as stream:
 stream.write('\n- Sealed next repair batch: four final archive/naming/size gates pass after four path-only archive filename corrections; all 578 exact staged inputs pass the real compressed-content secret engine with a 256 MiB heap. Captured original/compressed hashes and all failed naming-gate output remain retained. Fresh complete issue/PR conversation/inline/review feedback is unchanged, both queued/running lists are empty, and freshly fetched main is an ancestor. Subsequent sealing evidence is scanned separately before commits. Hosted script-module and real BuildKit execution remain pending; broad acceptance remains unfinished.\n')
print('Archived verified sealing records:',len(records),'peak child KiB:',outcome['peakChildRssKiB'])
