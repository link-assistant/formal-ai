from pathlib import Path
import gzip,hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/checks/buildkit-bootstrap-identity'
path=base/'records.json'; records=json.loads(path.read_text()); renames=[]
for row in records:
 old=row['file'];new=old.replace('docker-buildx-src_main.ts','docker-buildx-source-main.ts')
 if new==old:continue
 source=base/old;target=base/new
 assert hashlib.sha256(source.read_bytes()).hexdigest()==row['archiveSha256']
 source.rename(target);row['file']=new
 assert hashlib.sha256(target.read_bytes()).hexdigest()==row['archiveSha256']
 assert hashlib.sha256(gzip.decompress(target.read_bytes())).hexdigest()==row['rawSha256']
 renames.append({'before':old,'after':new,'originalBytesUnchanged':True})
assert len(renames)==4
path.write_text(json.dumps(records,indent=2)+'\n')
(base/'path-only-correction.json').write_text(json.dumps({'reason':'spell source filename in full; original capture bytes preserved','renames':renames},indent=2)+'\n')
print(json.dumps(renames,indent=2))
