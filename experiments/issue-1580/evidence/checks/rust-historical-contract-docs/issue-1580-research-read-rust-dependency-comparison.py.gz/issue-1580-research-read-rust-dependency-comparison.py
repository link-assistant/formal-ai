from pathlib import Path
import hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048')
src=Path('/tmp/issue-1580-research/templates/rust-complete')
dst=Path('/tmp/issue-1580-research/rust-dependency-comparison');dst.mkdir(exist_ok=False)
name='dev/log/issues/247/pulls/248/dependency-versions.md'
inventory={r['path']:r for r in json.loads((root/'experiments/issue-1580/evidence/checks/rust-template-first-gate/pinned-file-identities.json').read_text())}
raw=(src/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==inventory[name]['sha256']
lines=raw.decode().splitlines();(dst/'source.md').write_bytes(raw)
chunks=[]
for start in range(0,len(lines),75):
 chunk=f'lines-{start+1:04d}.txt';chunks.append(chunk)
 (dst/chunk).write_text(f'PINNED {name} lines {start+1}-{min(start+75,len(lines))}\n'+'\n'.join(f'{i+1}: {s}' for i,s in enumerate(lines[start:start+75],start))+'\n')
(dst/'identity.json').write_text(json.dumps({'path':name,'sha256':hashlib.sha256(raw).hexdigest(),'lines':len(lines),'bytes':len(raw),'chunks':chunks},indent=2)+'\n')
print((dst/'identity.json').read_text())
