from pathlib import Path
import datetime,gzip,hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048')
src=Path('/tmp/issue-1580-research/templates/rust-complete')
scratch=Path('/tmp/issue-1580-research')
ledger=root/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data=json.loads(ledger.read_text());assert data['fullyReadFiles']==343
manifest=root/data['readLogManifest'];records=json.loads(manifest.read_text());rows=[]
for directory,label in [('rust-dependency-comparison','dependency-comparison'),('rust-historical-pr-patch','historical-pr-patch')]:
 reads=scratch/directory;row=json.loads((reads/'identity.json').read_text());raw=(src/row['path']).read_bytes()
 assert row['path'] not in {r['path'] for r in data['files']}
 assert hashlib.sha256(raw).hexdigest()==row['sha256']
 lines=raw.decode().splitlines();assert len(lines)==row['lines']
 observed=[]
 for name in row['chunks']:
  for line in (reads/name).read_text().splitlines()[1:]:
   number,value=line.split(': ',1);observed.append((int(number),value))
 assert observed==list(enumerate(lines,1))
 name=label+'.txt.gz';packed=gzip.compress(raw,mtime=0);(manifest.parent/name).write_bytes(packed)
 records.append({'file':name,'rawSha256':row['sha256'],'archiveSha256':hashlib.sha256(packed).hexdigest()})
 data['files'].append({'path':row['path'],'lines':len(lines),'sha256':row['sha256'],'readLogs':[name],
  'literalReadRanges':[[1,len(lines)]],'literalReadLines':len(lines),'literalSourceFullyRead':True,
  'formalAiPracticeImplementationVerified':False});rows.append(row)
data['files'].sort(key=lambda r:r['path']);data['fullyReadFiles']=len(data['files'])
data['fullyReadSourceLines']=sum(r['literalReadLines'] for r in data['files'])
assert (data['fullyReadFiles'],data['fullyReadSourceLines'])==(345,42721)
data['observedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
data['practiceDecisions'].append({'practice':'Preserve dependency parent constraints and working-directory ownership without treating historical drafts as live execution',
 'templateEvidence':[r['path'] for r in rows],
 'assessment':'All 300 dependency-comparison lines and all 879 historical pull-request patch lines were literally read. The dependency table pins its 2026-11-14 observation and distinguishes registry latest from parent-compatible resolutions, including retained Chrono, platform and npm majors; its statements are historical claims, not a fresh registry/audit observation or accepted mandatory-Chrono removal. The patch documents command-stream virtual cd mutating the parent process, explicit root configuration and cwd restoration before retries; its Rust changelog still uses an unscoped version regex. This PR already separately repairs Cargo package/workspace identity with focused actual native CLI controls. The historical patch is not current runtime or publication evidence. Compare process-owned cwd and failure restoration against actual maintained consumers, preserving exact source identity and tests before adopting any helper. All-template practice acceptance and remaining dependency/runtime criteria remain open.',
 'status':'complete-literal-historical-contract-document-review-current-practice-runtime-open'})
manifest.write_text(json.dumps(records,indent=2)+'\n');ledger.write_text(json.dumps(data,indent=2)+'\n')
dst=root/'experiments/issue-1580/evidence/checks/rust-historical-contract-docs';dst.mkdir(exist_ok=False)
captured=[]
for p in [Path(__file__),scratch/'read-rust-dependency-comparison.py',scratch/'read-rust-historical-pr-patch.py',
 scratch/'rust-dependency-comparison/identity.json',scratch/'rust-historical-pr-patch/identity.json']:
 raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);name=p.parent.name+'-'+p.name+'.gz';(dst/name).write_bytes(packed)
 captured.append({'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
(dst/'records.json').write_text(json.dumps(captured,indent=2)+'\n')
(dst/'assessment.json').write_text(json.dumps({'literalPinnedFilesRead':345,'literalTextLinesRead':42721,
 'newSourceRecords':rows,'historicalDraftEstablishesCurrentRuntime':False,'allTemplatePracticesAdopted':False,
 'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
with (root/'experiments/issue-1580/work-plan.md').open('a') as f:f.write('\n- Fully read the pinned 300-line dependency comparison and 879-line historical release patch: Rust literal review is 345/373 files and 42,721 lines. Retain compatible parent constraints and process-working-directory ownership as scoped findings; historical registry claims and a draft patch prove no present publication or dependency removal. Twenty-eight Rust identities and all incomplete practice/runtime acceptance remain open.\n')
print(json.dumps({'literalFilesRead':345,'literalTextLinesRead':42721,'remainingIdentities':28,'fullIssueComplete':False,'independentAuthorshipCredit':0}))
