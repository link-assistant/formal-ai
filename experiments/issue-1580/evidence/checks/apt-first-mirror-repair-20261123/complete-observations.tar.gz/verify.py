from pathlib import Path
import subprocess,json,datetime
root=Path('/tmp/issue-1580-research/apt-first-mirror-repair');records=[]
def check(label,args):
 with (root/(label+'.log')).open('wb') as output:
  result=subprocess.run(args,stdout=output,stderr=subprocess.STDOUT)
 records.append({'label':label,'command':args,'exitCode':result.returncode})
 (root/'progress.json').write_text(json.dumps(records,indent=2)+'\n')
 print(label,result.returncode,flush=True)
for name in ['agentic-search-installer','official-ubuntu-mirror-fallback','container-apt-retry','browser-ubuntu-apt-isolation','browser-engine-release-integration']:
 check(name,['node','--test','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs'])
for name in ['apt-install-with-retry','install-agentic-search-tools']:
 check(name+'-syntax',['bash','-n','scripts/'+name+'.sh'])
check('whitespace',['git','diff','--check'])
for gate in ['check-file-size','check-file-size-js-twin','check-readable-code','check-required-documentation','check-tests-as-docs','check-tests-as-documentation-javascript-twin','check-changelog-fragment-js-twin','release#1','check-closure-audit','check-generated-files','layered-ci#1']:
 check('gate-'+gate,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate])
(root/'outcome.json').write_text(json.dumps({'complete':True,'records':records,'allPassed':all(row['exitCode']==0 for row in records),'independentAuthorshipCredit':0,'nativeExecutionVerified':False,'fullIssueComplete':False,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print('COMPLETE',flush=True)
