from pathlib import Path
import subprocess,json,datetime
r=Path('/tmp/issue-1580-research/apt-first-mirror-repair');records=[]
for label,cmd in [('container-startup-control',['node','experiments/issue-1580/container-apt-startup-control.mjs']),('container-apt-retry-isolated',['node','--test','--test-concurrency=1','rust/tests/web/container-apt-retry.test.mjs'])]:
 with (r/(label+'.log')).open('w') as out: result=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 records.append({'label':label,'command':cmd,'exitCode':result.returncode});print(json.dumps(records[-1]),flush=True)
(r/'container-isolation-results.json').write_text(json.dumps({'records':records,'complete':True,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
