from pathlib import Path
import json,os,re,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/procedure-extraction-parity')
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=256'
test=root/'experiments/issue-1580/procedure-extraction-parity.test.mjs'
test.write_text('''// Procedure refactors must retain the cases actually carried by JavaScript.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import test from 'node:test';
import {specificationCases, testFunctions, tokenize} from '../../scripts/lib/rust-specification-cases.mjs';

const root = fileURLToPath(new URL('../../', import.meta.url));
const owner = 'rust/tests/unit/specification/reasoning_paths_procedures.rs';
test('procedure coverage keeps the original JavaScript case and native test identities', () => {
  const inventory = specificationCases(root);
  const expected = [
    'telegraphic_how_requires_a_known_procedural_action',
    'greeting_prefixed_russian_connect_how_to_composes_procedure',
    'procedural_elaboration_followup_rebinds_to_prior_how_to',
    'procedural_elaboration_followup_covers_supported_languages',
    'procedural_elaboration_followup_covers_many_topics',
  ];
  assert.deepEqual(inventory.cases.filter(entry => entry.id.startsWith(owner + '::'))
    .map(entry => entry.id.slice(owner.length + 2)), expected);
  const source = readFileSync(root + owner, 'utf8');
  const names = testFunctions(tokenize(source)).map(entry => entry.name);
  assert.equal(names.length, 16);
  assert.equal(new Set(names).size, names.length);
  for (const name of expected) assert(names.includes(name), 'native test identity disappeared: ' + name);
});
''')
def run(name,args):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:p=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
    print(json.dumps({'name':name,'exitCode':p.returncode}),flush=True)
    return p.returncode
assert run('before',['node','--test','--test-concurrency=1',str(test)])!=0
source=(out/'original.rs').read_text()
start=source.index('fn documented_english_procedure(')
end=source.index('// ---------------------------------------------------------------------------',start)
helpers=source[start:end].rstrip()
helpers=re.sub(r'^fn (documented_[a-z_]+)\(',r'pub(super) fn \1(',helpers,flags=re.M)
source=source[:start]+source[end:]
parts=['//! Source-backed procedure fixtures; assertion bodies stay in their original tests.', '', helpers]
for name,label in [('telegraphic_install_prompts_use_official_docs_procedure_plan','InstallCase'),('procedural_request_surfaces_stay_multilingual_after_elided_gate','SurfaceCase'),('spec_driven_typo_how_to_prompts_cover_supported_languages','TypoCase')]:
    fn_start=source.index('fn '+name+'() {')
    struct_start=source.index('    struct Case {',fn_start)
    struct_end=source.index('\n    }',struct_start)+6
    struct=source[struct_start:struct_end]
    loop_start=source.index('    for case in [',struct_end)
    loop_end=source.index('    ] {',loop_start)
    assert source[struct_end:loop_start].strip()==''
    array=source[loop_start+len('    for case in '):loop_end]+']'
    assert array.count('Case {')==4
    struct='\n'.join(line[4:] for line in struct.splitlines()).replace('struct Case {','pub(super) struct '+label+' {',1)
    struct=re.sub(r'^(    )([a-z_]+):',r'\1pub(super) \2:',struct,flags=re.M)
    array=array.replace('Case {',label+' {')
    array='\n'.join(line[4:] if line.startswith('    ') else line for line in array.splitlines())
    const=re.sub(r'Case$','',label).upper()+'_CASES'
    parts.extend(['',struct,'','pub(super) const '+const+': ['+label+'; 4] = '+array+';'])
    source=source[:struct_start]+'    for case in fixtures::'+const+' {'+source[loop_end+len('    ] {'):]
source=source.replace('use formal_ai::','mod fixtures;\n\nuse fixtures::{documented_connect_procedure, documented_english_procedure};\n\nuse formal_ai::',1)
owner=root/'rust/tests/unit/specification/reasoning_paths_procedures.rs';owner.write_text(source)
child=owner.with_suffix('')/'fixtures.rs';child.write_text('\n'.join(parts)+'\n')
(owner.with_suffix('')/'elaboration.rs').unlink()
headroom=root/'experiments/issue-1580/native-test-headroom.test.mjs';s=headroom.read_text()
start=s.index("  ['rust/tests/unit/specification/reasoning_paths_procedures', 'elaboration', [")
end=s.index('  ]],\n',start)+len('  ]],\n');s=s[:start]+s[end:]
s+='''\n\ntest('procedure fixtures retain headroom while assertion bodies remain extractable', () => {
  const owner = 'rust/tests/unit/specification/reasoning_paths_procedures';
  assert.deepEqual(checkListedFiles(root, new Set([owner + '.rs', owner + '/fixtures.rs'])),
    {warnings: [], violations: [], embeddedDataViolations: []});
  const source = readFileSync(root + '/' + owner + '.rs', 'utf8');
  assert.match(source, /^mod fixtures;$/mu);
  for (const name of ['INSTALL_CASES', 'SURFACE_CASES', 'TYPO_CASES']) assert(source.includes('fixtures::' + name));
});
''';headroom.write_text(s)
maintained=root/'rust/tests/web/issue-1580-template-observations.test.mjs';s=maintained.read_text();s+="\nimport '../../../experiments/issue-1580/procedure-extraction-parity.test.mjs';\n";maintained.write_text(s)
assert run('format',['rustfmt','--edition','2024',str(owner),str(child)])==0
assert run('after',['node','--test','--test-concurrency=1',str(test)])==0
assert run('headroom',['node','--test','--test-concurrency=1','experiments/issue-1580/native-test-headroom.test.mjs'])==0
print(json.dumps({'ownerLines':len(owner.read_text().splitlines()),'fixtureLines':len(child.read_text().splitlines()),'nativeBuildRun':False,'independentAuthorshipCredit':0}),flush=True)
