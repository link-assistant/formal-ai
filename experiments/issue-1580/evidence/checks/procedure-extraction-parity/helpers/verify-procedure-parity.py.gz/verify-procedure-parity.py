from pathlib import Path
import subprocess,json,os,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');out=Path('/tmp/issue-1580-research/procedure-extraction-parity-validation')
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'pid.json').write_text(json.dumps({'pid':worker.pid})+'\n');print(json.dumps({'pid':worker.pid,'finite':True}));sys.exit(0)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=512';records=[]
try:
    test=root/'experiments/issue-1580/procedure-extraction-parity.test.mjs';s=test.read_text();s=s.replace("    'procedural_elaboration_followup_covers_supported_languages',\n    'procedural_elaboration_followup_covers_many_topics',","    'procedural_elaboration_requires_a_prior_how_to',\n    'procedural_elaboration_followup_covers_supported_languages',")
    s=s.replace('assert.equal(names.length, 16);','assert.equal(names.length, 16);')
    test.write_text(s)
    commands=[('parity',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(test)]),('headroom',['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/native-test-headroom.test.mjs']),('default-branch-policy',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/default-branch-build-policy.test.mjs']),('repaired-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-specification-in-javascript,check-tests-as-docs,check-tests-as-documentation-javascript-twin,check-file-size,check-file-size-js-twin']),('maintained',['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'])]
    for name,args in commands:
        with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:run=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr)
        row={'name':name,'arguments':args,'exitCode':run.returncode,'summary':(out/(name+'.stdout')).read_text().splitlines()[-10:]};records.append(row);(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
    import shutil
    details=out/'gate-details';details.mkdir()
    for name in ['check-specification-in-javascript','check-tests-as-docs','check-tests-as-documentation-javascript-twin','check-file-size','check-file-size-js-twin']:
        file=root/'experiments/formal_ai_subagent/sandboxes/gates'/ (name+'.log');shutil.copyfile(file,details/file.name)
    result={'complete':all(row['exitCode']==0 for row in records),'nativeBuildRun':False,'independentAuthorshipCredit':0,'fullIssueComplete':False};(out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
except BaseException:
    (out/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');raise
