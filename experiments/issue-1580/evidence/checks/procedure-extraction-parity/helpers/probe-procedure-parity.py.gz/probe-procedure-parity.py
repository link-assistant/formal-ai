from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/procedure-extraction-parity');out.mkdir(exist_ok=True)
owner='rust/tests/unit/specification/reasoning_paths_procedures.rs'
original=subprocess.run(['git','show','5d83bf4^:'+owner],cwd=root,capture_output=True,check=True).stdout
(out/'original.rs').write_bytes(original)
program="""import {specificationCases} from './scripts/lib/rust-specification-cases.mjs';const all=specificationCases();console.log(JSON.stringify({total:all.total,carried:all.cases.length,cases:all.cases.filter(x=>x.id.includes('reasoning_paths_procedures.rs')),unsupported:all.unsupported.filter(x=>x.id.includes('reasoning_paths_procedures.rs'))},null,2));"""
run=subprocess.run(['node','--max-old-space-size=256','--input-type=module','-e',program],cwd=root,capture_output=True,check=True)
(out/'before-inventory.json').write_bytes(run.stdout)
print(run.stdout.decode())
