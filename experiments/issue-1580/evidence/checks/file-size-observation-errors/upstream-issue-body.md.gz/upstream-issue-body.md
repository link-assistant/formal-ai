The file-size gate can report success even though it could not inspect maintained source files. This is distinct from the path-exclusion repair in #217, which is present in the current source.

Observed source revision: `260ae6f826d6bff0cbfe2280098c287a4c09b3f4`, blob `6e94c9e507a70a7f87e79e71375b1277b69bc7e6`, at 2026-11-22T04:24:39.659628+00:00.

The complete source is [scripts/check-file-size.rs](https://github.com/link-foundation/rust-ai-driven-development-pipeline-template/blob/260ae6f826d6bff0cbfe2280098c287a4c09b3f4/scripts/check-file-size.rs):

- `check_directory` discards all traversal errors through `filter_map(Result::ok)` (line 123).
- A failed `count_lines` only prints a warning and adds no failed observation (lines 147–149).
- `main` returns success whenever the violations vector is empty (line 271), including these incomplete scans.

A minimal physical input is `src/broken.rs` containing the single byte `ff`, which is invalid UTF-8. Run the ordinary `rust-script scripts/check-file-size.rs` from that fixture directory. The current source reaches the read-error warning, then the empty-violations success branch. An unreadable scanned directory is likewise dropped during traversal.

Expected behavior: preserve the failed path and reason, complete collection of other findings, and exit nonzero when any required read or traversal fails. Keep genuine excluded directories and non-source formats outside the scan. Evaluate exclusions relative to the scanned root, as in the existing #217 repair.

Suggested regressions use actual invalid UTF-8 bytes and an unavailable scan root, plus a control with an excluded `target/` file, an unlisted file where applicable, and a binary file. Also retain the existing line-threshold, warning and path-exclusion cases.

This report establishes the defect from the complete upstream source; no native upstream executable was run. A matching JavaScript production twin in https://github.com/link-assistant/formal-ai/pull/1581 was executed against an actual invalid-UTF-8 file: before its fix it printed “All checked files are within their line limits” and exited 0; afterward the regression passes with exit 1. Matching downstream Rust regressions are prepared, with hosted native execution still pending.
