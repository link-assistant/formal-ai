from pathlib import Path
import subprocess,json,os,datetime
r=Path('/tmp/issue-1580-research/file-size-literal-final-checks')
command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only','release#2']
with (r/'secret-gate.log').open('w') as stream:
 result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,env={**os.environ,'BASE_REF':'bc08222b5a5195dc9992c0459bde2b6369377b9f'})
(r/'outcome.json').write_text(json.dumps({'complete':True,'command':command,'exitCode':result.returncode,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'base':'bc08222b5a5195dc9992c0459bde2b6369377b9f','finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fullIssueComplete':False},indent=2)+'\n')
