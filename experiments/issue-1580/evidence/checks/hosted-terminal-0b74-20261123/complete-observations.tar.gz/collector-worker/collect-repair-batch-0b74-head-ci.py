import datetime,gzip,hashlib,json,subprocess,time,zipfile
from pathlib import Path
root=Path('/tmp/issue-1580-research/repair-batch-0b74-head-ci');root.mkdir(exist_ok=True)
head='0b74d3b102290b98d8ad3632e8b00e944b742d03';repository='link-assistant/formal-ai';records=[]
assert not (root/'outcome.json').exists()
def capture(label,command,required=True):
 result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 for stream,value in [('stdout',result.stdout),('stderr',result.stderr)]: (root/(label+'.'+stream+'.gz')).write_bytes(gzip.compress(value,mtime=0))
 records.append({'label':label,'command':command,'exitCode':result.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 (root/'records.json').write_text(json.dumps(records,indent=2)+'\n')
 if required and result.returncode:raise RuntimeError(label+': '+result.stderr.decode(errors='replace')[:500])
 return result
def collect(run):
 identity=run['databaseId']
 capture('jobs-'+str(identity),['gh','api','repos/'+repository+'/actions/runs/'+str(identity)+'/jobs','--paginate','--slurp'])
 result=capture('cli-log-'+str(identity),['gh','run','view',str(identity),'--repo',repository,'--log'],False)
 fallback=False
 if result.returncode:
  archive=root/('available-logs-'+str(identity)+'.zip')
  with archive.open('wb') as stream:download=subprocess.run(['gh','api','repos/'+repository+'/actions/runs/'+str(identity)+'/logs'],stdout=stream,stderr=subprocess.PIPE)
  (root/('archive-'+str(identity)+'.stderr.gz')).write_bytes(gzip.compress(download.stderr,mtime=0))
  assert download.returncode==0 and zipfile.is_zipfile(archive)
  with zipfile.ZipFile(archive) as z:
   assert z.testzip() is None
   members=[{'name':x.filename,'bytes':x.file_size,'crc32':x.CRC} for x in z.infolist()]
  (root/('archive-'+str(identity)+'.json')).write_text(json.dumps({'members':members,'verified':True,'missingLogsAreNotExecutionEvidence':True},indent=2)+'\n');fallback=True
 return {'run':identity,'wholeCliLogAvailable':result.returncode==0,'fallbackArchiveVerified':fallback,'semanticReviewComplete':False}
try:
 saved={};previous=None;stable=0;consecutive_errors=0
 for observation in range(720):
  try:
   result=capture('observation-'+str(observation).zfill(3),['gh','run','list','--repo',repository,'--branch','issue-1580-8d61a32a61e1','--commit',head,'--limit','100','--json','databaseId,workflowName,status,conclusion,createdAt,updatedAt,headSha,url,event'])
   runs=json.loads(result.stdout);assert all(row['headSha']==head for row in runs)
   (root/'latest.json').write_text(json.dumps(runs,indent=2)+'\n')
   for run in runs:
    if run['status']=='completed' and run['conclusion'] in ['failure','cancelled','timed_out','action_required'] and run['databaseId'] not in saved:saved[run['databaseId']]=collect(run)
   signature=sorted((row['databaseId'],row['status'],row['conclusion']) for row in runs)
   terminal=len(runs)>=33 and all(row['status']=='completed' for row in runs)
   stable=stable+1 if terminal and signature==previous else 0;previous=signature
   print(json.dumps({'observation':observation,'runs':len(runs),'pending':sum(row['status']!='completed' for row in runs),'nonpassingCollected':len(saved),'terminalStable':stable}),flush=True)
   consecutive_errors=0
   if stable>=2:
    for run in runs:
     if run['databaseId'] not in saved:saved[run['databaseId']]=collect(run)
    capture('pr-checks',['gh','pr','view','1581','--repo',repository,'--json','headRefOid,isDraft,mergeStateStatus,statusCheckRollup'])
    (root/'outcome.json').write_text(json.dumps({'head':head,'complete':True,'runs':runs,'collected':saved,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n');break
  except Exception as error:
   consecutive_errors+=1;print(json.dumps({'observation':observation,'collectorObservationError':str(error),'consecutiveErrors':consecutive_errors}),flush=True)
   if consecutive_errors>=10:raise
  time.sleep(30)
 else:(root/'outcome.json').write_text(json.dumps({'head':head,'complete':False,'reason':'Finite observation window exhausted; remaining checks unfinished','runs':runs,'collected':saved},indent=2)+'\n')
except Exception as error:
 (root/'collector-error.json').write_text(json.dumps({'head':head,'error':str(error)},indent=2)+'\n');raise
