from pathlib import Path
p=Path('rust/tests/web/issue-1580-template-observations.test.mjs')
s=p.read_text()
line="import '../../../experiments/issue-1580/formal-command.test.mjs';\n"
assert line not in s
p.write_text(s+'\n'+line)
p=Path('changelog.d/20261123_115000_formal_command_process_receipts.md')
assert not p.exists()
p.write_text("""### Fixed
- Preserve complete Formal AI command output when source bytes contain the driver's answer marker, and qualify the exact command's terminal process receipt instead of printed exit-code claims.
""")
r=Path('/tmp/issue-1580-research')
d=r/'aggregate-experiment-tools-review-bc08'
import hashlib,json,subprocess
i=json.loads((d/'inventory.json').read_text())
raw=subprocess.check_output(['git','diff','--no-ext-diff',i['base'],i['source'],'--',*i['paths']])
assert raw==(d/'complete.diff').read_bytes()
assert hashlib.sha256(raw).hexdigest()==i['sha256']
chunks=[]
for c in i['chunks']:
 b=(d/c['path']).read_bytes()
 assert hashlib.sha256(b).hexdigest()==c['sha256']
 assert len(b.splitlines())==c['lines']
 chunks.append(b)
 c['readComplete']=True
assert b''.join(chunks)==raw
i.update({'completeReview':True,'reviewedScope':'Complete source diff for eighty non-test experiment tools at the pinned source. New wrapper repair is a separately reviewed delta.','sourceBehaviorExecutedByReview':False,'completeAggregateReview':False,'fullIssueComplete':False,'independentAuthorshipCredit':0,'findings':[{'path':'experiments/issue-1580/formal-command.mjs','defect':'Substring answer boundary truncation and unqualified exit-code parsing','repairWorkingTree':True,'regression':'experiments/issue-1580/formal-command.test.mjs','beforeFailed':11,'afterPassed':16}]})
(d/'completed-review.json').write_text(json.dumps(i,indent=2)+'\n')
print('Registered the regression in the maintained CI suite; verified all thirty-three review chunks.')
