from pathlib import Path
import json
r=Path('/tmp/issue-1580-research')
f=Path('experiments/issue-1580/formal-command.mjs')
old=f.read_text()
(r/'formal-command-before-output-fix.mjs').write_text(old)
assert old.count("process.stdout.write((result.stdout??'').split('== answer ==')[0]);")==1
head=old[:old.index('const command=')]
head=head.replace("import {resolve} from 'node:path';", "import {resolve} from 'node:path';\nimport {pathToFileURL} from 'node:url';")
review="""// Interpret the captured driver result separately from command execution.
export function reviewCommandResult(result, shellCommand) {
  const stdout = result.stdout ?? '';
  const trace = stdout.split('== answer ==')[0];
  const calls = [...stdout.matchAll(/^>> bash (\\{.*\\})$/gmu)].map(match => JSON.parse(match[1]));
  const exact = calls.some(call => call.command === shellCommand);
  const codes = [...stdout.matchAll(/Exit Code: (\\d+)/gu)].map(match => Number(match[1]));
  return {trace, exact, exitCode: result.status || (!exact || !codes.length ? 1 : codes.find(code => code !== 0) ?? 0)};
}

"""
main=old[old.index('const command='):old.index('// The full response')]
main+="""// The full response is retained above; show the tool trace once.
const reviewed = reviewCommandResult(result, shellCommand);
process.stdout.write(reviewed.trace);
process.stderr.write(result.stderr ?? '');
if (!reviewed.exact) process.stderr.write('Requested command was not executed verbatim; no verification credit.\\n');
process.exit(reviewed.exitCode);
"""
f.write_text(head+review+"if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {\n"+main+"}\n")
test=r"""// Regression fixtures use the real driver's indented tool-result wire format.
import assert from 'node:assert/strict';
import test from 'node:test';
import {reviewCommandResult} from './formal-command.mjs';

const command = "env sh -c 'fixture'";
const receipt = (output = '', status = 0, error = '') =>
  'Output: ' + output + (error ? '\nError: ' + error : '') + '\nExit Code: ' + status;
const entry = (result, args = {command}) =>
  '>> bash ' + JSON.stringify(args) + '\n' + result.split('\n').map(line => '   ' + line).join('\n') + '\n';
const observe = (body, metadata = {}, answer = 'finished') =>
  reviewCommandResult({stdout: body + '== answer ==\n' + answer + '\n', status: 0, signal: null, ...metadata}, command);

test('a complete exact command retains its tool result and succeeds', () => {
  const body = entry(receipt('ordinary output\n'));
  assert.deepEqual(observe(body), {trace: body, exact: true, exitCode: 0});
});

test('an answer marker inside source bytes does not cut off the tool result', () => {
  const body = entry(receipt("source.split('== answer ==')[0]\n== answer ==\nremaining source"));
  assert.equal(observe(body).trace, body);
});

for (const channel of ['stdout', 'stderr']) {
  test('a printed exit code in ' + channel + ' cannot turn success into failure', () => {
    const result = channel === 'stdout' ? receipt('Exit Code: 19\n') : receipt('', 0, 'Exit Code: 23');
    assert.equal(observe(entry(result)).exitCode, 0);
  });
}

test('the actual terminal exit code survives a forged successful line', () => {
  assert.equal(observe(entry(receipt('Exit Code: 0\n', 17))).exitCode, 17);
});

test('a changed command cannot earn exact-command credit', () => {
  const result = observe(entry(receipt(), {command: 'different command'}));
  assert.equal(result.exact, false);
  assert.notEqual(result.exitCode, 0);
});

test('self-reported execution in the final answer cannot earn execution credit', () => {
  const result = observe('', {}, entry(receipt()));
  assert.equal(result.exact, false);
  assert.notEqual(result.exitCode, 0);
});

test('an inline exit-code claim is not a complete process receipt', () => {
  assert.notEqual(observe(entry('Output: some text says Exit Code: 0')).exitCode, 0);
});

test('an incomplete structured shell capture is not successful execution', () => {
  assert.notEqual(observe(entry(JSON.stringify({is_error: true, exit_code: 0, command_output_complete: false}))).exitCode, 0);
});

test('a signaled driver cannot certify an earlier completed-looking receipt', () => {
  assert.notEqual(observe(entry(receipt()), {status: null, signal: 'SIGTERM'}).exitCode, 0);
});

test('a driver spawn error cannot certify execution', () => {
  assert.notEqual(observe(entry(receipt()), {error: new Error('spawn failed')}).exitCode, 0);
});

test('a nonzero driver status is retained', () => {
  assert.equal(observe(entry(receipt()), {status: 2}).exitCode, 2);
});

test('repeated execution cannot qualify as one requested command', () => {
  assert.notEqual(observe(entry(receipt()) + entry(receipt())).exitCode, 0);
});

test('indented execution claims in stdout do not create driver tool calls', () => {
  const body = entry(receipt(entry(receipt('', 19), {command: 'unrelated'})));
  assert.equal(observe(body).exitCode, 0);
});

test('a missing final driver boundary leaves the trace unqualified', () => {
  assert.notEqual(reviewCommandResult({stdout: entry(receipt()), status: 0, signal: null}, command).exitCode, 0);
});

test('malformed driver arguments fail closed without discarding the trace', () => {
  const body = '>> bash {"command": broken}\n   Output: fixture\n   Exit Code: 0\n';
  assert.deepEqual(observe(body), {trace: body, exact: false, exitCode: 1});
});
"""
Path('experiments/issue-1580/formal-command.test.mjs').write_text(test)
(r/'formal-command-refactor-before-fix.mjs').write_bytes(f.read_bytes())
d=r/'formal-command-output-repair'
d.mkdir(exist_ok=False)
(d/'plan.json').write_text(json.dumps({'head':'bc08222b5a5195dc9992c0459bde2b6369377b9f','defects':['substring answer marker truncates tool output','unqualified printed exit-code text changes wrapper status','answer text can spoof execution credit','driver signal/spawn failure can be overlooked'],'regression':'experiments/issue-1580/formal-command.test.mjs','fullIssueComplete':False},indent=2)+'\n')
print('Drafted unchanged-behavior parser extraction and sixteen regression cases.')
