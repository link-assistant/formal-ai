from pathlib import Path
p=Path('experiments/issue-1580/formal-command.mjs')
s=p.read_text()
start=s.index('// Interpret the captured driver result')
end=s.index('if (process.argv[1]',start)
replacement=r"""// Tool result lines are indented by drive.mjs; only its top-level boundary
// ends the transcript. Source bytes may contain the same marker or exit text.
export function reviewCommandResult(result, shellCommand) {
  const stdout = result.stdout ?? '';
  const boundary = /^== answer ==\r?$/mu.exec(stdout);
  const trace = boundary ? stdout.slice(0, boundary.index) : stdout;
  const headers = [...trace.matchAll(/^>> (\S+) ([^\r\n]*)\r?$/gmu)];
  let arguments_, receipt;
  if (headers.length === 1 && trace.slice(0, headers[0].index) === '') {
    try { arguments_ = JSON.parse(headers[0][2]); } catch { /* Invalid arguments earn no execution credit. */ }
    const body = trace.slice(headers[0].index + headers[0][0].length);
    // shell-capture.mjs appends the actual status after all stdout/stderr.
    // A preview, signal or JSON error capture has no such complete footer.
    if (body.startsWith('\n   Output: ')) receipt = /\n   Exit Code: (\d{1,3})\r?\n?$/u.exec(body);
  }
  const exact = headers.length === 1 && headers[0][1] === 'bash'
    && arguments_ !== null && typeof arguments_ === 'object' && !Array.isArray(arguments_)
    && Object.keys(arguments_).length === 1 && arguments_.command === shellCommand;
  const code = receipt ? Number(receipt[1]) : null;
  const driverSucceeded = result.status === 0 && !result.signal && !result.error;
  const qualified = boundary !== null && exact && code !== null && code <= 255;
  const exitCode = !driverSucceeded
    ? (Number.isInteger(result.status) && result.status > 0 ? result.status : 1)
    : qualified ? code : 1;
  return {trace, exact, exitCode};
}

"""
p.write_text(s[:start]+replacement+s[end:])
print('Qualified the exact single command and its complete terminal process receipt.')
