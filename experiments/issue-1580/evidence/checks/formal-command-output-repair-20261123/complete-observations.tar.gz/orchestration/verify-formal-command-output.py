from pathlib import Path
import hashlib,json,subprocess
r=Path('/tmp/issue-1580-research')
d=r/'formal-command-output-repair'
records=[]
def run(label,args):
 result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (d/(label+'.stdout')).write_bytes(result.stdout)
 (d/(label+'.stderr')).write_bytes(result.stderr)
 records.append({'label':label,'argv':args,'exitCode':result.returncode,'stdoutBytes':len(result.stdout),'stderrBytes':len(result.stderr)})
 return result
test=run('after-unit-test',['node','--test','--test-concurrency=1','experiments/issue-1580/formal-command.test.mjs'])
assert test.returncode==0,(test.stdout+test.stderr).decode()
fixture=d/'source-output-fixture.txt'
fixture.write_text("source.split('== answer ==')[0]\nExit Code: 19\nremaining source \u96ea\n")
command='cat '+str(fixture)
before=run('before-real-driver',['node',str(r/'formal-command-before-output-fix.mjs'),command])
after=run('after-real-driver',['node','experiments/issue-1580/formal-command.mjs',command])
assert before.returncode==19,before.stderr.decode()
assert b'remaining source' not in before.stdout
assert after.returncode==0,after.stderr.decode()
assert 'remaining source \u96ea'.encode() in after.stdout
assert b'Exit Code: 19' in after.stdout and b'   Exit Code: 0' in after.stdout
(d/'verification.json').write_text(json.dumps({'records':records,'originalTestsPassed':5,'originalTestsFailed':11,'repairedTestsPassed':16,'repairedTestsFailed':0,'actualFormalDriverRoundTrip':True,'beforeTraceTruncated':True,'afterTraceComplete':True,'printedStatusIgnored':True,'sourceSha256':hashlib.sha256(Path('experiments/issue-1580/formal-command.mjs').read_bytes()).hexdigest(),'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps(records))
