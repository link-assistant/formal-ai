from pathlib import Path
import subprocess,json,re
root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/artifact-input-review');out.mkdir(exist_ok=True)
r=subprocess.run(['gh','run','view','44720055862','--repo','link-assistant/formal-ai','--json','jobs'],cwd=root,capture_output=True,text=True);(out/'pipeline-jobs.json').write_text(r.stdout);assert r.returncode==0,r.stderr
print('UNFINISHED JOBS',json.dumps([{k:j.get(k) for k in ['databaseId','name','status','conclusion','startedAt','completedAt']} for j in json.loads(r.stdout)['jobs'] if j['status']!='completed']))
files=sorted(p for p in (root/'.github').rglob('*') if p.is_file() and p.suffix in ['.yml','.yaml'])
for p in files:
 a=p.read_text().splitlines()
 for i,line in enumerate(a):
  if 'uses: actions/download-artifact@' not in line and 'DEP0040' not in line:continue
  start=max(0,i-3);end=min(len(a),i+32)
  for j in range(i+1,end):
   if re.match(r'\s*- name:',a[j]) and len(a[j])-len(a[j].lstrip())<=len(line)-len(line.lstrip()):end=j;break
  print('FILE',p.relative_to(root),f'LINES {start+1}-{end}')
  for j in range(start,end):print(f'{j+1}: {a[j]}')
print('TEMPLATE TESTS')
r=subprocess.run(['rg','--files','/tmp/issue-1580-research/templates/rust-complete'],capture_output=True,text=True);print('\n'.join(s for s in r.stdout.splitlines() if 'extract' in s or 'artifact' in s))
