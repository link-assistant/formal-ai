from pathlib import Path
import subprocess,os,json,hashlib,shutil
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/artifact-extractor-upstream');s.mkdir(exist_ok=False)
(s/'package.json').write_text('{"name":"issue-1580-extractor-probe","private":true,"version":"0.0.0"}\n')
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=128',npm_config_cache='/tmp/issue-1580-research/npm-probe-cache')
args=['npm','install','--ignore-scripts','--no-audit','--no-fund','--no-package-lock','unzip-stream@0.3.4'];p=subprocess.Popen(args,cwd=s,env=env,stdout=(s/'install.stdout').open('wb'),stderr=(s/'install.stderr').open('wb'));print('Background installation PID',p.pid,flush=True);status=p.wait();print('Installation exit',status,flush=True);assert status==0
# The original template fixture supplies the actual deprecated dependency probe.
source=Path('/tmp/issue-1580-research/templates/rust-complete/experiments/issue-223-deprecated-extractor.cjs');target=r/'experiments/issue-1580/reproduce-artifact-extractor.cjs';shutil.copyfile(source,target)
env['UNZIP_STREAM_ROOT']=str(s);p=subprocess.run(['node',str(target)],cwd=r,env=env,capture_output=True);(s/'reproduction.stdout').write_bytes(p.stdout);(s/'reproduction.stderr').write_bytes(p.stderr);print('Actual unzip-stream probe exit',p.returncode,flush=True);print(p.stdout.decode(),flush=True);print(p.stderr.decode(),flush=True);assert p.returncode==0
for path in [s/'node_modules/unzip-stream/package.json',s/'node_modules/binary/package.json',s/'node_modules/buffers/package.json']:
 data=path.read_bytes();print('DEPENDENCY',path.relative_to(s),hashlib.sha256(data).hexdigest());print(data.decode())
