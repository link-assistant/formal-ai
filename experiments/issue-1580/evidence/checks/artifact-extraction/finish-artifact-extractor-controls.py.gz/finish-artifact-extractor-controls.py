from pathlib import Path
import subprocess,os,json,tempfile,zipfile
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/artifact-download-checks');env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
p=r/'experiments/issue-1580/artifact-extraction-fixtures.py';t=p.read_text().replace('import os\n','');needle='''        path = self.archive(entries=[("file", b"unique fixture bytes")])''';replacement='''        with zipfile.ZipFile(path, "w"):
            pass
        with self.assertRaises(ValueError):
            self.module.extract_artifacts(self.raw, self.destination, False)
        self.assertFalse(self.destination.exists())
'''+needle;assert needle in t;p.write_text(t.replace(needle,replacement))
args=['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/native-test-artifact.test.mjs'];p=subprocess.run(args,cwd=r,env=env,capture_output=True);(s/'empty-archive-before.stdout').write_bytes(p.stdout);(s/'empty-archive-before.stderr').write_bytes(p.stderr);print('Empty archive before',p.returncode,flush=True);assert p.returncode!=0
p=r/'scripts/extract-artifacts.py';t=p.read_text();needle='''        # Validate every path and member type before any destination is changed.
        root.mkdir''';assert needle in t;t=t.replace(needle,'''        # Validate every path and member type before any destination is changed.
        if not planned:
            raise ValueError("Artifact archives contain no members")
        root.mkdir''');p.write_text(t)
p=r/'experiments/issue-1580/reproduce-artifact-extractor.cjs';t=p.read_text();p.write_text('// Reused from link-foundation Rust template at 309387f761f9f0f1b2ea15bfe181cb51f5a9a1fb (Unlicense).\n'+t)
results=[]
for file in ['native-test-artifact','release-web','default-branch-build-policy','documentation-only-ci-policy','fast-pull-request-production-profile']:
 args=['timeout','600','node','--test','--test-concurrency=1',f'rust/tests/web/{file}.test.mjs'];p=subprocess.run(args,cwd=r,env=env,capture_output=True);(s/(file+'-final.stdout')).write_bytes(p.stdout);(s/(file+'-final.stderr')).write_bytes(p.stderr);results.append({'command':args,'exitCode':p.returncode});print(file,p.returncode,flush=True)
# Offline rehearsal uses a real ZIP of the bounded hosted payload. This does not run the Actions transport.
with tempfile.TemporaryDirectory(prefix='artifact-roundtrip-') as directory:
 root=Path(directory);raw=root/'raw';raw.mkdir()
 subprocess.run(['python3','experiments/issue-1580/artifact-transport-roundtrip.py','prepare',directory],cwd=r,check=True)
 with zipfile.ZipFile(raw/'artifact','w') as archive:
  archive.write(root/'source/nested/payload.bin','nested/payload.bin')
 output=root/'output';p=subprocess.run(['python3','scripts/extract-artifacts.py',str(raw),str(root/'download')],cwd=r,env=dict(env,GITHUB_OUTPUT=str(output)),capture_output=True);(s/'roundtrip.stdout').write_bytes(p.stdout);(s/'roundtrip.stderr').write_bytes(p.stderr);assert p.returncode==0
 lines=output.read_text().splitlines();assert lines[0].startswith('download-path<<') and lines[1]==str(root/'download') and lines[2]==lines[0].split('<<')[1]
 subprocess.run(['python3','experiments/issue-1580/artifact-transport-roundtrip.py','verify',directory],cwd=r,check=True)
(s/'final.json').write_text(json.dumps(results,indent=2)+'\n');assert all(x['exitCode']==0 for x in results)
