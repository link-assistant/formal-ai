from pathlib import Path
import os,subprocess,json
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/artifact-final-gates');env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
p=r/'rust/tests/web/native-test-artifact.test.mjs';t=p.read_text();needle=" const extraction=adapter.runs.steps.find(step=>step.id==='extract');";assert needle in t;t=t.replace(needle,needle+"\n assert.equal(extraction['working-directory'],'${{ github.workspace }}');");p.write_text(t)
args=['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/native-test-artifact.test.mjs'];p=subprocess.run(args,cwd=r,env=env,capture_output=True);(s/'working-directory-before.stdout').write_bytes(p.stdout);(s/'working-directory-before.stderr').write_bytes(p.stderr);print('BEFORE',p.returncode,flush=True);assert p.returncode!=0
p=r/'.github/actions/download-artifact/action.yml';t=p.read_text();needle='''    - name: Extract verified archives
      id: extract
      shell: bash
''';assert needle in t;t=t.replace(needle,needle+'      working-directory: ${{ github.workspace }}\n');p.write_text(t)
p=subprocess.run(args,cwd=r,env=env,capture_output=True);(s/'working-directory-after.stdout').write_bytes(p.stdout);(s/'working-directory-after.stderr').write_bytes(p.stderr);print('AFTER',p.returncode,flush=True);assert p.returncode==0
