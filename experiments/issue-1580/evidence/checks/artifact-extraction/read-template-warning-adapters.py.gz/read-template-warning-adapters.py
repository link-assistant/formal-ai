from pathlib import Path
import subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');t=Path('/tmp/issue-1580-research/templates/rust-complete')
for args in [['rg','-n','punycode|DEP0040|deploy-pages@','--glob','!dev/log/**','--glob','!docs/case-studies/**',str(t)],['rg','-n','DEP0005|download-artifact','rust/tests/web','--glob','ci-*.test.mjs']]:
 p=subprocess.run(args,cwd=r,capture_output=True,text=True);print('SEARCH',args,'EXIT',p.returncode);print(p.stdout[:12000]);print(p.stderr)
