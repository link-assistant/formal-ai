from pathlib import Path
import subprocess,json
r=Path('/tmp/gh-issue-solver-1794900398048')
for file in ['.github/workflows/workflows.yml','scripts/lib/ci-event-policy.mjs','rust/tests/web/documentation-only-ci-policy.test.mjs']:
 p=r/file
 if p.exists():
  lines=p.read_text().splitlines();print('FILE',file,'LINES',len(lines));
  if len(lines)<1500: print('\n'.join(f'{n}: {line}' for n,line in enumerate(lines,1)))
for p in Path('/tmp/issue-1580-research/templates/rust-complete/experiments').rglob('*'):
 if p.is_file() and ('artifact' in p.name or 'zip' in p.name): print('TEMPLATE EXPERIMENT',p);print(p.read_text())
