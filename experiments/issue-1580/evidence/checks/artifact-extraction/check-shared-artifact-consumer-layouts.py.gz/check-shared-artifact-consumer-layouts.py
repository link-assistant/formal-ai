from pathlib import Path
import subprocess
r=Path('/tmp/gh-issue-solver-1794900398048')
code="""import fs from 'node:fs';import Y from 'yaml';for(const f of fs.readdirSync('.github/workflows').filter(f=>f.endsWith('.yml'))){const w=Y.parse(fs.readFileSync('.github/workflows/'+f,'utf8'));for(const[id,j]of Object.entries(w.jobs??{})){const a=(j.steps??[]).filter(s=>s.uses?.includes('download-formal-ai-binary')||s.uses?.includes('/release-web'));if(a.length)console.log(JSON.stringify({workflow:f,job:id,consumers:a,checkouts:j.steps.filter(s=>s.uses?.includes('checkout@')),setup:j.steps.filter(s=>s.with?.['sparse-checkout'])},null,2))}}"""
p=subprocess.run(['node','--input-type=module','-e',code],cwd=r,capture_output=True);print(p.stdout.decode());print(p.stderr.decode());assert p.returncode==0
