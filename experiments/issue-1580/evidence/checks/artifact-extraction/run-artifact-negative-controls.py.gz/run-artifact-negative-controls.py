from pathlib import Path
import subprocess,os,json
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/artifact-download-checks');s.mkdir(exist_ok=False);env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256');results=[]
for file in ['native-test-artifact','release-web']:
 args=['timeout','600','node','--test','--test-concurrency=1',f'rust/tests/web/{file}.test.mjs'];p=subprocess.run(args,cwd=r,env=env,capture_output=True);(s/(file+'-before.stdout')).write_bytes(p.stdout);(s/(file+'-before.stderr')).write_bytes(p.stderr);results.append({'file':file,'exitCode':p.returncode});print(file,p.returncode);assert p.returncode!=0,'Negative control unexpectedly passed'
(s/'before.json').write_text(json.dumps(results,indent=2)+'\n')
