from pathlib import Path
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'experiments/issue-1580/artifact-transport-roundtrip.py'
p.write_text('''#!/usr/bin/env python3
"""Create and verify a tiny real Actions artifact without repository build output."""
import argparse
from pathlib import Path

PAYLOAD = bytes(range(256)) * 4


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("prepare", "verify"))
    parser.add_argument("directory", type=Path)
    options = parser.parse_args()
    root = options.directory
    if options.mode == "prepare":
        (root / "source/nested").mkdir(parents=True)
        (root / "source/nested/payload.bin").write_bytes(PAYLOAD)
        (root / "download/nested").mkdir(parents=True)
        (root / "download/nested/payload.bin").write_bytes(b"old cached executable")
        (root / "download/retained.txt").write_text("retained", encoding="utf-8")
    else:
        assert (root / "download/nested/payload.bin").read_bytes() == PAYLOAD
        assert (root / "download/retained.txt").read_text(encoding="utf-8") == "retained"
        assert not list((root / "download").rglob(".artifact-*"))
        print("Actual artifact transport preserved every byte and refreshed the cached file.")


if __name__ == "__main__":
    main()
''')
p=r/'rust/tests/web/native-test-artifact.test.mjs';s=p.read_text();s+='''
test('hosted artifact round trip uses the real raw adapter on all supported desktop hosts',()=>{
 const workflow=YAML.parse(readFileSync(new URL('../../../.github/workflows/workflows.yml',import.meta.url),'utf8'));
 for(const event of ['push','pull_request'])for(const path of ['scripts/extract-artifacts.py','experiments/issue-1580/artifact-transport-roundtrip.py'])assert(workflow.on[event].paths.includes(path));
 const job=workflow.jobs['artifact-roundtrip'];
 assert(job);assert.equal(job['timeout-minutes'],10);
 assert.deepEqual(job.strategy.matrix.os,['ubuntu-24.04','macos-15','windows-2025']);
 const steps=job.steps,prepare=steps.findIndex(step=>step.run?.includes(' prepare ')),verify=steps.findIndex(step=>step.run?.includes(' verify '));
 const upload=steps.findIndex(step=>step.uses==='actions/upload-artifact@v7');
 const download=steps.findIndex(step=>step.uses==='./.github/actions/download-artifact');
 assert(prepare>=0 && upload>prepare && download>upload && verify>download);
 assert.equal(steps[upload].with.name,steps[download].with.name);
 assert.equal(steps[upload].with['if-no-files-found'],'error');
 assert.equal(steps[upload].with.path,'${{ runner.temp }}/artifact-roundtrip/source');
 assert.equal(steps[download].with.path,'${{ runner.temp }}/artifact-roundtrip/download');
 assert.equal(steps[0].with['persist-credentials'],false);
 for(const path of ['/.github/actions/download-artifact/','/scripts/extract-artifacts.py','/experiments/issue-1580/artifact-transport-roundtrip.py'])assert(steps[0].with['sparse-checkout'].includes(path));
});
''';p.write_text(s)
print('Drafted actual transport fixture and admission regression before hosted workflow implementation.')
