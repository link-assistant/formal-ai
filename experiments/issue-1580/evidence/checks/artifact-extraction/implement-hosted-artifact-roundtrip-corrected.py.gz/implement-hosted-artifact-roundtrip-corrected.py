from pathlib import Path
import subprocess,os,json
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/artifact-download-checks');env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
args=['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/native-test-artifact.test.mjs'];p=subprocess.run(args,cwd=r,env=env,capture_output=True);(s/'hosted-roundtrip-before.stdout').write_bytes(p.stdout);(s/'hosted-roundtrip-before.stderr').write_bytes(p.stderr);print('BEFORE',p.returncode,flush=True);assert p.returncode!=0
p=r/'.github/workflows/workflows.yml';t=p.read_text();assert t.count("    paths: ['.github/**']")==2;t=t.replace("    paths: ['.github/**']","    paths: ['.github/**', 'scripts/extract-artifacts.py', 'experiments/issue-1580/artifact-transport-roundtrip.py']");t=t.replace('# Both jobs are gated on `paths:', '# Workflow checks are gated on `paths:').replace("# when the workflows do.","# when workflow sources do; the artifact fixture also selects its extractor.")
t+='''
  artifact-roundtrip:
    name: Artifact transport (${{ matrix.os }})
    runs-on: ${{ matrix.os }}
    timeout-minutes: 10
    strategy:
      fail-fast: false
      matrix:
        os: [ubuntu-24.04, macos-15, windows-2025]
    concurrency:
      group: check-${{ github.workflow }}-${{ github.ref }}-artifact-${{ matrix.os }}
      cancel-in-progress: ${{ github.ref != 'refs/heads/main' }}
    steps:
      - uses: actions/checkout@v7
        timeout-minutes: 3
        with:
          persist-credentials: false
          filter: blob:none
          sparse-checkout: |
            /.github/actions/download-artifact/
            /scripts/extract-artifacts.py
            /experiments/issue-1580/artifact-transport-roundtrip.py
          sparse-checkout-cone-mode: false
      - uses: actions/setup-python@v6
        with:
          python-version: '3.14'
      - name: Prepare a bounded artifact and cached destination
        shell: bash
        env:
          ROUNDTRIP: ${{ runner.temp }}/artifact-roundtrip
        run: python experiments/issue-1580/artifact-transport-roundtrip.py prepare "$ROUNDTRIP"
      - uses: actions/upload-artifact@v7
        with:
          name: artifact-roundtrip-${{ matrix.os }}
          path: ${{ runner.temp }}/artifact-roundtrip/source
          if-no-files-found: error
          retention-days: 1
      - uses: ./.github/actions/download-artifact
        with:
          name: artifact-roundtrip-${{ matrix.os }}
          path: ${{ runner.temp }}/artifact-roundtrip/download
      - name: Verify actual downloaded bytes and cached replacement
        shell: bash
        env:
          ROUNDTRIP: ${{ runner.temp }}/artifact-roundtrip
        run: python experiments/issue-1580/artifact-transport-roundtrip.py verify "$ROUNDTRIP"
''';p.write_text(t)
p=subprocess.run(args,cwd=r,env=env,capture_output=True);(s/'hosted-roundtrip-after.stdout').write_bytes(p.stdout);(s/'hosted-roundtrip-after.stderr').write_bytes(p.stderr);print('AFTER',p.returncode,flush=True);assert p.returncode==0
