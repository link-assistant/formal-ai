from pathlib import Path
import subprocess,os,json,gzip,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/artifact-final-gates');s.mkdir(exist_ok=False);env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
files=['scripts/extract-artifacts.py','.github/actions/download-artifact/action.yml','.github/actions/download-formal-ai-binary/action.yml','.github/actions/release-web/action.yml','experiments/issue-1580/artifact-transport-roundtrip.py','experiments/issue-1580/reproduce-artifact-extractor.cjs','docs/case-studies/issue-1580/artifact-extraction-checkpoint.md']
for file in files:print('READ',file,flush=True);print((r/file).read_text(),flush=True)
args=['node','--input-type=module','-e',"import fs from 'node:fs';import Y from 'yaml';for(const [file,id]of [['release.yml','fast-pr-lint'],['layered-ci.yml','js']]){const data=Y.parse(fs.readFileSync('.github/workflows/'+file,'utf8'));console.log(file,id,JSON.stringify(data.jobs[id],null,2))}"]
p=subprocess.run(args,cwd=r,env=env,capture_output=True);(s/'checkout-closure.txt').write_bytes(p.stdout);print('Checkout closure',p.returncode)
results=[]
for g in ['check-runner-labels','release#1','check-changelog-fragment-js-twin','check-file-size','check-file-size-js-twin','check-abbreviations']:
 args=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',g];p=subprocess.run(args,cwd=r,env=env,capture_output=True);(s/(g.replace('#','-')+'.stdout')).write_bytes(p.stdout);(s/(g.replace('#','-')+'.stderr')).write_bytes(p.stderr);results.append({'command':args,'exitCode':p.returncode});print(g,p.returncode,flush=True)
for args in [['git','diff','--check'],['git','branch','--show-current'],['git','fetch','origin','main'],['git','merge-base','--is-ancestor','origin/main','HEAD'],['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--status','in_progress','--json','databaseId,workflowName,headSha'],['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--status','queued','--json','databaseId,workflowName,headSha']]:
 p=subprocess.run(args,cwd=r,env=env,capture_output=True);results.append({'command':args,'exitCode':p.returncode});print(args,p.returncode,flush=True);print(p.stdout.decode(),flush=True);print(p.stderr.decode(),flush=True)
(s/'results.json').write_text(json.dumps(results,indent=2)+'\n');assert all(x['exitCode']==0 for x in results)
