from pathlib import Path
import subprocess,os,json
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/artifact-download-checks');env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256');results=[]
for file in ['documentation-only-ci-policy','fast-pull-request-production-profile']:
 args=['timeout','600','node','--test','--test-concurrency=1',f'rust/tests/web/{file}.test.mjs'];p=subprocess.run(args,cwd=r,env=env,capture_output=True);(s/(file+'.stdout')).write_bytes(p.stdout);(s/(file+'.stderr')).write_bytes(p.stderr);results.append({'command':args,'exitCode':p.returncode});print(file,p.returncode,flush=True)
(s/'admission.json').write_text(json.dumps(results,indent=2)+'\n')
for args in [['rg','--files','/tmp/issue-1580-research/templates/rust-complete/experiments'],['rg','-n','MatcherStream|reproduce_artifact','/tmp/issue-1580-research/artifact-producer-research']]:
 p=subprocess.run(args,cwd=r,capture_output=True);print(args,p.returncode);print(p.stdout.decode());print(p.stderr.decode())
assert all(x['exitCode']==0 for x in results)
