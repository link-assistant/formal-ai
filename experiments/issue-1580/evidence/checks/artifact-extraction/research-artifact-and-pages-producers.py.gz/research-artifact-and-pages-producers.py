from pathlib import Path
import subprocess, json, base64
root=Path('/tmp/gh-issue-solver-1794900398048'); out=Path('/tmp/issue-1580-research/artifact-producer-research');out.mkdir(exist_ok=True)
def api(name,path):
 r=subprocess.run(['gh','api',path,'--paginate'],cwd=root,capture_output=True);(out/(name+'.json')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);assert r.returncode==0,(name,r.stderr);return json.loads(r.stdout)
for name,path in [('download-definition','repos/actions/download-artifact/contents/action.yml?ref=9000827ccba6bdab643e8b6fd33ac0654aef8333'),('download-source','repos/actions/download-artifact/contents/src/download-artifact.ts?ref=9000827ccba6bdab643e8b6fd33ac0654aef8333'),('download-package','repos/actions/download-artifact/contents/package.json?ref=9000827ccba6bdab643e8b6fd33ac0654aef8333'),('pages-tags','repos/actions/deploy-pages/tags?per_page=100'),('pages-package','repos/actions/deploy-pages/contents/package.json?ref=v4')]:
 d=api(name,path)
 if isinstance(d,dict) and d.get('encoding')=='base64':
  raw=base64.b64decode(d['content']);(out/(name+'.txt')).write_bytes(raw);a=raw.decode().splitlines();print('SOURCE',name,'BLOB',d['sha'],'LINES',len(a))
  for i,s in enumerate(a,1):print(f'{i}: {s}')
 else:print(name,json.dumps([{'name':x['name'],'sha':x['commit']['sha']} for x in d[:12]]))
for f in ['experiments/issue-223-artifact-tests.py','experiments/issue-223-deprecated-extractor.cjs','.github/actions/deploy-pages/action.yml']:
 p=Path('/tmp/issue-1580-research/templates/rust-complete')/f;print('TEMPLATE',f,'EXISTS',p.exists())
 if p.exists():
  for i,s in enumerate(p.read_text().splitlines(),1):print(f'{i}: {s}')
