from pathlib import Path
import subprocess,os,json
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/artifact-download-checks');env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256');results=[]
commands=[['node','experiments/formal_ai_subagent/local-gates.mjs','--only',g] for g in ['release#1','check-changelog-fragment-js-twin','check-file-size','check-file-size-js-twin','check-abbreviations']]
commands += [['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/default-branch-build-policy.test.mjs'],['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/documentation-policy.test.mjs']]
for n,args in enumerate(commands):
 p=subprocess.run(args,cwd=r,env=env,capture_output=True);(s/f'gate-{n}.stdout').write_bytes(p.stdout);(s/f'gate-{n}.stderr').write_bytes(p.stderr);results.append({'command':args,'exitCode':p.returncode});print(n,args,p.returncode,flush=True)
(s/'gates.json').write_text(json.dumps(results,indent=2)+'\n')
for args in [['git','diff','--stat'],['git','diff','--','.github/actions/download-formal-ai-binary/action.yml','.github/actions/release-web/action.yml'],['git','status','--short']]:
 p=subprocess.run(args,cwd=r,capture_output=True);print(args,p.returncode);print(p.stdout.decode());print(p.stderr.decode())
assert all(x['exitCode']==0 for x in results)
