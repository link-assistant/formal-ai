from pathlib import Path
import subprocess,os,json
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/artifact-download-checks');env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
for file in ['scripts/extract-artifacts.py','.github/actions/download-artifact/action.yml','experiments/issue-1580/artifact-extraction-fixtures.py','rust/tests/web/native-test-artifact.test.mjs','rust/tests/web/release-web.test.mjs','changelog.d/1580-artifact-extraction.md']:
 print('\nSOURCE',file,flush=True);print((r/file).read_text(),flush=True)
results=[]
for file in ['native-test-artifact','release-web']:
 args=['timeout','600','node','--test','--test-concurrency=1',f'rust/tests/web/{file}.test.mjs'];p=subprocess.run(args,cwd=r,env=env,capture_output=True);(s/(file+'-after.stdout')).write_bytes(p.stdout);(s/(file+'-after.stderr')).write_bytes(p.stderr);results.append({'file':file,'exitCode':p.returncode});print('TEST',file,p.returncode,flush=True)
(s/'after.json').write_text(json.dumps(results,indent=2)+'\n')
for args in [['git','branch','--show-current'],['git','status','--short'],['git','diff','--check'],['gh','run','view','44720055862','--repo','link-assistant/formal-ai','--json','status,conclusion,jobs'],['node','experiments/formal_ai_subagent/local-gates.mjs','--list']]:
 p=subprocess.run(args,cwd=r,env=env,capture_output=True);print('COMMAND',args,'EXIT',p.returncode,flush=True);print(p.stdout.decode(),flush=True);print(p.stderr.decode(),flush=True)
assert all(x['exitCode']==0 for x in results)
