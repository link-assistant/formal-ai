from pathlib import Path
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'scripts/extract-artifacts.py'
p.write_text('''#!/usr/bin/env python3
"""Extract verified raw Actions archives without the deprecated Node ZIP parser.

Uses the raw-download adapter pattern from link-foundation's Rust template at
309387f761f9f0f1b2ea15bfe181cb51f5a9a1fb (Unlicense). Existing regular files
can be refreshed, as with download-artifact; links and conflicting members fail.
"""
import argparse
from contextlib import ExitStack
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import tempfile
import uuid
import zipfile


def member_path(name):
    """Require a portable, unambiguous path below the selected destination."""
    if not name or "\\\\" in name or "\\0" in name or name.startswith("/") or re.match(r"^[A-Za-z]:", name):
        raise ValueError(f"Unsafe artifact member: {name!r}")
    parts = name.removesuffix("/").split("/")
    if any(part in ("", ".", "..") for part in parts):
        raise ValueError(f"Ambiguous artifact member: {name!r}")
    return PurePosixPath(*parts)


def validate_destination(root, relative, directory):
    current = root
    parts = relative.parts
    for index, part in enumerate(parts):
        current = current / part
        if current.is_symlink():
            raise ValueError(f"Artifact destination is a symlink: {current}")
        must_be_directory = index < len(parts) - 1 or directory
        if current.exists() and ((must_be_directory and not current.is_dir()) or (not must_be_directory and not current.is_file())):
            raise ValueError(f"Conflicting artifact destination: {current}")
    return root.joinpath(*parts)


def raw_archives(raw):
    """SDK raw mode writes one ZIP per download, flat for a single artifact."""
    if not raw.is_dir() or raw.is_symlink():
        raise ValueError("Raw artifact directory is absent or is a symlink")
    sources = []
    for entry in sorted(raw.iterdir()):
        if entry.is_symlink():
            raise ValueError("Raw artifact path is a symlink")
        if entry.is_file():
            sources.append((PurePosixPath(), entry))
        elif entry.is_dir():
            files = list(entry.iterdir())
            if len(files) != 1 or files[0].is_symlink() or not files[0].is_file():
                raise ValueError("Expected one raw ZIP per artifact")
            sources.append((member_path(entry.name), files[0]))
        else:
            raise ValueError("Raw artifact path is not a regular file or directory")
    if not sources or (len(sources) > 1 and any(not prefix.parts for prefix, _ in sources)):
        raise ValueError("Raw artifact layout is empty or ambiguous")
    return sources


def extract_artifacts(raw, destination, merge_multiple=False):
    root = Path(destination).expanduser().absolute()
    if root.is_symlink() or (root.exists() and not root.is_dir()):
        raise ValueError("Artifact destination is not a real directory")
    root = root.resolve()
    planned, files, directories = [], set(), set()
    with ExitStack() as stack:
        for prefix, source in raw_archives(Path(raw)):
            archive = stack.enter_context(zipfile.ZipFile(source))
            for member in archive.infolist():
                member_path(member.orig_filename)
                relative = member_path(member.filename)
                if not merge_multiple:
                    relative = prefix / relative
                mode = stat.S_IFMT(member.external_attr >> 16)
                directory = member.is_dir()
                if mode not in (0, stat.S_IFDIR if directory else stat.S_IFREG):
                    raise ValueError(f"Non-regular artifact member: {member.filename!r}")
                key = str(relative).casefold()
                parents = {str(parent).casefold() for parent in relative.parents if parent.parts}
                if key in files or parents & files or (not directory and key in directories):
                    raise ValueError(f"Duplicate or conflicting artifact member: {relative}")
                directories.update(parents)
                (directories if directory else files).add(key)
                target = validate_destination(root, relative, directory)
                planned.append((archive, member, relative, target))
        # Validate every path and member type before any destination is changed.
        root.mkdir(parents=True, exist_ok=True)
        for archive, member, relative, target in planned:
            validate_destination(root, relative, member.is_dir())
            if member.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            temporary = None
            try:
                # CRC errors never replace an existing cached executable.
                with tempfile.NamedTemporaryFile(dir=target.parent, prefix=".artifact-", delete=False) as output:
                    temporary = Path(output.name)
                    with archive.open(member) as content:
                        shutil.copyfileobj(content, output, length=1024 * 1024)
                temporary.chmod(0o644)
                validate_destination(root, relative, False)
                os.replace(temporary, target)
            finally:
                if temporary is not None:
                    temporary.unlink(missing_ok=True)
    return root


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("raw", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--merge-multiple", choices=("true", "false"), default="false")
    options = parser.parse_args()
    destination = extract_artifacts(options.raw, options.destination, options.merge_multiple == "true")
    if os.environ.get("GITHUB_OUTPUT"):
        delimiter = "artifact_path_" + uuid.uuid4().hex
        with open(os.environ["GITHUB_OUTPUT"], "a", encoding="utf-8") as output:
            output.write(f"download-path<<{delimiter}\\n{destination}\\n{delimiter}\\n")
    print(f"Extracted verified artifact archives to {destination}")


if __name__ == "__main__":
    main()
''')
p=r/'.github/actions/download-artifact/action.yml';p.parent.mkdir(exist_ok=True)
p.write_text('''name: Download verified artifacts without deprecated extraction
 description: unused
'''.replace(' description: unused','description: Preserve strict transport digests and extract ZIP members with Python'))
p.write_text(p.read_text()+'''inputs:
  name:
    description: Artifact name; omitted for ID or pattern selection
  artifact-ids:
    description: Comma-separated artifact IDs
  pattern:
    description: Artifact name pattern
  path:
    description: Extraction destination
    default: ${{ github.workspace }}
  merge-multiple:
    description: Merge selected artifacts into the destination
    default: 'false'
  github-token:
    description: Optional cross-run or cross-repository download token
  repository:
    description: Producer repository
    default: ${{ github.repository }}
  run-id:
    description: Producer workflow run
    default: ${{ github.run_id }}
outputs:
  download-path:
    description: Absolute extraction destination
    value: ${{ steps.extract.outputs.download-path }}
runs:
  using: composite
  steps:
    - uses: actions/setup-python@v6
      with:
        python-version: '3.14'
    - name: Allocate raw archive directory
      id: temporary
      shell: bash
      run: echo "path=$(mktemp -d "$RUNNER_TEMP/artifact-archives.XXXXXX")" >> "$GITHUB_OUTPUT"
    - uses: actions/download-artifact@9000827ccba6bdab643e8b6fd33ac0654aef8333 # v8.0.2
      env:
        NODE_OPTIONS: --throw-deprecation
      with:
        name: ${{ inputs.name }}
        artifact-ids: ${{ inputs.artifact-ids }}
        pattern: ${{ inputs.pattern }}
        github-token: ${{ inputs.github-token }}
        repository: ${{ inputs.repository }}
        run-id: ${{ inputs.run-id }}
        path: ${{ steps.temporary.outputs.path }}
        merge-multiple: false
        skip-decompress: true
        digest-mismatch: error
    - name: Extract verified archives
      id: extract
      shell: bash
      env:
        ACTION_DIRECTORY: ${{ github.action_path }}
        RAW_DIRECTORY: ${{ steps.temporary.outputs.path }}
        DESTINATION: ${{ inputs.path }}
        MERGE_MULTIPLE: ${{ inputs.merge-multiple }}
      run: python "$ACTION_DIRECTORY/../../../scripts/extract-artifacts.py" "$RAW_DIRECTORY" "$DESTINATION" --merge-multiple "$MERGE_MULTIPLE"
    - name: Remove temporary raw archives
      if: always() && steps.temporary.outcome == 'success'
      shell: bash
      env:
        RAW_DIRECTORY: ${{ steps.temporary.outputs.path }}
      run: rm -rf -- "$RAW_DIRECTORY"
''')
for f in ['download-formal-ai-binary','release-web']:
 p=r/f'.github/actions/{f}/action.yml';s=p.read_text();assert s.count('uses: actions/download-artifact@v8')==1;s=s.replace('uses: actions/download-artifact@v8','uses: ./.github/actions/download-artifact');s=s.replace('      env:\n        NODE_OPTIONS: --disable-warning=DEP0005\n','');p.write_text(s)
p=r/'changelog.d/1580-artifact-extraction.md';p.write_text('''---
bump: patch
---

### Fixed
- Download native and selected-source renderer artifacts with strict digest verification and streaming extraction, replacing the deprecated Node ZIP parser while preserving cached regular-file refreshes and refusing unsafe archive paths.
''')
print('Drafted strict raw transport, streaming/atomic extraction, two existing shared consumers and patch release fragment.')
