from pathlib import Path
import subprocess
r=Path('/tmp/gh-issue-solver-1794900398048')
code="""import fs from 'node:fs';import Y from 'yaml';const w=Y.parse(fs.readFileSync('.github/workflows/desktop-release.yml','utf8'));for(const id of ['native-source','build','vscode']){const s=w.jobs[id].steps;const use=s.findIndex(s=>s.uses==='./.github/actions/release-web');console.log(id,JSON.stringify(s.slice(0,use+1),null,2))}"""
p=subprocess.run(['node','--input-type=module','-e',code],cwd=r,capture_output=True);print(p.stdout.decode());print(p.stderr.decode());assert p.returncode==0
for args in [['rg','-n','release-web|download-artifact|extract-artifacts|PROTOCOL|protocol','scripts/native-release-source.mjs'],['rg','-n','release-web|PROTOCOL|protocol','rust/tests/web/native-release-artifact.test.mjs']]:
 p=subprocess.run(args,cwd=r,capture_output=True);print(args,p.returncode);print(p.stdout.decode());print(p.stderr.decode())
