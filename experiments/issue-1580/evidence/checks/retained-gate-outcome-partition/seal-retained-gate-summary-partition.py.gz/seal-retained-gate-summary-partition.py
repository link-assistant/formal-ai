from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = scratch / 'retained-gate-summary-partition'
if len(sys.argv) == 1:
    with (out / 'worker.log').open('wb') as stream:
        process = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print('Started finite partition checks', process.pid)
    raise SystemExit()
records = []
def run(name, argv):
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=root, env={**os.environ, 'NODE_OPTIONS': '--max-old-space-size=256'}, stdout=stdout, stderr=stderr)
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == 0
    return (out / (name + '.stdout')).read_text()
assert run('branch', ['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
selected = ['experiments/issue-1580/evidence/checks/all-local-gates-fifth-summary.json', 'experiments/issue-1580/evidence/checks/all-local-gates-fifth-outcomes', 'docs/case-studies/issue-1580/README.md']
run('stage-partition', ['git', 'add', '--', *selected])
run('gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-abbreviations,check-file-size-js-twin,check-file-size,check-readable-code'])
archive = root / 'experiments/issue-1580/evidence/checks/retained-gate-outcome-partition'
archive.mkdir(exist_ok=False)
files = [scratch / 'partition-retained-gate-summary.py', scratch / 'partition-retained-gate-summary.log', scratch / 'seal-retained-gate-summary-partition.py', *[path for path in out.iterdir() if path.is_file() and path.name != 'worker.log']]
entries = []
for path in sorted(set(files)):
    value = path.read_bytes()
    packed = gzip.compress(value, mtime=0)
    destination = archive / (path.name + '.gz')
    assert not destination.exists()
    destination.write_bytes(packed)
    entries.append({'file': destination.name, 'rawSha256': hashlib.sha256(value).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(value), 'lines': len(value.splitlines())})
(archive / 'records.json').write_text(json.dumps({'entries': entries, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
plan = root / 'experiments/issue-1580/work-plan.md'
plan.write_text(plan.read_text() + '\n- Partition the retained 1,437-line gate summary into two 692-line readable outcome arrays and a 71-line index. Exact reassembly matches every original byte, including the initial exit-1 invocation, all 138 results and subsequent successful recheck; retain a hash-bound original gzip and unchanged historical warning inventory. Four archive/naming/size gates pass without changing thresholds. Broader warning and issue acceptance remain unfinished; no independent authorship credit.\n')
selected.extend([archive.relative_to(root).as_posix(), plan.relative_to(root).as_posix()])
run('stage-evidence', ['git', 'add', '--', *selected])
inputs = []
for relative in selected:
    path = root / relative
    inputs.extend(item.relative_to(root).as_posix() for item in sorted(path.rglob('*')) if item.is_file()) if path.is_dir() else inputs.append(relative)
run('secrets', ['bash', 'scripts/check-secrets.sh', *inputs])
run('whitespace', ['git', 'diff', '--cached', '--check'])
run('commit', ['git', 'commit', '-m', 'docs: partition retained gate outcomes with exact reconstruction proof'])
head = run('head', ['git', 'rev-parse', 'HEAD']).strip()
(out / 'outcome.json').write_text(json.dumps({'passed': True, 'head': head, 'completedAt': datetime.now(timezone.utc).isoformat(), 'pushExecuted': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
