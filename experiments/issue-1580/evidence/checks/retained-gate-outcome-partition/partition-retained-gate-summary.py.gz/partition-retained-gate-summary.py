from pathlib import Path
from collections import Counter
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/checks'
path = base / 'all-local-gates-fifth-summary.json'
original = path.read_bytes()
data = json.loads(original)
assert len(original.splitlines()) == 1437 and len(data['outcomes']) == 138
assert data['initialInvocation']['exitCode'] == 1
assert Counter(row['status'] for row in data['outcomes']) == {'PASS': 86, 'SKIP': 52}
parts = base / 'all-local-gates-fifth-outcomes'
parts.mkdir(exist_ok=False)
proof = []
for name, owner in [('initial', data['initialInvocation']), ('combined', data)]:
    value = (json.dumps(owner['outcomes'], indent=2) + '\n').encode()
    assert len(value.splitlines()) < 900
    filename = name + '.json'
    (parts / filename).write_bytes(value)
    owner['outcomes'] = {'file': parts.name + '/' + filename, 'sha256': hashlib.sha256(value).hexdigest(), 'entries': 138}
    proof.append({'file': filename, 'lines': len(value.splitlines()), 'entries': 138})
packed = gzip.compress(original, mtime=0)
(parts / 'original-summary.json.gz').write_bytes(packed)
data['partition'] = {'schema': 'issue-1580-retained-gate-outcomes/v1', 'originalFile': parts.name + '/original-summary.json.gz', 'originalSha256': hashlib.sha256(original).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(), 'originalBytes': len(original), 'originalLines': len(original.splitlines())}
path.write_text(json.dumps(data, indent=2) + '\n')
reconstructed = json.loads(path.read_text())
partition = reconstructed.pop('partition')
for owner in [reconstructed, reconstructed['initialInvocation']]:
    reference = owner['outcomes']
    raw = (base / reference['file']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == reference['sha256']
    value = json.loads(raw)
    assert len(value) == reference['entries']
    owner['outcomes'] = value
assert (json.dumps(reconstructed, indent=2) + '\n').encode() == original
assert gzip.decompress((base / partition['originalFile']).read_bytes()) == original
assert hashlib.sha256((base / partition['originalFile']).read_bytes()).hexdigest() == partition['archiveSha256']
assert hashlib.sha256(original).hexdigest() == partition['originalSha256']
document = root / 'docs/case-studies/issue-1580/README.md'
before = '`checks/all-local-gates-fifth-summary.json` preserves the initial exit 1 and every original outcome, the separate successful recheck, and hashes of the full gate/focused logs.'
after = '`checks/all-local-gates-fifth-summary.json` indexes the initial exit 1, the separate successful recheck and full log hashes. Its two linked readable outcome files preserve every initial and combined gate result; the compressed original and exact reconstruction proof preserve all original bytes.'
assert document.read_text().count(before) == 1
document.write_text(document.read_text().replace(before, after))
out = Path('/tmp/issue-1580-research/retained-gate-summary-partition')
out.mkdir(exist_ok=False)
result = {'originalLines': 1437, 'summaryLines': len(path.read_text().splitlines()), 'outcomeParts': proof, 'originalSha256': partition['originalSha256'], 'originalBytesExactlyReconstructed': True, 'allOriginalGateResultsPreserved': True, 'remainingSourceSizeWarningsUnresolved': True, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
(out / 'inverse-proof.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
