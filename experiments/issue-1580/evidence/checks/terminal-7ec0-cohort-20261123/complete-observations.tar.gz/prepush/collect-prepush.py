from pathlib import Path
import subprocess,gzip,json,datetime
r=Path('/tmp/issue-1580-research/prepush-hosted-7ec0-qualified');rows=[]
commands=[('fetch-main',['git','fetch','origin','main']),('published-pr-diff',['gh','pr','diff','1581','--repo','link-assistant/formal-ai','--color','never']),('pr-state',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','headRefOid,baseRefName,title,body,isDraft,mergeStateStatus,url']),('latest-runs',['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','5','--json','databaseId,workflowName,status,conclusion,createdAt,headSha'])]
for label,command in commands:
 p=subprocess.run(command,capture_output=True)
 for name,value in [('stdout',p.stdout),('stderr',p.stderr)]:(r/(label+'.'+name+'.gz')).write_bytes(gzip.compress(value,mtime=0))
 rows.append({'label':label,'command':command,'exitCode':p.returncode,'bytes':len(p.stdout),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 (r/'records.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
(r/'outcome.json').write_text(json.dumps({'complete':True,'records':rows},indent=2)+'\n')
