from pathlib import Path
import subprocess,gzip,json,datetime,os
r=Path('/tmp/issue-1580-research/7ec0-pipeline-log-recovery')
rows=[];env=os.environ.copy();env.pop('NODE_OPTIONS',None);env['GODEBUG']='http2client=0'
source=Path('/tmp/issue-1580-research/repair-batch-7ec0-head-ci/jobs-45218149963.stdout.gz')
pages=json.loads(gzip.decompress(source.read_bytes()))
jobs=[x for page in pages for x in page.get('jobs',[]) if x['conclusion']!='skipped']
for job in jobs:
 ident=job['id'];cmd=['gh','api','--allow-escape-sequences','repos/link-assistant/formal-ai/actions/jobs/'+str(ident)+'/logs']
 p=subprocess.run(cmd,capture_output=True,env=env)
 for n,b in [('stdout',p.stdout),('stderr',p.stderr)]:(r/(str(ident)+'.'+n+'.gz')).write_bytes(gzip.compress(b,mtime=0))
 row={'id':ident,'name':job['name'],'command':cmd,'exitCode':p.returncode,'bytes':len(p.stdout),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 rows.append(row);(r/'records.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if sum(x['exitCode']!=0 for x in rows)>=3:break
(r/'outcome.json').write_text(json.dumps({'complete':True,'jobsRequested':len(jobs),'collected':len(rows),'allAvailable':len(rows)==len(jobs) and all(x['exitCode']==0 for x in rows),'records':rows},indent=2)+'\n')
