from pathlib import Path
import subprocess,json,gzip,datetime
r=Path('/tmp/issue-1580-research/feedback-and-blockers-20261123-1721');records=[]
commands=[
 ('issue',['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','number,title,body,state,url,updatedAt']),
 ('issue-comments',['gh','api','repos/link-assistant/formal-ai/issues/1580/comments','--paginate','--slurp']),
 ('pr-comments',['gh','api','repos/link-assistant/formal-ai/issues/1581/comments','--paginate','--slurp']),
 ('pr-inline',['gh','api','repos/link-assistant/formal-ai/pulls/1581/comments','--paginate','--slurp']),
 ('pr-reviews',['gh','api','repos/link-assistant/formal-ai/pulls/1581/reviews','--paginate','--slurp']),
 ('subissues',['gh','api','repos/link-assistant/formal-ai/issues/1580/sub_issues','--paginate','--slurp']),
 ('pr',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','title,body,headRefOid,isDraft,baseRefName,url']),
 ('command-stream-upstream',['gh','api','repos/link-foundation/command-stream/pulls/240']),
 ('calculator-upstream',['gh','api','repos/link-assistant/calculator/issues/265']),
 ('hive-serving-identity',['gh','api','repos/link-assistant/hive-mind/issues/3909']),
 ('command-stream-registry',['curl','--fail','--silent','--show-error','https://crates.io/api/v1/crates/command-stream']),
 ('calculator-registry',['curl','--fail','--silent','--show-error','https://crates.io/api/v1/crates/link-calculator'])]
for label,cmd in commands:
 p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 for stream,value in [('stdout',p.stdout),('stderr',p.stderr)]:(r/(label+'.'+stream+'.gz')).write_bytes(gzip.compress(value,mtime=0))
 records.append({'label':label,'command':cmd,'exitCode':p.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()});(r/'records.json').write_text(json.dumps(records,indent=2)+'\n')
 print(label,p.returncode,flush=True)
(r/'outcome.json').write_text(json.dumps({'complete':True,'allPassed':all(x['exitCode']==0 for x in records),'records':records},indent=2)+'\n')
