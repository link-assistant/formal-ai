from pathlib import Path
import json, hashlib, subprocess

source = Path('/tmp/issue-1580-research/aggregate-review-current')
index = json.loads((source / 'index.json').read_text())
rows = []
for row in index['files']:
    if row.get('diff') not in {f'{i:04d}.diff' for i in range(53)}:
        continue
    path = row['path']
    original = (source / row['diff']).read_bytes()
    assert hashlib.sha256(original).hexdigest() == row['sha256']
    current = subprocess.check_output(['git', 'diff', 'origin/main...HEAD', '--', path])
    # The whole-export splitter removes the inter-file newline; Git's
    # single-file command includes it. Compare source text, retaining both hashes.
    changed = current.rstrip(b'\n') != original.rstrip(b'\n')
    if changed:
        assert path == '.github/workflows/workflows.yml'
    rows.append({
        'path': path,
        'completeDiffLiterallyRead': True,
        'sourceSha256': hashlib.sha256(Path(path).read_bytes()).hexdigest(),
        'diffSha256': hashlib.sha256(current).hexdigest(),
        'exportedDiffSha256': row['sha256'],
        'reviewMethod': 'Complete bounded reads; workflow audit source trigger delta reviewed after the exported diff.' if changed else 'Complete bounded reads of the exported diff; exporter separator newline normalized for identity comparison.',
    })
assert len(rows) == 53
out = Path('experiments/issue-1580/evidence/checks/production-diff-review-workflow-round')
out.mkdir(exist_ok=True)
receipt = {
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'base': index['base'],
    'reviewedProductionDiffs': rows,
    'findings': [
        'Workflow audit helper and regression paths were absent from push and pull_request filters. Commit d3aebbdc9 adds both, with a failing-before/passing-after assertion.',
        'Exact workflow source pinning, failed observations, immutable artifact identity, constrained runner acquisition, and existing native families remain represented in the reviewed workflow changes.',
    ],
    'wholePrReviewed': False,
    'allIssueRequirementsAccepted': False,
    'independentAuthorshipCredit': 0,
}
(out / 'review.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'reviewedDiffs':len(rows),'wholePrReviewed':False,'findings':receipt['findings']}, indent=2))
