from pathlib import Path
import json,re,hashlib,subprocess,os
root=Path.cwd();scratch=Path('/tmp/issue-1580-research');logs=scratch/'2809-hosted-checks/layered-all-jobs';fixture=root/'experiments/issue-1580/fixtures/hosted-javascript-2809ce65';fixture.mkdir(exist_ok=True)
jobs=json.loads((logs/'index.json').read_text());identity={'sourceCommit':'2809ce657a6216599252c929f436687652091302','run':44970848351,'runConclusion':'failure','modeledWorkers':4,'unobservedFallbackSeconds':1,'completeObservations':0,'jobs':[],'scope':'Completed file timings, including files from failed shards; completion is a timing observation and does not assert test success.'};observed=[]
for job in jobs:
 if 'suite group ' not in job['name']:continue
 raw=Path(job['log']).read_bytes();identity['jobs'].append({'job':job['name'],'id':job['job'],'conclusion':job['conclusion'],'logSha256':hashlib.sha256(raw).hexdigest()})
 for line in raw.decode().splitlines():
  match=re.search(r'\[test-file\] completed (\S+) (\{.*\})',line)
  if match:observed.append({'file':match[1],'seconds':json.loads(match[2])['duration_ms']/1000,'complete':True,'job':job['name']})
assert len(observed)==len({r['file'] for r in observed})==910
observed.sort(key=lambda r:r['file']);data=''.join(json.dumps(row,separators=(',',':'))+'\n' for row in observed)
(fixture/'durations.jsonl').write_text(data);identity.update(completeObservations=len(observed),durationsSha256=hashlib.sha256(data.encode()).hexdigest())
(fixture/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
test=root/'experiments/issue-1580/hosted-javascript-scheduling.test.mjs';source=test.read_text();assert 'complete current hosted costs' not in source
source+='''
test('complete current hosted costs fit the deployed eight-shard plan without discarding failed-shard observations', () => {
  const fixture = new URL('./fixtures/hosted-javascript-2809ce65/', import.meta.url);
  const identity = JSON.parse(readFileSync(new URL('identity.json', fixture), 'utf8'));
  const observations = readFileSync(new URL('durations.jsonl', fixture), 'utf8').trim().split('\\n').map(line => JSON.parse(line));
  assert.equal(observations.length, identity.completeObservations);
  assert.equal(new Set(observations.map(row => row.file)).size, observations.length);
  assert.equal(identity.runConclusion, 'failure');
  assert(observations.some(row => identity.jobs.find(job => job.job === row.job)?.conclusion === 'failure'));
  const recorded = readFileSync(new URL('../../data/meta/javascript-test-durations.lino', import.meta.url), 'utf8');
  const weights = parseTestDurations(recorded);
  const files = readdirSync(new URL('../../rust/tests/web/', import.meta.url)).filter(file => file.endsWith('.test.mjs')).map(file => 'rust/tests/web/' + file);
  const {shards} = planShards(files, 8, durationLookup(weights, Number(recorded.match(/^ {2}default-seconds (\\S+)$/mu)[1])));
  assert.deepEqual(partitionProblems(files, shards), {missing: [], repeated: [], extra: []});
  const costs = durationLookup(new Map(observations.map(row => [row.file, row.seconds])), identity.unobservedFallbackSeconds);
  for (const [index, shard] of shards.entries()) {
    const load = Array(identity.modeledWorkers).fill(0);
    for (const file of shard) {
      const worker = load.indexOf(Math.min(...load)); load[worker] += costs(file);
    }
    assert(Math.max(...load) <= 270, 'current measured shard ' + (index + 1) + ': ' + Math.max(...load));
  }
});
'''
test.write_text(source)
out=scratch/'current-hosted-headroom';out.mkdir(exist_ok=True)
with (out/'before.log').open('w') as f:r=subprocess.run(['node','--test','--test-concurrency=1','--test-name-pattern','complete current hosted costs',str(test.relative_to(root))],stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'})
print('Current measured headroom before repair',r.returncode)
(out/'before-exit.json').write_text(json.dumps({'exitCode':r.returncode,'authorshipCredit':0})+'\n')
assert r.returncode!=0,'Regression must reproduce current shard overrun before changing weights'
