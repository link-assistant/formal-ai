from pathlib import Path
import subprocess,json
out=Path('/tmp/issue-1580-research/native-grok-boundary-repair');out.mkdir(exist_ok=True)
for p,old,new in [
 ('rust/tests/integration/with_formal_ai.rs','vec!["--model", "formal-ai", "--prompt", "hi"],','vec!["--model", "formal-ai", "-p", "hi"],'),
 ('rust/tests/integration/with_formal_ai_argv.rs','vec!["--model", "formal-ai", "--verbose", "--prompt", "hi"],','vec!["--model", "formal-ai", "--verbose", "-p", "hi"],'),
]:
 path=Path(p);before=path.read_text();assert before.count(old)==1
 (out/(path.name+'.before')).write_text(before)
 path.write_text(before.replace(old,new))
p=Path('data/meta/core-boundary-ledger.lino');s=p.read_text();(out/(p.name+'.before')).write_text(s)
old='  source rust/src/solver_handlers/prompt_data.rs\n    disposition promote\n    baseline_lines 559\n';assert s.count(old)==1
s=s.replace(old,old.replace('559','563'))
assert s.count('  source_lines_max 37182\n')==1
s=s.replace('  source_lines_max 37182\n','  source_lines_max 37186\n')
note='  note "Issue #1580 restores typed text-operation ownership before generic prompt-data field extraction. The reusable parser guard adds four measured lines to the promoted prompt_data.rs interpreter (559 to 563); source_lines_max increases by four to 37186. Handler dispositions and outside-core ceilings are unchanged."\n'
s=s.replace('core_boundary_ledger\n','core_boundary_ledger\n'+note,1);p.write_text(s)
print('REPAIRED two stale native Grok vectors and measured four-line interpreter census')
for command in [['rg','--files','rust/tests','js','experiments'],['git','log','-5','--oneline','-G','prompt_arg.*-p','--','data/seed/client-integrations.lino']]:
 r=subprocess.run(command,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 print('COMMAND',command,'EXIT',r.returncode)
 print('\n'.join(x for x in r.stdout.splitlines() if any(v in x.lower() for v in ['with-formal','with_formal','client-integration','grok'])) if command[0]=='rg' else r.stdout)
print(json.dumps({'authorshipCredit':0,'nativeExecution':'pending hosted CI; no local Rust compilation','semanticAssertionsRemoved':0}))
