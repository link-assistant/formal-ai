from pathlib import Path
import subprocess,os
out=Path('/tmp/issue-1580-research/layered-source-repair')
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'}
for name,command in [('typescript-regeneration',['node','scripts/translate-es.mjs','--write']),('typescript-full-projection',['node','scripts/translate-es.mjs','--check']),('typescript-registry-recheck',['node','--test','--test-concurrency=1','rust/tests/web/typescript-runtime.test.mjs'])]:
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=env)
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
print('All maintained TypeScript twins regenerated through the real translator.')
