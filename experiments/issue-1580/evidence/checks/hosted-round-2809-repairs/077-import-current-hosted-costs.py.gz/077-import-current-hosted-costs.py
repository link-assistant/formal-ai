from pathlib import Path
import subprocess,os,json
path=Path('experiments/issue-1580/import-hosted-javascript-costs.mjs');source=path.read_text()
source=source.replace("import {readFileSync, writeFileSync} from 'node:fs';","import {readFileSync, writeFileSync} from 'node:fs';\nimport {createHash} from 'node:crypto';")
needle="if (process.argv.includes('--write')) writeFileSync(path, after);"
assert source.count(needle)==1
source=source.replace(needle,"""// Preserve the older complete cohort and conservative split-scenario bounds.
// New completed timings can raise weights; a faster PR never lowers main bounds.
const currentFixture = new URL('./fixtures/hosted-javascript-2809ce65/', import.meta.url);
const currentIdentity = JSON.parse(readFileSync(new URL('identity.json', currentFixture), 'utf8'));
const currentRaw = readFileSync(new URL('durations.jsonl', currentFixture), 'utf8');
if (createHash('sha256').update(currentRaw).digest('hex') !== currentIdentity.durationsSha256) throw Error('HostedCostCaptureDigestMismatch');
const currentRows = currentRaw.trim().split('\\n').map(line => JSON.parse(line));
if (currentRows.length !== currentIdentity.completeObservations || currentRows.some(row => !row.complete || !currentIdentity.jobs.some(job => job.job === row.job))
  || new Set(currentRows.map(row => row.file)).size !== currentRows.length) throw Error('IncompleteCurrentHostedCostObservations');
after = mergeJavaScriptDurations(after, new Map(currentRows.map(({file, seconds, complete}) => [file, {seconds, complete}])),
  {...options, source: String(currentIdentity.run)});
"""+needle)
path.write_text(source)
out=Path('/tmp/issue-1580-research/current-hosted-headroom')
commands=[('import',['node',str(path),'--write']),('import-currency',['node',str(path)]),('after',['node','--test','--test-concurrency=1','experiments/issue-1580/hosted-javascript-scheduling.test.mjs','experiments/issue-1580/provenance-scenario-partition.test.mjs'])]
rows=[]
for name,argv in commands:
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'})
 rows.append({'name':name,'exitCode':r.returncode});print(name,r.returncode)
 assert r.returncode==0,name
(out/'outcome.json').write_text(json.dumps({'passed':True,'checks':rows,'retainedBeforeFailure':True,'authorshipCredit':0},indent=2)+'\n')
