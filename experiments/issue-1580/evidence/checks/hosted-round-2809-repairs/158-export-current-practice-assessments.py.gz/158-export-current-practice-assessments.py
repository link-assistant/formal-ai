from pathlib import Path
import json,textwrap
rows=json.loads(Path('docs/case-studies/issue-1580/templates/rust-source-review-progress.json').read_text())['practiceDecisions']
out=Path('/tmp/issue-1580-research/current-practice-assessments.txt')
lines=[]
for n,row in enumerate(rows,1):
 lines.append(f'PRACTICE {n}: '+row['practice'])
 for key,value in row.items():
  if key=='practice':continue
  text=value if isinstance(value,str) else json.dumps(value,ensure_ascii=False)
  lines+=textwrap.wrap(key+': '+text,width=110,subsequent_indent='  ')
 lines.append('')
out.write_text('\n'.join(lines)+'\n')
print('Exported',len(rows),'dated assessments;',len(lines),'bounded lines;',out)
