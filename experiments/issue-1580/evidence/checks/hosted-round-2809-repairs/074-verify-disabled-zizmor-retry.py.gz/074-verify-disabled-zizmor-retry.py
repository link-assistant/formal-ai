from pathlib import Path
import subprocess,json,os
out=Path('/tmp/issue-1580-research/zizmor-transport-checks')
source=Path('scripts/run-zizmor.mjs').read_text();old='if (!advisoryTransportFailure(result) || attempt === 2)';assert source.count(old)==1
module=out/'disabled-retry.mjs';module.write_text(source.replace(old,'if (true || attempt === 2)'))
test=Path('experiments/issue-1580/zizmor-disabled-retry-control.test.mjs');assert not test.exists()
original=Path('experiments/issue-1580/zizmor-transport.test.mjs').read_text()
test.write_text(original.replace("'../../scripts/run-zizmor.mjs'",repr(module.as_uri())))
(out/'disabled-retry-control.test.mjs').write_text(test.read_text())
try:
 with (out/'disabled-retry-negative-control.log').open('w') as f:r=subprocess.run(['node','--test','--test-concurrency=1',str(test)],stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'})
 assert r.returncode==1
 log=(out/'disabled-retry-negative-control.log').read_text();assert '# fail 2' in log and '# pass 4' in log,log
 (out/'disabled-retry-negative-control.json').write_text(json.dumps({'exitCode':r.returncode,'expectedFailedRetryCases':2,'unchangedControlsPassed':4,'authorshipCredit':0},indent=2)+'\n')
 print('NEGATIVE CONTROL: disabled retry fails both actual recovery cases; four unrelated controls still pass')
finally:test.unlink()
