from pathlib import Path
import json,gzip,hashlib,subprocess
scratch=Path('/tmp/issue-1580-research');dest=Path('experiments/issue-1580/evidence/checks/hosted-round-2809-repairs');dest.mkdir(parents=True,exist_ok=True)
assert not (dest/'manifest.json').exists()
items=[]
def retain(p,label):
 data=p.read_bytes();packed=gzip.compress(data,mtime=0);name=f'{len(items)+1:03d}-'+p.name+'.gz';(dest/name).write_bytes(packed)
 items.append({'file':name,'source':label,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'compressedSha256':hashlib.sha256(packed).hexdigest()})
for directory in ['zizmor-transport-checks','layered-source-repair','shared-runner-pagination-checks','current-hosted-headroom','native-grok-boundary-repair','2809-repair-full-validation']:
 for p in sorted((scratch/directory).glob('*')):
  if p.is_file() and p.suffix in ['.log','.json','.md','.before','.py','.mjs']:retain(p,directory+'/'+p.name)
for name in ['check-minimal-core-boundary.log','check-minimal-core-boundary-js-twin.log','check-worker-line-budget.log','check-worker-line-budget-js-twin.log']:
 p=scratch/'2809-repair-full-validation/gate-logs'/name;retain(p,'2809-repair-full-validation/gate-logs/'+name)
for name in ['repair-grok-fixtures-and-boundary.py','preserve-worker-cap-and-verify.py','verify-disabled-zizmor-retry.py','complete-javascript-cpp-file-applicability-maps.py','regenerate-all-affected-typescript-twins.py','import-current-hosted-costs.py','add-current-hosted-cost-regression.py','verify-shared-template-runner-pagination.py','report-shared-runner-pagination-final.py','retain-current-local-repair-evidence.py']:
 p=scratch/name
 if p.exists():retain(p,'procedure/'+name)
(dest/'manifest.json').write_text(json.dumps({'baseHead':'2809ce657a6216599252c929f436687652091302','hostedQualification':'pending repaired source','allIssueRequirementsAccepted':False,'autonomousAuthorshipCredit':0,'localRustCompilation':False,'files':items},indent=2)+'\n')
doc='''# Repairs from hosted source 2809ce65

The current published source is `2809ce657a6216599252c929f436687652091302`.
These are repairs drafted against its real completed jobs, not a claim that
the repaired source has passed hosted execution.

## Workflow scanning

[Workflows run 44970848479](https://github.com/link-assistant/formal-ai/actions/runs/44970848479)
reached Zizmor's online advisory audit and failed before any pedantic audit
completed: complete-log lines 3204–3212 contain the fatal no-audit result and
GitHub advisory request transport error. The regular audit succeeded.
The pinned Docker helper retries only that captured transport class, at most
three complete audits, and retains every diagnostic. Both security personas,
confidence/severity policies, online checks, live workflow/action scope and
failure exit statuses are preserved. Six controls pass; disabling retry makes
both recovery controls fail while four unrelated controls still pass.
See [the transport analysis](zizmor-advisory-transport.md).

The same completed log warned about YAML aliases at line 3081 and implicit
macOS shells at lines 3091 and 3123. Expanding both identical CodeQL environment
and step lists preserves the complete parsed before/after workflow value.
The dynamic macOS job now declares its actual bash shell.

## Layered JavaScript failures and timing

[Layered run 44970848351](https://github.com/link-assistant/formal-ai/actions/runs/44970848351)
failed group 8 on the original R294 URL-extraction ownership test (job log
lines 2651–2668) and the quantity-response consumer (2671–2695). Generic
prompt-data extraction had captured the colon in a URL belonging to a typed
text operation. Both JavaScript and Rust now consult the existing typed parser
before generic field extraction; no request vocabulary or outer priority list
is added. The existing reproducer fails before and passes after. Prompt-data
coverage still passes. The worker remains at its existing 279-line ceiling;
the measured Rust interpreter gains four lines, explicitly recorded in its
promoted-core census without changing dispositions or outside-core ceilings.

The quantity consumer now reads the actual conserved response owner after the
seed split, retaining every original five-language assertion. Group 6's
TypeScript-runtime failure (lines 3095–3140) exposed stale generated seed
registrations. The maintained whole-tree translator regenerates all three
affected twins, and its currency check and TypeScript runtime test pass.

Group 5 also crossed its unchanged 270-second warning threshold at log line
1806. All eight actual job logs provide 910 complete unique file timings,
including files from failed groups. A replay of the actual eight-shard,
four-worker plan fails before import at 274.032497046 seconds. The maintained
raise-only cost merger imports the complete content-addressed cohort; the
same replay then passes. Faster PR results never reduce conservative main
weights. All three newly separated provenance scenarios really completed:
85.444476131, 85.312615276 and 70.760105652 seconds. Their conservative inherited
316-second scheduling bounds remain explicitly labeled bounds. These observed
file costs and a passing scheduling model do not substitute for a future
hosted group execution under the new plan.

## Native interfaces

[Native interfaces job 137051666550](https://github.com/link-assistant/formal-ai/actions/runs/44970848731/job/137051666550)
completed 76 tests and failed two exact Grok argument comparisons: raw job-log
lines 822–855 and 863–896. The supported Grok Build integration changed its
declared prompt argument to `-p` in `4a6fe0e6c`; both native test vectors still
expected `--prompt`. Updating those two vectors preserves the exact interactive,
argument and piped-prompt assertions for all clients. Rust formatting passes;
the native behavior assertions must execute on the repaired hosted source.
No local Rust compilation or native test execution is claimed.

## Shared template findings and complete maps

The actual pinned C++ helper fetches only the first 100 check annotations;
the actual C# helper fetches only the default first 30. A runner-acquisition
marker at annotation 101 is missed by both, and one at annotation 31 is missed
by C#. Maintained finite replays import the original licensed source and its
actual dependency, then exercise isolated pagination candidates. Original
first-page controls, marker absence and genuine code failures remain exact.
Three tests pass; disabling candidate pagination makes both behavioral tests
fail. No actual workflow rerun is requested by the reproduction.

The reproduced defects are reported with pins, hashes and the complete finite
recipe in [C++ template issue 41](https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/issues/41)
and [C# template issue 114](https://github.com/link-foundation/csharp-ai-driven-development-pipeline-template/issues/114).
Formal AI's existing helper already paginates these annotations; this finding
does not justify weakening failed-code classification or claiming an upstream
fix has landed.

The last JavaScript (566 files) and C++ (552 files) applicability maps complete
the per-file inventories for all eight pinned template trees. Each file carries
its exact blob/content identity, observed structure or literal review method,
Formal AI counterparts and applicability decision. Active workflow scripts
and transitive helpers receive explicit comparisons; binary/history records
are not mislabeled as current executed practices. All eight complete maps
exist. Their runtime-qualification fields deliberately remain false until
the corresponding acceptance evidence is complete.

## Verification state

The maintained issue entry passes. The first complete local inventory executed
all 141 entries and found four real draft failures: both boundary twins and
both worker-line-budget twins. The boundary census and unchanged worker ceiling
are repaired; their focused checks pass. That failed full-inventory result is
retained as failed, alongside successful JavaScript/native-source and TypeScript
projection checks. Final full-inventory execution after these repairs remains
pending. All supplied procedures receive zero autonomous-authorship credit.
Original strict acceptance, final hosted qualification, whole-PR review and
the genuine independent-authorship requirement remain unfinished.

Evidence: `experiments/issue-1580/evidence/checks/hosted-round-2809-repairs/`.
Pull request: https://github.com/link-assistant/formal-ai/pull/1581.
'''
Path('docs/case-studies/issue-1580/hosted-round-2809-repairs.md').write_text(doc)
p=Path('experiments/issue-1580/work-plan.md')
with p.open('a') as f:f.write('''

### 2026-11-22: current hosted-source failure batch

- [x] Reproduce current Zizmor advisory transport failure; preserve complete online auditing and fail-closed controls. Remove actual YAML-alias and dynamic-shell warnings with parsed behavior conservation.
- [x] Reproduce and repair typed text-operation ownership in both roots, moved quantity-response consumption and all stale generated TypeScript registrations.
- [x] Capture all 910 complete current file timings and reproduce the actual overloaded shard before raise-only import. Retain original budgets, all eight shards and conservative inherited bounds; record the three actual provenance-scenario timings.
- [x] Reproduce actual pinned C++/C# annotation pagination misses, retain licensed sources and negative controls, and publish verified upstream reports (C++ #41, C# #114).
- [x] Complete exact per-file applicability maps for all eight pinned template trees. Runtime/practice acceptance is a separate unfinished criterion.
- [x] Identify both stale native Grok vectors from the real interface failure; update only those exact expectations, and measure the four-line promoted-interpreter change. Preserve the JavaScript worker ceiling.
- [ ] Collect every terminal current-head workflow and annotation, address any remaining failures, and complete the final full local gate inventory before one coordinated push.
- [ ] Qualify all repaired hosted paths, finish original strict/practice acceptance and genuine authorship, review the whole PR, merge current main and mark ready only when complete.

Evidence: [current hosted-source repairs](../../docs/case-studies/issue-1580/hosted-round-2809-repairs.md).
''')
print('Retained',len(items),'local evidence streams; manifest bytes',(dest/'manifest.json').stat().st_size)
