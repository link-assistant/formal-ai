from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile,io

scratch=Path('/tmp/issue-1580-research')
final=scratch/'2809-synchronized-seed-validation/outcome.json'
assert final.exists(), 'Wait for the running full gate inventory before sealing evidence.'
result=json.loads(final.read_text())
assert result['complete'] and result['passed'], result
dest=Path('experiments/issue-1580/evidence/checks/hosted-round-2809-repairs')
manifest=json.loads((dest/'manifest.json').read_text())
items=manifest['files']
known={row['source'] for row in items}

def retain(data,source,name):
 if source in known:return
 packed=gzip.compress(data,mtime=0)
 filename=f'{len(items)+1:03d}-{name}.gz'
 assert not (dest/filename).exists()
 (dest/filename).write_bytes(packed)
 items.append({'file':filename,'source':source,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'compressedSha256':hashlib.sha256(packed).hexdigest()})
 known.add(source)

directories=[
 '2809-repair-full-validation','2809-repair-final-validation','2809-final-gate-repairs',
 '2809-combined-final-validation','2809-mirrored-seed-validation',
 '2809-synchronized-seed-validation','canonical-terminal-projection-sync',
 'environment-command-routing','workflow-audit-source-triggers',
]
for directory in directories:
 root=scratch/directory
 for path in sorted(root.iterdir()):
  if path.is_file():retain(path.read_bytes(),directory+'/'+path.name,path.name)
 gates=root/'gate-logs'
 if gates.exists():
  # One deterministic archive keeps complete per-gate streams without adding
  # hundreds of separate evidence paths or altering any original bytes.
  stream=io.BytesIO()
  with tarfile.open(fileobj=stream,mode='w') as bundle:
   for path in sorted(gates.rglob('*')):
    if not path.is_file():continue
    data=path.read_bytes();entry=tarfile.TarInfo(str(path.relative_to(gates)))
    entry.size=len(data);entry.mtime=0;entry.mode=0o644
    bundle.addfile(entry,io.BytesIO(data))
  retain(stream.getvalue(),directory+'/complete-gate-streams.tar',directory+'-complete-gate-streams.tar')

procedures=[
 'run-combined-final-validation.py','run-mirrored-seed-validation.py',
 'run-synchronized-seed-validation.py','synchronize-canonical-terminal-projections.py',
 'repair-workflow-audit-source-triggers.py','finish-current-repair-evidence.py',
 'record-current-workflow-review.py','record-current-workflow-review-driver.log',
 'record-current-workflow-review-final-driver.log',
 'current-practice-assessments.txt','export-current-practice-assessments.py',
 'read-terminal-seed-drift-source-driver.log',
]
for name in procedures:
 path=scratch/name
 if path.exists():retain(path.read_bytes(),'procedure/'+name,name)
failed_precondition=scratch/'reviewed-repair-publication/failed-mirrored-source-precondition.log'
if failed_precondition.exists():
 retain(failed_precondition.read_bytes(),'procedure/failed-mirrored-source-precondition.log','failed-mirrored-source-precondition.log')
manifest.update({
 'finalLocalValidation':result,
 'maintainedIssueEntryPassedTests':362,
 'fullGateInventory':{'entries':141,'passed':88,'explicitHostedOnlySkips':53,'failed':0},
 'localRustCompilation':False,
 'allIssueRequirementsAccepted':False,
 'autonomousAuthorshipCredit':0,
})
text=(scratch/'2809-synchronized-seed-validation/all-local-gates.log').read_text()
assert sum(line.startswith('PASS ') for line in text.splitlines())==88
assert sum(line.startswith('SKIP ') for line in text.splitlines())==53
assert not any(line.startswith('FAIL ') for line in text.splitlines())
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')

doc=Path('docs/case-studies/issue-1580/hosted-round-2809-repairs.md')
with doc.open('a') as handle:handle.write('''

## Final local replay and review corrections

The final maintained issue entry passes all 362 observations. Successive full
141-entry local inventories exposed real draft errors and remain archived as
failures: four boundary/worker-budget failures, two evidence-name/status failures,
then two embedded-package mirror failures and one ignored browser-seed drift.
The official package-data generator repairs the embedded mirror; the official
seed synchronizer refreshes the ignored browser deployment copy from the
already-correct canonical source. The final whole inventory passes
all 88 JavaScript gates, with 53 explicit hosted-only exclusions and no failures.
Both source-projection checks and whitespace checks also pass. Every original
per-gate stream is retained in deterministic archives; no Rust build is run.

A natural explicit shell request previously routed to web search because its
environment-prefixed command was not admitted by the generic shell-token
classifier. The shared seed now recognizes the environment command; its
official embedded-package mirror is regenerated. The corrected exact-request
regression fails two controls before the repair and passes all three afterward.
The unchanged original request then actually executes through the maintained
Formal AI wrapper. A preliminary test using the wrong tool-property name and
an insufficient request is retained as failed, without reproducer credit.
This supplied repair and retry receive zero autonomous-authorship credit.

Complete bounded reading of all changed workflow diffs found an additional
regression: changing the new online-audit helper or its test would not trigger
the workflow. Both push and pull-request path filters now include those files.
The new assertion fails against the prior workflow, then all six focused
Zizmor controls pass. The review receipt binds the 53 reviewed workflow/config
diffs and source bytes; it makes no whole-PR review claim. The receipt controller
first compared an export separator newline literally, then corrected that
comparison while retaining both original and current diff hashes.

Main `82e506f5447cd6c0b96095993107d6d028a890f5` remains an ancestor of the
prepared source. The complete current-head workflow round was collected before
publication; no active or queued run is superseded. A fresh hosted run must
still qualify the repaired native interfaces, genre module, online audit and
JavaScript schedule. Original strict/practice acceptance, genuine independent
authorship and complete aggregate review remain unfinished. The PR stays draft
and unmerged. The independent reasoning target remains 0/20 and is distinct
from the CONTRIBUTING.md 20% real authored-leaf requirement.
''')
work=Path('experiments/issue-1580/work-plan.md')
text=work.read_text()
start=text.index('## Current verification checkpoint\n\n')+len('## Current verification checkpoint\n\n')
end=text.index('The entries below are retained historical observations',start)
text=text[:start]+'''Published `2809ce657a6216599252c929f436687652091302` has 33 terminal workflows:
29 succeed, three fail and one skips. All 163 checks and 30 annotations are
preserved with complete original workflow logs and hashes. The collected failures
and actionable warnings have concrete local repairs; fresh hosted execution of
the repaired source remains pending. Main `82e506f54` (v0.356.3) is merged.

All 362 maintained issue observations pass. After retaining and repairing the
intermediate failed inventories, the final full local inventory has 88 passing
JavaScript gates and 53 explicit hosted-only exclusions. Native-source and
TypeScript projection checks pass. No local Rust compilation or native execution
is claimed. The official terminal-seed package and ignored browser mirrors are
current; both before/after command-routing and workflow-trigger controls pass.

All eight pinned template trees have complete per-file applicability maps.
Applicable-practice/runtime qualification, original strict acceptance and complete
aggregate review remain unfinished. The 53 reviewed workflow/configuration diffs
have exact source and diff hashes; this is not whole-PR review. Genuine independent
authorship remains zero against the CONTRIBUTING.md 20% authored-leaf requirement.
The independent reasoning target remains 0/20. PR #1581 stays draft and unmerged.

Latest evidence: [collected hosted-source repairs](../../docs/case-studies/issue-1580/hosted-round-2809-repairs.md).

'''+text[end:]
needle='- [ ] Collect every terminal current-head workflow and annotation, address any remaining failures, and complete the final full local gate inventory before one coordinated push.'
assert needle in text
text=text.replace(needle,'- [x] Collect all 33 terminal current-head workflows, 163 checks and 30 annotations; address their actionable failures and warnings. Final maintained entry: 362 passes. Final local inventory: 88 passes and 53 explicit hosted-only exclusions; no local Rust compilation.')
text+='''

### 2026-11-22: final local validation of the collected hosted round

- [x] Retain every failed intermediate full inventory, correct the official embedded terminal-seed mirror, and finish all 141 final local gate entries successfully or with explicit hosted-only exclusions.
- [x] Reproduce the environment-command routing gap, improve the shared generic classifier, regenerate its package mirror and execute the unchanged original request. All three regression controls pass; supplied authorship credit remains zero.
- [x] Read the complete 53 changed workflow/configuration diffs, repair the newly discovered audit-source trigger omission and prove the added assertion fails before and all six controls pass afterward. Preserve exact source/diff hashes and an explicit incomplete aggregate-review boundary.
- [ ] Qualify this source with all fresh hosted checks and finish the original strict/practice acceptance, complete aggregate review and genuine independent-authorship floor. Keep the PR draft and unmerged until verified.
'''
work.write_text(text)
print(json.dumps({'retainedStreams':len(items),'finalLocalPassed':True,'issueComplete':False,'suppliedAuthorshipCredit':0},indent=2))
