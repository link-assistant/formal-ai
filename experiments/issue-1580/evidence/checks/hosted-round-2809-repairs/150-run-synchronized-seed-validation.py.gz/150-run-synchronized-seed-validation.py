from pathlib import Path
import subprocess,json,os,time,shutil
out=Path('/tmp/issue-1580-research/2809-synchronized-seed-validation');out.mkdir(exist_ok=True)
previous=Path('/tmp/issue-1580-research/canonical-terminal-projection-sync/outcome.json')
while not previous.exists():time.sleep(2)
assert json.loads(previous.read_text())['passed']
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','SECRETLINT_VERSION':'14.0.0','CARGO_BUILD_JOBS':'1'}
env['PATH']='/tmp/issue-1580-research/secretlint-built-in-migration/dependencies/node_modules/.bin:'+env['PATH']
commands=[
 ('seed-sync',['bash','scripts/sync-seed.sh','--check']),
 ('all-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs']),
 ('native-source-projection',['node','scripts/translate-js-rust.mjs','--verify']),
 ('typescript-projection',['node','scripts/translate-es.mjs','--check']),
 ('whitespace',['git','diff','--check'])]
rows=[]
for name,command in commands:
 started=time.monotonic();p=out/(name+'.log')
 with p.open('w') as f:result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=env)
 row={'name':name,'command':command,'exitCode':result.returncode,'seconds':round(time.monotonic()-started,3),'log':str(p)};rows.append(row)
 (out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if name=='all-local-gates':shutil.copytree('experiments/formal_ai_subagent/sandboxes/gates',out/'gate-logs',dirs_exist_ok=True)
 if result.returncode!=0 and name!='all-local-gates':break
(out/'outcome.json').write_text(json.dumps({'complete':True,'passed':all(x['exitCode']==0 for x in rows),'checks':rows,'maintainedIssueEntryPreviouslyPassedTests':362,'independentAuthorshipCredit':0},indent=2)+'\n')
