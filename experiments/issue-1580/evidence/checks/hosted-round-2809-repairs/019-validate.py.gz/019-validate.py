from pathlib import Path
import subprocess,json,os,time
out=Path('/tmp/issue-1580-research/layered-source-repair')
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','CARGO_BUILD_JOBS':'1'}
commands=[('native-format',['rustfmt','--edition','2024','--check','rust/src/solver_handlers/prompt_data.rs'])]
for name,file in [('text-ownership','rust/tests/web/issue-0408-text-edit-parity.test.mjs'),('quantity-consumer','rust/tests/web/quantity-aggregate-comparison.test.mjs'),('typescript-registry','rust/tests/web/typescript-runtime.test.mjs'),('seed-consumers','rust/tests/web/seed-and-workflow-headroom.test.mjs'),('prompt-data','rust/tests/web/issue-1593-prompt-data.test.mjs'),('zizmor','experiments/issue-1580/zizmor-transport.test.mjs'),('workflow-policy','rust/tests/web/default-branch-build-policy.test.mjs'),('worker-currency','experiments/issue-1580/local-worker-currency.test.mjs')]:
 commands.append((name,['node','--test','--test-concurrency=1',file]))
rows=[]
for name,command in commands:
 started=time.monotonic();p=out/(name+'-after.log')
 with p.open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=env)
 rows.append({'name':name,'command':command,'exitCode':r.returncode,'seconds':round(time.monotonic()-started,3),'log':str(p)})
 (out/'validation-progress.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,r.returncode,rows[-1]['seconds'],flush=True)
(out/'validation-outcome.json').write_text(json.dumps({'complete':True,'passed':all(x['exitCode']==0 for x in rows),'checks':rows},indent=2)+'\n')
