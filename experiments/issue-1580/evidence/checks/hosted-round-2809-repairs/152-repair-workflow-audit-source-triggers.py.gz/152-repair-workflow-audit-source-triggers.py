from pathlib import Path
import subprocess,json,os,time
out=Path('/tmp/issue-1580-research/workflow-audit-source-triggers');out.mkdir(exist_ok=False)
test=Path('experiments/issue-1580/zizmor-transport.test.mjs')
source=test.read_text();needle="  const job = workflow.jobs.zizmor;"
assert source.count(needle)==1
replacement="""  for (const event of ['push', 'pull_request']) {
    for (const path of ['scripts/run-zizmor.mjs', 'experiments/issue-1580/zizmor-transport.test.mjs']) {
      assert(workflow.on[event].paths.includes(path), `${event} must audit changes to ${path}`);
    }
  }
  const job = workflow.jobs.zizmor;"""
test.write_text(source.replace(needle,replacement))
command=['node','--test','--test-concurrency=1',str(test)];env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'}
with (out/'before.log').open('w') as log:before=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
assert before.returncode==1
assert 'push must audit changes to scripts/run-zizmor.mjs' in (out/'before.log').read_text()
workflow=Path('.github/workflows/workflows.yml');source=workflow.read_text()
needle="'scripts/documentation-policy-dependencies/**']";assert source.count(needle)==2
workflow.write_text(source.replace(needle,"'scripts/documentation-policy-dependencies/**', 'scripts/run-zizmor.mjs', 'experiments/issue-1580/zizmor-transport.test.mjs']"))
with (out/'after.log').open('w') as log:after=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
assert after.returncode==0
(out/'outcome.json').write_text(json.dumps({'beforeExit':before.returncode,'afterExit':after.returncode,'tests':6,'allSourcePathsTriggerOnlineAudit':True,'independentAuthorshipCredit':0},indent=2)+'\n')
print((out/'outcome.json').read_text())
