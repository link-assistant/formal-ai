from pathlib import Path
import subprocess,json,os,time,shutil
out=Path('/tmp/issue-1580-research/2809-mirrored-seed-validation')
out.mkdir(exist_ok=True)
previous=Path('/tmp/issue-1580-research/2809-combined-final-validation/outcome.json')
while not previous.exists():time.sleep(2)
assert json.loads(previous.read_text())['complete']
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','SECRETLINT_VERSION':'14.0.0','CARGO_BUILD_JOBS':'1'}
env['PATH']='/tmp/issue-1580-research/secretlint-built-in-migration/dependencies/node_modules/.bin:'+env['PATH']
commands=[
 ('regenerate-package-data',['node','scripts/mirror-package-data.mjs','--write']),
 ('check-package-data',['node','scripts/mirror-package-data.mjs','--check']),
 ('environment-command-regression',['node','--test','--test-concurrency=1','experiments/issue-1580/environment-command-routing.test.mjs']),
 ('all-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs']),
 ('native-source-projection',['node','scripts/translate-js-rust.mjs','--verify']),
 ('typescript-projection',['node','scripts/translate-es.mjs','--check']),
 ('whitespace',['git','diff','--check'])]
rows=[]
for name,command in commands:
 started=time.monotonic();p=out/(name+'.log')
 with p.open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=env)
 row={'name':name,'command':command,'exitCode':r.returncode,'seconds':round(time.monotonic()-started,3),'log':str(p)};rows.append(row)
 (out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if name=='all-local-gates':shutil.copytree('experiments/formal_ai_subagent/sandboxes/gates',out/'gate-logs',dirs_exist_ok=True)
 if r.returncode!=0 and name!='all-local-gates':break
(out/'outcome.json').write_text(json.dumps({'complete':True,'passed':all(x['exitCode']==0 for x in rows),'checks':rows,'maintainedIssueEntryPreviouslyPassedTests':362,'independentAuthorshipCredit':0},indent=2)+'\n')
