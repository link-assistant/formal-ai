A runner-loss annotation beyond the first API page is silently ignored by the current recovery classifier. This was found while comparing the complete templates for https://github.com/link-assistant/formal-ai/pull/1581.

Pinned source: [scripts/unacquired_jobs.py](https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/blob/45c42aff119b366ba103a9342ec3c33731bb7e2e/scripts/unacquired_jobs.py), commit `45c42aff119b366ba103a9342ec3c33731bb7e2e`. I reviewed PR #20, including its conversation, inline comments and reviews, before filing this follow-up.

## Reproduction

Use a finite check run with 101 annotations and put `The job was not acquired by Runner of type hosted even after multiple attempts` at zero-based index 100. The job has an empty runner name, no steps, and a cancelled conclusion. The current helper reads only the first 100 annotations and fails to identify the unacquired job. The jobs-list pagination does not paginate this separate annotations endpoint.

The maintained offline reproduction executes the exact, hash-verified upstream helper, with an API fake that honors the requested page size and pagination. It also executes an isolated candidate repair against the same cases:

```
node --test --test-concurrency=1 experiments/issue-1580/template-shared-runner-pagination.test.mjs
```

Files and immutable-source manifest: https://github.com/link-assistant/formal-ai/tree/issue-1580-8d61a32a61e1/experiments/issue-1580/fixtures/shared-runner-pagination . The test and companion `cpp-runner-annotation-replay.py` are in the parent directory. These files are being prepared in the linked draft PR and will be published with its next complete CI repair batch.

## Actual and expected behavior

The original helper detects markers on its first page, but misses the marker at index 100. The candidate paginates annotations before classifying the job and detects it. Controls cover markers at indices 0, 29, 30 and 100, absence of the marker, and an actual test failure with executed steps. Genuine code failures stay excluded. Reverting only the candidate pagination makes the regression fail again.

Please paginate the annotations endpoint as well as the jobs endpoint, retaining the existing strict runner/steps/annotation filter, attempt bound and superseded-run protections. Do not reinterpret a transport or pagination failure as an empty, successful observation.

This report used bounded offline fixtures only. No workflow reruns or GitHub POST requests were issued by the reproduction. The candidate is a local proof, not a claim that the upstream implementation has already been repaired.
