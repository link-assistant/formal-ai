from pathlib import Path
import subprocess,json,os,time
out=Path('/tmp/issue-1580-research/canonical-terminal-projection-sync');out.mkdir(exist_ok=True)
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','CARGO_BUILD_JOBS':'1'}
commands=[
 ('sync',['bash','scripts/sync-seed.sh']),
 ('sync-check',['bash','scripts/sync-seed.sh','--check']),
 ('terminal-vocabulary',['node','experiments/issue-513-sync-worker-terminal.mjs','--check']),
 ('package-mirror',['node','scripts/mirror-package-data.mjs','--check']),
 ('command-regression',['node','--test','--test-concurrency=1','experiments/issue-1580/environment-command-routing.test.mjs']),
 ('working-tree',['git','status','--short']),
]
rows=[]
for name,command in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 rows.append({'name':name,'exitCode':result.returncode,'seconds':round(time.monotonic()-start,3)})
 if result.returncode:break
(out/'outcome.json').write_text(json.dumps({'complete':True,'passed':all(row['exitCode']==0 for row in rows),'checks':rows,'canonicalSourceAlreadyCommitted':True,'ignoredBrowserDeploymentCopyWasStale':True,'independentAuthorshipCredit':0},indent=2)+'\n')
print((out/'outcome.json').read_text())
