from pathlib import Path
import gzip,hashlib,json
p=Path('docs/case-studies/issue-1580/hosted-round-2809-repairs.md')
text=p.read_text(); marker='\n\n## Final local replay and review corrections\n'
parts=text.split(marker)
assert len(parts)==3,len(parts)
assert parts[1]==parts[2]
p.write_text(parts[0]+marker+parts[1])
root=Path('experiments/issue-1580/evidence/checks/hosted-round-2809-repairs')
manifest=json.loads((root/'manifest.json').read_text())
for name in ['reconcile-repeated-evidence-write.py','seal-reviewed-repair-batch.py']:
 data=(Path('/tmp/issue-1580-research')/name).read_bytes()
 packed=gzip.compress(data,mtime=0); filename=f'{len(manifest["files"])+1:03d}-{name}.gz'
 (root/filename).write_bytes(packed)
 manifest['files'].append({'file':filename,'source':'publication-controller/'+name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'compressedSha256':hashlib.sha256(packed).hexdigest()})
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Removed duplicate append from repeated archive controller; no validation evidence changed.')
