from pathlib import Path
import subprocess,json,time,os

out=Path('/tmp/issue-1580-research/reviewed-repair-publication')
out.mkdir(exist_ok=True)
final=Path('/tmp/issue-1580-research/2809-synchronized-seed-validation/outcome.json')
while not final.exists():time.sleep(2)
assert json.loads(final.read_text())['passed'], final.read_text()
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','CARGO_BUILD_JOBS':'1'}
steps=[
 ('reconcile-repeated-evidence-write',['python3','/tmp/issue-1580-research/reconcile-repeated-evidence-write.py']),
 ('check-evidence-names',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations']),
 ('check-status-render',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-status-render']),
 ('verify-evidence-identities',['python3','/tmp/issue-1580-research/verify-current-repair-archives.py']),
 ('whitespace',['git','diff','--check']),
]
rows=[]
for name,command in steps:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env)
 row={'name':name,'exitCode':result.returncode,'seconds':round(time.monotonic()-start,3)}
 rows.append(row);(out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n')
 if result.returncode:break
passed=all(row['exitCode']==0 for row in rows) and len(rows)==len(steps)
if passed:
 paths=[
  'docs/status.md','docs/case-studies/issue-1580/hosted-round-2809-repairs.md',
  'experiments/issue-1580/work-plan.md',
  'experiments/issue-1580/evidence/checks/hosted-round-2809-repairs',
  'experiments/issue-1580/evidence/ci/2809ce65-terminal-round',
  'experiments/issue-1580/evidence/checks/production-diff-review-workflow-round',
 ]
 subprocess.run(['git','add','--',*paths],check=True)
 subprocess.run(['git','diff','--cached','--check'],check=True)
 with (out/'commit.log').open('w') as log:
  subprocess.run(['git','commit','-m','Preserve complete hosted failures and final local repair verification'],stdout=log,stderr=subprocess.STDOUT,check=True)
 status=subprocess.check_output(['git','status','--short'],text=True)
 (out/'status.log').write_text(status)
 assert not status,status
(out/'outcome.json').write_text(json.dumps({'complete':True,'passed':passed,'checks':rows,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'pushed':False},indent=2)+'\n')
