from pathlib import Path
import subprocess,os,json
out=Path('/tmp/issue-1580-research/native-grok-boundary-repair');env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'}
p=Path('js/worker/formal_ai_worker_prompt_data.js');s=p.read_text()
old='''  if (promptDataStarts(key, rules, "extraction")) {
    // A parsed text operation already binds its input and result type. A URL's
    // colon must not turn that request into an unrelated field lookup.
    if (parseTextManipulationRequest(prompt, normalizePrompt(prompt))) return null;
    return promptDataExtract(key, payload, rules, locale);
  }'''
new='  if (promptDataStarts(key, rules, "extraction")) return parseTextManipulationRequest(prompt, normalizePrompt(prompt)) ? null : promptDataExtract(key, payload, rules, locale);'
assert s.count(old)==1;p.write_text(s.replace(old,new))
rows=[]
for name,args in [('typescript-regeneration',['node','scripts/translate-es.mjs','--write']),('worker-cap',['node','scripts/check-worker-line-budget.mjs']),('text-owner-final',['node','--test','--test-concurrency=1','rust/tests/web/issue-0408-text-edit-parity.test.mjs']),('typescript-final',['node','scripts/translate-es.mjs','--check'])]:
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=env)
 rows.append({'name':name,'exitCode':r.returncode})
 (out/'worker-cap-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert r.returncode==0,name
print(json.dumps(rows))
