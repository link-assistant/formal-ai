from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,gzip,hashlib,tarfile,io,os,sys,traceback
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');b=s/'codeql-batch-commits'
assert json.loads((s/'codeql-final-staged-validation/outcome.json').read_text())['complete']
b.mkdir(exist_ok=False);records=[]
def run(label,args):
 p=subprocess.run(args,cwd=r,capture_output=True);raw=p.stdout+p.stderr;packed=gzip.compress(raw,mtime=0);name=label+'.log.gz';(b/name).write_bytes(packed);records.append({'label':label,'argv':args,'exitCode':p.returncode,'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()});(b/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(label,p.returncode,raw.decode(errors='replace')[-4500:],flush=True);assert p.returncode==0,label
 return p.stdout.decode().strip()
try:
 assert run('branch',['git','branch','--show-current'])=='issue-1580-8d61a32a61e1'
 identities=json.loads((r/'experiments/issue-1580/evidence/checks/codeql-result-gate/final-validation/source-identities.json').read_text())
 for row in identities:assert hashlib.sha256((r/row['file']).read_bytes()).hexdigest()==row['sha256'],row['file']
 p=r/'experiments/issue-1580/work-plan.md';t=p.read_text();t+='\n- Staged-evidence validation also passes the documentation-policy suite, all fourteen release-fixture admission controls, both lightweight registry fixture regressions, the unchanged abbreviation ceiling and both file-size policies. Command/file identities, stdout/stderr and failed investigation attempts are preserved. These checks do not claim actual native release execution, original source acceptance, live CodeQL execution or completion of the wider issue.\n';p.write_text(t)
 names=['close-codeql-local-validation.py','close-codeql-local-validation.log','codeql-final-staged-validation/worker.log','codeql-final-staged-validation/outcome.json','codeql-result-gate-final-closure/worker.log','codeql-result-gate-final-closure/outcome.json','codeql-final-document-read.log','codeql-final-document-read-corrected.log','read-codeql-final-document.py','codeql-final-gate-list.log','codeql-status-before-final.log','read-secrets-scan-during-gates.log','list-rust-remaining-active.py','rust-remaining-active.log','publish-codeql-batch.py','collect-codeql-batch-ci.py','commit-codeql-batch.py','codeql-batch-pr-body.md']
 buf=io.BytesIO();manifest=[]
 with tarfile.open(fileobj=buf,mode='w') as archive:
  for name in names:
   raw=(s/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(raw));manifest.append({'file':name,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
 raw=buf.getvalue();packed=gzip.compress(raw,mtime=0);d=r/'experiments/issue-1580/evidence/checks/codeql-batch-preflight';(d/'supplied-final-validation.tar.gz').write_bytes(packed);(d/'supplied-final-validation.json').write_text(json.dumps({'files':manifest,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'independentAuthorshipCredit':0},indent=2)+'\n')
 run('archive-final-command-records',['python3',str(s/'archive-evidence.py')]);run('stage-complete-batch',['git','add','--all']);run('staged-difference-check',['git','diff','--cached','--check']);run('staged-summary',['git','diff','--cached','--stat'])
 production=[row['file'] for row in identities]
 run('commit-result-gate',['git','commit','-m','Reject incomplete CodeQL analysis and retain native contract coverage','--',*production]);source_head=run('source-commit',['git','rev-parse','HEAD'])
 run('commit-replay-evidence',['git','commit','-m','Preserve exact-head CI failures and template review evidence']);evidence_head=run('evidence-commit',['git','rev-parse','HEAD'])
 assert run('clean-status',['git','status','--porcelain'])==''
 outcome={'complete':True,'sourceCommit':source_head,'head':evidence_head,'fullIssueComplete':False,'independentAuthorshipCredit':0};(b/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome),flush=True)
except BaseException:
 traceback.print_exc();(b/'failure.json').write_text(json.dumps({'complete':False,'traceback':traceback.format_exc()})+'\n');sys.exit(1)
