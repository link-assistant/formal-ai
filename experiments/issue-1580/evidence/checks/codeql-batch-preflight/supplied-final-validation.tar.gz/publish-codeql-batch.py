from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,gzip,hashlib,sys,os,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');os.chdir(root);base=Path('/tmp/issue-1580-research/codeql-batch-publication')
if len(sys.argv)==1:
 base.mkdir(exist_ok=False)
 (base/'pull-request-body.md').write_bytes(Path('/tmp/issue-1580-research/codeql-batch-pr-body.md').read_bytes())
 with (base/'worker.log').open('wb') as stream:p=subprocess.Popen([sys.executable,__file__,'worker'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid}));sys.exit(0)
records=[];head='';pushed=False

def run(name,args,parsed=False,checked=True):
 r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE);row={'name':name,'argv':args,'exitCode':r.returncode}
 for label,raw in [('stdout',r.stdout),('stderr',r.stderr)]:
  filename=name+'.'+label+'.gz';packed=gzip.compress(raw,mtime=0);(base/filename).write_bytes(packed);row[label]={'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()}
 records.append(row);(base/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,r.stdout.decode(errors='replace')[-800:],r.stderr.decode(errors='replace')[-800:],flush=True)
 if checked:assert r.returncode==0,name
 return json.loads(r.stdout) if parsed else r.stdout.decode().strip()
try:
 assert run('branch',['git','branch','--show-current'])=='issue-1580-8d61a32a61e1'
 assert run('status',['git','status','--porcelain'])==''
 head=run('head',['git','rev-parse','HEAD']);assert head!='c5b6850813d20fa7d3d5e9f4a496b6b8c5220009'
 run('release-repair-ancestor',['git','merge-base','--is-ancestor','14ce8c0995b25024639b860443bd6e315e99023d','HEAD'])
 pr=run('pull-request-before',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','headRefOid,headRefName,baseRefName,isDraft,url,title'],True);assert pr['headRefOid']=='c5b6850813d20fa7d3d5e9f4a496b6b8c5220009' and pr['headRefName']=='issue-1580-8d61a32a61e1' and pr['isDraft']
 run('fetch-main',['git','fetch','origin','main']);run('main-ancestor',['git','merge-base','--is-ancestor','origin/main','HEAD'])
 for state in ['in_progress','queued']:
  assert run('runs-'+state,['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--status',state,'--limit','100','--json','databaseId,workflowName,headSha,status'],True)==[]
 run('push',['git','push','origin','HEAD:issue-1580-8d61a32a61e1']);pushed=True
 run('edit-pull-request',['gh','pr','edit','1581','--repo','link-assistant/formal-ai','--title','Repair CI admission, JavaScript shard planning and release scripts','--body-file',str(base/'pull-request-body.md')])
 pr=run('pull-request-after',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','headRefOid,headRefName,baseRefName,isDraft,url,title,body'],True);assert pr['headRefOid']==head and pr['isDraft'] and pr['body']==(base/'pull-request-body.md').read_text()
 assert run('status-after',['git','status','--porcelain'])==''
 outcome={'complete':True,'head':head,'pushExecuted':True,'url':pr['url'],'isDraft':True,'fullIssueComplete':False,'independentAuthorshipCredit':0,'publishedAt':datetime.now(timezone.utc).isoformat()};(base/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome),flush=True)
except BaseException:
 traceback.print_exc();(base/'outcome.json').write_text(json.dumps({'complete':False,'head':head,'pushExecuted':pushed,'traceback':traceback.format_exc()})+'\n');sys.exit(1)
