from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,gzip,hashlib,os,sys,traceback,tarfile,io
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');scratch=s/'codeql-final-staged-validation';b=r/'experiments/issue-1580/evidence/checks/codeql-batch-preflight/staged-validation'
if len(sys.argv)==1:
 assert json.loads((s/'codeql-result-gate-final-closure/outcome.json').read_text())['complete']
 scratch.mkdir(exist_ok=False);b.mkdir(exist_ok=False)
 with (scratch/'worker.log').open('wb') as out:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=r,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'scratch':str(scratch)}));raise SystemExit(0)
records=[]
def run(label,args):
 p=subprocess.run(args,cwd=r,capture_output=True,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','PYTHONDONTWRITEBYTECODE':'1'});raw=p.stdout+p.stderr;packed=gzip.compress(raw,mtime=0);name=label+'.log.gz';(b/name).write_bytes(packed);records.append({'label':label,'argv':args,'exitCode':p.returncode,'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()});(b/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(label,p.returncode,raw.decode(errors='replace')[-3500:],flush=True);assert p.returncode==0,label
 return p.stdout
try:
 identity_path=r/'experiments/issue-1580/evidence/checks/codeql-result-gate/final-validation/source-identities.json'
 for row in json.loads(identity_path.read_text()):assert hashlib.sha256((r/row['file']).read_bytes()).hexdigest()==row['sha256'],row['file']
 p=r/'docs/case-studies/issue-1580/codeql-result-checkpoint.md';t=p.read_text();old='full gate run passes all 140 executable-or-explicitly-excluded entries. A separate\nfinal run verifies the subsequent native admission change; inspect its receipt\nbefore treating that final source as checked.';assert old in t;t=t.replace(old, 'full gate run passes all 140 executable-or-explicitly-excluded entries. The final\nrun after the native admission update also passes; its exact source identities\nand complete logs are retained in `final-validation/`.');p.write_text(t)
 p=r/'experiments/issue-1580/work-plan.md';t=p.read_text();t+='\n- Final CodeQL source closure: 8 result-gate groups, 18 production-profile cases, 97 workflow-policy cases, all four Rust formatting checks and the full 140-entry local gate inventory pass. Source identities are reverified before staging the complete evidence. CI-only exclusions remain explicit; actual corrected native release CLIs and the two newly focused CodeQL contracts still require the next exact-head hosted run. The broader issue, all open alerts, remaining original-source acceptance and 0/20 independent Formal AI credit remain unfinished.\n';p.write_text(t)
 run('archive-command-records',['python3',str(s/'archive-evidence.py')])
 run('stage-final-evidence',['git','add','--all'])
 jobs=[('documentation-policy',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/documentation-only-ci-policy.test.mjs']),('release-fixture-admission',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/release-fixture-caller-admission.test.mjs']),('registry-fixture',['python3','experiments/issue-1580/release-registry/check_fixture.py'])]
 for label,args in jobs:run(label,args)
 for gate in ['check-abbreviations','check-file-size','check-file-size-js-twin']:
  run(gate,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate])
 run('working-difference-check',['git','diff','--check']);run('staged-difference-check',['git','diff','--cached','--check'])
 for row in json.loads(identity_path.read_text()):assert hashlib.sha256((r/row['file']).read_bytes()).hexdigest()==row['sha256'],row['file']
 (b/'verification.json').write_text(json.dumps({'complete':True,'sourceIdentitiesUnchanged':True,'records':records,'nativeCompilationExecuted':False,'liveCodeqlExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n');(scratch/'outcome.json').write_text(json.dumps({'complete':True,'fullIssueComplete':False})+'\n');print('COMPLETE',flush=True)
except BaseException:
 traceback.print_exc();(scratch/'failure.json').write_text(json.dumps({'complete':False,'traceback':traceback.format_exc()})+'\n');sys.exit(1)
