from pathlib import Path
import json
for name in ['docs/case-studies/issue-1580/codeql-result-checkpoint.md', 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json']:
 p=Path(name)
 if name.endswith('.json'):
  d=json.loads(p.read_text()); print(name, d['fullyReadFiles'], d['fullyReadSourceLines'], len(d['files']))
 else:
  print('FILE',name)
  for n,line in enumerate(p.read_text().splitlines(),1): print(str(n)+': '+line)
