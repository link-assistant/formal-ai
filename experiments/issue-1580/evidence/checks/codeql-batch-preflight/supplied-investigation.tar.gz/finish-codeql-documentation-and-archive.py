from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,tarfile,io,subprocess,os
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');b=r/'experiments/issue-1580/evidence/checks/codeql-batch-preflight'
p=r/'docs/case-studies/issue-1580/codeql-result-checkpoint.md';text=p.read_text().replace('169/373 pinned files and 25,817 literal source','180/373 pinned files and 26,781 literal source').replace('The 204 unread files','The 193 unread files');p.write_text(text)
p=r/'experiments/issue-1580/work-plan.md';text=p.read_text();text+='\n- Additional pinned review: eleven remaining release/rename/provenance experiments and guides add 964 literally read, identity-verified lines. Rust source review is now 180/373 files and 26,781 lines, with 193 files and all unverified practice/runtime criteria open. The initial read-log parser rejected the SHA-bearing headers without changing the ledger; its corrected parser verifies every numbered line before recording progress.\n';p.write_text(text)
names=['review-codeql-local-and-ci.py','read-codeql-gate-draft.py','read-abbreviation-new-names.py','read-warning-cleanup-contacts.py','repair-codeql-gate-review.py','verify-codeql-result-gate-reviewed.py','inspect-codeql-version-and-template-remainder.py','inspect-codeql-version-and-template-remainder-corrected.py','search-codeql-trusted-main-reports.py','read-rust-javascript-example-and-release-probes.py','read-codeql-related-reports.py','report-codeql-trusted-main.py','codeql-trusted-main-report.md','record-rust-javascript-example-review.py','review-native-codeql-module-admission.py','read-native-codeql-admission-corrected.py','read-codeql-native-execution-closure.py','read-codeql-shared-reader-contacts.py','read-codeql-native-closure-next.py','read-native-module-source.py','repair-native-codeql-closure.py','verify-codeql-result-gate-final-closure.py','review-current-codeql-diff.py','prepare-codeql-publication.py','read-codeql-preflight-feedback.py','assess-terminal-registry-ci.py','list-rust-unread-after-169.py','document-codeql-checkpoint.py','read-rust-remaining-release-experiments.py','check-codeql-module-registration.py','read-codeql-coverage-name-consumers.py','record-rust-release-guards-review.py','record-rust-release-guards-review-corrected.py','finish-codeql-documentation-and-archive.py','codeql-batch-pr-body.md']
all_names=set(names)
for n in names:
 p=s/n
 for candidate in [p.with_suffix('.log'),s/(p.stem+'-corrected.log')]:
  if candidate.exists():all_names.add(candidate.name)
for n in ['codeql-result-gate-final/worker.log','codeql-result-gate-final/failure.json','codeql-result-gate-reviewed/worker.log','codeql-result-gate-reviewed/outcome.json','registry-batch-ci/worker.log','registry-batch-ci/outcome.json','codeql-current-source.diff']:
 if (s/n).exists():all_names.add(n)
rows=[];buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as a:
 for n in sorted(all_names):
  p=s/n
  if not p.exists():continue
  raw=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(raw);info.mode=0o644;info.mtime=0;a.addfile(info,io.BytesIO(raw));rows.append({'file':n,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
raw=buffer.getvalue();packed=gzip.compress(raw,mtime=0);(b/'supplied-investigation.tar.gz').write_bytes(packed);(b/'supplied-investigation.json').write_text(json.dumps({'files':rows,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'independentAuthorshipCredit':0},indent=2)+'\n')
q=subprocess.run(['rg','--files','rust/tests/web','experiments/issue-1580'],cwd=r,capture_output=True,text=True,check=True);print('ADMISSION TESTS',[n for n in q.stdout.splitlines() if 'admission' in n and n.endswith('.test.mjs')]);print('ARCHIVED',len(rows),'inputs and logs',len(packed),'bytes')
