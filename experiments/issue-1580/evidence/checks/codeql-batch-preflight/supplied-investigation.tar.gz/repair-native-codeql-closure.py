from pathlib import Path
import subprocess,hashlib,json,gzip,os
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/checks/codeql-result-gate/native-admission';b.mkdir(exist_ok=False)
name='rust/tests/web/default-branch-build-policy.test.mjs';p=r/name
extra='''

test('CodeQL native contracts admit their source and archived fixture changes', () => {
  for (const path of [
    'rust/tests/unit/ci-cd/step_budgets_within_job_clocks/codeql.rs',
    'docs/case-studies/issue-96/raw-data/link-calculator-lib-excerpt.rs',
    '.github/codeql/codeql-config.yml',
  ]) assert.equal(admission([path])['native-type-check'], true, path);
  assert.equal(admission(['docs/unrelated-codeql-note.md'])['native-type-check'], false);
  assert.match(read('rust/tests/unit/workflow_contracts.rs'),
    /#\\[path = "ci-cd\\/step_budgets_within_job_clocks\\/codeql[.]rs"\\]\\s+mod codeql;/u);
});
'''
s=p.read_text();assert 'CodeQL native contracts admit' not in s;p.write_text(s+extra)
args=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','--test-name-pattern=CodeQL native contracts admit',name]
q=subprocess.run(args,cwd=r,capture_output=True);raw=q.stdout+q.stderr;(b/'before.log.gz').write_bytes(gzip.compress(raw,mtime=0));assert q.returncode==1,raw.decode();print('Before: new regression fails',raw.decode()[-1700:])
parent=r/'rust/tests/unit/ci-cd/step_budgets_within_job_clocks.rs';s=parent.read_text();old='''fn repository_file(path: &str) -> String {
    fs::read_to_string(format!("{}/../{path}", env!("CARGO_MANIFEST_DIR")))
        .unwrap_or_else(|error| panic!("failed to read {path}: {error}"))
        .replace("\\r\\n", "\\n")
}

''';assert s.count(old)==1;s=s.replace(old,'');s=s.replace('use super::workflow_fixtures::{job_block, read_only_group, workflow_job_names};','use super::workflow_fixtures::{job_block, read_only_group, repository_file, workflow_job_names};');parent.write_text(s)
f=r/'rust/tests/unit/ci-cd/workflow_fixtures.rs';s=f.read_text();assert 'fn repository_file' not in s;s=s.replace('use std::path::Path;\n','use std::path::Path;\n\n/// Read a repository fixture with platform-independent line endings.\npub '+old);f.write_text(s)
f=r/'rust/tests/unit/workflow_contracts.rs';s=f.read_text();anchor='pub mod workflow_release;\n';assert s.count(anchor)==1;s=s.replace(anchor,anchor+'\nuse workflow_fixtures::{job_block, repository_file};\n\n#[path = "ci-cd/step_budgets_within_job_clocks/codeql.rs"]\nmod codeql;\n');f.write_text(s)
f=r/'scripts/ci-pull-request-admission.mjs';s=f.read_text();anchor='  "rust/tests/unit/ci-cd/workflow_fixtures.rs",';assert s.count(anchor)==1;s=s.replace(anchor,'  "rust/tests/unit/ci-cd/step_budgets_within_job_clocks/codeql.rs",\n  "docs/case-studies/issue-96/raw-data/link-calculator-lib-excerpt.rs",\n'+anchor);f.write_text(s)
rust=['rust/tests/unit/ci-cd/workflow_fixtures.rs','rust/tests/unit/ci-cd/step_budgets_within_job_clocks.rs','rust/tests/unit/ci-cd/step_budgets_within_job_clocks/codeql.rs','rust/tests/unit/workflow_contracts.rs'];subprocess.run(['rustfmt','--edition','2024',*rust],cwd=r,check=True)
q=subprocess.run(args,cwd=r,capture_output=True);raw2=q.stdout+q.stderr;(b/'after.log.gz').write_bytes(gzip.compress(raw2,mtime=0));assert q.returncode==0,raw2.decode();print('After: new regression passes',raw2.decode()[-1200:]);(b/'verification.json').write_text(json.dumps({'argv':args,'beforeExitCode':1,'afterExitCode':0,'beforeRawSha256':hashlib.sha256(raw).hexdigest(),'afterRawSha256':hashlib.sha256(raw2).hexdigest(),'nativeCompilationExecuted':False,'hostedExecutionStillRequired':True,'checkoutChangeRequired':False,'checkoutReason':'Both native checkout attempts retain /* and exclude only dev/log and selected experiments; Rust, .github and this docs fixture are included.','independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
