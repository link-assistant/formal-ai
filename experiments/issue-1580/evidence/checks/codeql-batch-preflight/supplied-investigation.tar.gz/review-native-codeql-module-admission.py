from pathlib import Path
import subprocess,json
r=Path('/tmp/gh-issue-solver-1794900398048')
for args in [['rg','-n','step_budgets_within_job_clocks','data','scripts','experiments/issue-1580/native-admission','--glob','!**/evidence/**'],['rg','-n','ci-cd|workflow_contracts|mod declaration|mod\\s|path =','scripts/native-type-check','scripts/run-native-contracts.mjs','rust/tests/web/default-branch-build-policy.test.mjs']]:
 p=subprocess.run(args,cwd=r,capture_output=True,text=True);print('SEARCH',args,'EXIT',p.returncode);print(p.stdout[:12000]);print(p.stderr[:1200])
