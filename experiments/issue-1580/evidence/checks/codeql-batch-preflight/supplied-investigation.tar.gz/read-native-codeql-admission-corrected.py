from pathlib import Path
import subprocess
r=Path('/tmp/gh-issue-solver-1794900398048')
for name,ranges in [('rust/tests/web/default-branch-build-policy.test.mjs',[(1,35),(1055,1110)]),('rust/tests/unit/workflow_contracts.rs',[(1,70)]),('scripts/ci-change-admission.mjs',[(1,120)])]:
 p=r/name
 if not p.is_file(): print('MISSING',name);continue
 lines=p.read_text().splitlines()
 for start,end in ranges:
  print('SOURCE',name,start,end);print('\n'.join(f'{i+1}: {lines[i]}' for i in range(start-1,min(end,len(lines)))))
p=subprocess.run(['rg','--files','scripts'],cwd=r,capture_output=True,text=True);print('ADMISSION/NATIVE SCRIPT PATHS\n'+'\n'.join(x for x in p.stdout.splitlines() if 'native' in x or 'admission' in x))
