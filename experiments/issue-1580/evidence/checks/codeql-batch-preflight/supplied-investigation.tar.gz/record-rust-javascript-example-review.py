from pathlib import Path
from datetime import datetime,timezone
import re,json,gzip,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');t=Path('/tmp/issue-1580-research/templates/rust-complete');raw=Path('/tmp/issue-1580-research/read-rust-javascript-example-and-release-probes.log').read_bytes();rows={};current=None
for line in raw.decode().splitlines():
 m=re.match(r'   (?:Output: )?FILE (\S+) LINES (\d+)$',line)
 if m:current=m[1];rows[current]={'lines':int(m[2]),'numbered':[]};continue
 m=re.match(r'   (\d+): (.*)$',line)
 if m and current:rows[current]['numbered'].append((int(m[1]),m[2]))
assert len(rows)==20,len(rows)
p=r/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json';d=json.loads(p.read_text());known={x['path'] for x in d['files']};identities={x['path']:x for x in json.loads((r/d['all373BlobIdentitiesVerifiedBy']).read_text())};total=0;b=r/'experiments/issue-1580/evidence/checks/rust-source-review';name='rust-javascript-example-and-release-probes-read.log.gz'
for path,row in rows.items():
 source=(t/path).read_bytes();lines=source.decode().splitlines();sha=hashlib.sha256(source).hexdigest();assert sha==identities[path]['sha256'];assert len(lines)==row['lines'];assert row['numbered']==list(enumerate(lines,1)),path;assert path not in known,path
 d['files'].append({'path':path,'lines':len(lines),'sha256':sha,'readLogs':[name],'literalReadRanges':[[1,len(lines)]],'literalReadLines':len(lines),'literalSourceFullyRead':True,'formalAiPracticeImplementationVerified':False});total+=len(lines)
assert total==798,total
packed=gzip.compress(raw,mtime=0);(b/name).write_bytes(packed);lp=b/'logs.json';logs=json.loads(lp.read_text());assert not any(x['file']==name for x in logs);logs.append({'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()});lp.write_text(json.dumps(logs,indent=2)+'\n')
d['files'].sort(key=lambda x:x['path']);d['fullyReadFiles']=len(d['files']);d['fullyReadSourceLines']=sum(x['literalReadLines'] for x in d['files']);d['observedAt']=datetime.now(timezone.utc).isoformat();assert(d['fullyReadFiles'],d['fullyReadSourceLines'])==(169,25817)
d['practiceDecisions'].append({'practice':'Independent JavaScript-first checked-i32 API, pinned typed translation and explicit native adapters; release source and registry regression boundaries','templateEvidence':list(rows),'assessment':'All 798 numbered lines in twenty pinned files are read and match the immutable blob inventory. The example has eight shared success/refusal/boundary fixtures, independently implemented JavaScript, hash-pinned typed IR and translator, generated native tests and compile-fail adapter controls. Documentation requires original validated source preservation through release metadata races. Two old version experiments mutate branches without isolated fixtures and must not be copied or executed against the prepared branch. Template runtime execution and Formal AI full-application parity/source-race acceptance remain unfinished.','status':'source-read-comparison-and-runtime-pending'})
p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'fullyReadFiles':169,'fullyReadSourceLines':25817,'remainingFiles':204,'literalLinesAndPinnedIdentitiesVerified':True,'runtimeExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}))
