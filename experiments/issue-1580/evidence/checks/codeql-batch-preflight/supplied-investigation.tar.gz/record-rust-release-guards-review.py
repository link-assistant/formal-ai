from pathlib import Path
from datetime import datetime,timezone
import re,json,gzip,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');t=Path('/tmp/issue-1580-research/templates/rust-complete');raw=Path('/tmp/issue-1580-research/read-rust-remaining-release-experiments.log').read_bytes();rows={};current=None
for line in raw.decode().splitlines():
 m=re.match(r'   (?:Output: )?FILE (\S+) LINES (\d+)$',line)
 if m:current=m[1];rows[current]={'lines':int(m[2]),'numbered':[]};continue
 m=re.match(r'   (\d+): (.*)$',line)
 if m and current:rows[current]['numbered'].append((int(m[1]),m[2]))
assert len(rows)==11,len(rows)
p=r/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json';d=json.loads(p.read_text());known={x['path'] for x in d['files']};identities={x['path']:x for x in json.loads((r/d['all373BlobIdentitiesVerifiedBy']).read_text())};total=0;b=r/'experiments/issue-1580/evidence/checks/rust-source-review';name='rust-release-guards-and-workflow-prerequisites-read.log.gz'
for path,row in rows.items():
 source=(t/path).read_bytes();lines=source.decode().splitlines();sha=hashlib.sha256(source).hexdigest();assert sha==identities[path]['sha256'];assert len(lines)==row['lines'];assert row['numbered']==list(enumerate(lines,1)),path;assert path not in known,path
 d['files'].append({'path':path,'lines':len(lines),'sha256':sha,'readLogs':[name],'literalReadRanges':[[1,len(lines)]],'literalReadLines':len(lines),'literalSourceFullyRead':True,'formalAiPracticeImplementationVerified':False});total+=len(lines)
assert total==964,total
packed=gzip.compress(raw,mtime=0);(b/name).write_bytes(packed);lp=b/'logs.json';logs=json.loads(lp.read_text());assert not any(x['file']==name for x in logs);logs.append({'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()});lp.write_text(json.dumps(logs,indent=2)+'\n')
d['files'].sort(key=lambda x:x['path']);d['fullyReadFiles']=len(d['files']);d['fullyReadSourceLines']=sum(x['literalReadLines'] for x in d['files']);d['observedAt']=datetime.now(timezone.utc).isoformat();assert(d['fullyReadFiles'],d['fullyReadSourceLines'])==(180,26781)
d['practiceDecisions'].append({'practice':'Release guards, rename-complete Git inventories and original validated revision custody across every native workflow','templateEvidence':list(rows),'assessment':'All 964 numbered lines in eleven pinned files match their immutable blob identities. Preserve version checks on release-prefixed branches, new collectable fragment identity independent of Git rename heuristics, both endpoints of source moves, author-based bot exemptions, publish credentials in the environment, manifest warning refusal and bounded installer retries. Workflow controls validate exact-revision JavaScript prerequisites before native/container work, generated release candidates and simulated merges, and serialize writers without cancellation. Historical per-commit-only detection is not adopted as a substitute for the complete PR delta. The CodeQL diagnostic precedent agrees with the current local draft. These template experiments were read, not executed; corresponding complete runtime/application acceptance remains unfinished.','status':'literal-source-comparison-and-counterpart-runtime-pending'})
p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'fullyReadFiles':180,'fullyReadSourceLines':26781,'remainingFiles':193,'literalLinesAndPinnedIdentitiesVerified':True,'runtimeExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}))
