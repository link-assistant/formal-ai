from pathlib import Path
import json
r=Path('/tmp/gh-issue-solver-1794900398048');t=Path('/tmp/issue-1580-research/templates/rust-complete');d=json.loads((r/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json').read_text());read={x['path'] for x in d['files']};remaining=[]
for p in sorted(t.rglob('*')):
 if p.is_file() and p.relative_to(t).as_posix() not in read:
  n=p.relative_to(t).as_posix();raw=p.read_bytes();remaining.append({'path':n,'bytes':len(raw),'lines':len(raw.splitlines())});print(n,len(raw.splitlines()),len(raw))
assert len(remaining)==204,len(remaining)
Path('/tmp/issue-1580-research/rust-unread-after-169.json').write_text(json.dumps(remaining,indent=2)+'\n')
