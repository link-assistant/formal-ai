from pathlib import Path
import subprocess,gzip,json,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/checks/codeql-result-gate';body=Path('/tmp/issue-1580-research/codeql-trusted-main-report.md');assert not(b/'upstream-report.json').exists()
args=['gh','issue','create','--repo','github/codeql','--title','Actions: trusted main commit outputs named sha become PR-head cache-poisoning sources','--body-file',str(body)];p=subprocess.run(args,cwd=r,capture_output=True)
for label,raw in [('stdout',p.stdout),('stderr',p.stderr)]: (b/('create-upstream-report.'+label+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
assert p.returncode==0,p.stderr.decode(errors='replace');url=p.stdout.decode().strip();assert url.startswith('https://github.com/github/codeql/issues/');packed=gzip.compress(body.read_bytes(),mtime=0);(b/'upstream-report-body.md.gz').write_bytes(packed)
(b/'upstream-report.json').write_text(json.dumps({'url':url,'bodySha256':hashlib.sha256(body.read_bytes()).hexdigest(),'bodyArchiveSha256':hashlib.sha256(packed).hexdigest(),'observedRealAnalysis':2198826017,'codeqlVersion':'2.27.4','independentReducedQueryExecution':False,'upstreamFixVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n');print(url)
