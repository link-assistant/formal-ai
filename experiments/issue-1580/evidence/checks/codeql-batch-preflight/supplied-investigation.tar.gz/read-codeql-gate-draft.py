from pathlib import Path
import subprocess,json,gzip
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'experiments/formal_ai_subagent/sandboxes/gates/check-abbreviations.log';print('ABBREVIATIONS LOG\n'+p.read_text())
p=subprocess.run(['git','diff','--cached','--','.github/workflows/security.yml','scripts/check-codeql-results.mjs','rust/tests/web/security-codeql-results.test.mjs','rust/tests/unit/ci-cd/step_budgets_within_job_clocks.rs','data/benchmarks/fast-pull-request-javascript-tests.json','data/benchmarks/fast-pull-request-retained-jobs.json','changelog.d/1580-codeql-result-gate.md'],cwd=r,capture_output=True,text=True);Path('/tmp/issue-1580-research/codeql-result-gate-source.diff').write_text(p.stdout);print('DIFF LINES',len(p.stdout.splitlines()))
ci=r/'experiments/issue-1580/evidence/ci/native-families-c5b68508';lines=gzip.decompress((ci/'failed-run-44692731148.stdout.gz').read_bytes()).decode().splitlines();found=[]
for i,line in enumerate(lines):
 parts=line.split('\t',2)
 if len(parts)==3 and ('##[error]' in parts[2] or '\x1b[31merror' in parts[2] or 'FAILED (' in parts[2] or 'fatal:' in parts[2] or 'AssertionError:' in parts[2]): found.append({'line':i+1,'job':parts[0],'text':parts[2]})
print('PIPELINE ACTIONABLE ERRORS',json.dumps(found,indent=2))
for p in ci.glob('job-*.stdout.gz'):
 if p.name.endswith('136158975499.stdout.gz'):
  print('PIPELINE STATUS LOG\n'+gzip.decompress(p.read_bytes()).decode())
