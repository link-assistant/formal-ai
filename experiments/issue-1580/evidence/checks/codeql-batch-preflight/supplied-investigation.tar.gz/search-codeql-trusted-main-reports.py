from pathlib import Path
import subprocess,gzip,json
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/checks/codeql-result-gate'
for label,query in [('trusted-main','cache-poisoning sha'),('checkout-heuristic','UntrustedCheckoutQuery'),('poisonable-false-positive','"poisonable-step" "false positive"')]:
 args=['gh','search','issues',query,'--repo','github/codeql','--limit','50','--json','number,title,state,url,updatedAt'];p=subprocess.run(args,cwd=r,capture_output=True)
 for field,raw in [('stdout',p.stdout),('stderr',p.stderr)]: (b/('upstream-report-search-'+label+'.'+field+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
 print(label,'EXIT',p.returncode);print(p.stdout.decode(errors='replace'));print(p.stderr.decode(errors='replace'))
