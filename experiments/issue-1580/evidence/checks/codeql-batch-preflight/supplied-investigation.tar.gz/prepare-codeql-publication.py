from pathlib import Path
import subprocess,json,gzip,hashlib,tarfile,io,datetime,os,sys,traceback
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research');scratch=s/'codeql-batch-final-preflight'
if len(sys.argv)==1:
 scratch.mkdir(exist_ok=False)
 with (scratch/'worker.log').open('wb') as out:worker=subprocess.Popen([sys.executable,__file__,'worker'],cwd=r,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':worker.pid,'scratch':str(scratch)}));raise SystemExit(0)
b=r/'experiments/issue-1580/evidence/checks/codeql-batch-preflight';b.mkdir(exist_ok=False);records=[]
def run(label,args):
 result=subprocess.run(args,cwd=r,capture_output=True,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','PYTHONDONTWRITEBYTECODE':'1'});row={'label':label,'argv':args,'exitCode':result.returncode}
 for name,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
  packed=gzip.compress(raw,mtime=0);filename=label+'.'+name+'.gz';(b/filename).write_bytes(packed);row[name]={'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()}
 records.append(row);(b/'records.json').write_text(json.dumps(records,separators=(',',':'))+'\n');print(label,result.returncode,result.stdout.decode(errors='replace')[-1800:],result.stderr.decode(errors='replace')[-1000:],flush=True);assert result.returncode==0,label
 return result.stdout
try:
 assert run('branch',['git','branch','--show-current']).decode().strip()=='issue-1580-8d61a32a61e1'
 run('fetch-main',['git','fetch','origin','main']);run('main-ancestor',['git','merge-base','--is-ancestor','origin/main','HEAD'])
 for label,path in [('issue-comments','issues/1580/comments'),('pull-request-comments','issues/1581/comments'),('pull-request-inline','pulls/1581/comments'),('pull-request-reviews','pulls/1581/reviews')]:
  raw=run(label,['gh','api','repos/link-assistant/formal-ai/'+path,'--paginate']);data=json.loads(raw);print('FEEDBACK',label,len(data),flush=True)
 run('source-difference-summary',['git','diff','--stat','14ef1b5f..HEAD'])
 outcome={'complete':True,'nativeRegistryExecuted':False,'fullIssueComplete':False,'suppliedAuthorshipCredit':0};(scratch/'outcome.json').write_text(json.dumps(outcome)+'\n');print('COMPLETE',flush=True)
except BaseException:
 traceback.print_exc();(scratch/'failure.json').write_text(json.dumps({'complete':False,'traceback':traceback.format_exc()})+'\n');sys.exit(1)
