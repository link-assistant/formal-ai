from pathlib import Path
import json,gzip,subprocess,base64
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/checks/codeql-result-gate'
for name in ['UntrustedCheckoutQuery.qll','CachePoisoningQuery.qll']:
 path='actions/ql/lib/codeql/actions/security/'+name;args=['gh','api','repos/github/codeql/contents/'+path+'?ref=codeql-cli/v2.27.4'];p=subprocess.run(args,cwd=r,capture_output=True)
 for field,raw in [('stdout',p.stdout),('stderr',p.stderr)]: (b/('codeql-2.27.4-'+name+'.'+field+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
 print('MATCHED_VERSION_REQUEST',name,'EXIT',p.returncode)
 if p.returncode:print(p.stderr.decode(errors='replace'));continue
 d=json.loads(p.stdout);raw=base64.b64decode(d['content']);target=Path('/tmp/issue-1580-research')/('codeql-2.27.4-'+name);target.write_bytes(raw);print('BLOB',d['sha'],'PATH',path,'LINES',len(raw.splitlines()))
 lines=raw.decode().splitlines()
 if name=='UntrustedCheckoutQuery.qll':
  for i,line in enumerate(lines):
   if 'class ActionsSHACheckout' in line or 'class ActionsMutableRefCheckout ' in line:
    print('\n'.join(f'{j+1}: {lines[j]}' for j in range(i,min(len(lines),i+56))))
p=r/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json';d=json.loads(p.read_text());seen={x['path'] for x in d['files']};t=Path('/tmp/issue-1580-research/templates/rust-complete');rows=sorted(str(x.relative_to(t)) for x in t.rglob('*') if x.is_file());assert len(rows)==373,(len(rows),'pinned archive inventory mismatch');unread=[x for x in rows if x not in seen];print('UNREAD',len(unread));print('\n'.join(unread[:100]));Path('/tmp/issue-1580-research/rust-template-unread.json').write_text(json.dumps(unread,indent=2)+'\n')
