from pathlib import Path
r=Path('/tmp/issue-1580-research/templates/rust-complete')
names=['docs/javascript-first.md']+[str(p.relative_to(r)) for p in sorted((r/'examples/javascript-first').rglob('*')) if p.is_file()]+['experiments/test-changelog-parsing.rs','experiments/test-crates-io-check.rs','experiments/test-issue143-throttled-crates-io-probe.rs','experiments/test-version-check-dependencies.sh','experiments/test-version-check.sh','docs/case-studies/issue-232/analysis.md']
for name in names:
 data=(r/name).read_text();lines=data.splitlines();assert len(lines)<=1500;print('FILE',name,'LINES',len(lines))
 for i,line in enumerate(lines,1):print(f'{i}: {line}')
