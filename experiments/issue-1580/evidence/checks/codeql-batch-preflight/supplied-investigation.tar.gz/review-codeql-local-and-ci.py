from pathlib import Path
import gzip,json,re,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/checks/codeql-result-gate';ci=r/'experiments/issue-1580/evidence/ci/native-families-c5b68508'
for source in [b/'all-local-gates.log.gz',ci/'failed-run-44692731148.stdout.gz']:
 lines=gzip.decompress(source.read_bytes()).decode(errors='replace').splitlines(); print('LOG',source.name,'LINES',len(lines)); wanted=set()
 patterns=['FAIL','Error:','error[','error:','fatal:','AssertionError','FAILED','not ok','check-abbreviations']
 for i,line in enumerate(lines):
  if any(p in line for p in patterns): wanted.update(range(max(0,i-3),min(len(lines),i+5)))
 out='\n'.join(f'{i+1}: {lines[i]}' for i in sorted(wanted))+'\n';dst=Path('/tmp/issue-1580-research')/(source.stem+'.diagnostics.txt');dst.write_text(out);print('DIAGNOSTICS',dst,len(out.splitlines())); print(out[:24000])
for p in sorted(ci.glob('jobs-*.stdout.gz')):
 jobs=json.loads(gzip.decompress(p.read_bytes()))['jobs'];print('JOBS',p.name)
 for j in jobs:
  print(json.dumps({k:j.get(k) for k in ['databaseId','name','conclusion','startedAt','completedAt','url']}))
print(subprocess.check_output(['git','status','--short'],cwd=r,text=True)[:5000])
print(subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True))
