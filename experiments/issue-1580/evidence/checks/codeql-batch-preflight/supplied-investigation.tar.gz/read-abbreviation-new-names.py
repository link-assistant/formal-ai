from pathlib import Path
import subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');p=subprocess.run(['node','scripts/measure-abbreviations.mjs','--list','file-names'],cwd=r,capture_output=True,text=True);Path('/tmp/issue-1580-research/abbreviation-new-names.txt').write_text(p.stdout+p.stderr);print(p.stdout+p.stderr)
