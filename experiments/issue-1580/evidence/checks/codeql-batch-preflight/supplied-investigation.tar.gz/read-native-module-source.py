import pathlib,subprocess
r=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
for n,a,b in [('rust/tests/unit/ci-cd/step_budgets_within_job_clocks/codeql.rs',1,130),('rust/tests/unit/ci-cd/step_budgets_within_job_clocks.rs',1,75),('rust/tests/web/default-branch-build-policy.test.mjs',1,65),('rust/tests/web/default-branch-build-policy.test.mjs',1050,1190)]:
 s=(r/n).read_text().splitlines();print('FILE',n,len(s));print('\n'.join(f'{i+1}: {s[i]}' for i in range(a-1,min(b,len(s)))))
p=subprocess.run(['rg','-n','fs::|Path::|repository_file|codeql-config|link-calculator-lib-excerpt','rust/tests/unit/ci-cd/step_budgets_within_job_clocks.rs','scripts/ci-pull-request-admission.mjs','rust/tests/web/default-branch-build-policy.test.mjs'],cwd=r,text=True,capture_output=True);print(p.stdout);print('exit',p.returncode)
