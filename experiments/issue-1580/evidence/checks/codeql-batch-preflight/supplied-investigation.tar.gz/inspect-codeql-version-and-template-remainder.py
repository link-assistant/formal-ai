from pathlib import Path
import json,gzip,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/checks/codeql-result-gate'
for p in b.glob('*analys*.stdout.gz'):
 try:d=json.loads(gzip.decompress(p.read_bytes()))
 except Exception:continue
 if isinstance(d,dict) and 'runs' in d:print('SARIF TOOL',p.name,json.dumps([x.get('tool',{}) for x in d['runs']])[:1800])
 if isinstance(d,list):
  rows=d if not d or isinstance(d[0],dict) else [x for page in d for x in page]
  for row in rows:
   if row.get('id') in [2198915200,2198826017]: print('ANALYSIS',json.dumps(row,indent=2))
p=r/'docs/case-studies/issue-1580/templates/rust-source-review-progress.json';d=json.loads(p.read_text());print('PROGRESS KEYS',list(d));print('FIRST REVIEW ROW',json.dumps(d['files'][0]) if 'files' in d else json.dumps(d)[:1200])
t=Path('/tmp/issue-1580-research/templates/rust-complete');rows=subprocess.check_output(['git','ls-tree','-r','--name-only','HEAD'],cwd=t,text=True).splitlines();encoded=json.dumps(d);unread=[x for x in rows if '"'+x+'"' not in encoded];print('UNREAD',len(unread));print('\n'.join(unread[:95]))
