from pathlib import Path
import subprocess
r=Path('/tmp/gh-issue-solver-1794900398048')
for name,ranges in [('scripts/ci-native-regressions.sh',[(1,220)]),('scripts/ci-pull-request-admission.mjs',[(1,180)]),('scripts/lib/native-test-module-graph.mjs',[(1,200)]),('rust/tests/unit/ci-cd/mod.rs',[(50,80)])]:
 lines=(r/name).read_text().splitlines()
 for start,end in ranges:
  print('SOURCE',name,start,end,'TOTAL',len(lines));print('\n'.join(f'{i+1}: {lines[i]}' for i in range(start-1,min(end,len(lines)))))
a=['node','--input-type=module','-e',"import {admission} from './scripts/ci-pull-request-admission.mjs';console.log(JSON.stringify(admission(['rust/tests/unit/ci-cd/step_budgets_within_job_clocks/codeql.rs'])));"]
p=subprocess.run(a,cwd=r,capture_output=True,text=True);print('ACTUAL_CHILD_ADMISSION',p.returncode,p.stdout,p.stderr)
