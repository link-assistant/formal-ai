from pathlib import Path
import json,gzip,hashlib,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048'); b=r/'experiments/issue-1580/evidence/checks/codeql-result-gate'
# Keep captured command output byte-identical; update only archive locators.
relocations=[]
for directory,names in [('registry-batch-preflight',{'source-diff-stat':'source-difference-summary'}),('release-io-batch-preflight',{'pr-comments':'pull-request-conversation-comments','pr-review-comments':'pull-request-inline-comments','pr-reviews':'pull-request-reviews','pr':'pull-request'})]:
 base=r/'experiments/issue-1580/evidence/checks'/directory; records=json.loads((base/'records.json').read_text())
 for old,new in names.items():
  for stream in ['stdout','stderr']:
   source=base/(old+'.'+stream+'.gz');target=base/(new+'.'+stream+'.gz');assert source.is_file() and not target.exists();packed=source.read_bytes();raw=gzip.decompress(packed);source.rename(target)
   count=0
   for record in records:
    if record[stream]['file']==source.name:
     assert record[stream]['rawSha256']==hashlib.sha256(raw).hexdigest() and record[stream]['archiveSha256']==hashlib.sha256(packed).hexdigest();record[stream]['file']=target.name;count+=1
   assert count==1
   relocations.append({'directory':directory,'old':source.name,'new':target.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
 (base/'records.json').write_text(json.dumps(records,indent=2)+'\n')
(b/'archive-relocations.json').write_text(json.dumps({'reason':'Spell archive names in full while preserving captured command names, arguments and output bytes. Restore the existing abbreviation ratchet without changing its ceiling.','moves':relocations},indent=2)+'\n')
p=r/'.github/workflows/security.yml';s=p.read_text();s=s.replace('      # failures remain. A missing toolchain warns rather than fails — the\n','      # failures remain. Both paths must be available before analysis: the\n');p.write_text(s)
p=r/'rust/tests/web/security-codeql-results.test.mjs';s=p.read_text().replace("import { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';","import { mkdtempSync, mkdirSync, writeFileSync, rmSync, readFileSync, chmodSync } from 'node:fs';").replace("import { readFileSync, chmodSync } from 'node:fs';\n",'').replace("\n\n\nconst security",'\n\nconst security');p.write_text(s)
p=r/'rust/tests/unit/ci-cd/step_budgets_within_job_clocks.rs';s=p.read_text();blocks=[]
for start,end in [('/// The `CodeQL` run emitted parse diagnostics','/// An audit is only worth having'),('/// A `CodeQL` run that reports success','/// The same false negative from a third direction.')]:
 left=s.index(start);right=s.index(end,left);blocks.append(s[left:right]);s=s[:left]+s[right:]
marker='use super::workflow_fixtures::{job_block, read_only_group, workflow_job_names};\n';assert marker in s;s=s.replace(marker,marker+'\n#[path = "step_budgets_within_job_clocks/codeql.rs"]\nmod codeql;\n');p.write_text(s)
child=p.parent/'step_budgets_within_job_clocks/codeql.rs';child.parent.mkdir(exist_ok=True);assert not child.exists();child.write_text('//! CodeQL coverage and extractor prerequisites.\n\nuse std::fs;\n\nuse super::{job_block, repository_file};\n\n'+''.join(blocks).rstrip()+'\n')
subprocess.run(['rustfmt','--edition','2024',str(p),str(child)],cwd=r,check=True)
(b/'native-module-extraction.json').write_text(json.dumps({'source':str(p.relative_to(r)),'destination':str(child.relative_to(r)),'movedTestNames':['codeql_skips_archived_evidence_but_still_analyses_compiled_code','codeql_rust_lane_pins_the_extractor_sysroot'],'extractedBlocksSha256':[hashlib.sha256(x.encode()).hexdigest() for x in blocks],'parentLines':len(p.read_text().splitlines()),'childLines':len(child.read_text().splitlines()),'nativeExecutionVerified':False,'sourceSizeWarningRemovedLocally':True,'allWarningsResolved':False},indent=2)+'\n')
print('MOVED',len(relocations),'archives; Rust parent',len(p.read_text().splitlines()),'lines; child',len(child.read_text().splitlines()),'lines')
print(subprocess.check_output(['git','diff','--check'],cwd=r,text=True))
