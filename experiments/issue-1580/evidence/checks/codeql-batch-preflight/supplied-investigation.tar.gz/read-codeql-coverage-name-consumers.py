from pathlib import Path
import subprocess
r=Path('/tmp/gh-issue-solver-1794900398048')
for n in ['rust/tests/fixtures/coverage/cold-research-shard-timeout.json','rust/tests/unit/ci-cd/mod.rs']:
 s=(r/n).read_text().splitlines();print('FILE',n,'LINES',len(s));print('\n'.join(f'{i+1}: {v}' for i,v in enumerate(s)))
for args in [['rg','-n','cold-research-shard-timeout|codeql_skips_archived_evidence|codeql_rust_lane_pins','scripts','.github','rust/tests','data/benchmarks']]:
 p=subprocess.run(args,cwd=r,capture_output=True,text=True);print('SEARCH EXIT',p.returncode);print(p.stdout);print(p.stderr)
