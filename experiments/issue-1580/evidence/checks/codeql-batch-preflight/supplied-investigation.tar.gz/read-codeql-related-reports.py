from pathlib import Path
import subprocess,json,gzip
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/checks/codeql-result-gate'
for number in [19835,22755]:
 for label,args in [('issue',['gh','issue','view',str(number),'--repo','github/codeql','--json','title,body,url,state,updatedAt']),('comments',['gh','api','repos/github/codeql/issues/'+str(number)+'/comments','--paginate','--slurp'])]:
  p=subprocess.run(args,cwd=r,capture_output=True);name='upstream-related-'+str(number)+'-'+label
  for field,raw in [('stdout',p.stdout),('stderr',p.stderr)]: (b/(name+'.'+field+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
  print('REQUEST',number,label,'EXIT',p.returncode)
  if p.returncode:print(p.stderr.decode(errors='replace'));continue
  d=json.loads(p.stdout)
  if label=='issue':print(d['title'],d['url'],d['state'],d['body'])
  else:
   for page in d:
    for c in page:print('COMMENT',c['html_url'],c['body'])
