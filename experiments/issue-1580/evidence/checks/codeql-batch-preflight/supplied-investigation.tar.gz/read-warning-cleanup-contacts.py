from pathlib import Path
import subprocess,json
r=Path('/tmp/gh-issue-solver-1794900398048')
for pattern in ['experiments/issue-1580/evidence/checks/registry-batch-preflight/*.json','experiments/issue-1580/evidence/checks/release-io-batch-preflight/*.json']:
 for p in r.glob(pattern):
  text=p.read_text();print('METADATA',p.relative_to(r),len(text));print(text[:14000])
p=r/'rust/tests/unit/ci-cd/step_budgets_within_job_clocks.rs';lines=p.read_text().splitlines()
for start,end in [(1,35),(435,485),(568,630)]:
 print('SOURCE',p.relative_to(r),start,end);print('\n'.join(f'{i+1}: {lines[i]}' for i in range(start-1,min(end,len(lines)))))
p=subprocess.run(['rg','-n','step_budgets_within_job_clocks|security.yml|workflow_dispatch','.github/workflows/security.yml','rust/tests/unit/ci-cd/mod.rs'],cwd=r,capture_output=True,text=True);print(p.stdout+p.stderr)
