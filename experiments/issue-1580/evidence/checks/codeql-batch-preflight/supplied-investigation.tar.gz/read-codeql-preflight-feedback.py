from pathlib import Path
import gzip,json
r=Path('/tmp/gh-issue-solver-1794900398048/experiments/issue-1580/evidence/checks/codeql-batch-preflight')
for n in ['issue-comments','pull-request-comments','pull-request-inline','pull-request-reviews']:
 d=json.loads(gzip.decompress((r/(n+'.stdout.gz')).read_bytes()));print('ENDPOINT',n,'COUNT',len(d))
 for x in d:
  print('COMMENT',x.get('id'),x.get('html_url'),'UPDATED',x.get('updated_at',x.get('submitted_at')));print(x.get('body',''))
