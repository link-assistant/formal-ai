from pathlib import Path
import subprocess,gzip,hashlib,json,os,sys,time,traceback
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/checks/codeql-result-gate/final-validation';scratch=Path('/tmp/issue-1580-research/codeql-result-gate-final-closure')
if len(sys.argv)==1:
 scratch.mkdir(exist_ok=False);b.mkdir(exist_ok=False)
 files=['scripts/ci-pull-request-admission.mjs','rust/tests/web/default-branch-build-policy.test.mjs','rust/tests/unit/workflow_contracts.rs','rust/tests/unit/ci-cd/workflow_fixtures.rs','.github/workflows/security.yml','changelog.d/1580-codeql-result-gate.md','data/benchmarks/fast-pull-request-javascript-tests.json','data/benchmarks/fast-pull-request-retained-jobs.json','rust/tests/unit/ci-cd/step_budgets_within_job_clocks.rs','rust/tests/unit/ci-cd/step_budgets_within_job_clocks/codeql.rs','rust/tests/web/security-codeql-results.test.mjs','scripts/check-codeql-results.mjs','experiments/issue-1580/evidence/checks/registry-batch-preflight','experiments/issue-1580/evidence/checks/release-io-batch-preflight']
 subprocess.run(['git','add','--',*files],cwd=r,check=True)
 identities=[{'file':p,'sha256':hashlib.sha256((r/p).read_bytes()).hexdigest()} for p in files if (r/p).is_file()];(b/'source-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
 with (scratch/'worker.log').open('wb') as out:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=r,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'scratch':str(scratch)}));raise SystemExit(0)
records=[]
try:
 jobs=[('new-codeql-regressions',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/security-codeql-results.test.mjs']),('fast-production-profile',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs']),('maintained-workflow-policy',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/default-branch-build-policy.test.mjs']),('rust-format',['rustfmt','--edition','2024','--check','rust/tests/unit/ci-cd/step_budgets_within_job_clocks.rs','rust/tests/unit/ci-cd/step_budgets_within_job_clocks/codeql.rs','rust/tests/unit/workflow_contracts.rs','rust/tests/unit/ci-cd/workflow_fixtures.rs']),('all-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs']),('diff-check',['git','diff','--check']),('staged-diff-check',['git','diff','--cached','--check'])]
 for label,args in jobs:
  began=time.monotonic();p=subprocess.run(args,cwd=r,capture_output=True,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','PYTHONDONTWRITEBYTECODE':'1'});raw=p.stdout+p.stderr;packed=gzip.compress(raw,mtime=0);name=label+'.log.gz';(b/name).write_bytes(packed);records.append({'label':label,'argv':args,'exitCode':p.returncode,'seconds':round(time.monotonic()-began,3),'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()});(b/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(label,p.returncode,raw.decode(errors='replace')[-3000:],flush=True)
  if p.returncode!=0:raise RuntimeError(label+' failed')
 (b/'verification.json').write_text(json.dumps({'records':records,'nativeCompilationExecuted':False,'liveCodeqlExecuted':False,'allSourceFindingsResolved':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n');(scratch/'outcome.json').write_text(json.dumps({'complete':True,'fullIssueComplete':False})+'\n');print('COMPLETE',flush=True)
except BaseException:
 traceback.print_exc();(scratch/'failure.json').write_text(json.dumps({'complete':False,'traceback':traceback.format_exc()})+'\n');sys.exit(1)
