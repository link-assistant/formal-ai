from pathlib import Path
from datetime import datetime,timezone
import json,gzip,hashlib,re,collections
b=Path('/tmp/gh-issue-solver-1794900398048/experiments/issue-1580/evidence/ci/native-families-c5b68508');d=json.loads((b/'latest.json').read_text());rows=json.loads((b/'records.json').read_text());verified=0
for row in rows:
 assert row['exitCode']==0,row
 for channel in ['stdout','stderr']:
  x=row[channel];packed=(b/x['file']).read_bytes();raw=gzip.decompress(packed);assert hashlib.sha256(raw).hexdigest()==x['rawSha256'];assert hashlib.sha256(packed).hexdigest()==x['archiveSha256'];verified+=1
jobs=[];failures=[];diagnostics=[];native=[]
for p in sorted(b.glob('jobs-*.stdout.gz')):
 data=json.loads(gzip.decompress(p.read_bytes()))
 for j in data.get('jobs',[]):
  jobs.append(j)
  if j.get('conclusion') not in ['success','skipped']:failures.append({'id':j['databaseId'],'name':j['name'],'conclusion':j.get('conclusion')})
for p in sorted(b.glob('job-*.stdout.gz')):
 lines=gzip.decompress(p.read_bytes()).decode(errors='replace').splitlines();summaries=[]
 for i,s in enumerate(lines,1):
  if 'test result:' in s or re.search(r'Ran \d+ tests? in',s) or re.search(r'\btest .*codeql_|\btest .*registry::',s):summaries.append({'line':i,'text':s})
 if summaries:native.append({'file':p.name,'summaries':summaries})
p=b/'failed-run-44692731148.stdout.gz';lines=gzip.decompress(p.read_bytes()).decode(errors='replace').splitlines()
for i,s in enumerate(lines,1):
 if re.search(r'WARNING: .+ has \d+ lines \(approaching',s):diagnostics.append({'line':i,'text':s,'classification':'source file size headroom warning'})
errors=[]
for i,s in enumerate(lines,1):
 if 'AssertionError: 1 != 0' in s or 'Error staging release files:' in s or 'FAILED (failures=' in s or '##[error]' in s:errors.append({'line':i,'text':s})
a={'head':d['head'],'observedAt':datetime.now(timezone.utc).isoformat(),'workflowCount':23,'success':22,'failedWorkflows':d['failed'],'allWorkflowsTerminal':True,'archivedChannelsIdentityVerified':verified,'failedJobs':failures,'failedAggregateFile':p.name,'failedAggregateLines':len(lines),'actionableErrors':errors,'rootCause':'The successful native release CLI reached actual Git staging, but its temporary repository omitted docs/status.md, docs/benchmarks.md and README.md. The terminal pipeline status propagates this failure.','localCorrectionCommit':'14ce8c0995b25024639b860443bd6e315e99023d','correctedNativeCliExecutionVerified':False,'nativeSummaries':native,'sourceSizeWarningsInFailedAggregate':len(diagnostics),'allAggregateLinesLiterallyRead':False,'failedRegistryJobLiterallyRead':True,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(b/'assessment.json').write_text(json.dumps(a,indent=2)+'\n');(b/'source-size-warning-candidates.jsonl').write_text(''.join(json.dumps(x,separators=(',',':'))+'\n' for x in diagnostics))
print(json.dumps({k:v for k,v in a.items() if k!='nativeSummaries'},indent=2))
for x in native:
 print('NATIVE',x['file'])
 for q in x['summaries']: print(q['line'],q['text'])
print('WARNINGS')
for x in diagnostics: print(x['line'],x['text'])
