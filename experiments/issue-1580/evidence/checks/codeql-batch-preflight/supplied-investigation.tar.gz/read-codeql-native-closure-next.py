import subprocess,json,pathlib
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
for name in ['.github/workflows/native-type-check.yml','rust/tests/unit/workflow_contracts.rs','rust/tests/unit/ci-cd/workflow_fixtures.rs','scripts/ci-pull-request-admission.mjs']:
 p=root/name; lines=p.read_text().splitlines(); print('FILE',name,'LINES',len(lines))
 if name.endswith('workflow_fixtures.rs'): ranges=[(1,75)]
 elif name.endswith('ci-pull-request-admission.mjs'): ranges=[(1,100)]
 else:ranges=[(1,min(len(lines),110))]
 for a,b in ranges:
  for i in range(a-1,b): print(f'{i+1}: {lines[i]}')
print(subprocess.run(['git','status','--short'],cwd=root,text=True,capture_output=True).stdout)
