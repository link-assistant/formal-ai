from pathlib import Path
import hashlib
r=Path('/tmp/issue-1580-research/templates/rust-complete')
files=['changelog.d/README.md','experiments/issue-139-multi-language-detect-code-changes.sh','experiments/issue-188-regressions.py','experiments/issue-190-rename-regressions.py','experiments/issue-193-zizmor-inputs.py','experiments/issue-196-fresh-merge.mjs','experiments/issue-196-workflows.mjs','experiments/test-detect-code-changes.sh','experiments/test-issue141-manifest-printf-quoting.sh','experiments/test-issue69-buildx-mirror-fallback.sh','docs/issue-228-analysis.md']
for n in files:
 raw=(r/n).read_bytes();lines=raw.decode().splitlines();print('FILE',n,'LINES',len(lines),'SHA256',hashlib.sha256(raw).hexdigest())
 for i,line in enumerate(lines,1): print(f'{i}: {line}')
