import subprocess,pathlib
r=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
for args in [['rg','-n','mod workflow_contracts|step_budgets_within_job_clocks|pub mod workflow_fixtures','rust/tests'],['rg','-n','workflow_contracts|unit[.]rs|unit/main','rust/Cargo.toml']]:
 q=subprocess.run(args,cwd=r,capture_output=True,text=True);print('COMMAND',args,'EXIT',q.returncode);print(q.stdout);print(q.stderr)
