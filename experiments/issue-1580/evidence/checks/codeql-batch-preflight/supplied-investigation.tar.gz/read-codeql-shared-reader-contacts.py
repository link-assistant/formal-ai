from pathlib import Path
r=Path('/tmp/gh-issue-solver-1794900398048')
for name,start,end in [('rust/tests/unit/ci-cd/step_budgets_within_job_clocks.rs',35,68),('rust/tests/unit/ci-cd/workflow_fixtures.rs',1,105),('rust/tests/unit/ci-cd/step_budgets_within_job_clocks/codeql.rs',1,110),('scripts/ci-pull-request-admission.mjs',180,230)]:
 lines=(r/name).read_text().splitlines();print('FILE',name,'TOTAL',len(lines));print('\n'.join(f'{i+1}: {lines[i]}' for i in range(start-1,min(end,len(lines)))))
