Rust: include_str! can extract an empty literal for an existing nonempty non-Rust file

Observed on CodeQL CLI **2.27.5**, Rust queries **0.1.47**, action **4.39.4**, Rust **1.99**, `build-mode: none`:
[completed Security run 45093409488](https://github.com/link-assistant/formal-ai/actions/runs/45093409488), source [`cec9207c3e139e2212f6d4ea478ff1b88e17be7c`](https://github.com/link-assistant/formal-ai/tree/cec9207c3e139e2212f6d4ea478ff1b88e17be7c).

The actual Rust producer, standard analysis and an additional diagnostic query all finish successfully. Rust SARIF has zero findings and no warning/error invocation notifications. However, a source-bound diagnostic shows `include_str!` literal expansions whose decoded payload is empty although the included source file exists and is nonempty.

A concrete observed case:

- [`rust/src/google_trends_catalog.rs:33`](https://github.com/link-assistant/formal-ai/blob/cec9207c3e139e2212f6d4ea478ff1b88e17be7c/rust/src/google_trends_catalog.rs#L33) contains `include_str!("../embedded/data/seed/google-trends-prompts.lino")`.
- The [included file at that exact commit](https://github.com/link-assistant/formal-ai/blob/cec9207c3e139e2212f6d4ea478ff1b88e17be7c/rust/embedded/data/seed/google-trends-prompts.lino) has 2,372 bytes and SHA-256 `589a2477b200e941d00f819f0f8c0a7b00855f1961d5a22845dbc273f0cd4faa`.
- The actual `IncludedStringPayloads.ql` result at line 33, column 5 is a `StringLiteralExpr` with token text `""`, decoded length zero, and no expansion CFG node.
- The source was not rewritten into an empty stub. Equivalent mismatches occur at handler-promotion and language seed includes.

The query enumerates include-string macro contexts, their expansion states, literal token text and CFG presence. The complete result has 2,108 context rows: 1,854 literal expansions, 253 unexpanded and one other expansion. Comparing only exact immutable source spans with a literal relative path and JSON-compatible quoted token finds **541 context rows with empty expansion of nonempty source**, nine exact source matches, 24 tokens requiring a Rust-specific decoder, 1,279 nonliteral/unbound spans and one unavailable included source. These are context rows, not 541 unique application calls or a measured security-coverage percentage.

The version-matched [CodeQL Cargo manifest](https://github.com/github/codeql/blob/ceeaafac4e629e0e39de04d40c719d7d18b4b612/rust/extractor/Cargo.toml) selects rust-analyzer crates 0.0.358. In those published crate sources, `ra_ap_load-cargo` loads `rs`, `toml` and `md` extensions; `ra_ap_hir_expand`'s `include_str_expand` returns `ExpandResult::ok(quote!(call_site =>""))` if the relative file cannot be loaded. This is consistent with the observed `.lino` mismatch. I have not modified or independently rebuilt the extractor, so this is a source-grounded causal inference, distinct from the actual query result above.

Expected: preserve the actual included bytes in the extracted literal, or report that the payload is unavailable so an empty literal is not mistaken for a faithful expansion. Is there a supported way to load these included files without rewriting application source? If not, please consider demand-loading the exact file for include-string expansion and a regression covering a nonempty arbitrary extension.

Complete original artifacts, query sources, evaluator trace, full workflow log, source-bound comparison script and per-member hashes are retained in this [checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/codeql-cec9207c-checkpoint.md) and its linked archive/manifest. The complete result JSON SHA-256 is `f4c8deba276a13b8804423cef2b4c62c1e536c9395326936547624d5a6140a6e`; its original artifact ID is 14783061566. Reproduction uses the actual pinned application and producer; a reduced independent crate has not been analyzed.

This is separate from the resolved std macro compatibility report #19982, whose closing comment requests distinct remaining cases, and from Actions checkout report #23176. No findings have been dismissed or queries excluded. Investigation: [link-assistant/formal-ai#1580](https://github.com/link-assistant/formal-ai/issues/1580), [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581).
