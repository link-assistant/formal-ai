import hashlib, io, json, tarfile
from pathlib import Path

scratch = Path('/tmp/issue-1580-research')
destination = Path('experiments/issue-1580/evidence/checks/codeql-versioned-includes-20261123')
destination.mkdir(parents=True, exist_ok=True)
archive = destination / 'complete-sources.tar.gz'
assert not archive.exists()
names = ['codeql-2.27.5-source-pin.txt', 'codeql-2.27.5-Cargo.toml',
         'codeql-2.27.5-rust-config.rs', 'ra_ap_hir_expand-0.0.358.crate',
         'ra_ap_load-cargo-0.0.358.crate', 'ra_ap_hir_expand-0.0.358-source.rs',
         'ra_ap_load-cargo-0.0.358-source.rs', 'codeql-included-payload-report.md',
         'seal-codeql-versioned-source.py', 'stale-source-walk-neighbor.log']
records = []
with tarfile.open(archive, 'w:gz', compresslevel=6) as stream:
    for name in names:
        payload = (scratch / name).read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(payload)
        info.mode = 0o644
        stream.addfile(info, io.BytesIO(payload))
        records.append({'path': name, 'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()})
with tarfile.open(archive, 'r:gz') as stream:
    for row in records:
        payload = stream.extractfile(row['path']).read()
        assert len(payload) == row['bytes'] and hashlib.sha256(payload).hexdigest() == row['sha256']
manifest = {'scope': 'Version-matched published CodeQL/rust-analyzer source and proposed upstream report; no independently rebuilt extractor or minimal-crate analysis.',
            'independentAuthorshipCredit': 0, 'roundTripVerified': True,
            'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}, 'files': records}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')

path = Path('docs/case-studies/issue-1580/codeql-cec9207c-checkpoint.md')
body = path.read_text()
start = body.index('Current rust-analyzer [include_str expansion]')
end = body.index('The earlier [macro-expansion issue', start)
body = body[:start] + '''The official CodeQL 2.27.5 tag resolves to
`ceeaafac4e629e0e39de04d40c719d7d18b4b612`. Its
[extractor Cargo manifest](https://github.com/github/codeql/blob/ceeaafac4e629e0e39de04d40c719d7d18b4b612/rust/extractor/Cargo.toml)
selects rust-analyzer crates 0.0.358. The exact published `ra_ap_load-cargo`
source loads extensions `rs`, `toml` and `md` (lines 305–307). The corresponding
`ra_ap_hir_expand` source explicitly returns an empty string when an included
relative file cannot be loaded (lines 890–898). The version-matched config exposes
extra include directories; no supported arbitrary-extension setting was established.
These sources support a causal inference consistent with the actual `.lino`
mismatch. The extractor was not rebuilt, and no reduced independent crate was
analyzed. Full binary dependency identity was not independently proven.

The published crate archives, exact extracted source members, version-matched
CodeQL sources and proposed distinct upstream report are retained with round-trip
hashes in `experiments/issue-1580/evidence/checks/codeql-versioned-includes-20261123/`.
The actual query result above remains the direct evidence; source analysis is not
a replacement for a corrected producer and payload comparison.

''' + body[end:]
path.write_text(body)
path = Path('experiments/issue-1580/work-plan.md')
with path.open('a') as out:
    out.write('''
## Stale capture and complete local replay (2026-11-23)

- [x] Preserve the clean 423be15fc observation: 18 procedure cases pass; 87 gates
  pass, two fail on the evidence manifest size, 54 require hosted context.
- [x] Preserve the entire parsed manifest while compacting its flat records from
  3,462 lines to 541. Original archive bytes and all hashes are unchanged.
- [x] Reproduce a stale contributing capture losing its age warning; repair both
  walkers and pass the two focused procedure controls and seven source-walk cases.
- [x] Pin the CodeQL release source and exact published rust-analyzer 0.0.358
  sources. Distinguish causal inference from the actual included-file mismatch.
- [ ] Run the full 19-case procedure suite and all 143 gates on the next clean
  commit. Preserve every result; refresh main and run queues before a single push.
- [ ] Publish the distinct included-file upstream report with working evidence
  links, qualify next-head CI and both actual native artifact reruns, and finish
  every remaining original criterion. Keep external criteria unfinished and PR draft.
''')
print(json.dumps({'archive': manifest['archive'], 'files': len(records)}))
