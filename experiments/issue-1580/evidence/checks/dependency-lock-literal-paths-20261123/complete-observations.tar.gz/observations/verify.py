from pathlib import Path
import subprocess,json,datetime
r=Path('/tmp/issue-1580-research/dependency-lock-literal-paths')
commands=[('neighbor-dependency-workflow', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/issue-1169-dependencies-latest-workflow.test.mjs']), ('neighbor-publication', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/dependency-update-publication.test.mjs']), ('neighbor-critical-profile', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/ci-fast-critical-profile.test.mjs']), ('neighbor-scope', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/release-workflow-scope-controls.test.mjs']), ('neighbor-compiler-boundary', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/coding-research-compiler-boundary.test.mjs']), ('gate-check-required-documentation', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-required-documentation']), ('gate-check-readable-code', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-readable-code']), ('gate-check-file-size', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-file-size']), ('gate-check-file-size-js-twin', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-file-size-js-twin']), ('gate-check-tests-as-docs', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-tests-as-docs']), ('gate-check-tests-as-documentation-javascript-twin', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-tests-as-documentation-javascript-twin']), ('gate-workflows', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'workflows'])]
results=[]
for name,argv in commands:
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (r/(name+".log")).open("w") as log: p=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
 result={"name":name,"argv":argv,"exitCode":p.returncode,"startedAt":started,"finishedAt":datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (r/(name+".json")).write_text(json.dumps(result,indent=2))
 results.append(result)
(r/"verification-outcome.json").write_text(json.dumps({"complete":True,"allPassed":all(x["exitCode"]==0 for x in results),"checks":results},indent=2))
