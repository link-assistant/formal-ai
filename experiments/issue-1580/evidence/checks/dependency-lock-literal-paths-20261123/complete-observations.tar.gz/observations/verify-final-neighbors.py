from pathlib import Path
import json,subprocess,os
r=Path('/tmp/issue-1580-research/dependency-lock-literal-paths')
environment=dict(os.environ)
environment.pop("NODE_OPTIONS",None)
results=[]
for name,argv in [('final-neighbor-workflow', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/issue-1169-dependencies-latest-workflow.test.mjs']), ('isolated-neighbor-scope', ['node', '--test', '--test-concurrency=1', 'rust/tests/web/release-workflow-scope-controls.test.mjs'])]:
 with (r/(name+".log")).open("w") as log: p=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,env=environment)
 results.append({"name":name,"argv":argv,"exitCode":p.returncode,"nodeOptionsRemoved":True})
(r/"final-neighbors-outcome.json").write_text(json.dumps({"complete":True,"checks":results},indent=2))
