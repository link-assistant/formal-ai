from pathlib import Path
import json,subprocess,os,datetime
r=Path('/tmp/issue-1580-research/dependency-lock-literal-paths')
environment=dict(os.environ)
environment.pop("NODE_OPTIONS",None)
results=[]
for name,argv in [('staged-whitespace', ['git', 'diff', '--cached', '--check']), ('staged-check-required-documentation', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-required-documentation']), ('staged-check-readable-code', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-readable-code']), ('staged-check-file-size', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-file-size']), ('staged-check-file-size-js-twin', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-file-size-js-twin']), ('staged-check-tests-as-docs', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-tests-as-docs']), ('staged-check-tests-as-documentation-javascript-twin', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-tests-as-documentation-javascript-twin']), ('staged-workflows', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'workflows'])]:
 with (r/(name+".log")).open("w") as log: p=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,env=environment)
 result={"name":name,"argv":argv,"exitCode":p.returncode,"nodeOptionsRemoved":True}
 (r/(name+".json")).write_text(json.dumps(result,indent=2))
 results.append(result)
(r/"staged-outcome.json").write_text(json.dumps({"complete":True,"allPassed":all(x["exitCode"]==0 for x in results),"checks":results},indent=2))
