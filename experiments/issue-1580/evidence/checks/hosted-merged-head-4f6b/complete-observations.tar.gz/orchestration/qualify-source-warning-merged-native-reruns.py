import datetime,gzip,hashlib,json,subprocess,time
from pathlib import Path
scratch=Path('/tmp/issue-1580-research')
root=scratch/'source-warning-merged-head-native-reruns'
root.mkdir(exist_ok=False)
repo='link-assistant/formal-ai'
head='4f6b611d6a4e158647dbe04b34e73fd7d149f9d3'
records=[]
def capture(label,command,compress=False):
    result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    for name,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
        path=root/(label+'.'+name+('.gz' if compress else ''))
        path.write_bytes(gzip.compress(raw,mtime=0) if compress else raw)
    records.append({'label':label,'command':command,'exitCode':result.returncode,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdoutSha256':hashlib.sha256(result.stdout).hexdigest()})
    (root/'records.json').write_text(json.dumps(records,indent=2)+'\n')
    result.check_returncode()
    return result.stdout
def api(label,endpoint,paginate=False):
    command=['gh','api','--allow-escape-sequences',endpoint]
    if paginate:command+=['--paginate','--slurp']
    value=json.loads(capture(label,command))
    return value
def snapshot(label,run,attempt):
    directory=root/label
    directory.mkdir(exist_ok=False)
    runvalue=api(label+'-run',f'repos/{repo}/actions/runs/{run}/attempts/{attempt}')
    pages=api(label+'-jobs',f'repos/{repo}/actions/runs/{run}/attempts/{attempt}/jobs?per_page=100',True)
    jobs=[j for page in pages for j in page['jobs']]
    artifacts=api(label+'-artifacts',f'repos/{repo}/actions/runs/{run}/artifacts?per_page=100',True)
    artifacts=[a for page in artifacts for a in page['artifacts']]
    assert runvalue['head_sha']==head and runvalue['run_attempt']==attempt
    assert runvalue['status']=='completed' and runvalue['conclusion']=='success',runvalue
    upload=[a for a in artifacts if a['name']==f'native-contracts-{run}-{attempt}-{head}']
    if attempt<=2:
        assert len(upload)==1 and not upload[0]['expired'] and upload[0]['size_in_bytes']>0,artifacts
    for job in jobs:
        if ('Native contracts (coding-2)' in job['name'] or 'Build native contracts' in job['name'] or 'Compile focused native contracts once' in job['name'] or 'Native contract executables' in job['name']):
            capture(label+'-job-'+str(job['id']),['gh','api','--allow-escape-sequences',f'repos/{repo}/actions/jobs/{job["id"]}/logs'],True)
    value={'source':head,'run':run,'attempt':attempt,'runValue':runvalue,'jobs':jobs,'artifacts':artifacts,'upload':upload,'nativeArchiveDownloadedLocally':False}
    (directory/'snapshot.json').write_text(json.dumps(value,indent=2)+'\n')
    print(json.dumps({'event':'snapshot','attempt':attempt,'jobs':len(jobs),'uploadIds':[a['id'] for a in upload]}),flush=True)
    return value
def wait_complete(run,attempt):
    for observation in range(240):
        value=api(f'attempt-{attempt}-observation-{observation:03}',f'repos/{repo}/actions/runs/{run}')
        assert value['head_sha']==head and value['run_attempt']<=attempt,value
        print(json.dumps({'attempt':attempt,'observation':observation,'observedAttempt':value['run_attempt'],'status':value['status'],'conclusion':value['conclusion']}),flush=True)
        if value['run_attempt']==attempt and value['status']=='completed':
            if value['conclusion']!='success':
                capture(f'attempt-{attempt}-complete-failure',['gh','run','view',str(run),'--repo',repo,'--attempt',str(attempt),'--log'],True)
                raise RuntimeError(f'Actual hosted rerun {attempt} failed: '+str(value['conclusion']))
            return
        time.sleep(30)
    raise RuntimeError('Bounded hosted rerun observation count exhausted')
try:
    cohortpath=scratch/'source-warning-merged-head-ci/outcome.json'
    for observation in range(240):
        if cohortpath.exists():break
        errorpath=scratch/'source-warning-merged-head-ci/collector-error.json'
        if errorpath.exists():raise RuntimeError(errorpath.read_text())
        if observation%4==0:print(json.dumps({'event':'waiting-for-original-cohort','observation':observation}),flush=True)
        time.sleep(30)
    else:raise RuntimeError('Original cohort remains incomplete')
    cohort=json.loads(cohortpath.read_text())
    assert cohort['complete'] and cohort['head']==head and not cohort['failedRuns'],cohort
    pipelines=[r for r in cohort['runs'] if r['workflowName']=='CI/CD Pipeline']
    assert len(pipelines)==1 and pipelines[0]['conclusion']=='success'
    run=pipelines[0]['databaseId']
    original=snapshot('attempt-1',run,1)
    capture('request-full-rerun',['gh','run','rerun',str(run),'--repo',repo])
    wait_complete(run,2)
    full=snapshot('attempt-2',run,2)
    assert original['upload'][0]['id']!=full['upload'][0]['id']
    consumers=[j for j in full['jobs'] if 'Native contracts (coding-2)' in j['name']]
    assert len(consumers)==1 and consumers[0]['conclusion']=='success',[(j['id'],j['name']) for j in full['jobs']]
    consumer=consumers[0]
    capture('request-consumer-only-rerun',['gh','run','rerun',str(run),'--job',str(consumer['id']),'--repo',repo])
    wait_complete(run,3)
    partial=snapshot('attempt-3',run,3)
    assert not partial['upload'],'A consumer-only rerun must not create a new producer upload'
    retained=[a for a in partial['artifacts'] if a['id']==full['upload'][0]['id']]
    assert len(retained)==1 and not retained[0]['expired']
    repeated=[j for j in partial['jobs'] if 'Native contracts (coding-2)' in j['name']]
    assert len(repeated)==1 and repeated[0]['conclusion']=='success' and repeated[0]['id']!=consumer['id']
    capture('attempt-3-consumer-original-log',['gh','api','--allow-escape-sequences',f'repos/{repo}/actions/jobs/{repeated[0]["id"]}/logs'],True)
    outcome={'complete':True,'source':head,'run':run,'fullRerunAttempt':2,'consumerOnlyAttempt':3,'originalArtifactId':original['upload'][0]['id'],'rerunArtifactId':full['upload'][0]['id'],'consumerOriginalJobId':consumer['id'],'consumerRepeatedJobId':repeated[0]['id'],'sameProducerArtifactRetained':True,'nativeArchiveDownloadedLocally':False,'actualFailedConsumerInduced':False,'scope':'Actual full rerun and explicit successful-consumer rerun. This does not claim an induced failed consumer or live package publication. Exact consumer receipt and original logs still require review.','independentAuthorshipCredit':0,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (root/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
    print(json.dumps(outcome),flush=True)
except Exception as error:
    (root/'error.json').write_text(json.dumps({'source':head,'error':str(error),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
    raise
