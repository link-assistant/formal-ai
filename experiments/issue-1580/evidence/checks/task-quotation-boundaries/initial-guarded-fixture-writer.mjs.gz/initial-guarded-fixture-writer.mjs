// Supplied shared-fixture refresh; zero independent authorship credit.
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { WorkerHost } from '../../js/server/worker-host.mjs';
import { installNodeHost } from '../../js/agentic/node-host.mjs';
await installNodeHost(new WorkerHost());
const { CASES, replayCase } = await import('../../rust/tests/web/helpers/issue-1550-meta-executor-cases.mjs');
const file = 'rust/tests/fixtures/meta-executor-parity.json';
const original = JSON.parse(readFileSync(file, 'utf8'));
assert.equal(original.cases.length, 15);
const cases = [];
for (const input of CASES) cases.push({ ...input, expected: await replayCase(input) });
assert.deepEqual(cases.slice(0, original.cases.length), original.cases, 'Every original input, assertion and trace must remain unchanged');
assert.equal(cases.length, 22);
for (const entry of cases.slice(15)) assert.equal(entry.expected.status, 'resolved', entry.name);
writeFileSync(file, JSON.stringify({ ...original, cases }, null, 2) + '\n');
console.log(JSON.stringify({ originalCasesUnchanged: 15, addedCases: cases.slice(15).map((entry) => ({ name: entry.name, leaves: entry.expected.leaves, shape: entry.expected.shape, status: entry.expected.status })) }));
