from pathlib import Path
import json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/current-queue-validation')
base.mkdir(exist_ok=False)
records = []
commands = [
    ('latest-release', ['gh', 'api', 'repos/rhysd/actionlint/releases/latest']),
    ('queue-pull', ['gh', 'api', 'repos/rhysd/actionlint/pulls/654']),
    ('queue-comments', ['gh', 'api', 'repos/rhysd/actionlint/issues/654/comments', '--paginate']),
    ('queue-review-comments', ['gh', 'api', 'repos/rhysd/actionlint/pulls/654/comments', '--paginate']),
    ('queue-reviews', ['gh', 'api', 'repos/rhysd/actionlint/pulls/654/reviews', '--paginate']),
]
for name, argv in commands:
    result = subprocess.run(argv, cwd=root, capture_output=True)
    for label in ['stdout', 'stderr']:
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    assert result.returncode == 0, (name, result.stderr)
(base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
references = [
    'scripts/check-runner-labels.mjs', 'experiments/formal_ai_subagent/local-gates.mjs',
    '.github/workflows/workflows.yml', '.github/workflows/ci.yml',
    'rust/tests/web/ci-pull-request-admission.test.mjs',
]
with (base / 'local-references.txt').open('w') as stream:
    for path in references:
        source = root / path
        if source.exists():
            text = source.read_text()
            stream.write('\nFILE ' + path + ' LINES ' + str(len(text.splitlines())) + '\n' + text + '\n')
        else:
            stream.write('\nMISSING ' + path + '\n')
for name in ['latest-release', 'queue-pull', 'queue-comments', 'queue-review-comments', 'queue-reviews']:
    value = json.loads((base / (name + '.stdout')).read_text())
    if isinstance(value, dict):
        value = {key: value.get(key) for key in ['html_url', 'tag_name', 'published_at', 'state', 'merged', 'updated_at', 'body']}
    else:
        value = [{key: row.get(key) for key in ['html_url', 'state', 'created_at', 'updated_at', 'body']} for row in value]
    (base / (name + '.read.json')).write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({'originalResponsesPreserved': len(records), 'fullIssueComplete': False}))
