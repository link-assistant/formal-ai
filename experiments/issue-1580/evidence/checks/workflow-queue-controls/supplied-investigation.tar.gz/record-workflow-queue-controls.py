from pathlib import Path
import gzip, hashlib, io, json, tarfile, urllib.request

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
destination = root / 'experiments/issue-1580/evidence/checks/workflow-queue-controls'
destination.mkdir(exist_ok=False)
url = 'https://docs.github.com/en/actions/how-tos/write-workflows/choose-when-workflows-run/control-workflow-concurrency'
request = urllib.request.Request(url, headers={'User-Agent': 'formal-ai-issue-1580-source-validation'})
with urllib.request.urlopen(request, timeout=30) as response:
    raw = response.read(2 * 1024 * 1024 + 1)
assert len(raw) <= 2 * 1024 * 1024 and b'cancel-in-progress' in raw and b'queue' in raw
(destination / 'github-concurrency-documentation.html.gz').write_bytes(gzip.compress(raw, mtime=0))
selected = [Path(__file__)]
for name in ['research-current-queue-validation', 'probe-current-actionlint-queue',
    'draft-workflow-queue-controls', 'verify-workflow-queue-controls']:
    selected += [scratch / (name + '.py'), scratch / (name + '.log')]
selected += [scratch / 'workflow-concurrency-admission-search.log', scratch / 'find-concurrency-admission.log']
for folder in ['current-queue-validation', 'actionlint-queue-negative-control', 'workflow-queue-controls']:
    selected += [path for path in (scratch / folder).rglob('*') if path.is_file()
        and path.name != 'actionlint' and path.suffix != '.gz']
buffer = io.BytesIO()
rows = []
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for path in sorted(set(selected)):
        raw = path.read_bytes()
        name = path.relative_to(scratch).as_posix()
        entry = tarfile.TarInfo(name)
        entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
        archive.addfile(entry, io.BytesIO(raw))
        rows.append({'file': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
raw = buffer.getvalue()
packed = gzip.compress(raw, mtime=0)
(destination / 'supplied-investigation.tar.gz').write_bytes(packed)
(destination / 'supplied-investigation.json').write_text(json.dumps({'files': rows,
    'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(),
    'independentAuthorshipCredit': 0, 'fullIssueComplete': False}, indent=2) + '\n')
identity = json.loads((scratch / 'actionlint-queue-negative-control/identity.json').read_text())
(destination / 'assessment.json').write_text(json.dumps({'officialReleaseIdentity': identity,
    'officialActionlintAcceptedInvalidPolicies': 3, 'companionRejectedThosePolicies': True,
    'focusedControlsPassed': 13, 'actualHostedCompanionVerified': False,
    'expressionOutcomesStaticallyProven': False, 'fullIssueComplete': False,
    'independentAuthorshipCredit': 0}, indent=2) + '\n')
(root / 'docs/case-studies/issue-1580/workflow-queue-checkpoint.md').write_text('''# Workflow queue validation checkpoint

The pinned actionlint 1.7.12 schema does not model the documented `concurrency.queue` key. Its narrow unknown-key exception allows valid queues, but also hides invalid queue values and the forbidden `queue: max` with `cancel-in-progress: true` combination. A fresh primary-source check still finds [1.7.12 as the latest release](https://github.com/rhysd/actionlint/releases/tag/v1.7.12) and [the supporting parser PR open](https://github.com/rhysd/actionlint/pull/654). The full PR body, all 14 conversation comments, empty inline/review responses and official release response are retained.

Download the official Linux binary, verify its archive against the release asset digest, and run it against the four retained fixture sources using the actual repository configuration. Valid `max`, invalid `unlimited`, an invalid sequence value, and `max` combined with cancellation all exit zero. This is a reproduced false negative in the exception, independent of shell linting. The probe intentionally disables ShellCheck and Pyflakes because it tests schema only; it earns no shell-validation credit.

`node scripts/check-workflow-concurrency.mjs` now checks queue values at workflow and job scope. It rejects invalid literal types/values and the documented forbidden combination. Expressions retain an explicit requirement for runtime evaluation. Duplicate or malformed YAML and an empty workflow tree fail closed. This small companion check preserves the current pinned Docker linter, every other schema check and its real ShellCheck canary. [GitHub's concurrency reference](https://docs.github.com/en/actions/how-tos/write-workflows/choose-when-workflows-run/control-workflow-concurrency) is the source for the accepted literal values and combination.

All 13 focused controls pass, including a real command run over each original fixture: valid policy succeeds and all three invalid policies now fail. Existing default-branch and documentation-policy suites pass. The official binary also accepts all current workflow schemas. The existing Actionlint job admits the checker and regression using only the already locked isolated YAML parser; changes to those sources select the job. Actual next-head hosted execution remains to be verified. Expression runtime semantics are not inferred from static acceptance.

Original sources, failed/accepted command streams, fresh primary responses, supplied code and resource boundaries are preserved under `experiments/issue-1580/evidence/checks/workflow-queue-controls/`. No Rust, Docker or application build runs locally. Supplied work receives zero independent Formal AI credit. This repair does not complete the eight-template comparison, production delivery, native-source qualification, remaining warnings or whole-PR review; PR #1581 remains draft and unmerged.
''')
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- Fresh actionlint 1.7.12 plus the exact repository exception accepts three invalid concurrency queues. The new general workflow/job companion checker rejects those same original sources, keeps valid queues and explicitly unresolved expressions, and passes 13 focused controls plus existing branch/documentation policies. The actual Actionlint job admits both checker and controls with its existing pinned parser. Hosted next-head execution, dynamic outcomes and broader acceptance remain open.\n')
print('Preserved official-binary false negatives and passing companion controls; actual hosted execution remains open.')
