from pathlib import Path
import json

root = Path('/tmp/gh-issue-solver-1794900398048')
script = root / 'scripts/check-workflow-concurrency.mjs'
test = root / 'experiments/issue-1580/workflow-concurrency.test.mjs'
assert not script.exists() and not test.exists()
script.write_text(r'''#!/usr/bin/env node
// Qualify the concurrency.queue key that actionlint 1.7.12 cannot model.
// Keep its narrow unknown-key exception and all other schema/shell checks.
// Expressions are observations requiring runtime evaluation, not invalid literals.
import {readFileSync, readdirSync} from 'node:fs';
import {dirname, join, resolve} from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import YAML from 'yaml';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const expression = value => typeof value === 'string' && /\$\{\{\s*\S[\s\S]*?\}\}/u.test(value);
const mapping = value => value !== null && typeof value === 'object' && !Array.isArray(value);

export function checkSource(file, source) {
  const observations = [], problems = [];
  let workflow;
  try {
    const document = YAML.parseDocument(source);
    if (document.errors.length) throw new Error(document.errors.map(error => error.message).join('; '));
    workflow = document.toJS({maxAliasCount: 100});
    if (!mapping(workflow)) throw new Error('workflow must be a mapping');
  } catch (error) {
    return {observations, problems: [{file, scope: 'workflow', message: error.message}]};
  }
  const scopes = [['workflow', workflow.concurrency]];
  for (const [name, job] of Object.entries(mapping(workflow.jobs) ? workflow.jobs : {}))
    scopes.push(['job ' + name, job?.concurrency]);
  for (const [scope, concurrency] of scopes) {
    if (!mapping(concurrency) || !Object.hasOwn(concurrency, 'queue')) continue;
    const queue = concurrency.queue;
    const dynamicQueue = expression(queue);
    const cancellation = concurrency['cancel-in-progress'];
    const dynamicCancellation = expression(cancellation);
    const problem = message => problems.push({file, scope, message});
    if (typeof queue !== 'string' || (!dynamicQueue && !['max', 'single'].includes(queue))) {
      problem('concurrency.queue must be max, single, or an expression');
      continue;
    }
    if (queue === 'max' && (cancellation === true || cancellation === 'true'))
      problem('concurrency.queue max cannot be combined with cancel-in-progress true');
    observations.push({file, scope, queue,
      qualification: dynamicQueue || dynamicCancellation ? 'requires-runtime-evaluation' : 'literal'});
  }
  return {observations, problems};
}

export function checkRepository(root = ROOT) {
  const directory = join(root, '.github/workflows');
  const files = readdirSync(directory, {withFileTypes: true})
    .filter(entry => entry.isFile() && /\.ya?ml$/u.test(entry.name))
    .map(entry => '.github/workflows/' + entry.name).sort();
  const observations = [], problems = [];
  for (const file of files) {
    const result = checkSource(file, readFileSync(join(root, file), 'utf8'));
    observations.push(...result.observations);
    problems.push(...result.problems);
  }
  if (!files.length) problems.push({file: directory, scope: 'repository', message: 'no workflow sources checked'});
  return {files, observations, problems};
}

function main(arguments_) {
  if (arguments_.length > 1) {
    console.error('usage: node scripts/check-workflow-concurrency.mjs [ROOT]');
    return 2;
  }
  try {
    const result = checkRepository(arguments_.length ? resolve(arguments_[0]) : ROOT);
    for (const {file, scope, message} of result.problems)
      console.error(file + ': ' + scope + ': ' + message);
    if (result.problems.length) return 1;
    const unresolved = result.observations.filter(row => row.qualification === 'requires-runtime-evaluation').length;
    console.log('Workflow concurrency: ' + result.files.length + ' files, ' + result.observations.length +
      ' queue policies; ' + unresolved + ' require runtime evaluation.');
    return 0;
  } catch (error) {
    console.error('Workflow concurrency: ' + error.message);
    return 1;
  }
}
if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url)
  process.exitCode = main(process.argv.slice(2));
''')
test.write_text(r'''import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {spawnSync} from 'node:child_process';
import YAML from 'yaml';
import {checkSource, checkRepository} from '../../scripts/check-workflow-concurrency.mjs';

const source = (queue, cancellation = false, scope = 'workflow') => YAML.stringify({
  name: 'Queue validity control', on: 'push',
  ...(scope === 'workflow' ? {concurrency: {group: 'control', queue, 'cancel-in-progress': cancellation}} : {}),
  jobs: {control: {'runs-on': 'ubuntu-24.04',
    ...(scope === 'job' ? {concurrency: {group: 'control', queue, 'cancel-in-progress': cancellation}} : {}),
    steps: [{run: 'true'}]}}
});

for (const scope of ['workflow', 'job']) {
  test(scope + ' permits both documented queue values with cancellation disabled', () => {
    for (const queue of ['single', 'max']) {
      const result = checkSource('control.yml', source(queue, false, scope));
      assert.deepEqual(result.problems, []);
      assert.equal(result.observations.length, 1);
      assert.equal(result.observations[0].qualification, 'literal');
    }
  });
  test(scope + ' rejects unknown literal values and non-string queue nodes', () => {
    for (const queue of ['unlimited', 'Max', '', null, true, 100, ['max'], {value: 'max'}, '${{ broken']) {
      const result = checkSource('control.yml', source(queue, false, scope));
      assert.equal(result.problems.length, 1, JSON.stringify(queue));
      assert.match(result.problems[0].message, /must be max, single, or an expression/u);
    }
  });
  test(scope + ' rejects the documented max and true combination including quoted true', () => {
    for (const cancellation of [true, 'true'])
      assert.match(checkSource('control.yml', source('max', cancellation, scope)).problems[0].message,
        /cannot be combined/u);
    assert.deepEqual(checkSource('control.yml', source('single', true, scope)).problems, []);
  });
  test(scope + ' preserves unknown expression outcomes rather than rejecting them as literals', () => {
    for (const [queue, cancellation] of [
      ['${{ inputs.queue }}', true], ['max', '${{ inputs.cancel }}'],
      ['ma${{ inputs.suffix }}', false]
    ]) {
      const result = checkSource('control.yml', source(queue, cancellation, scope));
      assert.deepEqual(result.problems, []);
      assert.equal(result.observations[0].qualification, 'requires-runtime-evaluation');
    }
  });
}

test('omitted queue, scalar concurrency, and unrelated nested data retain actionlint ownership', () => {
  for (const concurrency of [undefined, 'release', {group: 'release'}, {group: 'release', queu: 'max'}]) {
    const result = checkSource('control.yml', YAML.stringify({concurrency,
      env: {queue: 'unlimited'}, jobs: {control: {steps: [{run: 'echo queue: max'}]}}}));
    assert.deepEqual(result.problems, []);
    assert.equal(result.observations.length, 0);
  }
});

test('malformed documents and duplicate queue keys fail closed', () => {
  for (const text of ['concurrency: [', '- workflow', 'concurrency:\n  queue: max\n  queue: single\n'])
    assert(checkSource('control.yml', text).problems.length > 0);
});

test('real command refuses invalid workflow sources and an empty repository', {timeout: 10000}, () => {
  const root = mkdtempSync(join(tmpdir(), 'formal-ai-workflow-queue-'));
  try {
    const directory = join(root, '.github/workflows');
    mkdirSync(directory, {recursive: true});
    const invoke = () => spawnSync(process.execPath, ['scripts/check-workflow-concurrency.mjs', root], {encoding: 'utf8'});
    assert.equal(invoke().status, 1);
    for (const [queue, cancellation, expected] of [
      ['max', false, 0], ['unlimited', false, 1], ['max', true, 1], [['single', 'max'], false, 1]
    ]) {
      writeFileSync(join(directory, 'control.yml'), source(queue, cancellation));
      const result = invoke();
      assert.equal(result.status, expected, result.stdout + result.stderr);
    }
  } finally { rmSync(root, {recursive: true, force: true}); }
});

test('all current workflow sources have explicit queue qualification', () => {
  const result = checkRepository();
  assert(result.files.length > 0);
  assert(result.observations.length > 0);
  assert.deepEqual(result.problems, []);
});

test('actual linter job admits the companion check and controls with locked parser inputs', () => {
  const workflow = YAML.parse(readFileSync('.github/workflows/workflows.yml', 'utf8'));
  const steps = workflow.jobs.actionlint.steps;
  assert(steps.some(step => step.run === 'node scripts/check-workflow-concurrency.mjs'));
  assert(steps.some(step => step.run === 'node --test --test-concurrency=1 experiments/issue-1580/workflow-concurrency.test.mjs'));
  assert(steps.some(step => step.uses === 'actions/setup-node@v7' && step.with['node-version'] === '22'));
  assert(steps.some(step => step.run?.includes('npm ci --ignore-scripts --no-audit --no-fund --prefix scripts/documentation-policy-dependencies')));
  const sparse = steps[0].with['sparse-checkout'];
  for (const path of ['/scripts/check-workflow-concurrency.mjs', '/experiments/issue-1580/workflow-concurrency.test.mjs',
    '/scripts/documentation-policy-dependencies/', '/package.json']) assert(sparse.includes(path), path);
  for (const trigger of [workflow.on.push, workflow.on.pull_request]) {
    for (const path of ['scripts/check-workflow-concurrency.mjs', 'experiments/issue-1580/workflow-concurrency.test.mjs',
      'scripts/documentation-policy-dependencies/**']) assert(trigger.paths.includes(path), path);
  }
  assert(steps.some(step => step.uses?.startsWith('docker://rhysd/actionlint@sha256:')));
  assert(steps.some(step => step.run?.includes('shellcheck-canary.yml')));
});
''')
workflow = root / '.github/workflows/workflows.yml'
text = workflow.read_text()
before = "'experiments/issue-1580/buildkit-bootstrap-probe.py']"
after = "'experiments/issue-1580/buildkit-bootstrap-probe.py', 'scripts/check-workflow-concurrency.mjs', 'experiments/issue-1580/workflow-concurrency.test.mjs', 'scripts/documentation-policy-dependencies/**']"
assert text.count(before) == 2
text = text.replace(before, after)
before = '            /rust/tests/fixtures/actionlint/\n'
after = before + '            /scripts/check-workflow-concurrency.mjs\n            /experiments/issue-1580/workflow-concurrency.test.mjs\n            /scripts/documentation-policy-dependencies/\n            /package.json\n'
assert text.count(before) == 2
text = text.replace(before, after, 1)
marker = '      # The image bundles ShellCheck and pyflakes, so this lints every `run:`\n'
assert text.count(marker) == 1
text = text.replace(marker, '''      # The upstream schema still rejects queue. Qualify its values and the
      # forbidden cancellation combination separately, using only the locked parser.
      - uses: actions/setup-node@v7
        with:
          node-version: '22'
      - run: npm ci --ignore-scripts --no-audit --no-fund --prefix scripts/documentation-policy-dependencies
      - run: |
          mkdir -p node_modules
          ln -s ../scripts/documentation-policy-dependencies/node_modules/yaml node_modules/yaml
      - run: node scripts/check-workflow-concurrency.mjs
      - run: node --test --test-concurrency=1 experiments/issue-1580/workflow-concurrency.test.mjs

''' + marker)
workflow.write_text(text)
config = root / '.github/actionlint.yaml'
text = config.read_text()
marker = '      # GitHub supports `concurrency.queue`; actionlint\'s embedded schema lags.\n'
assert text.count(marker) == 1
config.write_text(text.replace(marker, marker + '      # scripts/check-workflow-concurrency.mjs validates the suppressed values.\n'))
(root / 'changelog.d/issue-1580-concurrency-queue-validation.md').write_text('Validate workflow and job concurrency queue values and reject max with cancellation enabled beside the pinned actionlint schema exception. Keep expression outcomes explicitly unresolved and preserve the Docker ShellCheck canary.\n')
print(json.dumps({'companionCheckerDrafted': True, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}))
