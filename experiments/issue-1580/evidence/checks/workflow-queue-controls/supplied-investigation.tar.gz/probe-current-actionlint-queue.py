from pathlib import Path
import gzip, hashlib, io, json, os, subprocess, tarfile, urllib.request

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
base = scratch / 'actionlint-queue-negative-control'
base.mkdir(exist_ok=False)
release = json.loads((scratch / 'current-queue-validation/latest-release.stdout').read_text())
assets = {row['name']: row for row in release['assets']}
name = 'actionlint_1.7.12_linux_amd64.tar.gz'
asset = assets[name]
request = urllib.request.Request(asset['browser_download_url'], headers={'User-Agent': 'formal-ai-issue-1580-source-validation'})
with urllib.request.urlopen(request, timeout=30) as response:
    raw = response.read(16 * 1024 * 1024 + 1)
assert len(raw) <= 16 * 1024 * 1024 and len(raw) == asset['size']
digest = hashlib.sha256(raw).hexdigest()
assert asset['digest'] == 'sha256:' + digest
(base / name).write_bytes(raw)
with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
    entry = archive.getmember('actionlint')
    assert entry.isfile() and entry.size < 64 * 1024 * 1024
    executable = archive.extractfile(entry).read()
binary = base / 'actionlint'
binary.write_bytes(executable)
binary.chmod(0o755)
fixture = base / 'fixture'
workflow_directory = fixture / '.github/workflows'
workflow_directory.mkdir(parents=True)
config = root / '.github/actionlint.yaml'
(fixture / '.github/actionlint.yaml').write_bytes(config.read_bytes())
records = []
cases = [('valid-max', 'max', 'false'), ('invalid-value', 'unlimited', 'false'),
    ('invalid-combination', 'max', 'true'), ('invalid-type', '[single, max]', 'false')]
for label, queue, cancellation in cases:
    source = ('name: Queue schema control\non: push\nconcurrency:\n  group: queue-control\n  queue: ' + queue +
        '\n  cancel-in-progress: ' + cancellation + '\njobs:\n  control:\n    runs-on: ubuntu-24.04\n    steps:\n      - run: true\n')
    path = workflow_directory / 'control.yml'
    path.write_text(source)
    (base / (label + '.yml')).write_text(source)
    argv = [str(binary), '-no-color', '-shellcheck=', '-pyflakes=', '-config-file', '.github/actionlint.yaml', '.github/workflows/control.yml']
    result = subprocess.run(argv, cwd=fixture, capture_output=True)
    for field in ['stdout', 'stderr']:
        (base / (label + '.' + field)).write_bytes(getattr(result, field))
    records.append({'case': label, 'argv': argv, 'exitCode': result.returncode,
        'expectedGitHubAcceptance': label == 'valid-max'})
(base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
(base / 'identity.json').write_text(json.dumps({'officialRelease': release['html_url'],
    'releaseAssetSha256': digest, 'releaseAssetDigestVerified': True,
    'binarySha256': hashlib.sha256(executable).hexdigest(), 'configurationSha256': hashlib.sha256(config.read_bytes()).hexdigest(),
    'scope': 'schema only; ShellCheck and Pyflakes intentionally disabled for no shell/Python findings',
    'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
print(json.dumps(records, indent=2))
