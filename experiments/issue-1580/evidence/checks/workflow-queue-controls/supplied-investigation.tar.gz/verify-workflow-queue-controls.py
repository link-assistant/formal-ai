from pathlib import Path
import json, os, subprocess, sys, traceback

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
base = scratch / 'workflow-queue-controls'
if len(sys.argv) == 1:
    base.mkdir(exist_ok=False)
    with (base / 'worker.log').open('wb') as stream:
        child = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root,
            stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': child.pid, 'scratch': str(base)}))
    sys.exit(0)
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
records = []
def run(name, argv, expected=0):
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
    for label in ['stdout', 'stderr']:
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode, 'expectedExitCode': expected})
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == expected, (name, result.stdout[-2500:], result.stderr[-1000:])
    print(name, 'EXPECTED', expected, flush=True)
try:
    run('focused', ['timeout', '600', 'node', '--test', '--test-reporter=tap', '--test-concurrency=1',
        'experiments/issue-1580/workflow-concurrency.test.mjs'])
    run('default-branch-policy', ['timeout', '600', 'node', '--test', '--test-reporter=tap', '--test-concurrency=1',
        'rust/tests/web/default-branch-build-policy.test.mjs'])
    run('documentation-policy', ['timeout', '600', 'node', '--test', '--test-reporter=tap', '--test-concurrency=1',
        'rust/tests/web/documentation-only-ci-policy.test.mjs'])
    run('repository', ['node', 'scripts/check-workflow-concurrency.mjs'])
    run('original-actionlint-schema', [str(scratch / 'actionlint-queue-negative-control/actionlint'),
        '-no-color', '-verbose', '-shellcheck=', '-pyflakes='])
    fixture = scratch / 'actionlint-queue-negative-control/fixture'
    for name, expected in [('valid-max', 0), ('invalid-value', 1), ('invalid-combination', 1), ('invalid-type', 1)]:
        (fixture / '.github/workflows/control.yml').write_bytes((scratch / 'actionlint-queue-negative-control' / (name + '.yml')).read_bytes())
        run('companion-' + name, ['node', 'scripts/check-workflow-concurrency.mjs', str(fixture)], expected)
    run('whitespace', ['git', 'diff', '--check'])
    (base / 'outcome.json').write_text(json.dumps({'complete': True, 'passed': True,
        'originalActionlintAcceptedInvalidPolicies': 3, 'companionRejectsThosePolicies': True,
        'dockerShellCheckActualExecutionLocal': False, 'fullIssueComplete': False}, indent=2) + '\n')
except BaseException:
    traceback.print_exc()
    (base / 'failure.json').write_text(json.dumps({'complete': False, 'traceback': traceback.format_exc()}) + '\n')
    sys.exit(1)
