from pathlib import Path
import subprocess,json,datetime,os
root=Path('/tmp/issue-1580-research/apt-first-mirror-final-checks');records=[]
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
commands=[('experiment-syntax',['node','--check','experiments/issue-1580/container-apt-startup-control.mjs']),('whitespace',['git','diff','--check'])]
gates=['check-file-size','check-file-size-js-twin','check-readable-code','check-required-documentation','check-tests-as-docs','check-tests-as-documentation-javascript-twin','check-changelog-fragment-js-twin','release#1','check-closure-audit','check-generated-files','layered-ci#1','release#2']
commands += [('gate-'+g,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',g]) for g in gates]
for label,cmd in commands:
 env=dict(os.environ,BASE_REF='bc08222b5a5195dc9992c0459bde2b6369377b9f')
 with (root/(label+'.log')).open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,env=env)
 records.append({'label':label,'command':cmd,'exitCode':r.returncode});(root/'progress.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records[-1]),flush=True)
(root/'outcome.json').write_text(json.dumps({'head':head,'records':records,'allPassed':all(r['exitCode']==0 for r in records),'complete':True,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
