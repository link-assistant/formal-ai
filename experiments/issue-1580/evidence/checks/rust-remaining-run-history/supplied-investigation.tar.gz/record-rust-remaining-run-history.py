from pathlib import Path
import datetime, gzip, hashlib, io, json, tarfile

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
source = scratch / 'templates/rust-complete'
read_root = scratch / 'rust-remaining-run-history'
rows = json.loads((read_root / 'identities.json').read_text())
inventory = {row['path']: row for row in json.loads((root / 'experiments/issue-1580/evidence/checks/rust-template-first-gate/pinned-file-identities.json').read_text())}
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert data['fullyReadFiles'] == 332 and len(rows) == 7
manifest = root / data['readLogManifest']
records = json.loads(manifest.read_text())
for row in rows:
    path = row['path']
    assert path not in {item['path'] for item in data['files']}
    raw = (source / path).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    lines = len(raw.decode().splitlines())
    assert digest == row['sha256'] == inventory[path]['sha256']
    assert lines == row['sourceLines'] == 1
    read = (read_root / row['readFile']).read_bytes()
    assert json.loads(read.decode().split('\n', 2)[2]) == json.loads(raw)
    name = 'remaining-run-history-' + row['readFile'] + '.gz'
    packed = gzip.compress(read, mtime=0)
    assert not (manifest.parent / name).exists()
    (manifest.parent / name).write_bytes(packed)
    records.append({'file': name, 'rawSha256': hashlib.sha256(read).hexdigest(),
        'archiveSha256': hashlib.sha256(packed).hexdigest()})
    data['files'].append({'path': path, 'lines': lines, 'sha256': digest,
        'readLogs': [name], 'literalReadRanges': [[1, lines]], 'literalReadLines': lines,
        'literalSourceFullyRead': True, 'formalAiPracticeImplementationVerified': False})
manifest.write_text(json.dumps(records, indent=2) + '\n')
data['files'].sort(key=lambda row: row['path'])
data['fullyReadFiles'] = len(data['files'])
data['fullyReadSourceLines'] = sum(row['literalReadLines'] for row in data['files'])
assert data['fullyReadFiles'] == 339 and data['fullyReadSourceLines'] == 39016
data['observedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
data['practiceDecisions'].append({
    'practice': 'Distinguish green prerequisite metadata from actual publication and documentation outcomes',
    'templateEvidence': [row['path'] for row in rows],
    'assessment': 'Read all seven complete pinned JSON values, including every job and step. Rust issue 247 is historical dependency-update context, not an additional required issue of Formal AI issue 1580. On the same November 14 template head, pipeline metadata records failure in Cargo manifest warnings and three operating-system test jobs; Security records audit and strict Rust SARIF gate failures despite a successful analyzer step. These records do not reveal the original diagnostics. April main run 24465255225 and downstream run 24983875003 fail before release version collection and skip documentation. Downstream run 24985948212 reaches version collection failure after a successful bump while independently building and deploying documentation. May pull-request run 25212295127 succeeds with publication, documentation, lint and coverage skipped; it cannot prove those paths. Current Formal AI preserves strict aggregate and report validation, and has behavioral Pages admission controls for failed/skipped publishers. Actual hosted fallback, served revision identity, publication correctness and original archived failure diagnostics remain open.',
    'status': 'complete-historical-metadata-read-hosted-publication-and-original-diagnostics-open',
    'formalAiPaths': ['.github/workflows/release.yml', '.github/workflows/pages-artifact.yml',
        '.github/workflows/security.yml', 'experiments/issue-1580/pages-release-failure.test.mjs'],
    'verification': 'experiments/issue-1580/evidence/checks/rust-remaining-run-history/assessment.json'})
ledger.write_text(json.dumps(data, indent=2) + '\n')
destination = root / 'experiments/issue-1580/evidence/checks/rust-remaining-run-history'
destination.mkdir(exist_ok=False)
selected = [Path(__file__), scratch / 'read-rust-remaining-run-history.py',
    scratch / 'read-rust-remaining-run-history.log']
selected += [path for path in read_root.iterdir() if path.is_file()]
buffer = io.BytesIO()
identities = []
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for path in sorted(selected):
        raw = path.read_bytes()
        name = path.relative_to(scratch).as_posix()
        item = tarfile.TarInfo(name)
        item.size, item.mode, item.mtime = len(raw), 0o644, 0
        archive.addfile(item, io.BytesIO(raw))
        identities.append({'file': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
raw = buffer.getvalue()
packed = gzip.compress(raw, mtime=0)
(destination / 'supplied-investigation.tar.gz').write_bytes(packed)
(destination / 'supplied-investigation.json').write_text(json.dumps({'files': identities,
    'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(),
    'independentAuthorshipCredit': 0, 'fullIssueComplete': False}, indent=2) + '\n')
(destination / 'assessment.json').write_text(json.dumps({'literalPinnedFilesRead': 339,
    'literalPinnedSourceLinesRead': 39016, 'sourceFiles': rows,
    'metadataIsOriginalFailureDiagnosis': False, 'metadataIsCurrentRuntimeVerification': False,
    'allTemplatePracticesAdopted': False, 'fullIssueComplete': False,
    'independentAuthorshipCredit': 0}, indent=2) + '\n')
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- Fully read seven remaining pinned Rust issue/run JSON values, including every nested job/step: review is 339/373 files and 39,016 original source lines. Preserve the distinction between successful PR prerequisites, failed main publication and an actually successful independent downstream documentation deployment. Original diagnostic streams, current hosted fallback/publication and all broader acceptance remain open.\n')
print(json.dumps({'literalFilesRead': 339, 'literalSourceLinesRead': 39016,
    'fullIssueComplete': False, 'independentAuthorshipCredit': 0}))
