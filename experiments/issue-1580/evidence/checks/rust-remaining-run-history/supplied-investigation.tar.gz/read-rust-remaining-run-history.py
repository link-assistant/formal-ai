from pathlib import Path
import hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
source = Path('/tmp/issue-1580-research/templates/rust-complete')
destination = Path('/tmp/issue-1580-research/rust-remaining-run-history')
destination.mkdir(exist_ok=False)
paths = ['dev/log/issues/247/pulls/248/' + name for name in ['issue.json', 'main-pipeline.json', 'main-security.json']]
paths += ['docs/case-studies/issue-38/raw-data/' + name for name in [
    'downstream-meta-after-run-24985948212.json', 'downstream-meta-before-run-24983875003.json',
    'main-run-24465255225.json', 'pr-run-25212295127.json']]
inventory = {row['path']: row for row in json.loads((root / 'experiments/issue-1580/evidence/checks/rust-template-first-gate/pinned-file-identities.json').read_text())}
rows = []
for path in paths:
    raw = (source / path).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert inventory[path]['sha256'] == digest
    value = json.loads(raw)
    rendered = json.dumps(value, indent=2, ensure_ascii=False)
    name = Path(path).name + '.read.txt'
    (destination / name).write_text('Pinned source: ' + path + '\nSHA256: ' + digest + '\n' + rendered + '\n')
    rows.append({'path': path, 'sha256': digest, 'sourceLines': len(raw.decode().splitlines()),
        'renderedLines': len(rendered.splitlines()), 'readFile': name})
(destination / 'identities.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows, indent=2))
