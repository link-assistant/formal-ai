import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
import {checkListedFiles} from '/tmp/gh-issue-solver-1794900398048/scripts/check-file-size.mjs';
const listing = spawnSync('git', ['ls-files', '-z', '--cached', '--others', '--exclude-standard'],
  {encoding:'utf8', maxBuffer:16*1024*1024});
if (listing.status !== 0) throw new Error(listing.stderr);
const paths = new Set(listing.stdout.split('\0').filter(Boolean));
const results = checkListedFiles(process.cwd(), paths);
const output = {selection:'maintained CLI committablePaths equivalent', paths:paths.size, results};
writeFileSync('/tmp/issue-1580-research/current-committable-source-size-findings.json', JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify(output));
