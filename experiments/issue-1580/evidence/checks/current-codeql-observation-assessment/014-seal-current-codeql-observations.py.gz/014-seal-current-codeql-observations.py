from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
producer = root / 'experiments/issue-1580/evidence/ci/codeql-producer-27e895c1'
assessment = json.loads((producer / 'macro-observation-assessment.json').read_text())
assert assessment['macroRows'] == 122574
assert assessment['includedStringRows'] == 2179
assert assessment['positionalCrosswalkCounts'] == {'unexpanded-contexts': 631}
findings = json.loads((scratch / 'current-committable-source-size-findings.json').read_text())
assert len(findings['results']['warnings']) == 92
assert findings['results']['violations'] == findings['results']['embeddedDataViolations'] == []
archive = root / 'experiments/issue-1580/evidence/checks/current-codeql-observation-assessment'
assert not archive.exists()
stems = ['verify-current-codeql-producer', 'assess-current-codeql-observations',
         'scan-current-committable-source-warnings', 'scan-current-all-source-size-findings',
         'seal-current-codeql-observations']
sources = {p for stem in stems for p in scratch.glob(stem + '*') if p.is_file()}
sources.update(scratch / name for name in ['current-committable-source-size-findings.json',
                                          'current-all-source-size-findings.json'])
for p in (root / 'experiments/issue-1580/evidence/commands').glob('*.json'):
    command = json.loads(p.read_text())
    if any(stem in command.get('request', '') for stem in stems):
        sources.add(p)
archive.mkdir()
inventory = []
for number, p in enumerate(sorted(sources), 1):
    raw = p.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    name = f'{number:03d}-' + p.name + '.gz'
    (archive / name).write_bytes(packed)
    assert gzip.decompress((archive / name).read_bytes()) == raw
    inventory.append({'source': str(p), 'file': name, 'bytes': len(raw),
                      'lines': len(raw.splitlines()), 'rawSha256': hashlib.sha256(raw).hexdigest(),
                      'archiveSha256': hashlib.sha256(packed).hexdigest()})
parts = []
for first in range(0, len(inventory), 35):
    name = f'inventory-{first // 35 + 1:02d}.json'
    raw = (json.dumps(inventory[first:first + 35], indent=2) + '\n').encode()
    (archive / name).write_bytes(raw)
    parts.append({'file': name, 'records': len(inventory[first:first + 35]),
                  'sha256': hashlib.sha256(raw).hexdigest()})
(archive / 'inventory.json').write_text(json.dumps({'records': len(inventory), 'parts': parts}, indent=2) + '\n')
outcome = {'observedAt': datetime.now(timezone.utc).isoformat(), 'publishedHead': assessment['head'],
    'runId': assessment['runId'], 'allProducerIdentitiesVerified': True,
    'producerFiles': 142, 'commandStreams': 22, 'macroRows': 122574,
    'includedStringRows': 2179, 'warningErrorNotifications': 0,
    'maintainedSourceSizeWarnings': 92, 'sourceSizeViolations': 0,
    'initialAssessmentVocabularyMismatchRetained': True,
    'unfilteredSourceInventoryIncludesFiveIgnoredSeedCopies': True,
    'aggregateLiteralReviewComplete': False, 'allMacroSemanticsQualified': False,
    'independentAuthorshipCredit': 0, 'fullIssueComplete': False}
(archive / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
checkpoint = '''# Successful hosted security observers, 2026-11-21

Published head `27e895c1103926b4f73862c0eb15fa77fb505089` completes
[Security run 44860038851](https://github.com/link-assistant/formal-ai/actions/runs/44860038851).
All 142 downloaded producer payloads equal their retained compressed originals;
their bytes, newlines, raw/compressed hashes and source identity verify. The
22 retained command streams also verify. The two original SARIF reports have
zero findings, zero warning/error execution notifications and successful
invocations. Rust retains informational diagnostics, including all 631 original
unexpanded macro positions. Aggregate identity verification and structured
assessment do not claim literal reading of every retained line.

Both opt-in queries compile and evaluate with their unchanged four-minute
step bounds, two threads, 4 GiB policy and resolved 2,607 MiB loading heap.
Neither emits query runtime diagnostics. The macro-context query takes
26.1 seconds to compile and 59.3 seconds to evaluate. Its 122,574 rows span
2,232 source paths: 42,436 expanded outside another expansion, 79,507 expanded
inside one, and 631 unexpanded outside one. Every original SARIF position
matches the final category. This is positional correspondence, with no
individual child-to-expansion semantic or dataflow qualification.

The included-string query takes 22.3 seconds to compile and 3m30s to evaluate.
Its 2,179 rows span 258 source paths. Of these, 1,930 have literal expansions:
266 have CFG nodes and 1,664 do not. Another 248 are unexpanded without CFG
nodes, while one nonliteral expansion has a CFG node. Original complete
literal text remains in the retained table. A partitioned position inventory
records every row's literal byte count/hash, source coordinates and explicit
expansion/CFG states. Neither a payload string nor a CFG node establishes
complete per-child security semantics. No local CodeQL execution is claimed.

These observations qualify hosted execution after removing the duplicate
inverse option. They do not establish cache eviction as the earlier timeout's
cause. The observer's finite execution budget and strict security gate stay
unchanged. The first assessment helper used state names that differed from
the retained query's actual vocabulary; its assertion failed before writing
assessment output. The corrected retry uses the query's literal state names.
Both attempts are retained separately and earn zero independent reasoning
credit.

The maintained committable-path source scanner still reports 92 warnings and
zero ordinary/embedded-data violations. An initial scan without that maintained
selection included five ignored seed copies and reported 97 warnings; it is
retained as an observation of a different input set, not a product regression.
No scanner limits or exclusions change. Source warnings, complete template
practices, original/live acceptance and final PR review remain unfinished.
The PR stays draft and unmerged.

Evidence: `experiments/issue-1580/evidence/ci/codeql-producer-27e895c1/` and
`experiments/issue-1580/evidence/checks/current-codeql-observation-assessment/`.
'''
(root / 'docs/case-studies/issue-1580/successful-security-observers-checkpoint.md').write_text(checkpoint)
readme = root / 'experiments/issue-1580/codeql-macro-contexts/README.md'
text = readme.read_text()
text += '''

Hosted qualification on `27e895c1` now succeeds in [Security run
44860038851](https://github.com/link-assistant/formal-ai/actions/runs/44860038851).
All 142 producer payloads match the downloaded originals. Both original SARIF
reports have zero findings and zero warning/error notifications. Both observers
complete without runtime diagnostics, with the resolved 2,607 MiB loading heap.
The macro table contains 122,574 rows; all 631 original positions remain
unexpanded. The included-string table contains 2,179 rows: 1,930 literal
expansions (266 with CFG nodes), 248 unexpanded calls and one other expansion
with a CFG node. The complete literal payload table and partitioned position
hashes remain under `../evidence/ci/codeql-producer-27e895c1/`. These observations
qualify the actual option repair and profile execution; per-child semantic
qualification remains open. The earlier cache-eviction explanation is still an
inference. See the [dated assessment](../../../docs/case-studies/issue-1580/successful-security-observers-checkpoint.md).
'''
readme.write_text(text)
plan = root / 'experiments/issue-1580/work-plan.md'
text = plan.read_text()
marker = '## Current verification checkpoint\n\n'
assert text.count(marker) == 1
text = text.replace(marker, marker + 'Successful current-head security observers: [hosted assessment](../../docs/case-studies/issue-1580/successful-security-observers-checkpoint.md). Both original SARIF reports and both opt-in profiles complete; 631 unexpanded positions and per-child semantics remain explicit. The maintained scanner retains 92 warnings and zero violations.\n\n', 1)
text = text.replace('its final Pipeline and Security results are still being collected before the next push.', 'its final Pipeline results are still being collected before the next push.', 1)
plan.write_text(text)
print(json.dumps(outcome, indent=2))
