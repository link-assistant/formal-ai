from collections import Counter
from pathlib import Path
import gzip, hashlib, json, re

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/ci/codeql-producer-27e895c1'
outcome = json.loads((base / 'outcome.json').read_text())
assert outcome['complete'] and outcome['captureComplete']
assert outcome['conclusion'] == 'success'
inventory = json.loads((base / 'producer-files.json').read_text())
files = []
for part in inventory['parts']:
    content = (base / part['file']).read_bytes()
    assert hashlib.sha256(content).hexdigest() == part['sha256']
    files.extend(json.loads(content))
assert len(files) == inventory['records'] == 142
lookup = {row['relativePath']: row for row in files}

def raw(path):
    row = lookup[path]
    packed = (base / row['file']).read_bytes()
    assert hashlib.sha256(packed).hexdigest() == row['archiveSha256']
    value = gzip.decompress(packed)
    assert hashlib.sha256(value).hexdigest() == row['rawSha256']
    assert len(value) == row['bytes']
    return value

def table(path, width):
    item = lookup[path]
    digest = hashlib.sha256()
    byte_count = line_count = 0
    header = ''
    table_open = table_closed = root_closed = False
    with gzip.open(base / item['file'], 'rb') as stream:
        for line in stream:
            digest.update(line)
            byte_count += len(line)
            line_count += 1
            text = line.decode().strip()
            if not table_open:
                header += line.decode()
                if re.search(r'"tuples"\s*:\s*\[\s*$', header):
                    empty = json.loads(header + ']}}')
                    assert len(empty['#select']['columns']) == width
                    table_open = True
                continue
            if text == ']}}':
                assert not table_closed
                table_closed = root_closed = True
                continue
            if table_closed:
                assert text == '}}' and not root_closed
                root_closed = True
                continue
            record = text.removeprefix(',')
            row, end = json.JSONDecoder().raw_decode(record)
            suffix = record[end:].strip()
            assert suffix in ['', ']', ']}}'], repr(suffix)
            if suffix:
                table_closed = True
                root_closed = suffix == ']}}'
            assert len(row) == width and isinstance(row[0], dict)
            yield row
    assert table_open and table_closed and root_closed
    assert digest.hexdigest() == item['rawSha256']
    assert byte_count == item['bytes'] and line_count == item['lines']

reports, notes = {}, []
for path in ['rust.sarif', 'actions.sarif']:
    report = json.loads(raw(path))
    levels = Counter()
    executions = []
    for run in report['runs']:
        for invocation in run.get('invocations', []):
            executions.append(invocation.get('executionSuccessful'))
            for note in invocation.get('toolExecutionNotifications', []):
                levels[note.get('level', 'warning')] += 1
                if path == 'rust.sarif' and note.get('descriptor', {}).get('id') == 'rust/diagnostics/unresolved-macro-calls':
                    notes.append(note)
    reports[path] = {
        'sha256': lookup[path]['rawSha256'],
        'results': sum(len(run.get('results', [])) for run in report['runs']),
        'toolExecutionNotificationLevels': dict(levels),
        'warningErrorNotifications': levels['warning'] + levels['error'],
        'allInvocationsSuccessful': bool(executions) and all(executions),
    }
assert len(notes) == 631
targets = {}
for number, note in enumerate(notes):
    assert len(note['locations']) == 1
    physical = note['locations'][0]['physicalLocation']
    region = physical['region']
    key = (physical['artifactLocation']['uri'], region['startLine'], region.get('startColumn', 1))
    targets.setdefault(key, []).append({'notification': number, 'region': region})
matches = {key: [] for key in targets}
states, paths = Counter(), Counter()
macro_rows = 0
for row in table('macro-contexts/macro-contexts.json', 8):
    assert row[6] in ['expanded', 'unexpanded']
    assert row[7] in ['inside-expansion', 'outside-expansion']
    macro_rows += 1
    states[row[6] + ':' + row[7]] += 1
    paths[row[1]] += 1
    key = (row[1], row[2], row[3])
    if key in matches:
        matches[key].append({'entity': row[0], 'path': row[1], 'startLine': row[2],
            'startColumn': row[3], 'endLine': row[4], 'endColumn': row[5],
            'expansion': row[6], 'enclosing': row[7]})
crosswalk, classifications = [], Counter()
for key, original in targets.items():
    found = matches[key]
    expanded = any(row['expansion'] == 'expanded' for row in found)
    unexpanded = any(row['expansion'] == 'unexpanded' for row in found)
    category = 'mixed-contexts' if expanded and unexpanded else 'expanded-contexts' if expanded else 'unexpanded-contexts' if unexpanded else 'no-exact-start-match'
    classifications[category] += len(original)
    crosswalk.append({'path': key[0], 'startLine': key[1], 'startColumn': key[2],
        'originalNotifications': original, 'classification': category, 'observedContexts': found})

payloads, payload_states, payload_paths = [], Counter(), Counter()
for row in table('included-string-payloads/included-string-payloads.json', 9):
    assert row[6] in ['literal-expansion', 'other-expansion', 'unexpanded']
    assert row[8] in ['expansion-has-cfg-node', 'no-expansion-cfg-node']
    assert isinstance(row[7], str)
    literal = row[7].encode()
    payload_states[row[6] + ':' + row[8]] += 1
    payload_paths[row[1]] += 1
    payloads.append({'entity': row[0], 'path': row[1], 'startLine': row[2],
        'startColumn': row[3], 'endLine': row[4], 'endColumn': row[5],
        'expansion': row[6], 'controlFlow': row[8],
        'payloadBytes': len(literal), 'payloadSha256': hashlib.sha256(literal).hexdigest()})

profiles = {}
for profile, filename, query, rows in [
    ('macro-contexts', 'macro-contexts.json', 'MacroContexts.ql', macro_rows),
    ('included-string-payloads', 'included-string-payloads.json', 'IncludedStringPayloads.ql', len(payloads)),
]:
    manifest = json.loads(raw(profile + '/manifest.json'))
    assert manifest['complete'] and manifest['rows'] == rows
    assert manifest['result']['sha256'] == lookup[profile + '/' + filename]['rawSha256']
    assert manifest['query']['sha256'] == hashlib.sha256((root / 'experiments/issue-1580/codeql-macro-contexts' / query).read_bytes()).hexdigest()
    assert manifest['semanticCoverageProven'] is False
    assert manifest['queryRuntimeDiagnostics'] == []
    stderr = raw(profile + '/query.stderr').decode()
    assert not any('WARNING:' in line or 'ERROR:' in line for line in stderr.splitlines())
    assert json.loads(raw(profile + '/memory.stdout')) == manifest['resolvedMemory']['arguments']
    assert manifest['resolvedMemory']['totalMiB'] == 4096
    assert manifest['resolvedMemory']['offHeapMiB'] == 0
    assert 2048 <= manifest['resolvedMemory']['heapMiB'] <= 4096
    commands = {command['name']: command for command in manifest['commands']}
    for name in ['memory', 'query']:
        assert '--ram=4096' in commands[name]['argv']
        assert '--off-heap-ram=0' in commands[name]['argv']
    assert all(command['exitCode'] == 0 for command in manifest['commands'])
    profiles[profile] = {'rows': rows, 'resolvedMemory': manifest['resolvedMemory'],
        'queryRuntimeDiagnostics': [], 'queryCompiledAndExecuted': True,
        'queryStderr': stderr.splitlines(), 'resultSha256': manifest['result']['sha256']}
assert all(report['results'] == 0 and report['warningErrorNotifications'] == 0 and report['allInvocationsSuccessful'] for report in reports.values())
assessment = {'head': outcome['head'], 'runId': outcome['runId'], 'url': outcome['url'],
    'reports': reports, 'profiles': profiles, 'macroRows': macro_rows,
    'macroSourceFiles': len(paths), 'expansionStates': dict(states),
    'originalNotifications': len(notes), 'distinctOriginalPositions': len(targets),
    'positionalCrosswalkCounts': dict(classifications),
    'includedStringRows': len(payloads), 'includedStringSourceFiles': len(payload_paths),
    'includedStringStates': dict(payload_states),
    'allMacroSemanticsQualified': False, 'fullIssueComplete': False,
    'independentAuthorshipCredit': 0}
(base / 'macro-observation-assessment.json').write_text(json.dumps(assessment, indent=2) + '\n')
(base / 'macro-observation-position-crosswalk.json').write_text(json.dumps(crosswalk, separators=(',', ':')) + '\n')
parts = []
for index in range(0, len(payloads), 100):
    path = base / ('included-string-position-%02d.json' % (index // 100 + 1))
    path.write_text(json.dumps(payloads[index:index + 100], separators=(',', ':')) + '\n')
    parts.append({'file': path.name, 'records': len(payloads[index:index + 100]),
                  'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
(base / 'included-string-positions.json').write_text(json.dumps({'records': len(payloads), 'parts': parts}, indent=2) + '\n')
print(json.dumps(assessment, indent=2))
