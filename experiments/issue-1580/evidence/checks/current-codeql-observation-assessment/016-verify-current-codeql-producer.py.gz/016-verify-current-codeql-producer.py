from pathlib import Path
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/ci/codeql-producer-27e895c1'
original = Path('/tmp/issue-1580-research/bd6-ci-repair-producer-original-reports/download')
index = json.loads((base / 'producer-files.json').read_text())
files = []
for part in index['parts']:
    raw = (base / part['file']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == part['sha256']
    rows = json.loads(raw)
    assert len(rows) == part['records']
    files.extend(rows)
assert len(files) == index['records'] == 142
reports = []
profiles = []
for row in files:
    packed = base / row['file']
    digest = hashlib.sha256()
    with packed.open('rb') as stream:
        while chunk := stream.read(65536):
            digest.update(chunk)
    assert digest.hexdigest() == row['archiveSha256'], row['file']
    raw_digest = hashlib.sha256()
    byte_count = newline_count = 0
    last = b''
    source = original / str(row['artifact']['id']) / row['relativePath']
    with gzip.open(packed, 'rb') as retained, source.open('rb') as downloaded:
        while chunk := retained.read(65536):
            assert downloaded.read(len(chunk)) == chunk, row['relativePath']
            raw_digest.update(chunk)
            byte_count += len(chunk)
            newline_count += chunk.count(b'\n')
            last = chunk[-1:]
        assert downloaded.read(1) == b''
    assert raw_digest.hexdigest() == row['rawSha256'] and byte_count == row['bytes']
    assert newline_count + int(bool(last) and last != b'\n') == row['lines']
    assert row['artifact']['workflow_run']['head_sha'] == '27e895c1103926b4f73862c0eb15fa77fb505089'
    if row['relativePath'].endswith('.sarif'):
        report = json.loads(gzip.decompress(packed.read_bytes()))
        reports.append({'path': row['relativePath'], 'sha256': row['rawSha256'],
                        'version': report['version'],
                        'runs': [{'results': len(run.get('results', [])),
                                  'tool': run['tool']['driver']['name'],
                                  'invocations': [{'executionSuccessful': invocation.get('executionSuccessful'),
                                                   'notifications': len(invocation.get('toolExecutionNotifications', []))}
                                                  for invocation in run.get('invocations', [])]}
                                 for run in report['runs']]})
    if row['relativePath'].endswith(('macro-contexts.json', 'included-string-payloads.json')):
        value = json.loads(gzip.decompress(packed.read_bytes()))
        profiles.append({'path': row['relativePath'], 'sha256': row['rawSha256'],
                         'topLevelKeys': list(value) if isinstance(value, dict) else None})
records = json.loads((base / 'records.json').read_text())
for record in records:
    for key in ['stdout', 'stderr']:
        row = record[key]
        packed = (base / row['file']).read_bytes()
        raw = gzip.decompress(packed)
        assert hashlib.sha256(packed).hexdigest() == row['archiveSha256']
        assert hashlib.sha256(raw).hexdigest() == row['rawSha256']
        assert len(raw) == row['bytes'] and len(raw.splitlines()) == row['lines']
summary = {'head': '27e895c1103926b4f73862c0eb15fa77fb505089',
           'runId': 44860038851, 'verifiedOriginalPayloads': len(files),
           'verifiedCommandStreams': len(records) * 2, 'reports': reports,
           'profiles': profiles, 'wholeAggregateLogLiterallyReviewed': False,
           'macroChildSemanticSecurityQualified': False,
           'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
(base / 'identity-verification.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
