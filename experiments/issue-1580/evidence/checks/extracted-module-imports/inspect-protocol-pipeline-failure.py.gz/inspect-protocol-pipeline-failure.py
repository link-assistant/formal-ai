from pathlib import Path
import subprocess, sys
base = Path('/tmp/issue-1580-research')
source = (base / 'inspect-protocol-layered-failure.py').read_text()
source = source.replace('protocol-layered-failure', 'protocol-pipeline-failure').replace('44843761720', '44843761970')
target = base / 'inspect-protocol-pipeline-failure-worker.py'
target.write_text(source)
subprocess.run([sys.executable, str(target)], check=True)
