from pathlib import Path
import gzip, json, re
base = Path('/tmp/issue-1580-research/protocol-pipeline-failure')
state = json.loads(gzip.decompress((base / 'state.stdout.gz').read_bytes()))
print(json.dumps({'head': state['headSha'], 'failedJobs': [
    {'id': item['databaseId'], 'name': item['name'], 'url': item['url']} for item in state['jobs']
    if item['conclusion'] == 'failure']}, indent=2))
lines = gzip.decompress((base / 'full-log.stdout.gz').read_bytes()).decode().splitlines()
plain = [re.sub(r'\x1b\[[0-9;]*m', '', line) for line in lines]
hits = []
for i, line in enumerate(plain):
    if 'Rust compile inputs changed' not in line:
        continue
    if re.search(r'error\[E[0-9]+\]|warning: unused import|error: could not compile', line):
        hits.extend(range(max(0, i-1), min(len(lines), i+17)))
for i in sorted(set(hits)):
    print(str(i+1) + ': ' + plain[i])
(base / 'native-error-context.txt').write_text('\n'.join(str(i+1) + ': ' + plain[i] for i in sorted(set(hits))) + '\n')
