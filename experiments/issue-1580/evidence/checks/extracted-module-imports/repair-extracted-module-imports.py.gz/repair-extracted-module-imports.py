from pathlib import Path
import gzip, hashlib, json, os, re, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
out = root / 'experiments/issue-1580/evidence/checks/extracted-module-imports'
out.mkdir(exist_ok=False)
records = []
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
def run(name, argv):
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
    record = {'name': name, 'argv': argv, 'exitCode': result.returncode}
    for label, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
        packed = gzip.compress(raw, mtime=0)
        file = name + '.' + label + '.gz'
        (out / file).write_bytes(packed)
        record[label] = {'file': file, 'sha256': hashlib.sha256(raw).hexdigest(),
            'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())}
    records.append(record)
    (out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, (name, result.stdout.decode(errors='replace')[-2000:], result.stderr.decode(errors='replace')[-2000:])
    return result
seed = root / 'rust/src/seed.rs'
protocol = root / 'rust/src/protocol.rs'
before = {str(path.relative_to(root)): path.read_bytes() for path in [seed, protocol]}
text = seed.read_text()
old = 'use parser::{LinoNode, escape_value, find_closing_quote, parse_codepoint, unescape_value};'
new = 'use parser::{\n    LinoNode, escape_value, find_closing_quote, parse_codepoint, split_pipe_list, unescape_value,\n};'
assert text.count(old) == 1 and text.count('split_pipe_list(') == 7
seed.write_text(text.replace(old, new))
text = protocol.read_text()
old = 'use crate::engine::{\n    SymbolicAnswer, ThinkingStep, estimate_tokens, render_thinking_steps, stable_id,\n};'
new = 'use crate::engine::{SymbolicAnswer, estimate_tokens, render_thinking_steps, stable_id};'
assert text.count(old) == 1 and text.count('ThinkingStep') == 1
protocol.write_text(text.replace(old, new))
run('rustfmt', ['rustfmt', '--edition', '2024', str(seed), str(protocol)])
run('rustfmt-check', ['rustfmt', '--edition', '2024', '--check', str(seed), str(protocol)])
run('projection-currency', ['node', 'scripts/translate-js-rust.mjs', '--verify'])
run('whitespace', ['git', 'diff', '--check'])
run('review-diff', ['git', 'diff', '--', 'rust/src/seed.rs', 'rust/src/protocol.rs'])
source = Path('/tmp/issue-1580-research/protocol-pipeline-failure')
for name in ['state.stdout.gz', 'state.stderr.gz', 'full-log.stdout.gz', 'full-log.stderr.gz', 'native-error-context.txt']:
    (out / ('failed-run-' + name)).write_bytes((source / name).read_bytes())
raw = gzip.decompress((source / 'full-log.stdout.gz').read_bytes()).decode()
# Keep every job's actual diagnostic, including -D warnings in the lint job.
clean = re.sub(r'\x1b\[[0-9;]*m', '', raw)
errors = []
for number, line in enumerate(clean.splitlines(), 1):
    if 'error[E0425]' in line or 'unused import:' in line or 'error: could not compile' in line:
        errors.append({'line': number, 'message': line})
(out / 'all-native-diagnostics.json').write_text(json.dumps(errors, indent=2) + '\n')
identities = []
for name, raw in before.items():
    identities.append({'path': name, 'beforeSha256': hashlib.sha256(raw).hexdigest(),
        'afterSha256': hashlib.sha256((root / name).read_bytes()).hexdigest()})
(out / 'verification.json').write_text(json.dumps({'complete': True, 'failingRun': 44843761970,
    'failingHead': 'd48b09883ac91cd1d2319bea2afbaf0df2df8f86',
    'diagnosticCount': len(errors), 'firstMissingImportLine': 42913, 'unusedParentImportLine': 42990,
    'sourceIdentities': identities, 'nativeCompilationPerformedLocally': False,
    'hostedCompilationAfterRepair': 'pending', 'fullIssueComplete': False,
    'independentAuthorshipCredit': 0}, indent=2) + '\n')
print(json.dumps({'complete': True, 'diagnosticsRetained': len(errors), 'localChecks': len(records),
    'nativeCompilationAfterRepair': 'pending hosted CI'}))
