from pathlib import Path
import subprocess,json,os,time
out=Path('/tmp/issue-1580-research/6903-ci-repair-validation')
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','FORMAL_AI_OFFLINE':'1','FORMAL_AI_LIVE_FETCH':'0'}
prior=Path('/tmp/issue-1580-research/supporting-source-batch-validation/outcome.json')
for n in range(180):
 if prior.exists():break
 time.sleep(10)
else:raise RuntimeError('prior focused validation not terminal within finite observation bound')
commands=[
 ('source-callbacks',['node','--test','--test-concurrency=1','rust/tests/web/recipe-source-callbacks.test.mjs']),
 ('included-string',['node','--test','--test-concurrency=1','experiments/issue-1580/codeql-included-string-observation.test.mjs']),
 ('security-codeql',['node','--test','--test-concurrency=1','rust/tests/web/security-codeql-results.test.mjs']),
 ('public-release',['node','--test','--test-concurrency=1','rust/tests/web/verify-public-release-downloads.test.mjs']),
 ('workflow-policy',['node','--test','--test-concurrency=1','rust/tests/web/default-branch-build-policy.test.mjs']),
 ('native-projection',['node','scripts/translate-js-rust.mjs','--verify']),
 ('typescript-projection',['node','scripts/translate-ts.mjs','--check']),
 ('whitespace',['git','diff','--check']),
]
rows=[]
for name,args in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 rows.append({'name':name,'args':args,'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3)})
 (out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
(out/'outcome.json').write_text(json.dumps({'complete':True,'passed':all(row['exitCode']==0 for row in rows),'checks':rows},indent=2)+'\n')
