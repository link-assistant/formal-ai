from pathlib import Path
import subprocess,json,hashlib
out=Path('/tmp/issue-1580-research/6903-final-ci-review');out.mkdir(exist_ok=True)
names=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+['experiments/issue-1580/workflow-checkout-retry.test.mjs']
rows=[]
for name in names:
 if name in ['docs/status.md','experiments/issue-1580/work-plan.md']:continue
 if name=='experiments/issue-1580/workflow-checkout-retry.test.mjs': data=Path(name).read_bytes()
 else:data=subprocess.check_output(['git','diff','--',name])
 p=out/(str(len(rows)+1).zfill(3)+'-'+name.replace('/','--')+'.diff');p.write_bytes(data)
 rows.append({'source':name,'path':str(p),'sha256':hashlib.sha256(data).hexdigest(),'sourceSha256':hashlib.sha256(Path(name).read_bytes()).hexdigest(),'lines':len(data.splitlines())})
(out/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
