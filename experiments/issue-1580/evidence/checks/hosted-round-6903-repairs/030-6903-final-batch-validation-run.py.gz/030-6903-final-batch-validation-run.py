from pathlib import Path
import subprocess,json,os,time
out=Path('/tmp/issue-1580-research/6903-final-batch-validation')
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','FORMAL_AI_OFFLINE':'1','FORMAL_AI_LIVE_FETCH':'0'}
commands=[
 ('public-release',['node','--test','--test-concurrency=1','rust/tests/web/verify-public-release-downloads.test.mjs']),
 ('zizmor-transport',['node','--test','--test-concurrency=1','experiments/issue-1580/zizmor-transport.test.mjs']),
 ('eight-step-failure',['node','experiments/issue-1580/native-hive-fixture-probe.mjs','Scala','--physical-edits','--verifier-result=failure','--steps=8']),
 ('typescript-projection',['node','scripts/translate-es.mjs','--check']),
 ('seed-sync',['bash','scripts/sync-seed.sh','--check']),
 ('rust-format',['rustfmt','--edition','2024','--check','rust/src/agentic_coding/command_reroute.rs','rust/src/agentic_coding/command_reroute/recipe_execution.rs','rust/src/agentic_coding/recipe_resume.rs','rust/tests/unit/issue_1133_hive_mind_three_runs/extended.rs','rust/tests/unit/ci-cd/pinned_tool_images/image_policy.rs']),
 ('render-status',['node','scripts/render-status.mjs','--write']),
 ('all-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs']),
 ('native-projection',['node','scripts/translate-js-rust.mjs','--verify']),
 ('whitespace',['git','diff','--check']),
]
rows=[]
for name,args in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 rows.append({'name':name,'command':args,'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3)})
 (out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
 if name=='eight-step-failure' and p.returncode==0:
  result=json.loads((out/(name+'.log')).read_text());steps=result['steps'];assert len(steps)==8 and steps[-1].get('final') and 'scalac' in steps[-1]['final']
  summary=[{'turn':step['turn'],'tool':step.get('call',{}).get('tool'),'path':step.get('call',{}).get('arguments',{}).get('path'),'final':step.get('final')} for step in steps]
  (out/'eight-step-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'outcome.json').write_text(json.dumps({'complete':True,'passed':all(row['exitCode']==0 for row in rows),'checks':rows,'independentAuthorshipCredit':0},indent=2)+'\n')
