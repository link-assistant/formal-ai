from pathlib import Path
import subprocess,json,os,time
out=Path('/tmp/issue-1580-research/6903-checkout-final-verification')
commands=[
 ('checkout-guard',['node','--test','--test-concurrency=1','experiments/issue-1580/workflow-checkout-retry.test.mjs']),
 ('workflow-policy',['node','--test','--test-concurrency=1','rust/tests/web/default-branch-build-policy.test.mjs']),
 ('workflow-concurrency',['node','scripts/check-workflow-concurrency.mjs']),
 ('typescript-projection',['node','scripts/translate-es.mjs','--check']),
 ('rust-format',['rustfmt','--edition','2024','--check','rust/src/agentic_coding/command_reroute.rs','rust/src/agentic_coding/command_reroute/recipe_execution.rs','rust/src/agentic_coding/recipe_resume.rs','rust/tests/unit/issue_1133_hive_mind_three_runs/extended.rs','rust/tests/unit/ci-cd/pinned_tool_images/image_policy.rs']),
 ('whitespace',['git','diff','--check']),
]
rows=[];env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','FORMAL_AI_OFFLINE':'1','FORMAL_AI_LIVE_FETCH':'0'}
for name,args in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env)
 rows.append({'name':name,'command':args,'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3)})
 (out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
(out/'outcome.json').write_text(json.dumps({'complete':True,'passed':all(x['exitCode']==0 for x in rows),'checks':rows,'independentAuthorshipCredit':0},indent=2)+'\n')
