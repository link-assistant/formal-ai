from pathlib import Path
import subprocess

source = Path('/tmp/issue-1580-research/collect-next-security-reports.py').read_text()
source = source.replace('import gzip, hashlib, json, subprocess, sys, traceback', 'import gzip, hashlib, json, subprocess, sys, time, traceback')
source = source.replace('next-security-original-reports', 'macro-producer-original-reports')
source = source.replace('codeql-producer-3bb3083b', 'codeql-producer-39196d1f')
old = """    selected = json.loads((Path('/tmp/issue-1580-research/next-repair-hosted') / 'outcome.json').read_text())
    head = selected['head']
    rid = selected['run']['databaseId']"""
new = """    head = '39196d1fb218d0ef492f90915270f9ae3ac28ba1'
    dispatch = Path('/tmp/issue-1580-research/macro-batch-publication/dispatch-security.stdout').read_text().strip()
    rid = int(dispatch.rsplit('/', 1)[1])
    latest = root / 'experiments/issue-1580/evidence/ci/native-families-39196d1f/latest.json'
    finished = False
    for tick in range(120):
        if latest.exists():
            observed = json.loads(latest.read_text())
            assert observed['head'] == head
            found = [row for row in observed['runs'] if row['databaseId'] == rid]
            if found and found[0]['status'] == 'completed':
                finished = True
                break
        time.sleep(30)
    assert finished, 'Existing finite CI observer has not recorded producer completion'"""
assert old in source
source = source.replace(old, new)
source = source.replace("'headSha,status,conclusion,jobs,url,createdAt,updatedAt'", "'event,headSha,status,conclusion,jobs,url,createdAt,updatedAt'")
source = source.replace("and state['conclusion'] == 'success'", "and state['event'] == 'workflow_dispatch'")
source = source.replace("if not artifact['name'].startswith('codeql-results-'):", "if not artifact['name'].startswith(('codeql-results-', 'codeql-rust-contexts-')):")
target = Path('/tmp/issue-1580-research/collect-macro-producer-reports.py')
target.write_text(source)
result = subprocess.run(['python3', str(target)], capture_output=True)
Path('/tmp/issue-1580-research/start-macro-producer-report-collection.stdout').write_bytes(result.stdout)
Path('/tmp/issue-1580-research/start-macro-producer-report-collection.stderr').write_bytes(result.stderr)
assert result.returncode == 0
print(result.stdout.decode())
