from pathlib import Path
import gzip, hashlib, json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/checks/split-script-suite-admission'
base.mkdir(exist_ok=False)
environment = dict(os.environ)
environment.pop('NODE_OPTIONS', None)
records = []
def run(name, argv):
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
    row = {'name':name, 'argv':argv, 'exitCode':result.returncode}
    for label in ('stdout', 'stderr'):
        raw = getattr(result,label)
        packed = gzip.compress(raw, mtime=0)
        filename = name + '.' + label + '.gz'
        (base / filename).write_bytes(packed)
        row[label] = {'file':filename, 'rawSha256':hashlib.sha256(raw).hexdigest(), 'archiveSha256':hashlib.sha256(packed).hexdigest(), 'bytes':len(raw), 'lines':len(raw.splitlines())}
    records.append(row)
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == 0, (name, result.stdout.decode(errors='replace')[-4000:], result.stderr.decode(errors='replace')[-1000:])
    return result

for name, file in [('native-groups','experiments/issue-1580/native-regression-groups.test.mjs'), ('default-branch-policy','rust/tests/web/default-branch-build-policy.test.mjs'), ('script-selection','rust/tests/web/script-suite-selection.test.mjs')]:
    result = run(name, ['timeout','600','node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1',file])
    print('\n'.join(result.stdout.decode().splitlines()[-9:]), flush=True)
run('locked-script-metadata',['cargo','metadata','--manifest-path','experiments/issue-1580/release-registry/Cargo.toml','--locked','--offline','--no-deps','--format-version','1'])
run('gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-ci-speed,check-runner-labels,check-readable-code,check-file-size,check-abbreviations'])
run('whitespace',['git','diff','--check'])
paths = ['.github/workflows/native-type-check.yml','experiments/issue-1580/native-regression-groups.test.mjs','experiments/issue-1580/release-registry/Cargo.toml','experiments/issue-1580/release-registry/Cargo.lock','rust/tests/web/default-branch-build-policy.test.mjs','scripts/ci-pull-request-admission.mjs']
(base/'source-identities.json').write_text(json.dumps([{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in paths], indent=2)+'\n')
print('Complete: focused JavaScript tests, locked metadata, five gates and whitespace pass; Rust execution remains hosted-only. Independent credit: 0.')
