from pathlib import Path
import json, subprocess
base = Path('/tmp/issue-1580-research/macro-security-dispatch-jobs')
base.mkdir(exist_ok=False)
dispatch = Path('/tmp/issue-1580-research/macro-batch-publication/dispatch-security.stdout').read_text().strip()
run_id = dispatch.rsplit('/', 1)[1]
result = subprocess.run(['gh', 'run', 'view', run_id, '--repo', 'link-assistant/formal-ai', '--json', 'event,headSha,status,conclusion,jobs,url'], capture_output=True)
(base / 'jobs.stdout').write_bytes(result.stdout)
(base / 'jobs.stderr').write_bytes(result.stderr)
assert result.returncode == 0
state = json.loads(result.stdout)
assert state['headSha'] == '39196d1fb218d0ef492f90915270f9ae3ac28ba1'
assert state['event'] == 'workflow_dispatch'
for row in state['jobs']:
    print(row['databaseId'], row['name'], row['status'], row['conclusion'])
    for step in row['steps']:
        if 'macro' in step['name'].lower() or 'codeql' in step['name'].lower():
            print('  ', step['name'], step['conclusion'])
