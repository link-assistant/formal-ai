from pathlib import Path
import os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/script-suite-admission')
base.mkdir(exist_ok=False)
env = dict(os.environ)
env.pop('NODE_OPTIONS', None)
argv = ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-reporter=tap', '--test-concurrency=1', '--test-name-pattern=the lightweight script job executes', 'experiments/issue-1580/native-regression-groups.test.mjs']
result = subprocess.run(argv, cwd=root, env=env, capture_output=True)
(base / 'before.stdout').write_bytes(result.stdout)
(base / 'before.stderr').write_bytes(result.stderr)
assert result.returncode == 1 and b'# fail 1' in result.stdout
assert b'assemble_requirements' in result.stdout
print('The new admission regression fails against the published manifest/workflow as expected; complete streams retained.')
