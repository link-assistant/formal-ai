from pathlib import Path
import json

root = Path('/tmp/gh-issue-solver-1794900398048')
archive = root / 'experiments/issue-1580/evidence/ci/codeql-producer-39196d1f'
assessment = json.loads((archive / 'macro-observation-assessment.json').read_text())
assert assessment['macroRows'] == 122534 and assessment['originalNotifications'] == 631
document = root / 'docs/case-studies/issue-1580/hosted-macro-observation-checkpoint.md'
document.write_text('''# Hosted macro observation checkpoint

The optional query compiled and executed on published `39196d1fb218d0ef492f90915270f9ae3ac28ba1` in [Security run 44775311368](https://github.com/link-assistant/formal-ai/actions/runs/44775311368). This was the explicit manual dispatch; the automatic pull request Security run skipped its CodeQL jobs. Both original Rust and Actions reports contain zero findings and zero warning/error notifications. Rust retains 631 informational unresolved-macro notifications. This checkpoint does not establish complete macro semantics or complete issue #1580.

The captured CLI is 2.27.5, Rust queries 0.1.47, and `rust-all` 0.2.26. The query source hash is `762d3bd84356e257aa0828d95baf9aa34db594f59f7a8cc6537857210e47f1b5`. Its producer database is finalised and bound to the published source. The retained BQRS is 3,417,552 bytes; its decoded table is 38,112,020 bytes. The collector preserves exact producer bytes and compressed hashes, including the query, pack lock, database metadata and raw result. The readable inventory is split into four parts; its original unsplit representation is also retained. Archive path spelling changes preserve all payload bytes.

The table has 122,534 source macro nodes across 2,216 paths: 42,427 expanded outside another expansion, 79,476 expanded inside another expansion, and 631 unexpanded outside an expansion. All 631 original notification start positions match the last category. The crosswalk explicitly supplies SARIF's default start column of one and retains the producer's original end coordinates. CodeQL and SARIF end-column conventions must not be silently equated.

Those original source positions do not imply that the included code lacks compiled expansion contexts. A separate source-bound include-graph inspection finds actual expanded calls at 15 parent include sites. All eight production included files have such parent contexts. For example, the embedded registry's original 246 `include_str!` and one `vec!` calls reappear expanded at `rust/src/seed/embedded.rs:19`, alongside the parent `include!`. Other production parents retain `format!`, `matches!`, `thread_local!` and their generated helpers. Count/label agreement and relocated contexts are useful observations; individual child-to-expanded-entity mapping and semantic/dataflow qualification remain unfinished.

The query took about 29 seconds to compile and two minutes to evaluate within its four-minute deadline. Its 2 GiB request left a 914 MiB Java heap and emitted `Not caching stages during query-loading`. The next local source commit requests 3 GiB while retaining two threads, a 512 MiB disk cache and the original deadline/security report gates. The adapter's negative control fails on the old request and all 19 security groups pass afterward. Actual hosted warning removal remains unverified until a new dispatch. The CLI documents the RAM setting as an evaluator budget rather than a strict process limit: [query run reference](https://docs.github.com/en/code-security/reference/code-scanning/codeql/codeql-cli-manual/query-run).

Layered CI on the same published head fails its retained producer fingerprint assertion at original workflow log lines 12,533–12,554. The shard completed in 79 seconds; it did not exhaust its deadline. The repaired fingerprint is accepted only after removing the isolated observer and its two step identifiers from the candidate and comparing every retained producer field with the earlier source. All 18 profile checks and all 19 security checks pass locally. One additional local profile invocation hit the existing 100 ms VM deadline while other checks were busy; the isolated invocation passes without increasing that limit. All original failure transcripts are retained.

The original split script modules are now registered directly as focused Cargo test targets. This adds their original 22 assemble-requirements tests, 17 ordered-list tests and self-hosting ledger tests to the existing hosted registry job. Offline locked metadata and 99 policy checks pass without a local native build. Actual execution of these newly admitted targets is still required on the next published head.

The complete local inventory records 87 passing gates and 53 explicit context/native exclusions, with zero failures. Later checks caught copied `_temp` archive names and the 3,474-line producer inventory. Full-word archive names and four readable inventory parts repair those two failures without changing payloads, limits, exclusions or ratchets. All four touched gates pass afterward. No Rust or CodeQL build runs locally.

Rust template literal review reaches 313/373 files and 37,630 lines. The two newly encountered diagnostic images are authenticated, format-verified and visually inspected. Historical upstream claims remain historical evidence; complete template comparison and applicable runtime verification remain open. The original native-source acceptance stays 31/53, with remaining changed-fixture contracts and budget criteria unfinished. Pages publication/served identity, other templates, dependencies, live delivery identity, warnings and complete PR review remain open in the work plan. Supplied scripts, commands, analysis and reviews receive zero independent Formal AI credit; independently accepted reasoning remains 0/20.

Evidence: [producer inventory](../../../experiments/issue-1580/evidence/ci/codeql-producer-39196d1f/producer-files.json), [assessment](../../../experiments/issue-1580/evidence/ci/codeql-producer-39196d1f/macro-observation-assessment.json), and [position crosswalk](../../../experiments/issue-1580/evidence/ci/codeql-producer-39196d1f/macro-observation-position-crosswalk.json). The include inspection and failed assessment harnesses are retained in the companion check archive.
''')
plan = root / 'experiments/issue-1580/work-plan.md'
lines = plan.read_text().splitlines(keepends=True)
start = next(i for i, line in enumerate(lines) if line.startswith('## 17 November hosted-CI repair round'))
end = next(i for i, line in enumerate(lines) if line.startswith('## Rust audit inventory and Java historical comparison'))
history = root / 'experiments/issue-1580/work-plan-history-through-native-interface.md'
assert not history.exists()
history.write_text('# Earlier issue 1580 work plan entries\n\n' + ''.join(lines[start:end]))
plan.write_text(''.join(lines[:start]) + 'Earlier chronology: [preserved work plan entries](work-plan-history-through-native-interface.md).\n\n' + ''.join(lines[end:]) + '''

## Hosted macro results and next combined CI repair

- Published 39196d1f's manual producer compiles and executes the original query: 122,534 macro contexts, retained BQRS/decoded table/pack/database identities, and both unchanged original SARIF reports. All 631 original informational start positions match unexpanded source nodes; actual expanded calls also appear at 15 relocated include parents, including all eight production files. Semantic mapping remains unfinished. See the hosted macro observation checkpoint.
- Local commits a7d92f60, 6a98c602 and 9374f60 respectively admit original split-script tests, repair the reviewed retained producer fingerprint, and request a bounded 3 GiB hosted query budget. Actual next-head execution and warning removal remain required. Current-head native jobs are still running; no next push is authorised by this checkpoint alone.
- Preserve all three failed assessment harnesses, the load-related 100 ms profile failure, both archive gate failures and their corrections. Complete local inventory: 87 pass / 53 explicit exclusions / zero failures; four touched gates pass after full-word path and partitioned inventory corrections. All 124 captured producer payloads retain their original hashes. No local native/CodeQL build, limit increase or independent reasoning credit.
''')
print('Wrote macro checkpoint; preserved earlier chronology in', history.name)
