from pathlib import Path
import gzip, hashlib, json, os, subprocess, sys, traceback

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research/script-and-fingerprint-gates')
archive = root / 'experiments/issue-1580/evidence/checks/script-and-fingerprint-gates'
if len(sys.argv) == 1:
    scratch.mkdir(exist_ok=False)
    with (scratch / 'worker.log').open('wb') as stream:
        child = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root,
                                 stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': child.pid, 'directory': str(scratch)}))
    sys.exit(0)
try:
    archive.mkdir(exist_ok=False)
    environment = dict(os.environ)
    environment['NODE_OPTIONS'] = '--max-old-space-size=256'
    argv = ['node', '--max-old-space-size=256', 'experiments/formal_ai_subagent/local-gates.mjs']
    with (scratch / 'stdout').open('wb') as output, (scratch / 'stderr').open('wb') as errors:
        result = subprocess.run(argv, cwd=root, env=environment, stdout=output, stderr=errors)
    files = []
    candidates = [('stdout', scratch / 'stdout'), ('stderr', scratch / 'stderr')]
    directory = root / 'experiments/formal_ai_subagent/sandboxes/gates'
    candidates += [('gate-' + path.name, path) for path in sorted(directory.glob('*.log'))]
    for label, source in candidates:
        raw = source.read_bytes()
        packed = gzip.compress(raw, mtime=0)
        name = label + '.gz'
        (archive / name).write_bytes(packed)
        files.append({'file': name, 'rawSha256': hashlib.sha256(raw).hexdigest(),
                      'archiveSha256': hashlib.sha256(packed).hexdigest(),
                      'bytes': len(raw), 'lines': len(raw.splitlines())})
    outcome = {'finished': True, 'exitCode': result.returncode, 'argv': argv,
               'files': files, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
    (archive / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    (scratch / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    print(json.dumps({'finished': True, 'exitCode': result.returncode, 'capturedFiles': len(files)}), flush=True)
except BaseException:
    traceback.print_exc()
    (scratch / 'failure.json').write_text(json.dumps({'finished': False, 'traceback': traceback.format_exc()}) + '\n')
    sys.exit(1)
