from pathlib import Path
import hashlib, json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/hosted-macro-query-memory')
base.mkdir(exist_ok=False)
environment = dict(os.environ)
environment.pop('NODE_OPTIONS', None)
records = []
def run(name, argv, expected=0):
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
    for label in ('stdout', 'stderr'):
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode, 'expectedExitCode': expected})
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == expected, (name, result.stdout.decode(errors='replace')[-3000:], result.stderr.decode(errors='replace')[-1000:])
    return result.stdout.decode()
test = root / 'rust/tests/web/security-codeql-results.test.mjs'
source = test.read_text()
assert source.count("'--ram=2048'") == 1
test.write_text(source.replace("'--ram=2048'", "'--ram=3072'"))
run('before', ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-reporter=tap',
    '--test-concurrency=1', '--test-name-pattern=macro observation preserves', str(test.relative_to(root))], 1)
adapter = root / 'experiments/issue-1580/codeql-macro-contexts/observe.py'
source = adapter.read_text()
assert source.count('"--ram=2048"') == 1
adapter.write_text(source.replace('"--ram=2048"', '"--ram=3072"'))
readme = root / 'experiments/issue-1580/codeql-macro-contexts/README.md'
source = readme.read_text()
assert 'query execution requests two threads, 2 GiB RAM and a 512 MiB disk cache.' in source
source = source.replace('query execution requests two threads, 2 GiB RAM and a 512 MiB disk cache.',
    'query execution requests two threads, 3 GiB RAM and a 512 MiB disk cache.\nThe first hosted run on `39196d1f` compiled and executed this query, retaining\n122,534 rows. Its earlier 2 GiB setting left a 914 MiB Java heap and emitted a\nstage-cache warning. The bounded 3 GiB adjustment needs its own hosted\nverification; local adapter controls cannot prove the actual heap allocation.')
readme.write_text(source)
fragment = root / 'changelog.d/issue-1580-macro-query-memory.md'
fragment.write_text('Keep the optional hosted Rust macro observation within a 3 GiB memory budget so the CodeQL evaluator can retain query-loading stages; preserve its four-minute deadline, two threads, strict compiler warnings and original security report checks.\n')
run('security', ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-reporter=tap',
    '--test-concurrency=1', str(test.relative_to(root))])
run('profile', ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-reporter=tap',
    '--test-concurrency=1', 'rust/tests/web/fast-pull-request-production-profile.test.mjs'])
run('whitespace', ['git', 'diff', '--check'])
paths = [str(path.relative_to(root)) for path in [test, adapter, readme, fragment]]
(base / 'source-identities.json').write_text(json.dumps([{'path': path,
    'sha256': hashlib.sha256((root / path).read_bytes()).hexdigest()} for path in paths], indent=2) + '\n')
print('Bounded hosted memory adjustment: negative adapter control fails, full security/profile suites pass. Actual warning removal remains unverified until the next hosted run.')
