from pathlib import Path
import datetime, gzip, hashlib, json, shutil

root = Path('/tmp/gh-issue-solver-1794900398048')
source = Path('/tmp/issue-1580-research/templates/rust-complete')
path = 'dev/log/issues/247/pulls/248/codeql-macros-upstream.json'
raw = (source / path).read_bytes()
digest = hashlib.sha256(raw).hexdigest()
identities = {row['path']: row for row in json.loads((root / 'experiments/issue-1580/evidence/checks/rust-template-first-gate/pinned-file-identities.json').read_text())}
assert digest == identities[path]['sha256'] and len(raw.decode().splitlines()) == 1
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert data['fullyReadFiles'] == 312 and path not in {row['path'] for row in data['files']}
name = 'macro-upstream-history.read.txt.gz'
read = ('FILE ' + path + ' LINES 1 SHA256 ' + digest + '\n1: ' + raw.decode().rstrip('\n') + '\n').encode()
packed = gzip.compress(read, mtime=0)
(root / 'experiments/issue-1580/evidence/checks/rust-source-review' / name).write_bytes(packed)
manifest = root / data['readLogManifest']
records = json.loads(manifest.read_text())
records.append({'file': name, 'rawSha256': hashlib.sha256(read).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest()})
manifest.write_text(json.dumps(records, indent=2) + '\n')
data['files'].append({'path': path, 'lines': 1, 'sha256': digest, 'readLogs': [name],
    'literalReadRanges': [[1, 1]], 'literalReadLines': 1, 'literalSourceFullyRead': True,
    'formalAiPracticeImplementationVerified': False})
data['files'].sort(key=lambda row: row['path'])
data['fullyReadFiles'] = len(data['files'])
data['fullyReadSourceLines'] = sum(row['literalReadLines'] for row in data['files'])
data['observedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
data['practiceDecisions'].append({'practice': 'Revalidate compiler ABI and each macro failure class against the exact extractor bundle',
    'templateEvidence': [path],
    'assessment': 'Read the complete historical CodeQL #19982 report and all twelve comments, including the correction that the first repository-scale workaround was not yet experimentally verified. The subsequent measured run removes 20,725 standard-library expansion failures but reveals 355 procedural-macro and three OUT_DIR failures. An upstream rust-analyzer fix and a later successful consumer do not prove every distinct cause fixed; the snapshot remains open. The authenticated PNG is verified and visually read: rust-analyzer reports expected Expr in the cw_serde ExecuteMsg case. Formal AI already replaces the obsolete 1.94 sysroot with the exact 1.99 ABI for its newer bundle and retains strict original SARIF/context checks. The new explicit hosted macro observation must still be assessed against original locations; a clean SARIF or complete source inventory is not semantic-macro proof.',
    'status': 'complete-historical-report-read-exact-producer-semantic-qualification-open',
    'formalAiPaths': ['.github/workflows/security.yml', 'scripts/codeql-rust-projects.py',
                      'experiments/issue-1580/codeql-macro-contexts/MacroContexts.ql'], 'verification': None})
ledger.write_text(json.dumps(data, indent=2) + '\n')
images = root / 'experiments/issue-1580/evidence/checks/macro-template-image'
images.mkdir(exist_ok=False)
for name in ['macro-diagnostic.png', 'receipt.json', 'download.stdout', 'download.stderr']:
    shutil.copyfile(Path('/tmp/issue-1580-research/macro-template-image') / name, images / name)
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- Read the complete pinned CodeQL macro issue and all twelve comments; authenticate, format-verify and visually read its rust-analyzer image. Literal Rust coverage is 313/373 files and 37,630 lines, with 60 files remaining. Preserve the original unmeasured claim and later measured correction, distinct standard/procedural/OUT_DIR causes, and exact-bundle ABI requirement. Current semantic coverage and all broader requirements remain open.\n')
print(json.dumps({'files': data['fullyReadFiles'], 'lines': data['fullyReadSourceLines'], 'remaining': 60}))
