from pathlib import Path
import gzip,hashlib,json,os,subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
base=Path('/tmp/issue-1580-research/macro-security-fingerprint')
base.mkdir(exist_ok=False)
env=dict(os.environ);env.pop('NODE_OPTIONS',None)
records=[]
def run(name,argv,expected=0):
    result=subprocess.run(argv,cwd=root,env=env,capture_output=True)
    for label in ('stdout','stderr'):(base/(name+'.'+label)).write_bytes(getattr(result,label))
    records.append({'name':name,'argv':argv,'exitCode':result.returncode,'expectedExitCode':expected})
    (base/'records.json').write_text(json.dumps(records,indent=2)+'\n')
    assert result.returncode==expected,(name,result.stdout.decode(errors='replace')[-3000:],result.stderr.decode(errors='replace')[-1000:])
    return result
run('before',['timeout','600','node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','--test-name-pattern=heavy original job bodies','rust/tests/web/fast-pull-request-production-profile.test.mjs'],1)
code='''import fs from 'node:fs';import assert from 'node:assert/strict';import YAML from 'yaml';import {execFileSync} from 'node:child_process';import {createHash} from 'node:crypto';
const path='data/benchmarks/fast-pull-request-retained-jobs.json';
const old=YAML.parse(execFileSync('git',['show','3bb3083ba9d91dbb3b45386083875a1adb9a92f2:.github/workflows/security.yml'],{encoding:'utf8'})).jobs.codeql;
const current=YAML.parse(fs.readFileSync('.github/workflows/security.yml','utf8')).jobs.codeql;
const payload=j=>({steps:j.steps,uses:j.uses,with:j.with,strategy:j.strategy});
const normalized=structuredClone(current);
const observer=normalized.steps.filter(s=>s.name==='Observe Rust macro expansion contexts');assert.equal(observer.length,1);
assert.equal(observer[0].if,"${{ github.job == 'codeql-readonly' && matrix.language == 'rust' && inputs.macro-contexts }}");
normalized.steps=normalized.steps.filter(s=>s!==observer[0]);
for(const step of normalized.steps) if(['codeql-init','codeql-analyze'].includes(step.id)) delete step.id;
assert.deepEqual(payload(normalized),payload(old),'every original producer step and setting must remain intact');
const rows=JSON.parse(fs.readFileSync(path));const row=rows.jobs.find(r=>r.file==='security.yml'&&r.id==='codeql');
const hash=j=>createHash('sha256').update(JSON.stringify(payload(j))).digest('hex');assert.equal(row.payloadSha256,hash(old));
const previous=row.payloadSha256;row.payloadSha256=hash(current);fs.writeFileSync(path,JSON.stringify(rows,null,2)+'\\n');
console.log(JSON.stringify({previous,current:row.payloadSha256,originalPayloadPreserved:true,observationExcludedFromProductionJob:true}));'''
run('review-and-refresh',['node','--max-old-space-size=256','--input-type=module','-e',code])
run('production-profile',['timeout','600','node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs'])
run('security',['timeout','600','node','--max-old-space-size=256','--test','--test-reporter=tap','--test-concurrency=1','rust/tests/web/security-codeql-results.test.mjs'])
run('whitespace',['git','diff','--check'])
print('Original CodeQL payload preserved exactly around the isolated observer and IDs; stale fingerprint negative control fails, refreshed profile and security tests pass.')
