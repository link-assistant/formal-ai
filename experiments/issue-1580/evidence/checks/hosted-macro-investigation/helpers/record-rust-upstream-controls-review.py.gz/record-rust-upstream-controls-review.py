from pathlib import Path
import datetime, gzip, hashlib, json, shutil

root = Path('/tmp/gh-issue-solver-1794900398048')
source = Path('/tmp/issue-1580-research/templates/rust-complete')
ledger = root / 'docs/case-studies/issue-1580/templates/rust-source-review-progress.json'
data = json.loads(ledger.read_text())
assert data['fullyReadFiles'] == 309
identities = {row['path']: row for row in json.loads((root / 'experiments/issue-1580/evidence/checks/rust-template-first-gate/pinned-file-identities.json').read_text())}
archive = root / 'experiments/issue-1580/evidence/checks/rust-source-review'
manifest = root / data['readLogManifest']
records = json.loads(manifest.read_text())
prefix = 'dev/log/issues/247/pulls/248/'
names = ['codeql-msrv-upstream.json', 'audit-panic-upstream.json', 'actionlint-issue-upstream.json']
for name in names:
    path = prefix + name
    raw = (source / path).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == identities[path]['sha256']
    assert path not in {row['path'] for row in data['files']}
    lines = raw.decode().splitlines()
    assert len(lines) == 1
    read = ('FILE ' + path + ' LINES 1 SHA256 ' + digest + '\n1: ' + lines[0] + '\n').encode()
    filename = 'upstream-controls-' + name + '.read.txt.gz'
    packed = gzip.compress(read, mtime=0)
    (archive / filename).write_bytes(packed)
    records.append({'file': filename, 'rawSha256': hashlib.sha256(read).hexdigest(),
                    'archiveSha256': hashlib.sha256(packed).hexdigest()})
    data['files'].append({'path': path, 'lines': 1, 'sha256': digest,
        'readLogs': [filename], 'literalReadRanges': [[1, 1]], 'literalReadLines': 1,
        'literalSourceFullyRead': True, 'formalAiPracticeImplementationVerified': False})
decisions = [
    ('Test actual macro expansions rather than infer completeness from a successful extractor', names[0],
     'The complete historical CodeQL #22793 report and all comments distinguish a hidden Cargo minimum-version refusal from ordinary extraction success. The reporter explicitly limits --ignore-rust-version to the version guard; it cannot supply compiler features a build script actually needs. The snapshot records the issue closed and two upstream fixes, which supplies no present-runtime proof. Formal AI pins the sysroot/compiler ABI and preserves original SARIF plus an explicit default-off database query. Actual hosted query execution and semantic qualification of all informational macro records remain open; do not copy the historical bypass or infer semantic coverage from source-path extraction.',
     ['.github/workflows/security.yml', 'experiments/issue-1580/codeql-macro-contexts/observe.py']),
    ('Preserve exact audit dependency graphs and distinguish contradictory reproduction claims', names[1],
     'The full historical cargo-audit #1241 discussion begins by attributing a panic to locked installation, then corrects that claim: cargo install --locked works while cargo run and a FreeBSD package fail. Preserve the git branch source and exact locked dependency graph in any reproduction; removing a lock is not a demonstrated repair. Formal AI audits committed lockfiles, rejects incomplete Git inventory and denies warnings. This historical thread does not qualify the current audit tool, every current lock graph or unresolved dependency migrations.',
     ['scripts/check-rust-dependencies.sh']),
    ('Keep queue serialization while testing a narrowly scoped schema exception and live shell linting', names[2],
     'The full historical Actionlint #657 report and all six comments concern queue syntax missing from 1.7.12, with a later comment separately documenting the ubuntu-26.04 label gap. The authenticated downloaded PNG is verified as PNG and visually read: common-draft-release-upon-push-to-release.yml:60:7 rejects queue: max and names only group/cancel-in-progress. Formal AI retains the exact-message queue exception in .github/actionlint.yaml, pins the actual Actionlint image and has a shell syntax canary in workflows.yml. The image and historical open report provide no proof that an upstream parser fix has shipped or that every warning is resolved.',
     ['.github/actionlint.yaml', '.github/workflows/workflows.yml'])]
for practice, name, assessment, paths in decisions:
    data['practiceDecisions'].append({'practice': practice, 'templateEvidence': [prefix + name],
        'assessment': assessment, 'status': 'complete-historical-report-read-current-runtime-qualification-open',
        'formalAiPaths': paths, 'verification': None})
data['files'].sort(key=lambda row: row['path'])
data['fullyReadFiles'] = len(data['files'])
data['fullyReadSourceLines'] = sum(row['literalReadLines'] for row in data['files'])
data['observedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest.write_text(json.dumps(records, indent=2) + '\n')
ledger.write_text(json.dumps(data, indent=2) + '\n')
images = root / 'experiments/issue-1580/evidence/checks/actionlint-template-image'
images.mkdir(exist_ok=False)
for name in ['queue-diagnostic.png', 'receipt.json', 'download.stdout', 'download.stderr']:
    shutil.copyfile(Path('/tmp/issue-1580-research/actionlint-template-image') / name, images / name)
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- Published 39196d1f starts 27 exact-head workflows. Layered CI exposes one stale retained CodeQL payload fingerprint at original lines 12,533–12,554, within a 79-second shard. Preserve its failure and refresh only the reviewed hash after proving every original producer step remains unchanged around the isolated observer/IDs. All 18 profile and 19 security groups pass locally. Local a7d92f60 admits the original 22 assemble and 17 ordered-list tests plus self-hosting ledger tests into the existing focused Rust job; 99 policy checks, locked offline metadata and five gates pass. Hosted execution remains required; no push while current-head jobs run.\n')
    stream.write('\n- Three complete pinned Rust upstream reports and all comments are literally read, plus the authenticated queue diagnostic PNG is format-verified and visually read. Coverage is 312/373 files, 37,629 literal lines; 61 files remain. Preserve the MSRV/procedural-macro distinction, the corrected cargo-audit reproduction and the narrow queue-schema exception. Historical reports, images and supplied work receive no current-runtime or independent reasoning credit; broad acceptance remains unfinished.\n')
print(json.dumps({'fullyReadFiles': data['fullyReadFiles'], 'literalLines': data['fullyReadSourceLines'],
    'remaining': 373 - data['fullyReadFiles'], 'fullIssueComplete': False}))
