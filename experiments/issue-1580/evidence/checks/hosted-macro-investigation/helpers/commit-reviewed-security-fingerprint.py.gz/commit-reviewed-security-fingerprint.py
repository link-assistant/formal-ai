from pathlib import Path
import json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/reviewed-security-fingerprint-commit')
base.mkdir(exist_ok=False)
environment = dict(os.environ)
environment['NODE_OPTIONS'] = '--max-old-space-size=256'
path = 'data/benchmarks/fast-pull-request-retained-jobs.json'
records = []
def run(name, argv):
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
    for label in ('stdout', 'stderr'):
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, (name, result.stderr.decode(errors='replace')[-2000:])
    return result.stdout.decode()
assert run('branch', ['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
changes = run('diff', ['git', 'diff', '--', path])
assert changes.count('\n-      "payloadSha256":') == 1
assert changes.count('\n+      "payloadSha256":') == 1
assert 'f7c40020037aa348add2f3b9fd39812668fa9a04ce498bcf32174344edb728df' in changes
run('secrets', ['bash', 'scripts/check-secrets.sh', path])
run('whitespace', ['git', 'diff', '--check'])
run('stage', ['git', 'add', '--', path])
run('commit', ['git', 'commit', '-m', 'test: refresh reviewed CodeQL observation payload fingerprint'])
head = run('head', ['git', 'rev-parse', 'HEAD']).strip()
state = run('hosted-security', ['gh', 'run', 'view', '44775311368', '--repo', 'link-assistant/formal-ai',
            '--json', 'event,headSha,status,conclusion,jobs,url'])
state = json.loads(state)
assert state['headSha'] == '39196d1fb218d0ef492f90915270f9ae3ac28ba1' and state['event'] == 'workflow_dispatch'
(base / 'outcome.json').write_text(json.dumps({'complete': True, 'head': head, 'pushExecuted': False,
    'hostedSecurity': state['status'], 'fullIssueComplete': False}, indent=2) + '\n')
print('Committed reviewed fingerprint:', head, '; no push. Hosted security:', state['status'], state['conclusion'])
for job in state['jobs']:
    print(job['databaseId'], job['name'], job['status'], job['conclusion'])
