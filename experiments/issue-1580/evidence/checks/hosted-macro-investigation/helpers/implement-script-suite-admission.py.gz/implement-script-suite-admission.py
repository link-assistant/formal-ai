from pathlib import Path
import json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/script-suite-admission')
manifest = root / 'experiments/issue-1580/release-registry/Cargo.toml'
source = manifest.read_text()
source = source.replace('[dependencies]\n', '''# Compile the exact standalone sources and their split test modules. This
# isolated manifest avoids another build of the application and its grammars.
[[test]]
name = "assemble_requirements"
path = "../../../scripts/assemble-requirements.rs"

[[test]]
name = "normalize_ordered_lists"
path = "../../../scripts/normalize-ordered-lists.rs"

[[test]]
name = "self_hosting_metric"
path = "../../../scripts/self-hosting-metric.rs"

[dev-dependencies]
syn = { version = "2", features = ["full"] }

[dependencies]
''')
manifest.write_text(source)
old = 'cargo test --manifest-path experiments/issue-1580/release-registry/Cargo.toml --locked --lib -- --test-threads=1 --nocapture'
new = old.replace('--lib --', '--lib --test assemble_requirements --test normalize_ordered_lists --test self_hosting_metric --')
workflow = root / '.github/workflows/native-type-check.yml'
assert workflow.read_text().count(old) == 1
workflow.write_text(workflow.read_text().replace(old, new))
test = root / 'rust/tests/web/default-branch-build-policy.test.mjs'
assert test.read_text().count(old) == 1
test.write_text(test.read_text().replace(old, new))
path = root / 'scripts/ci-pull-request-admission.mjs'
additional = [
    'scripts/assemble-requirements.rs', 'scripts/assemble-requirements-tests.rs',
    'scripts/normalize-ordered-lists.rs', 'scripts/normalize-ordered-lists-tests.rs',
    'scripts/lib/registered-module-paths.rs', 'scripts/self-hosting-metric.rs',
    'scripts/self-hosting-metric-cli.rs', 'scripts/self-hosting-ledger.rs',
    'scripts/self-hosting-ledger-rows.rs', 'scripts/self-hosting-retraction.rs',
    'scripts/self-hosting-attribution.rs', 'scripts/self-hosting-replay.rs',
    'scripts/self-development-loop.rs',
]
text = path.read_text()
assert all("'" + name + "'" not in text for name in additional)
path.write_text(text.replace('const NATIVE_REGRESSION_INPUTS = new Set([\n', 'const NATIVE_REGRESSION_INPUTS = new Set([\n' + ''.join("  '" + name + "',\n" for name in additional)))
(root / 'changelog.d/issue-1580-split-script-test-admission.md').write_text('''### Fixed

- Run the original standalone requirements, ordered-list and self-hosting metric
  sources in the focused native script job, including their split modules. Admit
  every consumed helper to that lane without rebuilding the application.
''')
environment = dict(os.environ, CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0')
argv = ['cargo', 'update', '--offline', '--manifest-path', str(manifest), '-p', 'syn@2.0.119', '--precise', '2.0.119']
result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
(base / 'lock-update.stdout').write_bytes(result.stdout)
(base / 'lock-update.stderr').write_bytes(result.stderr)
(base / 'lock-update.json').write_text(json.dumps({'argv':argv, 'exitCode':result.returncode}) + '\n')
assert result.returncode == 0, result.stderr.decode(errors='replace')[-2000:]
print('Drafted complete native script admission and resolved the existing Syn 2 lock without compilation.')
