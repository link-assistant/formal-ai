from collections import Counter
from pathlib import Path
import gzip, hashlib, json, re

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/ci/codeql-producer-39196d1f'
outcome = json.loads((base / 'outcome.json').read_text())
assert outcome['complete'] and outcome['conclusion'] == 'success'
files = json.loads((base / 'producer-files.json').read_text())
lookup = {row['relativePath']: row for row in files}
def raw(path):
    row = lookup[path]
    packed = (base / row['file']).read_bytes()
    assert hashlib.sha256(packed).hexdigest() == row['archiveSha256']
    value = gzip.decompress(packed)
    assert hashlib.sha256(value).hexdigest() == row['rawSha256']
    assert len(value) == row['bytes'] and len(value.splitlines()) == row['lines']
    return value
for row in files:
    if row['relativePath'] == 'macro-contexts/macro-contexts.json':
        continue
    raw(row['relativePath'])
reports = {}
notes = []
for path in ['rust.sarif', 'actions.sarif']:
    report = json.loads(raw(path))
    results = sum(len(run.get('results', [])) for run in report['runs'])
    warnings = []
    for run in report['runs']:
        for invocation in run.get('invocations', []):
            for note in invocation.get('toolExecutionNotifications', []):
                if note.get('level', 'warning') in ['warning', 'error']:
                    warnings.append(note)
                if path == 'rust.sarif' and note.get('descriptor', {}).get('id') == 'rust/diagnostics/unresolved-macro-calls':
                    notes.append(note)
    reports[path] = {'sha256': lookup[path]['rawSha256'], 'results': results,
                     'warningErrorNotifications': len(warnings)}
assert len(notes) == 631
targets = {}
for number, note in enumerate(notes):
    locations = note['locations']
    assert len(locations) == 1
    physical = locations[0]['physicalLocation']
    path = physical['artifactLocation']['uri']
    region = physical['region']
    key = (path, region['startLine'], region.get('startColumn', 1))
    targets.setdefault(key, []).append({'notification': number, 'region': region})
matches = {key: [] for key in targets}
counts = Counter()
path_counts = Counter()
columns = None
rows = 0
json_row = lookup['macro-contexts/macro-contexts.json']
packed = (base / json_row['file']).read_bytes()
assert hashlib.sha256(packed).hexdigest() == json_row['archiveSha256']
digest = hashlib.sha256()
byte_count = line_count = 0
header = ''
table_open = False
table_closed = False
root_closed = False
with gzip.open(base / json_row['file'], 'rb') as stream:
    for line in stream:
        digest.update(line)
        byte_count += len(line)
        line_count += 1
        text = line.decode().strip()
        if not table_open:
            header += line.decode()
            if re.search(r'"tuples"\s*:\s*\[\s*$', header):
                empty = json.loads(header + ']}}')
                columns = empty['#select']['columns']
                assert len(columns) == 8
                table_open = True
            continue
        if text == ']}}':
            table_closed = True
            root_closed = True
            continue
        if table_closed:
            assert text == '}}' and not root_closed, repr(text)
            root_closed = True
            continue
        assert not table_closed
        record = text.removeprefix(',')
        row, end = json.JSONDecoder().raw_decode(record)
        suffix = record[end:].strip()
        assert suffix in ['', ']', ']}}'], repr(suffix)
        if suffix:
            table_closed = True
            root_closed = suffix == ']}}'
        assert len(row) == 8 and isinstance(row[0], dict)
        assert row[6] in ['expanded', 'unexpanded'] and row[7] in ['inside-expansion', 'outside-expansion']
        rows += 1
        counts[row[6] + ':' + row[7]] += 1
        path_counts[row[1]] += 1
        key = (row[1], row[2], row[3])
        if key in matches:
            matches[key].append({'entity': row[0], 'path': row[1], 'startLine': row[2],
                'startColumn': row[3], 'endLine': row[4], 'endColumn': row[5],
                'expansion': row[6], 'enclosing': row[7]})
assert table_open and table_closed and root_closed
assert digest.hexdigest() == json_row['rawSha256']
assert byte_count == json_row['bytes'] and line_count == json_row['lines']
manifest = json.loads(raw('macro-contexts/manifest.json'))
assert manifest['complete'] and manifest['rows'] == rows
assert manifest['result']['sha256'] == json_row['rawSha256']
assert manifest['query']['sha256'] == hashlib.sha256((root / 'experiments/issue-1580/codeql-macro-contexts/MacroContexts.ql').read_bytes()).hexdigest()
crosswalk = []
classifications = Counter()
for key, values in targets.items():
    found = matches[key]
    expanded = any(row['expansion'] == 'expanded' for row in found)
    unexpanded = any(row['expansion'] == 'unexpanded' for row in found)
    category = 'mixed-contexts' if expanded and unexpanded else 'expanded-contexts' if expanded else 'unexpanded-contexts' if unexpanded else 'no-exact-start-match'
    classifications[category] += len(values)
    crosswalk.append({'path': key[0], 'startLine': key[1], 'startColumn': key[2],
        'originalNotifications': values, 'classification': category, 'observedContexts': found})
warnings = [line for line in raw('macro-contexts/query.stderr').decode().splitlines() if 'WARNING:' in line]
assessment = {'head': outcome['head'], 'runId': outcome['runId'], 'producerFilesVerified': len(files),
    'reports': reports, 'macroRows': rows, 'macroSourceFiles': len(path_counts), 'expansionStates': dict(counts),
    'originalNotifications': len(notes), 'distinctOriginalPositions': len(targets),
    'positionalCrosswalkCounts': dict(classifications), 'queryRuntimeWarnings': warnings,
    'queryCompiledAndExecuted': True, 'allMacroSemanticsQualified': False,
    'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
(base / 'macro-observation-assessment.json').write_text(json.dumps(assessment, indent=2) + '\n')
(base / 'macro-observation-position-crosswalk.json').write_text(json.dumps(crosswalk, separators=(',', ':')) + '\n')
print(json.dumps(assessment, indent=2))
for row in crosswalk[:4]:
    print(json.dumps(row))
