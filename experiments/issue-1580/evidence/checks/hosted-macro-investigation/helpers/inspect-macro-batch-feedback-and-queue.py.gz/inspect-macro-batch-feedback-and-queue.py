from pathlib import Path
import hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/script-admission-batch-feedback')
base.mkdir(exist_ok=False)
old = Path('/tmp/issue-1580-research/macro-batch-feedback')
records = []
def run(name, argv, parsed=False):
    result = subprocess.run(argv, cwd=root, capture_output=True)
    for label in ('stdout', 'stderr'):
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, name
    return json.loads(result.stdout) if parsed else result.stdout.decode()
issue = run('issue', ['gh', 'issue', 'view', 'https://github.com/link-assistant/formal-ai/issues/1580',
        '--json', 'title,body,state,url,updatedAt'], True)
old_issue = json.loads((old / 'issue.stdout').read_text())
print('Issue contents unchanged:', issue['body'] == old_issue['body'] and issue['title'] == old_issue['title'])
for name, endpoint in [('issue-comments', 'issues/1580/comments'), ('conversation', 'issues/1581/comments'),
                       ('inline', 'pulls/1581/comments'), ('reviews', 'pulls/1581/reviews')]:
    pages = run(name, ['gh', 'api', 'repos/link-assistant/formal-ai/' + endpoint, '--paginate', '--slurp'], True)
    rows = [row for page in pages for row in page]
    previous = {row['id']: row for row in json.loads((old / (name + '.stdout')).read_text())}
    changed = [row for row in rows if row['id'] not in previous or row.get('body') != previous[row['id']].get('body')]
    print(name, len(rows), 'new/changed', len(changed))
    for row in changed:
        print(json.dumps({key: row.get(key) for key in ('html_url', 'updated_at', 'state', 'body')}, ensure_ascii=False))
run('recent-runs', ['gh', 'run', 'list', '--repo', 'link-assistant/formal-ai', '--branch',
    'issue-1580-8d61a32a61e1', '--limit', '5', '--json', 'databaseId,conclusion,createdAt,headSha'])
state = run('pipeline', ['gh', 'run', 'view', '44775337494', '--repo', 'link-assistant/formal-ai',
    '--json', 'headSha,status,conclusion,jobs,url,createdAt,updatedAt'], True)
assert state['headSha'] == '39196d1fb218d0ef492f90915270f9ae3ac28ba1'
print('Pipeline:', state['status'], state['conclusion'])
for job in state['jobs']:
    print(job['databaseId'], job['name'], job['status'], job['conclusion'])
