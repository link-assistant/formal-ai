from pathlib import Path
import shutil, subprocess

base = Path('/tmp/issue-1580-research')
shutil.copyfile(base / 'assess-hosted-macro-observations.py', base / 'assess-hosted-macro-observations-before-default-column.py')
shutil.copyfile(base / 'assess-hosted-macro-observations.log', base / 'assess-hosted-macro-observations-before-default-column.log')
path = base / 'assess-hosted-macro-observations.py'
source = path.read_text()
assert "region['startLine'], region['startColumn']" in source
source = source.replace("region['startLine'], region['startColumn']", "region['startLine'], region.get('startColumn', 1)")
path.write_text(source)
result = subprocess.run(['python3', str(path)], capture_output=True)
(base / 'assess-hosted-macro-observations-corrected.stdout').write_bytes(result.stdout)
(base / 'assess-hosted-macro-observations-corrected.stderr').write_bytes(result.stderr)
print(result.stdout.decode())
print(result.stderr.decode())
assert result.returncode == 0
