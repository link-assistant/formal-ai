from pathlib import Path
import hashlib, json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/hosted-macro-memory-validation')
base.mkdir(exist_ok=False)
environment = dict(os.environ)
environment.pop('NODE_OPTIONS', None)
records = []
def run(name, argv):
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
    for label in ('stdout', 'stderr'):
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, (name, result.stdout.decode(errors='replace')[-3000:], result.stderr.decode(errors='replace')[-1000:])
    return result.stdout.decode()
run('profile-after-gates', ['timeout', '600', 'node', '--max-old-space-size=256', '--test',
    '--test-reporter=tap', '--test-concurrency=1', 'rust/tests/web/fast-pull-request-production-profile.test.mjs'])
run('touched-gates', ['node', '--max-old-space-size=256', 'experiments/formal_ai_subagent/local-gates.mjs',
    '--only', 'check-ci-speed,check-readable-code,check-file-size,check-abbreviations'])
run('whitespace', ['git', 'diff', '--check'])
paths = ['rust/tests/web/security-codeql-results.test.mjs', 'experiments/issue-1580/codeql-macro-contexts/observe.py',
         'experiments/issue-1580/codeql-macro-contexts/README.md', 'changelog.d/issue-1580-macro-query-memory.md']
rows = [{'path': path, 'sha256': hashlib.sha256((root / path).read_bytes()).hexdigest()} for path in paths]
(base / 'source-identities.json').write_text(json.dumps(rows, indent=2) + '\n')
environment['NODE_OPTIONS'] = '--max-old-space-size=256'
run('secret-scan', ['bash', 'scripts/check-secrets.sh', *paths])
assert run('branch', ['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
run('stage', ['git', 'add', '--', *paths])
run('commit', ['git', 'commit', '-m', 'ci: bound hosted macro query memory above the stage cache threshold'])
head = run('head', ['git', 'rev-parse', 'HEAD']).strip()
(base / 'outcome.json').write_text(json.dumps({'complete': True, 'head': head, 'pushExecuted': False,
    'hostedWarningRemovalVerified': False, 'fullIssueComplete': False}, indent=2) + '\n')
print('Memory repair checks and source scan pass; committed', head, '; no push. Hosted warning removal remains pending.')
