from pathlib import Path
import hashlib, json, subprocess

base = Path('/tmp/issue-1580-research/actionlint-template-image')
base.mkdir(exist_ok=False)
url = 'https://github.com/user-attachments/assets/088d4459-fd2f-4ead-bd42-2676d9539677'
target = base / 'queue-diagnostic.png'
token = subprocess.run(['gh', 'auth', 'token'], capture_output=True, check=True).stdout.decode().strip()
result = subprocess.run(['curl', '--fail', '-L', '-H', 'Authorization: token ' + token,
                         '-o', str(target), url], capture_output=True)
(base / 'download.stdout').write_bytes(result.stdout)
(base / 'download.stderr').write_bytes(result.stderr)
assert result.returncode == 0
kind = subprocess.run(['file', '--brief', str(target)], capture_output=True, check=True).stdout.decode().strip()
assert kind.startswith('PNG image data'), kind
(base / 'receipt.json').write_text(json.dumps({'url': url, 'fileType': kind,
    'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'bytes': target.stat().st_size,
    'independentAuthorshipCredit': 0}, indent=2) + '\n')
print(kind)
