from pathlib import Path
import subprocess

source = Path('/tmp/issue-1580-research/download-actionlint-template-image.py').read_text()
source = source.replace('actionlint-template-image', 'macro-template-image')
source = source.replace('088d4459-fd2f-4ead-bd42-2676d9539677', '936139b2-0daf-4b26-9d22-b0d8ddf96839')
source = source.replace('queue-diagnostic.png', 'macro-diagnostic.png')
target = Path('/tmp/issue-1580-research/download-macro-template-image-worker.py')
target.write_text(source)
result = subprocess.run(['python3', str(target)], capture_output=True)
Path('/tmp/issue-1580-research/download-macro-template-image.stdout').write_bytes(result.stdout)
Path('/tmp/issue-1580-research/download-macro-template-image.stderr').write_bytes(result.stderr)
assert result.returncode == 0
print(result.stdout.decode())
