from pathlib import Path
import shutil, subprocess

base = Path('/tmp/issue-1580-research')
path = base / 'assess-hosted-macro-observations.py'
shutil.copyfile(path, base / 'assess-hosted-macro-observations-before-closing-lines.py')
source = path.read_text()
assert "table_closed = False" in source
source = source.replace("table_closed = False", "table_closed = False\nroot_closed = False")
source = source.replace("            table_closed = True\n            continue\n        assert not table_closed", "            table_closed = True\n            root_closed = True\n            continue\n        if table_closed:\n            assert text == '}}' and not root_closed, repr(text)\n            root_closed = True\n            continue\n        assert not table_closed")
source = source.replace("assert suffix in ['', ']}}'], repr(suffix)", "assert suffix in ['', ']', ']}}'], repr(suffix)")
source = source.replace("        if suffix:\n            table_closed = True", "        if suffix:\n            table_closed = True\n            root_closed = suffix == ']}}'")
source = source.replace('assert table_open and table_closed', 'assert table_open and table_closed and root_closed')
path.write_text(source)
result = subprocess.run(['python3', str(path)], capture_output=True)
(base / 'assess-hosted-macro-observations-closing-lines.stdout').write_bytes(result.stdout)
(base / 'assess-hosted-macro-observations-closing-lines.stderr').write_bytes(result.stderr)
print(result.stdout.decode())
print(result.stderr.decode())
assert result.returncode == 0
