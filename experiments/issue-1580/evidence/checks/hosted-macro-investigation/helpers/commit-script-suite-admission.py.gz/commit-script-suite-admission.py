from pathlib import Path
import hashlib, json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/script-suite-source-commit')
base.mkdir(exist_ok=False)
environment = dict(os.environ)
environment['NODE_OPTIONS'] = '--max-old-space-size=256'
rows = json.loads((root / 'experiments/issue-1580/evidence/checks/split-script-suite-admission/source-identities.json').read_text())
paths = [row['path'] for row in rows] + ['changelog.d/issue-1580-split-script-test-admission.md']
for row in rows:
    assert hashlib.sha256((root / row['path']).read_bytes()).hexdigest() == row['sha256']
records = []
def run(name, argv):
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True)
    for label in ('stdout', 'stderr'):
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name':name, 'argv':argv, 'exitCode':result.returncode})
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, (name, result.stderr.decode(errors='replace')[-2000:])
    return result.stdout.decode()
assert run('branch', ['git','branch','--show-current']).strip() == 'issue-1580-8d61a32a61e1'
run('secrets', ['bash','scripts/check-secrets.sh', *paths])
run('whitespace', ['git','diff','--check'])
run('stage', ['git','add','--',*paths])
run('commit', ['git','commit','-m','test: execute original split script suites in the focused native lane'])
head = run('head',['git','rev-parse','HEAD']).strip()
(base/'outcome.json').write_text(json.dumps({'complete':True,'head':head,'paths':paths,'pushExecuted':False,'nativeExecutionVerified':False,'fullIssueComplete':False},indent=2)+'\n')
print('Committed focused script test admission:',head,'; no push and no local Rust build.')
