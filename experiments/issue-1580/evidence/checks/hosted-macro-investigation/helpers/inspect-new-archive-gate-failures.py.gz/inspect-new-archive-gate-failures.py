from pathlib import Path
import hashlib, json, os, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/new-archive-gate-failures')
base.mkdir(exist_ok=False)
for name in ['check-abbreviations', 'check-file-size']:
    raw = (root / 'experiments/formal_ai_subagent/sandboxes/gates' / (name + '.log')).read_bytes()
    (base / (name + '.log')).write_bytes(raw)
    print(name, hashlib.sha256(raw).hexdigest())
    for number, line in enumerate(raw.decode().splitlines(), 1):
        if '::error' in line or 'exceeds' in line:
            print(number, line)
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
result = subprocess.run(['node', 'scripts/measure-abbreviations.mjs', '--list', 'file-names'],
                        cwd=root, env=environment, capture_output=True)
(base / 'abbreviated-file-names.stdout').write_bytes(result.stdout)
(base / 'abbreviated-file-names.stderr').write_bytes(result.stderr)
assert result.returncode == 0
paths = [line for line in result.stdout.decode().splitlines() if 'codeql-producer-39196d1f/' in line]
print('New producer abbreviated paths:', len(paths))
for path in paths:
    print(path)
inventory = json.loads((root / 'experiments/issue-1580/evidence/ci/codeql-producer-39196d1f/producer-files.json').read_text())
print('Producer inventory type:', type(inventory).__name__)
print('Inventory keys:', list(inventory)[:8] if isinstance(inventory, dict) else list(inventory[0]))
