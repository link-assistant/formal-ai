from collections import Counter, defaultdict
from pathlib import Path
import gzip, hashlib, json, posixpath, re, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/compiled-include-macro-contexts')
base.mkdir(exist_ok=False)
archive = root / 'experiments/issue-1580/evidence/ci/codeql-producer-39196d1f'
changed = subprocess.run(['git', 'diff', '--name-only', '39196d1fb218d0ef492f90915270f9ae3ac28ba1', '--', '*.rs'], cwd=root, capture_output=True, check=True)
(base / 'changed-rust-source.stdout').write_bytes(changed.stdout)
assert not changed.stdout.strip()
crosswalk = json.loads((archive / 'macro-observation-position-crosswalk.json').read_text())
children = {row['path'] for row in crosswalk}
result = subprocess.run(['rg', '--json', r'include!\s*\(', 'rust', 'scripts', 'js/wasm-worker', '-g', '*.rs'], cwd=root, capture_output=True)
assert result.returncode == 0
(base / 'include-search.stdout').write_bytes(result.stdout)
(base / 'include-search.stderr').write_bytes(result.stderr)
edges = []
for line in result.stdout.splitlines():
    event = json.loads(line)
    if event['type'] != 'match':
        continue
    data = event['data']
    path = data['path']['text']
    for match in re.finditer(r'include!\s*\(\s*"([^"]+)"\s*\)', data['lines']['text']):
        child = posixpath.normpath((Path(path).parent / match[1]).as_posix())
        if child in children:
            edges.append({'parent': path, 'line': data['line_number'], 'child': child,
                'parentSourceSha256': hashlib.sha256((root / path).read_bytes()).hexdigest(),
                'childSourceSha256': hashlib.sha256((root / child).read_bytes()).hexdigest()})
positions = {(row['parent'], row['line']) for row in edges}
observed = defaultdict(list)
files = json.loads((archive / 'producer-files.json').read_text())
selected = next(row for row in files if row['relativePath'] == 'macro-contexts/macro-contexts.json')
with gzip.open(archive / selected['file'], 'rt') as stream:
    in_table = False
    for text in stream:
        if not in_table:
            if '"tuples":[' in text:
                in_table = True
            continue
        text = text.strip().removeprefix(',')
        if not text.startswith('['):
            continue
        row, _ = json.JSONDecoder().raw_decode(text)
        if (row[1], row[2]) in positions:
            observed[(row[1], row[2])].append({'entity': row[0], 'path': row[1], 'startLine': row[2],
                'startColumn': row[3], 'endLine': row[4], 'endColumn': row[5],
                'expansion': row[6], 'enclosing': row[7]})
rows = []
for edge in edges:
    found = observed[(edge['parent'], edge['line'])]
    counts = Counter(row['entity']['label'] + ':' + row['expansion'] + ':' + row['enclosing'] for row in found)
    rows.append({**edge, 'contexts': found, 'counts': dict(counts)})
    print(json.dumps({**edge, 'counts': dict(counts)}))
(base / 'observations.json').write_text(json.dumps({'edges': rows, 'semanticCoverageProven': False,
    'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, separators=(',', ':')) + '\n')
print('Direct include parents:', len(edges), '; observation only, no individual macro semantic credit.')
