from pathlib import Path
import shutil, subprocess

base = Path('/tmp/issue-1580-research')
path = base / 'assess-hosted-macro-observations.py'
shutil.copyfile(path, base / 'assess-hosted-macro-observations-before-final-record.py')
source = path.read_text()
old = "        row = json.loads(text.removeprefix(','))"
new = """        record = text.removeprefix(',')
        row, end = json.JSONDecoder().raw_decode(record)
        suffix = record[end:].strip()
        assert suffix in ['', ']}}'], repr(suffix)
        if suffix:
            table_closed = True"""
assert old in source
path.write_text(source.replace(old, new))
result = subprocess.run(['python3', str(path)], capture_output=True)
(base / 'assess-hosted-macro-observations-final-record.stdout').write_bytes(result.stdout)
(base / 'assess-hosted-macro-observations-final-record.stderr').write_bytes(result.stderr)
print(result.stdout.decode())
print(result.stderr.decode())
assert result.returncode == 0
