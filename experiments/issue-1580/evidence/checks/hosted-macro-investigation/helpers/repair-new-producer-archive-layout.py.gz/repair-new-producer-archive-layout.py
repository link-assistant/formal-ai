from pathlib import Path
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/ci/codeql-producer-39196d1f'
scratch = Path('/tmp/issue-1580-research/new-producer-archive-layout')
scratch.mkdir(exist_ok=False)
inventory = base / 'producer-files.json'
original = inventory.read_bytes()
(base / 'original-producer-inventory.json.gz').write_bytes(gzip.compress(original, mtime=0))
rows = json.loads(original)
renames = []
for row in rows:
    old = row['file']
    new = old.replace('_temp_', '_temporary_')
    packed = (base / old).read_bytes()
    assert hashlib.sha256(packed).hexdigest() == row['archiveSha256']
    raw = gzip.decompress(packed)
    assert hashlib.sha256(raw).hexdigest() == row['rawSha256']
    assert len(raw) == row['bytes'] and len(raw.splitlines()) == row['lines']
    if new != old:
        assert not (base / new).exists()
        (base / old).rename(base / new)
        row['file'] = new
        renames.append({'old': old, 'new': new, 'archiveSha256': row['archiveSha256']})
parts = []
for start in range(0, len(rows), 40):
    name = 'producer-files-part-' + str(start // 40 + 1) + '.json'
    content = (json.dumps(rows[start:start + 40], indent=2) + '\n').encode()
    assert len(content.splitlines()) <= 1400
    (base / name).write_bytes(content)
    parts.append({'file': name, 'records': len(rows[start:start + 40]),
                  'sha256': hashlib.sha256(content).hexdigest()})
inventory.write_text(json.dumps({'format': 'partitioned-producer-inventory', 'records': len(rows),
    'parts': parts, 'originalInventory': {'file': 'original-producer-inventory.json.gz',
        'rawSha256': hashlib.sha256(original).hexdigest(), 'bytes': len(original),
        'lines': len(original.splitlines())}}, indent=2) + '\n')
(scratch / 'renames.json').write_text(json.dumps(renames, indent=2) + '\n')
gate = root / 'experiments/issue-1580/evidence/checks/script-and-fingerprint-gates'
old = 'gate-check-tests-as-docs.log.gz'
new = 'gate-check-tests-as-documentation.log.gz'
assert (gate / old).exists() and not (gate / new).exists()
digest = hashlib.sha256((gate / old).read_bytes()).hexdigest()
(gate / old).rename(gate / new)
for path in gate.glob('*.json'):
    text = path.read_text()
    if old in text:
        path.write_text(text.replace(old, new))
load = """inventory = json.loads((base / 'producer-files.json').read_text())
files = []
for part in inventory['parts']:
    content = (base / part['file']).read_bytes()
    assert hashlib.sha256(content).hexdigest() == part['sha256']
    files.extend(json.loads(content))
assert len(files) == inventory['records']"""
source = Path('/tmp/issue-1580-research/assess-hosted-macro-observations.py')
updated = source.read_text().replace("files = json.loads((base / 'producer-files.json').read_text())", load)
assert updated != source.read_text()
Path('/tmp/issue-1580-research/assess-partitioned-hosted-macro-observations.py').write_text(updated)
(scratch / 'outcome.json').write_text(json.dumps({'producerFilesVerified': len(rows),
    'archiveRenames': len(renames), 'inventoryParts': parts,
    'gateLogRename': {'old': old, 'new': new, 'archiveSha256': digest},
    'payloadBytesChanged': False, 'ratchetChanged': False}, indent=2) + '\n')
print('Verified', len(rows), 'payloads; renamed', len(renames), 'archive paths; split inventory into', len(parts), 'readable parts.')
