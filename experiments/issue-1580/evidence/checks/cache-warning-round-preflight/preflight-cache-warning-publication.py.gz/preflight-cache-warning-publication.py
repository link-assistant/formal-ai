from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess, sys, traceback
root = Path('/tmp/gh-issue-solver-1794900398048')
out = Path('/tmp/issue-1580-research/cache-warning-publication/preflight')
if '--worker' not in sys.argv:
    if '--resume' in sys.argv:
        for source in list(out.iterdir()):
            if source.is_file() and source.name != 'worker.log' and not source.name.startswith('first-'):
                (out / ('first-' + source.name)).write_bytes(source.read_bytes())
    else:
        out.mkdir(exist_ok=False)
    with (out / 'worker.log').open('ab') as stream:
        worker = subprocess.Popen([sys.executable, __file__, '--worker'], cwd=root,
            stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': worker.pid, 'directory': str(out)})); sys.exit(0)
records = []
def run(name, argv, parsed=False, checked=True):
    result = subprocess.run(argv, cwd=root, capture_output=True)
    (out / (name + '.stdout')).write_bytes(result.stdout); (out / (name + '.stderr')).write_bytes(result.stderr)
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    if checked:
        assert result.returncode == 0, (name, result.stderr.decode(errors='replace')[-1500:])
    print(json.dumps({'name': name, 'exitCode': result.returncode}), flush=True)
    return json.loads(result.stdout) if parsed else result.stdout.decode()
try:
    assert run('branch', ['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
    run('fetch-main', ['git', 'fetch', 'origin', 'main'])
    main = run('main', ['git', 'rev-parse', 'origin/main']).strip()
    run('main-ancestor', ['git', 'merge-base', '--is-ancestor', main, 'HEAD'])
    issue = run('issue', ['gh', 'issue', 'view', 'https://github.com/link-assistant/formal-ai/issues/1580', '--json', 'title,body,updatedAt'], True)
    old = root / 'experiments/issue-1580/evidence/checks/query-import-php-batch-seal'
    counts = {}; changed = []
    for name, endpoint in [('issue-comments', 'issues/1580/comments'), ('conversation', 'issues/1581/comments'),
                           ('inline', 'pulls/1581/comments'), ('reviews', 'pulls/1581/reviews')]:
        def flatten_pages(value):
            assert isinstance(value, list)
            rows = [row for page in value for row in page] if all(isinstance(page, list) for page in value) else value
            assert all(isinstance(row, dict) for row in rows)
            return rows
        actual = flatten_pages(run(name, ['gh', 'api', 'repos/link-assistant/formal-ai/' + endpoint, '--paginate', '--slurp'], True))
        previous = flatten_pages(json.loads(gzip.decompress((old / ('feedback-' + name + '.stdout.gz')).read_bytes())))
        counts[name] = len(actual)
        if actual != previous:
            changed.append(name)
    assert not changed, ('Fresh feedback requires literal review', changed)
    pull = run('pull-request', ['gh', 'pr', 'view', '1581', '--repo', 'link-assistant/formal-ai', '--json', 'title,body,isDraft,headRefOid,state,baseRefName,mergeStateStatus'], True)
    previous_body = (out.parent / 'previous-pull-request-body.md').read_text()
    assert pull['body'].rstrip('\n') == previous_body.rstrip('\n'), 'PR body changed; preserve current edits before updating'
    assert pull['isDraft'] and pull['state'] == 'OPEN' and pull['baseRefName'] == 'main'
    previous = 'bbda05c06bce8e9fef10a9c8812b6b6cc31858b2'
    assert pull['headRefOid'] == previous
    for state in ['in_progress', 'queued']:
        rows = run(state, ['gh', 'run', 'list', '--repo', 'link-assistant/formal-ai', '--branch', 'issue-1580-8d61a32a61e1', '--status', state, '--limit', '100', '--json', 'databaseId,workflowName,headSha'], True)
        assert not rows, (state, rows)
    assert run('remote-head', ['git', 'ls-remote', 'origin', 'refs/heads/issue-1580-8d61a32a61e1']).split()[0] == previous
    run('pull-request-diff', ['gh', 'pr', 'diff', '1581', '--repo', 'link-assistant/formal-ai'], checked=False)
    run('batch-source-diff', ['git', 'diff', previous, '--', '.', ':!experiments/issue-1580/evidence'])
    summary = {'observedAt': datetime.now(timezone.utc).isoformat(), 'main': main, 'mainAncestor': True,
        'previousPublishedHead': previous, 'feedbackCounts': counts, 'changedFeedbackKinds': changed,
        'emptyQueues': True, 'isDraft': True, 'previousBodySha256': hashlib.sha256(previous_body.encode()).hexdigest(),
        'fullPullRequestDiffLiterallyReviewed': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
    (out / 'outcome.json').write_text(json.dumps(summary, indent=2) + '\n')
    archive = root / 'experiments/issue-1580/evidence/checks/cache-warning-round-preflight'
    archive.mkdir(exist_ok=False); inventory = []
    sources = [Path(__file__)] + sorted(p for p in out.iterdir() if p.is_file() and p.name != 'worker.log')
    for source in sources:
        raw = source.read_bytes(); packed = gzip.compress(raw, mtime=0); name = source.name + '.gz'
        (archive / name).write_bytes(packed)
        inventory.append({'file': name, 'rawSha256': hashlib.sha256(raw).hexdigest(),
            'archiveSha256': hashlib.sha256(packed).hexdigest(), 'bytes': len(raw), 'lines': len(raw.splitlines())})
    (archive / 'streams.json').write_text(json.dumps(inventory, indent=2) + '\n')
    (archive / 'outcome.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary), flush=True)
except Exception:
    (out / 'failure.json').write_text(json.dumps({'records': records, 'traceback': traceback.format_exc()}, indent=2) + '\n')
    traceback.print_exc(); sys.exit(1)
