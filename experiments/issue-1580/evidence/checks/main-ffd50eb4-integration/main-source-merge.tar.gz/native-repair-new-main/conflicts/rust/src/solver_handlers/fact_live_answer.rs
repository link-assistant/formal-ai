//! Live fact answers and researched explanations (issue #1172 R3 and R8).
//!
//! R3: when no seeded record's subject matches, the `fact_lookup` row asks
//! Wikidata itself through [`crate::fact_live::resolve_fact_live`]. The
//! question is formalized from seed data alone: the relation is the
//! `fact_relation` meaning the prompt names (its `grounded-in` property must
//! be a Wikidata property), and the subject term is what remains of the
//! relation's clause once the relation's own surfaces, the
//! `interrogative_opener` words and the `statement_function_word` words are
//! removed. The answer is the seeded `fact_live_answer` template, citing the
//! reference URL the claim names (else the subject snapshot it was read from).
//!
//! R8: an explanation request ("explain X", the `capability_act_explain`
//! surfaces opening the prompt) about a concept is answered from retrieved,
//! formalized pages: [`crate::concept_lookup::research_page_senses`] (the
//! issue #1163 R4 retrieve-and-formalize path) yields the page statements that
//! mention the concept, and each is quoted with its page URL and SHA-256 via
//! the `explanation_research_answer` and `explanation_research_row` templates.
//!
//! Neither path reaches the network by itself: every byte goes through a
//! [`CachedSourceClient`], which only reads the capture cache unless the
//! runtime opted into live fetches, and a cache miss falls through (`None`)
//! instead of guessing. The browser twin of R3 is `resolveFactQueryViaWikidata`
//! with `factLiveAnswer` (`js/worker/formal_ai_worker_factual_qa.js`).

use super::factual_qa::{relation_label, render_template};
use super::finalize_simple;
use crate::coding::contains_cjk;
use crate::engine::{SymbolicAnswer, normalize_prompt};
use crate::event_log::EventLog;
use crate::fact_live::{
    LiveFactQuestion, bounded_subject, capture_client, live_fact_questions, locate,
    record_fact_question, resolve_fact_live, role_surfaces,
};
use crate::language::detect as detect_language;
use crate::seed;
use crate::source_fetch::{CachedSourceClient, SourceTransport};

/// The intent of a live Wikidata resolution, as the browser names it.
const LIVE_FACT_INTENT: &str = "fact_query";
/// The intent of an explanation composed from retrieved pages.
#[cfg(feature = "meta-language")]
const EXPLANATION_INTENT: &str = "explanation_research";

/// Answer an unseeded fact question from Wikidata (issue #1172 R3).
///
/// Every byte comes through `client`. `None` when the prompt is not a fact
/// question, Wikidata states nothing for it, or a capture cannot be read.
pub fn try_fact_live_answer<T: SourceTransport>(
    prompt: &str,
    log: &mut EventLog,
    client: &CachedSourceClient<T>,
) -> Option<SymbolicAnswer> {
<<<<<<< HEAD
    let question = live_fact_question(prompt)?;
    log.append_search_request(
        "wikidata",
        format!("{}:{}", question.relation, question.subject_term),
    );
=======
    try_rewritten_fact_answer(prompt, prompt, log, client)
}

pub(super) fn try_rewritten_fact_answer<T: SourceTransport>(
    prompt: &str,
    rewritten: &str,
    log: &mut EventLog,
    client: &CachedSourceClient<T>,
) -> Option<SymbolicAnswer> {
>>>>>>> origin/main
    let language = detect_language(prompt).slug();
    let mut questions = live_fact_questions(rewritten).into_iter();
    let first = questions.next()?;
    answer_live_fact_question(prompt, &first, language, log, client).or_else(|| {
        questions
            .filter(|question| question.subject_term == first.subject_term)
            .find_map(|question| {
                answer_live_fact_question(prompt, &question, language, log, client)
            })
    })
}

fn answer_live_fact_question<T: SourceTransport>(
    prompt: &str,
    question: &LiveFactQuestion,
    language: &str,
    log: &mut EventLog,
    client: &CachedSourceClient<T>,
) -> Option<SymbolicAnswer> {
    record_fact_question(log, prompt, &question.relation, &question.subject_term);
    log.append("fact_live:relation", question.relation.as_str());
    log.append("fact_live:subject", question.subject_term.as_str());
    let statement =
        match resolve_fact_live(client, &question.relation, &question.subject_term, language) {
            Ok(Some(statement)) => statement,
            Ok(None) => {
                log.append("fact_live:no_match", question.subject_term.as_str());
                return None;
            }
            Err(error) => {
                log.append("fact_live:unavailable", error.to_string());
                return None;
            }
        };
    for capture in &statement.captures {
        capture.record(log);
    }
    log.append("fact_query:property", statement.property.as_str());
    log.append("fact_query:subject_qid", statement.subject_qid.as_str());
    log.append("wikidata", statement.subject_qid.as_str());
    if let Some(value_qid) = &statement.value_qid {
        log.append("fact_query:value_qid", value_qid.as_str());
        log.append("wikidata", value_qid.as_str());
    }
    log.append("source", statement.reference_url.as_str());
    let relation = relation_label(&question.relation, language);
    let slots = [
        ("relation", relation.as_str()),
        ("subject", statement.subject_label.as_str()),
        ("value", statement.value.as_str()),
        ("reference", statement.reference_url.as_str()),
    ];
    // A relation may seed its own phrasing (`fact_live_answer_<relation>`);
    // the generic template is the fallback, as in the browser twin.
    let own = render_template(
        &format!("fact_live_answer_{}", question.relation),
        language,
        &slots,
    );
    let body = if own.is_empty() {
        render_template("fact_live_answer", language, &slots)
    } else {
        own
    };
    if body.is_empty() {
        return None;
    }
    Some(finalize_simple(
        prompt,
        log,
        LIVE_FACT_INTENT,
        "response:fact_live_answer",
        &body,
        0.88,
    ))
}

/// The concept an explanation request asks about (issue #1172 R8).
///
/// The prompt must open with a `capability_act_explain` surface; the concept
/// is the subject phrase following that surface.
#[must_use]
pub fn explanation_concept(prompt: &str) -> Option<String> {
    let normalized = normalize_prompt(prompt);
    if normalized.is_empty() || contains_cjk(&normalized) {
        return None;
    }
    let cue = role_surfaces(seed::ROLE_CAPABILITY_ACT_EXPLAIN)
        .into_iter()
        .find(|cue| locate(&normalized, cue) == Some(0))?;
    let rest = normalized.strip_prefix(cue.as_str())?;
    bounded_subject(rest.trim())
}

/// Answer an explanation request from retrieved pages (issue #1172 R8).
///
/// Each statement of a retrieved page that mentions the concept is quoted
/// with the page URL and its SHA-256.
#[cfg(feature = "meta-language")]
pub fn try_explanation_research<T: SourceTransport>(
    prompt: &str,
    log: &mut EventLog,
    client: &CachedSourceClient<T>,
) -> Option<SymbolicAnswer> {
    let concept = explanation_concept(prompt)?;
    let language = detect_language(prompt).slug();
    log.append("explanation_research:concept", concept.as_str());
    let bounds = crate::source_walk::LookupBounds::default();
    let Some((source_id, senses)) =
        crate::concept_lookup::research_page_senses(client, &concept, language, &bounds)
    else {
        log.append("explanation_research:unavailable", concept);
        return None;
    };
    if senses.is_empty() {
        log.append("explanation_research:no_statement", concept);
        return None;
    }
    log.append("explanation_research:source", source_id);
    let mut rows = Vec::with_capacity(senses.len());
    for sense in &senses {
        log.append("source", sense.source_url.as_str());
        rows.push(render_template(
            "explanation_research_row",
            language,
            &[
                ("statement", sense.gloss.as_str()),
                ("url", sense.source_url.as_str()),
                ("sha256", sense.sha256.as_str()),
            ],
        ));
    }
    let rows = rows.join("\n");
    let body = render_template(
        "explanation_research_answer",
        language,
        &[("concept", concept.as_str()), ("rows", rows.as_str())],
    );
    if body.is_empty() {
        return None;
    }
    Some(finalize_simple(
        prompt,
        log,
        EXPLANATION_INTENT,
        "response:explanation_research_answer",
        &body,
        0.8,
    ))
}

/// The `fact_lookup` row through a caller-supplied capture client.
///
/// A seeded record answers first (R2, R6, R7), then the live Wikidata answer
/// (R3), then an explanation from retrieved pages (R8).
pub fn try_fact_lookup_with_client<T: SourceTransport>(
    prompt: &str,
    normalized: &str,
    log: &mut EventLog,
    client: &CachedSourceClient<T>,
) -> Option<SymbolicAnswer> {
    // Conversation references belong to the coreference row.
    if super::resolves_coreference_request(prompt, log) {
        return None;
    }
<<<<<<< HEAD
    super::try_fact_lookup(prompt, normalized, log)
        .or_else(|| try_fact_live_answer(prompt, log, client))
        .or_else(|| explanation_fallback(prompt, log, client))
}

=======
    if let Some(answer) = super::project_origin::try_project_origin(prompt, log, client)
        .or_else(|| publisher_fact_answer(prompt, normalized, log, client))
        .or_else(|| super::factual_qa::try_live_fact_comparison(prompt, log, client))
        .or_else(|| try_fact_live_answer(prompt, log, client))
    {
        return Some(answer);
    }
    explanation_fallback(prompt, log, client)
}

fn publisher_fact_answer<T: SourceTransport>(
    prompt: &str,
    normalized: &str,
    log: &mut EventLog,
    client: &CachedSourceClient<T>,
) -> Option<SymbolicAnswer> {
    let language = detect_language(prompt).slug();
    let today = crate::external_benchmarks::today_utc();
    let rendered =
        if let Some((record, gate)) = super::factual_qa::gated_fact_record(prompt, normalized) {
            if record.release_timeline.is_empty() {
                return publisher_policy_answer(prompt, record, &gate, log, client);
            }
            let rendered = crate::release_timeline::try_release_timeline(
                &record.release_timeline,
                language,
                &today,
                log,
                client,
            )?;
            record_publisher_fact(record, &gate, log);
            rendered
        } else {
            crate::release_timeline::try_open_release_timeline(
                normalized, language, &today, log, client,
            )?
        };
    log.append("fact_lookup:request", prompt);
    Some(finalize_simple(
        prompt,
        log,
        "fact_lookup",
        "response:fact_lookup",
        &rendered.text,
        0.9,
    ))
}

fn publisher_policy_answer<T: SourceTransport>(
    prompt: &str,
    record: &seed::FactRecord,
    gate: &str,
    log: &mut EventLog,
    client: &CachedSourceClient<T>,
) -> Option<SymbolicAnswer> {
    if record.publisher_heading.is_empty() || record.source_kind != "official-docs" {
        return None;
    }
    let language = detect_language(prompt).slug();
    let source = record.source_for(language);
    let url = url::Url::parse(source).ok()?;
    if url.scheme() != "https" || !url.username().is_empty() || url.password().is_some() {
        return None;
    }
    log.append("publisher_policy:request", source);
    let capture = match client.fetch(source) {
        Ok(capture) => capture,
        Err(error) => {
            log.append("publisher_policy:unavailable", error.to_string());
            return None;
        }
    };
    let Some(excerpt) = crate::solver_handler_how::practical_help::section_excerpt(
        capture.bytes(),
        &record.publisher_heading,
        &record.publisher_terms,
    ) else {
        log.append("publisher_policy:rejected", "no_matching_excerpt");
        return None;
    };
    let key = "publisher-policy-excerpt";
    let body = render_template(key, language, &[("source", source), ("excerpt", &excerpt)]);
    if body.is_empty() {
        return None;
    }
    capture.record(log);
    log.append("source", source);
    record_publisher_fact(record, gate, log);
    Some(finalize_simple(
        prompt,
        log,
        "fact_lookup",
        &format!("response:{key}"),
        &body,
        0.85,
    ))
}

fn record_publisher_fact(record: &seed::FactRecord, gate: &str, log: &mut EventLog) {
    log.append("fact_lookup:hit", record.slug.clone());
    log.append("fact_lookup:subject_gate", gate);
    for identifier in &record.wikidata {
        log.append("wikidata", identifier.as_str());
    }
}

/// The R8 step of the row.
>>>>>>> origin/main
#[cfg(feature = "meta-language")]
use self::try_explanation_research as explanation_fallback;

/// Without the page formalizer there is no retrieve-and-formalize path.
#[cfg(not(feature = "meta-language"))]
fn explanation_fallback<T: SourceTransport>(
    _prompt: &str,
    _log: &mut EventLog,
    _client: &CachedSourceClient<T>,
) -> Option<SymbolicAnswer> {
    None
}

/// The `fact_lookup` row over the process capture cache.
///
/// Transport is enabled only when the runtime opted into live fetches
/// (`offline` false); offline, verified runtime captures still replay and a miss
/// falls through.
pub fn try_fact_lookup_with_offline(
    prompt: &str,
    normalized: &str,
    log: &mut EventLog,
    offline: bool,
) -> Option<SymbolicAnswer> {
    try_fact_lookup_with_client(prompt, normalized, log, &capture_client(offline))
}
