from pathlib import Path
import json,hashlib,subprocess
r=Path("/tmp/issue-1580-research/dependency-source-warning-909")
r.mkdir(exist_ok=False)
parent=Path("scripts/check-dependencies-latest.rs")
child=Path("scripts/check-dependencies-snapshot.rs")
test=Path("rust/tests/web/issue-1580-source-warning-headroom.test.mjs")
before=parent.read_text()
oldchild=child.read_text()
(r/"check-dependencies-latest.rs.before").write_text(before)
(r/"check-dependencies-snapshot.rs.before").write_text(oldchild)
text=test.read_text()
needle="  'scripts/check-dependencies-latest.rs',\n"
assert needle not in text
text=text.replace("const files = [\n","const files = [\n  'scripts/check-dependencies-latest.rs',\n  'scripts/check-dependencies-snapshot.rs',\n")
test.write_text(text)
with (r/"before.stdout").open("w") as out,(r/"before.stderr").open("w") as err:
 result=subprocess.run(["timeout","600","node","--test","--test-concurrency=1",str(test)],stdout=out,stderr=err)
assert result.returncode!=0,"909-line warning must reproduce before repair"
a=before.index("/// Findings as flat lino records, one per drift.")
b=before.index('#[path = "check-dependencies-latest-npm.rs"]',a)
moved=before[a:b].rstrip()+"\n"
after=before[:a]+before[b:]
assert "pub use snapshot_io::{read_snapshot, write_snapshot};" in after
after=after.replace("pub use snapshot_io::{read_snapshot, write_snapshot};","pub use snapshot_io::{read_snapshot, render_lino, write_snapshot};")
parent.write_text(after)
child.write_text(oldchild+"\n"+moved)
assert child.read_text().endswith(moved)
assert before[:a]==after[:a]
assert before[b:].replace("pub use snapshot_io::{read_snapshot, write_snapshot};","pub use snapshot_io::{read_snapshot, render_lino, write_snapshot};")==after[a:]
(r/"conservation.json").write_text(json.dumps({"parent":str(parent),"child":str(child),"movedBodySha256":hashlib.sha256(moved.encode()).hexdigest(),"parentLinesBefore":len(before.splitlines()),"parentLinesAfter":len(after.splitlines()),"childLinesBefore":len(oldchild.splitlines()),"childLinesAfter":len(child.read_text().splitlines()),"exactMovedBody":True,"unchangedRemainingParent":True,"nativeExecution":False,"independentAuthorshipCredit":0},indent=2)+"\n")
checks=[["rustfmt","--edition","2024","--config","skip_children=true","--check",str(parent),str(child)],["timeout","600","node","--test","--test-concurrency=1",str(test)]]
results=[]
for i,c in enumerate(checks):
 with (r/("after-"+str(i)+".stdout")).open("w") as out,(r/("after-"+str(i)+".stderr")).open("w") as err:
  p=subprocess.run(c,stdout=out,stderr=err)
 results.append({"command":c,"exitCode":p.returncode})
(r/"outcome.json").write_text(json.dumps(results,indent=2)+"\n")
assert all(x["exitCode"]==0 for x in results),results
print((r/"conservation.json").read_text())
print(json.dumps(results))
