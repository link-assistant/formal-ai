from pathlib import Path
import datetime,gzip,hashlib,json,re,subprocess,urllib.request
root=Path.cwd();scratch=Path('/tmp/issue-1580-research')
validation=json.loads((scratch/'runtime-warning-validation/outcome.json').read_text())
assert validation['complete'] and len(validation['checks'])==10 and all(c['exit']==0 for c in validation['checks']),validation
entry=(scratch/'runtime-warning-validation/maintained-entry.log').read_text()
assert re.search(r'tests 335\b',entry) and re.search(r'pass 335\b',entry) and re.search(r'fail 0\b',entry)
terminal=json.loads((scratch/'bootstrap-all-terminal-logs/outcome.json').read_text())
assert terminal['complete'] and len(terminal['runs'])==34,terminal.keys()
annotations=json.loads((scratch/'bootstrap-hosted-round/check-annotations/summary.json').read_text())
assert annotations['checkCount']==173 and sum(r['count'] for r in annotations['annotated'])==31
out=root/'experiments/issue-1580/evidence/checks/terminal-warning-repairs';out.mkdir(exist_ok=True)
rows=[]
def seal(path,label):
 raw=path.read_bytes();compressed=gzip.compress(raw,mtime=0);target=out/(label+'.gz');assert not target.exists(),target
 target.write_bytes(compressed)
 assert gzip.decompress(target.read_bytes())==raw
 rows.append({'file':target.name,'bytes':len(raw),'lines':len(raw.splitlines()),'sha256':hashlib.sha256(raw).hexdigest(),'compressedBytes':len(compressed),'compressedSha256':hashlib.sha256(compressed).hexdigest()})
for directory in ['warning-repair-validation','warning-final-validation','runtime-warning-validation','bootstrap-final-gates','current-acceptance-feedback']:
 for p in sorted((scratch/directory).glob('*')):
  if p.is_file():seal(p,directory+'--'+p.name)
for row in terminal['runs']:
 p=Path(row['path']);raw=p.read_bytes()
 assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
 seal(p,'hosted-complete-workflow--'+p.name)
for p in sorted((scratch/'bootstrap-all-terminal-logs').glob('*.json')):seal(p,'hosted-diagnostics--'+p.name)
for p in sorted((scratch/'bootstrap-hosted-round/check-annotations').glob('*.json')):seal(p,'hosted-check-annotations--'+p.name)
procedures=['read-experimental-warnings.py','read-experimental-warnings-driver.log','read-warning-source.py','read-warning-source-driver.log','read-warning-repair-targets.py','read-warning-repair-targets-driver.log','prepare-runtime-warning-repair.py','prepare-runtime-warning-repair-driver.log','read-javascript-runtime-job.py','read-javascript-runtime-job-driver.log','fix-runtime-warnings.py','fix-runtime-warnings-driver.log','verify-runtime-warning-repair.py','verify-runtime-warning-repair-driver.log','correct-runtime-regression-target.py','correct-runtime-regression-target-driver.log','correct-runtime-regression-target-retry-driver.log','verify-runtime-warning-repair-retry-driver.log','final-warning-validation.py','final-warning-validation-driver.log','warning-review.patch','prepare-warning-review.py','prepare-warning-review-driver.log','collect-bootstrap-all-terminal-logs.py','collect-bootstrap-check-annotations.py','collect-bootstrap-check-annotations-final-driver.log','commit-bootstrap-source-batch.py','commit-bootstrap-source-batch-driver.log','fix-bootstrap-evidence-names.py','fix-bootstrap-evidence-names-driver.log','check-final-bootstrap-gates.py','archive-terminal-warning-repairs.py']
procedures += ['commit-terminal-warning-source.py','commit-terminal-warning-source-driver.log']
for name in procedures:
 p=scratch/name
 if p.exists():seal(p,'procedure--'+name)
for version in ['v24.22.3','v22.23.5']:
 url=f'https://raw.githubusercontent.com/nodejs/node/{version}/lib/sqlite.js'
 raw=urllib.request.urlopen(url).read();p=scratch/'runtime-warning-validation'/('official-node-'+version+'-sqlite.js');p.write_bytes(raw)
 seal(p,'official-node-'+version+'-sqlite.js')
parts=[]
for offset in range(0,len(rows),80):
 name=f'manifest-files-{offset//80+1}.json';raw=(json.dumps(rows[offset:offset+80],indent=2)+'\n').encode();(out/name).write_bytes(raw)
 parts.append({'file':name,'files':len(rows[offset:offset+80]),'sha256':hashlib.sha256(raw).hexdigest()})
manifest={'schema':'issue-1580-terminal-warning-repairs/v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseSource':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'publishedSource':annotations['head'],'workflowCount':34,'workflowConclusions':{'success':30,'skipped':1,'failure':3},'checkCount':173,'annotationCount':31,'fileCount':len(rows),'parts':parts,'maintainedCases':335,'authorshipCredit':0,'reasoningCredit':0,'localRuntime':'Node 26.13.0; not proof of the newly selected hosted Node 24.22.3','hostedQualification':'pending next source and actual worker compilation','readScope':'All complete workflow streams scanned for diagnostics; selected diagnostics and contexts reviewed. No claim that all 68,174 Pipeline lines were literally read.'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
note='''# Completed CI round and warning repairs

Published source `d1d11e6039845ead74f1cb229266acb9ea42823d` completed all
34 observed workflows: 30 succeeded, one skipped and three failed. The full
34 workflow streams and all 31 annotations from 173 checks are retained with
original and compressed byte hashes. A complete-stream diagnostic scan found
the worker compiler error, stale worker receipt, source/checkout failures,
missing interface companion, nine deprecated artifact-download calls, one
Hive timing warning, the deliberate BuildKit outage annotation, two SQLite
experimental imports and one experimental timer mock. Selected diagnostics
and their actual source were reviewed; the entire 68,174-line Pipeline stream
was not literally read. The passing test name containing “warn category” is
a scan false positive, not a runtime warning.

The source and native companion repairs are recorded in
[the bootstrap checkpoint](bootstrap-ci-repair.md). The standalone wrapper is
now receipt-bound together with the main binary. All ten family groups reuse
verified finite executables in the regression, with zero Cargo invocations.
This fixture result does not replace the next hosted native execution.

The Hive workflow test combined four complete language sessions into one
696.84-second case and crossed the unchanged 675-second warning boundary.
Extract exactly its existing session/assertion body into one helper and expose
Kotlin, Scala, Rust and Python as separate real tests. Both complete bodies
have the same normalized SHA256. Four measured-weight shards retain every
listed test exactly once, two concurrent jobs, single native test threads,
the 900-second command budget and the 20-minute job clock. New language weights
are explicitly labeled estimates of 169 seconds, derived from the historical
672.933-second aggregate; they are not new hosted duration observations.
All 62 runner/admission regressions pass; rustfmt passes without a Rust build.

The deliberate canonical BuildKit pull failure emitted a failure annotation
even though the real mirror recovered. Stop command parsing only around that
negative-control action, using a fresh random token. Always resume commands;
non-success outcomes then emit a real error and remain fatal. Actual mirror
image and daemon verification follows with ordinary annotations enabled.
All 11 controls pass, including failure, cancellation, skip and empty outcomes.
The production setup action and its failure behavior are unchanged.

The two SQLite consumers now explicitly select Node 24.22.3 instead of Node 22
or the runner's ambient executable. Its upstream SQLite module no longer calls
the experimental-warning emitter; the API is still a release candidate, not
fully stable. See the [official API history](https://nodejs.org/docs/latest-v24.x/api/sqlite.html)
and [versioned implementation](https://github.com/nodejs/node/blob/v24.22.3/lib/sqlite.js).
The regression exercises a real SQLite round trip and emits an independent
sentinel to prove that process warnings remain enabled. Local Node 26 execution
does not qualify the selected hosted Node 24 binary; that awaits CI. The link
test uses stable method mocks, observes the exact remaining 15 ms budget,
asserts cancellation and verifies timer cleanup. All 16 link tests pass.

The crates.io warning is an honest unavailable credential observation, not an
invalid-token verdict: a public crate lookup cannot verify a publish-scoped
token. No credential is sent to a cookie-only endpoint and no publication is
performed to manufacture verification. Registry uncertainty remains explicit.

The final maintained entry passes 335 cases. Production checkout tests pass
21/21; the two runtime checks, the touched size/readability/filename/scheduling
and workflow gates, and whitespace checks pass. Earlier incorrect gate names,
the mistaken test job key, source-selector corrections and failed before-fix
controls are retained separately and receive no verification credit. The full
local inventory's earlier 87 passes, 53 hosted-only skips and one genuine stale
worker failure remain its actual outcome, not 88 passes. Hosted worker
regeneration, final-head native checks, complete template/practice acceptance,
whole-PR review and the independent-authorship floor remain unfinished.
Supplied procedures and conclusions receive zero autonomous credit.

Evidence: `experiments/issue-1580/evidence/checks/terminal-warning-repairs/`.
Pull request: https://github.com/link-assistant/formal-ai/pull/1581.
'''
(root/'docs/case-studies/issue-1580/terminal-warning-repairs.md').write_text(note)
p=root/'experiments/issue-1580/work-plan.md'
with p.open('a') as stream:stream.write('''

### 2026-11-21: terminal bootstrap round and complete warning batch

- [x] Collect all 34 complete workflow logs for published `d1d11e603`, compare
  source/timestamps, and preserve all 31 annotations from 173 checks. Three
  genuine failing workflows and the additional warnings are now classified.
- [x] Split the original four complete Hive sessions into independent tests;
  preserve the whole assertion body and all deadlines. Four shards retain the
  complete listing. Explicit estimates await new hosted measurements.
- [x] Contain only the deliberate BuildKit negative-control annotations;
  unexpected setup outcomes remain fatal after annotation handling resumes.
- [x] Provision Node 24.22.3 for the actual SQLite consumers, retain an active
  warning-channel sentinel, and replace the experimental link timer mock.
- [x] Final local maintained entry: 335 passes. Native runner controls: 62;
  BuildKit controls: 11; finite artifact controls: 9; link parser: 16;
  production checkout: 21. Touched JavaScript gates, formatting and whitespace
  pass. No local Rust compilation or execution took place.
- [ ] Publish the complete batch after a fresh default-branch/queue preflight;
  qualify actual hosted worker regeneration and all final-head CI paths.
- [ ] Complete the original template/practice mapping, aggregate PR review and
  genuine independent-authorship floor. Expected crates.io token uncertainty
  is retained; supplied scripts and patches earn zero autonomous credit.

Current evidence: [terminal warning repairs](../../docs/case-studies/issue-1580/terminal-warning-repairs.md).
Earlier checkpoints retain their original pins and outcomes.
''')
p=root/'changelog.d/20261121_1580_bootstrap_ci_repairs.md'
with p.open('a') as stream:stream.write('''- Schedule all four complete Hive workflow sessions independently under the
  existing execution budgets, and retain real failures in the BuildKit outage
  control without false failure annotations after successful recovery.
- Select the maintained SQLite runtime explicitly and remove the experimental
  timer mock while preserving warning reporting and deadline assertions.
''')
print(json.dumps({'files':len(rows),'archiveBytes':sum(r['compressedBytes'] for r in rows),'workflowLogs':34,'checks':173,'annotations':31,'localCases':335,'manifest':str(out/'manifest.json'),'authorshipCredit':0}))
