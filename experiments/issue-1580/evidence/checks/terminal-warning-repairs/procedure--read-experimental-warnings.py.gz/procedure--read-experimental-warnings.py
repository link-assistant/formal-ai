from pathlib import Path
import subprocess
base=Path('/tmp/issue-1580-research/bootstrap-all-terminal-logs')
print('MANIFEST FILES')
print('\n'.join(str(p) for p in base.glob('*.json')))
for run, first, last in [('44950901905',20510,20560),('44950902013',58625,58680)]:
 path=next(base.glob(run+'*.log'))
 print(str(path))
 for n,line in enumerate(path.open(errors='replace'),1):
  if first<=n<=last: print(f'{n}: {line}',end='')
for p in base.glob('*-diagnostics.json'):
 if 'MockTimers' in p.read_text():
  print(p.read_text())
  path=base/(p.name.split('-')[0]+'.log')
  if path.exists():
   for n,line in enumerate(path.open(errors='replace'),1):
    if 245<=n<=285: print(f'{n}: {line}',end='')
for args in [['rg','-n','node:sqlite|mock\\.timers|enableExperimental|ExperimentalWarning','scripts','rust/tests/web','js','.github/workflows'],['rg','-n','node-version:|NODE_VERSION|Release Preflight|preflight-credentials','data/meta','.github/workflows'],['sed','-n','1,170p','experiments/issue-1580/work-plan.md']]:
 r=subprocess.run(args,capture_output=True,text=True)
 print('COMMAND',args,'EXIT',r.returncode)
 print(r.stdout[:35000])
