from pathlib import Path
import subprocess,json
def run(*args,**kw):return subprocess.run(args,check=True,text=True,capture_output=True,**kw)
assert run('git','branch','--show-current').stdout.strip()=='issue-1580-8d61a32a61e1'
assert not run('git','diff','--cached','--name-only').stdout.strip(),'unexpected pre-staged changes'
validation=json.loads(Path('/tmp/issue-1580-research/runtime-warning-validation/outcome.json').read_text())
assert validation['complete'] and all(c['exit']==0 for c in validation['checks'])
path='.github/workflows/native-type-check.yml'
patch=run('git','diff','--',path).stdout
header=patch[:patch.index('@@')]
hunks=['@@'+hunk for hunk in patch.split('@@')[1:]]
# Split on complete unified hunk headers, preserving each hunk's range.
import re
pieces=re.split(r'(?=^@@ )',patch,flags=re.M)
selected=[h for h in pieces[1:] if 'group: [coding-1' in h]
assert len(selected)==1
run('git','apply','--cached','-',input=header+selected[0])
groups=[('test: schedule complete Hive workflow sessions independently',[
 'rust/tests/unit/issue_1133_hive_mind_three_runs.rs','scripts/ci-native-regressions.sh','scripts/ci-native-hive-durations.lino','experiments/issue-1580/derive-native-hive-durations.py','experiments/issue-1580/native-regression-groups.test.mjs','experiments/issue-1580/native-contract-artifact.test.mjs']),
 ('test: retain real errors in the BuildKit outage control',['.github/workflows/workflows.yml','experiments/issue-1580/buildkit-image-identity.test.mjs']),
 ('fix: select the SQLite CI runtime and stable deadline mocks',['.github/workflows/layered-ci.yml','.github/workflows/native-type-check.yml','experiments/issue-1580/javascript-runtime-warnings.test.mjs','scripts/recheck-broken-links.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs'])]
for message,files in groups:
 run('git','add','--',*files);run('git','diff','--cached','--check');run('git','commit','-m',message)
 print(json.dumps({'commit':run('git','rev-parse','HEAD').stdout.strip(),'message':message,'files':files,'autonomousAuthorshipCredit':0}))
