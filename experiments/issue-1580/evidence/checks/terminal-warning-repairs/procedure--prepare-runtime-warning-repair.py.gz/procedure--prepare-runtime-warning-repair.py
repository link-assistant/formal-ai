from pathlib import Path
import subprocess,json
out=Path('/tmp/issue-1580-research/runtime-warning-validation');out.mkdir(exist_ok=True)
for path,first,last in [('.github/workflows/layered-ci.yml',610,645),('rust/tests/web/dynamic-meta-http.test.mjs',1,170),('rust/tests/web/dynamic-meta.test.mjs',1,75)]:
 p=Path(path)
 print('FILE',path)
 if not p.exists():continue
 for n,line in enumerate(p.open(),1):
  if first<=n<=last:print(f'{n}: {line}',end='')
for name,args in [('diff',['git','diff','--','.github/workflows/native-type-check.yml','.github/workflows/workflows.yml','scripts/ci-native-regressions.sh','experiments/issue-1580/derive-native-hive-durations.py']),('dynamic-inventory',['rg','-n','dynamic-meta|node-version|SQLite|node:sqlite','rust/tests/web/dynamic-meta-http.test.mjs','rust/tests/web/dynamic-meta.test.mjs','.github/workflows/layered-ci.yml','.github/workflows/native-type-check.yml','scripts/ci-native-regressions.sh'])]:
 r=subprocess.run(args,capture_output=True,text=True);(out/(name+'.log')).write_text(r.stdout+r.stderr);print(name,'bytes',len(r.stdout+r.stderr))
