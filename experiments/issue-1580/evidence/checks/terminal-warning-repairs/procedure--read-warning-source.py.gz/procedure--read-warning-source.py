from pathlib import Path
import subprocess
for path,first,last in [('scripts/recheck-broken-links.test.mjs',1,90),('scripts/recheck-broken-links.test.mjs',280,385),('scripts/recheck-broken-links.mjs',1,300),('.github/workflows/broken-links.yml',1,150),('scripts/preflight-credentials.sh',1,230),('js/server/dynamic-meta/runtime.mjs',1,135),('.github/workflows/native-type-check.yml',115,150),('.github/workflows/native-type-check.yml',285,320),('.github/workflows/layered-ci.yml',240,290)]:
 p=Path(path)
 if not p.exists():
  print('MISSING',path); continue
 print('\nFILE',path)
 for n,line in enumerate(p.open(),1):
  if first<=n<=last: print(f'{n}: {line}',end='')
print(subprocess.run(['rg','-n','recheck-broken-links|dynamic-meta-native-parity|dynamic-meta|node-version','rust/tests/web/fast-pull-request-production-profile.test.mjs','rust/tests/web/ci-speed.test.mjs','.github/workflows/check-links.yml','.github/workflows/native-type-check.yml','.github/workflows/layered-ci.yml'],capture_output=True,text=True).stdout)
