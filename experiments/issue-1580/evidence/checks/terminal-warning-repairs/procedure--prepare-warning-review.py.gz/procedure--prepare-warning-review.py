from pathlib import Path
import subprocess,json
out=Path('/tmp/issue-1580-research/warning-review.patch')
r=subprocess.run(['git','diff','--','.github/workflows/layered-ci.yml','.github/workflows/native-type-check.yml','.github/workflows/workflows.yml','experiments/issue-1580/buildkit-image-identity.test.mjs','experiments/issue-1580/derive-native-hive-durations.py','experiments/issue-1580/native-contract-artifact.test.mjs','experiments/issue-1580/native-regression-groups.test.mjs','rust/tests/unit/issue_1133_hive_mind_three_runs.rs','scripts/ci-native-hive-durations.lino','scripts/ci-native-regressions.sh','scripts/recheck-broken-links.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs'],capture_output=True,text=True,check=True)
out.write_text(r.stdout)
print(json.dumps({'diff':str(out),'lines':len(r.stdout.splitlines()),'bytes':out.stat().st_size}))
print('ANNOTATION PATHS')
for p in Path('/tmp/issue-1580-research').glob('*annotation*'):print(str(p))
print('CONTRIBUTING')
for n,line in enumerate(Path('CONTRIBUTING.md').open(),1):
 if n<=135: print(f'{n}: {line}',end='')
