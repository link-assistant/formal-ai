from pathlib import Path
import subprocess,json,os
out=Path('/tmp/issue-1580-research/runtime-warning-validation');out.mkdir(exist_ok=True)
test=Path('experiments/issue-1580/javascript-runtime-warnings.test.mjs')
assert not test.exists()
test.write_text('''import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import YAML from 'yaml';

test('SQLite consumers provision a runtime without the experimental import warning', () => {
  for (const [path, name] of [
    ['.github/workflows/layered-ci.yml', 'js'],
    ['.github/workflows/native-type-check.yml', 'check'],
  ]) {
    const job = YAML.parse(readFileSync(path, 'utf8')).jobs[name];
    assert(job, `${path}: missing consumer ${name}`);
    const setup = job.steps.find(step => step.uses === 'actions/setup-node@v7');
    assert(setup, `${path}: consumer must not depend on the runner's ambient Node`);
    const version = String(setup.with['node-version']).split('.').map(Number);
    assert(version[0] === 24 && version[1] >= 15,
      `${path}: SQLite requires the Node 24 release-candidate implementation`);
  }
});

test('the actual runtime reads and writes SQLite without hiding process warnings', {timeout: 5000}, () => {
  const result = spawnSync(process.execPath, ['--input-type=module', '-e', `
    import {DatabaseSync} from 'node:sqlite';
    const database = new DatabaseSync(':memory:');
    database.exec('CREATE TABLE sample (value TEXT NOT NULL)');
    database.prepare('INSERT INTO sample VALUES (?)').run('preserved');
    if (database.prepare('SELECT value FROM sample').get().value !== 'preserved') {
      throw new Error('SQLite round trip failed');
    }
    database.close();
    process.emitWarning('diagnostic sentinel', {code: 'CI_DIAGNOSTIC_SENTINEL'});
  `], {encoding: 'utf8', timeout: 3000, maxBuffer: 65536,
    env: {...process.env, NODE_OPTIONS: '--max-old-space-size=64'}});
  assert.equal(result.error, undefined, String(result.error));
  assert.equal(result.status, 0, result.stderr);
  assert.doesNotMatch(result.stderr, /ExperimentalWarning/u);
  assert.match(result.stderr, /CI_DIAGNOSTIC_SENTINEL.*diagnostic sentinel/u,
    'the warning channel must remain active');
});
''')
entry=Path('rust/tests/web/issue-1580-template-observations.test.mjs')
entry.write_text(entry.read_text()+"\nimport '../../../experiments/issue-1580/javascript-runtime-warnings.test.mjs';\n")
# Capture the regression against the original workflow configuration.
with (out/'runtime-before.log').open('w') as log:
 r=subprocess.run(['node','--test','--test-concurrency=1',str(test)],stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'})
assert r.returncode!=0,'negative control unexpectedly passed'
p=Path('.github/workflows/layered-ci.yml');text=p.read_text()
start=text.index('  js:\n');end=text.index('\n  ',start+7)
# Job keys have exactly two leading spaces; nested keys have four or more.
import re
match=re.search(r'\n  [a-zA-Z][a-zA-Z0-9-]*:\n',text[start+7:])
assert match
end=start+7+match.start()
section=text[start:end]
anchor='          sparse-checkout-cone-mode: false\n'
assert section.count(anchor)==1
section=section.replace(anchor,anchor+'''      - name: Set up the SQLite release-candidate runtime
        uses: actions/setup-node@v7
        with:
          node-version: '24.22.3'
''',1)
p.write_text(text[:start]+section+text[end:])
p=Path('.github/workflows/native-type-check.yml');text=p.read_text()
assert text.count('with: {node-version: 22}')==3
text=text.replace('with: {node-version: 22}',"with: {node-version: '24.22.3'}",1)
p.write_text(text)
p=Path('scripts/recheck-broken-links.test.mjs');text=p.read_text()
old="  t.mock.timers.enable({apis: ['setTimeout']});\n  let requestSignal;"
new="""  let fireTimeout;
  const timer = Symbol('request deadline');
  const cleared = [];
  t.mock.method(globalThis, 'setTimeout', (callback, milliseconds) => {
    assert.equal(milliseconds, 15, 'request timeout must use the remaining shared budget');
    fireTimeout = callback;
    return timer;
  });
  t.mock.method(globalThis, 'clearTimeout', handle => cleared.push(handle));
  let requestSignal;"""
assert text.count(old)==1
text=text.replace(old,new)
assert text.count('  t.mock.timers.tick(15);')==1
text=text.replace('  t.mock.timers.tick(15);',"  assert.equal(requestSignal.aborted, false);\n  fireTimeout();")
old="  const result = await pending;\n  assert.equal(result.get('https://silent.example/').outcome, 'unreachable');"
assert text.count(old)==1
text=text.replace(old,old+"\n  assert.deepEqual(cleared, [timer], 'the completed request releases its timer');")
p.write_text(text)
print(json.dumps({'beforeExit':r.returncode,'filesChanged':[str(test),str(entry),'.github/workflows/layered-ci.yml','.github/workflows/native-type-check.yml',str(p)],'authorshipCredit':0}))
