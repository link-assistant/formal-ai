from pathlib import Path
import re,json
p=Path('.github/workflows/native-type-check.yml');text=p.read_text()
jobs=re.findall(r'^  ([a-zA-Z][a-zA-Z0-9-]*):$',text,re.M)
print('actual job keys',jobs)
assert jobs[0]=='clippy',jobs
p=Path('experiments/issue-1580/javascript-runtime-warnings.test.mjs');text=p.read_text()
assert text.count("['.github/workflows/native-type-check.yml', 'check']")==1
p.write_text(text.replace("['.github/workflows/native-type-check.yml', 'check']","['.github/workflows/native-type-check.yml', 'clippy']"))
out=Path('/tmp/issue-1580-research/runtime-warning-validation')
(out/'runtime-after.log').rename(out/'runtime-after-wrong-job-key.log')
(out/'outcome.json').rename(out/'wrong-job-key-outcome.json')
print(json.dumps({'correction':'bind to the observed clippy job key','authorshipCredit':0}))
