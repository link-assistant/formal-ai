from pathlib import Path
import subprocess,json,re,time,os,sys,hashlib
out=Path('/tmp/issue-1580-research/bootstrap-all-terminal-logs');out.mkdir(exist_ok=True)
if len(sys.argv)==1:
 with (out/'supervisor.log').open('w') as log:p=subprocess.Popen([sys.executable,__file__,'worker'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'outcome':str(out/'outcome.json')}));raise SystemExit(0)
source=Path('/tmp/issue-1580-research/bootstrap-hosted-round');head=(source/'head.log').read_text().strip()
runs=json.loads(sorted(source.glob('*-runs.json'))[-1].read_text());runs=[run for run in runs if run['headSha']==head];assert len(runs)==34 and all(run['status']=='completed' for run in runs)
rows=[];diagnostics=[]
pattern=re.compile(r'##\[(?:error|warning)\]|(?:\(node:\d+\).*?(?:DeprecationWarning|ExperimentalWarning))|(?:^|\s)(?:warning:|npm warn|WARN |WARNING:)',re.I)
for run in runs:
 identity=str(run['databaseId']);p=out/(identity+'.log');existing=source/(identity+'-complete.log')
 if not p.exists():
  if existing.exists():p.write_bytes(existing.read_bytes())
  else:
   with p.open('w') as stream:r=subprocess.run(['gh','run','view',identity,'--repo','link-assistant/formal-ai','--log'],stdout=stream,stderr=subprocess.STDOUT)
   assert r.returncode==0,(identity,p.read_text()[-2000:])
 raw=p.read_bytes();lines=raw.decode().splitlines();matched=[]
 for number,line in enumerate(lines,1):
  if pattern.search(line):matched.append({'line':number,'text':line})
 if matched:
  selected=out/(identity+'-diagnostics.json');selected.write_text(json.dumps(matched,indent=2)+'\n');diagnostics.append({'run':run,'selected':str(selected),'count':len(matched)})
 rows.append({'run':run,'path':str(p),'bytes':len(raw),'lines':len(lines),'sha256':hashlib.sha256(raw).hexdigest(),'diagnostics':len(matched)})
 (out/'outcome.json').write_text(json.dumps({'complete':False,'head':head,'runs':rows,'diagnostics':diagnostics},indent=2)+'\n')
 print(json.dumps({'id':identity,'workflow':run['workflowName'],'conclusion':run['conclusion'],'lines':len(lines),'diagnostics':len(matched)}),flush=True)
(out/'outcome.json').write_text(json.dumps({'complete':True,'head':head,'runs':rows,'diagnostics':diagnostics},indent=2)+'\n')
