from pathlib import Path
import subprocess,os,json,time
out=Path('/tmp/issue-1580-research/bootstrap-final-gates');out.mkdir(exist_ok=True)
environment={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'}
rows=[]
for gate in ['check-file-size','check-file-size-js-twin','check-readable-code','check-abbreviations','check-ci-speed','check_js_rust_translation','workflows']:
 command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate];start=time.monotonic()
 with (out/(gate+'.log')).open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=environment)
 row={'gate':gate,'exit':r.returncode,'seconds':round(time.monotonic()-start,3)};rows.append(row);print(json.dumps(row),flush=True)
(out/'outcome.json').write_text(json.dumps(rows,indent=2)+'\n')
assert all(row['exit']==0 for row in rows),rows
