from pathlib import Path
import subprocess,json,time,os,sys
out=Path('/tmp/issue-1580-research/warning-final-validation');out.mkdir(exist_ok=True)
if len(sys.argv)==1:
 with (out/'supervisor.log').open('w') as log:p=subprocess.Popen([sys.executable,__file__,'worker'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'outcome':str(out/'outcome.json')}));raise SystemExit(0)
checks=[(gate,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]) for gate in ['check-file-size-js-twin','check-readable-code','check-abbreviations','check-ci-speed','workflows']]
checks.append(('maintained-entry',['node','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs']))
checks.append(('whitespace',['git','diff','--check']))
rows=[]
for name,args in checks:
 start=time.monotonic();p=out/(name+'.log')
 with p.open('w') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256','PYTHONDONTWRITEBYTECODE':'1'})
 row={'name':name,'exit':r.returncode,'seconds':round(time.monotonic()-start,3),'path':str(p)};rows.append(row);print(json.dumps(row),flush=True)
 (out/'outcome.json').write_text(json.dumps({'complete':False,'checks':rows},indent=2)+'\n')
(out/'outcome.json').write_text(json.dumps({'complete':True,'checks':rows},indent=2)+'\n')
