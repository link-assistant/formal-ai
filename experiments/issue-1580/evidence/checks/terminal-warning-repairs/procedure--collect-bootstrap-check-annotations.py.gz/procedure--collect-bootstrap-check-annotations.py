from pathlib import Path
import subprocess,json,re,hashlib
root=Path('/tmp/issue-1580-research/bootstrap-hosted-round');out=root/'check-annotations';out.mkdir(exist_ok=True)
head=(root/'head.log').read_text().strip()
def fetch(name,endpoint):
 command=['gh','api',endpoint,'--paginate','--slurp'];r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/(name+'.json')).write_text(r.stdout);assert r.returncode==0,(command,r.stdout);return json.loads(r.stdout)
pages=fetch('check-runs',f'repos/link-assistant/formal-ai/commits/{head}/check-runs?per_page=100');checks=[row for page in pages for row in page['check_runs']]
rows=[]
for check in checks:
 if not check['output']['annotations_count']:continue
 annotations=[row for page in fetch(str(check['id']),f'repos/link-assistant/formal-ai/check-runs/{check["id"]}/annotations?per_page=100') for row in page]
 rows.append({'id':check['id'],'name':check['name'],'conclusion':check['conclusion'],'count':len(annotations),'annotations':[{'path':a['path'],'start':a['start_line'],'end':a['end_line'],'level':a['annotation_level'],'title':a['title'],'message':a['message']} for a in annotations]})
(out/'summary.json').write_text(json.dumps({'head':head,'checkCount':len(checks),'annotated':rows},indent=2)+'\n')
print(json.dumps({'head':head,'checks':len(checks),'annotatedChecks':len(rows),'annotations':sum(r['count'] for r in rows)}))
for row in rows:print(json.dumps(row))
