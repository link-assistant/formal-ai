from pathlib import Path
import subprocess
for first,last in [(297,355),(550,608)]:
 for n,line in enumerate(Path('.github/workflows/layered-ci.yml').open(),1):
  if first<=n<=last:print(f'{n}: {line}',end='')
print(subprocess.run(['rg','--files','.github/actions'],capture_output=True,text=True).stdout)
print(subprocess.run(['rg','-n','dynamic-meta|setup-node|node-version','experiments/issue-1580/ci-source-transport.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs','.github/actions/setup-ci-node/action.yml'],capture_output=True,text=True).stdout)
