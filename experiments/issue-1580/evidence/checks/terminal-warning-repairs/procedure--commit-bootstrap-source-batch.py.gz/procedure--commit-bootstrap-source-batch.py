from pathlib import Path
import subprocess,json
out=Path('/tmp/issue-1580-research/bootstrap-source-commits');out.mkdir(exist_ok=True)
assert '1/1 passed or skipped; failed: none' in Path('/tmp/issue-1580-research/bootstrap-final-gates/check-abbreviations-after.log').read_text()
def run(name,args):
 r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(out/(name+'.log')).write_text(r.stdout);assert r.returncode==0,(name,r.stdout);return r.stdout.strip()
assert run('branch',['git','branch','--show-current'])=='issue-1580-8d61a32a61e1'
run('whitespace',['git','diff','--check'])
groups=[('fix: detect stale worker inputs without local compilation',['js/wasm-worker/src/lib.rs','experiments/formal_ai_subagent/local-gates.mjs','experiments/issue-1580/local-worker-currency.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs']),('fix: retain verified native contract companion executables',['scripts/native-contract-artifact.mjs','experiments/issue-1580/native-contract-artifact.test.mjs','.github/workflows/native-type-check.yml','rust/tests/web/native-test-artifact.test.mjs']),('fix: preserve consumed sparse fixtures and first-wave scheduling',['.github/workflows/layered-ci.yml','experiments/issue-1580/ci-source-transport.test.mjs','rust/tests/web/fast-pull-request-production-profile.test.mjs','rust/tests/web/ci-speed.test.mjs'])]
rows=[]
for index,(message,files) in enumerate(groups):
 run(f'{index}-stage',['git','add','--',*files]);run(f'{index}-commit',['git','-c','gc.auto=0','commit','-m',message]);head=run(f'{index}-head',['git','rev-parse','HEAD']);rows.append({'commit':head,'message':message,'files':files});print(json.dumps(rows[-1]),flush=True)
(out/'outcome.json').write_text(json.dumps(rows,indent=2)+'\n');print(run('remaining-status',['git','status','--short']))
