from pathlib import Path
import json,hashlib,gzip,subprocess,os,time
root=Path.cwd();out=root/'experiments/issue-1580/evidence/checks/bootstrap-repair';index=json.loads((out/'manifest.json').read_text());renamed=[]
for part in index['parts']:
 path=out/part['file'];assert hashlib.sha256(path.read_bytes()).hexdigest()==part['sha256'];rows=json.loads(path.read_text())
 for row in rows:
  name=row['file'];new=name.replace('--lib.rs','--library.rs').replace('check-tests-as-docs','check-tests-as-documentation')
  source=out/name;raw=source.read_bytes();assert hashlib.sha256(raw).hexdigest()==row['compressedSha256'];assert hashlib.sha256(gzip.decompress(raw)).hexdigest()==row['sha256']
  if name!=new:
   destination=out/new;assert not destination.exists();source.rename(destination);row['file']=new;row['renamedFrom']=name;renamed.append({'before':name,'after':new})
 path.write_text(json.dumps(rows,indent=2)+'\n');part['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
assert len(renamed)==4,renamed
index['fullWordArchiveNames']=renamed;(out/'manifest.json').write_text(json.dumps(index,indent=2)+'\n')
scratch=Path('/tmp/issue-1580-research/bootstrap-final-gates');(scratch/'archive-name-correction.json').write_text(json.dumps(renamed,indent=2)+'\n')
with (scratch/'check-abbreviations-after.log').open('w') as log:r=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations'],stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'})
print(json.dumps({'archivesVerified':index['fileCount'],'renamed':renamed,'abbreviationRetry':r.returncode}));assert r.returncode==0
