from pathlib import Path
import subprocess,os
for path,first,last in [('.github/workflows/layered-ci.yml',215,300),('.github/workflows/native-type-check.yml',100,145),('.github/workflows/native-type-check.yml',285,315),('.github/workflows/native-type-check.yml',385,430),('.github/workflows/links.yml',1,100),('experiments/issue-1580/native-regression-groups.test.mjs',1,110)]:
 print('FILE',path)
 for n,line in enumerate(Path(path).open(),1):
  if first<=n<=last: print(f'{n}: {line}',end='')
args=['rg','-n','node-version.*22|setup-node|Node.js 22|Node 22','rust/tests/web/fast-pull-request-production-profile.test.mjs','rust/tests/web/dynamic-meta.test.mjs','rust/tests/web/dynamic-meta-http.test.mjs','experiments/issue-1580','rust/tests/web/ci-speed.test.mjs','rust/tests/web/native-test-artifact.test.mjs','data/meta/ci-checks.lino']
r=subprocess.run(args,capture_output=True,text=True);print(r.stdout[:9000])
for args in [['node','--version'],['bash','-c','command -v node; ls /opt/node/bin/node /usr/local/bin/node /usr/bin/node 2>/dev/null']]:
 print(subprocess.run(args,capture_output=True,text=True).stdout)
