from pathlib import Path
import datetime, json, os, subprocess, sys, time

root = Path('/tmp/issue-1580-research/clean-semantic-contract-gates-final')
if '--worker' not in sys.argv:
    assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
    root.mkdir(exist_ok=False)
    with (root / 'worker.log').open('w') as output:
        process = subprocess.Popen([sys.executable, __file__, '--worker'], stdout=output,
                                   stderr=subprocess.STDOUT, start_new_session=True)
    (root / 'pid.json').write_text(json.dumps({'pid': process.pid}) + '\n')
    print('Started the final complete clean-source gate run:', process.pid)
else:
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
    before = subprocess.check_output(['git', 'status', '--porcelain'], text=True)
    assert not before.strip()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    env = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
    clock = time.monotonic()
    command = ['node', 'experiments/formal_ai_subagent/local-gates.mjs']
    with (root / 'all-local-gates.log').open('w') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, env=env)
    status = subprocess.check_output(['git', 'status', '--porcelain'], text=True)
    after = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
    lines = (root / 'all-local-gates.log').read_text().splitlines()
    outcome = {'complete': True, 'head': head, 'headAfter': after, 'cleanBefore': True,
               'cleanAfter': not status.strip(), 'statusAfter': status,
               'command': command, 'exitCode': result.returncode,
               'pass': sum(line.startswith('PASS ') for line in lines),
               'failure': sum(line.startswith('FAIL ') for line in lines),
               'hostedOnlySkip': sum(line.startswith('SKIP ') for line in lines),
               'seconds': time.monotonic() - clock, 'startedAt': started,
               'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'localRustExecution': False}
    outcome['qualified'] = result.returncode == 0 and outcome['cleanAfter'] and after == head
    (root / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    print(json.dumps(outcome), flush=True)
