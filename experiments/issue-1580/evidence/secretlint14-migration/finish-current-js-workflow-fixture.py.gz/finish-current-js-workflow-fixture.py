from pathlib import Path
import hashlib,json,subprocess
base=Path('/tmp/issue-1580-research')
tree={r['path']:r for r in json.loads((base/'fresh-template-delta-sources/trees/js.json').read_text())['tree'] if r['type']=='blob'}
raw=(base/'templates/js-complete/.secretlintrc.json').read_bytes()
assert hashlib.sha1(b'blob '+str(len(raw)).encode()+bytes([0])+raw).hexdigest()==tree['.secretlintrc.json']['sha']
out=base/'current-js-focused-checks'
(out/'.secretlintrc.json').write_bytes(raw)
args=['node','--max-old-space-size=256','--test','--test-concurrency=1','--test-timeout=30000','tests/workflows-lint.test.js']
with (out/'retry-final-workflow.log').open('w') as log:result=subprocess.run(args,cwd=out,stdout=log,stderr=subprocess.STDOUT)
receipt={'argv':args,'exitCode':result.returncode,'supportBlob':tree['.secretlintrc.json']['sha'],'fullTemplateAcceptance':False}
(out/'retry-final-workflow.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));print((out/'retry-final-workflow.log').read_text())
