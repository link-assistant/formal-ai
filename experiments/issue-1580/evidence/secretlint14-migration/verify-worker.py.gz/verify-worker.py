from pathlib import Path
import json,os,subprocess,time
base=Path('/tmp/issue-1580-research/secretlint-built-in-migration')
root=Path('/tmp/gh-issue-solver-1794900398048')
environment={**os.environ,'SECRETLINT_TEST_BIN':str(base/'dependencies/node_modules/.bin')}
commands=[
['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/compressed-secrets.test.mjs'],
['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/bounded-subprocess-boundaries.test.mjs'],
['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs'],
['node','--max-old-space-size=256','experiments/issue-1580/secretlint14-live-check.mjs'],
['bash','-n','scripts/check-secrets.sh'],
['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations'],
['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size'],
['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-readable-code'],
['git','diff','--check']]
results=[]
for i,args in enumerate(commands,1):
    start=time.monotonic()
    with (base/f'verify-{i:02}.log').open('w') as log:result=subprocess.run(args,cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT)
    row={'argv':args,'exitCode':result.returncode,'seconds':round(time.monotonic()-start,3),'log':f'verify-{i:02}.log'}
    results.append(row);print(json.dumps(row),flush=True)
    (base/'verify-outcome.json').write_text(json.dumps({'results':results,'finished':len(results)==len(commands),'allChecksPassed':len(results)==len(commands) and all(r['exitCode']==0 for r in results),'fullIssueComplete':False},indent=2)+'\n')
