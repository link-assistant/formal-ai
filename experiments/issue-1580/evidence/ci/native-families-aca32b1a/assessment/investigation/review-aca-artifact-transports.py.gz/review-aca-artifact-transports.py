from pathlib import Path
import json,gzip,re,hashlib,subprocess
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/ci/native-families-aca32b1a';o=Path('/tmp/issue-1580-research/aca-hosted-review')
rows=json.loads((b/'records.json').read_text());row=next(x for x in rows if x['name']=='full-run-44730577755' and x['exitCode']==0);raw=gzip.decompress((b/row['stdout']['file']).read_bytes());lines=raw.decode().splitlines();hosts=[]
for host in ['ubuntu-24.04','macos-15','windows-2025']:
 selected=[(n,l) for n,l in enumerate(lines,1) if l.startswith('Artifact transport ('+host+')\t')];assert selected,host
 (o/(host+'-complete.log')).write_text('\n'.join(f'{n}: {l}' for n,l in selected)+'\n')
 annotations=[{'line':n,'text':l} for n,l in selected if re.search(r'##\[(?:error|warning)\]|DEP0005|DEP0040',l)];(o/(host+'-annotation-candidates.json')).write_text(json.dumps(annotations,indent=2)+'\n')
 witnesses=[{'line':n,'text':l} for n,l in selected if any(x in l for x in ['All artifacts have been successfully downloaded','downloaded successfully','Extracted','sha256','SHA256','1024','verified','Verified','skip-decompress','digest-mismatch'])]
 hosts.append({'host':host,'originalLog':row['stdout']['file'],'completeExtract':host+'-complete.log','lines':len(selected),'annotationCandidates':annotations,'witnesses':witnesses})
assessment={'head':'aca32b1aa27aee55f1d9443f54d6a1c08f77ccb0','run':44730577755,'originalLogSha256':hashlib.sha256(raw).hexdigest(),'hosts':hosts,'newUnpublishedMigrationVerified':False,'independentAuthorshipCredit':0}
(o/'artifact-transports.json').write_text(json.dumps(assessment,indent=2)+'\n');print(json.dumps(assessment,indent=2))
