from pathlib import Path
import subprocess,json,sys,gzip,hashlib,time,os
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research/optional-context-ci');b=r/'experiments/issue-1580/evidence/ci/native-families-aca32b1a'
if '--worker' not in sys.argv:
 with (s/'resumed-worker.log').open('ab') as out:p=subprocess.Popen([sys.executable,__file__,'--worker'],cwd=r,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 (s/'resumed-pid').write_text(str(p.pid)+'\n');print('Resumed collection',p.pid,flush=True);sys.exit(0)
rows=json.loads((b/'records.json').read_text());successful={x['name']:x for x in rows if x['exitCode']==0}
def record(name,args,parsed=False,checked=True):
 if name in successful:
  raw=gzip.decompress((b/successful[name]['stdout']['file']).read_bytes());return json.loads(raw) if parsed else raw
 for attempt in range(1,4):
  start=time.monotonic();p=subprocess.run(args,cwd=r,capture_output=True);identity=name+'-resumed-'+str(attempt)
  row={'name':identity,'requestedName':name,'argv':args,'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3)}
  for label,raw in [('stdout',p.stdout),('stderr',p.stderr)]:
   filename=identity+'.'+label+'.gz';packed=gzip.compress(raw,mtime=0);(b/filename).write_bytes(packed);row[label]={'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())}
  rows.append(row);(b/'records.json').write_text('[\n'+',\n'.join(json.dumps(x,separators=(',',':')) for x in rows)+'\n]\n');print(identity,p.returncode,flush=True)
  if p.returncode==0 or not checked:return json.loads(p.stdout) if parsed else p.stdout
  if not any(x in p.stderr for x in [b'HTTP 500',b'HTTP 502',b'HTTP 503',b'HTTP 504',b'TLS handshake timeout',b'connection reset']):break
  time.sleep(attempt*2)
 raise RuntimeError(name+': '+p.stderr.decode(errors='replace')[-1500:])
latest=json.loads((b/'latest.json').read_text());assert latest['workflowCount']==24 and latest['completed']==24 and latest['success']==24
for run in latest['runs']:
 identity=str(run['databaseId']);record('full-run-'+identity,['gh','run','view',identity,'--repo','link-assistant/formal-ai','--log'])
 if run['workflowName'] not in ['CI/CD Pipeline','Layered CI','Security'] and 'native' not in run['workflowName'].lower():continue
 jobs=record('jobs-'+identity,['gh','run','view',identity,'--repo','link-assistant/formal-ai','--json','jobs'],True)['jobs']
 for job in jobs:
  name=job['name'].lower()
  if any(x in name for x in ['codeql','native','registry','javascript','js tier','fast pull request']) or name=='pipeline status' or job['conclusion'] in ['failure','cancelled']:
   jid=str(job['databaseId']);record('job-'+jid,['gh','run','view',identity,'--repo','link-assistant/formal-ai','--job',jid,'--log'])
record('pull-request-checks',['gh','pr','checks','1581','--repo','link-assistant/formal-ai','--json','name,state,bucket,workflow,link'],True,False)
outcome={'complete':True,'head':latest['head'],'workflowCount':24,'success':24,'failed':[],'fullIssueComplete':False,'independentAuthorshipCredit':0,'collectorRecovery':'Initial collector stopped on transient HTTP 502; original failure retained and remaining requests resumed with three bounded transient retries.'}
for target in [b/'outcome.json',s/'outcome.json']:target.write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome),flush=True)
