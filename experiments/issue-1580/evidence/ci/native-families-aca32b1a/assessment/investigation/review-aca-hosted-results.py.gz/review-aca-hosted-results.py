from pathlib import Path
import gzip,json,hashlib,re
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/ci/native-families-aca32b1a';o=Path('/tmp/issue-1580-research/aca-hosted-review');o.mkdir(exist_ok=True)
records=json.loads((b/'records.json').read_text());checked=0;jobs={};summaries=[];transports=[]
for row in records:
 for stream in ['stdout','stderr']:
  part=row[stream];packed=(b/part['file']).read_bytes();raw=gzip.decompress(packed);assert hashlib.sha256(raw).hexdigest()==part['rawSha256'];assert hashlib.sha256(packed).hexdigest()==part['archiveSha256'];assert len(raw)==part['bytes'];checked+=1
 if row['exitCode']==0 and row['name'].startswith('jobs-'):
  data=json.loads(gzip.decompress((b/row['stdout']['file']).read_bytes()))
  for job in data['jobs']:jobs[job['databaseId']]=job
seen=set()
for row in records:
 if row['exitCode'] or not row['name'].startswith('job-'):continue
 jid=int(row['name'].split('-')[1])
 if jid in seen:continue
 seen.add(jid);lines=gzip.decompress((b/row['stdout']['file']).read_bytes()).decode(errors='replace').splitlines();diagnostics=[];tests=[];witness=[]
 for number,line in enumerate(lines,1):
  if any(x in line for x in ['test result:','##[error]','##[warning]','::warning','::error','error[E','warning:']):diagnostics.append({'line':number,'text':line})
  match=re.search(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',line)
  if match:tests.append({'line':number,'result':match[1],'passed':int(match[2]),'failed':int(match[3]),'ignored':int(match[4])})
  if re.search(r'DEP0005|DEP0040|roundtrip|round trip|artifact.*transport|transport.*artifact|Buffer\(',line,re.I):witness.append({'line':number,'text':line})
 (o/(str(jid)+'-diagnostics.jsonl')).write_text(''.join(json.dumps(x)+'\n' for x in diagnostics));(o/(str(jid)+'-transport-candidates.jsonl')).write_text(''.join(json.dumps(x)+'\n' for x in witness))
 summaries.append({'id':jid,'name':jobs.get(jid,{}).get('name'),'conclusion':jobs.get(jid,{}).get('conclusion'),'source':row['stdout']['file'],'lines':len(lines),'testSummaries':tests,'passed':sum(x['passed'] for x in tests),'failed':sum(x['failed'] for x in tests),'diagnostics':len(diagnostics),'transportCandidates':len(witness)})
outcome=json.loads((b/'outcome.json').read_text());assert outcome['complete'] and outcome['success']==24
assessment={'head':outcome['head'],'verifiedStreams':checked,'workflows':24,'successfulWorkflows':24,'jobs':summaries,'totalNativePassed':sum(x['passed'] for x in summaries),'totalNativeFailed':sum(x['failed'] for x in summaries),'newUnpublishedChangesVerified':False,'originalSourceCoverageInferred':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(o/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n')
print(json.dumps({k:v for k,v in assessment.items() if k!='jobs'}));print(json.dumps([{k:v for k,v in row.items() if k not in ['testSummaries']} for row in summaries],indent=2))
