from pathlib import Path
import collections, hashlib, json, re, subprocess
root=Path.cwd(); scratch=Path('/tmp/issue-1580-research')
folder=scratch/'codeql-cec-rust-results/included-string-payloads'
raw=(folder/'included-string-payloads.json').read_bytes()
manifest=json.loads((folder/'manifest.json').read_text())
assert hashlib.sha256(raw).hexdigest()==manifest['result']['sha256']
table=json.loads(raw)['#select']; rows=table['tuples']
source='cec9207c3e139e2212f6d4ea478ff1b88e17be7c'
cache={}; compared=[]; observations=collections.Counter()
def blob(path):
    if path not in cache:
        result=subprocess.run(['git','show',source+':'+path],capture_output=True)
        cache[path]=result.stdout if result.returncode==0 else None
    return cache[path]
for row in rows:
    if row[6]!='literal-expansion':continue
    file=row[1]
    marker='/formal-ai/formal-ai/'
    if marker in file:file=file.split(marker,1)[1]
    if file.startswith('/') or '..' in Path(file).parts:
        observations['non-repository-location']+=1;continue
    body=blob(file)
    if body is None:observations['source-unavailable']+=1;continue
    lines=body.decode().splitlines(keepends=True)
    if not 1<=row[2]<=len(lines):observations['unbound-span']+=1;continue
    start=sum(len(x) for x in lines[:row[2]-1])+row[3]-1
    match=re.match(r'include_str!\s*\(\s*"([^"\n]+)"\s*\)',body.decode()[start:])
    if match is None:observations['non-literal-or-unbound-span']+=1;continue
    target=(root/file).parent/match.group(1)
    try:path=str(target.resolve().relative_to(root))
    except ValueError:observations['outside-source-root']+=1;continue
    expected=blob(path)
    if expected is None:observations['included-source-unavailable']+=1;continue
    try:decoded=json.loads(row[7])
    except (ValueError,TypeError):observations['literal-requires-rust-decoder']+=1;continue
    if not isinstance(decoded,str):observations['non-string-token']+=1;continue
    observed=decoded.encode()
    state='matches-exact-source' if observed==expected else ('empty-expansion-of-nonempty-source' if not observed and expected else 'differs-from-exact-source')
    observations[state]+=1
    compared.append({'file':file,'line':row[2],'column':row[3],'included':path,
                     'sourceBytes':len(expected),'sourceSha256':hashlib.sha256(expected).hexdigest(),
                     'decodedBytes':len(observed),'decodedSha256':hashlib.sha256(observed).hexdigest(),
                     'comparison':state,'cfg':row[8]})
report={'source':source,'queryResultSha256':hashlib.sha256(raw).hexdigest(),
        'rows':len(rows),'states':dict(collections.Counter(row[6] for row in rows)),
        'controlFlow':dict(collections.Counter(row[8] for row in rows)),
        'files':len({row[1] for row in rows}),'literalComparisonCounts':dict(observations),
        'scope':'Exact source spans with one literal relative include path and JSON-compatible quoted text only; macro contexts are not collapsed into an application coverage claim.',
        'comparisons':compared}
(scratch/'codeql-cec-payload-source-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='comparisons'}))
print(json.dumps(compared[:5],ensure_ascii=False))
