from pathlib import Path

path = Path('js/worker/formal_ai_worker_how_to_guide.js')
before = path.read_text()
old = '''  if (items.length > 0) detail = capture.url;
  items.forEach((item, index) => { item.position = produced + index + 1; });
  return { items, follow, detail };
'''
new = '''  items.forEach((item, index) => { item.position = produced + index + 1; });
  return { items, follow, detail: items.length > 0 ? capture.url : detail };
'''
assert before.count(old) == 1
path.write_text(before.replace(old, new))
