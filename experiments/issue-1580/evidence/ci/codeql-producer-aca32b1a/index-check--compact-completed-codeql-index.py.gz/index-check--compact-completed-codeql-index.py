from pathlib import Path
import gzip, hashlib, json

r = Path('/tmp/gh-issue-solver-1794900398048')
s = Path('/tmp/issue-1580-research')
b = r/'experiments/issue-1580/evidence/ci/codeql-producer-aca32b1a'
assert json.loads((b/'outcome.json').read_text())['complete']
p = b/'producer-files.json'
rows = json.loads(p.read_text())
original = p.read_bytes()
(b/'producer-files-original.json.gz').write_bytes(gzip.compress(original,mtime=0))
p.write_text('[\n'+',\n'.join('  '+json.dumps(row) for row in rows)+'\n]\n')
assert json.loads(p.read_text()) == rows
retained = []
for source in [s/'finish-artifact-consumer-commit-second.log', r/'experiments/formal_ai_subagent/sandboxes/gates/check-file-size.log', Path(__file__)]:
    raw=source.read_bytes();name='index-check--'+source.name+'.gz';packed=gzip.compress(raw,mtime=0)
    (b/name).write_bytes(packed)
    retained.append({'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw)})
(b/'index-check-records.json').write_text(json.dumps(retained,indent=2)+'\n')
print('Completed CodeQL producer index:',len(rows),'unchanged records; original bytes retained.')
