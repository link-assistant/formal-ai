from pathlib import Path
from collections import Counter
import gzip, hashlib, json, re

b=Path('/tmp/gh-issue-solver-1794900398048/experiments/issue-1580/evidence/ci/codeql-producer-aca32b1a')
out=Path('/tmp/issue-1580-research/codeql-optional-review');out.mkdir(exist_ok=True)
assessment={'head':json.loads((b/'outcome.json').read_text())['head'],'jobs':{},'reports':[],'independentAuthorshipCredit':0,'fullIssueComplete':False}
for name in ['job-136269105795.stdout.gz','job-136269105882.stdout.gz','job-136269105488.stdout.gz']:
    lines=gzip.decompress((b/name).read_bytes()).decode().splitlines()
    hits=[]
    for i,line in enumerate(lines):
        # Preserve source echoes separately: colored shell code is not a diagnostic.
        if re.search(r'##\[(?:warning|error)\]|\b(?:WARN|ERROR)\b|Rust analysis context unavailable|RUSTSEC-|strict CodeQL|Strict CodeQL|independent.*result|no results|0 results',line):
            hits.append({'line':i+1,'text':line})
    (out/(name+'.diagnostics.json')).write_text(json.dumps(hits,indent=2)+'\n')
    assessment['jobs'][name]={'lines':len(lines),'candidateDiagnosticLines':len(hits),'emittedWorkflowWarnings':sum('##[warning]' in x for x in lines),'emittedWorkflowErrors':sum('##[error]' in x for x in lines)}
for p in b.glob('*sarif.gz'):
    raw=gzip.decompress(p.read_bytes());report=json.loads(raw)
    for run in report['runs']:
        row={'file':p.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'version':report['version'],'driver':run['tool']['driver']['name'],'toolVersion':run['tool']['driver'].get('semanticVersion'),'results':len(run.get('results',[])),'invocations':[]}
        for inv in run.get('invocations',[]):
            notifications=inv.get('toolExecutionNotifications',[])
            row['invocations'].append({'successful':inv.get('executionSuccessful'),'levels':dict(Counter(x.get('level','unspecified') for x in notifications)),'descriptors':dict(Counter(x.get('descriptor',{}).get('id','unspecified') for x in notifications))})
            significant=[x for x in notifications if x.get('level') in ['error','warning']]
            (out/(p.name+'.significant.json')).write_text(json.dumps(significant,indent=2)+'\n')
        assessment['reports'].append(row)
(out/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n')
print(json.dumps(assessment,indent=2))
