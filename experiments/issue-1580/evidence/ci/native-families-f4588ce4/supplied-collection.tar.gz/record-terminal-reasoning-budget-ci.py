from pathlib import Path
import gzip, hashlib, io, json, tarfile

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
base = root / 'experiments/issue-1580/evidence/ci/native-families-f4588ce4'
assessment = json.loads((base / 'assessment.json').read_text())
assert assessment['terminalWorkflows'] == 27 and assessment['successfulWorkflows'] == 26
assert assessment['nativeRustPassingTests'] == 573 and assessment['nativeRustFailingTests'] == 0
selected = [Path(__file__), scratch / 'collect-reasoning-budget-head-ci.py',
    scratch / 'assess-reasoning-budget-terminal-ci.py', scratch / 'read-terminal-native-diagnostics.py',
    scratch / 'assess-reasoning-budget-terminal-ci.log', scratch / 'read-terminal-native-diagnostics.log',
    scratch / 'inspect-reasoning-budget-head-jobs-current.log', scratch / 'seal-client-entropy-review.py',
    scratch / 'seal-client-entropy-review.log']
for directory in ['reasoning-budget-head-ci', 'terminal-native-diagnostics', 'sealed-client-entropy-review']:
    selected.extend(path for path in (scratch / directory).rglob('*') if path.is_file())
buffer = io.BytesIO()
identities = []
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for path in sorted(set(selected)):
        raw = path.read_bytes()
        name = path.relative_to(scratch).as_posix()
        item = tarfile.TarInfo(name)
        item.size, item.mode, item.mtime = len(raw), 0o644, 0
        archive.addfile(item, io.BytesIO(raw))
        identities.append({'file': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
raw = buffer.getvalue()
packed = gzip.compress(raw, mtime=0)
(base / 'supplied-collection.tar.gz').write_bytes(packed)
(base / 'supplied-collection.json').write_text(json.dumps({'files': identities,
    'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(),
    'fullIssueComplete': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
document = root / 'docs/case-studies/issue-1580/reasoning-budget-hosted-checkpoint.md'
document.write_text('''# Hosted reasoning and release registry replay

Published head `f4588ce40023a1cc722cbed4ed7f977581fd4530` finished all 27
observed workflows: 26 succeeded and one was explicitly skipped. The pipeline
[run 44785531588](https://github.com/link-assistant/formal-ai/actions/runs/44785531588)
passed its ten native jobs: 573 Rust cases and eight Python CLI cases passed.
The reasoning halves each exercised 74 cases, taking 8m18s and 11m02s. The
release-registry target exercised 3 library, 22 requirements, 19 ordered-list
and 4 self-hosting cases, then eight tests invoking the actual release scripts.
These include two previously imported module-path cases; counts alone do not
prove unchanged acceptance of every historical source. Strict original source
acceptance remains 31/53, with the other contract qualifications unfinished.

The exact-head check snapshot records 57 passing and 86 explicitly skipped
checks. Manual read-only security producer
[run 44785512004](https://github.com/link-assistant/formal-ai/actions/runs/44785512004)
also passed. All 290 original collection streams have compressed and raw hashes,
byte counts and line counts in `native-families-f4588ce4/records.json`. Individual
native summaries and original line numbers are in `assessment.json`. The
aggregate logs are preserved; they have not all been literally read.

Green jobs do not clear the warning and error requirements. The annotation
inventory retains 121 warnings and six errors. Of those, 119 warnings concern
source file sizes. The other warnings concern unverified crates.io publish-token
capability and checkout cleanup. The deliberate registry-outage negative control
emitted one expected daemon error. Hive-1's first partial checkout emitted a
20-second low-speed timeout and related Git errors at pipeline log lines
44885–44916; its existing second checkout recreated the incomplete repository
after the cleanup diagnostics at lines 44974–44978 and succeeded. This is
observed recovery, not a claim that an upstream network fault was repaired.

The macro observation still emitted its plain-text heap warning at 3 GiB even
though both original producer SARIF files contained zero findings and zero
warning/error notifications. The separate 4 GiB change requires another real
producer run. File-size remediation, publish capability, strict source coverage,
per-child macro semantics, actual publication and all eight full template
comparisons remain open. This checkpoint supplies no independent authorship or
reasoning credit and does not complete issue #1580.
''')
with (root / 'experiments/issue-1580/work-plan.md').open('a') as stream:
    stream.write('\n- Exact published f4588ce4 is terminal: 27 workflows (26 success, one skip), 57 passing/86 skipped checks, 573 Rust plus eight actual registry CLI tests. All 290 original collection streams hash-verified. Preserve 121 warnings/six errors, including recovered Hive-1 checkout timeout and deliberate outage control; no all-warnings-cleared claim. Strict original 31/53 and broad acceptance remain unfinished. See reasoning-budget-hosted-checkpoint.md.\n')
print(json.dumps({'checkpoint': str(document.relative_to(root)), 'terminal': True,
    'rustCases': 573, 'cliCases': 8, 'fullIssueComplete': False}))
