from pathlib import Path
import gzip, hashlib, json, os, subprocess, sys, traceback

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/sealed-client-entropy-review')
if len(sys.argv) == 1:
    base.mkdir(exist_ok=False)
    with (base / 'worker.log').open('wb') as stream:
        child = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root,
            stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': child.pid, 'scratch': str(base)}))
    sys.exit(0)
records = []
def run(name, argv):
    result = subprocess.run(argv, cwd=root, env=dict(os.environ, NODE_OPTIONS='--max-old-space-size=256'), capture_output=True)
    for label in ['stdout', 'stderr']:
        (base / (name + '.' + label)).write_bytes(getattr(result, label))
    records.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    (base / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
    assert result.returncode == 0, (name, result.stderr[-2000:], result.stdout[-2000:])
    print(name, 'PASS', flush=True)
    return result.stdout
try:
    assert run('branch', ['git', 'branch', '--show-current']).decode().strip() == 'issue-1580-8d61a32a61e1'
    run('gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only',
        'check-file-size,check-file-size-js-twin,check-readable-code,check-tests-as-docs'])
    selected = ['docs/case-studies/issue-1580/templates/rust-source-review-progress.json',
        'experiments/issue-1580/evidence/checks/rust-source-review/logs.json',
        'experiments/issue-1580/evidence/checks/rust-client-entropy-history', 'experiments/issue-1580/work-plan.md']
    selected += [path.relative_to(root).as_posix() for path in
        sorted((root / 'experiments/issue-1580/evidence/checks/rust-source-review').glob('client-entropy-history-*.gz'))]
    files = []
    for name in selected:
        path = root / name
        files.extend(item for item in path.rglob('*') if item.is_file()) if path.is_dir() else files.append(path)
    identities = [{'path': path.relative_to(root).as_posix(), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
        for path in sorted(set(files))]
    (base / 'selection.json').write_text(json.dumps(identities, indent=2) + '\n')
    run('secrets', ['bash', 'scripts/check-secrets.sh', *[row['path'] for row in identities]])
    for row in identities:
        assert hashlib.sha256((root / row['path']).read_bytes()).hexdigest() == row['sha256']
    run('whitespace', ['git', 'diff', '--check'])
    seal = root / 'experiments/issue-1580/evidence/checks/rust-client-entropy-history-seal'
    seal.mkdir(exist_ok=False)
    captured = []
    for path in sorted(base.iterdir()):
        if not path.is_file() or path.name == 'worker.log': continue
        raw = path.read_bytes()
        packed = gzip.compress(raw, mtime=0)
        target = seal / (path.name + '.gz')
        target.write_bytes(packed)
        captured.append({'file': target.name, 'rawSha256': hashlib.sha256(raw).hexdigest(),
            'archiveSha256': hashlib.sha256(packed).hexdigest()})
    (seal / 'records.json').write_text(json.dumps(captured, indent=2) + '\n')
    run('seal-secrets', ['bash', 'scripts/check-secrets.sh', *[path.relative_to(root).as_posix() for path in sorted(seal.iterdir())]])
    run('stage', ['git', 'add', '--', *selected, seal.relative_to(root).as_posix()])
    run('staged-whitespace', ['git', 'diff', '--cached', '--check'])
    run('commit', ['git', 'commit', '-m', 'docs: preserve complete Rust entropy and client history review'])
    head = run('head', ['git', 'rev-parse', 'HEAD']).decode().strip()
    outcome = {'complete': True, 'head': head, 'pushExecuted': False, 'fullIssueComplete': False,
        'independentAuthorshipCredit': 0}
    (base / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
    print(json.dumps(outcome), flush=True)
except BaseException:
    traceback.print_exc()
    (base / 'failure.json').write_text(json.dumps({'complete': False, 'traceback': traceback.format_exc()}) + '\n')
    sys.exit(1)
