from pathlib import Path
import gzip, json

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/ci/native-families-f4588ce4'
lines = gzip.decompress((base / 'full-run-44785531588.stdout.gz').read_bytes()).decode().splitlines()
scratch = Path('/tmp/issue-1580-research/terminal-native-diagnostics')
scratch.mkdir(exist_ok=False)
for name, start, stop in [('checkout', 44840, 45120), ('publication', 1410, 1490)]:
    (scratch / (name + '.read.txt')).write_text('\n'.join(f'{number}: {lines[number - 1]}'
        for number in range(start, stop + 1)) + '\n')
annotations = json.loads((base / 'workflow-annotations.json').read_text())
size_warnings = [row for row in annotations if 'approaching limit of' in row['text']]
(scratch / 'size-warnings.json').write_text(json.dumps(size_warnings, indent=2) + '\n')
print(json.dumps({'diagnosticSlices': 2, 'sizeWarnings': len(size_warnings),
    'allAggregateLinesLiterallyRead': False, 'fullIssueComplete': False}))
