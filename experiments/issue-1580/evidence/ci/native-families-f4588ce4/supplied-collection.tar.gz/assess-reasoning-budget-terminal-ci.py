from collections import Counter
from pathlib import Path
import datetime, gzip, hashlib, json, re

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/ci/native-families-f4588ce4'
outcome = json.loads((base / 'outcome.json').read_text())
assert outcome['complete'] and outcome['workflowCount'] == 27
records = json.loads((base / 'records.json').read_text())
lookup = {row['name']: row for row in records}
verified = 0
annotations = []
runtime_diagnostics = []
def raw(entry):
    packed = (base / entry['file']).read_bytes()
    unpacked = gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest() == entry['archiveSha256']
    assert hashlib.sha256(unpacked).hexdigest() == entry['rawSha256']
    assert len(unpacked) == entry['bytes'] and len(unpacked.splitlines()) == entry['lines']
    return unpacked
for record in records:
    assert record['exitCode'] == 0, record['name']
    for label in ('stdout', 'stderr'):
        value = raw(record[label])
        verified += 1
        if label == 'stdout' and record['name'].startswith('full-run-'):
            for number, line in enumerate(value.decode().splitlines(), 1):
                match = re.search(r'##\[(warning|error)\](.*)', line)
                if match:
                    annotations.append({'file': record[label]['file'], 'line': number, 'level': match[1],
                        'text': match[2], 'quotedShellSource': '\x1b[36;1m' in line})
                if 'WARNING:' in line or 'warning:' in line:
                    runtime_diagnostics.append({'file': record[label]['file'], 'line': number, 'text': line})
pipeline = json.loads(raw(lookup['jobs-44785531588']['stdout']))
native = []
failed_jobs = []
for job in pipeline['jobs']:
    if job['conclusion'] not in ['success', 'skipped']:
        failed_jobs.append({key: job[key] for key in ['databaseId', 'name', 'conclusion']})
    if not job['name'].startswith('Native type and lint check /'):
        continue
    record = lookup['job-' + str(job['databaseId'])]
    summaries, cli = [], []
    lines = raw(record['stdout']).decode().splitlines()
    for number, line in enumerate(lines, 1):
        match = re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;', line)
        if match:
            summaries.append({'line': number, 'passed': int(match[1]), 'failed': int(match[2]), 'text': line})
        if 'registry' in job['name'].lower() and any(word in line for word in ['Ran 8 tests', 'CLI', 'passed', 'OK', 'FAIL']):
            cli.append({'line': number, 'text': line})
    native.append({'name': job['name'], 'job': job['databaseId'], 'log': record['stdout']['file'],
        'lines': len(lines), 'passed': sum(row['passed'] for row in summaries),
        'failed': sum(row['failed'] for row in summaries), 'summaries': summaries, 'cliObservations': cli,
        'startedAt': job['startedAt'], 'completedAt': job['completedAt'], 'conclusion': job['conclusion']})
checks = json.loads(raw(lookup['pull-request-checks']['stdout']))
assessment = {'head': outcome['head'], 'observedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'verifiedStreams': verified, 'terminalWorkflows': 27, 'successfulWorkflows': outcome['success'],
    'skippedWorkflows': 27 - outcome['success'] - len(outcome['failed']),
    'failedWorkflows': outcome['failed'], 'failedPipelineJobs': failed_jobs,
    'nativeJobs': native, 'nativeRustPassingTests': sum(row['passed'] for row in native),
    'nativeRustFailingTests': sum(row['failed'] for row in native),
    'pullRequestCheckBuckets': dict(Counter(row['bucket'] for row in checks)),
    'annotationCounts': dict(Counter(row['level'] + (':quoted' if row['quotedShellSource'] else ':emitted') for row in annotations)),
    'allAggregateLinesLiterallyRead': False, 'strictOriginalNativeSourceAcceptance': '31/53; remaining contract qualification open',
    'allWarningsResolved': False, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
(base / 'assessment.json').write_text(json.dumps(assessment, indent=2) + '\n')
(base / 'workflow-annotations.json').write_text(json.dumps(annotations, indent=2) + '\n')
(base / 'runtime-diagnostics.jsonl').write_text(''.join(json.dumps(row, separators=(',', ':')) + '\n' for row in runtime_diagnostics))
print(json.dumps({key: value for key, value in assessment.items() if key != 'nativeJobs'}, indent=2))
for row in native:
    print(row['name'], row['passed'], 'Rust passes', row['conclusion'])
    for item in row['cliObservations']:
        print(json.dumps(item))
for row in annotations:
    if not row['quotedShellSource'] and 'approaching limit of' not in row['text']:
        print('Other emitted diagnostic:', json.dumps(row))
