from pathlib import Path
import json,gzip,hashlib,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'terminal-seed-ci-preservation'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('w') as stream:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(p.pid);sys.exit(0)
def run(name,args):
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=subprocess.run(args,cwd=root,stdout=stdout,stderr=stderr)
 print(json.dumps({'check':name,'status':r.returncode}),flush=True);assert r.returncode==0,(name,r.returncode)
 return (out/(name+'.stdout')).read_text()
try:
 archiveRoot=root/'experiments/issue-1580/evidence/ci/seed-readers-9e945eae';target=archiveRoot/'terminal-analysis';target.mkdir(exist_ok=False);records=[]
 def archive(raw,name):
  packed=gzip.compress(raw,mtime=0);dest=target/(name+'.gz');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(packed);assert gzip.decompress(packed)==raw
  records.append({'path':str(dest.relative_to(target)),'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
 for dirname in ['seed-reader-completed-ci-analysis','terminal-seed-ci-annotations','seed-ci-shard-costs']:
  for p in sorted((scratch/dirname).rglob('*')):
   if p.is_file():archive(p.read_bytes(),dirname+'/'+str(p.relative_to(scratch/dirname)))
 for name in ['inspect-completed-seed-ci.py','read-seed-pipeline-failures.py','scan-terminal-seed-ci.py','read-terminal-warning-contexts.py','inspect-current-shard-costs.py','read-shard-rebalance-inputs.py',Path(__file__).name,'inspect-completed-seed-ci-driver.log','inspect-completed-seed-ci-corrected-driver.log','read-seed-pipeline-failures-driver.log','scan-terminal-seed-ci-driver.log','read-terminal-warning-contexts-driver.log','inspect-current-shard-costs-driver.log','read-shard-rebalance-inputs-driver.log']:
  p=scratch/name
  if p.exists():archive(p.read_bytes(),'supplied-procedures-and-attempts/'+name)
 (target/'records.jsonl').write_text(''.join(json.dumps(v,separators=(',',':'))+'\n' for v in records))
 doc=root/'docs/case-studies/issue-1580/seed-reader-terminal-ci.md';doc.write_text('''# Complete terminal CI record for 9e945eae

All 32 workflows for published commit
`9e945eae3f1f3a03a2b9e3302bdb81000f7820b1` are terminal: 29 succeed,
one skips and two fail. The retained run observations, job states and complete
gzip log streams live under
`experiments/issue-1580/evidence/ci/seed-readers-9e945eae/`.
Thirty-one nonempty workflow logs were scanned for actual warning/error lines;
28 occurrences form 20 distinct messages. Full byte digests and line locations
are recorded. Echoed shell programs are separate from emitted annotations.

## Actionable failures

Layered CI run 44938456935 fails on six source/transport checks already repaired
in local commit 2c81c95, plus the unchanged stale WASM worker-input receipt.
The Pipeline run 44938457098 fails at lines 57558–57589: the native structured
output HTTP suite omits the `formalAiSeedRecordReaders` prerequisite (the exact
ReferenceError is at 57565). The same local repair adds the actual prerequisite
and a focused VM regression. The final Pipeline failure at 72747–72750 correctly
propagates that job failure; it is not an aggregation false positive.

All nine native contract groups and release registry scripts pass on this
published head. Later local changes require fresh hosted validation. The
cycle-rejection panic at 57251 belongs to a passing bounded negative control
(`nested_reusable_jobs_are_visible_and_cycles_are_bounded`, success at 57254),
within the 195 passing workflow contracts. It must not be silenced as a defect.

## Other diagnostics

The BuildKit canonical-registry failure at artifact-contract run 44938456883,
line 662, is the deliberate fallback control; the mirror branch succeeds.
The Windows artifact download at line 2281 is a genuine transient visibility
failure recovered by the second bounded download, followed by successful byte
round-trip verification. Its original failure remains visible. The Git pathspec
error at Layered line 26093 is the successful untracked-owner rejection test.

Pipeline size warnings at 2615–2635 name the traceability table, conversation UI,
eight immutable captures and the live canonical staged workflow. The first two
are now partitioned without changing behavior; the eight captures are losslessly
archived with complete-byte conservation. The canonical workflow remains open.

Layered groups 2 and 3 warn after 270/360 seconds (3540, 18658). Native coding-1
and Hive-3 warn after 675/900 seconds (69417, 72387). Complete per-file and native
timestamps are retained for a measured scheduling/compile-reuse repair. No clock
or warning threshold was increased. The crates.io token remains explicitly
unverified at Pipeline 2250: public reads cannot certify token authority.

The stale WASM receipt requires actual hosted regeneration. Its inactive
read-only proposal awaits the explicit build-policy exception; no local Rust
compilation, false identity substitution or hand-written receipt is claimed.

Supplied analysis and procedures receive zero independent Formal AI authorship
credit. This evidence records unfinished work and does not complete issue #1580.
Pull request: https://github.com/link-assistant/formal-ai/pull/1581.
''')
 assert run('branch',['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
 run('whitespace',['git','diff','--check']);run('stage',['git','add','--',str(archiveRoot.relative_to(root)),str(doc.relative_to(root))]);run('commit',['git','commit','-m','Retain complete terminal CI evidence and classify remaining diagnostics'])
 (out/'outcome.json').write_text(json.dumps({'complete':True,'head':run('head',['git','rev-parse','HEAD']).strip(),'pushed':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
except BaseException:traceback.print_exc();(out/'failed.txt').write_text(traceback.format_exc());sys.exit(1)
