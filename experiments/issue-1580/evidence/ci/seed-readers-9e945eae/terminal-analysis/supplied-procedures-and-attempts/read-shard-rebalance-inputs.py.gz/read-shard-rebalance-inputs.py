from pathlib import Path
import gzip,re,json,collections
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/ci/seed-readers-9e945eae';out=Path('/tmp/issue-1580-research/seed-ci-shard-costs')
lines=gzip.decompress((base/'failed-run-44938457098.stdout.gz').read_bytes()).decode().splitlines();groups=collections.defaultdict(list)
for i,line in enumerate(lines,1):
 if '/ Native contracts (' in line and (re.search(r'test [a-z_][a-z_0-9:]*(?:\.\.\.| )',line) or 'running ' in line or 'test result:' in line or 'Finished ' in line or 'selected ' in line):groups[line.split('\t')[0]].append({'line':i,'text':line})
(out/'native-test-timestamps.json').write_text(json.dumps(groups,indent=2)+'\n')
for group,rows in groups.items():
 print('NATIVE',group)
 for row in rows:
  if any(s in row['text'] for s in ['test result:','Finished ','running ']):print(json.dumps(row))
for name,selection in [('scripts/ci-native-coding-durations.lino',None),('scripts/ci-native-hive-durations.lino',None),('scripts/lib/ci-speed-shards.mjs',None),('data/meta/javascript-test-durations.lino',[(1,45)]),('scripts/update-test-durations.mjs',None),('experiments/issue-1580/native-regression-groups.test.mjs',[(125,262),(405,500)]),('.github/workflows/native-type-check.yml',[(210,310)]),('.github/workflows/layered-ci.yml',[(265,305),(420,492)])]:
 p=root/name;print('SOURCE',name)
 if not p.exists():print('MISSING');continue
 ls=p.read_text().splitlines()
 for start,end in (selection or [(1,len(ls))]):
  for i in range(start-1,min(end,len(ls))):print(f'{i+1}: {ls[i]}')
