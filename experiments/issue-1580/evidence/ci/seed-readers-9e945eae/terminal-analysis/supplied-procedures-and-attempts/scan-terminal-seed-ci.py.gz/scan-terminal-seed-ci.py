from pathlib import Path
import gzip,json,re,hashlib,collections,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/ci/seed-readers-9e945eae';out=Path('/tmp/issue-1580-research/terminal-seed-ci-annotations');out.mkdir(exist_ok=False)
annotations=[];logs=[];ansi=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
for p in sorted(base.glob('*.stdout.gz')):
 if not re.search(r'(?:failed|successful|completed|skipped|run)-\d+\.stdout\.gz$',p.name):continue
 raw=gzip.decompress(p.read_bytes());lines=raw.decode().splitlines()
 if not any('\t' in x and '2026-' in x for x in lines[:10]):continue
 logs.append({'path':p.name,'lines':len(lines),'rawSha256':hashlib.sha256(raw).hexdigest()})
 for i,line in enumerate(lines,1):
  plain=ansi.sub('',line);parts=re.split(r'\d{4}-\d\d-\d\dT\S+Z\s*',plain,maxsplit=1);message=parts[-1].strip()
  m=re.match(r'(?:##\[(warning|error)\]|::(warning|error)(?:\s+[^:]*)?::|(warning|error)(?:\[[^]]+\])?:)\s*(.*)',message)
  if m:
   severity=next(v for v in m.groups()[:3] if v is not None);annotations.append({'path':p.name,'line':i,'severity':severity,'message':message,'raw':line})
(out/'logs.json').write_text(json.dumps(logs,indent=2)+'\n');(out/'annotations.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in annotations))
groups={}
for row in annotations:
 key=row['message'];groups.setdefault(key,{'severity':row['severity'],'message':key,'locations':[]})['locations'].append({'path':row['path'],'line':row['line']})
(out/'distinct.jsonl').write_text(''.join(json.dumps(v)+'\n' for v in groups.values()))
print('WORKFLOW LOGS',len(logs),'ANNOTATIONS',len(annotations),'DISTINCT',len(groups))
for row in logs:print('LOG',json.dumps(row))
for number,row in enumerate(groups.values(),1):print('ANNOTATION',number,json.dumps(row))
print('EVIDENCE SCRIPT CONSUMERS')
records=json.loads(Path('/tmp/issue-1580-research/archive-warning-consumer-review/records.json').read_text());seen=set()
for row in records:
 if '/dormant-staged-release/' in row['path']:continue
 for q in row['searches']:
  for name in q['allMatches']:
   if '/evidence/' in name and name.endswith(('.mjs','.js','.py','.sh','.rs')) and name not in seen:
    seen.add(name);p=root/name;print('CONSUMER',name)
    for i,line in enumerate(p.read_text().splitlines(),1):print(f'{i}: {line}')
