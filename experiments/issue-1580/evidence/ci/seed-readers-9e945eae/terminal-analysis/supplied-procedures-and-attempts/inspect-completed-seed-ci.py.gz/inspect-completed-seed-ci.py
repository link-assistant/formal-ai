from pathlib import Path
import json,re,gzip,hashlib
base=Path('/tmp/gh-issue-solver-1794900398048/experiments/issue-1580/evidence/ci/seed-readers-9e945eae');out=Path('/tmp/issue-1580-research/seed-reader-completed-ci-analysis');out.mkdir(exist_ok=True)
print('FILES')
for p in sorted(base.iterdir()):print(p.name,p.stat().st_size)
for p in sorted(base.glob('*jobs*.stdout.gz')):
 try:value=json.loads(gzip.decompress(p.read_bytes()))
 except (ValueError,UnicodeDecodeError):continue
 print('JOBS FILE',p.name)
 jobs=value.get('jobs',[]) if isinstance(value,dict) else value
 for job in jobs:
  if job.get('conclusion') not in ['success','skipped']:
   print(json.dumps({'name':job.get('name'),'id':job.get('id'),'conclusion':job.get('conclusion'),'steps':[{'name':step.get('name'),'conclusion':step.get('conclusion')} for step in job.get('steps',[]) if step.get('conclusion') not in ['success','skipped']]}))
records=[]
for p in sorted(base.glob('*44938457098*.stdout.gz')):
 raw=gzip.decompress(p.read_bytes());lines=raw.decode().splitlines();print('PIPELINE LOG',p.name,'LINES',len(lines),'SHA256',hashlib.sha256(raw).hexdigest())
 for i,line in enumerate(lines):
  if re.search(r'error\[|error:|::error|FAILED|panicked at|failures:|did not complete|failed to run|warning:',line):records.append({'file':p.name,'line':i+1,'text':line})
(out/'diagnostic-candidates.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in records));print('DIAGNOSTIC CANDIDATES',len(records))
for row in records[:65]:print(json.dumps(row))
