from pathlib import Path
import gzip,json,re,subprocess,collections
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/ci/seed-readers-9e945eae';out=Path('/tmp/issue-1580-research/seed-ci-shard-costs');out.mkdir(exist_ok=False)
raw=gzip.decompress((base/'failed-run-44938456935.stdout.gz').read_bytes()).decode().splitlines();groups=collections.defaultdict(list)
for i,line in enumerate(raw,1):
 m=re.search(r'\[test-file\] completed (\S+) (\{.*\})',line)
 if m:
  duration=json.loads(m[2])['duration_ms'];groups[line.split('\t')[0]].append({'path':m[1],'durationMs':duration,'line':i})
(out/'javascript-files.json').write_text(json.dumps(groups,indent=2)+'\n')
for name,rows in groups.items():
 print('JAVASCRIPT GROUP',name,'FILES',len(rows),'TOTAL',round(sum(r['durationMs'] for r in rows)/1000,2))
 for row in sorted(rows,key=lambda r:r['durationMs'],reverse=True)[:7]:print(json.dumps(row))
native=gzip.decompress((base/'failed-run-44938457098.stdout.gz').read_bytes()).decode().splitlines()
for pattern in ['Native contracts (coding-1)','Native contracts (hive-3)']:
 print('NATIVE GROUP',pattern)
 for i,line in enumerate(native,1):
  if pattern in line and any(q in line for q in ['[budget]','test result:','Finished ','Running tests/','Run bash scripts/run-with-budget']):print(f'{i}: {line}')
r=subprocess.run(['rg','-n','native-regression|suite.group|shard|NATIVE_CONTRACT|coding-1|hive-3','.github/workflows/layered-ci.yml','.github/workflows/native-type-check.yml','scripts/ci-native-regressions.sh','experiments/issue-1580/native-regression-groups.test.mjs','scripts/ci-js.sh'],cwd=root,capture_output=True,text=True);print('SOURCE INDEX',r.stdout,r.stderr)
for name in ['scripts/ci-native-regressions.sh','experiments/issue-1580/native-regression-groups.test.mjs','.github/workflows/layered-ci.yml']:
 p=root/name;print('SOURCE',name)
 for i,line in enumerate(p.read_text().splitlines(),1):print(f'{i}: {line}')
