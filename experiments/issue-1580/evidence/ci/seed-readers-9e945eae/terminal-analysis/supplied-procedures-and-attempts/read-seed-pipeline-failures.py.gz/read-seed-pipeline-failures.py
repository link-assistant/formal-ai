from pathlib import Path
import gzip,json
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/ci/seed-readers-9e945eae'
lines=gzip.decompress((base/'failed-run-44938457098.stdout.gz').read_bytes()).decode().splitlines()
for start,end in [(57220,57280),(57535,57665),(72650,72751)]:
 print('FULL LOG',start,end)
 for i in range(start-1,min(end,len(lines))):print(f'{i+1}: {lines[i]}')
jobs=json.loads(gzip.decompress((base/'jobs-44938457098.stdout.gz').read_bytes()))['jobs']
print('ALL PIPELINE JOB VERDICTS')
for job in jobs:print(json.dumps({'name':job['name'],'id':job.get('databaseId'),'conclusion':job['conclusion']}))
p=root/'rust/tests/unit/ci_gates.rs';source=p.read_text().splitlines();print('RUST TEST SOURCE 85-140')
for i,line in enumerate(source[84:140],85):print(f'{i}: {line}')
