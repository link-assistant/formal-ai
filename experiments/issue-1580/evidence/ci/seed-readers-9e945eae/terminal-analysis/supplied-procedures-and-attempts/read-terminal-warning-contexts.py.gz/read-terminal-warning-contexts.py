from pathlib import Path
import gzip,json,subprocess,re
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/ci/seed-readers-9e945eae'
selections={'completed-run-44938456883.stdout.gz':[(640,680),(2255,2305)],'failed-run-44938456935.stdout.gz':[(3520,3555),(18640,18675),(26075,26110)],'failed-run-44938457098.stdout.gz':[(2235,2260),(69395,69430),(72365,72405)]}
for name,ranges in selections.items():
 lines=gzip.decompress((base/name).read_bytes()).decode().splitlines()
 for start,end in ranges:
  print('CONTEXT',name,start,end)
  for i in range(start-1,min(end,len(lines))):print(f'{i+1}: {lines[i]}')
  preceding=[(i+1,line) for i,line in enumerate(lines[:start]) if '##[group]Run ' in line]
  if preceding:print('PRECEDING COMMAND',preceding[-1])
for term in ['270s','execution budget','artifact-roundtrip-windows','canonical registry unavailable in deliberate fallback control']:
 r=subprocess.run(['rg','-n','--hidden','-F','--glob','!*.gz',term,'.github','scripts','rust/tests/web','experiments/issue-1580'],cwd=root,capture_output=True,text=True);assert r.returncode in (0,1)
 print('SOURCE SEARCH',term);print('\n'.join(r.stdout.splitlines()[:50]))
print('ARCHIVE TEST SEARCH')
p=Path('/tmp/issue-1580-research/find-archive-conservation-test-driver.log');print(p.read_text())
