from pathlib import Path
import json,gzip,hashlib,re,collections
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/ci/native-families-8c712eb9'
records=json.loads((base/'records.json').read_text());verified=[];annotations=[];native=[]
for row in records:
    for label in ('stdout','stderr'):
        value=row[label];packed=(base/value['file']).read_bytes();raw=gzip.decompress(packed)
        assert hashlib.sha256(raw).hexdigest()==value['rawSha256']
        assert hashlib.sha256(packed).hexdigest()==value['archiveSha256']
        assert len(raw)==value['bytes'] and len(raw.splitlines())==value['lines']
        verified.append(value['file'])
        if not row['name'].startswith('full-run-') or label!='stdout':continue
        for number,line in enumerate(raw.decode(errors='strict').splitlines(),1):
            match=re.search(r'##\[(warning|error)\](.*)',line)
            if not match:continue
            annotations.append({'command':row['name'],'file':value['file'],'line':number,'level':match[1],'message':match[2],'quotedShellSource':'\x1b[36;1m' in line})
scratch=Path('/tmp/issue-1580-research/current-head-repair')
jobs=[('core',136317612472,'native-compile-original.stdout'),('reasoning',136317612685,'native-136317612685.stdout'),('coding',136317612751,'native-136317612751.stdout'),('interfaces',136317612642,'native-136317612642.stdout'),('benchmarks',136317612804,'native-136317612804.stdout'),('hive-1',136317612700,'native-136317612700.stdout'),('hive-2',136317612737,'native-136317612737.stdout'),('hive-3',136317612609,'native-136317612609.stdout'),('registry',136317612384,'native-136317612384.stdout')]
for family,job,name in jobs:
    rows=[]
    for number,line in enumerate((scratch/name).read_text().splitlines(),1):
        match=re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',line)
        if match:rows.append({'line':number,'passed':int(match[1]),'failed':int(match[2]),'text':line})
    native.append({'family':family,'job':job,'sourceLog':name,'rawSha256':hashlib.sha256((scratch/name).read_bytes()).hexdigest(),'passed':sum(row['passed']for row in rows),'failed':sum(row['failed']for row in rows),'summaries':rows})
outcome=json.loads((base/'outcome.json').read_text());assert outcome['complete']and outcome['workflowCount']==27 and outcome['success']==23
assert sum(row['passed']for row in native)==526 and sum(row['failed']for row in native)==2
destination=base/'assessment';destination.mkdir(exist_ok=False)
data={'head':outcome['head'],'terminalWorkflows':27,'successfulWorkflows':23,'skippedWorkflows':1,'failedWorkflows':outcome['failed'],'verifiedStreams':len(verified),'nativeRustPassingTests':526,'nativeRustFailingTests':2,'actualReleaseCliCases':8,'nativeJobs':native,'fullWorkflowAnnotations':annotations,'limits':['Two native Pages contract assertions fail and are repaired only in the local draft until new-head hosted execution.','The read-only Rust CodeQL producer has one cleartext-logging finding; the constant diagnostic repair needs new-head analysis.','Actual source-size and dependency maintenance warnings remain open.','Passing current component tests do not qualify all production artifact consumers, live Pages publication or all original-source/budget acceptance.'],'fullIssueComplete':False,'independentAuthorshipCredit':0}
(destination/'summary.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
print('Verified streams:',len(verified),'native Rust:',526,'pass /',2,'fail; release CLI cases:',8,flush=True)
counts=collections.Counter((row['level'],row['quotedShellSource'])for row in annotations);print('Full-run annotations:',dict(counts),flush=True)
for row in annotations:
    if row['quotedShellSource']or 'approaching limit of' in row['message']:continue
    print(row['command'],row['line'],row['level'],row['message'],flush=True)
