from pathlib import Path
import subprocess,sys
source=Path('/tmp/issue-1580-research/assess-new-head-ci-and-codeql.py')
text=source.read_text().replace("scratch.mkdir(exist_ok=False)","scratch.mkdir(exist_ok=True)")
old="prior=[r for r in notifications(old) if r.get('level') in ('warning','error')]"
new="prior=[r for r in notifications(old) if r.get('level','warning') in ('warning','error')]"
assert old in text
first=Path('/tmp/issue-1580-research/new-head-terminal-assessment/initial-codeql-coverage.json')
assert not first.exists();first.write_bytes(Path('/tmp/issue-1580-research/new-head-terminal-assessment/codeql-coverage.json').read_bytes())
source.with_name('assess-new-head-ci-and-codeql-initial.py').write_text(source.read_text());source.write_text(text.replace(old,new))
result=subprocess.run([sys.executable,str(source)])
assert result.returncode==0
