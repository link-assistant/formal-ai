from pathlib import Path
from collections import Counter
import gzip,hashlib,json,re
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');local=scratch/'new-head-terminal-assessment'
base=root/'experiments/issue-1580/evidence/ci/native-families-76371322'
raw=gzip.decompress((base/'full-run-44754682051.stdout.gz').read_bytes());warnings=[]
for number,line in enumerate(raw.decode().splitlines(),1):
 match=re.search(r'WARNING: (.*?) has (\d+) lines \(approaching (.*?) limit of (\d+), warning threshold: (\d+)\)',line)
 if match:warnings.append({'line':number,'file':match[1],'lines':int(match[2]),'category':match[3],'limit':int(match[4]),'warningThreshold':int(match[5])})
assert len(warnings)==122
(local/'source-size-warnings.json').write_text(json.dumps(warnings,indent=2)+'\n')
assessment=json.loads((local/'ci-assessment.json').read_text());registry=gzip.decompress((base/'job-136352057390.stdout.gz').read_bytes()).decode();assert re.search(r'Ran 8 tests in [\d.]+s\n[^\n]*\n[^\n]*OK',registry)
assessment.update(actualReleaseCliCases=8,sourceSizeWarnings=122,publishTokenCertaintyWarnings=1)
(local/'ci-assessment.json').write_text(json.dumps(assessment,indent=2)+'\n')

def archive(destination,sources):
 destination.mkdir(exist_ok=False);records=[]
 for name,path in sources:
  original=path.read_bytes();raw=gzip.decompress(original) if path.suffix=='.gz' else original
  packed=original if path.suffix=='.gz' else gzip.compress(raw,mtime=0)
  name=name if name.endswith('.gz') else name+'.gz';target=destination/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(packed)
  assert gzip.decompress(packed)==raw
  records.append({'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
 (destination/'records.json').write_text(json.dumps(records,indent=2)+'\n');return len(records)
ci_sources=[(p.name,p) for p in local.iterdir() if p.is_file() and p.name in ['ci-assessment.json','workflow-annotations.json','source-size-warnings.json']]
ci_sources += [('helpers/'+n,scratch/n) for n in ['collect-current-repair-new-head-ci.py','assess-new-head-ci-and-codeql.py','assess-new-head-ci-and-codeql-initial.py','assess-new-head-ci-and-codeql.log','correct-codeql-warning-assessment.py','correct-codeql-warning-assessment.log']]
ci_sources += [('collector/'+p.name,p) for p in (scratch/'current-repair-new-head-ci').iterdir() if p.is_file()]
ci_sources += [('helpers/'+Path(__file__).name,Path(__file__))]
ci_count=archive(base/'assessment',ci_sources)
producer_sources=[]
for folder in ['current-security-original-reports','current-pipeline-and-codeql-notes']:
 for p in (scratch/folder).rglob('*'):
  if p.is_file() and p.suffix!='.zip':producer_sources.append((folder+'/'+str(p.relative_to(scratch/folder)),p))
producer_sources += [('crosswalk/'+p.name,p) for p in local.iterdir() if p.is_file() and p.name not in ['ci-assessment.json','workflow-annotations.json','source-size-warnings.json']]
for name in ['collect-current-security-reports','assess-current-security-reports','inspect-current-pipeline-and-codeql-notes','finish-codeql-context-crosswalk']:
 for suffix in ['.py','.log']:
  p=scratch/(name+suffix);assert p.is_file(),p;producer_sources.append(('helpers/'+p.name,p))
producer_count=archive(root/'experiments/issue-1580/evidence/ci/codeql-producer-76371322/assessment',producer_sources)
(root/'docs/case-studies/issue-1580/native-and-codeql-76371322-checkpoint.md').write_text('''# Exact-head native and original CodeQL producer results

Pull request: https://github.com/link-assistant/formal-ai/pull/1581

All 27 workflows for 763713221c0681393da9266d9ffc9cc7c2bbefe2 are terminal:
25 success, one explicit skip and one Layered CI failure. Every one of the 276
collected stdout/stderr streams passes original/compressed SHA-256, byte and line
verification. The failed assertion and local reproduction are documented in the
script/secret-inventory checkpoint; its correction awaits the next hosted head.
No skipped main-only application build or publication receives execution credit.

The native jobs pass 528 Rust cases, including the previously failing Pages
contracts and real-Git detector controls, plus eight actual release CLI cases.
The 528 include three registry helper cases. Coding/reasoning/interfaces,
benchmark and all three Hive families pass. Their logs preserve exact job IDs,
line-numbered summaries and filtered-case counts. This execution does not verify
later uncommitted script splits, actual live Pages delivery or historical replay
acceptance. Hosted logs retain 122 actual source-size warnings and one honest
publish-token certainty warning; these remain open except for separately drafted
structural repairs still awaiting their own hosted execution.

The explicit read-only Security producer 44754743681 uses the same source head.
Original CodeQL 2.27.5 Rust and Actions SARIF both have zero results and successful
invocations, with zero warning/error notifications. The Rust report's original
SHA-256 is 55b13f140c5f9c0a2d3c08dc93a7260b9762c8362b3e4ab10a80654acc1566c4;
Actions is 57b9861421e99056fda2e3be6b5a3f51381d597d8e2f8aed1ab7e5cee4b63d54.
Artifact metadata binds both original files to the producer run and head.

The actual extractor names all 2,573 expected Rust paths as successfully
extracted, with no path missing or added. All 105 paths previously lacking a
semantic manifest are present in the current original extraction. The historical
406 macro ABI and 105 missing-context warnings are absent without suppression.
Omitted SARIF notification levels default to warning: the initial assessment
forgot that default and then used an overly broad context substring. Both
incorrect intermediate assessments and the corrected exact-message crosswalk
remain retained; neither incorrect intermediate gets verification credit.

Remaining informational limits are explicit: Rust has 56 notes and 631
unresolved-macro notifications at level none. Their exact source locations,
source hashes and source lines are preserved: 282 in rust/src, 347 in rust/tests
and two examples. Successful file extraction does not establish every macro's
semantic coverage. That investigation and broader coverage acceptance stay open.
The Cargo audit still records Chrono's blocked dated exception and the historical
unsafe-libyaml maintenance warning; zero CodeQL findings does not resolve either.

Complete terminal logs and assessments are under
`experiments/issue-1580/evidence/ci/native-families-76371322/` and
`experiments/issue-1580/evidence/ci/codeql-producer-76371322/`.
Every broader unfinished issue requirement remains open; PR #1581 stays draft.
Supplied commands, helpers and patches earn zero independent reasoning credit.
''')
with (root/'experiments/issue-1580/work-plan.md').open('a') as out:
 out.write('\n- Exact 76371322 results are now complete: 27 terminal workflows, 25 successes / one skip / one stale-profile failure, 276 streams verified, 528 native Rust and eight actual release CLI cases pass. Original CodeQL 2.27.5 Rust/Actions producer reports contain zero findings or warning/error notifications. The exact-message crosswalk verifies all 105 formerly context-free paths within 2,573 expected/extracted paths; preserve omitted-level/substr assessment mistakes and corrections. The 631 informational unresolved-macro locations, 122 actual size warnings, publish-token certainty, dependency warnings and every broader criterion remain open. New local structural/BuildKit repairs still require their own next-head hosted execution.\n')
print('Archived CI assessment records',ci_count,'producer assessment records',producer_count)
for row in warnings:print(row['file'],row['lines'],row['category'])
