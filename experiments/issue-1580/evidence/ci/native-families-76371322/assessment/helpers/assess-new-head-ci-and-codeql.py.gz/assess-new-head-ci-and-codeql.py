from pathlib import Path
from collections import Counter
import gzip,hashlib,json,re,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/ci/native-families-76371322'
scratch=Path('/tmp/issue-1580-research/new-head-terminal-assessment');scratch.mkdir(exist_ok=True)
records=json.loads((base/'records.json').read_text());lookup={r['name']:r for r in records};annotations=[];verified=0
for record in records:
 for label in ('stdout','stderr'):
  entry=record[label];packed=(base/entry['file']).read_bytes();raw=gzip.decompress(packed)
  assert hashlib.sha256(packed).hexdigest()==entry['archiveSha256']
  assert hashlib.sha256(raw).hexdigest()==entry['rawSha256']
  assert len(raw)==entry['bytes'] and len(raw.splitlines())==entry['lines']
  verified+=1
  if label=='stdout' and record['name'].startswith('full-run-'):
   for number,line in enumerate(raw.decode().splitlines(),1):
    match=re.search(r'##\[(warning|error)\](.*)',line)
    if match: annotations.append({'file':entry['file'],'line':number,'level':match[1],'text':match[2],'quotedShellSource':'\x1b[36;1m' in line})
pipeline=json.loads(gzip.decompress((base/lookup['jobs-44754682051']['stdout']['file']).read_bytes()))
native=[]
for job in pipeline['jobs']:
 if not job['name'].startswith('Native type and lint check /'):continue
 assert job['conclusion']=='success'
 record=lookup['job-'+str(job['databaseId'])];entry=record['stdout'];lines=gzip.decompress((base/entry['file']).read_bytes()).decode().splitlines();summaries=[]
 for number,line in enumerate(lines,1):
  match=re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',line)
  if match:summaries.append({'line':number,'passed':int(match[1]),'failed':int(match[2]),'text':line})
 native.append({'name':job['name'],'job':job['databaseId'],'log':entry['file'],'lines':len(lines),'passed':sum(r['passed'] for r in summaries),'failed':sum(r['failed'] for r in summaries),'summaries':summaries})
latest=json.loads((base/'latest.json').read_text());assert latest['completed']==27 and latest['success']==25
assessment={'head':latest['head'],'verifiedStreams':verified,'terminalWorkflows':27,'successfulWorkflows':25,'skippedWorkflows':1,'failedWorkflows':latest['failed'],'nativeJobs':native,'nativeRustPassingTests':sum(r['passed'] for r in native),'nativeRustFailingTests':sum(r['failed'] for r in native),'annotationCounts':dict(Counter((r['level']+(':quoted' if r['quotedShellSource'] else ':emitted')) for r in annotations)),'fullIssueComplete':False,'independentAuthorshipCredit':0}
(scratch/'ci-assessment.json').write_text(json.dumps(assessment,indent=2)+'\n');(scratch/'workflow-annotations.json').write_text(json.dumps(annotations,indent=2)+'\n')
print(json.dumps(assessment,indent=2))
for row in annotations:
 if not row['quotedShellSource'] and 'approaching limit of' not in row['text']:print('diagnostic',json.dumps(row))

def read_report(folder):
 directory=root/'experiments/issue-1580/evidence/ci'/folder
 entry=next(r for r in json.loads((directory/'producer-files.json').read_text()) if r['relativePath']=='rust.sarif')
 packed=(directory/entry['file']).read_bytes();raw=gzip.decompress(packed)
 assert hashlib.sha256(packed).hexdigest()==entry['archiveSha256'] and hashlib.sha256(raw).hexdigest()==entry['rawSha256']
 return json.loads(raw)['runs'][0]
old=read_report('codeql-producer-ad59ff56');current=read_report('codeql-producer-76371322')
def notifications(run):return [r for invocation in run['invocations'] for r in invocation.get('toolExecutionNotifications',[])]
def paths(rows):return {p['physicalLocation']['artifactLocation']['uri'] for r in rows for p in r.get('locations',[])}
prior=[r for r in notifications(old) if r.get('level','warning') in ('warning','error')]
(scratch/'old-warning-notifications.json').write_text(json.dumps(prior,indent=2)+'\n')
extracted=paths([r for r in notifications(current) if r.get('descriptor',{}).get('id')=='rust/diagnostics/successfully-extracted-files'])
expected=paths([r for r in notifications(current) if r.get('descriptor',{}).get('id')=='cli/expected-extracted-files/rust'])
macro=[]
for item in notifications(current):
 if item.get('descriptor',{}).get('id')!='rust/diagnostics/unresolved-macro-calls':continue
 for location in item.get('locations',[]):
  physical=location['physicalLocation'];path=physical['artifactLocation']['uri'];region=physical.get('region',{});number=region.get('startLine')
  raw=subprocess.check_output(['git','show',latest['head']+':'+path]);lines=raw.decode().splitlines()
  macro.append({'file':path,'line':number,'region':region,'sourceSha256':hashlib.sha256(raw).hexdigest(),'source':lines[number-1] if number else None,'level':item.get('level')})
(scratch/'unresolved-macro-locations.json').write_text(json.dumps(macro,indent=2)+'\n')
context_paths=paths([r for r in prior if 'context' in r.get('message',{}).get('text','').lower()])
coverage={'head':latest['head'],'expectedFiles':len(expected),'successfullyExtractedFiles':len(extracted),'missingExpectedFiles':sorted(expected-extracted),'unexpectedExtractedFiles':sorted(extracted-expected),'oldWarningDescriptors':dict(Counter(r.get('descriptor',{}).get('id') for r in prior)),'oldContextWarningFiles':len(context_paths),'oldContextPathsMissingExtraction':sorted(context_paths-extracted),'remainingUnresolvedMacroCalls':len(macro),'macroSourceRoots':dict(Counter('/'.join(r['file'].split('/')[:2]) for r in macro)),'macroSourceCalls':dict(Counter(re.match(r'\s*([\w:]+!)',r['source'] or '').group(1) if re.match(r'\s*([\w:]+!)',r['source'] or '') else '(other)' for r in macro)),'allMacroSemanticsVerified':False,'fullIssueComplete':False}
(scratch/'codeql-coverage.json').write_text(json.dumps(coverage,indent=2)+'\n');print(json.dumps(coverage,indent=2))
