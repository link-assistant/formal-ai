from pathlib import Path
import subprocess,json,time,hashlib,re,datetime
out=Path('/tmp/issue-1580-research/c55-complete-terminal');head='c55a5f9c50ebe58d9bb6103ca46c685e355fcd0d'
def capture(name,args):
 with (out/name).open('w') as f,(out/(name+'.stderr')).open('w') as err:r=subprocess.run(args,stdout=f,stderr=err)
 if r.returncode:raise RuntimeError(str(args)+' exit '+str(r.returncode))
 return json.loads((out/name).read_text())
for attempt in range(1,161):
 allruns=capture('runs.json',['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','100','--json','databaseId,workflowName,status,conclusion,createdAt,updatedAt,headSha,url'])
 runs=[r for r in allruns if r['headSha']==head]
 status={'attempt':attempt,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'count':len(runs),'active':[r for r in runs if r['status']!='completed']}
 (out/'waiting.json').write_text(json.dumps(status,indent=2)+'\n');print('OBSERVATION',attempt,'runs',len(runs),'active',len(status['active']),flush=True)
 if len(runs)>=33 and not status['active']:break
 time.sleep(45)
else:raise RuntimeError('CI remains active after 160 bounded observations; no terminal qualification claimed')
rows=[];diagnostics=[]
for run in runs:
 p=out/(str(run['databaseId'])+'.log')
 with p.open('w') as f,(out/(p.name+'.stderr')).open('w') as err:r=subprocess.run(['gh','run','view',str(run['databaseId']),'--repo','link-assistant/formal-ai','--log'],stdout=f,stderr=err)
 if r.returncode:raise RuntimeError('complete log failed '+str(run['databaseId']))
 data=p.read_bytes();row={'run':run,'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'lines':len(data.splitlines())};rows.append(row)
 for n,line in enumerate(data.decode(errors='replace').splitlines(),1):
  if re.search(r'##\[(error|warning)\]|::(?:error|warning)\b|(?:^|\s)(?:error\[[^]]+\]|fatal:|FAILED|Error:)',line):diagnostics.append({'runId':run['databaseId'],'workflow':run['workflowName'],'line':n,'text':line})
 (out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n');print('COLLECTED',run['databaseId'],run['conclusion'],len(data),flush=True)
checksPages=capture('checks-pages.json',['gh','api',f'repos/link-assistant/formal-ai/commits/{head}/check-runs?per_page=100','--paginate','--slurp'])
checks=[check for page in checksPages for check in page['check_runs']];annotations=[]
for check in checks:
 if check['output']['annotations_count']:
  pages=capture('annotations-'+str(check['id'])+'.json',['gh','api',f"repos/link-assistant/formal-ai/check-runs/{check['id']}/annotations?per_page=100",'--paginate','--slurp'])
  annotations.append({'check':check,'annotations':[x for page in pages for x in page]})
(out/'diagnostics.json').write_text(json.dumps(diagnostics,indent=2)+'\n')
(out/'check-annotations.json').write_text(json.dumps({'head':head,'checkCount':len(checks),'annotated':annotations},indent=2)+'\n')
(out/'outcome.json').write_text(json.dumps({'head':head,'allRunsTerminal':True,'collectionComplete':True,'runs':rows,'checkCount':len(checks),'annotationCount':sum(len(x['annotations']) for x in annotations),'diagnosticCount':len(diagnostics),'literalCompleteWorkflowReviewClaim':False},indent=2)+'\n')
print('COMPLETE',len(rows),'checks',len(checks),'annotations',sum(len(x['annotations']) for x in annotations),flush=True)
