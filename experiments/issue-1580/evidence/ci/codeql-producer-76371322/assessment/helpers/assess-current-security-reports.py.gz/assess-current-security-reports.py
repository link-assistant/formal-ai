from pathlib import Path
from collections import Counter
import gzip, hashlib, json, re

base = Path('experiments/issue-1580/evidence/ci/codeql-producer-76371322')
out = Path('/tmp/issue-1580-research/current-security-original-reports')
reports = []
for record in json.loads((base / 'producer-files.json').read_text()):
    packed = (base / record['file']).read_bytes()
    raw = gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest() == record['archiveSha256']
    assert hashlib.sha256(raw).hexdigest() == record['rawSha256']
    assert len(raw) == record['bytes']
    document = json.loads(raw)
    for run in document['runs']:
        invocations = []
        for invocation in run.get('invocations', []):
            notifications = invocation.get('toolExecutionNotifications', [])
            configuration = invocation.get('toolConfigurationNotifications', [])
            invocations.append({'successful': invocation.get('executionSuccessful'),
                'executionLevels': dict(Counter(row.get('level', 'unspecified') for row in notifications)),
                'executionDescriptors': dict(Counter(row.get('descriptor', {}).get('id', 'unspecified') for row in notifications)),
                'configurationLevels': dict(Counter(row.get('level', 'unspecified') for row in configuration)),
                'warningOrErrorNotifications': [row for row in notifications + configuration if row.get('level') in ['warning', 'error']]})
        row = {'file': record['file'], 'originalSha256': record['rawSha256'], 'version': document['version'],
            'driver': run['tool']['driver']['name'], 'toolVersion': run['tool']['driver'].get('semanticVersion'),
            'results': run.get('results', []), 'invocations': invocations, 'artifacts': len(run.get('artifacts', []))}
        reports.append(row)
    print(record['file'], 'verified', len(raw), 'bytes')
jobs = []
for record in json.loads((base / 'records.json').read_text()):
    for label in ['stdout', 'stderr']:
        entry = record[label]
        packed = (base / entry['file']).read_bytes()
        raw = gzip.decompress(packed)
        assert hashlib.sha256(packed).hexdigest() == entry['archiveSha256']
        assert hashlib.sha256(raw).hexdigest() == entry['rawSha256']
    if not record['name'].startswith('job-'):
        continue
    entry = record['stdout']
    lines = gzip.decompress((base / entry['file']).read_bytes()).decode().splitlines()
    selected = [{'line': i + 1, 'text': line} for i, line in enumerate(lines)
                if re.search(r'##\[(?:warning|error)\]|\b(?:WARN|ERROR)\b|Strict CodeQL|strict CodeQL|RUSTSEC-', line)]
    target = out / (record['name'] + '.diagnostics.json')
    target.write_text(json.dumps(selected, indent=2) + '\n')
    jobs.append({'file': entry['file'], 'lines': len(lines), 'candidateDiagnostics': len(selected),
                 'emittedWorkflowWarnings': sum('##[warning]' in line for line in lines),
                 'emittedWorkflowErrors': sum('##[error]' in line for line in lines)})
assessment = {'head': json.loads((base / 'outcome.json').read_text())['head'],
              'reports': reports, 'jobs': jobs, 'fullIssueComplete': False, 'independentAuthorshipCredit': 0}
(out / 'assessment.json').write_text(json.dumps(assessment, indent=2) + '\n')
print(json.dumps(assessment, indent=2))
