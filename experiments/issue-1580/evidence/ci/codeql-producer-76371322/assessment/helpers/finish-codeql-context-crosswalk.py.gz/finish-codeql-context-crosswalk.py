from pathlib import Path
from collections import Counter
import gzip,json,hashlib,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research/new-head-terminal-assessment')
prior=json.loads((scratch/'old-warning-notifications.json').read_text())
context=[r for r in prior if 'semantic analyzer unavailable (no manifest found)' in r['message']['text']]
paths=sorted({p['physicalLocation']['artifactLocation']['uri'] for r in context for p in r['locations']})
assert len(context)==105 and len(paths)==105
b=root/'experiments/issue-1580/evidence/ci/codeql-producer-76371322';entry=next(r for r in json.loads((b/'producer-files.json').read_text()) if r['relativePath']=='rust.sarif');run=json.loads(gzip.decompress((b/entry['file']).read_bytes()))['runs'][0]
notifications=[r for i in run['invocations'] for field in ['toolExecutionNotifications','toolConfigurationNotifications'] for r in i.get(field,[])]
assert not [r for r in notifications if r.get('level','warning') in ['warning','error']]
extracted={p['physicalLocation']['artifactLocation']['uri'] for r in notifications if r.get('descriptor',{}).get('id')=='rust/diagnostics/successfully-extracted-files' for p in r['locations']}
coverage=json.loads((scratch/'codeql-coverage.json').read_text())
(scratch/'intermediate-codeql-coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
coverage.update(oldContextWarningFiles=len(paths),oldContextPathsMissingExtraction=sorted(set(paths)-extracted),oldContextPathCrosswalk=[{'file':p,'currentlyExtracted':p in extracted} for p in paths],assessmentCorrection='Historical notifications without level default to warning under SARIF; classify the 105 missing-manifest diagnostics by their exact actual message, not a generic context substring. All source bytes and earlier failed assessments remain retained.')
assert not coverage['oldContextPathsMissingExtraction'];(scratch/'codeql-coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
print('All 105 formerly context-free source paths are present in original current producer extraction; zero warning/error notifications, including omitted-level defaults.')
for name in ['rust/ql/src/Diagnostics','rust/ql/src/diagnostics']:
 result=subprocess.run(['gh','api','repos/github/codeql/contents/'+name,'--paginate'],capture_output=True)
 target=scratch/('codeql-'+name.rsplit('/',1)[1]);target.with_suffix('.stdout').write_bytes(result.stdout);target.with_suffix('.stderr').write_bytes(result.stderr)
 if result.returncode==0:
  entries=json.loads(result.stdout);print(name,[r['name'] for r in entries]);break
else:print('Primary diagnostic-source discovery did not resolve; no inferred semantics credit.')
