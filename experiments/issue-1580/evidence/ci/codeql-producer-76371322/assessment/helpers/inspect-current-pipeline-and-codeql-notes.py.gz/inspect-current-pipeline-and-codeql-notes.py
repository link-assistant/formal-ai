from pathlib import Path
import gzip, hashlib, json, subprocess
base = Path('/tmp/issue-1580-research/current-pipeline-and-codeql-notes')
base.mkdir(exist_ok=False)
argv = ['gh','run','view','44754682051','--repo','link-assistant/formal-ai','--json','headSha,status,conclusion,jobs']
result = subprocess.run(argv, capture_output=True)
(base/'pipeline.stdout.gz').write_bytes(gzip.compress(result.stdout, mtime=0))
(base/'pipeline.stderr.gz').write_bytes(gzip.compress(result.stderr, mtime=0))
assert result.returncode == 0
state = json.loads(result.stdout)
print('pipeline',state['headSha'],state['status'],state['conclusion'])
for job in state['jobs']:
    print(json.dumps({'id':job['databaseId'],'name':job['name'],'status':job['status'],
        'conclusion':job['conclusion'],'activeSteps':[row['name'] for row in job['steps'] if row['status']=='in_progress']}))
source = Path('experiments/issue-1580/evidence/ci/codeql-producer-76371322')
for record in json.loads((source/'producer-files.json').read_text()):
    if not record['relativePath'].endswith('rust.sarif'):
        continue
    document=json.loads(gzip.decompress((source/record['file']).read_bytes()))
    for run in document['runs']:
        notes=[row for invocation in run.get('invocations',[]) for row in invocation.get('toolExecutionNotifications',[]) if row.get('level')=='note']
        (base/'rust-notes.json').write_text(json.dumps(notes,indent=2)+'\n')
        print('Rust informational notes:',len(notes))
