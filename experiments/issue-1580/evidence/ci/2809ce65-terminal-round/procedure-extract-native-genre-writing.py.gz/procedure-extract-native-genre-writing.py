from pathlib import Path
import hashlib,json,subprocess,os
out=Path('/tmp/issue-1580-research/native-rewrite-warning-repair');out.mkdir(exist_ok=True)
parent=Path('rust/src/solver_handlers/text_rewrite.rs');before=parent.read_text();assert len(before.splitlines())==941
start=before.index("/// The genre styleguide's required slots")
end=before.index('/// The text-transform umbrella')
body=before[start:end].rstrip()+'\n'
child=parent.with_suffix('')/'genre_writing.rs';assert not child.exists();child.parent.mkdir(exist_ok=True)
child.write_text('use super::*;\n\n'+body)
parent.write_text(before[:start]+'mod genre_writing;\npub use genre_writing::handle_genre_writing;\n\n'+before[end:])
assert child.read_text().removeprefix('use super::*;\n\n')==body
assert parent.read_text().replace('mod genre_writing;\npub use genre_writing::handle_genre_writing;\n\n',before[start:end])==before
(out/'text_rewrite.rs.before').write_text(before)
ledger=Path('data/meta/core-boundary-ledger.lino');text=ledger.read_text();(out/'core-boundary-ledger.lino.before').write_text(text)
parentLines=len(parent.read_text().splitlines());childLines=len(child.read_text().splitlines());delta=parentLines+childLines-941
assert parentLines<=900 and childLines<=900
old='  source rust/src/solver_handlers/text_rewrite.rs\n    disposition promote\n    baseline_lines 941\n';assert text.count(old)==1
new=f'  source rust/src/solver_handlers/text_rewrite/genre_writing.rs\n    disposition promote\n    baseline_lines {childLines}\n    core_component text_rewrite_interpreter\n    reason "Issue #1580 moves the complete seed-driven genre-writing entry point and its two private helpers out of text_rewrite.rs. Original bodies and comments are conserved; the promoted interpreter disposition remains unchanged."\n'+old.replace('941',str(parentLines))
text=text.replace(old,new);assert text.count('  source_file_count_max 94\n')==1 and text.count('  source_lines_max 37186\n')==1
text=text.replace('  source_file_count_max 94\n','  source_file_count_max 95\n').replace('  source_lines_max 37186\n',f'  source_lines_max {37186+delta}\n')
note=f'  note "Issue #1580 conserves all three genre-writing functions and their comments in text_rewrite/genre_writing.rs. The parent falls from 941 to {parentLines} lines and the child has {childLines}; module imports/re-export add {delta} source lines. The exact census is 95 files and {37186+delta} lines; dispositions and outside-core ceilings are unchanged."\n'
ledger.write_text(text.replace('core_boundary_ledger\n','core_boundary_ledger\n'+note,1))
identity={'originalParentLines':941,'parentLines':parentLines,'childLines':childLines,'sourceLineDelta':delta,'preservedBodySha256':hashlib.sha256(body.encode()).hexdigest(),'completeParentRoundTripConserved':True,'sourceBodiesAndCommentsConserved':True,'localRustCompilation':False,'authorshipCredit':0}
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps(identity))
env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'};checks=[]
for name,args in [('rustfmt',['rustfmt','--edition','2024','--check','rust/src/solver_handlers/text_rewrite.rs',str(child)]),('core-boundary',['node','scripts/check-minimal-core-boundary.mjs']),('size',['node','scripts/check-file-size.mjs'])]:
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=env)
 checks.append({'name':name,'exitCode':r.returncode});(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
 assert r.returncode==0,name
print(json.dumps(checks))
