from pathlib import Path
import gzip,json,hashlib,subprocess
scratch=Path('/tmp/issue-1580-research');source=scratch/'2809-complete-terminal';a=json.loads((source/'outcome.json').read_text());assert a['collectionComplete'] and a['allRunsTerminal'] and len(a['runs'])==33
dest=Path('experiments/issue-1580/evidence/ci/2809ce65-terminal-round');dest.mkdir(parents=True,exist_ok=True);assert not (dest/'manifest.json').exists()
items=[]
def retain(p,target):
 data=p.read_bytes();packed=gzip.compress(data,mtime=0);(dest/(target+'.gz')).write_bytes(packed);items.append({'path':target+'.gz','bytes':len(data),'lines':len(data.splitlines()),'sha256':hashlib.sha256(data).hexdigest(),'compressedSha256':hashlib.sha256(packed).hexdigest()})
for row in a['runs']:
 p=Path(row['path']);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];retain(p,'workflow-'+str(row['run']['databaseId'])+'.log')
for name in ['outcome.json','check-annotations.json','diagnostics.json','additional-warning-scan.json','checks-pages.json']:retain(source/name,name)
for name in ['issue','conversation','inline','reviews','pr']:retain(scratch/'current-round-feedback'/(name+'.json'),'feedback-'+name+'.json')
for name in ['identity.json','checks.json','text_rewrite.rs.before','core-boundary-ledger.lino.before','rustfmt.log','core-boundary.log','size.log']:retain(scratch/'native-rewrite-warning-repair'/name,'native-rewrite-'+name)
for p in [scratch/'extract-native-genre-writing.py',scratch/'verify-disabled-zizmor-retry-final-driver.log',scratch/'zizmor-transport-checks/disabled-retry-negative-control.json',scratch/'scan-all-current-ci-warning-streams-final-driver.log',scratch/'archive-current-terminal-and-native-headroom.py']:retain(p,'procedure-'+p.name)
manifest={'head':a['head'],'completeWorkflows':33,'conclusions':{'success':29,'failure':3,'skipped':1},'checkCount':a['checkCount'],'annotationCount':a['annotationCount'],'literalCompleteWorkflowReviewClaim':False,'completeStreamDiagnosticAndWarningScan':True,'reviewedActualDiagnosticsAndSource':True,'newActionableWarning':'941-line native text rewrite source','suppliedAuthorshipCredit':0,'issueComplete':False,'items':items}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
doc=Path('docs/case-studies/issue-1580/hosted-round-2809-repairs.md');s=doc.read_text();s+='''

## Terminal round and native readability warning

All 33 workflows on `2809ce65` are terminal: 29 succeeded, three failed and
one skipped. All 163 check records and 30 annotations are retained with the
33 complete original workflow streams and content hashes under
`evidence/ci/2809ce65-terminal-round/`. All four native Hive groups passed.
The BuildKit fallback control now produced two notices and no failure
annotation; its actual image and daemon verification job succeeded. The full
streams were scanned for diagnostics and warnings and actual diagnostic
contexts were reviewed; no literal reading of all 70,810 Pipeline lines is
claimed. Echoed error branches, deliberate worker-import failures and the
release-tag/detached-HEAD negative controls are distinguished from real
failures. The crates.io publish-token observation remains honestly unknown;
a public read cannot prove publish authority.

The final annotation inventory exposed a real new source-headroom warning:
`text_rewrite.rs` has 941 lines (Pipeline complete-log 2114–2115). Extract the
entire genre-writing handler and both private helpers into its child module,
using the same module/re-export pattern as the existing statistics split.
The parent is now 643 lines and the child 302. Original function bodies and
comments are conserved exactly; substituting the captured original region
reconstructs the entire original parent byte for byte. The module import and
re-export account for four additional aggregate lines, explicitly recorded
in the 95-file promoted-core census. No dispositions, migration ceilings,
request vocabulary or language behavior change. Rust formatting, the source
census and the existing file-size check pass without a local Rust build.
The repaired source still requires hosted compiler and behavior execution.

The Zizmor negative-control driver initially assumed TAP summary prefixes;
the actual Node reporter used `ℹ`. Its real result was already two expected
failures and four passes. The corrected reporter-independent assertion and
unchanged negative-control rerun both preserve that result. The failed
controller result is retained rather than called a passing execution.
''';doc.write_text(s)
print('Retained terminal evidence',len(items),'streams',sum(p.stat().st_size for p in dest.iterdir()),'compressed bytes')
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
subprocess.run(['git','add','--','rust/src/solver_handlers/text_rewrite.rs','rust/src/solver_handlers/text_rewrite/genre_writing.rs','data/meta/core-boundary-ledger.lino'],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','Extract native genre writing while conserving its complete implementation'],check=True)
print('LOCAL',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'NO PUSH')
