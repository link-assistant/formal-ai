from pathlib import Path
import json,subprocess,urllib.request,datetime
out=Path('/tmp/issue-1580-research/6903-chrono-upstream');out.mkdir(exist_ok=True)
for label,path in [('command-stream','link-foundation/command-stream/issues/238'),('calculator','link-assistant/calculator/issues/265')]:
 p=subprocess.run(['gh','api','repos/'+path],capture_output=True,text=True);(out/(label+'-issue.json')).write_text(p.stdout);(out/(label+'-issue.stderr')).write_text(p.stderr);assert p.returncode==0
 x=json.loads(p.stdout);print(label,'issue',x['state'],x['updated_at'],x['html_url'])
for name in ['command-stream','link-calculator']:
 url='https://crates.io/api/v1/crates/'+name
 request=urllib.request.Request(url,headers={'User-Agent':'formal-ai-issue-1580-qualification'})
 with urllib.request.urlopen(request,timeout=30) as response:raw=response.read(4*1024*1024+1)
 assert len(raw)<=4*1024*1024
 (out/(name+'-registry.json')).write_bytes(raw);x=json.loads(raw);version=x['crate']['max_stable_version']
 url='https://crates.io/api/v1/crates/'+name+'/'+version+'/dependencies'
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'formal-ai-issue-1580-qualification'}),timeout=30) as response:raw=response.read(4*1024*1024+1)
 assert len(raw)<=4*1024*1024
 (out/(name+'-dependencies.json')).write_bytes(raw);deps=json.loads(raw)['dependencies']
 print(name,'current stable',version,'chrono',[(v['crate_id'],v['req'],v['kind'],v['optional']) for v in deps if v['crate_id'] in ['chrono','jiff']])
(out/'observed-at.txt').write_text(datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n')
