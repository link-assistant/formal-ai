from pathlib import Path
from collections import Counter
import subprocess,json,gzip,hashlib,datetime
scratch=Path('/tmp/issue-1580-research');src=scratch/'6903-complete-terminal'
out=json.loads((src/'outcome.json').read_text());assert out['collectionComplete'] and out['allRunsTerminal']
assert out['head']=='6903d9bd28ac96f3e73b35d700dce1415c0f5ac6'
assert len(out['runs'])==33 and out['checkCount']==163 and out['annotationCount']==29
failed={v['run']['databaseId'] for v in out['runs'] if v['run']['conclusion']=='failure'}
assert failed=={44978282591,44978282529,44978282675}
checks=[v for page in json.loads((src/'checks-pages.json').read_text()) for v in page['check_runs']]
native=[v for v in checks if 'Native contracts (' in v['name']]
assert len(native)==10 and all(v['conclusion']=='success' for v in native)
annotations=json.loads((src/'check-annotations.json').read_text());classified=[]
for row in annotations['annotated']:
 for a in row['annotations']:
  level=a['annotation_level'];message=a['message'];check=row['check']['name']
  if level=='failure':
   if check=='Actionlint':decision='repaired-bounded-checkout-recovery'
   elif check in ['Pipeline Status','Native type and lint check / Rust compile inputs changed']:decision='repaired-shared-zizmor-contract-and-terminal-propagation'
   elif check.endswith('suite group 5)'):decision='repaired-complete-yaml-sequence-structural-equality'
   elif check.endswith('suite group 8)'):decision='repaired-actual-original-verifier-git-object-binding'
   else:raise AssertionError(('unclassified failure',check,message))
  elif level=='warning':
   assert check=='Release Preflight' and message.startswith('UNKNOWN: crates.io publish token')
   decision='unresolved-publication-authority-observation-no-read-proof-available'
  elif level=='notice':
   if check=='pr-check-profile / profile':decision='explicit-unexecuted-heavy-path-notice-no-capability-credit'
   elif a['title'].startswith('sccache stats'):decision='actual-cache-statistics-zero-errors'
   elif check=='Artifact transport (macos-15)':decision='hosted-capacity-notice-job-actually-passed'
   elif check=='Immutable BuildKit bootstrap and registry fallback':decision='deliberate-outage-control-actual-mirror-daemon-check-passed'
   else:raise AssertionError(('unclassified notice',check,message))
  else:raise AssertionError(level)
  classified.append({'checkId':row['check']['id'],'name':check,'annotation':a,'decision':decision})
dest=Path('experiments/issue-1580/evidence/ci/6903d9bd-terminal-round');dest.mkdir(exist_ok=True)
records=[]
files=[p for p in sorted(src.iterdir()) if p.is_file() and p.name not in ['worker-pid','collect.py']]
files += [p for p in sorted((scratch/'6903-chrono-upstream').iterdir()) if p.is_file()]
files += [scratch/'archive-6903-terminal-round.py',scratch/'refresh-chrono-upstream-6903.py',scratch/'refresh-chrono-upstream-6903-driver.log']
for p in files:
 raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);name=f'{len(records)+1:03d}-{p.parent.name}-{p.name}.gz'
 (dest/name).write_bytes(packed);records.append({'file':name,'source':str(p),'bytes':len(raw),'lines':len(raw.splitlines()),'sha256':hashlib.sha256(raw).hexdigest(),'compressedSha256':hashlib.sha256(packed).hexdigest()})
for row in out['runs']:assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
(dest/'annotation-decisions.json').write_text(json.dumps(classified,indent=2)+'\n')
summary={'head':out['head'],'allRunsTerminal':True,'completeRawWorkflowLogs':33,'checks':163,'annotations':29,'annotationLevels':dict(Counter(v['annotation']['annotation_level'] for v in classified)),'workflowConclusions':dict(Counter(v['run']['conclusion'] for v in out['runs'])),'nativeGroupConclusions':{v['name']:v['conclusion'] for v in native},'allActionableCurrentRunFailuresRepairedLocally':True,'newHeadHostedExecutionPending':True,'unresolvedWarning':'crates.io publish authority cannot be established by public/read-only requests','freshRegistryObservation':'command-stream 1.13.0 and link-calculator 0.24.0 both still require Chrono','files':records,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(dest/'manifest.json').write_text(json.dumps(summary,indent=2)+'\n')
doc=Path('docs/case-studies/issue-1580/hosted-round-6903-repairs.md')
text=doc.read_text();text += '''
## Terminal collection of the published source

All 33 workflows are now terminal: 29 succeeded, three failed and the explicit
Issue 1028 scope gate skipped. The complete 106,651 log lines, all 163 check
records and all 29 annotations are retained with original byte hashes in
[the terminal collection](../../../experiments/issue-1580/evidence/ci/6903d9bd-terminal-round/manifest.json).
All ten actual native contract groups succeeded. The failed type/lint job's
compiler step succeeded; its separate workflow-contract step exposed the one
stale Zizmor contract described above. All three actionable workflow failures
have local repairs. This is verification of published `6903d9bd`, not of its
three later implementation commits.

Every annotation has an explicit disposition: eight failure annotations map to
the repaired failures and terminal propagation; one warning preserves genuinely
unknown crates.io publication authority; twenty notices retain the explicit
unexecuted heavy paths, successful zero-error cache statistics, macOS capacity
notice and successful deliberate BuildKit outage control. Printed shell bodies,
expected Git failure controls and browser-import negative-control stacks are
not additional failed producer results. Their original full streams remain
available for inspection; no whole-log literal-reading claim is made.

Fresh registry observations on 22 November still show command-stream 1.13.0
requiring Chrono ^0.4.45 and link-calculator 0.24.0 requiring Chrono ^0.4.
Command-stream's source migration report is closed, but that change is not yet
available in its latest published crate. Calculator's migration report remains
open. Both published dependency paths still block removal of the existing
exact-version, self-expiring exception. No source fix or public registry read
is presented as proof of a dependency migration or publication authority.

Current main `82e506f5447cd6c0b96095993107d6d028a890f5` is an ancestor of
the local branch. All issue comments, PR conversation comments, inline comments
and reviews were refreshed; their counts remain 1, 11, 0 and 0. The aggregate
PR review, applicable-practice execution, strict/live acceptance and genuine
authorship criteria remain unfinished. The next published source requires its
own complete hosted verification before any readiness claim.
'''
doc.write_text(text)
plan=Path('experiments/issue-1580/work-plan.md');text=plan.read_text().replace('- [ ] Collect every current-head terminal workflow and annotation, repair every additional actionable result, then publish one coordinated batch.','- [x] Collect all 33 terminal current-head workflows, 163 checks and 29 annotations; all ten native groups pass, and the three actionable failing workflows have local repairs. Preserve fresh dependency-publication blockers separately.\n- [ ] Publish the complete locally verified batch only after a fresh queue/source preflight, then qualify its actual hosted results.')
plan.write_text(text)
# Record this small review increment without claiming a complete aggregate review.
review=Path('experiments/issue-1580/evidence/checks/aggregate-review-continuation');review.mkdir(exist_ok=True)
idx=json.loads((scratch/'6903-aggregate-continuation/index.json').read_text());read_names={f'{n:04}.diff' for n in [0,1,2,3,4,5,6,7,8,9,19,56,58,99,102,126]}
selected=[v for v in idx['files'] if v['diff'] in read_names]
for v in selected:
 raw=(scratch/'6903-aggregate-continuation'/v['diff']).read_bytes();assert hashlib.sha256(raw).hexdigest()==v['sha256'];(review/(v['diff']+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
(review/'manifest.json').write_text(json.dumps({'head':idx['head'],'base':idx['base'],'newCompleteDiffsRead':selected,'previousExactDiffReviewsCarried':83,'currentProductionDiffsInventoried':524,'wholePullRequestReviewed':False,'allPriorFeaturesProvenPreserved':False,'independentAuthorshipCredit':0},indent=2)+'\n')
subprocess.run(['git','add','--',str(dest),str(review),str(doc),str(plan)],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','Preserve complete hosted results and refresh dependency blockers'],check=True)
print(json.dumps({k:v for k,v in summary.items() if k not in ['files','nativeGroupConclusions']},indent=2))
print('HEAD',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
print('STATUS',subprocess.check_output(['git','status','--short'],text=True))
