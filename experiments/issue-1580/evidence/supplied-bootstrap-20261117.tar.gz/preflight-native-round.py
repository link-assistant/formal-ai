from pathlib import Path
import datetime, gzip, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out = root / 'experiments/issue-1580/evidence/ci/checkout-7e89122c' / ('preflight-' + stamp)
out.mkdir()
def command(argv):
    run = subprocess.run(argv, cwd=root, capture_output=True, text=True)
    assert run.returncode == 0, (argv, run.stderr)
    return run.stdout.strip()
def capture(name, argv):
    raw = command(argv).encode()
    (out / (name + '.json.gz')).write_bytes(gzip.compress(raw, mtime=0))
    value = json.loads(raw)
    print('CAPTURE', name, len(raw), hashlib.sha256(raw).hexdigest())
    return value

assert command(['git', 'branch', '--show-current']) == 'issue-1580-8d61a32a61e1'
assert command(['git', 'diff', '--cached', '--name-only']) == ''
print('FETCH', command(['git', 'fetch', 'origin', 'main']))
head = command(['git', 'rev-parse', 'HEAD'])
main = command(['git', 'rev-parse', 'origin/main'])
assert main == '015a683197c89e8f74375b097e8dd06a57dcea8f', main
command(['git', 'merge-base', '--is-ancestor', 'origin/main', 'HEAD'])
print('HEAD', head, 'MERGED MAIN', main)
old = root / 'experiments/issue-1580/evidence/ci/checkout-7e89122c/refresh-20261118T014101Z'
for name, endpoint in [
    ('issue-comments', 'issues/1580/comments'),
    ('pull-request-comments', 'issues/1581/comments'),
    ('pull-request-inline-comments', 'pulls/1581/comments'),
    ('pull-request-reviews', 'pulls/1581/reviews'),
]:
    values = capture(name, ['gh', 'api', 'repos/link-assistant/formal-ai/' + endpoint, '--paginate'])
    prior = json.loads(gzip.decompress((old / (name + '.json.gz')).read_bytes()))
    previous = {row['id']: row for row in prior}
    current = {row['id']: row for row in values}
    changed = [row for identifier, row in current.items() if previous.get(identifier) != row]
    removed = sorted(set(previous) - set(current))
    print('FEEDBACK', name, 'total', len(values), 'changed', len(changed), 'removed', removed)
    for row in changed:
        print('CHANGED BODY', row.get('html_url'), row.get('body'))
    assert not changed and not removed, 'Read fresh changed feedback before publication'
published = '7e89122c9d030b3af5eec2d346141bba3ff3fdab'
pages = capture('published-head-runs', ['gh', 'api', 'repos/link-assistant/formal-ai/actions/runs?branch=issue-1580-8d61a32a61e1&head_sha=' + published + '&per_page=100', '--paginate', '--slurp'])
runs = [row for page in pages for row in page['workflow_runs']]
assert len(runs) == 23 and all(row['status'] == 'completed' and row['conclusion'] == 'success' and row['head_sha'] == published for row in runs)
for state in ['in_progress', 'queued']:
    values = capture(state, ['gh', 'run', 'list', '--repo', 'link-assistant/formal-ai', '--branch', 'issue-1580-8d61a32a61e1', '--status', state, '--limit', '100', '--json', 'databaseId,workflowName,headSha'])
    assert values == [], values
pr = capture('pull-request', ['gh', 'pr', 'view', '1581', '--repo', 'link-assistant/formal-ai', '--json', 'url,isDraft,headRefOid,headRefName,title,body'])
assert pr['isDraft'] and pr['headRefName'] == 'issue-1580-8d61a32a61e1' and pr['headRefOid'] == published
print('23/23 SUCCESS; NO ACTIVE/QUEUED RUNS; FEEDBACK UNCHANGED; PR STILL DRAFT')
status = command(['git', 'status', '--porcelain=v1', '--untracked-files=all'])
print('WORKING TREE', status)
(out / 'outcome.json').write_text(json.dumps({'checkedAt': stamp, 'head': head, 'main': main, 'publishedHead': published, 'passingWorkflows': 23, 'feedbackUnchanged': True, 'noActiveRuns': True, 'nativeBehaviorVerified': False}, indent=2) + '\n')
print('PREFLIGHT DIRECTORY', out.relative_to(root))
