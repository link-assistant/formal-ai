import gzip,json
from pathlib import Path
base=Path('experiments/issue-1580/evidence/checks/main-merge-015a6831/focused')
path=base/'results.json'
if not path.exists():print('No completed checks yet');raise SystemExit(0)
rows=json.loads(path.read_text())
print(json.dumps({'completed':len(rows),'failed':[r['label'] for r in rows if r['exitCode']],'latest':rows[-1]['label']}))
for row in rows:
 print(row['label'],row['exitCode'],row['durationSeconds'],'seconds',row['rawLines'],'log lines')
 if row['exitCode']:
  raw=gzip.decompress(Path(row['logArchive']).read_bytes()).decode();lines=raw.splitlines()
  print('\n'.join(f'{i+1}: {line}' for i,line in enumerate(lines[:100])))
print('worker state',Path('/proc/740209/stat').read_text().split(')')[1].split()[0] if Path('/proc/740209/stat').exists() else 'exited')
