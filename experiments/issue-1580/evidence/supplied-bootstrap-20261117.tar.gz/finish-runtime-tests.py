from pathlib import Path
p=Path('rust/tests/unit/meta_executor_parity.rs')
with p.open('a') as f:
    f.write('''
#[test]
fn validated_prime_candidates_keep_their_intent_in_every_response_language() {
    let solver = formal_ai::UniversalSolver::new(formal_ai::SolverConfig {
        offline: true,
        temperature: 0.0,
        ..formal_ai::SolverConfig::default()
    });
    for (prompt, expected) in [
        ("Choose a prime between 8 and 12", "11"),
        ("Выбери простое число от 24 до 30", "29"),
        ("Elige un número primo entre 32 y 40", "37"),
        ("选择8到12之间的质数", "11"),
        ("0 और 3 के बीच अभाज्य संख्या चुनो", "2"),
    ] {
        let answer = solver.solve(prompt);
        assert_eq!(answer.content, expected, "{prompt}");
        assert_eq!(answer.intent, "number_property_prime", "{prompt}");
    }
}
''')
