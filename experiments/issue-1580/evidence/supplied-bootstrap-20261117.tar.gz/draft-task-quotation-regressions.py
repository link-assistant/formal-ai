from pathlib import Path

helper = Path('rust/tests/web/helpers/issue-1550-meta-executor-cases.mjs')
text = helper.read_text()
anchor = '/** Every case of the fixture, in order. */'
assert text.count(anchor) == 1
addition = r'''/** Literal quotation controls shared with the native fixture reader. */
export const QUOTATION_CASES = [
  ['ascii-double-aggregation', 'Count "salt and pepper" and report the size', 'aggregation', ['Count "salt and pepper"', 'report the size']],
  ['ascii-double-sequence', 'Read "first then second" then report the length', 'sequence', ['Read "first then second"', 'report the length']],
  ['ascii-single-aggregation', "Count 'salt and pepper' and report the size", 'aggregation', ["Count 'salt and pepper'", 'report the size']],
  ['unquoted-contraction', "Don't count and report the size", 'aggregation', ["Don't count", 'report the size']],
  ['quoted-contraction', "Read 'Don't split and join' and report the length", 'aggregation', ["Read 'Don't split and join'", 'report the length']],
  ['plural-possessive', "Count the dogs' coats and report the size", 'aggregation', ["Count the dogs' coats", 'report the size']],
  ['escaped-double-quote', 'Read "a \\"quote and join\\" stays" and report the length', 'aggregation', ['Read "a \\"quote and join\\" stays"', 'report the length']],
];

'''
text = text.replace(anchor, addition + anchor)
end = "\n];\n\n/** The table host of one case. */"
assert text.count(end) == 1
text = text.replace(end, r'''
  ...QUOTATION_CASES.map(([name, text, , parts]) => ({
    name,
    text,
    language: 'en',
    answers: Object.fromEntries(parts.map((part, index) => [part, answered(String(index + 1))])),
    cached: {},
    withheld: [],
    bounds: {},
  })),
];

/** The table host of one case. */''')
helper.write_text(text)
test = Path('rust/tests/web/issue-1550-meta-executor.test.mjs')
text = test.read_text()
assert 'let quotationCases;' not in text
text = text.replace('let CASES;\n', 'let CASES;\nlet quotationCases;\n')
text = text.replace('({ CASES, replayCase } =', '({ CASES, QUOTATION_CASES: quotationCases, replayCase } =')
text += r'''
test('ASCII quoted connectives stay in their task while apostrophes and escaped quotes keep their boundaries', () => {
  for (const [name, text, relation, parts] of quotationCases) {
    assert.deepEqual(executor.splitRequest(text, 'en'), { relation, parts }, name);
    const expected = named(name).expected;
    assert.equal(expected.shape, `${relation}(leaf,leaf)`, name);
    assert.deepEqual(expected.leaves, parts, name);
    assert.equal(expected.status, 'resolved', name);
  }
});
'''
test.write_text(text)
print('Drafted seven shared quotation controls and one focused assertion')
