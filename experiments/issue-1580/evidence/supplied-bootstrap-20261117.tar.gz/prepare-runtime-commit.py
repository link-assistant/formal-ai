from pathlib import Path
import json

p=Path('rust/src/solver_synthesis.rs')
s=p.read_text()
start=s.index('\n#[cfg(test)]\nmod parent_tests {')
body=s[start:].split('mod parent_tests {\n',1)[1].rsplit('\n}',1)[0]
fixture=Path('rust/tests/fixtures/synthesis-parent-tests.rs')
fixture.write_text('\n'.join(line[4:] if line.startswith('    ') else line for line in body.splitlines())+'\n')
p.write_text(s[:start]+'\n#[cfg(test)]\n#[path = "../tests/fixtures/synthesis-parent-tests.rs"]\nmod parent_tests;\n')

p=Path('rust/src/solver.rs')
s=p.read_text().replace('.filter(|_| matches!(rule, SelectedRule::Unknown))','.filter(|_| matches!(&rule, SelectedRule::Unknown))')
p.write_text(s)

p=Path('data/benchmarks/fast-pull-request-javascript-tests.json')
value=json.loads(p.read_text())
new='rust/tests/web/issue-1580-production-composition.test.mjs'
assert new not in value['files']
value['files'].append(new)
p.write_text(json.dumps(value,indent=2)+'\n')

Path('changelog.d/20261117_120000_issue-1580-ci-regressions.md').write_text('''---
bump: patch
---

### Fixed

- Preserve concrete output contracts when the recursive procedure considers joining child answers, and retain the intent of validated prime-number candidates.
- Check only consumed child answers when evaluating source operands, and recognize full-width terminal punctuation in concept queries across runtimes.
- Correct CI regression fixtures for source observations, validation events, generated workflow retirement and supported pull-request handoffs.
- Bound CI downloads and duration collection, avoid overlapping Hive drafts, and distinguish image transfer time from solver time.
''')

with Path('data/meta/main-only-regressions.lino').open('a') as f:
    f.write('''main-run 43815999666
  javascript-twin
    regression concrete-output-composition
      introduced-by "PR #1576, recursive production entry"
      failed "generic composition replaced a concrete source-output intent with joined refusal text"
      check rust/tests/web/issue-1580-production-composition.test.mjs
      marker "production composition preserves concrete output obligations"
    regression concept-full-width-punctuation
      introduced-by "terminal query normalization"
      failed "compound_courtesy_and_question_are_answered_in_source_order: Redis是什么？ remained unknown"
      check rust/tests/web/issue-1580-production-composition.test.mjs
      marker "concept queries trim terminal punctuation"
''')

# Keep API metadata readable without thousands of lines of repeated job steps.
# Full downloaded workflow logs are already retained as gzip with their hashes.
for p in Path('experiments/issue-1580/evidence/ci').glob('*.json'):
    value=json.loads(p.read_text())
    if len(p.read_text().splitlines())>1500:
        p.write_text(json.dumps(value,separators=(',',':'))+'\n')
