from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
base=Path('experiments/issue-1580/evidence/checks/native-test-admission')
review=json.loads((base/'manual-review.json').read_text())
assert review['localVerified']
for name,digest in review['sources'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
patch=subprocess.check_output(['git','diff','--',*review['sources']])
print(patch.decode())
print(Path('changelog.d/1580-native-regressions.md').read_text())
(base/'source-review.diff.gz').write_bytes(gzip.compress(patch,mtime=0))
review['retryLogLiterallyRead']=True
review['sourcePatchLiterallyRead']=False
(base/'manual-review.json').write_text(json.dumps(review,indent=2)+'\n')
subprocess.run(['git','add','--',*review['sources']],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','Select isolated native regression inputs and replay synthesis contracts'],check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
(base/'local-source-commit.json').write_text(json.dumps({'head':head,'observedAt':datetime.now(timezone.utc).isoformat(),'pushed':False,'nativeExecution':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps({'head':head,'pushed':False}))
