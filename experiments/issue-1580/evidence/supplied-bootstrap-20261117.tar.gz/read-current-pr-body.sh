set -eu
gh pr view 1581 --repo link-assistant/formal-ai --json title,body,isDraft,state,headRefOid,url > /tmp/issue-1580-research/pr-before-eighth.json
cat /tmp/issue-1580-research/pr-before-eighth.json
