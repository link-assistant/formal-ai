from pathlib import Path

root=Path('/tmp/gh-issue-solver-1794900398048')
path=root/'rust/tests/web/worker-unknown-language.test.mjs'
text=path.read_text()
text=text.replace('import { WorkerHost } from "../../../js/server/worker-host.mjs";', 'import { WorkerHost, createWorkerContext, evaluate } from "../../../js/server/worker-host.mjs";')
old='''  const answer = await host.solve(prompts[1]);'''
new='''  const worker = createWorkerContext();
  await evaluate(worker, "loadSeed()");
  worker.fetch = async () => { throw new Error("Network disabled for the Spanish sibling regression"); };
  const definition = await worker.solve(prompts[0], [], {}, {}, [], {});
  assert.equal(definition.intent, "web_search");
  const answer = await worker.solve(prompts[1], [], {}, {}, [], {});'''
assert text.count(old)==1
text=text.replace(old,new)
text+='''
test("meaning hydration includes registered seed names and keeps extension fixtures isolated", { timeout: 15000 }, async () => {
  const worker = createWorkerContext();
  await evaluate(worker, "loadSeed()");
  const meaning = (opener) => `meanings
  fixture_request_opener
    defined-by inquiry
    role term_information_request_opener
    lexeme en "${opener} …"`;
  worker.__meaningFixtures = {
    "/fixtures/learned-request-openers.lino": meaning("registered inquiry"),
    "/fixtures/meanings-fixture.lino": meaning("extension inquiry"),
    "/fixtures/notes.lino": meaning("unregistered inquiry"),
    "/fixtures/learned-request-openers.json": meaning("wrong extension inquiry"),
  };
  evaluate(worker, "hydrateLinoSeedText(__meaningFixtures)");
  const query = (prompt) => {
    worker.__meaningPrompt = prompt;
    return evaluate(worker, "extractTermInformationRequest(__meaningPrompt, normalizePrompt(__meaningPrompt))");
  };
  assert.equal(query("registered inquiry a held-out subject"), "a held-out subject");
  assert.equal(query("extension inquiry a held-out subject"), "a held-out subject");
  assert.equal(query("unregistered inquiry a held-out subject"), "");
  assert.equal(query("wrong extension inquiry a held-out subject"), "");
});

test("rehydration replaces warmed search markers with the new meaning seed", { timeout: 15000 }, async () => {
  const worker = createWorkerContext();
  await evaluate(worker, "loadSeed()");
  const meaning = (opener) => `meanings
  fixture_request_opener
    defined-by inquiry
    role term_information_request_opener
    lexeme en "${opener} …"`;
  const query = (prompt) => {
    worker.__meaningPrompt = prompt;
    return evaluate(worker, "extractTermInformationRequest(__meaningPrompt, normalizePrompt(__meaningPrompt))");
  };
  worker.__meaningFixtures = { "meanings-fixture.lino": meaning("earlier inquiry") };
  evaluate(worker, "hydrateLinoSeedText(__meaningFixtures)");
  assert.equal(query("earlier inquiry a held-out subject"), "a held-out subject");
  worker.__meaningFixtures = { "meanings-fixture.lino": meaning("replacement inquiry") };
  evaluate(worker, "hydrateLinoSeedText(__meaningFixtures)");
  assert.equal(query("replacement inquiry a held-out subject"), "a held-out subject");
  assert.equal(query("earlier inquiry a held-out subject"), "");
});
'''
assert 'meaning hydration includes registered seed names' not in path.read_text()
path.write_text(text)
print('Drafted three browser regression cases; production code unchanged.')
