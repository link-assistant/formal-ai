from pathlib import Path

Path('rust/tests/web/issue-1580-production-composition.test.mjs').write_text('''// A generic prose join cannot satisfy a concrete program-output contract.
import assert from 'node:assert/strict';
import { before, test } from 'node:test';
import { WorkerHost } from '../../../js/server/worker-host.mjs';
import { installNodeHost } from '../../../js/agentic/node-host.mjs';

let executor;
before(async () => {
  await installNodeHost(new WorkerHost());
  executor = await import('../../../js/agentic/crate/meta_executor.mjs');
});

test('production composition preserves concrete output obligations, including skill gaps', async () => {
  for (const intent of ['write_program_skill_gap', 'write_program_unspecified', 'write_program']) {
    const root = { intent, content: 'The source implementation is unavailable.', confidence: 0 };
    const { answer, run } = await executor.solveAnswer(
      { text: 'Create source and import assert', language: 'en' }, root,
      async () => ({ intent: 'read_file', content: 'This surface needs a file-reading tool.', confidence: 1 }),
    );
    assert.equal(answer.intent, intent);
    assert.equal(answer.content, root.content);
    assert.notEqual(run.outcome.candidate?.method, 'composition');
    assert.ok(run.events.some(({ kind }) => kind === 'meta_exec:compose'));
  }
});

test('production still composes independently answered tasks for an untyped unresolved root', async () => {
  const { answer, run } = await executor.solveAnswer(
    { text: 'First task and second task', language: 'en' },
    { intent: 'unknown', content: '', confidence: 0 },
    async (text) => ({ intent: 'answered', content: text.startsWith('First') ? 'one' : 'two', confidence: 1 }),
  );
  assert.equal(run.outcome.candidate.method, 'composition');
  assert.match(answer.content, /one[\\s\\S]*two/u);
});
''')
p=Path('rust/tests/web/worker-candidate-validation.test.mjs')
s=p.read_text().replace('assert.ok(answer.content.includes("17"));', 'assert.equal(answer.content, "17");\n  assert.equal(answer.intent, "number_property_prime");')
p.write_text(s)
