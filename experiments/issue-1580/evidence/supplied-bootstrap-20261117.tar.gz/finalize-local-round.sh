set -eu
python3 /tmp/issue-1580-research/document-current-round.py
python3 - <<'PY'
from pathlib import Path
p=Path('experiments/issue-1580/compare-template-trees.mjs')
s=p.read_text().replace('     //','  //').replace('        // outputs,','  // outputs,').replace('        // The remaining','  // The remaining')
p.write_text(s)
PY
python3 experiments/issue-1580/archive-evidence.py
git diff --check
git diff --numstat
git status --short
