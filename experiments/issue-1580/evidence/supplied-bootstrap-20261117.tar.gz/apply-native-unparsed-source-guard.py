from pathlib import Path

root=Path('/tmp/gh-issue-solver-1794900398048')
path=root/'rust/src/solver_unknown_reasoning.rs'
text=path.read_text()
old='''    let sense = senses
        .iter()
        .enumerate()'''
new='''    // A word definition cannot answer a sentence whose grammar is unsupported.
    // Keep the consult evidence, but preserve the whole unresolved request.
    // A bare term is itself a lookup, so it still accepts attributed senses.
    let language_supported = seed::supported_languages()
        .iter()
        .any(|supported| supported == language.slug());
    if !language_supported && !is_unresolved_bare_term_prompt(prompt, prompt) {
        if !senses.is_empty() {
            log.append(
                "reasoning:gather_result",
                "external_source:no_verified_answer".to_owned(),
            );
        }
        return None;
    }
    let sense = senses
        .iter()
        .enumerate()'''
assert text.count(old)==1
path.write_text(text.replace(old,new))
print('Unparsed-language sentences no longer promote a retrieved word gloss to a verified full answer; bare-term lookups remain available.')
