from pathlib import Path
import gzip
import hashlib
import json

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research/source-composition-probe')
assert json.loads((scratch / 'outcome.json').read_text())['complete']
base = root / 'experiments/issue-1580/evidence/checks/source-operand-replays'
base.mkdir(exist_ok=False)
inventory = []
for name in ('outcome.json', 'worker.log', 'responses.jsonl', 'stderr.log'):
    raw = (scratch / name).read_bytes()
    packed = gzip.compress(raw, mtime=0)
    (base / (name + '.gz')).write_bytes(packed)
    inventory.append({'name': name, 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest()})
(base / 'probe-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
path = root / 'rust/tests/web/issue-1580-production-composition.test.mjs'
path.write_text(path.read_text() + '''
test('remainder-sale composition recomputes changed source operands', { timeout: 30000 }, async () => {
  for (const [total, price, expected] of [[24, 3, 36], [30, 4, 72]]) {
    const prompt = `Marisol's hens lay ${total} eggs per day. She eats five for breakfast every morning and bakes cakes for her neighbors every day with seven. She sells the remainder at the market daily for $${price} per fresh egg. How much in dollars does she make every day at the market?`;
    const response = await host.solve(prompt);
    assert.equal(response.intent, 'arithmetic_word_problem', response.content);
    assert.ok(response.content.endsWith(`gives ${expected}.`), response.content);
    assert.ok(response.evidence.includes(`composition:remainder:total=${total} consumed=12 remainder=${total - 12} price=${price}`), JSON.stringify(response.evidence));
    assert.ok(response.evidence.includes(`composition:evaluation:(${total} - 12) * ${price} = ${expected}`), JSON.stringify(response.evidence));
  }
});
''')
path = root / 'rust/tests/unit/meta_executor_parity.rs'
path.write_text(path.read_text() + '''
// Replay the main-only synthesis contracts through the real offline solver.
#[test]
fn production_remainder_sale_recomputes_source_operands() {
    let solver = formal_ai::UniversalSolver::new(formal_ai::SolverConfig {
        offline: true,
        execution_surface: formal_ai::ExecutionSurface::RustLibrary,
        temperature: 0.0,
        ..formal_ai::SolverConfig::default()
    });
    for (total, price, expected) in [(24, 3, 36), (30, 4, 72)] {
        let prompt = format!("Marisol's hens lay {total} eggs per day. She eats five for breakfast every morning and bakes cakes for her neighbors every day with seven. She sells the remainder at the market daily for ${price} per fresh egg. How much in dollars does she make every day at the market?");
        let response = solver.solve(&prompt);
        assert_eq!(response.intent, "arithmetic_word_problem", "{}", response.answer);
        assert_eq!(response.answer, expected.to_string(), "{prompt}");
        assert!(response.evidence_links.iter().any(|link| link.starts_with("composition:remainder:")), "{prompt}");
        let evaluation = format!("({total} - 12) * {price} = {expected}");
        assert!(response.evidence_links.iter().any(|link| link.starts_with("composition:evaluation:") && link.ends_with(&evaluation)), "{prompt}: {:?}", response.evidence_links);
        assert!(response.links_notation.contains(&evaluation), "{prompt}");
    }
}

#[test]
fn production_object_count_replays_membership_sources() {
    let solver = formal_ai::UniversalSolver::new(formal_ai::SolverConfig {
        offline: true,
        execution_surface: formal_ai::ExecutionSurface::RustLibrary,
        temperature: 0.0,
        ..formal_ai::SolverConfig::default()
    });
    let prompt = "I have a clarinet, a violin, and a flute. How many musical instruments do I have?";
    let response = solver.solve(prompt);
    assert_eq!(response.intent, "verifiable_task", "{}", response.answer);
    assert_eq!(response.answer, "3", "{prompt}");
    assert!(response.evidence_links.iter().any(|link| link.starts_with("verifiable_task:executed:")), "{:?}", response.evidence_links);
    assert!(response.links_notation.contains("verifiable_task:membership_source"), "{}", response.links_notation);
}
''')
print('Drafted two native replay tests (three prompts) and one JavaScript replay test (two prompts).')
print('Native execution pending hosted CI. Probe payloads retained:', len(inventory))
