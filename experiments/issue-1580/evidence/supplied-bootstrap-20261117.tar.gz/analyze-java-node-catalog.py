from pathlib import Path
from collections import Counter, defaultdict
from datetime import date, datetime, timezone
import hashlib
import json
import re
import subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
source = Path('/tmp/issue-1580-research/templates/java-complete')
relative = 'dev/log/issues/24/pulls/25/sources/node.json'
raw = (source / relative).read_bytes()
inventory = json.loads(Path('/tmp/issue-1580-research/templates/java-complete-inventory.json').read_text())
expected = next(row for row in inventory if row['path'] == relative)
assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == expected['gitBlob']
data = json.loads(raw)
assert isinstance(data, list)
versions = set()
major_counts = Counter()
key_counts = Counter()
field_types = defaultdict(Counter)
platforms = Counter()
lts = Counter()
security = Counter()
dates = []
prereleases = []
for row in data:
    assert isinstance(row, dict)
    assert {'version', 'date', 'files', 'lts', 'security'} <= row.keys()
    version = row['version']
    match = re.fullmatch(r'v(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?', version)
    assert match and version not in versions, version
    versions.add(version)
    if match[4]:
        prereleases.append(version)
    major_counts[int(match[1])] += 1
    dates.append(date.fromisoformat(row['date']))
    assert isinstance(row['files'], list) and all(isinstance(item, str) for item in row['files'])
    assert isinstance(row['security'], bool)
    assert row['lts'] is False or isinstance(row['lts'], str)
    platforms.update(row['files'])
    lts[str(row['lts'])] += 1
    security[str(row['security'])] += 1
    key_counts.update(row.keys())
    for key, value in row.items():
        field_types[key][type(value).__name__] += 1
result = subprocess.run(['rg', '-n', 'node.json|nodejs.org/dist/index', str(source / '.github'), str(source / 'scripts')], capture_output=True, text=True)
assert result.returncode in (0, 1)
report = {
    'observedAt': datetime.now(timezone.utc).isoformat(),
    'pinnedTemplateHead': 'dd803a2d9fa5b3a992b435acce73162274fb9e8b',
    'path': relative,
    'gitBlob': expected['gitBlob'],
    'sha256': hashlib.sha256(raw).hexdigest(),
    'rawLines': len(raw.splitlines()),
    'recordsParsedAndValidated': len(data),
    'prereleaseVersions': prereleases,
    'wholeRawPayloadLiterallyRead': False,
    'literalSourceLinesRead': [1, 129],
    'dateRange': [min(dates).isoformat(), max(dates).isoformat()],
    'majorVersionCounts': dict(sorted(major_counts.items(), reverse=True)),
    'fieldPresenceCounts': dict(sorted(key_counts.items())),
    'fieldTypeCounts': {key: dict(value) for key, value in sorted(field_types.items())},
    'artifactCounts': dict(sorted(platforms.items())),
    'ltsCounts': dict(sorted(lts.items())),
    'securityCounts': dict(security),
    'activeSourceReferences': result.stdout.splitlines(),
    'decisions': [
        'This is a retained release registry response, not executable CI policy or a current dependency selection.',
        'Every release record is parsed and validated for identity, date, artifact list, LTS state and security flag; optional dependency-field absence is counted rather than silently treated as a known current version.',
        'Preserve pinned supported runtime labels and actual fetched currency checks in Formal AI. Historical release presence and security flags do not prove compatibility, vulnerability status or current runner support.',
        'This structured inspection supplements the existing literal review through line 129; it does not relabel the remaining raw pages as literally read or close the complete repository comparison.',
    ],
    'nativeExecutionClaimed': False,
    'completeRepositorySemanticReview': False,
    'independentAuthorshipCredit': 0,
}
target = root / 'experiments/issue-1580/evidence/checks/source-operand-replays/java-node-catalog-structure.json'
target.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
