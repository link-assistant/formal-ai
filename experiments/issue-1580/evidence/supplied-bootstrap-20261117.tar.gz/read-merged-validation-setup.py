from pathlib import Path
import subprocess
for name in ['run-merged-client-all-gates.py', 'check-final-client-output-batch.py']:
    print('FILE', name)
    print((Path('/tmp/issue-1580-research') / name).read_text())
for args in [['git','status','--short'], ['git','branch','--show-current']]:
    print(subprocess.check_output(args,text=True))
