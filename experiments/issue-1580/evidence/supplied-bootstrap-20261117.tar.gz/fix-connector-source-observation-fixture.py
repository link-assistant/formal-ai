from pathlib import Path
p=Path('rust/tests/unit/issue_1133_hive_mind_three_runs/extended.rs')
source=p.read_text()
before='''    let tools = ["write", "bash", "mcp__codex_apps__github_fetch"];
    let calls = calls(plan_chat_step(&messages, tools.as_slice()));
    assert_eq!(calls[0].tool, "write", "{calls:?}");
    assert!(calls[0].arguments.contains("fn main()"), "{calls:?}");'''
after='''    let tools = ["write", "bash", "mcp__codex_apps__github_fetch"];
    let source_calls = calls(plan_chat_step(&messages, tools.as_slice()));
    let source_call = &source_calls[0];
    assert_eq!(source_call.tool, "bash", "{source_calls:?}");
    let source_command = command_of(source_call);
    assert!(source_command.contains("workspace-source-v1"), "{source_command}");
    assert!(source_command.contains("main.rs"), "{source_command}");
    // Observe the real workspace before the planner decides whether to create
    // or edit the entry point; the connector envelope above stays unchanged.
    let mut workspace = crate::observed_plan_tools::ToolWorkspace::new(
        "issue-1133-connector-source-observation",
    );
    let observed = workspace.execute("c1", source_call);
    record(&mut messages, "c1", source_call, &source_call.arguments, "");
    *messages.last_mut().expect("recorded source observation") = observed;
    let calls = calls(plan_chat_step(&messages, tools.as_slice()));
    assert_eq!(calls[0].tool, "write", "{calls:?}");
    assert!(calls[0].arguments.contains("fn main()"), "{calls:?}");'''
assert source.count(before)==1
p.write_text(source.replace(before,after))
print('Preserved original structured connector receipt and final write assertions; added actual source observation before write.')
