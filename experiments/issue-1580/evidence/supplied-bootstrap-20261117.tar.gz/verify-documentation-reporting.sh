set -eu
python3 /tmp/issue-1580-research/complete-documentation-reporting.py
timeout 600 node --test --test-concurrency=1 rust/tests/web/documentation-only-ci-policy.test.mjs > /tmp/issue-1580-research/documentation-reporting.log 2>&1
tail -n 35 /tmp/issue-1580-research/documentation-reporting.log
python3 /tmp/issue-1580-research/inspect-head-ci.py
