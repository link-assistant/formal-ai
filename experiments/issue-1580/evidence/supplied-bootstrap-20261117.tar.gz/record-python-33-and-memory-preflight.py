from pathlib import Path
import collections
import hashlib
import json
import subprocess

root=Path("/tmp/issue-1580-research/templates/python-complete")
path=Path("docs/case-studies/issue-1580/templates/python-partial-semantic-review.json")
review=json.loads(path.read_text());assert review["activeReadLines"]==13055
inventory=json.loads(Path("/tmp/issue-1580-research/python-active-source-inventory.json").read_text())
active={row["path"]:row for row in inventory["active"]}
deferred={".github/actions/artifact/dist/835.index.mjs",".github/actions/artifact/dist/index.mjs",".github/actions/artifact/package-lock.json","uv.lock"}
selected=[(row["path"],n) for row in inventory["active"] if row["path"] not in deferred for n in range(1,row["lines"]+1)]
ranges=collections.defaultdict(set)
for row in review["files"]:
    for first,last in row["readRanges"]:ranges[row["path"]].update(range(first,last+1))
for name,n in selected[:13200]:ranges[name].add(n)
decisions={
 "scripts/validate_changeset.py":"Read all 240 lines: verified commit/merge-base comparison, NUL-delimited source paths, exact-rename exclusion for added fragments, source layout prefix, visible category/content checks and fatal Git/read/ref errors. Markdown/examples/experiments and authenticated Dependabot authors are explicitly exempt. No Git fixture execution or new acceptance/defect claim is made by this source reading.",
 "src/my_package/__init__.py":"Read all 47 lines: example add/multiply functions, asyncio delay, version string and public export list. This is the template's replacement placeholder; no package installation or runtime benchmark is claimed.",
 "tests/__init__.py":"Read the complete one-line test package marker; no runtime behavior is implied.",
 "tests/artifact.test.mjs":"Read only line 1 (assert import). The artifact action behavior, fixtures and remaining assertions are unread; no test execution or coverage claim is made.",
}
for row in review["files"]:
    assert hashlib.sha256((root/row["path"]).read_bytes()).hexdigest()==row["sha256"]
    if row["path"] not in active:continue
    numbers=sorted(ranges[row["path"]]);merged=[]
    for n in numbers:
        if merged and merged[-1][1]+1==n:merged[-1][1]=n
        else:merged.append([n,n])
    row["readRanges"]=merged
    row["reviewStatus"]="active-source-fully-read" if len(numbers)==row["lines"] else "active-source-partially-read" if numbers else "active-source-unread"
    if row["path"] in decisions:row["decision"]=decisions[row["path"]]
counts=collections.Counter(row["reviewStatus"] for row in review["files"])
review["counts"]={key:counts[key] for key in review["counts"]}
review["activeReadLines"]=sum(len(ranges[name]) for name in active);assert review["activeReadLines"]==13240
review["readMethod"]=review["readMethod"].replace("pages 1-31","pages 1-33")
header={k:v for k,v in review.items() if k!="files"}
path.write_text(json.dumps(header,indent=2)[:-2]+',\n  "files": [\n'+',\n'.join("    "+json.dumps(row,ensure_ascii=False,separators=(",",":")) for row in review["files"])+'\n  ]\n}\n')
old="The Python review now fully reads 155 active files plus one partial file (13,055/44,284 active lines), through corrected pages 1-31 and separately read release/helper tests. The 47 unread active files"
new=f'The Python review now fully reads {counts["active-source-fully-read"]} active files plus one partial file (13,240/44,284 active lines), through corrected pages 1-33 and separately read release/helper tests. The {counts["active-source-unread"]} unread active files'
for name in ["docs/case-studies/issue-1580/README.md","docs/case-studies/issue-1580/templates/README.md","experiments/issue-1580/work-plan.md"]:
    p=Path(name);text=p.read_text();assert text.count(old)==1;p.write_text(text.replace(old,new))
directory=Path("experiments/issue-1580/evidence/checks/generated-header-memory")
cache=json.loads((directory/"clean-file-cache.json").read_text())
assert cache["gitObjects"]["after"]["available"]>1024*1024*1024
with (directory/"memory-README.md").open("a") as stream:
    stream.write("\nA final gate attempt refused to start when measured container headroom was only 299,167,744 bytes; no test command was launched by that attempt. Best-effort POSIX_FADV_DONTNEED advice released clean cached pages for this task's evidence and Git objects, without changing file contents or invoking a global cache purge. The recorded Git-object pass increases measured headroom to 1,341,624,320 bytes. The final run retains its 512 MiB minimum-headroom check rather than bypassing it. This resource observation is not a passing gate result.\n")
for command in [["git","diff","--check"],["git","add","--","docs/case-studies/issue-1580","experiments/issue-1580/work-plan.md",str(directory/"clean-file-cache.json"),str(directory/"memory-README.md")],["git","diff","--cached","--check"]]:subprocess.run(command,check=True)
subprocess.run(["git","commit","-m","docs: record bounded validation memory and Python review progress"],check=True,stdout=subprocess.PIPE)
print(json.dumps({"counts":review["counts"],"activeReadLines":review["activeReadLines"],"nextPage":34}))
print("HEAD",subprocess.run(["git","rev-parse","HEAD"],capture_output=True,text=True,check=True).stdout.strip())
assert not subprocess.run(["git","status","--porcelain"],capture_output=True,text=True,check=True).stdout.strip()
