set -eu
sed -n '98,150p' /tmp/issue-1580-research/templates/go-complete/scripts/detect-code-changes.mjs
sed -n '1,160p' /tmp/issue-1580-research/templates/go-complete/scripts/ci/check-pipeline-status.mjs
sed -n '1,150p' experiments/issue-1580/template-download-retry.test.mjs
sed -n '1,160p' experiments/issue-1580/compare-template-trees.mjs
cat /tmp/issue-1580-research/templates/go-complete/LICENSE
