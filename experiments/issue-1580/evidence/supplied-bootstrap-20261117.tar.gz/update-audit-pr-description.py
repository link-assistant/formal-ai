from pathlib import Path
import json,subprocess
repo='link-assistant/formal-ai'
def view():return json.loads(subprocess.run(['gh','pr','view','1581','--repo',repo,'--json','body,title,url,isDraft,headRefOid'],capture_output=True,text=True,check=True).stdout)
before=view();assert before['isDraft'] and before['headRefOid']=='1cc2d536ac11e26602cc55a40dffb61716233aa6'
assert before['body']==Path('/tmp/issue-1580-research/pr-python-runtime-body.md').read_text()
body='''Fixes #1580

Failed Git commands could produce successful “no code changed” or empty/subset dependency-audit verdicts, documentation-only PRs could miss required status contexts, and candidate validation could lose the requested operation or concrete-output contract. This draft repairs those observed boundaries and preserves the unresolved issue-wide acceptance criteria below.

- Require successful complete Git comparisons and a successful lockfile inventory before publishing change outputs or starting any JavaScript dependency audit. Preserve full push/PR ranges, legitimate initial trees, successful empty inventories, advisory failures, retry limits and request deadlines. Git selects lockfiles before Bash iteration, avoiding a measured full-tree scan slowdown.
- Emit required contexts for documentation-only PRs without compiling. Preserve source-path authority, existing assertions, default-branch build restrictions and all prior functionality; repair reviewed source fingerprints and the unused native binding.
- Retain candidate intent, consumed-child validity and concrete-output requirements; recognize full-width terminal punctuation. Preserve all 221 witness cases/assertions and unchanged benchmark floors.
- Bound CI downloads and duration collection, avoid overlapping Hive drafts, and distinguish image transfer from solver time. Optional compiler-cache diagnostics preserve command exits and retain at most 64 KiB / 80 lines with URL redaction and fresh workflow-command suspension tokens; they do not establish the historical backend failure cause.
- Preserve complete parsed template workflow context and transitive helper references, including GitHub `$/` self-repository references. Retain full pinned-source reproductions and disposable candidate controls for Go release/Git/pin integrity, Java rejected release commits, C# changeset loss, Python fragment collisions and Python failed audit inventories.
- Provision Python 3.15.2 only on the JavaScript shard that selects the maintained template observations. Missing or old Python fails hosted observations while remaining optional locally; the actual selected file list is reused for execution.

Verification: the new JavaScript audit regression fails before the repair (8 pass, 2 fail) and passes afterward (10/10). The Python inventory candidate fails its preservation test when disabled (2 pass, 1 fail) and passes all three offline-control tests when enabled. The maintained template entrypoint passes all 34 tests locally with no skips. Controls include real Git repositories, failed/partial inventories, empty inventories, space-containing paths, untracked locks, severity forwarding and advisory rejection. Relevant readability, abbreviation, file-size, CI-speed, runner-label and ShellCheck gates pass. The registered dependency gate verifies all eight tracked lockfiles with offline npm/Bun stand-ins; this is not a live advisory result. Initial failures and full before/after logs are retained. Existing policy/candidate/cache checks and Rust formatting remain recorded in the case study; no local Rust compilation, application build, Docker build or release effect was performed.

All 24 workflows passed on published head `e120c05b4`. Its [Layered CI log](https://github.com/link-assistant/formal-ai/actions/runs/44112040276) confirms that all five previously skipped Python cases actually passed, plus the runtime/shard regressions (lines 4931 and 4947–4952). The previous green head's five Python skips are retained as a coverage gap, not acceptance. CI for the new audit repair at `1cc2d536a` is running. Scope-gated pull-request checks do not establish main-only native, benchmark, publication or live-identity acceptance.

All 3,007 template files and 48 workflows are inventoried and hash-verified. Semantic review status:

| Template | Completed source review | Still unread or unverified |
| --- | --- | --- |
| Go | All 42 source blobs with per-file decisions | Runtime/publication acceptance |
| Java | All 62 active files; 207 blobs verified | 145 historical files; runtime/publication acceptance |
| C# | All 158 active files / 18,327 lines; 337 blobs verified | 179 historical files; runtime/publication acceptance |
| Python | 131 fully read active files, one partial; 8,864/44,284 active lines | 71 active files, including both generated bundles and both locks; 126 historical files; full runtime/publication acceptance |
| JavaScript, Rust, PHP, C++ | Full-tree identity/workflow inventories and bounded observations | Complete semantic file/reference review and applicable best-practice integration |

Shared template reports: [Python failed audit inventory #158](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/158), [Python fragment collision #157](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/157), [Python change detection #156](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/156), [C# changeset loss #111](https://github.com/link-foundation/csharp-ai-driven-development-pipeline-template/issues/111), [Java rejected release commit #31](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/31), [Java change detection #30](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/30), [Go manual release #18](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/18), [Go change detection #19](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/19), [Go stale-pin integrity #20](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/20), [PHP #26](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/26), [C++ #35](https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/issues/35). Draft-accounting findings: [Hive Mind #4071](https://github.com/link-assistant/hive-mind/issues/4071), [#4072](https://github.com/link-assistant/hive-mind/issues/4072). Upstream reports and disposable candidate controls do not constitute upstream repairs or complete unmet local criteria.

Still unfinished in this single PR:

- Final-head hosted verification, main-only native failures/fixtures, benchmark floors and the missing general search/arithmetic capabilities.
- Measured native/JavaScript shard headroom and remaining source-size, extension-package and cache-backend warnings.
- Work-item qualification with actual Docker pull diagnostics, and required-status configuration compatible with machine writers.
- Seven complete semantic template reviews, full CI-reference closure and every applicable best-practice change across all eight templates.
- Chrono removal from both direct dependency paths, and live serving/Hive identity plus useful-source delivery ([Hive Mind #3909](https://github.com/link-assistant/hive-mind/issues/3909)). The existing exact-version `blocked-upstream` audit proof retains its stale/missing/unrelated-failure refusal; it is not the dependency migration.

[The case study](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/README.md) maps requirements to complete logs, source identities, negative controls and remaining limits. Supplied scripts, patches and orchestration receive zero autonomous-authorship credit; independently accepted Formal AI reasoning remains 0/20. Keep this PR draft and unmerged until every acceptance criterion is verified.
'''
path=Path('/tmp/issue-1580-research/pr-audit-inventory-body.md');path.write_text(body)
assert view()==before
subprocess.run(['gh','pr','edit','1581','--repo',repo,'--title','Fix CI result integrity, change detection, and candidate validation','--body-file',str(path)],check=True)
after=view();assert after['body']==body and after['isDraft']
Path('/tmp/issue-1580-research/pr-audit-inventory-after.json').write_text(json.dumps(after,indent=2)+'\n')
print(json.dumps({k:after[k] for k in ['url','title','isDraft','headRefOid']}))
