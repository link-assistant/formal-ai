import subprocess
for args in [
 ['rg','-n','fn run_ephemeral|emit_control|control_record|machine_evidence|eprintln!|stderr\(','rust/src/client_integrations','rust/src/client_integrations.rs'],
 ['rg','--files','rust/tests'],
 ['rg','-n','FORMAL_AI_LOG_STDERR|clear_client_environment','rust/tests/integration/with_formal_ai'],
]:
    r=subprocess.run(args,text=True,capture_output=True);print('COMMAND',args,'EXIT',r.returncode)
    if '--files' in args:print('\n'.join(p for p in r.stdout.splitlines() if 'fixture_env' in p))
    else:print(r.stdout,r.stderr)
