from pathlib import Path
import json, subprocess

repo='link-assistant/formal-ai'
base=Path('/tmp/issue-1580-research')
for args,name in [
    (['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','title,body,state,url'],'issue-1580-scope-fresh.json'),
    (['gh','api','repos/'+repo+'/issues/1580/comments','--paginate'],'issue-1580-comments-scope-fresh.json'),
]:
    raw=subprocess.run(args,check=True,text=True,capture_output=True).stdout
    (base/name).write_text(raw)
    parsed=json.loads(raw)
    items=parsed if isinstance(parsed,list) else [parsed]
    for item in items:
        body=item['body'].splitlines()
        assert len(body)<=1500
        print('DOCUMENT',name,item.get('html_url',item.get('url')),item.get('title',''))
        for number,line in enumerate(body,1):print(str(number)+': '+line)
for name in ['record-csharp-partial-review.py','read-csharp-page.py']:
    lines=(base/name).read_text().splitlines()
    assert len(lines)<=1500
    print('SCRIPT',name)
    for number,line in enumerate(lines,1):print(str(number)+': '+line)
