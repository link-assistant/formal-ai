import subprocess
for args in [
 ['git','diff','444575f2','058e9bef','--','data/seed/meanings-text-transform.lino','data/seed'],
 ['rg','-n','196|423|unknown','rust/tests/unit/page_formalization_route.rs'],
 ['rg','-n','quoted passage is answered','rust/tests/web'],
 ['rg','-n','temporary server|stderr|output_log','rust/src/client_integrations/session_files.rs','rust/src/client_integrations/command.rs'],
]:
    r=subprocess.run(args,text=True,capture_output=True);print('COMMAND',args,'EXIT',r.returncode);print(r.stdout,r.stderr)
