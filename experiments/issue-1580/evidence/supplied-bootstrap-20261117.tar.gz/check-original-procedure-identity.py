from pathlib import Path
import subprocess,json,hashlib
name='rust/tests/unit/specification/reasoning_paths_procedures.rs';original='015a683197c89e8f74375b097e8dd06a57dcea8f'
r=subprocess.run(['git','diff',original,'--',name],text=True,capture_output=True,check=True);print(r.stdout)
print('MATCH PUBLISHED HEAD',Path(name).read_bytes()==subprocess.check_output(['git','show','cf22c611:'+name]))
p=Path('experiments/issue-1580/evidence/checks/production-diff-review/manifest.json');d=json.loads(p.read_text())
for row in d['reviewedProductionDiffs']:
 if row.get('path') in ['rust/src/source_walk.rs','.github/workflows/native-type-check.yml','js/worker/formal_ai_worker_source_endpoints.js']:
  print('REVIEW ROW',json.dumps(row,indent=2))
folder=Path('experiments/issue-1580/evidence/checks/native-deadline-and-title')
(folder/'original-procedure-diff.txt').write_text(r.stdout)
(folder/'procedure-identity.json').write_text(json.dumps({'path':name,'originalBase':original,'originalWholeFileUnchanged':not bool(r.stdout),'unchangedFromPublishedHead':True,'currentSha256':hashlib.sha256(Path(name).read_bytes()).hexdigest(),'originalWholeFileReplayCredit':False},indent=2)+'\n')
