#!/bin/sh
set -eu
git add .github/workflows/native-type-check.yml .github/workflows/release.yml scripts/check-required-status-checks.mjs rust/tests/web/default-branch-build-policy.test.mjs changelog.d/20261117_120000_issue-1580-ci-regressions.md experiments/formal_ai_subagent/evidence/specification-delivery-1188/dormant-staged-release/original-release-workflow.yml experiments/formal_ai_subagent/evidence/specification-delivery-1188/dormant-staged-release/stage-source-coverage.json experiments/formal_ai_subagent/evidence/specification-delivery-1188/dormant-staged-release/candidate-output-bindings.json experiments/formal_ai_subagent/evidence/specification-delivery-1188/dormant-staged-release/candidate-release-caller.yml experiments/issue-1580/refresh-staged-caller.mjs
git diff --cached --check
git commit -m 'fix(ci): report required contexts for every pull request'
cp /tmp/issue-1580-research/archive-evidence.py experiments/issue-1580/archive-evidence.py
python3 experiments/issue-1580/archive-evidence.py
PATH=/tmp/issue-1580-research/shellcheck-v0.11.0:$PATH node experiments/formal_ai_subagent/local-gates.mjs > /tmp/issue-1580-research/all-local-gates-second.log 2>&1
