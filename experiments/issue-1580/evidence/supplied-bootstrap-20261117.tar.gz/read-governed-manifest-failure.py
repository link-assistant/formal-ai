from pathlib import Path
import re, subprocess

lines=Path('/tmp/issue-1580-research/layered-44156399182.log').read_text().splitlines()
for number,line in enumerate(lines,1):
    if re.search(r'✖|AssertionError|ℹ fail [1-9]',line):
        payload=line.split('\t',2)[-1]
        print('FAILURE',number,payload[:500])
for first,last in [(8130,8250)]:
    print('FAILURE DETAIL',first,last)
    for number in range(first,last+1):print(f'{number}: '+lines[number-1].split('\t',2)[-1])
for name in ['rust/tests/web/rust-specification-fixture-integrity.test.mjs','rust/tests/web/rust-specification-unicode-identifiers.test.mjs']:
    path=Path(name)
    print('SOURCE',name,'LINES',len(path.read_text().splitlines()))
    print(path.read_text())
result=subprocess.run(['rg','--files','-g','*rust-specification*','-g','*governed*','-g','*witness*'],text=True,capture_output=True)
print('SOURCE CANDIDATES',result.stdout)
