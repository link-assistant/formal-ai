from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
base=Path('experiments/issue-1580/evidence/checks/main-merge-444575f2/publication')
base.mkdir(exist_ok=True)
def run(args):return subprocess.check_output(args,text=True)
branch=run(['git','branch','--show-current']).strip()
assert branch=='issue-1580-8d61a32a61e1'
print('BRANCH',branch,'HEAD',run(['git','rev-parse','HEAD']).strip())
subprocess.run(['git','fetch','origin','main',branch],check=True,capture_output=True,text=True)
main=run(['git','rev-parse','origin/main']).strip()
ancestor=subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD']).returncode
print('CURRENT MAIN',main,'ANCESTOR',ancestor==0)
assert ancestor==0,'Main advanced; merge and revalidate before publishing'
commands=[
 ('latest-branch-runs',['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--limit','5','--json','databaseId,conclusion,createdAt,headSha,status,workflowName']),
 ('in-progress-runs',['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--status','in_progress','--json','databaseId,workflowName,headSha']),
 ('queued-runs',['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--status','queued','--json','databaseId,workflowName,headSha']),
 ('pull-request-state',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','title,body,headRefOid,baseRefName,isDraft,url']),
]
rows=[]
for name,args in commands:
 raw=subprocess.check_output(args);data=json.loads(raw)
 (base/(name+'.json.gz')).write_bytes(gzip.compress(raw,mtime=0))
 rows.append({'kind':name,'rawSha256':hashlib.sha256(raw).hexdigest()})
 if name=='pull-request-state': print(name,json.dumps({k:v for k,v in data.items() if k!='body'}))
 else: print(name,raw.decode())
 if name in ['in-progress-runs','queued-runs']: assert not data,data
(base/'preflight-index.json').write_text(json.dumps({'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main':main,'branch':branch,'records':rows},indent=2)+'\n')
subprocess.run(['git','diff','--check'],check=True)
untracked=run(['git','ls-files','--others','--exclude-standard']).splitlines()
print('UNTRACKED COUNT',len(untracked))
print('SOURCE UNTRACKED','\n'.join(p for p in untracked if not p.startswith('experiments/issue-1580/evidence/')))
print('CHANGELOG',run(['git','ls-files','changelog.d/*1580*']))
