from pathlib import Path
import subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
cargo=root/'rust/Cargo.toml'
text=cargo.read_text()
needle='[[test]]\nname = "openai_forced_functions"\npath = "tests/unit/openai_forced_functions.rs"\n'
assert text.count(needle)==1 and 'name = "meta_executor_parity"' not in text
cargo.write_text(text.replace(needle,needle+'\n[[test]]\nname = "meta_executor_parity"\npath = "tests/unit/meta_executor_parity.rs"\n'))
for name in ['.github/workflows/native-type-check.yml','rust/tests/web/default-branch-build-policy.test.mjs']:
    path=root/name; text=path.read_text()
    old='--test calendar_currency --test openai_forced_functions -- --test-threads=1'
    assert text.count(old)==1
    text=text.replace(old,'--test calendar_currency --test openai_forced_functions --test meta_executor_parity -- --test-threads=1')
    text=text.replace('Verify calendar, currency and forced OpenAI function behavior','Verify isolated native behavior regressions')
    text=text.replace('native calendar, currency and OpenAI behavior','native calendar, currency, OpenAI and executor behavior')
    path.write_text(text)
changelog=root/'changelog.d/20261117_120000_issue-1580-ci-regressions.md'
text=changelog.read_text()
assert 'isolated native executor parity target' not in text
changelog.write_text(text.rstrip()+'\n- Replay all shared executor fixtures, including unverified draft statuses, in the isolated native executor parity target on pull requests.\n')
subprocess.run(['node','--max-old-space-size=256','/tmp/issue-1580-research/refresh-merged-status-witness.mjs'],cwd=root,check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('Added one isolated native target reusing the existing four-test module; no local native build ran.')
