set -eu
sed -n '211,241p' /tmp/issue-1580-research/templates/java-complete/experiments/ci-dependencies.test.mjs
