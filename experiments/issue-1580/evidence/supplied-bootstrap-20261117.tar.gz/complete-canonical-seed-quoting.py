from pathlib import Path
import json,re,subprocess,hashlib,gzip
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/cnl-canonical-data'
rows=[]
for p in sorted((root/'data').rglob('*.lino')):
 before=p.read_text();after=[];changed=[]
 for n,line in enumerate(before.splitlines(),1):
  match=re.fullmatch(r'(\s*)([^#\s]\S*)\s+("(?:\\.|[^"\\])*")(\s*(?:#.*)?)',line)
  if match and '\\"' in match[3]:
   indent,key,raw,tail=match.groups()
   try:value=json.loads(raw)
   except json.JSONDecodeError:raise AssertionError((str(p),n,'non-JSON legacy escaping needs explicit review'))
   encoded=value.replace('\\','\\\\').replace('\n','\\n').replace('\r','\\r').replace('\t','\\t').replace("'","''")
   after.append(indent+key+" '"+encoded+"'"+tail);changed.append(n)
  else:after.append(line)
 if not changed:continue
 after='\n'.join(after)+ ('\n' if before.endswith('\n') else '')
 before_file=base/(p.name+'.before.txt.gz');before_file.write_bytes(gzip.compress(before.encode(),mtime=0));p.write_text(after)
 rows.append({'path':str(p.relative_to(root)),'lines':changed,'beforeSha256':hashlib.sha256(before.encode()).hexdigest(),'afterSha256':hashlib.sha256(after.encode()).hexdigest(),'beforeArchive':before_file.name})
(base/'canonical-quoting.json').write_text(json.dumps(rows,indent=2)+'\n')
checker=Path('/tmp/issue-1580-research/compare-canonical-seed-quoting.mjs')
checker.write_text('''import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
import {parseLino} from '/tmp/gh-issue-solver-1794900398048/js/server/lino.mjs';
const base='experiments/issue-1580/evidence/checks/cnl-canonical-data';
const records=JSON.parse(readFileSync(base+'/canonical-quoting.json'));
for(const row of records) assert.deepEqual(parseLino(readFileSync(row.path,'utf8')),parseLino(gunzipSync(readFileSync(base+'/'+row.beforeArchive)).toString()),row.path);
writeFileSync(base+'/canonical-quoting-comparison.json',JSON.stringify({allDecodedTreesIdentical:true,files:records.length,fields:records.reduce((n,r)=>n+r.lines.length,0),independentAuthorshipCredit:0},null,2)+'\\n');
''')
subprocess.run(['node',str(checker)],cwd=root,check=True)
print(json.dumps(rows,indent=2));print((base/'canonical-quoting-comparison.json').read_text())
for name in ['scripts/check-generated-files.mjs','package.json']:
 p=root/name
 if p.exists():print('SOURCE',name); print('\n'.join(p.read_text().splitlines()[:120]))
