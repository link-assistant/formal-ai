from pathlib import Path
import json,subprocess
base=Path('/tmp/issue-1580-research/native-test-admission')
for name in ['before.log','before.json']:
    (base/name).rename(base/('test-draft-error.'+name.rsplit('.',1)[1]))
p=Path('rust/tests/web/default-branch-build-policy.test.mjs')
s=p.read_text()
old="const step = workflow('native-type-check.yml').jobs['native-type-check'].steps"
assert old in s
p.write_text(s.replace(old,"const step = Object.values(workflow('native-type-check.yml').jobs)[0].steps"))
args=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',
      '--test-name-pattern=isolated native regressions select execution',str(p)]
with (base/'before.log').open('wb') as stream:
    result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
report={'argv':args,'exitCode':result.returncode,'expectedFailure':True}
(base/'before.json').write_text(json.dumps(report,indent=2)+'\n')
text=(base/'before.log').read_text()
assert result.returncode!=0 and 'rust/tests/unit/calendar-currency.rs' in text,text
print(json.dumps(report));print(text)
