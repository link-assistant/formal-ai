from pathlib import Path
import hashlib, json, subprocess

scratch=Path('/tmp/issue-1580-research')
issue=json.loads((scratch/'picomatch-push-preflight/issue.json').read_text())
print('ISSUE BODY',issue['body'])
lines=Path('experiments/issue-1580/work-plan.md').read_text().splitlines()
print('PLAN LINES 1-87')
print('\n'.join(f'{i+1}: {lines[i]}' for i in range(min(87,len(lines)))))
for arguments in [
    ['rg','-n','main.only|default.branch|native.*build|Rust.*build|no.*Rust|native-type-check','CONTRIBUTING.md','AGENTS.md','experiments/issue-1580/requirements.md','experiments/issue-1580/requirement-inventory.json'],
    ['gh','pr','diff','1581','--repo','link-assistant/formal-ai','--name-only'],
    ['gh','pr','diff','1581','--repo','link-assistant/formal-ai'],
]:
    result=subprocess.run(arguments,text=True,capture_output=True)
    if '--name-only' in arguments:
        (scratch/'pr1581-83882c-paths.txt').write_text(result.stdout)
        expected=subprocess.run(['git','diff','--name-only','origin/main...HEAD'],text=True,capture_output=True,check=True).stdout.splitlines()
        actual=result.stdout.splitlines()
        print('PR PATH INVENTORY',result.returncode,'remote',len(actual),'local',len(expected),'same',set(actual)==set(expected),'rawSha256',hashlib.sha256(result.stdout.encode()).hexdigest())
    elif arguments[:3]==['gh','pr','diff']:
        (scratch/'pr1581-83882c.diff').write_text(result.stdout)
        (scratch/'pr1581-83882c-diff-error.log').write_text(result.stderr)
        print('PR DIFF',result.returncode,'bytes',len(result.stdout.encode()),'lines',len(result.stdout.splitlines()),'rawSha256',hashlib.sha256(result.stdout.encode()).hexdigest(),'error',result.stderr[:2000])
    else:print('POLICY SEARCH',result.returncode,result.stdout,result.stderr)
