from pathlib import Path
import gzip,hashlib,json

test=Path('rust/tests/web/issue-1550-meta-executor.test.mjs')
old="  assert.deepEqual(remembered.outcome.candidate.source.evidence, result.answer.evidence);"
new="  assert.deepEqual(remembered.outcome.candidate.evidence, result.answer.evidence);\n"+old
text=test.read_text()
assert text.count(old)==1 and new not in text
test.write_text(text.replace(old,new))

base=Path('experiments/issue-1580/evidence/checks/javascript-archive-checkout/javascript-checkout-publication-final')
raw=gzip.decompress((base/'source-api-patches.txt.gz').read_bytes())
assert len(raw.splitlines())==83
(base/'literal-patch-review.json').write_text(json.dumps({
    'sourceCommit':'8ace3291f83b2f5c7a667740cdad31c485467e24',
    'publishedHead':'bfe5ac0f3babe512f1bf0a03935bd1d220f9e40f',
    'archive':'source-api-patches.txt.gz','rawSha256':hashlib.sha256(raw).hexdigest(),
    'literalLinesReviewed':83,'allThreePublishedSourcePatchesLiterallyRead':True,
    'earlierImmutableVerificationUnchanged':True,'wholePullRequestDiffReviewed':False,
    'wholePullRequestDiffLimitation':'GitHub returns HTTP 406 for more than 300 changed files',
    'independentAuthorshipCredit':0},indent=2)+'\n')

checkpoint=Path('docs/case-studies/issue-1580/checkout-archive-checkpoint.md')
text=checkpoint.read_text()
assert '## Published bfe5ac0f result' not in text
checkpoint.write_text(text+'''

## Published bfe5ac0f result

All 23 workflows pass on `bfe5ac0f3babe512f1bf0a03935bd1d220f9e40f`.
[Layered CI 44269762053](https://github.com/link-assistant/formal-ai/actions/runs/44269762053)
finishes without a retry. The two original source checkouts finish in 19 and
17 seconds. The complete JavaScript shard totals report 1,440 passes and four
skips in group one, and 1,253 passes and 13 skips in group two, with no failures
or cancellations. Focused changed-component checks also execute successfully.
The original limits and test budgets remain intact. This verifies this hosted
checkout and these tests; the earlier transport root cause remains unknown.

Complete direct job logs, paginated workflow/job responses, source identities
and bounded literal-review receipts are retained under
`experiments/issue-1580/evidence/ci/javascript-checkout-bfe5ac0f/`.
The logs contain 4,997 and 2,745 lines; only the specifically recorded metadata,
command headers and test totals are claimed literally read. The first collector
refuses terminal escape sequences before downloading one log; retain that failure
and retry with GitHub CLI's explicit escape-sequence flag. No test rerun follows.

All 83 lines of the three published source patches are literally reviewed.
The full PR diff remains unavailable through `gh pr diff` because GitHub rejects
more than 300 changed files; individual commit patches and blob identities remain
reviewable. Preserve the original immutable publication receipts and the later
review receipt separately. Expand two newly archived abbreviated filenames
without changing either archive's bytes or the original manifest.
The broader issue remains unfinished, and independent reasoning acceptance
remains 0/20.
''')

plan=Path('experiments/issue-1580/work-plan.md')
text=plan.read_text()
text=text.replace('- [ ] Publish this combined round once after a fresh main/feedback/run check, then collect and review every current-head CI result, including the new native target.', '- [x] Publish the combined round as 9095abcb after fresh main/feedback/run checks; collect all 23 results and the actual passing native target. Preserve both checkout failure attempts separately.')
text=text.replace('- [ ] Review and commit this complete checkout/evidence batch, then publish only after checking the latest head\'s failures, feedback, main ancestry and idle workflow state.', '- [x] Review and publish the complete checkout/evidence batch as bfe5ac0f after checking failures, feedback, main ancestry and idle workflow state. Preserve both stopped local publication attempts and their corrections.')
text=text.replace('- [ ] Review the new hosted checkout and every workflow result before claiming it passes. Input reduction is verified locally; the transport cause remains unproved.', '- [x] Verify all 23 bfe5ac0f workflows pass without a retry. Both original JavaScript checkouts finish in 19/17 seconds; actual shards report 1,440/1,253 passes and 4/13 skips. Preserve complete logs and explicit literal-review limits. Transport cause remains unproved.')
text+='''

## Selected-child evidence preservation (2026-11-18)

- [x] Reproduce three failures: composition loses child evidence, adoption retains
  rejected root evidence, and the answer-to-draft adapter drops direct evidence.
  Preserve the complete 10-pass/3-failure before run.
- [x] Carry copied evidence through JavaScript drafts, deduplicate selected child
  evidence in stable order in both runtimes, and replace adopted answer evidence
  with that composition's evidence. Unused alternatives and rejected roots supply
  no evidence to the adopted composition. Regenerate worker and TypeScript mirrors.
- [x] Pass the initial 13 JavaScript executor cases, 15 adjacent factual-QA cases,
  both fixture currency checks, specification fixture integrity and Rust 2024
  formatting. Preserve the metadata-gate failure and the two filename corrections.
- [ ] Refresh the stale JavaScript-to-Rust projection with the maintained pinned
  translator; run the complete shared-data gate inventory and final focused test.
- [ ] Review and publish the complete batch once after fresh feedback/main/CI
  checks, then verify every hosted result including the fifth native executor test.
- [ ] Complete parent-answer coverage, passage binding, multi-passage provenance
  validation and every earlier unfinished issue criterion. Carrying selected
  evidence alone does not prove those contracts. Independent acceptance remains
  0/20; keep this PR draft and unmerged.
'''
plan.write_text(text)

description=Path('experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md')
text=description.read_text()
text=text.replace('- Keep nonempty `_unverified` answers unresolved', '- Retain selected child evidence through composition, caching and answer adoption in JavaScript and Rust; replace rejected root evidence and exclude unused alternatives. Three new JavaScript regressions reproduce the original loss; the fifth native executor test awaits CI.\n- Keep nonempty `_unverified` answers unresolved',1)
text=text.replace('Add the existing four-test `meta_executor_parity` module as an isolated native CI target', 'Run the `meta_executor_parity` module as an isolated native CI target',1)
old='- Published head `9095abcb` passes **22/23 workflows**.'
new='- Published head `bfe5ac0f` passes **23/23 workflows** without a retry. [Layered CI](https://github.com/link-assistant/formal-ai/actions/runs/44269762053) completes the two original checkouts in **19 and 17 seconds**, then reports **1,440 and 1,253 passing shard tests**, with **4 and 13 skips**, zero failures and zero cancellations. Focused changed-component checks also pass. Complete logs and specific literal-review limits remain preserved; this does not prove the earlier transport cause.\n- Earlier head `9095abcb` passes **22/23 workflows**.'
assert old in text
text=text.replace(old,new,1)
text=text.replace('Hosted checkout with the new rules remains unverified;', 'The hosted checkout and both JavaScript groups now pass on `bfe5ac0f`;')
text=text.replace('The current hosted native regression executes; Layered CI remains unsuccessful during checkout, as recorded above.', 'The hosted native regression executes on `9095abcb`; the later `bfe5ac0f` checkout and JavaScript groups pass, as recorded above.')
text=text.replace('Aggregated provenance and general parent coverage remain open.', 'Selected-child evidence preservation is a separate production draft; complete provenance validation and general parent coverage remain open.')
description.write_text(text)

child=Path('docs/case-studies/issue-1580/child-evidence-checkpoint.md')
assert not child.exists()
child.write_text('''# Selected-child evidence checkpoint

This is an unfinished checkpoint for [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581).
The original issue and all wider unchecked acceptance criteria remain open.

## Reproduction and cause

Solve an unknown root containing two independent tasks whose answers contain
distinct evidence and one shared evidence entry. The JavaScript answer adapter
drops the child evidence when constructing a draft. Composition has no evidence
field, and adopting its text spreads the original root answer, retaining the
rejected root's evidence. The Rust draft and production adapter have the same
missing transfer. An alternative request must retain only its selected child.

Three new JavaScript regressions fail against published source bfe5ac0f; the
before run has ten passes and three failures. Preserve the complete assertions
under `experiments/issue-1580/evidence/checks/child-evidence-provenance/`.
The tests cover selected children, stable deduplication, unused alternatives,
cache reuse, direct answers and preservation of the host's original evidence.

## Draft change

Copy evidence into JavaScript drafts and native drafts. Composition concatenates
only the selected children's evidence, deduplicating while preserving first-use
order. Adoption replaces the rejected root's evidence with the composition's
evidence. Direct answers keep their evidence, and unresolved compositions do not
adopt evidence from rejected children. Regenerate worker and TypeScript mirrors
through the maintained writers. Add one native executor test for conjunctions
and alternatives; native execution remains pending CI.

The initial focused run passes all 13 executor tests, all 15 adjacent factual-QA
tests, both existing shared-fixture checks, specification fixture integrity and
Rust 2024 formatting. The original 29 fixture cases and event traces remain
unchanged. Add an explicit cached-candidate evidence assertion before final
verification. The stale JavaScript-to-Rust projection gate correctly fails;
its maintained regeneration and the required full shared-data gate inventory
remain pending. No local native build runs.

## Limits

This change carries evidence already supplied by selected children. It does not
validate a citation's truth, establish semantic parent coverage, bind passages to
questions, or solve multi-passage aggregation. Those acceptance criteria remain
unfinished. Supplied diagnostics, commands, patches and conclusions receive zero
independent authorship credit; independent acceptance remains 0/20.
''')
print('Updated checkpoints, checklist, tracked PR description and cache assertion; native and full-gate verification remain pending.')
