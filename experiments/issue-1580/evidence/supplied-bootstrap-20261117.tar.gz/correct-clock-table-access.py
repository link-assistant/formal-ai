from pathlib import Path
import json
root=Path('/tmp/gh-issue-solver-1794900398048')
p=root/'js/worker/formal_ai_worker_calendar_and_proofs.js';s=p.read_text();old='handlerRulesTableRows("calendar_spoken_hour_marker")';assert s.count(old)==1;p.write_text(s.replace(old,'handlerRulesTables().calendar_spoken_hour_marker?.rows || []'))
p=root/'rust/src/solver_handlers/calendar_create.rs';s=p.read_text();old='\nstruct PlaceZone';assert s.count(old)==1;p.write_text(s.replace(old,'\n/// One timezone-bearing place the prompt names: the IANA zone its grounding\n/// resolves to, the entity slug, and the surface that named it.\nstruct PlaceZone'))
base=root/'experiments/issue-1580/evidence/checks/spelled-calendar-clock';(base/'after').rename(base/'invalid-table-access-first-draft');print('Corrected JavaScript table access to the existing shared accessor; restored the unrelated Rust documentation.')
