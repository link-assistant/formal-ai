from pathlib import Path
import json, subprocess

blob = '9df886c42a1e2082f1471383d986fea4d531f8ac'
tree = subprocess.check_output(['git', 'ls-tree', '-r', 'HEAD']).decode().splitlines()
paths = [line.split('\t', 1)[1] for line in tree if line.split('\t', 1)[0].endswith(blob)]
size = int(subprocess.check_output(['git', 'cat-file', '-s', blob]))
history = subprocess.check_output(['git', 'log', '-6', '--format=%h %ad %s', '--date=iso-strict', '--', '.github/workflows/layered-ci.yml']).decode()
worker = Path('/proc/1082850/stat')
state = worker.read_text().split(') ', 1)[1].split()[0] if worker.exists() else 'absent'
assert state in ['Z', 'absent']
print(json.dumps({'repeatedPromisorBlob': blob, 'paths': paths, 'bytes': size, 'downloadWorkerState': state, 'workflowHistory': history}, indent=2))
