from pathlib import Path
import json
for name in ['experiments/issue-1580/evidence/ci/main-512ce428/native-failure-inventory.json','experiments/issue-1580/evidence/ci/native-failure-summary.json']:
    p=Path(name)
    print('FILE',name,'BYTES',p.stat().st_size)
    if p.stat().st_size<18000:print(p.read_text())
    else:
        value=json.loads(p.read_text());print('KEYS',list(value))
        for key,row in value.items():
            print(key,json.dumps(row)[:3000])
