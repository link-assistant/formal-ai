from pathlib import Path
p=Path('experiments/issue-1580/template-python-runtime.test.mjs')
s=p.read_text();old="    for(const hosted of [false,true]){\n      const result=spawnSync"
new="    for(const hosted of [false,true]){\n      const env={...process.env,PATH:directory,GITHUB_ACTIONS:String(hosted)};\n      delete env.NODE_TEST_CONTEXT;\n      const result=spawnSync"
assert s.count(old)==1;s=s.replace(old,new).replace("env:{...process.env,PATH:directory,GITHUB_ACTIONS:String(hosted)},","env,")
p.write_text(s)
old=Path('experiments/issue-1580/evidence/checks/python-runtime-provisioning/before.log')
old.rename(old.with_name('initial-harness-failure.log'))
for i,line in enumerate(s.splitlines()[14:33],15):print(f'{i}: {line}')
