
function cacheWriteReport(t, stats) {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'sccache-write-report-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const summary = path.join(directory, 'summary.md');
  const result = spawnSync('bash', ['scripts/check-sccache-write-health.sh', '-'], {
    cwd: root,
    input: typeof stats === 'string' ? stats : JSON.stringify(stats),
    encoding: 'utf8',
    timeout: 5000,
    maxBuffer: 131072,
    env: {
      ...process.env,
      SCCACHE_WRITE_ERROR_WARN_PERCENT: '25',
      SCCACHE_WRITE_MIN_ATTEMPTS: '20',
      SCCACHE_HEALTH_LABEL: 'fixture',
      GITHUB_STEP_SUMMARY: summary,
    },
  });
  assert.equal(result.status, 0, result.stderr);
  return { ...result, summary: fs.existsSync(summary) ? fs.readFileSync(summary, 'utf8') : '' };
}

test('cache write errors report measured counts without inventing future cache misses', t => {
  const observed = cacheWriteReport(t, { cache_writes: 1, cache_write_errors: 87 });
  assert.match(observed.stderr, /::warning title=fixture: Compiler cache reported errors for 98%/u);
  assert.match(observed.stderr, /88 cache writes: 87 recorded errors and 1 were stored/u);
  assert.match(observed.stderr, /another writer may already have stored the same key/u);
  assert.doesNotMatch(observed.stderr, /Every refused write is a crate the next run compiles again/u);
  assert.equal(observed.summary, '- Compiler cache writes (fixture): 1 stored, 87 write errors, 98% errors.\n');
});

test('pretty JSON statistics retain the same write-error warning', t => {
  const observed = cacheWriteReport(t, JSON.stringify({ cache_writes: 60, cache_write_errors: 20 }, null, 2));
  assert.match(observed.stderr, /reported errors for 25%/u);
  assert.match(observed.summary, /60 stored, 20 write errors/u);
});

test('healthy, undersampled and unrelated statistics do not create cache warnings', t => {
  for (const stats of [
    { cache_writes: 100, cache_write_errors: 0 },
    { cache_writes: 0, cache_write_errors: 19 },
    { cache_writes_total: 0, cache_write_errors: 100 },
  ]) {
    const observed = cacheWriteReport(t, stats);
    assert.equal(observed.stderr, '');
    assert.equal(observed.summary, '');
  }
});
