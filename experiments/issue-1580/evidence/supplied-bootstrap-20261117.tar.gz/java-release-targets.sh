set -eu
cat /tmp/issue-1580-research/templates/java-complete/scripts/version-and-commit.mjs
rg -n 'version-and-commit|collect-changelog|execSync|simulate' /tmp/issue-1580-research/templates/java-complete/scripts/release-recovery.test.mjs /tmp/issue-1580-research/templates/java-complete/scripts/cli-inputs.test.mjs
cat /tmp/issue-1580-research/templates/java-complete/scripts/cli-inputs.test.mjs
