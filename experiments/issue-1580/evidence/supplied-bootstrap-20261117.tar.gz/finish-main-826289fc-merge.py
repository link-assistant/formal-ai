import pathlib, subprocess

assert subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip() == 'issue-1580-8d61a32a61e1'
assert pathlib.Path(subprocess.check_output(['git', 'rev-parse', '--git-path', 'MERGE_HEAD'], text=True).strip()).read_text().strip() == '826289fc78154dcd894199ed966f366176be0afb'
assert not subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=U'], text=True).strip()
with open('/tmp/issue-1580-research/main-826289fc-merge-commit.log', 'wb') as output:
    subprocess.run(['git', 'commit', '-m', 'Merge main request-context changes into issue 1580'], check=True, stdout=output, stderr=subprocess.STDOUT)
print(subprocess.check_output(['git', 'log', '-1', '--format=%H%n%P%n%s'], text=True))
