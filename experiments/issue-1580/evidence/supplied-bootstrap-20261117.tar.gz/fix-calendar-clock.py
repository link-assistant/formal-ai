from pathlib import Path
import json,subprocess

def replace(path,old,new):
 source=Path(path);text=source.read_text()
 assert text.count(old)==1,(path,old,text.count(old))
 source.write_text(text.replace(old,new))

worker='js/worker/formal_ai_worker_calendar_and_proofs.js'
replace(worker,
 '    const normalized = normalizePrompt(clause);\n    const anchor =',
 '    const normalized = normalizePrompt(clause);\n    // Normalization erases clock punctuation; read the same request span first.\n    const clock = extractClockTime(clause) || extractClockTime(normalized);\n    const anchor =')
replace(worker,'      extractClockTime(normalized) !== null ||','      clock !== null ||')
replace(worker,'    return action || (prefix && extractClockTime(normalized) !== null &&',
 '    return action || (prefix && clock !== null &&')
replace(worker,'  const [hour, minute] = extractClockTime(normalized) || [17, 0];',
 '  const [hour, minute] = extractClockTime(span) || extractClockTime(normalized) || [17, 0];')

native='rust/src/solver_handlers/calendar_create.rs'
replace(native,'    let (hour, minute) = extract_clock_time(normalized).unwrap_or((17, 0));',
 '    // Clock punctuation belongs to the request span; normalization erases it.\n    let (hour, minute) = extract_clock_time(span)\n        .or_else(|| extract_clock_time(normalized))\n        .unwrap_or((17, 0));')
replace(native,'fn has_calendar_anchor(normalized: &str) -> bool {',
 'fn has_calendar_anchor(span: &str, normalized: &str) -> bool {')
replace(native,'        || extract_clock_time(normalized).is_some();',
 '        || extract_clock_time(span).is_some()\n        || extract_clock_time(normalized).is_some();')
replace(native,'        if !has_calendar_anchor(&normalized) {',
 '        if !has_calendar_anchor(clause, &normalized) {')
replace(native,'            && extract_clock_time(&normalized).is_some()',
 '            && extract_clock_time(clause)\n                .or_else(|| extract_clock_time(&normalized))\n                .is_some()')

subprocess.run(['rustfmt',native,'rust/tests/unit/solver/issue_869_meeting_scheduling.rs'],check=True)
Path('changelog.d/20261117_174500_preserve_calendar_clock.md').write_text(
 '### Fixed\n\n- Preserve clock punctuation and minutes when recognizing scheduling requests and generating calendar event payloads in JavaScript and Rust.\n')
inventory=json.loads(Path('data/benchmarks/fast-pull-request-javascript-tests.json').read_text())
print('FAST INVENTORY TYPE',type(inventory).__name__)
if isinstance(inventory,dict):
 print('KEYS',list(inventory))
 for key,value in inventory.items():
  if isinstance(value,list): print(key,'length',len(value),'sample',value[:1],value[-1:])
else: print(inventory[:1],inventory[-1:])
print(subprocess.run(['rg','-n','1580|1588|calendar','data/meta/main-only-regressions.lino'],text=True,capture_output=True).stdout)
