from pathlib import Path
import json,hashlib,collections

path=Path('docs/case-studies/issue-1580/templates/python-partial-semantic-review.json')
record=json.loads(path.read_text());inventory=json.loads(Path('/tmp/issue-1580-research/python-active-source-inventory.json').read_text())
root=Path('/tmp/issue-1580-research/templates/python-complete')
previous={r['path']:r for r in record['files']}
deferred={'.github/actions/artifact/dist/835.index.mjs','.github/actions/artifact/dist/index.mjs','.github/actions/artifact/package-lock.json','uv.lock'}
specific={
 '.gitignore':'Read all ignore rules. Preserve tracked version/lock inputs and exclude generated environments/caches; do not silently exclude CI source from review.',
 '.gitkeep':'Read the empty-tree retention placeholder; no runtime behavior.',
 '.lycheeignore':'Read the narrow placeholder/link exceptions; do not turn real terminal link failures into success.',
 '.nvmrc':'Read the upstream Node 26.13.1 pin. It is a source identity, not a blanket dependency update for Formal AI.',
 '.pre-commit-config.yaml':'Read pinned ShellCheck, Ruff, mypy and whitespace/large-file hooks. Generated bundle exceptions remain scoped; no pre-commit execution is claimed.',
 '.python-version':'Read the upstream Python 3.15.2 pin. Provision that interpreter only for the maintained pinned Python observations; preserve unrelated benchmark runtime policy.',
 '.ruff.toml':'Read the scoped Python lint configuration and target. No lint run on the complete upstream repository is claimed.',
 '.secretlintrc.json':'Read secret-scanner configuration; retain narrow source/bundle handling rather than broad security exclusions.',
 'CHANGELOG.md':'Read historical release notes; their past CI/runtime claims do not establish current Formal AI acceptance.',
 'CONTRIBUTING.md':'Read all 305 lines of upstream contribution, dependency, evidence, identity and release policy. Retain Formal AI own default-branch build/effect restrictions.',
 'LICENSE':'Read the complete Unlicense terms and retain source provenance; licensing is not runtime validation.',
 'README.md':'Read all 462 lines of template layout, supported runtime, CI/release/dependency and operational guidance. Preserve failure/identity evidence; no live release or broad latest-version claim.',
 'docs/ci-evidence.md':'Read source-validation, dependency attestation and release evidence contract. Preserve exact identity and terminal outcomes; source review does not execute the provider flows.',
 'docs/conf.py':'Read Sphinx configuration and the explicit compatibility-hook import. No complete documentation build was executed.',
 'docs/sphinx_compat.py':'Read the narrow Sphinx 9.2.0 _AutoDocumenterOptions boolean compatibility patch. Do not replace it with global warning suppression or claim a fresh Sphinx build.',
 'docs/requirements.txt':'Read exact documentation dependency pins; no resolver or documentation build was executed.',
 'docs/preview-regeneration.md':'Read the deliberate absence of a Python UI preview workflow. Retain Formal AI own real Playwright/browser verification; do not add a no-op preview job.',
 'docs/api.md':'Read API documentation entrypoints; application/test execution remains pending.',
 'docs/index.md':'Read documentation navigation and build references; preserve actual required checks.',
 'examples/basic_usage.py':'Read the bounded asynchronous arithmetic example. It is not release machinery and was not run as fresh acceptance evidence.',
 'experiments/archiver_glob_probe.cjs':'Read the historical glob probe and fixed /tmp/globprobe cleanup. Do not execute or port its unsafe concurrent scratch-directory reuse.',
 'experiments/issue-151/inventory.py':'Read all 144 lines of historical dependency inventory. urlopen has no explicit I/O timeout despite bounded-loop prose; do not port this one-off network probe as a runtime gate.',
 'experiments/issue-151/final_inventory.py':'Read the historical dependency inventory and API probe. Do not treat recorded versions or unbounded network calls as current runtime evidence.',
 'experiments/issue-151/render_inventory.py':'Read all 270 lines of dependency review rendering. Preserve compatibility-specific decisions; historical latest-version assertions require fresh verification before adoption.',
 'experiments/issue-151/update_manifests.py':'Read all 180 lines of manifest updates and compatibility retentions. Do not copy historical tool pins or blanket major overrides into Formal AI.',
}
offset=0;rows=[]
for category in ['active','historical']:
 for item in inventory[category]:
  row=dict(previous[item['path']]);data=(root/item['path']).read_bytes()
  assert hashlib.sha256(data).hexdigest()==item['sha256']
  assert hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()==item['gitBlob']
  assert len(data.decode().splitlines())==item['lines']
  if category=='active' and item['path'] not in deferred:
   read=max(0,min(item['lines'],6800-offset));offset+=item['lines']
   old=sum(b-a+1 for a,b in row['readRanges']);read=max(old,read)
   if read>old:
    row['readRanges']=[[1,read]]
    if read==item['lines']:
     row['reviewStatus']='active-source-fully-read'
     if item['path'] in specific:row['decision']=specific[item['path']]
     elif item['path'].startswith('changelog.d/'):
      row['decision']='Read the complete pending release record/template and its release-category guidance. Preserve valid earlier fragments; historical change descriptions are not fresh runtime acceptance.'
     elif item['path'].startswith('experiments/'):
      row['decision']='Read the complete historical plan, reproduction or captured result. Keep its pre-fix fixtures, test scope and limitations distinct from current source; it was not executed as fresh acceptance evidence.'
     else:raise AssertionError('Missing file-specific review decision: '+item['path'])
    else:
     row['reviewStatus']='active-source-partially-read'
     row['decision']='Read only lines 1-62 of the historical issue-98 release analysis. Lines 63-120 remain unread; no complete analysis or runtime validation is claimed.'
  rows.append(row)
assert offset==21394
record['files']=rows;record['counts']=dict(collections.Counter(r['reviewStatus'] for r in rows))
record['activeReadLines']=sum(b-a+1 for r in rows for a,b in r['readRanges'])
assert record['activeReadLines']==7664
record['readMethod']='Corrected ordered active-source pages 1-17 (400 lines each) were fully read, plus create_manual_changeset.py 1-249 and version_and_commit.py 1-400/401-615. Generated bundles/locks and every historical blob remain unread. Initial unbounded/truncated previews receive no reading credit. Complete Formal AI command transcripts retain source output.'
record['runtimeEvidence']='The original four-case frozen-clock Python entrypoint fixture and maintained observations were executed locally. The updated maintained entrypoint passes 31 tests with no skips, including runtime/selected-shard regressions. Hosted head 624812120 passed 24 workflows but skipped five Python cases; runtime provisioning must be verified on the next published head. Python fragment children retain 128 MiB address-space and 3 CPU-second limits. Full upstream suites/builds/provider effects were not executed.'
header={k:v for k,v in record.items() if k!='files'}
path.write_text(json.dumps(header,indent=2)[:-2]+',\n  "files": [\n'+',\n'.join('    '+json.dumps(r,separators=(',',':')) for r in rows)+'\n  ]\n}\n')
counts=record['counts'];print(json.dumps({'counts':counts,'readLines':record['activeReadLines']},indent=2))
for name in ['docs/case-studies/issue-1580/README.md','docs/case-studies/issue-1580/templates/README.md','experiments/issue-1580/work-plan.md']:
 p=Path(name);s=p.read_text()
 s=s.replace('publish immutable executable evidence before filing the report.','the published evidence supports [upstream report #157](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/157).')
 s=s.replace('Publish the executable evidence before filing this distinct report.','The evidence is published and [upstream report #157](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/157) is filed.')
 s+='''\n## Python review and hosted runtime checkpoint\n\nThe Python semantic checkpoint now covers '''+str(counts['active-source-fully-read'])+''' fully read active files and one partial file (7,664/44,284 active lines). Corrected pages 1-17 are read; both generated bundles, both lockfiles, remaining active source and all 126 historical blobs remain explicitly unread. The historical experiments were read as source, not rerun or credited as current acceptance. The pinned helper remains unchanged; the silent same-second fragment overwrite is reported at https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/157.\n\nAll 24 workflows on `624812120feee0180bf9df8164f87e73326b5cb8` passed, but full Layered CI log lines 4877 and 4893-4896 show five Python cases skipped on the older runner interpreter. This is not hosted Python acceptance. The new draft plans the actual JavaScript shard first and installs Python 3.15.2 only where the maintained template entrypoint is selected. Missing/old Python fails on GitHub Actions while remaining optional locally. The selected file list is reused for execution, and regressions exercise owning/non-owning shards in both two- and eight-shard profiles. The maintained entrypoint passes 31 tests locally without skips; hosted verification of the next published head is still required. Default-branch build restrictions and benchmark floors remain unchanged. All broader issue criteria remain active.\n'''
 p.write_text(s)
