from pathlib import Path
import json,subprocess

path='rust/tests/web/calendar-clock-preservation.test.mjs'
inventory=Path('data/benchmarks/fast-pull-request-javascript-tests.json')
data=json.loads(inventory.read_text())
assert path not in data['files']
data['files'].append(path)
inventory.write_text(json.dumps(data,indent=2)+'\n')
ledger=Path('data/meta/main-only-regressions.lino')
text=ledger.read_text()
assert 'regression calendar-clock-punctuation' not in text
ledger.write_text(text+'''main-run 44117975432
  javascript-twin
    regression calendar-clock-punctuation
      introduced-by "PR #1589 request-span recognition, merged as 512ce428"
      failed "meeting participant/time/Georgia and Tbilisi scheduling fell through after normalized clock punctuation disappeared"
      check rust/tests/web/calendar-clock-preservation.test.mjs
      marker "calendar preserves the clock in"
''')
print(subprocess.run(['rg','-l','main-only-regressions.lino','scripts','rust/tests/web'],text=True,capture_output=True).stdout)
print('Registered calendar clock regression in fast PR inventory and main-only replay ledger.')
