set -eu
for item in python:detect_code_changes.py cpp:detect_code_changes.py php:detect-code-changes.php rust:detect-code-changes.rs; do
  language=${item%%:*}
  filename=${item#*:}
  printf '\n%s\n' "$language"
  cat "/tmp/issue-1580-research/templates/$language-complete/scripts/$filename"
done
command -v php || true
for language in js rust python php csharp java cpp go; do
  rg -n -A 7 'detect-changes:|detect-code-changes:|workflow_dispatch|pipeline-status:' "/tmp/issue-1580-research/templates/$language-complete/.github/workflows/release.yml"
done > /tmp/issue-1580-research/template-detection-context.txt
