from pathlib import Path
import gzip,hashlib,json,subprocess

base=Path('experiments/issue-1580/evidence')
before=base/'checks/csharp-changeset-collision'
log=(before/'before.tap').read_bytes()
assert b'# pass 3\n' in log and b'# fail 1\n' in log
assert b'not ok 2 - C\\# candidate preserves every input' in log
assert b'Removed: merged-bright-apple.md' in log and b'Removed: other.md' in log
assert b'Changeset merge completed successfully' in log
record=json.loads((before/'before.json').read_text())
assert record['exitCode']==1
assert hashlib.sha256(gzip.decompress((before/'before-test.mjs.gz').read_bytes())).hexdigest()==record['testSha256']
record['logSha256']=hashlib.sha256(log).hexdigest()
record['assertionsVerified']=True
record['harnessCorrections']='Initial harness assumed TAP output; explicit TAP reporting was added. TAP escapes C# as C\\#; a subsequent check of the preserved log uses the escaped label. Both captured test runs show the same 3 passing / 1 failing preservation test; no application or fixture input changed between those runs.'
(before/'before.json').write_text(json.dumps(record,indent=2)+'\n')
print('Before-fix archive verified:',json.dumps(record))
repo='link-assistant/formal-ai'
run='44089535561'
metadata=json.loads(subprocess.check_output(['gh','api',f'repos/{repo}/actions/runs/{run}/attempts/2'],text=True))
assert metadata['head_sha']=='e582b270a01443b995d7f36fd2fa685d508fde77'
assert metadata['status']=='completed' and metadata['conclusion']=='success' and metadata['run_attempt']==2
destination=base/'ci/e582b270a/attempt-2'
destination.mkdir(parents=True,exist_ok=True)
data=subprocess.check_output(['gh','run','view',run,'--repo',repo,'--attempt','2','--log'])
(destination/(run+'.log.gz')).write_bytes(gzip.compress(data,mtime=0))
(destination/(run+'.json')).write_text(json.dumps(metadata,indent=2)+'\n')
summary={'head':metadata['head_sha'],'run':int(run),'attempt':2,'conclusion':'success','logSha256':hashlib.sha256(data).hexdigest(),'logLines':len(data.splitlines()),'interpretation':'The same-head failed-job-only rerun passed after an attempt-1 checkout transport failure. This does not establish any main-only native or benchmark acceptance criterion.'}
(destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('CI rerun:',json.dumps(summary))
