from pathlib import Path
import json
for name in ['docs/case-studies/issue-1580/README.md','scripts/create-changelog-fragment.rs']:
 p=Path(name); lines=p.read_text().splitlines(); print('FILE',name,len(lines)); assert len(lines)<=1500
 print('\n'.join(f'{n}: {line}' for n,line in enumerate(lines,1)))
base=Path('/tmp/issue-1580-research/templates')
print('TEMPLATE CHECKOUTS',json.dumps([p.name for p in base.iterdir() if p.is_dir()]))
print('TEMPLATE INVENTORIES',json.dumps([p.name for p in base.iterdir() if p.is_file() and 'inventory' in p.name]))
print('REVIEW ARTIFACTS',json.dumps([p.name for p in Path('docs/case-studies/issue-1580/templates').iterdir() if 'review' in p.name]))
