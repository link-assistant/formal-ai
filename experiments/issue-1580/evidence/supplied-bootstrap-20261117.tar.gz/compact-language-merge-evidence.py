from pathlib import Path
import gzip,hashlib,json
base=Path('experiments/issue-1580/evidence/checks/language-main-integration');rows=[]
for name in ('native-registry-complete-delta.json','native-registry-merged-review.json'):
 p=base/name;raw=p.read_bytes();value=json.loads(raw)
 # Preserve full structured comparison with one parent per line and no semantic change.
 compact='[\n'+',\n'.join(json.dumps(x,separators=(',',':')) for x in value)+'\n]\n' if isinstance(value,list) else json.dumps(value,separators=(',',':'))+'\n'
 assert json.loads(compact)==value
 packed=gzip.compress(raw,mtime=0);(base/(name+'.original.gz')).write_bytes(packed);p.write_text(compact)
 rows.append({'file':name,'beforeLines':len(raw.splitlines()),'afterLines':len(compact.splitlines()),'originalSha256':hashlib.sha256(raw).hexdigest(),'compactSha256':hashlib.sha256(compact.encode()).hexdigest(),'originalArchiveSha256':hashlib.sha256(packed).hexdigest(),'completeStructuredEquality':True})
(base/'structured-evidence-formatting.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
