from pathlib import Path
import gzip, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
def run(args):
    result = subprocess.run(args, cwd=root, capture_output=True, text=True)
    assert result.returncode == 0, (args, result.stdout, result.stderr)
    return result.stdout.strip()
assert run(['git', 'branch', '--show-current']) == 'issue-1580-8d61a32a61e1'
assert run(['git', 'rev-parse', 'HEAD']) == 'd0b395bb2310e285c89d93818571e4d54ed59c02'
assert run(['git', 'diff', '--cached', '--name-only']) == ''
out = root / 'experiments/issue-1580/evidence/checks/opener-native-boundary'
receipt = json.loads((out / 'publication/outcome.json').read_text())
assert receipt['complete'] and all(row['exitCode'] == 0 for row in receipt['records'])
summary = json.loads((out / 'reviewed-round-summary.json').read_text())
for name, sha in summary['sourceHashes'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == sha, name
run(['git', 'diff', '--check'])
code = ['rust/src/unknown_opener.rs', 'rust/src/web_engine_core.rs', 'rust/tests/source/unknown_opener_language_tests.rs']
run(['git', 'add', '--', *code])
assert set(run(['git', 'diff', '--cached', '--name-only']).splitlines()) == set(code)
commits = []
raw = run(['git', 'commit', '-m', 'Keep localized opener checks outside WASM source'])
(scratch / 'opener-boundary-code-commit.log.gz').write_bytes(gzip.compress(raw.encode(), mtime=0))
commits.append(run(['git', 'rev-parse', 'HEAD']))
run(['git', 'add', '--', 'docs/case-studies/issue-1580', 'experiments/issue-1580', 'changelog.d/20261117_120000_issue-1580-ci-regressions.md'])
names = run(['git', 'diff', '--cached', '--name-only']).splitlines()
assert names and all(name.startswith(('docs/case-studies/issue-1580/', 'experiments/issue-1580/', 'changelog.d/')) for name in names)
run(['git', 'diff', '--cached', '--check'])
raw = run(['git', 'commit', '-m', 'Preserve complete opener CI failures and verification limits'])
(scratch / 'opener-boundary-evidence-commit.log.gz').write_bytes(gzip.compress(raw.encode(), mtime=0))
commits.append(run(['git', 'rev-parse', 'HEAD']))
assert run(['git', 'status', '--porcelain']) == ''
receipt = {'commits': commits, 'evidenceFiles': len(names), 'cleanWorkingTree': True, 'pushed': False}
(scratch / 'opener-boundary-publication-commits.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
