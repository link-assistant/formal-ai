import json
from pathlib import Path
import subprocess

paths = [
    Path('/tmp/issue-1580-research/ci-logs/javascript-checkout-bfe5ac0f/outcome.json'),
    Path('/tmp/issue-1580-research/ci-logs/javascript-checkout-bfe5ac0f/worker.log'),
    Path('/tmp/issue-1580-research/child-evidence-validation-worker.log'),
    Path('experiments/issue-1580/evidence/checks/child-evidence-provenance/extended-validation.json'),
]
for path in paths:
    print('\nFILE', path)
    if path.exists():
        value = path.read_text()
        print(value if len(value) < 18000 else value[-18000:])
    else:
        print('MISSING')
for pid in (1224525, 1224627):
    result = subprocess.run(['ps', '-p', str(pid), '-o', 'pid,stat,etime,args'], capture_output=True, text=True)
    print(result.stdout)
print(subprocess.run(['git', 'status', '--short'], capture_output=True, text=True).stdout)
