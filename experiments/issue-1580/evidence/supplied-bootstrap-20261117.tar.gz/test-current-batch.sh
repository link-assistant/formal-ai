set -eu
rustfmt --edition 2024 scripts/detect-code-changes.rs
rustfmt --edition 2024 --check scripts/detect-code-changes.rs
timeout 600 node --test --test-concurrency=1 rust/tests/web/cargo-audit-blocked-proof.test.mjs > /tmp/issue-1580-research/cargo-audit-blocked-proof.log 2>&1
cat /tmp/issue-1580-research/cargo-audit-blocked-proof.log
timeout 600 node --test --test-concurrency=1 rust/tests/web/issue-1580-template-observations.test.mjs > /tmp/issue-1580-research/template-observations.log 2>&1
cat /tmp/issue-1580-research/template-observations.log
timeout 600 node --test --test-concurrency=1 rust/tests/web/release-pending-pipeline.test.mjs > /tmp/issue-1580-research/release-pending-pipeline-current.log 2>&1
cat /tmp/issue-1580-research/release-pending-pipeline-current.log
