import pathlib,subprocess
p=pathlib.Path('/tmp/issue-1580-research/review-merged-native-registry.mjs')
s=p.read_text()
s=s.replace("if(copy.sha256!==actual){assert.equal(copy.sha256,hash(execFileSync('git',['show',parent+':'+node.path],{cwd:r,maxBuffer:8*1024*1024})));changes.push", "if(copy.sha256!==actual){const parentHash=hash(execFileSync('git',['show',parent+':'+node.path],{cwd:r,maxBuffer:8*1024*1024}));if(copy.sha256!==parentHash)console.log('STALE_PARENT_IDENTITY',JSON.stringify({parent,export:key,program:old.path,source:node.path,registry:copy.sha256,parentHash,current:actual}));assert.equal(copy.sha256,parentHash);changes.push")
p.with_name('diagnose-merged-registry-identity.mjs').write_text(s)
r=subprocess.run(['node','--max-old-space-size=256',str(p.with_name('diagnose-merged-registry-identity.mjs'))],capture_output=True,text=True)
print('EXIT',r.returncode);print(r.stdout);print(r.stderr[:6500])
for f in ('record-java-history-112-113.py',):
 p=pathlib.Path('/tmp/issue-1580-research')/f
 print('SCRIPT',f);print(p.read_text())
