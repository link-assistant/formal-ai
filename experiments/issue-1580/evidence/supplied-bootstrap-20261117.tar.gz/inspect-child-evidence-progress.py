from pathlib import Path
import json

for name in [
    '/tmp/issue-1580-research/javascript-checkout-resume-worker.log',
    '/tmp/issue-1580-research/ci-logs/javascript-checkout-bfe5ac0f/resume/outcome.json',
    '/tmp/issue-1580-research/child-evidence-validation-resume-worker.log',
    'experiments/issue-1580/evidence/checks/child-evidence-provenance/resumed-validation.json',
    'experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md',
    'experiments/issue-1580/work-plan.md',
]:
    path=Path(name)
    print('\nFILE',name)
    if not path.exists():print('MISSING');continue
    lines=path.read_text().splitlines()
    if name.endswith('work-plan.md'):
        start=max(0,len(lines)-180)
    else:start=0
    assert len(lines)-start<=1500
    for number,line in enumerate(lines[start:],start+1):print(f'{number}: {line}')
