from pathlib import Path
import subprocess
rows=Path('experiments/formal_ai_subagent/sandboxes/gates/check-worker-line-budget.log').read_text().splitlines()
print('\n'.join(rows[-12:]))
for args in [['rg','-l','formal_ai_worker_candidate_validation','js','ts','scripts','data','--glob','!*.bundle.js','--glob','!*.json'],['rg','-n','generate|Usage|worker-script-files','scripts/generate-worker-prerequisites.mjs','scripts/generate-runtime-feature-inventory.mjs']]:
    r=subprocess.run(args,text=True,capture_output=True);print('SEARCH',args,r.stdout[:8000],r.stderr)
print('GUARD',Path('js/worker/formal_ai_worker_candidate_validation.js').read_text())
