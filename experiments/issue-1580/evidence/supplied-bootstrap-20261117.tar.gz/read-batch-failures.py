import gzip,re
from pathlib import Path
root=Path('/tmp/issue-1580-research/current-head-ci')
for run in ['44059369287','44059368522']:
    lines=gzip.open(root/(run+'.log.gz'),'rt').read().splitlines()
    print('\nRUN',run)
    hits=[i for i,line in enumerate(lines) if re.search(r'error\[|error:|not ok |✖ |failing tests:|FAIL:|test result: FAILED|ℹ fail [1-9]',line)]
    indices=set()
    for i in hits:
        indices.update(range(max(i-3,0),min(i+18,len(lines))))
    text='\n'.join(str(i+1)+' '+lines[i] for i in sorted(indices))
    (root/(run+'-errors.txt')).write_text(text+'\n')
    print(text[:50000])
