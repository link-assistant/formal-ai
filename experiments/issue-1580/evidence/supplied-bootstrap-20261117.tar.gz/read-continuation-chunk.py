from pathlib import Path
import sys
name, first, last = sys.argv[1:]
first,last=int(first),int(last)
lines=Path(name).read_text().splitlines()
assert 1<=first<=last and last-first<1500
selected=lines[first-1:last]
assert sum(len(line) for line in selected)<22000, 'Choose a smaller chunk'
print(f'{name}: total {len(lines)} lines; selected {first}-{min(last,len(lines))}')
for number,line in enumerate(selected,first):print(f'{number}: {line}')
