import json
import subprocess
from pathlib import Path

folder = Path('/tmp/issue-1580-research/eighth-feedback')
folder.mkdir(exist_ok=True)
paths = {
    'issue-comments': 'issues/1580/comments',
    'pr-conversation': 'issues/1581/comments',
    'pr-inline': 'pulls/1581/comments',
    'pr-reviews': 'pulls/1581/reviews',
}
for name, suffix in paths.items():
    raw = subprocess.check_output(['gh', 'api', 'repos/link-assistant/formal-ai/' + suffix, '--paginate'])
    (folder / (name + '.json')).write_bytes(raw)
    rows = json.loads(raw)
    print(name, len(rows))
    for row in rows:
        changed = row.get('updated_at') or row.get('submitted_at') or row.get('created_at') or ''
        print('IDENTITY', row.get('id'), changed, row.get('html_url'))
        if changed >= '2026-11-17T12:00:00Z':
            print(row.get('body') or '')
subprocess.run(['git', 'fetch', 'origin', 'main'], check=True)
subprocess.run(['git', 'merge-base', '--is-ancestor', 'origin/main', 'HEAD'], check=True)
print('main', subprocess.check_output(['git','rev-parse','origin/main'], text=True).strip())
print('current branch', subprocess.check_output(['git','branch','--show-current'], text=True).strip())
