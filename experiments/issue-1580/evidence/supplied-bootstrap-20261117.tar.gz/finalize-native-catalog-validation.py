from pathlib import Path
import json,subprocess,os,time,gzip,hashlib,re,sys,traceback
root=Path.cwd();scratch=Path('/tmp/issue-1580-research/native-catalog-final-validation');base=root/'experiments/issue-1580/evidence/checks/native-catalog-final-validation'
if len(sys.argv)==1:
 scratch.mkdir();base.mkdir()
 with(scratch/'worker.log').open('wb')as f:p=subprocess.Popen([sys.executable,__file__,'worker'],stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'log':str(scratch/'worker.log')}));raise SystemExit
rows=[];env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256');env['PATH']='/home/box/.local/bin:'+env['PATH']
def save(name,raw):
 z=gzip.compress(raw,mtime=0);filename=name+'.log.gz';(base/filename).write_bytes(z);return {'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(z).hexdigest(),'lines':len(raw.splitlines())}
def run(name,args):
 start=time.monotonic()
 with(scratch/(name+'.log')).open('wb')as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 row=dict(save(name,(scratch/(name+'.log')).read_bytes()),name=name,argv=args,exitCode=r.returncode,seconds=round(time.monotonic()-start,3));rows.append(row);print(json.dumps(row),flush=True);assert r.returncode==0,(name,(scratch/(name+'.log')).read_text()[-2000:])
try:
 while not Path('/tmp/issue-1580-research/native-catalog-batch-validation/outcome.json').exists():time.sleep(5)
 previous=root/'experiments/issue-1580/evidence/checks/native-catalog-batch-validation';attempt=json.loads((previous/'result.json').read_text());failed=[r['name']for r in attempt['checks']if r['exitCode']];assert failed==['shellcheck','all-gates'],failed
 run('normalize-artifact-name',['python3','/tmp/issue-1580-research/normalize-retained-gate-file-name.py'])
 run('shellcheck',['shellcheck','scripts/ci-native-regressions.sh'])
 run('policy',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/default-branch-build-policy.test.mjs'])
 run('focused-map',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/focused-test-map.test.mjs'])
 run('affected-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size-js-twin,check-file-size,check-changelog-fragment-js-twin,check-tests-as-docs,check-tests-as-documentation-javascript-twin'])
 gates=(Path('/tmp/issue-1580-research/native-catalog-batch-validation/all-gates.log')).read_text();failed_gates=re.findall(r'^FAIL (\S+)',gates,re.M);assert failed_gates==['check-abbreviations'],failed_gates
 assert len(re.findall(r'^(?:PASS|FAIL|SKIP) ',gates,re.M))==139
 for name in ['overlap-before','core-boundary','shellcheck-recheck','shellcheck-recheck-2']:
  p=Path('/tmp/issue-1580-research/native-overlap-draft-validation')/(name+'.log');save(name,p.read_bytes())
 checked=0
 for directory in ['google-trends-draft-validation','native-catalog-batch-validation']:
  b=root/'experiments/issue-1580/evidence/checks'/directory;x=json.loads((b/'result.json').read_text())
  for item in x['checks']+x['gates']:
   z=(b/item['file']).read_bytes();assert hashlib.sha256(z).hexdigest()==item['archiveSha256'];assert hashlib.sha256(gzip.decompress(z)).hexdigest()==item['rawSha256'];checked+=1
 paths=subprocess.check_output(['git','show','--format=','--name-only','82c36fa5c'],text=True).splitlines();sources={p:hashlib.sha256((root/p).read_bytes()).hexdigest()for p in paths if p}
 report={'complete':True,'sourceHead':'82c36fa5c3ed30947d42d125a311c36187cf8171','javascriptPassed':52,'fullGateInventory':139,'gatesPassedAfterRecheck':87,'explicitGateExclusions':52,'unresolvedGateFailures':0,'initialInventoryFailedGates':failed_gates,'initialShellcheckFailed':True,'beforeSerialRegressionFailed':True,'checks':rows,'sourceHashes':sources,'verifiedEarlierPayloadPairs':checked,'nativeExecuted':False,'nativeFixturesRegenerated':False,'fullIssueComplete':False,'independentAuthorshipCredit':0};(base/'result.json').write_text(json.dumps(report,indent=2)+'\n');(scratch/'outcome.json').write_text(json.dumps({k:v for k,v in report.items()if k not in ['checks','sourceHashes']},indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in ['checks','sourceHashes']}),flush=True)
except BaseException:
 traceback.print_exc();(scratch/'failure.json').write_text(json.dumps({'complete':False,'error':traceback.format_exc()})+'\n');raise
