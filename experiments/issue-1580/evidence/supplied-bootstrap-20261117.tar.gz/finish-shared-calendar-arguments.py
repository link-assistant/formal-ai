from pathlib import Path
import subprocess
root=Path.cwd()
source=Path('/tmp/issue-1580-research/draft-shared-calendar-arguments.py').read_text()
start=source.index("p=root/'js/seed_loader.js'")
exec(source[start:])
