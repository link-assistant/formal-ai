from pathlib import Path
import json
s=Path('/tmp/issue-1580-research/offline-research-catalog-final-validation')
for name in ['outcome.json','failure.json']:
 p=s/name
 if p.exists():print(name,p.read_text())
p=s/'all-gates.log';a=p.read_text().splitlines();print('Gate totals',{k:sum(l.startswith(k+' ') for l in a) for k in ['PASS','FAIL','SKIP']});print('\n'.join(a[-7:]));print('Failures','\n'.join(l for l in a if l.startswith('FAIL')))
root=Path('/tmp/gh-issue-solver-1794900398048');p=root/'rust/embedded/data/seed/meanings-how.lino';print('embedded mirror exists',p.exists());print('same bytes',p.exists() and p.read_bytes()==(root/'data/seed/meanings-how.lino').read_bytes())
