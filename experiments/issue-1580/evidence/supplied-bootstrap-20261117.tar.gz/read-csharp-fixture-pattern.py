from pathlib import Path
import subprocess,json
for name in ['experiments/issue-1580/template-java-release-integrity.test.mjs','experiments/issue-1580/template-reference-graph.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs']:
    p=Path(name)
    lines=p.read_text().splitlines()
    print('FILE',name,'LINES',len(lines))
    limit=90 if 'java-release' in name else 40
    for i,line in enumerate(lines[:limit],1):print(f'{i}: {line}')
print('FIXTURES',subprocess.check_output(['rg','--files','experiments/issue-1580/fixtures'],text=True))
rows=json.loads(Path('/tmp/issue-1580-research/templates/csharp-complete-inventory.json').read_text())
for row in rows:
    if row['path'] in ['scripts/merge-changesets.mjs','scripts/parse-changeset.mjs','scripts/print-untrusted.mjs','LICENSE']:print(json.dumps(row))
