from pathlib import Path
import subprocess

root=Path.cwd()
def replace(path,before,after):
    text=path.read_text()
    assert text.count(before)==1,(str(path),before,text.count(before))
    path.write_text(text.replace(before,after))

javascript=root/'js/agentic/crate/meta_executor.mjs'
replace(javascript,"    parts: chosen.map((outcome) => outcome.task),\n", "    parts: chosen.map((outcome) => outcome.task),\n    evidence: [...new Set(chosen.flatMap((outcome) => outcome.candidate.evidence))],\n")
replace(javascript,"    steps,\n    source: raw,\n", "    steps,\n    evidence: Array.isArray(raw.evidence) ? raw.evidence.slice() : [],\n    source: raw,\n")
replace(javascript,"answer ? { intent: answer.intent, content: answer.content, confidence: answer.confidence } : null;", "answer ? { intent: answer.intent, content: answer.content, confidence: answer.confidence, evidence: answer.evidence } : null;")
replace(javascript,"{ ...answer, intent: selected.intent, content: selected.content, confidence: selected.confidence }", "{ ...answer, intent: selected.intent, content: selected.content, confidence: selected.confidence, evidence: selected.evidence }")

native=root/'rust/src/meta_executor.rs'
replace(native,'pub struct Draft {\n    pub intent: String,\n    pub content: String,\n    pub confidence: f32,\n}', 'pub struct Draft {\n    pub intent: String,\n    pub content: String,\n    pub confidence: f32,\n    /// Evidence belonging to this draft, retained when selected or composed.\n    pub evidence: Vec<String>,\n}')
replace(native,'        confidence: 0.0,\n    };\n    let verdict = run_task_test', '        confidence: 0.0,\n        evidence: Vec::new(),\n    };\n    let verdict = run_task_test')
replace(native,'    Some(Candidate {\n        method: "composition",', '''    let mut seen = BTreeSet::new();
    let evidence = chosen
        .iter()
        .flat_map(|candidate| candidate.draft.evidence.iter())
        .filter(|entry| seen.insert(entry.as_str()))
        .cloned()
        .collect();
    Some(Candidate {
        method: "composition",''')
replace(native,'            content,\n            confidence,\n        },', '            content,\n            confidence,\n            evidence,\n        },')
production=root/'rust/src/meta_executor/production.rs'
replace(production,'            confidence: solved.confidence,\n', '            confidence: solved.confidence,\n            evidence: solved.evidence_links.clone(),\n')
replace(production,'            answer.confidence = composed.confidence;\n', '            answer.confidence = composed.confidence;\n            answer.evidence_links.clone_from(&composed.evidence);\n')
tests=root/'rust/tests/unit/meta_executor_parity.rs'
text=tests.read_text()
needle='        confidence: row["confidence"].as_f64().map_or(0.0, |value| value as f32),\n'
assert text.count(needle)==1
text=text.replace(needle,needle+'        evidence: row.get("evidence").map_or_else(Vec::new, strings),\n')
for confidence,indent in [('0.0',12),('1.0',16),('1.0',12),('0.0',12)]:
    needle=' '*indent+'confidence: '+confidence+',\n'+' '*(indent-4)+'}'
    assert needle in text,needle
    text=text.replace(needle,' '*indent+'confidence: '+confidence+',\n'+' '*indent+'evidence: Vec::new(),\n'+' '*(indent-4)+'}',1)
text+='''
#[test]
fn production_composition_retains_only_selected_child_evidence() {
    for (connective, expected) in [
        ("and", vec!["source:first", "source:shared", "source:second"]),
        ("or", vec!["source:first", "source:shared"]),
    ] {
        let mut child = |text: &str| {
            let source = if text == "First task" { "source:first" } else { "source:second" };
            Some(Draft {
                intent: "answered".to_owned(),
                content: text.to_owned(),
                confidence: 1.0,
                evidence: vec![source.to_owned(), "source:shared".to_owned()],
            })
        };
        let prompt = format!("First task {connective} second task");
        let run = formal_ai::meta_executor::solve_answer(
            Request { text: &prompt, language: "en" },
            Draft {
                intent: "unknown".to_owned(),
                content: String::new(),
                confidence: 0.0,
                evidence: vec!["source:unselected-root".to_owned()],
            },
            &mut child,
            &RunOptions::default(),
        ).expect("outer production turn");
        let composed = formal_ai::meta_executor::adopted_composition(&run).expect("composition selected");
        assert_eq!(composed.evidence, expected, "{connective}");
    }
}
'''
tests.write_text(text)
result=subprocess.run(['rustfmt','--edition','2024',str(native),str(production),str(tests)],capture_output=True,text=True)
print(result.stdout,result.stderr)
assert result.returncode==0
print(subprocess.check_output(['git','diff','--stat'],text=True))
print(subprocess.check_output(['rg','-n','sync-worker|translate-typescript|governed-witness|source-reader','scripts/sync-worker.sh','scripts/translate-typescript.mjs','experiments/issue-1580/refresh-governed-fixture.mjs'],text=True,stderr=subprocess.STDOUT))
