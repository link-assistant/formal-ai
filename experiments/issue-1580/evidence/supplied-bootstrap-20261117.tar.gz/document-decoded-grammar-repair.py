from pathlib import Path

path = Path('changelog.d/20261117_120000_issue-1580-ci-regressions.md')
text = path.read_text()
text += '- Preserve decoded quote characters in native structural grammar and vocabulary values, preventing the ASCII quotation pair from becoming empty during task solving.\n'
path.write_text(text)

path = Path('docs/case-studies/issue-1580/task-quotation-checkpoint.md')
text = path.read_text()
text += '''
## Hosted failure and decoded-value repair

Publication head `04a468f53549f0825999c1dd9e53210476723106` completes
21 of 23 workflows successfully. CI/CD run 44242408037 fails at 05:14:34 UTC
on 2026-11-18; Layered CI run 44242407754 fails at 05:17:33 UTC. Both run
records identify this head and start after its publication. Preserve the full
workflow logs and each failed job log under
`experiments/issue-1580/evidence/ci/task-quotation-04a468f5/`.

The native calendar/currency regression reaches task decomposition and panics
at `rust/src/formalization/mod.rs:38`: `nonempty structural grammar facts`.
Its failed job log lines 1634–1644 retain the assertion and test failure. The
seed parser has already decoded the ASCII double-quote pair to two quote
characters. Both native grammar accessors then trim literal quote characters
from the decoded value, erasing the pair. The JavaScript accessor preserves the
decoded value. Retain native values exactly in both structural and vocabulary
accessors. Shared held-out vectors now include an all-quote value and values
with literal quotes at either or both edges. Both test implementations consume
the same expected values. Add an assertion against the actual seeded task
quote pairs to the native grammar regression. Native execution of the repair
remains pending CI; local source inspection and JavaScript fixture execution
cannot establish it.

The Layered CI failure occurs in checkout before any test runs. Failed job
134593254796 lines 124–126 report curl 28, a transfer below 1024 bytes/second
for 20 seconds, a bad pack header and failure to fetch a promisor blob. Its
entire 171-line log is read. This is separate from the native assertion; no
workflow policy is changed for the single transfer failure. The next complete
repair push will exercise checkout again.

The bounded semantic projection of all four selected context-candidate cases
is now read without truncation, excluding nested execution traces. It confirms
that the arithmetic-only parent reports `calculation`, while the uncovered
subject and two-passage parents report `prompt_text_gap`. The original meeting
parent reports both requested time and place. These observations explain the
candidate rejection; they do not establish a production coverage repair.

Broad acceptance and independent authorship remain unchanged and unfinished.
'''
path.write_text(text)
print('Updated patch changelog and quotation checkpoint; native repair remains unverified until hosted CI.')
