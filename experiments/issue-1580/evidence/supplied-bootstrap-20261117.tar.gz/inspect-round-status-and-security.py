from pathlib import Path
import json
import subprocess

folder = Path('/tmp/issue-1580-research/head-71e1dee44')
runs = json.loads((folder / 'runs.json').read_text())
print('Runs', len(runs), [(row['name'] if 'name' in row else row.get('workflowName'), row['conclusion'], row['databaseId']) for row in runs])
security = next(row for row in runs if (row.get('name') or row.get('workflowName')) == 'Security')
run_id = str(security['databaseId'])
if not (folder / f'security-{run_id}.log').exists():
    result = subprocess.run(['gh', 'run', 'view', run_id, '--repo', 'link-assistant/formal-ai', '--log'], stdout=subprocess.PIPE, check=True)
    (folder / f'security-{run_id}.log').write_bytes(result.stdout)
lines = (folder / f'security-{run_id}.log').read_text().splitlines()
selected = set()
for number, line in enumerate(lines, 1):
    body = line.split('\t')[-1].lower()
    if any(word in body for word in ['blocked-upstream', 'cargo audit', 'scanning', 'advisories', 'chrono@', 'unmaintained']):
        for n in range(max(1, number-1), min(len(lines), number+3)+1):
            selected.add(n)
assert len(selected) < 90, len(selected)
for n in sorted(selected):
    print(f'{n}: {lines[n-1]}')
print('Security log lines:', len(lines))
