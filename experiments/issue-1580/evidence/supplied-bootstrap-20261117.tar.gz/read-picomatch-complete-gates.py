from pathlib import Path
import subprocess
p=Path('/tmp/issue-1580-research/picomatch-validation-complete-local-gates.log')
lines=p.read_text().splitlines()
print('COMPLETE GATES',len(lines),'lines')
print('\n'.join(f'{i+1}: {x}' for i,x in enumerate(lines)))
r=Path('/tmp/gh-issue-solver-1794900398048')
cp=subprocess.run(['rg','-n','log|output|report|mkdtemp','experiments/formal_ai_subagent/local-gates.mjs'],cwd=r,text=True,capture_output=True)
print(cp.stdout[:7000])
print('SUPERVISOR')
print(Path('/tmp/issue-1580-research/picomatch-validation-supervisor.log').read_text()[-2500:])
