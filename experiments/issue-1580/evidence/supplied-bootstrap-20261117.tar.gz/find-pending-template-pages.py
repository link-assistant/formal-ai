from pathlib import Path
for parent in [Path('/tmp/issue-1580-research'),Path('docs/case-studies/issue-1580/templates')]:
    for path in sorted(parent.glob('*java*')):
        print(path, path.stat().st_size)
    for path in sorted(parent.glob('*python*review*')):
        print(path, path.stat().st_size)
for name in ['runtime-replay-all-local-gates.log','corrected-runtime-replay-worker.log']:
    path=Path('/tmp/issue-1580-research')/name
    if path.exists():
        lines=path.read_text().splitlines()
        print(name,'lines',len(lines))
        for line in lines[-8:]:print(line)
