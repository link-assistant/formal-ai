from pathlib import Path
p=Path('rust/tests/web/sccache-outage-fallback.test.mjs');text=p.read_text()
text=text.replace('function cacheWriteReport(t, stats) {','function cacheWriteReport(t, stats, options = {}) {')
needle="  const summary = path.join(directory, 'summary.md');"
assert needle in text
text=text.replace(needle,needle+"\n  const backendLog = path.join(directory, 'cache server.log');\n  if (options.log !== undefined) fs.writeFileSync(backendLog, options.log);")
needle="      SCCACHE_HEALTH_LABEL: 'fixture',";assert needle in text
text=text.replace(needle,needle+"\n      FORMAL_AI_CI_VERBOSE: options.verbose ? 'true' : 'false',\n      SCCACHE_ERROR_LOG: backendLog,")
text+='''
test('backend response is retained only in opt-in diagnostics, even without statistics', t => {
  const backend='::error::untrusted backend annotation\\nbackend reserve rejected HTTP 429 https://cache.example.invalid/key?sig=fixture-secret\\n';
  const quiet=cacheWriteReport(t,{cache_writes:100,cache_write_errors:0},{log:backend});
  assert.equal(quiet.stdout,'');
  assert.equal(quiet.stderr,'');
  const verbose=cacheWriteReport(t,'',{log:backend,verbose:true});
  assert.match(verbose.stderr,/\\[sccache\\] backend reserve rejected HTTP 429 <cache-url-redacted>/u);
  assert.doesNotMatch(verbose.stderr,/fixture-secret|https:\\/\\//u);
  assert.doesNotMatch(verbose.stderr,/^::error::/mu);
  assert.match(verbose.stderr,/^\\[sccache\\] ::error::untrusted backend annotation$/mu);
  assert.equal(verbose.summary,'');
});

test('opt-in diagnostics retain a bounded log tail and preserve warning counts', t => {
  const backend='old prefix that must be excluded\\n'+'x'.repeat(100000)+'\\nmost recent backend failure\\n';
  const observed=cacheWriteReport(t,{cache_writes:1,cache_write_errors:87},{log:backend,verbose:true});
  assert.match(observed.stderr,/88 cache writes: 87 recorded errors and 1 were stored/u);
  assert.match(observed.stderr,/most recent backend failure/u);
  assert.doesNotMatch(observed.stderr,/old prefix that must be excluded/u);
  assert.ok(Buffer.byteLength(observed.stderr)<68000,'diagnostic reads at most 64 KiB, plus annotations/prefixes');
  assert.equal(observed.summary,'- Compiler cache writes (fixture): 1 stored, 87 write errors, 98% errors.\\n');
});

test('missing opt-in backend logs remain a nonfatal diagnostic', t => {
  const observed=cacheWriteReport(t,'',{verbose:true});
  assert.equal(observed.stdout,'');
  assert.equal(observed.stderr,'');
  assert.equal(observed.summary,'');
});
'''
p.write_text(text)
print('Added behavioral backend-log controls; no implementation change yet.')
