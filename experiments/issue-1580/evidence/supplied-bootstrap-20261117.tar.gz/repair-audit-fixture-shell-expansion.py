from pathlib import Path
p=Path('experiments/issue-1580/template-python-audit-integrity.test.mjs')
s=p.read_text();before='${AUDIT_FIXTURE_NPM_STATUS:-0}';assert s.count(before)==1
p.write_text(s.replace(before,'$AUDIT_FIXTURE_NPM_STATUS'))
print('Use the explicitly supplied fixture variable without JavaScript template interpolation.')
