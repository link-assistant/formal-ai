from pathlib import Path
import gzip,hashlib,json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/checks/main-merge-015a6831/final-documentation'
base.mkdir(exist_ok=False)
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='584b5f57f8d5b1ec6511def65273c78da0caca7b'
subprocess.run(['python3','/tmp/issue-1580-research/archive-round-bootstrap.py'],check=True)
subprocess.run(['python3','/tmp/issue-1580-research/archive-evidence.py'],check=True)
command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size-js-twin,check-file-size']
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
result=subprocess.run(command,env=env,capture_output=True)
raw=result.stdout+result.stderr
(base/'documentation-gates.log.gz').write_bytes(gzip.compress(raw,mtime=0))
(base/'documentation-gates.json').write_text(json.dumps({'command':command,'exitCode':result.returncode,'rawSha256':hashlib.sha256(raw).hexdigest(),'rawBytes':len(raw),'nativeExecuted':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print(raw.decode());assert result.returncode==0
subprocess.run(['git','diff','--check'],check=True)
paths=['docs/case-studies/issue-1580','experiments/issue-1580']
subprocess.run(['git','add','--',*paths],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
with Path('/tmp/issue-1580-research/verified-main-015a6831-evidence-commit.log').open('w') as stream:
    subprocess.run(['git','commit','--quiet','-m','Record merged-source validation and historical compatibility review'],stdout=stream,stderr=subprocess.STDOUT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
status=subprocess.check_output(['git','status','--short'],text=True)
print(json.dumps({'committedHead':head,'status':status,'pushed':False}))
assert not status.strip()
