from pathlib import Path

path=Path('/tmp/issue-1580-research/main-058e9bef-refresh-44174504347.log')
for number,line in enumerate(path.read_text().splitlines(),1):
    if ('with_formal_ai_argv::' in line and ('----' in line or 'panicked' in line)) or 'captured_args_without_model_catalog' in line:
        print(f'{number}: {line.split(chr(9))[-1][:400]}')
