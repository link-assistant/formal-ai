from pathlib import Path
import json, gzip, hashlib, re

base=Path('experiments/issue-1580/evidence/checks/picomatch-governed-refresh')
receipt=base/'all-local-gates.json'
if not receipt.exists():
    lines=Path('/tmp/issue-1580-research/governed-refresh-all-local-gates.log').read_text().splitlines()
    print('RUNNING','\n'.join(lines[-8:]))
    raise SystemExit(0)
value=json.loads(receipt.read_text())
print(json.dumps({key:row for key,row in value.items() if key!='gateLogs'},indent=2))
data=gzip.decompress((base/value['log']).read_bytes())
assert hashlib.sha256(data).hexdigest()==value['rawSha256']
print(data.decode())
for row in value['gateLogs']:
    raw=gzip.decompress((base/row['log']).read_bytes())
    assert hashlib.sha256(raw).hexdigest()==row['rawSha256']
print('VERIFIED_LOG_IDENTITIES',len(value['gateLogs']))
print('COUNTS',json.dumps({label:len(re.findall('^'+label+' ',data.decode(),re.M)) for label in ['PASS','SKIP','FAIL']}))
