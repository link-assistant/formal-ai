from pathlib import Path
import subprocess,gzip,json,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'rust/tests/web/default-branch-build-policy.test.mjs'
s=p.read_text();old='--test unknown_reasoning --test data_files -- --test-threads=1'
assert s.count(old)==1
s=s.replace(old,'--test unknown_reasoning --test data_files --test scheduling_contracts -- --test-threads=1')
assert "native scheduling regressions select every consumed source" not in s
s+='''

test('native scheduling regressions select every consumed source', () => {
  for (const path of ['rust/tests/unit/scheduling_contracts.rs',
    'rust/tests/unit/issue_1138_place_timezone.rs', 'rust/tests/unit/solver/issue_869_meeting_scheduling.rs',
    'rust/tests/unit/specification/spoken_hour_scheduling.rs',
    'rust/tests/unit/capability-routing/issue_1138_self_use_intent_routing.rs',
    'rust/tests/fixtures/issue-1580-calendar-clock.json', 'data/benchmarks/self-use-intent-routing.lino'])
    assert.equal(admission([path])['native-type-check'], true, path);
  for (const path of ['rust/tests/unit/unrelated.rs', 'rust/tests/fixtures/unrelated.json'])
    assert.equal(admission([path])['native-type-check'], false, path);
});
'''
p.write_text(s)
out=r/'experiments/issue-1580/evidence/checks/scheduling-native-replay';out.mkdir(exist_ok=False)
result=subprocess.run(['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',str(p.relative_to(r))],cwd=r,capture_output=True)
for label,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
 (out/('before.'+label+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
print(result.stdout.decode())
print(result.stderr.decode())
assert result.returncode!=0
assert b'# tests 26' in result.stdout and b'# pass 24' in result.stdout and b'# fail 2' in result.stdout
print('BEFORE REPRODUCED: 26 tests, 24 pass, 2 fail; policy draft only, no native execution')
