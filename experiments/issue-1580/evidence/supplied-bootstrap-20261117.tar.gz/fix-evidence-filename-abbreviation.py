from pathlib import Path
import gzip,hashlib,json,subprocess

base=Path('experiments/issue-1580/evidence/checks/csharp-changeset-collision')
old=base/'initial-spec-reporter.log.gz'; new=base/'initial-specification-reporter.log.gz'
assert old.exists() and not new.exists()
command=['node','scripts/measure-abbreviations.mjs','--check']
before=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
assert before.returncode!=0 and b'rose from 90 to 91' in before.stdout
(base/'abbreviation-before.log.gz').write_bytes(gzip.compress(before.stdout,mtime=0))
payload=old.read_bytes(); raw=gzip.decompress(payload)
subprocess.run(['git','mv','--',str(old),str(new)],check=True)
assert new.read_bytes()==payload and gzip.decompress(new.read_bytes())==raw
record={'ciHead':'0f90c0a7a3bdd77b7d31c276a180d5ee297e57f6','run':44095402201,'job':134081207267,'actualFailureLog':'experiments/issue-1580/evidence/ci/0f90c0a7a/attempt-1/44095402201.log.gz','failureLines':[7069,7965,7966,7967,7968,7988],'cause':'New preserved reporter log used the abbreviated word spec in its basename; the existing filename ratchet rose from 90 to 91. This is a real policy failure, not a checkout or runner-acquisition error.','oldPath':str(old),'newPath':str(new),'compressedSha256':hashlib.sha256(payload).hexdigest(),'rawSha256':hashlib.sha256(raw).hexdigest(),'rawBytes':len(raw),'before':{'command':command,'exitCode':before.returncode,'log':str(base/'abbreviation-before.log.gz'),'logSha256':hashlib.sha256(before.stdout).hexdigest()},'baselineChanged':False,'historicalReferences':'Immutable archived scripts and original failure logs retain the original spelling. This receipt maps that historical name to the current byte-identical file.','authorship':'Codex-supplied filename repair and checks; zero independently accepted Formal AI reasoning units.'}
(base/'abbreviation-filename-correction.json').write_text(json.dumps(record,indent=2)+'\n')
index=Path('experiments/issue-1580/evidence/checks/csharp-changeset-integrity.json'); value=json.loads(index.read_text())
value['evidenceFilenameCorrection']=str(base/'abbreviation-filename-correction.json')
index.write_text(json.dumps(value,indent=2)+'\n')
summary=Path('experiments/issue-1580/evidence/ci/0f90c0a7a/attempt-1/summary.json'); value=json.loads(summary.read_text())
value['diagnosis']={'job':134081207267,'failure':'file-names abbreviated-file-names rose from 90 to 91','lines':[7069,7965,7966,7967,7968,7988],'causeFile':str(old),'repairReceipt':str(base/'abbreviation-filename-correction.json'),'otherHeadWorkflowsPassed':23,'retryRequested':False}
summary.write_text(json.dumps(value,indent=2)+'\n')
script=Path('/tmp/issue-1580-research/run-csharp-collision-before.py'); text=script.read_text(); assert 'initial-spec-reporter.log' in text
script.write_text(text.replace('initial-spec-reporter.log','initial-specification-reporter.log'))
print(json.dumps(record,indent=2)); print('Original local check output:',before.stdout.decode())
