from pathlib import Path
import json

base = Path('/tmp/issue-1580-research/unverified-child-status')
process = json.loads((base / 'process.json').read_text())
pid = process['pid']
stat_path = Path(f'/proc/{pid}/stat')
fields = stat_path.read_text().split(') ', 1)[1].split() if stat_path.exists() else []
print(json.dumps({'pid': pid, 'state': fields[0] if fields else 'absent', 'encodedExitCode': fields[-1] if fields else None}))
progress = json.loads((base / 'progress.json').read_text()) if (base / 'progress.json').exists() else []
print(json.dumps(progress, indent=2))
for row in progress:
    if row['name'] in ['meta-executor-tests', 'factual-qa-tests', 'parity-fixture-write', 'parity-fixture-check', 'all-local-gates', 'git-diff-check']:
        path = Path(row['log'])
        text = path.read_text()
        assert len(text.splitlines()) <= 1500 and len(text.encode()) < 50000
        print(f'FULL LOG {path}\n{text}')
if (base / 'outcome.json').exists():
    outcome = json.loads((base / 'outcome.json').read_text())
    print(json.dumps({key: value for key, value in outcome.items() if key not in ['archives', 'perGateLogs', 'checks']}, indent=2))
