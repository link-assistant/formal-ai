from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
for args in [['rg','-n','mentionsCalendarCreateRequest','js/worker','rust/tests/web'],['rg','-n','calendar_create.rs|source_lines_max|outside_core_lines_max','data/meta'],['rg','-n','calendar_and_proofs','data/meta']]:print(subprocess.run(args,cwd=root,text=True,capture_output=True).stdout)
p=root/'js/worker/formal_ai_worker_calendar_and_proofs.js';lines=p.read_text().splitlines()
for i,line in enumerate(lines[800:825],801):print(f'{i}: {line}')
