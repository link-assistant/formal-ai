from pathlib import Path
import subprocess
for args in [['python3','experiments/issue-1580/archive-evidence.py'],['python3','/tmp/issue-1580-research/archive-round-bootstrap.py']]:
    subprocess.run(args,check=True)
with Path('/tmp/issue-1580-research/self-reference-checks/archive-gates.log').open('w') as log:
    checked=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-file-size-js-twin'],stdout=log,stderr=subprocess.STDOUT)
print(Path('/tmp/issue-1580-research/self-reference-checks/archive-gates.log').read_text())
assert checked.returncode==0
subprocess.run(['git','diff','--check'],check=True)
print(subprocess.check_output(['git','diff','--stat'],text=True))
print(subprocess.check_output(['git','status','--short'],text=True))
