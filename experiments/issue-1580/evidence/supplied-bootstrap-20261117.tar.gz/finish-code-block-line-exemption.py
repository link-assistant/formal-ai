import pathlib, subprocess

def replace(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)

path = pathlib.Path('rust/src/protocol/request_context.rs')
text = path.read_text()
text = replace(text, 'if fields.len() != 4', 'if fields.len() != 5')
text = replace(text, 'fields[3] == "detail"', 'fields[4] == "detail"')
text = replace(text, '''                        let comparison =
                            compare_decimals(&answer.answer.lines().count().to_string(), fields[2]);''', '''                        // An explicit code-generation exemption measures prose outside fences.
                        let measured = if fields[3] == "code" {
                            pattern(RULES["fencedCodeBlock"].as_str().unwrap())
                                .replace_all(&answer.answer, "").into_owned()
                        } else { answer.answer.clone() };
                        let comparison = compare_decimals(&measured.lines().count().to_string(), fields[2]);''')
text = replace(text, '"{}|{}|{count}|{}",', '"{}|{}|{count}|{}|{}",')
text = replace(text, 'if found[2].is_empty() { "" } else { "detail" }', 'if found[2].is_empty() { "" } else { "code" },\n                            if found[3].is_empty() { "" } else { "detail" }')
path.write_text(text)
subprocess.run(['rustfmt', '--edition', '2024', str(path)], check=True)
path = pathlib.Path('rust/tests/web/issue-1580-client-output-constraints.test.mjs')
text = path.read_text()
text = replace(text, "assert.equal(message.content.trim(), 'ALPHA_MARKER_11111\\nalpha second line');", "assert.equal(message.content, 'Contents of `alpha.txt`:\\n\\n```text\\nALPHA_MARKER_11111\\nalpha second line\\n```');")
text += '''
test('code-block line exemptions preserve file bytes and still enforce prose limits', () => {
  const compose = (instruction, text) => composeFinalAnswer([{ role: 'system', content: instruction }, { role: 'user', content: 'Show the result.' }], text, []);
  const text = 'Observed file:\\n\\n```text\\na\\nb\\nc\\nd\\n```';
  const exempt = 'Answer with fewer than 4 lines (not including tool use or code generation).';
  assert.equal(compose(exempt, text).answer, text);
  assert.match(compose('Answer with fewer than 4 lines.', text).answer, /Cannot satisfy output constraint/u);
  assert.match(compose(exempt, 'one\\ntwo\\nthree\\nfour\\n```text\\na\\nb\\n```').answer, /Cannot satisfy output constraint/u);
});
'''
path.write_text(text)
print('Completed the native twin and replay expectations after matching the rustfmt-emitted layout.')
