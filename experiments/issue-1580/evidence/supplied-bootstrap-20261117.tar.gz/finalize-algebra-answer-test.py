from datetime import datetime, timezone
from pathlib import Path
import gzip
import hashlib
import json
import os
import subprocess

base = Path('experiments/issue-1580/evidence/checks/algebra-calculation-cues')
report = json.loads((base / 'shared-inventory/results.json').read_text())
assert report['complete'], 'Complete the shared-data inventory first'
path = Path('rust/tests/web/issue-1580-algebra-substitution.test.mjs')
text = path.read_text()
marker = "    assert.equal(response.intent, 'algebra_substitution', response.content);\n"
assert text.count(marker) == 1
text = text.replace(marker, marker + "    assert.ok(response.content.endsWith('= ' + expected + '.'), response.content);\n", 1)
path.write_text(text)
print('FINAL TEST SOURCE\n' + text)
env = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
checks = []
for name, args in [
    ('answer-regressions', ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-concurrency=1', str(path)]),
    ('answer-whitespace', ['git', 'diff', '--check']),
]:
    result = subprocess.run(args, env=env, capture_output=True)
    raw = result.stdout + result.stderr
    packed = gzip.compress(raw, mtime=0)
    (base / (name + '.log.gz')).write_bytes(packed)
    row = {'name': name, 'argv': args, 'exitCode': result.returncode, 'rawLines': len(raw.splitlines()), 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest()}
    checks.append(row)
    print(json.dumps(row))
    print(raw.decode())
    if result.returncode:
        break
receipt = {'complete': len(checks) == 2 and all(row['exitCode'] == 0 for row in checks), 'observedAt': datetime.now(timezone.utc).isoformat(), 'checks': checks, 'nativeExecuted': False, 'independentAuthorshipCredit': 0}
(base / 'answer-validation.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert receipt['complete']
