import json, pathlib, subprocess

def replace(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)

path = pathlib.Path('data/meta/request-context.json')
rules = json.loads(path.read_text())
rules['lineLimit'][0] = rules['lineLimit'][0].replace(r'(?:\s+\(not including tool use or code generation\))?', r'(?:\s+(\(not including tool use or code generation\)))?')
rules['fencedCodeBlock'] = r'(?:^|\n)```[^\n]*\n[\s\S]*?\n```(?:\r?\n|$)'
text = json.dumps(rules, ensure_ascii=False, indent=2) + '\n'
path.write_text(text)
pathlib.Path('rust/embedded/data/meta/request-context.json').write_text(text)
for name in ('js/server/request-context.mjs', 'ts/server/request-context.mts'):
    path = pathlib.Path(name)
    text = path.read_text()
    text = replace(text, "lines[3] ? 'detail' : ''", "lines[3] ? 'code' : '', lines[4] ? 'detail' : ''")
    text = replace(text, 'const [kind, mode, count, exception] = item.value.split(\'|\');', 'const [kind, mode, count, code, exception] = item.value.split(\'|\');')
    text = replace(text, "        const lines = text === '' ? 0 : text.split(/\\r?\\n/u).length - Number(text.endsWith('\\n'));", """        // The explicit code-generation exemption counts prose outside fenced blocks.
        const measured = code === 'code' ? text.replace(new RegExp(rules.fencedCodeBlock, 'gu'), '') : text;
        const lines = measured === '' ? 0 : measured.split(/\\r?\\n/u).length - Number(measured.endsWith('\\n'));""")
    path.write_text(text)
path = pathlib.Path('rust/src/protocol/request_context.rs')
text = path.read_text()
print('NATIVE LINE-LIMIT CONSTRUCTOR BEFORE UPDATE')
lines = text.splitlines()
for i, line in enumerate(lines):
    if 'lineLimitKind' in line or 'fields.len()' in line or 'answer.answer.lines()' in line:
        print('\n'.join(lines[max(0, i-3):i+7]))
text = replace(text, 'if fields.len() != 4', 'if fields.len() != 5')
text = replace(text, 'fields[3] == "detail"', 'fields[4] == "detail"')
text = replace(text, '''                        let comparison = compare_decimals(
                            &answer.answer.lines().count().to_string(),
                            fields[2],
                        );''', '''                        // An explicit code-generation exemption measures prose outside fences.
                        let measured = if fields[3] == "code" {
                            pattern(RULES["fencedCodeBlock"].as_str().unwrap())
                                .replace_all(&answer.answer, "").into_owned()
                        } else { answer.answer.clone() };
                        let comparison = compare_decimals(&measured.lines().count().to_string(), fields[2]);''')
text = replace(text, 'value: format!(\n                            "{}|{}|{count}|{}",', 'value: format!(\n                            "{}|{}|{count}|{}|{}",')
text = replace(text, 'if found[2].is_empty() { "" } else { "detail" }', 'if found[2].is_empty() { "" } else { "code" },\n                            if found[3].is_empty() { "" } else { "detail" }')
path.write_text(text)
subprocess.run(['rustfmt', '--edition', '2024', str(path)], check=True)
path = pathlib.Path('rust/tests/web/issue-1580-client-output-constraints.test.mjs')
text = path.read_text()
text = replace(text, "assert.equal(message.content.trim(), 'ALPHA_MARKER_11111\\nalpha second line');", "assert.equal(message.content, 'Contents of `alpha.txt`:\\n\\n```text\\nALPHA_MARKER_11111\\nalpha second line\\n```');")
text += '''
test('code-block line exemptions preserve file bytes and still enforce prose limits', () => {
  const compose = (instruction, text) => composeFinalAnswer([{ role: 'system', content: instruction }, { role: 'user', content: 'Show the result.' }], text, []);
  const text = 'Observed file:\\n\\n```text\\na\\nb\\nc\\nd\\n```';
  const exempt = 'Answer with fewer than 4 lines (not including tool use or code generation).';
  assert.equal(compose(exempt, text).answer, text);
  assert.match(compose('Answer with fewer than 4 lines.', text).answer, /Cannot satisfy output constraint/u);
  assert.match(compose(exempt, 'one\\ntwo\\nthree\\nfour\\n```text\\na\\nb\\n```').answer, /Cannot satisfy output constraint/u);
});
'''
path.write_text(text)
print('Retained exact existing file presentation; measured the client\'s explicit fenced-code exemption rather than dropping file bytes.')
