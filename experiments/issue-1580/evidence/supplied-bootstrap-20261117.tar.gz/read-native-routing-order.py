from pathlib import Path

root=Path('/tmp/gh-issue-solver-1794900398048')
for name,ranges in [
 ('rust/src/solver.rs',[(280,450),(470,565)]),
 ('rust/src/solver_synthesis.rs',[(112,155),(260,360)]),
 ('rust/src/solver_handlers/mod.rs',[(175,260)])
]:
    lines=(root/name).read_text().splitlines()
    for lo,hi in ranges:
        print('\nFILE',name,lo,hi)
        for number in range(lo-1,min(hi,len(lines))): print(f'{number+1}: {lines[number]}')
