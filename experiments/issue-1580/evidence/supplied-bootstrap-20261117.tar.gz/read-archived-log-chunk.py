from pathlib import Path
import gzip,sys
path=Path(sys.argv[1]);first,last=map(int,sys.argv[2:])
assert 1<=first<=last and last-first<1500
data=gzip.decompress(path.read_bytes()) if path.suffix=='.gz' else path.read_bytes()
lines=data.decode(errors='replace').splitlines()
output=[]
for index in range(first,min(last,len(lines))+1):
    line=lines[index-1]
    # Workflow job and step prefixes repeat on every line; keep the timestamp.
    if '\t' in line:line=line.split('\t',2)[-1]
    output.append(f'{index}: {line}')
rendered='\n'.join(output)
assert len(rendered)<24000, f'{len(rendered)} characters: use a smaller chunk'
print(f'{path}: {len(lines)} total lines; selected {first}-{min(last,len(lines))}')
print(rendered)
