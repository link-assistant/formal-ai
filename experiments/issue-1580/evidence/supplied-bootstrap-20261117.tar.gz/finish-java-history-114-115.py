from pathlib import Path
import json
d=Path('docs/case-studies/issue-1580/templates');i=json.loads((d/'java-historical-review-index.json').read_text())
assert i['cumulativeSummary']['literalPages']==115
p=Path('experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md');s=p.read_text()
old='**113/254 continuous pages**, with 111 complete files, one partial and 7,760 source lines; pages 114–254 and wider semantic review remain open.'
assert old in s;s=s.replace(old,'**115/254 continuous pages**, with 111 complete files, one partial and 7,815 source lines; pages 116–254 and wider semantic review remain open.');p.write_text(s)
p=Path('experiments/issue-1580/work-plan.md');s=p.read_text();entry='Read and preserve Java historical pages 114–115 fully';assert entry not in s
with p.open('a') as f:f.write('\n- [x] Read and preserve Java historical pages 114–115 fully: continuous\n  1–115/254, 111 complete files, one partial and 7,815 source lines. The Node\n  catalog is read through line 236/884. Pages 116–254 and full semantic review\n  remain unfinished; no independent authorship credit.\n')
print(json.dumps(i['cumulativeSummary'],indent=2))
