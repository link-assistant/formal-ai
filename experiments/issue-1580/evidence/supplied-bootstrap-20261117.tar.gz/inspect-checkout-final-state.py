from pathlib import Path
import subprocess

root = Path.cwd()
for args in (["git", "branch", "--show-current"], ["git", "status", "--short"]):
    result = subprocess.run(args, text=True, capture_output=True, check=True)
    print(result.stdout)
for name, start, end in [
    (".github/workflows/layered-ci.yml", 290, 370),
    ("experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md", 1, 135),
    ("docs/case-studies/issue-1580/checkout-archive-checkpoint.md", 130, 230),
    ("/tmp/issue-1580-research/publish-status-main-integration.py", 1, 250),
]:
    path = Path(name)
    lines = path.read_text().splitlines()
    print(f"FILE {name} {len(lines)} lines")
    for number in range(start, min(end, len(lines)) + 1):
        print(f"{number}: {lines[number - 1]}")
