from pathlib import Path
import json

root = Path('/tmp/gh-issue-solver-1794900398048')
research = Path('/tmp/issue-1580-research')
for path in [research / 'picomatch-final-supervisor.log', root / 'experiments/issue-1580/evidence/checks/picomatch-single-branch/final-rechecks.json', research / 'picomatch-template-research/summary.json']:
    print('\nFILE', path)
    print(path.read_text() if path.exists() else 'MISSING')
for name in ['js-report.md', 'python-report.md', 'cpp-report.md']:
    path = research / 'picomatch-template-research' / name
    print('\nFILE', path)
    print(path.read_text())
for name in ['experiments/issue-1580/work-plan.md', 'docs/case-studies/issue-1580/README.md']:
    path = root / name
    lines = path.read_text().splitlines()
    print('\nTAIL', name, 'totalLines',len(lines))
    for number in range(max(0, len(lines)-120), len(lines)):
        print(f'{number+1}: {lines[number]}')
