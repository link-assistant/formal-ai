from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
path = root / 'js/worker/formal_ai_worker_arithmetic_and_numeric_lists.js'
text = path.read_text()
start = text.index('function extractRequestedAlgebraExpression(prompt) {')
end = text.index('\nfunction lastNonWhitespace', start)
before = text[start:end]
assert before.endswith('  return null;\n}\n')
after = before.replace('  return null;\n}\n', '  return extractArithmeticExpression(text)?.expression ?? null;\n}\n', 1)
path.write_text(text[:start] + after + text[end:])
path = root / 'rust/src/solver_synthesis.rs'
text = path.read_text()
start = text.index('fn extract_requested_expression(prompt: &str) -> Option<String> {')
end = text.index('\nfn clean_expression', start)
before = text[start:end]
assert before.endswith('    None\n}\n')
after = before.replace('    None\n}\n', '''    crate::calculation::calculation_expression_candidates(prompt)
        .into_iter()
        .find(|candidate| candidate.explicit && !candidate.expression.contains('='))
        .map(|candidate| candidate.expression)
}
''', 1)
path.write_text(text[:start] + after + text[end:])
path = root / 'rust/tests/unit/meta_executor_parity.rs'
text = path.read_text()
marker = '        ("Given x = 3 and y = 4, evaluate (x^2 + 2y).", "17"),\n'
assert marker in text
text = text.replace(marker, marker + '''        ("If x = 3 and y = 4, what is x*x + 2*y?", "17"),
        ("If x = 4 and y = 6, what is x*x + 2*y?", "28"),
''', 1)
path.write_text(text)
subprocess.run(['rustfmt', '--edition', '2024', 'rust/src/solver_synthesis.rs', str(path)], cwd=root, check=True)
base = root / 'experiments/issue-1580/evidence/checks/algebra-calculation-cues'
raw = (base / 'before.log').read_bytes()
packed = gzip.compress(raw, mtime=0)
(base / 'before.log.gz').write_bytes(packed)
(base / 'before.json').write_text(json.dumps({'tests': 8, 'pass': 6, 'fail': 2, 'exitCode': 1, 'rawLines': len(raw.splitlines()), 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest(), 'wholePayloadLiterallyRead': True, 'nativeExecuted': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
(base / 'before.log').unlink()
print('Updated both extractors to reuse their existing calculator cue parser; drafted five native replay cases')
