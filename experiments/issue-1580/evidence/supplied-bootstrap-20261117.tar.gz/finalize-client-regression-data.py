import json,subprocess
from pathlib import Path
p=Path('data/meta/main-only-regressions.lino')
with p.open('a') as out:
    out.write('''    regression opencode-source-envelope
      introduced-by "OpenCode path/content Read envelope (observed on main 826289fc)"
      failed "transport path/type/content tags and numbered rows leaked into the final file text"
      check rust/tests/web/source-read-provenance.test.mjs
      marker "OpenCode path-bound source envelope"
main-run 44157125186
  javascript-twin
    regression concise-greeting-refusal
      introduced-by "PR #1595, merged as 826289fc"
      failed "cli_serve_exposes_agentic_tool_protocols_over_loopback: Answer concisely replaced the Hi greeting with an output refusal"
      check rust/tests/web/issue-1580-client-output-constraints.test.mjs
      marker "main run 44157125186"
''')

# Preserve existing fixture formatting and row order; append only new coverage.
p=Path('data/parity/issue-1587-request-context.json')
original=subprocess.check_output(['git','show','HEAD:'+str(p)],text=True)
old=json.loads(original);rows=json.loads(p.read_text());assert rows[:len(old)]==old
added=rows[len(old):]
p.write_text(original.rstrip()[:-1].rstrip()+',\n'+',\n'.join('  '+json.dumps(row,ensure_ascii=False,indent=2).replace('\n','\n  ') for row in added)+'\n]\n')

# Retain the compact established rules layout while adding the new grammar.
p=Path('data/meta/request-context.json')
original=subprocess.check_output(['git','show','HEAD:'+str(p)],text=True)
old=json.loads(original);rules=json.loads(p.read_text())
lines=original.rstrip().splitlines()
for index,line in enumerate(lines):
    if line.startswith('  "language":'):
        lines[index]='  "language": '+json.dumps(rules['language'],ensure_ascii=False)+','
lines[-2]+=','
extra=[key for key in rules if key not in old]
for key in extra:
    lines.insert(-1,'  '+json.dumps(key)+': '+json.dumps(rules[key],ensure_ascii=False)+(',' if key!=extra[-1] else ''))
text='\n'.join(lines)+'\n';assert json.loads(text)==rules
for name in ['data/meta/request-context.json','rust/embedded/data/meta/request-context.json']:Path(name).write_text(text)
print(json.dumps(dict(sharedContextFixtures=len(rows),addedContextFixtures=len(added),sharedReadEnvelopeFixtures=15)))
