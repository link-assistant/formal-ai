import pathlib
import subprocess

for relative in ("scripts/check-generated-files.mjs", "experiments/formal_ai_subagent/local-gates.mjs"):
    path=pathlib.Path(relative)
    lines=path.read_text().splitlines()
    print("FILE", relative, "LINES", len(lines), flush=True)
    for number,line in enumerate(lines[:1500],1):
        print(str(number)+": "+line)
print("LARGE TRACKED FILES",flush=True)
result=subprocess.run(["git","ls-files","-z"],capture_output=True,check=True)
files=[]
for raw in result.stdout.split(b"\0"):
    if not raw:continue
    path=pathlib.Path(raw.decode())
    if path.is_file():
        size=path.stat().st_size
        if size>8*1024*1024:files.append((size,str(path)))
for size,path in sorted(files,reverse=True)[:12]:print(size,path)
