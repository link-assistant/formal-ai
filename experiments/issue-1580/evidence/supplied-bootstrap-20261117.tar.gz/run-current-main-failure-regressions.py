import json
import subprocess
import sys

targets=[
 ("quoted-passage","rust/tests/web/issue-1172-factual-qa-subject-gate.test.mjs"),
 ("connector-receipts","rust/tests/web/connector-work-item-receipts.test.mjs"),
 ("browser-release","rust/tests/web/browser-engine-release-integration.test.mjs"),
 ("resume-policy","rust/tests/web/recipe-resume-policy-notation.test.mjs"),
]
statuses=[]
for label,target in targets:
    result=subprocess.run([sys.executable,"/tmp/issue-1580-research/run-header-focused.py",label,target,"256"],capture_output=True,text=True)
    lines=result.stdout.splitlines()
    print(lines[0] if lines else result.stderr[:1000],flush=True)
    for line in lines[1:]:
        if any(token in line for token in ("ℹ pass","ℹ fail","ℹ skipped","# pass","# fail","✖","AssertionError")):print(line,flush=True)
    statuses.append(result.returncode)
print(json.dumps({"statuses":statuses}))
sys.exit(1 if any(statuses) else 0)
