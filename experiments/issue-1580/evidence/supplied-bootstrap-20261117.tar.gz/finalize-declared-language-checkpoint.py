from pathlib import Path
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
out = root / 'experiments/issue-1580/evidence/checks/declared-language-policy'
publication = json.loads((out / 'publication/outcome.json').read_text())
assert publication['complete']
pid = json.loads((out / 'publication/worker.json').read_text())['pid']
status = Path('/proc') / str(pid) / 'status'
if status.exists():
    state = next(line for line in status.read_text().splitlines() if line.startswith('State:'))
    assert '\tZ ' in state, (pid, state)
for name in ['worker.stdout.log', 'worker.stderr.log']:
    path = out / 'publication' / name
    raw = path.read_bytes()
    assert len(raw.splitlines()) <= 1500
    print(name, len(raw), hashlib.sha256(raw).hexdigest())
    print(raw.decode())
    path.with_suffix(path.suffix + '.gz').write_bytes(gzip.compress(raw, mtime=0))
    path.unlink()

path = root / 'docs/case-studies/issue-1580/declared-language-policy-checkpoint.md'
body = path.read_text()
old = 'Both complete logs were read. Affected publication gates remain pending.'
assert body.count(old) == 1
body = body.replace(old, '''Both complete logs were read. The initial nine-gate publication run passed
eight gates and rejected the first 38-line draft against the unchanged 33-line
worker ceiling. Removing single-use bindings and retaining the prior compact
style restores 33 lines without changing the limit. The eight cases pass again
on this final source; its complete log is 885 bytes, SHA-256
`c60ff6f4c6b8c1702c2ec37684c016675f738aff55f8f3373eede40fa9ea28cd`.
All six affected source gates pass after that refactor. No `data/meta` input
changes, so the full inventory is not repeated. JavaScript/Rust projection
verification passes with 49 refused modules; it does not establish full parity.''')
old = '''One failed-job retry was requested after preserving the original attempt. The
underlying transport cause and retry result are not yet verified.'''
assert body.count(old) == 1
body = body.replace(old, '''One failed-job retry was requested after preserving the original attempt.
Checkout and both JavaScript suite groups pass on attempt 2. The underlying
transport cause remains unverified; no retry loop is added.

Attempt 2 instead fails in TypeScript projection job 134558393446. All 320
direct job-log lines were read. File-set parity passes at line 290; line 302
identifies the stale `formal_ai_worker_seed_responses_and_language.ts` mirror,
and the maintained translation check fails at line 304. Its complete raw log is
24,798 bytes, SHA-256
`0683ff1370cdcc53b75bee48cff6f5904c1bc68b61611c851a29f7432e1184fa`.
Both attempt inventories, aggregate logs and direct failed logs remain separate.

The maintained `scripts/translate-es.mjs --check` locally reproduces that drift
and the additional mirror drift from this new language-policy change. Its write
mode regenerates exactly those two TypeScript files. The final check passes all
717 maintained projections, and both changed mirrors equal their JavaScript
sources byte for byte. The complete before/write/after logs are retained under
`checks/declared-language-policy/type-projection/`. Hosted verification of the
next head is still required.''')
path.write_text(body)

plan = root / 'experiments/issue-1580/work-plan.md'
plan.write_text(plan.read_text() + '''

- [x] Collect both edffcb18 Layered CI attempts and read each failed job completely: 171 checkout lines, then 320 TypeScript-projection lines. The one allowed retry passes checkout and both JavaScript groups, then identifies the stale mirror. Transport cause remains unverified.
- [x] Preserve the initial 38-line worker budget failure, restore the unchanged 33-line ceiling, pass all eight focused cases again and all six affected source gates. The other eight initial publication gates passed; no shared metadata changes.
- [x] Reproduce both TypeScript mirror drifts, regenerate only those files through the maintained translator and pass its 717-file check. No native execution or full language-parity claim.
- [ ] Review, seal and publish the complete batch once; verify all workflows on its new head. All earlier broad unchecked requirements remain unfinished.
''')
fragment = root / 'changelog.d/20261117_120000_issue-1580-ci-regressions.md'
text = fragment.read_text()
old = '- Use the declared answer-language policy for unresolved JavaScript requests, retaining the full localized failure report and actual detected-language trace.'
assert text.count(old) == 1
fragment.write_text(text.replace(old, old + '\n- Regenerate the maintained TypeScript opener and unresolved-language mirrors to restore projection checks.'))

# Page 39 was literally read in the preceding session. Record only its actual
# fragments: no new complete source line or file is implied by this page.
source = (scratch / 'record-java-pages-61-64-generated.py').read_text()
source = source.replace('previous = list(range(1, 39)) + list(range(48, 61))', 'previous = list(range(1, 39)) + list(range(48, 65))')
source = source.replace('pages = previous + [61, 62, 63, 64]', 'pages = sorted(previous + [39])')
start = source.index("review['observationsThroughPage64'] = [")
end = source.index('target.write_text', start)
source = source[:start] + '''review['observationsPage39'] = [
    'Page 39 was fully read: retained osv-scope-reproduction.log line 2 fragments 10–15 of 66, covering historical Log4j advisory and affected-package records. This is historical review, not current execution or security advice.',
    'The long second source line is still incomplete; this page adds no complete source line or file. Pages 40–47 and forward pages 65–254 remain unread.',
]
''' + source[end:]
source = source.replace("'unreadGap': [39,47]", "'unreadGap': [40,47]")
exec(compile(source, 'record-java-page-39-generated.py', 'exec'), {'__name__': '__main__'})

original = (scratch / 'opener-boundary-pull-request-description.md').read_text()
intro = '''The latest local correction uses the declared answer-language metadata for terminal unresolved JavaScript requests. The complete original Spanish how-question body and a held-out metadata control fail before the change; all eight focused cases pass afterward. The unchanged 33-line worker ceiling and all six affected source gates pass. The maintained translator regenerates two TypeScript mirrors and its 717-file check passes.

On published `edffcb18`, 22 workflows pass and Layered CI fails. One bounded retry gets past the initial checkout failure and exposes TypeScript drift; both complete failed job logs are retained and read (171 and 320 lines). This batch corrects the projection drift. Checkout transport cause remains unverified, and the next head still needs hosted verification. The [declared-language checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/declared-language-policy-checkpoint.md) records reproduction, tests and limits. Native execution and the original adopted Spanish definition route remain unfinished; PR #1581 stays draft.

'''
original = original.replace('The latest correction fixes both Layered CI failures', 'The preceding correction fixes both Layered CI failures', 1)
original = original.replace('pages 1–38 and 48–64/254, 65 complete files and two partials', 'pages 1–39 and 48–64/254, 65 complete files and two partials')
assert 'Fixes #1580' in original
(scratch / 'declared-language-pull-request-description.md').write_text(intro + original)
print('Updated checkpoint, plan, patch fragment, literal Java page coverage and reviewable PR body. Broad acceptance remains unfinished.')
