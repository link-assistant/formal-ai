from pathlib import Path
import subprocess,os,time,hashlib,json,gzip
root=Path("experiments/issue-1580/evidence/checks/calendar-clock-preservation")
env=dict(os.environ)
env["NODE_OPTIONS"]="--max-old-space-size=256"
env["PATH"]="/tmp/issue-1580-research/shellcheck-v0.11.0:"+env["PATH"]
commands=[
 ("clock-noops-tests",["timeout","600","node","--test","--test-concurrency=1","rust/tests/web/calendar-clock-preservation.test.mjs"]),
 ("clock-noops-format",["rustfmt","--check","--edition","2024","rust/src/solver_handlers/calendar_create.rs"]),
 ("clock-noops-projection",["node","scripts/translate-js-rust.mjs","--verify"]),
]
for name in ["check-minimal-core-boundary-js-twin","check-minimal-core-boundary","check-worker-line-budget-js-twin","check-worker-line-budget","lint-shell-scripts"]:
 commands.append((name+"-recheck",["node","experiments/formal_ai_subagent/local-gates.mjs","--only",name]))
results=[]
for label,args in commands:
 started=time.monotonic()
 r=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 raw=r.stdout
 (root/(label+".log.gz")).write_bytes(gzip.compress(raw,mtime=0))
 row={"name":label,"status":r.returncode,"command":args,"durationSeconds":round(time.monotonic()-started,3),"rawSha256":hashlib.sha256(raw).hexdigest()}
 results.append(row)
 (root/"source-recheck.json").write_text(json.dumps(results,indent=2)+"\n")
 print(json.dumps(row),flush=True)
 if r.returncode:
  print(raw.decode(errors="replace"));raise SystemExit(r.returncode)
