from pathlib import Path
import gzip,re
p=Path('experiments/issue-1580/evidence/ci/native-routing-cancellation-1388db55/job-135757374368.stdout.gz');lines=gzip.decompress(p.read_bytes()).decode().splitlines();passed=failed=0
for i,l in enumerate(lines,1):
 if re.search(r'test result:|Running (unittests|tests/)|running [0-9]+ tests',l):
  print(i,l.split('\t')[-1]);m=re.search(r'test result: \w+\. (\d+) passed; (\d+) failed;',l)
  if m:passed+=int(m[1]);failed+=int(m[2])
print('TOTAL',passed,failed)
