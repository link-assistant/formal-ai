from pathlib import Path
import subprocess,gzip,hashlib,json,os,re
root=Path.cwd();p=root/'rust/tests/web/default-branch-build-policy.test.mjs';s=p.read_text();assert 'Hive workflow replay keeps every consumed fixture in native admission'not in s
s+='''\n\ntest('Hive workflow replay keeps every consumed fixture in native admission', {timeout:15000}, () => {
  const modules = ['issue_1133_hive_mind_three_runs.rs',
    'issue_1133_hive_mind_three_runs/extended.rs', 'issue_1066_ladder_capability/tool_workspace.rs'];
  const fixtures = ['atomic-record-append.rs', 'observed-plan-tools.rs',
    'commit-cue-masking.rs', 'hive-workflow-original-task.json'];
  for (const path of [...modules.map(path => 'rust/tests/unit/' + path),
    ...fixtures.map(path => 'rust/tests/fixtures/' + path),
    'rust/src/agentic_coding/work_item_steps.rs', 'data/meta/work-item-steps.lino'])
    assert.equal(admission([path])['native-type-check'], true, path);
  assert.equal(admission(['rust/tests/fixtures/unrelated-hive-task.json'])['native-type-check'], false);
  const source = read('rust/tests/unit/reasoning_contracts.rs');
  for (const path of [modules[0], modules[2], '../fixtures/observed-plan-tools.rs',
    '../../src/agentic_coding/work_item_steps.rs'])
    assert(source.includes('#[path = "' + path + '"]'), path);
  assert(read('rust/tests/unit/' + modules[0]).includes('mod extended;'));
});
'''
p.write_text(s)
base=root/'experiments/issue-1580/evidence/checks/hive-native-admission';base.mkdir(exist_ok=False)
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256');r=subprocess.run(['timeout','600','node','--test','--test-concurrency=1',str(p.relative_to(root))],env=env,capture_output=True);raw=r.stdout+r.stderr;packed=gzip.compress(raw,mtime=0);(base/'before.log.gz').write_bytes(packed)
text=raw.decode();assert r.returncode!=0 and re.search(r'[ℹ#] pass 46\b',text)and re.search(r'[ℹ#] fail 1\b',text),text[-6000:]
(base/'before.json').write_text(json.dumps({'expectedFailure':True,'exitCode':r.returncode,'javascriptPassed':46,'failed':1,'file':'before.log.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'nativeExecuted':False,'independentAuthorshipCredit':0},indent=2)+'\n');print(text[-2400:])
