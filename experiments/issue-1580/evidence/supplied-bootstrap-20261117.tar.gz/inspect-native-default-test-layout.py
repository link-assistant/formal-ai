from pathlib import Path
import subprocess
files=subprocess.check_output(['rg','--files','rust','scripts'],text=True).splitlines()
print('\n'.join(p for p in files if any(x in p for x in ['1582','unit-shard','unit-test','run-test-suite'])))
for name in ['CONTRIBUTING.md','AGENTS.md']:
 p=Path(name);lines=p.read_text().splitlines()
 selected=set()
 for i,line in enumerate(lines):
  if any(x in line.lower() for x in ['native','pull request','rust-only','local rust']):
   selected.update(range(max(0,i-2),min(len(lines),i+4)))
 print('FILE',name,'TOTAL',len(lines))
 for i in sorted(selected):print(str(i+1)+': '+lines[i])
