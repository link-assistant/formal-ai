from pathlib import Path
import subprocess,hashlib,json,gzip,datetime,os
out=Path('experiments/issue-1580/evidence/checks/php-release-guard');out.mkdir(parents=True,exist_ok=True)
checks=[('focused-tests',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/template-php-release-integrity.test.mjs']),
('maintained-tests',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs']),
('affected-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size-js-twin,check-file-size,changelog,abbreviations']),
('whitespace',['git','diff','--check'])]
results=[]
for name,command in checks:
    env={**os.environ,'PATH':'/home/box/.local/bin:'+os.environ['PATH']}
    raw=out/(name+'.log')
    with raw.open('wb') as stream:result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,env=env)
    payload=raw.read_bytes();archive=gzip.compress(payload,mtime=0)
    (out/(name+'.log.gz')).write_bytes(archive);raw.unlink()
    receipt={'name':name,'command':command,'exitCode':result.returncode,'bytes':len(payload),'lines':len(payload.splitlines()),'sha256':hashlib.sha256(payload).hexdigest(),'archiveSha256':hashlib.sha256(archive).hexdigest()}
    results.append(receipt)
    (out/'results.json').write_text(json.dumps({'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':results,'complete':len(results)==len(checks) and all(item['exitCode']==0 for item in results),'nativeExecution':False,'hostedPublication':False,'independentAuthorshipCredit':0},indent=2)+'\n')
    print(json.dumps(receipt),flush=True)
