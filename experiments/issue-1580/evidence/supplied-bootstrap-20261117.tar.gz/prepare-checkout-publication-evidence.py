from pathlib import Path
import json,subprocess
base=Path('experiments/issue-1580/evidence/checks/fast-source-archive-checkout')
v=json.loads((base/'touched-gates/outcome.json').read_text());assert all(r['exitCode']==0 for r in v['gates']) and v['runnerLabels']['exitCode']==0
p=Path('docs/case-studies/issue-1580/checkout-archive-checkpoint.md');s=p.read_text();anchor='## Java historical comparison\n';assert anchor in s
s=s.replace(anchor,'''The required deployed staged-release check initially rejects the stale canonical
source after the checkout change. Refresh that non-release job through the
maintained generator. All 52 staged operations, 104 bindings and the deployed
staged workflow remain byte-for-byte unchanged; only the canonical source hash
changes in the packet. The deployed projection check then passes. Seven touched
local gates and the pinned-runner check pass; the stage transition regression
is recorded separately.

'''+anchor);p.write_text(s)
p=Path('experiments/issue-1580/work-plan.md');p.write_text(p.read_text()+'''

The required deployed-stage check catches the stale canonical copy. Refresh
only the Fast Linux source job using the maintained generator, preserve every
one of 52 release operations and 104 bindings, and verify the unchanged staged
workflow bytes. The deployed projection and all seven touched gates pass;
pinned runner labels also pass. No data/meta source changes in this round.
''')
print('ARCHIVE TOOLS')
for name in ['archive-round-bootstrap.py','archive-evidence.py']:
 p=Path('/tmp/issue-1580-research')/name;print(name,'exists',p.exists())
 if p.exists():
  for n,line in enumerate(p.read_text().splitlines()[:65],1):print(f'{n}: {line}')
print('STATUS')
print(subprocess.check_output(['git','status','--short'],text=True))
