from pathlib import Path
import base64, datetime, hashlib, json, re, subprocess

root=Path('/tmp/issue-1580-research/picomatch-template-research')
out=root/'publication-preflight'
out.mkdir(exist_ok=True)
head='83882c0ec7c26b28dc8ac274fada2b39d9dc3a67'
expected=json.loads((root/'draft-heads.json').read_text())
summary=json.loads((root/'summary.json').read_text())
def api(endpoint):
    result=subprocess.run(['gh','api',endpoint,'--paginate','--slurp'],text=True,capture_output=True,check=True)
    return result.stdout,json.loads(result.stdout)
rows=[]
for language in ['js','python','cpp']:
    repository='link-foundation/'+language+'-ai-driven-development-pipeline-template'
    raw,pages=api('repos/'+repository)
    default=pages[0]['default_branch']
    raw,pages=api('repos/'+repository+'/commits/'+default)
    current=pages[0]['sha']
    assert current==expected[language],(language,current,expected[language])
    raw,pages=api('repos/'+repository+'/issues?state=all&per_page=100')
    (out/(language+'-all-issues.json')).write_text(raw)
    inventory_hash=hashlib.sha256(raw.encode()).hexdigest()
    items=[item for page in pages for item in page]
    previous=json.loads((root/(language+'-all-issues.json')).read_text())
    previous=[item for page in previous for item in page] if previous and isinstance(previous[0],list) else previous
    old={item['number']:item for item in previous}
    changes=[item for item in items if item['number'] not in old or any(item.get(key)!=old[item['number']].get(key) for key in ['title','body'])]
    candidates=[item for item in items if re.search(r'picomatch|112366|fc5q|single.branch.{0,30}extglob',str(item.get('title',''))+'\n'+str(item.get('body','')),re.I)]
    print(language,'default',default,'head',current,'items',len(items),'new/changed',len(changes),'duplicate candidates',len(candidates))
    for item in candidates:print('DUPLICATE CANDIDATE',item['html_url'],item['title'],item.get('body'))
    assert not candidates,'Read and resolve possible duplicate before filing.'
    for item in summary['locks']:
        if item['repository']!=repository:continue
        raw,pages=api('repos/'+repository+'/contents/'+item['path']+'?ref='+current)
        assert pages[0]['sha']==item['gitBlob']
    rows.append({'language':language,'repository':repository,'defaultBranch':default,'head':current,'issueInventoryCount':len(items),'newOrChangedBodies':len(changes),'duplicateCandidates':len(candidates),'inventoryRawSha256':inventory_hash})
for relative in ['experiments/issue-1580/evidence/checks/picomatch-template-locks/index.json','experiments/issue-1580/evidence/checks/picomatch-template-locks/summary.json.gz','packages/picomatch-compat/lib/extglob-guard.js']:
    raw,pages=api('repos/link-assistant/formal-ai/contents/'+relative+'?ref='+head)
    data=base64.b64decode(pages[0]['content'])
    assert data==Path(relative).read_bytes(),relative
    print('IMMUTABLE HOSTED BYTES VERIFIED',relative,hashlib.sha256(data).hexdigest())
raw,pages=api('advisories/GHSA-fc5q-39xc-vjpf')
(out/'advisory.json').write_text(raw)
print('ADVISORY PATCHED',[(item['package']['name'],item.get('first_patched_version')) for item in pages[0]['vulnerabilities']])
assert all(item.get('first_patched_version') is None for item in pages[0]['vulnerabilities'])
result=subprocess.run(['npm','view','picomatch','version','--json'],text=True,capture_output=True,check=True)
(out/'registry-version.json').write_text(result.stdout)
assert json.loads(result.stdout)=='4.0.7',result.stdout
value={'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'evidenceCommit':head,'repositories':rows,'allChecksPassed':True,'autonomousAuthorshipCredit':0}
(out/'summary.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value,indent=2))
