from pathlib import Path

path = Path('experiments/issue-1580/trace-passage-routing.mjs')
source = path.read_text()
source = source.replace("const worker = createWorkerContext();", "const mode = process.argv[3] || 'guarded';\nif (!['guarded', 'allow-candidate-research', 'standalone-research'].includes(mode)) throw new Error('invalid mode');\nconst worker = createWorkerContext();")
source = source.replace("const prompt = 'Read this and answer:", "if (mode === 'allow-candidate-research') {\n  // Negative control: undo only the existing speculative-research option.\n  await evaluate(worker, `const guardedSolveImpl = solveImpl; solveImpl = (...args) => {\n    args[5] = { ...args[5], metaSubTask: false }; return guardedSolveImpl(...args);\n  };`);\n}\nconst passage = 'Read this and answer:")
source = source.replace("const answer = plain(await worker.solve(prompt, [], {}, {}, [], {}));", "const prompt = mode === 'standalone-research' ? 'where is the meeting?' : passage;\nconst answer = plain(await worker.solve(prompt, [], {}, {}, [], {}));")
source = source.replace("label, head:", "label, mode, head:")
source = source.replace("writeFileSync(`${base}/${label}.json.gz`, gzipSync(raw));", "writeFileSync(`${base}/${label}.json.gz`, gzipSync(raw), { flag: 'wx' });")
path.write_text(source)
print(f'Updated supplied probe {path}; production source unchanged.')
