from pathlib import Path
import subprocess
def old(stage,path):
    return subprocess.run(["git","show",f":{stage}:{path}"],capture_output=True,text=True,check=True).stdout
path=".cargo/audit.toml"
source=old(2,path)
source=source.replace('report = "https://github.com/chronotope/chrono/issues/1768"','report = "https://github.com/link-foundation/command-stream/issues/238"')
needle="#   The maintainer's linked deprecation report confirms the upstream state.\n"
replacement=(
 "#   The maintainer's deprecation report confirms the upstream state:\n"
 "#   https://github.com/chronotope/chrono/issues/1768\n"
 "#   Migration is reported to both dependency owners:\n"
 "#   https://github.com/link-foundation/command-stream/issues/238\n"
 "#   https://github.com/link-assistant/calculator/issues/265\n"
)
assert source.count(needle)==1
source=source.replace(needle,replacement)
needle="#   entry records the blocker and does not claim a dependency migration.\n"
assert source.count(needle)==1
source=source.replace(needle,needle+"#   Vulnerabilities, unsoundness, yanked releases and every other warning remain fatal.\n")
assert source.count('# RUSTSEC-2026-0543 blocked-upstream =')==1
Path(path).write_text(source)
path="data/meta/worker-line-budget/formal_ai_worker_obligations.lino"
ours,theirs=old(2,path),old(3,path)
assert "  ceiling 488\n" in ours and "  ceiling 488\n" in theirs
Path(path).write_text(ours)
print("Reconciled one exact Chrono proof with all three reports and retained the agreed 488-line ceiling with its existing source explanation.")
