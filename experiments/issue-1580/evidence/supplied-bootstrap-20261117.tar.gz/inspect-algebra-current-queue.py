from pathlib import Path
import subprocess,json,gzip,datetime
out=Path('experiments/issue-1580/evidence/ci/algebra-acb9fa51/queue-observation-current');out.mkdir(parents=True,exist_ok=True)
head='acb9fa51085c8ba88ff8fae006b45698d355921e'
cmd=['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','5','--json','databaseId,workflowName,status,conclusion,createdAt,updatedAt,headSha']
r=subprocess.run(cmd,capture_output=True);assert r.returncode==0,r.stderr.decode()
(out/'recent-runs.json.gz').write_bytes(gzip.compress(r.stdout,mtime=0))
print(r.stdout.decode())
records=[]
for run in [44295294921,44295294376]:
    r=subprocess.run(['gh','api',f'repos/link-assistant/formal-ai/actions/runs/{run}/jobs?per_page=100','--paginate','--slurp'],capture_output=True)
    assert r.returncode==0,r.stderr.decode()
    (out/(str(run)+'-jobs.json.gz')).write_bytes(gzip.compress(r.stdout,mtime=0))
    jobs=[item for page in json.loads(r.stdout) for item in page['jobs']]
    for job in jobs:
        row={key:job.get(key) for key in ['name','status','conclusion','started_at','completed_at','runner_name','labels']}
        row['run']=run;records.append(row)
print(json.dumps(records,indent=2))
(out/'summary.json').write_text(json.dumps({'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'jobs':records,'allRunsComplete':False},indent=2)+'\n')
