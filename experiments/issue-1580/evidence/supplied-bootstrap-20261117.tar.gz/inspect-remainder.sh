set -eu
ps -eo pid,ppid,rss,etimes,args | rg 'local-gates|check-source-model|meta-language|finish-remaining' | head -n 15
tail -n 8 experiments/formal_ai_subagent/sandboxes/gates/layered-ci_4.log
tail -n 4 /tmp/issue-1580-research/all-local-gates-third.log
sed -n '200,300p' experiments/formal_ai_subagent/local-gates.mjs
