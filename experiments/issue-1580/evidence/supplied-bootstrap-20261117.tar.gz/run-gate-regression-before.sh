set -eu
timeout 600 node --test --test-concurrency=1 rust/tests/web/pull-request-1188-subagent-folder.test.mjs > /tmp/issue-1580-research/gate-selection-before.log 2>&1
