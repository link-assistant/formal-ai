from pathlib import Path
import datetime, gzip, hashlib, json, subprocess

root=Path('/tmp/issue-1580-research/picomatch-template-research')
preflight=root/'publication-preflight'
proof=json.loads((preflight/'summary.json').read_text())
assert proof['allChecksPassed']
head='83882c0ec7c26b28dc8ac274fada2b39d9dc3a67'
assert proof['evidenceCommit']==head
assert (datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(proof['capturedAt'])).total_seconds()<900
corrections=[]
for item in proof['repositories']:
    real=hashlib.sha256((preflight/(item['language']+'-all-issues.json')).read_bytes()).hexdigest()
    if item['inventoryRawSha256']!=real:
        corrections.append({'language':item['language'],'incorrectlyLabelledLockResponseSha256':item['inventoryRawSha256'],'inventoryRawSha256':real})
        item['inventoryRawSha256']=real
if corrections:
    (preflight/'initial-summary-inventory-hash-label-error.json').write_text((preflight/'summary.json').read_text())
    proof['inventoryHashCorrection']={'reason':'The initial summary hashed the later lockfile API response under the inventory label. Corrected from the retained unchanged raw inventory bytes; duplicate/source checks are unaffected.','corrections':corrections}
    (preflight/'summary.json').write_text(json.dumps(proof,indent=2)+'\n')
out=Path('experiments/issue-1580/evidence/checks/picomatch-template-locks/publication')
out.mkdir(exist_ok=True)
rows=[]
for path in sorted(preflight.glob('*.json')):
    data=path.read_bytes()
    name=path.name+'.gz'
    (out/name).write_bytes(gzip.compress(data,mtime=0))
    rows.append({'file':name,'rawSha256':hashlib.sha256(data).hexdigest(),'rawBytes':len(data)})
(out/'index.json').write_text(json.dumps({'files':rows,'autonomousAuthorshipCredit':0},indent=2)+'\n')
registry_path=Path('experiments/issue-1580/upstream/template-report-identities.json')
registry=json.loads(registry_path.read_text())
filed_path=Path('experiments/issue-1580/upstream/filed-issues.txt')
titles={
    'js':'Security audit fails on the picomatch single-branch ReDoS advisory in both npm locks',
    'python':'Artifact-action development lock fails npm audit for picomatch single-branch ReDoS',
    'cpp':'Release npm audit rejects locked picomatch under GHSA-fc5q-39xc-vjpf',
}
posted=[]
for language in ['js','python','cpp']:
    repository='link-foundation/'+language+'-ai-driven-development-pipeline-template'
    body=(root/(language+'-report.md')).read_text().replace('PUBLISHED_EVIDENCE_URL','[template lock audits](https://github.com/link-assistant/formal-ai/tree/'+head+'/experiments/issue-1580/evidence/checks/picomatch-template-locks), [bounded parser reproduction and backport](https://github.com/link-assistant/formal-ai/tree/'+head+'/experiments/issue-1580/evidence/checks/picomatch-single-branch)')
    assert 'PUBLISHED_EVIDENCE_URL' not in body
    body_path=Path('experiments/issue-1580/upstream')/(language+'-picomatch-security-report.md')
    body_path.write_text(body)
    existing=next((item for item in registry if item['repository']==repository and item['title']==titles[language]),None)
    if existing:
        url=existing['url']
    else:
        result=subprocess.run(['gh','issue','create','--repo',repository,'--title',titles[language],'--body-file',str(body_path)],text=True,capture_output=True,check=True)
        url=result.stdout.strip()
        assert url.startswith('https://github.com/'+repository+'/issues/'),url
        registry.append({'repository':repository,'title':titles[language],'url':url,'bodyFile':body_path.name,'evidenceCommit':head})
        registry_path.write_text(json.dumps(registry,indent=2)+'\n')
        listed=filed_path.read_text() if filed_path.exists() else ''
        if url not in listed.splitlines():filed_path.write_text(listed.rstrip('\n')+'\n'+url+'\n')
    result=subprocess.run(['gh','issue','view',url,'--json','number,title,body,url,createdAt'],text=True,capture_output=True,check=True)
    metadata=json.loads(result.stdout)
    assert metadata['body'].rstrip('\n')==body.rstrip('\n'), 'Posted body differs.'
    exact=metadata['body'].encode()
    (out/(language+'-posted-body.md')).write_bytes(exact)
    (out/(language+'-posted-metadata.json')).write_text(result.stdout)
    item={'language':language,'repository':repository,'url':url,'evidenceCommit':head,'preparedBodySha256':hashlib.sha256(body.encode()).hexdigest(),'postedBodySha256':hashlib.sha256(exact).hexdigest(),'createdAt':metadata['createdAt']}
    posted.append(item)
    (out/'posted-reports.json').write_text(json.dumps({'reports':posted,'autonomousAuthorshipCredit':0},indent=2)+'\n')
    print('FILED',json.dumps(item))
paragraph='\nThe reproduced picomatch dependency-gate failures are filed in '+', '.join(item['url'] for item in posted)+'. Immediately before filing, the complete current issue/PR inventories contain 306/159/35 entries with no changed bodies or matching advisory reports; all three default heads and all four lock Git blobs match the audited inputs. Hosted evidence bytes are verified at immutable commit '+head+'. Exact posted bodies, hashes, metadata and duplicate/source preflight responses are retained under evidence/checks/picomatch-template-locks/publication/. These reports do not repair the templates or establish runtime reachability. Wider acceptance remains unfinished and supplied work earns zero independent authorship credit.\n'
for name in ['experiments/issue-1580/work-plan.md','docs/case-studies/issue-1580/README.md']:
    path=Path(name)
    if 'The reproduced picomatch dependency-gate failures are filed in ' not in path.read_text():path.write_text(path.read_text()+paragraph)
print('ALL THREE REPORTS FILED; NO PUSH DURING CURRENT CI RUNS')
