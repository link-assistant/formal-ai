from pathlib import Path
import json
base=Path('experiments/issue-1580/evidence/checks/javascript-archive-checkout')
worker=json.loads((base/'sparse-worker.json').read_text())
status=Path(f"/proc/{worker['pid']}/stat")
rows=[]
for line in Path(worker['stdout']).read_text().splitlines():
    try:row=json.loads(line)
    except json.JSONDecodeError:continue
    if 'argv' in row:rows.append({k:row[k] for k in ['name','exitCode','seconds','log']})
receipt=base/'sparse-regressions.json'
print(json.dumps({'pid':worker['pid'],'processState':status.read_text().split()[2] if status.exists() else 'exited','completedCommands':rows,'receiptPresent':receipt.exists(),'stderr':Path(worker['stderr']).read_text(),'memoryEvents':Path('/sys/fs/cgroup/memory.events').read_text()},indent=2))
