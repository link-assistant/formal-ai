from pathlib import Path
import subprocess,gzip,hashlib,json,os,re
root=Path.cwd();checks=root/'experiments/issue-1580/evidence/checks';base=checks/'offline-research-catalog-final-validation';report=json.loads((base/'result.json').read_text());assert not report['complete']
# Preserve the original aggregate failure and every payload, changing only archived names.
for folder in ['offline-research-catalog-validation','offline-research-catalog-final-validation']:
 directory=checks/folder;p=directory/'result.json';r=json.loads(p.read_text());old='gate-check-tests-as-docs.log.gz';new='gate-check-tests-as-documentation.log.gz';assert(directory/old).exists();before=(directory/old).read_bytes();(directory/old).rename(directory/new);assert(directory/new).read_bytes()==before
 for x in r['gates']:
  if x['file']==old:x['file']=new
 p.write_text(json.dumps(r,indent=2)+'\n')
verified=0
for folder in ['offline-research-catalog-validation','offline-research-catalog-final-validation']:
 directory=checks/folder;r=json.loads((directory/'result.json').read_text())
 for x in r['checks']+r['gates']:
  z=(directory/x['file']).read_bytes();assert hashlib.sha256(z).hexdigest()==x['archiveSha256'];assert hashlib.sha256(gzip.decompress(z)).hexdigest()==x['rawSha256'];verified+=1
report=json.loads((base/'result.json').read_text())
for name,digest in report['sources'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for x in report['checks']:
 if x['name']!='all-gates':assert x['exitCode']==0,x
logs=gzip.decompress((base/next(x for x in report['checks']if x['name']=='all-gates')['file']).read_bytes()).decode();counts={k:len(re.findall('^'+k+' ',logs,re.M))for k in ['PASS','FAIL','SKIP']};assert counts=={'PASS':86,'FAIL':1,'SKIP':52},counts;assert re.findall(r'^FAIL (\S+)',logs,re.M)==['check-abbreviations']
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256');r=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations'],env=env,capture_output=True);raw=r.stdout+r.stderr;z=gzip.compress(raw,mtime=0);(base/'abbreviation-recheck.log.gz').write_bytes(z);assert r.returncode==0,raw.decode();verified+=1
js=0
for x in report['checks']:
 if x['name']in ['policy','focused-map']:
  t=gzip.decompress((base/x['file']).read_bytes()).decode();assert not re.search(r'(?:#|ℹ) fail [1-9]',t);n=re.findall(r'(?:#|ℹ) pass (\d+)',t);assert n;js+=int(n[-1])
assert js==54
final={'complete':True,'baseHead':report['baseHead'],'javascriptPassed':js,'fullGateInventory':139,'rawFinalInventory':counts,'gatesPassedAfterRecheck':87,'explicitGateExclusions':52,'allAggregateAndDetailedPayloadHashesVerified':verified,'sourceHashes':report['sources'],'nativeExecuted':False,'nativeFixtureSourceHead':'3c52b7f528b5f477ba04de297eb02bb41c298c78','freshNativeFixtureReplayPending':True,'abbreviationRecheck':{'file':'abbreviation-recheck.log.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(z).hexdigest()},'fullIssueComplete':False,'independentAuthorshipCredit':0}
(base/'final-result.json').write_text(json.dumps(final,indent=2)+'\n');print(json.dumps({k:v for k,v in final.items()if k!='sourceHashes'},indent=2))
