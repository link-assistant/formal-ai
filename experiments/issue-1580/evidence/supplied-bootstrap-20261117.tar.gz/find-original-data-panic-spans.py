from pathlib import Path
import gzip,hashlib,json
base=Path('experiments/issue-1580/evidence/ci/main-015a6831/individual-native-failed-jobs')
print('FILES',len(list(base.glob('*'))))
names=['meaning_slugs_are_globally_unique','seed_lino_values_never_pipe_pack_multi_values','lino_data_files_are_parseable_human_readable_and_bounded']
for p in sorted(base.glob('*.gz')):
 raw=gzip.decompress(p.read_bytes())
 lines=raw.decode(errors='replace').splitlines()
 indices=[i for i,line in enumerate(lines) if any(name in line for name in names)]
 if not indices:continue
 print('FILE',p,'SHA',hashlib.sha256(raw).hexdigest(),'LINES',len(lines),'HITS',indices)
 for i in indices:
  if 'panicked' not in lines[i] and not any('panicked' in s for s in lines[i:i+3]):continue
  for n in range(max(0,i-1),min(len(lines),i+8)):print(f'{n+1}: {lines[n][:1200]}')
root=Path('experiments/issue-1580/evidence/ci/main-015a6831')
print('CANDIDATE_LOGS',json.dumps([str(p) for p in root.glob('**/*') if p.is_file() and any(s in p.name for s in ['inventory','panics','failure','manifest'])][:30]))
