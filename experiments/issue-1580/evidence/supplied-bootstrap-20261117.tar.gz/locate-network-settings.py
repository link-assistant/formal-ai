import os
import subprocess

for key in ['FORMAL_AI_OFFLINE', 'FORMAL_AI_LIVE_FETCH', 'NODE_OPTIONS']:
    print(f'{key}={os.environ.get(key)!r}')
subprocess.run(['rg', '-n', 'FORMAL_AI_OFFLINE|FORMAL_AI_LIVE_FETCH|networkFetch|liveFetch|live_fetch', 'js/worker', 'js/server/worker-host.mjs', 'rust/tests/web/support', 'experiments/issue-1580/formal-command.mjs'], check=True)
