from pathlib import Path
import gzip,hashlib,json,subprocess

directory=Path('experiments/issue-1580/evidence/checks/python-release-formatting')
path=Path('rust/tests/web/fast-pull-request-production-profile.test.mjs')
source=path.read_text();boundary="'github-json-observation','self-authored-publication-source','hive-pre-effect-deferral',"
assert source.count(boundary)==1
path.write_text(source.replace(boundary,boundary+"'javascript-audit-inventory',"))
command=['timeout','600','node','--max-old-space-size=96','--test','--test-concurrency=1','--test-name-pattern=fast inventory retains',str(path)]
result=subprocess.run(command,capture_output=True)
raw=result.stdout+result.stderr
(directory/'fast-inventory-before.log.gz').write_bytes(gzip.compress(raw,mtime=0))
assert result.returncode==1 and b'javascript-audit-inventory' in raw,raw.decode(errors='replace')
metadata={'command':command,'status':result.returncode,'expectedFailure':True,'rawSha256':hashlib.sha256(raw).hexdigest(),'log':'fast-inventory-before.log.gz'}
(directory/'fast-inventory-before.json').write_text(json.dumps(metadata,indent=2)+'\n')
manifest_path=Path('data/benchmarks/fast-pull-request-javascript-tests.json')
manifest=json.loads(manifest_path.read_text());name='rust/tests/web/javascript-audit-inventory.test.mjs'
assert name not in manifest['files'];manifest['files'].append(name)
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(metadata));print(raw.decode(errors='replace'))
print('Added the unchanged ten-case audit suite to the explicit fast pull-request inventory.')
