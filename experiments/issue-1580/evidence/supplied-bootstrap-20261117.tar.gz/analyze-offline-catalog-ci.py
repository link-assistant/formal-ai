from pathlib import Path
import json,gzip,re,hashlib
folder=Path('experiments/issue-1580/evidence/ci/offline-catalog-cf22c611')
records=json.loads((folder/'records.json').read_text())
for r in records:
 for stream in ['stdout','stderr']:
  desc=r[stream];data=(folder/desc['file']).read_bytes();raw=gzip.decompress(data)
  assert hashlib.sha256(data).hexdigest()==desc['archiveSha256'];assert hashlib.sha256(raw).hexdigest()==desc['rawSha256']
 print(r['name'],r['exitCode'],r['stdout']['lines'])
 if '135851399936' in ' '.join(r['argv']) and '--log' in r['argv']:
  lines=gzip.decompress((folder/r['stdout']['file']).read_bytes()).decode().splitlines()
  print('NATIVE CONTRACT RESULTS')
  for i,line in enumerate(lines,1):
   clean=line.split('\t',2)[-1]
   if any(x in clean for x in ['test result:','Running tests/','panicked at','left:','right:','was canceled','Job was cancelled','exceeded','FAIL','Job timeout']):
    if len(clean)>1400:clean=clean[:1400]+' [long assertion retained]'
    print(f'{i}: {clean}')
  Path('/tmp/issue-1580-research/cf22-native-record.json').write_text(json.dumps(r,indent=2)+'\n')
print('ALL',2*len(records),'PAYLOAD HASHES VERIFIED')
p=Path('/tmp/issue-1580-research/offline-catalog-publication/outcome.json');d=json.loads(p.read_text());print('publication keys',list(d));print(json.dumps(d,indent=2)[:2200])
