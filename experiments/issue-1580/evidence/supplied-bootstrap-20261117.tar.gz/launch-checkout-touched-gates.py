from pathlib import Path
import json,subprocess
scratch=Path('/tmp/issue-1580-research');log=scratch/'checkout-touched-gates.log';assert not log.exists()
with log.open('wb') as stream:run=subprocess.Popen(['python3',str(scratch/'run-checkout-round-touched-gates.py')],cwd='/tmp/gh-issue-solver-1794900398048',stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
(scratch/'checkout-touched-gates.pid').write_text(str(run.pid)+'\n');print(json.dumps({'pid':run.pid,'log':str(log)}))
