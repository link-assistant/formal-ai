from pathlib import Path
import json,subprocess,urllib.request
out=Path("/tmp/issue-1580-research/picomatch")
out.mkdir(exist_ok=True)
for name,args in {
 "pull-194":["gh","api","repos/micromatch/picomatch/pulls/194"],
 "pull-194-comments":["gh","api","repos/micromatch/picomatch/issues/194/comments","--paginate"],
 "pull-194-files":["gh","api","repos/micromatch/picomatch/pulls/194/files","--paginate"],
 "latest-release":["gh","api","repos/micromatch/picomatch/releases/latest"],
}.items():
 r=subprocess.run(args,text=True,capture_output=True)
 print("REQUEST",name,"STATUS",r.returncode)
 if r.returncode: print(r.stderr);continue
 (out/(name+".json")).write_text(r.stdout)
 data=json.loads(r.stdout)
 if name=="pull-194": print(json.dumps({k:data[k] for k in ["html_url","state","title","body","merged","merge_commit_sha","updated_at"]},ensure_ascii=False));print("HEAD",data["head"]["sha"])
 elif name=="latest-release": print(json.dumps({k:data[k] for k in ["html_url","tag_name","body","published_at"]}))
 elif name=="pull-194-files":
  for row in data:print(row["filename"],row["status"],row.get("patch"))
 else:
  for row in data:print(row["html_url"],row["body"])
request=urllib.request.Request("https://registry.npmjs.org/picomatch/latest",headers={"Accept":"application/json"})
with urllib.request.urlopen(request,timeout=30) as response:raw=response.read(1024*1024+1)
assert len(raw)<=1024*1024
(out/"npm-latest.json").write_bytes(raw)
d=json.loads(raw)
print("NPM LATEST",json.dumps({k:d.get(k) for k in ["name","version","repository","dist","engines"]}))
for name in ["scripts/check-javascript-dependencies.sh","scripts/check-dependencies-latest.rs"]:
 p=Path(name)
 if p.exists():
  r=subprocess.run(["rg","-n","blocked|override|file:|picomatch|audit|npm","--",str(p)],capture_output=True,text=True)
  print("POLICY",name);print(r.stdout[:4000])
