from pathlib import Path
import json
import subprocess

def run(arguments):
    return subprocess.run(arguments, check=True, capture_output=True, text=True).stdout

assert run(['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
assert run(['git', 'rev-parse', 'HEAD']).strip() == 'b79dc1e0f147ed57d8e317c1b93bfa6ffc79078d'
assert not run(['git', 'diff', '--cached', '--name-only']).strip()
paths = [
    'docs/case-studies/issue-1580/README.md',
    'docs/case-studies/issue-1580/templates/README.md',
    'docs/case-studies/issue-1580/templates/python-partial-semantic-review.json',
    'experiments/issue-1580/work-plan.md',
    'experiments/issue-1580/fixtures/python-template/source.json',
    'experiments/issue-1580/fixtures/python-template/scripts/create_manual_changeset.py',
    'experiments/issue-1580/template-python-fragment-integrity.test.mjs',
    'rust/tests/web/issue-1580-template-observations.test.mjs',
    'experiments/issue-1580/evidence/checks/python-fragment-collision',
    'experiments/issue-1580/evidence/checks/python-fragment-integrity.json',
    'experiments/issue-1580/evidence/checks/python-review-reading',
    'experiments/issue-1580/evidence/ci/b79dc1e0f',
]
run(['git', 'add', '--', *paths])
staged = run(['git', 'diff', '--cached', '--name-only']).splitlines()
assert all(any(name == path or name.startswith(path + '/') for path in paths) for name in staged)
assert len(staged) >= 20
run(['git', 'diff', '--cached', '--check'])
print(run(['git', 'diff', '--cached', '--stat']), flush=True)
print(run(['git', 'commit', '-m', 'test: reproduce Python changelog fragment collisions']), flush=True)
head = run(['git', 'rev-parse', 'HEAD']).strip()
Path('/tmp/issue-1580-research/python-fragment-evidence-commit.txt').write_text(head + '\n')
print(json.dumps({'evidenceCommit': head, 'stagedFiles': len(staged), 'remotePushed': False, 'workingTree': run(['git', 'status', '--short'])}, indent=2), flush=True)
