from pathlib import Path
import subprocess,json,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');run=lambda a,**k:subprocess.run(a,cwd=root,check=True,**k)
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root)==b''
base=root/'experiments/issue-1580/evidence/checks/procedure-retrieval-validation';d=json.loads((base/'final-result.json').read_text());assert d['complete']
for p,h in d['sourceHashes'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
p='rust/tests/web/default-branch-build-policy.test.mjs';s=subprocess.check_output(['git','show','HEAD:'+p],cwd=root,text=True);s=s.replace("'  git rev-parse HEAD HEAD^{tree}\\n'", '"  git rev-parse HEAD \'HEAD^{tree}\'\\n"').replace(r'/git rev-parse HEAD HEAD\^\{tree\}/u',r"/git rev-parse HEAD 'HEAD\^\{tree\}'/u")
blob=subprocess.check_output(['git','hash-object','-w','--stdin'],cwd=root,input=s.encode()).decode().strip()
run(['git','add','--','.github/workflows/native-type-check.yml']);run(['git','update-index','--cacheinfo','100644,'+blob+','+p]);run(['git','diff','--cached','--check']);run(['git','-c','gc.auto=0','commit','-m','Quote the Git tree identity selector in native fixture generation'])
quote=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
run(['git','add','--',p,'scripts/ci-pull-request-admission.mjs','rust/tests/unit/reasoning_contracts.rs','changelog.d/issue-1580-retrieval-native-replay.md']);run(['git','diff','--cached','--check']);run(['git','-c','gc.auto=0','commit','-m','Replay existing procedure and concept retrieval contracts in focused native CI'])
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();out={'quoteCommit':quote,'admissionCommit':head,'pushed':False,'fullIssueComplete':False};(base/'source-commits.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
