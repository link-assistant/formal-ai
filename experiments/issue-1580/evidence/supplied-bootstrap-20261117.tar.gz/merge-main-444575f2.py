import json,subprocess
from pathlib import Path
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
main=subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()
assert main=='444575f2ac28f609c94497865f125f99415ff6d5'
result=subprocess.run(['git','merge','--no-ff','--no-commit',main],text=True,capture_output=True)
Path('/tmp/issue-1580-research/main-444575f2-merge.log').write_text(result.stdout+result.stderr)
print(json.dumps(dict(exitCode=result.returncode,output=result.stdout[-12000:],stderr=result.stderr[-3000:])))
print(subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],text=True))
