import pathlib
import subprocess

paths = [
    "rust/src/intent_formalization/obligations.rs",
    "rust/tests/unit/issue_1158_pull_request_steps.rs",
    "rust/tests/web/browser-engine-release-integration.test.mjs",
    "rust/tests/web/connector-work-item-receipts.test.mjs",
    "rust/tests/web/recipe-resume-policy-notation.test.mjs",
]
for path in paths:
    print("SOURCE", path, flush=True)
    if path.endswith("obligations.rs"):
        lines = pathlib.Path(path).read_text().splitlines()
        for index, line in enumerate(lines):
            if "bound_output_literals" in line or ("task); see" in line):
                print("\n".join(str(number + 1) + ": " + lines[number] for number in range(max(0, index - 4), min(len(lines), index + 6))))
    else:
        result = subprocess.run(["git", "diff", "--unified=2", "origin/main", "--", path], capture_output=True, text=True, check=True)
        print(result.stdout)
print("CORE QA DIFF LOCATIONS", flush=True)
subprocess.run(["git", "diff", "--stat", "origin/main", "--", "rust/src/solver_handlers", "rust/src/intent_formalization", "rust/src/reasoning_loop", "rust/web/intent*", "rust/web/solver*"], check=True)
print("LOCAL EVIDENCE DOCUMENTS", flush=True)
subprocess.run(["rg", "-n", "--glob", "*.md", "private.*link|explicit_count|quoted passage|UNKNOWN STEP|31 native|1080s|1158_pull", "experiments/issue-1580"], check=True)
