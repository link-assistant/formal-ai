from pathlib import Path
import subprocess
import sys

script = Path('experiments/issue-1580/refresh-task-quotation-fixture.mjs')
assert not script.exists()
script.write_text(r'''// Supplied shared-fixture refresh; zero independent authorship credit.
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { WorkerHost } from '../../js/server/worker-host.mjs';
import { installNodeHost } from '../../js/agentic/node-host.mjs';
await installNodeHost(new WorkerHost());
const { CASES, replayCase } = await import('../../rust/tests/web/helpers/issue-1550-meta-executor-cases.mjs');
const file = 'rust/tests/fixtures/meta-executor-parity.json';
const original = JSON.parse(readFileSync(file, 'utf8'));
assert.equal(original.cases.length, 15);
const cases = [];
for (const input of CASES) cases.push({ ...input, expected: await replayCase(input) });
assert.deepEqual(cases.slice(0, original.cases.length), original.cases, 'Every original input, assertion and trace must remain unchanged');
assert.equal(cases.length, 22);
for (const entry of cases.slice(15)) assert.equal(entry.expected.status, 'resolved', entry.name);
writeFileSync(file, JSON.stringify({ ...original, cases }, null, 2) + '\n');
console.log(JSON.stringify({ originalCasesUnchanged: 15, addedCases: cases.slice(15).map((entry) => ({ name: entry.name, leaves: entry.expected.leaves, shape: entry.expected.shape, status: entry.expected.status })) }));
''')

worker = Path('/tmp/issue-1580-research/validate-task-quotation-boundaries.py')
assert not worker.exists()
worker.write_text(r'''from pathlib import Path
import datetime, hashlib, json, os, subprocess, traceback

root = Path('experiments/issue-1580/evidence/checks/task-quotation-boundaries')
root.mkdir(exist_ok=False)
results = []

def run(name, command):
    log = root / (name + '.log')
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with log.open('wb') as output:
        process = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    raw = log.read_bytes()
    entry = {'name': name, 'command': command, 'startedAt': started, 'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exitCode': process.returncode, 'rawBytes': len(raw), 'rawLines': len(raw.splitlines()), 'rawSha256': hashlib.sha256(raw).hexdigest(), 'log': str(log)}
    results.append(entry)
    (root / 'progress.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(entry), flush=True)
    return process.returncode

try:
    files = ['js/agentic/crate/meta_executor.mjs', 'data/seed/text-formalization.lino']
    drafts = {name: Path(name).read_bytes() for name in files}
    try:
        for name in files:
            Path(name).write_bytes(subprocess.check_output(['git', 'show', 'HEAD:' + name]))
        code = run('before-original-quotation-policy', ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-concurrency=1', 'rust/tests/web/issue-1550-meta-executor.test.mjs'])
        assert code == 1, 'The old source must reject the new quotation controls'
        assert 'ascii-double-aggregation' in (root / 'before-original-quotation-policy.log').read_text()
    finally:
        for name, raw in drafts.items():
            Path(name).write_bytes(raw)
    assert run('worker-projection-write', ['node', '--max-old-space-size=256', 'scripts/generate-worker-crate-modules.mjs', '--write']) == 0
    assert run('shared-fixture-refresh', ['node', '--max-old-space-size=256', 'experiments/issue-1580/refresh-task-quotation-fixture.mjs']) == 0
    assert run('typescript-projection-write', ['node', '--max-old-space-size=256', 'scripts/translate-es.mjs', '--write']) == 0
    assert run('native-format', ['rustfmt', '--check', 'rust/src/meta_executor.rs']) == 0
    assert run('after-quotation-repair', ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-concurrency=1', 'rust/tests/web/issue-1550-meta-executor.test.mjs']) == 0
    assert run('adjacent-factual-qa', ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-concurrency=1', 'rust/tests/web/issue-1172-factual-qa-subject-gate.test.mjs']) == 0
    assert run('worker-projection-check', ['node', '--max-old-space-size=256', 'scripts/generate-worker-crate-modules.mjs', '--check']) == 0
    assert run('typescript-projection-check', ['node', '--max-old-space-size=256', 'scripts/translate-es.mjs', '--check']) == 0
    assert run('whitespace', ['git', 'diff', '--check']) == 0
    (root / 'outcome.json').write_text(json.dumps({'complete': True, 'nativeExecuted': False, 'independentAuthorshipCredit': 0, 'checks': results}, indent=2) + '\n')
except BaseException:
    traceback.print_exc()
    (root / 'outcome.json').write_text(json.dumps({'complete': False, 'nativeExecuted': False, 'independentAuthorshipCredit': 0, 'checks': results}, indent=2) + '\n')
    raise
''')
stdout = Path('/tmp/issue-1580-research/task-quotation-validation-worker.log')
with stdout.open('wb') as output:
    process = subprocess.Popen([sys.executable, str(worker)], stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
Path('/tmp/issue-1580-research/task-quotation-validation-worker.pid').write_text(str(process.pid) + '\n')
print('Started finite sequential quotation validation', process.pid, stdout)
