set -eu
sed -n '1,220p' scripts/check-rust-dependencies.sh
sed -n '1,180p' scripts/detect-code-changes.rs
cat /tmp/issue-1580-research/template-detection-context.txt
rg --files /tmp/issue-1580-research/templates/php-complete | rg '(ChangeDetector|Process|bootstrap)'
python3 --version
command -v python3.14 || true
rg -n 'issue-1580|\.test.mjs|entries|groups' data/benchmarks/fast-pull-request-javascript-tests.json | head -n 35
