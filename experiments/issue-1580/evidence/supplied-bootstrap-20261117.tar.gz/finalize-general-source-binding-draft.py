from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/general-source-binding'
paths=['rust/src/solver_unknown_reasoning.rs','rust/tests/unit/solver_unknown_reasoning_captured_sources.rs']
p=subprocess.run(['rustfmt','--edition','2024',*paths],cwd=root,capture_output=True);raw=p.stdout+p.stderr
(base/'rustfmt-edition-retry.log.gz').write_bytes(gzip.compress(raw,mtime=0));assert p.returncode==0,raw.decode()
record={'sources':[{'file':name,'beforeSha256':hashlib.sha256(subprocess.check_output(['git','show','HEAD:'+name],cwd=root)).hexdigest(),'afterSha256':hashlib.sha256((root/name).read_bytes()).hexdigest()} for name in paths],'newNativeCases':5,'nativeExecutedLocally':False,'rustfmtEdition':'2024','independentAuthorshipCredit':0}
(base/'implementation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
print(subprocess.run(['git','diff','--stat'],cwd=root,capture_output=True,text=True).stdout)
print(subprocess.run(['rg','-n','public_knowledge_cache:|cached_public|concept_lookup_resolved','rust/src/solver_unknown_reasoning.rs'],cwd=root,capture_output=True,text=True).stdout)
print((root/'experiments/issue-1580/evidence/ci/language-6a9aa198/outcome.json').read_text() if (root/'experiments/issue-1580/evidence/ci/language-6a9aa198/outcome.json').exists() else 'CI collector has not completed')
