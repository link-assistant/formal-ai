import fs from 'node:fs';
import v8 from 'node:v8';
import {execFileSync} from 'node:child_process';
const old=v8.deserialize(fs.readFileSync('/tmp/issue-1580-research/startup-governed-before.v8'));
const name=execFileSync('git',['ls-files','*governed-baseline.v8'],{encoding:'utf8'}).trim();
const current=v8.deserialize(fs.readFileSync(name));
const changes=[];let pairs=0;
function compare(left,right,path=''){
  if(left===right)return;
  if(left===null||right===null||typeof left!=='object'||typeof right!=='object') {changes.push({path,before:left,after:right});return;}
  if(++pairs>200000)throw Error('bounded_comparison_limit');
  if(Object.getPrototypeOf(left)!==Object.getPrototypeOf(right))throw Error('prototype_changed:'+path);
  if(JSON.stringify(Object.keys(left))!==JSON.stringify(Object.keys(right)))throw Error('keys_changed:'+path);
  for(const key of Object.keys(left))compare(left[key],right[key],path+'/'+key);
}
compare(old,current);
const result={pairs,changes,cases:current.inventory.cases.length,unsupported:current.inventory.unsupported.length};
fs.writeFileSync('experiments/issue-1580/evidence/checks/main-merge-444575f2/startup-witness-delta.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
