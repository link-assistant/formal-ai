from pathlib import Path
import gzip,hashlib,json
r=Path.cwd();h=lambda b:hashlib.sha256(b).hexdigest()
s=Path('/tmp/issue-1580-research/event-origin-publication');source=json.loads((s/'outcome.json').read_text());assert source['complete']and source['pushExecuted']and source['head']=='5f64ad16450a84ae1384d6fba753ab0efbd47866'
b=r/'experiments/issue-1580/evidence/checks/event-origin-publication';b.mkdir(exist_ok=True);rows=[]
for row in source['records']:
 item=dict(row)
 for label in ['stdout','stderr']:
  raw=(s/(row['name']+'.'+label)).read_bytes();assert h(raw)==row[label+'Sha256'];packed=gzip.compress(raw,mtime=0);name=row['name']+'.'+label+'.gz';(b/name).write_bytes(packed);item[label]={'file':name,'rawSha256':h(raw),'archiveSha256':h(packed),'bytes':len(raw)}
 rows.append(item)
(b/'records.json').write_text(json.dumps(rows,indent=2)+'\n');(b/'outcome.json').write_text(json.dumps({k:v for k,v in source.items()if k!='records'},indent=2)+'\n');print('PUBLICATION',len(rows),'commands',len(rows)*2,'verified payloads')
s=Path('/tmp/issue-1580-research/java-history-pages');b=r/'experiments/issue-1580/evidence/checks/java-historical-forward-022';b.mkdir(exist_ok=True);manifest=json.loads((s/'manifest.json').read_text());rows=[]
for page in range(154,158):
 name=f'page-{page:03}.log.gz';packed=(s/name).read_bytes();raw=gzip.decompress(packed);assert f'page {page}/254'.encode()in raw;(b/name).write_bytes(packed);rows.append(dict(manifest[page-1],file=name,archiveSha256=h(packed),rawSha256=h(raw),completeLiteralOutputRead=True))
(b/'manifest.json').write_text(json.dumps({'pinnedHead':'dd803a2d9fa5b3a992b435acce73162274fb9e8b','pages':rows,'independentAuthorshipCredit':0},indent=2)+'\n')
b=r/'docs/case-studies/issue-1580/templates';p=b/'java-historical-review-index.json';index=json.loads(p.read_text());old=index['cumulativeSummary'];assert old['literalPages']==153;updated=dict(old,literalPages=157,nextForwardPage=158,remainingPages=97);name='java-historical-forward-review-022.json';part={'previousIndexSummary':old,'pagesFullyRead':list(range(154,158)),'filesChangedSincePrevious':[{'path':'dev/log/issues/24/pulls/25/sources/pre-commit-pypi.json','newReadLinePieces':[91,114],'cumulativeReadLinePieces':[1,114],'totalLinePieces':145,'completeSourceRead':False}],'cumulativeSummary':updated,'observations':['Four pages were literally read without truncation in the preceding research context. This continues the historical registry through piece 114/145, without completing its single source line. Complete line/file counts remain 8,766/123, with one partial file. Current semantic applicability and pages 158–254 remain open. Supplied reading earns zero independent authorship credit.']};raw=(json.dumps(part,indent=2)+'\n').encode();(b/name).write_bytes(raw);index['forwardParts'].append({'file':name,'sha256':h(raw),'pages':list(range(154,158))});index['cumulativeSummary']=updated;p.write_text(json.dumps(index,indent=2)+'\n');print('JAVA',json.dumps(updated))
b=r/'experiments/issue-1580/evidence/checks/web-contract-probe';b.mkdir(exist_ok=True);rows=[]
for name in ['page-formalization.log','web-requests.log']:
 raw=(Path('/tmp/issue-1580-research/web-contract-probe')/name).read_bytes();packed=gzip.compress(raw,mtime=0);(b/(name+'.gz')).write_bytes(packed);rows.append({'file':name+'.gz','rawSha256':h(raw),'archiveSha256':h(packed),'lines':len(raw.splitlines())})
(b/'review.json').write_text(json.dumps({'records':rows,'existingPageFormalizationTestsPassed':6,'webRoutingObservations':8,'webObservationsAreAssertions':False,'externalNetworkDisabled':True,'fullLogsReadInPriorResearchContext':True,'offlineAnswersOmitQueryAndDoNotCertifyNativeSearchAnswerContract':True,'nativeExecutionVerified':False,'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n');print('PROBES',len(rows))
