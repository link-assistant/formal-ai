#!/bin/sh
set -eu
node scripts/translate-es.mjs --write
node scripts/generate-worker-prerequisites.mjs --write
node scripts/generate-runtime-feature-inventory.mjs --write
rustfmt --edition 2024 rust/src/solver_dispatch.rs
timeout 600 node --test --test-concurrency=1 rust/tests/web/worker-candidate-validation.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/default-branch-build-policy.test.mjs
npm install --prefix /tmp/issue-1580-research/parser-dependencies --ignore-scripts --no-audit --no-fund @babel/parser@8.0.7 yaml@2.9.1 lino-i18n@0.4.0 > /tmp/issue-1580-research/gate-dependencies-install.log 2>&1
