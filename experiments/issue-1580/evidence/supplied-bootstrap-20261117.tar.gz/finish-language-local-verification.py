from pathlib import Path
import subprocess,sys,time,json,hashlib,gzip,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');state=scratch/'finish-language-local-verification'
if len(sys.argv)==1:
 state.mkdir(exist_ok=False)
 with (state/'worker.log').open('wb') as f:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'scope':'Wait for complete first inventory, preserve all failures, correct documentation gates, then run final shared inventory sequentially.'}));sys.exit(0)
try:
 first=root/'experiments/issue-1580/evidence/checks/language-main-validation'
 while not (first/'outcome.json').exists():time.sleep(2)
 v=json.loads((first/'outcome.json').read_text());assert v['complete'] and v['sourceUnchangedDuringValidation']
 for row in v['checks']+v['gateLogs']:
  raw=gzip.decompress((first/row['log']).read_bytes());assert hashlib.sha256(raw).hexdigest()==row['sha256'],row
 print('FIRST_COMPLETE',json.dumps(v['gateCounts']),flush=True)
 subprocess.run([sys.executable,str(scratch/'fix-merged-documentation-gates.py')],cwd=root,check=True)
 source=(scratch/'validate-merged-language-batch.py').read_text().replace('language-main-validation','language-main-final-validation')
 old="for name,file in [('workflow-policy','default-branch-build-policy'),('worker-unknown-language','worker-unknown-language'),('fixture-integrity','rust-specification-fixture-integrity'),('governed-identifiers','rust-specification-unicode-identifiers'),('request-context','issue-1587-request-context'),('cnl-output','cnl-output'),('cnl-http','cnl-output-http'),('cnl-solver-dialogue','cnl-solver-dialogue'),('cnl-parity','cnl-parity'),('cnl-grammar-matrix','cnl-grammar-matrix')]:"
 assert old in source;source=source.replace(old,'for name,file in []:')
 script=scratch/'validate-final-merged-language-batch.py';script.write_text(source)
 (root/'experiments/issue-1580/evidence/checks/language-main-final-validation').mkdir(exist_ok=False)
 (scratch/'language-main-final-validation').mkdir(exist_ok=False)
 subprocess.run([sys.executable,str(script),'worker'],cwd=root,check=True)
 final=json.loads((root/'experiments/issue-1580/evidence/checks/language-main-final-validation/outcome.json').read_text())
 assert final['complete']
 (state/'outcome.json').write_text(json.dumps({'complete':True,'allPassed':final['allPassed'],'gateCounts':final['gateCounts']},indent=2)+'\n')
 print('FINAL',json.dumps(final['gateCounts']),'ALL_PASSED',final['allPassed'],flush=True)
except BaseException:traceback.print_exc();sys.exit(1)
