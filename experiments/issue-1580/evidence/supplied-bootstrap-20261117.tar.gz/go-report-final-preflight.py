import json
import subprocess
from pathlib import Path

repo='link-foundation/go-ai-driven-development-pipeline-template'
pages=json.loads(subprocess.check_output(['gh','api','--paginate','--slurp',f'repos/{repo}/issues?state=all&per_page=100'],text=True))
rows=[row for page in pages for row in page if 'pull_request' not in row]
Path('/tmp/issue-1580-research/go-issues-before-pin-report.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:
    print(row['number'],row['state'],row['title'])
    if row['number']>19:
        print(row.get('body') or '')
print('Current upstream HEAD:',subprocess.check_output(['gh','api',f'repos/{repo}/commits/main','--jq','.sha'],text=True).strip())
print('Published evidence commit:',subprocess.check_output(['gh','api','repos/link-assistant/formal-ai/commits/a4053def4bd4b921001fdf84a026ae35deebfc39','--jq','.sha'],text=True).strip())
report=Path('experiments/issue-1580/upstream/go-stale-pin-integrity-report.md').read_text()
print(report)
Path('/tmp/issue-1580-research/go-stale-pin-report-body.md').write_text(report.replace(' (file only after this commit is published)',''))
