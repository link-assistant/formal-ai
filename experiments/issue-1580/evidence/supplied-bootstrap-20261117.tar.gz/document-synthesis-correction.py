from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/checks/child-evidence-provenance/synthesis-correction'
assert json.loads((base/'results.json').read_text())['complete']
path=root/'docs/case-studies/issue-1580/child-evidence-checkpoint.md'
text=path.read_text();marker='## Limits\n'
assert marker in text and '## Published compile failure' not in text
text=text.replace(marker,'''## Published compile failure and correction

Head `ffebedb1` completes 23 workflows: 22 pass and the CI/CD Pipeline fails.
The native library check reports E0063 at `solver_synthesis.rs:219` and `:261`:
two validation-only `Draft` constructors omit the new `evidence` field. Preserve
the entire 16,099-line failed workflow and complete native job log under
`experiments/issue-1580/evidence/ci/child-evidence-ffebedb1/`. Literal review of
the failed workflow covers lines 15,761–15,775; the native job error window is
also read. The fifth native executor test does not execute on this failed head.

Initialize both temporary validation drafts with empty evidence. Their verdict
checks consume intent and content; actual synthesized answer evidence continues
to be assembled by `finalize_composed_candidate` from the event log. Audit all
Rust `Draft` constructors and imports, including the separate coding type.
The correction passes 13 executor tests, six procedure-census tests, five relevant
JavaScript gates, Rust 2024 formatting and whitespace checks. Native compilation
and the fifth executor regression remain pending the next hosted run.

The passing JavaScript jobs on `ffebedb1` report 1,440 and 1,256 passes, four and
13 skips, zero failures and zero cancellations. Complete logs and hash checks
are retained; literal review covers the final totals and named error windows,
not every successful log line. These results do not establish the wider issue.

'''+marker)
path.write_text(text)
path=root/'experiments/issue-1580/work-plan.md';text=path.read_text()
old='- [ ] Review and publish the complete batch once after fresh feedback/main/CI\n  checks, then verify every hosted result including the fifth native executor test.'
new='''- [x] Review and publish the complete batch once after fresh feedback/main/CI
  checks. Head ffebedb1 completes 23 workflows: 22 pass, while the native library
  check fails with two missing `Draft.evidence` initializers in synthesis.
  Preserve complete logs and read the actual compiler errors and JavaScript totals.
- [x] Initialize both validation-only synthesis drafts, audit every Rust `Draft`
  constructor/import, then pass 13 executor tests, six procedure-census tests,
  five selected gates, Rust 2024 formatting and whitespace checks.
- [ ] Publish the synthesis constructor correction after the single-push gate,
  then verify all hosted results and actual execution of the fifth executor test.'''
assert old in text;text=text.replace(old,new);path.write_text(text)
path=root/'experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md';text=path.read_text()
marker='- Published head `bfe5ac0f` passes'
assert marker in text and 'Published evidence head `ffebedb1`' not in text
paragraph='''- Published evidence head `ffebedb1` completes **22/23 workflows successfully**. The [native library check](https://github.com/link-assistant/formal-ai/actions/runs/44276631643/job/134706472381) fails with **E0063** at `solver_synthesis.rs:219` and `:261`: two validation-only `Draft` constructors omit `evidence`. The fifth executor regression does not execute. Initialize both fields, audit all Rust constructors/imports, then pass **13 executor tests, six procedure-census tests, five relevant gates, Rust 2024 formatting and whitespace checks**. Native verification of this correction remains pending the next hosted run. Preserve the complete failed workflow, native log, literal error windows and correction receipts. Passing JavaScript shards report **1,440 and 1,256 passes**, **4 and 13 skips**, zero failures and zero cancellations.
'''
text=text.replace(marker,paragraph+marker);path.write_text(text)
for relative in ['rust/src/solver_synthesis.rs','docs/case-studies/issue-1580/child-evidence-checkpoint.md','experiments/issue-1580/work-plan.md','experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md']:
    result=subprocess.run(['git','diff','--',relative],cwd=root,capture_output=True,check=True)
    print(result.stdout.decode())
