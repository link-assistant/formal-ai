from pathlib import Path
import json,sys
profile=Path('rust/tests/web/fast-pull-request-production-profile.test.mjs')
workflow=Path('.github/workflows/layered-ci.yml')
old='/*\n!/experiments/formal_ai_subagent/evidence/coordinator-1188/\n!/dev/log/\n/dev/log/issues/702/pulls/818/agent-cli/\n'
patterns=old+''.join(f'!/{root}/**/*.{extension}\n' for root in ['docs/case-studies','experiments/*/evidence'] for extension in ['gz','log','zip','tgz','diff'])+''.join(path+'\n' for path in ['/docs/case-studies/issue-717/e2e-npm-ci.log','/docs/case-studies/issue-932/raw-data/verify-*.log','/docs/case-studies/issue-982/self-hosting/contract/*.gz','/experiments/issue-1580/evidence/ci/main-826289fc/cli/opencode-interactive-proxy.jsonl.gz','/experiments/issue-1580/evidence/ci/main-826289fc/cli/qwen-interactive-proxy.jsonl.gz'])
Path('/tmp/issue-1580-research/javascript-proposed-checkout-patterns.txt').write_text(patterns)
if sys.argv[1]=='test':
    source=profile.read_text()
    needle="test('fast source checkout retains every measured tracked source while excluding only unmeasured archives', () => {"
    addition="""test('JavaScript acquisition excludes historical archives and retains consumed regression operands', () => {
  const patterns=workflow('layered-ci.yml').jobs.js.steps[0].with['sparse-checkout'];
  const retained=['docs/case-studies/issue-717/e2e-npm-ci.log',
    'docs/case-studies/issue-932/raw-data/verify-python.log',
    'docs/case-studies/issue-982/self-hosting/contract/actual.log.gz',
    ...['opencode','qwen'].map(client=>`experiments/issue-1580/evidence/ci/main-826289fc/cli/${client}-interactive-proxy.jsonl.gz`),
    'rust/tests/fixtures/expected.log','experiments/issue-1580/evidence/checks/receipt.json',
    'docs/case-studies/issue-703/comparison/sessions/000-codex.json'];
  const omitted=['gz','log','zip','tgz','diff'].flatMap(extension=>[
    `docs/case-studies/history/nested/archive.${extension}`,
    `experiments/issue-1580/evidence/ci/old/archive.${extension}`]);
  assert.deepEqual(checkoutSelection(patterns,[...retained,...omitted]),retained);
  const files=execFileSync('git',['ls-files','--cached','-z'],{
    encoding:'utf8',timeout:5000,maxBuffer:16*1024*1024
  }).split('\\0').filter(Boolean);
  const selected=new Set(checkoutSelection(patterns,files));
  for(const file of files){
    if(file.startsWith('dev/log/')||file.startsWith('experiments/formal_ai_subagent/evidence/coordinator-1188/'))continue;
    if(!selected.has(file)){
      assert.match(file,/^(?:docs\\/case-studies\\/|experiments\\/[^/]+\\/evidence\\/).*\\.(?:gz|log|zip|tgz|diff)$/u);
      assert.equal(fileLimit(file),null,'preserve measured source: '+file);
    }
  }
  for(const file of files.filter(file=>file==='Cargo.lock'||file.endsWith('/Cargo.lock')))
    assert.ok(selected.has(file),'preserve repo-wide lockfile audit: '+file);
});


"""
    assert source.count(needle)==1 and 'JavaScript acquisition excludes historical archives' not in source
    profile.write_text(source.replace(needle,addition+needle))
elif sys.argv[1]=='workflow':
    source=workflow.read_text();block='          sparse-checkout: |\n'+''.join('            '+line+'\n' for line in old.splitlines())
    newblock='          sparse-checkout: |\n'+''.join('            '+line+'\n' for line in patterns.splitlines())
    assert source.count(block)==1
    workflow.write_text(source.replace(block,newblock))
    source=profile.read_text();assert source.count(json.dumps(old,ensure_ascii=False)[1:-1])==1
    profile.write_text(source.replace(json.dumps(old,ensure_ascii=False)[1:-1],json.dumps(patterns,ensure_ascii=False)[1:-1]))
else:raise AssertionError(sys.argv[1])
print(json.dumps({'mode':sys.argv[1],'patterns':patterns,'independentAuthorshipCredit':0},indent=2))
