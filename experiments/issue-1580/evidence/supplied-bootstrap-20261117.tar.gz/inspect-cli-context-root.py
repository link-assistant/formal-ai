import json, pathlib, re, subprocess

for name in ('AGENTS.md', 'CONTRIBUTING.md', 'js/server/request-context.mjs', 'rust/tests/unit/protocol/issue_1587_request_context.rs'):
    path = pathlib.Path(name)
    print(f'FILE {name} {len(path.read_text().splitlines())} lines')
    for n, line in enumerate(path.read_text().splitlines(), 1):
        print(f'{n}: {line}')
root = pathlib.Path('/tmp/issue-1580-research/main-826289fc-cli-artifacts')
for client in ('opencode', 'qwen'):
    path = root / f'transcripts-{client}/artifacts/{client}/interactive/proxy.jsonl'
    requests = [json.loads(row) for row in path.read_text().splitlines() if json.loads(row)['method'] == 'POST']
    record = next(row for row in requests if row['response_tool_calls'])
    body = json.loads(record['request_body'])
    print(f'CLIENT {client} requestkeys={list(body)}')
    for i, message in enumerate(body['messages']):
        content = message.get('content', '')
        print(f'MESSAGE {i} role={message["role"]} contentType={type(content).__name__}')
        if message['role'] in ('system', 'developer'):
            text = content if isinstance(content, str) else json.dumps(content)
            out = pathlib.Path(f'/tmp/issue-1580-research/{client}-system.txt')
            out.write_text(text)
            lines = text.splitlines()
            selected = set()
            for n, line in enumerate(lines):
                if re.search(r'(?i)(reply in English|fewer than|your output must|language|# tone|# final|lines of text)', line):
                    selected.update(range(max(0, n - 2), min(len(lines), n + 3)))
            print(f'SYSTEM {len(text)} characters {len(lines)} lines; selected context:')
            for n in sorted(selected):
                print(f'{n + 1}: {lines[n]}')
        else:
            print(str(content)[:1200])
    for row in requests:
        response = json.loads(row['response_body']) if row['response_body'].lstrip().startswith('{') else None
        if response:
            print('RESPONSE', json.dumps(response.get('choices', []), ensure_ascii=False)[:2400])
fixture = json.loads(pathlib.Path('data/parity/issue-1587-request-context.json').read_text())
for row in fixture:
    print('FIXTURE', json.dumps(row, ensure_ascii=False))
