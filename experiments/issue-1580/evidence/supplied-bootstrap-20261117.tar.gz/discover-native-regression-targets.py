from pathlib import Path
import json, subprocess, tomllib

root = Path('/tmp/gh-issue-solver-1794900398048')
manifest = tomllib.loads((root / 'rust/Cargo.toml').read_text())
selected = []
for row in manifest.get('test', []):
    print('TEST TARGET', json.dumps(row))
    if row['name'] in ['synthesis_contracts', 'calendar_currency', 'meta_executor_parity', 'unit', 'integration', 'any_language']:
        selected.append(row)
for row in selected:
    path = root / 'rust' / row['path']
    lines = path.read_text().splitlines()
    print('TARGET SOURCE', path.relative_to(root), 'TOTAL LINES', len(lines))
    for n, line in enumerate(lines[:90], 1):
        print(f'{n}: {line}')
workflow = root / '.github/workflows/native-type-check.yml'
lines = workflow.read_text().splitlines()
print('NATIVE WORKFLOW LINES', len(lines))
for n, line in enumerate(lines, 1):
    print(f'{n}: {line}')
