from pathlib import Path
import json
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research/canonical-main-final-validation')
for name in ['outcome.json','failure.json']:
 p=scratch/name
 if p.exists():print(name,p.read_text())
f=root/'experiments/issue-1580/evidence/checks/canonical-main-final-validation/results.json'
if f.exists():print('CHECKS',json.dumps([(r['name'],r['exitCode'],r['seconds']) for r in json.loads(f.read_text())]))
for name in ['issue-991-how-to-synthesis.log','procedural-runtime-parity.log','all-local-gates.log']:
 p=scratch/name
 if p.exists():
  lines=p.read_text().splitlines();print(name,'LINES',len(lines));print('\n'.join(lines[-8:]))
