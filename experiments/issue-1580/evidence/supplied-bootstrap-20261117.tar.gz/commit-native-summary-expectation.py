from pathlib import Path
import datetime, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/checks/native-summary-expectation'
results = json.loads((base / 'results.json').read_text())
assert results['complete'] and all(row['exitCode'] == 0 for row in results['checks'])
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip() == 'issue-1580-8d61a32a61e1'
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=root)
files = ['rust/tests/unit/specification/synthesis.rs', 'changelog.d/issue-1580-native-summary-expectation.md']
receipt = json.loads((base / 'source-receipt.json').read_text())
assert hashlib.sha256((root / files[0]).read_bytes()).hexdigest() == receipt['afterSha256']
subprocess.run(['git', 'add', '--', *files], cwd=root, check=True)
patch = subprocess.check_output(['git', 'diff', '--cached'], cwd=root)
print(patch.decode())
assert subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=root, text=True).splitlines() == sorted(files)
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=root, check=True)
subprocess.run(['git', '-c', 'gc.auto=0', 'commit', '-m', 'test: align isolated synthesis summary with whole-sentence contract'], cwd=root, check=True)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
report = {'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'commit': head, 'files': files, 'sourcePatchSha256': hashlib.sha256(patch).hexdigest(), 'checksComplete': True, 'nativeExecutionPending': True, 'allIssueAcceptanceComplete': False, 'independentAuthorshipCredit': 0}
(base / 'source-commit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
