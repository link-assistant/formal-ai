from pathlib import Path
import gzip
import hashlib
import json
import subprocess

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()
assert git('branch','--show-current') == 'issue-1580-8d61a32a61e1'
checks = Path('experiments/issue-1580/evidence/checks')
path = Path('/tmp/issue-1580-research/touched-gates-sixth.log')
data = path.read_bytes()
assert data.count(b'PASS ') == 4 and b'FAIL ' not in data
packed = gzip.compress(data,mtime=0)
(checks/(path.name+'.gz')).write_bytes(packed)
index = checks/'ci-repair-sixth.json'
record = json.loads(index.read_text())
record['localVerification']['touchedGates'] = 4
record['files'].append({'file':path.name+'.gz','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'compressedSha256':hashlib.sha256(packed).hexdigest()})
index.write_text(json.dumps(record,indent=2)+'\n')
graph_folder = Path('docs/case-studies/issue-1580/templates')
for row in json.loads((graph_folder/'ci-reference-graphs.json').read_text()):
    data = (graph_folder/row['file']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == row['sha256']
    raw = gzip.decompress(data)
    assert hashlib.sha256(raw).hexdigest() == row['uncompressedSha256']
    graph = json.loads(raw)
    assert graph['commit'] == row['commit']
    assert graph['repository'] == row['repository']
    assert len(graph['roots']) == row['roots']
    assert 'not complete execution closure' in graph['coverageClaim']

def commit(message, *paths):
    subprocess.run(['git','add','--',*paths],check=True)
    subprocess.run(['git','diff','--cached','--check'],check=True)
    subprocess.run(['git','commit','-m',message],check=True)
commit('fix(ci): load workflow inventory YAML across CommonJS environments',
       'experiments/issue-1580/compare-template-trees.mjs',
       'experiments/issue-1580/template-inventory-integrity.test.mjs')
commit('fix(ci): reject unknown and empty local gate selections',
       'experiments/formal_ai_subagent/local-gates.mjs',
       'rust/tests/web/pull-request-1188-subagent-folder.test.mjs')
commit('docs(ci): preserve large registry responses as compressed evidence',
       'experiments/issue-1580/evidence/chrono-upstream')
commit('docs(ci): retain template references and complete repair evidence',
       'docs/case-studies/issue-1580',
       'experiments/issue-1580/trace-template-ci.mjs',
       'experiments/issue-1580/template-reference-graph.test.mjs',
       'experiments/issue-1580/evidence/ci/71e1dee44',
       'experiments/issue-1580/evidence/checks',
       'experiments/issue-1580/upstream',
       'experiments/issue-1580/work-plan.md',
       'changelog.d/20261117_120000_issue-1580-ci-regressions.md')
print('Committed repairs and evidence:', git('rev-parse','HEAD'))
