from pathlib import Path
import datetime,gzip,hashlib,json,os,resource,shutil,subprocess,tempfile,time
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
base=root/'experiments/issue-1580/evidence/checks/fast-source-archive-checkout';receipt=base/'sparse-source-commands.json';assert not receipt.exists()
parse="import fs from 'node:fs';import YAML from 'yaml';const j=YAML.parse(fs.readFileSync('.github/workflows/release.yml','utf8')).jobs['fast-pr-lint'];process.stdout.write(JSON.stringify({patterns:j.steps[0].with['sparse-checkout'],commands:j.steps.find(s=>s.run).run.trim().split('\\n')}));"
job=json.loads(subprocess.check_output(['node','--input-type=module','-e',parse],cwd=root,text=True))
files=subprocess.check_output(['git','ls-files','--cached','-z'],cwd=root).split(b'\0');files=[p.decode() for p in files if p]
work=Path(tempfile.mkdtemp(prefix='sparse-fast-source-',dir=scratch));rows=[];started=time.monotonic()
try:
 rules=work/'checkout-rules';rules.write_text(job['patterns'])
 selected=subprocess.check_output(['git','sparse-checkout','check-rules','--no-cone','--rules-file',str(rules),'-z'],cwd=root,input=('\0'.join(files)+'\0').encode()).decode().split('\0');selected=[p for p in selected if p]
 rules.unlink();omitted=sorted(set(files)-set(selected));raw='\n'.join(omitted).encode();(base/'omitted-paths.txt.gz').write_bytes(gzip.compress(raw,mtime=0))
 for name in selected:
  source=root/name;target=work/name;target.parent.mkdir(parents=True,exist_ok=True)
  if source.is_symlink():target.symlink_to(os.readlink(source))
  elif source.is_file():
   if source.suffix.lower() in ['.png','.jpg','.jpeg','.gif','.pdf','.webp']:os.link(source,target)
   else:shutil.copy2(source,target)
 (work/'.git').write_text('gitdir: '+str(root/'.git')+'\n')
 (work/'node_modules').symlink_to(root/'node_modules',target_is_directory=True)
 index=scratch/'sparse-fast-source-index';shutil.copy2(root/'.git/index',index)
 env=dict(os.environ,GIT_INDEX_FILE=str(index))
 assert Path(subprocess.check_output(['git','rev-parse','--show-toplevel'],cwd=work,env=env,text=True).strip())==work
 commands=[]
 for line in job['commands']:
  assert line.startswith('node scripts/') and len(line.split())<=3,line
  if line=='node scripts/check-fast-governance.mjs':
   extra="import {governanceChecks} from './scripts/check-fast-governance.mjs';process.stdout.write(JSON.stringify(governanceChecks));"
   governed=json.loads(subprocess.check_output(['node','--input-type=module','-e',extra],cwd=work,env=env,text=True))
   for check in governed:
    args=check['args'];command=check['command']
    if Path(command).name=='node':command='node';args=[arg for arg in args if not arg.startswith('--max-old-space-size=')];args=['--max-old-space-size=256',*args]
    commands.append((check['name'],[command,*args]))
  else:commands.append((line,['node','--max-old-space-size=256',*line.split()[1:]]))
 for number,(name,args) in enumerate(commands,1):
  before=time.monotonic();run=subprocess.run(args,cwd=work,env=env,capture_output=True);data=run.stdout+run.stderr;log=base/f'sparse-command-{number:02}.log.gz';log.write_bytes(gzip.compress(data,mtime=0))
  value={'name':name,'argv':args,'exitCode':run.returncode,'seconds':round(time.monotonic()-before,3),'log':log.name,'rawSha256':hashlib.sha256(data).hexdigest(),'rawBytes':len(data),'rawLines':len(data.splitlines())};rows.append(value);print(json.dumps(value),flush=True)
 value={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sourceWorkflowSha256':hashlib.sha256((root/'.github/workflows/release.yml').read_bytes()).hexdigest(),'selectedFiles':len(selected),'selectedBytes':sum((root/p).stat().st_size for p in selected if (root/p).is_file()),'omittedFiles':len(omitted),'omittedBytes':sum((root/p).stat().st_size for p in omitted if (root/p).is_file()),'omittedPathsRawSha256':hashlib.sha256(raw).hexdigest(),'commands':rows,'durationSeconds':round(time.monotonic()-started,3),'cumulativeChildPeakKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'scope':'Actual fast source commands against a temporary sparse working copy; direct governance children because the hosted-only wrapper must not impersonate GitHub Actions. No remote checkout or native execution.','independentAuthorshipCredit':0}
 receipt.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({k:v for k,v in value.items() if k!='commands'}));assert len(rows)==20 and all(row['exitCode']==0 for row in rows)
finally:
 shutil.rmtree(work)
 if 'index' in locals():index.unlink(missing_ok=True)
