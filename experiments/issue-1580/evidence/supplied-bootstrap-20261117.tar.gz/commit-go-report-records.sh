set -eu
test "$(git branch --show-current)" = issue-1580-8d61a32a61e1
git diff --check
git add docs/case-studies/issue-1580/README.md docs/case-studies/issue-1580/templates/README.md experiments/issue-1580/upstream/filed-issues.txt experiments/issue-1580/upstream/go-stale-pin-integrity-report.md experiments/issue-1580/upstream/template-report-identities.json experiments/issue-1580/work-plan.md
git commit -m 'docs: record published Go stale-pin integrity report'
git status --short
