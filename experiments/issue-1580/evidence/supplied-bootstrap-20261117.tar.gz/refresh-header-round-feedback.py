from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
out=Path('/tmp/issue-1580-research/header-round-preflight');out.mkdir(exist_ok=True)
old=Path('experiments/issue-1580/evidence/checks/python-release-formatting')
def run(args):
 p=subprocess.run(args,text=True,capture_output=True)
 if p.returncode:raise RuntimeError(str(args)+' '+p.stderr)
 return p.stdout
assert run(['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
summary={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':run(['git','rev-parse','HEAD']).strip(),'feedback':{}}
for suffix,name in [('issues/1580','feedback-issue'),('issues/1580/comments','feedback-issue-comments'),('pulls/1581','feedback-pull-request'),('issues/1581/comments','feedback-pull-request-comments'),('pulls/1581/comments','feedback-inline-comments'),('pulls/1581/reviews','feedback-reviews')]:
 raw=run(['gh','api','repos/link-assistant/formal-ai/'+suffix,'--paginate']);data=json.loads(raw)
 (out/(name+'.json.gz')).write_bytes(gzip.compress(raw.encode(),mtime=0))
 prev=json.loads(gzip.decompress((old/(name+'.json.gz')).read_bytes()))
 previous={row['id']:row for row in prev} if isinstance(prev,list) else {prev['id']:prev}
 rows=data if isinstance(data,list) else [data]
 changed=[row for row in rows if row['id'] not in previous or any(row.get(k)!=previous[row['id']].get(k) for k in ['body','state','draft'])]
 summary['feedback'][name]={'count':len(rows),'changedIds':[row['id'] for row in changed],'rawSha256':hashlib.sha256(raw.encode()).hexdigest()}
 for row in changed:
  text=json.dumps({k:row.get(k) for k in ['id','html_url','created_at','updated_at','state','draft','title','body']},ensure_ascii=False,indent=2)
  p=out/(name+'-'+str(row['id'])+'.txt');p.write_text(text+'\n')
  print('CHANGED',str(p),'lines',len(text.splitlines()))
print(run(['git','fetch','origin','main']))
summary['main']=run(['git','rev-parse','origin/main']).strip()
summary['mainIsAncestor']=subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD']).returncode==0
summary['branchRuns']={}
for status in ['in_progress','queued']:
 rows=json.loads(run(['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--status',status,'--limit','100','--json','databaseId,workflowName,headSha,createdAt']))
 summary['branchRuns'][status]=rows
summary['recentBranchRuns']=json.loads(run(['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','5','--json','databaseId,conclusion,createdAt,headSha']))
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
