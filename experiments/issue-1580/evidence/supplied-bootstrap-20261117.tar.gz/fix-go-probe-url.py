from pathlib import Path
path = Path('experiments/issue-1580/template-go-result-integrity.test.mjs')
source = path.read_text()
assert "new URL('file://'+script).href" in source
source = source.replace("import {fileURLToPath} from 'node:url';", "import {fileURLToPath,pathToFileURL} from 'node:url';")
source = source.replace("new URL('file://'+script).href", "pathToFileURL(script).href")
path.write_text(source)
