import json
import subprocess

branch = 'issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip() == branch
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],check=True)
for status in ['in_progress','queued']:
    rows = json.loads(subprocess.check_output(['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--status',status,'--limit','100','--json','databaseId,workflowName,headSha'],text=True))
    print(status, len(rows))
    assert not rows, 'wait for all branch runs before pushing'
subprocess.run(['git','push','origin','HEAD:refs/heads/'+branch],check=True)
print('published', subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
