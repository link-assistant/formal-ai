from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
def output(argv):return subprocess.check_output(argv,cwd=root,text=True).strip()
def run(argv):return subprocess.run(argv,cwd=root,check=True)
assert output(['git','branch','--show-current'])=='issue-1580-8d61a32a61e1'
assert output(['git','rev-parse','HEAD'])=='6b1d75a62a610e58914ef594c107f3fa402ded9d'
base=root/'experiments/issue-1580/evidence/checks/fast-source-archive-checkout'
v=json.loads((base/'publication-after-format/outcome.json').read_text());assert all(r['exitCode']==0 for r in v['commands'])
for p,expected in v['sources'].items():
 if p.endswith('supplied-bootstrap-20261117.tar.gz'):continue
 assert hashlib.sha256((root/p).read_bytes()).hexdigest()==expected,p
for r in v['commands']:
 raw=gzip.decompress((base/'publication-after-format'/(r['name']+'.log.gz')).read_bytes());assert hashlib.sha256(raw).hexdigest()==r['rawSha256']
run(['python3','/tmp/issue-1580-research/archive-round-bootstrap.py'])
run(['python3','/tmp/issue-1580-research/archive-evidence.py'])
run(['git','diff','--check'])
run(['git','add','.github/workflows/release.yml','changelog.d/20261117_120000_issue-1580-ci-regressions.md','docs/case-studies/issue-1580','experiments/issue-1580','rust/tests/web/fast-pull-request-production-profile.test.mjs','experiments/formal_ai_subagent/evidence/specification-delivery-1188/dormant-staged-release'])
run(['git','diff','--cached','--check'])
names=output(['git','diff','--cached','--name-only']).splitlines()
print(json.dumps({'stagedFiles':len(names),'sourceDiff':output(['git','diff','--cached','--numstat','--','.github/workflows/release.yml','rust/tests/web/fast-pull-request-production-profile.test.mjs']),'newCommandRecords':len([p for p in names if '/commands/' in p]),'sourceChecksVerified':len(v['commands'])}),flush=True)
run(['git','commit','-m','Reduce fast source checkout archive inputs'])
assert output(['git','status','--porcelain'])==''
print('COMMITTED',output(['git','rev-parse','HEAD']),flush=True)
