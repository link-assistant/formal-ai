from pathlib import Path
import json
p=Path('scripts/ci-pull-request-admission.mjs')
s=p.read_text()
anchor='export function nativeCompileInput(path) {\n'
insert="""// The focused native lane also executes isolated integration targets and an
// HTTP replay. Changes to their sources or consumed fixtures must run that lane.
const NATIVE_REGRESSION_INPUTS = new Set([
  'rust/tests/unit/calendar-currency.rs',
  'rust/tests/unit/openai_forced_functions.rs',
  'rust/tests/unit/meta_executor_parity.rs',
  'rust/tests/unit/specification/synthesis.rs',
  'rust/tests/fixtures/meta-executor-parity.json',
  'rust/tests/fixtures/meta-executor-status-parity.json',
  'rust/tests/fixtures/meta-executor-cue-parity.json',
  'data/parity/issue-1589-calendar-currency.json',
  'data/parity/issue-1590-forced-functions.json',
  'data/parity/cross-runtime-synthesis.json',
  'rust/tests/web/issue-1590-forced-functions.test.mjs',
  'rust/tests/web/support/structured-log-fixture.mjs',
  'js/server/structured-log.mjs',
]);
"""
assert anchor in s and 'NATIVE_REGRESSION_INPUTS' not in s
s=s.replace(anchor,insert+anchor)
s=s.replace("if (path === 'scripts/ci-clippy-profile.sh') return true;",
"if (NATIVE_REGRESSION_INPUTS.has(path) || ['scripts/ci-clippy-profile.sh',\n    'scripts/ci-pull-request-admission.mjs', 'scripts/lib/documentation-paths.mjs'].includes(path)) return true;")
p.write_text(s)
p=Path('rust/Cargo.toml');s=p.read_text()
anchor='[[test]]\nname = "integration"\n'
assert anchor in s and 'name = "synthesis_contracts"' not in s
s=s.replace(anchor,'# Replay the existing synthesis contracts without compiling the whole unit suite.\n[[test]]\nname = "synthesis_contracts"\npath = "tests/unit/specification/synthesis.rs"\n\n'+anchor)
p.write_text(s)
old='--test meta_executor_parity -- --test-threads=1'
new='--test meta_executor_parity --test synthesis_contracts -- --test-threads=1'
for name in ['.github/workflows/native-type-check.yml','rust/tests/web/default-branch-build-policy.test.mjs']:
    p=Path(name);s=p.read_text();assert s.count(old)==1,(name,s.count(old));p.write_text(s.replace(old,new))
p=Path('rust/tests/web/default-branch-build-policy.test.mjs');s=p.read_text()
old="'.github/actions/setup-sccache/action.yml', 'scripts/ci-clippy-profile.sh', 'clippy.toml', 'new-top-level/unknown.txt'"
new="""'.github/actions/setup-sccache/action.yml', 'scripts/ci-clippy-profile.sh', 'scripts/ci-pull-request-admission.mjs',
    'scripts/lib/documentation-paths.mjs', 'rust/tests/web/issue-1590-forced-functions.test.mjs',
    'rust/tests/web/support/structured-log-fixture.mjs', 'js/server/structured-log.mjs', 'clippy.toml', 'new-top-level/unknown.txt'"""
assert old in s;s=s.replace(old,new)
old="'rust/tests/unit/proof_request.rs', 'scripts/check-tests-as-docs.mjs'"
new="'rust/tests/unit/proof_request.rs', 'rust/tests/fixtures/unrelated.json', 'data/parity/unrelated.json', 'scripts/check-tests-as-docs.mjs'"
assert old in s;s=s.replace(old,new)
p.write_text(s)
Path('changelog.d/1580-native-regressions.md').write_text('''### Fixed

- Run the focused native PR check when its isolated regression tests, embedded
  fixtures, or HTTP replay inputs change. Replay the existing synthesis contracts
  in the same lane without compiling the complete unit test suite.
''')
print(json.dumps({'changed':['scripts/ci-pull-request-admission.mjs','rust/Cargo.toml',
    '.github/workflows/native-type-check.yml','rust/tests/web/default-branch-build-policy.test.mjs',
    'changelog.d/1580-native-regressions.md'],'nativeExecution':'hosted CI only','independentAuthorshipCredit':0}))
