from pathlib import Path
import gzip,json,sys
directory=Path("experiments/issue-1580/evidence/checks/python-release-formatting")
names=["check-generated-files","check-notation","layered-ci#4"]
if len(sys.argv)==1:
    for name in names:
        path=directory/"gate-details"/(name+".log.gz")
        text=gzip.decompress(path.read_bytes()).decode(errors="replace")
        print(name,"lines",len(text.splitlines()),"bytes",len(text.encode()))
else:
    name=sys.argv[1];assert name in names
    lines=gzip.decompress((directory/"gate-details"/(name+".log.gz")).read_bytes()).decode(errors="replace").splitlines()
    start=int(sys.argv[2]) if len(sys.argv)>2 else 1
    amount=int(sys.argv[3]) if len(sys.argv)>3 else 300
    assert 1<=amount<=1500
    print(name,"total lines",len(lines))
    for n,line in enumerate(lines[start-1:start-1+amount],start):print(f"{n}: {line}")
