from pathlib import Path
import subprocess

args=['rg','-n','write|fetch|argv|verify|build|spawn|exec|fingerprint','scripts/translate-js-rust.mjs']
result=subprocess.run(args,capture_output=True,text=True)
print(result.stdout);print(result.stderr)
path=Path('scripts/translate-js-rust.mjs')
lines=path.read_text().splitlines()
print('LINES',len(lines))
for number,line in enumerate(lines[:210],1):print(f'{number}: {line}')
path=Path('experiments/issue-1580/evidence/checks/child-evidence-provenance/resumed-check-tests-as-docs.log.gz')
target=path.with_name('resumed-check-tests-as-documentation.log.gz')
assert path.exists() and not target.exists()
path.rename(target)
print('RENAMED',path,'TO',target)
