from pathlib import Path
p=Path('rust/tests/unit/meta_executor_parity.rs')
s=p.read_text().replace('assert_eq!(answer.content, expected, "{prompt}");','assert_eq!(answer.answer, expected, "{prompt}");')
p.write_text(s)
