from pathlib import Path
import gzip, hashlib, json, subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
out=root/'experiments/issue-1580/evidence/ci/opener-native-boundary-edffcb18/failures'
assert not out.exists()
out.mkdir(parents=True)
run_id='44230021091'
def request(args):
    result=subprocess.run(['gh',*args],cwd=root,capture_output=True)
    assert result.returncode==0,result.stderr.decode()
    return result.stdout
def save(name,raw):
    (out/(name+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
    return {'path':name+'.gz','bytes':len(raw),'lines':len(raw.splitlines()),'sha256':hashlib.sha256(raw).hexdigest()}
receipt={'run':run_id,'head':'edffcb183a7a7f9d5d17967cfea94071aee57a90'}
receipt['aggregate']=save('layered-'+run_id+'.log',request(['run','view',run_id,'--repo','link-assistant/formal-ai','--log']))
jobs_raw=request(['api','repos/link-assistant/formal-ai/actions/runs/'+run_id+'/jobs?per_page=100','--paginate','--slurp'])
receipt['inventory']=save('jobs.json',jobs_raw)
receipt['failures']=[]
for page in json.loads(jobs_raw):
    for job in page['jobs']:
        if job['conclusion'] in ('success','skipped'): continue
        assert job['completed_at'],job
        raw=request(['api','repos/link-assistant/formal-ai/actions/jobs/'+str(job['id'])+'/logs','--allow-escape-sequences'])
        entry={key:job[key] for key in ('id','name','conclusion','started_at','completed_at')}
        entry['log']=save('job-'+str(job['id'])+'.log',raw)
        receipt['failures'].append(entry)
        print('FAILED_JOB',json.dumps(entry),flush=True)
        for number,line in enumerate(raw.decode().splitlines(),1):
            if any(token in line.lower() for token in ('not ok ','error:','error ','fatal:','# fail ','exit code','timed out')):
                print(str(number)+': '+line[:3000],flush=True)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('RECEIPT',json.dumps(receipt),flush=True)
