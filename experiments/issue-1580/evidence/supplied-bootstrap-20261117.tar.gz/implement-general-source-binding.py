from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/general-source-binding';base.mkdir(exist_ok=True)
source=root/'rust/src/solver_unknown_reasoning.rs';old=source.read_text()
target='''    let sense = senses
        .iter()
        .enumerate()
        .max_by_key(|(index, sense)| (sense.tier.weight_percent(), usize::MAX - index))?
        .1;
'''
replacement='''    // A retrieved definition answers only its named term. Rank source quality
    // after binding the sense to the request, so an unrelated high-tier source
    // cannot replace the question or a matching lower-tier definition. A
    // context-qualified query needs more evidence than a context-free gloss.
    let requested = crate::concepts::extract_concept_query(prompt).map_or_else(
        || normalize_fact_subject(prompt),
        |query| {
            if query.context.is_some() {
                String::new()
            } else {
                normalize_fact_subject(&query.term)
            }
        },
    );
    let selected = senses
        .iter()
        .enumerate()
        .filter(|(_, sense)| {
            !requested.is_empty()
                && [sense.surface.as_str(), sense.lemma.as_str()]
                    .into_iter()
                    .chain(sense.synonyms.iter().map(String::as_str))
                    .any(|term| normalize_fact_subject(term) == requested)
        })
        .max_by_key(|(index, sense)| (sense.tier.weight_percent(), usize::MAX - index));
    let Some((_, sense)) = selected else {
        if !senses.is_empty() {
            log.append(
                "reasoning:gather_result",
                "external_source:no_verified_answer".to_owned(),
            );
        }
        return None;
    };
'''
assert old.count(target)==1;new=old.replace(target,replacement)
new=new.replace('''    let focus_normalized = normalize_search_surface(focus);
    let padded_focus = format!(" {focus_normalized} ");''','''    let focus_normalized = normalize_fact_subject(focus);''')
target='''            let normalized = normalize_search_surface(&candidate);
            if normalized.len() < 3 {
                continue;
            }
            // A surface names the focus as whole words: "colour" inside
            // "colourless" is no mention of colour (issue #1175 p329). A
            // script written without spaces keeps the substring reading.
            let matches = normalized == focus_normalized
                || padded_focus.contains(&format!(" {normalized} "))
                || (normalized.chars().any(is_unspaced_script)
                    && focus_normalized.contains(&normalized));
            if matches {'''
replacement='''            let normalized = normalize_fact_subject(&candidate);
            if normalized.len() < 3 {
                continue;
            }
            // A cached definition must cover the complete extracted focus.
            // Mentioning a concept inside an operative question does not make
            // its encyclopedia summary an answer to that question.
            if normalized == focus_normalized {'''
assert new.count(target)==1;new=new.replace(target,replacement)
target='''/// Whether `ch` belongs to a script written without spaces (kana, CJK, hangul).
const fn is_unspaced_script(ch: char) -> bool {
    matches!(
        ch,
        '\\u{3040}'..='\\u{30ff}' | '\\u{3400}'..='\\u{9fff}' | '\\u{ac00}'..='\\u{d7af}'
    )
}

'''
assert new.count(target)==1;new=new.replace(target,'');source.write_text(new)
tests=root/'rust/tests/unit/solver_unknown_reasoning_captured_sources.rs';prior=tests.read_text()
unknown='''I could not determine `{focus}` from local Links Notation memory, cached public knowledge, or the source cache, and cannot infer a verified answer. I recorded the failed gather attempts in the trace.

If reasoning still cannot resolve this and a shared Links Notation seed fact or links rule is needed, use Report issue with the trace. To keep a dialog-local rule durable, export memory or teach it with `When I say ... answer ...`; inspect routes with `List behavior rules` and `Show behavior rule unknown`.

I detected a failure while working on this request. Would you like me to prepare an issue report with the diagnostic context? Reply `Report issue`.'''
def literal(text):return json.dumps(text,ensure_ascii=False)
extra=''
for name,prompt,focus,senses in [
 ('operative_question_cannot_be_replaced_by_a_retrieved_word_definition','How should an isogram be calibrated for teal silence?','an isogram be calibrated for teal silence','&[captured_sense("isogram", "en")]'),
 ('a_definition_request_cannot_use_a_different_retrieved_term','What is a snorflax?','a snorflax','&[captured_sense("isogram", "en")]'),
 ('a_cached_concept_mention_cannot_replace_an_operative_question','How should WebAssembly be calibrated for teal silence?','WebAssembly be calibrated for teal silence','&[]'),
]:
 extra+='''
#[test]
fn '''+name+'''() {
    let mut log = EventLog::new();
    let answer = answer_unknown_prompt(
        '''+literal(prompt)+''',
        Language::English,
        &mut log,
        offline_config(),
        '''+senses+''',
    );
    assert_eq!(answer.intent, "unknown");
    assert_eq!(answer.answer, '''+literal(unknown.format(focus=focus))+''');
    assert!(!log.events().iter().any(|event| {
        event.kind == "reasoning:gather_result"
            && (event.payload.starts_with("external_source:hit:")
                || event.payload.starts_with("public_knowledge_cache:hit:"))
    }));
}
'''
extra+='''
#[test]
fn an_unrelated_higher_tier_sense_cannot_replace_the_requested_definition() {
    let mut unrelated = captured_sense("isograma", "es");
    unrelated.tier = SourceTier::OriginalFirstParty;
    let mut log = EventLog::new();
    let answer = answer_unknown_prompt(
        "What is an isogram?",
        Language::English,
        &mut log,
        offline_config(),
        &[unrelated, captured_sense("isogram", "en")],
    );
    assert_eq!(answer.intent, "concept_lookup");
    assert_eq!(answer.answer, "isogram (isogram): a line drawn on a map connecting points having the same numerical value of some variable\\n\\nSource: https://en-word.net/api/lemma/isogram (sha256 ae8c98f774fd255a; CC BY 4.0)");
    assert!(log.events().iter().any(|event| {
        event.kind == "reasoning:gather_result" && event.payload.starts_with("external_source:hit:")
    }));
}

#[test]
fn an_explicit_cached_concept_request_keeps_its_complete_attributed_answer() {
    let mut log = EventLog::new();
    let answer = answer_unknown_prompt(
        "Use cached public knowledge about WebAssembly",
        Language::English,
        &mut log,
        offline_config(),
        &[],
    );
    assert_eq!(answer.intent, "concept_lookup");
    assert_eq!(answer.answer, "WebAssembly (runtime): WebAssembly (Wasm) is a binary instruction format for a stack-based virtual machine. It is designed as a portable compilation target for programming languages, enabling deployment on the web for client and server applications.\\n\\nSource: https://en.wikipedia.org/wiki/WebAssembly (wikipedia).");
    assert!(log.events().iter().any(|event| {
        event.kind == "reasoning:gather_result" && event.payload.starts_with("public_knowledge_cache:hit:")
    }));
}
'''
assert 'fn operative_question_cannot_be_replaced' not in prior;tests.write_text(prior+extra)
subprocess.run(['rustfmt',str(source),str(tests)],check=True)
record={'sources':[{'file':str(source.relative_to(root)),'beforeSha256':hashlib.sha256(old.encode()).hexdigest(),'afterSha256':hashlib.sha256(source.read_bytes()).hexdigest()},{'file':str(tests.relative_to(root)),'beforeSha256':hashlib.sha256(prior.encode()).hexdigest(),'afterSha256':hashlib.sha256(tests.read_bytes()).hexdigest()}],'newNativeCases':5,'nativeExecutedLocally':False,'independentAuthorshipCredit':0}
(base/'implementation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
