import json
from pathlib import Path

data = json.loads(Path('/tmp/issue-1580-research/java-pom-structure.json').read_text())
plugins = data['build']['plugins']['plugin']
for plugin in plugins:
    if plugin['artifactId'] in ['maven-jar-plugin', 'maven-source-plugin', 'maven-javadoc-plugin']:
        print(json.dumps(plugin, indent=2))
print('build keys', list(data['build']))
print('root keys', list(data))
