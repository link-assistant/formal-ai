import hashlib
import json
import os
from pathlib import Path
import textwrap

source_path=Path('rust/src/agentic_coding/tool_result/source_observation.rs')
test_path=Path('rust/tests/source/source_tests/agentic_coding/tool_result/source_observation/opencode_tests.rs')
source=source_path.read_text()
marker='#[cfg(test)]\nmod opencode_tests {\n'
assert source.count(marker)==1
production,body=source.split(marker)
assert body.endswith('}\n')
body=textwrap.dedent(body[:-2])
old_include='../../../embedded/data/parity/issue-1580-opencode-read-envelope.json'
fixture=Path('rust/embedded/data/parity/issue-1580-opencode-read-envelope.json')
assert (source_path.parent/old_include).resolve()==fixture.resolve()
new_include=os.path.relpath(fixture,test_path.parent)
assert body.count(old_include)==1
moved=body.replace(old_include,new_include)
assert not test_path.exists()
test_path.parent.mkdir(parents=True,exist_ok=True)
test_path.write_text(moved)
registration=os.path.relpath(test_path,source_path.parent)
source_path.write_text(production+f'#[cfg(test)]\n#[path = "{registration}"]\nmod opencode_tests;\n')
assert moved.replace(new_include,old_include)==body
receipt={'schema':'issue-1580-external-test-move/v1','source':str(source_path),'test':str(test_path),'registration':registration,'fixtureInclude':new_include,'fixtureSha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'testBodyPreservedExceptRelativeInclude':True,'originalTestBodySha256':hashlib.sha256(body.encode()).hexdigest(),'movedTestBodySha256':hashlib.sha256(moved.encode()).hexdigest(),'nativeExecution':False,'beforeEvidence':'https://github.com/link-assistant/formal-ai/actions/runs/44180825006#summary'}
base=Path('experiments/issue-1580/evidence/checks/external-opencode-test')
base.mkdir(parents=True,exist_ok=True)
(base/'move.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
