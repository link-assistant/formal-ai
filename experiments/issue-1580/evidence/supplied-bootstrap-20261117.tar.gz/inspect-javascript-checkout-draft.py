from pathlib import Path
import subprocess
for title,args in [('source-diff',['git','diff','--','.github/workflows/layered-ci.yml','rust/tests/web/fast-pull-request-production-profile.test.mjs']),('previous-change-files',['git','diff','--name-only','26f3f332^','26f3f332'])]:
    run=subprocess.run(args,capture_output=True,text=True);assert run.returncode==0;print(title+'\n'+run.stdout)
path=Path('experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md')
print(str(path)+'\n'+path.read_text())
