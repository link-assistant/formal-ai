from pathlib import Path
import gzip,hashlib,json,subprocess
for name in ['docs/case-studies/issue-1580/README.md','docs/case-studies/issue-1580/templates/README.md','experiments/issue-1580/work-plan.md']:
 p=Path(name);s=p.read_text();before='Seventy-one active files, both generated bundles, both locks and all 126 historical blobs remain unread.';assert s.count(before)==1
 p.write_text(s.replace(before,'Seventy-one active files (including both generated bundles and both locks) and all 126 historical blobs remain unread.'))
directory=Path('experiments/issue-1580/evidence/ci/e120c05b4');path=directory/'44112040276.log.gz';raw=gzip.decompress(path.read_bytes());lines=raw.decode().splitlines()
expected=['python: failed Git is reported as a successful no-code observation','Python pinned manual fragment creation silently replaces an earlier same-second change','Python candidate rejects a same-second collision and preserves the earlier bytes','Python separate timestamps retain both descriptions before and after the guard','Python invalid bump remains a fatal nonmutating argument error before and after the guard','missing or old Python fails hosted observations while remaining optional locally','the selected JavaScript shard provisions Python before executing the pinned observations']
observations=[]
for name in expected:
 hits=[{'line':n,'text':line} for n,line in enumerate(lines,1) if name in line]
 assert len(hits)==1 and '✔' in hits[0]['text'] and 'SKIP' not in hits[0]['text']
 observations.append({'test':name,**hits[0]})
record={'head':'e120c05b4d8e35d51e4c1efb95e9b0c46c8d42b5','run':44112040276,'url':'https://github.com/link-assistant/formal-ai/actions/runs/44112040276','log':path.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'observations':observations}
(directory/'python-runtime-verification.json').write_text(json.dumps(record,indent=2)+'\n')
print('HOSTED_PYTHON_VERIFIED',[(r['line'],r['test']) for r in observations])
print(subprocess.run(['git','diff','--cached','--','scripts/check-javascript-dependencies.sh','rust/tests/web/javascript-audit-inventory.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs','experiments/issue-1580/template-python-audit-integrity.test.mjs','experiments/issue-1580/fixtures/python-template/source.json','changelog.d/20261117_1580_audit_inventory.md'],capture_output=True,text=True,check=True).stdout)
