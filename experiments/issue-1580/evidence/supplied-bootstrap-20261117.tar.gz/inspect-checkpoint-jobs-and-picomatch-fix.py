import json
import pathlib
import subprocess

scratch=pathlib.Path('/tmp/issue-1580-research')
result=subprocess.run(['gh','run','view','44180825006','--repo','link-assistant/formal-ai','--json','status,conclusion,headSha,jobs,url'],text=True,capture_output=True,check=True)
(scratch/'checkpoint-layered-jobs.json').write_text(result.stdout)
data=json.loads(result.stdout)
print(json.dumps({key:data[key] for key in ['status','conclusion','headSha','url']},indent=2))
print(json.dumps([{'name':job['name'],'status':job['status'],'conclusion':job['conclusion'],'startedAt':job['startedAt'],'completedAt':job['completedAt'],'failedSteps':[step['name'] for step in job['steps'] if step['conclusion']=='failure']} for job in data['jobs']],indent=2))
result=subprocess.run(['gh','pr','view','194','--repo','micromatch/picomatch','--json','title,state,mergedAt,headRefOid,baseRefName,body,url'],text=True,capture_output=True)
(scratch/'picomatch-pull-194.json').write_text(result.stdout+result.stderr)
print('UPSTREAM',result.stdout if result.returncode==0 else result.stderr)
result=subprocess.run(['npm','view','picomatch','version','dist.integrity','--json'],text=True,capture_output=True)
(scratch/'picomatch-registry-version.json').write_text(result.stdout+result.stderr)
print('REGISTRY',result.stdout if result.returncode==0 else result.stderr)
