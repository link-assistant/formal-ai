import subprocess
for args in [
 ['rg','-n','solveIndependentQuestions|tryPromptText|promptTextAnswer|prompt_text_answer|extractPromptText','js','ts','rust/src/solver_handlers'],
 ['rg','-n','solve_independent|independent_questions|prompt_text','rust/src/solver*.rs'],
]:
    r=subprocess.run(args,text=True,capture_output=True);print('COMMAND',args,'EXIT',r.returncode);print(r.stdout,r.stderr)
