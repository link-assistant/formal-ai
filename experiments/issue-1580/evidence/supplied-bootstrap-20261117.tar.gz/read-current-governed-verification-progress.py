from pathlib import Path
import json, subprocess

base=Path('experiments/issue-1580/evidence/checks/picomatch-governed-refresh')
path=Path('/tmp/issue-1580-research/governed-refresh-all-local-gates.log')
print('CURRENT_PROGRESS')
print('\n'.join(path.read_text().splitlines()[-12:]))
receipt=base/'all-local-gates.json'
if receipt.exists():
    value=json.loads(receipt.read_text())
    print('CURRENT_RECEIPT',json.dumps({key:row for key,row in value.items() if key!='gateLogs'}))
else: print('CURRENT_RECEIPT_PENDING')
path=Path('/tmp/issue-1580-research/picomatch-pr-description.md')
print('PR_BODY_BYTES',path.stat().st_size)
if path.stat().st_size<13000: print(path.read_text())
else: print('PR_BODY_REQUIRES_CHUNKS')
print('MEMORY',Path('/sys/fs/cgroup/memory.current').read_text().strip())
