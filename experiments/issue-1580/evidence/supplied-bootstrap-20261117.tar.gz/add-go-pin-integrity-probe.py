from pathlib import Path
import hashlib
import json

root = Path.cwd()
fixture = root / 'experiments/issue-1580/fixtures/go-template'
relative = 'scripts/ci/check-dependencies.mjs'
source = Path('/tmp/issue-1580-research/templates/go-complete') / relative
data = source.read_bytes()
provenance_path = fixture / 'source.json'
provenance = json.loads(provenance_path.read_text())
assert provenance['commit'] == '65c686846d7327d8c835a0d30b1a76cc6345cfc6'
inventory = json.loads(Path('/tmp/issue-1580-research/templates/go-complete-inventory.json').read_text())
identity = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
assert next(item for item in inventory if item['path'] == relative)['gitBlob'] == identity
target = fixture / relative
assert not target.exists()
target.write_bytes(data)
provenance['files'].append({'path': relative, 'gitBlob': identity, 'sha256': hashlib.sha256(data).hexdigest()})
provenance_path.write_text(json.dumps(provenance, indent=2) + '\n')
test_path = root / 'experiments/issue-1580/template-go-result-integrity.test.mjs'
test_source = test_path.read_text()
assert 'stale-pin integrity' not in test_source
test_source += r'''
test('Go stale-pin integrity failures become warnings; independent verification preserves failures', {timeout:5000}, async()=>{
  const {checkDependencies,report}=await import('./fixtures/go-template/scripts/ci/check-dependencies.mjs');
  const dependency={name:'actions/checkout',kind:'action',version:'1.0.0',ref:'1'.repeat(40),location:'fixture.yml:1'};
  const events=['push','schedule','workflow_dispatch','pull_request'];
  const codes=(reporter,errors)=>events.map(event=>reporter(errors,{
    event,total:1,githubActions:false,stdout:{write:()=>{}},stderr:{write:()=>{}},
  }));
  async function observe(check,version,badPin){
    let verified=0;
    const errors=await check([dependency],{
      latest:async()=>version,
      verifyPin:async()=>{verified+=1;if(badPin)throw new Error('Pinned SHA does not match the release tag');},
    });
    return {verified,errors};
  }
  const current=await observe(checkDependencies,'1.0.0',true);
  assert.equal(current.verified,1);
  assert.deepEqual(codes(report,current.errors),[1,1,1,1]);
  const stale=await observe(checkDependencies,'2.0.0',true);
  assert.equal(stale.verified,0,'the actual upstream checker skips integrity for stale versions');
  assert.deepEqual(stale.errors.map(error=>error.stale),[true]);
  assert.deepEqual(codes(report,stale.errors),[0,0,0,1]);

  const directory=mkdtempSync(join(tmpdir(),'issue-1580-stale-pin-'));
  try{
    cpSync(join(fixture,'scripts'),join(directory,'scripts'),{recursive:true});
    const script=join(directory,'scripts/ci/check-dependencies.mjs');
    const original=readFileSync(script,'utf8');
    const boundary='        continue;\n      }\n      const key';
    assert.equal(original.split(boundary).length,2,'one stale-version early return');
    writeFileSync(script,original.replace(boundary,'      }\n      const key'));
    const repaired=await import(new URL('file://'+script).href);
    for(const version of ['1.0.0','2.0.0']){
      const invalid=await observe(repaired.checkDependencies,version,true);
      assert.equal(invalid.verified,1);
      assert.ok(invalid.errors.some(error=>!error.stale&&/Pinned SHA/.test(error.message)));
      assert.deepEqual(codes(repaired.report,invalid.errors),[1,1,1,1]);
      const valid=await observe(repaired.checkDependencies,version,false);
      assert.equal(valid.verified,1);
      assert.deepEqual(codes(repaired.report,valid.errors),version==='1.0.0'?[0,0,0,0]:[0,0,0,1]);
    }
  }finally{rmSync(directory,{recursive:true,force:true});}
});
'''
test_path.write_text(test_source)
print(json.dumps({'fixture': relative, 'gitBlob': identity, 'testAdded': True}))
