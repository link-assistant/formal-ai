import gzip, hashlib, json, pathlib, subprocess

root = pathlib.Path('experiments/issue-1580/evidence/ci/main-826289fc')
raw = pathlib.Path('/tmp/issue-1580-research/pipeline-44157125186.log')
if not raw.exists():
    with raw.open('wb') as output:
        subprocess.run(['gh', 'run', 'view', '44157125186', '--repo', 'link-assistant/formal-ai', '--log'], stdout=output, check=True)
data = raw.read_bytes()
(root / 'pipeline-44157125186.log.gz').write_bytes(gzip.compress(data, mtime=0))
lines = data.decode().splitlines()
summary = {'run': 44157125186, 'head': '826289fc78154dcd894199ed966f366176be0afb', 'bytes': len(data), 'lines': len(lines), 'sha256': hashlib.sha256(data).hexdigest()}
(root / 'pipeline-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
needles = ('FAILED', 'panicked at', 'test result:', 'timed out', 'Process completed with exit code', 'error:', 'Error:', 'GHSA-', 'failures:', 'failed:', 'TIMEOUT')
matches = []
for n, line in enumerate(lines, 1):
    if any(needle in line for needle in needles):
        matches.append({'line': n, 'text': line})
(root / 'pipeline-failure-index.json.gz').write_bytes(gzip.compress(json.dumps(matches).encode(), mtime=0))
print(f'{len(matches)} indexed diagnostics; first 35:')
for row in matches[:35]:
    print(f'{row["line"]}: {row["text"][:700]}')
