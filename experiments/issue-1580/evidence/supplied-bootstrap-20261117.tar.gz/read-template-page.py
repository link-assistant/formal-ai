from pathlib import Path
import hashlib
import json
import sys

language = sys.argv[1]
page = int(sys.argv[2])
base = Path('/tmp/issue-1580-research/templates')
folder = base / (language+'-complete')
inventory = json.loads((base/(language+'-complete-inventory.json')).read_text())
records = []
for item in sorted(inventory, key=lambda item:item['path']):
    raw = (folder/item['path']).read_bytes()
    identity = hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest()
    assert identity == item['gitBlob'], item['path']
    if b'\0' in raw:
        records.append(f"{item['path']}: binary {len(raw)} bytes, blob {identity}")
        continue
    for number, line in enumerate(raw.decode('utf-8', errors='replace').splitlines(),1):
        records.append(f"{item['path']}:{number}: {line}")
start = (page-1)*450
assert 0 <= start < len(records), (page,len(records))
print(f'LANGUAGE {language} PAGE {page}/{(len(records)+449)//450} TOTAL {len(records)} lines')
print('\n'.join(records[start:start+450]))
