from pathlib import Path
import gzip,hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048');target=root/'experiments/issue-1580/evidence/checks/general-source-binding/prior-publication';target.mkdir(exist_ok=True);allrows=[]
for folder in ['language-main-publication','language-main-publication-retry']:
 source=Path('/tmp/issue-1580-research')/folder;dest=target/folder;dest.mkdir(exist_ok=True);rows=[]
 for path in sorted(source.iterdir()):
  if not path.is_file():continue
  raw=path.read_bytes();name=path.name.replace('edit-pr.','edit-pull-request.').replace('pr-details.','pull-request-details.').replace('whole-pr-diff.','whole-pull-request-diff.')+'.gz';packed=gzip.compress(raw,mtime=0);(dest/name).write_bytes(packed);assert gzip.decompress((dest/name).read_bytes())==raw
  rows.append({'originalName':path.name,'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw)})
 outcome=json.loads((source/'outcome.json').read_text());report={'folder':folder,'outcome':outcome,'files':rows,'independentAuthorshipCredit':0};(dest/'manifest.json').write_text(json.dumps(report,separators=(',',':'))+'\n');allrows.append({'folder':folder,'files':len(rows),'complete':outcome.get('complete'),'pushExecuted':outcome.get('pushExecuted')})
source=Path('/tmp/issue-1580-research/frozen-formal-driver-a748854');old=root/'experiments/issue-1580/evidence/checks/language-main-integration/bootstrap-recovery';oldfiles={x['file'] for x in json.loads((old/'manifest.json').read_text())['records']};dest=target/'worker-identity-recovery';dest.mkdir(exist_ok=True);rows=[]
for path in sorted((source/'experiments/issue-1580/evidence/commands').glob('*.json')):
 name=path.name+'.gz'
 if name in oldfiles:continue
 raw=path.read_bytes();value=json.loads(raw);packed=gzip.compress(raw,mtime=0);(dest/name).write_bytes(packed);rows.append({'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'status':value['status'],'source':value['source'],'signal':value['signal'],'independentAuthorshipCredit':0,'validationCredit':0})
(dest/'manifest.json').write_text(json.dumps({'records':rows,'purpose':'Frozen coherent snapshot used only to inspect and refresh the maintained worker prerequisite identities; every command and all supplied reasoning retain zero validation and independent capability credit.'},indent=2)+'\n')
print(json.dumps({'publications':allrows,'newRecoveryRecords':len(rows)},indent=2))
