from pathlib import Path
import json

root=Path('/tmp/gh-issue-solver-1794900398048')
evidence=root/'experiments/issue-1580/evidence'
receipt=Path('/tmp/issue-1580-research/opener-boundary-publication.json')
assert receipt.exists()
(evidence/'ci/opener-native-boundary-edffcb18/publication-verification.json').write_text(receipt.read_text())
changelog=root/'changelog.d/20261117_120000_issue-1580-ci-regressions.md'
with changelog.open('a') as stream:
    stream.write('- Use the declared answer-language policy for unresolved JavaScript requests, retaining the full localized failure report and actual detected-language trace.\n')
document=root/'docs/case-studies/issue-1580/declared-language-policy-checkpoint.md'
assert not document.exists()
document.write_text('''# Declared answer languages and unresolved JavaScript requests

Issue: https://github.com/link-assistant/formal-ai/issues/1580
Pull request: https://github.com/link-assistant/formal-ai/pull/1581

The original unchanged native Spanish fixture distinguishes an adopted definition
frame from an unresolved operative question. Its complete how-question response
includes the unresolved focus, shared guidance and failure-report invitation.
After the localized opener correction, the production JavaScript worker still
returned the generic localized teaching response for that question.

## Cause and change

`data/seed/agent-info.lino` declares the answer languages as a reference list.
The native terminal reasoning path checks this declaration; the JavaScript helper
previously accepted only the detector's `unknown` language. Detection recognizes
Spanish, which is absent from the answer-language declaration, so it bypassed the
helper and lost the native fixture's complete unresolved-reasoning response.

The helper now reads the declaration with the maintained Links Notation list
parser. A language outside that declaration can reach the existing terminal
unresolved response after earlier handlers and source research decline. No
language identifier or test prompt is added to production routing. Whole-prompt
focus delimiters follow the native quote and terminal-punctuation handling, and
the trace keeps the actual detected language. The helper continues to distinguish
observed local matches from verified answers.

## Reproduction and verification

Run the focused file separately:

```sh
timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/worker-unknown-language.test.mjs
```

The new full-response regression extracts both inputs and the complete expected
body from the unchanged native fixture, rather than replacing it with a shortened
expectation. A held-out control changes the declared metadata while keeping the
same language value. Before the production change, six cases passed and both new
cases failed. After the change, all eight cases pass, including Persian, Arabic,
empty-input, greeting, unverified-memory and localized opener controls.

The complete before/after logs and command outcomes are retained under
`experiments/issue-1580/evidence/checks/declared-language-policy/`. The before log
is 5,121 bytes, SHA-256 `13e633d926000ed1d06f292027540c720aa1936b36f7f0e3104a4c3e158b1db2`;
the after log is 884 bytes, SHA-256 `db6f0196c9a76dcd1c2f69ad98ceb7a1a9eb7d7963f0918db3191ecfebc7ae11`.
Both complete logs were read. Affected publication gates remain pending.

## Published-head CI and limits

On edffcb18, all 23 workflows completed: 22 passed and Layered CI failed at
checkout in JavaScript suite group 2. Direct job 134552599041 has 171 lines,
all read. Lines 124–126 show the configured low-speed abort, bad pack header and
promisor fetch failure for the `.bun-version` blob. No application test ran in
that job. The aggregate run log, paginated job inventory and complete direct job
log are retained under `experiments/issue-1580/evidence/ci/opener-native-boundary-edffcb18/`.
One failed-job retry was requested after preserving the original attempt. The
underlying transport cause and retry result are not yet verified.

The preceding publication metadata assertion failed because it stripped only the
local body's terminal newline. Fresh verification confirms the exact GitHub body
and remote head; this was not a missing push or description update.

No native application build or test was run. The original adopted Spanish
definition route, the native full-response regression and the wider native,
template, upstream, benchmark and independent-reasoning requirements remain
unfinished. Supplied scripts, tests, patches and conclusions receive zero
independent authorship credit. Keep PR #1581 draft and the goal active.
''')
plan=root/'experiments/issue-1580/work-plan.md'
source=plan.read_text()
source=source.replace('- [ ] Reproduce the complete original Spanish how-question answer mismatch and a held-out metadata-policy control before changing production code. Preserve both failing assertion payloads.','- [x] Reproduce the complete original Spanish how-question answer mismatch and a held-out metadata-policy control before changing production code. Both fail before the fix; preserve both complete assertion payloads.')
source=source.replace('- [ ] Use the maintained seed list parser for the JavaScript terminal policy, preserve actual detected-language trace metadata and native whole-prompt punctuation handling; retain positive supported-language routes.','- [x] Use the maintained seed list parser for the JavaScript terminal policy, preserve actual detected-language trace metadata and native whole-prompt punctuation handling; all eight focused cases pass, including positive supported-language routes.')
source+='\nThe complete edffcb18 CI inventory has 22 passing workflows and one checkout failure; the sole failed direct log is read in full (171 lines). Preserve the original transport failure and request one failed-job retry, then await it before publication. The transport root cause remains unverified. Evidence and acceptance limits: `docs/case-studies/issue-1580/declared-language-policy-checkpoint.md`.\n'
plan.write_text(source)
print('DOCUMENTED declared-language policy, failing and passing regressions, prior-head CI limits',flush=True)
