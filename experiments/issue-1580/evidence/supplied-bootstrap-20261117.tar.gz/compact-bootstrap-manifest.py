from pathlib import Path
import gzip, hashlib, json

base = Path('/tmp/issue-1580-research')
out = Path('experiments/issue-1580/evidence')
checks = out / 'checks/csharp-changeset-collision'
checks.mkdir(parents=True, exist_ok=True)
manifest = out / 'supplied-bootstrap-20261117.json'
original = manifest.read_bytes()
decoded = json.loads(original)
backup = checks / 'bootstrap-manifest-size-failure.json.gz'
assert not backup.exists(), backup
backup.write_bytes(gzip.compress(original, mtime=0))
records = []
for source, target in [
    (Path('experiments/formal_ai_subagent/sandboxes/gates/check-file-size.log'), checks / 'bootstrap-manifest-size-failure.log.gz'),
    (checks / 'archive-check-file-size.log.gz', checks / 'archive-check-file-size-failed.log.gz'),
]:
    raw = source.read_bytes()
    assert not target.exists(), target
    target.write_bytes(raw if source.suffix == '.gz' else gzip.compress(raw, mtime=0))
    records.append({'file': str(target), 'source': str(source), 'sourceBytes': len(raw), 'sourceSha256': hashlib.sha256(raw).hexdigest()})

writer = base / 'archive-round-bootstrap.py'
source = writer.read_text()
old = "(out/'supplied-bootstrap-20261117.json').write_text(json.dumps({'autonomousAuthorshipCredit':0,'archiveSha256':hashlib.sha256(payload).hexdigest(),'files':rows},indent=2)+'\\n')"
new = "(out/'supplied-bootstrap-20261117.json').write_text('{\\n  \\\"autonomousAuthorshipCredit\\\": 0,\\n  \\\"archiveSha256\\\": '+json.dumps(hashlib.sha256(payload).hexdigest())+',\\n  \\\"files\\\": [\\n'+',\\n'.join('    '+json.dumps(row,separators=(',', ':')) for row in rows)+'\\n  ]\\n}\\n')"
assert source.count(old) == 1
writer.write_text(source.replace(old, new))
compile(writer.read_text(), str(writer), 'exec')

compact = '{\n  "autonomousAuthorshipCredit": '+json.dumps(decoded['autonomousAuthorshipCredit'])+',\n  "archiveSha256": '+json.dumps(decoded['archiveSha256'])+',\n  "files": [\n'+',\n'.join('    '+json.dumps(row,separators=(',', ':')) for row in decoded['files'])+'\n  ]\n}\n'
assert json.loads(compact) == decoded
manifest.write_text(compact)
assert json.loads(manifest.read_bytes()) == decoded
metadata = {'reason': 'Formatting only: one bootstrap file record per line preserves all manifest entries and hashes without changing the maintained file limit.', 'beforeLines': len(original.splitlines()), 'afterLines': len(compact.splitlines()), 'beforeSha256': hashlib.sha256(original).hexdigest(), 'afterSha256': hashlib.sha256(compact.encode()).hexdigest(), 'preservedFiles': len(decoded['files']), 'structurallyIdentical': True, 'logs': records, 'autonomousAuthorshipCredit': 0}
(checks / 'bootstrap-manifest-formatting.json').write_text(json.dumps(metadata, indent=2)+'\n')
print(json.dumps(metadata, indent=2))
