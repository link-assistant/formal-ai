set -eu
cat /tmp/issue-1580-research/current-head-status.py
cat /tmp/issue-1580-research/archive-seventh-round.py
git diff --stat
git status --short
