from pathlib import Path
import json,subprocess
root=Path('experiments/issue-1580/upstream')
research=Path('/tmp/issue-1580-research')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/issue-1580-8d61a32a61e1'],text=True).split()[0]
assert head==remote,(head,remote)
fixture='experiments/issue-1580/template-shared-git-observation.test.mjs'
expected=subprocess.check_output(['git','rev-parse',f'HEAD:{fixture}'],text=True).strip()
visible=subprocess.check_output(['gh','api',f'repos/link-assistant/formal-ai/contents/{fixture}?ref={head}','--jq','.sha'],text=True).strip()
assert visible==expected,(visible,expected)
cases=[
 ('go','CI: manual release skips lint/build/publication but terminal status passes','go-manual-release-report.md',17),
 ('go','CI: failed Git comparisons become successful no-code change outputs','go-change-detection-report.md',17),
 ('java','CI: failed Git comparisons become successful no-code change outputs','java-change-detection-report.md',29),
 ('python','CI: failed Git comparisons become successful no-code change outputs','python-change-detection-report.md',155),
 ('php','CI: failed Git comparisons become successful no-code change outputs','php-change-detection-report.md',25),
]
record=research/'filed-template-reports.json'
results=json.loads(record.read_text()) if record.exists() else []
for language,title,body,known_max in cases:
 repo=f'link-foundation/{language}-ai-driven-development-pipeline-template'
 pages=json.loads(subprocess.check_output(['gh','api',f'repos/{repo}/issues?state=all&per_page=100','--paginate','--slurp'],text=True))
 issues=[item for page in pages for item in page]
 (research/f'{language}-issues-at-report.json').write_text(json.dumps(issues,indent=2)+'\n')
 existing=next((item for item in issues if item['title']==title),None)
 if existing:
  url=existing['html_url']
 else:
  unexpected=[{'number':item['number'],'title':item['title']} for item in issues if item['number']>known_max and not any(x['url']==item['html_url'] for x in results)]
  assert not unexpected,('Read fresh upstream issues before filing',repo,unexpected)
  url=subprocess.check_output(['gh','issue','create','--repo',repo,'--title',title,'--body-file',str(root/body)],text=True).strip()
 if not any(x['url']==url for x in results):results.append({'repository':repo,'title':title,'url':url,'bodyFile':body,'evidenceCommit':head})
 record.write_text(json.dumps(results,indent=2)+'\n')
 print(url,flush=True)
print('Filed or reused',len(results),'template reports; no publishing workflows dispatched.')
