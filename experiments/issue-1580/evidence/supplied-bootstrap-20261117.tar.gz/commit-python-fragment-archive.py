import pathlib, subprocess

def run(arguments):
    return subprocess.run(arguments, text=True, capture_output=True, check=True).stdout

assert run(['git', 'branch', '--show-current']).strip() == 'issue-1580-8d61a32a61e1'
assert run(['git', 'rev-parse', 'HEAD']).strip() == '9c018344df2e6b09a0f2496897b14a002dad62f4'
paths = [
    'experiments/issue-1580/evidence/commands',
    'experiments/issue-1580/evidence/supplied-bootstrap-20261117.json',
    'experiments/issue-1580/evidence/supplied-bootstrap-20261117.tar.gz',
    'experiments/issue-1580/evidence/checks/python-fragment-collision/after-archive-check-abbreviations.log.gz',
    'experiments/issue-1580/evidence/checks/python-fragment-collision/after-archive-check-file-size.log.gz',
    'experiments/issue-1580/evidence/checks/python-fragment-collision/after-archive-check-file-size-js-twin.log.gz',
    'experiments/issue-1580/evidence/checks/python-fragment-collision/gates-after-archive.json',
    'experiments/issue-1580/upstream/python-fragment-collision-report.md',
]
changed = run(['git', 'status', '--porcelain', '-uall']).splitlines()
for entry in changed:
    name = entry[3:]
    assert any(name == path or name.startswith(path + '/') for path in paths), entry
run(['git', 'add', '--', *paths])
run(['git', 'diff', '--cached', '--check'])
print(run(['git', 'diff', '--cached', '--stat']), flush=True)
print(run(['git', 'commit', '-m', 'docs: retain Python collision report and execution evidence']), flush=True)
assert not run(['git', 'status', '--porcelain']).strip()
print('Committed archive; working tree clean.', flush=True)
