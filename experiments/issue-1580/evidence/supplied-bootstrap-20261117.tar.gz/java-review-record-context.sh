set -eu
sed -n '1,165p' docs/case-studies/issue-1580/templates/go-semantic-review.json
cat /tmp/issue-1580-research/read-template-ci-page.py
rg --files scripts .github/actions .github/workflows rust/tests/web | rg 'release|runner|dependencies|dependabot|file-size|changelog|version|retry|rerun|actions-log|workflow|security|lint|pre-commit|change'
