from pathlib import Path
import subprocess

path=Path('experiments/issue-1580/trace-moon-lexeme.mjs')
source=path.read_text().replace("const before = unknownTerms(reports.withoutBecause);", "console.log(JSON.stringify({counts: Object.fromEntries(Object.entries(reports).map(([key, report]) => [key, counts(report)])), unknownSamples: unknownTerms(reports.withoutBecause).slice(0, 3), becauseSentences: Object.fromEntries(Object.entries(reports).map(([key, report]) => [key, report.sentences.filter(sentence => /because/iu.test(sentence.text)).map(sentence => ({text: sentence.text, unknown: sentence.unknown}))]))}, null, 2));\nconst before = unknownTerms(reports.withoutBecause);")
path.write_text(source)
result=subprocess.run(['node','--max-old-space-size=256',str(path)],text=True,capture_output=True)
log=Path('/tmp/issue-1580-research/moon-lexeme-probe-diagnostic.log')
log.write_text(result.stdout+result.stderr)
print(f'LOG {log} exit={result.returncode}')
print(log.read_text())
