from pathlib import Path
import collections,datetime,gzip,hashlib,json,shutil,subprocess

path=Path('docs/case-studies/issue-1580/templates/python-partial-semantic-review.json')
review=json.loads(path.read_text());assert review['activeReadLines']==16040
inventory=json.loads(Path('/tmp/issue-1580-research/python-active-source-inventory.json').read_text())
active={row['path']:row for row in inventory['active']}
deferred={'.github/actions/artifact/dist/835.index.mjs','.github/actions/artifact/dist/index.mjs','.github/actions/artifact/package-lock.json','uv.lock'}
selected=[(row['path'],n) for row in inventory['active'] if row['path'] not in deferred for n in range(1,row['lines']+1)]
assert len(selected)==21394
decisions={
 'tests/test_detect_code_changes.py':'Read all 73 lines: path classification and exclusion precedence are covered. The failed/partial Git-observation reproductions remain separately recorded; no new runtime assertion is inferred from reading this file.',
 'tests/test_extract_artifact.py':'Read all 88 lines: offline CLI fixtures cover nested empty/binary files, traversal and drive/backslash paths, symlinks/special files, destination symlinks and corrupt ZIPs. Whole-archive validation before extraction is applicable; no upstream test execution or arbitrary archive-size guarantee is claimed.',
 'tests/test_issue_118_workflows.py':'Read all 155 lines: workflow policies cover exact bot identity, writer queuing, versioned actions, complete link scanning with day-scoped cache, artifact presence, dependency-graph gating, dispatch defaults, local Pages transport, ShellCheck and exact PR-head superseding. Assertions are source policies, not fresh hosted proof.',
 'tests/test_issue_126_workflows.py':'Read all 39 lines: full CodeQL analysis is checked before preserving reports and all artifact operations use the transport wrapper. This is source review, not a CodeQL scan or artifact transfer.',
 'tests/test_issue_133_workflows.py':'Read all 195 lines: Pages exact artifact identity, dependency-free action imports, immutable installer pins, day-scoped link cache, npm inventory coverage, Dependabot surfaces, stale bundle repair guidance and patched dependency assertions are covered. The npm inventory success gap is already separately reproduced/reported as #158; these lexical checks do not close it.',
 'tests/test_issue_140_concurrency.py':'Read all 93 lines: every job is checked on main and PR refs for isolated check groups and a shared non-cancelling writer group; cancelled superseded checks may pass while writers fail, and only the serialized Pages deploy configures the site. Read-only review; no settings mutation or hosted concurrency acceptance.',
 'tests/test_issue_147_workflows.py':'Read all 42 lines: PR caches restore only, main cache saves occur on miss, both architecture digest pins are required, and manual release dispatch retains actions permission and stale-publish refusal. Docker PR caching/build behavior is template-specific and cannot override this repository default-branch build policy.',
 'tests/test_issue_91.py':'Read all 307 lines: runner pins, bounded transient retries, final-failure retention, exact GitHub contents API mapping, token separation, redirect refusal, remaining-budget forwarding and default-off external fallback behavior are tested. No real URL acceptance or upstream pytest execution is claimed.',
 'tests/test_issue_98.py':'Read all 172 lines: Git defaults, shell-expression isolation, scanner pin compatibility, resumable package publication with propagation checks, both Python layouts, full CodeQL filtering and throttled GitHub link checks are asserted. Keep result integrity and deadlines; no registry publication or dependency installation occurred.',
 'tests/test_lychee_install_and_scan.py':'Read all 253 lines: loopback fixtures distinguish one-shot failure from bounded verified downloads, reject digest/asset/version drift, select architecture pins, and execute the exact workflow scan command with a stand-in process. The stale-report clearing and nonzero/zero-result distinction are applicable; source review alone does not execute these cases.',
 'tests/test_my_package.py':'Read all 64 lines: example addition, multiplication and asynchronous delay assertions. These teach the Python template package API; no corresponding Formal AI arithmetic capability or benchmark result is inferred.',
 'tests/test_preflight_credentials.py':'Read all 359 lines: local fake OIDC/PyPI/Docker endpoints distinguish verified, refused and unknown credentials; the Docker write probe cancels its fake upload, all failures remain visible, publisher guidance depends on observed registry state, and secrets stay out of output. No real credential probe, upload or account mutation was performed.',
 'tests/test_preview_regeneration_docs.py':'Read all 30 lines: the preview parity gap is explicitly retained until a browser surface exists, with discoverability assertions. This documentation contract is not a visual regression or proof of browser app support.',
 'tests/test_project_metadata.py':'Read all 57 lines: declared mypy compatibility and current options, documentation dependency parity and universal-lock version constraints are checked. The generated lock itself remains unread; package installation and full resolution validation are not claimed.',
 'tests/test_read_manifest.py':'Read all 81 lines: table-aware TOML version reading rejects missing/non-string fields and supports GitHub output. Prefer parsed metadata to grep scrapes. No upstream pytest execution is claimed.',
 'tests/test_recheck_broken_links.py':'Read all 432 lines: distinguish status answers from unanswered transport failures; preserve request policy, bounded retries and healthy-only recovery, deduplicate URLs and keep live-link failure gating when evidence is missing or malformed. Recovery-helper exit zero is advisory and does not release the parent gate by itself; no live link scan ran.',
 'tests/test_release_integrity.py':'Read all 338 lines: real isolated Git histories exercise complete-tree source/dependency/mode/fragment provenance, sole-parent metadata releases, clean checkout and nested-layout boundaries, detached HEAD publication, identical-commit retry/adoption and preserved manual inputs. Source drift defers for fresh CI instead of rebasing a validated build. No actual upstream suite, remote push or release was executed here.',
 'tests/test_release_workflow.py':'Read all 582 lines: every release/dependency condition, least-privilege scope, timeout, required context, fresh merge, detected package layout, metadata-aware tag and package smoke check is asserted. Template PR Docker builds explicitly conflict with the local default-branch build policy; retain the useful provenance, failure and deadline contracts without enabling PR application builds.',
 'tests/test_run_with_budget_warning.py':'Read all 270 lines: separate streams/status survive relaying; overruns warn then terminate whole groups, stubborn descendants receive bounded escalation even after root exit, and inside-budget commands remain successful. The fixture treats an exited zombie as terminated; our browser regression instead reaps its own descendant before exact ESRCH. No upstream timing suite was run.',
 'tests/test_simulate_fresh_merge.py':'Read all 139 lines: fake Git covers required base ref, bounded transient recovery, persistent failure and invalid retry settings. Broader return-code/path integrity is covered by our separate unchanged-source reproductions; these source assertions are not actual fresh-merge execution.',
 'tests/test_smoke_test_published_package.py':'Read all 130 lines: package/import/console metadata comes from project config, captured output remains literal, exact published versions retry with bounded delay and previews avoid shell pipelines. No live pip install or consumer publication acceptance occurred.',
 'tests/test_sphinx_compat.py':'Read all 31 lines: the Napoleon option compatibility shim runs with warnings as errors and its class mutation is restored by pytest. Sphinx-specific behavior is not a Formal AI runtime dependency requirement.',
 'tests/test_validate_changeset.py':'Read all 400 lines: isolated histories require genuinely added committed fragments, preserve bot/exemption scope, validate replacement content, reject missing/unrelated refs and failed diffs, account for deleted/renamed source, and keep checkout drift or shell-like ref data from changing the verdict. The useful complete-observation/committed-content contracts are applicable; no upstream pytest execution is claimed.',
 'tests/test_version_and_commit.py':'Read all 358 lines: table-aware versions, numeric changelog collection, rule refusals before lost-race classification, bounded identical-commit transient retry and default-off diagnostics are asserted. Failed source provenance and policy refusals never become successful publication. No release commit, remote push or fresh upstream test run occurred.',
 'tests/test_workflows.py':'Read all 457 lines: complete security/dependency/link/status coverage, scoped caches, opt-in Pages deploy, job/step deadline headroom, supported concurrency, lint/audit pins, Dependabot scan inclusion, explicit credential persistence and per-job write permissions are checked. Lexical fixture counts are not a substitute for a parsed complete reference graph, already maintained separately here.',
 'tests/test_zizmor_compatibility.py':'Read all 97 lines: action/CLI compatibility follows the selected complete upstream tree and exact supported version entries; ambiguous pins, truncated metadata and lookup failures stay fatal. No network compatibility lookup or scanner execution was performed in this source review.',
 'tests/workflow_helpers.py':'Read all 183 lines: indentation-based helpers locate workflow jobs, steps, run blocks, conditions, timeouts, action identities and concurrency keys, and reserve 30 percent of the job cap for setup. These helpers support this fixed template layout and are not arbitrary YAML parsing; our shared template observations retain parsed complete workflows/reference closure.',
}
ranges=collections.defaultdict(set)
for row in review['files']:
 for first,last in row['readRanges']:ranges[row['path']].update(range(first,last+1))
for name,n in selected:ranges[name].add(n)
root=Path('/tmp/issue-1580-research/templates/python-complete')
changed=[]
for row in review['files']:
 assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256']
 if row['path'] not in active:continue
 numbers=sorted(ranges[row['path']]);merged=[]
 for n in numbers:
  if merged and merged[-1][1]+1==n:merged[-1][1]=n
  else:merged.append([n,n])
 row['readRanges']=merged
 if row['path'] in decisions:
  row['decision']=decisions[row['path']];changed.append(row['path'])
 row['reviewStatus']='active-source-fully-read' if len(numbers)==row['lines'] else 'active-source-partially-read' if numbers else 'active-source-unread'
status=collections.Counter(row['reviewStatus'] for row in review['files'])
review['counts']={key:status[key] for key in review['counts']}
review['activeReadLines']=sum(len(ranges[name]) for name in active)
assert review['activeReadLines']==21394 and status['active-source-fully-read']==199 and status['active-source-unread']==4 and status['active-source-partially-read']==0
assert set(changed)==set(decisions)
review['readMethod']=review['readMethod'].replace('pages 1-40','pages 1-54')
header={k:v for k,v in review.items() if k!='files'}
path.write_text(json.dumps(header,indent=2)[:-2]+',\n  "files": [\n'+',\n'.join('    '+json.dumps(row,ensure_ascii=False,separators=(',',':')) for row in review['files'])+'\n  ]\n}\n')
old='The Python review now fully reads 172 active files plus one partial file (16,040/44,284 active lines), through corrected pages 1-40 and separately read release/helper tests. The 30 unread active files'
new='The Python review now fully reads 199 active files (21,394/44,284 active lines), through corrected pages 1-54 and separately read release/helper tests. The four unread active files'
for name in ['docs/case-studies/issue-1580/README.md','docs/case-studies/issue-1580/templates/README.md','experiments/issue-1580/work-plan.md']:
 p=Path(name);text=p.read_text();assert text.count(old)==1;p.write_text(text.replace(old,new))

ci=Path('experiments/issue-1580/evidence/ci/d0b8b8956')
(ci/'README.md').write_text('''# Published-header batch hosted verification

All 24 workflows completed successfully on commit d0b8b895661c6b5e809810c4da8a3db9f79138b3. runs.json and summary.json preserve exact identities and timestamps. Layered CI run [44134042788](https://github.com/link-assistant/formal-ai/actions/runs/44134042788) is preserved in full: 8,507 lines / 1,520,382 raw bytes, SHA-256 6b661d33f53860fd239b9e46a39aff139716d39099b8e8dcd58da21bca619fc3.

selected-test-execution.json matches every passing title from the retained focused local logs to an actual hosted passing line. All ten audit cases executed at lines 3986–3995, including both registry-outage variants and the failed/partial/empty Git inventory controls. All 38 maintained template cases executed at lines 7825–7862; the four Python release-formatting cases are at lines 7859–7862. Python setup selected and installed 3.15.2 at lines 6684 and 6696. These selected cases did not skip.

Scope-gated pull-request success does not establish main-only native test execution, benchmark floors, upstream repairs, package publication, live serving identity or complete issue acceptance. Supplied verification and orchestration earn zero independent Formal AI reasoning credit.
''')
target=Path('experiments/issue-1580/evidence/checks/generated-header-memory/pr-review');target.mkdir(exist_ok=True)
source=Path('/tmp/issue-1580-research/header-pr-review')
for name in ['summary.json','github-diff-error.txt','github-file-inventory.json.gz','full.diff.gz','new-source.diff']:
 shutil.copyfile(source/name,target/name)
(target/'README.md').write_text('''# Complete PR inventory and source review

GitHub refused gh pr diff because the PR exceeds its 300-file combined-diff limit. The exact response, complete paginated inventory and full local merge-base-to-head diff are retained. All 2,003 changed paths and every GitHub blob identity match the local base/head trees. The full diff has 51,298 lines; preserving it does not claim all lines were read in this pass.

The new source changes across eight files were read completely in two bounded pages, 530 lines total. The review preserved production deadline behavior, exact descendant-removal assertions, all audit inventory failure controls, generated-file registration and stale-exception policy. The chosen fast inventory now includes the dedicated audit tests; the unknown-gate negative control still refuses execution. No further source defect was identified in those patches.
''')
push=Path('/tmp/issue-1580-research/header-push')
target=Path('experiments/issue-1580/evidence/checks/generated-header-memory/published-preflight');target.mkdir(exist_ok=True)
for source in push.iterdir():
 if source.is_file():shutil.copyfile(source,target/source.name)
with Path('experiments/issue-1580/work-plan.md').open('a') as stream:
 stream.write('\nHosted d0b8b8956 verification: all 24 workflows passed, with literal execution of all ten audit and 38 maintained template cases verified in the full log. Python formatter report #159 is filed with an exact published body hash and immutable reproductions. Complete paginated PR inventory matches all 2,003 Git paths/blob identities; 530 newly changed source lines were reviewed. Python active semantic review reaches 199 complete files and 21,394 lines; both generated bundles, both locks, all 126 historical files and broader template applicability/runtime acceptance remain unfinished. Next: investigate native failure payloads and remaining source review without local Rust builds or PR build-policy bypasses. The overall issue goal remains active and the PR remains draft.\n')
subprocess.run(['git','diff','--check'],check=True)
print(json.dumps({'pythonFullyRead':199,'pythonReadLines':21394,'pythonUnreadActive':4,'historicalUnread':126,'decisionsAdded':len(changed),'hostedWorkflowsPassed':24,'hostedSelectedAuditTests':10,'hostedMaintainedTests':38,'autonomousAuthorshipCredit':0},indent=2))
