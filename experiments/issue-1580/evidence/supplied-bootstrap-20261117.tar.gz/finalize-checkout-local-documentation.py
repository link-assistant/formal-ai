from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/checks/fast-source-archive-checkout'
receipt=json.loads((base/'staged-transition-clean-environment.json').read_text())
assert receipt['exitCode']==0 and receipt['counts']=={'tests':3,'pass':3,'fail':0,'skipped':0},receipt
p=root/'docs/case-studies/issue-1580/checkout-archive-checkpoint.md'
s=p.read_text();old='local gates and the pinned-runner check pass; the stage transition regression\nis recorded separately.'
assert old in s
s=s.replace(old,'local gates and the pinned-runner check pass. All three stage transition\nregressions pass. The first invocation preserves a 2/3 result because inherited\n`NODE_OPTIONS` violates the proof subprocess guard. Clearing that inherited\nvariable, while retaining the test process CLI heap cap, passes 3/3; the\nproduction environment guard remains intact.')
p.write_text(s)
p=root/'experiments/issue-1580/work-plan.md'
p.write_text(p.read_text()+'''\nThe existing staged-release activation transition tests pass 3/3 after clearing\ninherited NODE_OPTIONS, which the proof subprocess correctly refuses. Preserve\nthe initial 2/3 failure and the corrected clean-environment invocation separately.\nThe production guard is unchanged. Broad acceptance remains unfinished.\n''')
old=(Path('/tmp/issue-1580-research/calendar-health-pull-request-description.md').read_text())
start=old.index('The published input `2ec6ef93`')
end=old.index('\n\nThe [calendar/cache checkpoint]',start)
new='''The published input `6b1d75a6` has **22/23 successful workflows** after one unchanged-head failed-job retry. [Layered CI 44207032757](https://github.com/link-assistant/formal-ai/actions/runs/44207032757) passes; [pipeline 44207033000](https://github.com/link-assistant/formal-ai/actions/runs/44207033000) still fails checkout with curl 28, early EOF and an unavailable promisor blob before source checks execute. Native type/lint passes. Complete logs and source identities are retained. The transport root cause remains unproved.

This update extends the fast source checkout's existing archive exclusions to historical `.gz`, `.log`, `.zip`, `.tgz` and `.diff` files under case studies and experiment evidence. Selected working-tree bytes fall from 732,862,187 to 413,103,005, with every measured source and authored diagnostic retained. The regression passes **15/16 before and 16/16 after**. All **20 underlying fast source checks** pass against an actual materialized sparse selection; the hosted-only debt wrapper is verified through its exported measurement/check functions without impersonating Actions. This reduces inputs; it does not prove the hosted transport failure fixed. Hosted CI for the next head remains pending.

The required staged projection is refreshed with the maintained generator, preserving all **52 staged operations, 104 bindings and deployed staged workflow bytes**. The deployed projection check, **3/3 stage transition tests**, seven touched JavaScript gates and pinned runner labels pass. The stage proof's strict environment guard is preserved; the initial inherited-`NODE_OPTIONS` refusal and corrected invocation are retained. Reproduce with `rust/tests/web/fast-pull-request-production-profile.test.mjs`, `rust/tests/web/staged-release-activation-transition.test.mjs` (clean `NODE_OPTIONS`), and `node scripts/generate-staged-release.mjs --check-deployed`.'''
old=old[:start]+new+old[end:]
old=old.replace('Java historical review reaches pages 1–37/254, 34 complete files and one partial; the remaining review is unfinished.','Java historical literal review covers pages 1–38 and 48–55/254, 52 complete files and two partials; pages 39–47 and the remaining review stay unfinished. Parsed compile/test vulnerability payload comparison is recorded separately from literal coverage.')
old=old.replace('The [calendar/cache checkpoint]','The [checkout checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/checkout-archive-checkpoint.md), [calendar/cache checkpoint]')
Path('/tmp/issue-1580-research/checkout-archive-pull-request-description.md').write_text(old)
print('Updated the checkpoint and work plan; prepared reviewable PR description with pending hosted CI and unfinished criteria.')
print(subprocess.check_output(['git','diff','--stat'],cwd=root,text=True))
