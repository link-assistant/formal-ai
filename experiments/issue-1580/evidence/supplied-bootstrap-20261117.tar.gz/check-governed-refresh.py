import pathlib, subprocess, gzip, hashlib, json, time

root=pathlib.Path.cwd()
evidence=root/'experiments/issue-1580/evidence/checks/picomatch-governed-refresh'
results=[]
for name in ['rust-specification-unicode-identifiers','rust-specification-fixture-integrity']:
    command=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs']
    started=time.time()
    result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    log=evidence/(name+'.log.gz')
    log.write_bytes(gzip.compress(result.stdout,mtime=0))
    receipt={'command':command,'exitCode':result.returncode,'seconds':round(time.time()-started,3),'rawSha256':hashlib.sha256(result.stdout).hexdigest(),'log':str(log.relative_to(root))}
    results.append(receipt)
    print(json.dumps(receipt),flush=True)
    print(result.stdout.decode(),flush=True)
    assert result.returncode == 0
(evidence/'focused-tests.json').write_text(json.dumps(results,indent=2)+'\n')
for p in sorted(pathlib.Path('/tmp/issue-1580-research').glob('*gate*')):
    if p.suffix in ['.py','.sh']:
        print('RUNNER',str(p),p.stat().st_size)
print('MEMORY',pathlib.Path('/sys/fs/cgroup/memory.current').read_text().strip())
