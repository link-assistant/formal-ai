from pathlib import Path
p=Path('rust/tests/web/default-branch-build-policy.test.mjs');s=p.read_text();assert 'the complete reasoning-loop and interpretation contracts execute' not in s
s+='''

test('the complete reasoning-loop and interpretation contracts execute in the focused native lane', {timeout:15000}, () => {
  for (const path of ['rust/tests/unit/reasoning_contracts.rs',
    'rust/tests/unit/specification/reasoning_loop.rs', 'rust/tests/unit/specification/formalization.rs'])
    assert.equal(admission([path])['native-type-check'], true, path);
  for (const path of ['rust/tests/unit/specification/unrelated.rs', 'rust/tests/fixtures/unrelated.json'])
    assert.equal(admission([path])['native-type-check'], false, path);
  const step = Object.values(workflow('native-type-check.yml').jobs)[0].steps.find(step => step.name === 'Verify isolated native behavior regressions');
  assert.match(step.run, /--test reasoning_contracts(?: |$)/u);
  assert.match(step.run, /--no-fail-fast/u);
  assert.match(read('rust/Cargo.toml'), /name = "reasoning_contracts"\\npath = "tests\\/unit\\/reasoning_contracts[.]rs"/u);
  const source = read('rust/tests/unit/reasoning_contracts.rs');
  for (const path of ['specification/reasoning_loop.rs', 'specification/formalization.rs'])
    assert(source.includes('#[path = "' + path + '"]'), path);
});
''';p.write_text(s)
print('Added a finite native-admission and execution regression; production selection remains unchanged for the before replay.')
