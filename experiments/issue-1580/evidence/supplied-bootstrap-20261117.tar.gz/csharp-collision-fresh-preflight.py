from pathlib import Path
import base64,datetime,hashlib,json,subprocess

repo='link-foundation/csharp-ai-driven-development-pipeline-template'
directory=Path('/tmp/issue-1580-research/csharp-collision-preflight')
directory.mkdir(exist_ok=True)
def api(endpoint,paginate=False):
    args=['gh','api']
    if paginate:args+=['--paginate','--slurp']
    args.append(endpoint)
    value=json.loads(subprocess.check_output(args,text=True))
    return [row for page in value for row in page] if paginate else value
issues=api(f'repos/{repo}/issues?state=all&per_page=100',True)
pulls=api(f'repos/{repo}/pulls?state=all&per_page=100',True)
comments=api(f'repos/{repo}/issues/78/comments?per_page=100',True)
head=api(f'repos/{repo}/commits/HEAD')['sha']
content=api(f'repos/{repo}/contents/scripts/merge-changesets.mjs?ref={head}')
source=base64.b64decode(content['content'])
matches=[]
for kind,rows in [('issue',[r for r in issues if not r.get('pull_request')]),('pull',pulls)]:
    for row in rows:
        text=(row['title']+'\n'+(row.get('body') or '')).lower()
        if any(term in text for term in ['merge-changesets','filename collision','file name collision','merged-bright','changeset filename','changeset it cannot parse']):
            matches.append({'kind':kind,'number':row['number'],'state':row['state'],'title':row['title'],'url':row['html_url'],'body':row.get('body') or ''})
for label,data in [('issues',issues),('pulls',pulls),('issue-78-comments',comments),('matching-items',matches)]:
    (directory/(label+'.json')).write_text(json.dumps(data,indent=2)+'\n')
(directory/'current-merge-changesets.mjs').write_bytes(source)
result={'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':repo,'head':head,'sourceBlob':content['sha'],'sourceSha256':hashlib.sha256(source).hexdigest(),'sameAsPinnedSource':content['sha']=='a57d1f941a39dd9aa23ef770a26f02d04fe9fc94','issueCount':sum(not r.get('pull_request') for r in issues),'pullCount':len(pulls),'matchingItems':[{'kind':r['kind'],'number':r['number'],'state':r['state'],'title':r['title'],'url':r['url']} for r in matches],'issue78Comments':len(comments),'interpretation':'Potentially related existing reports must be read before reporting. No report is created by this preflight.'}
(directory/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
for row in comments:print('ISSUE 78 COMMENT',row['html_url'],row['body'])
