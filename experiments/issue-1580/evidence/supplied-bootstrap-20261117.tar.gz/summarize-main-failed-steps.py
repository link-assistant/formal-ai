import gzip
import json
import pathlib
import re

directory = pathlib.Path("experiments/issue-1580/evidence/ci/main-512ce428")
completion = json.loads((directory / "failure-download-completion.json").read_text())
runs = completion["runs"]
for run in runs:
    print("RUN", run["runId"], run["workflowName"])
    wanted = {(job["name"], step) for job in run["failedJobs"] for step in job["failedSteps"]}
    groups = {key: [] for key in wanted}
    with gzip.open(directory / (run["runId"] + ".log.gz"), "rt") as source:
        for number, raw in enumerate(source, 1):
            fields = raw.rstrip().split("\t", 2)
            if len(fields) != 3 or tuple(fields[:2]) not in wanted:
                continue
            body = re.sub(r"^\d{4}-\d\d-\d\dT\S+\s", "", fields[2])
            groups[tuple(fields[:2])].append({"line": number, "text": body})
    for (job, step), lines in groups.items():
        print(json.dumps({"job": job, "step": step, "lines": len(lines)}))
        errors = [row for row in lines if re.search(r"^\s*(?:✖|not ok\b|thread .+panicked at|error(?:\[[^]]+\])?:|test result: FAILED)|##\[error\]|^.*(?:TIMEOUT|deadline exceeded|timed out after)", row["text"])]
        for row in errors:
            print(str(row["line"]) + ": " + row["text"])
        print("TAIL")
        for row in lines[-8:]:
            print(str(row["line"]) + ": " + row["text"])
    with gzip.open(directory / (run["runId"] + "-failed-steps.json.gz"), "wt") as sink:
        json.dump([{"job": job, "step": step, "lines": lines} for (job, step), lines in groups.items()], sink)
