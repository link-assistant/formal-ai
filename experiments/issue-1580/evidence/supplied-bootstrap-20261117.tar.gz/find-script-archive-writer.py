from pathlib import Path
import subprocess
root=Path('/tmp/issue-1580-research')
for p in sorted(root.glob('*.py')):
 s=p.read_text()
 if 'supplied-scripts' in s or 'supplied_scripts' in s:
  print('WRITER',p.name,'LINES',len(s.splitlines()))
  for i,line in enumerate(s.splitlines(),1):
   if any(t in line for t in ('supplied','manifest','glob(','.gz','archivePath','source_path')):print(i,line[:500])
for p in Path('experiments/issue-1580/evidence').glob('*'):
 if 'script' in p.name:print('ARCHIVE',p)
p=Path('/tmp/issue-1580-research/language-main-validation/all-local-gates.log')
lines=p.read_text().splitlines();print('GATE_PROGRESS',len(lines));print('\n'.join(lines[-8:]))
