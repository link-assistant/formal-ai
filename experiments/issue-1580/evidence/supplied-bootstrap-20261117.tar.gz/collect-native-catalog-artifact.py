from pathlib import Path
import subprocess,json,hashlib,gzip
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/google-native-catalog-artifact';base.mkdir(exist_ok=False)
scratch=Path('/tmp/issue-1580-research/google-native-catalog-artifact');scratch.mkdir(exist_ok=False)
argv=['gh','run','download','44595510266','--repo','link-assistant/formal-ai','--name','google-trends-native-fixtures','--dir',str(scratch/'download')]
p=subprocess.run(argv,capture_output=True)
row={'argv':argv,'exitCode':p.returncode,'run':44595510266,'head':'3c52b7f528b5f477ba04de297eb02bb41c298c78'}
for key,raw in [('stdout',p.stdout),('stderr',p.stderr)]:
 packed=gzip.compress(raw,mtime=0);name=key+'.gz';(base/name).write_bytes(packed);row[key]={'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()}
row['files']=[]
if p.returncode==0:
 for path in sorted((scratch/'download').rglob('*')):
  if path.is_file():
   raw=path.read_bytes();relative=path.relative_to(scratch/'download');out=base/relative;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
   row['files'].append({'file':str(relative),'bytes':len(raw),'lines':len(raw.splitlines()),'sha256':hashlib.sha256(raw).hexdigest()})
row['adopted']=False;row['nativeSourceIdentityVerified']=False;row['independentAuthorshipCredit']=0
(base/'manifest.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row,indent=2))
for path in ['rust/src/solver_unknown_reasoning.rs','data/seed/meanings-how.lino']:
 raw=(root/path).read_bytes();print(path,len(raw.splitlines()),hashlib.sha256(raw).hexdigest())
