from pathlib import Path
for p,a,b in [('experiments/issue-1580/work-plan.md',1,80),('/tmp/issue-1580-research/picomatch-pr-description.md',1,100),('docs/case-studies/issue-1580/main-444575f2-regressions.md',1,140)]:
    lines=Path(p).read_text().splitlines();print('SOURCE',p,'TOTAL',len(lines),'RANGE',a,b)
    for i in range(a-1,min(b,len(lines))):print(str(i+1)+': '+lines[i])
