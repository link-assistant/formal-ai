from pathlib import Path
import json

scratch = Path('/tmp/issue-1580-research')
for name in ('record-java-page-109.py', 'record-java-pages-101-108.py'):
    print('\nFILE ' + name)
    print((scratch / name).read_text())
manifest = json.loads((scratch / 'java-history-pages/manifest.json').read_text())
remaining = {}
for page in manifest[111:]:
    for name, label in page['sourceParts']:
        remaining.setdefault(name, []).append(label)
print('\nFORWARD FILES')
for name, labels in remaining.items():
    print(name, 'parts=', len(labels), 'range=', labels[0], labels[-1])
path = scratch / 'ci-logs/algebra-acb9fa51/latest-runs.json'
runs = [run for page in json.loads(path.read_text()) for run in page['workflow_runs']]
print('\nEXACT HEAD WORKFLOWS')
for run in runs:
    print(run['id'], run['name'], run['status'], run['conclusion'], run['created_at'], run['head_sha'][:8])
