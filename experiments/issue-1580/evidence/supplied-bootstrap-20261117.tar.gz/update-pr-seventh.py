import json
import subprocess
from pathlib import Path

d=json.loads(Path('/tmp/issue-1580-research/pr-before-seventh.json').read_text())
body=d['body']
body=body.replace('The latest batch adds executable evidence for shared template failures and preserves complete workflow execution fields.','The latest batch retains opt-in cache backend diagnostics, completes the Go source comparison, and adds an executed stale-pin integrity regression against unchanged upstream code.')
body=body.replace('The transitive semantic review remains open.','All 42 Go source blobs now have per-file semantic decisions; the seven other complete semantic reviews remain open.')
body=body.replace('passes ten tests locally','passes eleven tests locally')
body=body.replace('Existing policy/specification regressions pass,','Twelve cache regression cases pass, including the actual budget wrapper preserving successful and failed command exits; ShellCheck passes. Existing policy/specification regressions pass,')
start=body.index('The previous pushed head ')
end=body.index('Full logs, source identities',start)
body=body[:start]+('All 24 workflows on published head `09021cb30e` completed successfully. The new Go/cache batch at `e6627385d` is under verification. Cache diagnostics are off by default and retain at most 64 KiB / 80 lines with URL redaction and fresh workflow-command suspension tokens; this does not establish the historical backend failure cause. Local gate selection rejects unknown names and zero selected gates; its complete 11-test file and both actual file-size gates pass. ')+body[end:]
body=body.replace('[Go change detection #19](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/19),','[Go change detection #19](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/19), [Go stale-pin integrity #20](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/20),')
assert 'Fixes #1580' in body and 'Keep this PR draft and unmerged' in body
path=Path('/tmp/issue-1580-research/pr-body-seventh.md')
path.write_text(body)
subprocess.run(['gh','pr','edit','1581','--repo','link-assistant/formal-ai','--title',d['title'],'--body-file',str(path)],check=True)
print('Updated PR with published batch, executed tests, upstream report, and unfinished acceptance criteria.')
identities=Path('experiments/issue-1580/upstream/template-report-identities.json')
rows=json.loads(identities.read_text())
print('Identity format:',json.dumps(rows[-1],indent=2))
