#!/bin/sh
set -eu
rg -n 'curl|wget|docker pull' /tmp/issue-1580-research/templates/*-complete/.github/workflows --glob '*.yml' > /tmp/issue-1580-research/template-downloads.txt
cat /tmp/issue-1580-research/template-downloads.txt
sed -n '1,160p' scripts/work-item-qualification/command-capture.mjs
sed -n '1,140p' scripts/work-item-qualification/run-work-item-qualification.mjs
