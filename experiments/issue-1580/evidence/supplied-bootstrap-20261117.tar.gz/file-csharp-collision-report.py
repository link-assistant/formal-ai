from pathlib import Path
import datetime,gzip,hashlib,json,subprocess

repo='link-foundation/csharp-ai-driven-development-pipeline-template'
formal='link-assistant/formal-ai'
branch='issue-1580-8d61a32a61e1'
base=Path('experiments/issue-1580')
head=Path('/tmp/issue-1580-research/csharp-evidence-published-head.txt').read_text().strip()
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()==branch
def api(endpoint,paginate=False):
 args=['gh','api']+(['--paginate','--slurp'] if paginate else [])+[endpoint]
 value=json.loads(subprocess.check_output(args,text=True))
 return [row for page in value for row in page] if paginate else value
remote=api(f'repos/{formal}/git/ref/heads/{branch}')['object']['sha']
assert remote==head
test='experiments/issue-1580/template-csharp-changeset-integrity.test.mjs'
assert api(f'repos/{formal}/contents/{test}?ref={head}')['sha']==subprocess.check_output(['git','hash-object',test],text=True).strip()
upstream=api(f'repos/{repo}/commits/HEAD')['sha']
assert api(f'repos/{repo}/contents/scripts/merge-changesets.mjs?ref={upstream}')['sha']=='a57d1f941a39dd9aa23ef770a26f02d04fe9fc94'
issues=api(f'repos/{repo}/issues?state=all&per_page=100',True)
title='Changeset merge can delete every valid input when its output filename collides'
bodyFile=base/'upstream/csharp-changeset-output-collision-report.md'
body=bodyFile.read_text().replace('EVIDENCE_COMMIT',head)
assert 'EVIDENCE_COMMIT' not in body and body.count(head)==3
matching=[row for row in issues if not row.get('pull_request') and row['title']==title]
duplicates=[row for row in issues if row not in matching and not row.get('pull_request') and any(term in (row['title']+'\n'+(row.get('body') or '')).lower() for term in ['merged-bright-apple','changeset output collision','changeset filename collision','changeset file name collision'])]
assert not duplicates,[(row['number'],row['title']) for row in duplicates]
assert len(matching)<=1
bodyFile.write_text(body)
if matching:
 assert matching[0]['body']==body
 url=matching[0]['html_url']
else:
 url=subprocess.check_output(['gh','issue','create','--repo',repo,'--title',title,'--body-file',str(bodyFile)],text=True).strip()
posted=json.loads(subprocess.check_output(['gh','issue','view',url,'--repo',repo,'--json','body,title,url'],text=True))
assert posted['body']==body and posted['title']==title
record={'repository':repo,'title':title,'url':url,'bodyFile':bodyFile.name,'evidenceCommit':head}
identities=base/'upstream/template-report-identities.json'
rows=json.loads(identities.read_text())
if not any(row['url']==url for row in rows):rows.append(record)
identities.write_text(json.dumps(rows,indent=2)+'\n')
filed=base/'upstream/filed-issues.txt'
lines=filed.read_text().splitlines()
if url not in lines:filed.write_text(filed.read_text().rstrip()+'\n'+url+'\n')
evidence=base/'evidence/checks/csharp-changeset-collision'
receipt={**record,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'upstreamHead':upstream,'sourceBlob':'a57d1f941a39dd9aa23ef770a26f02d04fe9fc94','bodySha256':hashlib.sha256(body.encode()).hexdigest(),'remoteEvidenceVerified':True,'freshIssueRowsChecked':len(issues),'duplicateTitles':[],'claim':'Reported reproduced valid-input loss with immutable executable evidence; no upstream repair or complete template review is claimed.'}
(evidence/'filed-report.json').write_text(json.dumps(receipt,indent=2)+'\n')
(evidence/'filed-issue.json.gz').write_bytes(gzip.compress(json.dumps(posted,indent=2).encode()+b'\n',mtime=0))
docs=Path('docs/case-studies/issue-1580/templates/README.md')
old='The distinct upstream report is drafted and must cite immutable published evidence before filing.'
new=f'The finding is filed as [C# #{url.rsplit("/",1)[1]}]({url}) with immutable executable evidence at `{head}`. Reporting does not establish an upstream repair.'
assert old in docs.read_text()
docs.write_text(docs.read_text().replace(old,new))
case=Path('docs/case-studies/issue-1580/README.md')
case.write_text(case.read_text()+f'\nThe C# valid-input changeset-loss finding is filed as [upstream #{url.rsplit("/",1)[1]}]({url}), with immutable executable evidence at `{head}`. Its exact posted body and fresh source/duplicate checks are retained locally. Reporting is not an upstream repair or completion of the remaining review and native/runtime criteria.\n')
plan=base/'work-plan.md'
plan.write_text(plan.read_text()+f'\nThe distinct collision report is filed at [{repo}#{url.rsplit("/",1)[1]}]({url}) with published evidence `{head}`. Retain the posted body and verified source identity; do not infer an upstream repair or full acceptance.\n')
Path('/tmp/issue-1580-research/csharp-filed-report-url.txt').write_text(url+'\n')
print(json.dumps(receipt,indent=2))
