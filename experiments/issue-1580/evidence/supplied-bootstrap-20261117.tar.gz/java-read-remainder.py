import sys
from pathlib import Path

root = Path('/tmp/issue-1580-research/templates/java-complete')
name = sys.argv[1]
start, end = map(int, sys.argv[2:4])
assert 1 <= start <= end and end - start < 1500
print(name)
for number, line in enumerate((root / name).read_text().splitlines(), 1):
    if start <= number <= end:
        print(f'{number}: {line}')
