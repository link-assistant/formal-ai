from pathlib import Path
import gzip, hashlib, json, os, subprocess, sys, time, traceback
root = Path('/tmp/gh-issue-solver-1794900398048')
out = root / 'experiments/issue-1580/evidence/checks/declared-language-policy/final-publication'
if len(sys.argv) == 1:
    assert not out.exists()
    out.mkdir()
    with (out / 'worker.stdout.log').open('wb') as stdout, (out / 'worker.stderr.log').open('wb') as stderr:
        child = subprocess.Popen([sys.executable, __file__, 'worker'], cwd=root, stdout=stdout, stderr=stderr, start_new_session=True)
    (out / 'worker.json').write_text(json.dumps({'pid': child.pid}) + '\n')
    print('Started final publication checks', child.pid)
    sys.exit(0)
env = os.environ.copy()
env['NODE_OPTIONS'] = '--max-old-space-size=256'
selection = 'check-abbreviations,check-changelog-fragment-js-twin,check-fragment-release-map,check-file-size,check-reconstructed-changelog'
commands = [
    ('gates', ['node', '--max-old-space-size=256', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', selection]),
    ('type-projection', ['node', '--max-old-space-size=256', 'scripts/translate-es.mjs', '--check']),
    ('whitespace', ['git', 'diff', '--check']),
]
records = []
try:
    for name, argv in commands:
        started = time.monotonic()
        result = subprocess.run(argv, cwd=root, env=env, capture_output=True)
        raw = result.stdout + result.stderr
        (out / (name + '.log.gz')).write_bytes(gzip.compress(raw, mtime=0))
        row = {'name': name, 'argv': argv, 'exitCode': result.returncode, 'seconds': round(time.monotonic() - started, 3), 'rawBytes': len(raw), 'rawLines': len(raw.splitlines()), 'rawSha256': hashlib.sha256(raw).hexdigest()}
        records.append(row)
        print(json.dumps(row), flush=True)
        if name == 'gates':
            details = out / 'gate-details'
            details.mkdir()
            for gate in selection.split(','):
                source = root / 'experiments/formal_ai_subagent/sandboxes/gates' / (gate + '.log')
                (details / (gate + '.log.gz')).write_bytes(gzip.compress(source.read_bytes(), mtime=0))
    (out / 'outcome.json').write_text(json.dumps({'complete': True, 'records': records, 'nativeBehaviorVerified': False, 'autonomousAuthorshipCredit': 0}, indent=2) + '\n')
except BaseException:
    traceback.print_exc()
    (out / 'failure.txt').write_text(traceback.format_exc())
    sys.exit(1)
