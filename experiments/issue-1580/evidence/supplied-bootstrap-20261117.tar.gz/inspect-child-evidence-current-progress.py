from pathlib import Path
import json,subprocess
for folder in ['ci-logs/child-evidence-ffebedb1','synthesis-draft-validation']:
    base=Path('/tmp/issue-1580-research')/folder
    p=base/'worker.log';print(folder+'\n'+(p.read_text()[-2500:] if p.exists() else 'PENDING'))
    p=base/'outcome.json'
    if p.exists():
        d=json.loads(p.read_text());print(json.dumps({k:v for k,v in d.items() if k!='records'},indent=2))
result=subprocess.run(['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--status','in_progress','--json','databaseId,workflowName,headSha,createdAt'],text=True,stdout=subprocess.PIPE,check=True)
print(result.stdout)
