from pathlib import Path
import subprocess,gzip
result=subprocess.run(['ps','-eo','pid,ppid,etime,args'],capture_output=True,text=True)
print('\n'.join(line for line in result.stdout.splitlines() if any(v in line for v in ['check-python-runtime-draft','--test','plan-test-shards']) and 'formal-command' not in line))
directory=Path('experiments/issue-1580/evidence/checks/python-runtime-provisioning')
for name in ['runtime-regression.log.gz','maintained-observations.log.gz']:
 p=directory/name
 if p.exists():
  text=gzip.decompress(p.read_bytes()).decode();print(name,p.stat().st_mtime);print('\n'.join(text.splitlines()[-12:]))
print(subprocess.run(['git','diff','--stat'],capture_output=True,text=True).stdout)
print(subprocess.run(['git','diff','--','.github/workflows/layered-ci.yml','rust/tests/web/fast-pull-request-production-profile.test.mjs'],capture_output=True,text=True).stdout)
