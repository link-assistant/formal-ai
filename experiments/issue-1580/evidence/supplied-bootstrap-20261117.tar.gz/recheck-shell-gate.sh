set -eu
cp experiments/formal_ai_subagent/sandboxes/gates/lint-shell-scripts.log /tmp/issue-1580-research/lint-shell-scripts-fifth-failure.log
sha256sum /tmp/issue-1580-research/shellcheck-v0.11.0/shellcheck
PATH="/tmp/issue-1580-research/shellcheck-v0.11.0:$PATH"
export PATH
node experiments/formal_ai_subagent/local-gates.mjs --only lint-shell-scripts > /tmp/issue-1580-research/lint-shell-scripts-fifth-recheck.log 2>&1
cat /tmp/issue-1580-research/lint-shell-scripts-fifth-recheck.log
