from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path.cwd(); directory=root/'experiments/issue-1580'
names=['restore-synthesis.py','fix-known-checks.py','fix-receipt-tests.py','add-composition-tests.py','fix-production-composition.py','fix-concept-punctuation.py','fix-concept-worker.py','fix-delivery-fixtures.py','prepare-runtime-commit.py','finish-runtime-verification.py','fix-pr-status-and-prime.py']
archive=directory/'evidence/supplied-patches.tar.gz'
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as tar:
    for name in names:
        p=directory/name
        if not p.exists(): continue
        content=p.read_bytes(); item=tarfile.TarInfo(name); item.size=len(content); item.mtime=0; item.mode=0o644
        tar.addfile(item,io.BytesIO(content))
archive.write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
for name in names:
    (directory/name).unlink(missing_ok=True)
archive.with_suffix('.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
p=root/'data/benchmarks/fast-pull-request-javascript-tests.json'
value=json.loads(p.read_text())
for file in ['rust/tests/web/sccache-outage-fallback.test.mjs','rust/tests/web/worker-candidate-validation.test.mjs']:
    if file not in value['files']: value['files'].append(file)
p.write_text(json.dumps(value,indent=2)+'\n')
exclude=root/'.git/info/exclude'
s=exclude.read_text() if exclude.exists() else ''
for name in ['node_modules','.meta-language']:
    assert (root/name).is_symlink()
    pattern='/'+name
    if pattern not in s.splitlines(): s+='\n'+pattern+'\n'
exclude.write_text(s)
print('Archived supplied one-off patches with zero authorship credit; added both small production regressions to the fast lane.')
