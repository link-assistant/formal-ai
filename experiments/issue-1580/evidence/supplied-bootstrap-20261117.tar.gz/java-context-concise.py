import json
import sys
from pathlib import Path

base = Path('/tmp/issue-1580-research')
data = json.loads((base / 'java-context/issues.json').read_text())
number, start, end = map(int, sys.argv[1:])
row = next(row for row in data if row['number'] == number)
print(row['html_url'], row['title'])
assert end - start < 1500
for index, line in enumerate((row.get('body') or '').splitlines(), 1):
    if start <= index <= end:
        print(f'{index}: {line}')
