set -eu
test "$(git branch --show-current)" = issue-1580-8d61a32a61e1
python3 /tmp/issue-1580-research/archive-round-bootstrap.py
python3 experiments/issue-1580/archive-evidence.py
node experiments/formal_ai_subagent/local-gates.mjs --only check-file-size,check-file-size-js-twin,check-changelog-fragment-js-twin,check-ci-speed > /tmp/issue-1580-research/archive-seventh-gates.log 2>&1
cat /tmp/issue-1580-research/archive-seventh-gates.log
git add -- docs/case-studies/issue-1580/README.md experiments/issue-1580/work-plan.md experiments/issue-1580/upstream/go-stale-pin-integrity-report.md experiments/issue-1580/evidence
git diff --cached --check
git diff --cached --stat
git commit -m 'docs(ci): preserve successful checkpoint and Go/cache repair evidence'
git status --short
