import json,pathlib,subprocess
blob='9df886c42a1e2082f1471383d986fea4d531f8ac'
process=subprocess.run(['git','ls-tree','-r','HEAD'],capture_output=True,text=True)
assert process.returncode==0
matches=[line for line in process.stdout.splitlines() if blob in line]
size=subprocess.run(['git','cat-file','-s',blob],capture_output=True,text=True)
receipt={'blob':blob,'pathsAtHead':matches,'sizeCommandExitCode':size.returncode,'sizeBytes':size.stdout.strip(),'stderr':size.stderr}
pathlib.Path('experiments/issue-1580/evidence/ci/published-2ec6ef93/promisor-blob.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
