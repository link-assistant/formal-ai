from pathlib import Path

path=Path('experiments/issue-1580/compare-template-trees.mjs')
source=path.read_text()
old='workflows.push({path:file,name:document.name'
new='workflows.push({path:file,gitBlob:item.gitBlob,document,name:document.name'
assert source.count(old)==1
source=source.replace(old,new).replace('// One workflow per JSON line, preserving every run body for review.','// One workflow per JSON line. The complete parsed document preserves inputs,\n     // outputs, environments, services, reusable bindings and other execution fields.\n     // The remaining fields are a compact index, never the authoritative source.')
path.write_text(source)

test=Path('experiments/issue-1580/template-go-result-integrity.test.mjs')
source=test.read_text()
source+='''
test('Go initial-commit detection loses real source files without a comparison parent', {timeout:15000},()=>{
  const directory=mkdtempSync(join(tmpdir(),'issue-1580-real-git-'));
  try{
    cpSync(join(fixture,'scripts'),join(directory,'scripts'),{recursive:true});
    const git=(...args)=>{
      const result=spawnSync('git',args,{cwd:directory,encoding:'utf8',timeout:5000,maxBuffer:65536,
        env:{...process.env,GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:'/dev/null',GIT_AUTHOR_NAME:'Fixture',GIT_AUTHOR_EMAIL:'fixture@example.invalid',GIT_COMMITTER_NAME:'Fixture',GIT_COMMITTER_EMAIL:'fixture@example.invalid'}});
      assert.equal(result.status,0,result.stderr);
      return result.stdout;
    };
    git('init','--quiet');
    writeFileSync(join(directory,'main.go'),'package main\\nfunc main() {}\\n');
    git('add','main.go');
    git('-c','core.hooksPath=/dev/null','-c','commit.gpgsign=false','commit','--quiet','-m','initial fixture');
    const script=join(directory,'scripts/detect-code-changes.mjs');
    const invoke=()=>spawnSync(process.execPath,['--max-old-space-size=64',script],{
      cwd:directory,encoding:'utf8',timeout:5000,maxBuffer:65536,
      env:{...process.env,GITHUB_EVENT_NAME:'push',GITHUB_BASE_SHA:'',GITHUB_HEAD_SHA:'',GITHUB_OUTPUT:'',GITHUB_ACTIONS:'false'},
    });
    const before=invoke();
    assert.equal(before.status,0,before.stderr);
    assert.match(before.stderr,/HEAD\\^/u);
    assert.match(before.stdout,/^go-changed=false$/mu);
    const original=readFileSync(script,'utf8');
    writeFileSync(script,original.replace('return "";','throw error;'));
    const after=invoke();
    assert.equal(after.status,0,after.stderr);
    assert.match(after.stdout,/^go-changed=true$/mu);
    assert.match(after.stdout,/^any-code-changed=true$/mu);
  }finally{rmSync(directory,{recursive:true,force:true});}
});
'''
test.write_text(source)

Path('experiments/issue-1580/template-inventory-integrity.test.mjs').write_text('''import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import YAML from 'yaml';

const workflow=`name: Complete execution context
on:
  workflow_call:
    inputs:
      target: {type: string, required: true}
    outputs:
      artifact: {value: "\\${{ jobs.build.outputs.artifact }}"}
env: {ROOT: retained}
defaults: {run: {shell: bash}}
jobs:
  build:
    runs-on: ubuntu-24.04
    environment: production
    container: {image: 'node:24', options: '--memory=128m'}
    services: {db: {image: 'postgres:17'}}
    strategy: {fail-fast: false, max-parallel: 1, matrix: {target: [linux]}}
    continue-on-error: false
    outputs: {artifact: "\\${{ steps.build.outputs.artifact }}"}
    steps:
      - id: build
        working-directory: source
        env: {STEP: retained}
        run: echo hello
      - uses: actions/upload-artifact@v4
        with: {name: output, path: source/output}
  reuse:
    needs: build
    uses: ./local-workflow.yml
    secrets: inherit
    with: {target: linux}
`;

function fixture(run){
  const directory=mkdtempSync(join(tmpdir(),'issue-1580-inventory-'));
  try{
    const input=join(directory,'input'),output=join(directory,'output');
    const source=join(input,'fixture-complete','.github/workflows');
    mkdirSync(source,{recursive:true});
    const bytes=Buffer.from(workflow);
    const gitBlob=createHash('sha1').update(`blob ${bytes.length}\\0`).update(bytes).digest('hex');
    const sourcePath=join(source,'complete.yml');
    writeFileSync(sourcePath,bytes);
    writeFileSync(join(input,'manifest.json'),JSON.stringify([{repo:'fixture/fixture-template',sha:'a'.repeat(40)}]));
    writeFileSync(join(input,'fixture-complete-inventory.json'),JSON.stringify([{path:'.github/workflows/complete.yml',bytes:bytes.length,gitBlob}]));
    const invoke=()=>spawnSync(process.execPath,['--max-old-space-size=64','experiments/issue-1580/compare-template-trees.mjs',input,output],{encoding:'utf8',timeout:5000,maxBuffer:65536});
    run({invoke,sourcePath,output,gitBlob});
  }finally{rmSync(directory,{recursive:true,force:true});}
}

test('workflow review inventory preserves the entire parsed execution context', {timeout:10000},()=>{
  fixture(({invoke,output,gitBlob})=>{
    const result=invoke();
    assert.equal(result.status,0,result.stderr);
    const row=JSON.parse(readFileSync(join(output,'fixture-workflows.jsonl'),'utf8'));
    assert.equal(row.gitBlob,gitBlob);
    assert.deepEqual(row.document,YAML.parse(workflow));
    assert.equal(row.document.jobs.build.steps[1].with.path,'source/output');
    assert.equal(row.document.jobs.reuse.secrets,'inherit');
    assert.equal(row.document.jobs.build.strategy['max-parallel'],1);
  });
});

test('workflow review refuses content that differs from the pinned Git blob', {timeout:10000},()=>{
  fixture(({invoke,sourcePath})=>{
    writeFileSync(sourcePath,workflow.replace('path: source/output','path: different/output'));
    const result=invoke();
    assert.equal(result.status,1,result.stderr);
    assert.match(result.stderr,/source drift: .github\\/workflows\\/complete.yml/u);
  });
});
''')
print('Preserved complete workflow documents; added bounded negative controls and real initial-Git reproduction.')
