set -eu
sed -n '210,530p' docs/case-studies/issue-1580/templates/go-semantic-review.json
cat /tmp/issue-1580-research/record-go-semantic-review.py
tail -n 90 docs/case-studies/issue-1580/README.md
