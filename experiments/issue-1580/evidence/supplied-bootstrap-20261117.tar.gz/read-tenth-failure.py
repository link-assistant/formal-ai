from pathlib import Path
import re, gzip
p=Path('/tmp/issue-1580-research/head-e582b270a')
for f in p.rglob('*'):
    if f.is_file():
        print('FILE',f,f.stat().st_size)
        if f.name.endswith('.log.gz') or f.suffix=='.log':
            contents=gzip.open(f,'rt',errors='replace').read() if f.suffix=='.gz' else f.read_text(errors='replace')
            lines=contents.splitlines()
            hits=[i for i,s in enumerate(lines) if re.search(r'error|failed|FAIL|panicked|timeout|exceeded|not ok',s,re.I)]
            selected=set()
            for i in hits:
                selected.update(range(max(0,i-3),min(len(lines),i+7)))
            print('MATCHES',len(hits),'LINES',len(lines),'SELECTED',len(selected))
            for i in sorted(selected):
                print(f'{i+1}: {lines[i]}')
