import json,subprocess

assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
commits=[
    ('Move OpenCode envelope regression into external Rust test source',[
        'rust/src/agentic_coding/tool_result/source_observation.rs',
        'rust/tests/source/source_tests/agentic_coding/tool_result/source_observation/opencode_tests.rs',
        'rust/embedded/data/parity/issue-1580-opencode-read-envelope.json']),
    ('Align Moon summary fixtures with the causal seed vocabulary',[
        'rust/tests/unit/page_formalization_route.rs','rust/tests/web/page-formalization-route.test.mjs','experiments/issue-1580/trace-moon-lexeme.mjs']),
    ('Regenerate native program source witnesses without executable changes',[
        'scripts/lib/generated-native-programs.mjs']),
    ('Retain Claude read allowlist in native argv expectations',[
        'rust/tests/integration/with_formal_ai.rs','rust/tests/integration/with_formal_ai_argv.rs']),
    ('Verify lazy private diagnostics for tool argument binding failures',[
        'rust/tests/web/issue-1328-bounded-retries.test.mjs']),
    ('Replay four observed main regressions in the fast pull request lane',[
        'data/meta/main-only-regressions.lino','data/benchmarks/fast-pull-request-javascript-tests.json','experiments/issue-1580/trace-passage-routing.mjs']),
]
for message,paths in commits:
    subprocess.run(['git','add','--',*paths],check=True)
    result=subprocess.run(['git','commit','-m',message],capture_output=True,text=True)
    print(result.stdout);print(result.stderr)
    if result.returncode:raise SystemExit(result.returncode)
result=subprocess.run(['git','fetch','origin','main'],capture_output=True,text=True)
print(result.stdout);print(result.stderr)
if result.returncode:raise SystemExit(result.returncode)
for command in [['git','log','--oneline','058e9bef1214f2f1bc25971243cb787703ed64f1..origin/main'],['git','diff','--stat','058e9bef1214f2f1bc25971243cb787703ed64f1','origin/main']]:
    print(json.dumps(command));print(subprocess.check_output(command,text=True))
