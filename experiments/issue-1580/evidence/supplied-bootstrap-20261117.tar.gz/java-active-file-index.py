import json
from pathlib import Path

rows = json.loads(Path('/tmp/issue-1580-research/templates/java-complete-inventory.json').read_text())
for row in rows:
    if not row['path'].startswith(('dev/', 'docs/case-studies/')):
        print(row['path'])
