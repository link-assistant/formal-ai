from pathlib import Path

p=Path('rust/tests/web/worker-candidate-validation.test.mjs')
s=p.read_text()
start=s.index('test("held-out bounds')
end=s.index('\ntest("no candidate',start)
s=s[:start]+'''test("held-out bounds retain the validated intent across en, ru, hi, zh and es", async () => {
  for (const [language, prompt, expected] of [
    ["en", "Choose a prime between 8 and 12", "11"],
    ["ru", "Выбери простое число от 24 до 30", "29"],
    ["es", "Elige un número primo entre 32 y 40", "37"],
    ["zh", "选择8到12之间的质数", "11"],
    ["hi", "0 और 3 के बीच अभाज्य संख्या चुनो", "2"],
  ]) {
    const result = await host.solve(prompt);
    assert.equal(result.content, expected, language);
    assert.equal(result.intent, "number_property_prime", language);
  }
});
''' + s[end:]
p.write_text(s)
p=Path('experiments/issue-1580/compare-template-trees.mjs')
s=p.read_text().replace("{encoding:'utf8'}).split", "{encoding:'utf8',maxBuffer:16*1024*1024}).split",1)
p.write_text(s)
