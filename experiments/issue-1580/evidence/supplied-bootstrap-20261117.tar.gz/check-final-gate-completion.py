from pathlib import Path
import gzip,hashlib,json
base=Path('experiments/issue-1580/evidence/checks/main-merge-444575f2/final')
p=base/'all-local-gates.json'
if not p.exists():
 log=Path('/tmp/issue-1580-research/final-merged-444575f2-all-local-gates.log')
 print('RUNNING','\n'.join(log.read_text().splitlines()[-10:]));raise SystemExit(0)
r=json.loads(p.read_text());raw=gzip.decompress((base/r['log']).read_bytes())
assert hashlib.sha256(raw).hexdigest()==r['rawSha256']
for row in r['gateLogs']:
 data=gzip.decompress((base/row['log']).read_bytes())
 assert hashlib.sha256(data).hexdigest()==row['rawSha256'],row
print(json.dumps({k:v for k,v in r.items() if k!='gateLogs'}))
lines=raw.decode().splitlines()
print('COUNTS', {label:sum(line.startswith(label+' ') for line in lines) for label in ['PASS','FAIL','SKIP']})
print('FULL AGGREGATE',raw.decode())
print('COMPLETE PER-GATE ARCHIVES',len(r['gateLogs']))
