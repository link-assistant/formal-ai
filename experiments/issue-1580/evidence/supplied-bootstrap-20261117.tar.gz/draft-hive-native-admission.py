from pathlib import Path
import subprocess,re,json,hashlib
root=Path.cwd();p=root/'rust/tests/unit/reasoning_contracts.rs';s=p.read_text();assert 'mod hive_workflow_replay;'not in s
s+='''\n#[path = "../../src/agentic_coding/work_item_steps.rs"]
pub mod canonical_work_item_steps;
#[path = "../fixtures/observed-plan-tools.rs"]
mod observed_plan_tools;
#[path = "issue_1066_ladder_capability/tool_workspace.rs"]
mod tool_workspace;
#[path = "issue_1133_hive_mind_three_runs.rs"]
mod hive_workflow_replay;
''';p.write_text(s)
paths=['rust/tests/unit/issue_1133_hive_mind_three_runs.rs','rust/tests/unit/issue_1133_hive_mind_three_runs/extended.rs','rust/tests/unit/issue_1066_ladder_capability/tool_workspace.rs','rust/tests/fixtures/atomic-record-append.rs','rust/tests/fixtures/observed-plan-tools.rs','rust/tests/fixtures/commit-cue-masking.rs','rust/tests/fixtures/hive-workflow-original-task.json']
p=root/'scripts/ci-pull-request-admission.mjs';s=p.read_text();marker="  'rust/tests/unit/offline_instruction_research.rs',\n";assert s.count(marker)==1;s=s.replace(marker,marker+''.join("  '"+path+"',\n"for path in paths));p.write_text(s)
p=root/'changelog.d/issue-1580-hive-workflow-replay.md';p.write_text('Replay the intact Hive workflow and tool-workspace contracts in focused native CI, including multilingual workflow requests, remote connector reads, failed verification and file-bound commit behavior. Track every consumed fixture in pull request admission.\n')
subprocess.run(['rustfmt','--edition','2024','rust/tests/unit/reasoning_contracts.rs'],check=True)
records=[]
for name in paths:
 raw=(root/name).read_bytes();published=subprocess.check_output(['git','show','cf22c611:'+name]);assert raw==published,name
 try: original=subprocess.check_output(['git','show','015a1d7e:'+name],stderr=subprocess.DEVNULL);same=raw==original
 except subprocess.CalledProcessError:same=None
 records.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest(),'publishedByteIdentical':True,'originalMainByteIdentical':same,'testCount':len(re.findall(rb'#\[test\]',raw)),'completeSourceLiterallyRead':True})
base=root/'experiments/issue-1580/evidence/checks/hive-native-admission';(base/'included-modules.json').write_text(json.dumps({'records':records,'nativeTestsAdded':sum(r['testCount']for r in records),'nativeExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n');print(json.dumps(records,indent=2))
