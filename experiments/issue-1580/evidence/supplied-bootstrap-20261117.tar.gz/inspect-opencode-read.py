import gzip,json
from pathlib import Path
p=Path('experiments/issue-1580/evidence/ci/main-826289fc/cli/opencode-interactive-proxy.jsonl.gz')
for row in map(json.loads,gzip.decompress(p.read_bytes()).decode().splitlines()):
    if row.get('method')!='POST': continue
    body=json.loads(row['request_body'])
    for m in body.get('messages',[]):
        if m.get('tool_calls'): print(json.dumps(m,ensure_ascii=False)[:1800])
        if m.get('role')=='user': print('USER',str(m['content'])[:400])
