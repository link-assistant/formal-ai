from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,gzip
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/canonical-data-follow-through';rows=[]
for name,args in [('fetch-main',['git','-c','gc.auto=0','fetch','origin','main']),('main-head',['git','rev-parse','origin/main']),('main-ancestor',['git','merge-base','--is-ancestor','origin/main','HEAD']),('recent-main',['git','log','-5','--format=%H %cI %s','origin/main'])]:
 r=subprocess.run(args,cwd=root,capture_output=True);record={'name':name,'argv':args,'exitCode':r.returncode}
 for label,raw in [('stdout',r.stdout),('stderr',r.stderr)]:
  packed=gzip.compress(raw,mtime=0);filename='main-'+name+'.'+label+'.gz';(base/filename).write_bytes(packed);record[label]={'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()}
 rows.append(record);print(name,r.returncode,r.stdout.decode(),r.stderr.decode())
 if name!='main-ancestor':assert r.returncode==0
(base/'main-integration.json').write_text(json.dumps({'observedAt':datetime.now(timezone.utc).isoformat(),'records':rows},indent=2)+'\n')
