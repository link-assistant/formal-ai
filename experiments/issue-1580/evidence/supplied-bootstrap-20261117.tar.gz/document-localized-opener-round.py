from pathlib import Path
import gzip,hashlib,json

root=Path('.')
checks=root/'experiments/issue-1580/evidence/checks/localized-unknown-opener'
initial=json.loads((checks/'all-gates/outcome.json').read_text())
corrected=json.loads((checks/'corrected-checks/outcome.json').read_text())
shell=json.loads((checks/'shellcheck/receipt.json').read_text())
assert initial['complete'] and corrected['complete'] and shell['complete']
assert all(row['exitCode']==0 for row in corrected['records'])
assert all(row['exitCode']==0 for row in shell['records'])
summary=gzip.decompress((checks/'all-gates/full-javascript-gates.log.gz').read_bytes()).decode()
counts={name:sum(line.startswith(name+' ') for line in summary.splitlines()) for name in ['PASS','SKIP','FAIL']}
sources=['data/meta/core-boundary-ledger.lino','docs/status.md','data/meta/worker-line-budget/formal_ai_worker_seed_responses_and_language.lino','js/worker/formal_ai_worker_seed_responses_and_language.js','rust/src/unknown_opener.rs','rust/src/web_engine_core.rs','rust/tests/web/worker-unknown-language.test.mjs','experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8']
receipt={'publishedHead':'b367d603375dd23223861c92875e079a3a90df13','fullGateRunCounts':counts,'fullRunInitiallyPassed':False,'initialFiveFailuresResolvedBy':['corrected-checks/outcome.json','shellcheck/receipt.json'],'focusedJavaScriptTests':{'localizedUnknownLanguage':6,'fixtureIntegrity':2,'unicodeAndGovernedInventory':34},'nativeBehaviorVerified':False,'autonomousAuthorshipCredit':0,'sourceHashes':{name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in sources}}
(checks/'reviewed-round-summary.json').write_text(json.dumps(receipt,indent=2)+'\n')
target=root/'docs/case-studies/issue-1580/localized-opener-and-ci-checkpoint.md'
assert not target.exists()
target.write_text('''# Localized opener and CI metadata checkpoint

This is unfinished work for [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581).
The PR remains draft. The broader issue acceptance criteria and independent
Formal AI reasoning acceptance (0/20) remain open. Supplied commands, patches and
scripts earn zero independent authorship credit.

## Published-head failures

All 23 workflows on `b367d603375dd23223861c92875e079a3a90df13` have finished:
21 pass and two fail. The failures are introduced bookkeeping misses; the earlier
green head does not establish that this head passes.

| Run | Complete primary failure evidence | Correction |
| --- | --- | --- |
| [Pipeline 44220008975](https://github.com/link-assistant/formal-ai/actions/runs/44220008975) | Job 134519246760 lines 751–754 reports a 795→793 line improvement and a 36,519→36,517 core total. The status job only propagates this failure. | Lower both ledger limits and regenerate the maintained status surface. No migration disposition is changed. |
| [Layered CI 44220008509](https://github.com/link-assistant/formal-ai/actions/runs/44220008509) | Jobs 134519390942 lines 4860–4866 and 134519390973 lines 2754–2768 reject the stale `formalization.rs` source hash in the governed witness. | Compare every complete case and unsupported-case object, then use the maintained reviewed-refresh command. Only one source-manifest hash changes. |

Complete aggregate and failed-job logs, identities and fresh run snapshots are
retained under `experiments/issue-1580/evidence/ci/native-b367d603/`.
The complete primary failure payloads have been read; full literal review of
every line of all aggregate logs is not claimed. Neither failing suite exceeds
its time budget, and no CI retry is used for these failures.

The witness review preserves all 221 supported and 964 unsupported complete
objects, the manifest paths and the reader identity. Its sole hash delta is the
previously published offline interpretation fixture. The complete comparison,
old witness and maintained refresh receipt are under
`evidence/checks/localized-unknown-opener/governed-refresh/`. This is a reviewed
source-fingerprint refresh, not a change to test expectations.

## Preserve localized unknown responses

The opener registry has no Spanish pool and explicitly falls back to English
when callers ask for the pool itself. Previously, variation selection reused
that fallback and replaced the first sentence of a Spanish seed response with
an English opener. Both selectors now require a pool for the requested language.
The native formatter keeps the complete seed response when selection returns an
empty opener. The existing pool-query fallback API remains unchanged.

Reproduce the JavaScript regression with:

```sh
timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/worker-unknown-language.test.mjs
```

The unchanged original Spanish prompt produces two failing new checks before
the fix; all six checks pass afterward. They require full Spanish seed equality,
an empty selector result for the missing pool, the original English pool-query
fallback and a valid English selection. The four existing cases still pass.
The native unit regression uses a generic probe input to check the same
missing-pool behavior without embedding a held test prompt in production source.
That native test has not been executed locally.

The initial full gate run reports 133 passes or skips out of 138 entries, with
five failures. The new native test's literal prompt trips two prose-policy
checks; the generated status page is stale; ShellCheck is missing. Replace only
the native test input with a generic probe, regenerate status with the maintained
renderer, and extract the official ShellCheck v0.11.0 release to scratch storage.
The archive SHA-256 matches GitHub's asset digest. All five failed entries pass
on focused reruns. The repository gate definitions and shell lint command stay
unchanged. The initial failed logs are retained alongside the corrected results.

The two CI-failing JavaScript files pass separately (2 and 34 cases), the six
affected policy/core/status gates pass, and Rust formatting, JavaScript-to-Rust
projection verification and whitespace checks pass. These checks compile no Rust.
The projection report still has 49 refused modules; its successful check is not
complete language parity. Logs and final source identities are under
`experiments/issue-1580/evidence/checks/localized-unknown-opener/`.

## Remaining acceptance

The original native Spanish routing and complete unresolved-reasoning contracts
remain open. The retained pre-fix production-worker probe records their current
JavaScript routing and seed-answer gap, with attempted fetches refused and no
actual network traffic. Fixing the English opener does not establish either
native routing or a complete reasoning trace.

The 53 recovered native panic headers, three native budget terminations,
benchmark floors, warnings, catalog input determinism, all eight complete
template reviews, recursive context binding, dependency migration and live
serving/delivery acceptance remain unfinished. No local native build, broad
native behavioral pass, ready transition or merge is claimed.
''')
native=root/'docs/case-studies/issue-1580/native-evidence-checkpoint.md'
native.write_text(native.read_text()+'''\nThe next published head, `b367d603`, has 21 passing workflows and two failures.
The [localized opener and CI metadata checkpoint](localized-opener-and-ci-checkpoint.md)
records both complete primary failure payloads, their candidate corrections,
the reviewed witness refresh and a separate localized opener regression. The
earlier 23/23 result above applies only to `7e89122c`.
''')
plan=root/'experiments/issue-1580/work-plan.md'
plan.write_text(plan.read_text()+'''\n## Localized opener and introduced CI metadata failures

- [x] Collect all 23 completed b367d603 workflows and preserve complete logs for both failures; read both primary failure payloads. Pipeline line limits and Layered governed source identity are introduced bookkeeping misses.
- [x] Lower the 795→793 native handler baseline and 36,519→36,517 core ceiling; regenerate the maintained status projection.
- [x] Compare all 221 complete supported and 964 unsupported governed objects and every manifest path; refresh through the maintained reviewed command for exactly one changed source hash.
- [x] Reproduce the original Spanish input's English-opener leak with two failing new JavaScript cases; preserve the fallback pool API while both selectors require a localized pool. Six focused JavaScript cases pass after the fix.
- [x] Run the full 138-entry JavaScript gate inventory sequentially with a bounded heap. Preserve its five initial failures; resolve both prose-policy entries, stale status and missing ShellCheck, and pass focused reruns of every failure.
- [x] Pass the two CI-failing JavaScript files separately (2 and 34 cases), six affected policy/core/status gates, Rust formatting, projection verification and whitespace checks. No native build or execution is used.
- [ ] Verify the next published head in all CI workflows after the coordinated push.
- [ ] Complete the original native Spanish routing and full unresolved-reasoning contracts; the opener regression is a narrower improvement.
- [ ] Complete all earlier remaining criteria, including the 53 native panic headers, three budget terminations, eight complete template reviews and 0/20 independent reasoning acceptance. This checkpoint does not authorize a ready transition or merge.

Evidence: `docs/case-studies/issue-1580/localized-opener-and-ci-checkpoint.md`,
`experiments/issue-1580/evidence/ci/native-b367d603/` and
`experiments/issue-1580/evidence/checks/localized-unknown-opener/`.
''')
fragment=root/'changelog.d/20261117_120000_issue-1580-ci-regressions.md'
fragment.write_text(fragment.read_text()+'''\n- Preserve the complete localized unknown response when its language has no variation pool, while retaining the pool-query fallback API.
- Synchronize improved core source-size limits, generated status and the reviewed governed source witness without changing any complete case object.
''')
print(json.dumps(receipt,indent=2))
print('Wrote checkpoint, work plan and patch release fragment.')
