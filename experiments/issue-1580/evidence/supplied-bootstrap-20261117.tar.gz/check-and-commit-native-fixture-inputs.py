from pathlib import Path
import datetime, gzip, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/checks/native-fixture-inputs'
base.mkdir(exist_ok=True)
files = [
    'rust/tests/unit/docs_requirements/agent_cli_shell.rs',
    'rust/tests/unit/specification/formalization.rs',
]
def command(argv):
    result = subprocess.run(argv, cwd=root, capture_output=True, text=True)
    print(json.dumps({'argv': argv, 'exitCode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}))
    assert result.returncode == 0, argv
    return result.stdout.strip()

assert command(['git', 'branch', '--show-current']) == 'issue-1580-8d61a32a61e1'
assert command(['git', 'rev-parse', 'HEAD']) == '9d14fc9ec835d81d93fb8335ab50aef2ed14d1ba'
assert command(['git', 'diff', '--cached', '--name-only']) == ''
rows = []
for index, argv in enumerate([
    ['rustfmt', '--check', '--edition', '2024', *files],
    ['git', 'diff', '--check'],
]):
    started = datetime.datetime.now(datetime.timezone.utc)
    result = subprocess.run(argv, cwd=root, capture_output=True)
    raw = result.stdout + result.stderr
    target = base / f'{index + 1}.log.gz'
    target.write_bytes(gzip.compress(raw, mtime=0))
    rows.append({'argv': argv, 'exitCode': result.returncode,
                 'startedAt': started.isoformat(), 'log': target.name,
                 'rawSha256': hashlib.sha256(raw).hexdigest()})
    print(json.dumps(rows[-1]))
    if raw:
        print(raw.decode())
    assert result.returncode == 0, argv

receipt = {'checks': rows, 'sourceFiles': [
    {'path': path, 'sha256': hashlib.sha256((root / path).read_bytes()).hexdigest()}
    for path in files
], 'nativeBehaviorVerified': False, 'autonomousAuthorshipCredit': 0}
(base / 'outcome.json').write_text(json.dumps(receipt, indent=2) + '\n')
for path, title in zip(files, [
    'Trace agent mode through its current CLI and configuration owners',
    'Freeze network input in the interpretation determinism fixture',
]):
    command(['git', 'add', '--', path])
    assert command(['git', 'diff', '--cached', '--name-only']) == path
    command(['git', 'diff', '--cached', '--check'])
    command(['git', 'commit', '-m', title])
print('No push or native execution performed.')
