from pathlib import Path
import subprocess,json,gzip,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/checks/cnl-canonical-data'
base.mkdir(exist_ok=False)
snapshot=Path('/tmp/issue-1580-research/snapshot-cnl-data.mjs')
snapshot.write_text('''import {readFileSync,writeFileSync} from 'node:fs';
import {parseLino} from '/tmp/gh-issue-solver-1794900398048/js/server/lino.mjs';
import {parseOutputPolicy} from '/tmp/gh-issue-solver-1794900398048/js/agentic/crate/cnl_output.mjs';
import {parseLanguageGrammar} from '/tmp/gh-issue-solver-1794900398048/js/agentic/crate/cnl_grammar.mjs';
const read=path=>readFileSync(path,'utf8');
const data={policy:parseOutputPolicy(read('data/seed/cnl-output.lino'),parseLino),languages:{}};
for(const language of ['en','ru','hi','zh','es']) data.languages[language]=parseLanguageGrammar(read(`data/seed/cnl-language-${language}.lino`),parseLino);
writeFileSync(process.argv[2],JSON.stringify(data,null,2)+'\\n');
''')
subprocess.run(['node',str(snapshot),str(base/'decoded-before.json')],cwd=root,check=True)
p=root/'rust/tests/web/cnl-output.test.mjs'
s=p.read_text(); assert 'canonical CNL references preserve' not in s
s=s.replace('cnlPolicy, frequencyTier, formalizeOutput, outputConfiguration, outputDirective,','cnlPolicy, frequencyTier, formalizeOutput, outputConfiguration, outputDirective, parseOutputPolicy,')
s=s.replace("import {installHost}","import {parseLanguageGrammar} from '../../../js/agentic/crate/cnl_grammar.mjs';\nimport {installHost}",1)
s+='''
test('canonical CNL references preserve keyed forms, empty forms and template styles', () => {
  const legacy = `cnl-language en
  keys "bare|plural"
  fillers "you know|please"
  prime "I: i|me"
  list "basic: cat|dog"
  tier "100: cat|dog"
  term cat
    forms "|cats"
  template "reply plain|basic statement"
    positive "{subject.bare}."
`;
  const canonical = `cnl-language en
  keys ("bare" "plural")
  fillers ("you know" "please")
  prime I
    forms ("i" "me")
  list basic
    forms ("cat" "dog")
  tier 100
    forms ("cat" "dog")
  term cat
    forms ("" "cats")
  template "reply statement"
    styles ("plain" "basic")
    positive "{subject.bare}."
`;
  assert.deepEqual(parseLanguageGrammar(canonical, parseLino), parseLanguageGrammar(legacy, parseLino));
  const oldPolicy = `controlled-output
  registers "plain|basic"
  profile plain
    aliases "one|two"
    styles "plain|basic"
  lexeme sample
    form hello
      mode "plain|basic"
`;
  const newPolicy = oldPolicy.replaceAll('"plain|basic"', '("plain" "basic")')
    .replace('"one|two"', '("one" "two")');
  assert.deepEqual(parseOutputPolicy(newPolicy, parseLino), parseOutputPolicy(oldPolicy, parseLino));
});

test('every CNL seed stores alternatives as canonical references', () => {
  function check(node, path) {
    assert.ok(!node.value?.includes('|'), `${path}: ${node.name} ${node.value}`);
    for (const child of node.children ?? []) check(child, path);
  }
  for (const path of ['data/seed/cnl-output.lino',
    ...['en', 'ru', 'hi', 'zh', 'es'].map(language => `data/seed/cnl-language-${language}.lino`)]) {
    check(parseLino(readRepoFile(path)), path);
  }
});

test('both Gemini token overrides use canonical quoting around embedded JSON', () => {
  const lines = readRepoFile('data/seed/client-integrations.lino').split('\\n')
    .filter(line => line.includes('modelConfigs.overrides=json+:'));
  assert.equal(lines.length, 2);
  for (const line of lines) {
    assert.match(line.trim(), /^(?:temp_home_json_set|json_set) 'modelConfigs\\.overrides=json\\+:\\[/u);
    const node = parseLino(line.trim()).children[0];
    const overrides = node.value.slice('modelConfigs.overrides=json+:'.length)
      .replace('{max_output_tokens}', '123');
    assert.deepEqual(JSON.parse(overrides), [{match: {model: '{model}'},
      modelConfig: {generateContentConfig: {maxOutputTokens: 123}}}]);
  }
});
'''
p.write_text(s)
r=subprocess.run(['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',str(p.relative_to(root))],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
raw=r.stdout;packed=gzip.compress(raw,mtime=0);(base/'regression-before.log.gz').write_bytes(packed)
row={'exitCode':r.returncode,'file':'regression-before.log.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'lines':len(raw.splitlines()),'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'independentAuthorshipCredit':0}
(base/'regression-before.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row));print('\n'.join(raw.decode().splitlines()[-12:]))
assert r.returncode!=0
