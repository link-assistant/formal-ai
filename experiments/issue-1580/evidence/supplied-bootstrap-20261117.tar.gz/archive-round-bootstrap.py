from pathlib import Path
import io,gzip,tarfile,hashlib,json
base=Path('/tmp/issue-1580-research')
out=Path('experiments/issue-1580/evidence')
buffer=io.BytesIO();rows=[]
with tarfile.open(fileobj=buffer,mode='w') as archive:
 for path in sorted(base.iterdir()):
  if not path.is_file() or path.suffix not in {'.py','.sh','.mjs'}:continue
  data=path.read_bytes();info=tarfile.TarInfo(path.name);info.size=len(data);info.mtime=0;info.mode=0o644
  archive.addfile(info,io.BytesIO(data));rows.append({'file':path.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
payload=gzip.compress(buffer.getvalue(),mtime=0)
(out/'supplied-bootstrap-20261117.tar.gz').write_bytes(payload)
groups=[rows[index:index+2] for index in range(0,len(rows),2)]
(out/'supplied-bootstrap-20261117.json').write_text('{\n  \"autonomousAuthorshipCredit\": 0,\n  \"archiveSha256\": '+json.dumps(hashlib.sha256(payload).hexdigest())+',\n  \"files\": [\n'+',\n'.join('    '+','.join(json.dumps(row,separators=(',', ':')) for row in group) for group in groups)+'\n  ]\n}\n')
print('Preserved',len(rows),'externally supplied scripts;',len(payload),'compressed bytes; zero authorship credit.')
