from pathlib import Path
import json,hashlib
path=Path('/tmp/issue-1580-research/templates/java-complete/dev/log/issues/24/pulls/25/osv-scope-reproduction.log')
for number,line in enumerate(path.read_text().splitlines(),1):
 value=json.loads(line)
 print('LINE',number,'bytes',len(line.encode()),'sha256',hashlib.sha256(line.encode()).hexdigest())
 for key,item in value.items():
  print(key, json.dumps(item if not isinstance(item,(str,list,dict)) else item[:100] if isinstance(item,str) else {'kind':type(item).__name__,'size':len(item),'keys':list(item)[:12] if isinstance(item,dict) else None},ensure_ascii=False))
