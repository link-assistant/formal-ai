from pathlib import Path
import gzip,json,subprocess
root=Path.cwd();base=root/'experiments/issue-1580/evidence/checks/calendar-dispatch-registration'
rows=[]
for name,args in [
 ('typescript-refresh',['node','--max-old-space-size=256','scripts/translate-es.mjs','--write']),
 ('runtime-inventory-refresh',['node','--max-old-space-size=256','scripts/generate-runtime-feature-inventory.mjs','--write']),
 ('system-diagrams-refresh',['node','--max-old-space-size=256','scripts/generate-system-diagrams.mjs','--write']),
 ('closure-audit',['python3','scripts/check-closure-audit.py']),
 ('notation',['node','--max-old-space-size=256','scripts/measure-notation.mjs']),
 ('shared-handler-regression',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/handler-registry.test.mjs'])]:
 r=subprocess.run(args,capture_output=True);raw=r.stdout+r.stderr;(base/(name+'.log.gz')).write_bytes(gzip.compress(raw,mtime=0));rows.append({'name':name,'argv':args,'exitCode':r.returncode});print(name,'EXIT',r.returncode,raw.decode());assert r.returncode==0
(base/'initial-gate-repair-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
p=root/'changelog.d/issue-1580-worker-calendar-dispatch.md';text=p.read_text();extra='\nCalendar handlers share one named argument list. Refresh the generated runtime inventory and solver diagram, and record the lower measured closure gap.\n';assert extra not in text;p.write_text(text+extra)
for args in [['git','diff','--stat'],['git','status','--short'],['git','diff','--','js/seed_loader.js','ts/seed_loader.ts','data/meta/closure-audit.lino','data/seed/browser-handler-precedence.lino','docs/diagrams/solver-handlers.md']]:
 r=subprocess.run(args,capture_output=True);print(r.stdout.decode(),r.stderr.decode())
