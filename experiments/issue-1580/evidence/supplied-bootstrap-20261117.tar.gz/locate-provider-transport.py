import pathlib
import subprocess

for args in [
    ['rg', '-n', 'skipped:offline|readAccessEnabled|readAccess|duckduckgo.com|LIVE_FETCH', 'js', '--glob', '!seed/**', '--glob', '!*.map', '--glob', '!*.json'],
    ['git', 'diff', '058e9bef', 'HEAD', '--', 'js/worker', 'js/agentic/crate/meta_executor.mjs', 'js/server/worker-host.mjs'],
]:
    result = subprocess.run(args, text=True, capture_output=True)
    path = pathlib.Path('/tmp/issue-1580-research') / ('provider-transport-locations.log' if args[0] == 'rg' else 'branch-router-diff.log')
    path.write_text(result.stdout + result.stderr)
    lines = path.read_text().splitlines()
    print(f'LOG {path} lines={len(lines)}')
    for i, line in enumerate(lines[:100], 1):
        print(f'{i}: {line[:400]}')
