from pathlib import Path
import hashlib,json,subprocess

assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
base=Path('experiments/issue-1580')
index=base/'evidence/checks/csharp-changeset-integrity.json'
record=json.loads(index.read_text())
gates=json.loads((base/'evidence/checks/csharp-changeset-collision/gates.json').read_text())
assert len(gates)==4 and all(row['exitCode']==0 for row in gates)
record['gates']=gates
index.write_text(json.dumps(record,indent=2)+'\n')
for name in ['template-csharp-changeset-integrity.test.mjs']:
 path=base/name
 assert hashlib.sha256(path.read_bytes()).hexdigest()==record['checks']['after']['testSha256']
review=json.loads(Path(record['reviewArtifact']).read_text())
assert len(review['files'])==337 and len({row['path'] for row in review['files']})==337
assert sum(row['reviewStatus']=='active-source-fully-read' for row in review['files'])==120
assert sum(row['reviewStatus']=='inventoried-only-active' for row in review['files'])==38
assert sum(row['reviewStatus']=='inventoried-only-historical' for row in review['files'])==179
for name in ['archive-evidence.py']:
 result=subprocess.run(['python3',str(base/name)],check=True,text=True,stdout=subprocess.PIPE)
 print(result.stdout)
result=subprocess.run(['python3','/tmp/issue-1580-research/archive-round-bootstrap.py'],check=True,text=True,stdout=subprocess.PIPE)
print(result.stdout)
print(subprocess.check_output(['git','status','--short'],text=True))
