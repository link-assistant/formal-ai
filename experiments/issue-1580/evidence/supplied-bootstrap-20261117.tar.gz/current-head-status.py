from pathlib import Path
import json,subprocess,gzip,sys
root=Path('/tmp/issue-1580-research')
head=sys.argv[1] if len(sys.argv)>1 else subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
data=json.loads(subprocess.check_output(['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--commit',head,'--limit','100','--json','databaseId,workflowName,status,conclusion,createdAt,headSha'],text=True))
assert all(x['headSha']==head for x in data)
directory=root/('head-'+head[:9]);directory.mkdir(exist_ok=True)
(directory/'runs.json').write_text(json.dumps(data,indent=2)+'\n')
for row in data:
 if row['status']=='completed' and row['conclusion'] not in {'success','skipped'}:
  run=str(row['databaseId'])
  meta=directory/(run+'.json')
  if not meta.exists():meta.write_bytes(subprocess.check_output(['gh','run','view',run,'--repo','link-assistant/formal-ai','--json','jobs,headSha,createdAt,conclusion,status,url,workflowName']))
  log=directory/(run+'.log.gz')
  if not log.exists():log.write_bytes(gzip.compress(subprocess.check_output(['gh','run','view',run,'--repo','link-assistant/formal-ai','--log'],stderr=subprocess.STDOUT),mtime=0))
print(json.dumps({'head':head,'runs':len(data),'completed':sum(x['status']=='completed' for x in data),'failed':[x for x in data if x['status']=='completed' and x['conclusion'] not in {'success','skipped'}],'active':[{'id':x['databaseId'],'name':x['workflowName'],'status':x['status']} for x in data if x['status']!='completed']},indent=2))
