from pathlib import Path
import json,subprocess
cmd=['node','--max-old-space-size=256','scripts/measure-abbreviations.mjs','--list','file-names']
result=subprocess.run(cmd,text=True,capture_output=True)
print(result.stdout)
print(result.stderr)
print('RC',result.returncode)
