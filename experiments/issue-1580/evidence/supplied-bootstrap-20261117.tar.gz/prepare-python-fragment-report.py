from pathlib import Path
import hashlib
import json

head = Path('/tmp/issue-1580-research/python-fragment-evidence-commit.txt').read_text().strip()
assert head == '9c018344df2e6b09a0f2496897b14a002dad62f4'
text = Path('/tmp/issue-1580-research/python-fragment-collision-report.md').read_text()
assert text.count('@EVIDENCE_COMMIT@') == 2
text = text.replace('@EVIDENCE_COMMIT@', head)
path = Path('experiments/issue-1580/upstream/python-fragment-collision-report.md')
assert not path.exists()
path.write_text(text)
print(json.dumps({'report': str(path), 'bodySha256': hashlib.sha256(text.encode()).hexdigest(), 'immutableEvidenceCommit': head, 'filed': False, 'publicationRequiresPublishedEvidence': True}, indent=2))
