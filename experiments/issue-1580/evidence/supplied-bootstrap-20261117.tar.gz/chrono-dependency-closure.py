from pathlib import Path
import tomllib
data=tomllib.loads(Path('rust/Cargo.lock').read_text())
matches=[]
for item in data['package']:
    if any(value.startswith('chrono') for value in item.get('dependencies',[])):
        matches.append(item['name'])
        print('chrono dependent:',item)
print('manifest:\n'+Path('rust/Cargo.toml').read_text())
print('audit script:\n'+Path('scripts/check-rust-dependencies.sh').read_text())
for item in data['package']:
    if any(value.split()[0] in matches for value in item.get('dependencies',[])):
        print('next dependent:',item['name'],item['version'],[value for value in item.get('dependencies',[]) if value.split()[0] in matches])
