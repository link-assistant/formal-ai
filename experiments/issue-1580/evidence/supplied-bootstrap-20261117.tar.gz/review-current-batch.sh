set -eu
git diff -- scripts/detect-code-changes.rs .cargo/audit.toml
cat rust/tests/web/cargo-audit-blocked-proof.test.mjs
cat experiments/issue-1580/template-shared-git-observation.test.mjs
