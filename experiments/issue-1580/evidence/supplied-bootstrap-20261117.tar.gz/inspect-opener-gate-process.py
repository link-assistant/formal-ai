from pathlib import Path
import subprocess, time
print(subprocess.check_output(['ps','-eo','pid,ppid,rss,etime,args','--sort=-rss'],text=True).splitlines()[:12])
base=Path('experiments/formal_ai_subagent/sandboxes/gates')
for log in sorted(base.glob('*.log'), key=lambda path:path.stat().st_mtime, reverse=True)[:8]:
    print(log.name, 'bytes', log.stat().st_size, 'secondsSinceWrite', round(time.time()-log.stat().st_mtime,1))
    lines=log.read_text(errors='replace').splitlines()
    print('\n'.join(lines[-6:]))
