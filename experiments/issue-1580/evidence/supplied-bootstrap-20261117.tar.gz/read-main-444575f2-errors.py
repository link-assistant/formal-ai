from pathlib import Path
import re,sys
run=sys.argv[1]
lines=(Path('/tmp/issue-1580-research')/('main-444575f2-'+run+'.log')).read_text().splitlines()
if run=='44163377677':
    patterns=r'✖|error:|Error:|timed out|AssertionError|fail [1-9]'
elif run=='44163377753':
    patterns=r'assert|FAIL|failed|refus|Cannot|OutputConstraint|PermissionDenied'
else:
    patterns=r'panicked|GHSA-|time budget|band.*[0-9]'
rows=[(n,line.split('\t',2)[-1]) for n,line in enumerate(lines,1) if re.search(patterns,line,re.I)]
start=int(sys.argv[2]) if len(sys.argv)>2 else 0
for n,line in rows[start:start+35]:
    print(n,line[:1000])
    if run=='44163378148' and 'panicked' in line:
        for off in range(1,8):
            value=lines[n-1+off].split('\t',2)[-1]
            if 'stack backtrace' in value:break
            print(n+off,value[:1400])
print('ROWS',len(rows),'SLICE',start,start+35)
