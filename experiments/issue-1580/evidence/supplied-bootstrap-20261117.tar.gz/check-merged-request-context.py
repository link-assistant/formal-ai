from pathlib import Path
import subprocess, gzip, hashlib, json, time

base=Path('experiments/issue-1580/evidence/checks/main-merge-826289fc')
rows=[]
for name in ['rust-specification-unicode-identifiers','rust-specification-fixture-integrity','issue-1587-request-context','calendar-clock-preservation','fast-pull-request-production-profile']:
    command=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/'+name+'.test.mjs']
    started=time.time();result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    target=base/(name+'.log.gz');target.write_bytes(gzip.compress(result.stdout,mtime=0))
    row={'command':command,'exitCode':result.returncode,'seconds':round(time.time()-started,3),'rawSha256':hashlib.sha256(result.stdout).hexdigest(),'log':target.name}
    rows.append(row);print(json.dumps(row),flush=True)
    print(result.stdout.decode(),flush=True)
(base/'focused-tests.json').write_text(json.dumps(rows,indent=2)+'\n')
assert all(row['exitCode']==0 for row in rows)
