from pathlib import Path
import collections,hashlib,json

root=Path('/tmp/issue-1580-research/templates/python-complete')
path=Path('docs/case-studies/issue-1580/templates/python-partial-semantic-review.json')
review=json.loads(path.read_text())
inventory=json.loads(Path('/tmp/issue-1580-research/python-active-source-inventory.json').read_text())
active={row['path']:row for row in inventory['active']}
deferred={'.github/actions/artifact/dist/835.index.mjs','.github/actions/artifact/dist/index.mjs','.github/actions/artifact/package-lock.json','uv.lock'}
selected=[]
for row in inventory['active']:
    if row['path'] in deferred:continue
    selected.extend((row['path'],number) for number in range(1,row['lines']+1))
assert len(selected)==21394
ranges=collections.defaultdict(set)
for row in review['files']:
    for first,last in row['readRanges']:
        ranges[row['path']].update(range(first,last+1))
for name,number in selected[:10400]:ranges[name].add(number)
for name,total in [('scripts/release_naming.py',104),('tests/test_release_badges.py',40)]:ranges[name].update(range(1,total+1))
decisions={
 'scripts/audit-npm-locks.sh':'Read all 53 lines and execute unchanged failed/partial inventory, real tracked/empty Git and offline advisory controls. The disposable candidate rejects failed inventory. Filed as upstream #158 with immutable evidence at 1cc2d536a; no upstream repair is claimed. Formal AI analogous helper is repaired and its dedicated tests are now being added to fast pull-request selection.',
 'scripts/check-required-docs.sh':'Read all 101 lines: required files/headings, exact level-two match, list/unknown-argument behavior and Bash 3.2 failure accumulation. Preserve missing-document failure. No execution is claimed.',
 'scripts/check_codeql_results.py':'Read all 167 lines: nonempty SARIF runs, fatal findings, execution-success checks and notification severity/message/reference/location validation. JSON quoting keeps finding text inert in annotations. No fresh SARIF runtime probe is claimed.',
 'scripts/check_dependabot_health.py':'Read all 150 lines: paginated API shape, aged/rebase-loop criteria, timezone/threshold checks, repository identity, escaped annotations and fatal API/parse errors. No provider request was executed; individual gh deadlines remain delegated to outer CI.',
 'scripts/check_dist_size.py':'Read all 89 lines: positive distribution budget, fatal empty output, per-file limits and bounded member summaries without extraction. Inspection errors cannot erase a known size violation. No archive runtime or publication is claimed.',
 'scripts/check_file_size.py':'Read all 281 lines: component-aware pruning, source/document budgets, warnings/violations and escaped annotation properties. Final-newline counting uses split newline and remains an unexecuted boundary question. Keep Formal AI strict limits; no upstream gate execution is claimed.',
 'scripts/check_release.py':'Read all 225 lines: exact package/version endpoints, explicit-404 absence, bounded responses/requests, authenticated redirect refusal and finite retry deadline. Retain artifact identity and unknown/error refusal; no real publication/provider flow was run.',
 'scripts/check_web_archive.py':'Read all 204 lines: broken URL extraction, recovered-link filtering, malformed-report refusal and per-request deadline. Archive response validation/output handling and overall query bounds remain unexecuted questions; source reading is not a live-link acceptance result.',
 'scripts/check_zizmor_compatibility.py':'Read all 90 lines: one shared pin, complete upstream tree, lock/digest-table compatibility and fatal API/parse failure. Preserve exact pin policy; no live action lookup or fresh audit was executed.',
 'scripts/create_github_release.py':'Read all 343 lines: fence-aware exact changelog slicing, UTF-8 note limits, fresh command-suspension tokens, draft recovery and published-release preservation. Keep Formal AI publication/source policy; no real release or hosting effect was executed.',
 'scripts/detect_code_changes.py':'Read all 200 lines: event comparison/fallback, extension and docs classification, outputs. Suppressed Git errors remain the already-filed #156 defect, not a new report. Formal AI production detector already rejects observation failures; no additional upstream fix is claimed.',
 'scripts/format_release_notes.py':'Read all 266 lines and execute the full pinned CLI with an offline gh boundary. Literal newline/carriage-return/quote escapes in a code example are corrupted and written with success. Removing the three rewrite operations in a disposable candidate preserves these bytes, badge insertion, idempotence and fatal read/write errors. Four focused and 38 maintained cases pass; report remains drafted pending published evidence. No analogous named helper was found in the scoped Formal AI source search.',
 'scripts/install-lychee.sh':'Read all 69 lines: exact version/architecture/checksum pins, bounded retries, independent published/downloaded digest comparison, executable discovery and later-step PATH propagation. Preserve Formal AI verified download policy; no binary installation was executed.',
 'scripts/install-python-dependencies.sh':'Read all 8 lines: pinned pip/uv, locked all-extras synchronization and later-step venv PATH propagation. Existing Formal AI build/PR policy stays authoritative; no package installation was executed.',
 'scripts/preflight-credentials.sh':'Read only lines 1-29: documented write authorization probes, report/release modes and unknown-state requirements. Probe implementation remains unread and no credentials/provider writes were executed.',
 'scripts/release_naming.py':'Read all 104 lines: root/nested layouts, tag/title normalization, encoded badge paths and parsed exact-host badge detection. The complete unchanged helper is hash verified in formatter observations. No live release is claimed.',
 'tests/test_release_badges.py':'Read all 40 lines: unrelated/lookalike URL negative controls, actual badge host idempotence and existing project-link behavior. These cases do not exercise literal escape preservation. Existing pytest cases were not rerun; new full-CLI observations cover that boundary offline.',
}
for row in review['files']:
    data=(root/row['path']).read_bytes()
    assert hashlib.sha256(data).hexdigest()==row['sha256']
    if row['path'] not in active:continue
    numbers=sorted(ranges[row['path']]);merged=[]
    for number in numbers:
        if merged and merged[-1][1]+1==number:merged[-1][1]=number
        else:merged.append([number,number])
    row['readRanges']=merged
    row['reviewStatus']='active-source-fully-read' if len(numbers)==row['lines'] else 'active-source-partially-read' if numbers else 'active-source-unread'
    if row['path'] in decisions:row['decision']=decisions[row['path']]
counts=collections.Counter(row['reviewStatus'] for row in review['files'])
review['counts']={key:counts[key] for key in review['counts']}
review['activeReadLines']=sum(len(ranges[name]) for name in active)
assert review['activeReadLines']==11159 and review['counts']['active-source-partially-read']==1
review['readMethod']='Corrected ordered active-source pages 1-26 (400 lines each) fully read, plus version_and_commit.py 1-615, release_naming.py 1-104 and tests/test_release_badges.py 1-40. Earlier separate create_manual_changeset.py reading now overlaps these pages. Both generated bundles, both lockfiles and every historical blob remain unread. Truncated previews receive no reading credit. Full Formal AI command transcripts retain source output.'
review['runtimeEvidence']='Hosted head 1cc2d536a passes all 24 workflows; retained Layered CI log confirms all three Python npm inventory cases and all four Python fragment cases executed with Python 3.15.2. Its dedicated Formal AI audit file was absent from fast selection; this batch adds it with a failing-before selection guard. Local complete formatter CLI observation: four cases pass; maintained template entrypoint: 38 pass, no skips. Candidates are disposable, gh/npm are offline boundaries, and no full upstream suite/build/provider effect is claimed.'
header={key:value for key,value in review.items() if key!='files'}
path.write_text(json.dumps(header,indent=2)[:-2]+',\n  "files": [\n'+',\n'.join('    '+json.dumps(row,ensure_ascii=False,separators=(',',':')) for row in review['files'])+'\n  ]\n}\n')

full=review['counts']['active-source-fully-read'];unread=review['counts']['active-source-unread']
summary=f'The Python review now fully reads {full} active files plus one partial file (11,159/44,284 active lines), through corrected pages 1-26 and separately read release/helper tests. The {unread} unread active files include both generated bundles and both lockfiles; all 126 historical blobs remain unread. Hash verification is separate from semantic reading and source reading is separate from execution.'
hosted='All 24 workflows passed on `1cc2d536ac11e26602cc55a40dffb61716233aa6`. Full Layered CI run 44116797181 and hashes are retained under `experiments/issue-1580/evidence/ci/1cc2d536a/`. Log lines 4954-4956 confirm all three Python npm inventory observations executed; lines 4948-4951 confirm all four fragment cases. The dedicated Formal AI audit tests were missing from the explicit fast inventory; this batch adds their complete ten-case file and a failing-before selection assertion. Main-only native, benchmark, publication and live-identity criteria remain unfinished.'
audit='The repaired Formal AI JavaScript dependency helper checks one successful lockfile inventory before auditing; all ten local regressions pass and existing retry/threshold behavior is retained. The matching Python defect is filed as [upstream #158](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/158), against published evidence at `1cc2d536a`. The exact posted body, fresh duplicate inventory and real-Git reproduction are retained under `experiments/issue-1580/evidence/checks/audit-inventory-boundary/`. Reporting does not repair the upstream helper.'
formatting='The full unchanged Python release-formatting CLI rewrites literal `\\n`, `\\r` and escaped quotes in code examples and submits the corrupted body with success. A disposable candidate removes those three rewrites; four focused observations preserve escape bytes, Unicode, badge insertion, idempotence and fatal API read/write errors. The preservation case fails when that candidate is disabled; the maintained entrypoint passes 38 cases without skips. Complete logs, source identities and the distinct report draft are under `experiments/issue-1580/evidence/checks/python-release-formatting/` and `experiments/issue-1580/upstream/python-release-formatting-report.md`. The GitHub CLI is an offline stand-in; no hosted release, upstream repair or full Python suite is claimed. Publish immutable evidence before filing. Independent Formal AI reasoning remains 0/20 accepted.'
for name in ['docs/case-studies/issue-1580/README.md','docs/case-studies/issue-1580/templates/README.md','experiments/issue-1580/work-plan.md']:
    target=Path(name);text=target.read_text();marker='## Python review and audit inventory checkpoint'
    assert text.count(marker)==1
    target.write_text(text.split(marker)[0]+'## Python review, audit coverage and release-note preservation\n\n'+summary+'\n\n'+hosted+'\n\n'+audit+'\n\n'+formatting+'\n')
evidence=Path('experiments/issue-1580/evidence/checks/audit-inventory-boundary/README.md')
text=evidence.read_text();old='The upstream report body is drafted in `upstream/python-audit-inventory-report.md`; no filed issue or upstream repair is claimed yet.'
assert old in text
text=text.replace(old,'The report is filed as [Python template #158](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/158) with immutable evidence at `1cc2d536a`. `filed-report.json` preserves the exact body and identity; no upstream repair is claimed.')
evidence.write_text(text)
for number in [17,88]:
    source=Path(f'experiments/issue-1580/evidence/checks/python-release-formatting/related-{number}-comments.json.gz')
    target=source.with_name(f'related-pulls-{number}-comments.json.gz')
    assert source.exists() and not target.exists();source.rename(target)
print(json.dumps({'counts':review['counts'],'activeReadLines':review['activeReadLines'],'completePythonReviewClaimed':False,'independentAuthorshipCredit':0},indent=2))
