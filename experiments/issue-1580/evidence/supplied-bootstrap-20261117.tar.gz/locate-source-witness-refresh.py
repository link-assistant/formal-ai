from pathlib import Path
import subprocess

print('SCRATCH WITNESS SCRIPTS')
for name in sorted(Path('/tmp/issue-1580-research').glob('*witness*.py')):
    print(name)
print('FIXTURE INTEGRITY TEST')
lines=Path('rust/tests/web/rust-specification-fixture-integrity.test.mjs').read_text().splitlines()
for number,line in enumerate(lines[:110],1):
    print(f'{number}: {line}')
files=subprocess.check_output(['rg','--files','--no-ignore','scripts'],text=True).splitlines()
print('\n'.join(name for name in files if 'witness' in name or 'specification-fixture' in name))
