from pathlib import Path
import gzip, hashlib, json, os, re, subprocess, time

root=Path('/tmp/gh-issue-solver-1794900398048')
base=Path('/tmp/issue-1580-research/unverified-child-status-final')
initial=Path('/tmp/issue-1580-research/unverified-child-status')
destination=root/'experiments/issue-1580/evidence/checks/unverified-child-status/formatting-correction'
report=json.loads((base/'outcome.json').read_text())
assert report['complete'] is False
assert [(row['name'],row['exitCode']) for row in report['checks'] if row['exitCode']] == [('rustfmt',1)]
gate=(base/'all-local-gates.log').read_text().splitlines()
assert sum(line.startswith('PASS ') for line in gate)==86
assert sum(line.startswith('SKIP ') for line in gate)==52
assert not any(line.startswith('FAIL ') for line in gate)
pid=json.loads((base/'process.json').read_text())['pid']
stat=Path(f'/proc/{pid}/stat')
assert not stat.exists() or stat.read_text().split()[2]=='Z'
destination.mkdir(exist_ok=True)
native=root/'rust/tests/unit/meta_executor_parity.rs'
before_archive=destination/'native-before.rs.gz'
if before_archive.exists():
    before=gzip.decompress(before_archive.read_bytes())
else:
    before=native.read_bytes()
    before_archive.write_bytes(gzip.compress(before,mtime=0))
results=[]
for name,command in [('format',['rustfmt','--edition','2024',str(native)]),('check',['rustfmt','--edition','2024','--check',str(native)])]:
    started=time.time()
    outcome=subprocess.run(command,cwd=root,capture_output=True)
    for kind,raw in [('stdout',outcome.stdout),('stderr',outcome.stderr)]:
        (destination/f'{name}.{kind}.gz').write_bytes(gzip.compress(raw,mtime=0))
    results.append({'name':name,'command':command,'exitCode':outcome.returncode,'durationSeconds':round(time.time()-started,3),'stdoutSha256':hashlib.sha256(outcome.stdout).hexdigest(),'stderrSha256':hashlib.sha256(outcome.stderr).hexdigest()})
    assert outcome.returncode==0,(name,outcome.stderr.decode())
after=native.read_bytes()
normalized_before=re.sub(rb'\s+',b'',before)
normalized_after=re.sub(rb'\s+',b'',after)
assert normalized_before.count(b'.iter().cloned());')==1
assert normalized_before.replace(b'.iter().cloned());',b'.iter().cloned(),);',1)==normalized_after
(destination/'native-after.rs.gz').write_bytes(gzip.compress(after,mtime=0))
extra=[]
for name in ['validation-runner-initial.py.gz','expanded-29-case-fixture.json.gz','memory-observation.json']:
    source=initial/name
    if source.exists():
        raw=source.read_bytes()
        output=destination/name
        output.write_bytes(raw)
        extra.append({'file':name,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
summary={'complete':True,'nativeChangeLayoutOnly':True,'formattingDelta':'Whitespace plus one optional trailing argument comma inserted by rustfmt. The first post-format audit rejected that comma because it incorrectly assumed byte differences would be whitespace only; the strict token comparison now permits exactly that recorded comma.','beforeSha256':hashlib.sha256(before).hexdigest(),'afterSha256':hashlib.sha256(after).hexdigest(),'focusedTestsPassed':25,'sharedFixtures':{'originalByteIdenticalCases':25,'newStatusCases':4},'allLocalGates':{'pass':86,'excluded':52,'fail':0,'aggregateSha256':hashlib.sha256((base/'all-local-gates.log').read_bytes()).hexdigest()},'priorFailedOutcomeRetained':True,'nativeExecuted':False,'rustBuildsEnabled':False,'independentAuthorshipCredit':0,'checks':results,'extraArchives':extra}
(destination/'outcome.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
