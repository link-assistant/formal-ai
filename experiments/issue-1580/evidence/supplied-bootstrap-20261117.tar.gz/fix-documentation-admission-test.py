from pathlib import Path
file=Path('rust/tests/web/documentation-only-ci-policy.test.mjs')
text=file.read_text()
text=text.replace("  const needs = new Proxy({}, {get: () => ({result: 'success', outputs})});", """  const results = new Map();
  const needs = new Proxy({}, {get: (_, id) => {
    assert.ok(Object.hasOwn(release.jobs, id), 'unknown job dependency ' + id);
    if (!results.has(id)) results.set(id, evaluate(release.jobs[id].if) ? 'success' : 'skipped');
    return {result: results.get(id), outputs};
  }});""")
text=text.replace("'native-type-check', 'pipeline-status', 'release-preflight', 'version-check']);", "'native-type-check', 'pipeline-status', 'release-preflight', 'secrets-scan', 'version-check']);")
file.write_text(text)
