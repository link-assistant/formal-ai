from pathlib import Path
import gzip,hashlib,json,re
r=Path('/tmp/gh-issue-solver-1794900398048')
out=r/'experiments/issue-1580/evidence/checks/picomatch-single-branch/gates'
out.mkdir(exist_ok=True)
aggregate=Path('/tmp/issue-1580-research/picomatch-validation-complete-local-gates.log').read_text()
names=re.findall(r'^PASS ([^ ]+)',aggregate,re.M)
rows=[]
for name in names:
 filename=re.sub(r'[^\w.#-]','_',name)+'.log'
 p=r/'experiments/formal_ai_subagent/sandboxes/gates'/filename
 raw=p.read_bytes()
 (out/(filename+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
 rows.append({'gate':name,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest()})
 if name in ['check-file-size','check-file-size-js-twin','check-javascript-dependencies']:
  print(name,'lines',len(raw.splitlines()))
  for i,line in enumerate(raw.decode().splitlines()):
   if any(x in line.lower() for x in ['warning','picomatch','vulnerabilit','auditing']):
    print(str(i+1)+': '+line)
(out/'index.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Archived',len(rows),'complete successful gate logs')
