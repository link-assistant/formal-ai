from pathlib import Path
import json,subprocess
mapping=json.loads(Path('data/benchmarks/focused-test-map.json').read_text())
print('Focused template suite references:',[(x['id'],x['tests']) for x in mapping['families'] if any('1580-template' in p for p in x['tests'])])
print('Existing runtime helpers:')
result=subprocess.run(['rg','--files','experiments/issue-1580'],capture_output=True,text=True)
print('\n'.join(p for p in result.stdout.splitlines() if p.endswith('.mjs') and '/evidence/' not in p))
result=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--list'],capture_output=True,text=True)
Path('/tmp/issue-1580-research/python-ci-gate-list.log').write_text(result.stdout+result.stderr)
print('Relevant local gates:')
print('\n'.join(line for line in result.stdout.splitlines() if any(w in line.lower() for w in ['workflow','runner','abbreviat','file-size','ci-speed','readable','default','source','shell','action'])))
print('Layered retained payload?',[(x['file'],x['id']) for x in json.loads(Path('data/benchmarks/fast-pull-request-retained-jobs.json').read_text())['jobs'] if x['file']=='layered-ci.yml'])
