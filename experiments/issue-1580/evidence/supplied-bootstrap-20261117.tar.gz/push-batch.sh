#!/bin/sh
set -eu
test "$(git branch --show-current)" = issue-1580-8d61a32a61e1
git fetch origin main issue-1580-8d61a32a61e1
git merge-base --is-ancestor origin/main HEAD
git show origin/main:.gitkeep > .gitkeep
if ! git diff --quiet -- .gitkeep; then
  git add .gitkeep
  git commit -m 'chore: remove the prepared branch placeholder timestamp'
fi
test -z "$(git status --porcelain)"
gh run list --repo link-assistant/formal-ai --branch issue-1580-8d61a32a61e1 --status in_progress --json databaseId,workflowName,headSha > /tmp/issue-1580-research/pre-push-in-progress.json
gh run list --repo link-assistant/formal-ai --branch issue-1580-8d61a32a61e1 --status queued --json databaseId,workflowName,headSha > /tmp/issue-1580-research/pre-push-queued.json
python3 - <<'PY'
import json
from pathlib import Path
for file in ['pre-push-in-progress.json','pre-push-queued.json']:
    value=json.loads((Path('/tmp/issue-1580-research')/file).read_text())
    assert not value,(file,value)
print('No running or queued branch workflows. Main is merged and the working tree is clean.')
PY
git log -5 --oneline
git push origin HEAD:refs/heads/issue-1580-8d61a32a61e1
git rev-parse HEAD
