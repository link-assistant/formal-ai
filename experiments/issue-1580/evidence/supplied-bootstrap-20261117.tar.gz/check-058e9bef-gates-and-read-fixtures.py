from pathlib import Path
import gzip,json,subprocess
receipt=Path('experiments/issue-1580/evidence/checks/main-merge-058e9bef/all-local-gates.json')
print('GATE RECEIPT EXISTS',receipt.exists())
if receipt.exists():print(receipt.read_text())
else:
    log=Path('/tmp/issue-1580-research/merged-058e9bef-all-gates-supervisor.log')
    print('SUPERVISOR TAIL', '\n'.join(log.read_text().splitlines()[-8:]))
for p in ['rust/tests/web/page-formalization-route.test.mjs','rust/tests/web/issue-1172-extractive-reading.test.mjs']:
    path=Path(p)
    if not path.exists():continue
    lines=path.read_text().splitlines()
    print('SOURCE',p,'LINES',len(lines),'FIRST 145')
    for i,line in enumerate(lines[:145],1):print(str(i)+': '+line)
print(subprocess.check_output(['git','status','--short','--untracked-files=no'],text=True))
