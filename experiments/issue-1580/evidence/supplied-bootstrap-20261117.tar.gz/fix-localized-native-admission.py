from pathlib import Path
import gzip,hashlib,json,os,re,subprocess,time
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/localized-native-admission';base.mkdir(exist_ok=False)
test_path=root/'rust/tests/web/default-branch-build-policy.test.mjs';source_path=root/'scripts/ci-pull-request-admission.mjs'
test='''

test('localized native replay selects both its test source and consumed fixture', () => {
  const paths = ['rust/tests/web/issue-1396-native.test.mjs',
    'rust/tests/fixtures/issue-1396/wiki-how-ru.json'];
  assert.deepEqual(paths.map(path => admission([path])['native-type-check']), [true, true]);
  for (const path of ['rust/tests/web/unrelated.test.mjs', 'rust/tests/fixtures/unrelated.json'])
    assert.equal(admission([path])['native-type-check'], false, path);
});
'''
assert 'localized native replay selects both' not in test_path.read_text();test_path.write_text(test_path.read_text()+test)
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256');args=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',str(test_path.relative_to(root))];records=[]
def run(name,expected,counts):
 started=time.monotonic();result=subprocess.run(args,cwd=root,env=env,capture_output=True);raw=result.stdout+result.stderr;packed=gzip.compress(raw,mtime=0);(base/(name+'.log.gz')).write_bytes(packed);text=raw.decode()
 actual={key:int(re.search(r'^(?:ℹ|#) '+key+r' (\d+)',text,re.M)[1]) for key in ['tests','pass','fail','skipped']};assert result.returncode==expected and actual==counts,(result.returncode,actual)
 row={'name':name,'argv':args,'exitCode':result.returncode,'seconds':round(time.monotonic()-started,3),'counts':actual,'file':name+'.log.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'lines':len(raw.splitlines())};records.append(row);print(json.dumps(row),flush=True)
run('before',1,{'tests':27,'pass':26,'fail':1,'skipped':0})
text=source_path.read_text();needle="  'rust/tests/web/issue-1586-structured-output.test.mjs',\n";assert text.count(needle)==1
text=text.replace(needle,needle+"  'rust/tests/web/issue-1396-native.test.mjs',\n  'rust/tests/fixtures/issue-1396/wiki-how-ru.json',\n");source_path.write_text(text)
fragment=root/'changelog.d/issue-1580-localized-native-admission.md';assert not fragment.exists();fragment.write_text('Fix native regression admission for localized how-to test and fixture changes.\n')
run('after',0,{'tests':27,'pass':27,'fail':0,'skipped':0})
(base/'results.json').write_text(json.dumps(records,indent=2)+'\n');(base/'outcome.json').write_text(json.dumps({'complete':True,'allPassedAfterFix':True,'regressionReproduced':True,'sources':[str(p.relative_to(root)) for p in [test_path,source_path,fragment]],'nativeExecutedLocally':False,'independentAuthorshipCredit':0},indent=2)+'\n')
