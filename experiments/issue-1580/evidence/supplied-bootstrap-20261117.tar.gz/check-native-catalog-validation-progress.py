from pathlib import Path
import subprocess,json
p=Path('/tmp/issue-1580-research/native-catalog-batch-validation');f=p/'all-gates.log';rows=f.read_text().splitlines();print('GATES',len(rows));print('\n'.join(rows[-7:]));print('FAILURES',[l for l in rows if l.startswith('FAIL')]);print('OUTCOME',(p/'outcome.json').read_text()if(p/'outcome.json').exists()else'pending');print('MEMORY_BYTES',Path('/sys/fs/cgroup/memory.current').read_text().strip());print(subprocess.run(['ps','-p','2534314,2574986,2578611','-o','pid,stat,etime,args'],capture_output=True,text=True).stdout)
