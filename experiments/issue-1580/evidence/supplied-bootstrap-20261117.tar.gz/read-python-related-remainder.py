from pathlib import Path
import gzip
import json

directory = Path('experiments/issue-1580/evidence/checks/python-fragment-collision')
pages = json.loads(gzip.decompress((directory / 'upstream-issues.json.gz').read_bytes()))
item = next(item for page in pages for item in page if item['number'] == 152)
print('RELATED 152', item['title'])
print(item['body'])
print('\nSOURCE AND DUPLICATE CHECK')
print((directory / 'duplicate-and-source-check.json').read_text())
print('\nTEMPLATE REVIEW README LINES 1-47')
for number, line in enumerate(Path('docs/case-studies/issue-1580/templates/README.md').read_text().splitlines()[:47], 1):
    print(f'{number}: {line}')
