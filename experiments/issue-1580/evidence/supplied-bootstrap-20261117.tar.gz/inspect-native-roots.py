from pathlib import Path
import subprocess,gzip,re

for args in [
 ['rg','-n','This request routes to|does not expose the required','rust','js','data','scripts','web'],
 ['rg','-n','SOLVER_CAPABILITIES|HonestGap|try_natural_language_tool_request','rust/src/meta_method_dispatch.rs','rust/src/solver.rs','rust/src/solver_dispatch.rs'],
 ['rg','-l','calendar_create_event|calendarCreateEvent|calendar_create','js','rust/tests/web'],
]:
 p=subprocess.run(args,text=True,capture_output=True)
 print('SEARCH',args,'\n',p.stdout,p.stderr)
wanted=set()
for start in [43214,47787,74640]: wanted.update(range(start,start+5))
with gzip.open('experiments/issue-1580/evidence/ci/main-512ce428/44117975432.log.gz','rt') as stream:
 for n,line in enumerate(stream,1):
  if n in wanted:
   text=re.sub(r'^\d{4}-\d\d-\d\dT\S+\s','',line.rstrip().split('\t',2)[-1])
   print(f'{n}: {text[:1800]}')
