from pathlib import Path
import gzip,json,subprocess

directory=Path('experiments/issue-1580/evidence/checks/python-release-formatting')
metadata=directory/'all-local-gates.json'
if metadata.exists():
    record=json.loads(metadata.read_text())
    print('FULL GATES',json.dumps({key:record[key] for key in ['status','durationSeconds','rustBuildsEnabled','offlineAuditStandIns']}))
    lines=gzip.decompress((directory/record['log']).read_bytes()).decode().splitlines()
    print('LAST GATE LOG LINES')
    print('\n'.join(f'{n}: {line}' for n,line in enumerate(lines,1) if n>len(lines)-35))
else:
    path=directory/'all-local-gates.log'
    lines=path.read_text().splitlines() if path.exists() else []
    print('Gates still running; last twelve emitted lines')
    print('\n'.join(lines[-12:]))
print('CURRENT SOURCE DIFF')
names=['data/benchmarks/fast-pull-request-javascript-tests.json','rust/tests/web/fast-pull-request-production-profile.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs']
print(subprocess.run(['git','diff','--',*names],capture_output=True,text=True,check=True).stdout)
print('CURRENT CHANGE SUMMARY')
print(subprocess.run(['git','diff','--stat'],capture_output=True,text=True,check=True).stdout)
print('BRANCH',subprocess.run(['git','branch','--show-current'],capture_output=True,text=True,check=True).stdout.strip())
