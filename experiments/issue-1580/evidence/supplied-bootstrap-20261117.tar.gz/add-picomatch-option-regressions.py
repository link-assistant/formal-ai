from pathlib import Path
import subprocess,hashlib,gzip,json
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'rust/tests/web/picomatch-security-backport.test.mjs'
s=p.read_text()
s+='''
test('POSIX negation retains literal stars after an initial literal closing bracket', () => {
  assert.equal(picomatch.isMatch('aa', '+([!]*])', {posix:true}), true);
  assert.equal(picomatch.isMatch('***', '+([!]*])', {posix:true}), false);
});

test('unescape cannot expose a star quantifier under unbounded repetition', () => {
  const pattern = '+(a\\\\\\\\*)';
  assert.equal(picomatch.isMatch('aaaa', pattern, {unescape:true}), false);
  assert.equal(picomatch.isMatch(pattern, pattern, {unescape:true}), true);
});
'''
p.write_text(s)
e=r/'experiments/issue-1580/evidence/checks/picomatch-single-branch'
log=Path('/tmp/issue-1580-research/picomatch-option-before.log')
with log.open('w') as out:
 cp=subprocess.run(['timeout','600','node','--max-old-space-size=96','--test','--test-concurrency=1',str(p)],cwd=r,stdout=out,stderr=subprocess.STDOUT)
raw=log.read_bytes()
with gzip.open(e/'option-before.log.gz','wb') as out:out.write(raw)
(e/'option-before.json').write_text(json.dumps({'exitCode':cp.returncode,'rawSha256':hashlib.sha256(raw).hexdigest(),'autonomousAuthorshipCredit':0},indent=2)+'\n')
print(raw.decode())
