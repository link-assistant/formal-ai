from pathlib import Path
import gzip, hashlib, json, re

root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/checks/native-summary-governed-refresh'
report=json.loads((base/'results.json').read_text())
assert report['complete'] and len(report['checks'])==7
assert [row['exitCode'] for row in report['checks']]==[1,1,0,0,0,0,0]
all_rows=report['checks']+report['gatePayloads']
for row in all_rows:
    packed=(base/(row['name']+'.log.gz')).read_bytes()
    raw=gzip.decompress(packed)
    assert hashlib.sha256(packed).hexdigest()==row['archiveSha256']
    assert hashlib.sha256(raw).hexdigest()==row['rawSha256']
    assert len(raw.splitlines())==row['rawLines']
aggregate=gzip.decompress((base/'all-local-gates.log.gz').read_bytes()).decode()
assert len(re.findall(r'^PASS ',aggregate,re.M))==86
assert len(re.findall(r'^SKIP ',aggregate,re.M))==52
assert not re.search(r'^FAIL ',aggregate,re.M)
assert len(report['gatePayloads'])==86
review=json.loads((base/'complete-object-review.json').read_text())
assert review['completeInventoryDeepEqual'] and review['completeWitnessDeepEqualAfterExactlyOneReviewedHash']
assert len(review['changes'])==1 and review['total']==1185 and review['supported']==221 and review['unsupported']==964
review_receipt={'allPayloadHashesVerified':True,'payloads':len(all_rows),'executableGates':86,'explicitExclusions':52,'failedGates':0,'singleSourceIdentityChange':review['changes'][0],'completeInventoryDeepEqual':True,'localNativeExecution':False,'allDetailedGatePayloadsLiterallyRead':False,'independentAuthorshipCredit':0}
(base/'review.json').write_text(json.dumps(review_receipt,indent=2)+'\n')
ci=root/'experiments/issue-1580/evidence/ci/native-summary-73da561d'
scratch=Path('/tmp/issue-1580-research/ci-logs/native-summary-73da561d')
collector=[]
for name in ['outcome.json','worker.log']:
    raw=(scratch/name).read_bytes()
    if name=='outcome.json': assert json.loads(raw)['complete']
    packed=gzip.compress(raw,mtime=0)
    (ci/(name+'.gz')).write_bytes(packed)
    assert gzip.decompress(packed)==raw
    collector.append({'file':name+'.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'rawLines':len(raw.splitlines())})
(ci/'collector-receipt.json').write_text(json.dumps({'payloads':collector,'fullPayloadsLiterallyRead':False,'independentAuthorshipCredit':0},indent=2)+'\n')
checkpoint=root/'docs/case-studies/issue-1580/native-synthesis-checkpoint.md'
text=checkpoint.read_text()
anchor='PR: https://github.com/link-assistant/formal-ai/pull/1581\n\n'
assert text.count(anchor)==1
current='''Current published input `73da561d993cee3506e9f77dba353255888c4acc` completes all **23 workflows: 22 succeed, one fails**. The [native job](https://github.com/link-assistant/formal-ai/actions/runs/44314403754/job/134837122068) passes calendar/currency **1/1**, executor **8/8**, forced functions **1/1**, synthesis **12/12**, and both HTTP cases. Literal native log lines 1630–1746 cover those results, including the corrected exact Halley answer. This verifies the isolated targets, not every original main regression.

The remaining [Layered CI failure](https://github.com/link-assistant/formal-ai/actions/runs/44314403386) has one failure per JavaScript shard, both caused by the synthesis file's stale governed source hash. Group 1 reports 1,189 passes, one failure and four skips (literal lines 4750–4810); group 2 reports 1,541 passes, one failure and 13 skips (literal lines 2905–2980). Both have zero cancellations. The complete logs and hashes are retained under `experiments/issue-1580/evidence/ci/native-summary-73da561d/`; only the stated ranges are claimed as literally reviewed.

Both unchanged regression files reproduce the stale identity locally before the repair. The maintained explicit reviewed-baseline writer updates exactly `sourceManifest/116/sha256`, for `rust/tests/unit/specification/synthesis.rs`, from `257e83c8d00c70af9ce40adeb4708cc63fb778b103487d4accb0da9545e872b9` to `7f002374b4092ca4626db9f278189f583570aefa74c08dc7cc4e109c8c346a93`. Complete-object comparison preserves every case object, all 221 supported and 964 unsupported records, and the reader itself. No expected answer, unsupported reason, guard, budget or test inventory changes in this refresh.

Afterward fixture integrity passes **2/2** and identifier checks **34/34**. All **86 executable gates pass**, with **52 explicit native/context exclusions and zero failures**, under the 256 MiB Node heap cap. Complete aggregate and detailed payloads are hash verified and retained under `experiments/issue-1580/evidence/checks/native-summary-governed-refresh/`. The five focused before/after logs were read in full; detailed successful gate payloads are retained without claiming full literal review. No local Rust build runs. Hosted verification of this single source-identity refresh remains pending.

The preceding failure and its source correction remain recorded below.

'''
text=text.replace(anchor,anchor+current)
text=text.replace('Hosted execution of the correction remains pending.','Hosted execution of the correction subsequently passes all 12 synthesis cases on `73da561d9`, as recorded above.')
checkpoint.write_text(text)
plan=root/'experiments/issue-1580/work-plan.md'
text=plan.read_text()
old='- [ ] Pass both unchanged JavaScript regression files and the complete 138-entry local gate inventory, inspect full result/hash receipts, then publish this one correction batch after the single-push gate.'
assert text.count(old)==1
text=text.replace(old,'- [x] Both unchanged JavaScript regression files pass (2/2 and 34/34); all 86 executable gates pass with 52 explicit exclusions and zero failures. Verify all 93 retained payload hashes and the exact one-hash complete-object witness comparison. No local Rust build.\n- [ ] Publish the complete correction/evidence batch only after clean-tree, main-ancestry and empty active/queued-run checks.')
plan.write_text(text)
body=root/'experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md'
text=body.read_text()
text=text.replace('Automatic-release admission is reported in [PHP template #27](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/27).','Automatic-release admission is reported in [PHP template #27](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/27); ignored rejected pushes are reported separately in [PHP template #28](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/28).')
start=text.index('- Published head `fda677ef9`')
end=text.index('- The summary correction passes',start)
text=text[:start]+'''- Published head `73da561d9` completes **23 workflows: 22 pass, one fails**. The [actual native job](https://github.com/link-assistant/formal-ai/actions/runs/44314403754/job/134837122068) passes calendar/currency **1/1**, executor **8/8**, forced functions **1/1**, synthesis **12/12**, and both HTTP cases. Native source-operand cases produce **36**, **72** and **3**; the corrected exact Halley expectation also passes. These isolated targets do not cover every original main failure.
- That head's sole [Layered CI failure](https://github.com/link-assistant/formal-ai/actions/runs/44314403386) is the synthesis specification's stale governed source hash, reported once in each JavaScript shard. Both unchanged regression files reproduce the failure. The reviewed refresh changes exactly one authoritative source hash and preserves all **1,185 complete records** (221 supported, 964 unsupported), with the reader unchanged. The full failed workflow, job logs, identities and exact review ranges are retained in the [native synthesis checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/native-synthesis-checkpoint.md). Hosted re-execution of the refresh is pending.
'''+text[end:]
text=text.replace('Its distinct upstream report is prepared, pending immutable evidence publication and a fresh duplicate/source check.','[Upstream report #28](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/28) is filed after fresh source/duplicate checks and immutable evidence verification; its exact posted body and receipt are retained.')
start=text.index('- Before the preceding shared-data publication,')
end=text.index('- Earlier published algebra head',start)
text=text[:start]+'''- After the reviewed source-identity refresh, **all 86 executable local gates pass**, with **52 explicit native/context exclusions and zero failures**, under a 256 MiB Node heap cap. Both unchanged fixture-integrity **2/2** and identifier **34/34** files pass. All 93 aggregate, focused and detailed gate payloads are retained and hash verified; complete case objects remain equal. No local Rust build runs.
'''+text[end:]
anchor='timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/summary-payload-routing.test.mjs\n'
assert text.count(anchor)==1
text=text.replace(anchor,anchor+'timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/rust-specification-fixture-integrity.test.mjs\ntimeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/rust-specification-unicode-identifiers.test.mjs\n')
assert text.count('Fixes #1580')==1
body.write_text(text)
print(json.dumps(review_receipt,indent=2))
print('COMPLETE LOCAL GATE AGGREGATE\n'+aggregate)
print('UPDATED PR BODY\n'+text)
