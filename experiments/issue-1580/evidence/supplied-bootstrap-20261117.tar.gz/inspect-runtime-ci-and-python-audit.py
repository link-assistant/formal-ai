from pathlib import Path
import subprocess,json,gzip
def run(args):return subprocess.run(args,capture_output=True,text=True,check=True).stdout
value=json.loads(run(['gh','run','view','44112040276','--repo','link-assistant/formal-ai','--json','status,conclusion,headSha,jobs,url']))
Path('/tmp/issue-1580-research/python-runtime-ci-progress.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({k:v for k,v in value.items() if k!='jobs'},indent=2))
for job in value['jobs']:
 if job['status']!='completed' or job['conclusion']!='success' or 'js tier' in job['name']:
  print(json.dumps({'name':job['name'],'status':job['status'],'conclusion':job['conclusion'],'steps':[s for s in job['steps'] if s['status']!='completed' or s['conclusion']!='success' or 'Python' in s['name']]},indent=2))
print('Collector:')
for i,line in enumerate(Path('/tmp/issue-1580-research/collect-python-fragment-head-ci.py').read_text().splitlines()[:130],1):print(f'{i}: {line}')
print('Formal AI dependency audit helpers:')
files=run(['rg','--files','scripts']).splitlines();print('\n'.join(p for p in files if 'audit' in p))
p=Path('experiments/issue-1580/evidence/checks/python-fragment-collision/final-duplicate-issues.json.gz')
value=json.loads(gzip.decompress(p.read_bytes()))
print('Issue snapshot shape:',type(value).__name__,list(value)[:8] if isinstance(value,dict) else len(value))
