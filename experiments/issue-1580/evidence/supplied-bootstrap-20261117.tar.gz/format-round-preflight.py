from pathlib import Path
import gzip, hashlib, json, subprocess
root=Path("/tmp/gh-issue-solver-1794900398048")
out=root/"experiments/issue-1580/evidence/checks/python-release-formatting"
def run(args):
    p=subprocess.run(args,cwd=root,text=True,capture_output=True)
    if p.returncode: raise RuntimeError(f"{args}: {p.stderr}")
    return p.stdout
assert run(["git","branch","--show-current"]).strip()=="issue-1580-8d61a32a61e1"
assert run(["git","rev-parse","HEAD"]).strip()=="1cc2d536ac11e26602cc55a40dffb61716233aa6"
for suffix,name in [
    ("issues/1580","feedback-issue"),
    ("issues/1580/comments","feedback-issue-comments"),
    ("pulls/1581","feedback-pull-request"),
    ("issues/1581/comments","feedback-pull-request-comments"),
    ("pulls/1581/comments","feedback-inline-comments"),
    ("pulls/1581/reviews","feedback-reviews"),
]:
    raw=run(["gh","api",f"repos/link-assistant/formal-ai/{suffix}","--paginate"])
    data=json.loads(raw)
    (out/(name+".json.gz")).write_bytes(gzip.compress(raw.encode(),mtime=0))
    if isinstance(data,list):
        print(name,len(data))
        for item in data:
            print(json.dumps({k:item.get(k) for k in ["id","created_at","updated_at","state","body"]},ensure_ascii=False))
    else:
        print(name,json.dumps({k:data.get(k) for k in ["number","title","state","draft","updated_at","body"]},ensure_ascii=False))
print("REMOTE MAIN FETCH",run(["git","fetch","origin","main"]).strip())
print("MAIN",run(["git","rev-parse","origin/main"]).strip())
ancestor=subprocess.run(["git","merge-base","--is-ancestor","origin/main","HEAD"],cwd=root)
print("MAIN_IS_ANCESTOR",ancestor.returncode==0)
for status in ["in_progress","queued"]:
    raw=run(["gh","run","list","--repo","link-assistant/formal-ai","--branch","issue-1580-8d61a32a61e1","--status",status,"--limit","100","--json","databaseId,workflowName,headSha,createdAt"])
    (out/("preflight-"+status+".json")).write_text(raw)
    print(status,raw.strip())
