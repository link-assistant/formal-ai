from pathlib import Path
import urllib.request,tarfile,hashlib,io,json,subprocess
out=Path("/tmp/issue-1580-research/picomatch")
d=json.loads((out/"npm-latest.json").read_text())
with urllib.request.urlopen(d["dist"]["tarball"],timeout=30) as response:raw=response.read(2*1024*1024+1)
assert len(raw)<=2*1024*1024
assert hashlib.sha1(raw).hexdigest()==d["dist"]["shasum"]
(out/"picomatch-4.0.7.tgz").write_bytes(raw)
with tarfile.open(fileobj=io.BytesIO(raw),mode="r:gz") as archive:
 for member in archive.getmembers():
  if not member.isfile():continue
  assert member.name.startswith("package/") and ".." not in Path(member.name).parts
  dest=out/member.name
  dest.parent.mkdir(parents=True,exist_ok=True)
  dest.write_bytes(archive.extractfile(member).read())
  print("UPSTREAM FILE",member.name,member.size)
for name,start,count in [
 ("lib/parse.js",160,180),
 ("lib/parse.js",1,90),
 ("package.json",1,100),
 ("index.js",1,80),
 ("posix.js",1,80),
]:
 p=out/"package"/name
 if not p.exists():continue
 lines=p.read_text().splitlines()
 print("SOURCE",name,"WINDOW",start,count,"TOTAL",len(lines))
 for i in range(start-1,min(start-1+count,len(lines))):print(f"{i+1}: {lines[i]}")
print("NODE MODULES",{name:Path(name).exists() for name in ["node_modules/picomatch","desktop/node_modules/picomatch","vscode/node_modules/picomatch","vscode/node_modules/micromatch","desktop/node_modules/tinyglobby"]})
