from pathlib import Path
import collections,gzip,hashlib,json,subprocess
directory=Path("experiments/issue-1580/evidence/ci/main-512ce428")
directory.mkdir(exist_ok=True)
command=["gh","run","list","--repo","link-assistant/formal-ai","--branch","main","--limit","100","--json","databaseId,workflowName,conclusion,status,headSha,createdAt,updatedAt"]
p=subprocess.run(command,text=True,capture_output=True,check=True)
raw=p.stdout.encode();(directory/"runs.json.gz").write_bytes(gzip.compress(raw,mtime=0))
runs=[row for row in json.loads(p.stdout) if row["headSha"]=="512ce428029a92687628b4180309ee5ab660fe08"]
summary={"headSha":"512ce428029a92687628b4180309ee5ab660fe08","selected":len(runs),"counts":dict(collections.Counter((r["conclusion"] or r["status"]) for r in runs)),"runsSnapshotSha256":hashlib.sha256(raw).hexdigest(),"runs":runs}
(directory/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps({k:v for k,v in summary.items() if k!="runs"}))
for row in runs:print(json.dumps(row))
