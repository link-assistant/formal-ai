import gzip,json
from pathlib import Path
root=Path('experiments/issue-1580/evidence/checks/main-merge-826289fc')
status=json.loads(Path('/tmp/issue-1580-research/client-focused-status.json').read_text())
print(json.dumps(status,indent=2))
for row in status['rows']:
    p=root/(Path(row['file']).name.removesuffix('.test.mjs')+'-client-batch.log.gz')
    print('\nFILE',p)
    print(gzip.decompress(p.read_bytes()).decode())
