from pathlib import Path
import json,subprocess
p=Path('rust/tests/web/default-branch-build-policy.test.mjs')
s=p.read_text()
s=s.replace("import {join,resolve} from 'node:path';", "import {dirname,join,relative,resolve} from 'node:path';")
anchor="// The production-only failure this job closes: PR #1497 was green, then main\n"
test="""// A test-only change must execute the same isolated target that consumes it.
test('isolated native regressions select execution for their sources and embedded fixtures', () => {
  const step = workflow('native-type-check.yml').jobs['native-type-check'].steps
    .find(step => step.name === 'Verify isolated native behavior regressions');
  const manifest = read('rust/Cargo.toml').split('[[test]]').slice(1);
  const targets = [...step.run.matchAll(/--test (\\S+)/gu)].map(match => match[1]);
  assert(targets.length > 0);
  for (const target of targets) {
    const block = manifest.find(block => new RegExp('^name = "' + target + '"$', 'mu').test(block));
    assert(block, 'explicit Cargo target ' + target);
    const source = 'rust/' + /^path = "([^"]+)"$/mu.exec(block)[1];
    assert.equal(admission([source])['native-type-check'], true, source);
    for (const match of read(source).matchAll(/include_str!\\(\\s*"([^"]+)"/gu)) {
      const fixture = relative(process.cwd(), resolve(dirname(source), match[1]));
      assert(readFileSync(fixture).length > 0, fixture);
      assert.equal(admission([fixture])['native-type-check'], true, fixture);
    }
  }
});
"""
assert anchor in s and 'isolated native regressions select execution' not in s
p.write_text(s.replace(anchor,test+anchor))
base=Path('/tmp/issue-1580-research/native-test-admission')
base.mkdir(exist_ok=True)
args=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',
      '--test-name-pattern=isolated native regressions select execution',str(p)]
with (base/'before.log').open('wb') as stream:
    result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
report={'argv':args,'exitCode':result.returncode,'expectedFailure':True}
(base/'before.json').write_text(json.dumps(report,indent=2)+'\n')
assert result.returncode!=0,report
print(json.dumps(report))
print((base/'before.log').read_text())
