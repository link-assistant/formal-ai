from pathlib import Path

root=Path('/tmp/gh-issue-solver-1794900398048')
target=root/'rust/tests/web/worker-unknown-language.test.mjs'
addition=r'''

test("a detected language outside the declared answer languages keeps the entire native unresolved body", { timeout: 15000 }, async () => {
  const source = fs.readFileSync("rust/tests/unit/issue_706_any_language.rs", "utf8");
  const region = source.slice(source.indexOf("fn a_language_without_localized_openers_reports_a_gap_not_english()"));
  const prompts = [...region.matchAll(/\.answer\("([^"\n]+)"\)/gu)].map((match) => match[1]);
  assert.equal(prompts.length, 2);
  const literal = region.match(/answer\.answer,\s*("(?:[^"\\]|\\[\s\S])*")/u)[1];
  const expected = JSON.parse(literal.replace(/\\\r?\n\s*/gu, ""));
  const answer = await host.solve(prompts[1]);
  assert.equal(answer.intent, "unknown");
  assert.equal(answer.content, expected);
  assert.ok(answer.rawSolverEvents.some((event) => event.kind === "reasoning:known" && event.payload.startsWith("language=es ")));
  for (const source of ["link_memory", "public_knowledge_cache", "source_cache"]) {
    assert.ok(answer.rawSolverEvents.some((event) => event.kind === "reasoning:gather_attempt" && event.payload === source + ":" + prompts[1].slice(0, -1)));
    assert.ok(answer.rawSolverEvents.some((event) => event.kind === "reasoning:gather_result" && event.payload === source + ":miss"));
  }
});

test("declared answer languages control the fallback independently of detection rules", async () => {
  const result = await host.run(`(() => {
    const original = AGENT_INFO.supported_languages;
    try {
      AGENT_INFO.supported_languages = '("en" "held-out")';
      const supported = solverUnknownLanguage("a held-out request", "held-out", [], [], {});
      AGENT_INFO.supported_languages = '("en")';
      const unsupported = solverUnknownLanguage("a held-out request?", "held-out", [], [], { offline: true });
      return { supported, unsupported };
    } finally { AGENT_INFO.supported_languages = original; }
  })()`);
  assert.equal(result.supported, null);
  assert.ok(result.unsupported?.events.some((event) => event.payload === "missing_answer_for:a held-out request"));
  assert.ok(result.unsupported.events.some((event) => event.payload === "allowed_external_api:skipped_offline"));
});
'''
text=target.read_text()
assert 'a detected language outside the declared answer languages' not in text
target.write_text(text+addition)
plan=root/'experiments/issue-1580/work-plan.md'
with plan.open('a') as stream:
    stream.write('''

## Declared language policy in unresolved JavaScript answers

- [x] Verify publication of edffcb18 and its exact PR body; the prior metadata assertion stripped only the local terminal newline. Preserve the corrected receipt. Fresh CI has 21 passing workflows and two active workflows; no failure or completion conclusion is inferred.
- [x] Read the original complete native Spanish fixture, canonical agent-info answer-language declaration and both unresolved paths. Native uses declared answer languages; the JavaScript terminal helper currently checks only the detector's unknown value. Spanish is detected but absent from the four declared answer languages.
- [ ] Reproduce the complete original Spanish how-question answer mismatch and a held-out metadata-policy control before changing production code. Preserve both failing assertion payloads.
- [ ] Use the maintained seed list parser for the JavaScript terminal policy, preserve actual detected-language trace metadata and native whole-prompt punctuation handling; retain positive supported-language routes.
- [ ] Verify focused regressions and affected gates; collect every result on edffcb18 before any later push. The original adopted Spanish definition route and actual native execution remain separate unfinished criteria.

All supplied diagnostics, patches and conclusions retain zero independent authorship credit. Every earlier broad unchecked acceptance criterion remains open.
''')
print('DRAFTED',target.relative_to(root),'lines',len(target.read_text().splitlines()),flush=True)
