from pathlib import Path
import gzip,hashlib,json,re
directory=Path("experiments/issue-1580/evidence/checks/python-release-formatting")
p=directory/"gate-selection-notation-after.json";record=json.loads(p.read_text())
raw=gzip.decompress((directory/record["log"]).read_bytes())
assert record["status"]==0 and hashlib.sha256(raw).hexdigest()==record["rawSha256"]
assert re.search(r"^(?:#|ℹ) pass 11$",raw.decode(),re.M)
assert re.search(r"^(?:#|ℹ) skipped 0$",raw.decode(),re.M)
record["initialWrapperPostCheckMistake"]="The child passed 11/11, but an initial TAP-only summary assertion rejected Node's spec reporter. Full preserved output confirms zero skips without rerunning the test."
record["summaryConfirmed"]={"pass":11,"fail":0,"skip":0}
p.write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record,ensure_ascii=False))
