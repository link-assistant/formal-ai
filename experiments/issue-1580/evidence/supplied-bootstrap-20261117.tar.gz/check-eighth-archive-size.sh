set -eu
set +e
node experiments/formal_ai_subagent/local-gates.mjs --only check-file-size,check-file-size-js-twin > /tmp/issue-1580-research/java-release-checks/archive-gates.log 2>&1
result=$?
set -e
cat /tmp/issue-1580-research/java-release-checks/archive-gates.log
exit "$result"
