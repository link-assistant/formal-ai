from pathlib import Path
import gzip, hashlib, json, re, subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
ci=root/'experiments/issue-1580/evidence/ci/binding-8a74006f'
records=json.loads((ci/'records.json').read_text())
row=next(row for row in records if row['name']=='job-134952852325')
raw=gzip.decompress((ci/row['stdout']['file']).read_bytes())
assert hashlib.sha256(raw).hexdigest()==row['stdout']['rawSha256']
lines=raw.decode().splitlines()
executed={}
for n,line in enumerate(lines,1):
 match=re.search(r'\btest ([A-Za-z_][A-Za-z0-9_:]*) \.\.\. ok\s*$',line)
 if match:executed.setdefault(match[1],[]).append(n)
mapping=json.loads(Path('/tmp/issue-1580-research/original-native-current-declarations.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
out=[]
for original in mapping['tests']:
 item=dict(original)
 basename=original['originalTest'].split('::')[-1]
 hits=executed.get(basename,[])
 if hits and len(original['currentDeclarations'])==1:
  source=original['currentDeclarations'][0]['path']
  published=subprocess.check_output(['git','show','8a74006f69bc60dbbf52e0235ff380103bbbf375:'+source],cwd=root)
  current=(root/source).read_bytes()
  item['publishedReplay']={'head':'8a74006f69bc60dbbf52e0235ff380103bbbf375',
    'job':134952852325,'run':44347162546,'name':basename,'originalLogLines':hits,
    'logRawSha256':row['stdout']['rawSha256'],'source':source,
    'publishedSourceSha256':hashlib.sha256(published).hexdigest(),
    'currentSourceSha256':hashlib.sha256(current).hexdigest(),
    'currentSourceUnchanged':published==current,'result':'passed'}
  print('VERIFIED PUBLISHED REPLAY',original['originalTest'],'LINES',hits,'SOURCE UNCHANGED',published==current)
 item['currentExecutionVerified']=False
 out.append(item)
result={'currentHead':head,'originalInventoryCount':len(out),
 'publishedHead':'8a74006f69bc60dbbf52e0235ff380103bbbf375',
 'publishedReplays':sum('publishedReplay' in item for item in out),
 'currentHeadReplays':0,'tests':out,'fullAcceptanceVerified':False,
 'limits':'Exact success lines are joined to current declarations by unique test name. Source-byte equality is recorded separately. The current merge head has not executed natively. Remaining original failures and three budget terminations remain open.',
 'independentAuthorshipCredit':0}
dest=root/'experiments/issue-1580/evidence/checks/complete-cache-request-binding/original-native-replay-crosswalk.json'
dest.write_text(json.dumps(result,indent=2)+'\n')
print('SUMMARY',json.dumps({k:v for k,v in result.items() if k!='tests'}))
