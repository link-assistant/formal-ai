import json, pathlib

def replace(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)

path = pathlib.Path('data/meta/request-context.json')
rules = json.loads(path.read_text())
rules['language'].insert(0, r"^(?:answer|respond|reply)\s+in\s+the\s+(same)\s+language\s+as\s+the\s+user['’]s\s+input$")
rules['directiveCue'] = r"^(?:you\s+)?(?:(?:must|should|always|only|please|do\s+not|don't|never|not)\s+)*(?:answer|respond|reply|write|output|return|be brief|отвечай|отвечайте|ответь)(?:\s|$)|^(?:your|the)\s+(?:answer|response|output)\s+(?:must|should)|^(?:use\s+(?:json|xml|csv|markdown|yaml|plain text)|(?:keep|limit)\s+(?:your\s+|the\s+)?(?:answer|response|output))(?:\s|$)"
rules['lineLimit'] = [r"^(?:you\s+)?(?:must\s+)?(?:always\s+)?(?:answer|respond|reply)\s+(?:concisely\s+)?with\s+(exactly|at most|no more than|fewer than|less than)\s+(one|[0-9]+)\s+lines?(?:\s+of\s+text)?(?:\s+\(not including tool use or code generation\))?(?:,\s+(unless (?:the )?user asks for detail))?$"]
rules['sameLanguage'] = 'same'
rules['lineLimitKind'] = 'lines'
rules['strictLineModes'] = ['fewer than', 'less than']
rules['detailRequest'] = r"(?:^|\s)(?:explain|describe|answer|respond|reply|write|provide)(?:\s+[\p{L}]+){0,4}\s+in\s+detail(?:\s|[.!?]|$)|(?:^|\s)(?:give|provide)\s+(?:me\s+)?(?:a\s+)?detailed\s+(?:explanation|answer|description)(?:\s|[.!?]|$)"
text = json.dumps(rules, ensure_ascii=False, indent=2) + '\n'
path.write_text(text)
pathlib.Path('rust/embedded/data/meta/request-context.json').write_text(text)

for name in ('js/server/request-context.mjs', 'ts/server/request-context.mts'):
    path = pathlib.Path(name)
    text = path.read_text()
    text = replace(text, "import { thinkingStep } from './thinking.mjs';", "import { thinkingStep } from './thinking.mjs';\nimport { detect } from '../agentic/crate/language.mjs';")
    text = replace(text, "      const add = (kind, value) => constraints.push({ role, index, text, kind, value, status: 'pending' });", """      // A quoted example or a conditional continuation is not a direct instruction.
      if (!re(rules.directiveCue).test(text)) continue;
      const add = (kind, value) => constraints.push({ role, index, text, kind, value, status: 'pending' });
      const lines = captures('lineLimit', text);
      if (lines) {
        add('output', [rules.lineLimitKind, lines[1].toLowerCase(), rules.numberWords[lines[2].toLowerCase()] ?? lines[2], lines[3] ? 'detail' : ''].join('|'));
        continue;
      }""")
    text = replace(text, "return { prompt, history, constraints, active, language: languageOf(active('language')?.value) };", "return { prompt, history, constraints, active, language: active('language')?.value === rules.sameLanguage ? detect(prompt) : languageOf(active('language')?.value) };")
    text = replace(text, "satisfied = Boolean(languageOf(item.value)) &&", "satisfied = (item.value === rules.sameLanguage ? Object.hasOwn(rules.languages, context.language) : Boolean(languageOf(item.value))) &&")
    text = replace(text, "    if (item.kind === 'labels') satisfied = item.value.split('|').includes(text.toLowerCase());", """    if (item.kind === 'output') {
      const [kind, mode, count, exception] = item.value.split('|');
      if (kind === rules.lineLimitKind) {
        const lines = text === '' ? 0 : text.split(/\\r?\\n/u).length - Number(text.endsWith('\\n'));
        const comparison = compareDecimals(String(lines), count);
        satisfied = exception === 'detail' && re(rules.detailRequest).test(context.prompt)
          || (mode === 'exactly' ? comparison === 0 : rules.strictLineModes.includes(mode) ? comparison < 0 : comparison <= 0);
      }
    }
    if (item.kind === 'labels') satisfied = item.value.split('|').includes(text.toLowerCase());""")
    path.write_text(text)

path = pathlib.Path('rust/src/protocol/request_context.rs')
text = path.read_text()
text = replace(text, '.map(|value| value.unwrap().as_str().to_owned())', '.map(|value| value.map_or_else(String::new, |value| value.as_str().to_owned()))')
text = replace(text, '                if pattern(RULES["negated"].as_str().unwrap()).is_match(text)', '''                // A quoted example or conditional continuation is not a direct instruction.
                if !pattern(RULES["directiveCue"].as_str().unwrap()).is_match(text) {
                    continue;
                }
                if let Some(found) = capture("lineLimit", text) {
                    let count = RULES["numberWords"][found[1].to_lowercase()]
                        .as_u64()
                        .map_or_else(|| found[1].clone(), |count| count.to_string());
                    constraints.push(Constraint {
                        role: role.clone(), index, text: text.to_owned(), kind: "output",
                        value: format!("{}|{}|{count}|{}", RULES["lineLimitKind"].as_str().unwrap(), found[0].to_lowercase(), if found[2].is_empty() { "" } else { "detail" }),
                        status: "pending",
                    });
                    continue;
                }
                if pattern(RULES["negated"].as_str().unwrap()).is_match(text)''')
text = replace(text, '''        self.active("language")
            .and_then(|item| language(&item.value))''', '''        self.active("language").and_then(|item| {
            if Some(item.value.as_str()) == RULES["sameLanguage"].as_str() {
                Some(crate::language::detect(&self.prompt).slug())
            } else {
                language(&item.value)
            }
        })''')
text = replace(text, '                    language(&item.value).is_some()', '''                    (if Some(item.value.as_str()) == RULES["sameLanguage"].as_str() {
                        target.is_some_and(|code| RULES["languages"][code].is_array())
                    } else { language(&item.value).is_some() })''')
text = replace(text, '                "labels" => item', '''                "output" => {
                    let fields: Vec<_> = item.value.split('|').collect();
                    if fields.len() != 4 || Some(fields[0]) != RULES["lineLimitKind"].as_str() {
                        false
                    } else {
                        let comparison = compare_decimals(&answer.answer.lines().count().to_string(), fields[2]);
                        (fields[3] == "detail" && pattern(RULES["detailRequest"].as_str().unwrap()).is_match(&self.prompt))
                            || if fields[1] == "exactly" { comparison.is_eq() }
                            else if RULES["strictLineModes"].as_array().unwrap().iter().any(|mode| mode.as_str() == Some(fields[1])) { comparison.is_lt() }
                            else { !comparison.is_gt() }
                    }
                }
                "labels" => item''')
text = replace(text, '&& language(&item.value) != RULES["refusalLanguage"].as_str()', '&& target != RULES["refusalLanguage"].as_str()')
path.write_text(text)

print('Drafted JavaScript/TypeScript and native twins: direct instruction boundaries, same-language resolution and measured line limits.')
