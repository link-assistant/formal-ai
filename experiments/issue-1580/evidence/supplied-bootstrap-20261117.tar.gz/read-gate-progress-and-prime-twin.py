from pathlib import Path
import subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
path=Path('/tmp/issue-1580-research/sealed-complete-local-gates.log')
lines=path.read_text().splitlines()
print('GATE COUNTS',sum(line.startswith('PASS ') for line in lines),'passed',sum(line.startswith('SKIP ') for line in lines),'excluded',sum(line.startswith('FAIL ') for line in lines),'failed')
print('\n'.join(lines[-10:]))
print('SUPERVISOR',Path('/tmp/issue-1580-research/picomatch-sealed-gates-supervisor.log').read_text())
for command in [
 ['rg','-n','propertyInterval|property_interval|recordValidation|number_property_prime','js/worker','rust/tests/web/worker-candidate-validation.test.mjs','rust/src/solver_helpers/finalize.rs','rust/src/solver_helpers/mod.rs'],
 ['rg','-n','record_validation|record_answer_test|finalize_simple','rust/src/solver_handlers/mod.rs','rust/src/meta_method_dispatch.rs']
]:
    result=subprocess.run(command,cwd=root,text=True,capture_output=True)
    print('\nSEARCH',command)
    print(result.stdout,result.stderr)
