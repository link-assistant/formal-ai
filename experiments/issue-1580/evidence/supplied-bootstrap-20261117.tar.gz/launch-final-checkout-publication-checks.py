from pathlib import Path
import subprocess,json
p=Path('/tmp/issue-1580-research/checkout-publication-checks.log')
with p.open('wb') as log:
 child=subprocess.Popen(['python3','/tmp/issue-1580-research/final-checkout-publication-checks.py'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
Path('/tmp/issue-1580-research/checkout-publication-checks.pid').write_text(str(child.pid)+'\n')
print(json.dumps({'pid':child.pid,'log':str(p)}))
