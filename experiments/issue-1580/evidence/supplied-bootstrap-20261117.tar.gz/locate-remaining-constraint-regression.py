from pathlib import Path
import subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
for argv in [
    ['rg','-n','prime.*between|between.*prime|prime_range|Prime|primality','rust/src/solver_handlers','rust/src/solver_constraints.rs','rust/src/task_tests'],
    ['rg','--files','rust/tests/web'],
    ['rg','-n','consumes_sub_answers|parent_verdict|child_outcomes','rust/src/solver_synthesis.rs'],
]:
    result=subprocess.run(argv,cwd=root,text=True,capture_output=True)
    print('\nSEARCH',argv)
    lines=result.stdout.splitlines()
    if '--files' in argv: lines=[line for line in lines if any(term in line for term in ['synthesis','constraint','candidate','reasoning'])]
    print('\n'.join(lines[:70]))
    if len(lines)>70: print('MORE MATCHES NOT PRINTED',len(lines)-70)
    print(result.stderr)
path=root/'rust/tests/unit/specification/reasoning_loop.rs'
lines=path.read_text().splitlines()
print('NATIVE PRIME REGRESSION')
for n in range(198,230):print(f'{n+1}: {lines[n]}')
print('GATE PROGRESS')
path=Path('/tmp/issue-1580-research/sealed-complete-local-gates.log')
print('\n'.join(path.read_text().splitlines()[-12:]))
