import {GENERATED_NATIVE_PROGRAMS as before} from './registry-currency/before.mjs';
import {GENERATED_NATIVE_PROGRAMS as after} from '/tmp/gh-issue-solver-1794900398048/scripts/lib/generated-native-programs.mjs';
import {isDeepStrictEqual} from 'node:util';
import {writeFileSync} from 'node:fs';
const changed=[];
for(const old of before){const current=after.find(item=>item.path===old.path);if(!isDeepStrictEqual(old,current)){const keys=[...new Set([...Object.keys(old),...Object.keys(current??{})])].filter(key=>!isDeepStrictEqual(old[key],current?.[key]));changed.push({path:old.path,keys,before:old,after:current});}}
const added=after.filter(item=>!before.some(old=>old.path===item.path));
writeFileSync('/tmp/issue-1580-research/registry-currency/differences.json',JSON.stringify({changed,added},null,2)+'\n');
console.log(JSON.stringify({before:before.length,after:after.length,changed:changed.map(({path,keys,before,after})=>({path,keys,beforeWitnesses:before?.sourceWitnesses,afterWitnesses:after?.sourceWitnesses,beforeSpan:before?.sourceSpan,afterSpan:after?.sourceSpan})),added},null,2));
