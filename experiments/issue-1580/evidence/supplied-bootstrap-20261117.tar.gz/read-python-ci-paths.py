from pathlib import Path
import subprocess
def show(name,start=1,end=150):
    lines=Path(name).read_text().splitlines()
    print(f'{name} ({len(lines)} lines), {start}-{end}')
    for i in range(start-1,min(end,len(lines))): print(f'{i+1}: {lines[i]}')
show('CONTRIBUTING.md',1,32)
show('rust/tests/web/issue-1580-template-observations.test.mjs')
show('rust/tests/web/fast-pull-request-production-profile.test.mjs',150,205)
print(subprocess.run(['rg','-n','python3|Pinned upstream syntax|t.skip','experiments/issue-1580','--glob','*.mjs','--glob','!evidence/**'],capture_output=True,text=True).stdout[:12000])
print(subprocess.run(['rg','--files','scripts','experiments/issue-1580'],capture_output=True,text=True).stdout.splitlines()[:8])
show('scripts/plan-test-shards.mjs',1,150)
