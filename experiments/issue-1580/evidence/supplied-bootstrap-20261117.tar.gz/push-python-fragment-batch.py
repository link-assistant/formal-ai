from pathlib import Path
import json
import subprocess

def run(arguments):
    return subprocess.run(arguments, check=True, capture_output=True, text=True).stdout

repository = 'link-assistant/formal-ai'
branch = 'issue-1580-8d61a32a61e1'
old_remote = 'b79dc1e0f147ed57d8e317c1b93bfa6ffc79078d'
assert run(['git', 'branch', '--show-current']).strip() == branch
assert not run(['git', 'status', '--porcelain']).strip()
run(['git', 'fetch', 'origin', 'main'])
run(['git', 'merge-base', '--is-ancestor', 'origin/main', 'HEAD'])
run(['git', 'merge-base', '--is-ancestor', '9c018344df2e6b09a0f2496897b14a002dad62f4', 'HEAD'])
head = run(['git', 'rev-parse', 'HEAD']).strip()
remote = run(['git', 'ls-remote', '--heads', 'origin', f'refs/heads/{branch}']).split()[0]
assert remote == old_remote
for status in ['in_progress', 'queued']:
    runs = json.loads(run(['gh', 'run', 'list', '--repo', repository, '--branch', branch, '--status', status, '--limit', '100', '--json', 'databaseId,workflowName,headSha']))
    assert not runs, json.dumps(runs)
runs = json.loads(run(['gh', 'run', 'list', '--repo', repository, '--branch', branch, '--commit', old_remote, '--limit', '100', '--json', 'databaseId,workflowName,status,conclusion,createdAt,headSha']))
assert len(runs) == 24
assert all(item['headSha'] == old_remote and item['status'] == 'completed' and item['conclusion'] == 'success' for item in runs)
feedback = {}
for key, endpoint in [
    ('issueComments', 'issues/1580/comments'),
    ('conversationComments', 'issues/1581/comments'),
    ('inlineComments', 'pulls/1581/comments'),
    ('reviews', 'pulls/1581/reviews'),
]:
    pages = json.loads(run(['gh', 'api', f'repos/{repository}/{endpoint}?per_page=100', '--paginate', '--slurp']))
    items = [item for page in pages for item in page]
    feedback[key] = len(items)
    Path(f'/tmp/issue-1580-research/python-fragment-{key}.json').write_text(json.dumps(items, indent=2) + '\n')
assert feedback == {'issueComments': 1, 'conversationComments': 9, 'inlineComments': 0, 'reviews': 0}, feedback
run(['git', 'diff', '--check', f'{old_remote}..HEAD'])
print(json.dumps({'pushingHead': head, 'previousHead': old_remote, 'previousPassingRuns': 24, 'activeOrQueued': 0, 'freshMain': run(['git', 'rev-parse', 'origin/main']).strip(), 'feedbackCounts': feedback}, indent=2), flush=True)
print(run(['git', 'push', 'origin', f'HEAD:refs/heads/{branch}']), flush=True)
assert run(['git', 'ls-remote', '--heads', 'origin', f'refs/heads/{branch}']).split()[0] == head
assert not run(['git', 'status', '--porcelain']).strip()
Path('/tmp/issue-1580-research/python-fragment-published-head.txt').write_text(head + '\n')
print(json.dumps({'publishedHead': head, 'pullRequest': 'https://github.com/link-assistant/formal-ai/pull/1581', 'workingTreeClean': True, 'ready': False, 'acceptanceComplete': False}, indent=2), flush=True)
