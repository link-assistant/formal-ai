from pathlib import Path
import gzip,json,re,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
def command(argv):
    run=subprocess.run(argv,cwd=root,capture_output=True,text=True)
    assert run.returncode==0,(argv,run.stdout,run.stderr)
    return run.stdout.strip()
assert command(['git','branch','--show-current'])=='issue-1580-8d61a32a61e1'
assert command(['git','rev-parse','HEAD'])=='b367d603375dd23223861c92875e079a3a90df13'
assert command(['git','diff','--cached','--name-only'])==''
checks=root/'experiments/issue-1580/evidence/checks/localized-unknown-opener'
for name in ['corrected-checks','publication/naming-correction']:
    value=json.loads((checks/name/'outcome.json').read_text())
    assert value['complete'] and all(row['exitCode']==0 for row in value['records']),value
publication=json.loads((checks/'publication/outcome.json').read_text())
assert publication['complete']
log=gzip.decompress((checks/'publication/gates.log.gz').read_bytes()).decode()
assert re.findall(r'^FAIL (\S+)',log,re.M)==['check-abbreviations']
assert json.loads((checks/'shellcheck/receipt.json').read_text())['complete']
assert json.loads((root/'experiments/issue-1580/evidence/ci/native-b367d603/opener-round-preflight/outcome.json').read_text())['complete']
batches=[
    ('Synchronize improved core limits and reviewed source witness',[
        'data/meta/core-boundary-ledger.lino','docs/status.md',
        'experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8']),
    ('Preserve localized unknown answers without an opener pool',[
        'data/meta/worker-line-budget/formal_ai_worker_seed_responses_and_language.lino',
        'js/worker/formal_ai_worker_seed_responses_and_language.js',
        'rust/src/unknown_opener.rs','rust/src/web_engine_core.rs',
        'rust/tests/web/worker-unknown-language.test.mjs']),
    ('Record localized opener regressions and complete CI failure evidence',[
        'changelog.d/20261117_120000_issue-1580-ci-regressions.md',
        'docs/case-studies/issue-1580/native-evidence-checkpoint.md',
        'docs/case-studies/issue-1580/localized-opener-and-ci-checkpoint.md',
        'docs/case-studies/issue-1580/templates/java-historical-partial-review.json',
        'experiments/issue-1580/work-plan.md','experiments/issue-1580/review-governed-source-refresh.mjs',
        'experiments/issue-1580/unresolved-request-probe.mjs','experiments/issue-1580/evidence']),
]
commits=[]
for message,paths in batches:
    command(['git','add','--',*paths]);command(['git','diff','--cached','--check'])
    print(command(['git','diff','--cached','--stat']),flush=True)
    print(command(['git','commit','-m',message]),flush=True)
    commits.append({'sha':command(['git','rev-parse','HEAD']),'subject':message})
assert command(['git','status','--porcelain'])==''
value={'parent':'b367d603375dd23223861c92875e079a3a90df13','commits':commits,'head':commits[-1]['sha'],'clean':True}
Path('/tmp/issue-1580-research/opener-publication-commits.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value),flush=True)
