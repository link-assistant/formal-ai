import json, pathlib

path = pathlib.Path('data/parity/issue-1587-request-context.json')
rows = json.loads(path.read_text())
new = [
    {'id': 'client-same-language', 'messages': [{'role': 'system', 'content': "Respond in the same language as the user's input. If the user explicitly requests a specific language (e.g., \"please reply in English\"), switch to that language."}, {'role': 'user', 'content': 'What is 3 + 8?'}], 'answer': '3 + 8 = 11', 'constraint': 'language:applied'},
    {'id': 'quoted-language-is-not-a-directive', 'messages': [{'role': 'system', 'content': 'An example is "reply in French". If asked, use that example.'}, {'role': 'user', 'content': 'What is 3 + 8?'}], 'answer': '3 + 8 = 11', 'no_constraint': True},
    {'id': 'conditional-language-is-not-standing', 'messages': [{'role': 'system', 'content': 'If asked to translate, reply in French.'}, {'role': 'user', 'content': 'What is 3 + 8?'}], 'answer': '3 + 8 = 11', 'no_constraint': True},
    {'id': 'client-strict-line-limit', 'messages': [{'role': 'system', 'content': 'You MUST answer concisely with fewer than 4 lines of text (not including tool use or code generation), unless user asks for detail.'}, {'role': 'user', 'content': 'What is 3 + 8?'}], 'answer': '3 + 8 = 11', 'constraint': 'output:applied'},
    {'id': 'unmet-line-limit', 'messages': [{'role': 'system', 'content': 'Reply with at most 0 lines.'}, {'role': 'user', 'content': 'What is 3 + 8?'}], 'contains': 'Cannot satisfy output constraint', 'constraint': 'output:unmet'},
]
assert not any(row['id'] == new[0]['id'] for row in rows)
path.write_text(json.dumps(rows + new, ensure_ascii=False, indent=2) + '\n')
test = pathlib.Path('rust/tests/web/issue-1580-client-output-constraints.test.mjs')
text = test.read_text()
text += '''
test('line limits preserve final newlines, CRLF, and the explicit detail exception', () => {
  const instruction = 'You MUST answer concisely with fewer than 4 lines of text (not including tool use or code generation), unless user asks for detail.';
  const compose = (prompt, text) => composeFinalAnswer([{ role: 'system', content: instruction }, { role: 'user', content: prompt }], text, []);
  for (const text of ['a\\nb\\nc\\n', 'a\\r\\nb\\r\\nc\\r\\n', '']) assert.equal(compose('Show the result.', text).answer, text);
  assert.equal(compose('Please explain in detail.', 'a\\nb\\nc\\nd').answer, 'a\\nb\\nc\\nd');
  assert.match(compose('Show the result.', 'a\\nb\\nc\\nd').answer, /Cannot satisfy output constraint/u);
});
'''
test.write_text(text)
inventory = pathlib.Path('data/benchmarks/fast-pull-request-javascript-tests.json')
data = json.loads(inventory.read_text())
print('INVENTORY ROOT', type(data).__name__, list(data) if isinstance(data, dict) else len(data))
print('Added 5 shared JavaScript/native fixture cases and line-ending/detail boundaries.')
