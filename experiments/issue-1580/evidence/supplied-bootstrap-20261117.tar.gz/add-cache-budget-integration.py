from pathlib import Path
p=Path('rust/tests/web/sccache-outage-fallback.test.mjs');text=p.read_text();needle="  assert.equal(observed.summary,'- Compiler cache writes (fixture): 1 stored, 87 write errors, 98% errors.\\n');\n});\n\ntest('missing opt-in backend"
assert needle in text
text=text.replace(needle,"  assert.equal(observed.summary,'- Compiler cache writes (fixture): 1 stored, 87 write errors, 98% errors.\\n');\n  const manyLines=cacheWriteReport(t,'',{log:'noise\\n'.repeat(20000)+'last backend response\\n',verbose:true});\n  assert.match(manyLines.stderr,/last backend response/u);\n  assert.ok(manyLines.stderr.trim().split('\\n').length<=81,'at most 80 log lines plus the diagnostic heading');\n});\n\ntest('missing opt-in backend")
text+='''
test('actual budget wrapper retains backend evidence without replacing command outcomes', {timeout:10000}, t => {
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'sccache-budget-report-'));
  t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));
  const backendLog=path.join(directory,'server.log');
  fs.writeFileSync(backendLog,'last backend error after command\\n');
  const unavailable=path.join(directory,'sccache');
  fs.writeFileSync(unavailable,'#!/bin/sh\\nexit 2\\n',{mode:0o700});
  for(const status of [0,23]){
    const observed=spawnSync('bash',['scripts/run-with-budget-warning.sh','10','cache fixture','bash','-c',`exit ${status}`],{
      cwd:root,encoding:'utf8',timeout:5000,maxBuffer:131072,
      env:{...process.env,RUSTC_WRAPPER:'sccache',SCCACHE_PATH:unavailable,
        SCCACHE_ERROR_LOG:backendLog,FORMAL_AI_CI_VERBOSE:'true'},
    });
    assert.equal(observed.status,status,observed.stderr);
    assert.match(observed.stderr,/\\[sccache\\] last backend error after command/u);
    assert.match(observed.stdout,/cache fixture took/u);
  }
});
'''
p.write_text(text)
print('Added bounded-line and actual budget-wrapper outcome controls.')
