from pathlib import Path
import gzip,hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research/calendar-clock-publication');report=json.loads((scratch/'outcome.json').read_text());assert report['complete'] and report['pushExecuted'];base=root/'experiments/issue-1580/evidence/checks/reasoning-native-replay/previous-publication';base.mkdir(exist_ok=False);records=[]
for row in report['records']:
 item=dict(row)
 for stream in ['stdout','stderr']:
  raw=(scratch/(row['name']+'.'+stream)).read_bytes();assert hashlib.sha256(raw).hexdigest()==row[stream+'Sha256'];packed=gzip.compress(raw,mtime=0);filename=row['name']+'.'+stream+'.gz';(base/filename).write_bytes(packed);item[stream]={'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())}
 records.append(item)
(base/'records.json').write_text(json.dumps(records,indent=2)+'\n');(base/'outcome.json').write_text(json.dumps({k:v for k,v in report.items() if k!='records'},indent=2)+'\n');print('Archived previous publication',len(records),'records',len(records)*2,'verified payloads')
