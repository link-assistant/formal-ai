from pathlib import Path
import gzip, hashlib, json, os, resource, subprocess, sys, time

root=Path('/tmp/gh-issue-solver-1794900398048')
base=Path('/tmp/issue-1580-research/unverified-status-publication-checks')
destination=root/'experiments/issue-1580/evidence/checks/unverified-child-status/final-source-checks'
if len(sys.argv)==1:
    assert not base.exists()
    base.mkdir()
    with (base/'worker.log').open('wb') as stream:
        worker=subprocess.Popen([sys.executable,__file__,'finish'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (base/'process.json').write_text(json.dumps({'pid':worker.pid})+'\n')
    print(json.dumps({'pid':worker.pid,'sequential':True,'rustBuildsEnabled':False}))
    sys.exit(0)
assert sys.argv==[__file__,'finish']
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
destination.mkdir(exist_ok=False)
environment=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
checks=[('archive-supplied',['python3','/tmp/issue-1580-research/archive-round-bootstrap.py']),('archive-commands',['python3','experiments/issue-1580/archive-evidence.py'])]
for gate in ['check-file-size-js-twin','check-file-size','check-readable-code','check-abbreviations','check_js_rust_translation','check-changelog-fragment-js-twin','check-package-self-containment']:
    checks.append((gate,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]))
checks.append(('git-diff-check',['git','diff','--check']))
rows=[]
for name,command in checks:
    start=time.time()
    path=base/(name+'.log')
    with path.open('wb') as stream:
        outcome=subprocess.run(command,cwd=root,env=environment,stdout=stream,stderr=subprocess.STDOUT)
    raw=path.read_bytes()
    packed=gzip.compress(raw,mtime=0)
    (destination/(name+'.log.gz')).write_bytes(packed)
    row={'name':name,'command':command,'exitCode':outcome.returncode,'durationSeconds':round(time.time()-start,3),'rawLines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()}
    rows.append(row)
    (base/'progress.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
summary={'complete':all(row['exitCode']==0 for row in rows),'checks':rows,'nodeHeapMiB':256,'childrenPeakRssKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'rustBuildsEnabled':False,'nativeExecuted':False,'independentAuthorshipCredit':0}
(destination/'outcome.json').write_text(json.dumps(summary,indent=2)+'\n')
(base/'outcome.json').write_text(json.dumps(summary,indent=2)+'\n')
sys.exit(0 if summary['complete'] else 1)
