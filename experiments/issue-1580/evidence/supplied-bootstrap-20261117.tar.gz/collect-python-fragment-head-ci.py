from pathlib import Path
import datetime,gzip,hashlib,json,subprocess

def run(args):
    return subprocess.run(args,check=True,capture_output=True).stdout

repository='link-assistant/formal-ai'
head='624812120feee0180bf9df8164f87e73326b5cb8'
directory=Path('experiments/issue-1580/evidence/ci/624812120')
directory.mkdir(exist_ok=True)
runs=json.loads(run(['gh','run','list','--repo',repository,'--branch','issue-1580-8d61a32a61e1','--commit',head,'--limit','100','--json','databaseId,workflowName,status,conclusion,createdAt,headSha']))
assert len(runs)==24 and all(row['headSha']==head for row in runs)
(directory/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
summary={'head':head,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runCount':len(runs),'successful':sum(row['conclusion']=='success' and row['status']=='completed' for row in runs),'unfinished':[row for row in runs if row['status']!='completed'],'nonPassing':[row for row in runs if row['status']=='completed' and row['conclusion']!='success']}
for row in runs:
    if row['status']!='completed' or (row['conclusion']=='success' and row['workflowName']!='Layered CI'):
        continue
    identifier=str(row['databaseId'])
    metadata=run(['gh','run','view',identifier,'--repo',repository,'--json','databaseId,workflowName,headSha,createdAt,updatedAt,conclusion,status,url,jobs'])
    (directory/f'{identifier}.json').write_bytes(metadata)
    path=directory/f'{identifier}.log.gz'
    if not path.exists():
        raw=run(['gh','run','view',identifier,'--repo',repository,'--log'])
        path.write_bytes(gzip.compress(raw,mtime=0))
    raw=gzip.decompress(path.read_bytes())
    print(json.dumps({'workflow':row['workflowName'],'run':row['databaseId'],'url':f'https://github.com/{repository}/actions/runs/{identifier}','log':str(path),'rawBytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'conclusion':row['conclusion']}),flush=True)
    needles=['template observations','manual fragment','fragment collision','fragment creator','abbreviation ratchet','not ok','##[error]']
    hits=[(number,line.decode(errors='replace')) for number,line in enumerate(raw.splitlines(),1) if any(word in line.decode(errors='replace').lower() for word in needles)]
    print(json.dumps({'selectedLogLines':hits[:45],'matchingLineCount':len(hits)},indent=2),flush=True)
(directory/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
