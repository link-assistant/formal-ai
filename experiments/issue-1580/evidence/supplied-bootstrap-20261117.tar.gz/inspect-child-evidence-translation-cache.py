from pathlib import Path

source=Path('scripts/translate-js-rust.mjs').read_text().splitlines()
for first,last in [(530,570),(932,1034)]:
    print('\nLINES',first,last)
    for number,line in enumerate(source[first-1:last],first):print(f'{number}: {line}')
for directory in [Path('/tmp'),Path('/tmp/issue-1580-research')]:
    for path in directory.iterdir():
        if path.is_dir() and any(word in path.name for word in ['meta-language','translation']):
            marker=path/'.formal-ai-meta-language-commit'
            print('DIRECTORY',path,'MARKER',marker.read_text().strip() if marker.exists() else 'missing')
for name in ['prepare-governed-source-refresh.py','refresh-reviewed-witness.py','read-translation-refresh-exports.py']:
    path=Path('/tmp/issue-1580-research')/name
    lines=path.read_text().splitlines()
    assert len(lines)<=200
    print('\nFILE',path)
    print(path.read_text())
