from pathlib import Path
import json

directory=Path('docs/case-studies/issue-1580/templates')
for path in sorted(directory.glob('*semantic-review.json')):
    value=json.loads(path.read_text())
    print('REVIEW',path,'KEYS',list(value))
    for name in ['repository','commit','pinnedCommit','summary','coverage','limitations']:
        if name in value: print(name,json.dumps(value[name])[:1400])
    rows=value.get('files',[])
    pending=[]
    for row in rows:
        count=row.get('lines',row.get('lineCount',0))
        read=sum(last-first+1 for first,last in row.get('readRanges',[]))
        if read<count:pending.append({'path':row['path'],'lines':count,'read':read})
    print('FILES',len(rows),'PENDING',len(pending),'FIRST',json.dumps(pending[:12]))
scratch=Path('/tmp/issue-1580-research')
for path in sorted(scratch.glob('*java*')):
    if path.suffix in ['.py','.json'] and any(word in path.name for word in ['review','inventory','read']):
        print('JAVA_TOOL',path.name,path.stat().st_size)
