from pathlib import Path
import datetime,gzip,hashlib,json,re,subprocess,sys,time
label=sys.argv[1];assert label in ['before','after']
base=Path('experiments/issue-1580/evidence/checks/fast-source-archive-checkout');base.mkdir(exist_ok=True)
log=base/f'{label}-profile.log.gz';assert not log.exists()
args=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs']
started=time.monotonic();run=subprocess.run(args,capture_output=True);raw=run.stdout+run.stderr
log.write_bytes(gzip.compress(raw,mtime=0))
counts={name:int(value) for name,value in re.findall(r'^(?:#|ℹ) (tests|pass|fail|skipped) (\d+)$',raw.decode(),re.M)}
value={'label':label,'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':args,'exitCode':run.returncode,'seconds':round(time.monotonic()-started,3),'counts':counts,'rawSha256':hashlib.sha256(raw).hexdigest(),'rawBytes':len(raw),'rawLines':len(raw.splitlines()),'independentAuthorshipCredit':0}
(base/f'{label}-profile.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))
for n,line in enumerate(raw.decode().splitlines(),1):
 if line.startswith('not ok') or line.startswith('# pass') or line.startswith('# fail'):print(f'{n}: {line}')
assert run.returncode==(1 if label=='before' else 0)
