from pathlib import Path
import gzip, hashlib, json, os, subprocess, time

print('PUSH PREFLIGHT SOURCE')
print(Path('/tmp/issue-1580-research/picomatch-push-preflight.py').read_text())
base=Path('experiments/issue-1580/evidence/checks/picomatch-single-branch')
checks=[]
for gate in ['check-abbreviations','check-readable-code','check-file-size']:
    command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]
    start=time.monotonic()
    result=subprocess.run(command,text=True,capture_output=True,env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256'))
    data=(result.stdout+result.stderr).encode()
    name='sealed-notes-'+gate+'.log.gz'
    (base/name).write_bytes(gzip.compress(data,mtime=0))
    checks.append({'gate':gate,'exitCode':result.returncode,'seconds':round(time.monotonic()-start,3),'rawSha256':hashlib.sha256(data).hexdigest(),'log':name})
    print(data.decode())
value={'allPassed':all(item['exitCode']==0 for item in checks),'checks':checks,'autonomousAuthorshipCredit':0}
(base/'sealed-notes-checks.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
assert value['allPassed']
