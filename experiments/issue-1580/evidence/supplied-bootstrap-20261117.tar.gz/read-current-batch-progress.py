from pathlib import Path
import json,subprocess
scratch=Path('/tmp/issue-1580-research')
status=scratch/'final-444575f2-focused-status.json'
print('FOCUSED',status.read_text() if status.exists() else 'pending')
print('GATES SUPERVISOR SOURCE')
print((scratch/'run-merged-client-all-gates.py').read_text())
print('ISSUE BODY CANDIDATES')
print('\n'.join(str(f) for f in Path('experiments/issue-1580/evidence').glob('**/*issue*body*')))
print('NATIVE CANDIDATE DIFF')
print(subprocess.check_output(['git','diff','--','rust/src/structured_log.rs','rust/tests/source/source_tests/structured_log/tests.rs'],text=True))
