from pathlib import Path
import gzip, hashlib, json

root=Path.cwd()
base=root/'experiments/issue-1580/evidence/checks/picomatch-governed-refresh'
note='''# Reviewed manifest witness refresh

The security dependency update at 83882c0ec changes desktop/package.json and
vscode/package.json. Layered CI run 44156399182 fails two existing assertions:
the complete governed inventory comparison (log lines 8204-8206) and repository
fixture source binding (8507-8526). All other 23 workflows pass; the shard has
two assertion failures, not a timeout. The full failed log is retained under
../../ci/83882c0ec/.

The existing explicit refresh command reads the complete current inventory,
with exact previous-witness and reader hashes. The permanent experiment
experiments/issue-1580/governed-manifest-refresh.mjs compares every object key,
order, prototype and scalar, accepting only the exact two old/new manifest
texts or their hashes. It checks 7,016 object pairs and reports all 16 changed
fields: eight source values and eight hashes. All 221 supported and 964
unsupported cases, assertions and native source hashes remain unchanged.

Both existing failing test files pass after the refresh: 34 identity/inventory
tests and two fixture-integrity tests, with no skips. Complete logs, commands
and hashes are retained here. These are JavaScript source-fixture checks;
they do not execute the native specification or complete broader acceptance.
The complete local gate set and next-head hosted checks are pending. All
supplied work receives zero independent Formal AI authorship credit.
'''
(base/'README.md').write_text(note)
paragraph='''
Manifest-witness repair: current head 83882c0ec has 23 successful workflows and two assertions failing in Layered CI 44156399182, because the picomatch desktop/VS Code manifest updates were not reflected in the governed source fixture. The reviewed complete refresh changes exactly 16 fields (eight source strings and eight hashes), preserving all 221 supported/964 unsupported cases and native source hashes. Both existing failing files now pass all 36 tests without skips; evidence and the complete delta are under evidence/checks/picomatch-governed-refresh/. The complete local gate set and next-head hosted verification remain pending. This supplies no native execution or independent authorship credit; broader acceptance remains unfinished.
'''
for name in ['experiments/issue-1580/work-plan.md','docs/case-studies/issue-1580/README.md']:
    p=root/name
    assert 'Manifest-witness repair:' not in p.read_text()
    with p.open('a') as handle: handle.write(paragraph)
review=root/'experiments/issue-1580/evidence/checks/picomatch-governed-refresh/published-parent-review'
review.mkdir(exist_ok=True)
for name in ['pr1581-83882c-files.json','pr1581-83882c-review-summary.json']:
    raw=(Path('/tmp/issue-1580-research')/name).read_bytes()
    (review/(name+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
    print('ARCHIVE',name,len(raw),hashlib.sha256(raw).hexdigest())
print('Prepared witness review notes and complete paginated PR file identity inventory')
