from pathlib import Path
import hashlib,json,subprocess
r=Path.cwd();v=r/'experiments/issue-1580/evidence/checks/spelled-calendar-clock/final-validation';review=json.loads((v/'review.json').read_text())
assert review['allPassed'] and review['focusedCounts']['pass']==192
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==review['sourceHead']
assert not subprocess.check_output(['git','diff','--cached','--name-only'],text=True).strip()
for p,digest in review['sourceHashes'].items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==digest,p
batches=[('Preserve spelled calendar hours through shared numeral spans',[
'data/meta/core-boundary-ledger.lino','data/meta/abbreviation-ratchet.lino','docs/status.md','data/seed/entity-names.lino','data/seed/handler-rules.lino',
'rust/embedded/data/seed/entity-names.lino','rust/embedded/data/seed/handler-rules.lino',
'js/worker/formal_ai_worker_calendar_and_proofs.js','js/worker/formal_ai_worker_calendar_offset.js',
'rust/src/solver_handlers/calendar_create.rs','rust/src/verifiable_task/quantities.rs',
'rust/tests/fixtures/issue-1580-calendar-clock.json','rust/tests/web/calendar-clock-preservation.test.mjs',
 'ts/worker/formal_ai_worker_calendar_and_proofs.ts','ts/worker/formal_ai_worker_calendar_offset.ts',
'changelog.d/issue-1580-spelled-calendar-clock.md']),
('Retain native shell contract inputs in sparse checkout',[
'.github/workflows/native-type-check.yml','rust/tests/web/default-branch-build-policy.test.mjs','changelog.d/issue-1580-native-shell-checkout.md'])]
for message,paths in batches:
 subprocess.run(['git','add','--',*paths],check=True)
 assert subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines()==sorted(paths)
 subprocess.run(['git','diff','--cached','--check'],check=True)
 subprocess.run(['git','-c','gc.auto=0','commit','-m',message],check=True)
 print(json.dumps({'message':message,'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}),flush=True)
print('Committed both complete production repairs. Evidence and documentation remain for the publisher.')
