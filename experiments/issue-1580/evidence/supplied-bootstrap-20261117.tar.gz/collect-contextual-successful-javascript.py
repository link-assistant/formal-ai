from pathlib import Path
import subprocess,json,sys,gzip,hashlib,re,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research/contextual-javascript-confirmation');base=root/'experiments/issue-1580/evidence/ci/contextual-web-193546c7/javascript-confirmation'
if len(sys.argv)==1:
 scratch.mkdir(exist_ok=False);base.mkdir(exist_ok=False)
 with(scratch/'worker.log').open('wb')as f:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'directory':str(scratch)}));sys.exit(0)
rows=[]
try:
 for job in [135733085897,135733085685,135746524610]:
  run=44573034091 if job==135746524610 else 44573033729;argv=['gh','run','view',str(run),'--repo','link-assistant/formal-ai','--job',str(job),'--log'];result=subprocess.run(argv,cwd=root,capture_output=True);row={'run':run,'job':job,'argv':argv,'exitCode':result.returncode}
  for label,raw in [('stdout',result.stdout),('stderr',result.stderr)]:
   name=f'job-{job}.{label}.log.gz';packed=gzip.compress(raw,mtime=0);(base/name).write_bytes(packed);row[label]={'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'lines':len(raw.splitlines())}
  assert result.returncode==0
  lines=result.stdout.decode().splitlines();row['verdictLines']=[{'line':i,'text':line.split('\t')[-1]}for i,line in enumerate(lines,1)if re.search(r'# (?:pass|fail|tests) \d+|generated native registry is current|Cancelled jobs:|All required jobs succeeded|::warning::',line)];rows.append(row);print(json.dumps({k:v for k,v in row.items()if k not in ['stdout','stderr']}),flush=True)
 report={'complete':True,'head':'193546c746ab6a88aed96f58ff5d2c4f7a11ff3a','records':rows,'fullLiteralReviewClaim':False,'fullIssueComplete':False};(base/'review.json').write_text(json.dumps(report,indent=2)+'\n');(scratch/'outcome.json').write_text(json.dumps({'complete':True,'records':len(rows)})+'\n')
except BaseException:traceback.print_exc();(scratch/'outcome.json').write_text(json.dumps({'complete':False})+'\n');raise
