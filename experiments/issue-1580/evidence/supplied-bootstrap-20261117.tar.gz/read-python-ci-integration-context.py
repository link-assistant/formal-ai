from pathlib import Path
import subprocess,json

path=Path('.github/workflows/layered-ci.yml')
print('FILE',path,'LINES 1-405')
for number,line in enumerate(path.read_text().splitlines(),1):
    if number<=405: print(f'{number}: {line}')
print('CI POLICY TEST MATCHES')
print(subprocess.run(['rg','-n','layered-ci.yml|setup-python|Setup Python|matrix.shard','rust/tests/web','scripts','experiments/formal_ai_subagent','-g','*.mjs','-g','*.json'],capture_output=True,text=True,check=True).stdout[:18000])
for name in ['AGENTS.md','CONTRIBUTING.md']:
    data=Path(name).read_text().splitlines()
    print('FILE',name,'LINES',len(data))
    if len(data)<=300: print('\n'.join(f'{n}: {line}' for n,line in enumerate(data,1)))
