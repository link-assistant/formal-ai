from pathlib import Path
import json,subprocess

path=Path('data/benchmarks/fast-pull-request-javascript-tests.json')
lines=path.read_text().splitlines();assert len(lines)<400
print('FILE',path,'LINES',len(lines));print('\n'.join(f'{n}: {line}' for n,line in enumerate(lines,1)))
for command in [
 ['rg','-n','--max-count','8','javascript-audit-inventory|fast-pull-request-javascript-tests','scripts','experiments/formal_ai_subagent','rust/tests/web','.github/workflows'],
 ['rg','-n','python-required|javascript-shard|test-profile|fast-pull|plan-js','\.github/workflows/layered-ci.yml'],
 ['git','status','--short'],
]:
    result=subprocess.run(command,capture_output=True,text=True)
    print('COMMAND',command);print(result.stdout[:7000])
