from pathlib import Path
import hashlib, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
core = root / 'rust/src/web_engine_core.rs'
assert hashlib.sha256(core.read_bytes()).hexdigest() == '195455a8697022bf385816a9ac90d2690cb8aec2e150ec712c414187d572e0fe'
previous = subprocess.check_output(['git', 'show', 'b367d603375dd23223861c92875e079a3a90df13:rust/src/web_engine_core.rs'], cwd=root)
assert b'Pick an opener only when the seed declares' not in previous
assert previous.count(b'pub fn select_unknown_opener') == 1
core.write_bytes(previous)

p = root / 'rust/src/unknown_opener.rs'
text = p.read_text()
old = '''    let opener = select_unknown_opener(prompt, language);
    if opener.is_empty() {
        return seed_text.to_owned();
    }
'''
new = '''    if !has_unknown_opener_pool(language) {
        return seed_text.to_owned();
    }
    let opener = select_unknown_opener(prompt, language);
'''
assert text.count(old) == 1
text = text.replace(old, new)
marker = 'fn strip_leading_opener(text: &str, openers: &[&str]) -> String {'
helper = '''// The shared selector intentionally falls back to another language's pool.
// A localized answer can vary only over its own pool; preserve the full seed
// when that pool has not been authored yet.
fn has_unknown_opener_pool(language: &str) -> bool {
    use std::sync::OnceLock;
    static REGISTRY: OnceLock<crate::seed::parser::LinoNode> = OnceLock::new();
    let registry = REGISTRY.get_or_init(|| {
        crate::seed::parse_lino(include_str!("../embedded/data/seed/unknown-openers.lino"))
    });
    registry.children.iter().any(|root| {
        root.name == "unknown_openers"
            && root.children.iter().any(|pool| {
                pool.name == "pool"
                    && pool.find_child_value("language") == language
                    && pool.children.iter().any(|field| field.name == "opener" && !field.id.is_empty())
            })
    })
}

'''
assert text.count(marker) == 1
text = text.replace(marker, helper + marker)
test_start = text.index('#[cfg(test)]\nmod tests {')
assert text[test_start:].count('#[test]') == 1
text = text[:test_start] + '#[cfg(test)]\n#[path = "../tests/source/unknown_opener_language_tests.rs"]\nmod tests;\n'
p.write_text(text)

test = root / 'rust/tests/source/unknown_opener_language_tests.rs'
assert not test.exists()
test.write_text('''//! Native localized seed preservation, without compiling the browser worker.

#[test]
fn a_language_without_an_opener_pool_keeps_its_complete_localized_seed() {
    let seed = crate::seed::response_for("unknown", "es").expect("Spanish unknown seed");
    assert!(!super::has_unknown_opener_pool("es"));
    assert_eq!(
        super::language_aware_unknown_answer("probe", crate::Language::Spanish),
        seed,
    );
}

#[test]
fn authored_pools_still_select_their_own_first_opener() {
    for language in crate::language::registered_languages() {
        if !super::has_unknown_opener_pool(language.slug()) {
            continue;
        }
        let seed = crate::seed::response_for("unknown", language.slug())
            .expect("a language with an opener pool has a localized unknown seed");
        assert_eq!(
            super::language_aware_unknown_answer("", *language),
            seed,
            "{} must retain its complete seed when selecting the first opener",
            language.slug(),
        );
    }
}
''')
print('Restored recorded WASM input; retained native guard through shared seed parser; registered external native tests.')
for path in [core, p, test]:
    print(path.relative_to(root), hashlib.sha256(path.read_bytes()).hexdigest())
