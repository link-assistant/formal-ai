import gzip,json,subprocess
from pathlib import Path
repo='link-assistant/formal-ai'
root=Path('/tmp/issue-1580-research/current-head-ci');root.mkdir(exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
def gh(*args): return subprocess.check_output(['gh',*args],text=True)
raw=gh('run','list','--repo',repo,'--branch','issue-1580-8d61a32a61e1','--limit','50','--json','databaseId,workflowName,status,conclusion,createdAt,headSha')
runs=json.loads(raw);(root/'runs.json').write_text(raw)
for run in runs:
    if run['headSha']!=head: continue
    print(run['databaseId'],run['workflowName'],run['status'],run['conclusion'])
    if run['status']!='completed' or run['conclusion'] in ['success','skipped']: continue
    run_id=run['databaseId']
    data=json.loads(gh('run','view',str(run_id),'--repo',repo,'--json','jobs'))
    (root/f'{run_id}.json').write_text(json.dumps(data,indent=2)+'\n')
    archive=root/f'{run_id}.log.gz'
    if not archive.exists():
        raw=gh('run','view',str(run_id),'--repo',repo,'--log')
        archive.write_bytes(gzip.compress(raw.encode(),mtime=0))
    lines=gzip.decompress(archive.read_bytes()).decode().splitlines()
    findings=[]
    for i,line in enumerate(lines):
        if '##[error]' in line or 'not ok ' in line or 'FAIL' in line or 'Error:' in line:
            findings.append((i+1,line))
    for number,line in findings[:25]: print(number,line[:800])
