from pathlib import Path
import subprocess, gzip, json, hashlib, re

base=Path('experiments/issue-1580/evidence/ci/main-826289fc');base.mkdir(parents=True,exist_ok=True)
receipts=[]
for workflow,run_id in [('layered',44157124124),('agentic',44157124408)]:
    raw=subprocess.check_output(['gh','run','view',str(run_id),'--repo','link-assistant/formal-ai','--log'])
    scratch=Path('/tmp/issue-1580-research')/f'{workflow}-{run_id}.log';scratch.write_bytes(raw)
    target=base/f'{workflow}-{run_id}.log.gz';target.write_bytes(gzip.compress(raw,mtime=0))
    metadata=json.loads(subprocess.check_output(['gh','run','view',str(run_id),'--repo','link-assistant/formal-ai','--json','status,conclusion,headSha,createdAt,updatedAt,url,jobs']))
    (base/f'{workflow}-{run_id}-metadata.json.gz').write_bytes(gzip.compress(json.dumps(metadata,indent=2).encode(),mtime=0))
    row={'workflow':workflow,'runId':run_id,'conclusion':metadata['conclusion'],'headSha':metadata['headSha'],'rawSha256':hashlib.sha256(raw).hexdigest(),'rawBytes':len(raw),'rawLines':len(raw.splitlines()),'log':target.name}
    receipts.append(row);print('RECEIPT',json.dumps(row))
    lines=raw.decode().splitlines();matches=[]
    patterns=[r'✖ ',r'^.*##\[error\]',r'error: ',r'FAILED',r'AssertionError',r'failure:',r'panicked at',r'failed:']
    for number,line in enumerate(lines,1):
        if any(re.search(pattern,line) for pattern in patterns):matches.append((number,line))
    print('ERROR_MATCHES',len(matches))
    for number,line in matches[:24]:print(f'{number}: {line[:1500]}')
    for job in metadata['jobs']:
        if job['conclusion']!='success' and job['conclusion']!='skipped':
            print('FAILED_JOB',job['name'],job['conclusion'],[step['name'] for step in job['steps'] if step['conclusion']=='failure'])
(base/'finished-failures.json').write_text(json.dumps(receipts,indent=2)+'\n')
