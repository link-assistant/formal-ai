from pathlib import Path
import json,subprocess,sys,time,traceback
scratch=Path('/tmp/issue-1580-research/combined-tree-repairs')
if len(sys.argv)==1:
 scratch.mkdir(exist_ok=False)
 with (scratch/'worker.log').open('wb') as stream:
  process=subprocess.Popen([sys.executable,__file__,'worker'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':process.pid,'scratch':str(scratch)}));sys.exit(0)
try:
 initial=Path('/tmp/gh-issue-solver-1794900398048/experiments/issue-1580/evidence/checks/complete-cache-main-validation/outcome.json')
 print('Waiting for the complete first validation receipt before modifying its tree.',flush=True)
 while not initial.exists():
  assert Path('/proc/1684960').exists(),'The initial validator ended without an outcome receipt'
  time.sleep(5)
 print('INITIAL OUTCOME',initial.read_text(),flush=True)
 for script in ['ground-cache-request-prefix.py','repair-structured-output-native-admission.py']:
  print('RUN',script,flush=True)
  process=subprocess.run([sys.executable,str(Path(__file__).parent/script)],cwd='/tmp/gh-issue-solver-1794900398048')
  assert process.returncode==0,(script,process.returncode)
 (scratch/'outcome.json').write_text(json.dumps({'complete':True,'repairsComplete':True,'fullRevalidationPending':True})+'\n')
 print('Both repairs complete; inspect the diffs, commit the atomic repairs and revalidate the final tree.',flush=True)
except BaseException:
 traceback.print_exc();(scratch/'failure.json').write_text(json.dumps({'traceback':traceback.format_exc()})+'\n');sys.exit(1)
