from pathlib import Path
import subprocess
for args in [['rg','--files','experiments','rust/tests/web','scripts'],['git','status','--short']]:
 p=subprocess.run(args,capture_output=True,text=True,check=True)
 print(p.stdout if args[0]=='git' else '\n'.join(x for x in p.stdout.splitlines() if any(w in x for w in ['audit','javascript-dependencies'])))
for name in ['experiments/issue-1580/template-python-fragment-integrity.test.mjs','experiments/issue-1580/fixtures/python-template/source.json']:
 p=Path(name)
 if name.endswith('source.json'):print(p.read_text())
