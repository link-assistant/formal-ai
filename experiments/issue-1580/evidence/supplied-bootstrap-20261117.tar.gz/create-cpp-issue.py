import json, pathlib, subprocess
root = pathlib.Path.cwd()
source = next(row for row in json.loads((root/'docs/case-studies/issue-1580/templates/sources.json').read_text()) if row['language'] == 'cpp')
body_path = pathlib.Path('/tmp/issue-1580-research/cpp-download-retry.md')
body = body_path.read_text().replace('link-foundation/cpp-template',source['repository']).replace('3769fa70a1bc30ce9516e01f78bcd7edea3b3f80550',source['commit'])
body_path.write_text(body)
result = subprocess.run(['gh','issue','create','--repo',source['repository'],'--title','Retry truncated Doxygen archive downloads after curl error 18','--body-file',str(body_path)],check=True,text=True,capture_output=True)
url = result.stdout.strip()
if not url.startswith('https://github.com/'+source['repository']+'/issues/'):
    raise RuntimeError('Unexpected issue creation response: '+url)
target = root/'experiments/issue-1580/upstream'
target.mkdir(exist_ok=True)
(target/'cpp-doxygen-download-retry.md').write_text(body)
with (target/'filed-issues.txt').open('a') as output:
    output.write(url+'\n')
print(url)
