from pathlib import Path
import json
import shutil

base=Path('/tmp/issue-1580-research/csharp-layout-context')
issues=json.loads((base/'issues.json').read_text())
for r in issues:
 if 'pull_request' not in r:
  print(json.dumps({k:r[k] for k in ['number','title','state']}))
print('RELEVANT EXISTING REPORTS')
for r in issues:
 if 'pull_request' not in r and any(t in (r['title']+' '+(r.get('body') or '')).lower() for t in ['csharp-layout','invalid action','invalid workflow','local action','$/.']):
  print(json.dumps({k:r.get(k) for k in ['number','title','body','html_url']},indent=2))
pulls=json.loads((base/'pulls.json').read_text())
merged=[p for p in pulls if p['merged_at']]
print('RECENT MERGED')
for p in merged[:3]:
 print(json.dumps({k:p[k] for k in ['number','title','merged_at','html_url','body']},indent=2))
print('actionlint',shutil.which('actionlint'))
print('cached actionlint',[str(p) for p in Path('/tmp/issue-1580-research').glob('*actionlint*')])
