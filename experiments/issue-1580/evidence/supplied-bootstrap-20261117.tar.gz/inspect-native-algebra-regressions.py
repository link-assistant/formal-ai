from pathlib import Path
import gzip
import subprocess

path = Path('experiments/issue-1580/evidence/ci/main-015a6831/individual-native-failed-jobs/job-134419506379.log.gz')
lines = gzip.decompress(path.read_bytes()).decode().splitlines()
for number in range(3160, 3286):
    print(str(number) + ': ' + lines[number - 1])
subprocess.run(['rg', '-n', 'decomposed_sub_results_are_composed_for_algebra|renumbered_algebra_substitution_recomputes_closed_value', 'rust/tests'], check=True)
