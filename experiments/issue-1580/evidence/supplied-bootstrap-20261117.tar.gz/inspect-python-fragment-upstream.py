from pathlib import Path
import gzip
import json
import subprocess

repo = 'link-foundation/python-ai-driven-development-pipeline-template'
directory = Path('/tmp/issue-1580-research/python-fragment-collision')
directory.mkdir(exist_ok=True)
arguments = ['gh', 'api', f'repos/{repo}/issues?state=all&per_page=100', '--paginate', '--slurp']
raw = subprocess.run(arguments, check=True, capture_output=True).stdout
(directory / 'upstream-issues.json.gz').write_bytes(gzip.compress(raw, mtime=0))
pages = json.loads(raw)
matches = []
for item in [item for page in pages for item in page]:
    text = (item.get('title', '') + '\n' + (item.get('body') or '')).lower()
    if any(word in text for word in ['collision', 'overwrite', 'create_manual_changeset', 'manual fragment']):
        matches.append({key: item.get(key) for key in ['number', 'title', 'html_url', 'state', 'body', 'pull_request']})
print('Potential matching issues/pull requests:', json.dumps(matches, indent=2))
for name in ['experiments/issue-1580/template-shared-git-observation.test.mjs', 'rust/tests/web/issue-1580-template-observations.test.mjs']:
    lines = Path(name).read_text().splitlines()
    print('\nFILE', name, 'LINES', len(lines))
    assert len(lines) <= 350
    for number, line in enumerate(lines, 1):
        print(f'{number}: {line}')
print('Existing fixture metadata paths:', [str(path) for path in Path('experiments/issue-1580/fixtures').glob('**/source.json')])
