import json,subprocess
branch='issue-1580-8d61a32a61e1';head='1cc2d536ac11e26602cc55a40dffb61716233aa6';previous='e120c05b4d8e35d51e4c1efb95e9b0c46c8d42b5'
def run(*args):return subprocess.run(args,capture_output=True,text=True,check=True).stdout.strip()
assert run('git','branch','--show-current')==branch and run('git','rev-parse','HEAD')==head
assert not run('git','status','--porcelain')
assert run('git','ls-remote','origin','refs/heads/'+branch).split()[0]==previous
for status in ['in_progress','queued']:
 assert not json.loads(run('gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--status',status,'--limit','100','--json','databaseId,workflowName'))
subprocess.run(['git','push','origin','HEAD:refs/heads/'+branch],check=True)
assert run('git','ls-remote','origin','refs/heads/'+branch).split()[0]==head
print('Published',head,'to https://github.com/link-assistant/formal-ai/pull/1581')
