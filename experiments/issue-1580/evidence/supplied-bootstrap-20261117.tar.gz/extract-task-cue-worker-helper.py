from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
path=root/'js/agentic/crate/meta_executor.mjs';text=path.read_text()
start=text.index('// A seeded passage cue');end=text.index('function cleanPart(characters)',start)
helper=text[start:end].replace('function maskQuotedCues(lowered, original, mask) {','export function maskQuotedCues(lowered, original, mask, ruleValues, markerMatches) {')
target=root/'js/agentic/crate/task_decomposition_cues.mjs';assert not target.exists()
target.write_text('''// Issue #1580: quoted passage cues use the shared seed in both runtimes.
// The native twin is rust/src/meta_executor/decomposition.rs.
import { containsCjk, wordsForRole } from './seed_meanings.mjs';
import { isWhitespace } from './rust_str.mjs';

'''+helper)
text=text[:start]+text[end:]
text=text.replace("import { containsCjk, wordsForRole } from './seed_meanings.mjs';","import { containsCjk } from './seed_meanings.mjs';\nimport { maskQuotedCues } from './task_decomposition_cues.mjs';")
text=text.replace('  maskQuotedCues(lowered, original, mask);','  maskQuotedCues(lowered, original, mask, ruleValues, markerMatches);');path.write_text(text)
print('Moved cue masking into a small imported helper; the maintained worker ceiling is unchanged.')
print(target.read_text())
old=Path('/tmp/issue-1580-research/validate-task-cue-boundaries.py').read_text()
old=old.replace("scratch=Path('/tmp/issue-1580-research/task-cue-validation')","scratch=Path('/tmp/issue-1580-research/task-cue-validation-resumed')")
old=old.replace("checks/quoted-passage-cues/after'","checks/quoted-passage-cues/resumed'")
old=old.replace("'--jobs','1','js/agentic/crate/meta_executor.mjs']","'--jobs','1','js/agentic/crate/meta_executor.mjs','js/agentic/crate/task_decomposition_cues.mjs']")
new=Path('/tmp/issue-1580-research/validate-task-cue-boundaries-resumed.py');new.write_text(old)
