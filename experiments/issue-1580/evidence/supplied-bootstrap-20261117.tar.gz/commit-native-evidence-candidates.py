from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
def command(args):
 result=subprocess.run(args,cwd=root,capture_output=True,text=True)
 print(result.stdout+result.stderr)
 assert result.returncode==0,(args,result.returncode)
 return result.stdout.strip()
assert command(['git','branch','--show-current'])=='issue-1580-8d61a32a61e1'
assert command(['git','rev-parse','HEAD'])=='7e89122c9d030b3af5eec2d346141bba3ff3fdab'
assert command(['git','diff','--cached','--name-only'])==''
for path,title in [
 ('rust/src/solver_handlers/verifiable_task.rs','Retain seeded membership evidence alongside retrieved matches'),
 ('rust/tests/unit/issue_1133_hive_mind_three_runs/extended.rs','Observe workspace source in the native connector regression'),
]:
 command(['git','add','--',path])
 assert command(['git','diff','--cached','--name-only'])==path
 command(['git','diff','--cached','--check'])
 command(['git','commit','-m',title])
print('DRAFT CODE COMMITS',command(['git','log','-2','--format=%H %s']))
print('No push or native behavior verification in this operation.')
