from pathlib import Path

path=Path('/tmp/gh-issue-solver-1794900398048/js/worker/formal_ai_worker_seed_responses_and_language.js')
text=path.read_text()
old='''  MEANINGS_LINO = seedRawTexts(
    raw,
    (fileName) => fileName === "meanings.lino" || /^meanings-[a-z0-9-]+\\.lino$/.test(fileName),
  ).join("\\n");'''
new='''  const meaningSeedFiles = new Set((self.FORMAL_AI_CRATE_MEANING_SEEDS || []).map((stem) => stem + ".lino"));
  MEANINGS_LINO = seedRawTexts(
    raw,
    (fileName) => meaningSeedFiles.has(fileName) || fileName === "meanings.lino" || /^meanings-[a-z0-9-]+\\.lino$/.test(fileName),
  ).join("\\n");'''
assert text.count(old)==1
text=text.replace(old,new)
old='''  cachedMeaningLexicon = null;
  cachedMarketPriceReferences = null;'''
new='''  cachedMeaningLexicon = null;
  if (typeof WEB_SEARCH_MARKERS_CACHE !== "undefined") WEB_SEARCH_MARKERS_CACHE = null;
  cachedMarketPriceReferences = null;'''
assert text.count(old)==1
path.write_text(text.replace(old,new))
print('Meaning hydration now includes the canonical registered .lino files and invalidates its derived search markers.')
