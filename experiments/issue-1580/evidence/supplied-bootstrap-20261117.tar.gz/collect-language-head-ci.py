from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,os,subprocess,sys,time,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');publication=Path('/tmp/issue-1580-research/language-main-publication-retry/outcome.json');scratch=Path('/tmp/issue-1580-research/language-head-ci')
if len(sys.argv)==1:
 scratch.mkdir(exist_ok=False)
 with (scratch/'worker.log').open('wb') as stream:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'scratch':str(scratch)}));sys.exit(0)
pub=json.loads(publication.read_text());assert pub['complete'] and pub['pushExecuted'];head=pub['head'];commit_time=datetime.fromisoformat(subprocess.check_output(['git','show','-s','--format=%cI',head],cwd=root,text=True).strip());base=root/'experiments/issue-1580/evidence/ci'/('language-'+head[:8]);base.mkdir(exist_ok=False);records=[];saved=set()
def run(name,args,parse=False,check=True):
 p=subprocess.run(args,cwd=root,capture_output=True);rows={}
 for label,raw in [('stdout',p.stdout),('stderr',p.stderr)]:
  namepart=name+'.'+label+'.gz';(base/namepart).write_bytes(gzip.compress(raw,mtime=0));rows[label]={'file':namepart,'rawSha256':hashlib.sha256(raw).hexdigest(),'lines':len(raw.splitlines()),'bytes':len(raw)}
 row={'name':name,'argv':args,'exitCode':p.returncode,**rows};records.append(row);(base/'records.json').write_text(json.dumps(records,indent=2)+'\n')
 if check:assert p.returncode==0,(name,p.stderr.decode()[-2000:])
 return json.loads(p.stdout) if parse else p.stdout
complete=False
try:
 for tick in range(120):
  runs=run(f'observation-{tick:03}',['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','100','--json','databaseId,workflowName,status,conclusion,headSha,createdAt,updatedAt,url'],True);current=[x for x in runs if x['headSha']==head]
  assert all(datetime.fromisoformat(x['createdAt'].replace('Z','+00:00'))>=commit_time for x in current)
  failed=[x for x in current if x['status']=='completed' and x['conclusion'] not in ['success','skipped']]
  for row in failed:
   if row['databaseId'] not in saved:run('failed-run-'+str(row['databaseId']),['gh','run','view',str(row['databaseId']),'--repo','link-assistant/formal-ai','--log']);saved.add(row['databaseId'])
  status={'head':head,'observedAt':datetime.now(timezone.utc).isoformat(),'workflowCount':len(current),'completed':sum(x['status']=='completed' for x in current),'success':sum(x['conclusion']=='success' for x in current),'failed':[{'id':x['databaseId'],'name':x['workflowName'],'conclusion':x['conclusion'],'url':x['url']} for x in failed],'runs':current,'fullIssueComplete':False}
  (base/'latest.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps({k:x for k,x in status.items() if k!='runs'}),flush=True)
  if len(current)>=23 and all(x['status']=='completed' for x in current):complete=True;break
  time.sleep(30)
 if complete:
  for row in current:
   if row['workflowName'] in ['CI/CD Pipeline','Layered CI']:
    jobs=run('jobs-'+str(row['databaseId']),['gh','run','view',str(row['databaseId']),'--repo','link-assistant/formal-ai','--json','jobs'],True)['jobs']
    for job in jobs:
     if 'native' in job['name'].lower() or 'javascript' in job['name'].lower():run('job-'+str(job['databaseId']),['gh','run','view',str(row['databaseId']),'--repo','link-assistant/formal-ai','--job',str(job['databaseId']),'--log'])
  run('pull-request-checks',['gh','pr','checks','1581','--repo','link-assistant/formal-ai','--json','name,state,bucket,workflow,link'],True,False)
 report={'complete':complete,'head':head,'workflowCount':len(current),'success':sum(x['conclusion']=='success' for x in current),'failed':status['failed'],'fullIssueComplete':False,'independentAuthorshipCredit':0};(base/'outcome.json').write_text(json.dumps(report,indent=2)+'\n');(scratch/'outcome.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
except BaseException:traceback.print_exc();(scratch/'failure.json').write_text(json.dumps({'head':head,'complete':False,'traceback':traceback.format_exc()})+'\n');sys.exit(1)
