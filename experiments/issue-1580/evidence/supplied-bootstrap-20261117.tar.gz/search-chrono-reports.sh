set -eu
gh api -X GET search/issues -f q='repo:link-foundation/command-stream chrono' -f per_page=100 --paginate --slurp > /tmp/issue-1580-research/command-stream-chrono-issues.json
gh api -X GET search/issues -f q='repo:link-assistant/calculator chrono' -f per_page=100 --paginate --slurp > /tmp/issue-1580-research/calculator-chrono-issues.json
python3 -c 'import json; from pathlib import Path; files=["command-stream-chrono-issues.json","calculator-chrono-issues.json"]; [(print(name),[print(x["number"],x["state"],x["title"],x["html_url"]) for page in json.loads((Path("/tmp/issue-1580-research")/name).read_text()) for x in page["items"]]) for name in files]'
