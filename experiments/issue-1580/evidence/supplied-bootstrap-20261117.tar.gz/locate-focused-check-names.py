import pathlib
import subprocess

files=subprocess.check_output(['rg','--files','--no-ignore','rust/tests/web'],text=True).splitlines()
print('\n'.join(name for name in files if any(token in name for token in ['1582','client-constraint','client-read','fixture-integrity','generated-native'])))
result=subprocess.run(['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--list'],text=True,capture_output=True,check=True)
path=pathlib.Path('/tmp/issue-1580-research/current-local-gate-list.log')
path.write_text(result.stdout)
print('\n'.join(line for line in result.stdout.splitlines() if any(token in line for token in ['abbrev','file-size','fixture','data','native','seed','translation'])))
