import gzip
import json
import subprocess

probe = json.loads(gzip.decompress(open('experiments/issue-1580/evidence/checks/passage-routing-probe/before.json.gz','rb').read()))
print(json.dumps(probe['answer'], ensure_ascii=False, indent=2))
subprocess.run(['rg', '-n', 'LIVE_FETCH|OFFLINE|liveFetch|live_fetch|network.*enabled|network.*default|fetchLive', 'js/agentic', 'js/server', 'js/worker/formal_ai_worker_web_requests.js', 'experiments/js_dogfood/shell-capture.mjs'], check=False)
