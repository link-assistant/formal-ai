import { execFileSync } from 'node:child_process';
import { deserialize } from 'node:v8';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { gzipSync } from 'node:zlib';
import assert from 'node:assert/strict';
const file='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8';
const after=deserialize(readFileSync(file));
const base='experiments/issue-1580/evidence/checks/main-merge-015a6831';
const digest=x=>createHash('sha256').update(typeof x==='string'?x:JSON.stringify(x)??'undefined').digest('hex');
for(const parent of [2,3]) {
  const before=deserialize(execFileSync('git',['show',`:${parent}:${file}`],{maxBuffer:16*1024*1024}));
  const differences=[];let pairs=0;const seen=new WeakMap();
  function walk(a,b,path='',context={}) {
    if(Object.is(a,b))return;
    if(a===null||b===null||typeof a!=='object'||typeof b!=='object') {
      differences.push({path,before:a,after:b,context});return;
    }
    if(seen.get(a)?.has(b))return;
    if(!seen.has(a))seen.set(a,new WeakSet());seen.get(a).add(b);
    pairs++;assert.ok(pairs<200000);assert.equal(Object.getPrototypeOf(a),Object.getPrototypeOf(b),path);
    const nextContext=a.file||a.path?{file:a.file??a.path,sha256:a.sha256}:context;
    for(const key of new Set([...Object.keys(a),...Object.keys(b)]))walk(a[key],b[key],path+'/'+key,nextContext);
  }
  walk(before,after);
  const report={parent,pairs,beforeCaseCount:before.inventory.cases.length,afterCaseCount:after.inventory.cases.length,beforeUnsupportedCount:before.inventory.unsupported.length,afterUnsupportedCount:after.inventory.unsupported.length,nativeManifestUnchanged:JSON.stringify(before.sourceManifest)===JSON.stringify(after.sourceManifest),differences};
  const raw=Buffer.from(JSON.stringify(report,null,2)+'\n');
  writeFileSync(`${base}/governed-parent-${parent}-complete-delta.json.gz`,gzipSync(raw,{mtime:0}));
  console.log(JSON.stringify({...report,differences:differences.length}));
  for(const d of differences)console.log(JSON.stringify({path:d.path,context:d.context,beforeType:typeof d.before,afterType:typeof d.after,beforeBytes:String(d.before).length,afterBytes:String(d.after).length,beforeSha256:digest(d.before)??null,afterSha256:digest(d.after)??null,beforePrefix:String(d.before).slice(0,130),afterPrefix:String(d.after).slice(0,130)}));
}
