from pathlib import Path
import collections
import hashlib
import json

root=Path("/tmp/issue-1580-research/templates/python-complete")
path=Path("docs/case-studies/issue-1580/templates/python-partial-semantic-review.json")
review=json.loads(path.read_text())
assert review["activeReadLines"]==11959
inventory=json.loads(Path("/tmp/issue-1580-research/python-active-source-inventory.json").read_text())
active={row["path"]:row for row in inventory["active"]}
deferred={".github/actions/artifact/dist/835.index.mjs",".github/actions/artifact/dist/index.mjs",".github/actions/artifact/package-lock.json","uv.lock"}
selected=[(row["path"],n) for row in inventory["active"] if row["path"] not in deferred for n in range(1,row["lines"]+1)]
ranges=collections.defaultdict(set)
for row in review["files"]:
    for first,last in row["readRanges"]:ranges[row["path"]].update(range(first,last+1))
for name,n in selected[:12400]:ranges[name].add(n)
decisions={
 "scripts/recheck_broken_links.py":"Read all 383 lines: bounded shared/per-request retries, exact GitHub URL-to-Contents translation, no-redirect authorization fallback, finite backoff and final-versus-retryable failures. Recovered outputs are cleared before reporting; only a fully recovered set emits true. No network request, token use or runtime probe is claimed.",
 "scripts/run-with-budget-warning.sh":"Read all 273 lines: isolated output/status files and process group, atomic completion, finite TERM/KILL grace, zombie exclusion and explicit budget exit 124. No process stress, sudo, child command or runtime execution is claimed.",
 "scripts/simulate-fresh-merge.sh":"Read all 77 lines: required base ref, finite fetch retries, verified ref comparison, fatal fetch/merge conflicts and explicit up-to-date success. No remote fetch, checkout or merge in the template was performed.",
 "scripts/smoke_test_published_package.py":"Read all 397 lines: structured distribution/import/console metadata, disposable virtualenv, finite install retries, fatal installation/import/version/console failures, bounded displayed previews and cleanup. The subprocess output is captured before previewing; this source reading is not an executed package installation, smoke check or proof of bounded capture memory.",
 "scripts/validate_changeset.py":"Read only lines 1-104: visible category/description validation, checked Git command execution and verified base/head commit resolution. The remaining comparison, changed-path classification and CLI logic are unread; no new runtime or defect claim is made.",
}
for row in review["files"]:
    assert hashlib.sha256((root/row["path"]).read_bytes()).hexdigest()==row["sha256"]
    if row["path"] not in active:continue
    numbers=sorted(ranges[row["path"]]);merged=[]
    for n in numbers:
        if merged and merged[-1][1]+1==n:merged[-1][1]=n
        else:merged.append([n,n])
    row["readRanges"]=merged
    row["reviewStatus"]="active-source-fully-read" if len(numbers)==row["lines"] else "active-source-partially-read" if numbers else "active-source-unread"
    if row["path"] in decisions:row["decision"]=decisions[row["path"]]
counts=collections.Counter(row["reviewStatus"] for row in review["files"])
review["counts"]={key:counts[key] for key in review["counts"]}
review["activeReadLines"]=sum(len(ranges[name]) for name in active)
assert review["activeReadLines"]==13055
review["readMethod"]=review["readMethod"].replace("pages 1-28","pages 1-31")
header={k:v for k,v in review.items() if k!="files"}
path.write_text(json.dumps(header,indent=2)[:-2]+',\n  "files": [\n'+',\n'.join("    "+json.dumps(row,ensure_ascii=False,separators=(",",":")) for row in review["files"])+'\n  ]\n}\n')
old="The Python review now fully reads 151 active files plus one partial file (11,959/44,284 active lines), through corrected pages 1-28 and separately read release/helper tests. The 51 unread active files"
new=f'The Python review now fully reads {counts["active-source-fully-read"]} active files plus one partial file (13,055/44,284 active lines), through corrected pages 1-31 and separately read release/helper tests. The {counts["active-source-unread"]} unread active files'
for name in ["docs/case-studies/issue-1580/README.md","docs/case-studies/issue-1580/templates/README.md","experiments/issue-1580/work-plan.md"]:
    p=Path(name);text=p.read_text();assert text.count(old)==1;p.write_text(text.replace(old,new))
print(json.dumps({"counts":review["counts"],"activeReadLines":review["activeReadLines"],"nextPage":32,"completeReviewClaimed":False}))
