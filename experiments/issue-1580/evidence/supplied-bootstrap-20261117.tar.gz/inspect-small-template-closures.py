from pathlib import Path
import gzip
import json
base = Path('/tmp/issue-1580-research/templates')
for language in ['go','java']:
    graph = json.loads(gzip.decompress(Path(f'docs/case-studies/issue-1580/templates/{language}-ci-reference-graph.json.gz').read_bytes()))
    print('\nLANGUAGE',language,'PIN',graph['commit'])
    candidates = [json.loads(line) for line in Path(f'docs/case-studies/issue-1580/templates/{language}-ci-files.jsonl').read_text().splitlines()]
    for path in sorted(set(graph['files']) | {row['path'] for row in candidates}):
        raw = (base / (language+'-complete') / path).read_bytes()
        print(path, 'bytes',len(raw),'lines',raw.count(b'\n'))
    print('UNRESOLVED',json.dumps(graph['unresolved'],indent=2))
