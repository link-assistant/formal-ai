from pathlib import Path
for path,start,end in [('rust/tests/web/default-branch-build-policy.test.mjs',153,185),('rust/tests/web/default-branch-build-policy.test.mjs',830,865),('rust/src/agentic_coding/driver.rs',45,90),('scripts/check-minimal-core-boundary.mjs',1,135)]:
 p=Path(path);print('FILE',path);print('\n'.join(f'{n}: {l}'for n,l in enumerate(p.read_text().splitlines(),1)if start<=n<=end))
