import subprocess

for args in [
    ['rg', '-n', 'metaSubTask|speculative|unknown_intent_research', 'rust/tests/web', 'rust/src/meta_executor', 'docs/case-studies/issue-1580', 'experiments/issue-1580', '--glob', '!evidence/**'],
    ['git', 'log', '-5', '--format=%h %s', '--', 'js/worker/formal_ai_worker_solve.js'],
]:
    result = subprocess.run(args, text=True, capture_output=True)
    lines = (result.stdout + result.stderr).splitlines()
    print('COMMAND', args, 'lines', len(lines))
    for number, line in enumerate(lines[:90],1):
        print(f'{number}: {line[:500]}')
