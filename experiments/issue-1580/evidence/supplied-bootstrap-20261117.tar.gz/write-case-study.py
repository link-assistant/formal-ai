import gzip,hashlib,json,re,shutil,subprocess
from pathlib import Path

root=Path('docs/case-studies/issue-1580')
root.mkdir(parents=True,exist_ok=True)
evidence=Path('experiments/issue-1580/evidence')
checks=evidence/'checks'
checks.mkdir(exist_ok=True)
sources=json.loads((root/'templates/sources.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
base=subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()
index=[]
for name in ['all-local-gates-third.log','cache-write-regression.log','prime-validation-recheck.log','language-coverage-recheck.log','template-retry-regression.log','hive-mind-draft-workflow.test.log','draft-request-replay.test.log','hive-draft-attempt-identity.test.log','issue-1028-all-mode-sharding.test.log']:
    source=Path('/tmp/issue-1580-research')/name
    if not source.exists(): continue
    raw=source.read_bytes()
    target=checks/(name+'.gz')
    target.write_bytes(gzip.compress(raw,mtime=0))
    index.append({'file':target.name,'source':head,'sha256':hashlib.sha256(raw).hexdigest(),'lines':len(raw.splitlines())})
(checks/'index.jsonl').write_text(''.join(json.dumps(row)+'\n' for row in index))
gate_lines=Path('/tmp/issue-1580-research/all-local-gates-third.log').read_text().splitlines()
counts={status:sum(line.startswith(status+' ') for line in gate_lines) for status in ['PASS','SKIP','FAIL']}
assert '138/138 passed or skipped; failed: none' in gate_lines,counts

readme='''# Issue 1580: CI failures, warnings and result integrity

Work in progress in [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581), addressing [issue #1580](https://github.com/link-assistant/formal-ai/issues/1580). This record distinguishes source fixes, executed checks and unresolved acceptance criteria. It is not a completion claim.

## Reproduction and evidence

The issue's workflow table, every issue/PR conversation comment, inline review comments and reviews were read. The interrupted session was recovered from its authenticated Gists; its five commits were preserved, and main was merged forward. The audited main source is `BASE`; the source checkpoint for this report is `HEAD`.

`experiments/issue-1580/evidence/ci/all-cited-and-latest.json` indexes 71 cited/latest workflow runs with SHA, creation time, conclusion, log line count and SHA-256. The corresponding `.log.gz` files preserve the complete available logs. Annotation JSONL files contain original log line numbers. `summary.json` adds the failed-job inventory. The graph-update run 31914675335 returned HTTP 410 for its expired log; its `LOG_UNAVAILABLE` record is missing evidence, despite the historical success conclusion.

Important production failures, with original log lines:

| Run | Observation | Current disposition |
| --- | --- | --- |
| [43815999666](https://github.com/link-assistant/formal-ai/actions/runs/43815999666) | 31 failing native tests; full shards 3/5/8 exhausted the unchanged 1,080-second budget; shard 5 termination at line 60051 | Source fixes cover workflow parsing/retry, fixture receipts, composition/constraints and debug-session expectations. Native execution and remaining benchmark/timing defects are outstanding. |
| [43805800653](https://github.com/link-assistant/formal-ai/actions/runs/43805800653) | Browser worker budget and JavaScript regressions; shard 8 consumed 317 of 360 seconds at line 26315 | Recovered worker/runner fixes plus production composition and candidate-validation regressions; remaining shard headroom needs measurement. |
| [43899940611](https://github.com/link-assistant/formal-ai/actions/runs/43899940611) | Draft exited 5 after 8m32s: serving identity unverified, null Hive attempt identity, no useful source changes | Live identity contract remains blocked on [Hive Mind #3909](https://github.com/link-assistant/hive-mind/issues/3909). No identity, delivery or benchmark credit is fabricated. |
| [43878821415](https://github.com/link-assistant/formal-ai/actions/runs/43878821415) | File-size warning inventory, lines 3783–4023 | Solver reduced below its warning band. Other warning-band files remain open; limits were not globally raised. |
| [43872809507](https://github.com/link-assistant/formal-ai/actions/runs/43872809507) | Missing required main-branch contexts, line 784 | PR contexts now report on documentation changes. Repository rule configuration and machine-writer compatibility remain open. |
| [43870207134](https://github.com/link-assistant/formal-ai/actions/runs/43870207134) | HumanEval 12/20, MBPP 11/20 and GSM8K 1/2 below existing floors | Real capability defects reproduced with held-out native probes; floors unchanged. Concrete-output composition fix removes a false success but does not implement the missing algorithms. |
| [43815999458](https://github.com/link-assistant/formal-ai/actions/runs/43815999458) | Compiler cache: 88 attempted writes, 87 errors, one stored, line 1113 | Warning no longer invents a cause or asserts certain recompilation; pretty-printed counters are recognized. Backend error cause still needs retained diagnostics. |
| [41768761745](https://github.com/link-assistant/formal-ai/actions/runs/41768761745) | All 12 work-item qualification containers failed to pull | Public log lacks the underlying Docker stderr; inaccessible evidence prevents a verified root-cause claim. Qualification is not passed. |

Successful scope-gated release consumers and the issue-1028 ladder are not evidence that their heavy paths executed. In particular, the successful ladder runs had `FULL_LADDER=false`. Old failures already repaired by newer main commits are kept as historical observations, not attributed to this branch.

## Implemented changes and focused verification

| Requirement/failure | Implementation | Verification |
| --- | --- | --- |
| Unknown quoted concept and described-file safety | Preserve path authority, terminal punctuation and source order; do not fetch an unsupported quoted concept or write an inferred file | `rust/tests/web/pull-request-1188-fix-gaps.test.mjs`: 31 passing tests, including G102; source punctuation has held-out cross-language cases |
| Prime constraints and concrete output | Preserve a validated candidate's intent, reuse existing prime validation before Spanish conjunction parsing, prohibit joining prose as code/constraint success | `worker-candidate-validation.test.mjs`: four tests across five languages; `issue-1580-production-composition.test.mjs`: three positive/negative controls |
| Parent result validity | Validate child answers only when the selected composition actually consumes them | Native synthesis fixtures added; JavaScript production controls pass; native tests remain unexecuted |
| Real work-item receipts | Native fixtures obtain source-probe/write receipts from the actual workspace implementation; compiler/network effects remain explicit mocks | `connector-work-item-receipts.test.mjs`: 20 tests; `recipe-handoff-receipts.test.mjs`: two tests; native fixture execution remains outstanding |
| Required context reporting | Documentation-only PRs report the same native context without compiling; missing/failed change detection conservatively runs the compiler | `default-branch-build-policy.test.mjs`: 21 tests; `stale-pull-request-report.test.mjs`: six tests; canonical staged-release projection verified |
| Download/YAML/runner regressions | Recovered bounded retries, flow-YAML timeout parsing and pinned browser runner fixes | Local JavaScript gates pass; full native regression execution remains outstanding |
| Draft resource/result accounting | Recovered occupancy handling, image pre-pull outside the solving allowance, default-off debug and bounded duration-collector retries | Dedicated recovered workflow tests are retained with their actual results under `evidence/checks`; live drafting still fails its identity acceptance criterion |
| Cache warning accuracy | Parse compact and pretty JSON; report measured counters and causal uncertainty | `sccache-outage-fallback.test.mjs`: eight passing tests, including three subprocess tests of the actual checker |
| Shared template transport defect | Real curl server reproduces truncated HTTP 200 transfer without retry; `--retry-all-errors` retries and succeeds | `template-download-retry.test.mjs`: one passing bounded regression; reported as [C++ template #35](https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/issues/35) |

At the checkpoint, the full local JavaScript gate run reported **PASS_COUNT passed, SKIP_COUNT skipped, zero failed** (138 total). Skips explicitly include Rust builds/tests and checks requiring hosted context or artifacts. Full transcripts and hashes are under `experiments/issue-1580/evidence/checks/`. Required Rust formatting and maintained source/projection currency checks passed; Rust compilation was intentionally left to adequately provisioned CI in accordance with repository policy. This container's 2.92 GiB limit is not an adequate reason to mislabel skipped native checks as passes.

The six-line increase in the JavaScript quantity worker is recorded in its individual module allowance with a concrete rationale: invoke the already-existing prime validator before arithmetic interpretation, matching the Rust path. It adds no prime algorithm and does not relax the global worker target. The solver module was split along its executor boundary rather than changing its size limit.

## Full template comparison

The [template source manifest](templates/sources.json) pins all eight complete source trees. Every one of their 3,007 blobs was downloaded and verified against its Git blob identity; the 48 workflows have parsed run bodies in the per-language workflow JSONL. Each full-tree TSV records every file's role, byte count, Git blob and same-name local comparison. CI candidates outside `.github`, including scripts, test/configuration files and package/build metadata, are inventoried separately.

This is a complete file inventory, not a claim that same-name matching establishes semantic equivalence. The remaining transitive CI reference review and policy decisions are tracked in [the template review](templates/README.md). Application source and historical evidence are accounted for instead of silently omitted.

Upstream reports are preserved under `experiments/issue-1580/upstream/`: [Hive Mind #4071](https://github.com/link-assistant/hive-mind/issues/4071), [Hive Mind #4072](https://github.com/link-assistant/hive-mind/issues/4072), and [C++ template #35](https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/issues/35). Reporting them does not satisfy unimplemented local acceptance criteria.

## Provenance and remaining acceptance criteria

Development commands execute through the JavaScript Formal AI driver. The externally supplied orchestration, literal commands, patches and generators receive **zero autonomous-authorship credit**. `evidence/commands/index.jsonl` hashes full compressed request/response/tool transcripts and source identities; the supplied-patch archive preserves the one-off inputs. Recovered commits retain their historical attribution. The frozen list has 20 substantive reasoning units; independently accepted Formal AI reasoning is **0/20**, below the reporting target. Successful shell execution is not counted as independent reasoning.

Unfinished criteria remain in this PR: final-head hosted CI; native behavior and newly added native fixtures; external benchmark floors and underlying search/arithmetic capability; native/JavaScript shard timing; all remaining warning sources, including extension packaging and cache backend errors; work-item qualification; compatible required-status rules; full semantic template/CI-closure review and all applicable best-practice changes; and the live Hive identity/delivery contract. This PR remains draft and unmerged until these criteria are verified. No benchmark floor, file-size target, identity requirement or default-branch-only build policy is weakened to obtain a green result.
'''
readme=readme.replace('`BASE`','`'+base+'`').replace('`HEAD`','`'+head+'`').replace('PASS_COUNT',str(counts['PASS'])).replace('SKIP_COUNT',str(counts['SKIP']))
(root/'README.md').write_text(readme)
rows=['# Complete template inventory and CI review','',
      'Source trees were pinned and fully read/hash-verified before comparison. Same-name matches are review aids; they do not establish behavioral equivalence. All file roles, including application source, documentation and historical evidence, remain visible in the TSV inventories.','',
      '| Language | Source commit | Blobs | Workflows | CI candidates |','| --- | --- | ---: | ---: | ---: |']
for s in sources: rows.append(f"| {s['language']} | [{s['commit'][:12]}](https://github.com/{s['repository']}/tree/{s['commit']}) | {s['blobCount']} | {s['workflowCount']} | {s['ciCandidateCount']} |")
rows+=['','## Policy comparison and current decisions','',
'The current Hive Mind `docs/CI-CD-BEST-PRACTICES.md` was read in full. Its recommendations are evaluated against this repository\'s explicit default-branch build policy; adopting a template does not authorize PR application builds, Docker execution, deployments or weaker verdicts.','',
'| Topic | Formal AI application / review status |','| --- | --- |',
'| Pinned runners and native architecture | Keep pinned `ubuntu-24.04`; recovered browser runner follows the pinned policy. Native ARM release paths remain; do not introduce QEMU. |',
'| Change detection and required checks | Documentation-only PRs now emit required contexts without compiling. Unknown/failed detection triggers the check. Never filter production seed data as generic non-production `data/`. |',
'| Size, lint and formatting | Full local JS twins pass; existing warning inventory remains open. Keep global thresholds. |',
'| Changelog and publication identity | Patch fragment is the existing release trigger; retain trusted publication/OIDC and pre-publication freshness checks. |',
'| Merge checks and machine writers | Missing required main contexts are a real failure. Configure only with a verified bypass/PR design for automated ledger writers; compatibility is not yet established. |',
'| Serialized default-branch writers | Preserve non-cancelling write concurrency, immutable source identity and explicit GH006/GH013 failures; do not retry a protected-branch refusal as a network outage. |',
'| External secrets and publication preflight | Preserve verified/failed/unknown states. PRs may report unavailable external publication without claiming it succeeded; main must fail with the concrete action required. Token presence alone is not verification. |',
'| Workflow lint tools | Existing actionlint, ShellCheck, runner labels and security checks remain. Local ShellCheck used the verified v0.11.0 binary; no Rust build was performed. |',
'| Scheduled dependency checks | Latest dependencies run still exposes real source-size warnings. A successful install is not full runtime validation. |',
'| Download retries | Local OSV/source download fixes retain finite bounds. The C++ Doxygen archive command lacks all-error retry coverage; bounded real-curl regression and upstream #35 document it. |',
'| Retry classification and cleanup | Duration collection uses bounded retry and propagates unread/incomplete evidence; invalid credentials, refspecs and immutable 409 conflicts must remain terminal. |',
'| Input defaults, skip notices and verdict guards | Recovered draft and current context-reporting controls preserve explicit skip/failure states. Successful scope gates are not capability evidence. |',
'| Real GitHub end-to-end qualification | Keep opt-in live effects and default-off verbose tracing. Docker remains prohibited on PRs; the failing live qualification requires real pull diagnostics. |',
'| Packaging warnings | Retain extension runtime files; the Playwright external package cannot be removed solely to silence VSIX file-count warnings. Resolution remains open. |','',
'## Review boundaries','',
'`*-files.tsv` covers every blob. `*-ci-files.jsonl` conservatively selects workflows, composite actions, scripts/tests and build/policy metadata. `*-workflows.jsonl` preserves parsed job/step run bodies. These generated records do not substitute for resolving shell/package-script/configuration references and reviewing their behavior. That semantic/transitive review remains unfinished and must be completed in this PR.','',
'The latest related C++ merged change, PR #34, was reviewed before filing #35; it refreshes dependencies and release configuration but does not repair truncated-transfer retry. The Go pipeline-status helper was read; its failure/cancelled classification is not reported as a bug without evidence. Java already retries the OSV download with `--retry-all-errors`; it is not included in the C++ finding.','',
'Reproduction tooling: `experiments/issue-1580/templates.mjs` selects source identities, `full-template-trees.py` fetches complete archives and verifies every Git blob, and `compare-template-trees.mjs` generates these inventories. Run against the pinned manifest to retain historical reproducibility; selecting current heads intentionally creates a new comparison checkpoint.','']
(root/'templates/README.md').write_text('\n'.join(rows))
plan=Path('experiments/issue-1580/work-plan.md')
text=plan.read_text().replace('- [ ] Preserve and inspect nine cited failing workflow logs, recent main/branch runs, timestamps and SHAs; audit successful/skipped workflows for false results and warnings.','- [x] Preserve/read all cited and latest logs: 71 run records with hashes and original line numbers; expired graph log explicitly unavailable. Successful scope gates are not heavy-path verification.')
text+='\n## Current verification checkpoint\n\n'+f'At {head}, local gates: {counts["PASS"]} passed, {counts["SKIP"]} explicit skips, zero failures. Focused JS tests and native source formatting passed. All 3,007 template blobs and 48 workflows are inventoried; semantic CI closure review remains open. See docs/case-studies/issue-1580/README.md for each unresolved criterion. No native execution or final-head hosted CI is claimed.\n'
plan.write_text(text)
Path('/tmp/issue-1580-research/native-failure-summary.json').replace(evidence/'ci/native-failure-summary.json')
exclude=Path('.git/info/exclude')
text=exclude.read_text()
pattern='/experiments/issue-1580/evidence/commands/*.json'
if pattern not in text: exclude.write_text(text+'\n'+pattern+'\n')
print(json.dumps({'source':head,'base':base,'gates':counts,'checkLogs':len(index),'blobs':sum(s['blobCount'] for s in sources)}))
