from pathlib import Path
import re

path=Path('/tmp/issue-1580-research/layered-44156399182.log')
lines=path.read_text().splitlines()
indexes=[]
for i,line in enumerate(lines):
    if re.search(r'✖|not ok|AssertionError|ERR_ASSERTION|test failed|tests? failed|fail [1-9]|failed:|##\[error\]',line,re.I):indexes.append(i)
ranges=[]
for index in indexes:
    low=max(0,index-12);high=min(len(lines),index+28)
    if ranges and low<=ranges[-1][1]:ranges[-1][1]=max(high,ranges[-1][1])
    else:ranges.append([low,high])
print('LOG',path,'TOTAL LINES',len(lines),'MATCHES',len(indexes),'SELECTED LINES',sum(high-low for low,high in ranges))
for low,high in ranges:
    print('RANGE',low+1,high)
    for index in range(low,high):print(f'{index+1}: {lines[index]}')
