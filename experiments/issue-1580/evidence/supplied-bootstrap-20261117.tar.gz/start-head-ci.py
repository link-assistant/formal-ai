import json,subprocess
from pathlib import Path
repo='link-assistant/formal-ai'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
def gh(*args): return subprocess.check_output(['gh',*args],text=True)
subprocess.run(['gh','pr','edit','1581','--repo',repo,'--title','Fix CI verdicts, candidate validation, and draft workflow accounting','--body-file','/tmp/issue-1580-research/pr-body.md'],check=True)
pages=json.loads(gh('api',f'repos/{repo}/actions/runs?branch=issue-1580-8d61a32a61e1&per_page=100','--paginate','--slurp'))
runs=[run for page in pages for run in page['workflow_runs'] if run['head_sha']==head]
Path('/tmp/issue-1580-research/new-head-runs.json').write_text(json.dumps(runs,indent=2)+'\n')
print('Current head:',head)
for run in runs:
    print(run['id'],run['name'],run['status'],run['conclusion'],run['created_at'])
    if run['conclusion']=='action_required':
        print('Approving current-head run',run['id'])
        subprocess.run(['gh','api','--method','POST',f'repos/{repo}/actions/runs/{run["id"]}/approve'],check=True)
