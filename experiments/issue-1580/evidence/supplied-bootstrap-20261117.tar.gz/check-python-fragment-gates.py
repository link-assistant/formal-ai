from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import sys

label = sys.argv[1]
assert label in ['before-archive', 'after-archive']
directory = Path('experiments/issue-1580/evidence/checks/python-fragment-collision')
records = []
for gate in ['check-abbreviations', 'check-file-size', 'check-file-size-js-twin']:
    arguments = ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', gate]
    completed = subprocess.run(arguments, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    data = completed.stdout
    path = directory / f'{label}-{gate}.log.gz'
    path.write_bytes(gzip.compress(data, mtime=0))
    record = {'gate': gate, 'arguments': arguments, 'exitCode': completed.returncode, 'path': str(path), 'rawBytes': len(data), 'rawSha256': hashlib.sha256(data).hexdigest()}
    records.append(record)
    print(json.dumps(record), flush=True)
    lines = data.decode().splitlines()
    print('\n'.join(lines[-16:]), flush=True)
    assert completed.returncode == 0
(directory / f'gates-{label}.json').write_text(json.dumps(records, indent=2) + '\n')
if label == 'before-archive':
    raw = Path('/tmp/formal-ai-shell-capture-c69Dr2/stdout.raw').read_bytes()
    assert len(raw) == 2174030
    assert hashlib.sha256(raw).hexdigest() == '03386e48125a10753dca85edf216091918abe19d82192400b07ace5c139ec348'
    reading = Path('experiments/issue-1580/evidence/checks/python-review-reading')
    reading.mkdir(exist_ok=True)
    path = reading / 'initial-bundle-preview.log.gz'
    path.write_bytes(gzip.compress(raw, mtime=0))
    (reading / 'initial-bundle-preview.json').write_text(json.dumps({'path': str(path), 'rawBytes': len(raw), 'rawSha256': hashlib.sha256(raw).hexdigest(), 'compressedSha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'fullPageReadingCredit': False, 'correction': 'The corrected 400-line reader explicitly defers both generated JavaScript bundles and both lockfiles. Pages 1-8 were subsequently fully read without the minified bundle.'}, indent=2) + '\n')
    print('Preserved the initial overlarge reader output without granting full-page credit.', flush=True)
