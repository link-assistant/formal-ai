from pathlib import Path

for name in ['rust/tests/web/fast-pull-request-production-profile.test.mjs','scripts/list-fast-pull-request-tests.mjs']:
    lines=Path(name).read_text().splitlines()
    print('FILE',name,len(lines),'first 145 lines');print('\n'.join(f'{n}: {line}' for n,line in enumerate(lines[:145],1)))
print('EXISTING GATE RUNNER BOOTSTRAPS')
for path in sorted(Path('/tmp/issue-1580-research').glob('*gate*.py')):
    if any(term in path.name for term in ['full','start','background','remaining']):print(path)
