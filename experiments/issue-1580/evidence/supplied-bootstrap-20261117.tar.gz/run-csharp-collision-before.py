from pathlib import Path
import gzip,hashlib,json,subprocess

base=Path('experiments/issue-1580')
test=base/'template-csharp-changeset-integrity.test.mjs'
evidence=base/'evidence/checks/csharp-changeset-collision'
evidence.mkdir(parents=True,exist_ok=True)
assert 'Candidate repair is inserted here' in test.read_text()
source=test.read_bytes()
(evidence/'before-test.mjs.gz').write_bytes(gzip.compress(source,mtime=0))
if (evidence/'before.tap').exists():
    (evidence/'initial-specification-reporter.log').write_bytes((evidence/'before.tap').read_bytes())
command=['timeout','600','node','--test','--test-reporter=tap','--test-concurrency=1',str(test)]
run=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(evidence/'before.tap').write_bytes(run.stdout)
(evidence/'before.json').write_text(json.dumps({'command':command,'exitCode':run.returncode,'testSha256':hashlib.sha256(source).hexdigest(),'claim':'The candidate preservation assertion runs against the unchanged pinned merger and must fail. The supplied random source chooses one existing valid input filename deterministically. No network or .NET runtime is involved.'},indent=2)+'\n')
print(run.stdout.decode())
assert run.returncode==1
assert b'# pass 3' in run.stdout and b'# fail 1' in run.stdout
assert b'not ok 2 - C\\# candidate preserves every input' in run.stdout
