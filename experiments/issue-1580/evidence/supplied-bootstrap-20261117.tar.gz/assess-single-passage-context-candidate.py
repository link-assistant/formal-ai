from pathlib import Path
import gzip, hashlib, json

root = Path('experiments/issue-1580/evidence/checks/passage-routing-probe')
artifact = root / 'single-passage-task-context.json.gz'
raw = gzip.decompress(artifact.read_bytes())
value = json.loads(raw)
rows = {row['name']: row for row in value['rows']}

def result(name, enabled):
    return next(item for item in rows[name]['outcomes'] if item['enabled'] == enabled)

checks = [
    ('original-context-restored', result('original', True)['answer']['metaExecution']['status'] == 'resolved'),
    ('changed-facts-context-restored', result('held-out-facts', True)['answer']['metaExecution']['status'] == 'resolved'),
    ('withheld-child-still-unresolved', result('withheld-child', True)['answer']['metaExecution']['status'] == 'unresolved'),
    ('quoted-connective-remains-protected', result('quoted-connective', True)['answer']['metaExecution']['shape'] == 'aggregation(leaf,leaf)'),
    ('independent-request-answer-covers-both-results', all(text in result('independent-arithmetic', True)['answer']['content'] for text in ['Thursday', '2 + 2 = 4'])),
    ('two-independent-passages-both-covered', all(text in result('two-independent-passages', True)['answer']['content'] for text in ['Thursday', '517'])),
    ('uncovered-subject-still-unresolved', result('uncovered-subject', True)['answer']['metaExecution']['status'] == 'unresolved'),
    ('standalone-arithmetic-unchanged', result('standalone-arithmetic', True)['answer']['content'] == result('standalone-arithmetic', False)['answer']['content'] == '2 + 2 = 4'),
]
assert sum(passed for _, passed in checks) == 4
report = {
    'schema': 'issue-1580-context-candidate-qualification/v1',
    'sourceHead': value['head'], 'sourceHashes': value['sourceHashes'],
    'artifact': str(artifact), 'artifactRawSha256': hashlib.sha256(raw).hexdigest(),
    'artifactRawBytes': len(raw), 'qualification': 'rejected',
    'checks': [{'name': name, 'passed': passed} for name, passed in checks],
    'productionModifiedByCandidate': False, 'nativeExecuted': False,
    'actualNetworkRequests': value['actualNetworkRequests'], 'independentAuthorshipCredit': 0,
    'limits': [
        'The candidate ran only in a disposable worker VM; it is not a production repair.',
        'Both variants already misreport completion of the two-passage request; this is not a newly introduced candidate regression.',
        'The candidate newly reports independent arithmetic complete while omitting the passage answer.',
        'The shared quotation masks omit ASCII quotes and require a separate repair.',
        'Selected outcome, binding and meta-execution review is not full literal review of every nested solver trace.'
    ]
}
path = root / 'single-passage-candidate-qualification.json'
assert not path.exists()
path.write_text(json.dumps(report, indent=2) + '\n')
log = Path('/tmp/issue-1580-research/single-passage-context-probe-corrected.log').read_bytes()
(root / 'single-passage-task-context.log.gz').write_bytes(gzip.compress(log, mtime=0))
print(json.dumps(report, indent=2))
for name, row in rows.items():
    for item in row['outcomes']:
        answer = item['answer']
        meta = answer['metaExecution']
        print(json.dumps({'name': name, 'enabled': item['enabled'], 'intent': answer['intent'], 'content': answer['content'], 'status': meta['status'], 'shape': meta['shape'], 'requiredChildren': [event for event in meta['events'] if event.startswith(('meta_exec:compose', 'meta_exec:unresolved'))], 'bindings': item['bindings'], 'localTransportCalls': item['localTransportCalls']}, ensure_ascii=False))
