set -eu
cat experiments/issue-1580/work-plan.md
cat experiments/issue-1580/compare-template-trees.mjs
cat experiments/issue-1580/template-go-result-integrity.test.mjs
cat .cargo/audit.toml
