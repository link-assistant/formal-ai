from pathlib import Path
import json
name='docs/case-studies/issue-1580/templates/python-partial-semantic-review.json';value=json.loads(Path(name).read_text())
print(name);print('keys:',list(value))
for key,item in value.items():
 if isinstance(item,list):print(key,'list',len(item),json.dumps(item[:2],indent=2))
 elif isinstance(item,dict):print(key,'dict',json.dumps(item,indent=2)[:3000])
 else:print(key,repr(item))
print('Potential recording scripts:')
print('\n'.join(p.name for p in Path('/tmp/issue-1580-research').glob('*python*') if any(w in p.name for w in ['record','review','checkpoint'])))
