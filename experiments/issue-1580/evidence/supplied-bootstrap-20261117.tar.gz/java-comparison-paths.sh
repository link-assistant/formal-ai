set -eu
rg --files -g '*toolchain*' -g '*untrusted*' -g '*audit-triage*' -g '*detect*changes*' -g 'Cargo.lock'
