from pathlib import Path

source = Path('experiments/issue-1580/probe-single-passage-task-context.mjs').read_text()
target = Path('experiments/issue-1580/probe-parent-answer-coverage.mjs')
assert not target.exists()

def replace_once(before, after):
    global source
    assert source.count(before) == 1, before
    source = source.replace(before, after)

replace_once('await evaluate(worker, \'loadSeed()\');', '''await evaluate(worker, 'loadSeed()');
// Every change below applies only to one disposable worker VM. Production,
// generated artifacts, shared fixtures and their expected traces stay intact.
let factory = readFileSync('js/worker/formal_ai_worker_crate_meta_executor.js', 'utf8');
const transform = (before, after) => {
  assert.equal(factory.split(before).length, 2, before);
  factory = factory.replace(before, after);
};
transform('answer ? { intent: answer.intent, content: answer.content, confidence: answer.confidence } : null;',
  'answer ? { intent: answer.intent, content: answer.content, confidence: answer.confidence, evidence: answer.evidence } : null;');
transform('host.canCompose?.(node)', 'host.canCompose?.(node, childOutcomes)');
transform("canCompose: (task) => task.depth !== 0 || ruleValues('unresolved-intent').includes(answer.intent),",
  "canCompose: (task, outcomes) => task.depth !== 0 || ruleValues('unresolved-intent').includes(answer.intent) || (globalThis.parentCoverageProbeEnabled && answer.intent === 'calculation' && outcomes.some(outcome => outcome.candidate?.intent === 'prompt_text_answer') && outcomes.every(outcome => ['prompt_text_answer', 'calculation'].includes(outcome.candidate?.intent))),");
transform('const verdict = runTaskTest(test, candidate, childOutcomes);', `const verdict = runTaskTest(test, candidate, childOutcomes);
    if (globalThis.parentCoverageProbeEnabled) {
      const coverage = globalThis.parentCoverageProbeCheck(node, test, candidate, childOutcomes);
      if (coverage.applies) {
        verdict.executed.push('experiment:parent_coverage');
        if (!coverage.passed) {
          verdict.passed = false;
          verdict.failed ||= 'experiment:parent_coverage';
        }
        globalThis.parentCoverageProbeEvents.push({task: node.id, method: candidate.method, intent: candidate.intent, ...coverage});
      }
    }`);
await evaluate(worker, factory);
await evaluate(worker, `
  crateInstances.delete('crate/meta_executor.mjs');
  globalThis.parentCoverageProbeEnabled = false;
  globalThis.parentCoverageProbeEvents = [];
  globalThis.parentCoverageProbeCheck = (node, test, candidate, outcomes) => {
    const resolved = outcomes.filter(outcome => outcome.status === 'resolved');
    const selected = test.requires === 'any' ? resolved.slice(0, 1) : resolved;
    const passage = selected.filter(outcome => outcome.candidate?.intent === 'prompt_text_answer');
    if (!node.children.length || !passage.length) return {applies: false, passed: true};
    const required = selected.map(outcome => outcome.task);
    if (candidate.method === 'composition') {
      const passed = required.every(task => candidate.parts?.includes(task));
      return {applies: true, passed, required, reason: passed ? 'composition-retains-required-parts' : 'missing-composition-part'};
    }
    const facts = value => Array.isArray(value?.evidence) ? value.evidence : [];
    const parent = facts(candidate.source);
    const roles = values => values.filter(value => value.startsWith('prompt_text:asked:')).flatMap(value => value.slice('prompt_text:asked:'.length).split(','));
    const statements = values => values.filter(value => value.startsWith('prompt_text:statement:'));
    let passed = candidate.intent === 'prompt_text_answer';
    const obligations = [];
    for (const child of passage) {
      const evidence = facts(child.candidate.source);
      const asked = roles(evidence);
      const grounded = statements(evidence);
      const covers = asked.length > 0 && grounded.length > 0
        && asked.every(role => roles(parent).includes(role))
        && grounded.every(statement => statements(parent).includes(statement));
      obligations.push({task: child.task, asked, grounded, covers});
      passed &&= covers;
    }
    // A direct passage answer cannot discharge an independent calculation.
    passed &&= selected.every(outcome => outcome.candidate.intent === 'prompt_text_answer');
    return {applies: true, passed, required, obligations, reason: passed ? 'same-statement-and-question-roles' : 'parent-does-not-cover-child-evidence'};
  };
`);''')
replace_once('return candidate || direct;', "return parentCoverageProbeEnabled && candidate?.intent === 'prompt_text_gap' ? direct : (candidate || direct);")
replace_once("  { name: 'standalone-arithmetic', prompt: 'Calculate 2 + 2' },", "  { name: 'standalone-arithmetic', prompt: 'Calculate 2 + 2' },\n  { name: 'concrete-output-contract', prompt: 'Write a Python function to add two integers and include a test.' },")
replace_once('for (const enabled of [false, true]) {', "for (const [mode, enabled, coverage] of [['baseline', false, false], ['binding', true, false], ['coverage', true, true]]) {")
replace_once('    worker.contextProbeEnabled = enabled;', '    worker.contextProbeEnabled = enabled;\n    worker.parentCoverageProbeEnabled = coverage;\n    worker.parentCoverageProbeEvents.length = 0;')
replace_once('const outcome = { enabled, answer, bindings:', 'const outcome = { mode, enabled, coverage, coverageEvents: plain(worker.parentCoverageProbeEvents), answer, bindings:')
replace_once('JSON.stringify({ name: item.name, enabled, intent:', 'JSON.stringify({ name: item.name, mode, intent:')
start = source.index('const original = rows.find(')
end = source.index('const sourceHashes = ', start)
source = source[:start] + '''const baseline = name => rows.find(row => row.name === name).outcomes[0].answer;
const candidate = name => rows.find(row => row.name === name).outcomes[2].answer;
const resolved = name => candidate(name).metaExecution?.status === 'resolved';
const qualification = [
  ['original', resolved('original')],
  ['held-out-facts', resolved('held-out-facts')],
  ['withheld-child', !resolved('withheld-child')],
  ['quoted-connective', resolved('quoted-connective')],
  ['independent-arithmetic', resolved('independent-arithmetic') && /Thursday/.test(candidate('independent-arithmetic').content) && /2 \\+ 2 = 4/.test(candidate('independent-arithmetic').content)],
  ['two-independent-passages', resolved('two-independent-passages') && /Thursday/.test(candidate('two-independent-passages').content) && /hall 517/.test(candidate('two-independent-passages').content)],
  ['uncovered-subject', !resolved('uncovered-subject')],
  ['standalone-arithmetic', candidate('standalone-arithmetic').intent === baseline('standalone-arithmetic').intent && candidate('standalone-arithmetic').content === baseline('standalone-arithmetic').content],
  ['concrete-output-contract', candidate('concrete-output-contract').intent === baseline('concrete-output-contract').intent && candidate('concrete-output-contract').content === baseline('concrete-output-contract').content && candidate('concrete-output-contract').metaExecution.method !== 'composition'],
];
assert.ok(rows.every(row => row.outcomes.every(outcome => outcome.localTransportCalls === 0)));
console.log(JSON.stringify({qualification, passed: qualification.filter(([, passed]) => passed).length, total: qualification.length, productionAdopted: false, statementMetadataIsGeneralProof: false}));
''' + source[end:]
replace_once("schema: 'issue-1580-single-passage-context-experiment/v1'", "schema: 'issue-1580-parent-answer-coverage-experiment/v1', qualification, statementMetadataIsGeneralProof: false")
replace_once("'experiments/issue-1580/evidence/checks/passage-routing-probe/single-passage-task-context.json.gz'", "'experiments/issue-1580/evidence/checks/passage-routing-probe/parent-answer-coverage.json.gz'")
target.write_text(source)
print(f'Created {target}: {len(source.encode())} bytes; 9 requests x 3 variants; disposable VM only; zero independent authorship credit.')
