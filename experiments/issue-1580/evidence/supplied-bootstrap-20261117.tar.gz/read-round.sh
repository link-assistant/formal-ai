set -eu
cat /tmp/issue-1580-research/local-gate-list.txt
sed -n '1,200p' experiments/formal_ai_subagent/local-gates.mjs
git diff -- scripts/documentation-only-ci-policy.mjs rust/tests/web/documentation-only-ci-policy.test.mjs rust/src/solver.rs
sed -n '1,160p' experiments/issue-1580/archive-evidence.py
rg --files changelog.d | rg 1580
