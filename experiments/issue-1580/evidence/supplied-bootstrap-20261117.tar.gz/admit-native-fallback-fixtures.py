from pathlib import Path
p=Path('scripts/ci-pull-request-admission.mjs');s=p.read_text();anchor="  'rust/tests/unit/seed/issue_1172_live_fact_answer.rs',";assert s.count(anchor)==1;p.write_text(s.replace(anchor,anchor+"\n  'rust/tests/unit/issue_1173_fallback_executes_search.rs',"))
p=Path('rust/tests/unit/reasoning_contracts.rs');s=p.read_text();anchor='#[path = "specification/event_source_origin.rs"]';assert s.count(anchor)==1;s=s.replace(anchor,'#[path = "issue_1173_fallback_executes_search.rs"]\nmod external_search_fallback;\n'+anchor);p.write_text(s)
