from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
p=root/'docs/case-studies/issue-1580/checkout-archive-checkpoint.md'
s=p.read_text();anchor='## Java historical comparison\n';assert anchor in s
s=s.replace(anchor,'''The final publication checks find one new source-budget failure: the expanded
checkout block makes the canonical workflow 1,513 lines, above the unchanged
1,500-line ceiling. Preserve both failing gate invocations and their complete
diagnostics. Use the workflow's existing compact flow style for exactly the same
parsed configuration; the canonical source returns to 1,494 lines. The maintained
generator verifies identical staged workflow bytes and all 104 bindings again.
Recheck the affected size gates, source profile, stage transition and projection
before publication; their final receipts are retained separately.

'''+anchor);p.write_text(s)
p=root/'experiments/issue-1580/work-plan.md';p.write_text(p.read_text()+'''
Final publication checks catch the canonical workflow at 1,513 lines. Preserve
both unchanged-limit gate failures. Compact only the new checkout configuration
using its prior flow style, prove parsed YAML equality, and regenerate with the
maintained compiler: 1,494 lines, unchanged 52 operations/104 bindings/staged
workflow bytes. Recheck affected gates and focused regressions before pushing.
''')
p=Path('/tmp/issue-1580-research/checkout-archive-pull-request-description.md');s=p.read_text();s=s.replace('The deployed projection check, **3/3 stage transition tests**, seven touched JavaScript gates and pinned runner labels pass.','The deployed projection check, **3/3 stage transition tests**, seven touched JavaScript gates and pinned runner labels pass across the retained invocations. The final source-budget check catches the expanded canonical checkout block at 1,513 lines; restoring the existing compact flow style preserves the parsed YAML and returns it to 1,494 lines without changing the 1,500-line ceiling. Corrected gate and focused regression receipts are retained separately.');p.write_text(s)
r=subprocess.run(['python3','/tmp/issue-1580-research/archive-round-bootstrap.py'],cwd=root);assert r.returncode==0
r=subprocess.run(['python3','/tmp/issue-1580-research/final-checkout-publication-checks.py','--after-format'],cwd=root);raise SystemExit(r.returncode)
