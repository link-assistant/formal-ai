from pathlib import Path
import subprocess, json, gzip, hashlib, datetime

root=Path.cwd();out=root/'experiments/issue-1580/evidence/checks/picomatch-governed-refresh/feedback'
out.mkdir(exist_ok=True)
for name,endpoint in [
 ('issue-comments','issues/1580/comments'),
 ('pr-conversation','issues/1581/comments'),
 ('pr-inline-comments','pulls/1581/comments'),
 ('pr-reviews','pulls/1581/reviews')]:
    raw=subprocess.check_output(['gh','api','repos/link-assistant/formal-ai/'+endpoint,'--paginate'])
    rows=json.loads(raw)
    (out/(name+'.json.gz')).write_bytes(gzip.compress(raw,mtime=0))
    print('FEEDBACK',name,'COUNT',len(rows),'SHA256',hashlib.sha256(raw).hexdigest())
    for row in rows[-2:]:
        body=row.get('body') or ''
        print(json.dumps({key:row.get(key) for key in ['id','html_url','created_at','updated_at','submitted_at','state']},ensure_ascii=False))
        if len(body)<5500:print(body)
        else: print('BODY_REQUIRES_CHUNKED_READING',len(body))
(out/'collected-at.txt').write_text(datetime.datetime.now(datetime.timezone.utc).isoformat()+'\n')
path=Path('/tmp/issue-1580-research/governed-refresh-all-local-gates.log')
print('GATE_PROGRESS','\n'.join(path.read_text().splitlines()[-8:]))
print('MEMORY',Path('/sys/fs/cgroup/memory.current').read_text().strip())
