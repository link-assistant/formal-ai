import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const original=require('/tmp/issue-1580-research/picomatch/package');
const candidate=require('/tmp/gh-issue-solver-1794900398048/packages/picomatch-compat');
for (const pattern of ['+([[]*a)', '+([*a)', '+([[:alpha:]]*a)', '+("a*")', '+([*])', '+(\\*)']) {
  console.log(JSON.stringify({pattern, original:original.makeRe(pattern).source, candidate:candidate.makeRe(pattern).source}));
}
