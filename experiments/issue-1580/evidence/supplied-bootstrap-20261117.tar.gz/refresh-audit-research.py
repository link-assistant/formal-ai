from pathlib import Path
import gzip,json,subprocess,hashlib
directory=Path('experiments/issue-1580/evidence/checks/audit-inventory-boundary')
repo='link-foundation/python-ai-driven-development-pipeline-template'
def gh(*args):return subprocess.run(['gh',*args],capture_output=True,check=True).stdout
raw=gh('api',f'repos/{repo}/issues?state=all&per_page=100','--paginate','--slurp')
rows=[r for page in json.loads(raw) for r in page];(directory/'duplicate-issues.json.gz').write_bytes(gzip.compress(json.dumps(rows,indent=2).encode(),mtime=0))
print('UPSTREAM_ISSUES',len(rows))
for row in rows:
 if any(word in ((row.get('title') or '')+' '+(row.get('body') or '')).lower() for word in ['audit-npm-locks','mapfile','partial inventory','inventory failure']):
  print(json.dumps({k:row.get(k) for k in ['number','title','state','html_url']},ensure_ascii=False))
latest=json.loads(gh('api',f'repos/{repo}/commits/main'))
print('UPSTREAM_HEAD',latest['sha'])
(directory/'upstream-current-identity.json').write_text(json.dumps({'repository':repo,'head':latest['sha'],'message':latest['commit']['message']},indent=2)+'\n')
for endpoint,name in [('issues/1580/comments','issue-comments'),('issues/1581/comments','pr-comments'),('pulls/1581/comments','inline-comments'),('pulls/1581/reviews','reviews')]:
 raw=gh('api','repos/link-assistant/formal-ai/'+endpoint,'--paginate','--slurp');(directory/f'feedback-{name}.json.gz').write_bytes(gzip.compress(raw,mtime=0))
 rows=[r for page in json.loads(raw) for r in page];print('FEEDBACK_COUNT',name,len(rows))
 for row in rows:
  if row.get('created_at','')>'2026-11-17T15:00:00Z' or row.get('updated_at','')>'2026-11-17T15:00:00Z':print(json.dumps(row,ensure_ascii=False))
print('RESEARCH_REFRESH_COMPLETE')
