from pathlib import Path
import json
for name in ['docs/case-studies/issue-1580/templates/java-active-semantic-review.json','/tmp/issue-1580-research/templates/java-complete-inventory.json']:
    value=json.loads(Path(name).read_text())
    print('FILE',name,'TYPE',type(value).__name__)
    if isinstance(value,list):print('COUNT',len(value),'FIRST',json.dumps(value[:2]))
    else:
        for key,row in value.items():
            if isinstance(row,list):print('LIST',key,'COUNT',len(row),'FIRST',json.dumps(row[:2])[:4500])
            else:print(key,json.dumps(row)[:1200])
for name in ['inventory-java-history.py','java-read-remainder.py','java-archive-inventory.py']:
    path=Path('/tmp/issue-1580-research')/name
    print('TOOL',name,path.read_text())
