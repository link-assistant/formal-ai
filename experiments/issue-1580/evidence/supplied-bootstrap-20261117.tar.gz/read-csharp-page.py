from pathlib import Path
import json
import sys

base=Path('/tmp/issue-1580-research/templates/csharp-complete')
rows=json.loads(Path('/tmp/issue-1580-research/templates/csharp-complete-inventory.json').read_text())
page=int(sys.argv[1])
width=450
lines=[]
for row in rows:
 p=row['path']
 if p.startswith(('dev/log/','ci-logs/')):
  continue
 try:
  source=(base/p).read_text().splitlines()
 except UnicodeDecodeError:
  continue
 lines.extend((p,n,line) for n,line in enumerate(source,1))
print(f'csharp pinned a5b9a1a46686cfe844f9afa2ace030094969e766 active text {len(lines)} lines, page {page}/{(len(lines)+width-1)//width}')
part=lines[(page-1)*width:page*width]
assert part, 'page outside active source'
previous=None
for p,n,line in part:
 if p!=previous:
  print('\nFILE '+p)
  previous=p
 print(f'{n}: {line}')
