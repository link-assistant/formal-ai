from pathlib import Path
import json,subprocess
def run(args):return subprocess.run(args,check=True,text=True,capture_output=True).stdout
repo='link-assistant/formal-ai'
pr=json.loads(run(['gh','pr','view','1581','--repo',repo,'--json','body,title,url,isDraft,headRefOid,headRefName']))
assert pr['headRefName']=='issue-1580-8d61a32a61e1' and pr['headRefOid']=='b79dc1e0f147ed57d8e317c1b93bfa6ffc79078d' and pr['isDraft']
body=pr['body']
old='The recorded C# checkpoint covers 120 of 158 active files, with all 337 blobs hash-verified; 38 active and 179 historical files remain semantically unread at that checkpoint.'
new='C# now has all 158 active files / 18,327 lines semantically reviewed, including its six workflows and active transitive helpers/tests/configuration/application source, with all 337 blobs hash-verified; 179 historical files remain semantically unread and runtime/publication acceptance is unverified.'
assert old in body; body=body.replace(old,new)
old='The C# evidence head `0f90c0a7a3` is under verification. C# semantic review is partial; full remaining repository reviews stay open.'
new='The C# evidence head `0f90c0a7a3` completed with 23 passing workflows and one real Layered CI policy failure: a new preserved reporter log used `spec` in its basename, raising the filename abbreviation ratchet from 90 to 91 (full log lines 7069 and 7965-7968). A byte-preserving rename to `initial-specification-reporter.log.gz` fixes that failure without changing the baseline. All six existing abbreviation regression cases and all three touched gates pass, including post-archive gate checks. The complete original failure and local before/after logs are retained. Published head `b79dc1e0f1` is under verification. Full remaining repository reviews and C# runtime/publication acceptance stay open.'
assert old in body; body=body.replace(old,new)
assert body.startswith('Fixes #1580\n')
path=Path('/tmp/issue-1580-research/pr-csharp-active-completion-body.md');path.write_text(body)
print(run(['gh','pr','edit','1581','--repo',repo,'--title',pr['title'],'--body-file',str(path)]))
after=json.loads(run(['gh','pr','view','1581','--repo',repo,'--json','body,title,url,isDraft,headRefOid']))
assert after['body']==body and after['isDraft']
Path('/tmp/issue-1580-research/pr-csharp-active-completion-after.json').write_text(json.dumps(after,indent=2)+'\n')
print(json.dumps({'url':after['url'],'head':after['headRefOid'],'draft':after['isDraft'],'bodyVerified':True,'activeCsharpFiles':158,'historicalCsharpUnread':179,'complete':False},indent=2))
runs=json.loads(run(['gh','run','list','--repo',repo,'--branch','issue-1580-8d61a32a61e1','--commit',after['headRefOid'],'--limit','100','--json','databaseId,workflowName,status,conclusion,headSha,createdAt']))
Path('/tmp/issue-1580-research/csharp-active-head-initial-runs.json').write_text(json.dumps(runs,indent=2)+'\n')
print(json.dumps({'runs':len(runs),'passing':sum(r['conclusion']=='success' for r in runs),'active':[r for r in runs if r['status']!='completed'],'failed':[r for r in runs if r['status']=='completed' and r['conclusion']!='success']},indent=2))
