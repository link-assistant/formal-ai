from pathlib import Path
p=Path('scripts/check-sccache-write-health.sh');text=p.read_text()
text=text.replace('# default; set it to `true` and rerun to collect the discriminating evidence.','# default; set it to `true` and rerun. The EXIT diagnostic below retains a\n# bounded, URL-redacted tail in the hosted job log, including when stats fail.')
text=text.replace('#   SCCACHE_PATH                      sccache binary to ask (found on PATH)','#   SCCACHE_PATH                      sccache binary to ask (found on PATH)\n#   FORMAL_AI_CI_VERBOSE               true retains opt-in backend diagnostics\n#   SCCACHE_ERROR_LOG                  server log configured before startup')
needle='source="${1:-}"\n';assert text.count(needle)==1
text=text.replace(needle,needle+'''
# The daemon writes this file instead of the job's output. Without retaining it,
# an opt-in rerun loses the response needed to diagnose cache write failures.
# Read at most 64 KiB and print at most 80 lines; URL values can be signed.
# Prefix every line so backend text cannot become a workflow command.
# shellcheck disable=SC2329  # invoked by the EXIT trap, including early exits
emit_backend_diagnostics() {
  [ "${FORMAL_AI_CI_VERBOSE:-false}" = true ] || return 0
  local backend_log="${SCCACHE_ERROR_LOG:-}"
  [ -n "$backend_log" ] && [ -f "$backend_log" ] && [ -r "$backend_log" ] || return 0
  echo '[sccache] opt-in backend log tail (at most 64 KiB / 80 lines; URLs redacted):' >&2
  tail -c 65536 -- "$backend_log" 2> /dev/null | tail -n 80 |
    sed -E 's#https?://[^[:space:]]+#<cache-url-redacted>#g; s/^/[sccache] /' >&2 || true
  return 0
}
trap emit_backend_diagnostics EXIT
''')
p.write_text(text)
p=Path('.github/actions/setup-sccache/action.yml');text=p.read_text();needle='    # repository variable to true and rerun the affected workflow.';assert needle in text
text=text.replace(needle,needle+' The\n    # budget wrapper retains the bounded, URL-redacted tail in the job log via\n    # check-sccache-write-health.sh, even if statistics are unavailable.')
p.write_text(text)
print('Retain default-off bounded backend diagnostics through the existing budget-wrapper health call.')
