set -eu
sed -n '90,195p' scripts/detect-code-changes.rs
sed -n '575,700p' scripts/detect-code-changes.rs
cat experiments/issue-1580/fixtures/php-template/source.json
cat /tmp/issue-1580-research/whole-current-gates.sh
rg --files /tmp/issue-1580-research | rg 'chrono|registry|current-round|snapshot|archive|pr-body' | head -n 35
