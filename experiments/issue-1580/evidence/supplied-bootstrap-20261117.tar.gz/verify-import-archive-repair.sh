set -eu
timeout 600 node --test --test-concurrency=1 rust/tests/web/issue-1580-template-observations.test.mjs > /tmp/issue-1580-research/template-observations-sixth.log 2>&1
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-reference-graph.test.mjs > /tmp/issue-1580-research/template-reference-graph-sixth.log 2>&1
node experiments/formal_ai_subagent/local-gates.mjs --only check_file_size > /tmp/issue-1580-research/file-size-sixth.log 2>&1
cat /tmp/issue-1580-research/template-observations-sixth.log
cat /tmp/issue-1580-research/template-reference-graph-sixth.log
tail -n 10 /tmp/issue-1580-research/file-size-sixth.log
