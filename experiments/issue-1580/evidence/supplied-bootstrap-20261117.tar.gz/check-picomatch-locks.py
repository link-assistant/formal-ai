from pathlib import Path
import json,os
base=Path('/tmp/issue-1580-research')
p=base/'picomatch-lock-results.json'
print('RESULTS',p.read_text() if p.exists() else 'RUNNING')
for name in ['desktop','vscode']:
 p=base/('picomatch-lock-'+name+'.log')
 if p.exists():
  lines=p.read_text().splitlines()
  print(name,'log lines',len(lines))
  print('\n'.join(lines[-60:]))
r=Path('/tmp/gh-issue-solver-1794900398048')
for name in ['desktop','vscode']:
 d=json.loads((r/name/'package-lock.json').read_text())
 print(name,'picomatch packages')
 for key,value in d['packages'].items():
  if 'picomatch' in key: print(key,json.dumps(value))
