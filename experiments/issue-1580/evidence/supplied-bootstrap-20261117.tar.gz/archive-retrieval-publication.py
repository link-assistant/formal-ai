from pathlib import Path
import gzip,hashlib,json
s=Path('/tmp/issue-1580-research/native-retrieval-contract-publication');d=json.loads((s/'outcome.json').read_text());assert d['complete']and d['pushExecuted']and d['sourceHead'].startswith('39487885e');b=Path('experiments/issue-1580/evidence/checks/native-retrieval-contract-publication-verified');b.mkdir(exist_ok=True);records=[]
for row in d['records']:
 copy=dict(row)
 for label in ['stdout','stderr']:
  name=row['name']+'.'+label;raw=(s/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==row[label+'Sha256'];packed=gzip.compress(raw,mtime=0);(b/(name+'.gz')).write_bytes(packed);copy[label]={'file':name+'.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())}
 records.append(copy)
(b/'records.json').write_text(json.dumps(records,separators=(',',':'))+'\n');summary={k:v for k,v in d.items()if k!='records'};summary['verifiedPayloads']=2*len(records);summary['reason']='The prior batch is published as e6ca6bc8 after its recorded gate. Its completed failed CI is reviewed separately; no passing current CI or complete issue acceptance is inferred.';(b/'review.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k!='records'}))
