from pathlib import Path
import hashlib
import json
import sys

root = Path('/tmp/issue-1580-research/templates/python-complete')
inventory = json.loads(Path('/tmp/issue-1580-research/python-active-source-inventory.json').read_text())
name = sys.argv[1]
entry = next(item for item in inventory['active'] if item['path'] == name)
data = (root / name).read_bytes()
assert hashlib.sha256(data).hexdigest() == entry['sha256']
lines = data.decode().splitlines()
start = int(sys.argv[2]) if len(sys.argv) > 2 else 1
stop = int(sys.argv[3]) if len(sys.argv) > 3 else min(len(lines), start + 399)
assert 1 <= start <= stop <= len(lines) and stop - start < 600
part = lines[start - 1:stop]
assert sum(map(len, part)) < 65000
print(json.dumps({'path': name, 'pin': 'c532c173801dfb12e681b0730c4abbf93aefd0ca', 'sha256': entry['sha256'], 'totalLines': len(lines), 'readRange': [start, stop]}))
for number, line in enumerate(part, start):
    print(f'{number}: {line}')
