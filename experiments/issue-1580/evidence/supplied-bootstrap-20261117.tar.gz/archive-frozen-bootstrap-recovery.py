from pathlib import Path
import json,gzip,hashlib
source=Path('/tmp/issue-1580-research/frozen-formal-driver-a748854')
target=Path('experiments/issue-1580/evidence/checks/language-main-integration/bootstrap-recovery')
target.mkdir(exist_ok=False)
receipt=json.loads((source/'recovery-receipt.json').read_text());records=[]
for p in sorted((source/'experiments/issue-1580/evidence/commands').glob('*.json')):
 raw=p.read_bytes();value=json.loads(raw);packed=gzip.compress(raw,mtime=0);name=p.name+'.gz';(target/name).write_bytes(packed)
 records.append({'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'status':value['status'],'source':value['source'],'signal':value['signal'],'independentAuthorshipCredit':0,'validationCredit':0})
assert len(records)==6
(target/'manifest.json').write_text(json.dumps({'recovery':receipt,'records':records,'scope':'Temporary coherent HEAD snapshot for merge-conflict recovery only. Snapshot construction used direct host recovery commands; no validation, solver or independent reasoning credit. All merged validation uses restored ordinary driver in actual checkout without preloader.'},indent=2)+'\n')
print('Retained six frozen-snapshot Formal AI command records; all hashes verified and all credit zero.')
print(json.dumps([{'file':x['file'],'status':x['status']} for x in records]))
