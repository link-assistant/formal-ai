from pathlib import Path
import gzip,json
out=Path('experiments/issue-1580/evidence/checks/localized-unknown-opener/shellcheck/provisioning-attempts');out.mkdir()
for folder,names in [('shellcheck-install',['outcome.json','apt.log','worker.log']),('shellcheck-user',['outcome.json','download.log','worker.log'])]:
    source=Path('/tmp/issue-1580-research')/folder
    for name in names:
        path=source/name
        if path.exists():(out/(folder+'-'+name+'.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
base=Path('experiments/issue-1580/evidence')
for folder in ['checks/localized-unknown-opener/all-gates','checks/localized-unknown-opener/corrected-checks','checks/localized-unknown-opener/publication','ci/native-b367d603/opener-round-preflight']:
    for path in (base/folder).glob('worker.*.log'):
        path.with_suffix(path.suffix+'.gz').write_bytes(gzip.compress(path.read_bytes(),mtime=0))
print('Preserved failed provisioning attempts and completed worker streams with gzip.')
