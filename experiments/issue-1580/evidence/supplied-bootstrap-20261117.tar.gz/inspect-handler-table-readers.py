import pathlib, subprocess
for command in [
 ['rg','-n','function handlerRulesTables|fn table_rows|fn words\(|flatMap.*row.slice|row.slice\(1|\.split\("\\|"\)|split\(\x27\\|\x27\)','js/worker','rust/src/solver_handlers/calendar','rust/src/seed.rs','rust/tests/web/support'],
 ['rg','-n','row .*\\(','data/seed/handler-rules.lino'],
 ['rg','-n','meaningDefinitions|meaning.*unique|pipe.pack|technical.scalar','scripts','rust/tests/web'],
]:
 result=subprocess.run(command,text=True,capture_output=True)
 print('COMMAND',repr(command),'exit',result.returncode,flush=True)
 lines=(result.stdout+result.stderr).splitlines()
 if len(lines)>100:
  name=pathlib.Path('/tmp/issue-1580-research/handler-table-search-'+str(len(lines))+'.log')
  name.write_text('\n'.join(lines)+'\n')
  print('saved',len(lines),'lines',name)
 print('\n'.join(lines[:100]))
for name,first,last in [('rust/src/solver_handlers/calendar/month.rs',220,310),('rust/tests/unit/data_files.rs',540,600),('data/seed/handler-rules.lino',1275,1294),('data/meta/main-only-regressions.lino',1,200),('data/benchmarks/fast-pull-request-javascript-tests.json',1,80)]:
 lines=pathlib.Path(name).read_text().splitlines()
 print(f'\nFILE {name}:{first}-{min(last,len(lines))} of {len(lines)}')
 for n in range(first,min(last,len(lines))+1):print(f'{n}: {lines[n-1]}')
