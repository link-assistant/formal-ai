from pathlib import Path
import gzip, json, subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
print('RESOURCE STATE')
for name in ['memory.current','memory.max','memory.events']: print(name,Path('/sys/fs/cgroup',name).read_text().strip())
print('GATE PROGRESS',Path('/tmp/issue-1580-research/picomatch-sealed-gates-supervisor.log').read_text())
print('EXISTING FAILURE RECEIPTS')
for path in sorted((root/'experiments/issue-1580/evidence/ci/main-512ce428').iterdir()): print(path.name,path.stat().st_size)
print('SYNTHESIS INPUTS')
path=root/'rust/tests/unit/specification/synthesis.rs'
lines=path.read_text().splitlines()
for lo,hi in [(30,95),(300,351),(400,490)]:
    print('FILE',path.relative_to(root),lo,hi)
    for n in range(lo-1,min(hi,len(lines))): print(f'{n+1}: {lines[n]}')
print('FAILURE PAYLOADS WITHOUT STACK ADDRESSES')
log=root/'experiments/issue-1580/evidence/ci/main-512ce428/44117975432.log.gz'
ranges=[(51300,51325),(57800,57955),(57975,57995),(82125,82145),(82270,82295)]
with gzip.open(log,'rt') as handle:
    for number,line in enumerate(handle,1):
        if not any(lo<=number<=hi for lo,hi in ranges): continue
        text=line.rstrip().split('\t',2)[-1]
        if ' - ' in text and '<unknown>' in text: continue
        if 'stack backtrace:' in text or not text: continue
        if len(text)>1300:
            print(number,'long diagnostic omitted; bytes',len(text));continue
        print(f'{number}: {text}')
