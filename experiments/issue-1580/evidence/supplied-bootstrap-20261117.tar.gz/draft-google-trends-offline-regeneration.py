from pathlib import Path
import json,hashlib,subprocess
changed=[]
def update(path,old,new):
 p=Path(path);text=p.read_text();assert text.count(old)==1,(path,old[:120]);p.write_text(text.replace(old,new));changed.append(path)
update('rust/src/google_trends_catalog.rs','use crate::engine::FormalAiEngine;','use crate::solver::{SolverConfig, UniversalSolver};')
update('rust/src/google_trends_catalog.rs','    let engine = FormalAiEngine;','''    // A committed snapshot must not depend on the process-wide live-retrieval
    // default. Keep the normal solver/standing-requirement path, with network
    // access explicitly disabled for this deterministic catalog projection.
    let solver = UniversalSolver::new(SolverConfig {
        offline: true,
        ..SolverConfig::default()
    });''')
update('rust/src/google_trends_catalog.rs','                let answer = engine.answer(&prompt.prompt);','''                let answer = crate::dreaming_application::solve_with_standing_requirements(
                    &solver,
                    &prompt.prompt,
                    &[],
                    &[],
                );''')
p=Path('data/seed/google-trends-prompts.lino');p.write_text(p.read_text()+'''google_trend_prompt_template
  record_type "google_trend_prompt_template"
  language "es"
  variation "tell_me_about"
  text "Cuéntame sobre {query}?"
google_trend_prompt_template
  record_type "google_trend_prompt_template"
  language "es"
  variation "trends_context"
  text "Dame contexto de Google Trends sobre {query}?"
''');changed.append(str(p))
old='No captured provider response is available for `julián andrés quiñones`. Live fetching is off by default; enable it explicitly to populate the replayable source cache. The unexecuted plan includes DuckDuckGo, Internet Archive, Wikipedia, Wikidata, Wiktionary, and Wikinews.'
new='No captured provider response is available for `julián andrés quiñones`. Read-only retrieval is enabled by default. Check connectivity, provider errors, and explicit offline or deny settings; ask how to enable internet access for harness permission controls. The unexecuted plan includes DuckDuckGo, Internet Archive, Wikipedia, Wikidata, Wiktionary, and Wikinews.'
update('rust/tests/unit/issue_498_google_trends.rs',old,new)
p=Path('rust/tests/unit/reasoning_contracts.rs');p.write_text(p.read_text()+'''\n#[path = "issue_498_google_trends.rs"]
mod google_trends;
''');changed.append(str(p))
update('scripts/ci-pull-request-admission.mjs',"  'rust/tests/unit/reasoning_contracts.rs',","  'rust/tests/unit/reasoning_contracts.rs',\n  'rust/tests/unit/issue_498_google_trends.rs',\n  'rust/examples/dump_google_trends_catalog.rs',")
p=Path('rust/examples/dump_google_trends_catalog.rs');p.write_text('''//! Print the deterministic catalog, or stage the catalog and an actual driver
//! session in a fresh directory supplied as the sole argument.

use formal_ai::agentic_coding::{
    GOOGLE_TRENDS_CATALOG_PATH, GOOGLE_TRENDS_CATALOG_TASK, google_trends_catalog,
    run_agentic_task_with_tools,
};

fn main() {
    let document = google_trends_catalog::render_document();
    let mut arguments = std::env::args_os().skip(1);
    let Some(output) = arguments.next() else {
        print!("{document}");
        return;
    };
    assert!(arguments.next().is_none(), "one output directory is accepted");
    let output = std::path::PathBuf::from(output);
    std::fs::create_dir(&output).expect("a fresh output directory is required");

    // Only the task and advertised tools are inputs. Never reuse captured
    // outputs, command receipts, or final answers when generating a session.
    let path = "docs/case-studies/issue-498/agent-cli-session-google-trends.json";
    let captured: serde_json::Value =
        serde_json::from_slice(&std::fs::read(path).expect("read pinned session inputs"))
            .expect("parse pinned session inputs");
    assert_eq!(captured["task"].as_str(), Some(GOOGLE_TRENDS_CATALOG_TASK));
    let tools: Vec<&str> = captured["tools_advertised"]
        .as_array()
        .expect("pinned advertised tools")
        .iter()
        .map(|tool| tool.as_str().expect("tool name"))
        .collect();
    let fresh = run_agentic_task_with_tools(GOOGLE_TRENDS_CATALOG_TASK, &tools)
        .expect("execute the native catalog driver");
    assert!(!fresh.hit_turn_cap, "catalog driver reached its turn cap");
    let session = format!(
        "{}\\n",
        serde_json::to_string_pretty(&fresh.session_json()).expect("serialize actual session")
    );
    for (path, content) in [(GOOGLE_TRENDS_CATALOG_PATH, document), (path, session)] {
        let target = output.join(path);
        std::fs::create_dir_all(target.parent().expect("fixture parent"))
            .expect("create fixture parent");
        std::fs::write(target, content).expect("write generated fixture");
        println!("wrote {path}");
    }
}
''');changed.append(str(p))
p=Path('.github/workflows/native-type-check.yml');text=p.read_text();text+='''      - name: Stage deterministic Google Trends fixtures from the native driver
        if: ${{ !cancelled() && inputs.compile-inputs-changed && steps.native-lint.outcome == 'success' }}
        env:
          CARGO_BUILD_JOBS: '2'
          CARGO_PROFILE_DEV_OPT_LEVEL: '0'
          FORMAL_AI_OFFLINE: '1'
          CATALOG_OUTPUT: ${{ runner.temp }}/google-trends-fixtures
        run: |
          cargo build --manifest-path rust/Cargo.toml --locked --example dump_google_trends_catalog
          rust/target/debug/examples/dump_google_trends_catalog "$CATALOG_OUTPUT"
          {
            git rev-parse HEAD HEAD^{tree}
            rustc -vV
            sha256sum rust/target/debug/examples/dump_google_trends_catalog rust/examples/dump_google_trends_catalog.rs rust/src/google_trends_catalog.rs data/seed/google-trends-prompts.lino
          } > "$CATALOG_OUTPUT/generation-identity.txt"
      - name: Retain actual Google Trends fixture projections
        if: ${{ !cancelled() && inputs.compile-inputs-changed && steps.native-lint.outcome == 'success' }}
        uses: actions/upload-artifact@v7
        with:
          name: google-trends-native-fixtures
          path: ${{ runner.temp }}/google-trends-fixtures
          if-no-files-found: error
          retention-days: 7
''';p.write_text(text);changed.append(str(p))
p=Path('rust/tests/web/default-branch-build-policy.test.mjs');p.write_text(p.read_text()+'''

test('catalog snapshots and native projection inputs select the complete generation lane', {timeout:15000}, () => {
  for (const path of ['rust/tests/unit/issue_498_google_trends.rs',
    'rust/examples/dump_google_trends_catalog.rs', 'data/seed/google-trends-prompts.lino'])
    assert.equal(admission([path])['native-type-check'], true, path);
  assert.equal(admission(['rust/examples/unrelated.rs'])['native-type-check'], false);
  assert(read('rust/tests/unit/reasoning_contracts.rs')
    .includes('#[path = "issue_498_google_trends.rs"]'));
  const steps = Object.values(workflow('native-type-check.yml').jobs)[0].steps;
  const producer = steps.find(step => step.name === 'Stage deterministic Google Trends fixtures from the native driver');
  assert.equal(producer.env.FORMAL_AI_OFFLINE, '1');
  assert.match(producer.run, /cargo build [^\\n]*--example dump_google_trends_catalog/u);
  assert.match(producer.run, /rust\\/target\\/debug\\/examples\\/dump_google_trends_catalog "\\$CATALOG_OUTPUT"/u);
  assert.match(producer.run, /git rev-parse HEAD HEAD\\^\\{tree\\}/u);
  assert.match(producer.run, /sha256sum rust\\/target\\/debug\\/examples\\/dump_google_trends_catalog/u);
  const artifact = steps.find(step => step.name === 'Retain actual Google Trends fixture projections');
  assert.equal(artifact.with.name, 'google-trends-native-fixtures');
  assert.equal(artifact.with['if-no-files-found'], 'error');
  assert.equal(artifact.with.path, '${{ runner.temp }}/google-trends-fixtures');
});
''');changed.append(str(p))
p=Path('changelog.d/issue-1580-deterministic-trends.md');p.write_text('''fix: Keep Google Trends snapshot answers offline, include Spanish prompt variants, and stage fresh native catalog/session projections for byte-for-byte fixture replay.\n''');changed.append(str(p))
print(json.dumps({'drafted':changed,'nativeFixturesRegenerated':False,'allIssueCriteriaComplete':False}))
