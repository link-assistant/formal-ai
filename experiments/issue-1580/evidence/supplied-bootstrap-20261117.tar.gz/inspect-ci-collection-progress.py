from pathlib import Path
import json,subprocess
base=Path('experiments/issue-1580/evidence/ci/main-444575f2')
p=base/'push-runs.json'
if p.exists():
    rows=json.loads(p.read_text())
    print('PUSH RUNS',json.dumps(rows,indent=2))
print('FILES',json.dumps([{ 'name':p.name,'bytes':p.stat().st_size} for p in base.iterdir()]))
print(subprocess.check_output(['ps','-eo','pid,ppid,etimes,rss,args'],text=True).split('COMMAND')[-1][-1500:])
g=Path('/tmp/issue-1580-research/merged-444575f2-all-local-gates.log')
if g.exists():
    print('GATE TAIL',g.read_text()[-1800:])
