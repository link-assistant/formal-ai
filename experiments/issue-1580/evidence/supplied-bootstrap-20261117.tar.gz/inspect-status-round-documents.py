from pathlib import Path
import json

root = Path('/tmp/gh-issue-solver-1794900398048')
for relative in ['experiments/issue-1580/work-plan.md', 'docs/case-studies/issue-1580/task-quotation-checkpoint.md', 'experiments/issue-1580/evidence/checks/decoded-grammar-values/pull-request-description.md']:
    lines = (root / relative).read_text().splitlines()
    print(f'FILE {relative} ({len(lines)} lines)')
    selected = set()
    if 'checkpoint' in relative or 'description' in relative:
        selected = set(range(len(lines)))
    else:
        for index, line in enumerate(lines):
            if any(word in line.lower() for word in ['parent coverage qualification', 'unverified-child', 'decoded native', 'decoded grammar', '78/254', '87/254', '73–78', '73-78']):
                selected.update(range(max(0,index-2), min(len(lines),index+13)))
    for index in sorted(selected):
        print(f'{index+1}: {lines[index]}')

base = Path('/tmp/issue-1580-research/unverified-child-status-final')
for name in ['process.json', 'progress.json', 'fixture-preservation.json']:
    path = base / name
    if path.exists():
        print(name)
        print(path.read_text())
