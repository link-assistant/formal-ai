from pathlib import Path
import datetime,gzip,json,subprocess
head='015a683197c89e8f74375b097e8dd06a57dcea8f'
base=Path('/tmp/issue-1580-research/main-015a6831-runs');base.mkdir(exist_ok=True)
raw=subprocess.check_output(['gh','run','list','--repo','link-assistant/formal-ai','--branch','main','--limit','100','--json','databaseId,workflowName,status,conclusion,createdAt,updatedAt,headSha,event'])
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
(base/(stamp+'.json.gz')).write_bytes(gzip.compress(raw,mtime=0))
rows=[row for row in json.loads(raw) if row['headSha']==head]
print(json.dumps({'capturedAt':stamp,'head':head,'total':len(rows),'completed':sum(row['status']=='completed' for row in rows),'success':sum(row['conclusion']=='success' for row in rows),'active':[row for row in rows if row['status']!='completed'],'nonpassing':[row for row in rows if row['status']=='completed' and row['conclusion']!='success']},indent=2))
