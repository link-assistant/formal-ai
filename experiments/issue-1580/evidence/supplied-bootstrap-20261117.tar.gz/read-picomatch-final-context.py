from pathlib import Path
import json

root = Path('/tmp/gh-issue-solver-1794900398048')
for relative in ['packages/picomatch-compat/README.md', 'packages/picomatch-compat/upstream.json', 'experiments/issue-1580/picomatch-parser-probe.mjs', 'experiments/issue-1580/picomatch-consumer-probe.mjs', 'rust/tests/web/picomatch-security-backport.test.mjs']:
    path = root / relative
    print('\nFILE:', relative)
    for number, line in enumerate(path.read_text().splitlines(), 1):
        print(f'{number}: {line}')
print('\nRESEARCH SCRIPTS')
for path in sorted(Path('/tmp/issue-1580-research').glob('*picomatch*')):
    print(path)
