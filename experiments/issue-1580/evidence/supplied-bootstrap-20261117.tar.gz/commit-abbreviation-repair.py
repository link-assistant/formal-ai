from pathlib import Path
import json,subprocess
def run(args): return subprocess.run(args,check=True,text=True,capture_output=True).stdout
assert run(['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
base=Path('experiments/issue-1580/evidence/checks/csharp-changeset-collision')
receipt=json.loads((base/'abbreviation-filename-correction.json').read_text())
assert len(receipt['after'])==4 and all(row['exitCode']==0 for row in receipt['after'])
receipt['reviewHarnessCorrection']='The first metadata-review script indexed a lines key on historical inventory records that do not define line counts. It stopped with KeyError before any changes. The corrected optional-key comparison passes and preserves every existing blob/hash/byte/line field; no source or test repair was needed.'
(base/'abbreviation-filename-correction.json').write_text(json.dumps(receipt,indent=2)+'\n')
files=['experiments/issue-1580/evidence/ci/0f90c0a7a',str(base/'abbreviation-filename-correction.json'),str(base/'abbreviation-before.log.gz'),str(base/'abbreviation-regression-after.log.gz'),str(base/'check-abbreviations-after.log.gz'),str(base/'check-file-size-after.log.gz'),str(base/'check-file-size-js-twin-after.log.gz'),'experiments/issue-1580/evidence/checks/csharp-changeset-integrity.json']
run(['git','add','--',*files])
run(['git','diff','--cached','--check'])
print(run(['git','diff','--cached','--stat']))
print(run(['git','commit','-m','fix: spell out the C# evidence reporter filename']))
print('LOCAL COMMIT',run(['git','rev-parse','HEAD']).strip())
