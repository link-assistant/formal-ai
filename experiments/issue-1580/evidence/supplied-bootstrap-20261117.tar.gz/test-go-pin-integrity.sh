set -eu
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-go-result-integrity.test.mjs > /tmp/issue-1580-research/go-pin-integrity.log 2>&1
cat /tmp/issue-1580-research/go-pin-integrity.log
