from pathlib import Path
import gzip, hashlib, json, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
out = root / 'experiments/issue-1580/evidence/ci/native-b367d603'
run_id = sys.argv[1] if len(sys.argv) > 1 else '44220008975'
assert run_id in ('44220008975', '44220008509')
prefix = 'pipeline' if run_id == '44220008975' else 'layered'
run = subprocess.run(['gh', 'run', 'view', run_id, '--repo', 'link-assistant/formal-ai', '--log'], cwd=root, capture_output=True)
assert run.returncode == 0, run.stderr.decode()
raw = run.stdout
(out / (prefix + '-' + run_id + '.log.gz')).write_bytes(gzip.compress(raw, mtime=0))
print('RUN_LOG', len(raw), len(raw.splitlines()), hashlib.sha256(raw).hexdigest())
jobs = subprocess.run(['gh', 'api', 'repos/link-assistant/formal-ai/actions/runs/' + run_id + '/jobs?per_page=100', '--paginate', '--slurp'], cwd=root, capture_output=True)
assert jobs.returncode == 0, jobs.stderr.decode()
(out / (prefix + '-jobs.json.gz')).write_bytes(gzip.compress(jobs.stdout, mtime=0))
for page in json.loads(jobs.stdout):
    for job in page['jobs']:
        if job['conclusion'] not in ('success', 'skipped'):
            print('JOB', json.dumps({k:job[k] for k in ('id','name','conclusion','started_at','completed_at')}))
            result = subprocess.run(['gh','api','repos/link-assistant/formal-ai/actions/jobs/' + str(job['id']) + '/logs','--allow-escape-sequences'],cwd=root,capture_output=True)
            assert result.returncode == 0, result.stderr.decode()
            (out / ('job-' + str(job['id']) + '.log.gz')).write_bytes(gzip.compress(result.stdout,mtime=0))
            print('JOB_LOG', len(result.stdout), len(result.stdout.splitlines()), hashlib.sha256(result.stdout).hexdigest())
            lines = result.stdout.decode().splitlines()
            markers = [n for n,line in enumerate(lines) if any(token in line.lower() for token in ('error:', 'error ', 'failed', 'fatal:', 'panic', 'exit code'))]
            selected = set()
            for n in markers:
                selected.update(range(max(0,n-3),min(len(lines),n+5)))
            for n in sorted(selected):
                print(str(n+1) + ': ' + lines[n])
