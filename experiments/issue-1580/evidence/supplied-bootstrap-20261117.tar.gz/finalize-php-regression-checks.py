from pathlib import Path
import subprocess,json,gzip,hashlib
base=Path('experiments/issue-1580/evidence/checks/php-release-guard')
report=json.loads((base/'results.json').read_text())
commands=[('final-focused-tests','experiments/issue-1580/template-php-release-integrity.test.mjs'),('final-maintained-tests','rust/tests/web/issue-1580-template-observations.test.mjs')]
for name,file in commands:
    command=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',file]
    result=subprocess.run(command,capture_output=True)
    raw=result.stdout+result.stderr;archive=gzip.compress(raw,mtime=0)
    (base/(name+'.log.gz')).write_bytes(archive)
    row={'name':name,'command':command,'exitCode':result.returncode,'bytes':len(raw),'lines':len(raw.splitlines()),'sha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(archive).hexdigest()}
    report['checks'].append(row)
    print(json.dumps(row),flush=True)
report['complete']=all(item['exitCode']==0 for item in report['checks'] if item['name']!='affected-gates')
(base/'results.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(0 if report['complete'] else 1)
