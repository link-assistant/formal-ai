from pathlib import Path
import json,subprocess
for a in [['git','branch','--show-current'],['git','status','--short']]:
 p=subprocess.run(a,capture_output=True,text=True);print(p.stdout);assert p.returncode==0
for n in ['latest.json','outcome.json']:
 p=Path('experiments/issue-1580/evidence/ci/calendar-clock-070b9748')/n
 print(n)
 if p.exists():
  j=json.loads(p.read_text());j.pop('runs',None);print(json.dumps(j,indent=2))
 else:print('MISSING')
