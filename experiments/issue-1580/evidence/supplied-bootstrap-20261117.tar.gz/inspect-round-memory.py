from pathlib import Path
import json
import subprocess

root=Path("/sys/fs/cgroup")
limit=int((root/"memory.max").read_text())
current=int((root/"memory.current").read_text())
stats=dict(line.split() for line in (root/"memory.stat").read_text().splitlines())
print(json.dumps({"limit":limit,"current":current,"available":limit-current,"memory":{key:int(stats.get(key,0)) for key in ["anon","file","kernel","shmem","inactive_file","active_file","file_dirty","file_writeback"]}}))
result=subprocess.run(["ps","-eo","pid,ppid,rss,stat,comm","--sort=-rss"],capture_output=True,text=True,check=True)
print("\n".join(result.stdout.splitlines()[:12]))
