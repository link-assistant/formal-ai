from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,gzip,hashlib,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/language-main-publication-preflight';scratch=Path('/tmp/issue-1580-research/language-main-publication-preflight')
if len(sys.argv)==1:
 base.mkdir(exist_ok=False);scratch.mkdir(exist_ok=False)
 with (scratch/'worker.log').open('wb') as f:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid}));sys.exit(0)
rows=[]
commands=[('branch',['git','branch','--show-current']),('fetch-main',['git','-c','gc.auto=0','fetch','origin','main']),('main',['git','rev-parse','origin/main']),('recent-runs',['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','50','--json','databaseId,workflowName,conclusion,status,createdAt,headSha']),('pr',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','url,title,body,isDraft,headRefOid,baseRefName,mergeStateStatus']),('issue',['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','url,title,body,state']),('issue-comments',['gh','api','repos/link-assistant/formal-ai/issues/1580/comments?per_page=100','--paginate','--slurp']),('pr-comments',['gh','api','repos/link-assistant/formal-ai/issues/1581/comments?per_page=100','--paginate','--slurp']),('inline-comments',['gh','api','repos/link-assistant/formal-ai/pulls/1581/comments?per_page=100','--paginate','--slurp']),('reviews',['gh','api','repos/link-assistant/formal-ai/pulls/1581/reviews?per_page=100','--paginate','--slurp']),('sub-issues',['gh','api','repos/link-assistant/formal-ai/issues/1580/sub_issues?per_page=100','--paginate','--slurp'])]
try:
 for label,argv in commands:
  p=subprocess.run(argv,cwd=root,capture_output=True);raw=p.stdout;err=p.stderr
  (base/(label+'.stdout.gz')).write_bytes(gzip.compress(raw,mtime=0));(base/(label+'.stderr.gz')).write_bytes(gzip.compress(err,mtime=0))
  rows.append({'name':label,'argv':argv,'exitCode':p.returncode,'stdoutSha256':hashlib.sha256(raw).hexdigest(),'stderrSha256':hashlib.sha256(err).hexdigest(),'stdoutBytes':len(raw),'stderrBytes':len(err)})
  (base/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True);assert p.returncode==0,(label,err.decode())
 (base/'outcome.json').write_text(json.dumps({'complete':True,'observedAt':datetime.now(timezone.utc).isoformat(),'records':rows},indent=2)+'\n')
except BaseException:traceback.print_exc();sys.exit(1)
