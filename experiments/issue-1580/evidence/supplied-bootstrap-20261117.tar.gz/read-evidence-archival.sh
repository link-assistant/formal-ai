set -eu
sed -n '1,240p' /tmp/issue-1580-research/capture-round.py
sed -n '1,220p' experiments/issue-1580/archive-evidence.py
cat /tmp/issue-1580-research/file-size-sixth.log
git diff --stat
