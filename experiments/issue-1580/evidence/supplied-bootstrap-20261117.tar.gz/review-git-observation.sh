set -eu
git diff -- scripts/detect-code-changes.rs
sed -n '172,217p' .github/workflows/layered-ci.yml
rg --files rust/tests/web | rg '(change|admission|output|release-pending)'
rustfmt --edition 2024 scripts/detect-code-changes.rs
wc -l scripts/detect-code-changes.rs
