from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json

source = Path('/tmp/issue-1580-research/decoded-grammar-publication-corrected')
receipt_path = source / 'verification.json'
receipt = json.loads(receipt_path.read_text())
assert receipt['publicationVerified']
assert receipt['head'] == 'b26f5eebd3393b145c8693e985c8db24248380ad'
patches = source / 'code-commit-api-patches.txt'
assert patches.is_file() and len(patches.read_text().splitlines()) <= 260
states = {}
for pid in [1080429, 1081363]:
    stat = Path(f'/proc/{pid}/stat')
    state = stat.read_text().split(') ', 1)[1].split()[0] if stat.exists() else 'absent'
    assert state in ['Z', 'absent'], (pid, state)
    states[str(pid)] = state
receipt.update({
    'literalApiPatchReviewComplete': True,
    'literalApiPatchReviewedAt': datetime.now(timezone.utc).isoformat(),
    'literalApiPatchReviewMethod': 'All five complete commit API patches read through Formal AI driver; published blob hashes already matched local HEAD.',
    'reviewedPatchSha256': hashlib.sha256(patches.read_bytes()).hexdigest(),
    'wholePullRequestLiteralReviewClaimed': False,
    'publicationWorkersFinished': states,
})
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
destination = Path('experiments/issue-1580/evidence/ci/decoded-grammar-b26f5eeb/publication')
destination.mkdir(parents=True, exist_ok=True)
entries = []
for path in sorted(source.rglob('*')):
    if not path.is_file():
        continue
    raw = path.read_bytes()
    assert len(raw) < 24 * 1024 * 1024, path
    relative = path.relative_to(source)
    target = destination / (str(relative) + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(raw, mtime=0)
    assert gzip.decompress(packed) == raw
    target.write_bytes(packed)
    entries.append({'source': str(relative), 'file': str(target.relative_to(destination)), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'archivedSha256': hashlib.sha256(packed).hexdigest()})
manifest = {'head': receipt['head'], 'publicationVerified': True, 'incrementalCodeApiPatchesLiterallyReviewed': 5, 'wholePullRequestLiteralReviewClaimed': False, 'files': entries}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'head': receipt['head'], 'publicationWorkersFinished': states, 'incrementalCodeApiPatchesLiterallyReviewed': 5, 'archivedFiles': len(entries), 'wholePullRequestLiteralReviewClaimed': False, 'fullIssueComplete': False}, indent=2))
