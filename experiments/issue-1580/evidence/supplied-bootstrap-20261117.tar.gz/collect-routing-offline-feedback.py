from pathlib import Path
from datetime import datetime,timezone
import subprocess,json
b=Path('/tmp/issue-1580-research/routing-offline-feedback');b.mkdir(exist_ok=False)
for label,endpoint in [('issue-comments','issues/1580/comments'),('conversation-comments','issues/1581/comments'),('inline-comments','pulls/1581/comments'),('reviews','pulls/1581/reviews')]:
 p=subprocess.run(['gh','api','repos/link-assistant/formal-ai/'+endpoint,'--paginate'],capture_output=True);(b/(label+'.json')).write_bytes(p.stdout);(b/(label+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,p.stderr;rows=json.loads(p.stdout);print(label,len(rows))
 for row in rows:
  print(json.dumps({key:row.get(key)for key in ['id','html_url','user','created_at','updated_at','submitted_at','body','state']}))
(b/'observed-at.txt').write_text(datetime.now(timezone.utc).isoformat()+'\n')
