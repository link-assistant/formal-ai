from pathlib import Path
import subprocess,json
for args in [['git','branch','--show-current'],['git','-c','gc.auto=0','fetch','origin','main'],['git','rev-parse','origin/main'],['git','merge-base','--is-ancestor','origin/main','HEAD']]:
 p=subprocess.run(args,capture_output=True,text=True)
 print(json.dumps({'argv':args,'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}))
 assert p.returncode==0
base=Path('/tmp/issue-1580-research/unknown-role-native-validation')
for name in ['outcome.json','failure.json']:
 p=base/name
 if p.exists():print(name,p.read_text())
p=base/'all-local-gates.log'
lines=p.read_text().splitlines()
print('LATEST_GATE_LINES',len(lines))
for n,line in enumerate(lines[-12:],len(lines)-11):print(f'{n}: {line}')
