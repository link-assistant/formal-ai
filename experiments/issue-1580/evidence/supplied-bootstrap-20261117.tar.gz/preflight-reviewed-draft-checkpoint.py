from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
base=Path('experiments/issue-1580/evidence/checks/main-merge-058e9bef/publication')
base.mkdir(parents=True,exist_ok=True)
def run(args):return subprocess.check_output(args)
branch=run(['git','branch','--show-current']).decode().strip()
assert branch=='issue-1580-8d61a32a61e1'
head=run(['git','rev-parse','HEAD']).decode().strip()
pr=json.loads(run(['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','headRefOid,isDraft,title,body,url']))
remote=pr['headRefOid']
commands=[
 ('latest-branch-runs',['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--limit','5','--json','databaseId,conclusion,createdAt,headSha,status,workflowName']),
 ('in-progress-runs',['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--status','in_progress','--json','databaseId,workflowName,headSha']),
 ('queued-runs',['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--status','queued','--json','databaseId,workflowName,headSha']),
 ('remote-head-push-runs',['gh','api','--paginate','--slurp',f'repos/link-assistant/formal-ai/actions/runs?head_sha={remote}&event=push&per_page=100']),
 ('issue-comments',['gh','api','--paginate','--slurp','repos/link-assistant/formal-ai/issues/1580/comments?per_page=100']),
 ('pull-request-comments',['gh','api','--paginate','--slurp','repos/link-assistant/formal-ai/issues/1581/comments?per_page=100']),
 ('pull-request-inline-comments',['gh','api','--paginate','--slurp','repos/link-assistant/formal-ai/pulls/1581/comments?per_page=100']),
 ('pull-request-reviews',['gh','api','--paginate','--slurp','repos/link-assistant/formal-ai/pulls/1581/reviews?per_page=100']),
]
records=[]
for name,args in commands:
    raw=run(args);data=json.loads(raw)
    (base/(name+'.json.gz')).write_bytes(gzip.compress(raw,mtime=0))
    records.append({'kind':name,'rawSha256':hashlib.sha256(raw).hexdigest()})
    if name in ['in-progress-runs','queued-runs']:
        print(name,json.dumps(data));assert not data
    elif name=='remote-head-push-runs':
        rows=[r for page in data for r in page['workflow_runs']]
        print('REMOTE HEAD',remote,'PUSH RUNS',len(rows))
        for r in rows:print(r['id'],r['name'],r['status'],r['conclusion'],r['created_at'])
    elif name=='latest-branch-runs':print(name,json.dumps(data))
    else:
        rows=[r for page in data for r in page]
        print(name,'COUNT',len(rows),'LATEST',json.dumps({k:rows[-1].get(k) for k in ['id','created_at','updated_at','html_url']} if rows else {}))
(base/'pull-request-state.json.gz').write_bytes(gzip.compress(json.dumps(pr,indent=2).encode(),mtime=0))
receipt={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'localHead':head,'remoteHead':remote,'branch':branch,'records':records,'draft':pr['isDraft'],'scope':'Draft checkpoint preflight; no completion or default-branch freshness assertion.'}
(base/'preflight-index.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
