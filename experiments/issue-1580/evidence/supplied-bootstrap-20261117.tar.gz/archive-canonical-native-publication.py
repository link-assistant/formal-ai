from pathlib import Path
import gzip,hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research/canonical-native-publication');base=root/'experiments/issue-1580/evidence/checks/canonical-native-publication';base.mkdir(exist_ok=False)
outcome=json.loads((scratch/'outcome.json').read_text());assert outcome['complete'] and outcome['pushExecuted'] and outcome['head']=='2c9d93c5c61b5a8372f3e7634db1a979085d3c64';records=[]
for row in outcome['records']:
 record=dict(row)
 for stream in ['stdout','stderr']:
  raw=(scratch/(row['name']+'.'+stream)).read_bytes();assert hashlib.sha256(raw).hexdigest()==row[stream+'Sha256'];packed=gzip.compress(raw,mtime=0);name=row['name'].replace('incremental-diff-stat','incremental-diff-statistics')+'.'+stream+'.gz';(base/name).write_bytes(packed);record[stream]={'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'lines':len(raw.splitlines())}
 records.append(record)
outcome['records']=records;outcome['allPayloadHashesVerified']=True;outcome['allPayloadsLiterallyRead']=False;outcome['independentAuthorshipCredit']=0;outcome['fullIssueComplete']=False
(base/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
limitation=(scratch/'whole-pull-request-diff-limitation.json');assert limitation.exists();(base/limitation.name).write_bytes(limitation.read_bytes())
print(json.dumps({'head':outcome['head'],'records':len(records),'allPayloadHashesVerified':True,'allPayloadsLiterallyRead':False,'publishedAt':outcome['observedAt']}))
