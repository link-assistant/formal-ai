set -eu
PATH="/tmp/issue-1580-research/shellcheck-v0.11.0:$PATH" node experiments/formal_ai_subagent/local-gates.mjs --only 'layered-ci#4,layered-ci#5,layered-ci#6,links,question-necessity-ratchet,release-staged#1,release#1,release#2,release#3,security,self-development-status#1,self-development-status#3,web-ui-boundary' > /tmp/issue-1580-research/all-local-gates-fourth-remainder.log 2>&1
tail -n 18 /tmp/issue-1580-research/all-local-gates-fourth-remainder.log
git diff --check
