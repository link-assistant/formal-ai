from pathlib import Path
p=Path('rust/tests/web/default-branch-build-policy.test.mjs');s=p.read_text();s+='''

test('external lookup fixture contracts execute in the focused native lane', {timeout:15000}, () => {
  const path = 'rust/tests/unit/issue_1173_fallback_executes_search.rs';
  assert.equal(nativeCompileInput(path), true, path);
  assert(read('rust/tests/unit/reasoning_contracts.rs')
    .includes('#[path = "issue_1173_fallback_executes_search.rs"]'));
  assert(read('rust/tests/unit/reasoning_contracts.rs').includes('mod external_search_fallback;'));
});
''';p.write_text(s)
