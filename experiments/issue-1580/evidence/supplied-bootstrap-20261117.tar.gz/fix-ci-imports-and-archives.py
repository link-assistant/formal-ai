from pathlib import Path
import gzip
import hashlib
import json

for name in ['compare-template-trees.mjs', 'trace-template-ci.mjs']:
    path = Path('experiments/issue-1580') / name
    text = path.read_text()
    assert "import {parse} from 'yaml';" in text
    text = text.replace("import {parse} from 'yaml';", "import {createRequire} from 'node:module';\nconst {parse} = createRequire(import.meta.url)('yaml');")
    if name == 'trace-template-ci.mjs':
        text = text.replace("import {fileURLToPath} from 'node:url';", "import {fileURLToPath} from 'node:url';\nimport {gzipSync} from 'node:zlib';")
        text = text.replace("language+'-ci-reference-graph.json'),JSON.stringify({repository:source.repo,commit:source.sha,...graph},null,2)+'\\n'", "language+'-ci-reference-graph.json.gz'),gzipSync(JSON.stringify({repository:source.repo,commit:source.sha,...graph},null,2)+'\\n',{mtime:0})")
    path.write_text(text)

folder = Path('experiments/issue-1580/evidence/chrono-upstream')
old_index = json.loads((folder / 'sha256.json').read_text())
print('Previous registry evidence index:', json.dumps(old_index))
for name in ['command-stream-registry.json', 'link-calculator-registry.json']:
    path = folder / name
    original = path.read_bytes()
    compressed = gzip.compress(original, mtime=0)
    assert gzip.decompress(compressed) == original
    path.with_suffix('.json.gz').write_bytes(compressed)
    path.unlink()
rows = []
for path in sorted(folder.iterdir()):
    if path.name == 'sha256.json':
        continue
    content = path.read_bytes()
    row = {'path': path.name, 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}
    if path.suffix == '.gz':
        original = gzip.decompress(content)
        row.update(uncompressedBytes=len(original), uncompressedSha256=hashlib.sha256(original).hexdigest())
    rows.append(row)
(folder / 'sha256.json').write_text(json.dumps(rows, indent=2) + '\n')
for path in Path('docs/case-studies/issue-1580/templates').glob('*-ci-reference-graph.json'):
    original = path.read_bytes()
    path.with_suffix('.json.gz').write_bytes(gzip.compress(original, mtime=0))
    path.unlink()
