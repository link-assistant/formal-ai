from pathlib import Path
p=Path('js/worker/formal_ai_worker_concept_queries_and_arithmetic.js')
s=p.read_text(); old='/[?。.!!,,;:]+$/g'
assert old in s
p.write_text(s.replace(old, '/[?？。.！!,，;；:：]+$/g'))
p=Path('rust/tests/web/issue-1580-production-composition.test.mjs')
s=p.read_text().replace("assert.equal(query.term, 'redis', prompt);", "assert.ok(query, prompt);\n    assert.equal(query.term, 'redis', prompt);")
p.write_text(s)
