from pathlib import Path
import collections,hashlib,json
root=Path("/tmp/issue-1580-research/templates/python-complete")
path=Path("docs/case-studies/issue-1580/templates/python-partial-semantic-review.json")
review=json.loads(path.read_text())
inventory=json.loads(Path("/tmp/issue-1580-research/python-active-source-inventory.json").read_text())
active={row["path"]:row for row in inventory["active"]}
deferred={".github/actions/artifact/dist/835.index.mjs",".github/actions/artifact/dist/index.mjs",".github/actions/artifact/package-lock.json","uv.lock"}
selected=[(row["path"],n) for row in inventory["active"] if row["path"] not in deferred for n in range(1,row["lines"]+1)]
assert len(selected)==21394
ranges=collections.defaultdict(set)
for row in review["files"]:
    for first,last in row["readRanges"]:ranges[row["path"]].update(range(first,last+1))
for name,n in selected[:11200]:ranges[name].add(n)
decisions={
 "scripts/preflight-credentials.sh":"Read all 347 lines: finite Docker/PyPI authorization probes, write-scope cancellation attempt, report/release exit rules and refusal/unknown counters. No credentials, provider writes or probe execution is claimed. Partial-unknown release policy, HTTP-200 token shape and cancellation-result wording remain inspection questions requiring controls before a defect claim.",
 "scripts/publish_to_pypi.py":"Read all 172 lines: clean/build/twine checks, shared distribution budget before both dry-run and upload, skip-existing upload and fatal tool/build/check failures. No package installation, build, credential flow, OIDC exchange or publication was executed. Existing Formal AI artifact identity and publication policy remains authoritative.",
 "scripts/read-job-cancel-in-progress.sh":"Read all 96 lines: workflow/job concurrency inheritance, exact boolean versus expression unknown, missing-job sentinel and unreadable-file refusal. This is a bounded indentation-aware scalar reader, not a general YAML parser. No fresh runtime behavior is claimed.",
 "scripts/read_manifest.py":"Read all 76 lines: TOML table traversal, missing/non-string/read/parse refusal and optional GitHub output emission. This replaces flat-text version scraping without claiming a complete manifest-schema validator. No fresh runtime execution is claimed.",
 "scripts/recheck_broken_links.py":"Read only lines 1-138: finite shared/request budgets, typed lychee failures, retryable transport/429/5xx distinction and accept-range/user-agent extraction. Remaining retry, provider-authentication and output code is unread; no network/runtime result is claimed.",
}
for row in review["files"]:
    assert hashlib.sha256((root/row["path"]).read_bytes()).hexdigest()==row["sha256"]
    if row["path"] not in active:continue
    numbers=sorted(ranges[row["path"]]);merged=[]
    for n in numbers:
        if merged and merged[-1][1]+1==n:merged[-1][1]=n
        else:merged.append([n,n])
    row["readRanges"]=merged
    row["reviewStatus"]="active-source-fully-read" if len(numbers)==row["lines"] else "active-source-partially-read" if numbers else "active-source-unread"
    if row["path"] in decisions:row["decision"]=decisions[row["path"]]
counts=collections.Counter(row["reviewStatus"] for row in review["files"])
review["counts"]={key:counts[key] for key in review["counts"]}
oldlines=review["activeReadLines"];review["activeReadLines"]=sum(len(ranges[name]) for name in active)
assert oldlines==11159 and review["activeReadLines"]==11959
review["readMethod"]=review["readMethod"].replace("pages 1-26","pages 1-28")
header={k:v for k,v in review.items() if k!="files"}
path.write_text(json.dumps(header,indent=2)[:-2]+',\n  "files": [\n'+',\n'.join("    "+json.dumps(row,ensure_ascii=False,separators=(",",":")) for row in review["files"])+'\n  ]\n}\n')
old="The Python review now fully reads 147 active files plus one partial file (11,159/44,284 active lines), through corrected pages 1-26 and separately read release/helper tests. The 55 unread active files"
new=f'The Python review now fully reads {counts["active-source-fully-read"]} active files plus one partial file (11,959/44,284 active lines), through corrected pages 1-28 and separately read release/helper tests. The {counts["active-source-unread"]} unread active files'
for name in ["docs/case-studies/issue-1580/README.md","docs/case-studies/issue-1580/templates/README.md","experiments/issue-1580/work-plan.md"]:
    p=Path(name);text=p.read_text();assert text.count(old)==1;p.write_text(text.replace(old,new))
print(json.dumps({"counts":review["counts"],"activeReadLines":review["activeReadLines"],"nextPage":29,"completeReviewClaimed":False},indent=2))
