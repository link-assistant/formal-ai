from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
out=Path('/tmp/issue-1580-research/header-push');out.mkdir(exist_ok=True)
def run(args):
 p=subprocess.run(args,text=True,capture_output=True)
 if p.returncode:raise RuntimeError(str(args)+' '+p.stderr)
 return p.stdout
branch='issue-1580-8d61a32a61e1';head='d0b8b895661c6b5e809810c4da8a3db9f79138b3';old='1cc2d536ac11e26602cc55a40dffb61716233aa6'
assert run(['git','branch','--show-current']).strip()==branch
assert run(['git','rev-parse','HEAD']).strip()==head
assert not run(['git','status','--porcelain']).strip()
run(['git','fetch','origin','main'])
assert run(['git','rev-parse','origin/main']).strip()=='512ce428029a92687628b4180309ee5ab660fe08'
subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],check=True)
assert run(['git','ls-remote','origin','refs/heads/'+branch]).split()[0]==old
record={'head':head,'previousHead':old,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'feedback':{},'activeRuns':{}}
for suffix,name in [('issues/1580/comments','feedback-issue-comments'),('issues/1581/comments','feedback-pull-request-comments'),('pulls/1581/comments','feedback-inline-comments'),('pulls/1581/reviews','feedback-reviews')]:
 raw=run(['gh','api','repos/link-assistant/formal-ai/'+suffix,'--paginate'])
 rows=json.loads(raw);prev=json.loads(gzip.decompress((Path('/tmp/issue-1580-research/header-round-preflight')/(name+'.json.gz')).read_bytes()))
 assert [(r['id'],r.get('body'),r.get('state')) for r in rows]==[(r['id'],r.get('body'),r.get('state')) for r in prev],name+' changed; read before pushing'
 (out/(name+'.json.gz')).write_bytes(gzip.compress(raw.encode(),mtime=0))
 record['feedback'][name]=len(rows)
for status in ['in_progress','queued']:
 rows=json.loads(run(['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--status',status,'--limit','100','--json','databaseId,workflowName,headSha,createdAt']))
 record['activeRuns'][status]=rows
 assert not rows,rows
runs=json.loads(run(['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--commit',old,'--limit','100','--json','databaseId,workflowName,status,conclusion,headSha,createdAt']))
assert len(runs)==24 and all(r['headSha']==old and r['status']=='completed' and r['conclusion']=='success' for r in runs)
record['previousHeadSuccessfulWorkflows']=len(runs)
(out/'previous-head-runs.json').write_text(json.dumps(runs,indent=2)+'\n')
(out/'preflight.json').write_text(json.dumps(record,indent=2)+'\n')
p=subprocess.run(['git','push','origin','HEAD:refs/heads/'+branch],text=True,capture_output=True)
(out/'push.log').write_text(p.stdout+p.stderr)
assert p.returncode==0,p.stderr
assert run(['git','ls-remote','origin','refs/heads/'+branch]).split()[0]==head
record['pushedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(out/'completion.json').write_text(json.dumps(record,indent=2)+'\n')
assert not run(['git','status','--porcelain']).strip()
print(json.dumps(record,indent=2))
print('https://github.com/link-assistant/formal-ai/pull/1581')
