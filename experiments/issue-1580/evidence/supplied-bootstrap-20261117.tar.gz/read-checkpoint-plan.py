from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
names=['AGENTS.md','CONTRIBUTING.md','experiments/issue-1580/work-plan.md','docs/case-studies/issue-1580/README.md','docs/case-studies/issue-1580/runtime-fixture-checkpoint.md','docs/case-studies/issue-1580/templates/java-historical-partial-review.json']
for name in names:
    path=root/name
    if not path.exists():
        print('MISSING',name);continue
    lines=path.read_text().splitlines()
    print('\nFILE',name,'LINES',len(lines))
    assert len(lines)<=1500
    for number,line in enumerate(lines,1):print(f'{number}: {line}')
