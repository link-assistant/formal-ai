import gzip,re

starts=[51312,57802,57828,57859,57889,57919,57949,57983,82129,82161,82189,82217,82245,82277]
wanted={line for start in starts for line in range(start,start+5)}
with gzip.open('experiments/issue-1580/evidence/ci/main-512ce428/44117975432.log.gz','rt') as stream:
 for number,line in enumerate(stream,1):
  if number not in wanted: continue
  value=re.sub(r'^\d{4}-\d\d-\d\dT\S+\s','',line.rstrip().split('\t',2)[-1])
  if len(value)>2000: value=value[:2000]+' [projection: remaining characters not read]'
  print(f'{number}: {value}')
