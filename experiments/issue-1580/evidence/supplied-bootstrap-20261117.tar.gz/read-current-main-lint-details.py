import gzip
import pathlib
import re
import subprocess

path = pathlib.Path("experiments/issue-1580/evidence/ci/main-512ce428/44117975432.log.gz")
sections = [(17160, 58), (17253, 16), (17950, 63)]
with gzip.open(path, "rt") as source:
    for number, raw in enumerate(source, 1):
        if not any(start <= number < start + amount for start, amount in sections):
            continue
        text = raw.rstrip().split("\t", 2)[-1]
        text = re.sub(r"^\d{4}-\d\d-\d\dT\S+\s", "", text)
        print(str(number) + ": " + text)
print("ALREADY CHANGED LOCAL TESTS AGAINST MAIN")
subprocess.run(["git", "diff", "--stat", "origin/main", "--",
    "rust/tests/web/issue-1172-factual-qa-subject-gate.test.mjs",
    "rust/tests/web/recipe-resume-policy-notation.test.mjs",
    "rust/tests/web/connector-work-item-receipts.test.mjs",
    "rust/tests/web/browser-engine-release-integration.test.mjs"], check=True)
