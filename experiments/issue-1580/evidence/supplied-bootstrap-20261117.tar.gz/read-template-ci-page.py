from pathlib import Path
import hashlib,json,sys
language=sys.argv[1];page=int(sys.argv[2]);base=Path('/tmp/issue-1580-research/templates');folder=base/(language+'-complete')
inventory=json.loads((base/(language+'-complete-inventory.json')).read_text());records=[];selected=[]
for item in sorted(inventory,key=lambda x:x['path']):
 path=item['path']
 if path.startswith(('dev/','docs/case-studies/')):continue
 raw=(folder/path).read_bytes();assert hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest()==item['gitBlob'],path
 selected.append(path)
 if b'\0' in raw:records.append(f'{path}: binary {len(raw)} bytes');continue
 for number,line in enumerate(raw.decode('utf-8',errors='replace').splitlines(),1):records.append(f'{path}:{number}: {line}')
start=(page-1)*300;assert 0<=start<len(records),(page,len(records))
print(f'{language} CI/APPLICATION SOURCE PAGE {page}/{(len(records)+299)//300}; {len(selected)} files; {len(records)} lines; archived dev/case-study evidence excluded, retained in full inventory')
print('\n'.join(records[start:start+300]))
