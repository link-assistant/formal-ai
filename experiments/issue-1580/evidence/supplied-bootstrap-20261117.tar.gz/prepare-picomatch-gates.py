from pathlib import Path
import json
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'rust/tests/web/picomatch-security-backport.test.mjs'
s=p.read_text()
s=s.replace("import test from 'node:test';", "import test from 'node:test';\nimport {readFileSync} from 'node:fs';\nimport {createHash} from 'node:crypto';")
s+='''
test('the retained upstream license and sources match the recorded provenance', () => {
  const root = new URL('../../../packages/picomatch-compat/', import.meta.url);
  const provenance = JSON.parse(readFileSync(new URL('upstream.json', root), 'utf8'));
  assert.deepEqual(provenance.modifiedFiles, ['lib/parse.js']);
  assert.equal(provenance.files.length, 8);
  for (const file of provenance.files) {
    const hash = createHash('sha256').update(readFileSync(new URL(file.path, root))).digest('hex');
    assert.equal(hash, file.localSha256, file.path);
    if (file.path !== 'lib/parse.js') assert.equal(hash, file.originalSha256, file.path);
    else assert.notEqual(hash, file.originalSha256);
  }
});

for (const application of ['desktop', 'vscode']) {
  test(application + ' resolves every locked picomatch to the reviewed local source', () => {
    const root = new URL('../../../' + application + '/', import.meta.url);
    const manifest = JSON.parse(readFileSync(new URL('package.json', root), 'utf8'));
    const lock = JSON.parse(readFileSync(new URL('package-lock.json', root), 'utf8'));
    assert.equal(manifest.devDependencies.picomatch, 'file:../packages/picomatch-compat');
    assert.equal(manifest.overrides.picomatch, '$picomatch');
    const entries = Object.entries(lock.packages).filter(([path]) => path.endsWith('/picomatch'));
    assert.equal(entries.length, 1);
    assert.equal(entries[0][1].name, '@formal-ai/picomatch-compat');
    assert.equal(entries[0][1].resolved, 'file:../packages/picomatch-compat');
    assert.equal(entries[0][1].version, '4.0.7-formal-ai.1');
  });
}
'''
p.write_text(s)
(r/'changelog.d/20261117_190000_picomatch_security_backport.md').write_text(
'Fix the single-branch repeated-extglob denial of service in desktop and VS Code development dependencies with a reviewed local picomatch backport for GHSA-fc5q-39xc-vjpf. Preserve the upstream MIT license and source hashes, block nested wildcard repetitions through the existing literal fallback, and add bounded regression and installed-consumer checks.\\n'.replace('\\n','\n'))
e=r/'experiments/issue-1580/evidence/checks/picomatch-single-branch'
(e/'README.md').write_text('''# Picomatch repeated-wildcard backport

The dependency gate found GHSA-fc5q-39xc-vjpf after its 17 November review.
The registry and GitHub release metadata both still identify 4.0.7 as latest;
the advisory has no patched release. The published tarball is integrity checked,
with its MIT license and eight source hashes retained in the local package.
No advisory exception, omitted dependency class or higher severity threshold is used.

The existing guard handles dangerous multi-branch repeated extglobs but misses a
single wildcard branch. The original-source run has eight failures and three
passes, including two hostile matches killed after 1.25 seconds. Each child has
a 64 MiB heap, 256 KiB stack and finite 42-byte subjects.

The first candidate passed eleven cases. Further parser review found two
bracket bypasses: +([[]*a) and +([*a). The retained edge-before run reproduces
both failures. The guard now follows non-nesting character classes, recognized
POSIX classes, escaped/quoted stars and disabled bracket parsing; dangerous
patterns use the existing literal fallback. The expanded focused file also
checks actual locked resolution and per-file provenance.

The same installed-consumer probe passes on published 4.0.7 and the backport:
micromatch 4.0.8, tinyglobby 0.2.17 and fdir 6.5.0. Its initial failure was an
incorrect expectation that fdir omits dotfiles; the upstream control confirms
fdir includes them. Both full dependency-class npm audits report zero
vulnerabilities, and npm pack includes all eleven intended files.

This is a local compatibility backport, not an upstream release or proof that
arbitrary regular expressions are safe. The existing explicit
maxExtglobRecursion:false opt-out remains. Supplied code and commands earn
zero autonomous Formal AI authorship credit. Final gate results are recorded
separately; native execution is not claimed.
''')
note='''The new picomatch advisory has a local candidate backport, with published-source identity, license and hashes retained. The focused security probes cover single branches, nested wildcards and two independently reproduced bracket bypasses; hostile matches are finite and isolated. Real installed micromatch/tinyglobby/fdir controls pass on both upstream and the candidate. Desktop and VS Code locks now use the local source and both audits return zero vulnerabilities. The complete local gate set and final expanded tests remain pending. This is no upstream repair and earns zero independent authorship credit; all broader acceptance gaps remain open.'''
for name in ['experiments/issue-1580/work-plan.md','docs/case-studies/issue-1580/README.md']:
 p=r/name;p.write_text(p.read_text().rstrip()+'\n\n'+note+'\n')
print('Draft complete: 18 focused tests, fast inventory, locks, source provenance, changelog and evidence.')
