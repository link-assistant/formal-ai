from pathlib import Path
import datetime,gzip,hashlib,json,os,resource,subprocess,sys,time
root=Path("/tmp/gh-issue-solver-1794900398048")
directory=root/"experiments/issue-1580/evidence/checks/generated-header-memory/final-gates"
directory.mkdir(parents=True,exist_ok=True)
if len(sys.argv)==1:
    assert not (directory/"all-local-gates.json").exists()
    assert json.loads((directory.parent/"generated-streamed.json").read_text())["status"]==0
    assert json.loads((directory.parent/"browser-reaped.json").read_text())["status"]==0
    assert subprocess.run(["git","merge-base","--is-ancestor","512ce428029a92687628b4180309ee5ab660fe08","HEAD"],cwd=root).returncode==0
    assert not subprocess.run(["git","status","--porcelain"],cwd=root,capture_output=True,text=True,check=True).stdout.strip()
    available=int(Path("/sys/fs/cgroup/memory.max").read_text())-int(Path("/sys/fs/cgroup/memory.current").read_text())
    assert available>512*1024*1024,f"Insufficient measured headroom: {available}"
    with (directory/"all-local-gates-bootstrap.log").open("wb") as stream:
        child=subprocess.Popen([sys.executable,__file__,"finish"],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({"pid":child.pid,"startedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"availableBytes":available,"completion":str(directory/"all-local-gates.json")}))
    sys.exit(0)
assert sys.argv==[__file__,"finish"]
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
env=dict(os.environ);env["PATH"]="/tmp/issue-1580-research/shellcheck-v0.11.0:"+env["PATH"];env["NODE_OPTIONS"]="--max-old-space-size=256"
head=subprocess.run(["git","rev-parse","HEAD"],cwd=root,text=True,capture_output=True,check=True).stdout.strip()
command=["node","experiments/formal_ai_subagent/local-gates.mjs"]
started=time.time();plain=directory/"all-local-gates.log"
with plain.open("wb") as stream:
    result=subprocess.run(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
raw=plain.read_bytes();(directory/"all-local-gates.log.gz").write_bytes(gzip.compress(raw,mtime=0));plain.unlink()
logs=[]
for source in sorted((root/"experiments/formal_ai_subagent/sandboxes/gates").glob("*.log")):
    if source.stat().st_mtime<started:continue
    data=source.read_bytes();target=directory/"gate-details"/(source.name+".gz");target.parent.mkdir(exist_ok=True)
    target.write_bytes(gzip.compress(data,mtime=0))
    logs.append({"name":source.name,"rawBytes":len(data),"rawSha256":hashlib.sha256(data).hexdigest(),"log":str(target.relative_to(directory))})
record={"command":command,"status":result.returncode,"headSha":head,"durationSeconds":round(time.time()-started,3),"nodeHeapMiB":256,"childrenPeakRssKiB":resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,"rawSha256":hashlib.sha256(raw).hexdigest(),"log":"all-local-gates.log.gz","perGateLogs":logs,"rustBuildsEnabled":False,"offlineAuditStandIns":False,"independentAuthorshipCredit":0}
(directory/"all-local-gates.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({key:value for key,value in record.items() if key!="perGateLogs"}),flush=True)
