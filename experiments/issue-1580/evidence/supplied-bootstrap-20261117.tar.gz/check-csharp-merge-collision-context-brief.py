from pathlib import Path
import json,re
root=Path('/tmp/issue-1580-research/csharp-layout-context')
for name in ['issues.json','pulls.json']:
    rows=json.loads((root/name).read_text())
    for row in rows:
        if name=='issues.json' and row.get('pull_request'):continue
        title=row.get('title','')
        body=row.get('body') or ''
        matches=[m for m in re.finditer(r'collisi|overwrit|changeset.{0,20}(?:loss|dropp)|(?:loss|dropp).{0,20}changeset',title+'\n'+body,re.I)]
        if row.get('number')==78 or matches:
            print('ITEM',name,row['number'],title,row['state'])
            if row.get('number')==78: print(body)
            else:
                text=title+'\n'+body
                for m in matches[:6]:print(text[max(0,m.start()-90):m.end()+180].replace('\n',' '))
p=Path('/tmp/issue-1580-research/templates/csharp-complete/scripts/print-untrusted.mjs')
print('SOURCE',p)
print(p.read_text())
