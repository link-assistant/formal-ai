from pathlib import Path
import json,subprocess,time
base=Path('experiments/issue-1580/evidence/checks/language-main-validation');out=base/'outcome.json'
if out.exists():
 v=json.loads(out.read_text());print('VALIDATION',json.dumps({k:v[k] for k in ('complete','allPassed','sourceUnchangedDuringValidation','gateCounts')}));print('FAILED_CHECKS',json.dumps([r for r in v['checks'] if r['exitCode']]))
else:
 p=base/'running.json';print('RUNNING',p.read_text() if p.exists() else 'no status')
 p=Path('/tmp/issue-1580-research/language-main-validation/all-local-gates.log');lines=p.read_text().splitlines();print('PROGRESS_LINES',len(lines));print('\n'.join(lines[-8:]))
for pid in ('1549339','1573344'):print('PROCESS',subprocess.run(['ps','-p',pid,'-o','pid=,stat=,etime=,args='],capture_output=True,text=True).stdout.strip())
print('UNSTAGED_PATHS',subprocess.check_output(['git','diff','--name-only'],text=True));print('UNMERGED',subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],text=True))
print('MEMORY',Path('/sys/fs/cgroup/memory.current').read_text().strip())
