from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,os,subprocess,sys,time,traceback
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');out=scratch/'canonical-main-integration'
if len(sys.argv)==1:
 out.mkdir(exist_ok=False)
 with (out/'worker.log').open('wb') as stream:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'scratch':str(out)}));sys.exit(0)
base=root/'experiments/issue-1580/evidence/checks/canonical-data-follow-through/main-merge';base.mkdir(exist_ok=False);rows=[]
def run(name,args,checked=True):
 r=subprocess.run(args,cwd=root,capture_output=True);row={'name':name,'argv':args,'exitCode':r.returncode}
 for label,raw in [('stdout',r.stdout),('stderr',r.stderr)]:
  packed=gzip.compress(raw,mtime=0);filename=name+'.'+label+'.gz';(base/filename).write_bytes(packed);row[label]={'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'lines':len(raw.splitlines())}
 rows.append(row);(base/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,r.stdout.decode()[-2500:],r.stderr.decode()[-1000:],flush=True)
 if checked:assert r.returncode==0,name
 return r.stdout.decode().strip(),r.returncode
try:
 preparation=scratch/'canonical-main-preparation'
 while not (preparation/'outcome.json').exists():
  if (preparation/'failure.json').exists():raise RuntimeError((preparation/'failure.json').read_text())
  time.sleep(3)
 assert json.loads((preparation/'outcome.json').read_text())['complete']
 assert run('branch',['git','branch','--show-current'])[0]=='issue-1580-8d61a32a61e1'
 assert run('current-head',['git','rev-parse','HEAD'])[0]=='ca68d929474b129bc56500ce93cf189ce3fc7023'
 assert not run('initial-index',['git','diff','--cached','--name-only'])[0]
 paths=run('source-names',['git','diff','--name-only','--','data','js','rust','ts'])[0].splitlines()+['changelog.d/issue-1580-canonical-cnl-data.md']
 assert len(paths)==30,len(paths)
 run('stage-source',['git','add','--',*paths]);run('staged-whitespace',['git','diff','--cached','--check'])
 run('commit-source',['git','-c','gc.auto=0','commit','-m','Use canonical CNL references and seed quoting'])
 source=run('source-head',['git','rev-parse','HEAD'])[0]
 _,merge_exit=run('stage-main-merge',['git','-c','gc.auto=0','merge','--no-commit','--no-ff','origin/main'],False)
 assert merge_exit in [0,1]
 conflicts=run('conflicts',['git','diff','--name-only','--diff-filter=U'])[0].splitlines()
 report={'sourceHead':source,'incomingMain':'53cbe4430f8b65330f47728401fc83b09977129f','mergeExitCode':merge_exit,'conflicts':conflicts,'mergeCommitted':False,'pushExecuted':False,'observedAt':datetime.now(timezone.utc).isoformat(),'independentAuthorshipCredit':0}
 for d in [out,base]:(d/'outcome.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report),flush=True)
except BaseException:
 traceback.print_exc();(out/'failure.json').write_text(json.dumps({'complete':False,'traceback':traceback.format_exc()})+'\n');sys.exit(1)
