from pathlib import Path
import json,gzip,hashlib,subprocess,re
root=Path.cwd();checks=root/'experiments/issue-1580/evidence/checks'
verified=0
for folder,manifest,keys in [('procedure-retrieval-validation','final-result.json',['results','rechecks']),('java-upstream-compatibility','manifest.json',['records'])]:
 base=checks/folder;r=json.loads((base/manifest).read_text())
 for key in keys:
  for row in r[key]:
   raw=(base/row['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['archiveSha256'];assert hashlib.sha256(gzip.decompress(raw)).hexdigest()==row['rawSha256'];verified+=1
 if folder.startswith('procedure'):
  for name in ['policy-final','focused-map','affected-gates']:
   rows=r['results']+r['rechecks'];row=next(x for x in rows if x['name']==name);text=gzip.decompress((base/row['file']).read_bytes()).decode();assert row['exitCode']==0;print(name,text[-900:])
base=checks/'offline-validation-writers';base.mkdir(exist_ok=False);rows=[]
for p in sorted(Path('/tmp/issue-1580-research/offline-validation-repair').glob('*.log')):
 raw=p.read_bytes();z=gzip.compress(raw,mtime=0);(base/(p.name+'.gz')).write_bytes(z);rows.append({'file':p.name+'.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(z).hexdigest(),'lines':len(raw.splitlines())})
(base/'manifest.json').write_text(json.dumps({'records':rows,'priorEvidencePayloadsVerified':verified,'nativeExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
paths=['scripts/check-pipeline-status.sh','scripts/ci-pull-request-admission.mjs','scripts/documentation-only-ci-policy.mjs','.github/workflows/native-type-check.yml','.github/workflows/release.yml','.github/actions/setup-sccache/action.yml','scripts/check-sccache-write-health.sh','scripts/check-javascript-dependencies.sh','scripts/collect-job-durations.sh','scripts/detect-code-changes.rs','.github/workflows/layered-ci.yml','scripts/free-disk-if-short.mjs','scripts/check-generated-files.mjs','scripts/check-fast-governance.mjs','scripts/hive-mind-draft-result.mjs','.github/workflows/hive-mind-draft.yml','scripts/check-required-status-checks.mjs','scripts/ci-native-regressions.sh','js/agentic/file_read/source.mjs','js/agentic/tool_result.mjs','rust/src/agentic_coding/file_read/source.rs','rust/src/agentic_coding/tool_result/source_observation.rs','js/agentic/crate/meta_executor.mjs','rust/src/meta_executor.rs','rust/src/meta_executor/production.rs']
base=checks/'production-diff-review';base.mkdir(exist_ok=False);records=[]
for name in paths:
 raw=subprocess.check_output(['git','diff','origin/main','--',name]);records.append({'path':name,'sourceSha256':hashlib.sha256((root/name).read_bytes()).hexdigest(),'diffSha256':hashlib.sha256(raw).hexdigest(),'diffLines':len(raw.splitlines()),'completeDiffLiterallyRead':True,'completeSourceLiterallyRead':name=='scripts/ci-native-regressions.sh','newDefectEstablished':False})
(base/'manifest.json').write_text(json.dumps({'baseMain':subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip(),'reviewedProductionDiffs':records,'selectedPaths':104,'wholePullRequestReviewed':False,'allPriorFeaturesProvenPreserved':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps({'verifiedPriorPayloads':verified,'writerLogs':len(rows),'completeProductionDiffsReviewed':len(records),'wholePullRequestReviewed':False}))
