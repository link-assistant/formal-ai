from pathlib import Path
import json
import subprocess

base=Path('/tmp/issue-1580-research/eighth-feedback')
for p in sorted(base.glob('*.json')):
 data=json.loads(p.read_text())
 print('\nFILE '+p.name)
 if isinstance(data,list):
  for row in data:
   if isinstance(row,dict) and ('body' in row or 'html_url' in row):
    print(json.dumps({k:row.get(k) for k in ['html_url','created_at','updated_at','state','body']},indent=2))
print('\nNATIVE RELEASE FUNCTIONS')
subprocess.run(['rg','-n','fn .*version|git commit|commit failed|update.*pom|Nothing to commit','scripts/version-and-commit.rs'],check=False)
print('\nJAVA RELEASE SOURCE')
p=Path('/tmp/issue-1580-research/templates/java-complete/scripts/version-and-commit.mjs')
for n,s in enumerate(p.read_text().splitlines(),1):
 print(f'{n}: {s}')
