import {execFileSync} from 'node:child_process';
import {deserialize} from 'node:v8';
import {createHash} from 'node:crypto';
import {writeFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
const path='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8';
const base=execFileSync('git',['merge-base','HEAD','origin/main'],{encoding:'utf8'}).trim();
const values=Object.fromEntries([['base',base+':'+path],['ours',':2:'+path],['theirs',':3:'+path]].map(([key,ref])=>[key,deserialize(execFileSync('git',['show',ref],{maxBuffer:4194304}))]));
const differences=(a,b,path='')=>{
  if(Object.is(a,b))return [];
  if(a&&b&&typeof a==='object'&&typeof b==='object'&&Array.isArray(a)===Array.isArray(b)){
    return [...new Set([...Object.keys(a),...Object.keys(b)])].flatMap(key=>differences(a[key],b[key],path+'/'+key));
  }
  return [{path,before:a,after:b}];
};
const record={base,ours:differences(values.base,values.ours),theirs:differences(values.base,values.theirs),between:differences(values.ours,values.theirs)};
writeFileSync('experiments/issue-1580/evidence/checks/main-merge-512ce428/witness-three-way-delta.json.gz',gzipSync(JSON.stringify(record,null,2)+'\n',{mtime:0}));
const short=value=>typeof value==='string'&&value.length>600?{length:value.length,sha256:createHash('sha256').update(value).digest('hex')}:value;
for(const key of ['ours','theirs','between']){
  console.log(key,'leaf differences',record[key].length);
  for(const item of record[key])console.log(JSON.stringify({...item,before:short(item.before),after:short(item.after)}));
}
for(const [key,value]of Object.entries(values))console.log(key,JSON.stringify({total:value.inventory.total,cases:value.inventory.cases.length,unsupported:value.inventory.unsupported.length,sourceManifest:value.sourceManifest.length}));
