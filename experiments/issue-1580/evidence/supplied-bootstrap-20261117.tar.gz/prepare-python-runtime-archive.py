import subprocess
for name in ['compress-python-runtime-raw-logs.py','record-python-runtime-evidence.py','archive-round-bootstrap.py','stage-python-runtime-batch.py']:
 result=subprocess.run(['python3','/tmp/issue-1580-research/'+name],capture_output=True,text=True)
 print(name,flush=True);print(result.stdout,flush=True)
 if result.returncode:print(result.stderr,flush=True);raise SystemExit(result.returncode)
