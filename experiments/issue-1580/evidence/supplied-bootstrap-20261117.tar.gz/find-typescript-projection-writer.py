from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
for rel in ['scripts/check-typescript-runtime.mjs','ts/agentic/crate/cnl_grammar.mts','ts/agentic/crate/cnl_output.mts']:
 p=root/rel;ls=p.read_text().splitlines();print('FILE',rel,'LINES',len(ls))
 for i,l in enumerate(ls,1):
  if i<=135:print(f'{i}: {l}')
print(subprocess.run(['rg','-n','--glob','*.mjs','--glob','*.md','genuine TypeScript projection|generate-typescript|TypeScript projections|typescript-runtime.*write','scripts','CONTRIBUTING.md'],cwd=root,text=True,capture_output=True).stdout[:10000])
