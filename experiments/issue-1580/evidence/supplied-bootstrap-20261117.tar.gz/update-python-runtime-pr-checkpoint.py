from pathlib import Path
import subprocess,json
def run(args):return subprocess.run(args,capture_output=True,text=True,check=True).stdout
repo='link-assistant/formal-ai';before=json.loads(Path('/tmp/issue-1580-research/pr-python-runtime-before.json').read_text())
fresh=json.loads(run(['gh','pr','view','1581','--repo',repo,'--json','title,body,isDraft,headRefOid,url']))
assert fresh['body']==before['body'] and fresh['headRefOid']=='e120c05b4d8e35d51e4c1efb95e9b0c46c8d42b5' and fresh['isDraft']
body=fresh['body']
replacements={
 'The latest batch adds a full-entrypoint Python reproduction:':'The hosted Python observations now provision the pinned Python 3.15.2 interpreter only on the actual selected JavaScript shard; missing or old Python fails on GitHub Actions while remaining optional locally. The full-entrypoint Python reproduction demonstrates that',
 'Python now has 24 active files fully read and one partially read, including all six workflows and the manual-fragment and version/commit helpers; 178 active files and 126 historical files remain unread.':'Python now has 118 active files fully read and one partially read (7,664/44,284 active lines), including all six workflows and the manual-fragment and version/commit helpers; 84 active files and 126 historical files remain unread.',
 'The maintained template suite passes twenty-nine tests locally (no language-runtime skips)':'The maintained template suite passes thirty-one tests locally (no language-runtime skips), including missing/old-runtime and selected-shard regressions',
 'Published head `624812120f` adds the Python collision fixture, retained negative control, report and command evidence; current-head hosted CI is under verification.':'All 24 workflows on published head `624812120f` passed, but its complete Layered CI log shows five Python cases skipped because the runner interpreter cannot parse the unchanged pinned source (lines 4877 and 4893-4896). That green result is not hosted Python acceptance. Head `e120c05b4` fixes this coverage gap with planned runtime provisioning and fail-closed hosted observations; its hosted verification is in progress. The current local batch passes the maintained 31-case entrypoint, 15 fast-profile checks, 21 default-branch checks, three checkout checks, readable-code, CI-speed, runner-label, abbreviation and both file-size gates. The initial missing-ShellCheck result and single unchanged passing VM-timeout retry are retained; no timeout, benchmark floor or default-branch build policy was relaxed.',
}
for old,new in replacements.items():assert body.count(old)==1,old;body=body.replace(old,new)
assert body.startswith('Fixes #1580\n')
path=Path('/tmp/issue-1580-research/pr-python-runtime-body.md');path.write_text(body)
print(run(['gh','pr','edit','1581','--repo',repo,'--title',fresh['title'],'--body-file',str(path)]))
after=json.loads(run(['gh','pr','view','1581','--repo',repo,'--json','title,body,isDraft,headRefOid,url']))
assert after['body']==body and after['isDraft']
Path('/tmp/issue-1580-research/pr-python-runtime-after.json').write_text(json.dumps(after,indent=2)+'\n')
print('Updated draft PR description with exact partial-review coverage, runtime fix, local checks and prior hosted skips.')
print('Existing ShellCheck-related paths:')
for base in [Path('/tmp/issue-1580-research'),Path('/tmp')]:
 print(base,[p.name for p in base.iterdir() if any(x in p.name.lower() for x in ['shellcheck','issue-1580-tools','issue-1580-bin'])])
for p in sorted(Path('/tmp/issue-1580-research').glob('*.py')):
 text=p.read_text()
 if 'shellcheck' in text and any(x in text for x in ['bin/shellcheck','sha256','ShellCheck']):
  lines=[f'{i}: {line}' for i,line in enumerate(text.splitlines(),1) if 'shellcheck' in line.lower() or 'PATH' in line]
  if lines:print(p.name,'\n'.join(lines)[:1200])
