from pathlib import Path
import json,gzip,subprocess
scratch=Path('/tmp/issue-1580-research')
for relative in ['task-cue-validation-resumed','ci-logs/synthesis-c8fb9ad1']:
    base=scratch/relative;print('WORKER',relative)
    print('\n'.join((base/'worker.log').read_text().splitlines()[-10:]))
    for name in ['outcome.json']:
        if (base/name).exists():
            report=json.loads((base/name).read_text());print(json.dumps({k:v for k,v in report.items() if k!='records'}))
base=Path('experiments/issue-1580/evidence/checks/quoted-passage-cues/resumed')
for name in ['worker-writer','fixture-writer','executor','translation-writer']:
    path=base/(name+'.log.gz')
    if path.exists():print('PAYLOAD',name);print(gzip.decompress(path.read_bytes()).decode())
print('DIFF STAT');subprocess.run(['git','diff','--stat'],check=True)
