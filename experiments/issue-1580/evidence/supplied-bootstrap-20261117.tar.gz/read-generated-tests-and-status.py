import json
import pathlib
import subprocess

subprocess.run(["rg","--files","rust/tests/web","scripts"],check=True,stdout=subprocess.PIPE)
found=subprocess.run(["rg","-l","generatorOf|generatedFileProblems","rust/tests/web"],capture_output=True,text=True,check=True).stdout.splitlines()
for relative in found:
    lines=pathlib.Path(relative).read_text().splitlines()
    print("FILE",relative,"LINES",len(lines),flush=True)
    for number,line in enumerate(lines[:1500],1):print(str(number)+": "+line)
directory=pathlib.Path("experiments/issue-1580/evidence/checks/main-merge-512ce428")
path=directory/"all-local-gates.json"
if path.exists():
    result=json.loads(path.read_text())
    print("GATE RESULT",json.dumps({key:value for key,value in result.items() if key!="perGateLogs"}))
else:print("GATES STILL RUNNING")
