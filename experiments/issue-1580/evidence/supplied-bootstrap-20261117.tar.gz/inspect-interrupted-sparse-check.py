from pathlib import Path
import json,subprocess
raw=subprocess.check_output(['ps','-eo','pid,ppid,pgid,args'],text=True)
rows=[line for line in raw.splitlines() if any(term in line for term in ['verify-javascript-sparse-fixtures.py','javascript-sparse-fixtures-','issue-0932-box-language-projects.test.mjs']) and 'inspect-interrupted-sparse-check.py' not in line]
print(json.dumps({'processes':rows,'temporaryDirectories':[str(path) for path in Path('/tmp/issue-1580-research').glob('javascript-sparse-fixtures-*')],'memoryEvents':Path('/sys/fs/cgroup/memory.events').read_text()},indent=2))
