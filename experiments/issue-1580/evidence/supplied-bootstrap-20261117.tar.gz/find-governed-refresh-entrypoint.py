import subprocess
commands=[
 ['rg','-n','refresh-reviewed-baseline','scripts','experiments/formal_ai_subagent','--glob','*.mjs','--glob','*.md'],
 ['git','diff','--name-only','--diff-filter=U'],
 ['git','diff','--check'],
]
for command in commands:
    result=subprocess.run(command,capture_output=True,text=True)
    lines=(result.stdout+result.stderr).splitlines()
    print('COMMAND',command,'lines',len(lines),'exit',result.returncode)
    for line in lines[:35]:print(line)
