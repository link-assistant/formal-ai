from pathlib import Path
import json,subprocess
base=Path('/tmp/issue-1580-research/child-evidence-publication')
for name in ['worker.log','outcome.json','verification.json']:
    path=base/name
    print('\nFILE',name)
    if path.exists():print(path.read_text())
    else:print('PENDING')
path=base/'staged-gates.stdout'
if path.exists():print('STAGED GATES\n'+path.read_text())
path=base/'staged-gates.stderr'
if path.exists():print('STAGED GATE ERRORS\n'+path.read_text())
