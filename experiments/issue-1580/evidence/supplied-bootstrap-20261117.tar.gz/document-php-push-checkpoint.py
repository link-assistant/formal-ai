from pathlib import Path
from datetime import datetime, timezone
import csv, gzip, hashlib, json

root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/checks/php-push-integrity'
assert json.loads((base/'results.json').read_text())['complete']
source=Path('/tmp/issue-1580-research/templates/php-complete')
rows={row['path']:row for row in csv.DictReader((root/'docs/case-studies/issue-1580/templates/php-files.tsv').open(),delimiter='\t')}
decisions={
    '.github/workflows/release.yml':'Automatic status functions bypass implicit prerequisite success; bounded original/candidate controls are filed upstream as #27.',
    '.github/workflows/templates.yml':'All four captured source subtrees remain current CI inputs; all 221 files are present in the conservative reference graph. Path history alone does not exclude execution.',
    'scripts/src/VersionReleaser.php':'Commit errors throw, but branch/tag push return values are discarded before successful release outputs. Real local rejection controls reproduce both boundaries.',
    'scripts/src/Git.php':'add/commit/tag use mustRun; both publication methods return unchecked Process::run results. Disposable candidate changes those two calls only.',
    'scripts/src/Process.php':'Separates status-bearing run from throwing mustRun. Existing Formal AI release commands already propagate nonzero pushes.',
    'scripts/src/ProcessResult.php':'An unsuccessful process remains a structured result until the caller inspects ok() or uses mustRun.',
    'scripts/src/Project.php':'Locates manifest, reads identity/version, edits the version field and identifies the sentinel package; valid-input release fixture retains this implementation.',
    'scripts/src/ReleasePreflight.php':'Packagist and receive-pack probes distinguish verified, failed and unknown; the receive-pack path checks a complete advertisement without changing refs.',
    'scripts/src/ReleaseDecider.php':'Registry/GitHub state and fragments drive new-release versus self-heal selection. This review alone is not live registry verification.',
    'scripts/version-and-commit.php':'Actual CLI emits version_committed=true after the unchecked release method. Both changeset and instant modes are executed in the regression.',
    'scripts/bootstrap.php':'Falls back to local PSR-4 loading when Composer vendor code is absent; release reproduction installs no packages.',
    'tests/Pipeline/VersionReleaserTest.php':'Existing tests deliberately omit a remote and accept silent push failures, covering local commit/tag creation but missing publication rejection.',
    'scripts/src/ChangelogFragments.php':'Valid fragments are selected deterministically, merged by category and cleared during a release. The real-Git controls retain both release modes and successful fragment consumption.',
    'scripts/src/SemVer.php':'Existing version parsing and bump precedence are retained; regression uses a valid patch bump with exact 1.2.4 remote content.',
    'scripts/src/Changelog.php':'Preserves the existing insertion marker behavior used by the release fixture; no changelog implementation is copied into production.',
    'scripts/src/Cli.php':'Normalizes getopt string/flag inputs; regression executes the original CLI with its supported equals-form options.',
    'scripts/src/Actions.php':'Release outputs are inspected through the actual GITHUB_OUTPUT file, keeping process success distinct from remote publication state.',
}
review=[]
for path,decision in decisions.items():
    raw=(source/path).read_bytes()
    blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert blob==rows[path]['git_blob']
    review.append({'path':path,'gitBlob':blob,'sha256':hashlib.sha256(raw).hexdigest(),'lines':len(raw.splitlines()),'literalSourceReadComplete':True,'decision':decision})
report={'repository':'link-foundation/php-ai-driven-development-pipeline-template','commit':'3a034b27a56067971ca74dd4c74c7707056b215d','observedAt':datetime.now(timezone.utc).isoformat(),'files':review,'fullyReadFiles':len(review),'fullyReadLines':sum(row['lines'] for row in review),'wholeRepositorySemanticReviewComplete':False,'livePublicationVerified':False,'independentAuthorshipCredit':0}
(root/'docs/case-studies/issue-1580/templates/php-release-semantic-review.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'docs/case-studies/issue-1580/php-push-integrity-checkpoint.md').write_text('''# PHP release publication results

This partial review supports [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581).
The pinned PHP template is `3a034b27a56067971ca74dd4c74c7707056b215d`.
Its release CLI commits and tags locally, calls both Git push methods, then emits
`version_committed=true`. Those methods return unsuccessful process results that
the orchestration discards. Existing upstream tests intentionally use no remote
and accept the silent push failures.

Nine bounded controls execute the unmodified PHP entrypoint against disposable
local repositories and bare remotes. In both changeset and instant modes, an
update hook rejects a branch or tag. A rejected branch still allows a release tag
to reach the remote while its branch remains at the old commit. A rejected tag
leaves the branch updated but no remote release tag. Both original paths exit
successfully and emit the successful release outputs.

A disposable two-call candidate uses the existing throwing process helper for
both pushes. Both rejected operations become nonzero CLI outcomes without
successful release outputs; branch rejection stops the later tag push. A tag
failure still leaves the already accepted branch update visible. Four successful
controls retain exact version 1.2.4 in the remote tag before and after the candidate.
The candidate does not claim atomic publication or change the upstream repository.

The focused file passes nine tests; the maintained fast-PR entrypoint passes 52,
with zero skips/failures. Six affected JavaScript gates and whitespace pass. All
full logs were read and hash checked under
`experiments/issue-1580/evidence/checks/php-push-integrity/`. Eight additional source
fixtures are exact Git-blob/SHA-256-verified copies with the existing original
license. PHP runs with a 32 MiB limit; subprocess inputs and deadlines are finite.
No Composer installation, network publication, Rust build or PHP package build runs.

Formal AI's existing `scripts/version-and-commit.rs:920–989` already exits on
commit, exhausted branch-push and tag-push failures, and creates the tag after the
branch update. Those behaviors are retained. This new upstream report remains a
draft until immutable executable evidence is published and duplicates are checked.

The per-file release review records 17 completely read source/workflow/test files,
with explicit transfer decisions. The full 608-blob PHP semantic review, captured
CI tree review and broader issue criteria remain unfinished. Supplied commands,
candidate changes and conclusions receive zero independent Formal AI authorship credit.
''')
guard=root/'docs/case-studies/issue-1580/php-release-guard-checkpoint.md'
text=guard.read_text().replace('The distinct release-guard\nreport remains a draft until immutable executable evidence is published.', 'The distinct release-guard\nreport is filed as [PHP template #27](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/27),\nwith immutable executable evidence at `fda677ef9f25692b7b3823556f1349839a71f7a3`.\nReporting does not establish an upstream repair.')
guard.write_text(text)
posted=root/'experiments/issue-1580/evidence/checks/php-release-guard/report-publication/posted-body.md'
(root/'experiments/issue-1580/upstream/php-release-guard-report.md').write_text('Reported as [PHP template #27](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/27).\n\n'+posted.read_text())
plan=root/'experiments/issue-1580/work-plan.md'
with plan.open('a') as stream:stream.write('\n## PHP push-result regression (2026-11-18)\n\n- [x] File the separate automatic-release guard defect as PHP template #27 with immutable five-test evidence at fda677ef9.\n- [x] Read all 17 release-related files and reproduce ignored branch/tag push outcomes through the original PHP CLI in both modes. Nine focused and 52 maintained tests pass; six affected gates pass. Preserve remote state and actual output assertions; no package installation or hosted release.\n- [x] Preserve the eight unmodified fixture sources and atomic local source commit.\n- [ ] Collect every fda677ef9 workflow, including new native synthesis/source-operand execution, before the next push.\n- [ ] Publish the reviewed PHP push-result evidence once, then fresh-check/file the distinct upstream report. Full PHP review, wider native/runtime and 0/20 independent reasoning criteria remain open.\n')
print(json.dumps({'fullyReadFiles':len(review),'fullyReadLines':report['fullyReadLines'],'wholePhpReviewComplete':False,'independentAuthorshipCredit':0}))
