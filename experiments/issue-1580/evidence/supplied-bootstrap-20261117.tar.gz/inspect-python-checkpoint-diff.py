from pathlib import Path
import subprocess

def run(arguments):
    return subprocess.run(arguments, check=True, capture_output=True, text=True).stdout

for arguments in [['git', 'branch', '--show-current'], ['git', 'status', '--short'], ['git', 'diff', '--stat']]:
    print('COMMAND', arguments)
    print(run(arguments))
output = run(['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--list'])
Path('/tmp/issue-1580-research/python-fragment-gate-list.txt').write_text(output)
print('RELEVANT GATES')
for line in output.splitlines():
    if any(word in line.lower() for word in ['abbreviat', 'file-size', 'fast-pull', 'template', 'javascript-inventory', 'working-rules', 'agent-push']):
        print(line)
print('TRACKED DIFF')
print(run(['git', 'diff', '--', 'experiments/issue-1580/fixtures/python-template/source.json', 'rust/tests/web/issue-1580-template-observations.test.mjs', 'docs/case-studies/issue-1580/README.md', 'docs/case-studies/issue-1580/templates/README.md', 'experiments/issue-1580/work-plan.md']))
