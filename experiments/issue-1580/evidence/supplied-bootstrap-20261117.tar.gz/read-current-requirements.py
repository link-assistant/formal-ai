from pathlib import Path
import json
b=Path('/tmp/issue-1580-research/calendar-feedback')
for name in ['issue.json','issue-comments.json','pr-comments.json','pr-inline.json','pr-reviews.json']:
 p=b/name
 d=json.loads(p.read_text())
 if name=='issue.json':
  print('ISSUE',d.get('title'),d.get('body'))
 else:
  print('\n'+name)
  if isinstance(d,dict): d=[d]
  for item in d:
   print(item.get('html_url',item.get('url')),item.get('created_at',item.get('createdAt')),item.get('body'))
print('\nFEEDBACK SCRIPT')
print(Path('/tmp/issue-1580-research/refresh-calendar-feedback.py').read_text())
