set -eu
git branch --show-current
git status --short
rg -n 'file.size|readability|line.limit' experiments/formal_ai_subagent/local-gates.mjs
cat experiments/issue-1580/evidence/chrono-upstream/index.json
cat experiments/issue-1580/template-reference-graph.test.mjs
sed -n '1,180p' CONTRIBUTING.md
find .. -name AGENTS.md -print
