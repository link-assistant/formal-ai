from pathlib import Path
import hashlib,json
root=Path.cwd();directory=root/'experiments/issue-1580/evidence/checks/native-interface-admission';directory.mkdir(exist_ok=False)
paths=['rust/tests/interface_contracts.rs','rust/tests/integration/formal_ai_cli.rs','rust/tests/integration/http_server.rs','rust/tests/integration/pty.rs','rust/tests/support/structured_stderr.rs','rust/tests/integration/with_formal_ai.rs','rust/tests/integration/with_formal_ai/fixture_env.rs','rust/tests/integration/with_formal_ai/issue_1582.rs','rust/tests/integration/with_formal_ai/model_metadata.rs','rust/tests/integration/with_formal_ai_argv.rs','rust/tests/integration/issue_819_tui_isolation.rs','rust/tests/integration/issue_1138_family_behaviour.rs','rust/tests/unit/formal_ai/seed_and_memory.rs','rust/tests/unit/seed/issue_699_handler_migration.rs','docs/case-studies/issue-552/raw-data/chatgpt-share-6a3825b9.html','docs/case-studies/issue-781/raw-data/chatgpt-web-capture.json','docs/case-studies/issue-699/agent-cli-evidence/handler-migration-batch-report.lino']
for p in paths[1:]:
 raw=(root/p).read_bytes();print('INPUT',p,'lines',len(raw.splitlines()),'bytes',len(raw))
source='''\n\ntest('CLI, TUI, memory and retired-handler contracts retain their complete native closure', {timeout:15000}, () => {
  const inputs = INPUTS;
  for (const path of inputs) assert.equal(admission([path])['native-type-check'], true, path);
  for (const path of ['rust/tests/integration/unrelated-cli.rs', 'rust/tests/support/unrelated.rs',
    'docs/case-studies/unrelated-cli/input.json'])
    assert.equal(admission([path])['native-type-check'], false, path);
  assert.match(read('rust/Cargo.toml'), /name = "interface_contracts"\\npath = "tests\\/interface_contracts[.]rs"/u);
  const step = Object.values(workflow('native-type-check.yml').jobs)[0].steps
    .find(step => step.name === 'Verify isolated native behavior regressions');
  assert.match(nativeRegressionSource(step), /--test interface_contracts(?: |$)/u);
  assert.match(nativeRegressionSource(step), /--no-fail-fast/u);
  assert.equal(step.env.FORMAL_AI_OFFLINE, '1');
  const source = read('rust/tests/interface_contracts.rs');
  for (const path of inputs.filter(path => path.endsWith('.rs') && !path.includes('/with_formal_ai/')
    && !path.endsWith('/interface_contracts.rs')))
    assert(source.includes('#[path = "' + path.slice('rust/tests/'.length) + '"]'), path);
  for (const child of ['fixture_env', 'issue_1582', 'model_metadata'])
    assert(read('rust/tests/integration/with_formal_ai.rs').includes('mod ' + child + ';'), child);
});
'''.replace('INPUTS',json.dumps(paths,indent=4))
p=root/'rust/tests/web/default-branch-build-policy.test.mjs';p.write_text(p.read_text()+source)
(directory/'input-identity.json').write_text(json.dumps({'inputs':[{'path':p,'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in paths[1:]],'nativeReplayObserved':False,'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
print('Added policy regression; no native inclusion yet')
