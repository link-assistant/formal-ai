set -eu
sed -n '1,230p' experiments/issue-1580/compare-template-trees.mjs
cat docs/case-studies/issue-1580/templates/README.md
cat rust/tests/web/ci-change-detection-checkout.test.mjs
sed -n '1,220p' scripts/check-rust-dependencies.sh
tail -n 12 /tmp/issue-1580-research/all-local-gates-fifth.log
