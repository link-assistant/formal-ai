from pathlib import Path
import subprocess,json
base=Path('experiments/issue-1580/upstream')
for p in sorted(base.iterdir()):
 if p.is_file():print(p.name)
for p in sorted(base.glob('*.json')):
 data=json.loads(p.read_text())
 if isinstance(data,list):print('JSON ARRAY',p.name,len(data),json.dumps(data[-1],indent=2))
 elif isinstance(data,dict):print('JSON KEYS',p.name,list(data))
paths=subprocess.check_output(['rg','--files','scripts'],text=True).splitlines()
print('FORMAL FRAGMENTS',*[p for p in paths if 'changelog' in p or 'fragment' in p],sep='\n')
p=Path('scripts/create-changelog-fragment.rs')
if p.exists():
 lines=p.read_text().splitlines()
 print('FORMAL FILE',str(p),'LINES',len(lines))
 assert len(lines)<=1500
 for n,line in enumerate(lines,1):print(f'{n}: {line}')
