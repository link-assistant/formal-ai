export NODE_PATH=/tmp/issue-1580-research/node_modules
mkdir -p /tmp/issue-1580-research/self-reference-checks
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-reference-graph.test.mjs > /tmp/issue-1580-research/self-reference-checks/before.log 2>&1
result=$?
cat /tmp/issue-1580-research/self-reference-checks/before.log
test "$result" -eq 1
