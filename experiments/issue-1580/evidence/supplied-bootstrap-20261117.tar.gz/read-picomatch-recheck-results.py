from pathlib import Path
import collections, gzip, json, subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/checks/picomatch-single-branch'
progress=json.loads((base/'final-rechecks.json').read_text())
print('FINISHED',progress['finished'])
for item in progress['checks']:
    print(item['label'],item['exitCode'],item['durationSeconds'],item['rawSha256'])
    if item['exitCode']:
        print(gzip.decompress((base/item['log']).read_bytes()).decode())
for name in ['extracted-security-tests','extracted-consumers','extracted-pack']:
    print('\nFULL LOG',name)
    print(gzip.decompress((base/(name+'.log.gz')).read_bytes()).decode())
data=json.loads(gzip.decompress((base/'extracted-parser-comparison.log.gz').read_bytes()))
print('\nPARSER COMPARISONS',data['comparisons'],'DIFFERENCES',len(data['differences']))
for item in data['differences']:
    print(json.dumps(item))
print('\nTEST FILE PATHS')
result=subprocess.run(['rg','--files'],cwd=root,text=True,capture_output=True,check=True)
for line in result.stdout.splitlines():
    if 'fast-pull-request' in line and ('test' in line): print(line)
print('\nGATE IDENTIFIERS')
result=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--list'],cwd=root,text=True,capture_output=True,check=True)
for line in result.stdout.splitlines():
    if any(word in line for word in ['file-size','readable','abbreviations','javascript-dependencies','self-containment']): print(line)
