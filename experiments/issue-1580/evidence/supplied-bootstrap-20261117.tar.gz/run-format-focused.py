from pathlib import Path

source=Path('/tmp/issue-1580-research/run-audit-focused.py').read_text()
source=source.replace('checks/audit-inventory-boundary','checks/python-release-formatting')
exec(compile(source,__file__,'exec'))
