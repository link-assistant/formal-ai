from pathlib import Path
import gzip,json,re
base=Path('experiments/issue-1580/evidence/ci/main-015a6831')
scratch=Path('/tmp/issue-1580-research/main-015a6831-runs')
receipt=json.loads((base/'download-receipt.json').read_text())
patterns={
 'panic':re.compile(r"thread '[^']+' panicked at"),
 'failed-test':re.compile(r'test [^\t]+ \.\.\. FAILED\s*$'),
 'node-failure':re.compile(r'(?:not ok \d+ -|✖ .+\([0-9.]+m?s\)|ERR_ASSERTION|AssertionError)'),
 'timeout':re.compile(r'(?:exit code 124|exit code: 124|Process completed with exit code 124|timed out after|exceeded.*(?:1080|900)|timeout: sending signal)'),
 'workflow-error':re.compile(r'##\[error\]|::error(?: |::)'),
}
indices=[]
for download in receipt['downloads']:
    path=scratch/(download['archive'][:-3]);markers=[]
    with path.open() as stream:
        for number,line in enumerate(stream,1):
            matches=[name for name,pattern in patterns.items() if pattern.search(line)]
            if matches:markers.append({'line':number,'kinds':matches,'text':line.rstrip()})
    row={'archive':download['archive'],'downloadExitCode':download['exitCode'],'rawSha256':download['rawSha256'],'markers':markers,'markerCounts':{name:sum(name in m['kinds'] for m in markers) for name in patterns},'fullManualReview':False}
    indices.append(row)
    print('LOG',row['archive'],'COUNTS',json.dumps(row['markerCounts']),'DOWNLOAD EXIT',row['downloadExitCode'])
    for marker in markers[:25]:print(str(marker['line'])+': '+marker['text'][:700])
(base/'targeted-failure-index.json.gz').write_bytes(gzip.compress((json.dumps(indices,indent=2)+'\n').encode(),mtime=0))
print('Index counts are matched markers, not complete failure counts or full manual review.')
