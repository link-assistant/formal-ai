from pathlib import Path
for name in ['js/agentic/file_read/source.mjs','ts/agentic/file_read/source.mts']:
    p=Path(name);s=p.read_text();old='  const read = sourceReadObservation(legacy.content, legacy.is_error, null, path);'
    new="""  // The client may have absolutized a relative planned path. Decode only against
  // its validated call argument, while retaining this legacy alias as incomplete.
  const recordedPath = ['path', 'filePath', 'file_path', 'absolute_path']
    .map(key => legacy.arguments[key]).find(value => typeof value === 'string');
  const read = progress.sourceReadFor(recordedPath)
    ?? sourceReadObservation(legacy.content, legacy.is_error, null, recordedPath);"""
    assert old in s;s=s.replace(old,new,1);p.write_text(s)
p=Path('rust/src/agentic_coding/file_read/source.rs');s=p.read_text();old='''    let mut read =
        tool_result::source_read_observation(&legacy.content, legacy.is_error, None, path);
'''
new='''    // The client can absolutize a relative planned path. Use its validated call
    // argument for transport decoding; an alias never upgrades completeness.
    let recorded_path = ["path", "filePath", "file_path", "absolute_path"]
        .iter()
        .find_map(|key| legacy.arguments.get(*key).and_then(serde_json::Value::as_str))?;
    let mut read = if let Some(read) = progress.source_read_for(recorded_path) {
        tool_result::SourceReadObservation {
            status: read.status,
            complete: false,
            absent: read.absent,
            source: read.source.clone(),
            error: read.error.clone(),
        }
    } else {
        tool_result::source_read_observation(&legacy.content, legacy.is_error, None, recorded_path)
    };
'''
assert old in s;s=s.replace(old,new,1);p.write_text(s)
p=Path('rust/tests/web/source-read-provenance.test.mjs');s=p.read_text();s=s.replace("import { Progress } from '../../../js/agentic/progress.mjs';", "import { Progress } from '../../../js/agentic/progress.mjs';\nimport { toolResultRecords } from '../../../js/agentic/file_read/records.mjs';\nimport { readObservation } from '../../../js/agentic/file_read/source.mjs';",1)
s+='''
test('relative file rendering uses the actual client Read path without discarding raw metadata', () => {
  const row = opencodeRows.find(row => row.id === 'whole');
  for (const raw of [false, true]) {
    const messages = history(row.raw, raw ? { source_read: { path: row.path, success: true, complete: true, format: 'raw' } } : {}, { filePath: row.path });
    const observed = readObservation(toolResultRecords(messages), Progress.scan(messages), 'source.txt');
    assert.equal(observed.source, raw ? row.raw : row.source);
    assert.equal(observed.complete, false, 'legacy path aliases cannot certify the exact planned source');
  }
});
''';p.write_text(s)
print('Bound relative-path rendering to validated client call arguments, preserving typed raw metadata.')
