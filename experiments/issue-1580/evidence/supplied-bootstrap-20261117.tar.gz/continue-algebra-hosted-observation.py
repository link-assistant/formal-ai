from pathlib import Path
import json,subprocess,gzip
scratch=Path('/tmp/issue-1580-research/ci-logs/algebra-acb9fa51')
outcome=json.loads((scratch/'outcome.json').read_text())
assert not outcome['complete']
base=Path('experiments/issue-1580/evidence/ci/algebra-acb9fa51')
(base/'first-observation-window.json').write_text(json.dumps(outcome,indent=2)+'\n')
(base/'first-observation-window.log.gz').write_bytes(gzip.compress((scratch/'worker.log').read_bytes(),mtime=0))
source=Path('/tmp/issue-1580-research/collect-algebra-hosted-results.py').read_text()
source=source.replace("scratch=Path('/tmp/issue-1580-research/ci-logs/algebra-acb9fa51')","scratch=Path('/tmp/issue-1580-research/ci-logs/algebra-acb9fa51-continuation')")
source=source.replace('base.mkdir(exist_ok=False)','base.mkdir(exist_ok=True)')
source=source.replace('snapshots=[]','snapshots=json.loads((base/"progress.json").read_text())["snapshots"]')
source=source.replace('range(120)','range(180)')
target=Path('/tmp/issue-1580-research/collect-algebra-hosted-results-continuation.py');target.write_text(source)
result=subprocess.run(['python3',str(target)],capture_output=True)
assert result.returncode==0,result.stderr.decode()
print(result.stdout.decode())
