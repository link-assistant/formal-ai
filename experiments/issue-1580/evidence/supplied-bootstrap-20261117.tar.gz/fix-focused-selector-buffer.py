from pathlib import Path
import subprocess,gzip,json,hashlib

base=Path('experiments/issue-1580/evidence/checks/focused-selector-large-diff')
base.mkdir(exist_ok=False)
records=[]
def run(name,args,expected=0):
    p=subprocess.run(args,capture_output=True)
    row={'name':name,'argv':args,'exitCode':p.returncode}
    for label,raw in [('stdout',p.stdout),('stderr',p.stderr)]:
        packed=gzip.compress(raw,mtime=0); filename=name+'.'+label+'.gz'
        (base/filename).write_bytes(packed)
        row[label]={'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())}
    records.append(row);(base/'records.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,p.returncode,flush=True)
    assert p.returncode==expected,(name,p.stderr.decode(errors='replace')[-1500:])
    return p.stdout
p=Path('rust/tests/web/focused-test-map.test.mjs')
text=p.read_text().replace("import { readFileSync } from 'node:fs';", "import { chmodSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';\nimport { execFileSync } from 'node:child_process';\nimport { tmpdir } from 'node:os';\nimport { delimiter, join } from 'node:path';\nimport { fileURLToPath } from 'node:url';")
text+='''
// Issue #1580: changed evidence paths exceeded execFileSync's default 1 MiB.
for (const option of ['--base', '--since']) {
  test('the CLI selects from the complete large Git diff with ' + option, {timeout: 15000}, t => {
    const directory = mkdtempSync(join(tmpdir(), 'formal-focused-diff-'));
    t.after(() => rmSync(directory, {recursive: true, force: true}));
    const git = join(directory, 'git');
    writeFileSync(git, '#!' + process.execPath + '\\n' + `
      const paths = Array.from({length: 12000}, (_, index) => 'experiments/' + 'x'.repeat(96) + index);
      paths.push('irrelevant\\\\n.github/workflows/hive-mind-draft.yml');
      paths.push('js/agentic/work_item_evidence.mjs');
      process.stdout.write(paths.join(process.argv.includes('-z') ? '\\\\0' : '\\\\n'));
    `);
    chmodSync(git, 0o755);
    const output = execFileSync(process.execPath, [
      fileURLToPath(new URL('../../../scripts/select-focused-tests.mjs', import.meta.url)),
      option, 'captured-base', '--json',
    ], {encoding: 'utf8', env: {...process.env, PATH: directory + delimiter + process.env.PATH}, timeout: 10000});
    assert.deepEqual(JSON.parse(output), selectFocused(map, {changed: ['js/agentic/work_item_evidence.mjs']}));
  });
}

test('a failed Git diff cannot select tests from its partial output', {timeout: 15000}, t => {
  const directory = mkdtempSync(join(tmpdir(), 'formal-focused-diff-failure-'));
  t.after(() => rmSync(directory, {recursive: true, force: true}));
  const git = join(directory, 'git');
  writeFileSync(git, '#!' + process.execPath + '\\n' + `
    process.stdout.write('js/agentic/work_item_evidence.mjs\\\\0');
    process.exitCode = 7;
  `);
  chmodSync(git, 0o755);
  assert.throws(() => execFileSync(process.execPath, [
    fileURLToPath(new URL('../../../scripts/select-focused-tests.mjs', import.meta.url)),
    '--since', 'missing-base', '--json',
  ], {encoding: 'utf8', env: {...process.env, PATH: directory + delimiter + process.env.PATH}, timeout: 10000, stdio: ['ignore', 'pipe', 'pipe']}),
  error => error.status !== 0 && error.stdout === '' && /Command failed: git diff/u.test(error.stderr));
});
'''
p.write_text(text)
command=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/focused-test-map.test.mjs']
run('regression-before',command,1)
p=Path('scripts/select-focused-tests.mjs');text=p.read_text()
old="execFileSync('git', ['diff', '--name-only', base + '...HEAD'], { encoding: 'utf8' }).split('\\n')"
new="execFileSync('git', ['diff', '--name-only', '-z', base + '...HEAD'], { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 }).split('\\0')"
assert text.count(old)==1;text=text.replace(old,new)
old="execFileSync('git', ['diff', '--no-renames', '--name-only', since, 'HEAD'], { encoding: 'utf8' }).split('\\n')"
new="execFileSync('git', ['diff', '--no-renames', '--name-only', '-z', since, 'HEAD'], { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 }).split('\\0')"
assert text.count(old)==1;text=text.replace(old,new)
text=text.replace("  const changed = values(argv, '--changed');", "  const changed = values(argv, '--changed');\n  // Keep a finite 16 MiB ceiling while accepting evidence-heavy diffs above 1 MiB.\n  // NUL delimiters preserve spaces, Unicode and newlines in Git paths.")
p.write_text(text)
run('regression-after',command)
run('actual-published-diff',['node','--max-old-space-size=256','scripts/select-focused-tests.mjs','--since','7b7e189d770c4fbd8786b996d065282422e93b5c','--json'])
run('source-diff',['git','diff','--','scripts/select-focused-tests.mjs','rust/tests/web/focused-test-map.test.mjs'])
Path('changelog.d/issue-1580-focused-selector-large-diff.md').write_text('Allow the focused test selector to read evidence-heavy Git diffs within an explicit 16 MiB bound, preserve exact filenames with NUL delimiters, and keep Git failures terminal.\n')
(base/'outcome.json').write_text(json.dumps({'complete':True,'beforeExitCode':1,'afterExitCode':0,'boundedFixturePaths':12002,'maxGitDiffBytes':16777216,'gitFailureRemainsTerminal':True,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
