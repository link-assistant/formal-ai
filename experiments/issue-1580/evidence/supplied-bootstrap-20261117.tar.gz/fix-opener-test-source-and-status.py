from pathlib import Path
import os, subprocess, gzip, hashlib, json
path=Path('rust/src/unknown_opener.rs')
text=path.read_text()
old='"¿Cómo funciona la fotosíntesis submarina de xyzzy?",'
assert text.count(old)==1
text=text.replace(old,'"probe",')
path.write_text(text)
out=Path('experiments/issue-1580/evidence/checks/localized-unknown-opener/status-refresh')
out.mkdir()
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=256'
argv=['node','--max-old-space-size=256','scripts/render-status.mjs','--write']
result=subprocess.run(argv,env=env,capture_output=True)
raw=result.stdout+result.stderr
(out/'write.log.gz').write_bytes(gzip.compress(raw,mtime=0))
(out/'receipt.json').write_text(json.dumps({'argv':argv,'exitCode':result.returncode,'rawSha256':hashlib.sha256(raw).hexdigest(),'scope':'Regenerate maintained status surface after lowering the core source-size ceiling; no acceptance claim.'},indent=2)+'\n')
print(raw.decode(errors='replace'))
assert result.returncode==0
print(subprocess.check_output(['git','diff','--','docs/status.md'],text=True))
