#!/bin/sh
set -eu
gh release download v0.11.0 --repo koalaman/shellcheck --pattern shellcheck-v0.11.0.linux.x86_64.tar.xz --dir /tmp/issue-1580-research --skip-existing
echo '8c3be12b05d5c177a04c29e3c78ce89ac86f1595681cab149b65b97c4e227198  /tmp/issue-1580-research/shellcheck-v0.11.0.linux.x86_64.tar.xz' | sha256sum --check
tar -xJf /tmp/issue-1580-research/shellcheck-v0.11.0.linux.x86_64.tar.xz -C /tmp/issue-1580-research
rustfmt --edition 2024 rust/tests/unit/meta_executor_parity.rs
rustfmt --edition 2024 --check rust/src/concepts.rs rust/src/meta_executor.rs rust/src/meta_executor/production.rs rust/src/solver.rs rust/src/solver_dispatch.rs rust/src/solver_helpers/mod.rs rust/src/solver_synthesis.rs rust/tests/unit/concept_lookup_response_language.rs rust/tests/unit/issue_1133_hive_mind_three_runs.rs rust/tests/unit/issue_1133_hive_mind_three_runs/extended.rs rust/tests/unit/meta_executor_parity.rs rust/tests/fixtures/synthesis-parent-tests.rs
timeout 600 node --test --test-concurrency=1 rust/tests/web/issue-1580-production-composition.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/pull-request-1188-fix-gaps.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/stale-pull-request-report.test.mjs
node scripts/generate-staged-release.mjs --check-deployed
node scripts/translate-js-rust.mjs --verify
git diff --check
