from pathlib import Path
import gzip,hashlib,json,os,re,subprocess,time
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/native-failure-collection';base.mkdir(exist_ok=False)
policy=root/'rust/tests/web/default-branch-build-policy.test.mjs';workflow=root/'.github/workflows/native-type-check.yml';text=policy.read_text()
command='cargo test --manifest-path rust/Cargo.toml --locked --test calendar_currency';assert text.count(command)==1;text=text.replace(command,command.replace('--locked','--locked --no-fail-fast'))
old="""    'cargo test --manifest-path rust/Cargo.toml --locked --lib solver_unknown_reasoning::tests:: -- --test-threads=1\\n' +
    'cargo test --manifest-path rust/Cargo.toml --locked --test any_language a_language_without_localized_openers_reports_a_gap_not_english -- --exact --test-threads=1\\n',"""
new="""    'regression_status=0\\n' +
    'cargo test --manifest-path rust/Cargo.toml --locked --lib solver_unknown_reasoning::tests:: -- --test-threads=1 || regression_status=$?\\n' +
    'cargo test --manifest-path rust/Cargo.toml --locked --test any_language a_language_without_localized_openers_reports_a_gap_not_english -- --exact --test-threads=1 || regression_status=$?\\n' +
    'exit "$regression_status"\\n',"""
assert old in text;text=text.replace(old,new)
old="  for (const step of check.steps.filter(step => step.uses || ['Type-check and lint the library and binaries', 'Verify isolated native behavior regressions', 'Verify native unresolved-language source binding', 'Replay the forced function requests against the native CLI', 'Replay structured output and refusals against the native CLI', 'Replay localized procedures against the native CLI'].includes(step.name)))"
new="  for (const step of check.steps.filter(step => (step.uses && step.uses !== 'actions/setup-node@v7') || ['Type-check and lint the library and binaries', 'Verify isolated native behavior regressions'].includes(step.name)))"
assert old in text;text=text.replace(old,new)
text+='''

test('independent native replays continue after a regression fails and preserve failure status', () => {
  const job = workflow('native-type-check.yml').jobs.clippy;
  const later = job.steps.filter(step => step.name === 'Verify native unresolved-language source binding'
    || step.uses === 'actions/setup-node@v7' || step.name?.startsWith('Replay '));
  assert.equal(later.length, 5);
  const selected = (step, {earlierFailure = true, compile = true, lint = 'success', cancelled = false} = {}) => {
    const expression = step.if.slice(3, -2).trim();
    // Actions supplies success() unless an explicit status function is present.
    if (earlierFailure && !/\\b(?:always|cancelled|failure|success)\\s*\\(/u.test(expression)) return false;
    return Boolean(new Script(expression).runInNewContext({
      inputs: {'compile-inputs-changed': compile}, steps: {'native-lint': {outcome: lint}},
      cancelled: () => cancelled,
    }, {timeout: 100}));
  };
  for (const step of later) {
    assert.equal(selected(step), true, step.name ?? step.uses);
    assert.equal(selected(step, {earlierFailure: false}), true);
    assert.equal(selected(step, {cancelled: true}), false);
    assert.equal(selected(step, {compile: false}), false);
    for (const lint of ['failure', 'skipped', 'cancelled'])
      assert.equal(selected(step, {lint}), false);
  }
  assert.equal(job.steps.find(step => step.name === 'Type-check and lint the library and binaries').id, 'native-lint');
  const isolated = job.steps.find(step => step.name === 'Verify isolated native behavior regressions');
  assert.match(isolated.run, /--no-fail-fast/u);
  assert.equal(isolated['continue-on-error'], undefined);
  for (const step of later) assert.equal(step['continue-on-error'], undefined);
  const binding = later.find(step => step.name === 'Verify native unresolved-language source binding');
  // Run the actual shell body against a finite stub: either failure must still
  // run its sibling and leave the step failed; two successes must succeed.
  const directory = mkdtempSync(join(tmpdir(), 'native-replay-failures-'));
  try {
    const stub = join(directory, 'cargo');
    writeFileSync(stub, '#!/bin/sh\\nprintf "%s\\\\n" "$*" >> "$REPLAY_CALLS"\\ncase "$*" in *" --lib "*) exit "$REPLAY_LIBRARY_STATUS";; *) exit "$REPLAY_SPANISH_STATUS";; esac\\n', {mode: 0o755});
    for (const [library, spanish, expected] of [[1,0,1],[0,1,1],[0,0,0]]) {
      const calls = join(directory, `calls-${library}-${spanish}.txt`);
      const result = spawnSync('bash', ['-e', '-c', binding.run], {encoding:'utf8', timeout:5000,
        env:{...process.env, PATH:directory+':'+process.env.PATH, REPLAY_CALLS:calls,
          REPLAY_LIBRARY_STATUS:String(library), REPLAY_SPANISH_STATUS:String(spanish)}});
      assert.equal(result.status, expected, result.stderr);
      const commands = read(calls).trim().split('\\n');
      assert.equal(commands.length, 2);
      assert.match(commands[0], /--lib solver_unknown_reasoning::tests::/u);
      assert.match(commands[1], /--test any_language/);
    }
  } finally { rmSync(directory, {recursive:true, force:true}); }
});
'''
policy.write_text(text)
args=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',str(policy.relative_to(root))];env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256');records=[]
def run(name,expected,counts):
 started=time.monotonic();r=subprocess.run(args,cwd=root,env=env,capture_output=True);raw=r.stdout+r.stderr;packed=gzip.compress(raw,mtime=0);(base/(name+'.log.gz')).write_bytes(packed);actual={key:int(re.search(r'^(?:ℹ|#) '+key+r' (\d+)',raw.decode(),re.M)[1]) for key in ['tests','pass','fail','skipped']};row={'name':name,'argv':args,'exitCode':r.returncode,'seconds':round(time.monotonic()-started,3),'counts':actual,'file':name+'.log.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'lines':len(raw.splitlines())};records.append(row);(base/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True);assert r.returncode==expected and actual==counts,(r.returncode,actual)
run('before',1,{'tests':28,'pass':26,'fail':2,'skipped':0})
text=workflow.read_text();needle='      - name: Type-check and lint the library and binaries\n';assert text.count(needle)==1;text=text.replace(needle,needle+'        id: native-lint\n');assert text.count(command)==1;text=text.replace(command,command.replace('--locked','--locked --no-fail-fast'))
start=text.index('      - name: Verify native unresolved-language source binding\n');head=text[:start];tail=text[start:];guard="${{ !cancelled() && inputs.compile-inputs-changed && steps.native-lint.outcome == 'success' }}";assert tail.count('${{ inputs.compile-inputs-changed }}')==5;tail=tail.replace('${{ inputs.compile-inputs-changed }}',guard)
old='''          cargo test --manifest-path rust/Cargo.toml --locked --lib solver_unknown_reasoning::tests:: -- --test-threads=1
          cargo test --manifest-path rust/Cargo.toml --locked --test any_language a_language_without_localized_openers_reports_a_gap_not_english -- --exact --test-threads=1
'''
new='''          regression_status=0
          cargo test --manifest-path rust/Cargo.toml --locked --lib solver_unknown_reasoning::tests:: -- --test-threads=1 || regression_status=$?
          cargo test --manifest-path rust/Cargo.toml --locked --test any_language a_language_without_localized_openers_reports_a_gap_not_english -- --exact --test-threads=1 || regression_status=$?
          exit "$regression_status"
'''
assert old in tail;workflow.write_text(head+tail.replace(old,new))
fragment=root/'changelog.d/issue-1580-native-failure-collection.md';assert not fragment.exists();fragment.write_text('Collect independent native regression failures in one CI run while retaining failed job status.\n')
run('after',0,{'tests':28,'pass':28,'fail':0,'skipped':0})
(base/'outcome.json').write_text(json.dumps({'complete':True,'allPassedAfterFix':True,'regressionReproduced':True,'nativeExecutedLocally':False,'shellFailureControls':3,'independentAuthorshipCredit':0},indent=2)+'\n')
