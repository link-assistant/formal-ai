from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/ci/published-6b1d75a6/initial-failed-jobs';base.mkdir(exist_ok=True)
for job in [134475584343,134475516431]:
 target=base/f'job-{job}.log.gz';receipt=base/f'job-{job}.json'
 if receipt.exists():print(receipt.read_text());continue
 run=subprocess.run(['gh','api',f'repos/link-assistant/formal-ai/actions/jobs/{job}/logs'],cwd=root,capture_output=True)
 if run.returncode:print(json.dumps({'job':job,'exitCode':run.returncode,'stderr':run.stderr.decode()}));continue
 data=run.stdout;assert data and not data.startswith(b'PK'),data[:200];target.write_bytes(gzip.compress(data,mtime=0))
 value={'job':job,'head':'6b1d75a62a610e58914ef594c107f3fa402ded9d','endpoint':f'repos/link-assistant/formal-ai/actions/jobs/{job}/logs','rawBytes':len(data),'rawLines':len(data.splitlines()),'rawSha256':hashlib.sha256(data).hexdigest(),'log':target.name,'independentAuthorshipCredit':0}
 receipt.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value))
 lines=data.decode().splitlines()
 for number,line in enumerate(lines,1):
  if any(marker in line for marker in ['not ok ','error:','Error:','##[error]','fatal:','failed','Error [']):print(f'{number}: {line[:700]}')
