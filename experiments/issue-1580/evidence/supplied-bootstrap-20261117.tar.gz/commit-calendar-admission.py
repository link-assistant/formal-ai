from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/spoken-scheduling-paraphrases/after-refactor';report=json.loads((base/'review.json').read_text());assert report['allPassed'] and report['focusedCounts']['pass']==111 and report['gateCounts']=={'PASS':87,'FAIL':0,'SKIP':52}
def run(args):return subprocess.run(args,cwd=root,text=True,capture_output=True,check=True).stdout.strip()
assert run(['git','branch','--show-current'])=='issue-1580-8d61a32a61e1'
assert run(['git','rev-parse','HEAD'])=='0875e4c94a7636c31bb53cdaff16c494e4113049'
assert not run(['git','diff','--cached','--name-only'])
for name,digest in report['sourceHashes'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
paths=[name for name in report['sourceHashes'] if name!='scripts/lib/generated-native-programs.mjs'];assert len(paths)==6
run(['git','add','--',*paths]);assert set(run(['git','diff','--cached','--name-only']).splitlines())==set(paths)
run(['git','diff','--cached','--check']);print(run(['git','-c','gc.auto=0','commit','-m','Recognize shared scheduling acts within calendar request spans']))
result={'head':run(['git','rev-parse','HEAD']),'files':paths,'allFocusedChecksPassed':True,'allExecutableGatesPassed':True,'pushExecuted':False,'nativeVerification':'pending hosted execution','independentAuthorshipCredit':0}
(base/'source-commit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
