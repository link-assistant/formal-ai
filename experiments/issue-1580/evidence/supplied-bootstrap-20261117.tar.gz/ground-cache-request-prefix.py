from pathlib import Path
import gzip, hashlib, json, os, subprocess, time
root=Path('/tmp/gh-issue-solver-1794900398048')
initial=root/'experiments/issue-1580/evidence/checks/complete-cache-main-validation/outcome.json'
assert initial.exists(), 'Collect every result of the initial full run before modifying its tree'
base=root/'experiments/issue-1580/evidence/checks/complete-cache-request-binding/semantic-grounding'
base.mkdir(exist_ok=False)
rows=[]
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=256'
def run(name,args):
 started=time.monotonic()
 p=subprocess.run(args,cwd=root,env=env,capture_output=True)
 record={'name':name,'argv':args,'exitCode':p.returncode,'seconds':round(time.monotonic()-started,3)}
 for kind,raw in [('stdout',p.stdout),('stderr',p.stderr)]:
  filename=name+'.'+kind+'.gz';(base/filename).write_bytes(gzip.compress(raw,mtime=0))
  record[kind]={'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'lines':len(raw.splitlines())}
 rows.append(record);(base/'records.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 return p
before=run('before-closure-audit',['python3','scripts/check-closure-audit.py'])
assert before.returncode==1 and b'measured 1036 / reviewed 1035' in before.stdout
notation=run('before-notation',['node','scripts/measure-notation.mjs','--check'])
assert notation.returncode==1 and b'underscore-names rose from 9267 to 9268' in notation.stderr
for filename in ['data/seed/code-task-cues.lino','rust/src/solver_unknown_reasoning.rs']:
 target=root/filename;previous=target.read_text()
 assert previous.count('cache_request_prefix')==1
 target.write_text(previous.replace('cache_request_prefix','cache-request-prefix'))
path=root/'data/seed/meanings-concept-lookup.lino'
old=path.read_text()
assert '  cache-request-prefix\n' not in old
addition='''  cache-request-prefix
    defined-by concept
    role request_prefix
    precondition "The complete request starts with an authored public-cache instruction cue."
    effect "Removes only that leading cue and binds the entire remaining subject to an exact cached concept surface."
    unit "not applicable"
    example "Use cached public knowledge about WebAssembly binds WebAssembly; an operative request containing about grants no cache instruction."
    grounding "src/solver_unknown_reasoning.rs::cached_public_request_subject"
'''
assert old.startswith('meanings\n')
path.write_text('meanings\n'+addition+old[len('meanings\n'):])
after=run('after-closure-audit',['python3','scripts/check-closure-audit.py'])
assert after.returncode==0 and b'measured 1035 / reviewed 1035' in after.stdout
ratchet=root/'data/meta/notation-ratchet.lino';before_ratchet=ratchet.read_bytes()
assert run('lower-notation-ceilings',['node','scripts/measure-notation.mjs','--write']).returncode==0
assert run('after-notation',['node','scripts/measure-notation.mjs','--check']).returncode==0
(base/'notation-ratchet.before.gz').write_bytes(gzip.compress(before_ratchet,mtime=0))
assert run('rustfmt',['rustfmt','--edition','2024','--check','rust/src/solver_unknown_reasoning.rs','rust/tests/unit/solver_unknown_reasoning_captured_sources.rs']).returncode==0
assert run('sync-seed',['bash','scripts/sync-seed.sh']).returncode==0
assert run('mirror-package-data',['node','scripts/mirror-package-data.mjs','--write']).returncode==0
assert run('runtime-feature-inventory',['node','scripts/generate-runtime-feature-inventory.mjs','--write']).returncode==0
assert run('typescript-projection',['node','scripts/translate-es.mjs','--check']).returncode==0
assert run('whitespace',['git','diff','--check']).returncode==0
p=run('source-diff',['git','diff','--','data/seed/code-task-cues.lino','rust/src/solver_unknown_reasoning.rs','data/seed/meanings-concept-lookup.lino','rust/embedded/data/seed/code-task-cues.lino','rust/embedded/data/seed/meanings-concept-lookup.lino','data/meta/runtime-feature-coverage.json','data/meta/notation-ratchet.lino'])
assert p.returncode==0
canonical=path.read_bytes()
assert canonical==(root/'js/seed/meanings-concept-lookup.lino').read_bytes()==(root/'rust/embedded/data/seed/meanings-concept-lookup.lino').read_bytes()
(base/'outcome.json').write_text(json.dumps({'nativeExecutedLocally':False,'independentAuthorshipCredit':0,
 'reviewedCeilingUnchanged':True,'beforeMeasured':1036,'afterMeasured':1035,
 'canonicalAndBothMirrorsEqual':True,'fullRevalidationPending':True,
 'canonicalSha256':hashlib.sha256(canonical).hexdigest()},indent=2)+'\n')
