from pathlib import Path
import json,subprocess
out=Path('/tmp/issue-1580-research/summary-governed-publication')
if (out/'outcome.json').exists():
 data=json.loads((out/'outcome.json').read_text());data['recordsCount']=len(data.pop('records'));print(json.dumps(data,indent=2))
else: print('RUNNING')
if (out/'worker.log').exists():
 lines=(out/'worker.log').read_text().splitlines();print('\n'.join(lines[-8:]))
if (out/'staged-gates.stdout').exists():print((out/'staged-gates.stdout').read_text())
subprocess.run(['git','log','-2','--format=%h %s'],check=True)
