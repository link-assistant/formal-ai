from pathlib import Path
import subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
print('BRANCH', subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip())
print('STATUS', subprocess.check_output(['git', 'status', '--short'], cwd=root, text=True))
for name in [
    '/tmp/issue-1580-research/record-java-historical-pages-through-14.py',
    '/tmp/issue-1580-research/read-java-historical-page-chunk.py',
    '/tmp/issue-1580-research/run-main-015a6831-all-gates.py',
    '/tmp/issue-1580-research/seal-main-015a6831-merge.py',
]:
    p = Path(name)
    lines = p.read_text().splitlines()
    assert len(lines) <= 1500
    print('\nFILE', name, 'LINES', len(lines))
    for n, line in enumerate(lines, 1):
        print(f'{n}: {line}')
