from pathlib import Path
import json,subprocess
root=Path("/tmp/gh-issue-solver-1794900398048")
def run(*args):
    return subprocess.run(["git",*args],cwd=root,text=True,capture_output=True)
assert run("branch","--show-current").stdout.strip()=="issue-1580-8d61a32a61e1"
assert run("rev-parse","HEAD").stdout.strip()=="da712fadd3f680668c063a6d7de073ef1d52573b"
assert not run("status","--porcelain").stdout.strip()
assert run("rev-parse","origin/main").stdout.strip()=="512ce428029a92687628b4180309ee5ab660fe08"
result=run("merge","--no-commit","origin/main")
directory=root/"experiments/issue-1580/evidence/checks/main-merge-512ce428"
directory.mkdir()
(directory/"merge-initial.json").write_text(json.dumps({"status":result.returncode,"stdout":result.stdout,"stderr":result.stderr,"ours":"da712fadd3f680668c063a6d7de073ef1d52573b","theirs":"512ce428029a92687628b4180309ee5ab660fe08"},indent=2)+"\n")
print("MERGE",result.returncode,result.stdout,result.stderr)
unmerged=run("diff","--name-only","--diff-filter=U").stdout.splitlines()
print("UNMERGED",unmerged)
for name in unmerged:
    lines=(root/name).read_text().splitlines()
    assert len(lines)<200
    print("CONFLICT",name)
    for n,line in enumerate(lines,1):print(f"{n}: {line}")
