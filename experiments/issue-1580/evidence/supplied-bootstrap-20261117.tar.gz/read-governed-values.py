from pathlib import Path
p=Path('/tmp/issue-1580-research/layered-44156399182.log')
for i,line in enumerate(p.open(),1):
    if 8204 <= i <= 8268:
        print(f'{i}: {line.rstrip()}')
for f in ['experiments/issue-1580/work-plan.md','docs/case-studies/issue-1580/README.md']:
    p=Path(f); lines=p.read_text().splitlines()
    print('TAIL',f,'LINES',len(lines))
    for n,line in enumerate(lines[-40:],len(lines)-39): print(f'{n}: {line}')
