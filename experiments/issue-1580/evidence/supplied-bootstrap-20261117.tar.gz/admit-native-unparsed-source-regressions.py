from pathlib import Path

root=Path('/tmp/gh-issue-solver-1794900398048')
path=root/'rust/src/solver_unknown_reasoning.rs'
text=path.read_text()
start=text.index('\n#[cfg(test)]\nmod tests {\n')
body=text[start+len('\n#[cfg(test)]\nmod tests {\n'):]
assert body.endswith('}\n')
body=body[:-2]
body='\n'.join(line[4:] if line.startswith('    ') else line for line in body.splitlines())+'\n'
assert body.count('questioning_rigor: 0.8,')==1
body=body.replace('questioning_rigor: 0.8,','questioning_rigor: 0.4,')
tests=root/'rust/src/solver_unknown_reasoning_tests.rs'
assert not tests.exists()
tests.write_text(body)
path.write_text(text[:start]+'\n#[cfg(test)]\n#[path = "solver_unknown_reasoning_tests.rs"]\nmod tests;\n')

path=root/'rust/Cargo.toml'
text=path.read_text()
anchor='''[[test]]
name = "integration"'''
insert='''# Execute the unchanged unsupported-language sibling contract in the focused PR lane.
[[test]]
name = "any_language"
path = "tests/unit/issue_706_any_language.rs"

'''
assert text.count(anchor)==1
path.write_text(text.replace(anchor,insert+anchor))

path=root/'.github/workflows/native-type-check.yml'
text=path.read_text()
anchor='''      - uses: actions/setup-node@v7
'''
insert='''      - name: Verify native unresolved-language source binding
        if: ${{ inputs.compile-inputs-changed }}
        env:
          CARGO_BUILD_JOBS: '2'
          CARGO_PROFILE_TEST_OPT_LEVEL: '0'
        run: |
          cargo test --manifest-path rust/Cargo.toml --locked --lib solver_unknown_reasoning::tests:: -- --test-threads=1
          cargo test --manifest-path rust/Cargo.toml --locked --test any_language a_language_without_localized_openers_reports_a_gap_not_english -- --exact --test-threads=1
'''
assert text.count(anchor)==1
path.write_text(text.replace(anchor,insert+anchor))

path=root/'scripts/ci-pull-request-admission.mjs'
text=path.read_text()
anchor="  'rust/tests/unit/specification/synthesis.rs',\n"
assert text.count(anchor)==1
text=text.replace(anchor,anchor+"  'rust/tests/unit/issue_706_any_language.rs',\n  'rust/tests/fixtures/issue-1138-b1/expected-senses.json',\n")
path.write_text(text)

path=root/'rust/tests/web/default-branch-build-policy.test.mjs'
text=path.read_text()
anchor='''// The production-only failure this job closes: PR #1497 was green, then main
'''
insert='''test('native unsupported-language regressions execute the captured-source units and unchanged sibling contract', () => {
  const step = Object.values(workflow('native-type-check.yml').jobs)[0].steps
    .find(step => step.name === 'Verify native unresolved-language source binding');
  assert.equal(step.if, '${{ inputs.compile-inputs-changed }}');
  assert.deepEqual(step.env, {CARGO_BUILD_JOBS: '2', CARGO_PROFILE_TEST_OPT_LEVEL: '0'});
  assert.deepEqual(step.run.trim().split('\\n'), [
    'cargo test --manifest-path rust/Cargo.toml --locked --lib solver_unknown_reasoning::tests:: -- --test-threads=1',
    'cargo test --manifest-path rust/Cargo.toml --locked --test any_language a_language_without_localized_openers_reports_a_gap_not_english -- --exact --test-threads=1',
  ]);
  const target = read('rust/Cargo.toml').split('[[test]]').find(block => /^name = "any_language"$/mu.test(block));
  assert.match(target, /^path = "tests\\/unit\\/issue_706_any_language.rs"$/mu);
  const source = 'rust/src/solver_unknown_reasoning_tests.rs';
  const fixture = relative(process.cwd(), resolve(dirname(source), /include_str!\\(\\s*"([^"]+)"/u.exec(read(source))[1]));
  for (const path of [source, 'rust/src/solver_unknown_reasoning.rs', 'rust/tests/unit/issue_706_any_language.rs', fixture]) {
    assert(readFileSync(path).length > 0, path);
    assert.equal(admission([path])['native-type-check'], true, path);
  }
  assert.equal(admission(['rust/tests/fixtures/issue-1138-b1/unrelated.json'])['native-type-check'], false);
});
'''
assert text.count(anchor)==1
path.write_text(text.replace(anchor,insert+anchor))
print('Added focused hosted execution for four captured-source units and the unchanged native Spanish sibling contract, with source/fixture admission coverage.')
