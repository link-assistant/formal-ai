from pathlib import Path
import gzip,hashlib,json,subprocess

repo='link-assistant/formal-ai';branch='issue-1580-8d61a32a61e1'
old='e582b270a01443b995d7f36fd2fa685d508fde77'
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()==branch
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==old
for command in [
 ['python3','experiments/issue-1580/archive-evidence.py'],
 ['python3','/tmp/issue-1580-research/archive-round-bootstrap.py'],
]:
 print(subprocess.check_output(command,text=True).strip())
base=Path('experiments/issue-1580/evidence/checks/csharp-changeset-collision')
checks=[]
for gate in ['check-file-size','check-file-size-js-twin']:
 command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]
 result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log=base/('archive-'+gate+'.log.gz');log.write_bytes(gzip.compress(result.stdout,mtime=0))
 checks.append({'gate':gate,'command':command,'exitCode':result.returncode,'log':str(log),'sha256':hashlib.sha256(result.stdout).hexdigest()})
 print(result.stdout.decode())
 assert result.returncode==0
(base/'archive-size-gates.json').write_text(json.dumps(checks,indent=2)+'\n')
subprocess.run(['git','add','docs/case-studies/issue-1580','experiments/issue-1580','rust/tests/web/issue-1580-template-observations.test.mjs'],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
record=json.loads((base.parent/'csharp-changeset-integrity.json').read_text())
test=Path(record['regression'])
assert hashlib.sha256(test.read_bytes()).hexdigest()==record['checks']['after']['testSha256']
assert subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD']).returncode==0
for state in ['in_progress','queued']:
 runs=json.loads(subprocess.check_output(['gh','run','list','--repo',repo,'--branch',branch,'--status',state,'--json','databaseId,workflowName,headSha'],text=True))
 assert not runs,(state,runs)
 print(state,runs)
runs=json.loads(subprocess.check_output(['gh','run','list','--repo',repo,'--branch',branch,'--limit','100','--json','databaseId,status,conclusion,headSha'],text=True))
current=[r for r in runs if r['headSha']==old]
assert len(current)==24 and all(r['status']=='completed' and r['conclusion']=='success' for r in current)
print('Previous-head results collected:',len(current),'success')
subprocess.run(['git','commit','-m','test: reproduce C# changeset merge output collisions'],check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
subprocess.run(['git','push','origin','HEAD:'+branch],check=True)
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
Path('/tmp/issue-1580-research/csharp-evidence-published-head.txt').write_text(head+'\n')
print(json.dumps({'publishedHead':head,'branch':branch,'pullRequest':'https://github.com/link-assistant/formal-ai/pull/1581','treeClean':True,'goalComplete':False},indent=2))
