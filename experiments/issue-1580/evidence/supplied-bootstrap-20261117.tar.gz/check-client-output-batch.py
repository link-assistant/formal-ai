import gzip,hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path('experiments/issue-1580/evidence/checks/main-merge-826289fc')
status=Path('/tmp/issue-1580-research/client-focused-status.json')
files=[
 'rust/tests/web/issue-1587-request-context.test.mjs',
 'rust/tests/web/source-read-provenance.test.mjs',
 'rust/tests/web/source-read-owned-provider.test.mjs',
 'rust/tests/web/source-read-consumers.test.mjs',
 'rust/tests/web/line-slice-read-ownership.test.mjs',
 'rust/tests/web/main-only-regressions.test.mjs',
 'rust/tests/web/fast-pull-request-javascript-profile.test.mjs',
]
if sys.argv[-1]=='start':
    log=open('/tmp/issue-1580-research/client-focused-runner.log','wb')
    proc=subprocess.Popen([sys.executable,__file__,'run'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps(dict(pid=proc.pid,status=str(status))))
elif sys.argv[-1]=='status':
    print(status.read_text() if status.exists() else 'not yet started')
else:
    rows=[];status.write_text(json.dumps(dict(pid=os.getpid(),state='running',rows=rows)))
    for file in files:
        name=Path(file).name.removesuffix('.test.mjs');log=Path('/tmp/issue-1580-research/'+name+'-client-batch.log')
        start=time.monotonic()
        with log.open('wb') as out:
            result=subprocess.run(['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',file],stdout=out,stderr=subprocess.STDOUT)
        data=log.read_bytes();(root/(name+'-client-batch.log.gz')).write_bytes(gzip.compress(data,mtime=0))
        rows.append(dict(file=file,exitCode=result.returncode,seconds=round(time.monotonic()-start,3),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
        status.write_text(json.dumps(dict(pid=os.getpid(),state='running',rows=rows),indent=2))
    metadata=dict(state='complete',rows=rows)
    (root/'client-focused-tests.json').write_text(json.dumps(metadata,indent=2)+'\n');status.write_text(json.dumps(metadata,indent=2))
