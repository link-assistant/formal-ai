from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
out=Path('/tmp/issue-1580-research/header-pr-review');out.mkdir(exist_ok=True)
head='d0b8b895661c6b5e809810c4da8a3db9f79138b3'
pr=json.loads(subprocess.check_output(['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','headRefOid,isDraft,url'],text=True));assert pr['headRefOid']==head
path=out/'full.diff'
with path.open('wb') as stream:
 attempt=subprocess.run(['gh','pr','diff','1581','--repo','link-assistant/formal-ai','--color','never'],stdout=stream,stderr=subprocess.PIPE)
(out/'github-diff-error.txt').write_bytes(attempt.stderr)
if attempt.returncode:
 assert b'maximum number of files (300)' in attempt.stderr,attempt.stderr
 inventory=subprocess.check_output(['gh','api','repos/link-assistant/formal-ai/pulls/1581/files?per_page=100','--paginate','--jq','[.[] | {filename,status,sha,additions,deletions,changes}]'],stderr=subprocess.PIPE).decode()
 decoder=json.JSONDecoder();rows=[]
 while inventory.strip():
  page,end=decoder.raw_decode(inventory.lstrip());rows.extend(page);inventory=inventory.lstrip()[end:]
 (out/'github-file-inventory.json.gz').write_bytes(gzip.compress(json.dumps(rows,indent=2).encode(),mtime=0))
 with path.open('wb') as stream:
  subprocess.run(['git','diff','--no-ext-diff','origin/main...'+head],stdout=stream,check=True)
digest=hashlib.sha256();line_count=0
with path.open('rb') as source,gzip.open(out/'full.diff.gz','wb') as target:
 for line in source:
  digest.update(line);line_count+=1;target.write(line)
changed=set(subprocess.check_output(['git','diff','--name-only','1cc2d536a',head],text=True).splitlines())
blocks=[];block=[];name=None
with path.open() as stream:
 for raw_line in stream:
  line=raw_line.rstrip('\n')
  if line.startswith('diff --git a/'):
   if block:blocks.append((name,block))
   name=line.split(' b/',1)[1];block=[]
  if name in changed and name.endswith('.mjs') and '/fixtures/' not in name:block.append(line)
if block:blocks.append((name,block))
selected=[(name,block) for name,block in blocks if name in changed and name.endswith('.mjs') and '/fixtures/' not in name]
lines=[line for name,block in selected for line in block]
(out/'new-source.diff').write_text('\n'.join(lines)+'\n')
meta={'head':head,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'githubDiffStatus':attempt.returncode,'githubDiffLimit300Files':attempt.returncode!=0,'fallback':'complete local base-to-head diff and paginated GitHub file inventory' if attempt.returncode else None,'fullDiffLines':line_count,'fullDiffRawSha256':digest.hexdigest(),'newSourceFiles':[name for name,block in selected],'newSourceLines':len(lines),'pageSize':350,'pages':(len(lines)+349)//350}
(out/'summary.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2))
