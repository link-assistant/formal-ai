from pathlib import Path
import json

for name in [
 'experiments/issue-1580/upstream/java-release-commit-integrity-report.md',
 'experiments/issue-1580/upstream/template-report-identities.json',
 'experiments/issue-1580/upstream/filed-issues.txt',
]:
 print('\nFILE '+name+'\n'+Path(name).read_text())
p=Path('/tmp/issue-1580-research/pr-before-eighth.json')
j=json.loads(p.read_text())
print('\nPR BODY\n'+j['body'])
for name in ['work-plan.md','docs/case-studies/issue-1580/templates/README.md']:
 lines=Path(name).read_text().splitlines()
 print('\nFILE '+name+' lines='+str(len(lines)))
 if len(lines)<1500:
  print('\n'.join(f'{i+1}: {s}' for i,s in enumerate(lines)))
 else:
  print('\n'.join(f'{i+1}: {s}' for i,s in enumerate(lines) if 'Java' in s or 'e662' in s or '1580' in s or 'unverified' in s or 'unfinished' in s))
