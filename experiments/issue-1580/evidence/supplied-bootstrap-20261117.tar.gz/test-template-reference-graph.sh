set -eu
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-reference-graph.test.mjs > /tmp/issue-1580-research/template-reference-graph-tests.log 2>&1
tail -n 14 /tmp/issue-1580-research/template-reference-graph-tests.log
node --max-old-space-size=128 experiments/issue-1580/trace-template-ci.mjs > /tmp/issue-1580-research/template-reference-graph-summary.json
cat /tmp/issue-1580-research/template-reference-graph-summary.json
git diff --check
