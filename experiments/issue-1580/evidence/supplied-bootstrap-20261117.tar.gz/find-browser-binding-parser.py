from pathlib import Path
import subprocess
for args in [['rg','-n','browserHandlerPrecedence|browser.handler.precedence|startsWith\("argument_"\)|argument_userContext','js','scripts/lib','rust/tests/web'],['rg','--files','rust/tests/web']]:
 r=subprocess.run(args,capture_output=True);text=r.stdout.decode()
 if args[-1]=='rust/tests/web' and args[1]=='--files':text='\n'.join(l for l in text.splitlines() if any(x in l for x in ['browser','seed-loader','seed_loader','dispatch','precedence']))
 print(text);print(r.stderr.decode())
lines=Path('CONTRIBUTING.md').read_text().splitlines()
for a,b in [(1,138),(530,580),(1424,1456)]:
 print('CONTRIBUTING',a,b)
 for n in range(a,b+1):print(n,lines[n-1])
