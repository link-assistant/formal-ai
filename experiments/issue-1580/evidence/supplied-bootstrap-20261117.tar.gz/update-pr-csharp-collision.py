from pathlib import Path
import json, subprocess

repo = 'link-assistant/formal-ai'
base = Path('/tmp/issue-1580-research')
def run(args):
    return subprocess.run(args, check=True, text=True, capture_output=True).stdout
state = json.loads(run(['gh','pr','view','1581','--repo',repo,'--json','body,headRefOid,isDraft,title,url']))
assert state['isDraft'] is True
assert state['headRefOid'] == (base/'csharp-evidence-published-head.txt').read_text().strip()
body = state['body']
replacements = [
    ("The latest batch repairs the template review graph's omission of GitHub `$/` self-repository references, with nested-action/workflow and negative regressions.", "The latest batch adds an executable C# changeset-loss reproduction: a generated output filename can collide with a valid input, so the merge exits successfully after deleting every changeset. A disposable exclusive-write control preserves both inputs; no upstream repair is claimed. The preceding batch repairs the template review graph's omission of GitHub `$/` self-repository references, with nested-action/workflow and negative regressions."),
    ("The seven other complete semantic reviews remain open.", "The recorded C# checkpoint covers 120 of 158 active files, with all 337 blobs hash-verified; 38 active and 179 historical files remain semantically unread at that checkpoint. The seven other complete semantic reviews remain open."),
    ("The maintained template suite passes twenty-one tests locally", "The maintained template suite passes twenty-five tests locally"),
    ("The focused graph and Java suites each pass five cases.", "The focused graph and Java suites each pass five cases; the focused C# suite passes four cases. The unchanged C# helper loses both valid inputs under the bounded collision probe, and its preservation regression fails before the disposable fix. Noncolliding successful merges retain the major bump and both descriptions; malformed input remains fatal without mutation."),
    ("All 24 workflows on each published head `09021cb30e`, `e6627385d` and `078849576b` completed successfully. The self-repository reference batch at `e582b270a0` is under verification. C# semantic review is partial; full remaining repository reviews stay open.", "All 24 workflows on each published head `09021cb30e`, `e6627385d`, `078849576b` and `e582b270a0` completed successfully. For `e582b270a0`, the initial JavaScript shard checkout failed with a transport timeout and missing promisor object before tests started; a failed-job-only retry on that same SHA passed, and both attempts are retained. The C# evidence head `0f90c0a7a3` is under verification. C# semantic review is partial; full remaining repository reviews stay open."),
    ("Shared template reports: [C++ #35]", "Shared template reports: [C# changeset loss #111](https://github.com/link-foundation/csharp-ai-driven-development-pipeline-template/issues/111), [C++ #35]"),
]
for old, new in replacements:
    assert body.count(old) == 1, old
    body = body.replace(old, new)
assert body.startswith('Fixes #1580\n')
before = base/'pr-csharp-collision-before.json'
before.write_text(json.dumps(state, indent=2)+'\n')
body_file = base/'pr-csharp-collision-body.md'
body_file.write_text(body)
run(['gh','pr','edit','1581','--repo',repo,'--body-file',str(body_file)])
after = json.loads(run(['gh','pr','view','1581','--repo',repo,'--json','body,headRefOid,isDraft,title,url']))
assert after['body'] == body and after['isDraft'] is True
(base/'pr-csharp-collision-after.json').write_text(json.dumps(after, indent=2)+'\n')
print(json.dumps({'pullRequest':after['url'],'head':after['headRefOid'],'draft':after['isDraft'],'bodyVerified':True,'closingReference':'Fixes #1580','goalComplete':False}, indent=2))
