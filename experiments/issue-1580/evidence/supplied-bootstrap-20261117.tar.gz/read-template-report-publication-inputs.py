from pathlib import Path
import json, subprocess

base=Path('/tmp/issue-1580-research/picomatch-template-research')
for name in ['draft-heads.json','summary.json','js-report.md','python-report.md','cpp-report.md']:
    path=base/name
    print('FILE',path)
    print(path.read_text())
path=Path('experiments/issue-1580/upstream/template-report-identities.json')
print('REPORT REGISTRY',path.read_text())
head='83882c0ec7c26b28dc8ac274fada2b39d9dc3a67'
result=subprocess.run(['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--commit',head,'--limit','100','--json','databaseId,workflowName,status,conclusion,createdAt,headSha,url'],text=True,capture_output=True,check=True)
(base/'published-head-runs-initial.json').write_text(result.stdout)
runs=json.loads(result.stdout)
print('NEW HEAD RUNS',len(runs))
for item in runs:print(item['databaseId'],item['workflowName'],item['status'],item['conclusion'])
