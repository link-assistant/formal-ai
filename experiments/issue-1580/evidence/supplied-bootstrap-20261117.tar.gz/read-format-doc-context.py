from pathlib import Path
import gzip,json,subprocess

for name,count in [('experiments/issue-1580/work-plan.md',16),('/tmp/issue-1580-research/templates/python-complete/tests/test_release_badges.py',100),('experiments/issue-1580/upstream/python-audit-inventory-report.md',100)]:
    lines=Path(name).read_text().splitlines()
    print('FILE',name,'LINES',len(lines))
    print('\n'.join(f'{n}: {line}' for n,line in enumerate(lines,1) if n>len(lines)-count))
directory=Path('experiments/issue-1580/evidence/checks/python-release-formatting')
items=json.loads(gzip.decompress((directory/'duplicate-issues.json.gz').read_bytes()))
item=next(row for row in items if row['number']==6)
print('ISSUE 6',item['title']);print(item.get('body'))
for number,prefix in [(6,'issues'),(17,'issues'),(88,'issues')]:
    endpoint=f'{prefix}/{number}/comments'
    raw=subprocess.run(['gh','api','repos/link-foundation/python-ai-driven-development-pipeline-template/'+endpoint,'--paginate'],check=True,capture_output=True).stdout
    (directory/f'related-{prefix}-{number}-comments.json.gz').write_bytes(gzip.compress(raw,mtime=0))
    if number==6:
        for row in json.loads(raw):print(row.get('html_url'),row.get('body'))
