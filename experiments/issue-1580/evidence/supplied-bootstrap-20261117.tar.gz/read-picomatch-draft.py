from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
for name,start,end in [('packages/picomatch-compat/lib/parse.js',270,400),('rust/tests/web/picomatch-security-backport.test.mjs',1,240),('packages/picomatch-compat/upstream.json',1,100),('packages/picomatch-compat/README.md',1,120)]:
    lines=(root/name).read_text().splitlines()
    print(f'\n{name} ({len(lines)} lines)')
    for i in range(start-1,min(end,len(lines))):
        print(f'{i+1}: {lines[i]}')
