from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
root=Path('/tmp/issue-1580-research/templates/java-complete');inventory=json.loads(Path('/tmp/issue-1580-research/templates/java-complete-inventory.json').read_text());base=Path('experiments/issue-1580/evidence/checks/java-historical-structured-tail');base.mkdir(exist_ok=False);records=[]
for n in [2,3]:
 path=f'dev/log/issues/24/pulls/25/sources/transitive-registry-metadata-{n}.json';raw=(root/path).read_bytes();blob=next(r['gitBlob']for r in inventory if r['path']==path);assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob;obj=json.loads(raw);items=[];paths=set();unexpected=[]
 for coordinate,row in obj.items():
  if set(row)!={'source','xml'}:unexpected.append({'coordinate':coordinate,'keys':sorted(row)});continue
  xml=row['xml'];assert '<!DOCTYPE'not in xml and '<!ENTITY'not in xml,coordinate;tree=ET.fromstring(xml);assert tree.tag=='metadata',coordinate
  def walk(node,prefix=''):
   p=prefix+'/'+node.tag;paths.add(p)
   for child in node:walk(child,p)
  walk(tree)
  assert tree.findtext('groupId')+':'+tree.findtext('artifactId')==coordinate,coordinate
  group,artifact=coordinate.split(':');expected=f'https://repo.maven.apache.org/maven2/{group.replace(".","/")}/{artifact}/maven-metadata.xml';assert row['source']==expected,(coordinate,row['source'])
  versions=[x.text for x in tree.findall('versioning/versions/version')];items.append({'coordinate':coordinate,'source':row['source'],'xmlSha256':hashlib.sha256(xml.encode()).hexdigest(),'historicalLatest':tree.findtext('versioning/latest'),'historicalRelease':tree.findtext('versioning/release'),'historicalUpdated':tree.findtext('versioning/lastUpdated'),'versionCount':len(versions),'versionListSha256':hashlib.sha256(json.dumps(versions,separators=(',',':')).encode()).hexdigest(),'duplicateVersions':len(versions)-len(set(versions))})
 record={'path':path,'gitBlob':blob,'sha256':hashlib.sha256(raw).hexdigest(),'lines':len(raw.splitlines()),'bytes':len(raw),'jsonRecords':len(obj),'analyzedRecords':len(items),'xmlPaths':sorted(paths),'unexpected':unexpected,'records':items};records.append(record);print(json.dumps({k:v for k,v in record.items()if k!='records'}));print('ALL COORDINATES','; '.join(x['coordinate']for x in items))
for name in ['spotless-apply.log','spotless-upstream-report.txt','toolchains.log','transitive-inventory.log']:
 path='dev/log/issues/24/pulls/25/'+name;raw=(root/path).read_bytes();blob=next(r['gitBlob']for r in inventory if r['path']==path);assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob;print('FULL FILE',path);print(raw.decode());records.append({'path':path,'gitBlob':blob,'sha256':hashlib.sha256(raw).hexdigest(),'lines':len(raw.splitlines()),'bytes':len(raw),'fullLiteralRead':True})
report={'pinnedHead':'dd803a2d9fa5b3a992b435acce73162274fb9e8b','records':records,'literalContinuousPages':219,'literalTotalPages':254,'structuredComparisonIsNotLiteralPageRead':True,'fullIssueComplete':False,'independentAuthorshipCredit':0};(base/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print('analysis saved; unexpected metadata rows',sum(len(r.get('unexpected',[]))for r in records))
