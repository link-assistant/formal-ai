from pathlib import Path
import gzip,json,subprocess,hashlib
from datetime import datetime,timezone
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/checks/spelled-calendar-clock/feedback';b.mkdir(exist_ok=False);records=[]
for name,path in [('issue-comments','issues/1580/comments'),('conversation-comments','issues/1581/comments'),('inline-comments','pulls/1581/comments'),('reviews','pulls/1581/reviews')]:
 args=['gh','api','repos/link-assistant/formal-ai/'+path,'--paginate'];p=subprocess.run(args,cwd=r,capture_output=True);assert p.returncode==0,p.stderr.decode();raw=p.stdout;packed=gzip.compress(raw,mtime=0);(b/(name+'.json.gz')).write_bytes(packed);items=json.loads(raw);records.append({'name':name,'argv':args,'file':name+'.json.gz','count':len(items),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()});print(name,len(items),[(x['id'],x.get('updated_at',x.get('submitted_at'))) for x in items[-3:]])
(b/'records.json').write_text(json.dumps(records,indent=2)+'\n');(b/'observed-at.txt').write_text(datetime.now(timezone.utc).isoformat()+'\n')
