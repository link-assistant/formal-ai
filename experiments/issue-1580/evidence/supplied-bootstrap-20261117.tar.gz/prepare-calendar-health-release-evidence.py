from pathlib import Path
import gzip, hashlib, json

root=Path('/tmp/gh-issue-solver-1794900398048')
fragment=root/'changelog.d/20261117_120000_issue-1580-ci-regressions.md'
text=fragment.read_text()
addition='''- Keep calendar meaning identifiers unique and expand calendar/currency aliases into scalar seed rows, preserving every original spelling and the existing duration-sum response intent.
- Replay supported health access modes and offline source-cache fixtures in the fast PR lane, with explicit source-network policy and current TypeScript calendar mirrors.
'''
assert 'Keep calendar meaning identifiers unique' not in text
fragment.write_text(text+addition)
index=root/'experiments/issue-1580/evidence/ci/main-015a6831/native-panic-payload-index.json'
raw=index.read_bytes()
target=index.with_suffix('.json.gz')
target.write_bytes(gzip.compress(raw,mtime=0))
index.unlink()
reader=Path('/tmp/issue-1580-research/read-main-native-payload-range.py')
text=reader.read_text().replace('import json, sys','import gzip, json, sys')
text=text.replace("Path('experiments/issue-1580/evidence/ci/main-015a6831/native-panic-payload-index.json').read_text()", "gzip.decompress(Path('experiments/issue-1580/evidence/ci/main-015a6831/native-panic-payload-index.json.gz').read_bytes())")
reader.write_text(text)
print(json.dumps({'releaseTrigger':str(fragment.relative_to(root)),'panicIndex':str(target.relative_to(root)),'indexRawSha256':hashlib.sha256(raw).hexdigest(),'indexBytes':len(raw),'compressedBytes':target.stat().st_size,'reviewComplete':False}))
