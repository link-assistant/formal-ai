from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

directory=Path("experiments/issue-1580/evidence/checks/generated-header-memory")
labels=["quoted-passage","connector-receipts","browser-release","resume-policy","descendant-original","descendant-reaped","browser-reaped"]
for label in labels:
    record=json.loads((directory/(label+".json")).read_text())
    assert record["status"]==(1 if label=="browser-release" else 0)
    raw=gzip.decompress((directory/record["log"]).read_bytes())
    assert hashlib.sha256(raw).hexdigest()==record["rawSha256"]
    if label=="browser-reaped":
        assert re.search(r"^(?:#|ℹ) pass 11$",raw.decode(),re.M)
        assert re.search(r"^(?:#|ℹ) skipped 0$",raw.decode(),re.M)
    if label=="descendant-original":
        assert '"state":"Z","parent":1' in raw.decode()
    if label=="descendant-reaped":
        assert '"exists":false,"state":"ESRCH"' in raw.decode()
(directory/"browser-README.md").write_text("""# Deadline descendant test fixture

The newly merged main CI log retains a browser-release assertion against the obsolete ubuntu-latest label; the branch already checks the pinned ubuntu-24.04 baseline. Rechecking its whole suite exposed a separate container fixture problem: ten tests passed, but the exact descendant PID remained observable after timeout.

The bounded experiment runs the unchanged production deadline against the original fixture. It returns the required status 124 and observes the child in Linux state Z, adopted by PID 1: exited, but not reaped. In a second run the fixture parent waits for its child's exit event after the process-group TERM, without sending a signal to the child itself. The deadline again returns 124, and the exact PID reports ESRCH.

The test uses that cooperative reaper. The production deadline, timeout limits, expected status, permission-error rejection and exact ESRCH assertion are unchanged. A runner that leaves the descendant executing cannot satisfy the assertion through the parent's handler. The full browser suite now passes all eleven cases with zero skips in 2.873 seconds. Raw failing/passing logs and both process-state observations are retained. No live descendant remains from the completed probes.

The other fresh main JavaScript failures also pass on the merged branch: quoted-passage QA 15/15, connector receipts 20/20, and policy decoding 2/2, each with zero skips. This is supplied Codex work and receives zero independent Formal AI authorship credit.
""")
paths=["rust/tests/web/browser-engine-release-integration.test.mjs","experiments/issue-1580/browser-deadline-descendant.mjs",str(directory/"browser-README.md")]
for label in labels:paths.extend([str(directory/(label+".json")),str(directory/(label+".log.gz"))])
for command in [["git","diff","--check"],["git","add","--",*paths],["git","diff","--cached","--check"]]:
    subprocess.run(command,check=True)
print(subprocess.run(["git","diff","--cached","--stat"],capture_output=True,text=True,check=True).stdout)
subprocess.run(["git","commit","-m","test: reap deadline descendants before asserting their removal"],check=True,stdout=subprocess.PIPE)
print("HEAD",subprocess.run(["git","rev-parse","HEAD"],capture_output=True,text=True,check=True).stdout.strip())
