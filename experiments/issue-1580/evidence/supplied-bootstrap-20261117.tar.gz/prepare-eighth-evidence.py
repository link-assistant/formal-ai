from pathlib import Path
import subprocess

report = Path('experiments/issue-1580/upstream/java-release-commit-integrity-report.md')
text = report.read_text()
old = 'Publish this evidence before filing the report.'
assert text.count(old) == 1
text = text.replace(old, 'Immutable executable evidence: https://github.com/link-assistant/formal-ai/blob/ff5d883b15aeda06c07e509a73a0a436f10799b7/experiments/issue-1580/template-java-release-integrity.test.mjs. Filing remains pending until this commit is published.')
report.write_text(text)
subprocess.run(['python3', 'experiments/issue-1580/archive-evidence.py'], check=True)
subprocess.run(['python3', '/tmp/issue-1580-research/archive-round-bootstrap.py'], check=True)
subprocess.run(['git', 'diff', '--check'], check=True)
