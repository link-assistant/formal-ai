from pathlib import Path
import json
p=Path('scripts/ci-native-regressions.sh');p.write_text('''#!/usr/bin/env bash
# Compile once, then overlap two isolated processes. The benchmark module has
# its own serialization lock; every process retains one Rust test thread.
set -euo pipefail

native_targets=(--test calendar_currency --test openai_forced_functions --test meta_executor_parity --test synthesis_contracts --test cnl_output --test cnl_parity --test unknown_reasoning --test data_files --test scheduling_contracts --test operational_contracts --test reasoning_contracts)
cargo test --manifest-path rust/Cargo.toml --locked --no-run "${native_targets[@]}"
benchmark_log="$(mktemp "${RUNNER_TEMP:-${TMPDIR:-/tmp}}/formal-ai-native-benchmarks.XXXXXX.log")"
benchmark_pid=''
cleanup_native_regressions() {
  if [[ -n "$benchmark_pid" ]]; then
    kill "$benchmark_pid" 2>/dev/null || true
    wait "$benchmark_pid" 2>/dev/null || true
  fi
  cat "$benchmark_log"
  rm -f "$benchmark_log"
}
trap cleanup_native_regressions EXIT
cargo test --manifest-path rust/Cargo.toml --locked --test reasoning_contracts benchmarks:: -- --test-threads=1 >"$benchmark_log" 2>&1 &
benchmark_pid=$!
regression_status=0
cargo test --manifest-path rust/Cargo.toml --locked --no-fail-fast "${native_targets[@]}" -- --skip benchmarks:: --test-threads=1 || regression_status=$?
wait "$benchmark_pid" || regression_status=$?
benchmark_pid=''
exit "$regression_status"
''');p.chmod(0o755)
p=Path('.github/workflows/native-type-check.yml');t=p.read_text();old='        run: cargo test --manifest-path rust/Cargo.toml --locked --no-fail-fast --test calendar_currency --test openai_forced_functions --test meta_executor_parity --test synthesis_contracts --test cnl_output --test cnl_parity --test unknown_reasoning --test data_files --test scheduling_contracts --test operational_contracts --test reasoning_contracts -- --test-threads=1';assert t.count(old)==1;t=t.replace(old,'        run: bash scripts/ci-native-regressions.sh').replace('# or the classification is unknown. It uploads nothing and records no receipt.','# or the classification is unknown. Only deterministic fixture data is retained;\n# the focused lane publishes no products or semantic authorization.');p.write_text(t)
p=Path('scripts/ci-pull-request-admission.mjs');t=p.read_text();old="  'rust/examples/dump_google_trends_catalog.rs',";assert t.count(old)==1;p.write_text(t.replace(old,old+"\n  'docs/case-studies/issue-498/agent-cli-session-google-trends.json',"))
p=Path('rust/tests/web/default-branch-build-policy.test.mjs');t=p.read_text();needle="const workflow = name => YAML.parse(read('.github/workflows/' + name));";assert t.count(needle)==1;t=t.replace(needle,needle+'''
const nativeRegressionSource = step => {
  assert.equal(step.run, 'bash scripts/ci-native-regressions.sh');
  return read('scripts/ci-native-regressions.sh');
};''');old="    'cargo test --manifest-path rust/Cargo.toml --locked --no-fail-fast --test calendar_currency --test openai_forced_functions --test meta_executor_parity --test synthesis_contracts --test cnl_output --test cnl_parity --test unknown_reasoning --test data_files --test scheduling_contracts --test operational_contracts --test reasoning_contracts -- --test-threads=1',";assert t.count(old)==1;t=t.replace(old,"    'bash scripts/ci-native-regressions.sh',")
old="    'node --test --test-concurrency=1 rust/tests/web/issue-1396-native.test.mjs']);";new="""    'node --test --test-concurrency=1 rust/tests/web/issue-1396-native.test.mjs',
    'cargo build --manifest-path rust/Cargo.toml --locked --example dump_google_trends_catalog\\n' +
    'rust/target/debug/examples/dump_google_trends_catalog "$CATALOG_OUTPUT"\\n' +
    '{\\n' +
    '  git rev-parse HEAD HEAD^{tree}\\n' +
    '  rustc -vV\\n' +
    '  sha256sum rust/target/debug/examples/dump_google_trends_catalog rust/examples/dump_google_trends_catalog.rs rust/src/google_trends_catalog.rs data/seed/google-trends-prompts.lino\\n' +
    '} > "$CATALOG_OUTPUT/generation-identity.txt"\\n']);""";assert t.count(old)==1;t=t.replace(old,new)
t=t.replace("step.uses !== 'actions/setup-node@v7'","!['actions/setup-node@v7', 'actions/upload-artifact@v7'].includes(step.uses)")
old="  assert(!check.steps.some(step => /upload-artifact|attest|cache@|cache\\/save/u.test(step.uses ?? '')));";new="""  assert(!check.steps.some(step => /attest|cache@|cache\\/save/u.test(step.uses ?? '')));
  const uploads = check.steps.filter(step => /upload-artifact/u.test(step.uses ?? ''));
  assert.equal(uploads.length, 1, 'only the exact fixture projection is retained');
  assert.equal(uploads[0].uses, 'actions/upload-artifact@v7');
  assert.equal(uploads[0].with.name, 'google-trends-native-fixtures');
  assert.equal(uploads[0].with.path, '${{ runner.temp }}/google-trends-fixtures');
  assert.equal(uploads[0].if, "${{ !cancelled() && inputs.compile-inputs-changed && steps.native-lint.outcome == 'success' }}");""";assert t.count(old)==1;t=t.replace(old,new)
t=t.replace('Full suites, product builds and uploads remain main-only.','Full suites and product builds remain main-only; fixture data is retained for replay.').replace("'a lint check publishes no evidence'","'a focused check grants no semantic authorization'")
t=t.replace('const targets = [...step.run.matchAll(/--test (\\S+)/gu)].map(match => match[1]);','const targets = [...new Set([...nativeRegressionSource(step).matchAll(/--test (\\S+)/gu)].map(match => match[1]))];')
t=t.replace('assert.match(isolated.run, /--no-fail-fast/u);','assert.match(nativeRegressionSource(isolated), /--no-fail-fast/u);')
for pattern in ['/--test operational_contracts(?: |$)/u','/--test reasoning_contracts(?: |$)/u','/--no-fail-fast/u']:
 t=t.replace('assert.match(step.run, '+pattern+');','assert.match(nativeRegressionSource(step), '+pattern+');')
t=t.replace("'rust/examples/dump_google_trends_catalog.rs', 'data/seed/google-trends-prompts.lino']","'rust/examples/dump_google_trends_catalog.rs', 'data/seed/google-trends-prompts.lino',\n    'docs/case-studies/issue-498/agent-cli-session-google-trends.json']")
t+='''

for (const [label, compileStatus, contractStatus, benchmarkStatus, expectedStatus] of [
  ['overlaps isolated native groups after compiling every target once', 0, 0, 0, 0],
  ['retains contract failure after waiting for benchmark completion', 0, 17, 0, 17],
  ['retains benchmark failure after waiting for contract completion', 0, 0, 23, 23],
  ['does not start native tests after compilation fails', 19, 0, 0, 19],
]) {
  test('native regression runner ' + label, {timeout:15000}, () => {
    const directory = mkdtempSync(join(tmpdir(), 'formal-ai-native-overlap-'));
    const command = join(directory, 'cargo');
    writeFileSync(command, `#!/usr/bin/env python3
import json, os, pathlib, sys, time
root = pathlib.Path(os.environ['NATIVE_MOCK_DIRECTORY'])
arguments = sys.argv[1:]
mode = 'compile' if '--no-run' in arguments else 'contracts' if '--skip' in arguments else 'benchmarks'
with (root / 'invocations.jsonl').open('a') as stream:
    stream.write(json.dumps({'mode': mode, 'arguments': arguments}) + '\\\\n')
if mode == 'compile':
    sys.exit(int(os.environ['NATIVE_MOCK_COMPILE_STATUS']))
(root / (mode + '.started')).write_text('started')
other = 'benchmarks' if mode == 'contracts' else 'contracts'
for attempt in range(300):
    if (root / (other + '.started')).exists():
        print('completed fixture ' + mode, flush=True)
        sys.exit(int(os.environ['NATIVE_MOCK_' + mode.upper() + '_STATUS']))
    time.sleep(0.01)
raise SystemExit('both isolated groups must overlap')
`, {mode:0o755});
    try {
      const result = spawnSync('bash', [resolve('scripts/ci-native-regressions.sh')], {cwd:directory,
        env:{...process.env, PATH:directory + ':' + process.env.PATH, RUNNER_TEMP:directory,
          NATIVE_MOCK_DIRECTORY:directory, NATIVE_MOCK_COMPILE_STATUS:String(compileStatus),
          NATIVE_MOCK_CONTRACTS_STATUS:String(contractStatus), NATIVE_MOCK_BENCHMARKS_STATUS:String(benchmarkStatus)},
        encoding:'utf8', timeout:10000, maxBuffer:65536});
      assert.equal(result.error, undefined, String(result.error));
      assert.equal(result.status, expectedStatus, result.stdout + result.stderr);
      const calls = readFileSync(join(directory, 'invocations.jsonl'), 'utf8').trim().split('\\n').map(line => JSON.parse(line));
      assert.equal(calls[0].mode, 'compile');
      assert(calls[0].arguments.includes('--no-run'));
      assert(calls[0].arguments.includes('reasoning_contracts'));
      if (compileStatus) {
        assert.equal(calls.length, 1);
      } else {
        assert.equal(calls.length, 3);
        assert.deepEqual(calls.slice(1).map(call => call.mode).sort(), ['benchmarks', 'contracts']);
        for (const call of calls.slice(1)) assert(call.arguments.includes('--test-threads=1'));
        const contracts = calls.find(call => call.mode === 'contracts');
        assert(contracts.arguments.includes('--no-fail-fast'));
        assert(contracts.arguments.includes('--skip'));
        assert(contracts.arguments.includes('benchmarks::'));
        assert.match(result.stdout, /completed fixture contracts/u);
        assert.match(result.stdout, /completed fixture benchmarks/u);
      }
    } finally { rmSync(directory, {recursive:true, force:true}); }
  });
}
'''
p.write_text(t)
p=Path('changelog.d/issue-1580-native-benchmark-budget.md');p.write_text('fix: Overlap the independently serialized native benchmark group with other isolated contracts after one shared compilation, retaining both exit statuses and the existing 20-minute CI limit.\n')
print(json.dumps({'script':'scripts/ci-native-regressions.sh','mockCases':4,'jobDeadlineMinutes':20,'rustTestsModified':False}))
