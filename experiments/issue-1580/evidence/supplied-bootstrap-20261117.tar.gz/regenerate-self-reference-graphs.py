from pathlib import Path
import gzip
import json
import os
import subprocess

output=Path('docs/case-studies/issue-1580/templates')
logs=Path('/tmp/issue-1580-research/self-reference-checks')
before={p.name:json.loads(gzip.decompress(p.read_bytes())) for p in output.glob('*-ci-reference-graph.json.gz')}
env=dict(os.environ,NODE_PATH='/tmp/issue-1580-research/node_modules')
result=subprocess.run(['node','--max-old-space-size=96','experiments/issue-1580/trace-template-ci.mjs'],env=env,text=True,capture_output=True)
(logs/'regeneration.log').write_text(result.stdout+result.stderr)
print('regeneration exit',result.returncode)
assert result.returncode==0, result.stderr[-2000:]
summary=[]
for name,old in sorted(before.items()):
 new=json.loads(gzip.decompress((output/name).read_bytes()))
 previous=set(json.dumps(e,sort_keys=True) for e in old['edges'])
 added=[e for e in new['edges'] if json.dumps(e,sort_keys=True) not in previous]
 row={'language':name.split('-')[0], 'beforeFiles':len(old['files']), 'afterFiles':len(new['files']), 'addedFiles':sorted(set(new['files'])-set(old['files'])), 'addedSelfRepositoryEdges':[e for e in added if e['reason'].startswith('self-repository ')]}
 summary.append(row)
 print(json.dumps(row))
(logs/'graph-delta.json').write_text(json.dumps(summary,indent=2)+'\n')
print('memory current',Path('/sys/fs/cgroup/memory.current').read_text().strip())
