import gzip,json,pathlib,subprocess
root=pathlib.Path('.')
commands=[['git','status','--short'],['git','branch','--show-current'],['rg','-n','initial-spec-reporter|120/158|120 of 158|38 active|38 unread|C#.*120|Csharp.*120','docs/case-studies/issue-1580','experiments/issue-1580','--glob','!evidence/commands/**','--glob','!supplied-bootstrap/**'],['node','experiments/formal_ai_subagent/local-gates.mjs','--list']]
for command in commands:
    result=subprocess.run(command,text=True,capture_output=True)
    print(json.dumps({'command':command,'status':result.returncode,'stdout':result.stdout,'stderr':result.stderr}))
log=pathlib.Path('experiments/issue-1580/evidence/ci/0f90c0a7a/attempt-1/44095402201.log.gz')
lines=gzip.decompress(log.read_bytes()).decode().splitlines()
for first,last in [(7055,7080),(7955,7990)]:
    print('\n'.join(f'{n}: {lines[n-1]}' for n in range(first,min(last,len(lines))+1)))
for file in ['docs/case-studies/issue-1580/templates/csharp-partial-semantic-review.json','/tmp/issue-1580-research/record-csharp-partial-review.py','experiments/issue-1580/evidence/checks/csharp-changeset-integrity.json','/tmp/issue-1580-research/commit-csharp-report-metadata.py']:
    p=pathlib.Path(file)
    lines=p.read_text().splitlines()
    print(f'FILE {file} ({len(lines)} lines)')
    if file.endswith('csharp-partial-semantic-review.json'):
        value=json.loads(p.read_text()); print(json.dumps({k:v for k,v in value.items() if k!='files'},indent=2))
        print(json.dumps(value['files'][-40:],indent=2))
    else:
        print('\n'.join(f'{n}: {line}' for n,line in enumerate(lines,1)))
