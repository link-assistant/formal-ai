from pathlib import Path
import gzip,hashlib,json,os,subprocess,time

assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='d0b8b895661c6b5e809810c4da8a3db9f79138b3'
for script in ['archive-round-bootstrap.py','archive-evidence.py']:
 print(subprocess.check_output(['python3','/tmp/issue-1580-research/'+script],text=True).strip())
directory=Path('experiments/issue-1580/evidence/ci/d0b8b8956')
env=dict(os.environ);env['NODE_OPTIONS']='--max-old-space-size=256'
command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-abbreviations,check-readable-code']
started=time.monotonic()
p=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
raw=p.stdout
(directory/'documentation-gates.log.gz').write_bytes(gzip.compress(raw,mtime=0))
result={'command':command,'status':p.returncode,'durationSeconds':round(time.monotonic()-started,3),'nodeHeapMiB':256,'rawSha256':hashlib.sha256(raw).hexdigest(),'rustBuildsEnabled':False,'autonomousAuthorshipCredit':0}
(directory/'documentation-gates.json').write_text(json.dumps(result,indent=2)+'\n')
print(raw.decode());assert p.returncode==0
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--','docs/case-studies/issue-1580','experiments/issue-1580/work-plan.md','experiments/issue-1580/upstream/filed-issues.txt','experiments/issue-1580/upstream/template-report-identities.json','experiments/issue-1580/evidence'],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','docs: verify hosted regressions and preserve Python formatter report'],check=True,stdout=subprocess.PIPE)
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
print('HEAD',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
print(json.dumps(result))
