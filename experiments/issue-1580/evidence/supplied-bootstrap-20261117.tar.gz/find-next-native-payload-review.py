from pathlib import Path
import json
base=Path('experiments/issue-1580/evidence/native-baseline')
print('BASELINE_TOP',[(p.name,p.stat().st_size) for p in sorted(base.iterdir())])
for name in ('native-evidence-checkpoint.md','native-synthesis-checkpoint.md','README.md'):
 p=Path('docs/case-studies/issue-1580')/name
 for i,line in enumerate(p.read_text().splitlines(),1):
  if any(x in line.lower() for x in ('literal','unread','panic','53 ','payload','line')):print(name,i,line[:600])
p=Path('/tmp/issue-1580-research/language-main-validation/all-local-gates.log');lines=p.read_text().splitlines();print('GATE_PROGRESS',len(lines));print('\n'.join(lines[-5:]))
