from pathlib import Path
import subprocess,json,shutil,gzip,hashlib,datetime
repo='link-assistant/formal-ai'
run='44089535561'
head='e582b270a01443b995d7f36fd2fa685d508fde77'
state=json.loads(subprocess.check_output(['gh','run','view',run,'--repo',repo,'--json','headSha,status,conclusion,attempt,jobs'],text=True))
assert state['headSha']==head and state['status']=='completed' and state['conclusion']=='failure' and state['attempt']==1,state
failed=[job for job in state['jobs'] if job['conclusion']=='failure']
assert len(failed)==1 and failed[0]['name']=='js tier (node --check over js, suite group 2)',failed
assert [step['name'] for step in failed[0]['steps'] if step['conclusion']=='failure']==['Run actions/checkout@v7']
source=Path('/tmp/issue-1580-research/head-e582b270a')
target=Path('experiments/issue-1580/evidence/ci/e582b270a/attempt-1')
target.mkdir(parents=True,exist_ok=True)
for name in [run+'.log.gz',run+'.json','runs.json']:shutil.copyfile(source/name,target/name)
raw=gzip.open(target/(run+'.log.gz'),'rb').read()
report={'head':head,'run':int(run),'attempt':1,'runUrl':f'https://github.com/{repo}/actions/runs/{run}','workflows':24,'passed':23,'failed':1,'active':0,'logLines':len(raw.splitlines()),'logSha256':hashlib.sha256(raw).hexdigest(),'failureLines':[5634,5635,5636,5665],'failure':'Checkout of the PR merge ref exited 128: curl 28 low throughput for 20 seconds, bad pack header, missing promisor object. No test step ran in the failed shard.','recovery':'Rerun only failed jobs on the identical head after preserving attempt 1; do not change checkout policy on evidence of one transport interruption.','applicationOrNativeVerification':False,'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(target/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
subprocess.run(['gh','run','rerun',run,'--repo',repo,'--failed'],check=True)
print('Requested failed-job rerun on the same immutable head.')
