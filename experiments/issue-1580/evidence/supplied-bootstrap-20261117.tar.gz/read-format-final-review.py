from pathlib import Path
import subprocess

root = Path("/tmp/gh-issue-solver-1794900398048")
for name in [
    "experiments/issue-1580/template-python-release-formatting.test.mjs",
    "experiments/issue-1580/upstream/python-release-formatting-report.md",
    "experiments/issue-1580/evidence/checks/python-release-formatting/README.md",
]:
    path = root / name
    lines = path.read_text().splitlines()
    assert len(lines) <= 1500
    print(f"\nFILE {name} ({len(lines)} lines)")
    for n, line in enumerate(lines, 1):
        print(f"{n}: {line}")
print(subprocess.run(["git", "status", "--short"], cwd=root, text=True, capture_output=True, check=True).stdout)
