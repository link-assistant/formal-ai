from pathlib import Path
import sys,subprocess,json,gzip,hashlib
groups={'basic':'check-abbreviations,check-file-size,check-file-size-js-twin','workflow':'check-ci-speed,check-runner-labels,lint-shell-scripts','readable':'check-readable-code'}
name=sys.argv[1];command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',groups[name]]
result=subprocess.run(command,capture_output=True,text=True);content=(result.stdout+result.stderr).encode()
label=sys.argv[2]+'-'+name if len(sys.argv)>2 else name
directory=Path('experiments/issue-1580/evidence/checks/python-runtime-provisioning');log=directory/('gates-'+label+'.log.gz');log.write_bytes(gzip.compress(content,mtime=0))
record={'command':command,'exitCode':result.returncode,'log':str(log),'uncompressedSha256':hashlib.sha256(content).hexdigest()}
(directory/('gates-'+label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record));print(content.decode());sys.exit(result.returncode)
