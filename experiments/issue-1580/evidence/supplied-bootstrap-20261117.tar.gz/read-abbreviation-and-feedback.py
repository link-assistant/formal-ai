from pathlib import Path
import json, subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
result=subprocess.run(['node','scripts/measure-abbreviations.mjs','--list','file-names'],cwd=root,text=True,capture_output=True,check=True)
print('NEW EVIDENCE ABBREVIATIONS')
for line in result.stdout.splitlines():
    if 'picomatch' in line: print(line)
print('CURRENT RATCHET')
print((root/'data/meta/abbreviation-ratchet.lino').read_text())
base=Path('/tmp/issue-1580-research/picomatch-push-preflight')
for name in ['issue-comments','pull-conversation']:
    for page in json.loads((base/(name+'.json')).read_text()):
        for item in page:
            print('\nCOMMENT',item['html_url'])
            print(item['body'])
