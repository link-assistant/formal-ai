from pathlib import Path
import json,re
base=Path('experiments/issue-1580/evidence/ci/main-058e9bef')
inventory=json.loads((base/'inventory.json').read_text())
rows=[]
patterns=[r'^\s*not ok ',r'^\s*✖ ',r'##\[error\]',r'test result: FAILED',r'^failures:',r"^thread '.+' panicked",r'AssertionError',r'error: could not compile']
for run in inventory['runs']:
    if 'log' not in run:continue
    path=Path(f"/tmp/issue-1580-research/main-058e9bef-{run['id']}.log")
    lines=path.read_text().splitlines()
    selected=[]
    for i,line in enumerate(lines,1):
        parts=line.split('\t',2)
        payload=parts[-1]
        payload=re.sub(r'^\d{4}-\d\d-\d\dT[^ ]+ ','',payload)
        if any(re.search(p,payload) for p in patterns):
            selected.append({'line':i,'text':payload})
    row={'run':run['id'],'workflow':run['name'],'markers':selected}
    rows.append(row)
    print(run['id'],run['name'],'markers',len(selected))
    for record in selected:print(record['line'],record['text'])
(base/'failure-marker-index.json').write_text(json.dumps(rows,indent=2)+'\n')
print('These are failure markers, not an assertion that every log line was reviewed.')
