from pathlib import Path
for name in ['read-python-unread-page.py','record-python-33-and-memory-preflight.py','current-head-status.py','format-round-preflight.py','archive-round-bootstrap.py','run-final-header-gates.py']:
 p=Path('/tmp/issue-1580-research')/name
 lines=p.read_text().splitlines()
 print('\nFILE',str(p),'LINES',len(lines))
 if len(lines)>1500: raise RuntimeError('chunk required')
 print('\n'.join(f'{i}: {s}' for i,s in enumerate(lines,1)))
