from pathlib import Path

p=Path('js/worker/formal_ai_worker_quantity_constraints.js')
s=p.read_text().replace('function tryArithmetic(prompt) {\n', '''function tryArithmetic(prompt) {
  // A seeded number-property request owns its operands before loose expression extraction.
  const validation = solverPrimeIntervalValidation(prompt);
  if (validation?.answer) return {
    intent: NUMBER_PROPERTY_PRIME_SLUG, content: validation.answer, confidence: 1,
    evidence: ["validation:" + NUMBER_PROPERTY_PRIME_SLUG], solverEvents: validation.events,
  };
''')
p.write_text(s)
p=Path('rust/src/solver_dispatch.rs')
s=p.read_text().replace('    crate::quantity_constraint::try_answer(prompt, log).or_else(|| try_arithmetic(prompt, log))', '''    // A seeded number-property request owns its operands before loose expression extraction.
    if let Some(choice) = crate::solver_helpers::record_validation(log, prompt) {
        return Some(crate::solver_handlers::finalize_simple(
            prompt, log, &choice.intent, "response:number_property_prime", &choice.answer, 1.0,
        ));
    }
    crate::quantity_constraint::try_answer(prompt, log).or_else(|| try_arithmetic(prompt, log))''')
p.write_text(s)

p=Path('.github/workflows/release.yml')
s=p.read_text()
start=s.index('    paths-ignore:',s.index('  pull_request:'))
end=s.index('    branches-ignore:',start)
s=s[:start]+s[end:]
old=" && (needs.detect-changes.result != 'success' || needs.detect-changes.outputs.native-type-check != 'false') }}"
assert old in s
s=s.replace(old,' }}',1)
old='    uses: ./.github/workflows/native-type-check.yml\n'
s=s.replace(old,old+"    with:\n      compile-inputs-changed: ${{ needs.detect-changes.result != 'success' || needs.detect-changes.outputs.native-type-check != 'false' }}\n",1)
p.write_text(s)
p=Path('.github/workflows/native-type-check.yml')
s=p.read_text().replace('# called from release.yml when a Rust compile input changed or the\n# classification is unknown.', '# called from release.yml on every PR, compiling when a Rust input changed\n# or the classification is unknown.')
s=s.replace('  workflow_call:\n','''  workflow_call:
    inputs:
      compile-inputs-changed:
        description: Compile when inputs changed or their classification is unknown
        type: boolean
        default: true
''',1)
s=s.replace('    steps:\n','''    steps:
      - name: Report unchanged compile inputs
        if: ${{ !inputs.compile-inputs-changed }}
        run: echo '::notice::Rust compile inputs unchanged; required check is satisfied without compiling.'
''',1)
for text in ['      - uses: actions/checkout@v7','      - uses: dtolnay/rust-toolchain@stable', '      - uses: ./.github/actions/setup-sccache','      - uses: ./.github/actions/cache-cargo-registry','      - name: Type-check and lint the library and binaries']:
    assert text in s
    s=s.replace(text+'\n',text+'\n        if: ${{ inputs.compile-inputs-changed }}\n',1)
p.write_text(s)
p=Path('rust/tests/web/default-branch-build-policy.test.mjs')
s=p.read_text().replace("  assert.deepEqual(runs, ['bash scripts/ci-clippy-profile.sh --library-and-binaries']);", "  assert.deepEqual(runs.filter(run => !run.startsWith('echo ')), ['bash scripts/ci-clippy-profile.sh --library-and-binaries']);\n  assert.equal(called.on.workflow_call.inputs['compile-inputs-changed'].default, true);\n  for (const step of check.steps.filter(step => step.uses || step.name === 'Type-check and lint the library and binaries'))\n    assert.equal(step.if, '${{ inputs.compile-inputs-changed }}');\n  assert.equal(check.steps[0].if, '${{ !inputs.compile-inputs-changed }}');\n  assert.equal(workflow('release.yml').on.pull_request['paths-ignore'], undefined, 'required contexts must report for docs-only PRs');")
s=s.replace("assert.equal(selected('pull_request', 'refs/pull/1/merge', 'success', 'false'), false, 'docs-only and JS-only PRs skip it');", "assert.equal(selected('pull_request', 'refs/pull/1/merge', 'success', 'false'), true, 'docs-only and JS-only PRs still report the required context');\n  const compile = (result, value) => new Script(job.with['compile-inputs-changed'].slice(3, -2)).runInNewContext({needs: {'detect-changes': {result, outputs: {'native-type-check': value}}}});\n  assert.equal(compile('success', 'false'), false);\n  assert.equal(compile('success', 'true'), true);\n  assert.equal(compile('failure', 'false'), true);\n  assert.equal(compile('success', undefined), true);")
# Translate GitHub property syntax containing hyphens for the small expression replay.
s=s.replace("new Script(job.with['compile-inputs-changed'].slice(3, -2))", "new Script(job.with['compile-inputs-changed'].slice(3, -2).replaceAll('needs.detect-changes', \"needs['detect-changes']\").replaceAll('outputs.native-type-check', \"outputs['native-type-check']\"))")
p.write_text(s)
