from pathlib import Path
import subprocess,os,gzip,hashlib,json
p=Path('rust/tests/web/default-branch-build-policy.test.mjs')
s=p.read_text(); anchor="test('native execution inherits the optimized assertion-preserving repository profile'"
assert anchor not in s
s+='''\n\ntest('native execution inherits the optimized assertion-preserving repository profile', () => {
  const called = workflow('native-type-check.yml');
  const job = called.jobs.clippy;
  assert.equal(job['timeout-minutes'], 20, 'retain the existing deadline');
  for (const env of [called.env, job.env, ...job.steps.map(step => step.env)].filter(Boolean)) {
    for (const key of ['CARGO_PROFILE_TEST_OPT_LEVEL', 'CARGO_PROFILE_TEST_DEBUG_ASSERTIONS',
      'CARGO_PROFILE_TEST_OVERFLOW_CHECKS']) assert.equal(env[key], undefined, key);
  }
  const profile = read('rust/Cargo.toml').split('[profile.test]')[1].split('[profile.release]')[0];
  assert.match(profile, /^opt-level = 2$/mu);
  assert.match(profile, /^debug-assertions = true$/mu);
  assert.match(profile, /^overflow-checks = true$/mu);
});
'''
p.write_text(s)
p=Path('rust/tests/web/source-walk-offline-policy.test.mjs');s=p.read_text();assert 'localized wikiHow endpoints preserve' not in s
s+='''\n\ntest('localized wikiHow endpoints preserve their candidate title and combining marks',async()=>{
 const c=await boot();
 for(const [language,subject,title] of [
  ['en','connect mysql to node js','Connect-Mysql-To-Node-Js'],
  ['ru','подключить MYSQL к Node JS','подключить-mysql-к-node-js'],
  ['hi','कनेक्ट करें mysql को node js से','कनेक्ट-करें-Mysql-को-Node-Js-से'],
  ['zh','连接 mysql 到 node js','连接-Mysql-到-Node-Js'],
  ['es','conectar MYSQL a Node JS','conectar-mysql-a-node-js'],
 ]){
  c.__language=language;c.__subject=subject;
  const endpoint=evaluate(c,'sourceWalkEntryUrl(sourceWalkRegistry().find(record=>record.id==="wikihow"),__subject,__language)');
  const url=new URL(endpoint);
  assert.equal(url.searchParams.get('page'),title,language);
  assert.equal(url.hostname,language==='en'?'www.wikihow.com':language+'.wikihow.com');
 }
 assert.deepEqual(c.__network,[]);
});
'''
p.write_text(s)
folder=Path('experiments/issue-1580/evidence/checks/native-deadline-and-title');folder.mkdir(parents=True,exist_ok=True)
records=[]
for label,file in [('profile-before','rust/tests/web/default-branch-build-policy.test.mjs'),('title-before','rust/tests/web/source-walk-offline-policy.test.mjs')]:
 command=['timeout','600','node','--test','--test-concurrency=1',file]
 r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=256'})
 payload=gzip.compress(r.stdout,mtime=0);name=label+'.log.gz';(folder/name).write_bytes(payload)
 records.append({'label':label,'command':command,'exitCode':r.returncode,'log':name,'sha256':hashlib.sha256(payload).hexdigest()})
 print(label,'exit',r.returncode,flush=True)
 for line in r.stdout.decode().splitlines():
  if any(x in line for x in ['not ok','error:','expected:','actual:','# pass','# fail']):print(line)
 assert r.returncode!=0,label
(folder/'before.json').write_text(json.dumps(records,indent=2)+'\n')
