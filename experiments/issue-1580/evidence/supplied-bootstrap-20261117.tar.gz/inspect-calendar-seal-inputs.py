from pathlib import Path
import subprocess,gzip
for name in ["/tmp/issue-1580-research/commit-hosted-evidence.py","/tmp/issue-1580-research/seal-header-hosted-evidence.py"]:
 p=Path(name);lines=p.read_text().splitlines()
 print("SCRIPT",name,"LINES",len(lines))
 for i,line in enumerate(lines,1):print(f"{i}: {line}")
r=subprocess.run(["git","diff","--","js/worker/formal_ai_worker_calendar_and_proofs.js","rust/src/solver_handlers/calendar_create.rs","rust/tests/unit/solver/issue_869_meeting_scheduling.rs"],capture_output=True,text=True,check=True)
print("CALENDAR DIFF");print(r.stdout)
p=Path("/tmp/issue-1580-research/picomatch/package/lib/parse.js")
lines=p.read_text().splitlines()
for i in range(338,385):print(f"parse.js:{i+1}: {lines[i]}")
for name in ["intent-span-tests","worker-after"]:
 p=Path("experiments/issue-1580/evidence/checks/calendar-clock-preservation")/(name+".log.gz")
 lines=gzip.decompress(p.read_bytes()).decode().splitlines()
 print("LOG",name,"LINES",len(lines))
 if name=="worker-after":
  for i,line in enumerate(lines,1):print(f"{i}: {line}")
 else:
  for i in range(max(0,len(lines)-10),len(lines)):print(f"{i+1}: {lines[i]}")
