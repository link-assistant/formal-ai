from pathlib import Path
import subprocess
for args in [ ['rg','-n','serve-\{|serve-.*lino|diagnostic.*File|append\(true\)','rust/src','--glob','*log*'], ['rg','-n','readNetworkAllowed|networkAllowed|SOURCE_CACHE|LIVE_FETCH|sourceFetch','js/agentic/node-host.mjs','js/agentic/crate/version_resolution.mjs','js/server/solver-config.mjs'], ['rg','-l','serve-\{','rust/src'], ['rg','--files','rust/tests/web','--glob','*1582*'] ]:
    r=subprocess.run(args,text=True,capture_output=True)
    print('COMMAND',args, r.stdout,r.stderr)
for p in ['js/agentic/node-host.mjs','js/server/solver-config.mjs']:
    if Path(p).exists():print('FILE',p,Path(p).read_text())
