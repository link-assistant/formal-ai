from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess
root=Path("/tmp/gh-issue-solver-1794900398048")
directory=root/"experiments/issue-1580/evidence/checks/python-release-formatting"
def run(args):
    p=subprocess.run(args,cwd=root,text=True,capture_output=True)
    if p.returncode:raise RuntimeError(f"{args}\n{p.stdout}\n{p.stderr}")
    return p.stdout
assert run(["git","branch","--show-current"]).strip()=="issue-1580-8d61a32a61e1"
assert run(["git","rev-parse","HEAD"]).strip()=="1cc2d536ac11e26602cc55a40dffb61716233aa6"
completion=directory/"all-local-gates.json"
assert completion.exists(),"Wait for the active full local gates run"
gates=json.loads(completion.read_text());assert gates["status"]==1
raw=gzip.decompress((directory/gates["log"]).read_bytes())
assert hashlib.sha256(raw).hexdigest()==gates["rawSha256"]
text=raw.decode();counts=collections.Counter(re.findall(r"^(PASS|SKIP|FAIL) ",text,re.M))
assert re.findall(r"^FAIL ([^ ]+)",text,re.M)==["check-generated-files","check-notation","layered-ci#4"]
for item in gates["perGateLogs"]:
    data=gzip.decompress((directory/item["log"]).read_bytes())
    assert hashlib.sha256(data).hexdigest()==item["rawSha256"]
for label,expected in [("focused-first",0),("candidate-disabled",1),("maintained-after",0),("fast-inventory-before",1),("fast-inventory-after",0),("audit-selected",0),("gate-selection-notation-after",0)]:
    metadata=json.loads((directory/(label+".json")).read_text())
    assert metadata["status"]==expected
    data=gzip.decompress((directory/metadata["log"]).read_bytes())
    assert hashlib.sha256(data).hexdigest()==metadata["rawSha256"]
    if label=="maintained-after":
        assert re.search(r"^(?:#|ℹ) pass 38$",data.decode(),re.M) and re.search(r"^(?:#|ℹ) skipped 0$",data.decode(),re.M)
manifest=json.loads((root/"data/benchmarks/fast-pull-request-javascript-tests.json").read_text())
assert "rust/tests/web/javascript-audit-inventory.test.mjs" in manifest["files"]
readme=directory/"README.md";body=readme.read_text()
assert "Initial full local gate run:" not in body
body+=f'\nInitial full local gate run: {counts["PASS"]} pass, {counts["SKIP"]} explicitly excluded native/context gates, three failures; {gates["durationSeconds"]} seconds. Full logs and per-gate logs are retained. Both generated-file/source-model failures exhaust the supplied 128 MiB Node cap. The notation failure identifies an intentional old-name typo in the gate-selector negative control; it is replaced with a different misspelling that retains rejection-before-execution coverage, and its complete focused suite passes. The combined main merge will be checked with a measured 256 MiB cap. This initial run is not counted as passing. Merged-head validation and hosted execution of the newly selected audit file remain required.\n'
readme.write_text(body)
for name in ["docs/case-studies/issue-1580/README.md","docs/case-studies/issue-1580/templates/README.md","experiments/issue-1580/work-plan.md"]:
    p=root/name
    with p.open("a") as stream:
        stream.write(f'\nThe initial complete local gate run records {counts["PASS"]} pass, {counts["SKIP"]} native/context exclusions and three failures: two supplied 128 MiB Node-heap exhaustion failures and an old-name spelling in a gate-selection negative control. That control now uses a different typo and its focused suite passes; no policy is relaxed. Main advanced to 512ce428029a92687628b4180309ee5ab660fe08 during validation. Merge it without losing either fast-test addition, reconcile the duplicate Chrono advisory documentation, then revalidate the combined shared data under a measured 256 MiB Node cap before the single push. Hosted execution of the ten selected audit cases and formatter observations remains pending.\n')
rows=[]
for p in sorted(directory.rglob("*")):
    if not p.is_file() or p.name=="checksums.json":continue
    data=p.read_bytes();rows.append({"file":str(p.relative_to(directory)),"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()})
(directory/"checksums.json").write_text(json.dumps({"independentAuthorshipCredit":0,"files":rows},indent=2)+"\n")
for script in ["archive-round-bootstrap.py","archive-evidence.py"]:
    print(run(["python3","/tmp/issue-1580-research/"+script]).strip())
paths=[
 "data/benchmarks/fast-pull-request-javascript-tests.json",
 "docs/case-studies/issue-1580",
 "experiments/issue-1580",
 "rust/tests/web/fast-pull-request-production-profile.test.mjs",
 "rust/tests/web/issue-1580-template-observations.test.mjs",
 "rust/tests/web/pull-request-1188-subagent-folder.test.mjs",
]
print(run(["git","diff","--check"]))
print(run(["git","add","--",*paths]))
print(run(["git","diff","--cached","--check"]))
print(run(["git","diff","--cached","--stat"]).splitlines()[-1])
print(run(["git","commit","-m","test: cover release-note escape preservation and select audit regressions"]))
print("HEAD",run(["git","rev-parse","HEAD"]).strip())
print("STATUS",run(["git","status","--short"]))
print(json.dumps({"gates":dict(counts),"sourceCommitRequiresMainMerge":True,"upstreamReportDraftOnly":True,"hostedNewCoveragePending":True}))
