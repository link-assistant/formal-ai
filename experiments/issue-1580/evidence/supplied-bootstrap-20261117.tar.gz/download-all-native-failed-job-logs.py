from pathlib import Path
import gzip,hashlib,json,re,subprocess
base=Path('experiments/issue-1580/evidence/ci/main-015a6831')
out=base/'individual-native-failed-jobs';out.mkdir(exist_ok=True)
metadata=json.loads(gzip.decompress((base/'pipeline-metadata.json.gz').read_bytes()))
records=[]
for job in metadata['jobs']:
 if job['conclusion']!='failure' or not job['name'].startswith('Test ('):continue
 identifier=job['databaseId'];name=f'job-{identifier}.log.gz'
 target=out/name;existing=base/'individual-native-catalog-jobs'/name
 if target.exists():raw=gzip.decompress(target.read_bytes());artifact=target
 elif existing.exists():raw=gzip.decompress(existing.read_bytes());artifact=existing
 else:
  result=subprocess.run(['gh','api',f'repos/link-assistant/formal-ai/actions/jobs/{identifier}/logs','--allow-escape-sequences'],capture_output=True)
  assert result.returncode==0,result.stderr.decode();raw=result.stdout
  target.write_bytes(gzip.compress(raw,mtime=0));artifact=target
 lines=raw.decode().splitlines()
 large=[{'line':i,'bytes':len(line.encode()),'sha256':hashlib.sha256(line.encode()).hexdigest(),'prefix':line[:180]} for i,line in enumerate(lines,1) if len(line.encode())>65536]
 panics=[{'line':i,'text':line[:900]} for i,line in enumerate(lines,1) if re.search(r"thread '.*panicked at",line)]
 record={'job':identifier,'name':job['name'],'artifact':str(artifact),'rawBytes':len(raw),'rawLines':len(lines),'rawSha256':hashlib.sha256(raw).hexdigest(),'largeLines':large,'panics':panics}
 records.append(record);print(json.dumps({'job':identifier,'name':job['name'],'rawBytes':len(raw),'rawLines':len(lines),'rawSha256':record['rawSha256'],'largeLines':large,'panics':len(panics)},ensure_ascii=False),flush=True)
 (out/'receipts.json').write_text(json.dumps({'sourceHead':metadata['headSha'],'records':records,'downloadComplete':False,'fullLiteralReviewComplete':False},indent=2)+'\n')
(out/'receipts.json').write_text(json.dumps({'sourceHead':metadata['headSha'],'records':records,'downloadComplete':True,'fullLiteralReviewComplete':False},indent=2)+'\n')
