from pathlib import Path
path=Path('/tmp/gh-issue-solver-1794900398048/rust/tests/web/worker-unknown-language.test.mjs')
text=path.read_text()
start=text.index('test("meaning hydration includes registered seed names')
text=text[:start]+text[start:].replace('a held-out subject','a held out subject')
path.write_text(text)
print('Aligned synthetic fixture expectations with existing search-query punctuation normalization; production unchanged.')
