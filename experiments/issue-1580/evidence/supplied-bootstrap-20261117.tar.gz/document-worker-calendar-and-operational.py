from pathlib import Path
import json
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/calendar-dispatch-registration/final-validation';review=json.loads((base/'review.json').read_text());assert review['allPassed'] and review['focusedCounts']['pass']==123 and review['gateCounts']=={'PASS':87,'FAIL':0,'SKIP':52}
p=root/'docs/case-studies/issue-1580/calendar-dispatch-and-native-success-checkpoint.md';assert not p.exists();p.write_text('''# Calendar dispatch and native success checkpoint

Published `86dcf79d` completes all 23 workflows successfully. The
[native job](https://github.com/link-assistant/formal-ai/actions/runs/44398918743/job/135136530028)
passes lint, 82 isolated Rust cases, 13 library source-binding controls and the
unchanged Spanish sibling. Its three JavaScript files also pass four native HTTP
tests: forced functions in both agent modes, structured output, and localized
procedures with follow-up. Native log lines 1620–1820 and 1850–1960 are literally
reviewed. This does not claim literal review of the entire 2,066-line log.

The complete crosswalk now records 16 original panic contracts with published
passing replays and 37 without one, plus three original budget failures still
open. The new scheduling-act replay preserves its complete original test file.
Current matching names, source hashes and log lines remain separate from earlier
historical results. All 70 CI collection payload hashes are verified.

The Russian request still reached memory writing in the full JavaScript worker,
despite direct calendar admission. The browser handler registry omitted calendar
creation, and its promotion used an older independent recognizer. Registration
alone does not fix it. Commit `09f5ad42` registers creation and uses the shared
sentence-local calendar evidence for promotion. The initial 22-case regression
records 21 passes and one failure; registration alone retains that failure.
Both changes pass all 22 cases. The expanded suite passes 30 cases, including
all five original scheduling forms, four explicit memory writes and eight
full-worker source/ambiguity controls. Ordinary memory writes retain append
operations, while the scheduling results contain calendar artifacts.

Commit `4e62d913` adds an isolated native target for the existing shell
documentation and network download retry modules. All four existing tests remain
byte-for-byte unchanged. Their documentation and discovered shell-script inputs
now select the native lane. An initial new policy test used an invalid job key;
that failed receipt is retained with zero regression credit. The corrected
baseline fails for the missing target. Two consumed-input controls are moved
from negative to positive admission, retaining unrelated negative controls.
The final policy suite passes 29 cases. Actual execution of the four native
contracts remains pending for the next published head.

The first complete gate run records 83 passes, four failures and 52 exclusions.
All four failures are retained. Commit `21dcb086` removes the new duplicated
calendar argument block through one shared named list, lowers the reviewed audit
gap from 1,035 to its measured 1,032, and regenerates the feature inventory and
solver diagram. The new list test fails before the loader change and passes
after it, including exact inline equivalence and unknown-reference refusal.
The loader remains within its unchanged 1,500-line bound. Its maintained worker
identity generator and two source-bound lexical identity records are refreshed;
all 18 shared lexical closure controls still pass. The current driver correctly
refuses a stale identity during drafting; a retained coherent driver runs only
the maintained refresh generator, with zero verification or reasoning credit.

Seven focused JavaScript files pass all 123 cases. Rust 2024 formatting, projection
currency and generated-registry currency pass. The complete 139-gate run records
86 passes, one abbreviation failure and 52 explicit native/context exclusions.
Three evidence filenames are spelled out without changing their payloads, and
the maintained measurement lowers the Rust binding ceiling from 910 to 909.
The focused abbreviation replay passes; together these runs verify all 87
executable gates with 52 exclusions. The original failed run remains unchanged. The
official governed refresh changes only four references to the new Cargo source
hash; all complete objects, the authoritative manifest, 221 supported cases and
964 unsupported objects remain equal. All 17 aggregate/focused/follow-up and 87 detailed
gate payload hashes are verified. Focused and aggregate logs are literally read;
detailed passing payloads are not all read. No local Rust build runs.

The prior publication's 66 payload hashes and its successful branch push remain
archived. Fresh feedback reads retain one issue comment, nine pull request
conversation comments, and no inline comments or reviews, with no new feedback
since the prior complete review.

Java historical reading reaches 139/254 continuous pages, 8,766 complete source lines,
123 complete files and the partially read pre-commit registry JSON. The Node
catalog, five historical OSV records, complete Plexus duplicate-scope
issue, original-main POM and four historical PR records are now read. The
pre-commit registry response is partial through piece 6 of 145. Pages 140–254 and wider semantic applicability remain open.

Spelled-hour accuracy remains unfinished: the four eight-tonight forms still
use the fallback clock. The 37 original panic replays, benchmark floors,
template comparison/applicability, dependency and delivery criteria remain open.
An independent request comparing direct calendar calls with normal dispatcher
regressions receives no comparison: the driver refuses under its declared-create
contract. The complete two-line response and payload hashes are retained as a
rejected attempt, with zero accepted reasoning credit.
Accepted independent reasoning remains 0/20; supplied work earns zero credit.
The pull request remains draft and unmerged; the full issue is unfinished.
''')
link='[calendar dispatch and native success checkpoint](calendar-dispatch-and-native-success-checkpoint.md)'
p=root/'docs/case-studies/issue-1580/README.md';p.write_text(p.read_text()+'\nThe '+link+' records 23 passing workflows and 96 native Rust cases at `86dcf79d`, the locally verified Russian dispatcher repair, and the pending unchanged operational contracts. Full issue acceptance remains unfinished.\n')
p=root/'docs/case-studies/issue-1580/native-failure-collection-and-scheduling-checkpoint.md';p.write_text(p.read_text()+'\nThe subsequent '+link+' records the actual published native success and the full-worker dispatcher follow-up. The counts above describe the earlier checkpoint.\n')
p=root/'experiments/issue-1580/work-plan.md';p.write_text(p.read_text()+'''
### Calendar dispatch and native success follow-up

- [x] Collect all 23 current-head workflows for `86dcf79d`: all succeed.
- [x] Verify 96 native Rust cases and four native HTTP tests; retain exact log ranges and 70 payload hashes.
- [x] Update the original failure crosswalk to 16 published passing replays, 37 without one, and three original budget failures still open.
- [x] Reproduce the full-worker Russian memory-write misroute, retain the failed registration-only attempt, and pass the shared-evidence repair with 30 scheduling/memory/source controls.
- [x] Draft the isolated operational target with four unchanged existing native tests and consumed-input admission; pass 29 local policy cases.
- [x] Preserve the invalid initial policy baseline with zero regression credit; reproduce the actual missing-target failure after correcting the job lookup.
- [x] Pass 123 focused JavaScript tests, formatting, projection and registry currency, and all 87 executable gates with 52 explicit exclusions.
- [x] Prove the governed refresh changes only four Cargo fixture hashes, preserving all complete objects and the 1,185 / 221 / 964 inventory.
- [x] Read continuous Java historical pages 135–139, reaching 8,766 complete literal lines, 123 complete files and one partially read registry response; retain zero authorship credit.
- [ ] Publish this complete batch after fresh branch, main-ancestor and idle-run checks; collect every next-head native result.
- [ ] Verify the four operational contracts in hosted native CI.
- [ ] Correct spelled-hour values; finish all remaining original failures, benchmarks, template comparison, dependency, delivery and semantic criteria from the frozen acceptance inventory.
- [ ] Raise independently accepted Formal AI reasoning above 0/20; supplied patches, scripts and reading retain zero credit.

The broader issue is unfinished and the pull request remains draft and unmerged.
''')
p=root/'experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md';lines=p.read_text().splitlines()
assert lines[18].startswith('- Published `2c9d93c5`') and lines[19].startswith('- The scheduling regression') and lines[20].startswith('- Main `53cbe443`')
lines[18]='- Published `86dcf79d` completes **23/23 workflows successfully**. The [native job](https://github.com/link-assistant/formal-ai/actions/runs/44398918743/job/135136530028) passes lint and **96 Rust cases**: 82 isolated regressions, 13 library source-binding controls and the unchanged Spanish sibling. Four native HTTP tests also pass for forced functions, structured output and localized procedures. Exact log ranges and all 70 collection payload hashes are retained; complete literal review of the native log remains unfinished.'
lines[19]='- The full-worker Russian scheduling regression starts at **21 passes / one failure**; handler registration alone retains the failure. Shared sentence-local promotion plus registration passes all 22 cases, then **30/30** expanded scheduling/memory/source controls. The isolated operational target retains four existing native tests unchanged and admits their consumed documentation and shell inputs; **29/29** policy cases pass. Final local source passes **123 focused tests across seven files**, formatting, projection/registry currency, and **87 executable gates with 52 explicit exclusions**. The governed refresh changes only four Cargo fixture hashes and preserves every complete object. Native execution of the new target and spelled-hour accuracy remain unfinished. See the [calendar dispatch and native success checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/calendar-dispatch-and-native-success-checkpoint.md).'
lines[20]='- Main `53cbe443` is integrated as `5af5dfd7`. Complete decoded output policy and all five grammars remain equal after canonicalizing 986 fields; official generated sources and demanded package mirrors are refreshed. The strict complete-object governed union retains **1,185 / 221 supported / 964 unsupported**. Sixteen original panic contracts have published hosted passes, leaving **37 without passing replays plus three budget failures**. Historical and current-head verification remain distinguished; no native build runs locally.'
old=lines[57];assert old.startswith('Unfinished acceptance remains explicit')
lines[57]=old.replace('15 with published hosted passing replays and **38 without one**','16 with published hosted passing replays and **37 without one**').replace('**134/254 continuous pages**, with 111 complete files, one partial and 8,415 source lines; pages 135–254','**139/254 continuous pages**, with 123 complete files, one partial and 8,766 complete source lines; pages 140–254')
lines[11]+=' The focused operational target reuses the existing shell documentation and download contracts without modifying their test sources.'
lines[12]+=' Calendar creation is registered directly and promoted with the same clause-local evidence as admission, preserving explicit memory writes.'
p.write_text('\n'.join(lines)+'\n');assert p.read_text().count('Fixes #1580')==1
print('Updated the checkpoint, work plan and reviewable PR description; full acceptance remains open.')
