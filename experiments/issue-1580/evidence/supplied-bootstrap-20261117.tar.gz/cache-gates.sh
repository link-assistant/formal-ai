set -eu
export PATH="/tmp/issue-1580-research/shellcheck-v0.11.0:$PATH"
node experiments/formal_ai_subagent/local-gates.mjs --only check-file-size,check-file-size-js-twin,check-changelog-fragment-js-twin,check-ci-speed,lint-shell-scripts > /tmp/issue-1580-research/cache-log-gates.log 2>&1
tail -n 18 /tmp/issue-1580-research/cache-log-gates.log
rg -n 'sccache-outage-fallback|default-branch-build-policy|governed-specification' data/benchmarks/fast-pull-request-javascript-tests.json
