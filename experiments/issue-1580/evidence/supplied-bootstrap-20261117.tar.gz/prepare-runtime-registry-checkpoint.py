import gzip
import hashlib
import json
import pathlib
import subprocess

root=pathlib.Path.cwd()
scratch=pathlib.Path('/tmp/issue-1580-research')
doc=root/'docs/case-studies/issue-1580/runtime-fixture-checkpoint.md'
doc.write_text('''# Runtime fixture and registry checkpoint

Draft work for [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581)
and [issue #1580](https://github.com/link-assistant/formal-ai/issues/1580).
The published input is `7780c70715df515a8ffcb085bff0902b4489bb94`, including
main `058e9bef1214f2f1bc25971243cb787703ed64f1`.

## Reproductions and changes

All 23 workflows on that branch head completed: 22 succeeded and
[Layered CI 44180825006](https://github.com/link-assistant/formal-ai/actions/runs/44180825006)
failed. Original log lines 9038–9062 identify the inline OpenCode test under
`rust/src`. Moving its unchanged assertions into `rust/tests/source` makes
the existing five-case placement suite pass. Its fixture include now resolves
to the canonical repository data. The maintained mirror writer removes the
unused production copy: 481 remaining demands are byte-equal. The first
post-move check failed on that unused copy; its complete diagnostic is retained.
The fixture itself and its 15 envelope cases are unchanged. All 51 JavaScript
source-provenance cases pass; the relocated native case has not executed.

[Main Layered CI 44174503458](https://github.com/link-assistant/formal-ai/actions/runs/44174503458)
records the stale Moon count at lines 15868–15880 and generated registry at
18550–18592. Two fresh workers with local seed transport isolate the count
change: removing both English causal lexemes restores 196 unknown terms;
the current vocabulary has 195, differing only in the term `because`.
All other counts remain identical: 25 sentences, 67 statements, three fully
formal sentences, 423 terms and 61/62 retained facts. Both native and
JavaScript expectations now reflect the causal vocabulary; the JavaScript
file passes all six cases in five languages. The native twin remains unexecuted.

The official native-program generator reproduces and repairs the stale
registry. A complete object comparison preserves all 135 programs and every
executable field. Sixteen source witness hashes change, and the two offsets
of `memory_sync::LEARNED_CHUNK_KIND` move by 127 characters. Each new hash is
checked against the actual source, and the moved span is checked against the
same constant. The existing generated-program suite passes. An initial
comparison incorrectly assumed only hash changes; its failed assertion is
preserved separately from the corrected, complete comparison.

Main pipeline log 44174504347 lines 25731–25739 and 43465–43474 show Claude's
existing Read/Glob/Grep/WebFetch/WebSearch allowlist missing from the expected
argv. The three affected native expectations now retain that exact prefix,
caller flags and argument ordering. Capture normalization and the separate
quiet-stderr assertion remain unchanged. Rust formatting passes; actual native
argv and quiet startup behavior remain unverified.

## Supplied-passage routing controls

The branch already marks recursive candidates as `metaSubTask` and skips
unknown research for those candidates. Removing that guard only inside a
disposable worker reproduces 26 mocked transport calls; the production guard
makes zero calls with the identical passage answer. A standalone unknown
question still makes 16 mocked calls, preserving ordinary research behavior.
No probe contacts a provider. The existing factual QA file passes 15 cases.
The parent procedure still reports unresolved status for this correct answer;
this evidence does not complete recursive procedure acceptance.

Three main-only ledger entries retain the narrow existing JavaScript replays
for the count, registry and passage failures. Full shared-data gates are being
verified separately; no native build or runtime is claimed.

## Evidence and unfinished work

Complete focused logs, controlled reports and hashes are under
`experiments/issue-1580/evidence/checks/{runtime-fixture-refresh,moon-lexeme-probe,passage-routing-probe,native-program-registry-refresh,repaired-registry-and-external-test}/`.
Branch and fresh main inventories/logs are under
`experiments/issue-1580/evidence/ci/{checkpoint-7780c707-final,main-058e9bef-refresh}/`.
CLI and Layered logs identical to the earlier main snapshot are referenced by
hash rather than duplicated. Targeted payload review is not full-log review.

All 17 main push workflows now finish: 13 successes and four failures. The
benchmark corpus has a 900-second termination (44174504103 lines 2829–2831)
and a missing shard proof at 3335–3336; its hot-case cause remains unknown.
The full native pipeline retains failures and five 1,080-second terminations.
Main also reports the picomatch advisory; this branch already carries its
separately tested backport, so the default-branch failure alone is not proof
of a new branch defect. No new security fix is attributed to this checkpoint.

Feedback remains one issue comment, nine PR conversation comments, no inline
comments and no reviews. All earlier native, benchmark, warning, dependency
migration, template semantic review, historical evidence and live identity
criteria remain unfinished. Repository policy forbids feature-branch native
tests, including manual dispatch. Independent Formal AI reasoning acceptance
remains 0/20; supplied scripts, patches and conclusions earn zero credit.
The PR remains draft and unmerged.
''')
comparison=json.loads((root/'experiments/issue-1580/evidence/checks/native-program-registry-refresh/comparison.json').read_text())
text=doc.read_text().replace('all 135 programs',f"all {comparison['programs']} programs")
doc.write_text(text)
plan=root/'experiments/issue-1580/work-plan.md'
with plan.open('a') as stream:
    stream.write('''

## Runtime fixtures and generated registry (2026-11-17)

All 23 workflows on 7780c707 complete: 22 pass and the one Layered failure is the inline OpenCode native test. Move it into the external source suite, preserve its assertions and canonical fixture, and remove the unused mirrored copy through the official writer. Reproduce the Moon 196-to-195 change with a two-worker causal lexeme control and retain native/JavaScript expectations with identical other counts. Refresh the native registry through its generator; complete comparison verifies 16 actual-source hashes, two constant offsets and zero executable changes. Native Claude argv fixtures retain the existing allowlist without changing capture normalization or quiet stderr assertions. Corrected focused checks pass; the first mirror/comparison failures remain preserved. Existing supplied-passage guards pass positive and negative transport controls, but the parent procedure status is still unresolved. Add three main-only replay ledger rows and complete the full shared-data gate set before a single batch push. Native runtime, broader acceptance and 0/20 independent reasoning acceptance remain unfinished. See docs/case-studies/issue-1580/runtime-fixture-checkpoint.md.
''')
refresh=root/'experiments/issue-1580/evidence/ci/main-058e9bef-refresh'
references=[]
for run in ['44174503822','44174503458']:
    duplicate=refresh/f'{run}.log.gz'
    if not duplicate.exists(): continue
    raw=gzip.decompress(duplicate.read_bytes())
    matches=[]
    for prior in (root/'experiments/issue-1580/evidence/ci/main-058e9bef').glob('*.log.gz'):
        if gzip.decompress(prior.read_bytes())==raw: matches.append(prior)
    assert len(matches)==1,(run,matches)
    references.append({'run':run,'logArchive':str(matches[0].relative_to(root)),'rawSha256':hashlib.sha256(raw).hexdigest(),'rawBytes':len(raw)})
    duplicate.unlink()
(refresh/'unchanged-log-references.json').write_text(json.dumps(references,indent=2)+'\n')
publication=root/'experiments/issue-1580/evidence/ci/checkpoint-7780c707-publication'
publication.mkdir(parents=True,exist_ok=True)
for name in ['checkpoint-publication.json','checkpoint-push.log','checkpoint-pull-request-edit.log']:
    data=(scratch/name).read_bytes()
    (publication/(name+'.gz')).write_bytes(gzip.compress(data,mtime=0))
print('registry programs',comparison['programs'],'visited',comparison['visited'],'changes',len(comparison['changes']))
print('deduplicated',json.dumps(references))
print('changelog fragments',*[str(p) for p in root.glob('changelog.d/*1580*')])
print(subprocess.check_output(['git','diff','--check'],text=True))
