set -eu
head -n 8 data/benchmarks/fast-pull-request-javascript-tests.json
tail -n 25 data/benchmarks/fast-pull-request-javascript-tests.json
rg -n 'fast-pull-request-javascript-tests|group|rust/tests/web|experiments/' scripts/run-javascript-tests*.mjs .github/workflows/layered-ci.yml experiments/formal_ai_subagent/local-gates.mjs | head -n 70
git diff --check
wc -l scripts/detect-code-changes.rs
