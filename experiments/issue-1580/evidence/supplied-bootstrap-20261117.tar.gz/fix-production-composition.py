from pathlib import Path

def replace(path, old, new):
    p=Path(path); s=p.read_text()
    assert old in s, (path, old)
    p.write_text(s.replace(old, new))

replace('js/agentic/crate/meta_executor.mjs',
    'const composition = compose(node, test, childOutcomes);',
    'const composition = (host.canCompose?.(node) ?? true) ? compose(node, test, childOutcomes) : null;')
replace('js/agentic/crate/meta_executor.mjs',
    'const host = {\n    draft: async (text, task)',
    '''const host = {
    // Joining prose cannot establish a concrete output contract (for example,
    // source code), even when each fragment has a nonempty response. Only an
    // untyped unresolved root can be discharged by this generic composition.
    canCompose: (task) => task.depth !== 0 || ruleValues('unresolved-intent').includes(answer.intent),
    draft: async (text, task)''')
replace('rust/src/meta_executor.rs',
    '    /// A stored row of an earlier run of this procedure, if any.',
    '''    /// Whether joining child answers can fulfil this task's output contract.
    /// Untyped hosts allow it; production preserves concrete solver intents.
    fn can_compose(&self, _task: &TaskNode) -> bool {
        true
    }

    /// A stored row of an earlier run of this procedure, if any.''')
replace('rust/src/meta_executor.rs',
    'let composition = compose(node, test, child_outcomes);',
    'let composition = compose(node, test, child_outcomes).filter(|_| host.can_compose(node));')
replace('rust/src/meta_executor/production.rs',
    "impl MetaHost for AnswerHost<'_> {",
    '''impl MetaHost for AnswerHost<'_> {
    fn can_compose(&self, task: &TaskNode) -> bool {
        // A prose join cannot establish a concrete contract such as source
        // code. Mirror solveAnswer's root-intent check in JavaScript.
        task.depth != 0
            || self.root.as_ref().is_some_and(|root| {
                super::rule_values("unresolved-intent").contains(&root.intent)
            })
    }
''')
replace('rust/src/solver_helpers/mod.rs',
    'pub struct ValidationChoice {\n    pub answer: String,',
    'pub struct ValidationChoice {\n    pub intent: String,\n    pub answer: String,')
replace('rust/src/solver_helpers/mod.rs',
    'return Some(ValidationChoice {\n                answer:',
    'return Some(ValidationChoice {\n                intent: property.to_owned(),\n                answer:')
replace('rust/src/solver.rs',
    '''if let Some(choice) = record_validation(&mut log, prompt) {
                    let response_link''',
    '''if let Some(choice) = record_validation(&mut log, prompt) {
                    let intent = choice.intent;
                    let response_link''')
replace('rust/src/solver.rs',
    'let validation_choice = record_validation(&mut log, prompt);\n            record_candidates',
    '''let validation_choice = record_validation(&mut log, prompt);
            let intent = validation_choice.as_ref().filter(|_| matches!(rule, SelectedRule::Unknown))
                .map_or(intent, |choice| choice.intent.clone());
            record_candidates''')
replace('rust/src/solver.rs', '\nimpl UniversalSolver {}\n', '\n')
replace('js/worker/formal_ai_worker_solve.js',
    '''intent: "unknown",
    content: validation?.answer''',
    '''intent: validation?.answer ? NUMBER_PROPERTY_PRIME_SLUG : "unknown",
    content: validation?.answer''')

# Native counterpart: the same production host, not a duplicated guard.
p=Path('rust/tests/unit/meta_executor_parity.rs')
p.write_text(p.read_text()+'''
#[test]
fn production_composition_preserves_concrete_output_obligations() {
    for intent in ["write_program_skill_gap", "write_program_unspecified", "write_program"] {
        let root = Draft { intent: intent.to_owned(), content: "Source unavailable".to_owned(), confidence: 0.0 };
        let mut child = |_: &str| Some(Draft {
            intent: "read_file".to_owned(), content: "A reading tool is needed".to_owned(), confidence: 1.0,
        });
        let run = formal_ai::meta_executor::solve_answer(
            Request { text: "Create source and import assert", language: "en" }, root, &mut child, &RunOptions::default(),
        ).expect("outer production turn");
        assert!(formal_ai::meta_executor::adopted_composition(&run).is_none(), "{intent}");
        assert!(run.events.iter().any(|event| event.kind == "meta_exec:compose"));
    }
}

#[test]
fn production_composition_still_solves_untyped_independent_tasks() {
    let mut child = |text: &str| Some(Draft {
        intent: "answered".to_owned(), content: text.to_owned(), confidence: 1.0,
    });
    let run = formal_ai::meta_executor::solve_answer(
        Request { text: "First task and second task", language: "en" },
        Draft { intent: "unknown".to_owned(), content: String::new(), confidence: 0.0 },
        &mut child, &RunOptions::default(),
    ).expect("outer production turn");
    let composed = formal_ai::meta_executor::adopted_composition(&run).expect("valid composition");
    assert!(composed.content.contains("First task"));
    assert!(composed.content.contains("second task"));
}
''')
