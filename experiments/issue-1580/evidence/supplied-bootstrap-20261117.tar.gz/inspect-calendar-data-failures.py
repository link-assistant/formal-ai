import pathlib, subprocess

commands = [
    ['git', 'branch', '--show-current'],
    ['rg', '-n', 'calendar-duration-sum|year\\|years', 'data/seed', 'js', 'rust'],
    ['rg', '-n', 'seed_lino_values_never_pipe_pack|meaning_slugs_are_globally_unique|lino_data_files_are_parseable', 'rust/tests', 'js', 'scripts', 'experiments/formal_ai_subagent'],
    ['rg', '-n', 'calendar.*alias|unit.*alias|duration.*term|handler-rules', 'js/agentic', 'rust/src/agentic_coding', 'rust/tests/web/issue-1589-calendar-currency.test.mjs'],
]
for command in commands:
    print('\nCOMMAND', repr(command), flush=True)
    result = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    lines = result.stdout.splitlines()
    if len(lines) > 180:
        target = pathlib.Path('/tmp/issue-1580-research/calendar-data-search-' + str(commands.index(command)) + '.log')
        target.write_text(result.stdout)
        print('saved', len(lines), 'lines to', target)
        print('\n'.join(lines[:180]))
    else:
        print(result.stdout)
