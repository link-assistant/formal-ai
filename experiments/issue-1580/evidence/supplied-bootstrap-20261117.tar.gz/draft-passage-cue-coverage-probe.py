from pathlib import Path

source = Path('experiments/issue-1580/probe-parent-answer-coverage.mjs').read_text()
target = Path('experiments/issue-1580/probe-passage-cue-coverage.mjs')
assert not target.exists()

def replace_once(before, after):
    global source
    assert source.count(before) == 1, before
    source = source.replace(before, after)

replace_once("transform('host.canCompose?.(node)', 'host.canCompose?.(node, childOutcomes)');", '''transform('host.canCompose?.(node)', 'host.canCompose?.(node, childOutcomes)');
transform('const mask = quotedMask(original);', `const mask = quotedMask(original);
  if (globalThis.parentCoverageProbePrefixEnabled) {
    const openings = ruleValues('quote-pair').map(pair => Array.from(pair)[0]);
    const edges = ruleValues('edge-punctuation');
    for (const cue of globalThis.parentCoverageProbeCueSurfaces) {
      const chars = Array.from(cue).map(character => character.toLowerCase());
      for (let at = 0; at < original.length; at += 1) {
        if (!markerMatches(lowered, original, mask, at, chars, containsCjk(cue))) continue;
        let next = at + chars.length;
        while (next < original.length && (isWhitespace(original[next]) || edges.includes(original[next]))) next += 1;
        if (!openings.includes(original[next])) continue;
        mask.fill(true, at, at + chars.length);
        globalThis.parentCoverageProbeCueEvents.push({cue, start: at, end: at + chars.length});
      }
    }
  }`);''')
replace_once("answer.intent === 'calculation' && outcomes.some", "['calculation', 'prompt_text_gap'].includes(answer.intent) && outcomes.some")
replace_once('globalThis.parentCoverageProbeEnabled = false;', "globalThis.parentCoverageProbeEnabled = false;\n  globalThis.parentCoverageProbePrefixEnabled = false;\n  globalThis.parentCoverageProbeCueSurfaces = factualQaSurfaces(FACTUAL_QA_ROLE_TEXT_CUE);\n  globalThis.parentCoverageProbeCueEvents = [];")
replace_once("  { name: 'standalone-arithmetic', prompt: 'Calculate 2 + 2' },", "  { name: 'standalone-arithmetic', prompt: 'Calculate 2 + 2' },\n  { name: 'operation-before-passage-cue', prompt: `Calculate 2 + 2 and read this and answer: ${passage} When is the meeting?` },")
replace_once('    worker.parentCoverageProbeEnabled = coverage;', '    worker.parentCoverageProbeEnabled = coverage;\n    worker.parentCoverageProbePrefixEnabled = coverage;\n    worker.parentCoverageProbeCueEvents.length = 0;')
replace_once('    worker.contextProbeWithheld = item.withheld || [];', '''    worker.contextProbeWithheld = item.withheld || [];
    if (coverage && item.withheld?.length) {
      worker.contextProbeWithheldPrompt = item.prompt;
      // Keep the same semantic last-child obligation after the cue repairs
      // the tree from three children to two; do not withhold a missing id.
      worker.contextProbeWithheld = plain(await evaluate(worker, `(() => {
        const executor = crateModule('crate/meta_executor.mjs');
        const root = executor.planTasks(contextProbeWithheldPrompt, detectLanguage(contextProbeWithheldPrompt), executor.decompositionBounds());
        const leaves = node => node.children.length ? node.children.flatMap(leaves) : [node.id];
        return leaves(root).slice(-1);
      })()`));
    }''')
replace_once('const outcome = { mode, enabled, coverage, coverageEvents:', 'const outcome = { mode, enabled, coverage, cueEvents: plain(worker.parentCoverageProbeCueEvents), withheldTests: plain(worker.contextProbeWithheld), coverageEvents:')
replace_once("['withheld-child', !resolved('withheld-child')],", "['withheld-child', !resolved('withheld-child') && candidate('withheld-child').metaExecution.events.some(event => event.includes('reason=no_test'))],")
replace_once("  ['concrete-output-contract', candidate(", "  ['operation-before-passage-cue', resolved('operation-before-passage-cue') && /Thursday/.test(candidate('operation-before-passage-cue').content) && /2 \\+ 2 = 4/.test(candidate('operation-before-passage-cue').content)],\n  ['concrete-output-contract', candidate(")
replace_once("console.log(JSON.stringify({qualification, passed:", '''// Execute all 25 existing table-host fixtures in the patched VM and compare
// their complete observable results, including every event, unchanged.
worker.parentCoverageProbeEnabled = true;
worker.parentCoverageProbePrefixEnabled = true;
const fixture = JSON.parse(readFileSync('rust/tests/fixtures/meta-executor-parity.json', 'utf8'));
const fixtureCompatibility = [];
for (const entry of fixture.cases) {
  worker.contextProbeFixture = entry;
  const actual = plain(await evaluate(worker, `(async () => {
    const executor = crateModule('crate/meta_executor.mjs');
    const entry = contextProbeFixture;
    const own = (table, text) => Object.hasOwn(table, text) ? table[text] : null;
    const run = await executor.executeProcedure({text: entry.text, language: entry.language}, {
      draft: async text => own(entry.answers, text), cached: async text => own(entry.cached, text),
    }, {bounds: entry.bounds, withheldTests: entry.withheld});
    return {shape: executor.decompositionShape(run.root), leaves: executor.taskLeaves(run.root),
      status: run.outcome.status, content: run.outcome.candidate?.content ?? null,
      events: run.events.map(event => event.kind + ' ' + event.payload)};
  })()`));
  let passed = true;
  try { assert.deepEqual(actual, entry.expected); } catch { passed = false; }
  fixtureCompatibility.push({name: entry.name, passed, ...(passed ? {} : {actual, expected: entry.expected})});
}
const structuralControls = [];
for (const text of ['Read this and answer', 'Read this and answer: Count the letters and report the vowels']) {
  worker.contextProbeStructuralText = text;
  worker.parentCoverageProbePrefixEnabled = false;
  const baseline = plain(await evaluate(worker, "crateModule('crate/meta_executor.mjs').splitRequest(contextProbeStructuralText, 'en')"));
  worker.parentCoverageProbePrefixEnabled = true;
  const candidate = plain(await evaluate(worker, "crateModule('crate/meta_executor.mjs').splitRequest(contextProbeStructuralText, 'en')"));
  let passed = true;
  try { assert.deepEqual(candidate, baseline); } catch { passed = false; }
  structuralControls.push({text, baseline, candidate, passed});
}
console.log(JSON.stringify({fixtureCompatibility, structuralControls}));
console.log(JSON.stringify({qualification, passed:''')
replace_once("'js/worker/formal_ai_worker_factual_qa.js'].map", "'js/worker/formal_ai_worker_factual_qa.js', 'js/worker/formal_ai_worker_crate_meta_executor.js', 'data/seed/meanings-facts.lino', 'data/seed/text-formalization.lino', 'rust/tests/fixtures/meta-executor-parity.json'].map")
replace_once("schema: 'issue-1580-parent-answer-coverage-experiment/v1', qualification,", "schema: 'issue-1580-passage-cue-coverage-experiment/v1', qualification, fixtureCompatibility, structuralControls, seededCueSurfaces: plain(worker.parentCoverageProbeCueSurfaces),")
replace_once("'experiments/issue-1580/evidence/checks/passage-routing-probe/parent-answer-coverage.json.gz'", "'experiments/issue-1580/evidence/checks/passage-routing-probe/passage-cue-coverage.json.gz'")
target.write_text(source)
starter = Path('/tmp/issue-1580-research/run-parent-answer-coverage-probe.py').read_text()
starter = starter.replace("/parent-answer-coverage-probe'", "/passage-cue-coverage-probe'").replace('probe-parent-answer-coverage.mjs', 'probe-passage-cue-coverage.mjs').replace("'requestBound': 9", "'requestBound': 10")
Path('/tmp/issue-1580-research/run-passage-cue-coverage-probe.py').write_text(starter)
print(f'Created {target}: {len(source.encode())} bytes; 10 requests x 3 variants, 25 unchanged fixture replays, 2 structural controls; disposable VM only.')
