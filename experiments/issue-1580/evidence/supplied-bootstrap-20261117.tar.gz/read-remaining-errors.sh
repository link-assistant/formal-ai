python3 - <<'PY'
import gzip,re
from pathlib import Path
root=Path('/tmp/issue-1580-research/current-head-ci')
lines=gzip.open(root/'44059369287.log.gz','rt').read().splitlines()
for i in range(8110,8210):
 print(str(i+1),re.sub(r'\x1b\[[0-9;]*m','',lines[i]))
lines=gzip.open(root/'44059368522.log.gz','rt').read().splitlines()
for i,line in enumerate(lines):
 if '✖ ' in line or '[test-file] failed' in line or 'JavaScript suites shard' in line: print(i+1,line)
PY
sed -n '1,120p' rust/tests/web/rust-specification-fixture-integrity.test.mjs
sed -n '1,160p' rust/tests/web/rust-specification-unicode-identifiers.test.mjs
rg -n 'refresh.*governed|governed.*refresh|nativeSourceHashes|nativeSources' scripts/rust-specification* scripts/lib/rust-specification* rust/tests/web/rust-specification* package.json
