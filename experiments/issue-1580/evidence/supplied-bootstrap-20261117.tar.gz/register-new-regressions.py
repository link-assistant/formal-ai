import json
from pathlib import Path
p=Path('data/benchmarks/fast-pull-request-javascript-tests.json')
data=json.loads(p.read_text())
for name in ['cargo-audit-blocked-proof','issue-1580-template-observations']:
    file='rust/tests/web/'+name+'.test.mjs'
    assert file not in data['files']
    data['files'].append(file)
p.write_text(json.dumps(data,indent=2)+'\n')
print('Registered the audit and template observation suites in the fast PR inventory.')
