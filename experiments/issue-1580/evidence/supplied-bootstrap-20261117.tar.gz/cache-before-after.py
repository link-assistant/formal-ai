import json,os,subprocess,tempfile
from pathlib import Path
oldref=subprocess.check_output(['git','rev-parse','22ffaa73d^'],text=True).strip()
old=subprocess.check_output(['git','show',oldref+':scripts/check-sccache-write-health.sh'],text=True)
stats=json.dumps({'cache_writes':60,'cache_write_errors':20},indent=2)
with tempfile.TemporaryDirectory(prefix='issue-1580-cache-') as directory:
    script=Path(directory)/'before.sh';script.write_text(old)
    results=[]
    for name,path in [('before',str(script)),('after','scripts/check-sccache-write-health.sh')]:
        env=os.environ.copy()
        env.update(SCCACHE_WRITE_ERROR_WARN_PERCENT='25',SCCACHE_WRITE_MIN_ATTEMPTS='20',GITHUB_STEP_SUMMARY=str(Path(directory)/(name+'.md')))
        r=subprocess.run(['bash',path,'-'],input=stats,text=True,capture_output=True,env=env)
        assert r.returncode==0,r.stderr
        results.append({'version':name,'source':oldref if name=='before' else subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'stderr':r.stderr,'warning':r.stderr.startswith('::warning')})
    assert results[0]['warning'] is False
    assert results[1]['warning'] is True
    assert '25%' in results[1]['stderr']
Path('experiments/issue-1580/evidence/checks/cache-before-after.json').write_text(json.dumps({'input':stats,'results':results},indent=2)+'\n')
print('Same pretty JSON: previous source silently misses the warning; patched source reports the measured 25% write-error share.')
