from pathlib import Path
import json, subprocess

name = "/tmp/issue-1580-research/collect-python-fragment-head-ci.py"
lines = Path(name).read_text().splitlines()
assert len(lines) < 300
print("COLLECTOR")
print("\n".join(f"{n}: {line}" for n, line in enumerate(lines, 1)))
print("PLAN AND DECISION PATHS")
result = subprocess.run(["rg", "--files", "docs/case-studies/issue-1580", "experiments/issue-1580"], capture_output=True, text=True, check=True)
print("\n".join(p for p in result.stdout.splitlines() if any(s in p for s in ["plan", "requirements", "checkpoint", "semantic-decisions"])))
