from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
p=root/'rust/tests/unit/specification/formalization.rs'
text=p.read_text()
before='''fn same_prompt_and_config_produce_same_interpretation_choice() {
    let config = SolverConfig {
        temperature: 0.9,'''
after='''fn same_prompt_and_config_produce_same_interpretation_choice() {
    // Compare the complete answer against fixed inputs. A live first fetch and
    // a later cache hit have different provenance even with the same choice.
    let config = SolverConfig {
        offline: true,
        temperature: 0.9,'''
assert text.count(before)==1
p.write_text(text.replace(before,after))
print('The interpretation fixture retains full SymbolicAnswer equality and every original candidate assertion; only this fixture explicitly denies live fetches. Native execution remains pending.')
