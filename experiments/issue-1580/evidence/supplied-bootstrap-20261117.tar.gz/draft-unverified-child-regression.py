from pathlib import Path
import json

path = Path('rust/tests/web/issue-1550-meta-executor.test.mjs')
source = path.read_text()
assert 'unverified drafts cannot satisfy' not in source
source += '''
test('unverified drafts cannot satisfy a leaf test or complete an all-required parent', async () => {
  for (const intent of [
    'meta_reasoned_program_unverified',
    'coding_workspace_written_unverified',
    'general_plan_unverified',
  ]) {
    assert.equal(executor.answerValidation(intent, 'A nonempty draft'), `answered(${intent})=false`, intent);
  }
  for (const intent of ['meta_reasoned_program_unverified', 'meta_reasoned_program']) {
    const run = await executor.executeProcedure({ text: 'First task and second task', language: 'en' }, {
      cached: async () => null,
      draft: async (text) => text === 'First task'
        ? { intent, content: 'A nonempty program', confidence: 1 }
        : text === 'second task'
          ? { intent: 'answered', content: 'Second result', confidence: 1 }
          : null,
    });
    assert.equal(run.outcome.status, intent.endsWith('_unverified') ? 'unresolved' : 'resolved', intent);
  }
});
'''
path.write_text(source)
base = Path('/tmp/issue-1580-research/unverified-child-status')
base.mkdir(exist_ok=False)
fixture = Path('rust/tests/fixtures/meta-executor-parity.json')
(base / 'original-fixture.json').write_bytes(fixture.read_bytes())
print(json.dumps({'regression': str(path), 'productionChanged': False, 'beforeLogDirectory': str(base), 'independentAuthorshipCredit': 0}))
