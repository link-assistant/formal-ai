from pathlib import Path
import subprocess
p=Path('scripts/ci-native-regressions.sh');s=p.read_text();s=s.replace('cleanup_native_regressions() {','# Invoked indirectly by the EXIT trap below.\n# shellcheck disable=SC2329\ncleanup_native_regressions() {');p.write_text(s)
with Path('/tmp/issue-1580-research/native-overlap-draft-validation/shellcheck-recheck-2.log').open('w')as f:r=subprocess.run(['/home/box/.local/bin/shellcheck',str(p)],stdout=f,stderr=subprocess.STDOUT)
print('SHELLCHECK',r.returncode);assert r.returncode==0
