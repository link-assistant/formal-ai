from pathlib import Path
import json,subprocess
root=Path('/tmp/issue-1580-research')
for key,endpoint in [('issue-comments','issues/1580/comments'),('pr-comments','issues/1581/comments'),('pr-inline','pulls/1581/comments'),('pr-reviews','pulls/1581/reviews')]:
 pages=json.loads(subprocess.check_output(['gh','api','repos/link-assistant/formal-ai/'+endpoint,'--paginate','--slurp'],text=True))
 rows=[item for page in pages for item in page]
 (root/(key+'-latest.json')).write_text(json.dumps(rows,indent=2)+'\n')
 print(key,json.dumps([{'id':item['id'],'updated_at':item.get('updated_at'),'body':item.get('body'),'state':item.get('state')} for item in rows]))
for source in json.loads((root/'templates/manifest.json').read_text()):
 current=json.loads(subprocess.check_output(['gh','api','repos/'+source['repo']+'/commits?per_page=1'],text=True))[0]['sha']
 print(json.dumps({'repository':source['repo'],'pinned':source['sha'],'current':current,'same':current==source['sha']}))
