from pathlib import Path
import gzip,hashlib,json
base=Path('experiments/issue-1580/evidence/checks/main-merge-058e9bef')
p=base/'all-local-gates.json'
if not p.exists():
    raw=Path('/tmp/issue-1580-research/merged-058e9bef-all-local-gates.log').read_text()
    print('RUNNING; aggregate tail:');print('\n'.join(raw.splitlines()[-12:]))
else:
    data=json.loads(p.read_text());print(json.dumps({k:v for k,v in data.items() if k!='gateLogs'},indent=2))
    for row in data['gateLogs']:
        detail=gzip.decompress((base/row['log']).read_bytes())
        assert hashlib.sha256(detail).hexdigest()==row['rawSha256']
    print('Hash-validated per-gate archives',len(data['gateLogs']))
    raw=Path('/tmp/issue-1580-research/merged-058e9bef-all-local-gates.log').read_bytes()
    print('COMPLETE AGGREGATE',len(raw.splitlines()),'LINES',hashlib.sha256(raw).hexdigest());print(raw.decode())
