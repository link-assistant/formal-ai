sed -n '1,200p' /tmp/issue-1580-research/documentation-reporting.log
sed -n '1,220p' experiments/issue-1580/work-plan.md
sed -n '1,200p' docs/case-studies/issue-1580/templates/README.md
python3 /tmp/issue-1580-research/inspect-head-ci.py
