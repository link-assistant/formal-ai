from pathlib import Path
import sys
page=int(sys.argv[1])
requests=[
 ('.github/workflows/native-type-check.yml',1,145),
 ('rust/tests/source.rs',1,100),
 ('rust/tests/source/source_tests/structured_log/mod.rs',1,100),
 ('.github/workflows/release.yml',320,385),
 ('.github/workflows/release.yml',540,615),
 ('scripts/native-test-artifact.mjs',1,125),
]
name,a,b=requests[page]
p=Path(name)
if p.exists():
 lines=p.read_text().splitlines();print(name,'LINES',len(lines))
 print('\n'.join(f'{i+1}: {line}' for i,line in enumerate(lines) if a<=i+1<=b))
else: print('MISSING',name)
