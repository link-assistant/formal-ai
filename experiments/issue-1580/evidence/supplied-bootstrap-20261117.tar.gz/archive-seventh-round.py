from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import subprocess

assert subprocess.check_output(['git','branch','--show-current'],text=True).strip() == 'issue-1580-8d61a32a61e1'
head = '09021cb30ed98851f59f8b55f2cf71470ec613f4'
source = Path('/tmp/issue-1580-research/head-09021cb30/runs.json')
raw = source.read_bytes()
rows = json.loads(raw)
if isinstance(rows, dict):
    rows = rows.get('workflow_runs', rows.get('runs'))
assert len(rows) == 24
assert all(row['headSha'] == head and row['status'] == 'completed' and row['conclusion'] == 'success' for row in rows)
folder = Path('experiments/issue-1580/evidence/ci/09021cb30')
folder.mkdir(parents=True,exist_ok=True)
packed = gzip.compress(raw,mtime=0)
(folder/'runs.json.gz').write_bytes(packed)
(folder/'summary.json').write_text(json.dumps({
    'head':head,'observedAt':datetime.now(timezone.utc).isoformat(),
    'workflowRuns':24,'completedSuccess':24,'failed':0,'active':0,
    'verificationLimit':'Includes scope-gated successful workflows. Native runtime tests and full native change-detector behavior do not execute on pull requests under repository policy.',
    'files':[{'file':'runs.json.gz','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'compressedSha256':hashlib.sha256(packed).hexdigest()}],
    'runs':[{'id':row['databaseId'],'name':row['workflowName'],'conclusion':row['conclusion'],'url':'https://github.com/link-assistant/formal-ai/actions/runs/'+str(row['databaseId'])} for row in rows],
},indent=2)+'\n')
readme = Path('docs/case-studies/issue-1580/README.md')
readme.write_text(readme.read_text()+'\n### Hosted checkpoint after CommonJS and evidence-size repairs\n\nAll 24 workflow runs on `09021cb30ed98851f59f8b55f2cf71470ec613f4` completed successfully, with zero pending or failed runs. [Exact-head run metadata](../../../experiments/issue-1580/evidence/ci/09021cb30/summary.json) records the identities and byte hashes. Successful scope-gated workflows do not execute the main-only native runtime suites, native detector regressions, external benchmark capability checks, or live work-item qualification. These broader criteria remain unfinished; the subsequent Go and cache commits require their own hosted results.\n')
plan = Path('experiments/issue-1580/work-plan.md')
plan.write_text(plan.read_text()+'\n## Published checkpoint before the Go/cache batch\n\nAll 24 workflows on 09021cb30e completed successfully; no active or queued runs remain, and freshly fetched origin/main is already an ancestor. Retain exact-head metadata, review the Go/cache diff, archive supplied bootstrap scripts and Formal AI execution transcripts, then push the batch once. Native runtime, full template semantic review, benchmark capability, live identity, and historical cache-cause criteria remain open.\n')
report = Path('experiments/issue-1580/upstream/go-stale-pin-integrity-report.md')
text = report.read_text()
assert 'Permanent evidence commit/link will be added before filing' in text
text = text.replace('Permanent evidence commit/link will be added before filing', 'Immutable regression evidence: https://github.com/link-assistant/formal-ai/blob/a4053def4bd4b921001fdf84a026ae35deebfc39/experiments/issue-1580/template-go-result-integrity.test.mjs (file only after this commit is published)')
report.write_text(text)
print('Preserved all 24 successful exact-head workflow identities; broad acceptance remains open.')
