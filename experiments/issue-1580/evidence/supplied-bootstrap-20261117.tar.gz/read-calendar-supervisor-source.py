from pathlib import Path
for name in ['calendar-validation-job.py','start-calendar-validation.py','seal-calendar-commit.py','archive-evidence.py']:
 p=Path('/tmp/issue-1580-research')/name
 lines=p.read_text().splitlines()
 print(name,len(lines))
 print('\n'.join(f'{i+1}: {line}' for i,line in enumerate(lines[:200])))
