from pathlib import Path
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/checks/health-cache-fixtures'
changes = []
def replace(name, before, after):
 path = root / name
 raw = path.read_bytes()
 text = raw.decode()
 assert text.count(before) == 1, (name, before)
 updated = text.replace(before, after)
 saved = base / 'source-before' / (name + '.gz')
 if not saved.exists():
  saved.parent.mkdir(parents=True, exist_ok=True)
  saved.write_bytes(gzip.compress(raw, mtime=0))
 path.write_text(updated)
 changes.append({'path':name,'beforeSha256':hashlib.sha256(raw).hexdigest(),'afterSha256':hashlib.sha256(updated.encode()).hexdigest()})

health = 'rust/tests/web/server-memory-schema.test.mjs'
replace(health, "  assert.deepEqual(memoryHealthStatus(env(file)), {", "  const expected = {")
replace(health, "    minimum_readable_schema_version: 1,\n    schema_version: 1,", "    minimum_readable_schema_version: 1,\n    mode: 'read_write',\n    schema_version: 1,")
replace(health, "    target_schema_version: 2,\n  });\n  assert.equal(fs.readFileSync(file, 'utf8'), RELEASED);", "    target_schema_version: 2,\n  };\n  assert.deepEqual(memoryHealthStatus(env(file)), expected);\n  const originalPath = path.join(dir, 'configured-memory.lino');\n  assert.deepEqual(memoryHealthStatus(env(file), { originalPath }, true), {\n    ...expected, configured_path: originalPath, mode: 'read_only',\n  });\n  assert.deepEqual(fs.readdirSync(dir), ['memory.lino']);\n  assert.equal(fs.readFileSync(file, 'utf8'), RELEASED);")

hive = 'rust/tests/web/hive-work-item-consumer.test.mjs'
replace(hive, "import {before,test} from 'node:test';", "import {after,before,test} from 'node:test';")
replace(hive, "before(async()=>{await installNodeHost(new WorkerHost());});", "const previousLiveFetch=process.env.FORMAL_AI_LIVE_FETCH;\nbefore(async()=>{\n process.env.FORMAL_AI_LIVE_FETCH='0';\n await installNodeHost(new WorkerHost());\n});\nafter(()=>{\n if(previousLiveFetch===undefined)delete process.env.FORMAL_AI_LIVE_FETCH;\n else process.env.FORMAL_AI_LIVE_FETCH=previousLiveFetch;\n});")
replace(hive, "process.env.FORMAL_AI_CACHE_DIR=runtime;delete process.env.FORMAL_AI_SOURCE_CACHE_DIR;delete process.env.FORMAL_AI_LIVE_FETCH;", "// Cache/baseline replay is explicitly offline under the default-on read policy.\n  process.env.FORMAL_AI_CACHE_DIR=runtime;delete process.env.FORMAL_AI_SOURCE_CACHE_DIR;process.env.FORMAL_AI_LIVE_FETCH='0';")

source = 'rust/tests/web/issue-1168-source-cache.test.mjs'
replace(source, "// `FORMAL_AI_LIVE_FETCH` opt-in exactly as `VersionSet::for_generation` does.", "// shared default-on read policy; cache-only replay explicitly disables live reads.")

profile = 'rust/tests/web/fast-pull-request-production-profile.test.mjs'
replace(profile, "'github-json-observation','self-authored-publication-source','hive-pre-effect-deferral','javascript-audit-inventory',", "'github-json-observation','self-authored-publication-source','hive-pre-effect-deferral','javascript-audit-inventory',\n    'server-memory-schema','hive-work-item-consumer','issue-1168-source-cache',")

inventory = 'data/benchmarks/fast-pull-request-javascript-tests.json'
path = root / inventory
value = json.loads(path.read_text())
for name in [health, hive, source]:
 assert name not in value['files']
 value['files'].append(name)
replace(inventory, path.read_text(), json.dumps(value, indent=2)+'\n')

ledger = 'data/meta/main-only-regressions.lino'
path = root / ledger
addition = '''main-run 44188508228
  javascript-twin
    regression health-schema-access-mode
      introduced-by "commit ec6ade5cd (server ephemeral memory mode)"
      failed "server-memory-schema: health schema assertion omitted the supported read_write mode"
      check rust/tests/web/server-memory-schema.test.mjs
      marker "mode: 'read_only'"
    regression hive-cache-replay-network-policy
      introduced-by "default-on source reads observed on main 015a6831"
      failed "hive-work-item-consumer: empty source cache expected baseline but live publisher returned a pin"
      check rust/tests/web/hive-work-item-consumer.test.mjs
      marker "Cache/baseline replay is explicitly offline"
    regression version-cache-replay-network-policy
      introduced-by "default-on source reads observed on main 015a6831"
      failed "issue-1168-source-cache: empty source cache expected baseline but live publisher returned a pin"
      check rust/tests/web/issue-1168-source-cache.test.mjs
      marker "process.env.FORMAL_AI_LIVE_FETCH = '0'"
'''
assert 'main-run 44188508228' not in path.read_text()
replace(ledger, path.read_text(), path.read_text()+addition)
(base / 'changes.json').write_text(json.dumps({'changes':changes,'productionBehaviorChanged':False,'independentAuthorshipCredit':0}, indent=2)+'\n')
print(json.dumps({'updatedFiles':sorted(set(row['path'] for row in changes)), 'fastInventoryFiles':len(value['files']), 'independentAuthorshipCredit':0}))
