from pathlib import Path
import gzip,json,hashlib
scratch=Path('/tmp/issue-1580-research')
base=Path('experiments/issue-1580/evidence/ci/summary-governed-7f19154a')
source=scratch/'ci-logs/summary-governed-7f19154a'
report=json.loads((source/'outcome.json').read_text());assert report['complete'] and all(x['exitCode']==0 for x in report['records'])
(base/'collector-outcome.json').write_text(json.dumps(report,indent=2)+'\n')
if (source/'worker.log').exists():(base/'collector-worker.log.gz').write_bytes(gzip.compress((source/'worker.log').read_bytes(),mtime=0))
for row in report['records']:
 for label in ['stdout','stderr']:
  raw=gzip.decompress((base/(row['name']+'.'+label+'.gz')).read_bytes());assert hashlib.sha256(raw).hexdigest()==row[label+'Sha256']
runs=json.loads(gzip.decompress((base/'completed-head-runs.stdout.gz').read_bytes()))
rows=[x for page in runs for x in page['workflow_runs']];assert len(rows)==23 and all(x['status']=='completed' and x['conclusion']=='success' and x['head_sha']==report['head'] for x in rows)
retained=[]
pub=scratch/'summary-governed-publication';out=Path('experiments/issue-1580/evidence/checks/summary-governed-publication');out.mkdir(exist_ok=True)
for p in sorted(pub.iterdir()):
 if p.is_file():
  raw=p.read_bytes();target=p.name+'.gz';(out/target).write_bytes(gzip.compress(raw,mtime=0));retained.append({'name':p.name,'archive':target,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
(out/'archive-manifest.json').write_text(json.dumps({'files':retained,'independentAuthorshipCredit':0},indent=2)+'\n')
print('VERIFIED_PUBLISHED_WORKFLOWS',len(rows),'COLLECTOR_COMMANDS',len(report['records']),'PUBLICATION_FILES',len(retained))
print('PUBLICATION_OUTCOME',json.loads((pub/'outcome.json').read_text()))
