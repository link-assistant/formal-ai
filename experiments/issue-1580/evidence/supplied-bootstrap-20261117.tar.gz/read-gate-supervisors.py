from pathlib import Path
import subprocess
r=Path('/tmp/gh-issue-solver-1794900398048')
for args in [['rg','--files','/tmp/issue-1580-research'],['git','diff','--','desktop/package-lock.json','vscode/package-lock.json']]:
 cp=subprocess.run(args,cwd=r,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 lines=cp.stdout.splitlines()
 if args[0]=='rg':lines=[s for s in lines if any(k in s for k in ['calendar','seal','archive','validation','gate'])]
 print('\n'.join(lines))
for name in ['experiments/issue-1580/README.md','docs/case-studies/issue-1580/work-plan.md','rust/tests/web/javascript-audit-inventory.test.mjs','scripts/check-file-size.mjs']:
 p=r/name
 if p.exists():
  lines=p.read_text().splitlines()
  print(name,'lines',len(lines))
  start=max(0,len(lines)-110) if 'issue-1580' in name else 0
  print('\n'.join(f'{i+1}: {lines[i]}' for i in range(start,min(start+150,len(lines)))))
