from pathlib import Path
import subprocess
print(subprocess.check_output(['rg','--files','experiments/issue-1580'],text=True).strip().replace('\n','\n').split('unlikely-absent-marker')[0] if False else '')
names=subprocess.check_output(['rg','--files','experiments/issue-1580'],text=True).splitlines()
print('\n'.join(name for name in names if 'format_release_notes.py' in name or ('exact-source' in name and ('format' in name or 'python' in name))))
p=Path('experiments/issue-1580/evidence/checks/python-release-formatting/report-draft.json');print(p.read_text())
print(subprocess.check_output(['git','diff','--','docs/case-studies/issue-1580/templates/python-partial-semantic-review.json'],text=True))
