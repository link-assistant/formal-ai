from pathlib import Path
import gzip,hashlib,json,re,shutil
root=Path('experiments/issue-1580/evidence')
research=Path('/tmp/issue-1580-research')
checks=root/'checks'; checks.mkdir(exist_ok=True)
files=[]
for name in ['cargo-audit-blocked-proof.log','template-observations.log','release-pending-pipeline-current.log','all-local-gates-fifth.log','lint-shell-scripts-fifth-failure.log','lint-shell-scripts-fifth-recheck.log']:
 data=(research/name).read_bytes(); packed=gzip.compress(data,mtime=0)
 target=checks/(name+'.gz');target.write_bytes(packed)
 files.append({'file':target.name,'sha256':hashlib.sha256(data).hexdigest(),'compressedSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(data)})
gate=(research/'all-local-gates-fifth.log').read_text()
initial=[{'status':m[0],'gate':m[1],'detail':m[2]} for m in re.findall(r'^(PASS|SKIP|FAIL) (\S+)(.*)$',gate,re.M)]
assert [x['gate'] for x in initial if x['status']=='FAIL']==['lint-shell-scripts']
assert 'shellcheck: command not found' in (research/'lint-shell-scripts-fifth-failure.log').read_text()
recheck=(research/'lint-shell-scripts-fifth-recheck.log').read_text()
assert re.search(r'^PASS lint-shell-scripts ',recheck,re.M)
outcomes=[{**x,'status':'PASS','detail':' verified ShellCheck 0.11.0 recheck; see separate log'} if x['gate']=='lint-shell-scripts' else x for x in initial]
assert len(outcomes)==138,len(outcomes)
assert not any(x['status']=='FAIL' for x in outcomes)
assert sum(x['status']=='PASS' for x in outcomes)==86
assert sum(x['status']=='SKIP' for x in outcomes)==52
(checks/'all-local-gates-fifth-summary.json').write_text(json.dumps({'total':len(outcomes),'passed':sum(x['status']=='PASS' for x in outcomes),'skipped':sum(x['status']=='SKIP' for x in outcomes),'failed':0,'complete':True,'initialInvocation':{'exitCode':1,'outcomes':initial},'recheck':{'exitCode':0,'gate':'lint-shell-scripts','reason':'verified ShellCheck 0.11.0 added to PATH'},'outcomes':outcomes,'files':files},indent=2)+'\n')
ci=root/'ci'/'510fe7606';ci.mkdir(exist_ok=True)
for name in ['44064713318.log.gz','44064713318.json']:
 shutil.copyfile(research/'current-head-ci'/name,ci/name)
shutil.copyfile(research/'new-head-runs.json',ci/'runs.json')
(ci/'sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ci.iterdir() if p.name!='sha256.json'},indent=2)+'\n')
registry=root/'chrono-upstream';registry.mkdir(exist_ok=True)
for crate in ['command-stream','link-calculator']:
 for p in research.glob(crate+'*.json'):
  if 'issues' in p.name:continue
  shutil.copyfile(p,registry/p.name)
(registry/'sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in registry.iterdir() if p.name!='sha256.json'},indent=2)+'\n')
upstream=Path('experiments/issue-1580/upstream')
for name in ['go-manual-release-report.md','go-change-detection-report.md','java-change-detection-report.md','python-change-detection-report.md','php-change-detection-report.md']:
 text=(research/name).read_text().replace('No real GitHub token, network request, repository write or large build is needed by the test.','No GitHub token, network request, writes outside the disposable local fixture, or large build is needed by the test.')
 (upstream/name).write_text(text)
print(json.dumps({'gates':len(outcomes),'passed':sum(x['status']=='PASS' for x in outcomes),'skipped':sum(x['status']=='SKIP' for x in outcomes),'preservedLogs':len(files),'upstreamDrafts':5}))
