from pathlib import Path
import gzip, hashlib, json, re

base=Path('experiments/issue-1580/evidence/ci/main-015a6831')
path=base/'pipeline-44188508650.log.gz'
raw=gzip.decompress(path.read_bytes())
lines=raw.decode().splitlines()
entries=[]
for position,line in enumerate(lines):
 if "panicked at " not in line:continue
 end=position+1
 while end<len(lines) and end<position+25 and 'stack backtrace:' not in lines[end]:end+=1
 payload=[]
 for index in range(position,end):
  clean=re.sub(r'^.*?\d{4}-\d\d-\d\dT[^ ]+Z ?','',lines[index])
  payload.append({'line':index+1,'text':clean})
 entries.append({'number':len(entries)+1,'firstLine':position+1,'lastLine':end,'payload':payload})
result={'source':str(path),'rawSha256':hashlib.sha256(raw).hexdigest(),'totalLines':len(lines),'panics':entries,'reviewComplete':False}
(base/'native-panic-payload-index.json').write_text(json.dumps(result,indent=2)+'\n')
for entry in entries:print(entry['number'],entry['firstLine'],entry['lastLine'],entry['payload'][0]['text'])
