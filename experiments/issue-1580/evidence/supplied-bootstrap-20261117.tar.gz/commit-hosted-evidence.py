from pathlib import Path
import json,subprocess

assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='d0b8b895661c6b5e809810c4da8a3db9f79138b3'
assert json.loads(Path('experiments/issue-1580/evidence/ci/d0b8b8956/documentation-gates.json').read_text())['status']==0
for script in ['archive-round-bootstrap.py','archive-evidence.py']:
 print(subprocess.check_output(['python3','/tmp/issue-1580-research/'+script],text=True).strip())
subprocess.run(['git','add','--','docs/case-studies/issue-1580','experiments/issue-1580/work-plan.md','experiments/issue-1580/upstream/filed-issues.txt','experiments/issue-1580/upstream/template-report-identities.json','experiments/issue-1580/evidence'],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','docs: verify hosted regressions and preserve Python formatter report'],check=True,stdout=subprocess.PIPE)
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
print('HEAD',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
