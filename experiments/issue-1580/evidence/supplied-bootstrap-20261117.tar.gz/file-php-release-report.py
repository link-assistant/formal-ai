from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess

base = Path('experiments/issue-1580/evidence/checks/php-release-guard/report-publication')
preflight = json.loads((base / 'preflight.json').read_text())
assert preflight['sourceUnchanged'] and preflight['issueBodiesUnchanged'] and not preflight['duplicateFound']
bodyfile = base / 'posted-body.md'
body = bodyfile.read_text()
assert hashlib.sha256(body.encode()).hexdigest() == preflight['bodySha256']
urlfile = base / 'url.txt'
assert not urlfile.exists(), 'Report URL already retained; do not publish twice'
url = subprocess.check_output(['gh', 'issue', 'create', '--repo', 'link-foundation/php-ai-driven-development-pipeline-template', '--title', 'CI: automatic release can publish after lint, test or build fails', '--body-file', str(bodyfile)], text=True).strip()
urlfile.write_text(url + '\n')
number = url.rsplit('/', 1)[-1]
raw = subprocess.check_output(['gh', 'api', 'repos/link-foundation/php-ai-driven-development-pipeline-template/issues/' + number])
(base / 'posted-issue.json.gz').write_bytes(gzip.compress(raw, mtime=0))
issue = json.loads(raw)
assert issue['body'] == body and issue['html_url'] == url
(base / 'receipt.json').write_text(json.dumps({'url': url, 'observedAt': datetime.now(timezone.utc).isoformat(), 'bodySha256': preflight['bodySha256'], 'postedIssueSha256': hashlib.sha256(raw).hexdigest(), 'publishedEvidenceHead': preflight['publishedEvidenceHead'], 'upstreamRepaired': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
print(url)
