from pathlib import Path
import gzip,hashlib,json,subprocess
base=Path('experiments/issue-1580/evidence/checks/fast-source-archive-checkout');args=['node','--max-old-space-size=256','scripts/generate-staged-release.mjs','--check-deployed'];run=subprocess.run(args,capture_output=True);raw=run.stdout+run.stderr;(base/'staged-before.log.gz').write_bytes(gzip.compress(raw,mtime=0));value={'argv':args,'exitCode':run.returncode,'rawSha256':hashlib.sha256(raw).hexdigest(),'rawLines':len(raw.splitlines())};(base/'staged-before.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value));print(raw.decode()[:6500])
hits=[]
for p in Path('/tmp/issue-1580-research').glob('*.py'):
 text=p.read_text()
 if 'generate-staged-release' in text:hits.append(p)
print('PREVIOUS HELPERS')
for p in sorted(hits,key=lambda p:p.stat().st_mtime,reverse=True)[:10]:print(p.name)
print('GENERATOR OPTIONS')
p=Path('scripts/generate-staged-release.mjs')
for n,line in enumerate(p.read_text().splitlines(),1):
 if any(x in line for x in ['canonical','--write','--check-deployed','packet']):print(f'{n}: {line[:350]}')
