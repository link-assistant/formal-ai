set -eu
rg -n 'local-gates|0/0 passed|--only.*unknown' rust/tests/web experiments/issue-1580 experiments/formal_ai_subagent --glob '*.test.mjs' --glob '*.test.js'
sed -n '200,290p' experiments/formal_ai_subagent/local-gates.mjs
sed -n '1,140p' scripts/check-file-size.mjs
cat AGENTS.md
