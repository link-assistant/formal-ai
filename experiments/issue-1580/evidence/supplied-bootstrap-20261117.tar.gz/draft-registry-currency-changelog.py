from pathlib import Path
Path('changelog.d/issue-1580-native-registry-currency.md').write_text('Refresh the generated native constant registry after adding optional thinking-step origins. Preserve all 158 program objects and the complete governed inventory, with only the reviewed thinking source hash updated.\n')
print('Wrote generated registry currency changelog.')
