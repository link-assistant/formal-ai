from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess

base = Path('experiments/issue-1580/evidence/ci/decoded-grammar-b26f5eeb')
summary = json.loads((base / 'latest-summary.json').read_text())
assert summary['completedSuccessful'] == summary['runCount'] == 23 and not summary['active'] and not summary['nonPassingCompleted']
target = base / 'checkout-retry-attempt-2'
target.mkdir(exist_ok=False)
metadata_raw = subprocess.check_output(['gh', 'api', 'repos/link-assistant/formal-ai/actions/runs/44245878901'])
metadata = json.loads(metadata_raw)
assert metadata['head_sha'] == summary['head'] and metadata['run_attempt'] == 2 and metadata['conclusion'] == 'success' and metadata['status'] == 'completed'
(target / 'metadata.json.gz').write_bytes(gzip.compress(metadata_raw, mtime=0))
jobs_raw = subprocess.check_output(['gh', 'api', 'repos/link-assistant/formal-ai/actions/runs/44245878901/attempts/2/jobs?per_page=100', '--paginate', '--slurp'])
(target / 'jobs.json.gz').write_bytes(gzip.compress(jobs_raw, mtime=0))
jobs = [job for page in json.loads(jobs_raw) for job in page['jobs']]
selected = [job for job in jobs if job['name'] == 'js tier (node --check over js, suite group 2)']
assert len(selected) == 1 and selected[0]['conclusion'] == 'success'
job = selected[0]
assert all(step['conclusion'] in ['success', 'skipped'] for step in job['steps'])
with (target / 'job.log').open('wb') as output, (target / 'job.stderr').open('wb') as errors:
    result = subprocess.run(['gh', 'run', 'view', '44245878901', '--repo', 'link-assistant/formal-ai', '--attempt', '2', '--job', str(job['id']), '--log'], stdout=output, stderr=errors)
raw = (target / 'job.log').read_bytes()
packed = gzip.compress(raw, mtime=0)
assert gzip.decompress(packed) == raw
(target / 'job.log.gz').write_bytes(packed)
(target / 'job.log').unlink()
assert result.returncode == 0
report = {'observedAt': datetime.now(timezone.utc).isoformat(), 'head': summary['head'], 'workflowRun': 44245878901, 'runAttempt': 2, 'job': job['id'], 'name': job['name'], 'conclusion': job['conclusion'], 'startedAt': job['started_at'], 'completedAt': job['completed_at'], 'steps': job['steps'], 'log': {'file': 'job.log.gz', 'rawBytes': len(raw), 'rawLines': len(raw.splitlines()), 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archivedSha256': hashlib.sha256(packed).hexdigest()}, 'wholeJobLogLiterallyRead': False, 'all23CurrentHeadWorkflowsPass': True, 'fullIssueComplete': False}
(target / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
