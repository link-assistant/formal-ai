sed -n '1,260p' /tmp/issue-1580-research/fix-documentation-reporting.py
sed -n '1,70p' data/benchmarks/fast-pull-request-javascript-tests.json
sed -n '1,200p' docs/case-studies/issue-1580/README.md
git status --short
