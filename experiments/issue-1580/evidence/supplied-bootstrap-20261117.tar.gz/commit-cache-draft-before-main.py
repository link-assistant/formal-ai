from pathlib import Path
import json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
paths = ['rust/src/solver_unknown_reasoning.rs', 'rust/tests/unit/solver_unknown_reasoning_captured_sources.rs', 'data/seed/code-task-cues.lino', 'changelog.d/issue-1580-complete-cache-request-binding.md']
subprocess.run(['rustfmt', '--edition', '2024', '--check', paths[0], paths[1]], cwd=root, check=True)
subprocess.run(['git', 'add', '--', *paths], cwd=root, check=True)
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=root, check=True)
subprocess.run(['git', 'commit', '-m', 'fix: bind cached definitions to complete requests'], cwd=root, check=True)
print('CACHE COMMIT', subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip())
run = subprocess.run(['rg', '--files', 'scripts', '-g', '*embed*', '-g', '*fixture*', '-g', '*governed*'], cwd=root, capture_output=True, text=True)
print('EMBEDDING AND WITNESS TOOLS', run.stdout[:3000])
print('EMBEDDED SEED STATUS', (root / 'rust/embedded/data/seed/code-task-cues.lino').exists())
run = subprocess.run(['git', 'merge', '--no-ff', 'origin/main', '-m', 'Merge main structured-output support into issue 1580'], cwd=root, capture_output=True, text=True)
print('MERGE EXIT', run.returncode)
print(run.stdout[-6500:], run.stderr[-1500:])
print('CONFLICTS', subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=U'], cwd=root, text=True))
