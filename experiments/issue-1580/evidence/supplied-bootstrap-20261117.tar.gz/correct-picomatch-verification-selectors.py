from pathlib import Path
import datetime, gzip, hashlib, json, os, subprocess, time

root=Path('/tmp/gh-issue-solver-1794900398048')
evidence=root/'experiments/issue-1580/evidence/checks/picomatch-single-branch'
scratch=Path('/tmp/issue-1580-research')
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
checks=[]
for label,command in [
    ('corrected-fast-profile',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs']),
    ('corrected-file-size-twin',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size-js-twin'])
]:
    stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
    start=time.monotonic()
    raw=scratch/(label+'.log')
    with raw.open('wb') as handle:
        result=subprocess.run(command,cwd=root,env=env,stdout=handle,stderr=subprocess.STDOUT)
    data=raw.read_bytes()
    (evidence/(label+'.log.gz')).write_bytes(gzip.compress(data,mtime=0))
    checks.append({'label':label,'argv':command,'startedAt':stamp,'exitCode':result.returncode,'durationSeconds':round(time.monotonic()-start,3),'rawSha256':hashlib.sha256(data).hexdigest(),'rawBytes':len(data),'log':label+'.log.gz'})
    print(label,result.returncode)
    print(data.decode())
full=[]
for gate in ['check-file-size','check-file-size-js-twin','check-readable-code','check-abbreviations','check-javascript-dependencies','check-package-self-containment']:
    path=root/'experiments/formal_ai_subagent/sandboxes/gates'/(gate+'.log')
    data=path.read_bytes()
    target=evidence/'final-gates'/(gate+'.log.gz')
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(data,mtime=0))
    full.append({'gate':gate,'log':str(target.relative_to(evidence)),'rawSha256':hashlib.sha256(data).hexdigest(),'rawBytes':len(data),'rawLines':len(data.splitlines())})
    print('ARCHIVED',gate,len(data),len(data.splitlines()))
    if gate=='check-file-size':
        print('PICOMATCH WARNINGS',[line for line in data.decode().splitlines() if 'picomatch' in line])
record={'checks':checks,'allPassed':all(item['exitCode']==0 for item in checks),'reason':'Correct the runner path and gate identifier; preserve both original invocation errors. These are command-selection errors, not failing product regressions.','finalGateLogs':full,'nativeExecuted':False,'autonomousAuthorshipCredit':0}
(evidence/'final-recheck-corrections.json').write_text(json.dumps(record,indent=2)+'\n')
assert record['allPassed']
