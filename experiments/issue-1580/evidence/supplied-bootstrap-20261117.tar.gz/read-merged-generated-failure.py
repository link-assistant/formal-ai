import gzip
import pathlib

directory = pathlib.Path("experiments/issue-1580/evidence/checks/main-merge-512ce428")
saved = directory / "gate-details/check-generated-files.log.gz"
live = pathlib.Path("experiments/formal_ai_subagent/sandboxes/gates/check-generated-files.log")
data = gzip.decompress(saved.read_bytes()) if saved.exists() else live.read_bytes()
lines = data.decode(errors="replace").splitlines()
print("generated-files failure lines", len(lines))
for number, line in enumerate(lines[:1500], 1):
    print(str(number) + ": " + line)
print("FULL RUNNER")
path = pathlib.Path("/tmp/issue-1580-research/run-merged-main-all-gates.py")
for number, line in enumerate(path.read_text().splitlines(), 1):
    print(str(number) + ": " + line)
