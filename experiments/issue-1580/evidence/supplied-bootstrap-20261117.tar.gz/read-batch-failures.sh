python3 /tmp/issue-1580-research/read-batch-failures.py
sed -n '1,150p' .github/workflows/native-type-check.yml
rg -n -A 35 '^  (secrets-scan|test-e2e-pages|base|fast-pr-lint):' .github/workflows/release.yml
