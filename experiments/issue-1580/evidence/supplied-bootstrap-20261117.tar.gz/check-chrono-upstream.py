from pathlib import Path
import json, urllib.request
for crate in ['command-stream','link-calculator']:
    request=urllib.request.Request('https://crates.io/api/v1/crates/'+crate,headers={'User-Agent':'formal-ai-issue-1580-dependency-investigation'})
    with urllib.request.urlopen(request,timeout=30) as response: value=json.load(response)
    Path('/tmp/issue-1580-research/'+crate+'-registry.json').write_text(json.dumps(value,indent=2)+'\n')
    print(crate, 'repository',value['crate'].get('repository'),'latest stable',value['crate'].get('max_stable_version'))
    print('latest releases',[(x['num'],x['created_at'],x['yanked']) for x in value['versions'][:5]])
