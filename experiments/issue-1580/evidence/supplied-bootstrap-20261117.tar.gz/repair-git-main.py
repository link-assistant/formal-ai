from pathlib import Path
p=Path('scripts/detect-code-changes.rs')
s=p.read_text()
s=s.replace('            &changed_files,\n        )?;','            &changed_files,\n        );')
s=s.replace('            "A changelog fragment is waiting on main: the release needs lint, test and the build."\n        )?;','            "A changelog fragment is waiting on main: the release needs lint, test and the build."\n        );')
p.write_text(s)
print('Preserved the boolean release predicate and infallible println statements.')
