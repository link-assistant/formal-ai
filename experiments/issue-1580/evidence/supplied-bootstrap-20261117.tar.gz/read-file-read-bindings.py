from pathlib import Path
for name in ['js/agentic/file_read/records.mjs','rust/src/agentic_coding/file_read/records.rs','rust/src/agentic_coding/file_read/source.rs']:
    print('\nFILE',name)
    for i,line in enumerate(Path(name).read_text().splitlines(),1):print(f'{i}: {line}')
