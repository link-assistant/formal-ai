from pathlib import Path
path=Path('experiments/issue-1580/template-go-result-integrity.test.mjs')
value=path.read_text()
edits=[
("const mode=process.env.FAKE_GIT_MODE;\nif(command==='diff'){", "const mode=process.env.FAKE_GIT_MODE;\nif(command==='cat-file')process.exit(0);\nif(command==='diff'){"),
("const invoke=mode=>spawnSync", "const invoke=(mode,event='push')=>spawnSync"),
("GITHUB_EVENT_NAME:'push',GITHUB_OUTPUT:''", "GITHUB_EVENT_NAME:event,GITHUB_BASE_SHA:'a'.repeat(40),GITHUB_HEAD_SHA:'b'.repeat(40),GITHUB_OUTPUT:''"),
("    assert.match(invoke('code').stdout,/^any-code-changed=true$/mu);\n    assert.match(invoke('docs').stdout,/^any-code-changed=false$/mu);\n    assert.equal(original.split", "    const pullRequest=invoke('missing-comparison','pull_request');\n    assert.equal(pullRequest.status,0,pullRequest.stderr);\n    assert.match(pullRequest.stdout,/^any-code-changed=false$/mu);\n    assert.match(pullRequest.stderr,/fatal: unavailable comparison commit/u);\n    assert.match(invoke('code').stdout,/^any-code-changed=true$/mu);\n    assert.match(invoke('docs').stdout,/^any-code-changed=false$/mu);\n    assert.equal(original.split"),
("    const initial=invoke('first-commit');", "    const missingPullRequest=invoke('missing-comparison','pull_request');\n    assert.equal(missingPullRequest.status,1,missingPullRequest.stderr);\n    assert.doesNotMatch(missingPullRequest.stdout,/^any-code-changed=false$/mu);\n    const initial=invoke('first-commit');"),
]
for before,after in edits:
    assert value.count(before)==1,before
    value=value.replace(before,after)
path.write_text(value)
