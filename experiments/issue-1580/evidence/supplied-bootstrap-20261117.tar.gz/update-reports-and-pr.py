from pathlib import Path
import json,subprocess
root=Path('experiments/issue-1580/upstream')
rows=json.loads(Path('/tmp/issue-1580-research/filed-template-reports.json').read_text())
p=root/'filed-issues.txt';existing=p.read_text()
for row in rows:
 if row['url'] not in existing:existing+=row['url']+'\n'
p.write_text(existing)
(root/'template-report-identities.json').write_text(json.dumps(rows,indent=2)+'\n')
p=Path('docs/case-studies/issue-1580/templates/README.md')
p.write_text(p.read_text()+'''\nThe five reports are now filed with public executable evidence at commit `71e1dee442fd74589df20a1d6f33710b6dec0d18`: [Go manual dispatch #18](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/18), [Go Git observation #19](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/19), [Java #30](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/30), [Python #156](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/156), and [PHP #26](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/26). They are reports, not claims that the template repositories have applied fixes.\n''')
body='''Fixes #1580

This draft repairs observed CI false verdicts and source regressions while retaining the unfinished acceptance criteria below. Failed Git observations now fail the change-detection step instead of producing successful no-code outputs. Documentation-only PRs emit required contexts without compiling; validated candidates retain their intended operation and concrete-output requirements. The latest batch adds executable evidence for shared template failures and preserves complete workflow execution fields.

- Preserve full push/PR ranges, legitimate initial trees, source-path authority, consumed-child validity, full-width punctuation, bounded downloads and duration collection, and honest compiler-cache counters.
- Repair the required-context documentation-policy mismatch, native clippy's unused binding and reviewed governed-source fingerprints. Preserve all 221 witness cases/assertions and all prior functionality.
- Record Chrono's unmaintained notice under the existing exact-version `blocked-upstream` audit policy. The actual dependency migration remains unfinished; stale/missing proofs and unrelated audit failures still fail.
- Inventory and hash-verify all 3,007 files and 48 workflows across the eight pinned templates. Complete parsed workflow documents now retain action inputs, environments, defaults, services, outputs and reusable bindings. The transitive semantic review remains open.

Verification: the latest full local gate invocation had 85 passes, 52 explicit skips and one missing-ShellCheck failure. The verified-binary recheck passed, giving 86 passes, 52 skips and zero unresolved gate failures, with both logs retained. The maintained template suite passes nine tests locally (no language-runtime skips); the actual audit-shell boundary passes three controls; release-pending checks pass three. Existing policy/specification regressions pass, Rust formatting passes, and no Rust compilation/tests ran locally. Native application execution and scope-gated qualifications are not inferred from these results.

The previous pushed head `510fe7606` finished all 24 workflows: the three earlier failing workflows passed; only Security failed on Chrono. The new head `71e1dee44` is under verification. Full logs, source identities, negative controls, per-requirement evidence and exact remaining limits are in [the case study](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/README.md). Supplied commands, patches and orchestration receive zero autonomous-authorship credit; independently accepted Formal AI reasoning remains 0/20.

Shared template reports: [C++ #35](https://github.com/link-foundation/cpp-ai-driven-development-pipeline-template/issues/35), [Go manual release #18](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/18), [Go change detection #19](https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/19), [Java #30](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/30), [Python #156](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/156), [PHP #26](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/26). Draft-accounting findings: [Hive Mind #4071](https://github.com/link-assistant/hive-mind/issues/4071), [#4072](https://github.com/link-assistant/hive-mind/issues/4072). These reports do not complete unmet local criteria.

Still unfinished in this single PR:

- Final-head hosted CI, native fixtures/behavior, benchmark floors and the missing general search/arithmetic capabilities.
- Measured native/JavaScript shard headroom and remaining source-size, extension-package and cache-backend warnings.
- Work-item qualification with actual Docker pull diagnostics, and required-status configuration compatible with machine writers.
- Complete semantic CI-reference closure for all eight templates and every applicable best-practice change.
- Chrono removal from both direct dependency paths, and live serving/Hive identity plus useful-source delivery (upstream [Hive Mind #3909](https://github.com/link-assistant/hive-mind/issues/3909)).

No benchmark floor, global size limit, identity contract or default-branch build policy is weakened. Keep this PR draft and unmerged until every acceptance criterion is verified.
'''
path=Path('/tmp/issue-1580-research/pr-body.md');path.write_text(body)
subprocess.run(['gh','pr','edit','1581','--repo','link-assistant/formal-ai','--title','Fix CI result integrity, change detection, and candidate validation','--body-file',str(path)],check=True)
print('Recorded all five reports and updated PR #1581; draft status retained.')
