from pathlib import Path
import subprocess,json,shutil,os
for name in ["desktop/package.json","vscode/package.json","packages/minimatch-compat/package.json","scripts/lint-shell-scripts.sh"]:
 p=Path(name);lines=p.read_text().splitlines()
 print("FILE",name,"LINES",len(lines))
 for i,line in enumerate(lines,1): print(f"{i}: {line}")
for name in ["desktop/package-lock.json","vscode/package-lock.json"]:
 d=json.loads(Path(name).read_text())
 print("LOCK",name,"TOP",d["packages"].get(""))
 for key,value in d["packages"].items():
  if key.endswith("/picomatch"):print(key,json.dumps(value))
print("SHELLCHECK",shutil.which("shellcheck"))
r=subprocess.run(["rg","--files","/tmp/issue-1580-research"],text=True,capture_output=True)
print("SHELLCHECK CANDIDATES",[x for x in r.stdout.splitlines() if "shellcheck" in x])
r=subprocess.run(["gh","api","/advisories/GHSA-fc5q-39xc-vjpf"],text=True,capture_output=True)
print("ADVISORY STATUS",r.returncode)
if r.returncode==0:
 Path("/tmp/issue-1580-research/picomatch-advisory.json").write_text(r.stdout)
 print(r.stdout)
else: print(r.stderr)
