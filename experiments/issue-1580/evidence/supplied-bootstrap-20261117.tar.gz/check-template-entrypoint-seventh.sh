set -eu
timeout 600 node --test --test-concurrency=1 rust/tests/web/issue-1580-template-observations.test.mjs > /tmp/issue-1580-research/template-observations-seventh.log 2>&1
cat /tmp/issue-1580-research/template-observations-seventh.log
