import gzip,hashlib,json,pathlib,subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
out=root/'experiments/issue-1580/evidence/checks/browser-meaning-hydration'
result=subprocess.run(['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--list'],cwd=root,capture_output=True)
assert result.returncode==0,result.stderr.decode()
payload=result.stdout
(out/'gate-list.log.gz').write_bytes(gzip.compress(payload,mtime=0))
print('GATE LIST',{'sha256':hashlib.sha256(payload).hexdigest(),'bytes':len(payload)})
for line in payload.decode().splitlines():
 if any(x in line.lower() for x in ['worker','seed','javascript','syntax','source','changelog','contribution','specification','portable','native','release']):print(line)
print('NEARBY TESTS')
for p in sorted((root/'rust/tests/web').glob('*.test.mjs')):
 if any(x in p.name for x in ['seed','worker-boot','unknown','term-information','web-search','research','learned','request-opener']):print(p.relative_to(root))
print('BOOTSTRAP HELPERS')
for p in sorted(pathlib.Path('/tmp/issue-1580-research').glob('*publication*.py')):
 print(p.name,len(p.read_text().splitlines()))
