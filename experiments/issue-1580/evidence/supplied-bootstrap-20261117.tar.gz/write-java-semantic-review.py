import hashlib
import json
from pathlib import Path

root = Path.cwd()
source = Path('/tmp/issue-1580-research/templates/java-complete')
inventory = json.loads(Path('/tmp/issue-1580-research/templates/java-complete-inventory.json').read_text())
files = []
excluded = []

def choice(role, paths, decision):
    return role, paths, decision

specific = {
    '.gitattributes': choice('line endings', ['.gitattributes'], 'Keep repository-owned line endings. Java wrapper CRLF checkout dirtiness is already tracked in upstream #28; do not copy its wrapper policy or count an existing report as a new repair.'),
    '.github/actionlint.yaml': choice('workflow lint compatibility', ['.github/workflows/workflows.yml'], 'The source documents queue-schema compatibility. Retain pinned workflow linting; an ignored compatibility finding is not evidence that a workflow executed.'),
    '.github/dependabot.yml': choice('dependency update proposals', ['.github/workflows/dependencies-latest.yml', 'scripts/check-dependencies-latest.rs'], 'Weekly Maven, action and pre-commit updates include a seven-day cooldown. Formal AI keeps its dependency maintenance workflow and independent integrity/unverifiable receipts; Java-specific update groups are not portable.'),
    '.github/workflows/release.yml': choice('release admission, tests and publication', ['.github/workflows/release.yml', '.github/workflows/layered-ci.yml', 'scripts/ci-pull-request-admission.mjs'], 'Reviewed all 610 lines: narrow writer permissions, separate cancelable checks and serialized non-canceling writers, artifact downloads and byte comparison, recovery worktrees, and pinned matrix/tool versions. Java builds on PRs are not applicable to Formal AI default-branch-only application builds. Missing aggregate status is already Java #29. Manual dispatch lint is skipped by its dependency success rule while build admits skipped lint; this is a source observation, not a dispatched or modeled result.'),
    '.github/workflows/rerun-unacquired.yml': choice('bounded runner acquisition recovery', ['scripts/report-runner-capacity.sh', 'scripts/check-pipeline-status.sh'], 'Rerun only same-repository runs with explicit acquisition evidence, no assigned runner and no steps; paginate observations, cap retries, use trusted default-branch code and actions-write only where needed. Do not retry actual code failures or infer unavailable evidence.'),
    '.github/workflows/security.yml': choice('dependency vulnerability audit', ['.github/workflows/security.yml', 'scripts/check-rust-dependencies.sh'], 'OSV download already uses retry-all-errors and a checksum. Java supplements the source scan with resolved plugin and test dependency observations. Preserve the existing Rust audit scope and strict exception controls; Maven plugins and its Java-specific overrides cannot transfer directly.'),
    '.github/workflows/workflows.yml': choice('workflow source lint and freshness', ['.github/workflows/workflows.yml', 'scripts/check-runner-labels.mjs'], 'Pin actionlint container digest and tools, enforce explicit runner images and run JavaScript source-policy tests. Keep Formal AI runner labels and behavior regressions; source regex tests alone miss dependency propagation defects.'),
    '.mvn/jvm.config': choice('JVM process budget', ['scripts/cargo-test.sh'], 'Java JVM defaults are build-tool-specific. Formal AI uses its bounded shared Cargo target policy and hosted runners; do not start a local Maven or Rust build for this comparison.'),
    '.mvn/wrapper/maven-wrapper.properties': choice('Maven distribution pin', ['rust/rust-toolchain.toml'], 'Explicit Maven distribution and wrapper settings are language-specific. Retain the repository Rust toolchain policy and verify downloaded executables independently.'),
    '.pre-commit-config.yaml': choice('local static checks', ['.pre-commit-config.yaml', 'scripts/lint-shell-scripts.sh'], 'Pinned pre-commit hooks and matching CI checks are useful. Keep Formal AI checks and required JavaScript twins; do not introduce Maven compilation into local mixed-language validation.'),
    'pom.xml': choice('Java dependency graph and compiler/lint/test configuration', ['rust/Cargo.toml', 'Cargo.lock', '.github/workflows/security.yml'], 'Read all 1872 lines in bounded chunks and parsed all XML nodes. Compiler Xlint/Werror, Surefire 120-second process and JUnit 10-second defaults, Spotless validate and SpotBugs verify are explicit. Hundreds of Maven plugin transitive pins and Java 27/Maven floors are Java-specific. Preserve Formal AI benchmark floors, audit coverage and native-main-only policy. POM version-reader/writer parent handling differs; no unexecuted version-writing defect is presented as reproduced.'),
    'mvnw': choice('Unix Maven bootstrap', ['scripts/cargo-test.sh'], 'Reviewed complete bootstrap, distribution pin and downloads. Maven wrapper mechanics are not a substitute for Formal AI executable provenance or its Cargo resource constraints.'),
    'mvnw.cmd': choice('Windows Maven bootstrap', ['scripts/cargo-test.sh'], 'Reviewed full wrapper source. Its CRLF worktree concern is already upstream #28. Retain Formal AI platform paths and executable provenance rather than copy a Java wrapper.'),
    'scripts/audit-maven-plugins.mjs': choice('resolved Maven artifact audit', ['.github/workflows/security.yml', 'scripts/check-rust-dependencies.sh'], 'Resolve plugin/test artifact scope in addition to source scanning; fail on HTTP errors, unexpected result counts and any unsuppressed vulnerability. Keep Formal AI Cargo audit and strict scoped exception validation. No live Maven audit was run.'),
    'scripts/bump-version.mjs': choice('standalone version mutation', ['scripts/bump-version.rs'], 'Native CLI parsing rejects unknown/missing options. Preserve safe argument handling and consistent version writes. Java standalone regex handling differs from the hardened project-version reader; parent/comment cases remain source observations here.'),
    'scripts/check-ci-dependencies.mjs': choice('freshness versus integrity', ['scripts/check-dependencies-latest.rs', 'scripts/check-dependencies-action-release.rs'], 'Java intentionally warns for stale versions on every event and verifies integrity independently. Keep Formal AI strict findings/unverifiable policy. Java tests already cover stale-version/bad-pin integrity and do not reproduce the Go early-continue bypass.'),
    'scripts/check-file-size.mjs': choice('source size and warning thresholds', ['scripts/check-file-size.mjs', 'scripts/check-file-size.rs'], 'Inspect actual tracked source and explicit large-file warnings. Keep Formal AI targets and account for unresolved warnings instead of raising limits or hiding files.'),
    'scripts/collect-changelog.mjs': choice('changelog consumption', ['scripts/collect-changelog.rs'], 'Protect contributor text when printed and keep fragment consumption tied to successful release writes. Java can ignore invalid fragments while removing input files; this is a source observation without a separate executed defect claim.'),
    'scripts/create-github-release.mjs': choice('GitHub release creation', ['scripts/create-github-release.rs', 'scripts/create-release-with-recovery.mjs'], 'Use strict safe version arguments, distinguish exists/missing/unknown, require the remote tag and verify publication artifacts in the workflow. Keep Formal AI verified receipts, source freshness and default-branch writer restrictions.'),
    'scripts/create-manual-changeset.mjs': choice('manual release metadata', ['scripts/create-changelog-fragment.rs'], 'Use native argument parsing and structured output rather than direct dispatch interpolation. Keep Formal AI changelog.d format and existing version trigger.'),
    'scripts/detect-code-changes.mjs': choice('Git observation and test selection', ['scripts/detect-code-changes.mjs', 'scripts/detect-code-changes.rs'], 'Unmodified detector turns failed comparisons into successful negative outputs; already reproduced and reported as Java #30. Formal AI propagates unknown comparisons and permits a tree fallback only for established initial commits. Native execution remains main-only and unverified here.'),
    'scripts/github-actions-log.mjs': choice('untrusted diagnostic logging', ['scripts/check-sccache-write-health.sh', 'scripts/print-untrusted.cjs'], 'Fresh 128-bit stop/resume command tokens protect contributor text. Formal AI cache diagnostics now use the same boundary with bounded retained bytes/lines and URL redaction. A human prefix alone is not a runner-command boundary.'),
    'scripts/github-release-state.mjs': choice('external-state classification', ['scripts/release-recovery-decision.mjs'], 'Only the exact not-found result is missing; authentication/network/rate-limit/server/unavailable-tool results are unknown. Default diagnostics stay quiet; verbose text suspends workflow commands. Preserve independent verified/failed/unknown receipts.'),
    'scripts/merge-changesets.mjs': choice('release fragment merge', ['scripts/collect-changelog.rs'], 'Preserve bump priority, release note fidelity and safe logging. Java package frontmatter is not the Formal AI changelog format; source review is not a claim of full upstream suite execution.'),
    'scripts/rerun-unacquired.mjs': choice('runner failure classification', ['scripts/report-runner-capacity.sh', 'scripts/check-pipeline-status.sh'], 'No runner plus no steps plus the exact acquisition annotation is required; unknown annotations remain unclassified. Paginate jobs/annotations and allow only two automatic retries. Do not classify cache/backend failures by counters alone.'),
    'scripts/validate-changeset.mjs': choice('release metadata policy', ['scripts/check-changelog-fragment.mjs', 'scripts/check-changelog-fragment.rs'], 'The repaired Java fallback validates all changesets when the base diff is unavailable. Its absent-changeset warning is an explicit weaker policy. Keep Formal AI required fragments and distinguish unavailable observations from empty diffs.'),
    'scripts/version-and-commit.mjs': choice('release commit/tag ordering', ['scripts/version-and-commit.rs', 'scripts/version-and-commit-tests.rs'], 'New real-Git regression proves failed commit still yields released=true and pushes an old-source tag in both modes. Candidate removal of the commit-error fallback blocks tags/pushes, with positive controls. Formal AI already exits on failed commit and tags after a successful source push; retain those stronger checks. Java report pending immutable evidence publication; no upstream repair is claimed.'),
    'scripts/ci-security.test.mjs': choice('security and input regression coverage', ['rust/tests/web/release-recovery-decision.test.mjs'], 'Reviewed option-injection, freshness and protected logging cases. Keep executable negative controls and safe argument boundaries; do not treat source regex coverage as hosted execution.'),
    'scripts/workflow-policy.test.mjs': choice('workflow structure regressions', ['rust/tests/web/issue-1580-template-observations.test.mjs', 'scripts/check-runner-labels.mjs'], 'Tests pin runner/tool/download/input/publication policy, but text assertions do not execute the dependency graph. Keep Formal AI behavior controls and main-only native scope.'),
    'experiments/ci-dependencies.test.mjs': choice('dependency checker regressions', ['scripts/check-dependencies-action-release-tests.rs', 'rust/tests/web/issue-1580-template-observations.test.mjs'], 'Read current/stale integrity controls and registry failure mocks. Existing Java stale-plus-invalid checks prevent the Go policy bypass. No complete upstream test execution is claimed.'),
    'experiments/cli-runtime.test.mjs': choice('CLI compatibility regressions', ['rust/tests/web/issue-1580-template-observations.test.mjs'], 'Native parser tests reject missing values and misspelled flags and exercise normal version writes. Preserve bounded subprocesses and real behavior instead of accepting source shape alone.'),
    'experiments/file-size.test.mjs': choice('warning behavior regressions', ['rust/tests/web/issue-1580-template-observations.test.mjs'], 'Retain explicit warning/failure distinctions and source boundaries. Existing Formal AI size warning inventory remains unfinished; do not lower thresholds to manufacture success.'),
    'experiments/maven-plugin-audit.test.mjs': choice('audit-scope regressions', ['.github/workflows/security.yml'], 'Mock complete registry results and unexpected/missing/error observations; build/test plugin artifacts require scope beyond default source extraction. Maven-specific resolution is not executed or copied into Cargo.'),
    'experiments/osv-download.test.mjs': choice('download retry regression', ['rust/tests/web/container-apt-retry.test.mjs'], 'Reviewed interrupted-transfer retry and checksum expectations. Java already has retry-all-errors and is excluded from the C++ truncated-transfer report.'),
    'experiments/release-recovery.test.mjs': choice('recovery and positive release controls', ['rust/tests/web/release-recovery-decision.test.mjs', 'scripts/version-and-commit-tests.rs'], 'Tests missing/exists/unknown, original-tag worktree cleanup and successful local release pushes. They do not cover rejecting a release commit; the new five-case regression adds that negative control using local bare remotes.'),
    'experiments/rerun-unacquired.test.mjs': choice('bounded acquisition recovery regressions', ['scripts/report-runner-capacity.sh'], 'Read strict runner/steps/annotation checks and retry cap controls. Keep code failures distinct from capacity failures, including unavailable observation handling.'),
}

for item in inventory:
    name = item['path']
    data = (source / name).read_bytes()
    assert hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest() == item['gitBlob'], name
    if name.startswith(('dev/', 'docs/case-studies/')):
        excluded.append(name)
        continue
    if name in specific:
        role, paths, decision = specific[name]
    elif name.startswith('.changeset/') or name == 'CHANGELOG.md':
        role, paths, decision = choice('release metadata and history', ['changelog.d', 'CONTRIBUTING.md'], 'Preserve Formal AI changelog.d and release trigger. Historical descriptions supply context and are not independent evidence that current tests or workflows pass.')
    elif name.startswith(('src/', 'examples/')):
        role, paths, decision = choice('Java sample application and tests', ['rust/src', 'rust/tests'], 'Reviewed simple arithmetic, asynchronous delay, version and entrypoint examples with small JUnit cases. These are Java teaching examples, not additional Formal AI algorithms or evidence that its benchmark capability floors pass.')
    elif name.startswith('experiments/fixtures/'):
        role, paths, decision = choice('bounded fake external tools', ['experiments/issue-1580/fixtures'], 'Small fake gh/Maven executables isolate external-state and worktree controls. Keep these explicitly injected boundaries separate from live publication or runtime capability evidence.')
    elif name.startswith('experiments/'):
        role, paths, decision = choice('historical migration/audit experiments', ['experiments/issue-1580/dependency-audit-triage.mjs'], 'Reviewed Maven registry/transitive inventory, one-off dependency migration and audit gap reproduction. Do not replay a historical generator or copy Maven overrides into Formal AI. Registry metadata and upstream ABI blockers are evidence, not local repairs.')
    elif name in ['README.md', 'CONTRIBUTING.md']:
        role, paths, decision = choice('contributor and usage documentation', ['README.md', 'CONTRIBUTING.md'], 'Keep Formal AI execution, evidence and build policies. Java README freshness/PR-only audit language lags current implementation; compare actual scripts rather than copying obsolete policy text.')
    elif name == 'LICENSE':
        role, paths, decision = choice('license provenance', ['LICENSE'], 'Retain original license beside copied upstream fixtures and pin every copied source identity.')
    elif name == '.gitignore':
        role, paths, decision = choice('workspace exclusions', ['.gitignore'], 'Keep scratch/build outputs excluded while preserving reproducible scripts and intentionally committed evidence. Do not hide unfinished work or commit agent scratch state.')
    elif name == '.gitkeep':
        role, paths, decision = choice('empty directory marker', ['.gitignore'], 'Empty tracked marker has no executable behavior and requires no transfer.')
    else:
        raise AssertionError('unclassified active source: ' + name)
    replacements = {
        'rust/rust-toolchain.toml': 'data/seed/toolchains.lino',
        'Cargo.lock': 'rust/Cargo.lock',
        'scripts/detect-code-changes.mjs': 'experiments/formal_ai_subagent/local-gates.mjs',
        'scripts/print-untrusted.cjs': 'scripts/check-sccache-write-health.sh',
        'experiments/issue-1580/dependency-audit-triage.mjs': 'experiments/issue-1580',
    }
    paths = list(dict.fromkeys(replacements.get(path, path) for path in paths))
    for path in paths:
        assert (root / path).exists(), (name, path)
    files.append({
        'path': name, 'gitBlob': item['gitBlob'], 'bytes': len(data),
        'sha256': hashlib.sha256(data).hexdigest(), 'completeSourceRead': True,
        'role': role, 'formalAiComparison': paths, 'decision': decision,
    })

result = {
    'repository': 'link-foundation/java-ai-driven-development-pipeline-template',
    'commit': 'dd803a2d9fa5b3a992b435acce73162274fb9e8b',
    'scope': 'Complete source review of 62 active CI/application/configuration/documentation files, including all four workflows and the full 1872-line POM. All 207 pinned blobs are hash verified. The 145 dev/log historical evidence files below are inventoried and excluded from this active source review; their full semantic contents remain unreviewed.',
    'completeRepositorySemanticReview': False,
    'limits': [
        'Seven complete repository semantic reviews remain open, including Java historical evidence; the complete Go source review is separate.',
        'Source observations without an executable reproduction are labeled as such and are not reported as reproduced defects.',
        'No full upstream suite, Maven build, hosted dispatch or live publication was executed.',
        'The five new release regression cases execute real Git with disposable local bare remotes and a rejecting local pre-commit hook. A one-line candidate repair exists only in disposable copies.',
        'Externally supplied scripts/review decisions earn zero independent Formal AI reasoning or authorship credit.',
    ],
    'verification': {'newReleaseRegression': '5 pass, 0 fail, 0 skip', 'maintainedEntryPoint': '16 pass, 0 fail, 0 skip'},
    'files': files,
    'excludedHistoricalEvidence': {
        'policy': 'These 145 dev/log files are historical reports, command logs, registry responses, API receipts and previous source snapshots, not active CI source. Git blob identities remain in java-files.tsv. No full-content semantic read or current-runtime verification is claimed.',
        'files': excluded,
    },
}
assert len(files) == 62 and len(excluded) == 145
target = root / 'docs/case-studies/issue-1580/templates/java-active-semantic-review.json'
target.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'activeReviewed': len(files), 'historicalInventoriedOnly': len(excluded), 'lines': len(target.read_text().splitlines())}))
