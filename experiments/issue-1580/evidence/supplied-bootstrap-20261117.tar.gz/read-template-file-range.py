from pathlib import Path
import sys
language,name=sys.argv[1:3]
start=int(sys.argv[3])
end=int(sys.argv[4])
assert 1<=start<=end and end-start<1500
path=Path('/tmp/issue-1580-research/templates')/(language+'-complete')/name
lines=path.read_text().splitlines()
print(f'{language} {name} ({len(lines)} lines)')
for n in range(start,min(end,len(lines))+1):print(f'{n}: {lines[n-1]}')
