from pathlib import Path
import difflib,gzip,hashlib,json,re,subprocess
base=Path('experiments/issue-1580/evidence/ci/main-015a6831')
index=json.loads(gzip.decompress((base/'native-panic-payload-index.json.gz').read_bytes()))
records=[]
decoded={}
def parse(text):
 match=re.fullmatch(r'\s*(left|right): (?:Some\()?((?:"(?:[^"\\]|\\.)*"))(?:\))?[,]?\s*',text)
 assert match,text[:200]
 # Rust debug escapes combining Unicode characters as \u{...}; retain the
 # actual code points before parsing the otherwise JSON-compatible string.
 literal=re.sub(r'\\u\{([0-9a-fA-F]+)\}',lambda m:chr(int(m[1],16)),match[2])
 return match[1],json.loads(literal)
for row in index['panics']:
 if row['number'] not in (16,39):continue
 sides={}
 job=134419506413 if row['number']==16 else 134419506816
 source=base/'individual-native-catalog-jobs'/f'job-{job}.log.gz'
 source_lines={}
 for number,line in enumerate(gzip.decompress(source.read_bytes()).decode().splitlines(),1):
  text=re.sub(r'^\d{4}-\d{2}-\d{2}T\S+Z ', '',line)
  if re.match(r'\s*(left|right): (?:Some\()?"google_trends_catalog',text):
   side,value=parse(text);sides[side]=value;source_lines[side]=number
   decoded[(row['number'],side)]=value
 assert set(sides)=={'left','right'}
 record={'panic':row['number'],'job':job,'sourceLines':source_lines,'sides':{side:{'bytes':len(value.encode()),'lines':len(value.splitlines()),'sha256':hashlib.sha256(value.encode()).hexdigest()} for side,value in sides.items()}}
 diff=''.join(difflib.unified_diff(sides['left'].splitlines(True),sides['right'].splitlines(True),fromfile='captured',tofile='fresh',n=3))
 target=base/f'panic-{row["number"]}-catalog-difference.diff.gz';target.write_bytes(gzip.compress(diff.encode(),mtime=0))
 record['diff']={'path':str(target),'lines':len(diff.splitlines()),'sha256':hashlib.sha256(diff.encode()).hexdigest()};records.append(record)
 print(json.dumps(record,ensure_ascii=False))
 for i,line in enumerate(diff.splitlines(),1):
  if i<=65:print(f'DIFF {i}: {line[:600]}')
 print(json.dumps({'diffPreviewOnly':True,'fullDiffLines':len(diff.splitlines())}))
assert decoded[(16,'left')]==decoded[(39,'left')]
current=Path('data/meta/google-trends-catalog.lino').read_text()
summary={'sameCapturedArtifact':True,'sameFreshArtifacts':decoded[(16,'right')]==decoded[(39,'right')],'currentCommittedArtifact':{'sha256':hashlib.sha256(current.encode()).hexdigest(),'matchesOldCaptured':current==decoded[(16,'left')],'matchesOldFresh':current==decoded[(16,'right')]}}
print(json.dumps(summary))
(base/'catalog-payload-comparison.json').write_text(json.dumps({'records':records,**summary,'reviewMethod':'Complete direct-job Rust debug strings decoded and byte-compared, including both right values missing from gh run view --log. Only the initial 65 diff lines were previewed, capped at 600 characters per line. Full semantic review and native replay remain unfinished.'},indent=2)+'\n')
