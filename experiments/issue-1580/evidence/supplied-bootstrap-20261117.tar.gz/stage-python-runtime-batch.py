from pathlib import Path
import subprocess
def run(args):return subprocess.run(args,capture_output=True,text=True,check=True).stdout
assert run(['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
paths=['.github/workflows/layered-ci.yml','docs/case-studies/issue-1580','experiments/issue-1580','rust/tests/web/fast-pull-request-production-profile.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs']
run(['git','add','--',*paths]);run(['git','diff','--cached','--check'])
print(run(['git','diff','--cached','--stat']))
print('Archiver source:')
for i,line in enumerate(Path('/tmp/issue-1580-research/archive-evidence.py').read_text().splitlines()[:100],1):print(f'{i}: {line}')
