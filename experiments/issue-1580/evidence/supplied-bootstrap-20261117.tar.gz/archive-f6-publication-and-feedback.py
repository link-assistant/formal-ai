from pathlib import Path
from datetime import datetime,timezone
import gzip,json,hashlib,subprocess

base=Path('experiments/issue-1580/evidence/checks/unknown-native-replay')
dest=base/'prior-publication';dest.mkdir(exist_ok=False)
manifest=[]
for p in sorted(Path('/tmp/issue-1580-research/complete-cache-publication').iterdir()):
    if not p.is_file():continue
    raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);name=p.name+'.gz'
    (dest/name).write_bytes(packed)
    manifest.append({'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())})
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PUBLICATION RECEIPTS',len(manifest))
feedback=base/'feedback';feedback.mkdir(exist_ok=False)
commands=[
    ('issue',['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','title,body,updatedAt']),
    ('issue-comments',['gh','api','repos/link-assistant/formal-ai/issues/1580/comments','--paginate']),
    ('pr-comments',['gh','api','repos/link-assistant/formal-ai/issues/1581/comments','--paginate']),
    ('inline-comments',['gh','api','repos/link-assistant/formal-ai/pulls/1581/comments','--paginate']),
    ('reviews',['gh','api','repos/link-assistant/formal-ai/pulls/1581/reviews','--paginate']),
    ('sub-issues',['gh','api','repos/link-assistant/formal-ai/issues/1580/sub_issues','--paginate']),
    ('pull-request',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','title,body,isDraft,headRefOid,mergeStateStatus']),
]
observations=[]
for name,args in commands:
    p=subprocess.run(args,capture_output=True);assert p.returncode==0,(name,p.stderr)
    raw=p.stdout;obj=json.loads(raw);(feedback/(name+'.json')).write_bytes(raw)
    observations.append({'name':name,'argv':args,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'count':len(obj) if isinstance(obj,list) else None})
    if isinstance(obj,list):
        print('FEEDBACK',name,'COUNT',len(obj))
        for item in obj:
            print(json.dumps({'id':item['id'],'updatedAt':item.get('updated_at',item.get('submitted_at')),'url':item.get('html_url')}))
    else:print('STATE',name,json.dumps({k:v for k,v in obj.items() if k!='body'}))
(feedback/'manifest.json').write_text(json.dumps({'observedAt':datetime.now(timezone.utc).isoformat(),'records':observations},indent=2)+'\n')
print('PREVIOUS FEEDBACK FILES',[p.name for p in Path('experiments/issue-1580/evidence/checks/complete-cache-main-validation/feedback').iterdir()])
for file,start in [('experiments/issue-1580/work-plan.md',630),('docs/case-studies/issue-1580/language-source-binding-checkpoint.md',76),('docs/case-studies/issue-1580/README.md',220)]:
    print('DOCUMENT',file)
    for n,line in enumerate(Path(file).read_text().splitlines(),1):
        if n>=start:print(f'{n}: {line}')
