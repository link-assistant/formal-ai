from pathlib import Path
import subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
for name in ['js/worker/formal_ai_worker_candidate_validation.js','rust/tests/web/worker-candidate-validation.test.mjs']:
    print('\nFILE',name)
    print((root/name).read_text())
for name,lo,hi in [('rust/src/solver.rs',565,650),('rust/src/solver_handlers/mod.rs',730,780)]:
    lines=(root/name).read_text().splitlines()
    print('\nFILE',name)
    for n in range(lo-1,min(hi,len(lines))):print(f'{n+1}: {lines[n]}')
for args in [['rg','-n','validate.*Candidate|candidateValidation|numberPropertyCandidates|validateNumber|numberPropertyInterval','js/worker'],['rg','-n','run_meta_procedure','rust/src']]:
    result=subprocess.run(args,cwd=root,text=True,capture_output=True)
    print('\nREFERENCES',result.stdout,result.stderr)
