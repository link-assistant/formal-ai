set -eu
mkdir -p /tmp/issue-1580-research/java-release-checks
set +e
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-java-release-integrity.test.mjs > /tmp/issue-1580-research/java-release-checks/focused.log 2>&1
result=$?
set -e
cat /tmp/issue-1580-research/java-release-checks/focused.log
exit "$result"
