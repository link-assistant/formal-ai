from pathlib import Path
import gzip,hashlib,json,os,resource,subprocess,time

root=Path('experiments/issue-1580/evidence/checks/calendar-clock-preservation')
env=dict(os.environ);env['NODE_OPTIONS']='--max-old-space-size=256'
steps=[
 ('canonical-data-mirrors',['node','scripts/mirror-package-data.mjs','--write']),
 ('rust-format',['rustfmt','--check','--edition','2024','rust/src/solver_handlers/calendar_create.rs','rust/tests/unit/solver/issue_869_meeting_scheduling.rs']),
 ('projection-currency',['node','scripts/translate-js-rust.mjs','--verify']),
 ('clock-tests',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/calendar-clock-preservation.test.mjs']),
 ('intent-span-tests',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/issue-1588-intent-spans.test.mjs']),
 ('ledger-tests',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/main-only-regression-ledger.test.mjs']),
 ('fast-profile-tests',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs']),
 ('complete-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs']),
]
results=[]
for label,command in steps:
 started=time.monotonic()
 print('START',label,flush=True)
 process=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 raw=process.stdout
 (root/(label+'.log.gz')).write_bytes(gzip.compress(raw,mtime=0))
 result={'name':label,'command':command,'status':process.returncode,'durationSeconds':round(time.monotonic()-started,3),'rawSha256':hashlib.sha256(raw).hexdigest(),'nodeHeapMiB':256,'peakChildRssKiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss}
 results.append(result)
 (root/'validation-progress.json').write_text(json.dumps(results,indent=2)+'\n')
 print('DONE',json.dumps(result),flush=True)
status={'results':results,'allPassed':all(row['status']==0 for row in results),'rustBuildsEnabled':False,'nativeExecuted':False,'autonomousAuthorshipCredit':0}
(root/'validation-completion.json').write_text(json.dumps(status,indent=2)+'\n')
print('COMPLETE',status['allPassed'],flush=True)
