import json,subprocess,shutil
from pathlib import Path
review=json.loads(Path('/tmp/issue-1580-research/governed-baseline-review.json').read_text())
assert review['beforeCases']==review['afterCases']==221
assert len(review['changes'])==20
for item in review['changes']:
    path=item['path']
    assert path[-1]=='sha256'
    assert path[:2]==['inventory','cases'] or path==['sourceManifest','27','sha256']
subprocess.run(['git','diff','--exit-code','origin/main','--','scripts/lib/rust-specification-cases.mjs'],check=True)
subprocess.run(['node','rust/tests/web/rust-specification-unicode-identifiers.test.mjs',
 '--refresh-reviewed-baseline','--reviewed-reader-sha='+review['readerSha256'],
 '--previous-baseline-sha='+review['beforeSha256']],check=True)
shutil.copyfile('/tmp/issue-1580-research/governed-baseline-review.json',
 'experiments/issue-1580/evidence/checks/governed-baseline-review.json')
print('Reviewed 20 source-hash changes; all 221 complete specification cases and their assertions are unchanged.')
