set -eu
node experiments/formal_ai_subagent/local-gates.mjs --only check-file-size,check-file-size-js-twin,check-changelog-fragment-js-twin,check-ci-speed > /tmp/issue-1580-research/go-review-gates.log 2>&1
tail -n 18 /tmp/issue-1580-research/go-review-gates.log
