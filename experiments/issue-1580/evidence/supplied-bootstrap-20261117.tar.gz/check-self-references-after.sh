set -eu
export NODE_PATH=/tmp/issue-1580-research/node_modules
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-reference-graph.test.mjs > /tmp/issue-1580-research/self-reference-checks/after.log 2>&1
cat /tmp/issue-1580-research/self-reference-checks/after.log
timeout 600 node --test --test-concurrency=1 rust/tests/web/issue-1580-template-observations.test.mjs > /tmp/issue-1580-research/self-reference-checks/maintained.log 2>&1
tail -n 28 /tmp/issue-1580-research/self-reference-checks/maintained.log
