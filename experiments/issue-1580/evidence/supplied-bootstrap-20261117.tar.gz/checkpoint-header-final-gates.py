from pathlib import Path
import collections,datetime,gzip,hashlib,json,shutil,subprocess

directory=Path('experiments/issue-1580/evidence/checks/generated-header-memory')
result=json.loads((directory/'final-gates/all-local-gates.json').read_text())
assert result['status']==0,result
raw=gzip.decompress((directory/'final-gates/all-local-gates.log.gz').read_bytes())
assert hashlib.sha256(raw).hexdigest()==result['rawSha256']
lines=raw.decode().splitlines()
counts={key:sum(line.startswith(key+' ') for line in lines) for key in ['PASS','SKIP','FAIL']}
assert counts=={'PASS':86,'SKIP':52,'FAIL':0},counts
print('FINAL GATE LOG\n'+'\n'.join(f'{i}: {line}' for i,line in enumerate(lines,1)))
path=Path('docs/case-studies/issue-1580/templates/python-partial-semantic-review.json')
review=json.loads(path.read_text());assert review['activeReadLines']==13240
inventory=json.loads(Path('/tmp/issue-1580-research/python-active-source-inventory.json').read_text())
active={row['path']:row for row in inventory['active']}
deferred={'.github/actions/artifact/dist/835.index.mjs','.github/actions/artifact/dist/index.mjs','.github/actions/artifact/package-lock.json','uv.lock'}
selected=[(row['path'],n) for row in inventory['active'] if row['path'] not in deferred for n in range(1,row['lines']+1)]
ranges=collections.defaultdict(set)
for row in review['files']:
 for first,last in row['readRanges']:ranges[row['path']].update(range(first,last+1))
for name,n in selected[:16000]:ranges[name].add(n)
decisions={
 'tests/artifact.test.mjs':'Read all 206 lines: offline artifact retry fixtures distinguish transport errors, permanent refusals, existing-artifact protection, bounded exhaustion, glob roots/exclusions, Pages tar contents, download digest failure and deterministic ZIP bytes. The archive dependency case can skip when dependencies are absent. These tests were read, not executed here; the generated action bundles and lockfile remain unread.',
 'tests/deploy-pages.test.mjs':'Read all 315 lines: mocked API coverage includes exact artifact deployment, transient create retries, adoption after a lost response, permanent refusals, poll backoff, cancellation, OIDC, authenticated JSON requests and page_url output. No deployment, network request or upstream test execution is claimed.',
 'tests/test_audit_dependencies.py':'Read all 123 lines: command failure output, captured output, pip-less audit target, missing dependency surfaces/lock and committed-lock constraints are asserted with subprocess fixtures or mocks. This file does not cover the separately reproduced JavaScript lockfile inventory failure reported as upstream #158. No pip install or upstream suite execution is claimed.',
 'tests/test_check_codeql_results.py':'Read all 249 lines: real-CLI SARIF fixtures reject findings at all levels, malformed/unsuccessful reports and malformed notifications; permit valid informational diagnostics; escape injected workflow commands. This source review does not execute CodeQL or the upstream pytest file.',
 'tests/test_check_dependency_graph.py':'Read all 114 lines: scripted CLI responses distinguish disabled dependency graph from retryable/rate-limit/network failures, with PR-only advisory behavior and fatal default-branch unknowns. No account-setting change or live dependency-review request is claimed.',
 'tests/test_check_dist_size.py':'Read all 103 lines: tiny wheel/tar fixtures assert per-file limits, largest-member diagnostics, CLI budgets, local publish refusal and ordering before both workflow uploads. Archive construction, PyPI upload and upstream test execution were not performed here.',
 'tests/test_check_file_size.py':'Read all 208 lines: warning/error bands, separate Markdown limits, annotations, shell/JavaScript coverage and generated-tree pruning are asserted. Most fixture helpers omit a final newline; the remaining final-newline line-count boundary question is not reproduced or claimed as a defect here.',
 'tests/test_check_pipeline_status.py':'Read all 273 lines: fixture workflows distinguish literal/dynamic/inherited cancellation, require exact fork PR heads for superseding and retain non-cancelling timeout failures. No fresh hosted cancellation or upstream pytest execution is claimed.',
 'tests/test_check_release.py':'Read all 315 lines: mocked and loopback HTTP fixtures cover independent PyPI/GitHub existence, draft handling, bounded propagation time, permanent errors, redirect refusal, token separation and output publication. No release or registry mutation and no execution of this upstream file is claimed.',
 'tests/test_check_required_docs.py':'Read all 55 lines: real-script assertions cover the current repository, shared requirement listing, missing section/file annotations and usage errors. No new documentation-contract failure is reproduced and the upstream test file is not executed here.',
 'tests/test_check_web_archive.py':'Read all 149 lines: fixtures cover broken-URL extraction, HTTPS snapshot normalization, recovered-URL removal, outage refusal and failed-checker missing/malformed evidence. No live archive acceptance or upstream suite execution is claimed.',
 'tests/test_create_github_release.py':'Read all 370 lines: release creation preserves a published release, repairs drafts, handles layout-aware naming, fenced changelog headings, exact release notes, size caps, badge idempotence and workflow-command guards. Existing fenced-heading history is distinct from the separate standalone formatter escape-corruption reproduction. No hosted release or upstream suite execution is claimed.',
 'tests/test_dependabot_health.py':'Read all 185 lines: mocks cover independent age/rebase thresholds, malformed/all-page API data, visible failures, summaries, repository validation, opt-in diagnostics and scheduled read-only workflow policy. No Dependabot PR or account-setting mutation is claimed.',
 'tests/test_dependabot_updates.py':'Read all 65 lines: disposable workflow text accepts versioned Dependabot action updates while floating/invalid pins remain rejected. These are lexical/behavioral assertion fixtures, not proof that arbitrary future action versions are operationally compatible. No upstream suite execution is claimed.',
 'tests/test_detect_code_changes.py':'Read only lines 1-71: parametrized source/docs/excluded-path classification and beginning of exclusion precedence. The rest is unread; previously reproduced Git-observation failures have their separate evidence and no additional runtime claim is made here.',
}
root=Path('/tmp/issue-1580-research/templates/python-complete')
for row in review['files']:
 assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256']
 if row['path'] not in active:continue
 numbers=sorted(ranges[row['path']]);merged=[]
 for n in numbers:
  if merged and merged[-1][1]+1==n:merged[-1][1]=n
  else:merged.append([n,n])
 row['readRanges']=merged
 row['reviewStatus']='active-source-fully-read' if len(numbers)==row['lines'] else 'active-source-partially-read' if numbers else 'active-source-unread'
 if row['path'] in decisions:row['decision']=decisions[row['path']]
status=collections.Counter(row['reviewStatus'] for row in review['files'])
review['counts']={key:status[key] for key in review['counts']}
review['activeReadLines']=sum(len(ranges[name]) for name in active);assert review['activeReadLines']==16040
assert status['active-source-fully-read']==172 and status['active-source-partially-read']==1 and status['active-source-unread']==30,status
review['readMethod']=review['readMethod'].replace('pages 1-33','pages 1-40')
header={k:v for k,v in review.items() if k!='files'}
path.write_text(json.dumps(header,indent=2)[:-2]+',\n  "files": [\n'+',\n'.join('    '+json.dumps(row,ensure_ascii=False,separators=(',',':')) for row in review['files'])+'\n  ]\n}\n')
old='The Python review now fully reads 158 active files plus one partial file (13,240/44,284 active lines), through corrected pages 1-33 and separately read release/helper tests. The 44 unread active files'
new='The Python review now fully reads 172 active files plus one partial file (16,040/44,284 active lines), through corrected pages 1-40 and separately read release/helper tests. The 30 unread active files'
for name in ['docs/case-studies/issue-1580/README.md','docs/case-studies/issue-1580/templates/README.md','experiments/issue-1580/work-plan.md']:
 p=Path(name);text=p.read_text();assert text.count(old)==1;p.write_text(text.replace(old,new))
note='\nThe final complete local gate invocation on 12aff82c189eab0d2f920b0f233f2d1a868d2815 passes all 86 applicable gates with 52 explicit native/context exclusions, zero failures, a 256 MiB Node heap cap, and no Rust build or offline audit substitute. Complete logs and per-gate captures are retained in final-gates/. The earlier generated-file heap failure remains preserved. This is local gate verification, not main-only native or final-head hosted acceptance.\n'
with (directory/'memory-README.md').open('a') as stream:stream.write(note)
with Path('experiments/issue-1580/work-plan.md').open('a') as stream:stream.write('\nFinal merged-source local gate verification: 86 passed, 52 explicit exclusions, zero failures. Source fixes and focused regressions are complete for this batch; broad native, benchmark, full-template, dependency-migration and live-delivery requirements remain open. Fresh feedback is unchanged; origin/main 512ce428 is merged. Publish once after final preflight, inspect all exact-head hosted checks, then file the immutable Python formatter reproduction after another source/duplicate check.\n')
report=Path('experiments/issue-1580/upstream/python-release-formatting-report.md')
body=report.read_text();assert hashlib.sha256(body.encode()).hexdigest()=='a25993f0038fbfecd5df1f9c58b2021e8852c48ccbdd93730fb7edb56552b269'
commit='da712fadd3f680668c063a6d7de073ef1d52573b8'
commit=subprocess.check_output(['git','rev-parse','da712fadd'],text=True).strip()
base='https://github.com/link-assistant/formal-ai/blob/'+commit+'/'
addition='\nImmutable downstream reproduction: [complete four-case test]('+base+'experiments/issue-1580/template-python-release-formatting.test.mjs), [unchanged source and helper identities]('+base+'experiments/issue-1580/fixtures/python-template/exact-source.json), and [full before/after logs and maintained-entrypoint evidence](https://github.com/link-assistant/formal-ai/tree/'+commit+'/experiments/issue-1580/evidence/checks/python-release-formatting). These links identify the published evidence commit rather than a moving branch.\n'
report.write_text(body+addition)
preflight=Path('/tmp/issue-1580-research/header-round-preflight')
target=directory/'preflight';target.mkdir(exist_ok=True)
for source in preflight.iterdir():
 if source.is_file():shutil.copyfile(source,target/source.name)
print(json.dumps({'gates':counts,'durationSeconds':result['durationSeconds'],'peakRssKiB':result['childrenPeakRssKiB'],'python':review['counts'],'activeReadLines':review['activeReadLines'],'formatterReportSha256':hashlib.sha256(report.read_bytes()).hexdigest()},indent=2))
subprocess.run(['git','diff','--check'],check=True)
