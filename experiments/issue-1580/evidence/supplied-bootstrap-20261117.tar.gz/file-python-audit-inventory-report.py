from pathlib import Path
import base64,datetime,gzip,hashlib,json,os,subprocess,tempfile
repository='link-foundation/python-ai-driven-development-pipeline-template'
title='npm audit succeeds after Git fails to enumerate lockfiles'
body_path=Path('experiments/issue-1580/upstream/python-audit-inventory-report.md');body=body_path.read_text()
assert hashlib.sha256(body.encode()).hexdigest()=='d751611cdced5b0c3a0dc6a9d8b1d3b1d1e2e15dc5fc205a02f77705d1a0e622'
evidence=Path('experiments/issue-1580/evidence/checks/audit-inventory-boundary')
def run(*args):return subprocess.run(args,capture_output=True,text=True,check=True).stdout
env=dict(os.environ)
for name in ['GIT_DIR','GIT_COMMON_DIR','GIT_INDEX_FILE','GIT_WORK_TREE']:env.pop(name,None)
script=Path('experiments/issue-1580/fixtures/python-template/scripts/audit-npm-locks.sh').resolve();probes=[]
with tempfile.TemporaryDirectory(prefix='issue-1580-template-audit-real-git-') as directory:
 for args in [[],['--list']]:
  result=subprocess.run(['bash',str(script),*args],cwd=directory,env=env,capture_output=True,text=True,timeout=5)
  assert result.returncode==0 and 'fatal: not a git repository' in result.stderr
  if not args:assert 'No package-lock.json is tracked; nothing to audit.' in result.stdout
  probes.append({'command':['bash',str(script),*args],'status':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
(evidence/'real-git-reproduction.json').write_text(json.dumps(probes,indent=2)+'\n')
published='1cc2d536ac11e26602cc55a40dffb61716233aa6'
for path in [body_path,Path('experiments/issue-1580/template-python-audit-integrity.test.mjs'),Path('experiments/issue-1580/fixtures/python-template/source.json')]:
 remote=json.loads(run('gh','api',f'repos/link-assistant/formal-ai/contents/{path}?ref={published}'))
 assert base64.b64decode(remote['content'])==path.read_bytes()
pages=json.loads(run('gh','api',f'repos/{repository}/issues?state=all&per_page=100','--paginate','--slurp'));issues=[r for page in pages for r in page]
assert len(issues)==157 and not any(row['title']==title for row in issues)
(evidence/'final-duplicate-issues.json.gz').write_bytes(gzip.compress(json.dumps(issues,indent=2).encode(),mtime=0))
remote=json.loads(run('gh','api',f'repos/{repository}/contents/scripts/audit-npm-locks.sh?ref=main'))
assert base64.b64decode(remote['content'])==script.read_bytes()
url=run('gh','issue','create','--repo',repository,'--title',title,'--body-file',str(body_path)).strip()
Path('/tmp/issue-1580-research/python-audit-filed-url.txt').write_text(url+'\n')
posted=json.loads(run('gh','issue','view',url,'--json','body,title,url,number,createdAt'));assert posted['body']==body and posted['title']==title and posted['url']==url
(evidence/'filed-report.json').write_text(json.dumps({**posted,'bodySha256':hashlib.sha256(body.encode()).hexdigest(),'evidenceCommit':published,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'upstreamRepairClaimed':False},indent=2)+'\n')
p=Path('experiments/issue-1580/upstream/template-report-identities.json');identities=json.loads(p.read_text());assert len(identities)==9 and not any(row['url']==url for row in identities)
identities.append({'repository':repository,'title':title,'url':url,'bodyFile':body_path.name,'evidenceCommit':published});p.write_text(json.dumps(identities,indent=2)+'\n')
p=Path('experiments/issue-1580/upstream/filed-issues.txt');text=p.read_text();assert url not in text;p.write_text(text+url+'\n')
print(json.dumps({'filedReport':url,'bodySha256':hashlib.sha256(body.encode()).hexdigest(),'evidenceCommit':published,'verifiedRealGitReproductions':len(probes),'upstreamRepairClaimed':False},indent=2))
