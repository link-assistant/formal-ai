from pathlib import Path
import gzip,re
path=Path('/tmp/issue-1580-research/current-head-ci/44064713318.log.gz')
lines=gzip.decompress(path.read_bytes()).decode().splitlines()
for number,line in enumerate(lines,1):
    if 625<=number<=755: print(str(number)+': '+re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',line))
