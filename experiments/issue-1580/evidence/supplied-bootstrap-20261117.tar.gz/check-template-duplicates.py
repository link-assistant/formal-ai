import json,subprocess,re
from pathlib import Path
root=Path('/tmp/issue-1580-research')
for language in ['java','python','php']:
    repo='link-foundation/'+language+'-ai-driven-development-pipeline-template'
    result=subprocess.run(['gh','api',f'repos/{repo}/issues?state=all&per_page=100','--paginate','--slurp'],capture_output=True,text=True,check=True)
    (root/(language+'-upstream-issues.json')).write_text(result.stdout)
    issues=[item for page in json.loads(result.stdout) for item in page]
    candidates=[item for item in issues if re.search(r'git|detect|skip|manual|dispatch|pipeline|CI/CD',item['title']+' '+(item.get('body') or ''),re.I)]
    print(json.dumps({'language':language,'total':len(issues),'candidates':[{'number':x['number'],'title':x['title'],'state':x['state'],'pull':bool(x.get('pull_request'))} for x in candidates]},ensure_ascii=False))
