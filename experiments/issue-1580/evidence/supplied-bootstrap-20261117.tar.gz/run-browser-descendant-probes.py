import gzip
import hashlib
import json
import os
import pathlib
import resource
import subprocess
import time

directory=pathlib.Path("experiments/issue-1580/evidence/checks/generated-header-memory")
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
for label,extra in [("descendant-original",[]),("descendant-reaped",["--reap-child"])]:
    assert not (directory/(label+".json")).exists()
    command=["node","--max-old-space-size=64","experiments/issue-1580/browser-deadline-descendant.mjs",*extra]
    started=time.time()
    result=subprocess.run(command,capture_output=True,env=dict(os.environ,NODE_OPTIONS="--max-old-space-size=64"))
    raw=result.stdout+result.stderr
    (directory/(label+".log.gz")).write_bytes(gzip.compress(raw,mtime=0))
    record={"command":command,"status":result.returncode,"durationSeconds":round(time.time()-started,3),"rawSha256":hashlib.sha256(raw).hexdigest(),"log":label+".log.gz","independentAuthorshipCredit":0}
    (directory/(label+".json")).write_text(json.dumps(record,indent=2)+"\n")
    print(json.dumps(record),flush=True)
    print(raw.decode(errors="replace"),flush=True)
    assert result.returncode==0
