#!/bin/sh
set -eu
python3 /tmp/issue-1580-research/cache-before-after.py
python3 experiments/issue-1580/archive-evidence.py
git diff --check
node experiments/formal_ai_subagent/local-gates.mjs --only check-file-size > /tmp/issue-1580-research/final-file-size.log 2>&1
node experiments/formal_ai_subagent/local-gates.mjs --only check-abbreviations > /tmp/issue-1580-research/final-abbreviations.log 2>&1
node scripts/generate-staged-release.mjs --check-deployed
git diff --numstat origin/main > /tmp/issue-1580-research/local-diff-numstat.txt
git status --short
