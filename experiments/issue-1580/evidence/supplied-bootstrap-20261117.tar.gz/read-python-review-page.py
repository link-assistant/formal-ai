from pathlib import Path
import hashlib,json,sys

root=Path('/tmp/issue-1580-research/templates/python-complete')
inventory=json.loads(Path('/tmp/issue-1580-research/python-active-source-inventory.json').read_text())
page=int(sys.argv[1]);width=400;lines=[]
deferred={'.github/actions/artifact/dist/835.index.mjs','.github/actions/artifact/dist/index.mjs','.github/actions/artifact/package-lock.json','uv.lock'}
for row in inventory['active']:
 if row['path'] in deferred:continue
 data=(root/row['path']).read_bytes(); assert hashlib.sha256(data).hexdigest()==row['sha256']
 lines.extend((row['path'],n,line) for n,line in enumerate(data.decode().splitlines(),1))
print(f'Python pinned c532c173801dfb12e681b0730c4abbf93aefd0ca: {len(lines)} selected active lines, page {page}/{(len(lines)+width-1)//width}. Both generated JavaScript bundles and two locks are explicitly unread; historical files are also deferred. The initial reader preview exceeded its bound on the minified main bundle; that incomplete attempt receives no full-page reading credit.')
part=lines[(page-1)*width:page*width]; assert part
previous=None
for p,n,line in part:
 if p!=previous:print('\nFILE '+p);previous=p
 print(f'{n}: {line}')
