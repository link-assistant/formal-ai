from pathlib import Path
import subprocess, json

result=subprocess.run(['rg','--files','experiments/issue-1580'],text=True,capture_output=True,check=True)
for name in result.stdout.splitlines():
    if any(word in name for word in ['template-review','template-audit','reading','manifest']) and not name.endswith('.gz'):
        print(name)
scratch=Path('/tmp/issue-1580-research')
for path in sorted(scratch.glob('*python*')):
    if path.suffix in ['.py','.mjs','.json'] and any(word in path.name for word in ['review','reading','page']):
        print('SCRATCH',path.name,path.stat().st_size)
p=Path('experiments/issue-1580/evidence/checks/python-review-reading/initial-bundle-preview.json')
print(p.read_text())
p=Path('experiments/issue-1580/fixtures/python-template/source.json')
print(p.read_text())
