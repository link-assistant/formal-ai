from pathlib import Path
import subprocess
for args in [
 ['rg','-n','metaRunProcedure|solveImpl|compound|children|subTask','js/worker/formal_ai_worker_crate_meta_executor.js','js/worker/formal_ai_worker_meta_reasoner.js'],
 ['rg','-n','function|async|split|and','js/agentic/crate/meta_executor.mjs'],
]:
    r=subprocess.run(args,text=True,capture_output=True);print('COMMAND',args,'EXIT',r.returncode);print(r.stdout,r.stderr)
