from pathlib import Path

def replace(path, before, after):
    file=Path(path);source=file.read_text()
    assert source.count(before)==1,(path,before[:100])
    file.write_text(source.replace(before,after))

replace('rust/src/structured_log.rs',
'pub fn configure(silent: bool, _serve: bool) {',
'''// Probe writability without leaving a session log when the command emits no events.
fn check_log_directory(directory: &std::path::Path) -> io::Result<()> {
    static PROBE_SEQUENCE: AtomicU64 = AtomicU64::new(0);
    fs::create_dir_all(directory)?;
    let probe = directory.join(format!(
        ".writability-{}-{}.tmp",
        std::process::id(),
        PROBE_SEQUENCE.fetch_add(1, Ordering::Relaxed)
    ));
    let mut options = OpenOptions::new();
    options.write(true).create_new(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.mode(0o600);
    }
    let mut file = options.open(&probe)?;
    let flushed = file.flush();
    drop(file);
    let removed = fs::remove_file(probe);
    flushed.and(removed)
}

pub fn configure(silent: bool, _serve: bool) {''')
replace('rust/src/structured_log.rs',
'match open_log_file(&directory).and_then(|mut file| file.flush()) {',
'match check_log_directory(&directory) {')

file=Path('rust/tests/source/source_tests/structured_log/tests.rs')
source=file.read_text()
assert 'writability_probe_preserves_log_files' not in source
source+='''
#[test]
fn writability_probe_preserves_log_files_and_leaves_no_empty_session() {
    let directory = std::env::temp_dir().join(format!(
        "formal-ai-log-probe-{}-{}",
        std::process::id(),
        SEQUENCE.fetch_add(1, Ordering::Relaxed)
    ));
    fs::create_dir(&directory).expect("isolated log directory");
    let existing = directory.join("previous.lino");
    fs::write(&existing, "retained diagnostic\\n").expect("previous log");
    check_log_directory(&directory).expect("writable sink");
    assert_eq!(fs::read_dir(&directory).expect("log listing").count(), 1);
    assert_eq!(fs::read_to_string(&existing).expect("retained log"), "retained diagnostic\\n");
    assert!(check_log_directory(&existing).is_err(), "a regular file is not a log directory");
    let mut file = open_log_file(&directory).expect("first diagnostic opens the session");
    writeln!(file, "actual diagnostic").expect("diagnostic write");
    drop(file);
    assert_eq!(fs::read_dir(&directory).expect("written log listing").count(), 2);
    fs::remove_dir_all(directory).expect("remove isolated log directory");
}
'''
file.write_text(source)

replace('rust/tests/web/issue-1168-workflow-render-parity.test.mjs',
"import { before, test } from 'node:test';", "import { after, before, test } from 'node:test';")
replace('rust/tests/web/issue-1168-workflow-render-parity.test.mjs',
"before(async () => {\n  await installNodeHost(new WorkerHost());\n});",
"const previousOffline = process.env.FORMAL_AI_OFFLINE;\nbefore(async () => {\n  process.env.FORMAL_AI_OFFLINE = '1';\n  await installNodeHost(new WorkerHost());\n});\nafter(() => {\n  if (previousOffline === undefined) delete process.env.FORMAL_AI_OFFLINE;\n  else process.env.FORMAL_AI_OFFLINE = previousOffline;\n});")
replace('rust/tests/web/issue-1168-source-cache.test.mjs',
"    delete process.env.FORMAL_AI_LIVE_FETCH;", "    process.env.FORMAL_AI_LIVE_FETCH = '0';")
replace('rust/tests/web/issue-1168-source-cache.test.mjs',
"    if (live !== undefined) process.env.FORMAL_AI_LIVE_FETCH = live;",
"    if (live === undefined) delete process.env.FORMAL_AI_LIVE_FETCH;\n    else process.env.FORMAL_AI_LIVE_FETCH = live;")

path=Path('data/seed/client-integrations.lino')
rows=path.read_text().splitlines(keepends=True)
matches=[n for n,line in enumerate(rows) if 'temp_home_json_set "modelConfigs.overrides=json+:' in line]
assert len(matches)==1
index=matches[0]
original=rows[index]
value=original.strip().removeprefix('temp_home_json_set "').removesuffix('"').replace('\\"','"')
assert "'" not in value
rows[index]="      temp_home_json_set '"+value+"'\n"
path.write_text(''.join(rows))

replace('rust/src/agentic_coding/tool_result/source_observation.rs',
'''include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../data/parity/issue-1580-opencode-read-envelope.json"
        ))''',
'''include_str!("../../../embedded/data/parity/issue-1580-opencode-read-envelope.json")''')
print('Drafted startup sink probe, isolated offline fixtures, canonical client JSON scalar, and embedded regression include.')
