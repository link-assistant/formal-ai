from pathlib import Path
import gzip, hashlib, json, subprocess, sys

root = Path('/tmp/gh-issue-solver-1794900398048')
def command(argv):
    result = subprocess.run(argv, cwd=root, capture_output=True, text=True)
    assert result.returncode == 0, (argv, result.stderr)
    return result.stdout.strip()
assert command(['git', 'branch', '--show-current']) == 'issue-1580-8d61a32a61e1'
assert command(['git', 'rev-parse', 'HEAD']) == '9d4832c2c6d5e120a8741032d407f94098455ff3'
assert command(['git', 'diff', '--cached', '--name-only']) == ''
out = root / 'experiments/issue-1580/evidence/checks/native-round-publication'
outcome = json.loads((out / 'outcome.json').read_text())
assert outcome['complete'] and all(row['exitCode'] == 0 for row in outcome['records'])
identities = json.loads((out / 'source-identities.json').read_text())
for row in identities['files']:
    assert hashlib.sha256((root / row['path']).read_bytes()).hexdigest() == row['sha256']
note = '''

Final publication verification passes all five selected JavaScript gates, plus
formatting of all four candidate source/fixture files and whitespace checks.
The complete logs and unchanged source identities are retained under
`experiments/issue-1580/evidence/checks/native-round-publication/`. Fresh 01:57 UTC
feedback is unchanged, main 015a6831 remains merged, all 23 published-head runs
pass and both branch active/queued lists are empty. Native behavior and the
broader acceptance criteria remain unfinished.
'''
for relative in ['docs/case-studies/issue-1580/native-evidence-checkpoint.md',
                 'experiments/issue-1580/work-plan.md']:
    with (root / relative).open('a') as stream:
        stream.write(note)
for helper in ['archive-round-bootstrap.py', 'archive-evidence.py']:
    subprocess.run([sys.executable, '/tmp/issue-1580-research/' + helper], cwd=root, check=True)
allowed = [
    'changelog.d/20261117_120000_issue-1580-ci-regressions.md',
    'docs/case-studies/issue-1580/README.md',
    'docs/case-studies/issue-1580/checkout-archive-checkpoint.md',
    'docs/case-studies/issue-1580/native-evidence-checkpoint.md',
    'experiments/issue-1580/work-plan.md',
    'experiments/issue-1580/evidence/checks/native-evidence-candidates',
    'experiments/issue-1580/evidence/checks/native-fixture-inputs',
    'experiments/issue-1580/evidence/checks/native-round-publication',
    'experiments/issue-1580/evidence/ci/checkout-7e89122c',
    'experiments/issue-1580/evidence/ci/main-015a6831',
    'experiments/issue-1580/evidence/commands',
    'experiments/issue-1580/evidence/supplied-bootstrap-20261117.json',
    'experiments/issue-1580/evidence/supplied-bootstrap-20261117.tar.gz',
]
command(['git', 'add', '--', *allowed])
changed = command(['git', 'diff', '--cached', '--name-only']).splitlines()
assert changed and all(any(path == prefix or path.startswith(prefix + '/') for prefix in allowed) for path in changed)
command(['git', 'diff', '--cached', '--check'])
print('STAGED', len(changed), 'paths; no shared data/meta changes')
print(command(['git', 'diff', '--cached', '--stat', '--compact-summary']))
print(command(['git', 'commit', '-m', 'Preserve complete native failure evidence and candidate verification']))
assert command(['git', 'status', '--porcelain=v1']) == ''
print('CLEAN HEAD', command(['git', 'rev-parse', 'HEAD']))
print('No push performed.')
