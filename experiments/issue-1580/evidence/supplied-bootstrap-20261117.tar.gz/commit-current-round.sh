set -eu
test "$(git branch --show-current)" = issue-1580-8d61a32a61e1
git diff --check
python3 /tmp/issue-1580-research/archive-round-bootstrap.py
git add scripts/detect-code-changes.rs
git commit -m "fix(ci): propagate failed Git observations from change detection"
git add .cargo/audit.toml rust/tests/web/cargo-audit-blocked-proof.test.mjs
git commit -m "fix(security): prove the exact blocked Chrono dependency"
git add experiments/issue-1580/fixtures experiments/issue-1580/template-go-result-integrity.test.mjs experiments/issue-1580/template-inventory-integrity.test.mjs experiments/issue-1580/template-shared-git-observation.test.mjs experiments/issue-1580/compare-template-trees.mjs rust/tests/web/issue-1580-template-observations.test.mjs data/benchmarks/fast-pull-request-javascript-tests.json docs/case-studies/issue-1580/templates
git commit -m "test(ci): reproduce template skip and Git observation failures"
git add experiments/issue-1580/evidence experiments/issue-1580/formal-command.mjs experiments/issue-1580/upstream experiments/issue-1580/work-plan.md docs/case-studies/issue-1580/README.md changelog.d/20261117_120000_issue-1580-ci-regressions.md
git commit -m "docs(ci): preserve audit and template regression evidence"
git status --short
git log -4 --oneline
