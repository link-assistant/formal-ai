from pathlib import Path
import subprocess,json,hashlib,gzip
folder=Path('experiments/issue-1580/evidence/checks/native-deadline-and-title')
prior=json.loads((folder/'after.json').read_text());final=json.loads((folder/'repair.json').read_text());assert prior['complete'] and final['complete'] and final['allPassed']
for run in [prior,final]:
 for row in run['results']:
  blob=(folder/row['log']).read_bytes();raw=gzip.decompress(blob)
  assert hashlib.sha256(blob).hexdigest()==row['archiveSha256'];assert hashlib.sha256(raw).hexdigest()==row['rawSha256']
for path,digest in final['sourceHashes'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,path
for path,digest in prior['sourceHashes'].items():
 if path!='js/worker/formal_ai_worker_source_endpoints.js':assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,path
assert all(row['exitCode']==0 for row in prior['results'] if row['name']!='affected-gates')
branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip();assert branch=='issue-1580-8d61a32a61e1'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],text=True).strip()
paths=['.github/workflows/native-type-check.yml','rust/src/source_walk.rs','js/worker/formal_ai_worker_source_endpoints.js','rust/tests/web/default-branch-build-policy.test.mjs','rust/tests/web/source-walk-offline-policy.test.mjs','changelog.d/issue-1580-native-deadline-and-title.md']
subprocess.run(['git','add','--',*paths],check=True);subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','Restore native test optimization and localized procedure titles'],check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
(folder/'source-commit.json').write_text(json.dumps({'head':head,'published':False,'javascriptPassed':72,'affectedGatesPassed':14,'initialGateFailuresRetained':2,'nativeExecutedLocally':False,'procedureTestUnchangedFromPublishedHead':True,'originalWholeFileReplayCredit':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print('COMMITTED',head)
