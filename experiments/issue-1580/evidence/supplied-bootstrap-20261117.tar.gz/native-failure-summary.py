import gzip,json,re
from pathlib import Path
root=Path('experiments/issue-1580/evidence/ci')
out=[]
for run in ['43815999666','43805800854']:
    lines=gzip.decompress((root/(run+'.log.gz')).read_bytes()).decode(errors='replace').splitlines()
    found={}
    for i,line in enumerate(lines):
        m=re.search(r'\btest ([\w:]+) \.\.\. FAILED',line)
        if m: found.setdefault(m[1],[]).append(i+1)
    out.append({'run':run,'failedTests':[{'name':k,'lines':v} for k,v in found.items()],
      'timeouts': [{'line':i+1,'text':line} for i,line in enumerate(lines) if re.search(r'elapsed .*108[01]|exceeded .*1080|Test suite.*(?:timed out|exceeded)|has been running for over 60 seconds',line) and 'test-suite' not in line][:80]})
Path('/tmp/issue-1580-research/native-failure-summary.json').write_text(json.dumps(out,indent=2)+'\n')
for row in out:
    print('RUN',row['run'],'FAILED TESTS',len(row['failedTests']))
    for f in row['failedTests']: print(','.join(map(str,f['lines'])), f['name'])
    print('TIMEOUT/LONG TESTS')
    for f in row['timeouts']: print(f['line'],f['text'][:420])
