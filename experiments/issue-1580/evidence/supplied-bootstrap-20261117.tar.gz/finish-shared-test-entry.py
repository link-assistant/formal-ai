from pathlib import Path
p=Path('experiments/issue-1580/template-shared-git-observation.test.mjs')
s=p.read_text().replace("{timeout:15000},()=>{", "{timeout:15000},context=>{\n  const runtime=spawnSync(item.command,['--version'],{encoding:'utf8',timeout:5000,maxBuffer:4096});\n  if(runtime.error?.code==='ENOENT'){context.skip(item.command+' is not installed');return;}\n  assert.equal(runtime.status,0,runtime.stderr);\n  if(item.language==='python'){\n    const version=/Python (\\d+)\\.(\\d+)/u.exec(runtime.stdout);\n    assert.ok(version,runtime.stdout);\n    if(Number(version[1])===3&&Number(version[2])<14){context.skip('Pinned upstream syntax requires Python 3.14+');return;}\n  }")
p.write_text(s)
p=Path('rust/tests/web/issue-1580-template-observations.test.mjs')
s=p.read_text()+"import '../../../experiments/issue-1580/template-shared-git-observation.test.mjs';\n"
p.write_text(s)
print('Registered shared script tests with explicit runtime preconditions; unsupported Python earns no execution credit.')
