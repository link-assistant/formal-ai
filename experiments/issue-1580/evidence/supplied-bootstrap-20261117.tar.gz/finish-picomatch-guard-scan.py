from pathlib import Path
import hashlib,json
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'packages/picomatch-compat/lib/parse.js';s=p.read_text()
s=s.replace('// Escaped, quoted and bracket-class stars remain literals.','// Quoted and bracket-class stars remain literals; escaping follows unescape.')
s=s.replace("const hasUnboundedStar = (pattern, options) => {\n  let bracket", "const hasUnboundedStar = (pattern, options) => {\n  const lastBracket = options.nobracket === true ? -1 : pattern.lastIndexOf(']');\n  let bracket")
s=s.replace("const end = pattern.indexOf(':]', i + 2);\n        if (end !== -1 && POSIX_REGEX_SOURCE[pattern.slice(i + 2, end)]) {\n          i = end + 1;", "const match = /^\\[:([a-z]+):\\]/.exec(pattern.slice(i, i + 16));\n        if (match && POSIX_REGEX_SOURCE[match[1]]) {\n          i += match[0].length - 1;")
s=s.replace("ch === '[' && options.nobracket !== true && pattern.includes(']', i + 1)", "ch === '[' && i < lastBracket")
p.write_text(s)
p=r/'packages/picomatch-compat/upstream.json';d=json.loads(p.read_text())
for item in d['files']:
 item['localSha256']=hashlib.sha256((p.parent/item['path']).read_bytes()).hexdigest()
p.write_text(json.dumps(d,indent=2)+'\n')
print('Guard uses one closing-bracket lookup and bounded POSIX lookahead; parser lines',len(s.splitlines()))
