from pathlib import Path
import gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/checks/native-php-shared-inventory'
old, new = 'gate-check-tests-as-docs', 'gate-check-tests-as-documentation'
raw = (base / (old + '.log.gz')).read_bytes()
(base / (old + '.log.gz')).rename(base / (new + '.log.gz'))
report = json.loads((base / 'results.json').read_text())
rows = [row for row in report['gatePayloads'] if row['name'] == old]
assert len(rows) == 1 and hashlib.sha256(raw).hexdigest() == rows[0]['archiveSha256']
rows[0]['name'] = new
(base / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
failed = root / 'experiments/issue-1580/evidence/checks/native-php-publication/first-publication-attempt'
failed.mkdir(exist_ok=False)
records = []
source = Path('/tmp/issue-1580-research/native-php-publication')
assert not json.loads((source / 'outcome.json').read_text())['pushExecuted']
for path in sorted(source.iterdir()):
    if not path.is_file():
        continue
    payload = path.read_bytes()
    (failed / (path.name + '.gz')).write_bytes(gzip.compress(payload, mtime=0))
    records.append({'name': path.name, 'rawSha256': hashlib.sha256(payload).hexdigest()})
gate = root / 'experiments/formal_ai_subagent/sandboxes/gates/check-abbreviations.log'
(failed / 'abbreviation-gate.log.gz').write_bytes(gzip.compress(gate.read_bytes(), mtime=0))
(failed / 'rename.json').write_text(json.dumps({'old': old, 'new': new, 'archiveSha256': hashlib.sha256(raw).hexdigest(), 'payloadUnchanged': True, 'pushExecuted': False, 'records': records}, indent=2) + '\n')
print(json.dumps({'renamed': new, 'payloadUnchanged': True, 'preservedAttemptFiles': len(records), 'pushExecuted': False}))
