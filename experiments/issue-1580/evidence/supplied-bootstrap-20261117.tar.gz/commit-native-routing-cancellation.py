from pathlib import Path
import subprocess,hashlib,json
r=Path.cwd();review=json.loads((r/'experiments/issue-1580/evidence/checks/native-routing-cancellation-validation/review.json').read_text());assert review['complete']and review['focusedJavaScriptPassed']==45
run=lambda argv:subprocess.check_output(argv,cwd=r,text=True).strip()
assert run(['git','branch','--show-current'])=='issue-1580-8d61a32a61e1';assert run(['git','rev-parse','HEAD'])=='193546c746ab6a88aed96f58ff5d2c4f7a11ff3a';assert not run(['git','diff','--cached','--name-only'])
for p,h in review['sourceHashes'].items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h
paths=list(review['sourceHashes']);subprocess.run(['git','add','--',*paths],cwd=r,check=True);assert set(run(['git','diff','--cached','--name-only']).splitlines())==set(paths);subprocess.run(['git','diff','--cached','--check'],cwd=r,check=True);subprocess.run(['git','-c','gc.auto=0','commit','-m','Isolate native routing captures and reject cancelled PR checks'],cwd=r,check=True);print('Source commit',run(['git','rev-parse','HEAD']))
