from pathlib import Path
import json
p=Path('/tmp/gh-issue-solver-1794900398048/docs/case-studies/issue-1580/templates/python-partial-semantic-review.json')
d=json.loads(p.read_text())
print('TOP KEYS',list(d))
for k,v in d.items():
 if isinstance(v,list):
  print(k,'count',len(v))
  print(json.dumps(v[-2:],indent=2,ensure_ascii=False))
 elif isinstance(v,dict):
  print(k,'keys',list(v))
 else:print(k,v)
for name in ['read-python-template-fragment.py','read-python-fragment-page.py','review-python-fragment-page.py','commit-python-fragment-archive.py']:
 p=Path('/tmp/issue-1580-research')/name
 if p.exists():print(name,p.read_text()[:8000])
