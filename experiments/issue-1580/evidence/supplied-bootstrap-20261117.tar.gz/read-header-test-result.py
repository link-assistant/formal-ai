import gzip
import pathlib
import sys

path=pathlib.Path("experiments/issue-1580/evidence/checks/generated-header-memory")/(sys.argv[1]+".log.gz")
lines=gzip.decompress(path.read_bytes()).decode(errors="replace").splitlines()
print("LINES",len(lines))
for number,line in enumerate(lines[:1500],1):print(str(number)+": "+line)
