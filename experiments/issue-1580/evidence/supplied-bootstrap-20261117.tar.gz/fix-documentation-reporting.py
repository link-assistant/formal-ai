import json
from pathlib import Path
file=Path('scripts/documentation-only-ci-policy.mjs')
text=file.read_text()
text=text.replace("export {documentationPaths, lightweightWorkflows} from './lib/documentation-paths.mjs';", "export {documentationPaths, lightweightWorkflows} from './lib/documentation-paths.mjs';\n// Required contexts must exist on documentation PRs. Their build admission is\n// tested separately; the same workflow's heavy main push stays path-filtered.\nexport const contextReportingWorkflows = new Set(['release.yml']);")
text=text.replace('export function filteredWorkflow(source) {', 'export function filteredWorkflow(source, {file} = {}) {')
text=text.replace("  for (const event of ['push', 'pull_request']) {\n", "  for (const event of ['push', 'pull_request']) {\n    if (event === 'pull_request' && contextReportingWorkflows.has(file)) continue;\n")
text=text.replace('const expected = filteredWorkflow(source);','const expected = filteredWorkflow(source, {file});')
file.write_text(text)

file=Path('rust/tests/web/documentation-only-ci-policy.test.mjs')
text=file.read_text()
text=text.replace('filteredWorkflow, lightweightWorkflows}', 'filteredWorkflow, lightweightWorkflows, contextReportingWorkflows}')
text=text.replace("test('all heavy push and PR triggers carry the generated documentation policy'", "test('heavy triggers are filtered while required PR context reporters remain admitted'")
old="""        for (const path of selected) assert.ok(lightweightWorkflows.has(path.split('/').at(-1)), path);
        assert.ok(!selected.includes('.github/workflows/release.yml'));"""
new="""        for (const path of selected) assert.ok(lightweightWorkflows.has(path.split('/').at(-1))
          || (event === 'pull_request' && contextReportingWorkflows.has(path.split('/').at(-1))), path);
        assert.equal(selected.includes('.github/workflows/release.yml'), event === 'pull_request',
          'the required PR contexts report without selecting heavy build jobs');"""
assert old in text
text=text.replace(old,new)
text+='''
// Execute the retained workflow conditions for a real documentation-only
// classification; an event-level reporting exception cannot admit a build.
function assertDocumentationContextSafety(release, native) {
  const outputs = new Proxy({}, {get: (_, key) => key === 'docs-changed' ? 'true' : 'false'});
  const needs = new Proxy({}, {get: () => ({result: 'success', outputs})});
  const evaluate = (expression, inputs = {}) => {
    if (expression === undefined) return true;
    const source = String(expression).trim().replace(/^\\$\\{\\{\\s*|\\s*\\}\\}$/gu, '')
      .replace(/\\.([a-zA-Z_][a-zA-Z0-9_-]*)/gu, (_, key) => '[' + JSON.stringify(key) + ']');
    return Boolean(new Script(source).runInNewContext({
      github: {event_name: 'pull_request', ref: 'refs/pull/1/merge', event: {inputs: {}, workflow_run: {head_branch: 'main'}}},
      needs, inputs, vars: {}, cancelled: () => false, always: () => true,
      fromJSON: JSON.parse, contains: (container, value) => container.includes(value),
    }, {timeout: 100}));
  };
  assert.equal(release.on.pull_request['paths-ignore'], undefined);
  const selected = Object.entries(release.jobs).filter(([, job]) => evaluate(job.if)).map(([id]) => id).sort();
  assert.deepEqual(selected, ['base', 'detect-changes', 'fast-pr-lint', 'hive-source-provenance',
    'native-type-check', 'pipeline-status', 'release-preflight', 'version-check']);
  const call = release.jobs['native-type-check'];
  assert.equal(call.uses, './.github/workflows/native-type-check.yml');
  const compile = evaluate(call.with['compile-inputs-changed']);
  assert.equal(compile, false, 'a complete docs-only observation does not compile');
  const steps = native.jobs.clippy.steps.filter(step => evaluate(step.if, {'compile-inputs-changed': compile}));
  assert.equal(steps.length, 1);
  assert.equal(steps[0].name, 'Report unchanged compile inputs');
  assert.match(steps[0].run, /^echo '::notice::Rust compile inputs unchanged;/u);
  assert.equal(steps[0].uses, undefined);
}

test('documentation PR context reporting runs no native tool, product build or publication job', () => {
  const release = workflows.find(row => row.path.endsWith('/release.yml')).document;
  const native = workflows.find(row => row.path.endsWith('/native-type-check.yml')).document;
  assertDocumentationContextSafety(release, native);
  for (const mutate of [
    value => delete value.jobs['build-artifacts'].if,
    value => value.jobs['native-type-check'].with['compile-inputs-changed'] = true,
    value => value.on.pull_request['paths-ignore'] = ['docs/**'],
  ]) {
    const changed = structuredClone(release); mutate(changed);
    assert.throws(() => assertDocumentationContextSafety(changed, native));
  }
  const changed = structuredClone(native);
  delete changed.jobs.clippy.steps.find(step => step.name === 'Type-check and lint the library and binaries').if;
  assert.throws(() => assertDocumentationContextSafety(release, changed));
});

test('context reporter exemption preserves push filtering and does not apply to other heavy workflows', () => {
  const source = 'on:\\n  push:\\n  pull_request:\\njobs:\\n  retained:\\n    steps: []\\n';
  const reporter = YAML.parse(filteredWorkflow(source, {file: 'release.yml'}));
  assert.ok(reporter.on.push['paths-ignore'].includes('docs/**'));
  assert.equal(reporter.on.pull_request, null);
  const other = YAML.parse(filteredWorkflow(source, {file: 'another-heavy-workflow.yml'}));
  assert.ok(other.on.pull_request['paths-ignore'].includes('docs/**'));
});
'''
file.write_text(text)

file=Path('data/benchmarks/fast-pull-request-javascript-tests.json')
value=json.loads(file.read_text())
tests=value['files'] if 'files' in value else value.get('tests')
assert isinstance(tests,list),value.keys()
name='rust/tests/web/documentation-only-ci-policy.test.mjs'
if name not in tests: tests.append(name)
file.write_text(json.dumps(value,indent=2)+'\n')
