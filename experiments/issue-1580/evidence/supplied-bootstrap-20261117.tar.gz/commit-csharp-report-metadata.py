from pathlib import Path
import hashlib, json, subprocess

def run(args):
    return subprocess.run(args, check=True, text=True, capture_output=True).stdout
assert run(['git','branch','--show-current']).strip() == 'issue-1580-8d61a32a61e1'
root = Path('experiments/issue-1580')
receipt = json.loads((root/'evidence/checks/csharp-changeset-collision/filed-report.json').read_text())
assert receipt['bodySha256'] == hashlib.sha256((root/'upstream/csharp-changeset-output-collision-report.md').read_bytes()).hexdigest()
identities = json.loads((root/'upstream/template-report-identities.json').read_text())
assert len([row for row in identities if row['url'] == receipt['url']]) == 1
files = ['docs/case-studies/issue-1580/README.md','docs/case-studies/issue-1580/templates/README.md',str(root/'upstream/csharp-changeset-output-collision-report.md'),str(root/'upstream/filed-issues.txt'),str(root/'upstream/template-report-identities.json'),str(root/'work-plan.md'),str(root/'evidence/checks/csharp-changeset-collision/filed-report.json'),str(root/'evidence/checks/csharp-changeset-collision/filed-issue.json.gz')]
run(['git','add','--',*files])
run(['git','diff','--cached','--check'])
print(run(['git','commit','-m','docs: record verified C# changeset loss report']))
assert run(['git','status','--porcelain']).strip() == ''
print(json.dumps({'commit':run(['git','rev-parse','HEAD']).strip(),'upstreamIssue':receipt['url'],'pullRequest':'https://github.com/link-assistant/formal-ai/pull/1581','clean':True,'pushed':False,'reason':'Keep the local reporting commit while published-head CI is in progress.'},indent=2))
