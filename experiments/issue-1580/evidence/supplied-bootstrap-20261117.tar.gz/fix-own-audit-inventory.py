from pathlib import Path
p=Path('scripts/check-javascript-dependencies.sh');source=p.read_text()
before='# One temporary file per stream per lockfile. Concurrent audits would otherwise'
assert source.count(before)==1
source=source.replace(before,'''# Finish the inventory before starting any audit. A process substitution hides
# Git failures, including a failure after partial output, from set -e/pipefail.
tracked_files="$(git ls-files)" || {
  status=$?
  echo "::error::Unable to enumerate JavaScript lockfiles (git ls-files exited $status)." >&2
  exit "$status"
}

'''+before)
before='  while IFS= read -r lock; do\n';assert source.count(before)==1
source=source.replace(before,before+'    [[ "${lock##*/}" == "$lock_name" ]] || continue\n')
before="  done < <(git ls-files | awk -F/ -v name=\"$lock_name\" '$NF == name')"
assert source.count(before)==1
source=source.replace(before,'  done <<<"$tracked_files"')
p.write_text(source)
print('Git inventory is captured once and must succeed before creating any audit subprocess.')
