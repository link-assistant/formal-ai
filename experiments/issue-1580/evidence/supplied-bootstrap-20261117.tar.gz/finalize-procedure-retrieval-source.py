from pathlib import Path
import subprocess,json,gzip,hashlib,os
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/procedure-retrieval-validation'
r=subprocess.run(['rustfmt','--edition','2024','rust/tests/unit/reasoning_contracts.rs'],cwd=root,capture_output=True);assert r.returncode==0,r.stderr
# Preserve original failure; append narrow rechecks after rustfmt changes module ordering only.
checks=[('format-repaired',['rustfmt','--edition','2024','--check','rust/tests/unit/reasoning_contracts.rs']),('policy-final',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/default-branch-build-policy.test.mjs'])]
results=[]
for name,args in checks:
 r=subprocess.run(args,cwd=root,capture_output=True,env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256'));raw=r.stdout+r.stderr;packed=gzip.compress(raw,mtime=0);f=name+'.log.gz';(base/f).write_bytes(packed);row={'name':name,'argv':args,'exitCode':r.returncode,'file':f,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()};results.append(row);print(json.dumps(row));assert r.returncode==0,raw.decode()[-3000:]
d=json.loads((base/'result.json').read_text());d['rechecks']=results;d['sourceHashes']['rust/tests/unit/reasoning_contracts.rs']=hashlib.sha256((root/'rust/tests/unit/reasoning_contracts.rs').read_bytes()).hexdigest();d['complete']=True;d['initialFormatFailureRetained']=True;(base/'final-result.json').write_text(json.dumps(d,indent=2)+'\n')
print('gate names:')
for l in gzip.decompress((base/'gate-inventory.log.gz').read_bytes()).decode().splitlines():
 if any(s in l.lower() for s in ['workflow','timeout','native','branch','pipeline']):print(l)
print('Included modules and existing test counts: '+json.dumps(d['includedModules']))
