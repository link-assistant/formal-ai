from pathlib import Path
import subprocess, sys, os, json, time, hashlib, traceback, resource

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/checks/decoded-grammar-values/final'
if len(sys.argv) == 1:
    assert not base.exists()
    base.mkdir()
    with (base / 'worker.log').open('wb') as log:
        worker = subprocess.Popen([sys.executable, __file__, 'run'], cwd=root, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    (base / 'worker.json').write_text(json.dumps({'pid': worker.pid}) + '\n')
    print(json.dumps({'pid': worker.pid, 'evidence': str(base.relative_to(root))}))
    sys.exit()
assert sys.argv[1:] == ['run']
env = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
records = []
started = time.time()
def run(name, args):
    before = time.time()
    with (base / (name + '.log')).open('wb') as stream:
        result = subprocess.run(args, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT)
    raw = (base / (name + '.log')).read_bytes()
    row = {'name': name, 'command': args, 'exitCode': result.returncode, 'seconds': round(time.time()-before, 3), 'bytes': len(raw), 'lines': len(raw.splitlines()), 'sha256': hashlib.sha256(raw).hexdigest()}
    records.append(row)
    print(json.dumps(row), flush=True)
    assert result.returncode == 0, name
try:
    run('rust-format-write', ['rustfmt', '--edition', '2024', '--config', 'skip_children=true', 'rust/src/formalization/mod.rs', 'rust/tests/source/source_tests/formalization/grammar_native_parity.rs'])
    run('rust-format-check', ['rustfmt', '--edition', '2024', '--config', 'skip_children=true', '--check', 'rust/src/formalization/mod.rs', 'rust/tests/source/source_tests/formalization/grammar_native_parity.rs'])
    if int(Path('/sys/fs/cgroup/memory.max').read_text()) - int(Path('/sys/fs/cgroup/memory.current').read_text()) < 700*1024*1024:
        run('release-clean-read-cache', ['python3', '/tmp/issue-1580-research/release-quotation-read-cache.py'])
    run('focused-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-abbreviations,check-changelog-fragment-js-twin,check-fragment-release-map,check-file-size,check-reconstructed-changelog,check-hardcoded-language,check-tests-as-docs,check-twin-citations,check-package-self-containment,check_js_rust_translation'])
    run('whitespace', ['git', 'diff', '--check'])
    complete = True
except BaseException:
    traceback.print_exc()
    complete = False
outcome = {'complete': complete, 'seconds': round(time.time()-started, 3), 'records': records, 'nodeHeapMiB': 256, 'childrenPeakRssKiB': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss, 'nativeExecuted': False, 'independentAuthorshipCredit': 0}
(base / 'outcome.json').write_text(json.dumps(outcome, indent=2) + '\n')
print(json.dumps({key: value for key, value in outcome.items() if key != 'records'}), flush=True)
sys.exit(0 if complete else 1)
