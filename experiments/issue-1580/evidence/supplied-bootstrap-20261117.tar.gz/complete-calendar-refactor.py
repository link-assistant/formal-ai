from pathlib import Path
import json
root=Path('/tmp/gh-issue-solver-1794900398048');p=root/'rust/src/solver_handlers/calendar_create.rs';s=p.read_text();comment='    // The routed entry validates software ownership and the scheduling span.\n';assert s.count(comment)==1;p.write_text(s.replace(comment,''))
counts={name:len((root/name).read_text().splitlines()) for name in ['rust/src/solver_handlers/calendar_create.rs','js/worker/formal_ai_worker_calendar_and_proofs.js','ts/worker/formal_ai_worker_calendar_and_proofs.ts']}
assert counts['rust/src/solver_handlers/calendar_create.rs']==671
assert counts['js/worker/formal_ai_worker_calendar_and_proofs.js']<=1146
assert (root/'js/worker/formal_ai_worker_calendar_and_proofs.js').read_bytes()==(root/'ts/worker/formal_ai_worker_calendar_and_proofs.ts').read_bytes()
print(json.dumps({'lineCounts':counts,'ratchetsChanged':False}))
