from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
r=Path.cwd();h=lambda b:hashlib.sha256(b).hexdigest()
s=Path('/tmp/issue-1580-research/reasoning-witness-publication');source=json.loads((s/'outcome.json').read_text());assert source['complete'] and source['pushExecuted'] and source['head']=='d3adb3ce0b471b94f173b204b1e0091903c8a958'
b=r/'experiments/issue-1580/evidence/checks/reasoning-witness-publication';b.mkdir(exist_ok=True);rows=[]
for row in source['records']:
 item=dict(row)
 for label in ['stdout','stderr']:
  raw=(s/(row['name']+'.'+label)).read_bytes();assert h(raw)==row[label+'Sha256'];packed=gzip.compress(raw,mtime=0);file=row['name']+'.'+label+'.gz';(b/file).write_bytes(packed);item[label]={'file':file,'rawSha256':h(raw),'archiveSha256':h(packed),'bytes':len(raw)}
 rows.append(item)
(b/'records.json').write_text(json.dumps(rows,indent=2)+'\n');(b/'outcome.json').write_text(json.dumps({k:v for k,v in source.items() if k!='records'},indent=2)+'\n')
print('PRIOR PUBLICATION',len(rows),'commands',len(rows)*2,'payloads verified')
b=r/'experiments/issue-1580/evidence/ci/reasoning-witness-d3adb3ce';outcome=json.loads((b/'outcome.json').read_text());assert outcome['complete'] and outcome['workflowCount']==23 and outcome['success']==23 and outcome['failed']==[];records=json.loads((b/'records.json').read_text());count=0
for row in records:
 for label in ['stdout','stderr']:
  item=row[label];packed=(b/item['file']).read_bytes();assert h(packed)==item['archiveSha256'] and h(gzip.decompress(packed))==item['rawSha256'];count+=1
row=next(row for row in records if row['name']=='job-135649800212');log=gzip.decompress((b/row['stdout']['file']).read_bytes()).decode().splitlines();summary=[{'line':i,'text':line} for i,line in enumerate(log,1) if 'test result:' in line];assert len(summary)==13;assert sum(int(__import__('re').search(r'(\d+) passed;', x['text']).group(1)) for x in summary)==128
review={'head':outcome['head'],'allWorkflowsComplete':True,'workflows':23,'successfulWorkflows':23,'nativeRun':44549609309,'nativeJob':135649800212,'nativePassed':128,'nativeFailed':0,'nativeHttpPassed':4,'reasoningCasesPassed':28,'operationalCasesPassed':4,'payloadsVerified':count,'nativeLogRawSha256':row['stdout']['rawSha256'],'literalReview':{'filteredResultSummaryRowsOnly':summary,'literalNativeHttpRanges':[[1860,2010]],'fullNativeLog':False,'allIndividualJobLogs':False},'originalSourcePassingReplayUnion':17,'originalPanicsWithoutQualifyingReplay':36,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(b/'review.json').write_text(json.dumps(review,indent=2)+'\n');print('CI REVIEW',json.dumps({k:v for k,v in review.items() if k!='literalReview'}))
feedback=Path('/tmp/issue-1580-research/event-origin-feedback');b=r/'experiments/issue-1580/evidence/checks/event-origin-feedback';b.mkdir(exist_ok=True);rows=[]
for p in sorted(feedback.glob('*.json')):
 raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);file=p.name+'.gz';(b/file).write_bytes(packed);rows.append({'file':file,'count':len(json.loads(raw)),'rawSha256':h(raw),'archiveSha256':h(packed)})
(b/'review.json').write_text(json.dumps({'observedAt':(feedback/'observed-at.txt').read_text().strip(),'records':rows,'allBodiesComparedToPreviouslyReadFeedback':True,'changedOrNewBodies':0,'independentAuthorshipCredit':0},indent=2)+'\n')
s=Path('/tmp/issue-1580-research/java-history-pages');b=r/'experiments/issue-1580/evidence/checks/java-historical-forward-021';b.mkdir(exist_ok=True);manifest=json.loads((s/'manifest.json').read_text());rows=[]
for page in range(149,154):
 name=f'page-{page:03}.log.gz';packed=(s/name).read_bytes();raw=gzip.decompress(packed);assert f'page {page}/254'.encode() in raw;(b/name).write_bytes(packed);rows.append(dict(manifest[page-1],file=name,archiveSha256=h(packed),rawSha256=h(raw),completeLiteralOutputRead=True))
(b/'manifest.json').write_text(json.dumps({'pinnedHead':'dd803a2d9fa5b3a992b435acce73162274fb9e8b','pages':rows,'independentAuthorshipCredit':0},indent=2)+'\n')
b=r/'docs/case-studies/issue-1580/templates';p=b/'java-historical-review-index.json';index=json.loads(p.read_text());old=index['cumulativeSummary'];assert old['literalPages']==148;updated=dict(old,literalPages=153,nextForwardPage=154,remainingPages=101);name='java-historical-forward-review-021.json';part={'previousIndexSummary':old,'pagesFullyRead':list(range(149,154)),'filesChangedSincePrevious':[{'path':'dev/log/issues/24/pulls/25/sources/pre-commit-pypi.json','newReadLinePieces':[61,90],'cumulativeReadLinePieces':[1,90],'totalLinePieces':145,'completeSourceRead':False}],'cumulativeSummary':updated,'observations':['Five pages were literally read without truncation. This continues the historical PyPI pre-commit registry through piece 90/145, without completing its single source line. Complete line/file counts remain 8,766/123, with one partial file. No current dependency or runtime behavior is certified. Pages 154–254 and wider semantic applicability remain unfinished. Supplied reading earns zero independent authorship credit.']};raw=(json.dumps(part,indent=2)+'\n').encode();(b/name).write_bytes(raw);index['forwardParts'].append({'file':name,'sha256':h(raw),'pages':list(range(149,154))});index['cumulativeSummary']=updated;p.write_text(json.dumps(index,indent=2)+'\n');print('JAVA HISTORY',json.dumps(updated))
