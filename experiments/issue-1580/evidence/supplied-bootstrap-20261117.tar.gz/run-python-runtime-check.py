from pathlib import Path
import sys,subprocess,json,gzip,hashlib
targets={
 'maintained-observations':'rust/tests/web/issue-1580-template-observations.test.mjs',
 'fast-profile':'rust/tests/web/fast-pull-request-production-profile.test.mjs',
 'default-branch-policy':'rust/tests/web/default-branch-build-policy.test.mjs',
 'checkout-policy':'rust/tests/web/ci-change-detection-checkout.test.mjs',
}
name=sys.argv[1];command=['timeout','600','node','--test','--test-concurrency=1','--test-reporter=tap',targets[name]]
directory=Path('experiments/issue-1580/evidence/checks/python-runtime-provisioning')
result=subprocess.run(command,capture_output=True,text=True);content=(result.stdout+result.stderr).encode()
log=directory/(name+'.log.gz')
if log.exists():log.rename(log.with_name('previous-'+log.name))
log.write_bytes(gzip.compress(content,mtime=0))
record={'name':name,'command':command,'exitCode':result.returncode,'log':str(log),'uncompressedSha256':hashlib.sha256(content).hexdigest()}
(directory/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record));print(content.decode() if result.returncode else '\n'.join(content.decode().splitlines()[-10:]))
sys.exit(result.returncode)
