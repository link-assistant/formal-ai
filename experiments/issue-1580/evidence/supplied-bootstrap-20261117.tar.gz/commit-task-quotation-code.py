from pathlib import Path
import hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/checks/task-quotation-boundaries'
assert json.loads((base / 'generated-repair/outcome.json').read_text())['complete']
assert json.loads((base / 'publication-preflight/outcome.json').read_text())['complete']
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip() == 'issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == 'a97832237cbb365000dd7296050984e4bdd59ebb'
for path in [Path('/tmp/issue-1580-research/quotation-final-pr-body.md'), base / 'pull-request-description.md']:
    text = path.read_text()
    text = text.replace('rust/tests/web/worker-factual-qa.test.mjs', 'rust/tests/web/issue-1172-factual-qa-subject-gate.test.mjs')
    text = text.replace('All original 15 fixture entries are byte-equivalent as parsed values, including traces.', 'All original 15 fixture entries remain unchanged, including traces.')
    path.write_text(text)
files = [
    'changelog.d/20261117_120000_issue-1580-ci-regressions.md',
    'data/meta/translation-blockers.lino',
    'data/seed/text-formalization.lino',
    'js/agentic/crate/meta_executor.mjs',
    'js/worker/formal_ai_worker_crate_meta_executor.js',
    'rust/embedded/data/seed/text-formalization.lino',
    'rust/src/meta_executor.rs',
    'rust/tests/fixtures/js-rust-translation/crate/meta_executor.rs',
    'rust/tests/fixtures/meta-executor-parity.json',
    'rust/tests/web/helpers/issue-1550-meta-executor-cases.mjs',
    'rust/tests/web/issue-1550-meta-executor.test.mjs',
    'ts/agentic/crate/meta_executor.mts',
    'ts/worker/formal_ai_worker_crate_meta_executor.ts',
]
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
subprocess.run(['git', 'add', '--', *files], cwd=root, check=True)
staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=root, text=True).splitlines()
assert set(staged) == set(files), staged
result = subprocess.run(['git', 'commit', '-m', 'Preserve quoted connectives in recursive task decomposition'], cwd=root, capture_output=True)
(base / 'code-commit.stdout.log').write_bytes(result.stdout)
(base / 'code-commit.stderr.log').write_bytes(result.stderr)
assert result.returncode == 0, result.stderr.decode()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
value = {'commit': head, 'files': files, 'sourceHashes': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files}, 'localValidationComplete': True, 'nativeExecutionVerified': False, 'independentAuthorshipCredit': 0}
(base / 'code-commit.json').write_text(json.dumps(value, indent=2) + '\n')
print(result.stdout.decode())
print(json.dumps({'commit': head, 'files': len(files), 'remotePushed': False}))
