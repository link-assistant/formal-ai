from pathlib import Path

path = Path('experiments/issue-1580/template-inventory-integrity.test.mjs')
text = path.read_text()
text = text.replace("import {spawnSync} from 'node:child_process';", "import {spawnSync} from 'node:child_process';\nimport {createRequire} from 'node:module';")
text = text.replace('function fixture(run){', 'function fixture(run, commonJsYaml = false){')
text = text.replace("    const invoke=()=>spawnSync(process.execPath,['--max-old-space-size=64','experiments/issue-1580/compare-template-trees.mjs',input,output],{encoding:'utf8',timeout:5000,maxBuffer:65536});", """    let generator='experiments/issue-1580/compare-template-trees.mjs';
    if (commonJsYaml) {
      generator=join(directory,'generator.mjs');
      writeFileSync(generator,readFileSync(new URL('./compare-template-trees.mjs',import.meta.url)));
      const packageDirectory=join(directory,'node_modules/yaml');
      mkdirSync(packageDirectory,{recursive:true});
      writeFileSync(join(packageDirectory,'package.json'),JSON.stringify({main:'index.cjs'}));
      // Dynamic CommonJS exports reproduce CI without a dependency install.
      const yamlPath=createRequire(import.meta.url).resolve('yaml');
      writeFileSync(join(packageDirectory,'index.cjs'),`Object.assign(module.exports, require(${JSON.stringify(yamlPath)}));\\n`);
    }
    const invoke=()=>spawnSync(process.execPath,['--max-old-space-size=64',generator,input,output],{encoding:'utf8',timeout:5000,maxBuffer:65536});""")
text += """
test('workflow inventory runs when yaml exposes only dynamic CommonJS exports', {timeout:10000},()=>{
  fixture(({invoke,output})=>{
    const result=invoke();
    assert.equal(result.status,0,result.stderr);
    const row=JSON.parse(readFileSync(join(output,'fixture-workflows.jsonl'),'utf8'));
    assert.deepEqual(row.document,YAML.parse(workflow));
  },true);
});
"""
path.write_text(text)
