from pathlib import Path
import datetime,gzip,json,subprocess
head='2ec6ef93a80c7081a46816d1242bc0f7b843d5ff'
base=Path('/tmp/issue-1580-research/published-2ec6ef93-runs');base.mkdir(exist_ok=True)
raw=subprocess.check_output(['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','100','--json','databaseId,workflowName,status,conclusion,createdAt,updatedAt,headSha'])
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
(base/(stamp+'.json.gz')).write_bytes(gzip.compress(raw,mtime=0))
rows=[row for row in json.loads(raw) if row['headSha']==head]
print(json.dumps({'capturedAt':stamp,'head':head,'total':len(rows),'completed':sum(row['status']=='completed' for row in rows),'success':sum(row['conclusion']=='success' for row in rows),'active':[row for row in rows if row['status']!='completed'],'nonpassing':[row for row in rows if row['status']=='completed' and row['conclusion']!='success']},indent=2))
