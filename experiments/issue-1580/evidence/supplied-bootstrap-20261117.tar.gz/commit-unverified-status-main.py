from pathlib import Path
import datetime, gzip, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = Path('/tmp/issue-1580-research/unverified-status-main-update')
assert (root / '.git/MERGE_HEAD').exists()
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=root)
whitespace=subprocess.run(['git','diff','--cached','--check'],cwd=root,capture_output=True)
(base/'incoming-whitespace.stdout').write_bytes(whitespace.stdout)
(base/'incoming-whitespace.stderr').write_bytes(whitespace.stderr)
if whitespace.returncode:
    warnings=[line for line in whitespace.stdout.decode().splitlines() if ': trailing whitespace.' in line]
    assert warnings and all(line.startswith('dev/log/issues/1590/pulls/1601/') for line in warnings)
subprocess.run(['git','diff','--cached','--check','--','.',':(exclude)dev/log'],cwd=root,check=True)
result=subprocess.run(['git','commit','-m','Merge main forced-function handling and preserve required-context admission'],cwd=root,capture_output=True)
(base/'merge-commit.stdout').write_bytes(result.stdout)
(base/'merge-commit.stderr').write_bytes(result.stderr)
assert result.returncode==0,result.stderr.decode()
subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],cwd=root,check=True)
destination=root/'experiments/issue-1580/evidence/checks/unverified-child-status/main-update'
destination.mkdir()
archives=[]
for directory,prefix in [(base,'incoming'),(Path('/tmp/issue-1580-research/unverified-status-publication'),'stopped-publication')]:
    for path in sorted(directory.iterdir()):
        if path.is_file():
            raw=path.read_bytes(); output=destination/(prefix+'-'+path.name+'.gz'); output.write_bytes(gzip.compress(raw,mtime=0))
            archives.append({'source':str(path),'archive':output.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'rawBytes':len(raw)})
report={'main':'19235c49abaf1e71aad89e4badbe1f9bba5d4786','mergedHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceDiffLiteralReview':{'firstLine':1,'lastLine':1647,'excludesDevelopmentLogAndGeneratedMirrors':True},'previousPublicationStoppedBeforePush':True,'remoteBranchUnchanged':True,'conflictsResolved':['native workflow combines conditional admission with both isolated targets and CLI replay','policy test retains unconditional required-context assertions and pins all conditional compile steps','maintained baseline writer changes exactly four Cargo manifest fixture identities'],'nativeExecuted':False,'independentAuthorshipCredit':0,'archives':archives}
(destination/'merge.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='archives'}))
