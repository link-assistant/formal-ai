from pathlib import Path
import json,subprocess
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
gates=json.loads(Path('experiments/issue-1580/evidence/checks/main-merge-058e9bef/all-local-gates.json').read_text())
assert gates['exitCode']==0
for name in ['archive-round-bootstrap.py','archive-evidence.py']:
    result=subprocess.run(['python3','/tmp/issue-1580-research/'+name],check=True,text=True,capture_output=True)
    print(result.stdout)
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','experiments/issue-1580/evidence','experiments/issue-1580/work-plan.md','docs/case-studies/issue-1580/main-058e9bef-checkpoint.md'],check=True)
subprocess.run(['git','diff','--check','--cached'],check=True)
stats=subprocess.check_output(['git','diff','--cached','--stat'],text=True)
Path('/tmp/issue-1580-research/058e9bef-checkpoint-staged-stat.log').write_text(stats)
print('STAGED STAT TAIL','\n'.join(stats.splitlines()[-8:]))
subprocess.run(['git','commit','-m','Record merged-source validation and current CI failure evidence'],check=True)
print('HEAD',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
print('STATUS',subprocess.check_output(['git','status','--short'],text=True))
