from pathlib import Path
import gzip,hashlib,json,os,subprocess
base=Path('experiments/issue-1580/evidence/ci/native-b367d603')
for old,new in [('published-pr.diff.gz','published-pull-request.diff.gz'),('published-pr-diff.stderr.gz','published-pull-request-diff.stderr.gz')]:
    source=base/old;target=base/new;assert source.exists() and not target.exists();source.rename(target)
out=Path('experiments/issue-1580/evidence/checks/localized-unknown-opener/publication/naming-correction');out.mkdir()
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=256';rows=[]
for name,argv in [('naming',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations']),('whitespace',['git','diff','--check'])]:
    result=subprocess.run(argv,env=env,capture_output=True);raw=result.stdout+result.stderr;(out/(name+'.log.gz')).write_bytes(gzip.compress(raw,mtime=0))
    rows.append({'name':name,'argv':argv,'exitCode':result.returncode,'rawSha256':hashlib.sha256(raw).hexdigest()});print(raw.decode(errors='replace'))
(out/'outcome.json').write_text(json.dumps({'complete':True,'records':rows},indent=2)+'\n');assert all(row['exitCode']==0 for row in rows)
path=Path('experiments/formal_ai_subagent/sandboxes/gates/check-abbreviations.log');(out/'gate-details.log.gz').write_bytes(gzip.compress(path.read_bytes(),mtime=0))
checkpoint=Path('docs/case-studies/issue-1580/localized-opener-and-ci-checkpoint.md')
checkpoint.write_text(checkpoint.read_text()+'''\nFinal publication checks pass six of seven entries, then catch two abbreviated
evidence filenames added during review. Renaming those files in full words
restores the unchanged 90-file naming ceiling, and the naming/whitespace rerun
passes. The initial failed publication log and the correction receipt are both
retained under `evidence/checks/localized-unknown-opener/publication/`.
''')
plan=Path('experiments/issue-1580/work-plan.md');plan.write_text(plan.read_text()+'''\nFinal publication verification preserves six passing gates and its initial
naming-policy failure; spelling two evidence filenames in full words restores
the unchanged ceiling. The focused naming and whitespace rerun passes.
''')
body=Path('/tmp/issue-1580-research/opener-round-pull-request-description.md')
text=body.read_text();needle='Formatting, projection and whitespace checks pass; no local Rust build or native execution is used.'
assert needle in text;text=text.replace(needle,'Final publication checks also catch two abbreviated evidence filenames; spelling them in full words restores the unchanged naming ceiling and the focused rerun passes. '+needle);body.write_text(text)
helper=Path('/tmp/issue-1580-research/commit-localized-opener-round.py');text=helper.read_text()
text=text.replace("for name in ['corrected-checks','publication']:","for name in ['corrected-checks','publication/naming-correction']:")
needle="assert json.loads((checks/'shellcheck/receipt.json').read_text())['complete']"
text=text.replace(needle,"""publication=json.loads((checks/'publication/outcome.json').read_text())
assert publication['complete']
log=gzip.decompress((checks/'publication/gates.log.gz').read_bytes()).decode()
assert re.findall(r'^FAIL (\\S+)',log,re.M)==['check-abbreviations']
"""+needle).replace('import json,subprocess','import gzip,json,re,subprocess')
helper.write_text(text)
print('Two evidence names corrected without increasing the naming allowance.')
