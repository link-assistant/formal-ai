from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, subprocess, sys, time, traceback

root=Path('/tmp/gh-issue-solver-1794900398048')
scratch=Path('/tmp/issue-1580-research')
base=root/'experiments/issue-1580/evidence/checks/javascript-archive-checkout'
out=scratch/'javascript-checkout-publication-final'
if len(sys.argv)==1:
    out.mkdir(exist_ok=False)
    with (out/'worker.log').open('wb') as stream:
        worker=subprocess.Popen([sys.executable,__file__,'finish'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'process.json').write_text(json.dumps({'pid':worker.pid})+'\n')
    print(json.dumps({'pid':worker.pid,'output':str(out)}));sys.exit(0)
assert sys.argv[1:]==['finish']
environment=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
records=[]
def run(label,args,parse=False,checked=True):
    result=subprocess.run(args,cwd=root,env=environment,capture_output=True)
    (out/(label+'.stdout')).write_bytes(result.stdout)
    (out/(label+'.stderr')).write_bytes(result.stderr)
    row={'name':label,'command':args,'exitCode':result.returncode,'stdoutBytes':len(result.stdout),'stdoutSha256':hashlib.sha256(result.stdout).hexdigest(),'stderrBytes':len(result.stderr),'stderrSha256':hashlib.sha256(result.stderr).hexdigest()}
    records.append(row);print(json.dumps(row),flush=True)
    if checked:assert result.returncode==0,(label,result.stderr.decode())
    return json.loads(result.stdout) if parse else result.stdout.decode().strip()

complete=False;pushed=False;head=None;source='8ace3291f83b2f5c7a667740cdad31c485467e24'
try:
    branch='issue-1580-8d61a32a61e1';published='9095abcbcccdd5518ce2c9318d3ebc6eb8914fc8'
    paths=['.github/workflows/layered-ci.yml','rust/tests/web/fast-pull-request-production-profile.test.mjs','changelog.d/20261117_120000_issue-1580-ci-regressions.md']
    assert run('branch',['git','branch','--show-current'])==branch
    assert run('initial-head',['git','rev-parse','HEAD'])==source
    run('archive-supplied',['python3',str(scratch/'archive-round-bootstrap.py')])
    run('archive-commands',['python3','experiments/issue-1580/archive-evidence.py'])
    run('stage-correction',['git','add','--','experiments/issue-1580','docs/case-studies/issue-1580/checkout-archive-checkpoint.md'])
    names=run('staged-evidence',['git','diff','--cached','--name-only']).splitlines()
    assert names and all(name.startswith('experiments/issue-1580/') or name=='docs/case-studies/issue-1580/checkout-archive-checkpoint.md' for name in names)
    run('staged-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size-js-twin,check-file-size'])
    run('evidence-whitespace',['git','diff','--cached','--check'])
    run('evidence-commit',['git','-c','gc.auto=0','commit','-m','Preserve native execution and JavaScript checkout regression evidence'])
    head=run('head',['git','rev-parse','HEAD'])
    assert run('parent',['git','rev-parse','HEAD^'])==source
    assert run('clean-before-push',['git','status','--porcelain'])==''
    run('fetch-main-final',['git','-c','gc.auto=0','fetch','origin','main'])
    run('main-ancestor-final',['git','merge-base','--is-ancestor','origin/main','HEAD'])
    assert run('remote-before',['git','ls-remote','origin','refs/heads/'+branch]).split()[0]==published
    for status in ['in_progress','queued']:
        assert run('runs-'+status,['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--status',status,'--json','databaseId,workflowName,headSha'],True)==[]
    run('push',['git','push','origin','HEAD:refs/heads/'+branch]);pushed=True
    assert run('remote-after',['git','ls-remote','origin','refs/heads/'+branch]).split()[0]==head
    body=root/'experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md'
    run('edit-pr',['gh','pr','edit','1581','--repo','link-assistant/formal-ai','--title','Fix task decomposition, client constraints and CI regressions','--body-file',str(body)])
    pr=run('pr',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','headRefOid,isDraft,body,title,url'],True)
    assert pr['headRefOid']==head and pr['isDraft'] and pr['body']==body.read_text() and pr['body'].count('Fixes #1580')==1
    run('pr-diff',['gh','pr','diff','1581','--repo','link-assistant/formal-ai'],checked=False)
    available=records[-1]['exitCode']==0
    if not available:assert 'maximum number of files (300)' in (out/'pr-diff.stderr').read_text()
    pages=run('source-api',['gh','api','repos/link-assistant/formal-ai/commits/'+source+'?per_page=100','--paginate','--slurp'],True)
    files=[row for page in pages for row in page['files']]
    assert {row['filename'] for row in files}==set(paths)
    for number,row in enumerate(files):assert row['sha']==run('blob-'+str(number),['git','rev-parse',source+':'+row['filename']])
    patches='\n\n'.join(row['filename']+'\n'+row['patch'] for row in files)+'\n'
    (out/'source-api-patches.txt').write_text(patches)
    assert run('clean-after-publication',['git','status','--porcelain'])==''
    verification={'publicationVerified':True,'head':head,'sourceHead':source,'branch':branch,'pullRequest':pr['url'],'draft':True,'fullGhPrDiffAvailable':available,'incrementalSourceFiles':len(files),'incrementalPatchLines':len(patches.splitlines()),'literalApiPatchReviewComplete':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
    (out/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
    complete=True
except BaseException:
    traceback.print_exc()
report={'complete':complete,'head':head,'sourceHead':source,'pushExecuted':pushed,'observedAt':datetime.now(timezone.utc).isoformat(),'records':records,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(out/'outcome.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:value for key,value in report.items() if key!='records'}),flush=True)
sys.exit(0 if complete else 1)
