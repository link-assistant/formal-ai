from pathlib import Path
import subprocess
for p in sorted(Path('/tmp/issue-1580-research').glob('*.py')):
 s=p.read_text()
 if 'supplied-bootstrap-20261117' in s:
  print('WRITER',p.name);print(s[:13000])
print('MEMORY',Path('/sys/fs/cgroup/memory.current').read_text().strip())
p=Path('/tmp/issue-1580-research/language-main-validation/all-local-gates.log');lines=p.read_text().splitlines();print('PROGRESS',len(lines));print('\n'.join(lines[-5:]))
