import gzip,json,subprocess
from pathlib import Path
base=Path('experiments/issue-1580/evidence/checks/passage-routing-probe')
for path in sorted(base.glob('*.json.gz')):
 data=json.loads(gzip.decompress(path.read_bytes()))
 if 'answer' not in data:continue
 print(path.name,'mode',data.get('mode'),'calls',len(data.get('calls',[])))
 if data.get('mode')!='guarded':continue
 print('answer',data['answer'].get('intent'),data['answer'].get('content'))
 print('metaExecution',json.dumps(data['answer'].get('metaExecution')))
 for event in data['answer'].get('solverEvents',[]):
  if event['kind'] in ['meta_exec:task','meta_exec:unresolved','meta_exec:draft']:print(json.dumps(event))
print(subprocess.check_output(['rg','--files','rust/tests/web','-g','*meta*execut*','-g','*1550*'],text=True))
