set -eu
sed -n '383,535p' scripts/detect-code-changes.rs
cat /tmp/issue-1580-research/templates/php-complete/scripts/src/ChangeDetector.php
cat /tmp/issue-1580-research/templates/php-complete/scripts/bootstrap.php
rg -n 'detect-code-changes.rs|rust-script.*--test' .github/workflows scripts/check* experiments/formal_ai_subagent/local-gates.mjs rust/tests/web > /tmp/issue-1580-research/detector-consumers.txt
head -n 90 /tmp/issue-1580-research/detector-consumers.txt
