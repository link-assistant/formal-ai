from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,re
root=Path('/tmp/gh-issue-solver-1794900398048');checks=root/'experiments/issue-1580/evidence/checks';validation=checks/'canonical-main-final-validation';extra=checks/'canonical-post-merge-cnl'
outcome=json.loads((validation/'outcome.json').read_text());assert outcome['complete'] and outcome['sourceUnchangedDuringValidation'];assert outcome['gates']=={'PASS':86,'FAIL':1,'SKIP':52}
filename_repair=checks/'canonical-filename-repair';repair_outcome=json.loads((filename_repair/'outcome.json').read_text());assert repair_outcome['allPassed'] and not repair_outcome['runtimeSourceChanged'] and not repair_outcome['ratchetChanged']
packed=(filename_repair/repair_outcome['file']).read_bytes();raw=gzip.decompress(packed);assert hashlib.sha256(raw).hexdigest()==repair_outcome['rawSha256'] and hashlib.sha256(packed).hexdigest()==repair_outcome['archiveSha256']
supplement=json.loads((extra/'outcome.json').read_text());assert supplement['allPassed'] and supplement['sourceUnchangedDuringValidation'] and supplement['head']==outcome['head']
def verify_rows(base):
 counts={k:0 for k in ['tests','pass','fail','skipped']};rows=json.loads((base/'results.json').read_text())
 for row in rows:
  packed=(base/row['file']).read_bytes();raw=gzip.decompress(packed);assert hashlib.sha256(raw).hexdigest()==row['rawSha256'] and hashlib.sha256(packed).hexdigest()==row['archiveSha256'];assert row['exitCode']==(1 if row['name']=='all-local-gates' else 0)
  if '--test' in row['argv']:
   for k in counts:
    match=re.search(r'^(?:ℹ|#) '+k+r' (\d+)',raw.decode(),re.M);assert match;counts[k]+=int(match[1])
 return rows,counts
rows,counts=verify_rows(validation);assert counts=={'tests':116,'pass':116,'fail':0,'skipped':0}
extra_rows,extra_counts=verify_rows(extra);assert extra_counts=={'tests':22,'pass':22,'fail':0,'skipped':0}
records=json.loads((validation/'gate-log-manifest.json').read_text());assert len(records)==87
for row in records:
 packed=(validation/'gate-logs'/row['file']).read_bytes();raw=gzip.decompress(packed);assert hashlib.sha256(raw).hexdigest()==row['rawSha256'] and hashlib.sha256(packed).hexdigest()==row['archiveSha256']
review={'head':outcome['head'],'allPassed':True,'sourceUnchangedDuringValidation':True,'focusedCounts':counts,'postMergeCnlCounts':extra_counts,'totalFocusedTestsPassed':138,'initialFullInventoryGateCounts':outcome['gates'],'gateCounts':{'PASS':87,'FAIL':0,'SKIP':52},'gateCountBasis':'86 initial passes plus the repaired filename gate replay; 52 explicit skips. The original failed aggregate remains preserved.','filenameRepairPayloadHashVerifiedAndLiterallyRead':True,'allCheckPayloadHashesVerified':len(rows),'allDetailedGatePayloadHashesVerified':len(records),'allFocusedAndAggregatePayloadsLiterallyRead':True,'detailedGatePayloadsLiterallyRead':False,'nativeExecutedLocally':False,'independentAuthorshipCredit':0,'fullIssueComplete':False}
(validation/'review.json').write_text(json.dumps(review,indent=2)+'\n')
(extra/'review.json').write_text(json.dumps({'head':outcome['head'],'allCheckPayloadHashesVerified':len(extra_rows),'allFocusedPayloadsLiterallyRead':True,'counts':extra_counts,'nativeExecutedLocally':False,'independentAuthorshipCredit':0},indent=2)+'\n')
ci=root/'experiments/issue-1580/evidence/ci/data-native-0f8c178c'
repair={'head':'0f8c178ca9c4a2c6fd9bf07e67a2babd450436bb','failedWorkflowId':44371961425,'allActionableFailuresReviewed':True,'actionableFailures':[{'failure':'client-integrations.lino:440 invalid embedded JSON quoting','repairCommit':'a785a99b5b3291eadedc072e9effda51de0b3b75','repair':'Canonical single-quoted Links Notation scalar retains valid embedded JSON. Original native data tests remain unchanged.'},{'failure':'cnl-language-ru.lino:13 pipe-packed alternatives','repairCommit':'a785a99b5b3291eadedc072e9effda51de0b3b75','repair':'Canonical reference sequences and keyed child forms preserve full decoded output policy and all five grammars. Original native data tests remain unchanged.'}],'regressionBefore':{'tests':16,'pass':13,'fail':3},'initialAfter':{'tests':47,'pass':47,'fail':0,'skipped':0},'postMergeCnl':extra_counts,'nextNativeExecution':'pending hosted CI','originalNativeContractsVerified':10,'originalNativeContractsOpen':43,'originalBudgetFailuresOpen':3,'independentAuthorshipCredit':0,'fullIssueComplete':False}
(ci/'repair-review.json').write_text(json.dumps(repair,indent=2)+'\n')
section='''

## Canonical data, scheduling replay and current-main integration

- [x] Collect all 23 workflows for published `0f8c178c` with exact head/timestamp checks: 22 pass; pipeline 44371961425 fails two unchanged native data contracts. Literally inspect native job lines 1610–1714 and retain all 44 payload hashes. Twenty data cases and 32 native cases pass before abort; later targets do not execute. The original uniqueness panic now has an unchanged-source hosted pass: 10 original contracts verified, 43 open and three budget failures open.
- [x] Reproduce the canonical-data defects with 16 JavaScript cases: 13 pass and three fail. Convert 986 controlled-language fields to canonical reference sequences and keyed children, preserving complete decoded output policy and all five grammar trees. Preserve empty positional alternatives. Correct the Gemini embedded JSON scalar and 20 other quoted fields without changing complete decoded trees. Six focused files then pass 47/47; original native tests and thresholds remain unchanged.
- [x] Finish every actionable local preflight failure in one batch: quote 14 additional response fields consistently across all five languages with complete decoded-tree equality; run the official TypeScript and JavaScript-to-Rust generators; refresh 16 demanded package mirrors. Losslessly compress the two 14,438-line decoded snapshots with raw/archive hashes. Preserve the first 256 MiB translator heap failure and the sole 384 MiB, one-job successful retry (peak container use 2,867,990,528 bytes). No translation ratchet is relaxed and no local Rust build runs. Commit `a785a99b`.
- [x] Admit 18 existing native meeting, timezone, capability and spoken-hour cases through an isolated target without changing their assertions. Before/after policy checks demonstrate the admission repair; scheduling-focused validation passes 70 tests and 11 affected gates. Commit `ca68d929`; native execution remains pending.
- [x] Merge main `53cbe443` as `5af5dfd7`. Preserve all nine isolated native targets, library and Spanish controls, both HTTP modes and incoming localized native replay. Resolve the workflow admission guard explicitly. The unchanged governed reader produces the exact strict three-way union of both complete parent objects: 1,185 total / 221 supported / 964 unsupported; overlapping scalar conflicts fail instead of silently replacing evidence.
- [x] Validate unchanged merged source `5af5dfd7`: 116 tests in eight focused files pass; 22 controlled-language tests in two additional files pass after the merge. Rust 2024 formatting, whitespace and TypeScript runtime qualification pass. TypeScript runs 594 input operations over 570 unique inputs with independent calculation, real filesystem and missing/altered-input controls; this does not claim full runtime parity. The full 139-gate inventory records 86 passes, one filename failure and 52 native/context skips. Rename the two abbreviated merge receipt files without changing bytes or ratchet, then replay the failed gate successfully. All 87 executable gates have passing results; preserve the initial failed aggregate. Verify all aggregate, focused and 87 detailed gate hashes; literally read complete focused/aggregate logs without claiming full literal review of detailed gate payloads.
- [x] Preserve failed/canceled preparation receipts and the previous publication receipt. Latest feedback is unchanged: issue body, one issue comment and nine PR conversation comments; zero inline comments, reviews or required sub-issues. Literally read Java historical pages 127–130 without truncation: continuous 130/254 pages and 8,240 lines, with 111 complete files and the partial Node catalog through line 661/884. Pages 131–254 and full semantic applicability remain unfinished.
- [ ] Publish this complete repair batch only after fresh main, remote-head and empty queue checks. Collect all exact-head hosted results, including the 22 unchanged data cases, 18 scheduling cases, captured-source and Spanish controls, HTTP replays and incoming localized native replay. Any subsequent failure remains a new unfinished result until repaired and verified.
- [ ] Continue the remaining 43 original panic contracts, three historical budget terminations and every broader acceptance criterion. Keep PR #1581 draft and unmerged. Accepted independent reasoning remains 0/20; supplied commands, patches and source review earn zero credit and the 5% target remains reporting only.
'''
plan=root/'experiments/issue-1580/work-plan.md';text=plan.read_text();assert '## Canonical data, scheduling replay and current-main integration' not in text
text=text.replace('- [ ] Publish this complete repair batch after fresh queue checks. Collect all next-head workflows and verify the 22 unchanged data cases, nine unknown-source cases, 13 captured-source cases, original Spanish sibling, other isolated contracts and HTTP replays without treating them as full issue completion.','- [x] Publish the data-admission batch as `0f8c178c`; 22/23 workflows pass. Two original data failures block later native targets, investigated and repaired in the following batch.')
plan.write_text(text+section)
checkpoint=root/'docs/case-studies/issue-1580/canonical-data-and-scheduling-checkpoint.md';assert not checkpoint.exists()
checkpoint.write_text('''# Canonical data and scheduling checkpoint

Published `0f8c178c` completes 23 workflows, with 22 passing. Its sole
[pipeline failure](https://github.com/link-assistant/formal-ai/actions/runs/44371961425)
is two unchanged native data assertions: invalid embedded JSON at
`client-integrations.lino:440` and pipe-packed alternatives at
`cnl-language-ru.lino:13`. Twenty data cases pass before this abort; later native
targets do not run. Ten original panic contracts have actual hosted passes,
43 remain open, and three historical budget terminations remain open.

The regression starts with 13 passes and three failures across 16 JavaScript
cases. Commit `a785a99b` represents all 986 controlled-language fields using
canonical reference sequences and keyed children. Complete decoded output
policy and all five grammars remain equal, including empty positional forms.
Gemini JSON and other quoted scalars retain their decoded values. Six focused
files subsequently pass all 47 cases; the original native tests are unchanged.

The local full-gate preflight also exposes stale generated sources, embedded
package mirrors, multilingual formatting and oversized diagnostic snapshots.
The batch repairs all six failed gates together using official generators,
16 refreshed mirrors, complete decoded-tree checks, and lossless compressed
snapshots. The first translator attempt exhausts its 256 MiB heap; one bounded
384 MiB retry with one job succeeds, peaking at 2,867,990,528 container bytes.
Both attempts and all canceled preparation receipts remain recorded.

Commit `ca68d929` admits 18 existing scheduling, timezone and capability native
cases without changing assertions. Its 70 focused JavaScript tests and eleven
affected gates pass; the 18 native cases await hosted execution.

Main `53cbe443` is merged at `5af5dfd7`. The merged workflow retains nine isolated
targets, the library and Spanish checks, both HTTP modes, and main's localized
native replay with its compile-input guard. The unchanged governed reader
matches the strict complete-object union of both parents: 1,185 records,
221 supported and 964 unsupported. No expected diagnostic is weakened.

On unchanged merged source, 116 tests across eight focused files pass, followed
by 22 controlled-language cases across two files. The full 139-gate inventory
records 86 passes, one filename failure and 52 native/context skips. Renaming
two merge receipt files preserves their bytes and repairs that gate on replay;
all 87 executable gates now have passing results. The failed aggregate remains
retained. Rust 2024
formatting, whitespace and TypeScript runtime qualification also pass. The
TypeScript check executes 594 input operations over 570 unique inputs, including
independent arithmetic, filesystem and altered/missing-source controls; full
runtime parity remains unclaimed. All payload hashes are verified; detailed
gate payloads are retained without a full literal-read claim. No local Rust
build runs, and these local results do not certify pending native execution.

Java historical review reaches 130/254 continuous pages and 8,240 literal lines;
124 pages and wider semantic applicability remain unfinished. Accepted
independent reasoning stays 0/20. The PR remains draft and the full issue stays
unfinished. The work plan retains the remaining acceptance inventory.
''')
readme=root/'docs/case-studies/issue-1580/README.md';readme.write_text(readme.read_text()+'''

The [canonical-data and scheduling checkpoint](canonical-data-and-scheduling-checkpoint.md)
records `0f8c178c` (22/23 workflows pass), repairs both native data failures while
preserving complete decoded grammar objects, and admits 18 unchanged native
scheduling cases. Main `53cbe443` is merged. The merged source passes 138 focused
JavaScript tests, TypeScript runtime qualification and all 87 executable gates;
52 native/context gates explicitly skip. Current native execution remains
pending. Java historical review reaches 130/254 pages and 8,240 literal lines.
The remaining 43 original panics, three budget failures and wider criteria stay
unfinished; the PR remains draft with zero independent reasoning credit.
''')
body=checks/'unverified-child-status/pull-request-description.md';lines=body.read_text().splitlines();updated=[]
for line in lines:
 if line.startswith('- Main `7b7e189d` is integrated.'):
  line='- Main `53cbe443` is integrated as `5af5dfd7`. The unchanged merged source passes **138 focused JavaScript tests across ten files**, **87 executable local gates with 52 explicit native/context skips**, Rust 2024 formatting, whitespace and TypeScript runtime qualification (594 input operations / 570 unique inputs; full runtime parity unclaimed). Complete decoded output policy and all five grammars remain equal after canonicalizing 986 fields; official generated sources and 16 package mirrors are refreshed. The strict complete-object governed union retains **1,185 / 221 supported / 964 unsupported**. No native build runs locally. The new isolated scheduling target admits **18 unchanged native cases**, whose execution remains pending. See the [canonical-data and scheduling checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/canonical-data-and-scheduling-checkpoint.md).'
 elif line.startswith('- Published `4d105df7` completes'):
  line='- Published `0f8c178c` completes **23 workflows: 22 pass**. Its sole [pipeline failure](https://github.com/link-assistant/formal-ai/actions/runs/44371961425) is two unchanged native data assertions: malformed Gemini JSON and pipe-packed grammar alternatives. Twenty data cases and 32 native cases pass before abort; later targets do not execute. The repair reproduces three failures in 16 JavaScript cases, then passes 47/47 focused cases; post-merge controlled-language checks pass 22/22. Original native data tests remain unchanged. Ten original panic contracts now have hosted passes, with **43 open plus three budget failures**. Current native data, scheduling, captured-source, Spanish and HTTP results await hosted CI; historical passes remain distinguished from current-head results.'
 elif line.startswith('Unfinished acceptance remains explicit'):
  line='Unfinished acceptance remains explicit in the work plan: the original main inventory (53 distinct native panic headers, ten verified in hosted execution and **43 still open**, plus three unverified budget terminations), semantic regressions and benchmark floors, full file comparison/applicability for all eight templates, dependency migrations and warnings, historical cache/Docker and required-context reproduction, live delivery/model identity, and general parent/passage binding and provenance. Complete literal review of retained native payloads is unfinished. Java historical review is **130/254 continuous pages**, with 111 complete files, one partial and 8,240 source lines; pages 131–254 and wider semantic review remain open.'
 updated.append(line)
 if line.startswith('- Correct decoded native structural values'):
  updated.append('- Encode controlled-language alternatives as canonical reference sequences and keyed forms, preserving every decoded grammar field and empty positional alternative. Correct embedded JSON quoting, regenerate official projections and refresh demanded package mirrors without weakening the unchanged native data contracts.')
 if line=='timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/default-branch-build-policy.test.mjs':
  updated.extend(['timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/cnl-output.test.mjs','timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/cnl-parity.test.mjs'])
text='\n'.join(updated)+'\n';assert text.count('Fixes #1580')==1;body.write_text(text)
print(json.dumps({'review':review,'repairReview':repair,'documentsUpdated':[str(p.relative_to(root)) for p in [plan,checkpoint,readme,body]],'independentAuthorshipCredit':0},indent=2))
