from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys,tempfile
directory=Path('experiments/issue-1580/evidence/checks/audit-inventory-boundary');name=sys.argv[1]
groups={'abbreviations':'check-abbreviations','basic':'check-abbreviations,check-file-size,check-file-size-js-twin','workflow':'check-ci-speed,check-runner-labels,lint-shell-scripts','readable':'check-readable-code','dependency':'check-javascript-dependencies'}
env=dict(os.environ);env['PATH']='/tmp/issue-1580-research/shellcheck-v0.11.0:'+env['PATH']
command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',groups[name]]
with tempfile.TemporaryDirectory(prefix='issue-1580-offline-audit-gate-') as scratch:
 calls=Path(scratch)/'calls';calls.write_text('')
 if name=='dependency':
  for tool in ['bun','npm']:
   p=Path(scratch)/tool;p.write_text('#!/usr/bin/env bash\nprintf "%s\\t%s\\t%s\\n" "$PWD" "$0" "$*" >> "$FAKE_AUDIT_CALLS"\necho "offline fixture clean verdict"\n');p.chmod(0o755)
  env['PATH']=scratch+':'+env['PATH'];env['FAKE_AUDIT_CALLS']=str(calls)
 result=subprocess.run(command,env=env,capture_output=True)
 raw=result.stdout+result.stderr
 path=directory/f'gates-{name}.log.gz';path.write_bytes(gzip.compress(raw,mtime=0))
 record={'command':command,'exitCode':result.returncode,'log':path.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'offlineAuditStandIns':name=='dependency'}
 if name=='dependency':
  inventory=subprocess.run(['git','ls-files','-z','--','bun.lock','**/bun.lock','package-lock.json','**/package-lock.json'],capture_output=True,check=True).stdout.decode().split('\0')
  expected=sorted(p for p in inventory if p and Path(p).is_file())
  actual=calls.read_text().splitlines();assert len(actual)==len(expected)>0
  record['expectedLockfiles']=expected;record['toolCalls']=actual
  details=Path('experiments/formal_ai_subagent/sandboxes/gates/check-javascript-dependencies.log').read_bytes()
  (directory/'gates-dependency-details.log.gz').write_bytes(gzip.compress(details,mtime=0))
  assert details.count(b'offline fixture clean verdict')==len(expected)
 (directory/f'gates-{name}.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record,indent=2));print(raw.decode());sys.exit(result.returncode)
