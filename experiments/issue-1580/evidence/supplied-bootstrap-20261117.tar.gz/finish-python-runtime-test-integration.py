from pathlib import Path
p=Path('rust/tests/web/fast-pull-request-production-profile.test.mjs');s=p.read_text()
lines=s.splitlines(keepends=True);count=0
for i,line in enumerate(lines):
 if 'assert.match(' in line and 'printf' in line and 'rust' in line:
  begin=line.index('assert.match(')+len('assert.match(');end=line.index(',/printf',begin)
  lines[i]=line[:begin]+"workflow('layered-ci.yml').jobs.js.steps.find(s=>s.id==='javascript-plan').run"+line[end:];count+=1
assert count==2;p.write_text(''.join(lines))
p=Path('rust/tests/web/issue-1580-template-observations.test.mjs');s=p.read_text()
line="import '../../../experiments/issue-1580/template-python-runtime.test.mjs';\n"
assert line not in s;p.write_text(s+line)
directory=Path('experiments/issue-1580/evidence/checks/python-runtime-provisioning')
for name in ['checks.json','fast-profile.log.gz','maintained-observations.log.gz']:
 p=directory/name;p.rename(p.with_name('draft-'+name))
print('Updated both full-inventory policy assertions to the planning step and included runtime regressions in maintained CI.')
