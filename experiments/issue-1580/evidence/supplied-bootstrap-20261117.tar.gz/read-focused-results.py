from pathlib import Path
import gzip,hashlib,json
base=Path('experiments/issue-1580/evidence/checks/main-merge-444575f2')
status=json.loads(Path('/tmp/issue-1580-research/final-444575f2-focused-status.json').read_text())
print('STATE',status['state'])
for row in status['rows']:
 raw=gzip.decompress((base/row['log']).read_bytes())
 assert hashlib.sha256(raw).hexdigest()==row['rawSha256']
 print('TEST',row['file'],'EXIT',row['exitCode'],'SECONDS',row['seconds'])
 print(raw.decode())
