from pathlib import Path
for path in sorted(Path('/tmp/issue-1580-research').glob('*')):
    if path.is_file() and path.suffix in ['.py','.mjs','.sh'] and any(word in path.name for word in ['bootstrap','merge','resolve']):
        print(path.name,path.stat().st_size)
