git diff --check
git add experiments/issue-1580/upstream/java-release-commit-integrity-report.md experiments/issue-1580/upstream/template-report-identities.json experiments/issue-1580/upstream/filed-issues.txt docs/case-studies/issue-1580/templates/README.md docs/case-studies/issue-1580/README.md experiments/issue-1580/work-plan.md
git commit -m 'docs: record published Java release integrity report'
git status --short
