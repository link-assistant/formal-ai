from pathlib import Path
import json,subprocess
base=Path('experiments/issue-1580/evidence/checks/javascript-archive-checkout')
gates=json.loads((base/'affected-gates.json').read_text());assert len(gates['commands'])==9 and all(row['exitCode']==0 for row in gates['commands'])
plan=Path('experiments/issue-1580/work-plan.md');source=plan.read_text();old='- [ ] Run affected local gates, review and commit this complete checkout/evidence batch, then publish only after checking the latest head\'s failures, feedback, main ancestry and idle workflow state.'
assert source.count(old)==1
source=source.replace(old,'- [x] Pass all eight affected local gates plus the whitespace check; literally review each complete gate log.\n- [ ] Review and commit this complete checkout/evidence batch, then publish only after checking the latest head\'s failures, feedback, main ancestry and idle workflow state.');plan.write_text(source)
body=Path('experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md');source=body.read_text();needle='Hosted checkout with the new rules remains unverified;';assert source.count(needle)==1;source=source.replace(needle,'All eight affected local gates and whitespace checks pass. Hosted checkout with the new rules remains unverified;');body.write_text(source)
checkpoint=Path('docs/case-studies/issue-1580/checkout-archive-checkpoint.md');source=checkpoint.read_text();needle='The smaller selection is locally verified. A new hosted checkout is still\nrequired;';assert source.count(needle)==1;source=source.replace(needle,'All eight affected local gates and the whitespace check pass; complete gate logs\nare literally read. The smaller selection is locally verified. A new hosted\ncheckout is still required;');checkpoint.write_text(source)
command=['git','diff','--','.github/workflows/layered-ci.yml','rust/tests/web/fast-pull-request-production-profile.test.mjs','changelog.d/20261117_120000_issue-1580-ci-regressions.md','docs/case-studies/issue-1580/checkout-archive-checkpoint.md','experiments/issue-1580/work-plan.md','experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md']
result=subprocess.run(command,capture_output=True,text=True);assert result.returncode==0
(base/'final-review.diff').write_text(result.stdout)
print(result.stdout)
