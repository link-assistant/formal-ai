from pathlib import Path
import hashlib,json,subprocess,gzip
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'packages/picomatch-compat/lib/parse.js'
s=p.read_text()
start=s.index('const hasUnboundedStar =')
end=s.index('\nconst analyzeRepeatedExtglob',start)
s=s[:start]+r'''const hasUnboundedStar = (pattern, options) => {
  let bracket = -1;
  let classStar = false;
  let quote = false;
  let escaped = false;
  for (let i = 0; i < pattern.length; i++) {
    const ch = pattern[i];
    if (escaped) {
      escaped = false;
      continue;
    }
    if (ch === '\\') {
      escaped = true;
      continue;
    }
    if (bracket !== -1) {
      // Only recognized POSIX classes consume their inner closing bracket.
      if (ch === '[' && pattern[i + 1] === ':' && options.posix !== false) {
        const end = pattern.indexOf(':]', i + 2);
        if (end !== -1 && POSIX_REGEX_SOURCE[pattern.slice(i + 2, end)]) {
          i = end + 1;
          continue;
        }
      }
      if (ch === '*') classStar = true;
      if (ch === ']' && i > bracket + 1 &&
          !(i === bracket + 2 && pattern[bracket + 1] === '^')) {
        bracket = -1;
        classStar = false;
      }
      continue;
    }
    if (ch === '"') {
      quote = !quote;
      continue;
    }
    if (quote) continue;
    // A nested "[" is literal within a class. An unclosed class is escaped by
    // the parser, so its following stars remain active wildcards.
    if (ch === '[' && options.nobracket !== true && pattern.includes(']', i + 1)) {
      bracket = i;
    } else if (ch === '*') {
      return true;
    }
  }
  return classStar;
};
''' + s[end:]
s=s.replace('branches.some(hasUnboundedStar)','branches.some(branch => hasUnboundedStar(branch, options))')
p.write_text(s)
meta=r/'packages/picomatch-compat/upstream.json'
data=json.loads(meta.read_text())
for item in data['files']:
    item['localSha256']=hashlib.sha256((meta.parent/item['path']).read_bytes()).hexdigest()
meta.write_text(json.dumps(data,indent=2)+'\n')
p=r/'rust/tests/web/picomatch-security-backport.test.mjs'
s=p.read_text()
s+='''
test('disabled bracket parsing cannot hide an active wildcard', () => {
  const pattern = '+([*])';
  assert.equal(picomatch.isMatch('[aaa]', pattern, {nobracket:true}), false);
  assert.equal(picomatch.isMatch(pattern, pattern, {nobracket:true}), true);
});
'''
p.write_text(s)
e=r/'experiments/issue-1580/evidence/checks/picomatch-single-branch'
before=Path('/tmp/issue-1580-research/picomatch-edge-before.log')
with gzip.open(e/'edge-before.log.gz','wb') as out: out.write(before.read_bytes())
(e/'edge-before.json').write_text(json.dumps({'tests':14,'pass':12,'fail':2,'exitCode':1,'sha256':hashlib.sha256(before.read_bytes()).hexdigest()},indent=2)+'\n')
log=Path('/tmp/issue-1580-research/picomatch-edge-after.log')
with log.open('w') as out:
    cp=subprocess.run(['timeout','600','node','--max-old-space-size=96','--test','--test-concurrency=1',str(p)],stdout=out,stderr=subprocess.STDOUT,cwd=r)
print(log.read_text())
with gzip.open(e/'after.log.gz','wb') as out: out.write(log.read_bytes())
(e/'after.json').write_text(json.dumps({'tests':15,'exitCode':cp.returncode,'sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'nativeExecuted':False,'authorshipCredit':0},indent=2)+'\n')
print('parse.js lines:',len((r/'packages/picomatch-compat/lib/parse.js').read_text().splitlines()))
raise SystemExit(cp.returncode)
