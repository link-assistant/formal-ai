from pathlib import Path
import json

base=Path('/tmp/issue-1580-research/templates')
for language in ['csharp','rust','js','python','php','cpp']:
 p=base/(language+'-complete-inventory.json')
 if not p.exists():
  print(language,'inventory unavailable')
  continue
 rows=json.loads(p.read_text())
 source=base/(language+'-complete')
 active=[r for r in rows if not r['path'].startswith('dev/log/')]
 stats=[]
 for r in active:
  b=(source/r['path']).read_bytes()
  try: count=len(b.decode().splitlines())
  except UnicodeDecodeError: count=None
  stats.append({'path':r['path'],'bytes':len(b),'lines':count})
 print(json.dumps({'language':language,'allFiles':len(rows),'activeFiles':len(active),'activeLines':sum(r['lines'] or 0 for r in stats)}))
 if language=='csharp':
  for r in stats: print(json.dumps(r))
