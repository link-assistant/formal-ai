from pathlib import Path
import gzip, subprocess

root=Path.cwd()
out=root/'experiments/issue-1580/evidence/checks/javascript-archive-checkout/publication-gate-correction'
out.mkdir(exist_ok=False)
for name,path in [('staged-gates',Path('/tmp/issue-1580-research/javascript-checkout-publication/staged-gates.stdout')),('abbreviation-failure',root/'experiments/formal_ai_subagent/sandboxes/gates/check-abbreviations.log')]:
    (out/(name+'.log.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
result=subprocess.run(['node','--max-old-space-size=256','scripts/measure-abbreviations.mjs','--list','file-names'],capture_output=True,text=True)
(out/'original-filename-inventory.log.gz').write_bytes(gzip.compress((result.stdout+result.stderr).encode(),mtime=0))
print(result.stdout)
print(result.stderr)
assert result.returncode==0
