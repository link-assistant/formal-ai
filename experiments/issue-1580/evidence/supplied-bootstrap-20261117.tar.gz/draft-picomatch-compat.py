from pathlib import Path
import json,hashlib,shutil,subprocess,gzip,os,time
source=Path("/tmp/issue-1580-research/picomatch/package")
target=Path("packages/picomatch-compat")
assert not target.exists()
target.mkdir()
paths=["LICENSE","index.js","posix.js","lib/constants.js","lib/parse.js","lib/picomatch.js","lib/scan.js","lib/utils.js"]
files=[]
for name in paths:
 raw=(source/name).read_bytes()
 p=target/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 files.append({"path":name,"originalSha256":hashlib.sha256(raw).hexdigest(),"bytes":len(raw)})
metadata=json.loads(Path("/tmp/issue-1580-research/picomatch/npm-latest.json").read_text())
manifest={"name":"@formal-ai/picomatch-compat","version":"4.0.7-formal-ai.1","private":True,"description":"Picomatch 4.0.7 with a single-branch repeated-extglob security backport","license":"MIT","main":"index.js","engines":{"node":">=12"},"files":["index.js","posix.js","lib","LICENSE","upstream.json","README.md"]}
(target/"package.json").write_text(json.dumps(manifest,indent=2)+"\n")
(target/"upstream.json").write_text(json.dumps({"package":"picomatch","version":"4.0.7","tarball":metadata["dist"]["tarball"],"integrity":metadata["dist"]["integrity"],"sha1":metadata["dist"]["shasum"],"advisory":"https://github.com/advisories/GHSA-fc5q-39xc-vjpf","files":files,"modifiedFiles":["lib/parse.js"],"scope":"Draft: extend the existing repeated-extglob guard; this is not an upstream release."},indent=2)+"\n")
test=Path("rust/tests/web/picomatch-security-backport.test.mjs")
test.write_text(r'''import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import test from 'node:test';

const require = createRequire(import.meta.url);
const entry = fileURLToPath(new URL('../../../packages/picomatch-compat/index.js', import.meta.url));
const picomatch = require(entry);
const posix = require('../../../packages/picomatch-compat/posix.js');
const risky = ['+(*)', '*(*a)', '+(*a)', '+(a*)', '+(*a|b)', '+(@(*a))'];

for (const pattern of risky) {
  test('literalizes unsafe repeated wildcard: ' + pattern, {timeout:5000}, () => {
    assert.equal(picomatch.isMatch(pattern, pattern), true);
    assert.equal(picomatch.isMatch('aaaa', pattern), false);
    assert.equal(posix.isMatch(pattern, pattern), true);
  });
}

for (const pattern of ['+(*)', '+(*a)']) {
  test('bounded hostile match terminates: ' + pattern, {timeout:5000}, () => {
    const script = 'const pm=require(' + JSON.stringify(entry) + ');' +
      'if(pm.isMatch("a".repeat(40)+"/!",' + JSON.stringify(pattern) + '))process.exit(2);' +
      'if(pm.isMatch("a".repeat(40)+"!",' + JSON.stringify(pattern) + '))process.exit(3);';
    const child = spawnSync(process.execPath,
      ['--max-old-space-size=64', '--stack-size=256', '-e', script],
      {timeout:1250, killSignal:'SIGKILL', maxBuffer:4096});
    assert.equal(child.error, undefined, String(child.error));
    assert.equal(child.signal, null);
    assert.equal(child.status, 0, String(child.stderr));
  });
}

test('ordinary glob paths, ignore, dotfiles and callbacks remain supported', () => {
  const matched = [];
  const match = picomatch('src/**/*.js', {
    dot:true, ignore:'**/vendor/**', onMatch:result => matched.push(result.input),
  });
  assert.equal(match('src/a.js'), true);
  assert.equal(match('src/.hidden/a.js'), true);
  assert.equal(match('src/vendor/a.js'), false);
  assert.equal(match('src/a.txt'), false);
  assert.deepEqual(matched, ['src/a.js', 'src/.hidden/a.js']);
});

test('literal and flattened repeated extglobs retain their meaning', () => {
  assert.equal(picomatch.isMatch('abab', '+(ab)'), true);
  assert.equal(picomatch.isMatch('abac', '+(ab)'), false);
  assert.equal(picomatch.isMatch('abba', '+(*(a)|*(b))'), true);
  assert.equal(picomatch.isMatch('***', '+(\\*)'), true);
  assert.equal(picomatch.isMatch('***', '+([*])'), true);
  assert.equal(picomatch.isMatch('+(*a)', '+(*a)', {noextglob:true}), true);
});

test('public scan, parse, regex and platform entrypoints remain usable', () => {
  assert.equal(picomatch.scan('src/**/*.js').base, 'src');
  assert.equal(typeof picomatch.parse('*.js').output, 'string');
  assert.equal(picomatch.makeRe('*.js').test('a.js'), true);
  assert.equal(picomatch.makeRe('*.js').test('a.txt'), false);
  assert.equal(picomatch.isMatch('SRC/A.JS', 'src/*.js', {nocase:true}), true);
  assert.equal(posix.isMatch('src/a.js', 'src/**/*.js'), true);
});
''')
root=Path("experiments/issue-1580/evidence/checks/picomatch-single-branch")
root.mkdir(parents=True,exist_ok=True)
for name in ["picomatch-advisory.json"]:
 shutil.copyfile(Path("/tmp/issue-1580-research")/name,root/name)
for name in ["npm-latest.json","latest-release.json"]:
 shutil.copyfile(Path("/tmp/issue-1580-research/picomatch")/name,root/name)
env=dict(os.environ);env["NODE_OPTIONS"]="--max-old-space-size=96"
command=["timeout","600","node","--test","--test-concurrency=1",str(test)]
started=time.monotonic();r=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(root/"before.log.gz").write_bytes(gzip.compress(r.stdout,mtime=0))
(root/"before.json").write_text(json.dumps({"command":command,"status":r.returncode,"durationSeconds":round(time.monotonic()-started,3),"rawSha256":hashlib.sha256(r.stdout).hexdigest(),"nodeHeapMiB":96,"childHeapMiB":64,"childStackKiB":256,"childTimeoutMilliseconds":1250,"maxSubjectBytes":42,"autonomousAuthorshipCredit":0},indent=2)+"\n")
print(r.stdout.decode())
assert r.returncode!=0
