from pathlib import Path
import collections
import gzip
import hashlib
import json

root = Path('/tmp/issue-1580-research/templates/python-complete')
inventory = json.loads(Path('/tmp/issue-1580-research/python-active-source-inventory.json').read_text())
deferred = {'.github/actions/artifact/dist/835.index.mjs', '.github/actions/artifact/dist/index.mjs', '.github/actions/artifact/package-lock.json', 'uv.lock'}
full_extra = {'scripts/create_manual_changeset.py', 'scripts/version_and_commit.py'}
decisions = {
    '.gitattributes': 'Preserve generated bundle bytes; the scoped whitespace exception does not waive handwritten-source checks.',
    '.github/actionlint.yaml': 'Read narrow runner/queue/self-repository compatibility exceptions. Valid $/ syntax is already handled by the repaired Formal AI review graph; do not report it as invalid.',
    '.github/actions/artifact/action.yml': 'Read the Node 24 transfer contract and fatal missing-file policy. Retain verified artifact identity and explicit download inputs in Formal AI.',
    '.github/actions/artifact/dist/extract.py': 'Read the exact bundled extractor: prevalidate paths, links, modes, duplicates and file/directory conflicts, then create exclusively. Archive expansion/resource limits remain an unexecuted question.',
    '.github/actions/artifact/dist/licenses.txt': 'Read bundled MIT/Apache/0BSD license notices. Preserve attribution; license text is not evidence of transport behavior.',
    '.github/actions/artifact/extract.py': 'Read handwritten extractor, matching its bundled copy. Preserve traversal/symlink rejection and exclusive output creation; no extraction runtime result is claimed here.',
    '.github/actions/artifact/files.mjs': 'Read sorted native-glob discovery, hidden/link pruning, common-root handling and finally-cleaned Pages tar packaging. Tar dereference policy is an unexecuted source question, not a reproduced defect.',
    '.github/actions/artifact/index.mjs': 'Read explicit upload/download dispatch, exact or pattern selection, artifact-name validation, digest handling and output-after-completion. Generated main bundle remains unread.',
    '.github/actions/artifact/package.json': 'Read exact SDK/core/glob/build/scanner pins and override tree. Tooling Node/npm engines and action Node 24 ABI have distinct roles; do not infer incompatibility without execution.',
    '.github/actions/artifact/transport.mjs': 'Read bounded transient-only retry, auth/quota/conflict refusal, unique-name upload cleanup, required digest match, exact archive count and temporary cleanup. Preserve terminal errors; unique-producer races and partial extraction remain unexecuted questions.',
    '.github/actions/deploy-pages/action.yml': 'Read Node 24 deployment inputs/outputs. Preserve explicit artifact ID; no real deployment is authorized by source review.',
    '.github/actions/deploy-pages/deploy.mjs': 'Read bounded REST/OIDC requests through response bodies, transient-only creation retries, commit-based duplicate recovery, poll/error budgets, cancellation and escaped failure annotations. No real provider call was executed.',
    '.github/actions/deploy-pages/index.mjs': 'Read main rejection propagation to a failing action result; retain fail-closed deployment behavior.',
    '.github/codeql/codeql-config.yml': 'Read generated-bundle and experiment exclusions while scanning original action source. Do not count exclusion as runtime/security completion.',
    '.github/dependabot.yml': 'Read weekly/cooldown/group policy for Actions, npm, uv, docs pip and pre-commit. Committed bundle changes still require rebuild validation.',
    '.github/workflows/dependabot-health.yml': 'Read scoped PR unit tests, schedule/manual actual health checks and terminal status aggregation. Preserve pinned runners and explicit skipped scope in Formal AI.',
    '.github/workflows/docs.yml': 'Read strict Sphinx build, artifact retention, main-only opt-in Pages deployment, serialized writes and terminal status. Retain Formal AI default-branch effect policy; installer PATH propagation still needs helper review.',
    '.github/workflows/links.yml': 'Read daily restore/main-only save, independent checksum pins, transient recheck, advisory archive fallback, real live-link failure and terminal aggregation. Preserve terminal HTTP errors and unchanged failure verdicts.',
    '.github/workflows/release.yml': 'Read all 1017 lines: root/nested paths, dispatch admission, prerequisites, report/release preflight, locked lint/test/build, size and published-package checks, serialized source writers, native-architecture publishing and terminal status. Retain Formal AI PR build/Docker prohibition; source helpers and live publication remain incompletely verified.',
    '.github/workflows/security.yml': 'Read resolved Python/npm audits, full-source CodeQL with findings gate/report retention, availability-aware dependency review and terminal aggregation. Keep existing Formal AI security gates and truthful unavailable states.',
    '.github/workflows/workflows.yml': 'Read pinned actionlint image, regular and narrow pedantic zizmor, isolated ShellCheck, mocked transport/Pages tests, bundle reproducibility and actual byte-roundtrip jobs. Preserve scoped compatibility exceptions; these upstream hosted paths were not executed here.',
    '.github/zizmor.yml': 'Read trusted publisher tag policy and hash pinning for all others. Keep explicit repository security policy rather than broad exemptions.',
    'scripts/create_manual_changeset.py': 'Read all 249 lines and execute the complete unchanged entrypoint with real local Git and a frozen clock. Same-second writes silently erase the earlier category/description. A disposable exclusive-create guard preserves existing bytes and fails; 4 focused and 29 maintained cases pass. Upstream remains unchanged. Formal AI Rust timestamp writes remain an unexecuted source question.',
    'scripts/version_and_commit.py': 'Read all 615 lines: failed commands/commit propagate, full source/dependency attestation admits only metadata children, policy errors remain terminal, transient retries preserve identity, lost source races dispatch fresh validation, and publication outputs follow push. No Git race, redispatch or release runtime execution is claimed for this review.',
}
files = []
offset = 0
for category in ['active', 'historical']:
    for entry in inventory[category]:
        row = dict(entry)
        data = (root / row['path']).read_bytes()
        assert len(data) == row['bytes']
        assert hashlib.sha256(data).hexdigest() == row['sha256']
        assert hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest() == row['gitBlob']
        assert len(data.decode().splitlines()) == row['lines']
        read = 0
        if category == 'active' and row['path'] not in deferred:
            read = max(0, min(row['lines'], 3200 - offset))
            offset += row['lines']
        if row['path'] in full_extra:
            read = row['lines']
        row['readRanges'] = [[1, read]] if read else []
        if category == 'historical':
            row['reviewStatus'] = 'historical-unread'
            row['decision'] = 'Identity verified; historical report/log/source content remains semantically unread.'
        elif read and read == row['lines']:
            row['reviewStatus'] = 'active-source-fully-read'
            row['decision'] = decisions[row['path']]
        elif read:
            row['reviewStatus'] = 'active-source-partially-read'
            row['decision'] = 'Read the opening 80 ignore rules; remaining rules are explicitly unread. This does not establish complete configuration review.'
        else:
            row['reviewStatus'] = 'active-source-unread'
            row['decision'] = 'Identity verified; semantic reading is pending. Generated bundles and lockfiles are not silently credited as complete.'
        files.append(row)
assert offset == 21394 and len(files) == 329
counts = dict(collections.Counter(row['reviewStatus'] for row in files))
read_lines = sum(end - start + 1 for row in files for start, end in row['readRanges'])
assert read_lines == 4064
record = {
    'repository': 'link-foundation/python-ai-driven-development-pipeline-template',
    'commit': 'c532c173801dfb12e681b0730c4abbf93aefd0ca',
    'coverage': 'PARTIAL. Every blob is hash verified; all six workflows are fully read. Active transitive helpers/tests/configuration/application source, both generated JavaScript bundles, both locks and every historical blob still require further review. No complete Python repository review or live publication acceptance is claimed.',
    'counts': counts,
    'activeReadLines': read_lines,
    'activeTotalLines': 44284,
    'historicalTotalLines': 41260,
    'readMethod': 'Corrected ordered active-source pages 1-8 (400 lines each) were fully read, plus create_manual_changeset.py 1-249 and version_and_commit.py 1-400/401-615. The initial unbounded minified-bundle preview receives no full-page credit. Complete driver transcripts retain source output. Tool-truncated context-inspection output was reread in bounded parts before crediting it.',
    'runtimeEvidence': 'Only the four-case frozen-clock Python entrypoint fixture, real local Git initialization, and the existing 29-case maintained Node entrypoint were executed. Python children have 128 MiB address-space and 3 CPU-second limits. Upstream full suites, build/bundle regeneration, provider APIs and publication were not executed.',
    'authorship': 'Codex supplied all review decisions, experiments, commands and edits; zero independent Formal AI reasoning credit.',
}
path = Path('docs/case-studies/issue-1580/templates/python-partial-semantic-review.json')
assert not path.exists()
header = json.dumps(record, indent=2)[:-2]
path.write_text(header + ',\n  "files": [\n' + ',\n'.join('    ' + json.dumps(row, separators=(',', ':')) for row in files) + '\n  ]\n}\n')
assert json.loads(path.read_text())['activeReadLines'] == read_lines

directory = Path('experiments/issue-1580/evidence/checks/python-fragment-collision')
logs = []
for path in sorted(directory.glob('*.log.gz')):
    data = gzip.decompress(path.read_bytes())
    logs.append({'path': str(path), 'compressedSha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'rawSha256': hashlib.sha256(data).hexdigest(), 'rawBytes': len(data), 'rawLines': len(data.splitlines())})
evidence = {
    'regression': 'experiments/issue-1580/template-python-fragment-integrity.test.mjs',
    'maintainedEntrypoint': 'rust/tests/web/issue-1580-template-observations.test.mjs',
    'source': json.loads(Path('experiments/issue-1580/fixtures/python-template/source.json').read_text()),
    'before': {'passed': 3, 'failed': 1, 'skipped': 0, 'failingCase': 'candidate rejects a same-second collision and preserves the earlier bytes', 'logLines': [8, 33]},
    'after': {'passed': 4, 'failed': 0, 'skipped': 0},
    'maintained': {'passed': 29, 'failed': 0, 'skipped': 0},
    'harnessCorrection': 'The first invocation used Node default reporter output and the wrapper incorrectly expected TAP summary prefixes. Preserve initial-reporter.*; explicitly select --test-reporter=tap. The actual first run already had the expected 3-pass/1-fail preservation result. No source bug or passing test was fabricated from the parser error.',
    'bounds': {'pythonAddressSpaceBytes': 134217728, 'pythonCpuSeconds': 3, 'childWallMilliseconds': 5000, 'testWallMilliseconds': 15000},
    'upstreamRepairClaimed': False,
    'formalAiNativeFragmentBehaviorExecuted': False,
    'duplicateAndLatestSourceCheck': str(directory / 'duplicate-and-source-check.json'),
    'logs': logs,
}
Path('experiments/issue-1580/evidence/checks/python-fragment-integrity.json').write_text(json.dumps(evidence, indent=2) + '\n')

readme = Path('docs/case-studies/issue-1580/README.md')
text = readme.read_text()
old = 'The next published head still needs hosted verification.'
assert old in text
text = text.replace(old, 'All 24 workflows on `b79dc1e0f147ed57d8e317c1b93bfa6ffc79078d` subsequently passed; the complete successful Layered CI log retains the passing ratchet at line 7074. Exact-head metadata and the full compressed log are retained under `experiments/issue-1580/evidence/ci/b79dc1e0f/`. These scoped results do not verify main-only acceptance.')
text += f'''\n### Partial Python review and fragment preservation\n\nThe [Python checkpoint](templates/python-partial-semantic-review.json) verifies all 329 blobs and records {counts['active-source-fully-read']} fully read active files plus one partial file ({read_lines:,} of 44,284 active lines), including all six workflows and two separately read release helpers. The other active files, generated bundles/locks and all 126 historical blobs remain semantically unread. This is not complete transitive CI review.\n\nThe unchanged manual fragment entrypoint silently overwrites the earlier category and description when two valid invocations share the same second, Git user and branch. A frozen-clock regression uses the complete pinned source and real local Git, with bounded Python processes. The preservation case fails before a disposable exclusive-create guard; four focused cases and the maintained 29-test entrypoint pass afterward, with no skips. Distinct-time and invalid-input controls preserve intended behavior. Full before/after logs, source identities, the initial reporter parsing correction, fresh source verification and duplicate checks are indexed in `experiments/issue-1580/evidence/checks/python-fragment-integrity.json`. The upstream source is unchanged; publish immutable executable evidence before filing the report. Formal AI's analogous Rust timestamp/nonexclusive-write path remains an unexecuted source question. All broader criteria remain active.\n'''
readme.write_text(text)
template_readme = Path('docs/case-studies/issue-1580/templates/README.md')
text = template_readme.read_text()
old = 'the current suite passes twenty-five with reference-graph and C# changeset coverage, with no runtime skips.'
new = 'the C# checkpoint passed twenty-five; the current suite passes twenty-nine with Python fragment-preservation coverage, with no runtime skips.'
assert old in text
text = text.replace(old, new)
text += f'''\n## Partial Python active review and manual fragment loss\n\n[`python-partial-semantic-review.json`](python-partial-semantic-review.json) records {counts['active-source-fully-read']} fully read active files and one partial file, {read_lines:,}/44,284 active lines and all six workflows. All 329 blobs are reverified. The remaining active helpers/tests/configuration/application source, generated bundles/locks and 126 historical blobs remain semantically unread. Per-file decisions retain Formal AI's default-branch build/effect policy and distinguish source observations from execution.\n\nThe complete pinned `create_manual_changeset.py --no-scriv` entrypoint loses an earlier fragment when the same Git identity/branch creates two entries during one second. Both commands return success; the later file replaces the first category and description. A disposable exclusive-create guard rejects the collision and preserves the prior exact bytes. Four focused cases and the maintained 29-case entrypoint pass, without skips; the negative preservation control fails once before the guard. Distinct timestamps and invalid arguments retain intended results. Original source/Unlicense identities, full logs, the initial default-reporter parsing correction and current-main/duplicate checks are retained in `experiments/issue-1580/evidence/checks/python-fragment-integrity.json`. Related validator #100/#101, release-recovery #148 and dependency-locking #152 address different boundaries. Publish the executable evidence before filing this distinct report. No upstream fix, full Python runtime suite or native Formal AI fragment execution is claimed.\n'''
template_readme.write_text(text)
work_plan = Path('experiments/issue-1580/work-plan.md')
work_plan.write_text(work_plan.read_text() + f'''\n## Python partial review and fragment collision checkpoint\n\nAll 24 hosted workflows on `b79dc1e0f` passed, including the abbreviation ratchet at full successful Layered CI log line 7074; retain complete logs and metadata. Python: all 329 blobs reverified, all six workflows and two release helpers read; {counts['active-source-fully-read']} active files fully read, one partial, {read_lines:,}/44,284 active lines. Generated bundles/locks, remaining active source and 126 historical blobs remain unread. Reproduce silent same-second fragment overwrite through the complete original entrypoint and real local Git. Before preservation control: 3 pass / 1 fail; disposable exclusive-create guard: 4 pass; maintained entrypoint: 29 pass; no skips. Preserve the initial default-reporter parsing failure and explicitly select TAP. Current upstream helper remains byte-identical; related #100/#101/#148/#152 are distinct. Publish immutable evidence before filing. Formal AI Rust fragment creation is still an unexecuted source question. All native, benchmark, warning, identity and full-review acceptance criteria remain active.\n''')
print(json.dumps({'reviewCounts': counts, 'activeReadLines': read_lines, 'activeTotalLines': 44284, 'verifiedBlobs': len(files), 'regressionLogs': logs, 'issueComplete': False}, indent=2))
