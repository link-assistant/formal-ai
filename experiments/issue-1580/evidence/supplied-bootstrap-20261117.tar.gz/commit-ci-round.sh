set -eu
test "$(git branch --show-current)" = issue-1580-8d61a32a61e1
git fetch origin main issue-1580-8d61a32a61e1
git merge-base --is-ancestor origin/main HEAD
rustfmt --edition 2024 --check rust/src/solver.rs
if ! gh pr diff 1581 --repo link-assistant/formal-ai > /tmp/issue-1580-research/pr-reviewed-before-ci-round.diff 2> /tmp/issue-1580-research/pr-diff-limit.log; then
  gh api repos/link-assistant/formal-ai/pulls/1581/files --paginate --slurp > /tmp/issue-1580-research/pr-files-current.json
  git diff origin/main...HEAD > /tmp/issue-1580-research/pr-reviewed-before-ci-round.diff
fi
python3 experiments/issue-1580/archive-evidence.py
git diff --check
git diff --stat
git add scripts/documentation-only-ci-policy.mjs rust/tests/web/documentation-only-ci-policy.test.mjs rust/src/solver.rs experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8 docs/case-studies/issue-1580/README.md experiments/issue-1580/work-plan.md changelog.d/20261117_120000_issue-1580-ci-regressions.md experiments/issue-1580/evidence/checks experiments/issue-1580/evidence/ci/dd334ef6a experiments/issue-1580/evidence/commands
git diff --cached --check
git commit -m 'fix(ci): repair documentation admission and governed source checks'
git status --short
git rev-parse HEAD
