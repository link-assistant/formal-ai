from pathlib import Path
import gzip,hashlib,json
root=Path.cwd();research=Path('/tmp/issue-1580-research');checks=root/'experiments/issue-1580/evidence/checks'
records=[]
for name in ['cache-log-before.log','cache-log-after.log','cache-log-shellcheck.log','cache-log-gates.log']:
 raw=(research/name).read_bytes();payload=gzip.compress(raw,mtime=0);destination=checks/(name+'.gz');destination.write_bytes(payload)
 records.append({'file':str(destination.relative_to(root)),'sha256':hashlib.sha256(payload).hexdigest(),'originalSha256':hashlib.sha256(raw).hexdigest(),'originalBytes':len(raw)})
(checks/'cache-log-retention.json').write_text(json.dumps({'scope':'Actual shell health script and budget wrapper with mock cache/command processes; no Rust build, hosted cache access or causal backend claim.','before':{'testExit':1,'passed':9,'failed':2,'skipped':0},'after':{'testExit':0,'passed':12,'failed':0,'skipped':0},'shellcheck':{'version':'0.11.0','exit':0},'touchedGates':{'passed':5,'failed':0,'skipped':0},'logs':records},indent=2)+'\n')
p=root/'docs/case-studies/issue-1580/README.md';text=p.read_text();needle='## Full template comparison';assert needle in text
text=text.replace(needle,'''## Retained cache backend diagnostics

An opt-in logging rerun previously wrote the server response to a runner-local file that the budget wrapper's health check never retained in job output. Two behavioral regressions reproduce the missing evidence before the fix (nine passes, two failures). The health check now retains the last 64 KiB and at most 80 lines whenever existing `FORMAL_AI_CI_VERBOSE=true` logging is enabled, including when statistics are unavailable. URLs are redacted; a fresh 128-bit stop/resume token suspends workflow commands while printing backend text. Default mode remains quiet.

Twelve tests pass afterward, including actual wrapper success/failure outcomes, output bounds, missing logs, token renewal and unchanged warning counts. The verified ShellCheck binary and all five touched gates pass. Complete logs and identities are in `checks/cache-log-retention.json`. This repairs evidence retention; no new hosted backend response has been observed and the historical cache failure cause remains unresolved.

'''+needle)
text=text.replace('`sccache-outage-fallback.test.mjs`: eight passing tests, including three subprocess tests of the actual checker','`sccache-outage-fallback.test.mjs`: twelve passing tests, including actual health-check and budget-wrapper subprocesses')
p.write_text(text)
p=root/'experiments/issue-1580/work-plan.md';p.write_text(p.read_text()+'''
## Opt-in cache evidence retention

Reproduced the missing backend log in two failing subprocess controls, then retained a bounded URL-redacted tail through the existing health check, including early exits when statistics fail. Fresh workflow-command suspension tokens protect diagnostic output. Twelve regression cases pass, including actual budget-wrapper exit-code preservation; ShellCheck and five touched gates pass. This is prospective evidence collection only: historical cache-backend causality and other broad criteria remain open.
''')
p=root/'changelog.d/20261117_120000_issue-1580-ci-regressions.md';p.write_text(p.read_text()+'- Retain bounded opt-in compiler-cache backend diagnostics in hosted logs, including missing statistics, while preserving command outcomes and redacting signed URLs.\n')
print(json.dumps({'archivedLogs':len(records),'testsPassed':12,'gatesPassed':5,'historicalCauseVerified':False}))
