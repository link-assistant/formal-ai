from pathlib import Path
import gzip,hashlib,json,subprocess

branch='issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()==branch
data=Path('/tmp/issue-1580-research/self-reference-checks/archive-gates.log').read_bytes()
assert b'2/2 passed or skipped; failed: none' in data and b'SKIP' not in data
packed=gzip.compress(data,mtime=0)
folder=Path('experiments/issue-1580/evidence/checks')
(folder/'self-repository-reference-archive-gates.log.gz').write_bytes(packed)
(folder/'self-repository-reference-archive-gates.json').write_text(json.dumps({'command':'node experiments/formal_ai_subagent/local-gates.mjs --only check-file-size,check-file-size-js-twin','pass':2,'fail':0,'skip':0,'file':'self-repository-reference-archive-gates.log.gz','sha256':hashlib.sha256(data).hexdigest(),'compressedSha256':hashlib.sha256(packed).hexdigest(),'limits':'Archive-size checks only; substantive source checks retained separately.'},indent=2)+'\n')
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','experiments/issue-1580/evidence/commands','experiments/issue-1580/evidence/supplied-bootstrap-20261117.json','experiments/issue-1580/evidence/supplied-bootstrap-20261117.tar.gz','experiments/issue-1580/evidence/checks/self-repository-reference-archive-gates.log.gz','experiments/issue-1580/evidence/checks/self-repository-reference-archive-gates.json'],check=True)
subprocess.run(['git','commit','-m','docs: preserve self-repository regression and supplied execution evidence'],check=True)
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],check=True)
for status in ['in_progress','queued']:
    rows=json.loads(subprocess.check_output(['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--status',status,'--limit','100','--json','databaseId,workflowName,headSha'],text=True))
    print(status,len(rows))
    assert not rows
subprocess.run(['git','push','origin','HEAD:refs/heads/'+branch],check=True)
print('published',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
