from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
queries=[['rg','-n','function tryMemoryWrite|calendar_request_span|try_calendar_create_event|calendar_create','js/worker/formal_ai_worker_memory.js','rust/src/solver_handlers/conversation_memory.rs'],['rg','--files','js/worker','rust/src/solver_handlers']]
for q in queries:
 r=subprocess.run(q,cwd=root,capture_output=True,text=True)
 lines=r.stdout.splitlines();print('\n'.join(x for x in lines if 'memory' in x or 'calendar' in x));print(r.stderr)
