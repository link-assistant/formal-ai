from pathlib import Path
import subprocess,json,datetime,hashlib,gzip

def run(args):return subprocess.run(args,capture_output=True,text=True,check=True).stdout
repo='link-assistant/formal-ai';branch='issue-1580-8d61a32a61e1';head='624812120feee0180bf9df8164f87e73326b5cb8'
assert run(['git','branch','--show-current']).strip()==branch
assert run(['git','rev-parse','HEAD']).strip()==head
run(['git','fetch','origin','main']);run(['git','merge-base','--is-ancestor','origin/main','HEAD'])
assert run(['git','ls-remote','--heads','origin',f'refs/heads/{branch}']).split()[0]==head
runs=json.loads(run(['gh','run','list','--repo',repo,'--branch',branch,'--commit',head,'--limit','100','--json','databaseId,workflowName,status,conclusion,createdAt,headSha']))
assert len(runs)==24 and all(r['headSha']==head and r['status']=='completed' and r['conclusion']=='success' for r in runs)
created=datetime.datetime.fromisoformat(run(['git','show','-s','--format=%cI',head]).strip())
assert all(datetime.datetime.fromisoformat(r['createdAt'].replace('Z','+00:00'))>=created for r in runs)
for status in ['in_progress','queued']:
 active=json.loads(run(['gh','run','list','--repo',repo,'--branch',branch,'--status',status,'--limit','100','--json','databaseId,workflowName,headSha']))
 assert not active,active
feedback={}
for key,endpoint in [('issueComments','issues/1580/comments'),('conversationComments','issues/1581/comments'),('inlineComments','pulls/1581/comments'),('reviews','pulls/1581/reviews')]:
 pages=json.loads(run(['gh','api',f'repos/{repo}/{endpoint}?per_page=100','--paginate','--slurp']));items=[item for page in pages for item in page]
 prior=json.loads(Path(f'/tmp/issue-1580-research/python-fragment-{key}.json').read_text())
 fields=lambda values:[(v['id'],v.get('body'),v.get('state'),v.get('updated_at')) for v in values]
 assert fields(items)==fields(prior),'New feedback requires reading: '+key
 feedback[key]={'count':len(items),'sha256':hashlib.sha256(json.dumps(fields(items),sort_keys=True).encode()).hexdigest()}
record={'previousHead':head,'previousWorkflowsPassed':len(runs),'activeOrQueued':0,'freshMain':run(['git','rev-parse','origin/main']).strip(),'feedback':feedback,'pullRequest':'https://github.com/link-assistant/formal-ai/pull/1581','acceptanceComplete':False}
Path('experiments/issue-1580/evidence/checks/python-runtime-provisioning/preflight.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
