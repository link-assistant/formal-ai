set -eu
git branch --show-current
git status --short
wc -l experiments/issue-1580/work-plan.md
sed -n '1,220p' experiments/issue-1580/work-plan.md
