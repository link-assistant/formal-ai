from pathlib import Path
import gzip,json

for name in [
    '/tmp/issue-1580-research/child-evidence-all-gates/worker.log',
    '/tmp/issue-1580-research/child-evidence-publication-preflight/worker.log',
]:
    path=Path(name)
    print('\nFILE',path)
    print(path.read_text())
for name in [
    'experiments/issue-1580/evidence/checks/child-evidence-provenance/all-gates/results.json',
    'experiments/issue-1580/evidence/checks/child-evidence-provenance/publication-preflight/outcome.json',
]:
    path=Path(name)
    print('\nFILE',path)
    if path.exists():
        value=json.loads(path.read_text())
        print(json.dumps({key:item for key,item in value.items() if key not in ['checks','records']},indent=2))
    else:print('PENDING')
path=Path('/tmp/issue-1580-research/child-evidence-all-gates/all-gates.log')
lines=path.read_text().splitlines()
print('\nAGGREGATE LINES',len(lines))
print('\n'.join(lines if len(lines)<160 else lines[-30:]))
