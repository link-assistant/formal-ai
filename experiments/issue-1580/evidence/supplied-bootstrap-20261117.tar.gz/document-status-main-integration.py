from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json

root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/checks/unverified-child-status'
native=json.loads((base/'native-target-review/commit.json').read_text())
assert native['head']=='26f3f332aeffb7ced6985e58e682b209a71346c7'
assert json.loads((base/'native-target-review/outcome.json').read_text())['complete']
history=json.loads((base/'java-history-93-100/review-summary.json').read_text())
assert (history['literalPages'],history['completeFiles'],history['partialFiles'],history['literalLines'])==(100,106,1,6862)
path=base/'pull-request-description.md'
before=path.read_bytes()
(base/'main-update/pre-main-pull-request-description.md.gz').write_bytes(gzip.compress(before,mtime=0))
text=before.decode()
text=text.replace('Main `015a683197c89e8f74375b097e8dd06a57dcea8f` is merged.','Main `19235c49abaf1e71aad89e4badbe1f9bba5d4786` is merged, including its forced-function HTTP and native coverage. Preserve the required job context for source-free changes and condition every compile-dependent step.')
needle='- Retain bounded compiler-cache diagnostics;'
index=text.index(needle)
text=text[:index]+'- Add the existing four-test `meta_executor_parity` module as an isolated native CI target beside calendar/currency and forced functions. Replay all 29 shared cases and their complete event sequences; native execution on the new head remains pending CI.\n'+text[index:]
needle='Latest reproduction and verification:\n\n'
assert text.count(needle)==1
text=text.replace(needle,needle+'- After merging current main and adding the isolated native target, all **84 tests in six focused JavaScript files**, both fixture currency checks, Rust 2024 formatting and whitespace checks pass. The full 138-entry local run records **85 passes, 52 explicit exclusions and one abbreviated-evidence-filename failure**. Rename only those two archives without changing their bytes or the limit, then pass all **four affected gates**. Preserve the failed aggregate and correction separately. No local Rust build runs; the new hosted native target is pending publication.\n')
old='Java historical literal review covers **92/254 continuous pages**, 87 complete files, 1 partial file and 5,792 literally reviewed source lines; pages 93–254 remain unread.'
new='Java historical literal review covers **100/254 continuous pages**, 106 complete files, 1 partial file and 6,862 literally reviewed source lines; pages 101–254 remain unread.'
assert old in text
text=text.replace(old,new)
assert text.count('Fixes #1580')==1
path.write_text(text)
checkpoint=root/'docs/case-studies/issue-1580/task-quotation-checkpoint.md'
checkpoint.write_text(checkpoint.read_text()+'''
The pre-push main update advances to `19235c49abaf1e71aad89e4badbe1f9bba5d4786`.
Review every incoming source change and preserve the full 7,123-line diff.
Resolve the workflow and policy-test conflict by retaining both isolated native
targets and the required-context admission conditions, including the incoming
Node setup and native HTTP replay. Preserve the upstream development log bytes.
Refresh the governed witness through its maintained writer after comparing every
inventory object; only four Cargo manifest fixture hashes change.

Add the existing executor parity module as a third isolated native target. It
replays all 29 shared cases with complete events and retains its three production
composition/language tests. Commit the target, workflow, policy test, documentation
and reviewed Cargo fingerprint as `26f3f332aeffb7ced6985e58e682b209a71346c7`.
Native execution of this target remains pending hosted CI; no local compiler runs.

After main integration, all 84 tests in six focused JavaScript files pass. Both
fixtures are current, and Rust 2024 formatting and whitespace pass. The full
138-entry run records 85 passes, 52 explicit exclusions and one abbreviation
failure from two newly archived filenames. Rename those archives using full
words, preserve their compressed and raw bytes and original source paths, and
pass all four affected gates. Retain the failed run and correction separately.
Peak child RSS is 1,116,156 KiB, with no OOM or OOM-kill count change.

Java historical literal review now covers continuous pages 1–100/254, with 106
complete files, one partial file and 6,862 source lines. Pages 101–254 remain
unread; historical catalogs do not prove current compatibility or execution.
All broader unfinished criteria and the 0/20 independent acceptance result remain.
''')
plan=root/'experiments/issue-1580/work-plan.md'
plan.write_text(plan.read_text()+'''
- [x] Preserve the stopped publication attempt, merge current main `19235c49`, review all incoming source changes and resolve workflow/policy conflicts without dropping required-context admission or either native regression target.
- [x] Add isolated native executor parity CI using the existing four-test module and all 29 shared cases, with complete event comparisons; preserve complete governed-object equality apart from four Cargo fixture identities. Native execution remains pending hosted CI.
- [x] Pass 84 focused JavaScript tests, both fixture checks, Rust 2024 formatting and whitespace after integration. Preserve the full local run's 85 passes, 52 exclusions and one evidence-filename failure; correct only those two names and pass four affected gates without raising limits.
- [ ] Publish this combined round once after a fresh main/feedback/run check, then collect and review every current-head CI result, including the new native target.
''')
report={'observedAt':datetime.now(timezone.utc).isoformat(),'sourceHead':native['head'],'mainMerged':'19235c49abaf1e71aad89e4badbe1f9bba5d4786','focusedTestsPassed':84,'fullLocalInventory':{'pass':85,'excluded':52,'fail':1},'correctionGatesPassed':4,'nativeExecuted':False,'hostedCiPendingPublication':True,'javaLiteralPages':100,'fullIssueComplete':False,'independentAuthorshipCredit':0,'previousBodySha256':hashlib.sha256(before).hexdigest(),'newBodySha256':hashlib.sha256(path.read_bytes()).hexdigest()}
(base/'main-update/documentation-update.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
