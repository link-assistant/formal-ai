set -eu
export NODE_PATH=/tmp/issue-1580-research/node_modules
set +e
node experiments/formal_ai_subagent/local-gates.mjs --only check-file-size,check-file-size-js-twin,check-changelog-fragment-js-twin,check-ci-speed > /tmp/issue-1580-research/self-reference-checks/gates.log 2>&1
result=$?
set -e
cat /tmp/issue-1580-research/self-reference-checks/gates.log
git diff --check
exit "$result"
