from pathlib import Path
import gzip,json,subprocess
for command in [ ['rg','-l','initial-spec-reporter','docs/case-studies/issue-1580','experiments/issue-1580','/tmp/issue-1580-research','--glob','!commands/**','--glob','!supplied-bootstrap/**','--glob','!*.gz','--glob','!*.jsonl'],['node','experiments/formal_ai_subagent/local-gates.mjs','--list'] ]:
 r=subprocess.run(command,text=True,capture_output=True)
 if command[0]=='node': print('GATES', '\n'.join(line for line in r.stdout.splitlines() if any(word in line for word in ['abbrevi','file-size','changelog','ci-speed'])),r.returncode)
 else: print(r.stdout,r.stderr,r.returncode)
for name in ['experiments/issue-1580/evidence/checks/csharp-changeset-integrity.json','/tmp/issue-1580-research/commit-csharp-report-metadata.py']:
 p=Path(name); print('FILE',name); print(p.read_text())
p=Path('docs/case-studies/issue-1580/templates/csharp-partial-semantic-review.json'); value=json.loads(p.read_text())
print('REVIEW META', json.dumps({k:v for k,v in value.items() if k!='files'},indent=2))
print('UNREAD ACTIVE',json.dumps([r['path'] for r in value['files'] if r['reviewStatus']=='inventoried-only-active'],indent=2))
log=Path('experiments/issue-1580/evidence/ci/0f90c0a7a/attempt-1/44095402201.log.gz')
lines=gzip.decompress(log.read_bytes()).decode().splitlines()
for a,b in [(7063,7073),(7959,7971),(7985,7989)]:
 print('\n'.join(f'{n}: {lines[n-1]}' for n in range(a,b+1)))
