from pathlib import Path
p=Path('docs/case-studies/issue-1580/validation-origin-and-conversation-checkpoint.md');s=p.read_text();assert '## Published follow-up'not in s;s+='''
## Published follow-up

Published `5f64ad16` completes all 23 workflows: 21 succeed, while the stale generated registry and one unchanged contextual program-coreference assertion fail. Actual execution passes 147 Rust cases and four HTTP cases, including all four new origin controls and nine existing debug-session cases. Six pronoun cases pass; `Explain the program?` still reaches a cached general explanation and is unfinished on that head. The strict original-source union remains 17/53. All 96 collection payload hashes are verified.

The [next contextual repair and existing web replay checkpoint](contextual-explanation-and-web-replay-checkpoint.md) records both failures, the complete registry equality proof, preserved original test source and pending hosted repair verification. That later checkpoint also records continuous Java historical review through page 164. The historical local and pending-state observations above describe their original checkpoint; they do not claim the failed published head is green.
''';p.write_text(s);print('Published origin results appended without replacing historical observations')
