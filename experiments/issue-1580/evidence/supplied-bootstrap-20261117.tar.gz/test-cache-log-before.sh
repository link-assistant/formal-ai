set -u
timeout 600 node --test --test-concurrency=1 rust/tests/web/sccache-outage-fallback.test.mjs > /tmp/issue-1580-research/cache-log-before.log 2>&1
result=$?
tail -n 85 /tmp/issue-1580-research/cache-log-before.log
test "$result" -eq 1
