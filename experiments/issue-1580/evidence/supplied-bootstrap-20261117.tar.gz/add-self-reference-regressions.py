from pathlib import Path

p=Path('experiments/issue-1580/template-reference-graph.test.mjs')
s=p.read_text()
assert "function fixture(run){" in s
s=s.replace('function fixture(run){','function fixture(run, additions={}){')
s=s.replace(' const inventory=Object.entries(inputs).map', ' Object.assign(inputs,additions);\n const inventory=Object.entries(inputs).map')
s+=r'''
const selfRepositoryInputs={
 '.github/workflows/check.yml':`name: Check
on: push
jobs:
  reusable:
    uses: $/.github/workflows/reusable.yml
  check:
    steps:
      - uses: $/.github/actions/check
      - uses: external/action@0123456789012345678901234567890123456789
`,
 '.github/workflows/reusable.yml':'name: Reusable\non: workflow_call\njobs:\n  pass:\n    steps:\n      - run: echo bounded\n',
 '.github/actions/check/action.yml':'name: Composite\nruns:\n  using: composite\n  steps:\n    - uses: $/.github/actions/leaf\n',
 '.github/actions/leaf/action.yml':'name: Leaf\nruns:\n  using: node24\n  main: main.mjs\n  pre: pre.mjs\n  post: post.mjs\n',
 '.github/actions/leaf/main.mjs':"import './helper.mjs';\n",
 '.github/actions/leaf/pre.mjs':'export const before=true;\n',
 '.github/actions/leaf/post.mjs':'export const after=true;\n',
 '.github/actions/leaf/helper.mjs':'export const checked=true;\n',
};

test('self-repository uses follows reusable workflows, nested composites and JavaScript action phases',{timeout:5000},()=>{
 fixture((directory,inventory)=>{
  const graph=traceTree(directory,inventory);
  assert.ok(graph.edges.some(edge=>edge.from==='.github/workflows/check.yml'&&edge.to==='.github/workflows/reusable.yml'&&edge.reason==='self-repository reusable workflow'));
  assert.ok(graph.edges.some(edge=>edge.from==='.github/workflows/check.yml'&&edge.to==='.github/actions/check/action.yml'&&edge.reason==='self-repository action'));
  assert.ok(graph.edges.some(edge=>edge.from==='.github/actions/check/action.yml'&&edge.to==='.github/actions/leaf/action.yml'&&edge.reason==='self-repository action'));
  for(const file of ['main.mjs','pre.mjs','post.mjs','helper.mjs']) assert.ok(graph.files.includes('.github/actions/leaf/'+file),file);
  assert.equal(graph.files.includes('.github/actions/check/index.mjs'),false);
  assert.equal(graph.unresolved.some(row=>row.value.startsWith('external/action@')),false);
  assert.match(graph.coverageClaim,/not complete execution closure/u);
 },selfRepositoryInputs);
});

test('missing, dynamic and escaping self-repository paths remain explicit unresolved evidence',{timeout:5000},()=>{
 fixture((directory,inventory)=>{
  const graph=traceTree(directory,inventory);
  assert.ok(graph.unresolved.some(row=>row.value==='$/.github/actions/missing'&&row.reason.startsWith('no static file match:')));
  for(const value of ['$/../outside','$/..']) assert.ok(graph.unresolved.some(row=>row.value===value&&row.reason==='reference leaves the source tree'),value);
  assert.ok(graph.unresolved.some(row=>row.value==='$/.github/actions/${{ inputs.action }}'&&row.reason.includes('dynamic')));
 },{'.github/workflows/check.yml':'name: Check\non: push\njobs:\n  check:\n    steps:\n      - uses: $/.github/actions/missing\n      - uses: $/../outside\n      - uses: $/..\n      - uses: $/.github/actions/${{ inputs.action }}\n'});
});

test('self-repository transitive files retain pinned-blob verification',{timeout:5000},()=>{
 fixture((directory,inventory)=>{
  writeFileSync(join(directory,'.github/actions/leaf/helper.mjs'),'export const checked=false;\n');
  assert.throws(()=>traceTree(directory,inventory),/source drift: \.github\/actions\/leaf\/helper.mjs/u);
 },selfRepositoryInputs);
});
'''
p.write_text(s)
print('added three self-repository regressions')
