from pathlib import Path
import hashlib,json,re,sys
raw=Path('/tmp/issue-1580-research/main-444575f2-44163378148.log').read_bytes()
lines=raw.decode().splitlines()
rows=[]
for index,line in enumerate(lines):
 match=re.search(r'---- (.+?) stdout ----',line)
 if match:
  job=line.split('\t',1)[0]
  rows.append({'name':match.group(1),'job':job,'line':index+1})
timeouts=[{'line':i+1,'job':line.split('\t')[0],'detail':line.split('\t')[-1]} for i,line in enumerate(lines) if 'The command was terminated after 1080s' in line]
result={'run':44163378148,'head':'444575f2ac28f609c94497865f125f99415ff6d5','rawSha256':hashlib.sha256(raw).hexdigest(),'failureHeaders':rows,'timeouts':timeouts,'notACompleteRuntimeDiagnosis':True}
base=Path('experiments/issue-1580/evidence/ci/main-444575f2')
(base/'native-failure-header-inventory.json').write_text(json.dumps(result,indent=2)+'\n')
start=int(sys.argv[1]);print('TOTAL FAILURE HEADERS',len(rows),'UNIQUE',len(set(x['name'] for x in rows)))
for row in rows[start:start+25]: print(row['line'],row['job'],row['name'])
print('TIMEOUTS',json.dumps(timeouts))
