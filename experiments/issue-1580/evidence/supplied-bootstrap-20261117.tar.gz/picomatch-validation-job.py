from pathlib import Path
import gzip,hashlib,json,os,resource,subprocess,time
r=Path('/tmp/gh-issue-solver-1794900398048')
e=r/'experiments/issue-1580/evidence/checks/picomatch-single-branch'
env=dict(os.environ);env['NODE_OPTIONS']='--max-old-space-size=256'
env['PATH']='/tmp/issue-1580-research/shellcheck-v0.11.0:'+env['PATH']
checks=[
 ('canonical-data-mirrors',['node','scripts/mirror-package-data.mjs','--write']),
 ('final-security-tests',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/picomatch-security-backport.test.mjs']),
 ('fast-profile-tests',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs']),
 ('complete-local-gates',['node','experiments/formal_ai_subagent/local-gates.mjs']),
]
results=[]
for name,args in checks:
 print('START',name,flush=True);start=time.monotonic()
 log=Path('/tmp/issue-1580-research')/('picomatch-validation-'+name+'.log')
 with log.open('w') as out:
  cp=subprocess.run(args,cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT)
 raw=log.read_bytes()
 with gzip.open(e/(name+'.log.gz'),'wb') as out:out.write(raw)
 row={'name':name,'command':args,'exitCode':cp.returncode,'seconds':round(time.monotonic()-start,3),'rawSha256':hashlib.sha256(raw).hexdigest(),'nodeHeapMiB':256,'peakChildRssKiBCumulative':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss}
 results.append(row);(e/'validation-progress.json').write_text(json.dumps(results,indent=2)+'\n')
 print('DONE',json.dumps(row),flush=True)
(e/'validation-completion.json').write_text(json.dumps({'allPassed':all(x['exitCode']==0 for x in results),'results':results,'nativeExecuted':False,'autonomousAuthorshipCredit':0},indent=2)+'\n')
print('COMPLETE',flush=True)
