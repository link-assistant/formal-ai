from pathlib import Path
import subprocess
p=Path('changelog.d/20261117_1580_audit_inventory.md');s=p.read_text();assert s.startswith('### Fixed')
p.write_text('---\nbump: patch\n---\n\n'+s)
subprocess.run(['git','add','--',str(p)],check=True)
print('Prepared patch release fragment in the existing repository format.')
