from pathlib import Path
import subprocess,hashlib,json
root=Path.cwd();v=json.loads((root/'experiments/issue-1580/evidence/checks/offline-research-catalog-final-validation/final-result.json').read_text());assert v['complete']
for name,digest in v['sourceHashes'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
paths=['data/meta/google-trends-catalog.lino','data/seed/meanings-how.lino','docs/case-studies/issue-498/agent-cli-session-google-trends.json','rust/embedded/data/seed/meanings-how.lino','rust/src/solver_unknown_reasoning.rs','rust/tests/unit/reasoning_contracts.rs','rust/tests/unit/offline_instruction_research.rs','rust/tests/web/default-branch-build-policy.test.mjs','scripts/ci-pull-request-admission.mjs','changelog.d/issue-1580-offline-research-and-catalog.md']
subprocess.run(['git','add','--',*paths],check=True);subprocess.run(['git','diff','--cached','--check'],check=True);subprocess.run(['git','-c','core.compression=1','commit','-m','Preserve offline action research and replay actual generated catalog fixtures'],check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();base=root/'experiments/issue-1580/evidence/checks/offline-research-catalog-final-validation';(base/'source-commit.json').write_text(json.dumps({'sourceCommit':head,'published':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n');print(head)
