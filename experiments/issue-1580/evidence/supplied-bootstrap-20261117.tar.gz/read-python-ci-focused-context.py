from pathlib import Path
import subprocess,json

for name,start,end in [
    ('.github/workflows/layered-ci.yml',350,405),
    ('rust/tests/web/fast-pull-request-production-profile.test.mjs',1,230),
]:
    print('FILE',name,start,end)
    lines=Path(name).read_text().splitlines()
    for number in range(start,min(len(lines),end)+1):print(f'{number}: {lines[number-1]}')
print('MATCHING TEST FILES')
print(subprocess.run(['rg','-l','layered-ci.yml|setup-python','rust/tests/web','-g','*test.mjs'],capture_output=True,text=True,check=True).stdout)
print('CONTRIBUTING TARGETS')
print(subprocess.run(['rg','-n','workflow|Python|push|test|Formal AI|command|agent','CONTRIBUTING.md','--max-count','30'],capture_output=True,text=True,check=True).stdout)
manifest=subprocess.run(['gh','api','-H','Accept: application/vnd.github.raw+json','repos/actions/python-versions/contents/versions-manifest.json'],capture_output=True,check=True).stdout
Path('/tmp/issue-1580-research/python-versions-manifest.json').write_bytes(manifest)
versions=json.loads(manifest)
print('OFFICIAL PYTHON 3.15.2 ASSETS')
print(json.dumps([row for row in versions if row['version']=='3.15.2'],indent=2))
