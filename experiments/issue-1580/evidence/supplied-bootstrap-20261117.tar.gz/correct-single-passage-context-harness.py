from pathlib import Path
import gzip
import hashlib
import json

root = Path('experiments/issue-1580/evidence/checks/passage-routing-probe')
script = Path('experiments/issue-1580/probe-single-passage-task-context.mjs')
log = Path('/tmp/issue-1580-research/single-passage-context-probe.log')
records = []
for name, source in [('initial-constant-assignment-script.mjs', script), ('initial-constant-assignment.log', log)]:
    raw = source.read_bytes()
    out = root / (name + '.gz')
    assert not out.exists()
    out.write_bytes(gzip.compress(raw, mtime=0))
    records.append({'source': str(source), 'artifact': str(out), 'rawBytes': len(raw), 'rawSha256': hashlib.sha256(raw).hexdigest()})
text = script.read_text()
before = '''  const originalProcedure = metaRunProcedure;
  metaRunProcedure = async (prompt, answer, subTask) => {
    if (!contextProbeEnabled) return originalProcedure(prompt, answer, subTask);
    const executor = crateModule('crate/meta_executor.mjs');'''
after = '''  const originalCrateModule = crateModule;
  const originalExecutor = crateModule('crate/meta_executor.mjs');
  crateModule = (name) => name === 'crate/meta_executor.mjs'
    ? { ...originalExecutor, solveAnswer: contextProbeSolveAnswer } : originalCrateModule(name);
  const contextProbeSolveAnswer = async (request, answer, subTask, options = {}) => {
    const prompt = request.text;
    const runOptions = { ...options, withheldTests: contextProbeWithheld };
    if (!contextProbeEnabled) return originalExecutor.solveAnswer(request, answer, subTask, runOptions);
    const executor = originalExecutor;'''
assert text.count(before) == 1
text = text.replace(before, after)
before = "    }, { withheldTests: contextProbeWithheld })).answer;"
assert text.count(before) == 1
text = text.replace(before, "    }, runOptions));")
script.write_text(text)
record = root / 'initial-constant-assignment.json'
assert not record.exists()
record.write_text(json.dumps({'exitCode': 1, 'cause': 'Disposable harness attempted to assign a const binding; no requests executed and production sources unchanged.', 'records': records, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
print(json.dumps({'preserved': records, 'scriptBytes': script.stat().st_size}))
