from pathlib import Path
import subprocess,json,gzip,hashlib,datetime
base=Path('experiments/issue-1580/evidence/checks/php-release-guard')
def run(argv):
    result=subprocess.run(argv,capture_output=True);assert result.returncode==0,result.stderr.decode();return result.stdout
assert run(['git','branch','--show-current']).decode().strip()=='issue-1580-8d61a32a61e1'
parent=run(['git','rev-parse','HEAD']).decode().strip()
assert parent=='fca86432b7194eb94d0c153860d67f782a9a3401'
patch=run(['git','diff','--cached','--binary'])
assert patch==gzip.decompress((base/'staged-source.patch.gz').read_bytes())
review=json.loads((base/'manual-review.json').read_text())
for name,digest in review['sourceHashes'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
run(['git','diff','--cached','--check'])
print(run(['git','-c','gc.auto=0','commit','-m','Replay PHP automatic-release prerequisite failures']).decode())
head=run(['git','rev-parse','HEAD']).decode().strip()
review['textPatchLiterallyRead']=True
review['unmodifiedWorkflowHashVerified']=True
(base/'manual-review.json').write_text(json.dumps(review,indent=2)+'\n')
report={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'parent':parent,'pushed':False,'wholeStagedPatchSha256':hashlib.sha256(patch).hexdigest(),'nativeExecution':False,'hostedPublication':False,'upstreamIssueFiled':False,'independentAuthorshipCredit':0}
(base/'local-source-commit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
