from pathlib import Path
import json,subprocess

repo='link-foundation/csharp-ai-driven-development-pipeline-template'
base=Path('/tmp/issue-1580-research/csharp-collision-preflight')
def request(endpoint,paginate=False):
 args=['gh','api']+(['--paginate','--slurp'] if paginate else [])+[endpoint]
 value=json.loads(subprocess.check_output(args,text=True))
 return [row for page in value for row in page] if paginate else value
pr=request(f'repos/{repo}/pulls/83')
records=[('pull-83',pr)]
for kind,endpoint in [('conversation','issues/83/comments'),('inline','pulls/83/comments'),('reviews','pulls/83/reviews')]:
 rows=request(f'repos/{repo}/{endpoint}?per_page=100',True)
 records.append((kind,rows))
for label,value in records:
 (base/(label+'.json')).write_text(json.dumps(value,indent=2)+'\n')
 if isinstance(value,list):print(label,'COUNT',len(value))
 for row in value if isinstance(value,list) else [value]:
  print(label,row.get('html_url'),row.get('state',''),row.get('title',''))
  lines=(row.get('body') or '').splitlines()
  assert len(lines)<=1500
  for n,line in enumerate(lines,1):print(f'{n}: {line}')
