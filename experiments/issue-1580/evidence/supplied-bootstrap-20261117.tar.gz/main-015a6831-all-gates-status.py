from pathlib import Path
import json
base=Path('experiments/issue-1580/evidence/checks/main-merge-015a6831/all-gates');receipt=base/'all-local-gates.json'
print('worker',Path('/proc/742795/stat').read_text().split(')')[1].split()[0] if Path('/proc/742795/stat').exists() else 'exited')
if receipt.exists():
 data=json.loads(receipt.read_text());print(json.dumps({k:v for k,v in data.items() if k!='gateLogs'}));print('savedGateLogs',len(data['gateLogs']))
else:
 path=Path('/tmp/issue-1580-research/main-015a6831-all-local-gates.log');lines=path.read_text().splitlines() if path.exists() else []
 print('completedOutputLines',len(lines));print('\n'.join(lines[-12:]))
