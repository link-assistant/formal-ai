from pathlib import Path
import gzip,json
base=Path('experiments/issue-1580/evidence/ci/main-015a6831')
value=json.loads(gzip.decompress((base/'pipeline-metadata.json.gz').read_bytes()))
print(json.dumps({'keys':list(value),'jobs':[{'id':j.get('databaseId',j.get('id')),'name':j['name'],'conclusion':j.get('conclusion'),'url':j.get('url')} for j in value.get('jobs',[]) if j['name'] in ('Test (ubuntu-24.04 / full) shard 5/8','Test (ubuntu-24.04 / full)')]}))
for side in ('right:','  left:'):
 hits=[]
 with gzip.open(base/'pipeline-44188508650.log.gz','rt') as stream:
  for i,line in enumerate(stream,1):
   if side in line and (line.startswith('Test (ubuntu-24.04 / full) shard 5/8\t') or line.startswith('Test (ubuntu-24.04 / full)\t')):
    hits.append({'line':i,'chars':len(line),'prefix':line[:240]})
 print(json.dumps({'marker':side,'hits':hits},ensure_ascii=False))
