from pathlib import Path
for name in ['experiments/formal_ai_subagent/sandboxes/gates/lint-shell-scripts.log','scripts/lint-shell-scripts.sh']:
 p=Path(name);lines=p.read_text().splitlines();print(name,len(lines),'lines')
 for i,line in enumerate(lines[:160],1):print(f'{i}: {line}')
