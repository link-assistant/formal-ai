from pathlib import Path
import gzip,json
base=Path('experiments/issue-1580/evidence/checks/main-merge-826289fc/feedback')
print('FILES',*[p.name for p in base.iterdir()])
for p in base.iterdir():
    if 'issue' in p.name and p.suffix=='.gz':
        data=json.loads(gzip.decompress(p.read_bytes()))
        if isinstance(data,dict) and 'body' in data:
            print('ISSUE',data['body'])
