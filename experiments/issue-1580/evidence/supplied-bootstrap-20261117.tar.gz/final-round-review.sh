set -eu
node --max-old-space-size=128 experiments/issue-1580/trace-template-ci.mjs > /tmp/issue-1580-research/template-reference-graph-summary-sixth.json
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-reference-graph.test.mjs > /tmp/issue-1580-research/template-reference-graph-sixth.log 2>&1
node experiments/formal_ai_subagent/local-gates.mjs --only check-file-size,check-file-size-js-twin,check-changelog-fragment-js-twin,check-ci-speed > /tmp/issue-1580-research/touched-gates-sixth.log 2>&1
git diff --check
git diff -- experiments/formal_ai_subagent/local-gates.mjs experiments/issue-1580/compare-template-trees.mjs experiments/issue-1580/template-inventory-integrity.test.mjs rust/tests/web/pull-request-1188-subagent-folder.test.mjs
rg -n 'command-stream-registry.json|link-calculator-registry.json|ci-reference-graph.json' docs/case-studies/issue-1580 experiments/issue-1580 --glob '!*.gz' --glob '!*.jsonl'
cat /tmp/issue-1580-research/touched-gates-sixth.log
