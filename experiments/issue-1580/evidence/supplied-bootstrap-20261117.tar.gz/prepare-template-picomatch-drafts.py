from pathlib import Path
import json,subprocess
b=Path('/tmp/issue-1580-research');out=b/'picomatch-template-research'
summary=json.loads((out/'summary.json').read_text())
heads={}
for language in ['js','python','cpp']:
 rows=[x for x in summary['locks'] if '/'+language+'-' in x['repository']]
 repo=rows[0]['repository']
 cp=subprocess.run(['gh','api','repos/'+repo+'/commits/HEAD','--jq','.sha'],text=True,capture_output=True)
 assert cp.returncode==0,cp.stderr
 head=cp.stdout.strip();heads[language]=head
 intro={
 'js':'The root lock and universal-app lock currently contain affected picomatch releases. The security workflow audits committed npm locks; its policy is correctly rejecting the newly reviewed advisory.',
 'python':'The artifact-action lock contains affected picomatch 4.0.7 through the secretlint development toolchain. The npm-audit security job correctly rejects this lock. This report does not claim that the committed artifact runtime bundle exposes the same code.',
 'cpp':'The root npm lock contains affected picomatch 4.0.7 through secretlint. The release workflow runs npm audit --audit-level=low after installing this lock, so the newly reviewed high-severity advisory makes that gate fail.',
 }[language]
 body=intro+'\n\nCurrent source checked at '+head+' on '+summary['timestamp']+'. Each audited lock exactly matches its current default-branch Git blob.\n\n'
 for row in rows:
  directory=str(Path(row['path']).parent)
  versions=', '.join(sorted({v['version'] for v in row['picomatch'].values()}))
  body+='- ['+row['path']+'](https://github.com/'+repo+'/blob/'+head+'/'+row['path']+'): picomatch '+versions+', audit exits '+str(row['auditExitCode'])+', '+str(row['metadata']['vulnerabilities']['high'])+' high-severity affected dependency nodes. Blob '+row['gitBlob']+'.\n'
  fence=chr(96)*3
  body+='\n'+fence+'sh\ncd '+directory+'\nnpm audit --package-lock-only --audit-level=moderate --json\n'+fence+'\n\n'
 body+='All affected-node chains in these responses lead to [GHSA-fc5q-39xc-vjpf](https://github.com/advisories/GHSA-fc5q-39xc-vjpf) / CVE-2026-112366. Reviewed on 17 November, it affects picomatch through 4.0.7; no patched release is listed. Registry and GitHub release metadata still identify 4.0.7 as latest. The npm fixAvailable suggestions downgrade consumers; they do not identify a patched picomatch release.\n\n'
 body+='The published 4.0.7 source reproduces the single-branch guard gap with +(*) and +(*a). A finite 42-byte hostile subject fails to complete within 1.25 seconds in isolated Node children (64 MiB heap / 256 KiB stack); each process is killed. Exact output, source hashes, audit responses, a local candidate backport and normal micromatch/tinyglobby/fdir controls are retained in the associated investigation.\n\n'
 body+='Retain complete development-dependency auditing and the existing severity policy. Adopt a reviewed upstream security release when available, or an explicitly maintained backport with bounded hostile-pattern tests, source/license provenance and consumer compatibility checks. Regenerate affected locks and verify the real audit gate. Omitting dev dependencies or raising the severity threshold would hide this finding.\n\n'
 body+='This is a reproduced dependency-gate failure, not an upstream repair or proof that arbitrary untrusted glob patterns are reachable in the runtime application.\n\nEvidence: PUBLISHED_EVIDENCE_URL\nRelated investigation: https://github.com/link-assistant/formal-ai/pull/1581\n'
 (out/(language+'-report.md')).write_text(body)
 print(language,head,'draft bytes',len(body.encode()))
(out/'draft-heads.json').write_text(json.dumps(heads,indent=2)+'\n')
