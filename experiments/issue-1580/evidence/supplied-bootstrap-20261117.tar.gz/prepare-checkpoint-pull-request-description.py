from pathlib import Path
text='''Fixes #1580

CI could accept stale source evidence, lose useful failure diagnostics, and miss client output and startup-log regressions. This draft preserves exact-head evidence and adds focused failing-before controls. The full issue remains unfinished; keep this PR unmerged.

Changes include:

- Verify complete governed witnesses and current source identities; preserve command failures, artifact provenance and bounded cache diagnostics.
- Enforce request-local brevity, line and language constraints, and decode path-bound OpenCode Read results without changing observed file bytes.
- Probe native diagnostic-directory writability without creating empty session logs. Keep offline workflow fixtures explicit, canonicalize the client JSON scalar, and include the native Read fixture inside its package.
- Repair candidate validation and calendar request spans; retain the picomatch security backport and pinned-source template regression evidence.

Reproduction and automated verification:

- Real client failures are replayed by `rust/tests/web/issue-1580-client-output-constraints.test.mjs`; six cases pass. Shared request-context cases exercise worker and HTTP boundaries.
- The startup regression is `writability_probe_preserves_log_files_and_leaves_no_empty_session`. It preserves existing logs, rejects an invalid directory and checks the first actual log write. **Native execution is pending.**
- After merging main `058e9bef`, fourteen focused JavaScript files pass **154 tests**, zero failures or skips. The complete local inventory passes **86 gates**, with **52 explicit native/context exclusions**, zero failures, a 256 MiB Node heap cap and no Rust execution.
- Package mirroring verifies all 482 demands; formatting and translation checks pass. The complete witness comparison visits 7,727 object pairs and finds zero changes. Source-bound logs and hashes are in [the checkpoint record](docs/case-studies/issue-1580/main-058e9bef-checkpoint.md).
- The preceding published head `83882c0e` has 23 successful workflows and one stale-witness failure, repaired locally. CI for this newly published checkpoint must be checked separately.

Run focused files individually, then the JavaScript gates:

```sh
timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/issue-1580-client-output-constraints.test.mjs
timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/issue-1587-request-context.test.mjs
node experiments/formal_ai_subagent/local-gates.mjs
```

Outstanding acceptance includes native failures and shard timeouts, benchmark floors, full semantic review and applicability decisions for all eight templates, remaining dependency migrations and warnings, historical cache/Docker and required-context reproduction, live delivery/model identity, and the newly observed recursive supplied-passage network requests. The [work plan](experiments/issue-1580/work-plan.md) and [case study](docs/case-studies/issue-1580/README.md) retain each unfinished criterion and its evidence. Inventoried source bytes, skipped build jobs, candidate Rust changes and upstream reports do not establish those criteria. Independent Formal AI reasoning acceptance remains **0/20**; supplied commands, patches and scripts earn zero independent authorship credit.
'''
path=Path('/tmp/issue-1580-research/verified-checkpoint-pull-request-description.md')
path.write_text(text)
print(path.read_text())
