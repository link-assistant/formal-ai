#!/bin/sh
set -eu
sed -n '1,125p' scripts/check-sccache-write-health.sh
sed -n '85,230p' rust/tests/web/sccache-outage-fallback.test.mjs
sed -n '1,80p' /tmp/issue-1580-research/recovered-checks-driver.log
git diff --stat
node experiments/formal_ai_subagent/local-gates.mjs --list > /tmp/issue-1580-research/gate-list.log
rg 'file-size|abbreviations|fast-pull|fast.*java|staged|translation' /tmp/issue-1580-research/gate-list.log
