import pathlib,subprocess
for command in [
 ['rg','-n','currency-conversion-connector|split.*\\|','js/worker/formal_ai_worker_currency.js','rust/src/solver_handlers/currency'],
 ['rg','-n','function handlerRulesParseTree|function handlerRulesTokens','js/worker/formal_ai_worker_handler_rules.js'],
 ['rg','-n','fn meaning_definitions|meanings-','rust/tests/unit/data_files.rs'],
 ['rg','-n','createWorkerContext|evaluate','rust/tests/web/handler-rules.test.mjs','rust/tests/web/handler-rules-twin.test.mjs'],
]:
 r=subprocess.run(command,text=True,capture_output=True)
 print('\nCOMMAND',command,'exit',r.returncode)
 print(r.stdout+r.stderr)
for name,first,last in [('rust/src/rule_interpreter/parser.rs',110,150),('rust/src/rule_interpreter/values.rs',1,68),('rust/tests/web/support/browser-runtime.mjs',1,95),('rust/tests/web/main-only-regression-ledger.test.mjs',1,150),('rust/tests/unit/data_files.rs',890,970)]:
 lines=pathlib.Path(name).read_text().splitlines()
 print(f'\nFILE {name}:{first}-{min(last,len(lines))} of {len(lines)}')
 for n in range(first,min(last,len(lines))+1):print(f'{n}: {lines[n-1]}')
