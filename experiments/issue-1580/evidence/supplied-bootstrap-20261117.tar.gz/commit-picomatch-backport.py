from pathlib import Path
import gzip, hashlib, json, subprocess

branch='issue-1580-8d61a32a61e1'
def run(arguments):
    result=subprocess.run(arguments,text=True,capture_output=True,check=True)
    print(result.stdout)
    if result.stderr:print(result.stderr)
    return result.stdout
assert run(['git','branch','--show-current']).strip()==branch
source=Path('/tmp/issue-1580-research/picomatch-push-preflight')
summary=json.loads((source/'summary.json').read_text())
assert summary['preCommitPushGateSatisfied']
assert summary['localHead']==run(['git','rev-parse','HEAD']).strip()
base=Path('experiments/issue-1580/evidence/checks/picomatch-single-branch')
target=base/'push-preflight-final'
target.mkdir(exist_ok=True)
rows=[]
for path in sorted(source.glob('*.json')):
    data=path.read_bytes()
    name=path.name+'.gz'
    (target/name).write_bytes(gzip.compress(data,mtime=0))
    rows.append({'file':name,'rawSha256':hashlib.sha256(data).hexdigest(),'rawBytes':len(data)})
(target/'index.json').write_text(json.dumps({'files':rows,'autonomousAuthorshipCredit':0},indent=2)+'\n')
assert json.loads((base/'sealed-complete-gates.json').read_text())['allPassed']
assert json.loads((base/'sealed-notes-checks.json').read_text())['allPassed']
for name in ['archive-round-bootstrap.py','archive-evidence.py']:
    run(['python3','/tmp/issue-1580-research/'+name])
run(['git','diff','--check'])
paths=['data/benchmarks/fast-pull-request-javascript-tests.json','data/meta/abbreviation-ratchet.lino','desktop/package.json','desktop/package-lock.json','vscode/package.json','vscode/package-lock.json','packages/picomatch-compat','rust/tests/web/picomatch-security-backport.test.mjs','changelog.d/20261117_190000_picomatch_security_backport.md','experiments/issue-1580','docs/case-studies/issue-1580/README.md']
run(['git','add','--',*paths])
run(['git','diff','--cached','--check'])
run(['git','diff','--cached','--stat'])
run(['git','commit','-m','Fix repeated-extglob denial of service in development dependencies'])
status=run(['git','status','--porcelain'])
assert not status.strip(), 'Uncommitted files remain.'
print('COMMITTED',run(['git','rev-parse','HEAD']).strip())
