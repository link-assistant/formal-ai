from pathlib import Path
import gzip,json,itertools,re
root=Path('/tmp/issue-1580-research/head-71e1dee44')
pattern=re.compile(r'(ERR_MODULE_NOT_FOUND|Cannot find|Error:|error\[|not ok |✖|FAIL|error:|SyntaxError|AssertionError)',re.I)
for file in sorted(root.glob('*.log.gz')):
 meta=json.loads(file.with_name(file.name.removesuffix('.log.gz')+'.json').read_text())
 failed=[{'name':job['name'],'conclusion':job['conclusion'],'steps':[s['name'] for s in job.get('steps',[]) if s.get('conclusion')=='failure']} for job in meta.get('jobs',[]) if job.get('conclusion')=='failure']
 print(json.dumps({'file':file.name,'failedJobs':failed}))
 hits=[];line=0
 with gzip.open(file,'rt') as stream:
  while chunk:=list(itertools.islice(stream,1500)):
   for offset,text in enumerate(chunk):
    if pattern.search(text):hits.append((line+offset+1,text.rstrip()))
   line+=len(chunk)
 for number,text in hits[-45:]:print(f'{number}: {text}')
 print('Total log lines:',line,'matching lines:',len(hits))
