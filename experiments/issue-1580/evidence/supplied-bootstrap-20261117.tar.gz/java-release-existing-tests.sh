set -eu
cat /tmp/issue-1580-research/templates/java-complete/experiments/release-recovery.test.mjs
cat /tmp/issue-1580-research/templates/java-complete/experiments/cli-runtime.test.mjs
cat /tmp/issue-1580-research/templates/java-complete/scripts/github-release-state.mjs
rg -n -i 'nothing to commit|collection failed|git commit|release.*commit' scripts/check-release* scripts/*version* rust/src -g '*.rs' -g '*.mjs'
