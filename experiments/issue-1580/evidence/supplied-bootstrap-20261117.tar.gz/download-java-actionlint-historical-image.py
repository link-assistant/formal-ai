from pathlib import Path
import hashlib,json,subprocess
base=Path('/tmp/issue-1580-research/java-actionlint-image');base.mkdir(exist_ok=True)
url='https://github.com/user-attachments/assets/088d4459-fd2f-4ead-bd42-2676d9539677';target=base/'queue-diagnostic.png'
token=subprocess.check_output(['gh','auth','token'],text=True).strip()
run=subprocess.run(['curl','-L','--fail','--silent','--show-error','-H','Authorization: token '+token,'-o',str(target),url],capture_output=True)
assert run.returncode==0,run.stderr.decode()
kind=subprocess.check_output(['file','--brief',str(target)],text=True).strip();assert 'image' in kind.lower(),kind
print(json.dumps({'url':url,'path':str(target),'fileType':kind,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'historicalReference':True}))
