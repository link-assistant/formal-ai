from pathlib import Path
import gzip,json
p=Path('experiments/issue-1580/evidence/ci/main-015a6831/pipeline-44188508650.log.gz')
with gzip.open(p,'rt') as stream:
 for i,line in enumerate(stream,1):
  if ('google_trends_catalog' in line and ('left:' in line or 'right:' in line)) or ('right:' in line and ('shard 5/8\t' in line or line.startswith('Test (ubuntu-24.04 / full)\t'))) or i in (36071,36072,36073,66470,66471,66472):
   print(json.dumps({'line':i,'chars':len(line),'prefix':line[:380],'suffix':line[-220:]},ensure_ascii=False))
