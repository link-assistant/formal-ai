from pathlib import Path
import subprocess,json
directory=Path('experiments/issue-1580/evidence/checks/python-runtime-provisioning')
p=directory/'draft-checks.json';value=json.loads(p.read_text())
first=value[0];assert first['name']=='runtime-regression'
first['historicalLogPath']=first.pop('log')
first['log']=None
first['retention']='This first passing draft log was overwritten by an unchanged second passing runtime probe. Its printed summary and digest remain in the complete command transcript. The preserved runtime-regression.log.gz is the later 31-second probe; final current-source runtime coverage is in maintained-observations.log.gz. Do not equate those different full-log hashes.'
p.write_text(json.dumps(value,indent=2)+'\n')
for name in ['archive-round-bootstrap.py','archive-evidence.py','commit-python-runtime-batch.py']:
 result=subprocess.run(['python3','/tmp/issue-1580-research/'+name],capture_output=True,text=True)
 print(name,flush=True);print(result.stdout,flush=True)
 if result.returncode:print(result.stderr,flush=True);raise SystemExit(result.returncode)
