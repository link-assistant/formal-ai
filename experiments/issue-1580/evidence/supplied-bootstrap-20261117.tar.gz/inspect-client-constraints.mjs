import fs from 'node:fs';
const { formalizeRequest } = await import(`${process.cwd()}/js/server/request-context.mjs`);
for (const client of ['opencode', 'qwen']) {
  const base = `/tmp/issue-1580-research/main-826289fc-cli-artifacts/transcripts-${client}/artifacts/${client}/interactive/proxy.jsonl`;
  const rows = fs.readFileSync(base, 'utf8').split('\n').filter(Boolean).map(JSON.parse).filter(row => row.method === 'POST');
  for (const [i, row] of rows.entries()) {
    const request = JSON.parse(row.request_body);
    const context = formalizeRequest(request.messages);
    console.log(JSON.stringify({ client, i, prompt: context.prompt, language: context.language, constraints: context.constraints }, null, 2));
  }
}
