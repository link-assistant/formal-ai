from pathlib import Path
import hashlib, json, shutil
source=Path('/tmp/issue-1580-research/templates/go-complete')
inventory=json.loads(Path('/tmp/issue-1580-research/templates/go-complete-inventory.json').read_text())
known={item['path']:item for item in inventory}
target=Path('experiments/issue-1580/fixtures/go-template')
files=['LICENSE','.github/workflows/release.yml','scripts/detect-code-changes.mjs','scripts/github-actions-log.mjs','scripts/ci/check-pipeline-status.mjs','scripts/ci/runner-acquisition.mjs']
records=[]
for filename in files:
    data=(source/filename).read_bytes()
    digest=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert digest==known[filename]['gitBlob'],filename
    destination=target/filename
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes(data)
    records.append({'path':filename,'gitBlob':digest,'sha256':hashlib.sha256(data).hexdigest()})
(target/'source.json').write_text(json.dumps({'repository':'link-foundation/go-ai-driven-development-pipeline-template','commit':'65c686846d7327d8c835a0d30b1a76cc6345cfc6','files':records,'purpose':'Unmodified upstream sources for bounded offline reproductions; not a local implementation or a hosted workflow run.'},indent=2)+'\n')
driver=Path('experiments/issue-1580/formal-command.mjs')
text=driver.read_text()
before="process.stdout.write(result.stdout??'');"
after="// The full response is retained above; show the tool trace once.\nprocess.stdout.write((result.stdout??'').split('== answer ==')[0]);"
assert text.count(before)==1
driver.write_text(text.replace(before,after))
print('Retained',len(records),'Git-blob-verified unmodified Go template sources; full Formal AI responses remain archived.')
