set -eu
test "$(git branch --show-current)" = issue-1580-8d61a32a61e1
git fetch origin main
git merge-base --is-ancestor origin/main HEAD
git status --short
gh run list --repo link-assistant/formal-ai --branch issue-1580-8d61a32a61e1 --status in_progress --json databaseId,workflowName,headSha > /tmp/issue-1580-research/prepush-in-progress.json
gh run list --repo link-assistant/formal-ai --branch issue-1580-8d61a32a61e1 --status queued --json databaseId,workflowName,headSha > /tmp/issue-1580-research/prepush-queued.json
gh run list --repo link-assistant/formal-ai --branch issue-1580-8d61a32a61e1 --limit 5 --json databaseId,conclusion,createdAt,headSha
python3 - <<'PY'
from pathlib import Path
import json
for name in ['prepush-in-progress.json','prepush-queued.json']:
 value=json.loads((Path('/tmp/issue-1580-research')/name).read_text());assert not value,value
 print(name,value)
PY
git rev-parse HEAD origin/main
git diff 510fe7606..HEAD --check
git diff 510fe7606..HEAD --stat > /tmp/issue-1580-research/review-current-round-stat.txt
git diff 510fe7606..HEAD -- .cargo/audit.toml scripts/detect-code-changes.rs experiments/issue-1580/compare-template-trees.mjs experiments/issue-1580/formal-command.mjs data/benchmarks/fast-pull-request-javascript-tests.json > /tmp/issue-1580-research/review-current-round.diff
