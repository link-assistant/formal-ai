from pathlib import Path
import gzip,json,subprocess

fresh=json.loads(Path('/tmp/issue-1580-research/python-fragment-final-upstream-issues.json').read_text())
prior=json.loads(gzip.decompress(Path('experiments/issue-1580/evidence/checks/python-fragment-collision/upstream-issues.json.gz').read_bytes()))
if isinstance(prior,list) and prior and isinstance(prior[0],list):
    prior=[row for page in prior for row in page]
if isinstance(prior,dict):
    print('PRIOR SHAPE', list(prior))
else:
    print('PRIOR COUNT',len(prior))
    def identity(items):
        return sorted((row['number'],row['title'],row.get('body')) for row in items)
    print('Bodies/titles unchanged since complete prior duplicate investigation:',identity(fresh)==identity(prior))
print('CURRENT MATCHING TITLES')
for row in fresh:
    if any(word in row['title'].lower() for word in ['changelog','scriv','fragment','collision','overwrite','changeset']):
        print(row['number'],row['title'])
for name in ['experiments/issue-1580/upstream/template-report-identities.json','experiments/issue-1580/upstream/filed-issues.txt']:
    print('FILE',name)
    print(Path(name).read_text())
print('PRIOR FILE HELPERS')
print(subprocess.run(['rg','--files','/tmp/issue-1580-research','-g','*csharp*','-g','*file*report*'],capture_output=True,text=True,check=True).stdout)
