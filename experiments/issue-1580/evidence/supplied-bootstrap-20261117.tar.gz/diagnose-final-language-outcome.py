from pathlib import Path
import hashlib,json,gzip
r=Path('/tmp/gh-issue-solver-1794900398048');b=r/'experiments/issue-1580/evidence/checks/language-main-final-validation';v=json.loads((b/'outcome.json').read_text());print(json.dumps({k:x for k,x in v.items() if k!='gateLogs'},indent=2))
for name,sha in json.loads((b/'candidate-source-hashes.json').read_text()).items():
 actual=hashlib.sha256((r/name).read_bytes()).hexdigest() if (r/name).is_file() else None
 if actual!=sha:print('IDENTITY_CHANGED',name,sha,actual)
raw=gzip.decompress((b/'all-local-gates.log.gz').read_bytes());print(raw.decode())
for row in v['gateLogs']:
 if ('FAIL '+row['gateName']+' ') in raw.decode():print('FAILURE',row['gateName'],gzip.decompress((b/row['log']).read_bytes()).decode())
