import datetime,gzip,hashlib,json,pathlib,subprocess
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
status=subprocess.check_output(['git','status','--porcelain'],text=True)
assert not status,status
before=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
fetch=subprocess.run(['git','fetch','origin','main'],capture_output=True,text=True)
assert fetch.returncode==0,fetch.stderr
incoming=subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()
assert incoming=='015a683197c89e8f74375b097e8dd06a57dcea8f',incoming
base=pathlib.Path('experiments/issue-1580/evidence/checks/main-merge-015a6831')
base.mkdir(exist_ok=True)
run=subprocess.run(['git','merge','--no-commit','--no-ff',incoming],capture_output=True)
raw=run.stdout+run.stderr
(base/'merge.log.gz').write_bytes(gzip.compress(raw,mtime=0))
pathlib.Path('/tmp/issue-1580-research/main-015a6831-merge.log').write_bytes(raw)
conflicts=subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],text=True).splitlines()
receipt={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'previousHead':before,'incomingMain':incoming,'mergeExitCode':run.returncode,'conflicts':conflicts,'rawSha256':hashlib.sha256(raw).hexdigest(),'nativeExecuted':False,'independentAuthorshipCredit':0}
(base/'merge.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2));print(raw.decode())
