from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile
base=Path('experiments/issue-1580/evidence')
manifest=json.loads((base/'supplied-bootstrap-20261117.json').read_text())
archive=base/'supplied-bootstrap-20261117.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archiveSha256']
with tarfile.open(archive) as tar:
    actual={item.name:hashlib.sha256(tar.extractfile(item).read()).hexdigest() for item in tar if item.isfile()}
assert actual=={row['file']:row['sha256'] for row in manifest['files']}
index=[json.loads(line) for line in (base/'commands/index.jsonl').read_text().splitlines()]
assert len(index)==2314 and len({row['file'] for row in index})==len(index)
for row in index[2172:]:
    raw=(base/'commands'/row['file']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['compressedSha256']
    assert hashlib.sha256(gzip.decompress(raw)).hexdigest()==row['sha256']
summary=json.loads((base/'checks/localized-unknown-opener/reviewed-round-summary.json').read_text())
for name,sha in summary['sourceHashes'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==sha,name
commands=[['git','diff','--check'],['node','--max-old-space-size=256','--check','experiments/issue-1580/unresolved-request-probe.mjs'],['node','--max-old-space-size=256','--check','experiments/issue-1580/review-governed-source-refresh.mjs']]
for argv in commands:
    run=subprocess.run(argv,capture_output=True,text=True);assert run.returncode==0,(argv,run.stdout,run.stderr)
print(json.dumps({'suppliedScripts':len(actual),'commandRecords':len(index),'newCommandRecordsVerified':len(index)-2172,'unchangedFinalSourceHashes':len(summary['sourceHashes']),'syntaxChecks':2,'whitespace':'pass','nativeBehaviorVerified':False}))
