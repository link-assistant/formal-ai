from pathlib import Path
import gzip,json,subprocess

directory=Path('experiments/issue-1580/evidence/checks/python-release-formatting')
items=json.loads(gzip.decompress((directory/'duplicate-issues.json.gz').read_bytes()))
print('SOURCE REFERENCES')
root='/tmp/issue-1580-research/templates/python-complete'
result=subprocess.run(['rg','-n','--max-count','4','format_release_notes|format_release_body|escaped newlines',root+'/.github',root+'/scripts',root+'/tests'],capture_output=True,text=True)
rows=result.stdout.splitlines()
print('\n'.join(line[:350] for line in rows[:20]));print('total reference hits',len(rows))
print('RELATED CURRENT SOURCE HISTORY')
for item in items:
    if 'format_release_notes' in (item.get('body') or ''):
        print(json.dumps({'number':item['number'],'title':item['title'],'url':item['html_url']}))
for number in [124,88,17]:
    item=next(row for row in items if row['number']==number)
    print('FULL DISCUSSION',number,item['title'])
    print(item.get('body') or '')
    endpoints=[f'issues/{number}/comments']
    if 'pull_request' in item:endpoints += [f'pulls/{number}/comments',f'pulls/{number}/reviews']
    for endpoint in endpoints:
        raw=subprocess.run(['gh','api',f'repos/link-foundation/python-ai-driven-development-pipeline-template/{endpoint}','--paginate'],capture_output=True,check=True).stdout
        (directory/f'related-{number}-{endpoint.split("/")[-1]}.json.gz').write_bytes(gzip.compress(raw,mtime=0))
        comments=json.loads(raw)
        print(endpoint, f'{len(comments)} entries')
        for comment in comments:
            print(comment.get('html_url'),comment.get('body') or '')
