from pathlib import Path
import sys
page=int(sys.argv[1]);assert page>=1
lines=Path('/tmp/issue-1580-research/header-pr-review/new-source.diff').read_text().splitlines()
start=(page-1)*350;assert start<len(lines)
print('\n'.join(f'{i+1}: {line}' for i,line in enumerate(lines[start:start+350],start)))
