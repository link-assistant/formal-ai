import subprocess
from pathlib import Path

root = Path('/tmp/gh-issue-solver-1794900398048')
listed = subprocess.run(['node', 'scripts/measure-abbreviations.mjs', '--list', 'file-names'], cwd=root, capture_output=True, text=True)
(Path('/tmp/issue-1580-research') / 'staged-abbreviated-file-names.log').write_text(listed.stdout + listed.stderr)
added = set(subprocess.check_output(['git', 'diff', '--cached', '--name-only', '--diff-filter=A'], cwd=root, text=True).splitlines())
matches = [line for line in listed.stdout.splitlines() if any(name in line for name in added)]
print('exit:', listed.returncode, 'added:', len(added), 'new abbreviation matches:', len(matches))
print('\n'.join(matches))
