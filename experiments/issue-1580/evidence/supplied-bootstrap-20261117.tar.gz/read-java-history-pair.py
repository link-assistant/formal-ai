import subprocess, sys
first=int(sys.argv[1])
for page in range(first,first+2):
    subprocess.run(['python3','/tmp/issue-1580-research/read-java-history-page.py',str(page)],check=True)
