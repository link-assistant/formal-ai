from pathlib import Path
import datetime, gzip, hashlib, json

base=Path('/tmp/issue-1580-research/self-reference-checks')
out=Path('experiments/issue-1580/evidence/checks')
sha=lambda data:hashlib.sha256(data).hexdigest()
records=[]
for source in ['before.log','intermediate.log','after.log','maintained.log','regeneration.log','graph-delta.json']:
    data=(base/source).read_bytes()
    packed=gzip.compress(data,mtime=0)
    name='self-repository-reference-'+source+'.gz'
    (out/name).write_bytes(packed)
    records.append({'file':name,'bytes':len(data),'sha256':sha(data),'compressedSha256':sha(packed)})
sources=[]
for name in ['experiments/issue-1580/trace-template-ci.mjs','experiments/issue-1580/template-reference-graph.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs','docs/case-studies/issue-1580/templates/ci-reference-graphs.json']:
    data=Path(name).read_bytes()
    sources.append({'file':name,'sha256':sha(data)})
manifest={
 'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'primarySyntaxReference':'https://github.blog/changelog/2026-07-30-reference-same-repository-actions-with-self-repository-syntax/',
 'commands':[
  'timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-reference-graph.test.mjs',
  'timeout 600 node --test --test-concurrency=1 rust/tests/web/issue-1580-template-observations.test.mjs',
  'NODE_PATH=/tmp/issue-1580-research/node_modules node --max-old-space-size=96 experiments/issue-1580/trace-template-ci.mjs',
 ],
 'results':{
  'before':{'pass':2,'fail':3,'skip':0},
  'intermediate':{'pass':4,'fail':1,'skip':0,'explanation':'The new negative assertion incorrectly excluded an existing conservative sibling index expansion; corrected the assertion to check the unrelated file instead. Production expansion was retained.'},
  'after':{'pass':5,'fail':0,'skip':0},
  'maintained':{'pass':21,'fail':0,'skip':0},
  'regeneration':{'languages':8,'pinnedSourceBlobs':3007,'workflowRoots':48,'addedSelfRepositoryEdges':13,'addedFiles':0},
 },
 'limits':[
  'Lexical review aid, not complete execution closure or semantic verification.',
  'The pinned real templates already included the target files through other conservative paths; this repair adds explicit reference attribution.',
  'No hosted self-repository action, native runtime, or application build execution.',
  'C# active review is partial; full semantic reviews remain unfinished.',
  'Supplied scripts and decisions earn zero independent Formal AI reasoning/authorship credit.',
 ],
 'sources':sources,'files':records,
}
(out/'self-repository-references.json').write_text(json.dumps(manifest,indent=2)+'\n')

head='078849576b539e0e6adf2843306af16981d5c09a'
raw=(Path('/tmp/issue-1580-research')/('head-'+head[:9])/'runs.json').read_bytes()
runs=json.loads(raw)
assert len(runs)==24 and all(r['headSha']==head and r['status']=='completed' and r['conclusion']=='success' for r in runs)
ci=Path('experiments/issue-1580/evidence/ci')/head[:9]
ci.mkdir(exist_ok=True)
packed=gzip.compress(raw,mtime=0)
(ci/'runs.json.gz').write_bytes(packed)
(ci/'summary.json').write_text(json.dumps({'headSha':head,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':len(runs),'completed':len(runs),'success':len(runs),'failed':0,'active':0,'source':'gh run list --repo link-assistant/formal-ai --branch issue-1580-8d61a32a61e1 --commit '+head+' --limit 100 --json databaseId,workflowName,status,conclusion,createdAt,headSha','sourceSha256':sha(raw),'compressedSha256':sha(packed),'limits':'Scoped PR results do not execute main-only native runtime, application builds, benchmark capability, or live qualification.'},indent=2)+'\n')

path=Path('docs/case-studies/issue-1580/templates/README.md')
text=path.read_text()
text=text.replace('the current suite passes sixteen with the Java release cases','the Java checkpoint passed sixteen; the current suite passes twenty-one with reference-graph coverage')
old='Every visited file is checked against the pinned Git blob, and two bounded regressions exercise nested helpers and transitive source tampering. Full semantic review remains unfinished.'
new='Every visited file is checked against the pinned Git blob. Five bounded regressions cover local and self-repository actions, reusable workflows, nested JavaScript phases/helpers, unresolved paths and transitive source tampering. Full semantic review remains unfinished.'
assert text.count(old)==1
text=text.replace(old,new)
text+='\n## Self-repository reference correction\n\nGitHub supports [`$/` references to the running repository and commit](https://github.blog/changelog/2026-07-30-reference-same-repository-actions-with-self-repository-syntax/), including nested actions and reusable workflows. The C# workflow uses this valid syntax; its scoped actionlint compatibility exception already refers to upstream actionlint #711. The local review graph recognized only `./` and omitted explicit `$/` attribution. Three new cases fail before the repair; all five focused cases and the maintained 21-test entrypoint pass afterward. Missing, dynamic and escaping paths stay unresolved, and pinned-blob tampering still fails.\n\nRegenerating all eight graphs at the same source pins adds one C# and twelve Python self-repository edges. It adds no files to the real inventories: their target files were already present through other conservative paths. Complete logs, intermediate test-control correction, hashes and the exact edge delta are retained in `experiments/issue-1580/evidence/checks/self-repository-references.json`. This is an inventory repair, not hosted execution or completion of semantic review.\n'
path.write_text(text)

path=Path('experiments/issue-1580/work-plan.md')
text=path.read_text()+'\n## Self-repository references and hosted checkpoint\n\nAll 24 workflows on `078849576b539e0e6adf2843306af16981d5c09a` completed successfully; exact-head metadata is retained. During the partial C# review, verify valid `$/` syntax against GitHub\'s primary announcement and existing actionlint #711 rather than reporting it as an invalid template reference. Repair the lexical traversal, preserving conservative expansion and explicit unknowns. Focused cases: 5 pass; maintained suite: 21 pass; no skips. Three new regressions fail before the repair. All eight same-pin graphs regenerate with 13 added explicit edges and zero added files. Full semantic review, native/main runtime, benchmarks, historical cache cause, live identity and the other broad criteria remain open.\n'
path.write_text(text)

path=Path('docs/case-studies/issue-1580/README.md')
text=path.read_text().replace('PR head `078849576b` is still under hosted verification.','All 24 workflows on `078849576b` have now completed successfully; [exact-head metadata](../../../experiments/issue-1580/evidence/ci/078849576/summary.json) is retained. These scoped PR results do not complete the outstanding main-only criteria.')
text+='\n### Self-repository reference inventory\n\nThe partial C# review found a gap in this PR\'s lexical graph traversal: valid GitHub `$/` references lacked explicit edges. The repair follows reusable workflows, nested composite actions and JavaScript action phases, preserves unresolved/escaping paths, and checks every visited blob. Three new cases fail before the repair; all five focused cases and the maintained 21-test entrypoint pass afterward. Regeneration at all eight unchanged pins adds 13 explicit C#/Python edges and zero files because conservative paths already included those targets. [Full evidence](../../../experiments/issue-1580/evidence/checks/self-repository-references.json) retains the intermediate test-control correction as well. This inventory repair does not complete the C# or remaining full semantic reviews.\n'
path.write_text(text)
print('Archived complete self-reference logs, source hashes, 24 successful hosted identities, and updated review limits.')
