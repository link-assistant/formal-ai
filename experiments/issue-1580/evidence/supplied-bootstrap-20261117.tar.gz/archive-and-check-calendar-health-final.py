from pathlib import Path
import gzip,hashlib,json,os,resource,subprocess,sys,time
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
base=root/'experiments/issue-1580/evidence/checks/health-cache-fixtures/final-evidence'
base.mkdir(exist_ok=True)
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
for name in ['archive-round-bootstrap.py','archive-evidence.py']:
 subprocess.run([sys.executable,str(scratch/name)],cwd=root,check=True)
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256');env['PATH']=str(scratch/'shellcheck-v0.11.0')+':'+env['PATH']
gates='check-abbreviations,check-file-size,check-file-size-js-twin,check-changelog-fragment-js-twin,check-reconstructed-changelog,evidence-check#1'
cmd=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gates]
start=time.time();log=scratch/'calendar-health-final-evidence-gates.log'
with log.open('wb') as stream:run=subprocess.run(cmd,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
raw=log.read_bytes();(base/'gates.log.gz').write_bytes(gzip.compress(raw,mtime=0))
receipt={'command':cmd,'exitCode':run.returncode,'durationSeconds':round(time.time()-start,3),'rawSha256':hashlib.sha256(raw).hexdigest(),'rawBytes':len(raw),'rawLines':len(raw.splitlines()),'nativeExecuted':False,'independentAuthorshipCredit':0}
(base/'gates.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(raw.decode());print(json.dumps(receipt))
if run.returncode:raise SystemExit(run.returncode)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root).split(b'\0')
rows=[(str(Path(os.fsdecode(name))), (root/os.fsdecode(name)).stat().st_size) for name in untracked if name]
print(json.dumps({'untrackedFiles':len(rows),'largestNewFiles':sorted(rows,key=lambda row:row[1],reverse=True)[:8]}))
