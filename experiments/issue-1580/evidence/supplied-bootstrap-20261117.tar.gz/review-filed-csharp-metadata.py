from pathlib import Path
import json, subprocess

def run(args):
    return subprocess.run(args, check=True, text=True, capture_output=True).stdout
print(run(['git','branch','--show-current']))
print(run(['git','status','--short']))
print(run(['git','diff','--','docs/case-studies/issue-1580/README.md','docs/case-studies/issue-1580/templates/README.md','experiments/issue-1580/work-plan.md','experiments/issue-1580/upstream/csharp-changeset-output-collision-report.md','experiments/issue-1580/upstream/filed-issues.txt','experiments/issue-1580/upstream/template-report-identities.json']))
receipt = Path('experiments/issue-1580/evidence/checks/csharp-changeset-collision/filed-report.json')
print(receipt.read_text())
assert json.loads(receipt.read_text())['url'].endswith('/issues/111')
print('Metadata inspected; no commit or push performed.')
