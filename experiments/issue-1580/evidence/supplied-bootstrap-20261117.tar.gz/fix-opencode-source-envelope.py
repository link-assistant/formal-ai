import json
from pathlib import Path

js = '''/** Decode the path-bound OpenCode Read envelope, never a typed raw source value. */
function openCodeSourceRead(raw, expectedPath) {
  const frame = /^<path>([^\\n]+)<\\/path>\\n<type>file<\\/type>\\n<content>\\n([\\s\\S]*)\\n\\n\\(End of file - total ([0-9]+) lines\\)\\n<\\/content>$/u.exec(raw);
  if (frame === null || frame[1] !== expectedPath) return null;
  const rows = frame[2] === '' ? [] : frame[2].split('\\n');
  const numbered = rows.map(line => /^([0-9]+): (.*)$/u.exec(line));
  if (numbered.some(row => row === null)) return null;
  const first = numbered.length === 0 ? 1 : Number(numbered[0][1]);
  const total = Number(frame[3]);
  if (!Number.isSafeInteger(total) || first < 1 || numbered.some((row, index) => Number(row[1]) !== first + index)
    || first + numbered.length - 1 > total) return null;
  return { source: numbered.map(row => row[2]).join('\\n'), complete: first === 1 && numbered.length === total };
}

'''
for name in ['js/agentic/tool_result.mjs', 'ts/agentic/tool_result.mts']:
    p=Path(name);s=p.read_text();needle='export function sourceReadObservation(raw, explicitlyFailed, metadata = null, expectedPath = null) {'
    assert needle in s;s=s.replace(needle,js+needle,1)
    s=s.replace('const framed = metadata === null ? sourceFromAgentReadResult(raw) : null;', 'const openCode = metadata === null ? openCodeSourceRead(raw, expectedPath) : null;\n  const framed = metadata === null ? sourceFromAgentReadResult(raw) : null;',1)
    s=s.replace('(wholeFrame || (bound && status', '(wholeFrame || openCode?.complete === true || (bound && status',1)
    s=s.replace('source: error === null ? framed ?? raw : null', 'source: error === null ? framed ?? openCode?.source ?? raw : null',1)
    p.write_text(s)

native='''/// Decode only the exact path-bound OpenCode Read transport envelope.
fn opencode_source_read(raw: &str, expected_path: &str) -> Option<(String, bool)> {
    let (path, body) = raw.strip_prefix("<path>")?.split_once("</path>\\n<type>file</type>\\n<content>\\n")?;
    if path != expected_path || path.contains('\\n') {
        return None;
    }
    let body = body.strip_suffix("\\n</content>")?;
    let (numbered, footer) = body.rsplit_once("\\n\\n(End of file - total ")?;
    let total = footer.strip_suffix(" lines)")?.parse::<usize>().ok()?;
    // Match JavaScript's exact-integer range when reading untrusted line counts.
    if total as u128 > 9_007_199_254_740_991 {
        return None;
    }
    let rows = if numbered.is_empty() { Vec::new() } else { numbered.split('\\n').collect::<Vec<_>>() };
    let mut first = 1;
    let mut source = Vec::new();
    for (index, row) in rows.iter().enumerate() {
        let (number, text) = row.split_once(": ")?;
        if number.is_empty() || !number.bytes().all(|byte| byte.is_ascii_digit()) {
            return None;
        }
        let number = number.parse::<usize>().ok()?;
        if index == 0 { first = number; }
        if first == 0 || first.checked_add(index)? != number || number > total {
            return None;
        }
        source.push(text);
    }
    Some((source.join("\\n"), first == 1 && rows.len() == total))
}

'''
p=Path('rust/src/agentic_coding/tool_result/source_observation.rs');s=p.read_text();needle='/// A bare payload never declares provider success; typed metadata owns raw completeness.'
assert needle in s;s=s.replace(needle,native+needle,1)
needle='    let framed = metadata\n'
assert needle in s;s=s.replace(needle,'    let opencode = metadata.is_none().then(|| opencode_source_read(raw, expected_path)).flatten();\n'+needle,1)
s=s.replace('&& (whole_frame\n','&& (whole_frame\n            || opencode.as_ref().is_some_and(|(_, complete)| *complete)\n',1)
s=s.replace('then(|| framed.unwrap_or_else(|| raw.to_owned()));','then(|| framed.or_else(|| opencode.map(|(source, _)| source)).unwrap_or_else(|| raw.to_owned()));',1)
s+='''
#[cfg(test)]
mod opencode_tests {
    use super::*;

    #[test]
    fn shared_opencode_read_envelopes_preserve_source_and_provenance() {
        let fixtures: Value = serde_json::from_str(include_str!(concat!(env!("CARGO_MANIFEST_DIR"), "/../data/parity/issue-1580-opencode-read-envelope.json"))).unwrap();
        for row in fixtures.as_array().unwrap() {
            let raw = row["raw"].as_str().unwrap();
            let observed = source_read_observation(raw, row["failed"].as_bool().unwrap_or(false), row.get("metadata"), row["path"].as_str().unwrap());
            assert_eq!(observed.source.as_deref(), row["source"].as_str(), "{}", row["id"]);
            assert_eq!(observed.complete, row["complete"].as_bool().unwrap(), "{}", row["id"]);
        }
    }
}
''';p.write_text(s)

def frame(body,total=2,path='/tmp/work/source.txt'):
    return f'<path>{path}</path>\n<type>file</type>\n<content>\n{body}\n\n(End of file - total {total} lines)\n</content>'
base=frame('1: first\n2:   café <content>')
fixtures=[]
def add(id,raw,source,complete=False,**kw):
    fixtures.append(dict(id=id,path='/tmp/work/source.txt',raw=raw,source=source,complete=complete,**kw))
add('whole',base,'first\n  café <content>',True)
add('empty',frame('',0),'',True)
add('blank-last-row',frame('1: first\n2: '),'first\n',True)
add('slice-offset',frame('2: second\n3: third',3),'second\nthird')
add('partial-count',frame('1: first\n2: second',3),'first\nsecond')
for id,raw in [('wrong-path',base.replace('/tmp/work/source.txt','/tmp/other/source.txt')),('skipped-line',base.replace('2:','3:')),('zero-line',base.replace('1:','0:')),('nonnumeric',base.replace('1:','x:')),('unframed',base.replace('<type>file</type>\n','')),('truncated',base.replace('(End of file - total 2 lines)','(Output truncated)')),('extra-suffix',base+'extra')]:add(id,raw,raw)
add('typed-raw-wrapper-is-source',base,base,True,metadata=dict(path='/tmp/work/source.txt',success=True,complete=True,format='raw'))
add('typed-opaque-wrapper-is-source',base,base,metadata=dict(path='/tmp/work/source.txt',complete=False,format='opaque'))
add('outer-failure',base,None,failed=True)
p=Path('data/parity/issue-1580-opencode-read-envelope.json');p.write_text(json.dumps(fixtures,ensure_ascii=False,indent=2)+'\n')
p=Path('rust/tests/web/source-read-provenance.test.mjs');s=p.read_text();s=s.replace("import assert from 'node:assert/strict';","import assert from 'node:assert/strict';\nimport { readFileSync } from 'node:fs';",1)
s+='''
const opencodeRows = JSON.parse(readFileSync(new URL('../../../data/parity/issue-1580-opencode-read-envelope.json', import.meta.url)));
for (const row of opencodeRows) {
  test('OpenCode path-bound source envelope: ' + row.id, () => {
    const observation = sourceReadObservation(row.raw, row.failed ?? false, row.metadata ?? null, row.path);
    assert.equal(observation.source, row.source);
    assert.equal(observation.complete, row.complete);
    assert.equal(observation.status, row.failed ? SourceReadStatus.Failure : row.metadata?.success ? SourceReadStatus.Success : SourceReadStatus.Unknown);
  });
}
''';p.write_text(s)
print('Added strict OpenCode transport decoding and 15 shared native/JavaScript regression fixtures.')
