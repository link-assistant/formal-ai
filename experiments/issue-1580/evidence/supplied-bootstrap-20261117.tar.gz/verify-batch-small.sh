set -eu
sed -n '570,635p' rust/src/solver.rs
python3 /tmp/issue-1580-research/fix-lint-and-test.py
timeout 600 node --test --test-concurrency=1 rust/tests/web/documentation-only-ci-policy.test.mjs > /tmp/issue-1580-research/documentation-reporting.log 2>&1 || { tail -n 80 /tmp/issue-1580-research/documentation-reporting.log; exit 1; }
tail -n 12 /tmp/issue-1580-research/documentation-reporting.log
rustfmt --check rust/src/solver.rs
node scripts/documentation-only-ci-policy.mjs
