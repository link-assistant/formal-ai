#!/bin/sh
set -eu
python3 /tmp/issue-1580-research/finish-evidence-commit.py
git add -A docs/case-studies/issue-1580 experiments/issue-1580
git diff --cached --check
git commit -m 'docs(ci): preserve issue 1580 evidence and complete template inventories'
git status --porcelain | wc -l
