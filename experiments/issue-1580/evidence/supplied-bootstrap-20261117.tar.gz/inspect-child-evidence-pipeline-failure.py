from pathlib import Path
import gzip,hashlib,json,subprocess
base=Path('experiments/issue-1580/evidence/ci/child-evidence-ffebedb1')
scratch=Path('/tmp/issue-1580-research/ci-logs/child-evidence-ffebedb1')
run=44276631643
raw=subprocess.check_output(['gh','api',f'repos/link-assistant/formal-ai/actions/runs/{run}'])
metadata=json.loads(raw)
assert metadata['head_sha']=='ffebedb16802b73499db4a5bc937808c51ef533d' and metadata['conclusion']=='failure'
(base/'early-failed-run.json.gz').write_bytes(gzip.compress(raw,mtime=0))
pages=json.loads(subprocess.check_output(['gh','api',f'repos/link-assistant/formal-ai/actions/runs/{run}/jobs?per_page=100','--paginate','--slurp']))
(base/'early-failed-jobs.json.gz').write_bytes(gzip.compress((json.dumps(pages)+'\n').encode(),mtime=0))
path=scratch/'early-failed-workflow.log'
with path.open('wb') as stream:
    subprocess.run(['gh','run','view',str(run),'--repo','link-assistant/formal-ai','--log'],stdout=stream,check=True)
raw=path.read_bytes();packed=gzip.compress(raw,mtime=0)
(base/'early-failed-workflow.log.gz').write_bytes(packed)
rows=[]
for page in pages:
    for job in page['jobs']:
        if job['conclusion'] not in ['success','skipped']:
            rows.append({'id':job['id'],'name':job['name'],'conclusion':job['conclusion'],'failedSteps':[s for s in job['steps'] if s['conclusion']=='failure']})
lines=raw.decode().splitlines()
matches=[i for i,line in enumerate(lines) if any(token in line for token in ['error:', '::error', 'Error:', 'FAILED','test result:'])]
selected=set()
for i in matches:
    selected.update(range(max(0,i-3),min(len(lines),i+7)))
print(json.dumps({'run':run,'failedJobs':rows,'rawLines':len(lines),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()},indent=2))
for i in sorted(selected):print(str(i+1)+': '+lines[i])
