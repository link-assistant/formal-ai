from pathlib import Path

root=Path('/tmp/gh-issue-solver-1794900398048')
checkpoint=root/'docs/case-studies/issue-1580/calendar-seed-checkpoint.md'
text=checkpoint.read_text()
text=text.replace('runtime behavior after the scalar-row change. Next-head hosted checks and the\ncomplete current-source JavaScript gate set remain pending.', 'runtime behavior after the scalar-row change. The first complete local gate run\npasses 86 checks with 52 explicit exclusions, zero failures. It predates the\nhealth/cache fixture additions below; final combined-source gates and next-head\nhosted checks remain pending.')
text=text.replace('The cancelled main Layered aggregate is partial; unavailable job payloads are\nnot treated as inspected. Targeted failure-payload review is not full-log review.', 'The cancelled main Layered aggregate is partial. All five failed JavaScript job\nlogs are now recovered individually with their own hashes. Targeted failure\npayload review is separate from full-log review. The native panic index contains\n39 headers; long payload lines and truncated job tails remain explicitly unread\nor incomplete rather than being counted as verified behavior.')
needle='## Evidence and unfinished acceptance\n'
section='''## Health and offline cache fixture replay

Recovered [main Layered run 44188508228](https://github.com/link-assistant/formal-ai/actions/runs/44188508228)
has two further stale fixtures. Group 5 job `134411832462`, lines 2253–2285,
expects a health object without the supported `mode` field. Group 7 job
`134411832372`, lines 2710–2728, expects a baseline after deleting the live-fetch
setting, although reads are now enabled by default. The analogous group 2
version-cache fixture is already repaired on this branch, but lacked fast-lane
selection.

Before the new fixture repair, the complete health file passes 8/9 cases and the
Hive file passes 8/9; the existing version-cache repair passes 6/6. The replay
places an offline `curl` stand-in first on PATH: it supplies only the two
checkout publisher shapes and records every call, with no actual network I/O.
The Hive failure deterministically obtains a live checkout pin from that
stand-in. Health production behavior and default-on source-read policy remain
unchanged.

The health expectation includes `read_write` and checks the `read_only` result
with separate configured/active paths, unchanged released-schema bytes, and no
new files. The entire Hive fixture file disables live source reads and restores
the caller setting. Cache/baseline replay also retains an explicit offline
setting inside its temporary environment.

After the repair, all 24 cases in the three complete files pass with zero mock
transport calls; all 15 fast-profile and four ledger checks pass. The three files
are selected in the fast PR inventory, now 243 files, and each main failure has a
ledger entry. Complete original/repaired fixture bytes, test logs, hashes and
mock-call observations are under
`experiments/issue-1580/evidence/checks/health-cache-fixtures/`. Final full gates
and hosted checks for this combined batch are tracked separately.

'''
assert text.count(needle)==1
text=text.replace(needle,section+needle)
checkpoint.write_text(text)
plan=root/'experiments/issue-1580/work-plan.md'
with plan.open('a') as stream:
 stream.write('''

## Health/cache fixtures and recovered main logs

Recover all five failed JavaScript job logs from cancelled main Layered run
44188508228. Reproduce the health response omission and live-read cache fixture
failure using a recorded offline curl stand-in; 8/9 cases pass before each fix.
Preserve the supported health mode and default-on production reads. After the
fixture repairs, all 24 complete health/cache cases pass with zero transport
calls, followed by 15 fast-profile and four ledger checks. Add all three existing
files to the fast PR inventory and record the main-only failures. Final combined
shared-data gates and next-head hosted checks remain pending.

Java historical text review reaches pages 1–37/254, 34 complete files and one
partial, 1,662 fully read source lines. The first OSV JSON line is complete;
only fragments 1–3/66 of its second line are read. Broader semantic review and
native/runtime acceptance remain unfinished. Supplied work earns zero
independent authorship credit.
''')
print('Updated checkpoint and active work plan; final gates and broad acceptance remain unfinished.')
