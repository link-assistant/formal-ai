from pathlib import Path
import gzip,json,subprocess
base=Path('experiments/issue-1580/evidence/ci/native-b367d603/opener-round-preflight')
for name,endpoint in [('issue-comments','issues/1580/comments'),('pull-request-comments','issues/1581/comments'),('pull-request-inline-comments','pulls/1581/comments'),('pull-request-reviews','pulls/1581/reviews')]:
    run=subprocess.run(['gh','api','repos/link-assistant/formal-ai/'+endpoint,'--paginate'],capture_output=True);assert run.returncode==0,run.stderr.decode()
    old=json.loads(gzip.decompress((base/(name+'.json.gz')).read_bytes()));fresh=json.loads(run.stdout)
    assert fresh==old,'Read changed '+name+' before pushing'
    print(name,len(fresh),'unchanged')
print('COMMITS',Path('/tmp/issue-1580-research/opener-publication-commits.json').read_text())
print('STATUS',subprocess.check_output(['git','status','--porcelain'],text=True))
