from pathlib import Path
import gzip,hashlib,json,re,subprocess
base=Path('experiments/issue-1580/evidence/checks/main-merge-058e9bef')
r=subprocess.run(['git','diff','--check','--cached'],capture_output=True)
raw=r.stdout+r.stderr;(base/'inherited-log-whitespace.log.gz').write_bytes(gzip.compress(raw,mtime=0))
paths=sorted(set(line.split(':',1)[0] for line in raw.decode().splitlines() if re.search(r':\d+: trailing whitespace\.$',line)))
assert len(paths)==2 and all(p.startswith(('dev/log/issues/1592/','dev/log/issues/1594/')) for p in paths),paths
for p in paths:
 assert Path(p).read_bytes()==subprocess.check_output(['git','show','origin/main:'+p])
print(json.dumps({'inheritedWhitespacePaths':paths,'allBytesEqualToMain':True,'checkExitCode':r.returncode,'rawSha256':hashlib.sha256(raw).hexdigest(),'rawBytes':len(raw)}))
subprocess.run(['git','diff','--check','--cached','--','.',':!dev/log/'],check=True)
log=Path('/tmp/issue-1580-research/commit-merge-main-058e9bef.log')
with log.open('w') as out:r=subprocess.run(['git','commit','-m','Merge main retention and multilingual summary fixes'],stdout=out,stderr=subprocess.STDOUT)
print('COMMIT',r.returncode,'\n'.join(log.read_text().splitlines()[:4]));assert r.returncode==0
print('HEAD',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
print('UNSTAGED',subprocess.check_output(['git','diff','--name-only'],text=True))
