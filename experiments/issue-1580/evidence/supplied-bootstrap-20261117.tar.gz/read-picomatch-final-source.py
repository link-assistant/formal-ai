from pathlib import Path
import json, subprocess

for name in ['packages/picomatch-compat/lib/extglob-guard.js','rust/tests/web/picomatch-security-backport.test.mjs','packages/picomatch-compat/README.md','packages/picomatch-compat/package.json','changelog.d/20261117_190000_picomatch_security_backport.md','/tmp/issue-1580-research/archive-round-bootstrap.py','/tmp/issue-1580-research/archive-evidence.py']:
    path=Path(name)
    lines=path.read_text().splitlines()
    print('FILE',name,'LINES',len(lines))
    for number,line in enumerate(lines,1): print(f'{number}: {line}')
result=subprocess.run(['git','diff','--','desktop/package.json','desktop/package-lock.json','vscode/package.json','vscode/package-lock.json','data/meta/abbreviation-ratchet.lino','data/benchmarks/fast-pull-request-javascript-tests.json'],text=True,capture_output=True)
print('INTEGRATION DIFF',result.stdout,result.stderr)
receipt=json.loads(Path('experiments/issue-1580/evidence/checks/picomatch-single-branch/sealed-complete-gates.json').read_text())
print('GATE FINISHED',receipt['finished'],'ALL PASSED',receipt.get('allPassed'))
if receipt['finished']:
    print('CHECKS',json.dumps(receipt['checks']))
