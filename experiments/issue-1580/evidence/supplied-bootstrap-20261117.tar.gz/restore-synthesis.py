from pathlib import Path

solver = Path('rust/src/solver.rs')
source = solver.read_text()
start = source.index('    fn run_meta_procedure(')
end = source.index('\n    }\n}', start) + len('\n    }')
method = source[start:end].replace('    fn run_meta_procedure(', '    pub(crate) fn run_meta_procedure(', 1)
solver.write_text(source[:start] + source[end:])
production = Path('rust/src/meta_executor/production.rs')
source = production.read_text()
source += '\n// Keep the production adapter with its host rather than the dispatch loop.\n'
source += 'impl crate::solver::UniversalSolver {\n' + method + '\n}\n'
source = source.replace('use std::cell::{Cell, RefCell};', '''use std::cell::{Cell, RefCell};
use crate::engine::{ConversationTurn, SymbolicAnswer};
use crate::event_log::EventLog;
use crate::intent_formalization::IntentFormalizationCache;
use crate::probability::ProbabilityStore;''')
production.write_text(source)

synthesis = Path('rust/src/solver_synthesis.rs')
source = synthesis.read_text().replace('    source_result_ids: Vec<String>,', '''    source_result_ids: Vec<String>,
    /// Only an answer assembled from child answers depends on their verdicts.
    consumes_sub_answers: bool,''', 1)
source = source.replace('    checks.extend(\n', '    if candidate.consumes_sub_answers {\n        checks.extend(\n', 1)
source = source.replace('    );\n    let test = TaskTest {', '        );\n    }\n    let test = TaskTest {', 1)
source = source.replace('        requires: rule(&format!("{}-requires", candidate.relation))\n            .into_iter()\n            .next(),', '''        requires: candidate.consumes_sub_answers.then(|| {
            rule(&format!("{}-requires", candidate.relation)).into_iter().next()
        }).flatten(),''', 1)
source = source.replace('        sub_results,\n    ))', '        sub_results,\n        false,\n    ))', 2)
source = source.replace('        sub_results,\n    ))', '        sub_results,\n        true,\n    ))', 1)
source = source.replace('    sub_results: &[SolvedSubImpulse],\n) -> ComposedCandidate {', '    sub_results: &[SolvedSubImpulse],\n    consumes_sub_answers: bool,\n) -> ComposedCandidate {', 1)
source = source.replace('        source_result_ids,\n    }', '        source_result_ids,\n        consumes_sub_answers,\n    }', 1)
source += '''
#[cfg(test)]
mod parent_tests {
    use super::*;

    fn unresolved() -> Vec<SolvedSubImpulse> {
        vec![SolvedSubImpulse {
            impulse_id: "input".into(), result_id: "unresolved".into(),
            text: "x = 3".into(), independent: true,
            intent: "unknown".into(), answer: "No answer".into(),
        }]
    }

    #[test]
    fn evaluated_source_operands_do_not_consume_unresolved_child_answers() {
        let parts = unresolved();
        let mut log = EventLog::new();
        let candidate = compose_algebra_substitution(
            "Given x = 3 and y = 4, evaluate (x^2 + 2y).", &mut log, &parts
        ).expect("source operands evaluate");
        assert_eq!(candidate.answer, "17");
        assert!(parent_verdict(&candidate, &child_outcomes(&parts)).passed);
    }

    #[test]
    fn aggregation_still_rejects_an_unresolved_consumed_answer() {
        let parts = unresolved();
        let candidate = candidate("compound_response", "No answer".into(),
            ("aggregation", 1), &parts, true);
        assert!(!parent_verdict(&candidate, &child_outcomes(&parts)).passed);
    }
}
'''
synthesis.write_text(source)
test = Path('rust/tests/unit/specification/debug_session.rs')
test.write_text(test.read_text().replace('rust/src/solver_handlers/mod.rs:finalize_simple', 'rust/src/solver_helpers/mod.rs:record_answer_test'))
