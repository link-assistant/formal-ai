import pathlib
import subprocess

for args in [
    ['rg','--no-ignore','-n','text-summary-cause|lexeme "because"','data/seed'],
    ['rg','-n','unknown|meaning|lexicon|export','js/agentic/crate/page_formalization.mjs','js/worker/formal_ai_worker_page_formalization.js'],
]:
    subprocess.run(args,check=False)
print('FILE js/agentic/crate/page_formalization.mjs')
for index,line in enumerate(pathlib.Path('js/agentic/crate/page_formalization.mjs').read_text().splitlines()[:150],1):
    print(f'{index}: {line}')
