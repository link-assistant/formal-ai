from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/ci/published-6b1d75a6/attempt-2';base.mkdir(exist_ok=True)
head='6b1d75a62a610e58914ef594c107f3fa402ded9d'
for ident,name in [(44207032757,'layered'),(44207033000,'pipeline')]:
 value=json.loads(subprocess.check_output(['gh','run','view',str(ident),'--repo','link-assistant/formal-ai','--json','databaseId,headSha,status,conclusion,attempt,jobs,url,createdAt,updatedAt'],cwd=root,text=True))
 assert value['headSha']==head and value['attempt']==2
 if value['status']!='completed':print(json.dumps({'run':ident,'status':value['status']}));continue
 (base/f'{name}-{ident}.json').write_text(json.dumps(value,indent=2)+'\n');target=base/f'{name}-{ident}.log.gz'
 if target.exists():data=gzip.decompress(target.read_bytes())
 else:
  run=subprocess.run(['gh','run','view',str(ident),'--repo','link-assistant/formal-ai','--log'],cwd=root,capture_output=True);assert run.returncode==0,run.stderr.decode();data=run.stdout;target.write_bytes(gzip.compress(data,mtime=0))
 receipt={'run':ident,'head':head,'attempt':2,'rawSha256':hashlib.sha256(data).hexdigest(),'rawBytes':len(data),'rawLines':len(data.splitlines()),'log':target.name,'failures':[{key:job[key] for key in ['databaseId','name','conclusion']} for job in value['jobs'] if job['conclusion']=='failure'],'independentAuthorshipCredit':0}
 (base/f'{name}-{ident}-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
 for number,line in enumerate(data.decode().splitlines(),1):
  if any(marker in line for marker in ['not ok ','##[error]','curl 28','bad pack header','could not fetch']):print(f'{name}:{number}: {line[:600]}')
