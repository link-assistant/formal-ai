from pathlib import Path
import gzip, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
for argv in [
    ['git', 'diff', '--stat'],
    ['git', 'diff', '7e89122c9d030b3af5eec2d346141bba3ff3fdab', '--',
     'rust/src/solver_handlers/verifiable_task.rs',
     'rust/tests/unit/issue_1133_hive_mind_three_runs/extended.rs',
     'rust/tests/unit/docs_requirements/agent_cli_shell.rs',
     'rust/tests/unit/specification/formalization.rs'],
]:
    result = subprocess.run(argv, cwd=root, capture_output=True, text=True)
    assert result.returncode == 0
    print(result.stdout)
for pattern in ['**/catalog-payload-comparison.json', '**/formalization-answer-comparison.json']:
    for path in (root / 'experiments/issue-1580/evidence/ci/main-015a6831').glob(pattern):
        print('ARTIFACT', path.relative_to(root))
        print(path.read_text())
snapshot = root / 'experiments/issue-1580/evidence/ci/checkout-7e89122c/refresh-20261118T014101Z/pull-request.json.gz'
pr = json.loads(gzip.decompress(snapshot.read_bytes()))
print('CURRENT PR BODY', pr['body'])
