from pathlib import Path
import gzip,hashlib,json,subprocess
folder=Path('experiments/issue-1580/evidence/checks')
manifest_path=folder/'self-repository-references.json'
manifest=json.loads(manifest_path.read_text())
data=Path('/tmp/issue-1580-research/self-reference-checks/gates.log').read_bytes()
assert b'4/4 passed or skipped; failed: none' in data and b'SKIP' not in data
name='self-repository-reference-gates.log.gz'
packed=gzip.compress(data,mtime=0)
(folder/name).write_bytes(packed)
manifest['files'].append({'file':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'compressedSha256':hashlib.sha256(packed).hexdigest()})
manifest['commands'].append('node experiments/formal_ai_subagent/local-gates.mjs --only check-file-size,check-file-size-js-twin,check-changelog-fragment-js-twin,check-ci-speed')
manifest['results']['gates']={'pass':4,'fail':0,'skip':0}
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
for row in manifest['files']:
    packed=(folder/row['file']).read_bytes()
    assert hashlib.sha256(packed).hexdigest()==row['compressedSha256']
    assert hashlib.sha256(gzip.decompress(packed)).hexdigest()==row['sha256']
for row in manifest['sources']:
    assert hashlib.sha256(Path(row['file']).read_bytes()).hexdigest()==row['sha256']
subprocess.run(['git','diff','--check'],check=True)
print(subprocess.check_output(['git','diff','--stat'],text=True))
names=['experiments/issue-1580/trace-template-ci.mjs','experiments/issue-1580/template-reference-graph.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs','experiments/issue-1580/work-plan.md','docs/case-studies/issue-1580/README.md','docs/case-studies/issue-1580/templates/README.md']
print(subprocess.check_output(['git','diff','--',*names],text=True))
print(subprocess.check_output(['git','status','--short'],text=True))
