from pathlib import Path
from datetime import datetime, timezone
import subprocess, json, gzip, hashlib

root = Path('.')
base = root / 'experiments/issue-1580/evidence/checks/decoded-grammar-values'
out = base / 'publication-preflight'
assert not out.exists()
out.mkdir()
prior = root / 'experiments/issue-1580/evidence/checks/task-quotation-boundaries/publication-preflight'
head = '04a468f53549f0825999c1dd9e53210476723106'
branch = 'issue-1580-8d61a32a61e1'
records = []
def run(label, command, parsed=False):
    result = subprocess.run(command, capture_output=True)
    for name, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
        (out / (label + '.' + name + '.gz')).write_bytes(gzip.compress(raw, mtime=0))
    records.append({'label': label, 'command': command, 'exitCode': result.returncode, 'stdoutBytes': len(result.stdout), 'stdoutSha256': hashlib.sha256(result.stdout).hexdigest()})
    assert result.returncode == 0, (label, result.stderr.decode())
    return json.loads(result.stdout) if parsed else result.stdout.decode().strip()
assert run('branch', ['git', 'branch', '--show-current']) == branch
assert run('head', ['git', 'rev-parse', 'HEAD']) == head
issues = run('issue-view', ['gh', 'issue', 'view', 'https://github.com/link-assistant/formal-ai/issues/1580', '--json', 'title,body,comments'], True)
old_issue = json.loads(gzip.decompress((prior / 'issue.stdout.gz').read_bytes()))
assert issues['body'] == old_issue['body']
for label, endpoint in [('issue-comments', 'issues/1580/comments'), ('pull-request-comments', 'issues/1581/comments'), ('inline-comments', 'pulls/1581/comments'), ('reviews', 'pulls/1581/reviews')]:
    data = run(label, ['gh', 'api', 'repos/link-assistant/formal-ai/' + endpoint, '--paginate', '--slurp'], True)
    old = json.loads(gzip.decompress((prior / (label + '.stdout.gz')).read_bytes()))
    flatten = lambda pages: [row for page in pages for row in page]
    identity = lambda row: {key: row.get(key) for key in ['id', 'body', 'state', 'updated_at', 'submitted_at']}
    rows = flatten(data)
    same = list(map(identity, rows)) == list(map(identity, flatten(old)))
    print(json.dumps({'label': label, 'count': len(rows), 'unchanged': same}), flush=True)
    assert same
subissues = run('subissues', ['gh', 'api', 'repos/link-assistant/formal-ai/issues/1580/sub_issues?per_page=100', '--paginate', '--slurp'], True)
assert not [row for page in subissues for row in page]
pr = run('pull-request', ['gh', 'pr', 'view', '1581', '--repo', 'link-assistant/formal-ai', '--json', 'title,body,isDraft,headRefOid,baseRefName'], True)
assert pr['headRefOid'] == head and pr['isDraft']
assert pr['body'] == Path('/tmp/issue-1580-research/quotation-final-pr-body.md').read_text()
run('fetch-main', ['git', '-c', 'gc.auto=0', 'fetch', 'origin', 'main'])
run('main-ancestor', ['git', 'merge-base', '--is-ancestor', 'origin/main', 'HEAD'])
main = run('main', ['git', 'rev-parse', 'origin/main'])
for status in ['in_progress', 'queued']:
    assert run('runs-' + status, ['gh', 'run', 'list', '--repo', 'link-assistant/formal-ai', '--branch', branch, '--status', status, '--json', 'databaseId,workflowName,headSha'], True) == []
summary = {'complete': True, 'observedAt': datetime.now(timezone.utc).isoformat(), 'head': head, 'main': main, 'mainMerged': True, 'requiredSubIssues': 0, 'feedbackUnchanged': True, 'knownCompletedFailures': [44242408037, 44242407754], 'noActiveRuns': True, 'records': records, 'independentAuthorshipCredit': 0}
(out / 'outcome.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items() if key != 'records'}, indent=2))
