from pathlib import Path
import json
from collections import Counter

base=Path('/tmp/issue-1580-research/templates/java-complete')
data=json.loads(Path('docs/case-studies/issue-1580/templates/java-active-semantic-review.json').read_text())
print('review keys',list(data))
rows=json.loads(Path('/tmp/issue-1580-research/templates/java-complete-inventory.json').read_text())
print('historical paths')
total=Counter()
for row in rows:
 p=row['path']
 if not p.startswith('dev/log/'):
  continue
 b=(base/p).read_bytes()
 lines=b.decode('utf-8').splitlines()
 suffix=Path(p).suffix
 total[suffix]+=len(lines)
 print(json.dumps({'path':p,'lines':len(lines),'bytes':len(b),'gitBlob':row['gitBlob']},ensure_ascii=False))
print('total lines by suffix',dict(total))
