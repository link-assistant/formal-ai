from pathlib import Path
import datetime, gzip, hashlib, json, re, subprocess

repo = 'link-assistant/formal-ai'
branch = 'issue-1580-8d61a32a61e1'
head = '0f90c0a7a3bdd77b7d31c276a180d5ee297e57f6'
out = Path('experiments/issue-1580/evidence/ci/0f90c0a7a/attempt-1')
out.mkdir(parents=True, exist_ok=True)
def run(args):
    return subprocess.run(args, check=True, capture_output=True).stdout
fields = 'databaseId,conclusion,createdAt,headSha,status,workflowName'
recent = json.loads(run(['gh','run','list','--repo',repo,'--branch',branch,'--limit','5','--json',fields]))
print('RECENT FIVE', json.dumps(recent))
runs = json.loads(run(['gh','run','list','--repo',repo,'--branch',branch,'--limit','100','--json',fields]))
runs = [row for row in runs if row['headSha'] == head]
(out/'runs.json').write_text(json.dumps(runs, indent=2)+'\n')
failures = [row for row in runs if row['status']=='completed' and row['conclusion'] not in ('success','skipped')]
for row in failures:
    run_id = str(row['databaseId'])
    raw = run(['gh','run','view',run_id,'--repo',repo,'--json','databaseId,conclusion,createdAt,headSha,status,workflowName,jobs,attempt,url'])
    detail = json.loads(raw)
    assert detail['headSha'] == head and detail['attempt'] == 1
    (out/(run_id+'.json')).write_bytes(raw)
    log = run(['gh','run','view',run_id,'--repo',repo,'--log'])
    (out/(run_id+'.log.gz')).write_bytes(gzip.compress(log, mtime=0))
    print('FAILED RUN', json.dumps({key:value for key,value in detail.items() if key!='jobs'}))
    print('NONPASSING JOBS',json.dumps([{key:job.get(key) for key in ('name','conclusion','databaseId','url','steps')} for job in detail['jobs'] if job['conclusion'] not in ('success','skipped')]))
    lines = log.decode(errors='replace').splitlines()
    matches = [(i,line) for i,line in enumerate(lines,1) if re.search(r'##\[error\]|not ok\b|Error:|fatal:|error:|FAIL\b|exceeds Maintained|AssertionError',line)]
    assert len(matches)<100, 'Use narrower log review for large failures'
    for number,line in matches: print('LOG',number,line[:1800])
    summary = {'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'run':int(run_id),'attempt':1,'rawLogSha256':hashlib.sha256(log).hexdigest(),'rawLogBytes':len(log),'rawLogLines':len(lines),'selectedErrorLines':[number for number,_ in matches],'allHeadRuns':len(runs),'completed':sum(row['status']=='completed' for row in runs),'failures':failures,'claim':'Original failure preserved for diagnosis; no passing retry or fix is inferred.'}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Preserved all current-head failures:',len(failures))
