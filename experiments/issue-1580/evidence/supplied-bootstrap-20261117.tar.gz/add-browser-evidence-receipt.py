from pathlib import Path
import subprocess,os,signal,json
p=Path('experiments/issue-1580/browser-meaning-server.py')
s=p.read_text().replace('import hashlib\n','import hashlib\nimport gzip\n')
needle='    def do_GET(self):\n'
assert s.count(needle)==1
s=s.replace(needle,'''    def do_POST(self):
        # Keep observed browser data separate from production routes and source.
        if self.path != "/__experiment_observation" or self.server.saved_observation:
            self.send_error(404)
            return
        size = int(self.headers.get("Content-Length", "0"))
        if not 0 < size <= 524288:
            self.send_error(413)
            return
        payload = self.rfile.read(size)
        observation = json.loads(payload)
        phase = "before" if self.server.server_port == 8048 else "after"
        assert observation["phase"] == phase and observation["complete"] is True
        out = ROOT / "experiments/issue-1580/evidence/checks/browser-meaning-hydration/browser"
        out.mkdir(parents=True, exist_ok=True)
        (out / (phase + ".json.gz")).write_bytes(gzip.compress(payload, mtime=0))
        receipt = {"phase": phase, "sha256": hashlib.sha256(payload).hexdigest(),
                   "bytes": len(payload), "port": self.server.server_port}
        (out / (phase + "-receipt.json")).write_text(json.dumps(receipt, indent=2) + "\\n")
        self.server.saved_observation = True
        response = json.dumps(receipt).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(response)))
        self.end_headers()
        self.wfile.write(response)

'''+needle)
s=s.replace('    server.request_count = 0\n','    server.request_count = 0\n    server.saved_observation = False\n')
p.write_text(s)
script=Path('experiments/issue-1580/capture-meaning-hydration-browser.js')
assert not script.exists()
script.write_text('''// Supplied Playwright MCP experiment: zero independent authorship credit.
async (page) => {
  await page.setViewportSize({width:1120,height:1000});
  await page.context().route('**/*', route => {
    const url = new URL(route.request().url());
    return ['127.0.0.1','localhost'].includes(url.hostname) ? route.continue() : route.abort('blockedbyclient');
  });
  const results = [];
  for (const [phase,port] of [['before',8048],['after',8049]]) {
    await page.goto(`http://127.0.0.1:${port}/meaning-regression/`);
    await page.waitForFunction(() => window.harnessComplete || window.harnessError, {}, {timeout:50000});
    const observed = await page.evaluate(async (phase) => {
      if (window.harnessError || !window.harnessComplete) throw new Error(window.harnessError || 'Incomplete harness');
      const observation = {phase,complete:true,url:location.href,viewport:{width:innerWidth,height:innerHeight},
        userAgent:navigator.userAgent,observed:window.observed,body:document.body.innerText,
        nativeBehaviorVerified:false,productionAppUiVerified:false,independentAuthorshipCredit:0};
      const response = await fetch('/__experiment_observation', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(observation,null,2)+'\\n'});
      if (!response.ok) throw new Error('Browser evidence save failed: '+response.status);
      return {receipt:await response.json(),summary:observation.observed.map(x=>({prompt:x.prompt,intent:x.intent,engine:x.engine}))};
    },phase);
    const expected = phase === 'before' ? ['unknown','unknown'] : ['web_search','unknown'];
    if (JSON.stringify(observed.summary.map(x=>x.intent)) !== JSON.stringify(expected)) throw new Error('Unexpected sibling routes');
    await page.screenshot({path:`/tmp/gh-issue-solver-1794900398048/docs/screenshots/issue-1580/meaning-hydration-${phase}.png`,fullPage:true,scale:'css'});
    results.push({phase,...observed});
  }
  return results;
};
''')
receipt=Path('/tmp/issue-1580-research/browser-meaning-harness-server-pid.json')
pid=json.loads(receipt.read_text())['pid']
try:
    if b'browser-meaning-server.py' in Path(f'/proc/{pid}/cmdline').read_bytes():os.kill(pid,signal.SIGTERM)
except FileNotFoundError:pass
with Path('/tmp/issue-1580-research/browser-meaning-capture-server.log').open('wb') as log:
    child=subprocess.Popen(['python3',str(p)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
receipt=Path('/tmp/issue-1580-research/browser-meaning-capture-server-pid.json')
receipt.write_text(json.dumps({'pid':child.pid,'maximumSeconds':600,'maximumRequestsPerPort':2000})+'\n')
print(receipt.read_text())
