from pathlib import Path
import subprocess,gzip,json,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/cnl-canonical-data'
p=root/'rust/tests/web/cnl-output.test.mjs';s=p.read_text();old="    const node = parseLino(line.trim()).children[0];";assert old in s
p.write_text(s.replace(old,"    const parsed = parseLino(line.trim());\n    const node = parsed.name ? parsed : parsed.children[0];"))
for suffix in ['json','log.gz']:(base/('regression-before.'+suffix)).rename(base/('regression-before-initial-parser-shape.'+suffix))
r=subprocess.run(['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/cnl-output.test.mjs'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
raw=r.stdout;packed=gzip.compress(raw,mtime=0);(base/'regression-before.log.gz').write_bytes(packed)
row={'exitCode':r.returncode,'file':'regression-before.log.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'lines':len(raw.splitlines()),'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'independentAuthorshipCredit':0}
(base/'regression-before.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row)); print('\n'.join(raw.decode().splitlines()[-30:]));assert r.returncode!=0
for name,a,b in [('rust/src/cnl_output.rs',1,25),('rust/src/cnl_output.rs',155,185),('rust/tests/web/cnl-output.test.mjs',175,195)]:
 lines=(root/name).read_text().splitlines();print('SOURCE',name)
 for i in range(a-1,b): print(f'{i+1}: {lines[i]}')
