from pathlib import Path
import json
checkpoint=Path('docs/case-studies/issue-1580/checkout-archive-checkpoint.md')
assert not checkpoint.exists()
checkpoint.write_text('''# Fast source checkout archive checkpoint

This is an unfinished checkpoint for [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581),
not full acceptance of issue #1580.

## Published source and failure

All 23 workflows on `6b1d75a62a610e58914ef594c107f3fa402ded9d` completed.
Twenty-two pass after one unchanged-head failed-job retry. Layered CI
[44207032757](https://github.com/link-assistant/formal-ai/actions/runs/44207032757)
passes its retry. The pipeline's native type/lint job passes, but pipeline
[44207033000](https://github.com/link-assistant/formal-ai/actions/runs/44207033000)
still fails before fast source checks execute. Its second-attempt complete log
records curl 28, early EOF and invalid index-pack output at lines 123–128,
followed by the required aggregate failure at lines 12226–12227.

The checkout reports missing promisor object
`9df886c42a1e2082f1471383d986fea4d531f8ac`, the six-byte `.bun-version`.
A fresh seven-file remote partial checkout succeeds locally under the same
1024-byte/20-second low-speed policy, using 3.662 MB of pack data and 38,912 KiB
peak child memory. This proves availability from this different host/Git
version; it does not reproduce the full hosted checkout or establish the
transport failure's root cause. Both head and hosted merge trees are identical.
All attempts, complete logs, hashes and source identities are retained under
`experiments/issue-1580/evidence/ci/published-6b1d75a6/`.

## Smaller source input set

The fast source job previously selected 33,599 tracked files, approximately
733 MB. Its existing exclusions already omit unmeasured historical archives.
Extend that policy to `.gz`, `.log`, `.zip`, `.tgz` and `.diff` files only under
`docs/case-studies/` and `experiments/*/evidence/`. The proposed selection retains
24,020 files, approximately 413 MB, a reduction of 319,759,182 bytes.
These are working-tree byte counts, not measured remote pack sizes.

The regression file passes 15/16 before the workflow change, failing precisely
on retained historical archive payloads, and 16/16 afterward. It checks every
tracked measured source and all readable source inputs, requires each omitted
archive to remain unmeasured, and retains authored diagnostic code, JSON and
Links Notation. Source checks, event ref selection, credential settings, shallow
blobless acquisition, job/checkout clocks and low-speed limits remain intact.

The actual 20 underlying fast source checks pass against a temporary copy
materialized with the proposed selection. The first outer invocation hits
Formal AI's 60-second shell limit after emitting all 20 individual records;
19 checks pass and the hosted-only debt CLI refuses local execution. Preserve
that incomplete invocation and its refusal. A separate invocation of the same
exported debt measurement/check functions passes without impersonating GitHub
Actions. The hosted-only governance wrapper's timing is not tested locally.
The temporary copy is removed; no local native build or execution occurred.
Receipts and complete individual logs are under
`experiments/issue-1580/evidence/checks/fast-source-archive-checkout/`.

This is verified input reduction. Its effect on the hosted checkout remains
unverified until the next published commit completes CI. Do not represent a
smaller checkout as a proved transport root cause or an already green pipeline.

## Java historical comparison

Literal review now covers pages 1–38 and 48–55 of 254: 52 complete files, two
partial files and 2,141 complete source lines. Pages 39–47 remain literally
unread. A full parsed comparison separately covers the compile/test OSV
records: all three differences are read and equal vulnerability subtrees reuse
the fully read compile response. This does not turn skipped literal fragments
into source-read credit. The historical plugin scan finds no package sources;
resolved plugin audit coverage still needs its distinct inventory.

The historical actionlint screenshot is authenticated, image-validated and
viewed. Its receipt records a `concurrency.queue` rejection; it is not current
application UI or a new actionlint execution. Normalized historical logs are
identified as normalized, rather than original command-byte evidence.

Complete template applicability, native regressions, benchmark capability,
live identity/delivery and all previously unchecked acceptance criteria remain
unfinished. Independent Formal AI reasoning acceptance remains 0/20; supplied
scripts, commands and patches receive zero independent authorship credit.
''')
plan=Path('experiments/issue-1580/work-plan.md');plan.write_text(plan.read_text()+'''

## Smaller fast source checkout and published-head review

All 23 workflows on 6b1d75a6 finish: 22 pass after one unchanged-head retry;
the pipeline still fails checkout before source checks. Preserve both complete
attempts and exact identities. A small remote checkout succeeds from this
different host/Git version; hosted transport causality remains unproven.
Reduce only unmeasured historical archive inputs by about 320 MB, retaining
all measured/readable sources and unchanged clocks, refs and credentials.
The regression changes from 15/16 to 16/16. Twenty underlying source checks
pass in the sparse temporary copy across the incomplete initial invocation
and corrected direct debt-function check; the initial hosted guard refusal
and 60-second wrapper limit are retained. Temporary copies are removed.

Java literal history covers pages 1–38 and 48–55/254, 52 complete files and
two partial files, 2,141 complete source lines. Pages 39–47 stay literally
unread, with a separate complete structured OSV comparison retained. The
historical actionlint image is downloaded, validated and viewed. Complete
repository applicability and all broader unchecked criteria stay open.
Run touched gates, review the diff and evidence, archive supplied work, and
push this whole batch once after verifying no current-head runs are active.
Inspect every next-head result; keep the pull request draft and reasoning
acceptance 0/20. See docs/case-studies/issue-1580/checkout-archive-checkpoint.md.
''')
readme=Path('docs/case-studies/issue-1580/README.md');readme.write_text(readme.read_text()+'''

## Fast source archive acquisition checkpoint

The [checkout checkpoint](checkout-archive-checkpoint.md) records all 23 results
on 6b1d75a6, the remaining repeated checkout failure, a small successful remote
probe and a measured 320 MB source-input reduction. Its regression passes
16/16 and all 20 underlying source checks pass across the retained attempts.
The full hosted checkout remains unverified for the next head. Java historical
literal review covers pages 1–38 and 48–55/254; pages 39–47 remain literally
unread despite separate complete structured OSV comparison. Broader acceptance
and independent reasoning acceptance remain unfinished.
''')
fragment=Path('changelog.d/20261117_120000_issue-1580-ci-regressions.md');fragment.write_text(fragment.read_text()+'''\n- Reduce fast source checkout hydration by excluding unmeasured historical archive payloads while preserving every measured source and existing checks.\n''')
print(json.dumps({'checkpoint':str(checkpoint),'workPlanUpdated':True,'releaseFragmentUpdated':True,'completeAcceptance':False}))
