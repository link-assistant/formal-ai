from pathlib import Path
import gzip
import json
import subprocess

directory = Path('experiments/issue-1580/evidence/checks/python-fragment-collision')
for name in ['initial-reporter.log.gz', 'before.log.gz', 'after.log.gz', 'maintained.log.gz']:
    lines = gzip.decompress((directory / name).read_bytes()).decode().splitlines()
    print('\nFILE', name, 'lines', len(lines))
    assert len(lines) <= 300
    for number, line in enumerate(lines, 1):
        print(f'{number}: {line}')
upstream = Path('/tmp/issue-1580-research/python-fragment-collision')
pages = json.loads(gzip.decompress((upstream / 'upstream-issues.json.gz').read_bytes()))
matches = []
for item in [item for page in pages for item in page]:
    text = (item.get('title', '') + '\n' + (item.get('body') or '')).lower()
    if any(word in text for word in ['changelog', 'scriv', 'fragment']):
        matches.append({key: item.get(key) for key in ['number', 'title', 'html_url', 'state']})
print('\nAll broad changelog/scriv/fragment matches:', json.dumps(matches, indent=2))
result = subprocess.run(['gh', 'pr', 'list', '--repo', 'link-foundation/python-ai-driven-development-pipeline-template', '--state', 'merged', '--search', 'changelog', '--limit', '10', '--json', 'number,title,url,mergedAt,mergeCommit'], check=True, capture_output=True)
(upstream / 'recent-merged-changelog-pulls.json').write_bytes(result.stdout)
print('\nRecent merged changelog pull requests:', result.stdout.decode())
