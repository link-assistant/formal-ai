import gzip,hashlib,json,subprocess
from pathlib import Path
base=Path('experiments/issue-1580/evidence/checks/main-merge-444575f2')
report=json.loads(Path('/tmp/issue-1580-research/governed-main-merge-differences.json').read_text())
allowed={
 '/inventory/cases/79/program/fixtures/8/sha256': 'rust/tests/unit/mod.rs',
 '/inventory/cases/81/program/fixtures/4/sha256': 'rust/tests/unit/mod.rs',
 '/inventory/cases/190/program/fixtures/8/sha256': 'rust/tests/unit/mod.rs',
 '/inventory/cases/193/program/fixtures/9/sha256': 'rust/tests/unit/mod.rs',
 '/sourceManifest/34/sha256': 'rust/tests/unit/specification/external_benchmarks.rs',
}
assert set(item['path'] for item in report['differences'])==set(allowed)
assert report['caseCount']==221 and report['unsupportedCount']==964
sources=[]
for file in sorted(set(allowed.values())):
    old=subprocess.check_output(['git','show','HEAD:'+file]);new=Path(file).read_bytes()
    oldsha=hashlib.sha256(old).hexdigest();newsha=hashlib.sha256(new).hexdigest()
    assert oldsha!=newsha
    for item in report['differences']:
        if allowed[item['path']]==file:assert (item['before'],item['after'])==(oldsha,newsha)
    diff=subprocess.check_output(['git','diff','HEAD','--',file])
    (base/(Path(file).name+'-reviewed-source-diff.patch.gz')).write_bytes(gzip.compress(diff,mtime=0))
    sources.append(dict(path=file,beforeSha256=oldsha,afterSha256=newsha,diffSha256=hashlib.sha256(diff).hexdigest()))
report.update(dict(previousRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),mergedMain='444575f2ac28f609c94497865f125f99415ff6d5',reviewedSources=sources,assertionsAndCaseValuesUnchanged=True,refreshedBy='existing --refresh-reviewed-baseline command; no witness hash substitution',nativeExecuted=False,independentAuthorshipCredit=0))
(base/'governed-complete-merge-delta.json').write_text(json.dumps(report,indent=2)+'\n')
for name in subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],text=True).splitlines():subprocess.run(['git','add','--',name],check=True)
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],text=True).strip()
with Path('experiments/issue-1580/work-plan.md').open('a') as out:out.write('''

The 444575f2 merge preserves every fast test from both parents. Five generated source-hash conflicts prevented the command driver from booting; a narrow external bootstrap recomputed the actual merged worker hash without disabling source-identity verification, and normal Formal AI execution then resumed. The official complete witness refresh changes exactly five hash fields against the prior branch witness: four copies of the newly registered permissions module inventory and the main-provided offline benchmark test calls. All 7,016 object pairs, 221 cases, 964 unsupported cases, and assertion values are compared; native test-source differences are explicitly retained and reviewed. The failed two-manifest-only comparison is preserved as an inapplicable narrow review, not accepted proof. Merged-source local gates and focused client/defaults/permissions verification remain pending; broader acceptance remains unfinished.
''')
(base/'README.md').write_text('''# Main 444575f2 merge review

Both parents' fast JavaScript tests are retained without duplicates (233 files).
Generated worker hashes are recomputed from the actual merged worker source.
The external bootstrap recovery earns no Formal AI execution or authorship
credit; the temporary loader failed source-identity verification and was never
accepted. Normal verified command execution resumes after the narrow recovery.

The official complete governed-witness refresh preserves every case/assertion
value and changes five hashes against the previous branch witness. Four bind
`rust/tests/unit/mod.rs`, which adds the permissions test module. One binds
`specification/external_benchmarks.rs`, whose two unavailable-suite tests now
explicitly disable online acquisition. Both complete source diffs and exact
parent/current hashes are retained. All 7,016 object pairs are compared, with
221 supported and 964 unsupported cases unchanged. The earlier manifest-only
review is correctly rejected because its unchanged-native-manifest premise does
not cover this merge. No native test execution is claimed.
''')
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--','experiments/issue-1580/work-plan.md',str(base),'experiments/issue-1580/evidence/checks/main-merge-826289fc/driver-bootstrap-recovery.json'],check=True)
log=Path('/tmp/issue-1580-research/main-444575f2-merge-commit.log')
with log.open('wb') as out:subprocess.run(['git','commit','-m','Merge main client read defaults and preserve reviewed source witnesses'],stdout=out,stderr=subprocess.STDOUT,check=True)
print(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),reviewedFields=len(allowed),sourceChanges=sources)))
