from pathlib import Path
import subprocess
fragment=Path('changelog.d/20261117_1580_audit_inventory.md')
assert not fragment.exists()
fragment.write_text('''### Fixed

- Reject failed or partial Git lockfile inventories before starting JavaScript dependency audits, preserving advisory failures, retry bounds and complete lockfile coverage.
''')
paths=['scripts/check-javascript-dependencies.sh','rust/tests/web/javascript-audit-inventory.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs','experiments/issue-1580/template-python-audit-integrity.test.mjs','experiments/issue-1580/fixtures/python-template','experiments/issue-1580/evidence/checks/audit-inventory-boundary','experiments/issue-1580/evidence/checks/python-runtime-provisioning','experiments/issue-1580/evidence/ci/e120c05b4','experiments/issue-1580/upstream/python-audit-inventory-report.md','docs/case-studies/issue-1580','experiments/issue-1580/work-plan.md',str(fragment)]
subprocess.run(['git','add','--',*paths],check=True)
print(subprocess.run(['git','diff','--cached','--stat'],capture_output=True,text=True,check=True).stdout)
