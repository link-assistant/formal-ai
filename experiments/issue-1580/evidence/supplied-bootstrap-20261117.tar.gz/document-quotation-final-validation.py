from pathlib import Path
import json

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/checks/task-quotation-boundaries'
outcome = json.loads((base / 'generated-repair/outcome.json').read_text())
assert outcome['complete'] and len(outcome['perGateLogs']) == 86
assert all(row['exitCode'] == 0 for row in outcome['checks'])
path = root / 'docs/case-studies/issue-1580/task-quotation-checkpoint.md'
text = path.read_text()
old = 'Final 25-case focused verification and the complete shared-data gate set are pending.'
assert old in text
text = text.replace(old, '''The final 25-case fixture check passes. All nine executor tests and all
15 adjacent factual-QA tests pass in separate runs. The maintained worker and
717-file TypeScript projections, Rust 2024 formatting and whitespace checks pass.

Because this batch changes shared data, run the complete 138-entry local gate
inventory. The initial run records 83 passes, 52 explicit native/CI exclusions
and three failures: stale JavaScript-to-Rust projection, stale embedded seed
notation and the same stale seed in package self-containment. Read and retain
all three failed logs. Regenerate the embedded seed with its maintained writer
and the affected projection through the official single-job translator. The
translator still refuses 49 modules; this regeneration establishes currency,
not full JavaScript/Rust equivalence.

The final complete inventory records **86 passes, 52 explicit exclusions and
zero failures** in 620.949 seconds. Retain both full-run summaries and every
executed gate log. All 86 final compressed gate logs match their recorded raw
hashes. The repair worker finishes in 687.109 seconds, with a 256 MiB Node heap,
one translation job and peak child RSS of 1,041,380 KiB. No local Rust build or
native application execution occurs. The complete final aggregate is read;
archiving and hashing successful detailed logs do not imply literal review of
each detailed log.

Final aggregate SHA-256:
`b150c2758aa950b147a8a9d70371a209e12e1904993d853aa0146b72eac05d90`.
The full outcomes, per-command hashes and archived gate logs are under
`experiments/issue-1580/evidence/checks/task-quotation-boundaries/`.''')
path.write_text(text)
plan = root / 'experiments/issue-1580/work-plan.md'
plan.write_text(plan.read_text() + '''
- [x] Complete final quotation validation: 25 shared fixture cases, nine executor
  tests and 15 adjacent factual-QA tests pass. Preserve the first complete gate
  run's three stale-artifact failures, regenerate through maintained writers,
  then pass all 86 executable gates in the complete 138-entry inventory; 52
  native/CI-context exclusions remain explicit. No local Rust build or native
  execution is claimed. Parent coverage and the rejected context candidate stay
  unfinished; supplied work earns zero independent authorship credit.
''')

source = Path('/tmp/issue-1580-research/declared-language-final-pr-body.md').read_text()
source = source.replace('This draft repairs those failures together with client constraints and CI regressions.', 'Compound task parsing also splits conjunctions inside ASCII quotations. This draft repairs those boundaries and the recorded fixture, client-constraint and CI regressions.')
source = source.replace('Changes:\n\n', 'Changes:\n\n- Preserve ASCII quoted passages during task decomposition in both JavaScript and Rust, honor escapes and word apostrophes, and retain adjacent CJK quotations. Add ten shared regression cases without changing the original 15 inputs, outputs or traces; regenerate worker, TypeScript, seed and translation artifacts through maintained tools.\n')
start = source.index('Latest reproduction and verification:\n')
end = source.index('Earlier verification, recorded separately:\n', start)
source = source[:start] + '''Latest reproduction and verification:

- Before the quotation repair, `Count "salt and pepper" and report the size` incorrectly becomes three tasks. The focused before run has **7 passes and 2 failures**. A separate direct diagnostic reproduces the adjacent CJK single-quote defect. Afterward, the **25-case fixture check**, **9 executor tests** and **15 adjacent factual-QA tests** pass. All original 15 fixture entries are byte-equivalent as parsed values, including traces.
- Shared-data validation initially records three stale generated artifacts. Preserve all failures, run the maintained seed and translation writers, then pass the complete inventory: **86 executable gates pass, 52 explicit native/CI-context exclusions, zero failures**. Worker and **717-file TypeScript projections**, Rust 2024 formatting and whitespace checks pass. Projection verification still refuses 49 modules; native quotation execution remains unverified.
- All **23 hosted workflows pass on published input `a9783223`**, including CI/CD Pipeline 44233931277 and Layered CI 44233930887, completed at 2026-11-18T04:06:29Z. Scope-gated success does not prove native acceptance. The quotation batch still needs hosted verification after publication.
- Reject the supplied single-passage context candidate: only **4/8 qualification controls pass** across 16 finite VM observations with no transport calls. It can mark a passage-plus-arithmetic request resolved while omitting the passage answer. Parent answer coverage, multi-passage binding and withheld-child obligations remain open; do not suppress child tests or make the request atomic.
- The preceding declared-language correction passes **8/8 focused cases** after two before failures. Complete localized unknown responses and declared language metadata remain covered; native Spanish execution and the definition route remain unfinished. Both failed attempts on the earlier `edffcb18` head are retained separately from current success.

Run focused files separately:

```sh
timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/issue-1550-meta-executor.test.mjs
timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/worker-factual-qa.test.mjs
node --max-old-space-size=256 experiments/issue-1550/parity-fixture.mjs --check
node --max-old-space-size=256 experiments/formal_ai_subagent/local-gates.mjs
```

The [quotation checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/task-quotation-checkpoint.md), [declared-language checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/declared-language-policy-checkpoint.md), [native boundary checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/opener-native-boundary-checkpoint.md) and [localized opener checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/localized-opener-and-ci-checkpoint.md) retain source identities, complete failed logs and before/after evidence.

''' + source[end:]
start = source.index('Java historical literal review covers ')
source = source[:start] + '''Java historical literal review covers **78/254 continuous pages**, 70 complete files, one partial file and 4,631 literally reviewed source lines; pages 79–254 remain unread. Full semantic applicability for all templates remains unfinished. Source reading, upstream reports and skipped native jobs do not establish acceptance. Independent Formal AI reasoning acceptance remains **0/20**; supplied commands, patches, scripts and conclusions receive zero independent authorship credit.
'''
assert source.count('Fixes #1580') == 1
target = Path('/tmp/issue-1580-research/quotation-final-pr-body.md')
assert not target.exists()
target.write_text(source)
(base / 'pull-request-description.md').write_text(source)
print('Updated quotation checkpoint, work plan and reviewable PR description; no completion or native acceptance claimed.')
