import json
from pathlib import Path

base = Path('/tmp/issue-1580-research')
root = base / 'templates/java-complete'
for path in sorted(root.rglob('*')):
    if path.is_file() and ('test' in path.name or path.as_posix().endswith('github-release-state.mjs')) and not path.relative_to(root).as_posix().startswith(('dev/', 'docs/case-studies/')):
        print('SOURCE', path.relative_to(root))
data = json.loads((base / 'java-context/issues.json').read_text())
if isinstance(data, dict):
    print('INDEX KEYS', list(data))
else:
    for row in data:
        if row['number'] in [9, 12, 29]:
            print(json.dumps(row, indent=2))
