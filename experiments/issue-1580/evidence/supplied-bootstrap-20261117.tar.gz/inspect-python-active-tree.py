from pathlib import Path
import collections,hashlib,json
root=Path('/tmp/issue-1580-research/templates/python-complete')
rows=json.loads(Path('/tmp/issue-1580-research/templates/python-complete-inventory.json').read_text())
active=[]; historical=[];binary=[]
for row in rows:
 p=root/row['path']; data=p.read_bytes()
 assert len(data)==row['bytes'] and hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()==row['gitBlob']
 try: content=data.decode('utf-8'); assert '\0' not in content
 except (UnicodeDecodeError,AssertionError):binary.append(row);continue
 info={**row,'lines':len(content.splitlines()),'sha256':hashlib.sha256(data).hexdigest()}
 if row['path'].startswith(('dev/log/','ci-logs/')):historical.append(info)
 else:active.append(info)
print(json.dumps({'verifiedBlobs':len(rows),'activeFiles':len(active),'activeLines':sum(r['lines'] for r in active),'historicalFiles':len(historical),'historicalLines':sum(r['lines'] for r in historical),'binary':binary},indent=2))
for row in active: print(json.dumps({'path':row['path'],'lines':row['lines']}))
print('READ SCRIPT',Path('/tmp/issue-1580-research/read-csharp-page.py').read_text())
Path('/tmp/issue-1580-research/python-active-source-inventory.json').write_text(json.dumps({'active':active,'historical':historical,'binary':binary},indent=2)+'\n')
