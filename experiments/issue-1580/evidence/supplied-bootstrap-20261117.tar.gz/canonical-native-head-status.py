from pathlib import Path
import json
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/ci/canonical-native-2c9d93c5';scratch=Path('/tmp/issue-1580-research/canonical-native-head-ci')
for name in ['latest.json','outcome.json']:
 p=base/name
 if p.exists():
  data=json.loads(p.read_text());print(name,json.dumps({k:v for k,v in data.items() if k!='runs'}));print('UNFINISHED',[(r['workflowName'],r['status'],r['databaseId']) for r in data.get('runs',[]) if r['status']!='completed'])
if (scratch/'failure.json').exists():print('COLLECTOR FAILURE',(scratch/'failure.json').read_text())
if (base/'records.json').exists():
 rows=json.loads((base/'records.json').read_text());print('ARCHIVED COMMANDS',len(rows));print('NON-OBSERVATIONS',[(r['name'],r['exitCode'],r['stdout']['lines']) for r in rows if not r['name'].startswith('observation-')])
