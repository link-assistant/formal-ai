from pathlib import Path
source=Path('/tmp/issue-1580-research/collect-python-fragment-head-ci.py').read_text()
source=source.replace('624812120feee0180bf9df8164f87e73326b5cb8','d0b8b895661c6b5e809810c4da8a3db9f79138b3').replace('ci/624812120','ci/d0b8b8956')
source=source.replace("'abbreviation ratchet',","'abbreviation ratchet','audit inventory','npm audit','formatter preserves','formatter rejects',")
exec(compile(source,__file__,'exec'))
