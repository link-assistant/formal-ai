from pathlib import Path
import json,subprocess,gzip,hashlib
base=Path('experiments/issue-1580/evidence/checks/language-main-validation');outcome=json.loads((base/'outcome.json').read_text());assert outcome['complete'] and outcome['sourceUnchangedDuringValidation']
failed=[r['gateName'] for r in outcome['gateLogs'] if r['gateName'] in ('check-file-size','check-file-size-js-twin','check-status-render','check-tests-as-docs','check-tests-as-documentation-javascript-twin')]
assert outcome['gateCounts']['FAIL']==5 and len(failed)==5
target=Path('rust/tests/unit/solver_unknown_reasoning_captured_sources.rs');text=target.read_text()
start=text.index('    assert_eq!(\n        answer.answer,');end=text.index('    assert!(log.events()',start)
unknown=text[start:end].replace('¿Cómo funciona la fotosíntesis submarina de xyzzy','¿Cómo funciona un isograma')
old='    assert!(answer.answer.contains("`¿Cómo funciona un isograma`"));';assert text.count(old)==1;text=text.replace(old,unknown+old)
en='isogram (isogram): a line drawn on a map connecting points having the same numerical value of some variable\n\nSource: https://en-word.net/api/lemma/isogram (sha256 ae8c98f774fd255a; CC BY 4.0)'
es='isograma (Heterograma): Un heterograma es una palabra o frase que no contiene ninguna letra repetida. Esta propiedad fue descrita por Dmitri Borgmann en su libro Language on Vacation: An Olio of Orthographical Oddities, donde intentó encontrar la palabra más larga que cumpliera esta condición.\n\nFuente: https://es.wikipedia.org/api/rest_v1/page/summary/Isograma (sha256 7fbc0bf57dce4de1; CC BY-SA 4.0)'
marker='    assert_eq!(answer.intent, "concept_lookup");';assert text.count(marker)==2
parts=text.split(marker);text=parts[0]+marker+'\n    assert_eq!(answer.answer, '+json.dumps(en,ensure_ascii=False)+');'+parts[1]+marker+'\n    assert_eq!(answer.answer, '+json.dumps(es,ensure_ascii=False)+');'+parts[2]
target.write_text(text)
report=[];out=Path('experiments/issue-1580/evidence/checks/language-main-integration')
commands=[('format-exact-native-examples',['rustfmt','--edition','2024',str(target)]),('regenerate-status',['node','--max-old-space-size=256','scripts/render-status.mjs','--write']),('review-failed-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size-js-twin,check-file-size,check-status-render,check-tests-as-docs,check-tests-as-documentation-javascript-twin'])]
for name,argv in commands:
 p=subprocess.run(argv,capture_output=True);raw=p.stdout+p.stderr;(out/(name+'.log.gz')).write_bytes(gzip.compress(raw,mtime=0));report.append({'name':name,'argv':argv,'exitCode':p.returncode,'rawSha256':hashlib.sha256(raw).hexdigest(),'lines':len(raw.splitlines())});print(json.dumps(report[-1]),flush=True)
 if p.returncode:print(raw.decode()[-8000:]);break
(out/'documentation-gate-corrections.json').write_text(json.dumps({'beforeGateCounts':outcome['gateCounts'],'commands':report,'nativeExecution':False,'assertions':'Three native cases now show exact whole answer strings in addition to their original intent and contains assertions; no existing assertion removed.','status':'Maintained JavaScript renderer; no Rust build.'},indent=2)+'\n')
assert len(report)==3 and all(x['exitCode']==0 for x in report)
