from pathlib import Path
import subprocess, json
for args in [
 ["rg","-n","try_algebra|algebra_substitution|composition:substitution|composition:remainder|arithmetic_word_problem","rust/src"],
 ["rg","-n","arithmetic_word_problem|tryAlgebra|tryArithmetic|wordProblem","js/worker/formal_ai_worker_solver_core.js","js/worker/formal_ai_worker_solver.js"],
]:
 r=subprocess.run(args,text=True,capture_output=True)
 print("SEARCH",args,"STATUS",r.returncode)
 print(r.stdout)
for name,start,count in [
 ("rust/tests/unit/specification/debug_session.rs",1,65),
 ("js/worker/formal_ai_worker_arithmetic_and_numeric_lists.js",260,155),
 ("rust/tests/web/calendar-clock-preservation.test.mjs",1,155),
 ("rust/src/solver_handlers/calendar_create.rs",45,95),
]:
 p=Path(name); lines=p.read_text().splitlines()
 print("FILE",name,"LINES",len(lines),"WINDOW",start,count)
 for i in range(start-1,min(start-1+count,len(lines))): print(f"{i+1}: {lines[i]}")
p=Path("experiments/issue-1580/evidence/checks/calendar-clock-preservation/validation-completion.json")
print("VALIDATION",p.read_text() if p.exists() else "RUNNING")
