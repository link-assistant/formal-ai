import assert from 'node:assert/strict';
import fs from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const base='experiments/issue-1580/evidence/checks/spoken-scheduling-paraphrases';
const beforeText=gunzipSync(fs.readFileSync(`${base}/native-registry-before.mjs.gz`)).toString();
const afterText=fs.readFileSync('scripts/lib/generated-native-programs.mjs','utf8');
const read=async text=>(await import(`data:text/javascript;base64,${Buffer.from(text).toString('base64')}`)).GENERATED_NATIVE_PROGRAMS;
const before=await read(beforeText),after=await read(afterText),changes=[];
function compare(left,right,path=''){
 if(left&&right&&typeof left==='object'&&typeof right==='object'){
  assert.deepEqual(Object.keys(left),Object.keys(right),path);
  for(const key of Object.keys(left))compare(left[key],right[key],`${path}/${key}`);
 }else if(left!==right)changes.push({path,before:left,after:right});
}
compare(before,after);
for(const change of changes){
 if(!/\/sourceWitnesses\/\d+\/sha256$/.test(change.path))continue;
 const [,index,,witness]=change.path.split('/');
 const source=after[Number(index)].sourceWitnesses[Number(witness)];
 assert.equal(change.after,createHash('sha256').update(fs.readFileSync(source.path)).digest('hex'));
 change.source=source.path;
}
const executable=programs=>programs.map(({sourceSpan,sourceWitnesses,...program})=>program);
const sameExecutable=JSON.stringify(executable(before))===JSON.stringify(executable(after));
const receipt={programsBefore:before.length,programsAfter:after.length,changes,executableUnchanged:sameExecutable,nativeExecuted:false,independentAuthorshipCredit:0};
fs.writeFileSync(`${base}/registry-comparison.json`,JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt,null,2));
