from pathlib import Path
import subprocess
for args in [
    ["git","branch","--show-current"],
    ["git","status","--short"],
    ["git","log","-3","--oneline"],
]:
    r = subprocess.run(args, text=True, capture_output=True)
    print("COMMAND", args, "STATUS", r.returncode)
    print(r.stdout)
for name in [
    "experiments/issue-1580/WORK_PLAN.md",
    "experiments/issue-1580/work-plan.md",
    "experiments/issue-1580/evidence/checks/calendar-clock-preservation/README.md",
    "/tmp/issue-1580-research/project-native-failures.py",
    "/tmp/issue-1580-research/inspect-native-numeric-failures.py",
]:
    p = Path(name)
    if p.exists():
        lines = p.read_text().splitlines()
        print("FILE", name, "LINES", len(lines))
        if len(lines) <= 160:
            for i,line in enumerate(lines,1):
                print(f"{i}: {line}")
print("MEMORY", Path("/sys/fs/cgroup/memory.current").read_text().strip())
