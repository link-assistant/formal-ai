from pathlib import Path
import datetime, json

publication = Path('/tmp/issue-1580-research/task-quotation-publication')
path = publication / 'verification.json'
data = json.loads(path.read_text())
assert data['publicationVerified'] and data['codeCommitApiFiles'] == 13
assert not data['literalApiPatchReviewComplete']
data['literalApiPatchReviewComplete'] = True
data['apiPatchPagesLiterallyRead'] = [1, 2, 3, 4, 5]
data['incrementalReviewCompletedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
data['wholePullRequestLiteralReviewClaimed'] = False
path.write_text(json.dumps(data, indent=2) + '\n')
base = Path('experiments/issue-1580/evidence/ci/task-quotation-04a468f5')
(base / 'publication-verification.json').write_bytes(path.read_bytes())
print('All five API patch pages for the 13-file code commit are read; source blob identities match the published head. Whole-PR and issue completion are not claimed.')
