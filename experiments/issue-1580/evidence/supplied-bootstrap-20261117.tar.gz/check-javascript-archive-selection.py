from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,sys,time
phase=sys.argv[1];assert phase in ['before','after']
base=Path('experiments/issue-1580/evidence/checks/javascript-archive-checkout');base.mkdir(parents=True,exist_ok=True)
path=base/(phase+'-selection.json');assert not path.exists()
command=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs']
start=time.monotonic();run=subprocess.run(command,capture_output=True);raw=run.stdout+run.stderr
packed=gzip.compress(raw,mtime=0);name=phase+'-selection.log.gz';(base/name).write_bytes(packed)
report={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':phase,'argv':command,'exitCode':run.returncode,'seconds':round(time.monotonic()-start,3),'log':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'logBytes':len(raw),'logLines':len(raw.splitlines()),'independentAuthorshipCredit':0}
path.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));print(raw.decode())
assert run.returncode==(1 if phase=='before' else 0)
