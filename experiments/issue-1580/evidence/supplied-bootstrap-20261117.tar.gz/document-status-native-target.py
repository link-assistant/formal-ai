from pathlib import Path

root=Path('/tmp/gh-issue-solver-1794900398048')
path=root/'docs/ci-cd/default-branch-builds.md';text=path.read_text()
old='''    types or lints. Issue #1589 additionally runs the isolated calendar_currency
'''
assert old not in text
old='''  types or lints. Issue #1589 additionally runs the isolated calendar_currency
  regression target against the shared worker/native acceptance fixtures in this
  existing job, with two compiler jobs and test optimization disabled. The
  regression proves native behavior; it does not produce release evidence. Full
'''
new='''  types or lints. The same job runs three isolated regression targets:
  `calendar_currency` (#1589), `openai_forced_functions` (#1590), and
  `meta_executor_parity` (#1580). The executor target reuses its existing four-test
  module and compares all 29 shared cases, including complete event sequences
  and unverified-draft controls. The forced-function HTTP suite also replays
  against the native CLI. All compile-dependent steps retain the same input
  condition, with two compiler jobs and test optimization disabled. Successful
  execution verifies these regressions; it does not produce release evidence. Full
'''
assert text.count(old)==1
path.write_text(text.replace(old,new))
print('Documented the three isolated targets and retained compile-input admission and publication boundaries.')
