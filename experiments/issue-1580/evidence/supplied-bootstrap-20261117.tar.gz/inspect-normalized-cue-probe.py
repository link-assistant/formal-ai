from pathlib import Path
import gzip, hashlib, json

base = Path('/tmp/issue-1580-research/passage-cue-coverage-normalized')
process = json.loads((base / 'process.json').read_text())
pid = process['pid']
stat_path = Path(f'/proc/{pid}/stat')
stat = stat_path.read_text().split() if stat_path.exists() else []
print(json.dumps({'pid': pid, 'state': stat[2] if stat else 'absent', 'exitCodeEncoded': stat[51] if len(stat) > 51 else None}))
for name in ['syntax.json', 'stdout.log', 'stderr.log']:
    source = base / name
    data = source.read_bytes()
    assert len(data) < 65000
    print(f'{name}: {len(data)} bytes sha256={hashlib.sha256(data).hexdigest()}')
    print(data.decode())
artifact = Path('experiments/issue-1580/evidence/checks/passage-routing-probe/passage-cue-coverage-normalized.json.gz')
if artifact.exists():
    data = gzip.decompress(artifact.read_bytes())
    result = json.loads(data)
    print(json.dumps({'artifact': str(artifact), 'rawBytes': len(data), 'rawSha256': hashlib.sha256(data).hexdigest(), 'keys': list(result), 'qualification': result.get('qualification'), 'fixtureCompatibility': result.get('fixtureCompatibility'), 'structuralControls': result.get('structuralControls')}, ensure_ascii=False))
