from pathlib import Path
import json,subprocess
memory={key:int(value) for key,value in (line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines())}
print(json.dumps({'max':Path('/sys/fs/cgroup/memory.max').read_text().strip(),'current':Path('/sys/fs/cgroup/memory.current').read_text().strip(),'memory':{key:memory[key] for key in ['anon','file','shmem','inactive_file','active_file','slab_reclaimable','pagetables']}}))
lines=subprocess.check_output(['ps','-eo','pid,ppid,stat,rss,comm','--sort=-rss'],text=True).splitlines();print('\n'.join(lines[:12]))
