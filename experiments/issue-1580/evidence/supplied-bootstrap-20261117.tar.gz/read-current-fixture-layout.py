from pathlib import Path
for name in ['read-csharp-page.py', 'read-template-file-range.py', 'read-csharp-fixture-pattern.py']:
    p=Path('/tmp/issue-1580-research')/name
    print('BOOTSTRAP',name)
    print(p.read_text())
for name in ['experiments/issue-1580/fixtures/java-template/source.json', 'experiments/issue-1580/template-java-release-integrity.test.mjs']:
    p=Path(name)
    print('FILE',name)
    print(p.read_text())
