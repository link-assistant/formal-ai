from pathlib import Path
import json
import subprocess

for name in ['experiments/issue-1580/trace-template-ci.mjs','experiments/issue-1580/trace-template-ci.test.mjs']:
 p=Path(name)
 if not p.exists():
  print('MISSING',name)
  continue
 lines=p.read_text().splitlines()
 assert len(lines)<=1500
 print('\nFILE '+name+'\n'+'\n'.join(f'{n}: {s}' for n,s in enumerate(lines,1)))
print('\nSOURCE FILE PATHS')
paths=subprocess.check_output(['rg','--files','scripts','experiments/issue-1580'],text=True).splitlines()
for p in paths:
 if 'action' in Path(p).name or 'trace-template' in p:
  print(p)
context=json.loads(subprocess.check_output(['gh','issue','view','https://github.com/rhysd/actionlint/issues/711','--json','title,body,state,url'],text=True))
Path('/tmp/issue-1580-research/csharp-layout-context/actionlint-711.json').write_text(json.dumps(context,indent=2)+'\n')
print('\nPRIMARY CONTEXT\n'+json.dumps(context,indent=2))
