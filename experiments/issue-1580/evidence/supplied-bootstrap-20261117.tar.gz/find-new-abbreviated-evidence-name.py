import subprocess,json
from pathlib import Path
p=subprocess.run(['node','--max-old-space-size=256','scripts/measure-abbreviations.mjs','--list','file-names'],capture_output=True,text=True)
print('EXIT',p.returncode)
print(p.stdout)
print(p.stderr)
staged=set(subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines())
print('NEW_MATCHES')
for line in p.stdout.splitlines():
 if any(path in line for path in staged):print(line)
