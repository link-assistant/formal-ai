from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
base=Path('experiments/issue-1580/evidence/ci/main-444575f2')
base.mkdir(parents=True,exist_ok=True)
cmd=['gh','run','list','--repo','link-assistant/formal-ai','--branch','main','--limit','100','--json','databaseId,workflowName,headSha,status,conclusion,createdAt,updatedAt,url']
raw=subprocess.check_output(cmd)
(base/'run-list.json.gz').write_bytes(gzip.compress(raw,mtime=0))
rows=json.loads(raw)
current=[row for row in rows if row['headSha']=='444575f2ac28f609c94497865f125f99415ff6d5']
(base/'current-head-runs.json').write_text(json.dumps(current,indent=2)+'\n')
print(json.dumps({'collectedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':'444575f2ac28f609c94497865f125f99415ff6d5','runs':current},indent=2))
