from pathlib import Path
import subprocess
for p,a,b in [('js/seed_loader.js',1400,1477),('rust/src/structured_log.rs',470,500),('rust/tests/integration/with_formal_ai.rs',20,140),('rust/tests/integration/with_formal_ai_argv.rs',125,170),('rust/tests/unit/page_formalization_route.rs',60,120)]:
    lines=Path(p).read_text().splitlines();print('SOURCE',p,'TOTAL',len(lines),'RANGE',a,b)
    for i in range(a-1,min(b,len(lines))):print(str(i+1)+': '+lines[i])
for args in [
 ['rg','-n','composition:compound|compound_response|solveIndependent|split_independent','rust/src'],
 ['rg','--files','experiments/issue-1580','docs/case-studies/issue-1580'],
]:
    r=subprocess.run(args,text=True,capture_output=True);print('COMMAND',args,'EXIT',r.returncode)
    if '--files' in args: print('\n'.join(p for p in r.stdout.splitlines() if any(x in p for x in ['work-plan','work_plan','plan.md'])))
    else: print(r.stdout,r.stderr)
