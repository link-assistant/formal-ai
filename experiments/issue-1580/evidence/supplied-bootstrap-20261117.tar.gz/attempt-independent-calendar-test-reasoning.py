from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys,time
root=Path.cwd();base=root/'experiments/issue-1580/evidence/checks/calendar-dispatch-registration/independent-test-reasoning'
question='Compare two strategies for a full-worker calendar regression: directly calling the calendar helper or solving through the normal browser dispatcher. Explain which can detect a scheduling request accidentally becoming a memory write, and describe a negative control that checks ordinary memory writes.'
if len(sys.argv)==1:
 base.mkdir(exist_ok=False);head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 (base/'frozen-attempt.json').write_text(json.dumps({'frozenUnit':'negative regression controls','request':question,'sourceHead':head,'maxSteps':4,'maxAttempts':1,'nodeHeapMiB':256,'acceptance':['Correctly explains the distinct routing coverage','Proposes an ordinary memory write control with its expected result','Complete actual response and route/tool trace retained'],'accepted':False,'authorshipCredit':0,'status':'unreviewed'},indent=2)+'\n')
 with (base/'worker.log').open('wb') as log:p=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 print('Started independent reasoning attempt',p.pid);sys.exit(0)
args=['node','--max-old-space-size=256','experiments/js_dogfood/drive.mjs','--dir',str(root),'--steps','4',question];r=subprocess.run(args,capture_output=True)
rows=[]
for name,raw in [('stdout',r.stdout),('stderr',r.stderr)]:
 packed=gzip.compress(raw,mtime=0);filename=name+'.log.gz';(base/filename).write_bytes(packed);rows.append({'stream':name,'file':filename,'bytes':len(raw),'lines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
(base/'outcome.json').write_text(json.dumps({'complete':True,'exitCode':r.returncode,'argv':args,'payloads':rows,'accepted':False,'status':'unreviewed','fullIssueComplete':False},indent=2)+'\n');print('Attempt finished; independent review required.')
