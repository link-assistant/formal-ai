from pathlib import Path
p=Path('rust/src/meta_executor/production.rs')
s=p.read_text().replace('use crate::engine::{ConversationTurn, SymbolicAnswer};', 'use crate::engine::SymbolicAnswer;\nuse crate::solver::ConversationTurn;')
p.write_text(s)
p=Path('rust/tests/unit/specification/debug_session.rs')
s=p.read_text().replace('const FINALIZE: &str = "rust/src/solver_helpers/mod.rs:record_answer_test";', 'const FINALIZE: &str = "rust/src/solver_handlers/mod.rs:finalize_simple";\nconst ANSWER_TEST: &str = "rust/src/solver_helpers/mod.rs:record_answer_test";').replace('(\"rule_verification\", FINALIZE, EVENT_LOG)', '(\"rule_verification\", ANSWER_TEST, EVENT_LOG)')
p.write_text(s)
p=Path('rust/src/intent_formalization/obligations.rs')
p.write_text(p.read_text().replace('see [`explicit_count`] and [`output_again`]', 'see `explicit_count` and `output_again`'))
