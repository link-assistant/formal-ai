from pathlib import Path
import json

root=Path('/tmp/gh-issue-solver-1794900398048')
for name,lo,hi in [('rust/src/solver_helpers/mod.rs',300,475),('rust/src/solver.rs',760,865)]:
    lines=(root/name).read_text().splitlines()
    print('\nFILE',name)
    for n in range(lo-1,min(hi,len(lines))): print(f'{n+1}: {lines[n]}')
print('\nNATIVE FAILURE INVENTORY')
data=json.loads((root/'experiments/issue-1580/evidence/ci/main-512ce428/native-failure-inventory.json').read_text())
print(json.dumps(data,indent=2))
print('GATE PROGRESS')
path=Path('/tmp/issue-1580-research/sealed-complete-local-gates.log')
print('\n'.join(path.read_text().splitlines()[-8:]))
