import gzip
import pathlib
import re
import sys

directory = pathlib.Path("experiments/issue-1580/evidence/ci/main-512ce428")
run = sys.argv[1]
if sys.argv[2] == "errors":
    matches = []
    with gzip.open(directory / (run + ".log.gz"), "rt") as source:
        for number, raw in enumerate(source, 1):
            fields = raw.rstrip().split("\t", 2)
            if len(fields) != 3:
                continue
            job, step, text = fields
            text = re.sub(r"^\d{4}-\d\d-\d\dT\S+\s", "", text)
            if re.search(r"^\s*(?:✖|not ok\b|thread .+panicked at|error(?:\[[^]]+\])?:|test result: FAILED)|##\[error\]|timed out after|execution budget exhausted", text):
                matches.append(str(number) + ": " + job + " | " + step + " | " + text)
    start = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    amount = min(int(sys.argv[4]) if len(sys.argv) > 4 else 100, 1500)
    print("Total error matches", len(matches))
    print("\n".join(matches[start - 1:start - 1 + amount]))
else:
    start = int(sys.argv[2])
    amount = min(int(sys.argv[3]) if len(sys.argv) > 3 else 100, 1500)
    with gzip.open(directory / (run + ".log.gz"), "rt") as source:
        for number, raw in enumerate(source, 1):
            if number < start:
                continue
            if number >= start + amount:
                break
            fields = raw.rstrip().split("\t", 2)
            text = fields[-1]
            text = re.sub(r"^\d{4}-\d\d-\d\dT\S+\s", "", text)
            print(str(number) + ": " + text)
