set -eu
rg --files scripts rust/tests/web experiments/formal_ai_subagent | rg 'detect.*change|change.*detect|local-gate|git-observ'
sed -n '1,230p' experiments/issue-1580/work-plan.md
cat changelog.d/20261117_120000_issue-1580-ci-regressions.md
tail -n 110 docs/case-studies/issue-1580/README.md
cat experiments/issue-1580/archive-evidence.py
