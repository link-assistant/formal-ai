from pathlib import Path
import datetime, gzip, hashlib, json

root = Path('experiments/issue-1580/evidence/checks/passage-routing-probe')
dest = root / 'coverage-followup-qualification'
dest.mkdir(exist_ok=True)
records = []

def digest(data):
    return hashlib.sha256(data).hexdigest()

def archive(path, label):
    raw = path.read_bytes()
    output = dest / (label + '.gz')
    packed = gzip.compress(raw, mtime=0)
    if output.exists():
        assert output.read_bytes() == packed
    else:
        output.write_bytes(packed)
    records.append({'source': str(path), 'archive': str(output), 'rawBytes': len(raw), 'rawSha256': digest(raw), 'archiveSha256': digest(packed)})

for source in ['probe-parent-answer-coverage.mjs', 'probe-passage-cue-coverage.mjs']:
    archive(Path('experiments/issue-1580') / source, source)

studies = []
for label, artifact_name, expected in [
    ('parent-answer-coverage-rerun', 'parent-answer-coverage.json.gz', (5, 9)),
    ('passage-cue-coverage-probe', 'passage-cue-coverage.json.gz', (6, 10)),
    ('passage-cue-coverage-normalized', 'passage-cue-coverage-normalized.json.gz', (10, 10)),
]:
    base = Path('/tmp/issue-1580-research') / label
    process = json.loads((base / 'process.json').read_text())
    stat = Path(f"/proc/{process['pid']}/stat").read_text().split(') ', 1)[1].split()
    assert stat[0] == 'Z' and stat[-1] == '0', (label, stat[0], stat[-1])
    for name in ['syntax.json', 'process.json', 'stdout.log', 'stderr.log']:
        archive(base / name, label + '-' + name)
    assert (base / 'stderr.log').stat().st_size == 0
    packed = (root / artifact_name).read_bytes()
    raw = gzip.decompress(packed)
    data = json.loads(raw)
    qualification = data['qualification']
    actual = (sum(bool(check[1]) for check in qualification), len(qualification))
    assert actual == expected, (label, actual)
    assert data['productionModified'] is False and data['nativeExecuted'] is False
    studies.append({'label': label, 'artifact': str(root / artifact_name), 'rawBytes': len(raw), 'rawSha256': digest(raw), 'archiveSha256': digest(packed), 'qualification': qualification, 'qualificationPassed': actual[0], 'qualificationTotal': actual[1], 'fixtureCompatibilityPassed': sum(check['passed'] for check in data.get('fixtureCompatibility', [])), 'fixtureCompatibilityTotal': len(data.get('fixtureCompatibility', [])), 'structuralControlsPassed': sum(check['passed'] for check in data.get('structuralControls', [])), 'structuralControlsTotal': len(data.get('structuralControls', [])), 'workerFinished': True, 'workerExitCode': 0})

manifest = {'schema': 'issue-1580-coverage-followup/v1', 'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'studies': studies, 'files': records, 'allQualificationStdoutLiterallyRead': True, 'completeNestedTracesLiterallyRead': False, 'productionAdopted': False, 'statementMetadataIsGeneralProof': False, 'openCriteria': ['Aggregated provenance on adopted composition', 'Native execution and parity', 'Broader language and formatting obligations', 'General proof of parent-answer coverage'], 'independentAuthorshipCredit': 0}
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')

plan = Path('experiments/issue-1580/work-plan.md')
text = plan.read_text()
old = '- [ ] Publish the complete repair once and verify all new-head workflows, especially native calendar/currency execution. A checkout retry result does not establish transport causality.'
new = '- [x] Publish the complete decoded-value repair once as b26f5eeb. All 23 exact-head workflows pass after one failed-checkout-job retry. Native calendar/currency actually executes and passes 1/1 in 91.13 seconds; the retried JavaScript shard passes 1,430 cases with 13 skips. The initial checkout failure and its logs remain preserved; the retry does not establish transport causality or native quotation-fixture execution.'
assert text.count(old) == 1
text = text.replace(old, new)
text += '''

## Parent coverage qualification and unverified-child status (2026-11-18)

- [x] Preserve the 5/9 parent-coverage candidate, the 6/10 initial seeded-cue
  candidate, and the corrected 10/10 candidate as separate bounded VM studies.
  Corrected cue normalization preserves all 25 fixture outputs and complete
  event traces plus two non-passage structural controls. No production adoption,
  native execution or general-proof claim follows from those controls.
- [ ] Reproduce the separate status defect where a nonempty
  `meta_reasoned_program_unverified` child passes the leaf test; inventory all
  emitted unverified intents and add shared negative/verified controls before
  correcting the seeded unresolved suffix policy.
- [ ] Preserve the failing-before and passing-after checks; regenerate shared
  fixtures and maintained projections; run focused adjacent checks and the
  complete shared-data gate inventory sequentially before publishing.
- [ ] Complete aggregated composition provenance, native quotation/coverage
  execution, general parent coverage and every earlier unchecked criterion.
  Independent acceptance remains 0/20 and the PR stays draft and unmerged.
'''
plan.write_text(text)
print(json.dumps({'archivedFiles': len(records), 'studies': [{'label': s['label'], 'passed': s['qualificationPassed'], 'total': s['qualificationTotal']} for s in studies], 'manifest': str(dest / 'manifest.json'), 'productionAdopted': False}))
