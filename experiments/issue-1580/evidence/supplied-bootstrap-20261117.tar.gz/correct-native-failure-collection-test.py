from pathlib import Path
import gzip,hashlib,json,os,re,subprocess,time
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/native-failure-collection';path=root/'rust/tests/web/default-branch-build-policy.test.mjs';text=path.read_text()
start=text.index("test('native unsupported-language regressions execute the captured-source units and unchanged sibling contract'");end=text.index('// The production-only failure',start);block=text[start:end]
old="assert.equal(step.if, '${{ inputs.compile-inputs-changed }}');";new='assert.equal(step.if, "${{ !cancelled() && inputs.compile-inputs-changed && steps.native-lint.outcome == \'success\' }}");';assert block.count(old)==1;block=block.replace(old,new)
old="""    'cargo test --manifest-path rust/Cargo.toml --locked --lib solver_unknown_reasoning::tests:: -- --test-threads=1',
    'cargo test --manifest-path rust/Cargo.toml --locked --test any_language a_language_without_localized_openers_reports_a_gap_not_english -- --exact --test-threads=1',
"""
new="""    'regression_status=0',
    'cargo test --manifest-path rust/Cargo.toml --locked --lib solver_unknown_reasoning::tests:: -- --test-threads=1 || regression_status=$?',
    'cargo test --manifest-path rust/Cargo.toml --locked --test any_language a_language_without_localized_openers_reports_a_gap_not_english -- --exact --test-threads=1 || regression_status=$?',
    'exit "regression_status"',
""".replace('exit "regression_status"','exit "$regression_status"')
assert old in block;block=block.replace(old,new);text=text[:start]+block+text[end:]
old='const expression = step.if.slice(3, -2).trim();';new='''const expression = step.if.slice(3, -2).trim()
      .replaceAll('inputs.compile-inputs-changed', "inputs['compile-inputs-changed']")
      .replaceAll('steps.native-lint', "steps['native-lint']");''';assert text.count(old)==1;text=text.replace(old,new).replace('assert.match(commands[1], /--test any_language/);','assert.match(commands[1], /--test any_language/u);');path.write_text(text)
args=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',str(path.relative_to(root))];started=time.monotonic();r=subprocess.run(args,cwd=root,env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256'),capture_output=True);raw=r.stdout+r.stderr;packed=gzip.compress(raw,mtime=0);name='after-corrected';(base/(name+'.log.gz')).write_bytes(packed)
counts={key:int(re.search(r'^(?:ℹ|#) '+key+r' (\d+)',raw.decode(),re.M)[1]) for key in ['tests','pass','fail','skipped']};row={'name':name,'argv':args,'exitCode':r.returncode,'seconds':round(time.monotonic()-started,3),'counts':counts,'file':name+'.log.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'lines':len(raw.splitlines())};rows=json.loads((base/'results.json').read_text());assert len(rows)==2 and all(x['exitCode']==1 for x in rows);rows.append(row);(base/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row));print(raw.decode());assert r.returncode==0 and counts=={'tests':28,'pass':28,'fail':0,'skipped':0}
(base/'outcome.json').write_text(json.dumps({'complete':True,'allPassedAfterFix':True,'regressionReproduced':True,'nativeExecutedLocally':False,'shellFailureControls':3,'independentAuthorshipCredit':0,'failedInitialTestDraftPreserved':True},indent=2)+'\n')
