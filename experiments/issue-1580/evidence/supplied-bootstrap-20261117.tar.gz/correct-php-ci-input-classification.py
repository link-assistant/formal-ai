from pathlib import Path
import json,gzip,hashlib,datetime
source=Path('/tmp/issue-1580-research/php-active-review/inventory.json')
inventory=json.loads(source.read_text());rows=inventory['active']+inventory['historical']
base=Path('experiments/issue-1580/evidence/checks/php-release-guard')
(base/'path-taxonomy-inventory.json.gz').write_bytes(gzip.compress(source.read_bytes(),mtime=0))
root='docs/case-studies/issue-1/data/templates/'
jobs=[];captured=set()
for language in ['js','python','csharp','rust']:
    selected=[row for row in rows if row['path'].startswith(root+language+'/')]
    captured.update(row['path'] for row in selected)
    jobs.append({'language':language,'workingDirectory':root+language,'fileCount':len(selected),'lines':sum(row['lines'] for row in selected),'paths':[row['path'] for row in selected]})
assert all(job['fileCount']>0 for job in jobs)
report={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':inventory['repository'],'commit':inventory['commit'],'pathTaxonomyRootFiles':len(inventory['active']),'pathTaxonomyHistoricalOrExperimentalFiles':len(inventory['historical']),'capturedTreeJobInputs':jobs,'capturedTreeFileCount':len(captured),'note':'Historical path taxonomy does not imply CI inactivity. The current templates workflow installs, tests, builds and audits these captured source trees. Whole-subtree inclusion is conservative; full transitive semantic review remains unfinished.','wholeRepositorySemanticReview':False,'independentAuthorshipCredit':0}
(base/'ci-input-classification.json').write_text(json.dumps(report,indent=2)+'\n')
doc=Path('docs/case-studies/issue-1580/php-release-guard-checkpoint.md')
text=doc.read_text()
start=text.index('All 608 repository blobs are hash verified.')
text=text[:start]+'''All 608 repository blobs are hash verified. The path taxonomy tags 92 root or
nonhistorical files (13,759 lines) and 516 historical or experimental files.
This taxonomy is not a CI activity boundary: the complete 159-line
`templates.yml` currently installs, tests, builds and audits four captured trees
under `docs/case-studies/issue-1/data/templates/`. Those source trees are current
CI inputs despite their historical paths. The conservative subtree inventory is
retained in `ci-input-classification.json`; full dependency and semantic review
remain unfinished. The earlier path-only active/historical wording was incorrect
and is preserved in the supplied-helper archive. The PHP tree and broader issue
remain unfinished. Supplied scripts, conditions and reasoning receive zero
independent Formal AI authorship credit.
'''
text=text.replace('Validation is rerun\nafter the final control is added.','The final control is verified in five focused and 43 maintained cases, without\nskips or failures.')
doc.write_text(text)
review=json.loads((base/'manual-review.json').read_text())
review['finalFocusedTests']=5;review['finalMaintainedTests']=43;review['finalLogsLiterallyRead']=True
review['capturedWorkflowLiterallyRead']={'path':'.github/workflows/templates.yml','lines':159}
(base/'manual-review.json').write_text(json.dumps(review,indent=2)+'\n')
with Path('experiments/issue-1580/work-plan.md').open('a') as stream:stream.write('\nPHP classification correction: the path taxonomy is not a CI boundary. Current templates.yml installs/tests/builds/audits four captured trees under historical-looking case-study paths. Preserve a conservative subtree inventory and keep their full semantic applicability review open. Final PHP controls pass five focused and 43 maintained tests. The Cargo witness refresh preserves all complete objects except four manifest identity hashes, and 2/34 existing source-integrity/identifier checks pass. Native execution remains pending.\n')
print(json.dumps({key:value for key,value in report.items() if key!='capturedTreeJobInputs'},indent=2))
for job in jobs:print(job['language'],job['fileCount'],job['lines'])
