from pathlib import Path
import gzip,hashlib,json,subprocess
base=Path('experiments/issue-1580/evidence/checks/main-merge-444575f2')
status=json.loads(Path('/tmp/issue-1580-research/final-444575f2-focused-status.json').read_text())
print('FOCUSED',status['state'],'FILES',len(status['rows']),'FAILED',[x['file'] for x in status['rows'] if x['exitCode']])
for row in status['rows'][10:]:
 raw=gzip.decompress((base/row['log']).read_bytes())
 assert hashlib.sha256(raw).hexdigest()==row['rawSha256']
 print(row['file']);print(raw.decode())
gate=base/'final/all-local-gates.json'
if gate.exists():
 data=json.loads(gate.read_text());print('GATES',json.dumps({k:v for k,v in data.items() if k!='gateLogs'}))
else:
 p=Path('/tmp/issue-1580-research/final-merged-444575f2-all-local-gates.log')
 print('GATE PROGRESS','\n'.join(p.read_text().splitlines()[-8:]) if p.exists() else 'not started')
print('GIT',subprocess.check_output(['git','status','--short','--untracked-files=no'],text=True))
