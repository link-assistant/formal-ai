from pathlib import Path
import gzip,hashlib,json
source=Path('/tmp/issue-1580-research/templates/java-complete/dev/log/issues/24/pulls/25/osv-scope-reproduction.log')
records=[json.loads(line) for line in source.read_text().splitlines()]
before,after=records[:2];left=json.loads(before['stdout']);right=json.loads(after['stdout'])
same=[];different=[]
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def compare(a,b,path):
 if a==b:same.append({'path':path,'canonicalSha256':digest(a),'canonicalBytes':len(json.dumps(a,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())});return
 if type(a)!=type(b):different.append({'path':path,'compile':a,'test':b});return
 if isinstance(a,dict):
  for key in sorted(a.keys()|b.keys()):
   if key not in a or key not in b:different.append({'path':path+'/'+key,'compile':a.get(key),'test':b.get(key)})
   else:compare(a[key],b[key],path+'/'+key)
 elif isinstance(a,list) and len(a)==len(b):
  for index,(item,other) in enumerate(zip(a,b)):compare(item,other,path+'/'+str(index))
 else:different.append({'path':path,'compile':a,'test':b})
compare(left,right,'/stdout')
for key in sorted(before.keys()|after.keys()):
 if key=='stdout':continue
 compare(before.get(key),after.get(key),'/record/'+key)
value={'pinnedCommit':'dd803a2d9fa5b3a992b435acce73162274fb9e8b','file':str(source.relative_to(source.parents[6])),'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'sourceBytes':source.stat().st_size,'method':'Complete recursive comparison of parsed compile/test records; equal subtrees reuse previously read compile payload. Differences must be read separately. This does not claim literal reading of every test-payload fragment or a current scanner run.','equalSubtrees':same,'differences':different,'thirdRecord':records[2],'independentAuthorshipCredit':0}
out=Path('/tmp/gh-issue-solver-1794900398048/experiments/issue-1580/evidence/checks/java-historical-osv-scope-comparison.json.gz');out.write_bytes(gzip.compress((json.dumps(value,indent=2)+'\n').encode(),mtime=0))
print(json.dumps({'equalSubtrees':len(same),'differences':len(different),'sourceSha256':value['sourceSha256'],'evidence':str(out)}))
for item in different:print(json.dumps(item,ensure_ascii=False))
print('THIRD RECORD',json.dumps(records[2],ensure_ascii=False))
for item in same:print(json.dumps(item))
