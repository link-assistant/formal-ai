from pathlib import Path
import subprocess
name='/tmp/issue-1580-research/commit-python-fragment-archive.py';p=Path(name);print(name)
for i,line in enumerate(p.read_text().splitlines()[:100],1):print(f'{i}: {line}')
print('Archivers:',[str(p) for p in Path('/tmp/issue-1580-research').glob('*archive*')])
print(subprocess.run(['git','status','--short'],capture_output=True,text=True).stdout)
print('Feedback reference:',[p.name for p in Path('/tmp/issue-1580-research').glob('python-fragment-*Comments.json')])
