from pathlib import Path
import re,sys
p=Path(sys.argv[1]);lines=p.read_text().splitlines()
first=int(sys.argv[2]);last=int(sys.argv[3]);assert 0<first<=last and last-first<1500
print(str(p),'TOTAL',len(lines),'RANGE',first,last)
for i in range(first-1,min(last,len(lines))):
    parts=lines[i].split('\t',2)
    payload=re.sub(r'^\d{4}-\d\d-\d\dT[^ ]+ ','',parts[-1])
    print(str(i+1)+': '+payload)
