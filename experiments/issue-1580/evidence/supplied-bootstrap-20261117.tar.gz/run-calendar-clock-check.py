from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys,time

label=sys.argv[1]
assert label in ['before','after']
root=Path('experiments/issue-1580/evidence/checks/calendar-clock-preservation')
root.mkdir(parents=True,exist_ok=True)
command=['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/calendar-clock-preservation.test.mjs']
env=dict(os.environ);env['NODE_OPTIONS']='--max-old-space-size=256'
started=time.monotonic()
process=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
raw=process.stdout
(root/(label+'.log.gz')).write_bytes(gzip.compress(raw,mtime=0))
result={'command':command,'status':process.returncode,'durationSeconds':round(time.monotonic()-started,3),'nodeHeapMiB':256,'rawSha256':hashlib.sha256(raw).hexdigest(),'autonomousAuthorshipCredit':0,'nativeExecuted':False}
(root/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
for line in raw.decode().splitlines():
 if line.startswith(('ok ','not ok ','# pass','# fail','# skipped','# tests')): print(line)
