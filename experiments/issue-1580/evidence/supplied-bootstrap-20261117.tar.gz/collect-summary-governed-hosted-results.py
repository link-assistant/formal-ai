from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,re,subprocess,sys,time,traceback
head='7f19154a21d79f268f48af6b0938f17e6fb32ba3'
base=Path('experiments/issue-1580/evidence/ci/summary-governed-7f19154a')
scratch=Path('/tmp/issue-1580-research/ci-logs/summary-governed-7f19154a')
if len(sys.argv)==1:
    scratch.mkdir(exist_ok=False);base.mkdir(exist_ok=True)
    with (scratch/'worker.log').open('wb') as stream:
        worker=subprocess.Popen([sys.executable,__file__,'finish'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({'pid':worker.pid,'scratch':str(scratch)}));sys.exit(0)
assert sys.argv[1:]==['finish']
records=[]
def capture(label,args,parse=False):
    result=subprocess.run(args,capture_output=True)
    for name,data in [('stdout',result.stdout),('stderr',result.stderr)]:
        (scratch/(label+'.'+name)).write_bytes(data)
        (base/(label+'.'+name+'.gz')).write_bytes(gzip.compress(data,mtime=0))
    records.append({'name':label,'argv':args,'exitCode':result.returncode,'stdoutSha256':hashlib.sha256(result.stdout).hexdigest(),'stderrSha256':hashlib.sha256(result.stderr).hexdigest()})
    assert result.returncode==0,(label,result.stderr.decode())
    return json.loads(result.stdout) if parse else result.stdout
complete=False
try:
    snapshots=[]
    for attempt in range(180):
        raw=subprocess.check_output(['gh','api',f'repos/link-assistant/formal-ai/actions/runs?branch=issue-1580-8d61a32a61e1&head_sha={head}&per_page=100','--paginate','--slurp'])
        pages=json.loads(raw);runs=[r for p in pages for r in p['workflow_runs'] if r['head_sha']==head]
        observation={'observedAt':datetime.now(timezone.utc).isoformat(),'head':head,'workflowCount':len(runs),'completed':sum(r['status']=='completed' for r in runs),'failed':[{'id':r['id'],'name':r['name'],'conclusion':r['conclusion']} for r in runs if r['status']=='completed' and r['conclusion']!='success']}
        snapshots.append(observation)
        (base/'progress.json').write_text(json.dumps({'snapshots':snapshots},indent=2)+'\n')
        (scratch/'latest-runs.json').write_bytes(raw)
        print(json.dumps(observation),flush=True)
        if len(runs)==23 and observation['completed']==23:break
        time.sleep(30)
    else:
        raise RuntimeError('Finite hosted observation window exhausted; preserve progress without claiming completion')
    pages=capture('completed-head-runs',['gh','api',f'repos/link-assistant/formal-ai/actions/runs?branch=issue-1580-8d61a32a61e1&head_sha={head}&per_page=100','--paginate','--slurp'],True)
    runs=[r for p in pages for r in p['workflow_runs'] if r['head_sha']==head]
    assert len(runs)==23 and all(r['status']=='completed' for r in runs)
    jobs_saved=[]
    for run in runs:
        if run['name'] not in ['Layered CI','CI/CD Pipeline'] and run['conclusion']=='success':continue
        pages=capture('jobs-'+str(run['id']),['gh','api',f"repos/link-assistant/formal-ai/actions/runs/{run['id']}/jobs?per_page=100",'--paginate','--slurp'],True)
        jobs=[row for page in pages for row in page['jobs']]
        if run['conclusion']!='success':capture('failed-workflow-'+str(run['id']),['gh','run','view',str(run['id']),'--repo','link-assistant/formal-ai','--log'])
        for job in jobs:
            native='native-type-check' in job['name'] or any('regression' in step['name'].lower() and 'native' in step['name'].lower() for step in job.get('steps',[]))
            if not (native or job['name'].startswith('js tier') or job['conclusion']=='failure'):continue
            raw=capture('job-'+str(job['id']),['gh','api',f"repos/link-assistant/formal-ai/actions/jobs/{job['id']}/logs",'--allow-escape-sequences'])
            lines=raw.decode().splitlines()
            markers=[{'line':i+1,'text':line} for i,line in enumerate(lines) if re.search(r'test result:|test unit::meta_executor_parity|test production_|test compound_|test synthesis_|Running tests/|Running unittests|tests [0-9]|pass [0-9]|fail [0-9]|::error|not ok|error:',line)]
            jobs_saved.append({'workflowRun':run['id'],'jobId':job['id'],'name':job['name'],'conclusion':job['conclusion'],'steps':job['steps'],'rawLines':len(lines),'rawSha256':hashlib.sha256(raw).hexdigest(),'markers':markers,'wholeLogLiterallyRead':False})
    report={'observedAt':datetime.now(timezone.utc).isoformat(),'head':head,'workflowCount':len(runs),'success':sum(r['conclusion']=='success' for r in runs),'failed':[{'id':r['id'],'name':r['name'],'conclusion':r['conclusion']} for r in runs if r['conclusion']!='success'],'jobs':jobs_saved,'records':records,'independentAuthorshipCredit':0}
    data=(json.dumps(report,indent=2)+'\n').encode()
    (base/'completed-results.json.gz').write_bytes(gzip.compress(data,mtime=0))
    complete=True
except BaseException:traceback.print_exc()
outcome={'complete':complete,'head':head,'records':records,'independentAuthorshipCredit':0}
(scratch/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps({key:value for key,value in outcome.items() if key!='records'}),flush=True)
sys.exit(0 if complete else 1)
