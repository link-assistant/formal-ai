from pathlib import Path
import subprocess
path = Path('/tmp/issue-1580-research/pr-body.md')
text = path.read_text().replace('The maintained template suite passes nine tests locally', 'The maintained template suite passes ten tests locally')
text = text.replace('The new head `71e1dee44` is under verification.', 'Head `71e1dee44` completed all 24 workflows: 22 succeeded; Layered CI rejected a CommonJS YAML import and CI/CD rejected two oversized registry evidence files. Both failures have reproducing evidence and focused fixes. The new head `09021cb30` is under verification. Local gate selection now rejects unknown names and zero selected gates; its complete 11-test file and both actual file-size gates pass.')
path.write_text(text)
subprocess.run(['gh','pr','edit','1581','--repo','link-assistant/formal-ai','--body-file',str(path)],check=True)
