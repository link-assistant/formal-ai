from pathlib import Path
import json

root=Path('experiments/issue-1580/upstream')
identity=json.loads(Path('/tmp/issue-1580-research/java-release-report/filed.json').read_text())
p=root/'template-report-identities.json'
rows=json.loads(p.read_text())
assert not any(r['url']==identity['url'] for r in rows)
rows.append(identity)
p.write_text(json.dumps(rows,indent=2)+'\n')
p=root/'filed-issues.txt'
assert identity['url'] not in p.read_text()
p.write_text(p.read_text().rstrip()+'\n'+identity['url']+'\n')
(root/identity['bodyFile']).write_text(Path('/tmp/issue-1580-research/java-release-report/posted-body.md').read_text())
p=Path('docs/case-studies/issue-1580/templates/README.md')
s=p.read_text()
s=s.replace('Its eleven local tests all passed, with no runtime skips.','The Git-observation and Go-integrity checkpoint passed eleven local tests; the current suite passes sixteen with the Java release cases, with no runtime skips.')
old='The new failed-commit report draft is retained in `experiments/issue-1580/upstream/` pending publication of immutable executable evidence.'
new='The failed-commit finding is filed as [Java #31](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/31) with immutable executable evidence at `ff5d883b15aeda06c07e509a73a0a436f10799b7`. The posted report and source identity are retained in `experiments/issue-1580/upstream/`.'
assert s.count(old)==1
p.write_text(s.replace(old,new))
p=Path('experiments/issue-1580/work-plan.md')
p.write_text(p.read_text().rstrip()+'\n\n## Java release report filed (2026-11-17)\n\n[Java template #31](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/31) is filed with published real-Git regression evidence at `ff5d883b15aeda06c07e509a73a0a436f10799b7`. The posted body and identity are recorded locally. Head `078849576b539e0e6adf2843306af16981d5c09a` awaits all hosted results. No upstream repair, hosted release, complete historical Java semantic review, or broader native/benchmark/live-identity completion is claimed.\n')
p=Path('docs/case-studies/issue-1580/README.md')
s=p.read_text()
print('CASE STUDY JAVA REFERENCES')
for n,line in enumerate(s.splitlines(),1):
 if 'Java' in line or 'failed-commit' in line:
  print(str(n)+': '+line)
s=s.rstrip()+'\n\nJava failed-release-commit evidence is now filed as [upstream #31](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/31). Its immutable real-Git test link and posted body are retained under `experiments/issue-1580/upstream/`; reporting does not establish an upstream repair. PR head `078849576b` is still under hosted verification.\n'
p.write_text(s)
print('recorded '+identity['url'])
