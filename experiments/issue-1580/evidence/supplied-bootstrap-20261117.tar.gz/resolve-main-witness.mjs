import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {deserialize,serialize} from 'node:v8';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const path='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8';
const directory='experiments/issue-1580/evidence/checks/main-merge-512ce428/';
const ours=deserialize(execFileSync('git',['show',':2:'+path],{maxBuffer:4194304}));
const theirs=deserialize(execFileSync('git',['show',':3:'+path],{maxBuffer:4194304}));
const deltas=JSON.parse(gunzipSync(readFileSync(directory+'witness-three-way-delta.json.gz')));
assert.equal(deltas.theirs.length,4);
const merged=structuredClone(ours),changed=[];
for(const delta of deltas.theirs){
  assert.match(delta.path,/^\/inventory\/cases\/\d+\/program\/fixtures\/\d+\/sha256$/u);
  const keys=delta.path.split('/').slice(1);
  let target=merged;
  for(const key of keys.slice(0,-1))target=target[key];
  assert.equal(target.sha256,delta.before,'incoming leaf must not overwrite an independent change');
  assert.match(target.file,/^repo:/u);
  const file=target.file.slice(5),actual=createHash('sha256').update(readFileSync(file)).digest('hex');
  assert.equal(actual,delta.after,'incoming digest must match the actual merged fixture bytes');
  target.sha256=actual;
  changed.push({caseIndex:Number(keys[2]),file,sha256:actual});
}
assert.deepEqual(merged.sourceManifest,ours.sourceManifest,'retain the independently reviewed native source witness');
assert.deepEqual(merged.inventory.unsupported,ours.inventory.unsupported);
assert.equal(merged.inventory.total,1185);
assert.equal(merged.inventory.cases.length,221);
assert.equal(merged.inventory.unsupported.length,964);
const expected=structuredClone(merged);
for(const delta of deltas.theirs){
  const keys=delta.path.split('/').slice(1);let target=expected;
  for(const key of keys.slice(0,-1))target=target[key];
  target.sha256=delta.before;
}
assert.deepEqual(expected,ours,'only the four reviewed, non-overlapping fixture digests may change');
const raw=serialize(merged);writeFileSync(path,raw);
const record={method:'Three-way binary merge of exactly four non-overlapping fixture SHA-256 leaves from main. All full case objects, assertions, unsupported inventory and the independently reviewed native source witness are retained; normal complete-inventory validation remains required.',changed,total:1185,cases:221,unsupported:964,sourceManifest:merged.sourceManifest.length,sha256:createHash('sha256').update(raw).digest('hex'),independentAuthorshipCredit:0};
writeFileSync(directory+'witness-resolution.json',JSON.stringify(record,null,2)+'\n');
console.log(JSON.stringify(record));
