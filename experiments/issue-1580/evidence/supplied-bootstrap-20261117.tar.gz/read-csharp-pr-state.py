from pathlib import Path
import json,subprocess

value=json.loads(subprocess.check_output(['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','body,title,isDraft,headRefOid,url'],text=True))
Path('/tmp/issue-1580-research/pr-tenth-before.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value,indent=2))
