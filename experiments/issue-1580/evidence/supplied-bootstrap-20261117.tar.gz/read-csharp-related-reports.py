from pathlib import Path
import json,subprocess

base=Path('/tmp/issue-1580-research/csharp-collision-preflight')
repo='link-foundation/csharp-ai-driven-development-pipeline-template'
for row in json.loads((base/'matching-items.json').read_text()):
    if row['number']==78:continue
    body=row['body'].splitlines()
    assert len(body)<=1500
    print('RELATED',row['url'],row['title'],'LINES',len(body))
    for n,line in enumerate(body,1):print(f'{n}: {line}')
history=json.loads(subprocess.check_output(['gh','api',f'repos/{repo}/commits?path=scripts/merge-changesets.mjs&per_page=5'],text=True))
(base/'merge-changesets-history.json').write_text(json.dumps(history,indent=2)+'\n')
print('RECENT SOURCE HISTORY')
for row in history:print(row['sha'],row['commit']['message'].splitlines()[0])
if history:
    pages=json.loads(subprocess.check_output(['gh','api','--paginate','--slurp',f'repos/{repo}/commits/{history[0]["sha"]}/pulls?per_page=100'],text=True))
    prs=[row for page in pages for row in page]
    (base/'latest-source-pulls.json').write_text(json.dumps(prs,indent=2)+'\n')
    print('LATEST SOURCE PULLS',[(row['number'],row['title']) for row in prs])
