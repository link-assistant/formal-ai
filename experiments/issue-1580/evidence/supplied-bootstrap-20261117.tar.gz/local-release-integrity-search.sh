set -eu
rg -n 'Nothing to commit|collection failed|collect.changelog|git commit.*\|\|' scripts .github/workflows experiments/issue-1580/fixtures -g '*.mjs' -g '*.sh' -g '*.yml' -g '*.js'
