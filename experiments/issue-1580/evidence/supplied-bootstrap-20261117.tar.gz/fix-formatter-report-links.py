from pathlib import Path
import hashlib,json,subprocess
files=subprocess.check_output(['git','ls-tree','-r','--name-only','da712fadd','--','experiments/issue-1580/fixtures/python-template','experiments/issue-1580/evidence/checks/python-release-formatting'],text=True).splitlines()
print('\n'.join(files))
report=Path('experiments/issue-1580/upstream/python-release-formatting-report.md')
body=report.read_text();old='experiments/issue-1580/fixtures/python-template/exact-source.json'
new='experiments/issue-1580/fixtures/python-template/scripts/format_release_notes.py'
assert new in files and old not in files
body=body.replace('[unchanged source and helper identities]','[complete unchanged formatter source]').replace(old,new)
report.write_text(body)
meta=Path('experiments/issue-1580/evidence/checks/python-release-formatting/report-draft.json')
data=json.loads(meta.read_text());data['previousDraftBodySha256']=data['reportBodySha256'];data['reportBodySha256']=hashlib.sha256(report.read_bytes()).hexdigest()
data['immutableEvidenceCommit']=subprocess.check_output(['git','rev-parse','da712fadd'],text=True).strip()
meta.write_text(json.dumps(data,indent=2)+'\n')
print('CORRECTED REPORT SHA256',data['reportBodySha256'])
