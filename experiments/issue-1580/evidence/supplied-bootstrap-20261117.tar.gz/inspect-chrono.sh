set -eu
rg -n 'chrono|time::|jiff::' rust/Cargo.toml rust/src scripts/check-rust-dependencies.sh scripts/security* scripts/*advis* .github/workflows/security.yml > /tmp/issue-1580-research/chrono-uses.txt
sed -n '1,180p' /tmp/issue-1580-research/chrono-uses.txt
python3 -c 'import tomllib; d=tomllib.load(open("rust/Cargo.lock","rb")); [print(x["name"],x["version"],"depends on",[y for y in x.get("dependencies",[]) if y.startswith("chrono")]) for x in d["package"] if any(y.startswith("chrono") for y in x.get("dependencies",[]))]'
