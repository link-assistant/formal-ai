from pathlib import Path
import subprocess,json,hashlib
directory=Path('experiments/issue-1580/evidence/checks/python-runtime-provisioning');directory.mkdir(parents=True,exist_ok=True)
command=['timeout','600','node','--test','--test-concurrency=1','--test-reporter=tap','--test-name-pattern=missing or old Python','experiments/issue-1580/template-python-runtime.test.mjs']
result=subprocess.run(command,capture_output=True,text=True)
log=directory/'before.log';log.write_text(result.stdout+result.stderr)
print(json.dumps({'command':command,'exitCode':result.returncode,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()},indent=2))
print(log.read_text())
assert result.returncode==1
