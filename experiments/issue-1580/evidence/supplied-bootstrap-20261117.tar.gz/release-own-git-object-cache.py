from pathlib import Path
import json
import os
import stat
import subprocess

directory=Path("experiments/issue-1580/evidence/checks/generated-header-memory")
previous=json.loads((directory/"clean-file-cache.json").read_text())
previous["globalCachePurge"]=previous.pop("globalCachesChanged")
cgroup=Path("/sys/fs/cgroup")
def memory():
    stats=dict(line.split() for line in (cgroup/"memory.stat").read_text().splitlines())
    limit=int((cgroup/"memory.max").read_text());current=int((cgroup/"memory.current").read_text())
    return {"limit":limit,"current":current,"available":limit-current,"anon":int(stats["anon"]),"file":int(stats["file"])}
common=subprocess.run(["git","rev-parse","--path-format=absolute","--git-common-dir"],capture_output=True,text=True,check=True).stdout.strip()
before=memory();count=0;size=0
for parent,folders,files in os.walk(Path(common)/"objects",followlinks=False):
    for name in files:
        path=Path(parent)/name
        info=path.lstat()
        if not stat.S_ISREG(info.st_mode):continue
        descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
        try:os.posix_fadvise(descriptor,0,0,os.POSIX_FADV_DONTNEED)
        finally:os.close(descriptor)
        count+=1;size+=info.st_size
record={"action":"Best-effort POSIX_FADV_DONTNEED for regular files in this checkout's own Git object directory","before":before,"after":memory(),"objectsAdvised":count,"objectBytesAdvised":size,"fileContentsChanged":False,"globalCachePurge":False,"independentAuthorshipCredit":0}
(directory/"clean-file-cache.json").write_text(json.dumps({"workspaceEvidence":previous,"gitObjects":record},indent=2)+"\n")
print(json.dumps(record))
