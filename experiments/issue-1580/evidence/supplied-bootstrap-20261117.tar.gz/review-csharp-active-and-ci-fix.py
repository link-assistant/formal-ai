from pathlib import Path
import gzip,hashlib,json,subprocess
def run(args):return subprocess.run(args,check=True,text=True,capture_output=True).stdout
print('DIFF',run(['git','diff','--stat'])); print('STATUS',run(['git','status','--short']))
for name in ['docs/case-studies/issue-1580/README.md','docs/case-studies/issue-1580/templates/README.md','experiments/issue-1580/work-plan.md']:
 print(run(['git','diff','--',name]))
file=Path('docs/case-studies/issue-1580/templates/csharp-partial-semantic-review.json'); new=json.loads(file.read_text()); old=json.loads(run(['git','show','HEAD:'+str(file)]))
assert len(new['files'])==len(old['files'])==337
for before,after in zip(old['files'],new['files']):
 for key in ['path','gitBlob','bytes','sha256','lines']:assert before.get(key)==after.get(key),(key,before['path'])
 if before!=after:print(json.dumps({'path':after['path'],'beforeStatus':before['reviewStatus'],'afterStatus':after['reviewStatus'],'readRanges':after['readRanges'],'decision':after['decision']}))
assert sum(row['reviewStatus']=='active-source-fully-read' for row in new['files'])==158
assert sum(row['lines'] for row in new['files'] if row['reviewStatus']=='active-source-fully-read')==18327
receipt=json.loads(Path('experiments/issue-1580/evidence/checks/csharp-changeset-collision/abbreviation-filename-correction.json').read_text())
data=Path(receipt['newPath']).read_bytes(); assert hashlib.sha256(data).hexdigest()==receipt['compressedSha256']
assert hashlib.sha256(gzip.decompress(data)).hexdigest()==receipt['rawSha256']
print('UNCHANGED RATC HET',run(['git','diff','HEAD','--','data/meta/abbreviation-ratchet.lino','data/meta/notation-rules.lino']))
print('WHITESPACE',run(['git','diff','--check'])); print('STAGED WHITESPACE',run(['git','diff','--cached','--check']))
pr=json.loads(run(['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','title,body,url,isDraft,headRefOid,headRefName']))
Path('/tmp/issue-1580-research/pr-csharp-active-before.json').write_text(json.dumps(pr,indent=2)+'\n')
print('CURRENT PR',json.dumps(pr,indent=2))
