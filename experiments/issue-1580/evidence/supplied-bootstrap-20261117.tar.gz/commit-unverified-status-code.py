from pathlib import Path
import hashlib,json,subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/checks/unverified-child-status/code-review'
record=json.loads((base/'record.json').read_text())
assert record['patchSha256']=='e062222b721a697a2fa023c8f73fe036e0cda80aa8abedec45d1c0f285c38138'
patch=subprocess.check_output(['git','diff','--cached','--no-ext-diff','--no-color'],cwd=root)
assert hashlib.sha256(patch).hexdigest()==record['patchSha256']
for item in record['files']:
    assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256']
assert subprocess.check_output(['git','branch','--show-current'],cwd=root).decode().strip()=='issue-1580-8d61a32a61e1'
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
record['literalReviewComplete']=True
record['reviewedPatchLines']=[1,379]
(base/'record.json').write_text(json.dumps(record,indent=2)+'\n')
outcome=subprocess.run(['git','commit','-m','Reject unverified task drafts before parent composition'],cwd=root,capture_output=True)
print(outcome.stdout.decode())
print(outcome.stderr.decode())
assert outcome.returncode==0
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()
(base/'commit.json').write_text(json.dumps({'head':head,'patchSha256':record['patchSha256'],'sourceReviewComplete':True,'independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps({'codeCommit':head,'sourceFiles':len(record['files']),'pushed':False}))
