"""Supplied host recovery only: no production change or solver validation credit."""
from pathlib import Path
import subprocess, tarfile, json
root=Path('/tmp/gh-issue-solver-1794900398048')
snapshot=Path('/tmp/issue-1580-research/frozen-formal-driver-a748854')
snapshot.mkdir(exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='a748854197dcc693033610acc6589f10b1c6d525',head
paths=['js','ts','scripts','data','experiments/js_dogfood','experiments/issue-1580/formal-command.mjs','package.json']
p=subprocess.Popen(['git','archive',head,*paths],cwd=root,stdout=subprocess.PIPE)
with tarfile.open(fileobj=p.stdout,mode='r|') as archive:
    archive.extractall(snapshot,filter='data')
assert p.wait()==0
receipt={'purpose':'temporary recovery of merge-broken Formal AI bootstrap; zero validation and independent reasoning credit','head':head,'paths':paths,'snapshot':str(snapshot)}
(snapshot/'recovery-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
