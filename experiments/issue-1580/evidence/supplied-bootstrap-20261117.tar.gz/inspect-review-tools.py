from pathlib import Path
import json
for p in sorted(Path('/tmp/issue-1580-research').glob('*java*')):
 if any(word in p.name for word in ['review','checkpoint','progress','historical']):print(p.name)
p=Path('/tmp/issue-1580-research/java-history-pages/manifest.json');v=json.loads(p.read_text());print('MANIFEST',type(v).__name__);print(json.dumps(v,ensure_ascii=False)[:2800])
p=Path('docs/case-studies/issue-1580/templates/java-historical-partial-review.json');v=json.loads(p.read_text());print('REVIEW NONFILES');print(json.dumps({k:v for k,v in v.items() if k!='files'},indent=2,ensure_ascii=False))
