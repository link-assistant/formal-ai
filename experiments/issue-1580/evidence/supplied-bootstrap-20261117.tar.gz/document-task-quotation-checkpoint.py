from pathlib import Path

doc = Path('docs/case-studies/issue-1580/task-quotation-checkpoint.md')
assert not doc.exists()
doc.write_text('''# Task quotation boundaries and rejected context candidate

The input head `a97832237cbb365000dd7296050984e4bdd59ebb` finishes all 23
hosted workflows successfully. Layered CI run 44233930887 completes at
2026-11-18T04:06:29Z; the exact-head records are retained under
`experiments/issue-1580/evidence/ci/declared-language-policy-a9783223/`.
Scope-gated workflow successes do not establish native runtime acceptance.

## Reproduced quotation defect

`splitRequest('Count "salt and pepper" and report the size', 'en')` produces
three tasks before the repair: `Count "salt`, `pepper"`, and `report the size`.
The shared `task-decomposition` grammar declares curly quotes, CJK quotes and
backticks, but omits ASCII double and single quotes. Both runtime masks read
that incomplete list, so conjunctions inside those quotes become task edges.

Add both ASCII pairs to the shared grammar. The JavaScript and Rust masks
honor backslash escaping and distinguish word apostrophes from quotation
delimiters. An opening apostrophe touching the preceding alphanumeric character
stays inside a word; a closing apostrophe touching the following alphanumeric
character stays inside a word. This preserves unquoted contractions, plural
possessives and contractions inside quoted passages. Mixed-language quote
styles and the existing relation precedence continue to use the same grammar.

Seven new shared cases cover double-quoted aggregation and sequence,
single-quoted aggregation, an unquoted contraction, a quoted contraction,
a plural possessive, and escaped double quotes. Every original input,
expected result and trace in the 15-case fixture is unchanged. The native
fixture reader already iterates all cases; the fixture now contains 22.
The canonical fixture checker remains
`node experiments/issue-1550/parity-fixture.mjs --check`.

The focused regression fails before the repair with seven passing tests and
two failures: the new literal-boundary assertion and the deliberately stale
fixture inventory. The primary error shows the exact incorrect three-part
split. A direct command-driver attempt was refused as non-verbatim and earns
no verification credit; the retained before run executes through the supplied
Python orchestration with the original source and seed restored temporarily,
then restores the candidate bytes in a `finally` block.

Worker and TypeScript projections are regenerated through their maintained
writers. An initial bare `rustfmt --check` uses the wrong style edition and
also finds one long new expression; retain that failure. Format and check
using the repository's Rust 2024 edition. This is source formatting only.
Focused post-repair checks and the complete shared-data gate set are pending.

## Rejected single-passage binding candidate

The finite disposable-VM experiment runs eight requests before and after
a supplied candidate, for 16 observations, with no actual or mocked transport
calls. It retains required child tests and leaves production sources unchanged.
The first harness attempt fails before any request because it assigns a
constant; its complete source and log are retained separately.

The corrected candidate restores context for the original meeting request and
changed concert facts. Withholding child `t0.3` still leaves the root unresolved.
However, only four of eight explicit qualification checks pass. The independent
passage-plus-arithmetic request changes from unresolved to resolved while its
answer remains only `2 + 2 = 4`, omitting the requested passage answer. The
uncovered-subject case also changes to resolved while returning a gap. The
two-passage request already reports resolved with an inadequate answer in both
variants; that pre-existing failure is separate from the candidate regression.
The quoted-conjunction control identifies the separate quotation defect above.

Reject the binding candidate. `runTaskTest` checks whether children resolved
and whether the root has nonempty, permitted-intent text; it does not establish
that a direct parent answer covers each required child result. Correct context
binding therefore also needs executable parent coverage obligations. Neither
the quotation repair nor a successful direct passage answer completes that
broader requirement. Do not make the request atomic or remove child checks.

The complete experiment, 16-line outcome log, initial harness failure and
explicit failed qualification checks are under
`experiments/issue-1580/evidence/checks/passage-routing-probe/`.
Selected outcome/binding/meta-execution review is separate from full literal
review of every nested solver trace in the 305,557-byte artifact.

## Remaining acceptance

No native executable runs locally. Hosted native quotation behavior, parent
coverage, multi-passage context binding and every earlier broad unchecked
criterion remain unfinished. The PR stays draft and unmerged. Supplied scripts,
patches and conclusions receive zero independent Formal AI authorship credit;
the independently accepted reasoning share remains 0/20.
''')

plan = Path('experiments/issue-1580/work-plan.md')
with plan.open('a') as output:
    output.write('''

## Task quotation and rejected context binding (2026-11-18)

All 23 workflows on `a97832237cbb365000dd7296050984e4bdd59ebb` complete successfully; preserve exact-head snapshots without claiming native acceptance from scope gates. A finite 16-observation disposable context candidate restores the original and changed-facts traces, preserves a withheld child, but passes only four of eight explicit qualification checks. Reject it: the independent arithmetic request becomes resolved while omitting the passage result, and the pre-existing two-passage coverage failure remains. Retain complete evidence and default-off production behavior. Separately reproduce a real quotation defect: the shared grammar omits ASCII quote pairs and splits connectives inside literal passages. Draft both runtime masks with escape/apostrophe boundaries, seven new shared fixture controls and maintained projections; all 15 original fixture cases remain identical. The before run has seven passes/two failures, including the exact incorrect split. Bare rustfmt's edition mismatch is preserved; corrected focused checks and the complete shared-data gates remain pending. Parent coverage, native execution, the broader unchecked criteria and 0/20 independent reasoning acceptance remain unfinished. See docs/case-studies/issue-1580/task-quotation-checkpoint.md.
''')

changelog = Path('changelog.d/20261117_120000_issue-1580-ci-regressions.md')
with changelog.open('a') as output:
    output.write('\n- Preserve ASCII quoted connectives during recursive task decomposition, including escaped quotes, contractions and possessives, with shared JavaScript/native quotation fixtures.\n')
print('Documented the bounded quotation repair, rejected context candidate and unfinished acceptance')
