from pathlib import Path
import json,subprocess

issue=json.loads(subprocess.check_output(['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','title,body'],text=True))
print('ISSUE',issue['title'])
print(issue['body'])
result=subprocess.run(['rg','-l','the_named_branch_is_pushed_to_in_spanish|georgia_resolves_to_asia_tbilisi_not_a_raw_surface|only_the_current_platform_release_is_downloaded|a_workflow_requirement_adds_the_workflow_in_every_language','rust','js','scripts'],text=True,capture_output=True)
print('NATIVE FILES',result.stdout)
