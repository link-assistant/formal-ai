from pathlib import Path
import datetime, gzip, hashlib, json, subprocess

repo='link-assistant/formal-ai'
head='83882c0ec7c26b28dc8ac274fada2b39d9dc3a67'
root=Path('/tmp/issue-1580-research')
base=Path('experiments/issue-1580/evidence/ci/83882c0ec')
base.mkdir(exist_ok=True)
def run(arguments):return subprocess.run(arguments,text=True,capture_output=True,check=True).stdout
raw=run(['gh','run','list','--repo',repo,'--branch','issue-1580-8d61a32a61e1','--commit',head,'--limit','100','--json','databaseId,workflowName,status,conclusion,createdAt,updatedAt,headSha,url'])
runs=json.loads(raw)
(root/'picomatch-current-runs.json').write_text(raw)
print('HEAD',head,'WORKFLOWS',len(runs),'SUCCESS',sum(item['conclusion']=='success' for item in runs))
for item in runs:
    if item['conclusion']!='success':print(item)
targets=[item for item in runs if item['status']=='completed' and (item['workflowName'] in ['Layered CI','CI/CD Pipeline'] or item['conclusion']!='success')]
logs=[]
for item in targets:
    label='layered' if item['workflowName']=='Layered CI' else 'pipeline' if item['workflowName']=='CI/CD Pipeline' else 'failure'
    name=label+'-'+str(item['databaseId'])+'.log'
    path=root/name
    if not path.exists():path.write_text(run(['gh','run','view',str(item['databaseId']),'--repo',repo,'--log']))
    data=path.read_bytes()
    (base/(name+'.gz')).write_bytes(gzip.compress(data,mtime=0))
    logs.append({'workflow':item['workflowName'],'runId':item['databaseId'],'head':head,'conclusion':item['conclusion'],'log':name+'.gz','rawSha256':hashlib.sha256(data).hexdigest(),'rawBytes':len(data),'rawLines':len(data.splitlines())})
    print('ARCHIVED',logs[-1])
    for number,line in enumerate(data.decode().splitlines(),1):
        if any(term in line for term in ['picomatch-security-backport','calendar-clock-preservation','ordinary glob paths','POSIX negation retains','0 vulnerabilities','test result: FAILED','##[error]']):print('EVIDENCE',number,line[:1600])
all_passed=len(runs)>=24 and all(item['headSha']==head and item['status']=='completed' and item['conclusion']=='success' for item in runs)
summary={'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'workflowCount':len(runs),'allPassed':all_passed,'runs':runs,'logs':logs,'nativeTestExecutionClaim':False,'autonomousAuthorshipCredit':0}
(base/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(base/'all-runs.json.gz').write_bytes(gzip.compress(raw.encode(),mtime=0))
print('ALL PASSED',all_passed)
