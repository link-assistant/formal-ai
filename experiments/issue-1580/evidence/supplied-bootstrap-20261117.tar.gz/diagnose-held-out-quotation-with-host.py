from pathlib import Path
import hashlib, json, subprocess

code = '''
import { WorkerHost } from './js/server/worker-host.mjs';
import { installNodeHost } from './js/agentic/node-host.mjs';
await installNodeHost(new WorkerHost());
const { grammarVocabulary } = await import('./js/agentic/crate/formalization_grammar.mjs');
const { splitRequest } = await import('./js/agentic/crate/meta_executor.mjs');
const { isAlphanumeric } = await import('./js/agentic/crate/rust_str.mjs');
const { QUOTATION_CASES } = await import('./rust/tests/web/helpers/issue-1550-meta-executor-cases.mjs');
console.log(JSON.stringify({ chineseAggregation: grammarVocabulary('zh', 'connective-aggregation'), cjkAlphanumeric: isAlphanumeric('计') }));
for (const [name, text, relation, parts, language = 'en'] of QUOTATION_CASES.slice(7)) {
  const actual = splitRequest(text, language);
  console.log(JSON.stringify({ name, text, actual, expected: { relation, parts }, pass: JSON.stringify(actual) === JSON.stringify({ relation, parts }) }));
}
'''
root = Path('experiments/issue-1580/evidence/checks/task-quotation-boundaries')
log = root / 'held-out-direct-split-with-host.jsonl'
assert not log.exists()
with log.open('wb') as output:
    subprocess.run(['node', '--max-old-space-size=256', '--input-type=module', '-e', code], stdout=output, stderr=subprocess.STDOUT, check=True)
print(log.read_text())
correction = {
  'earlierLog': 'before-held-out-apostrophe-boundaries.log',
  'correction': 'The earlier held-out test failed because three fixture entries had not been generated. It did not demonstrate a CJK split defect. The first direct diagnostic omitted installNodeHost and failed before producing a split. The corrected direct diagnostic uses the actual aggregation connective inside each Chinese quotation and compares split output before fixture generation.',
  'nativeExecuted': False,
  'independentAuthorshipCredit': 0,
}
(root / 'held-out-diagnostic-correction.json').write_text(json.dumps(correction, indent=2) + '\n')
for name in ['memory.current', 'memory.max']:
    p = Path('/sys/fs/cgroup') / name
    print(name, p.read_text().strip())
