set -eu
git diff --check
git add -- .github/actions/setup-sccache/action.yml scripts/check-sccache-write-health.sh rust/tests/web/sccache-outage-fallback.test.mjs docs/case-studies/issue-1580/README.md experiments/issue-1580/work-plan.md changelog.d/20261117_120000_issue-1580-ci-regressions.md experiments/issue-1580/evidence/checks/cache-log-retention.json experiments/issue-1580/evidence/checks/cache-log-before.log.gz experiments/issue-1580/evidence/checks/cache-log-after.log.gz experiments/issue-1580/evidence/checks/cache-log-shellcheck.log.gz experiments/issue-1580/evidence/checks/cache-log-gates.log.gz
git commit -m "fix(ci): retain bounded opt-in cache backend diagnostics"
git status --short
