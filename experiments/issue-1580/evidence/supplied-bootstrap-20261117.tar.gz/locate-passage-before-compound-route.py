import subprocess
for args in [
 ['rg','-n','reading|passage|compound|factual|extractive','js/worker/formal_ai_worker_solve.js'],
 ['rg','-n','Read this and answer|reading|passage','rust/tests/web/issue-1172-factual-qa-subject-gate.test.mjs'],
 ['rg','--files','js'],
]:
    r=subprocess.run(args,text=True,capture_output=True)
    print('COMMAND',args,'EXIT',r.returncode)
    if '--files' in args:
        print('\n'.join(p for p in r.stdout.splitlines() if any(s in p for s in ['reading','extractive','compound'])))
    else:print(r.stdout,r.stderr)
