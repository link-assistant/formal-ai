set -eu
gh pr view 1581 --repo link-assistant/formal-ai --json title,body,isDraft,headRefOid,mergeStateStatus > /tmp/issue-1580-research/pr-before-seventh.json
python3 -c 'import json; from pathlib import Path; d=json.loads(Path("/tmp/issue-1580-research/pr-before-seventh.json").read_text()); print(json.dumps(d,indent=2))'
