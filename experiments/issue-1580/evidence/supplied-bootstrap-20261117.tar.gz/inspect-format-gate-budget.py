from pathlib import Path
import subprocess

for name in ['/sys/fs/cgroup/memory.current','/sys/fs/cgroup/memory.max']:
    path=Path(name)
    if path.exists():print(name,path.read_text().strip())
for name in ['experiments/formal_ai_subagent/local-gates.mjs']:
    lines=Path(name).read_text().splitlines()
    print('FILE',name,len(lines),'first 110 lines')
    print('\n'.join(f'{n}: {line}' for n,line in enumerate(lines[:110],1)))
print('RELATED GATE PROTOCOL RECORDS')
result=subprocess.run(['rg','--files','experiments/issue-1580/evidence/checks'],check=True,capture_output=True,text=True)
print('\n'.join(path for path in result.stdout.splitlines() if 'gate' in path and ('full' in path or 'remaining' in path or 'summary' in path))[:3000])
