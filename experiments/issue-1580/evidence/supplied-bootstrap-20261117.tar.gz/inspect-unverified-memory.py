from pathlib import Path
import json, subprocess

values = dict(line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines())
report = {'currentBytes': int(Path('/sys/fs/cgroup/memory.current').read_text()), 'limitBytes': int(Path('/sys/fs/cgroup/memory.max').read_text()), 'categories': {name: int(values.get(name, 0)) for name in ['anon', 'file', 'kernel', 'slab', 'file_dirty', 'file_writeback']}, 'events': Path('/sys/fs/cgroup/memory.events').read_text(), 'largestProcesses': subprocess.check_output(['ps', '-eo', 'pid,ppid,rss,comm', '--sort=-rss'], text=True).splitlines()[:13]}
Path('/tmp/issue-1580-research/unverified-child-status/memory-observation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
