from pathlib import Path
import subprocess,json,gzip
p=subprocess.run(['ps','-eo','pid,ppid,etime,rss,args'],capture_output=True,text=True,check=True)
for line in p.stdout.splitlines():
 if any(word in line for word in ['run-audit-focused.py','javascript-audit-inventory.test.mjs','check-javascript-dependencies.sh','formal-command.mjs','js_dogfood/drive.mjs']): print(line)
directory=Path('experiments/issue-1580/evidence/checks/audit-inventory-boundary')
for path in sorted(directory.glob('*')):
 print(path.name,path.stat().st_size)
 if path.name=='own-after.json':print(path.read_text())
 if path.name=='own-after.log.gz':print(gzip.decompress(path.read_bytes()).decode())
