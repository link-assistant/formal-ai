import json,pathlib,subprocess
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
result=subprocess.run(['ps','-eo','pid,ppid,pgid,stat,rss,args'],text=True,capture_output=True)
for line in result.stdout.splitlines():
 if any(x in line for x in ['run-browser-meaning-adjacent.py','local-gates.mjs','check-specification-in-javascript.mjs','collect-summary-governed-hosted-results.py']):print(line[:400])
result=subprocess.run(['gh','api','--paginate','repos/link-assistant/formal-ai/actions/runs/44320550638/jobs?per_page=100'],cwd=root,capture_output=True)
path=pathlib.Path('/tmp/issue-1580-research/ci-logs/summary-governed-7f19154a/pipeline-jobs-progress.json')
path.write_bytes(result.stdout)
assert result.returncode==0,result.stderr.decode()
data=json.loads(result.stdout)
print('PIPELINE JOBS',[{k:r.get(k) for k in ['id','name','status','conclusion','started_at','completed_at']} for r in data['jobs']])
