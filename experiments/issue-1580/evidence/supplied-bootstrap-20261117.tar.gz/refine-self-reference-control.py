from pathlib import Path
import shutil

logs=Path('/tmp/issue-1580-research/self-reference-checks')
shutil.copyfile(logs/'after.log',logs/'intermediate.log')
p=Path('experiments/issue-1580/template-reference-graph.test.mjs')
s=p.read_text()
old="assert.equal(graph.files.includes('.github/actions/check/index.mjs'),false);"
assert s.count(old)==1
p.write_text(s.replace(old,"assert.equal(graph.files.includes('unrelated/private.txt'),false);"))
print('Keep unrelated-file control without treating conservative index expansion as a defect')
