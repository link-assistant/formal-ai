import json
from pathlib import Path
rows=json.loads(Path('/tmp/issue-1580-research/head-09021cb30/runs.json').read_text())
print(json.dumps(rows[0],indent=2))
