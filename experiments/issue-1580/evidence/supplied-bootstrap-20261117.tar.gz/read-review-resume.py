from pathlib import Path
import subprocess

for file in ['AGENTS.md','CONTRIBUTING.md','experiments/issue-1580/evidence/checks/generated-header-memory/pr-review/summary.json','experiments/issue-1580/evidence/checks/generated-header-memory/pr-review/README.md']:
 p=Path(file)
 lines=p.read_text().splitlines()
 print('\nFILE',file,'LINES',len(lines))
 assert len(lines)<=1500
 print('\n'.join(f'{n}: {v}' for n,v in enumerate(lines,1)))
print(subprocess.check_output(['rg','-n','new-source.diff','experiments/issue-1580','docs/case-studies/issue-1580'],text=True))
print(subprocess.check_output(['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','title,body'],text=True))
