import json
from pathlib import Path
import subprocess

root = Path('/tmp/issue-1580-research')
for name in ['task-cue-final-gates', 'ci-logs/synthesis-c8fb9ad1']:
    directory = root / name
    print('\nDIRECTORY', directory)
    for path in sorted(directory.glob('*')):
        if path.is_file() and ('progress' in path.name or path.name in ['results.json', 'completed-results.json', 'worker.log']):
            print('FILE', path.name)
            lines = path.read_text(errors='replace').splitlines()
            print('\n'.join(lines[-12:]))
for pid in ['1278377', '1276586']:
    result = subprocess.run(['ps', '-p', pid, '-o', 'pid=,stat=,etime=,args='], text=True, capture_output=True)
    print('PROCESS', result.stdout.strip())
print('GIT STATUS')
subprocess.run(['git', 'status', '--short'], check=True)
for relative in ['experiments/issue-1580/evidence/ci/native-failure-summary.json', 'experiments/issue-1580/evidence/ci/main-015a6831/individual-native-failed-jobs/panic-coverage.json']:
    path = Path(relative)
    print('\nNATIVE INVENTORY', relative)
    value = json.loads(path.read_text())
    print(json.dumps(value, ensure_ascii=False, indent=2)[:16000])
