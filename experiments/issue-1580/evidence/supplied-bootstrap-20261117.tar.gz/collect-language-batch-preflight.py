from pathlib import Path
import subprocess,sys,json,gzip,hashlib,time,traceback
scratch=Path('/tmp/issue-1580-research/language-batch-preflight');out=Path('experiments/issue-1580/evidence/checks/language-batch-preflight')
if len(sys.argv)==1:
 scratch.mkdir(exist_ok=False);out.mkdir(exist_ok=False)
 with (scratch/'worker.log').open('wb') as stream:p=subprocess.Popen([sys.executable,__file__,'finish'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
 print(json.dumps({'pid':p.pid,'scratch':str(scratch)}));sys.exit()
assert sys.argv[1:]==['finish'];records=[]
commands=[('issue',['gh','api','repos/link-assistant/formal-ai/issues/1580']),('issue-comments',['gh','api','repos/link-assistant/formal-ai/issues/1580/comments?per_page=100','--paginate','--slurp']),('required-subissues',['gh','api','repos/link-assistant/formal-ai/issues/1580/sub_issues?per_page=100','--paginate','--slurp']),('pull',['gh','api','repos/link-assistant/formal-ai/pulls/1581']),('pull-comments',['gh','api','repos/link-assistant/formal-ai/issues/1581/comments?per_page=100','--paginate','--slurp']),('inline-comments',['gh','api','repos/link-assistant/formal-ai/pulls/1581/comments?per_page=100','--paginate','--slurp']),('reviews',['gh','api','repos/link-assistant/formal-ai/pulls/1581/reviews?per_page=100','--paginate','--slurp']),('fetch-main',['git','fetch','origin','main']),('main-ancestor',['git','merge-base','--is-ancestor','origin/main','HEAD']),('branch',['git','branch','--show-current']),('current-head-runs',['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','100','--json','databaseId,workflowName,status,conclusion,headSha,createdAt'])]
for name,argv in commands:
 r=subprocess.run(argv,capture_output=True);row={'name':name,'argv':argv,'exitCode':r.returncode}
 for label,raw in [('stdout',r.stdout),('stderr',r.stderr)]:
  (out/(name+'.'+label+'.gz')).write_bytes(gzip.compress(raw,mtime=0));row[label+'Sha256']=hashlib.sha256(raw).hexdigest()
 records.append(row);print(json.dumps(row),flush=True)
 if r.returncode!=0:print(r.stderr.decode()[:2000],flush=True)
(out/'results.json').write_text(json.dumps(records,indent=2)+'\n')
(out/'outcome.json').write_text(json.dumps({'complete':True,'allCommandsSucceeded':all(x['exitCode']==0 for x in records),'independentAuthorshipCredit':0},indent=2)+'\n')
