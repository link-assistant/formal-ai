import json
import subprocess
from pathlib import Path

folder = Path('/tmp/issue-1580-research/java-report-preflight')
folder.mkdir(exist_ok=True)
repository = 'link-foundation/java-ai-driven-development-pipeline-template'
head = subprocess.check_output(['gh', 'api', 'repos/' + repository + '/commits/HEAD', '--jq', '.sha'], text=True).strip()
print('upstream HEAD', head)
assert head == 'dd803a2d9fa5b3a992b435acce73162274fb9e8b', 're-review changed upstream before filing'
raw = subprocess.check_output(['gh', 'api', 'repos/' + repository + '/issues?state=all&per_page=100', '--paginate'])
(folder / 'issues.json').write_bytes(raw)
rows = json.loads(raw)
print('all issues / PRs', len(rows))
for row in rows:
    if 'pull_request' not in row:
        print(row['number'], row['state'], row['title'])
assert not any('release' in row['title'].lower() and 'commit' in row['title'].lower() and 'pull_request' not in row for row in rows), 'inspect possible duplicate before filing'
print('No matching failed-release-commit issue title. Previously fetched full bodies/related PRs were reviewed for this distinct boundary.')
