#!/bin/sh
set -eu
cp /tmp/issue-1580-research/template-download-retry.test.mjs experiments/issue-1580/template-download-retry.test.mjs
curl --version
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-download-retry.test.mjs
gh issue list --repo link-foundation/cpp-ai-driven-development-pipeline-template --state all --search 'retry download' --limit 20 --json number,title,url > /tmp/issue-1580-research/cpp-retry-existing-issues.json
gh pr list --repo link-foundation/cpp-ai-driven-development-pipeline-template --state merged --limit 5 --json number,title,body,url,mergedAt > /tmp/issue-1580-research/cpp-recent-prs.json
