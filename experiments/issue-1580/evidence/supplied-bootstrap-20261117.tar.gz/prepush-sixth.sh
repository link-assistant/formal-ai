set -eu
test "$(git branch --show-current)" = issue-1580-8d61a32a61e1
git fetch origin main
git merge-base --is-ancestor origin/main HEAD
git diff --check
git status --short
gh run list --repo link-assistant/formal-ai --branch "$(git branch --show-current)" --status in_progress --json databaseId,workflowName,headSha > /tmp/issue-1580-research/prepush-sixth-active.json
gh run list --repo link-assistant/formal-ai --branch "$(git branch --show-current)" --status queued --json databaseId,workflowName,headSha > /tmp/issue-1580-research/prepush-sixth-queued.json
python3 -c 'import json; from pathlib import Path; paths=[Path("/tmp/issue-1580-research/prepush-sixth-"+s+".json") for s in ["active","queued"]]; assert all(not json.loads(p.read_text()) for p in paths); print("No active or queued branch workflows.")'
git log -5 --oneline
