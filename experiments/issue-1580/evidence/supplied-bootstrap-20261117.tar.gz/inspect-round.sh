set -eu
git branch --show-current
git status --short
git diff --stat
ps -eo pid,ppid,rss,etimes,args | rg 'local-gates|finish-local-round|formal-ai-shell-capture|check-workflow|check-governed|generate-runtime-feature' | head -n 20
tail -n 12 /tmp/issue-1580-research/all-local-gates-fourth.log
cat /sys/fs/cgroup/memory.current
cat /sys/fs/cgroup/memory.max
