import subprocess
from pathlib import Path
for name in ['CONTRIBUTING.md','rust/tests/web/issue-1589-calendar-currency.test.mjs','docs/ci-cd/default-branch-builds.md','/tmp/issue-1580-research/run-runtime-replay-all-gates.py']:
    p=Path(name);lines=p.read_text().splitlines()
    print(name,'LINES',len(lines))
    if len(lines)<=180:
        for number,line in enumerate(lines,1):print(f'{number}: {line}')
    else:
        for number,line in enumerate(lines[:70],1):print(f'{number}: {line}')
print(subprocess.check_output(['rg','--files','rust/tests/web','-g','*clock*','-g','*permission*','-g','*generated*'],text=True))
print(subprocess.check_output(['rg','-n','process.argv|--check|--write|Usage|usage','scripts/generate-debug-stage-sources.mjs','scripts/lib/generate-native-specification-programs.mjs','scripts/sync-rust-embedded-data.mjs'],text=True,stderr=subprocess.STDOUT))
