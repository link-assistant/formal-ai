from pathlib import Path
import json,subprocess
def run(args):
 p=subprocess.run(args,text=True,capture_output=True)
 if p.returncode:raise RuntimeError(str(args)+' '+p.stderr)
 return p.stdout
for name in ['experiments/issue-1580/fixtures/python-template/exact-source.json','experiments/issue-1580/fixtures/python-template/format_release_notes.py','experiments/issue-1580/evidence/checks/generated-header-memory/final-gates/all-local-gates.json']:
 print(name,Path(name).is_file())
print(run(['git','status','--short']))
print(run(['git','diff','--stat']))
for script in ['archive-round-bootstrap.py','archive-evidence.py']:
 print(run(['python3','/tmp/issue-1580-research/'+script]))
print(run(['git','diff','--','experiments/issue-1580/upstream/python-release-formatting-report.md']))
print(run(['rg','-n','a25993f0038f','experiments/issue-1580','docs/case-studies/issue-1580']))
