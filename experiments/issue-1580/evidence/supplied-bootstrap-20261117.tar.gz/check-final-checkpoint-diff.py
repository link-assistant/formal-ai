from pathlib import Path
import subprocess
commands=[['git','status','--short'],['git','diff','--stat'],['git','diff','--check'],['git','diff','--','docs/case-studies/issue-1580/runtime-fixture-checkpoint.md','experiments/issue-1580/work-plan.md','docs/case-studies/issue-1580/README.md'],['git','diff','--','docs/case-studies/issue-1580/templates/java-historical-partial-review.json']]
for index,command in enumerate(commands):
    result=subprocess.run(command,capture_output=True,text=True)
    if index==4:
        path=Path('/tmp/issue-1580-research/java-through-22-review.diff');path.write_text(result.stdout)
        print('JAVA DIFF SAVED',len(result.stdout.splitlines()),'lines',path)
    else:
        print('COMMAND',command,'EXIT',result.returncode);print(result.stdout);print(result.stderr)
    assert result.returncode==0
