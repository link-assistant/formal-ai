from pathlib import Path
import subprocess
r=subprocess.run(['rg','-n','pr-(comments|inline-comments|reviews|conversation)\.json','experiments/issue-1580','docs/case-studies/issue-1580','--glob','!*.gz'],capture_output=True,text=True)
print(r.stdout[:18000])
print('TOTAL_BYTES',len(r.stdout))
for name in ['rust/tests/web/browser-seed-universe.test.mjs','rust/tests/web/worker-source-cache.test.mjs']:
    if Path(name).exists():print('FILE',name,Path(name).read_text())
