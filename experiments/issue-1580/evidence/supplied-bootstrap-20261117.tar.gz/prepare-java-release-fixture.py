import hashlib
import json
import shutil
from pathlib import Path

origin = Path('/tmp/issue-1580-research/templates/java-complete')
destination = Path('experiments/issue-1580/fixtures/java-template')
index = destination / 'source.json'
manifest = json.loads(index.read_text())
inventory = json.loads(Path('/tmp/issue-1580-research/templates/java-complete-inventory.json').read_text())
if isinstance(inventory, dict):
    print('INVENTORY KEYS', list(inventory))
    raise SystemExit('inspect inventory shape before copying')
inventory = {row['path']: row for row in inventory}
for name in ['scripts/version-and-commit.mjs', 'scripts/github-release-state.mjs', 'scripts/collect-changelog.mjs']:
    assert name not in {item['path'] for item in manifest['files']}
    data = (origin / name).read_bytes()
    git_blob = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
    assert git_blob == inventory[name]['gitBlob']
    target = destination / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(origin / name, target)
    manifest['files'].append({'path': name, 'gitBlob': git_blob, 'sha256': hashlib.sha256(data).hexdigest()})
index.write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'copied': manifest['files'][-3:]}, indent=2))
