from pathlib import Path
import gzip,json,re
base=Path('experiments/issue-1580/evidence/ci/main-015a6831/individual-failed-jobs')
receipt=json.loads((base/'receipt.json').read_text())
results=[]
for download in receipt['downloads']:
    lines=gzip.decompress((base/download['log']).read_bytes()).decode(errors='replace').splitlines()
    markers=[]
    for index,line in enumerate(lines,1):
        if re.search(r'✖ |not ok |##\[error\]|AssertionError|^Error:',line):
            payload=line.split('\t')[-1]
            markers.append({'line':index,'text':payload})
    results.append({'job':download['name'],'log':download['log'],'markers':markers})
    print(download['name'],download['log'],'total lines',len(lines),'markers',len(markers))
    for marker in markers: print(marker['line'],marker['text'])
(base/'failure-index.json').write_text(json.dumps({'results':results,'full_manual_review':False},indent=2)+'\n')
