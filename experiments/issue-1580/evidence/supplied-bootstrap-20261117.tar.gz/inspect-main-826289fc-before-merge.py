import subprocess, json
from pathlib import Path

def run(command): return subprocess.check_output(command,text=True)
old='512ce428029a92687628b4180309ee5ab660fe08';new='826289fc78154dcd894199ed966f366176be0afb'
print('NEW_MAIN_COMMITS')
print(run(['git','log','--format=%H %cI %s',old+'..'+new]))
diff=run(['git','diff','--numstat',old,new])
Path('/tmp/issue-1580-research/main-826289fc-numstat.txt').write_text(diff)
print('CHANGED_FILES',diff)
print('NEW_MAIN_RUNS',run(['gh','run','list','--repo','link-assistant/formal-ai','--branch','main','--commit',new,'--limit','40','--json','databaseId,workflowName,status,conclusion,createdAt,headSha,url']))
