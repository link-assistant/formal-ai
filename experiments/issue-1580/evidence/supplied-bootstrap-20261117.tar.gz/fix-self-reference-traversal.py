from pathlib import Path

p=Path('experiments/issue-1580/trace-template-ci.mjs')
s=p.read_text()
old="""  const resolve = (from, value, reason, relative = false) => {
    if (value.includes('://') || value.startsWith('node:')) return;
    const base = relative ? path.posix.dirname(from) : '.';
"""
new="""  const resolve = (from, value, reason, relative = false) => {
    if (value.includes('://') || value.startsWith('node:')) return;
    const observed = value;
    // GitHub's $/ references name this repository at the running commit.
    if (value.startsWith('$/')) value = './' + value.slice(2);
    if (/[$*?{}]/u.test(value)) {
      unresolved.push({from,value:observed,reason:'dynamic/glob path in '+reason});
      return;
    }
    const base = relative ? path.posix.dirname(from) : '.';
"""
assert s.count(old)==1
s=s.replace(old,new)
s=s.replace("if (target.startsWith('../')) {\n      unresolved.push({from, value, reason: 'reference leaves the source tree'});", "if (target === '..' || target.startsWith('../') || path.posix.isAbsolute(target)) {\n      unresolved.push({from, value:observed, reason: 'reference leaves the source tree'});")
old="unresolved.push({from,value,reason:'no static file match: '+reason});"
assert s.count(old)==1
s=s.replace(old,"unresolved.push({from,value:observed,reason:'no static file match: '+reason});")
needle="  const scan = (from, text, reason) => {"
assert s.count(needle)==1
s=s.replace(needle,"""  const localUse = (from, value, kind) => {
    if (typeof value !== 'string' || !(value.startsWith('./') || value.startsWith('$/'))) return;
    resolve(from,value,(value.startsWith('$/') ? 'self-repository ' : 'local ') + kind);
  };
"""+needle)
old="if (job.uses?.startsWith('./')) resolve(file,job.uses,'local reusable workflow');"
assert s.count(old)==1
s=s.replace(old,"localUse(file,job.uses,'reusable workflow');")
old="if (step.uses?.startsWith('./')) resolve(file,step.uses,'local action');"
assert s.count(old)==1
s=s.replace(old,"localUse(file,step.uses,'action');")
p.write_text(s)
p=Path('rust/tests/web/issue-1580-template-observations.test.mjs')
s=p.read_text()
assert 'template-reference-graph.test.mjs' not in s
p.write_text(s+"import '../../../experiments/issue-1580/template-reference-graph.test.mjs';\n")
print('resolve self-repository uses and maintain the five graph regressions in fast PR CI')
