from pathlib import Path
import datetime,gzip,hashlib,json,re,subprocess

head='9095abcbcccdd5518ce2c9318d3ebc6eb8914fc8'
run=44262999002
base=Path('experiments/issue-1580/evidence/ci/executor-status-'+head[:8])
scratch=Path('/tmp/issue-1580-research/ci-logs/executor-status-'+head[:8])
stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
def get(args):
    result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert result.returncode==0,result.stderr.decode()
    return result.stdout
def save(name,raw):
    path=base/(name+'.gz');assert not path.exists(),path
    packed=gzip.compress(raw,mtime=0);path.write_bytes(packed)
    (scratch/name).write_bytes(raw)
    return dict(archive=path.name,rawBytes=len(raw),rawLines=len(raw.splitlines()),rawSha256=hashlib.sha256(raw).hexdigest(),archiveSha256=hashlib.sha256(packed).hexdigest())
detail=get(['gh','api',f'repos/link-assistant/formal-ai/actions/runs/{run}/attempts/2'])
d=json.loads(detail);assert d['head_sha']==head and d['run_attempt']==2 and d['status']=='completed'
records=[save('layered-attempt-2.json',detail)]
payload=get(['gh','api',f'repos/link-assistant/formal-ai/actions/runs/{run}/attempts/2/jobs?per_page=100','--paginate'])
jobs=json.loads(payload);assert len(jobs['jobs'])==jobs['total_count']
records.append(save('layered-attempt-2-jobs.json',payload))
observations=[]
for job in jobs['jobs']:
    if job['conclusion'] in ['success','skipped']:
        continue
    ident=job['id'];name=f'layered-attempt-2-job-{ident}.log'
    raw=get(['gh','run','view',str(run),'--repo','link-assistant/formal-ai','--job',str(ident),'--log'])
    records.append(save(name,raw))
    markers=[{'line':i,'text':line} for i,line in enumerate(raw.decode().splitlines(),1) if re.search(r'error:|fatal:|##\[error\]|curl 28|timed out|# tests |# fail |test result:',line,re.I)]
    observations.append({'id':ident,'name':job['name'],'conclusion':job['conclusion'],'steps':[{k:step[k] for k in ['name','conclusion','number']} for step in job['steps']],'markers':markers,'rawLog':str(scratch/name)})
report={'observedAt':stamp,'head':head,'runId':run,'attempt':2,'conclusion':d['conclusion'],'jobs':observations,'archives':records,'allFailedPayloadsLiterallyRead':False,'causeEstablished':False,'independentAuthorshipCredit':0}
path=base/'retry-two-log-inventory.json';assert not path.exists();path.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
