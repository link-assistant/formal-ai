from pathlib import Path
import subprocess,json,base64,hashlib
out=Path('/tmp/issue-1580-research/php-active-review/upstream/example-app.png')
query='repos/link-foundation/php-ai-driven-development-pipeline-template/contents/docs/case-studies/issue-1/data/templates/js/docs/screenshots/example-app/example-app.png?ref=issue-23-addf7c5fd0d4'
result=subprocess.run(['gh','api',query],capture_output=True)
assert result.returncode==0,result.stderr.decode()
payload=json.loads(result.stdout)
raw=base64.b64decode(payload['content'])
assert raw.startswith(b'\x89PNG\r\n\x1a\n')
out.write_bytes(raw)
print(json.dumps({'path':str(out),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'gitBlob':payload['sha']}))
print(subprocess.run(['file',str(out)],capture_output=True,text=True).stdout)
