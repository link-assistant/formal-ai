from pathlib import Path
import csv,hashlib,json,subprocess,gzip,datetime
root=Path('/tmp/issue-1580-research/templates/php-complete')
fixture=Path('experiments/issue-1580/fixtures/php-template')
workflow='.github/workflows/release.yml'
rows=list(csv.DictReader(Path('docs/case-studies/issue-1580/templates/php-files.tsv').open(),delimiter='\t'))
row=next(item for item in rows if item['path']==workflow)
raw=(root/workflow).read_bytes()
assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['git_blob']
target=fixture/workflow;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
manifest=json.loads((fixture/'source.json').read_text())
assert not any(item['path']==workflow for item in manifest['files'])
manifest['files'].append({'path':workflow,'gitBlob':row['git_blob'],'sha256':hashlib.sha256(raw).hexdigest()})
(fixture/'source.json').write_text(json.dumps(manifest,indent=2)+'\n')
test=Path('experiments/issue-1580/template-php-release-integrity.test.mjs')
test.write_text('''// Evaluate the real pinned job guards with bounded, dependency-result controls.
// This is an offline expression model, not an observed hosted publication.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {Script} from 'node:vm';
import YAML from 'yaml';

const fixture=new URL('./fixtures/php-template/',import.meta.url);
const provenance=JSON.parse(readFileSync(new URL('source.json',fixture),'utf8'));
for(const item of provenance.files){
  const bytes=readFileSync(new URL(item.path,fixture));
  assert.equal(createHash('sha1').update(`blob ${bytes.length}\\0`).update(bytes).digest('hex'),item.gitBlob);
  assert.equal(createHash('sha256').update(bytes).digest('hex'),item.sha256);
}
const workflow=YAML.parse(readFileSync(new URL('.github/workflows/release.yml',fixture),'utf8'));
const prerequisites=['lint','test','build','release-preflight'];
const unsuccessful=['failure','cancelled','skipped'];

function admitted(job,{results={},event='push',ref='refs/heads/main',cancelled=false}={}){
  const needs=Object.fromEntries(prerequisites.map(name=>[name,{result:results[name]??'success'}]));
  const success=()=>Object.values(needs).every(value=>value.result==='success');
  const source=String(job.if).trim().replace(/^\\$\\{\\{\\s*|\\s*\\}\\}$/gu,'');
  const explicitStatus=/\\b(?:always|success|failure|cancelled)\\s*\\(/u.test(source);
  const value=new Script(source).runInNewContext({
    github:{event_name:event,ref},needs,always:()=>true,cancelled:()=>cancelled,
    success,failure:()=>Object.values(needs).some(value=>value.result==='failure'),
  },{timeout:100});
  return Boolean(value)&&(explicitStatus||success());
}

const automatic=workflow.jobs['auto-release'];
const manual=workflow.jobs['manual-release'];
const repaired={...automatic,if:automatic.if+' &&\\n'+
  ['lint','test','build'].map(name=>`needs.${name}.result == \\'success\\'`).join(' &&\\n')};

test('PHP automatic release admits unsuccessful quality checks in the actual pinned guard',()=>{
  assert.deepEqual(automatic.needs,prerequisites);
  assert.equal(admitted(automatic),true,'successful default-branch push is admitted');
  for(const name of ['lint','test','build']){
    for(const result of unsuccessful){
      assert.equal(admitted(automatic,{results:{[name]:result}}),true,`${name}: ${result}`);
    }
  }
  for(const result of unsuccessful){
    assert.equal(admitted(automatic,{results:{'release-preflight':result}}),false);
  }
});

test('explicit success checks block all unsuccessful prerequisites while retaining successful release',()=>{
  assert.equal(admitted(repaired),true);
  for(const name of prerequisites){
    for(const result of unsuccessful){
      assert.equal(admitted(repaired,{results:{[name]:result}}),false,`${name}: ${result}`);
    }
  }
});

test('the PHP automatic-release candidate retains event, branch and cancellation controls',()=>{
  for(const job of [automatic,repaired]){
    assert.equal(admitted(job,{event:'pull_request'}),false);
    assert.equal(admitted(job,{event:'workflow_dispatch'}),false);
    assert.equal(admitted(job,{ref:'refs/heads/feature'}),false);
    assert.equal(admitted(job,{cancelled:true}),false);
  }
});

test('the unchanged PHP manual-release guard already requires every prerequisite to succeed',()=>{
  assert.deepEqual(manual.needs,prerequisites);
  assert.equal(admitted(manual,{event:'workflow_dispatch'}),true);
  assert.equal(admitted(manual),false);
  assert.equal(admitted(manual,{event:'workflow_dispatch',cancelled:true}),false);
  for(const name of prerequisites){
    for(const result of unsuccessful){
      assert.equal(admitted(manual,{event:'workflow_dispatch',results:{[name]:result}}),false);
    }
  }
});
''')
entry=Path('rust/tests/web/issue-1580-template-observations.test.mjs')
entry.write_text(entry.read_text()+"import '../../../experiments/issue-1580/template-php-release-integrity.test.mjs';\n")
out=Path('/tmp/issue-1580-research/php-active-review')
inventory=json.loads((out/'inventory.json').read_text())
all_rows=inventory['active']+inventory['historical']
inventory['active']=[item for item in all_rows if item['role']!='historical-evidence-or-experiment' and not item['path'].startswith('dev/log/')]
inventory['historical']=[item for item in all_rows if item not in inventory['active']]
(out/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
print(json.dumps({'fixture':manifest['files'][-1],'activeFiles':len(inventory['active']),'activeLines':sum(item['lines'] for item in inventory['active']),'historicalFiles':len(inventory['historical']),'independentAuthorshipCredit':0},indent=2))
for item in inventory['active']: print(item['path'],item['lines'],item['role'])
