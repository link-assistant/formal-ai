from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
path=root/'data/seed/text-formalization.lino';text=path.read_text();old='    quote-pair "«»"'
assert text.count(old)==1;text=text.replace(old,'''    quote-cue-role "prompt_text_question_cue"
    quote-cue-separator ":"
    quote-cue-separator "："
'''+old);path.write_text(text)
path=root/'js/agentic/crate/meta_executor.mjs';text=path.read_text()
text=text.replace("import { containsCjk } from './seed_meanings.mjs';","import { containsCjk, wordsForRole } from './seed_meanings.mjs';")
marker='function cleanPart(characters) {'
function='''// A seeded passage cue is one unit only when it directly introduces a quote.
function maskQuotedCues(lowered, original, mask) {
  const separators = ruleValues('quote-cue-separator');
  const openers = ruleValues('quote-pair').map((pair) => Array.from(pair)[0]);
  const cues = ruleValues('quote-cue-role').flatMap(wordsForRole)
    .map((word) => ({ chars: Array.from(word).map((character) => character.toLowerCase()),
      cjk: containsCjk(word) }))
    .filter((cue) => cue.chars.length > 0);
  for (let at = 0; at < original.length; at += 1) {
    for (const cue of cues) {
      if (!markerMatches(lowered, original, mask, at, cue.chars, cue.cjk)) continue;
      const end = at + cue.chars.length;
      let next = end;
      while (next < original.length
        && (isWhitespace(original[next]) || separators.includes(original[next]))) next += 1;
      if (openers.includes(original[next]) && mask[next]) {
        mask.fill(true, at, end);
        break;
      }
    }
  }
}

'''
assert marker in text;text=text.replace(marker,function+marker)
old='  const mask = quotedMask(original);';assert text.count(old)==1;text=text.replace(old,old+'\n  maskQuotedCues(lowered, original, mask);');path.write_text(text)
path=root/'rust/src/meta_executor.rs';text=path.read_text()
marker='#[path = "meta_executor/production.rs"]'
assert marker in text;text=text.replace(marker,'#[path = "meta_executor/decomposition.rs"]\nmod decomposition;\n\n'+marker)
old='    let mask = quoted_mask(&original);';assert text.count(old)==1;text=text.replace(old,'    let mut mask = quoted_mask(&original);\n    decomposition::mask_quoted_cues(&lowered, &original, &mut mask);');path.write_text(text)
path=root/'rust/src/meta_executor/decomposition.rs';assert not path.exists()
path.write_text('''//! Quoted-passage cue boundaries, shared in data with the JavaScript executor.

use super::{Marker, lower_char, marker_matches, rule_values};
use crate::coding::contains_cjk;

pub(super) fn mask_quoted_cues(lowered: &[String], original: &[char], mask: &mut [bool]) {
    let separators = rule_values("quote-cue-separator");
    let openers: Vec<char> = rule_values("quote-pair")
        .iter()
        .filter_map(|pair| pair.chars().next())
        .collect();
    let cues: Vec<Marker> = rule_values("quote-cue-role")
        .iter()
        .flat_map(|role| crate::seed::lexicon().words_for_role(role))
        .map(|word| Marker {
            chars: word.chars().map(lower_char).collect(),
            cjk: contains_cjk(&word),
        })
        .filter(|cue| !cue.chars.is_empty())
        .collect();
    for at in 0..original.len() {
        for cue in &cues {
            if !marker_matches(lowered, original, mask, at, cue) {
                continue;
            }
            let end = at + cue.chars.len();
            let mut next = end;
            while next < original.len()
                && (original[next].is_whitespace()
                    || separators
                        .iter()
                        .any(|separator| separator.chars().eq([original[next]])))
            {
                next += 1;
            }
            if original.get(next).is_some_and(|value| openers.contains(value))
                && mask.get(next) == Some(&true)
            {
                mask[at..end].fill(true);
                break;
            }
        }
    }
}
''')
path=root/'rust/tests/web/helpers/issue-1550-meta-executor-cases.mjs';text=path.read_text()
marker="const answered = (content) =>"
assert marker in text;text=text.replace(marker,"import { CUE_CASES } from './issue-1580-task-cue-cases.mjs';\nexport { CUE_CASES };\n\n"+marker)
marker='  ...STATUS_CASES,';assert text.count(marker)==1;text=text.replace(marker,marker+'\n  ...CUE_CASES,');path.write_text(text)
path=root/'experiments/issue-1550/parity-fixture.mjs';text=path.read_text()
text=text.replace('const { CASES, STATUS_CASES }','const { CASES, STATUS_CASES, CUE_CASES }')
text=text.replace('const statusNames = new Set(STATUS_CASES.map((entry) => entry.name));','const supplementalNames = new Set([...STATUS_CASES, ...CUE_CASES].map((entry) => entry.name));')
text=text.replace('!statusNames.has(entry.name)','!supplementalNames.has(entry.name)')
marker="  { path: path.join(REPO, 'rust/tests/fixtures/meta-executor-status-parity.json'), entries: STATUS_CASES },"
assert marker in text;text=text.replace(marker,marker+"\n  { path: path.join(REPO, 'rust/tests/fixtures/meta-executor-cue-parity.json'), entries: CUE_CASES },");path.write_text(text)
path=root/'rust/tests/web/issue-1550-meta-executor.test.mjs';text=path.read_text()
marker='fixture.cases.push(...statusFixture.cases);';assert marker in text
text=text.replace(marker,marker+'''
const cueFixture = JSON.parse(
  readFileSync(new URL('../fixtures/meta-executor-cue-parity.json', import.meta.url), 'utf8'),
);
assert.equal(cueFixture.schema, fixture.schema);
fixture.cases.push(...cueFixture.cases);''');path.write_text(text)
path=root/'rust/tests/unit/meta_executor_parity.rs';text=path.read_text()
marker='const STATUS_FIXTURE: &str = include_str!("../fixtures/meta-executor-status-parity.json");'
assert marker in text;text=text.replace(marker,marker+'\nconst CUE_FIXTURE: &str = include_str!("../fixtures/meta-executor-cue-parity.json");')
start=text.index('    let status: Value =');end=text.index('    fixture\n}',start)
text=text[:start]+'''    for (name, source) in [("status", STATUS_FIXTURE), ("cue", CUE_FIXTURE)] {
        let supplement: Value = serde_json::from_str(source).expect(name);
        assert_eq!(supplement["schema"], fixture["schema"]);
        fixture["cases"]
            .as_array_mut()
            .expect("fixture cases")
            .extend(
                supplement["cases"]
                    .as_array()
                    .expect("supplement cases")
                    .iter()
                    .cloned(),
            );
    }
'''+text[end:];path.write_text(text)
path=root/'changelog.d/20261117_120000_issue-1580-ci-regressions.md';text=path.read_text();text+='\n- Keep seeded quoted-passage cues intact during task decomposition in both runtimes, while preserving surrounding independent tasks.\n';path.write_text(text)
print('Drafted cue boundaries in both runtimes and shared fixture wiring. Native compilation remains hosted.')
subprocess.run(['rg','--files','scripts','-g','*seed*','-g','*worker*','-g','*typescript*','-g','*translate*'],cwd=root,check=True)
