from pathlib import Path
import json
scratch=Path('/tmp/issue-1580-research');pid=int((scratch/'finish-sparse-source-verification.pid').read_text());p=Path('/proc')/str(pid)/'status'
if p.exists():
 for line in p.read_text().splitlines():
  if line.startswith(('State:','VmRSS:','PPid:')):print(line)
else:print('Process ended.')
print((scratch/'finish-sparse-source-verification.log').read_text())
print('Remaining temporary copies:',[p.name for p in scratch.glob('sparse-fast-source-*')])
