from pathlib import Path
for path in sorted(Path('/tmp/issue-1580-research').glob('*')):
    if path.is_file() and ('issue' in path.name or 'best-practice' in path.name or 'feedback' in path.name):
        print(path.name, path.stat().st_size)
