import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const r='/tmp/gh-issue-solver-1794900398048',file='scripts/lib/generated-native-programs.mjs';
const hash=x=>createHash('sha256').update(x).digest('hex');
const current=await import(r+'/'+file),rows=[];
for(const parent of ['a748854197dcc693033610acc6589f10b1c6d525','30ff2d8a81cf8f21f679c2826851b5b413c34b7a']){
 const raw=execFileSync('git',['show',parent+':'+file],{cwd:r,maxBuffer:8*1024*1024});
 const previous=await import('data:text/javascript;base64,'+raw.toString('base64'));
 const changes=[],additions=[];
 for(const key of Object.keys(previous)){
  assert(Array.isArray(previous[key]));assert(Array.isArray(current[key]));
  const byPath=new Map(current[key].map(item=>[item.path,item]));
  for(const old of previous[key]){
   const next=byPath.get(old.path);assert(next,'Preserve registered program '+old.path);
   function normalized(node){
    if(Array.isArray(node))return node.map(normalized);
    if(!node||typeof node!=='object')return node;
    const copy=Object.fromEntries(Object.entries(node).map(([name,value])=>[name,normalized(value)]));
    if(typeof node.path==='string'&&typeof node.sha256==='string'&&/^(rust|js|data|desktop|vscode)\//u.test(node.path)){
     const actual=hash(readFileSync(r+'/'+node.path));
     if(copy.sha256!==actual){const parentHash=hash(execFileSync('git',['show',parent+':'+node.path],{cwd:r,maxBuffer:8*1024*1024}));if(copy.sha256!==parentHash)console.log('STALE_PARENT_IDENTITY',JSON.stringify({parent,export:key,program:old.path,source:node.path,registry:copy.sha256,parentHash,current:actual}));assert.equal(copy.sha256,parentHash);changes.push({export:key,program:old.path,source:node.path,before:copy.sha256,after:actual});}
     copy.sha256=actual;
    }
    return copy;
   }
   assert.deepEqual(normalized(old),next,'Complete registered program '+old.path);
  }
  const previousPaths=new Set(previous[key].map(item=>item.path));
  additions.push({export:key,previous:previous[key].length,current:current[key].length,added:current[key].filter(item=>!previousPaths.has(item.path)).map(item=>item.path)});
 }
 rows.push({parent,previousSha256:hash(raw),currentSha256:hash(readFileSync(r+'/'+file)),completePreviousProgramsPreservedAfterSourceHashUpdates:true,changes,additions});
}
writeFileSync(r+'/experiments/issue-1580/evidence/checks/language-main-integration/native-registry-merged-review.json',JSON.stringify({parents:rows,independentAuthorshipCredit:0},null,2)+'\n');
console.log(JSON.stringify(rows.map(row=>({...row,changes:row.changes.length})),null,2));
