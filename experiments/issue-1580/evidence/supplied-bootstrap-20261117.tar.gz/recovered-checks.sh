#!/bin/sh
set -eu
for file in rust/tests/web/hive-mind-draft-workflow.test.mjs rust/tests/web/draft-request-replay.test.mjs rust/tests/web/hive-draft-attempt-identity.test.mjs rust/tests/web/issue-1028-all-mode-sharding.test.mjs
do
  log="/tmp/issue-1580-research/$(basename "$file" .mjs).log"
  timeout 600 node --test --test-concurrency=1 "$file" > "$log" 2>&1
  tail -n 8 "$log"
done
