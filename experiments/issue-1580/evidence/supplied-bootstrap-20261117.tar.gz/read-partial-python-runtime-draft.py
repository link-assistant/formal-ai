from pathlib import Path
for name,start,end in [('.github/workflows/layered-ci.yml',380,401),('experiments/issue-1580/template-python-runtime.mjs',1,40)]:
    print(name)
    for i,line in enumerate(Path(name).read_text().splitlines(),1):
        if start<=i<=end:print(f'{i}: {line}')
