from pathlib import Path
import gzip,json,re
directory=Path("experiments/issue-1580/evidence/ci/main-512ce428")
p=directory/"failure-download-completion.json"
if not p.exists():
    print("Downloads still running")
    log=directory/"failure-download-bootstrap.log"
    if log.exists():
        for line in log.read_text(errors="replace").splitlines()[-4:]:print(line)
    raise SystemExit(0)
record=json.loads(p.read_text());print(json.dumps(record,ensure_ascii=False))
for run in record["runs"]:
    if run.get("status")!=0:continue
    path=directory/run["log"]
    lines=gzip.decompress(path.read_bytes()).decode(errors="replace").splitlines()
    selected=[]
    pattern=re.compile(r"::error::|test result: FAILED|thread .+ panicked|^.*error(?:\[E[0-9]+\])?:|FATAL ERROR|^.*FAIL(?:ED)?(?:\s|:)|##\[error\]|exited with code (?:1|137|143)|exceeded.*budget",re.I)
    for n,line in enumerate(lines,1):
        if pattern.search(line):selected.append({"line":n,"text":line})
    (directory/(run["runId"]+"-error-locations.json.gz")).write_bytes(gzip.compress((json.dumps(selected,indent=2)+"\n").encode(),mtime=0))
    print("ERROR LOCATIONS",run["runId"],"total",len(selected),"log lines",len(lines))
    for row in selected[:32]:print(f'{row["line"]}: {row["text"]}')
