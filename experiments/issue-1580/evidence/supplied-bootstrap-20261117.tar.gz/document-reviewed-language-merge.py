from pathlib import Path
import json
p=Path('experiments/issue-1580/evidence/checks/language-main-integration/native-registry-merged-review.json')
v=json.loads(p.read_text())
for row in v['parents']:
 assert row.pop('completePreviousProgramsPreservedAfterSourceHashUpdates') is True
 row['completePreviousProgramsPreservedAfterListedSourceIdentityAndSpanRepairs']=True
p.write_text(json.dumps(v,indent=2)+'\n')
p=Path('docs/case-studies/issue-1580/language-source-binding-checkpoint.md');s=p.read_text();marker='## Verification still required\n';assert marker in s
s=s[:s.index(marker)]+'''## Reviewed main integration

The integration with main `30ff2d8a81cf8f21f679c2826851b5b413c34b7a` preserves both branches' behavior. The isolated native regression step now includes the existing four targets plus main's `cnl_output` and `cnl_parity`. The four captured-source units and unchanged Spanish sibling remain a separate step. The CNL parity runner discovers fixtures at runtime, so changes anywhere under `data/parity/issue-1584-cnl/` select native execution, including future language fixtures. The real workflow policy has 24 passing tests. This closes the merge's admission gap without a local Rust build.

Both TypeScript/JavaScript pairs preserve main's controlled-language answer projection and this branch's same-language and meta-subtask guards. The native solver retains main's controlled solve closure with this branch's validated intent selection. Generated worker prerequisite and runtime-feature identities are regenerated from the resolved sources.

The static native program registry is regenerated through its maintained JavaScript writer. The complete comparison preserves all 157 prior programs from each parent and adds `formal_ai::cnl_output::CNL_POLICY_PATH`. Against this branch, only the 157 library source-witness hashes change. Main's registry already contains 16 stale hashes across `derivation.rs`, `memory_sync.rs` and `service_accessibility.rs`, plus a stale `LEARNED_CHUNK_KIND` source span. The merged registry repairs those identities and offsets; its current 9676–9734 span selects the exact unchanged native constant declaration. Every current source-witness hash is checked against actual bytes. All other complete program fields remain equal. The initial stricter review failures are retained rather than treated as production failures.

The merged translation ledger uses all 164 committed source projections: 342 translated, 38 workaround, three inferred and 2,656 carried records; 114 modules have translations, one is fully translated and 50 are refused. The maintained renderers and regression ratchets against both parent ledgers pass. No native translation build, projection replacement or reduced threshold is used.

The governed witness is compared as complete objects against both parents before the maintained explicit writer refreshes it. Against this branch, 111 source-hash references change and one unchanged unsupported OpenAI compatibility test moves into its new `output.rs` module. Against main, 26 source-hash references change. Every previous/current source hash is tied to its exact Git blob/current file. All 1,185 records remain: 221 supported and 964 unsupported. The original reader remains unchanged. The complete delta, both parent binary archives, reviewed candidate and writer receipt are retained under `experiments/issue-1580/evidence/checks/language-main-integration/`.

During conflict resolution, the ordinary Formal AI driver could not import conflict-marked prerequisite modules. A temporary coherent snapshot of local commit `a748854197dcc693033610acc6589f10b1c6d525` was used only to execute the supplied merge-resolution commands. Host snapshot construction and the failed preload attempt receive zero solver or validation credit. No identity check was disabled. All merged-tree checks run through the restored ordinary driver against the actual checkout, without the preload or snapshot.

## Verification still required

The first pre-merge inventory completes in 764.618 seconds: 80 executable gates pass, six fail and 52 are explicitly excluded. All six failures trace to placing the test-only module under `rust/src`. The module has moved to the existing test tree without changing any ceiling or allowlist. All 91 initial aggregate/focused/detailed payload hashes are verified.

On the resolved merged tree, Rust formatting and all ten focused JavaScript files pass: workflow policy 24/24, browser language 10/10, fixture integrity 2/2, governed identifiers 34/34, request context 4/4, CNL output 13/13, HTTP 4/4, dialogue 7/7, parity 6/6 and grammar matrix 8/8. Their complete logs have been read and hash-verified. The full shared gate inventory is still running; its final result and every failure must be collected before publication.

The four new native tests, unchanged Spanish sibling and merged six-target execution remain unverified until they run on the actual published head. Every broader issue criterion remains unfinished in the work plan. Independent Formal AI reasoning acceptance remains **0/20**: all supplied patches, scripts, commands and review here receive zero independent authorship credit. PR #1581 remains draft and unmerged.
'''
p.write_text(s)
p=Path('experiments/issue-1580/work-plan.md');s=p.read_text();old='- [ ] Finish collecting every full local gate result; move the native test module into the existing test tree to resolve the specialization false positive without weakening the gate.';assert old in s
s=s.replace(old,'- [x] Collect every first local inventory result and move the native test module into the existing test tree, resolving the six specialization failures without weakening any gate. Retain all first-attempt evidence.')
with p.open('w') as f:f.write(s)
with p.open('a') as f:f.write('\n- [x] Resolve all twenty main-integration conflicts; preserve all seven native targets, CNL fixture admission, controlled output and both language guards. Review the complete governed witness against both parents, all native registry objects and all 164 translation projections.\n- [x] Pass and literally read Rust formatting and all ten merged focused JavaScript files, with complete log hashes checked. Full merged gate collection and actual next-head native execution remain pending.\n')
print('Updated checkpoint and work plan; no native or complete-gate success claimed.')
