from pathlib import Path
source=Path('/tmp/issue-1580-research/refresh-calendar-derived-sources.py').read_text()
source=source.replace("calendar-seed-integrity/derived'","calendar-seed-integrity/derived-corrected'")
source=source.replace("'scripts/mirror-package-data.mjs']","'scripts/mirror-package-data.mjs','--write']")
source=source.replace("'scripts/generate-debug-stage-sources.mjs']","'scripts/generate-debug-stage-sources.mjs','--write']")
exec(compile(source,__file__,'exec'))
