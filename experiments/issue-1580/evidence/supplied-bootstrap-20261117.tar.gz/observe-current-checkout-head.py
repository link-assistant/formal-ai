from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
out=root/'experiments/issue-1580/evidence/ci'/('checkout-'+head[:8]);out.mkdir(exist_ok=True)
argv=['gh','api',f'repos/link-assistant/formal-ai/actions/runs?branch=issue-1580-8d61a32a61e1&head_sha={head}&per_page=100','--paginate','--slurp']
r=subprocess.run(argv,cwd=root,capture_output=True);assert r.returncode==0,r.stderr.decode()
pages=json.loads(r.stdout);runs=[run for page in pages for run in page['workflow_runs']];assert all(run['head_sha']==head for run in runs)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
(out/('runs-'+stamp+'.json.gz')).write_bytes(gzip.compress(r.stdout,mtime=0))
print(json.dumps({'head':head,'observedAt':stamp,'total':len(runs),'complete':sum(run['status']=='completed' for run in runs),'success':sum(run['conclusion']=='success' for run in runs),'nonpassing':[{'id':run['id'],'workflow':run['name'],'status':run['status'],'conclusion':run['conclusion'],'attempt':run['run_attempt'],'createdAt':run['created_at'],'url':run['html_url']} for run in runs if run['conclusion']!='success'],'rawSha256':hashlib.sha256(r.stdout).hexdigest()}))
if runs and all(run['status']=='completed' for run in runs):
 for run in runs:
  if run['conclusion']=='success':continue
  prefix=str(run['id'])+'-attempt-'+str(run['run_attempt']);target=out/(prefix+'.log.gz')
  if target.exists():continue
  argv=['gh','run','view',str(run['id']),'--repo','link-assistant/formal-ai','--attempt',str(run['run_attempt']),'--log']
  result=subprocess.run(argv,cwd=root,capture_output=True);assert result.returncode==0,result.stderr.decode()
  target.write_bytes(gzip.compress(result.stdout,mtime=0))
  receipt={'run':run['id'],'workflow':run['name'],'head':head,'attempt':run['run_attempt'],'rawBytes':len(result.stdout),'rawLines':len(result.stdout.splitlines()),'rawSha256':hashlib.sha256(result.stdout).hexdigest()}
  (out/(prefix+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
