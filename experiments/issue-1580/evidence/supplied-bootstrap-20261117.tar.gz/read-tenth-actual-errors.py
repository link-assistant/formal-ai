from pathlib import Path
import gzip,json,re
root=Path('/tmp/issue-1580-research/head-e582b270a')
data=json.loads((root/'44089535561.json').read_text())
for job in data.get('jobs',[]):
    if job.get('conclusion') not in ['success','skipped']:
        print('FAILED JOB',json.dumps(job,ensure_ascii=False))
lines=gzip.open(root/'44089535561.log.gz','rt').read().splitlines()
hits=[i for i,s in enumerate(lines) if re.search(r'##\[error\]|✖|not ok\s+\d|AssertionError|ERR_ASSERTION|test failed|failures:|\bfail [1-9]',s)]
selected=set()
for i in hits:selected.update(range(max(0,i-5),min(len(lines),i+22)))
print('ACTUAL ERROR HITS',len(hits),'CONTEXT LINES',len(selected),'TOTAL',len(lines))
for i in sorted(selected):print(f'{i+1}: {lines[i]}')
