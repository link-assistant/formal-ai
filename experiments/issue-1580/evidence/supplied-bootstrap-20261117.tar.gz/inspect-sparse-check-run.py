from pathlib import Path
import json,subprocess
base=Path('experiments/issue-1580/evidence/checks/fast-source-archive-checkout')
p=base/'sparse-source-commands.json'
if p.exists():
 v=json.loads(p.read_text());print(json.dumps({k:v for k,v in v.items() if k!='commands'},indent=2));print('FAILURES',json.dumps([r for r in v['commands'] if r['exitCode']]))
else:print('No final receipt exists.')
print('TEMPORARY COPIES',[str(p) for p in Path('/tmp/issue-1580-research').glob('sparse-fast-source-*')])
run=subprocess.run(['ps','-eo','pid,ppid,comm'],capture_output=True,text=True)
print('RUNNING RELEVANT PROCESSES')
for line in run.stdout.splitlines():
 if any(word in line for word in ['python','node','git','cargo','rustc']):print(line)
