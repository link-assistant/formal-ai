import json
import pathlib
import re

directory = pathlib.Path("experiments/issue-1580/evidence/checks/main-merge-512ce428")
result = directory / "all-local-gates.json"
if result.exists():
    print(result.read_text())
else:
    path = directory / "all-local-gates.log"
    lines = path.read_text(errors="replace").splitlines() if path.exists() else []
    completed = [line for line in lines if re.match(r"^(?:PASS|SKIP|FAIL) ", line)]
    print(json.dumps({"completed": len(completed), "failures": [line for line in completed if line.startswith("FAIL ")]}))
    print("\n".join(lines[-10:]))
