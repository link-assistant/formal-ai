from pathlib import Path
import gzip,json
pr=json.loads(gzip.decompress(Path('/tmp/issue-1580-research/header-round-preflight/feedback-pull-request.json.gz').read_bytes()))
print('PR BODY\n'+pr['body'])
for name in ['experiments/issue-1580/work-plan.md','experiments/issue-1580/upstream/python-release-formatting-report.md','experiments/issue-1580/evidence/checks/generated-header-memory/memory-README.md']:
 p=Path(name);lines=p.read_text().splitlines();print('\nFILE',name,'LINES',len(lines))
 if len(lines)>1500:raise RuntimeError('chunk required')
 print('\n'.join(f'{i}: {s}' for i,s in enumerate(lines,1)))
