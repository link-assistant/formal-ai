set -eu
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-go-result-integrity.test.mjs > /tmp/issue-1580-research/template-go-result-integrity.log 2>&1
cat /tmp/issue-1580-research/template-go-result-integrity.log
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-inventory-integrity.test.mjs > /tmp/issue-1580-research/template-inventory-integrity.log 2>&1
cat /tmp/issue-1580-research/template-inventory-integrity.log
node experiments/issue-1580/compare-template-trees.mjs > /tmp/issue-1580-research/template-regeneration.log 2>&1
cat /tmp/issue-1580-research/template-regeneration.log
