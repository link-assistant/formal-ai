from pathlib import Path
import subprocess,hashlib,gzip,json,shutil
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'rust/tests/web/picomatch-security-backport.test.mjs'
s=p.read_text()
old=r"const pattern = '+(a\\\\*)';"
new=r"const pattern = '+(a\\*)';"
assert old in s
p.write_text(s.replace(old,new))
e=r/'experiments/issue-1580/evidence/checks/picomatch-single-branch'
for suffix in ['json','log.gz']:shutil.copy2(e/('option-before.'+suffix),e/('option-initial-fixture.'+suffix))
log=Path('/tmp/issue-1580-research/picomatch-option-before.log')
with log.open('w') as out:
 cp=subprocess.run(['timeout','600','node','--max-old-space-size=96','--test','--test-concurrency=1',str(p)],cwd=r,stdout=out,stderr=subprocess.STDOUT)
raw=log.read_bytes()
with gzip.open(e/'option-before.log.gz','wb') as out:out.write(raw)
(e/'option-before.json').write_text(json.dumps({'exitCode':cp.returncode,'rawSha256':hashlib.sha256(raw).hexdigest(),'autonomousAuthorshipCredit':0},indent=2)+'\n')
print(raw.decode())
