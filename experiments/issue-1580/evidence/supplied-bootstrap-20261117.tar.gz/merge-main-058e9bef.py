from pathlib import Path
import hashlib,json,shutil,subprocess
scratch=Path('/tmp/issue-1580-research')
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
assert not subprocess.check_output(['git','status','--porcelain'])
assert subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()=='058e9bef1214f2f1bc25971243cb787703ed64f1'
baseline=Path('experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8')
target=scratch/'merge-058e9bef-before.v8';assert not target.exists();shutil.copyfile(baseline,target)
print('BASELINE BEFORE',hashlib.sha256(target.read_bytes()).hexdigest())
log=scratch/'merge-main-058e9bef.log'
with log.open('wb') as out:r=subprocess.run(['git','merge','--no-edit','origin/main'],stdout=out,stderr=subprocess.STDOUT)
print('MERGE EXIT',r.returncode,'LOG',str(log))
print('\n'.join(log.read_text().splitlines()[:12]))
print('UNMERGED',subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],text=True))
print('STATUS',subprocess.check_output(['git','status','--short','--untracked-files=no'],text=True))
