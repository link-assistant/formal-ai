import gzip,json,subprocess
from pathlib import Path
root=Path('experiments/issue-1580/evidence/checks/main-merge-826289fc')
for row in json.loads((root/'client-final-focused-tests.json').read_text())['rows']:
    assert row['exitCode']==0
    p=root/(Path(row['file']).name.removesuffix('.test.mjs')+'-client-final-batch.log.gz')
    print(p.name);print(gzip.decompress(p.read_bytes()).decode())
for name in ['archive-round-bootstrap.py','archive-evidence.py']:
    result=subprocess.run(['python3','/tmp/issue-1580-research/'+name],text=True,capture_output=True,check=True)
    print(result.stdout)
files=['data/benchmarks/fast-pull-request-javascript-tests.json','data/meta/main-only-regressions.lino','data/meta/request-context.json','data/parity/issue-1587-request-context.json','data/parity/issue-1580-opencode-read-envelope.json','js/agentic/file_read/source.mjs','js/agentic/tool_result.mjs','js/server/request-context.mjs','rust/embedded/data/meta/request-context.json','rust/src/agentic_coding/file_read/source.rs','rust/src/agentic_coding/tool_result/source_observation.rs','rust/src/protocol/request_context.rs','rust/tests/web/source-read-provenance.test.mjs','rust/tests/web/issue-1580-client-output-constraints.test.mjs','ts/agentic/file_read/source.mts','ts/agentic/tool_result.mts','ts/server/request-context.mts','experiments/issue-1580/work-plan.md','experiments/issue-1580/evidence']
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--',*files],check=True)
subprocess.run(['git','commit','-m','Fix live client output constraints and path-bound Read rendering'],check=True)
print(subprocess.check_output(['git','status','--short'],text=True))
