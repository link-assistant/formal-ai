set -eu
git status --short
git branch --show-current
cat CONTRIBUTING.md
cat /tmp/issue-1580-research/go-manual-release-report.md
cat /tmp/issue-1580-research/go-change-detection-report.md
tail -n 8 /tmp/issue-1580-research/all-local-gates-fifth.log
git diff --stat
