from pathlib import Path
import gzip,json,subprocess

for name in ['experiments/issue-1580/template-python-fragment-integrity.test.mjs','experiments/issue-1580/fixtures/python-template/scripts/create_manual_changeset.py','rust/tests/web/issue-1580-template-observations.test.mjs']:
    print('FILE',name)
    for number,line in enumerate(Path(name).read_text().splitlines(),1):
        print(f'{number}: {line}')
print('WORKFLOW MATCHES')
result=subprocess.run(['rg','-n','js tier|js-tier|suite_group|suite-group|setup-python|python-version','--glob','*.yml','.github/workflows'],capture_output=True,text=True,check=True)
print(result.stdout)
raw=gzip.decompress(Path('experiments/issue-1580/evidence/ci/624812120/44104975691.log.gz').read_bytes()).decode().splitlines()
print('HOSTED LOG LINES 4865-4910')
for number in range(4865,4911):
    print(f'{number}: {raw[number-1]}')
