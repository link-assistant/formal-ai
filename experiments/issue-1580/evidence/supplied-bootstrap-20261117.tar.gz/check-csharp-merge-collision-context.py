from pathlib import Path
import json,re,subprocess
for name in ['issues.json','pulls.json']:
    data=json.loads((Path('/tmp/issue-1580-research/csharp-layout-context')/name).read_text())
    if isinstance(data,dict):
        print('TOP KEYS',name,list(data))
        continue
    print('ITEMS',name,len(data))
    for row in data:
        content=str(row.get('title',''))+'\n'+str(row.get('body',''))
        if re.search(r'collisi|merged-.*\.md|random|changeset.*loss|loss.*changeset|overwrite',content,re.I):
            print(json.dumps({k:row.get(k) for k in ['number','title','html_url','url','state','body']},indent=2))
print(subprocess.check_output(['rg','--files','scripts'],text=True).splitlines()[:0])
print(subprocess.check_output(['rg','--files','scripts'],text=True).strip().split('\n')[-1:])
p=Path('/tmp/issue-1580-research/templates/csharp-complete/scripts/print-untrusted.mjs')
print('SOURCE',p)
print(p.read_text())
