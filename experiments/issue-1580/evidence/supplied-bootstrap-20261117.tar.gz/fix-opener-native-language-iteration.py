from pathlib import Path
p = Path('/tmp/gh-issue-solver-1794900398048/rust/tests/source/unknown_opener_language_tests.rs')
text = p.read_text()
assert text.count('super::language_aware_unknown_answer("", *language)') == 1
p.write_text(text.replace('super::language_aware_unknown_answer("", *language)', 'super::language_aware_unknown_answer("", language)'))
print('Use the owned Language yielded by registered_languages() -> Vec<Language>.')
