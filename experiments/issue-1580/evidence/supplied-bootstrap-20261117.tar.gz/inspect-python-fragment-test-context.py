from pathlib import Path
import shutil
import sys

print('Python runtime:', sys.version)
for command in ['python3.15', 'python3.14', 'python3', 'uv', 'rust-script']:
    print(command, shutil.which(command))
for name in ['experiments/issue-1580/template-csharp-changeset-integrity.test.mjs', 'rust/tests/web/template-ci-correctness.test.mjs', 'scripts/create-changelog-fragment.rs']:
    path = Path(name)
    print('\nFILE', name, 'exists', path.exists())
    if path.exists():
        lines = path.read_text().splitlines()
        print('TOTAL LINES', len(lines))
        for number, line in enumerate(lines[:350], 1):
            print(f'{number}: {line}')
