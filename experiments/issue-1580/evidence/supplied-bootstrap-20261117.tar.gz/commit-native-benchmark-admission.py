from pathlib import Path
import hashlib,json,subprocess
r=Path.cwd();base=Path('experiments/issue-1580/evidence/checks/native-benchmark-admission-validation');d=json.loads((base/'review.json').read_text());assert d['complete'] and d['focusedJavaScriptPassed']==46 and d['gateCounts']=={'PASS':9,'FAIL':0}
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
assert git('branch','--show-current')=='issue-1580-8d61a32a61e1';assert git('rev-parse','HEAD')=='1388db5502f71d0f2bcf522da01ef8fdb8a6ef89';assert not git('diff','--cached','--name-only')
for p,h in d['sourceHashes'].items():assert hashlib.sha256((r/p).read_bytes()).hexdigest()==h,p
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--',*d['sourceHashes']],check=True);assert set(git('diff','--cached','--name-only').splitlines())==set(d['sourceHashes'])
subprocess.run(['git','commit','-m','Replay benchmark derivations in the focused native lane'],check=True)
print(json.dumps({'sourceHead':git('rev-parse','HEAD'),'sourceFiles':list(d['sourceHashes']),'nativeExecuted':False,'fullIssueComplete':False}))
