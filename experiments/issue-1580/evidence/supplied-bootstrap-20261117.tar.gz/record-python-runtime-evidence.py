from pathlib import Path
import json,gzip,hashlib,subprocess
directory=Path('experiments/issue-1580/evidence/checks/python-runtime-provisioning')
records=[]
for path in sorted(directory.iterdir()):
 if path.name.endswith('.log.gz'):
  raw=gzip.decompress(path.read_bytes());records.append({'path':str(path),'bytes':len(raw),'lines':len(raw.splitlines()),'uncompressedSha256':hashlib.sha256(raw).hexdigest(),'compressedSha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 elif path.name.endswith('.log'):
  raw=path.read_bytes();records.append({'path':str(path),'bytes':len(raw),'lines':len(raw.splitlines()),'sha256':hashlib.sha256(raw).hexdigest()})
manifest=json.loads(Path('/tmp/issue-1580-research/python-versions-manifest.json').read_text())
version=next(item for item in manifest if item['version']=='3.15.2')
asset=next(item for item in version['files'] if item.get('platform')=='linux' and item.get('platform_version')=='24.04' and item.get('arch')=='x64' and not item.get('freethreaded',False))
evidence={
 'hostedBefore':{'head':'624812120feee0180bf9df8164f87e73326b5cb8','run':44104975691,'allWorkflowsPassed':24,'skippedPythonCases':5,'fullLogLines':[4877,4893,4894,4895,4896],'fullLogSha256':'64832534932cf4b4d1007bbd5c1c1465d2ffb031b2b8a7320d016bb5d8aff5e4'},
 'runtime':{'upstreamPin':'3.15.2','minimumSyntaxVersion':'3.14','officialManifest':'https://github.com/actions/python-versions/blob/main/versions-manifest.json','manifestSha256':hashlib.sha256(Path('/tmp/issue-1580-research/python-versions-manifest.json').read_bytes()).hexdigest(),'stable':version['stable'],'linuxUbuntu2404Asset':asset},
 'regressionBefore':{'exitCode':1,'reason':'Hosted missing runtime incorrectly returned success with four skips.','log':'before.log.gz'},
 'localAfter':{'maintainedTests':31,'failed':0,'skipped':0,'fastProfileTests':15,'defaultBranchPolicyTests':21},
 'limits':{'childNodeHeapMiB':64,'childWallMilliseconds':10000,'testWallMilliseconds':30000,'shellPlans':4},
 'retainedFailures':['initial harness inherited NODE_TEST_CONTEXT and suppressed child TAP; the corrected regression reproduces the actual skip bug','draft policy assertions still pointed at the old run step; both now inspect the actual planning step','existing VM evaluation exceeded its unchanged 100 ms bound once; unchanged retry passed','combined check command exceeded the Formal AI shell 60-second budget; no result from its orphaned child is counted; final focused checks ran separately','local shell lint requires absent shellcheck; no shell scripts changed, and hosted lint remains required'],
 'upstreamSourceChanged':False,'defaultBranchBuildPolicyChanged':False,'benchmarkFloorsChanged':False,'issueComplete':False,'autonomousAuthorshipCredit':0,'logs':records,
}
(directory/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(directory/'README.md').write_text('''# Python runtime observations\n\nHead `624812120` passed 24 hosted workflows but skipped five Python cases because the runner runtime could not parse the unchanged upstream syntax. This is a coverage defect, not hosted Python acceptance. Full prior hosted logs are under `evidence/ci/624812120/`.\n\nThe regression fails before the fix when hosted execution succeeds with four skips. Runtime provisioning now follows the actual longest-first shard selection, pins the upstream Python 3.15.2 interpreter only on the owning shard, and reuses the selected test file for execution. Missing or old Python fails on GitHub Actions; optional local skips remain available. Tests execute both owning and non-owning branches for the two- and eight-shard profiles, with finite child/test budgets.\n\nThe final maintained local entrypoint passes 31 tests without skips. Fast profile and default-branch policy checks pass. A focused checkout check and final staged file gates are recorded separately. The preserved draft failures, reporter-context correction, single unchanged VM-timeout retry, and shell-tool limitation are indexed in `evidence.json`. No timeout, benchmark floor, native-build policy, pinned fixture source or upstream implementation was relaxed. Hosted verification of the new head remains required; broader issue acceptance remains unfinished.\n''')
print(json.dumps({'logs':len(records),'runtimeAsset':asset,'maintainedLocalTests':31},indent=2))
name='scripts/run-ordered-javascript-tests.mjs';lines=Path(name).read_text().splitlines();print(name,len(lines),'lines')
for i,line in enumerate(lines[:160],1):print(f'{i}: {line}')
print(subprocess.run(['rg','-n','python-partial|activeReadLines','experiments/issue-1580/template-inventory-integrity.test.mjs','experiments/issue-1580/template-reference-graph.test.mjs'],capture_output=True,text=True).stdout)
