from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
root=Path('experiments/issue-1580/evidence/ci/main-015a6831')
details=json.loads(gzip.decompress((root/'layered-metadata.json.gz').read_bytes()))
assert details['databaseId']==44188508228
jobs=[job for job in details['jobs'] if job['conclusion']=='failure']
base=root/'individual-failed-jobs';base.mkdir(exist_ok=False)
receipts=[]
for job in jobs:
    identifier=job['databaseId']
    cmd=['gh','run','view','--repo','link-assistant/formal-ai','--job',str(identifier),'--log']
    run=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    filename=f'job-{identifier}.log.gz'
    (base/filename).write_bytes(gzip.compress(run.stdout,mtime=0))
    row={'job_id':identifier,'name':job['name'],'conclusion':job['conclusion'],'command':cmd,
        'exit_code':run.returncode,'sha256':hashlib.sha256(run.stdout).hexdigest(),
        'bytes':len(run.stdout),'lines':len(run.stdout.splitlines()),'log':filename,
        'failed_steps':[step['name'] for step in job['steps'] if step['conclusion']=='failure']}
    receipts.append(row)
    print(json.dumps(row),flush=True)
(base/'receipt.json').write_text(json.dumps({'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_head':details['headSha'],'run_id':44188508228,'downloads':receipts,
    'full_manual_review':False,'independent_authorship_credit':0},indent=2)+'\n')
