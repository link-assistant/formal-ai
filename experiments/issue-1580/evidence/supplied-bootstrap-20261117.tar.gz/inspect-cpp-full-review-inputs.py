from pathlib import Path
import json, subprocess

for path in sorted(Path('/tmp/issue-1580-research/templates').iterdir()):
    if 'cpp' in path.name: print('LOCAL',path)
value=json.loads(Path('docs/case-studies/issue-1580/templates/sources.json').read_text())
print('SOURCE_TYPE',type(value).__name__)
if isinstance(value,list):
    for row in value:
        if 'cpp' in str(row): print(json.dumps(row))
else:
    for key,row in value.items():
        if 'cpp' in str(row): print(key,json.dumps(row)[:4000])
path=Path('docs/case-studies/issue-1580/templates/cpp-files.tsv')
lines=path.read_text().splitlines()
print('INVENTORY_ROWS',len(lines))
print('\n'.join(lines[:8]))
for path in sorted(Path('/tmp/issue-1580-research').glob('*cpp*')):
    if path.suffix in ['.py','.json']:print('CPP_TOOL',path.name,path.stat().st_size)
log=Path('/tmp/issue-1580-research/governed-refresh-all-local-gates.log')
print('GATE_PROGRESS','\n'.join(log.read_text().splitlines()[-5:]))
