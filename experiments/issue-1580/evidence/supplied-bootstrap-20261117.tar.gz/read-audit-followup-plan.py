from pathlib import Path
import subprocess

path = Path('experiments/issue-1580/work-plan.md')
lines = path.read_text().splitlines()
print(f'FILE {path}, {len(lines)} lines; first 130:')
print('\n'.join(f'{number}: {line}' for number, line in enumerate(lines[:130], 1)))
print('CHECKPOINT AND REPORT REFERENCES')
result = subprocess.run(['rg', '-n', '--max-count', '3', '131|8,864|drafted, not|not yet filed|audit inventory', 'docs/case-studies/issue-1580', 'experiments/issue-1580/work-plan.md', 'experiments/issue-1580/evidence/README.md'], capture_output=True, text=True)
rows = result.stdout.splitlines()
print('\n'.join(line[:1000] for line in rows[:40]))
print(f'{len(rows)} total hits')
