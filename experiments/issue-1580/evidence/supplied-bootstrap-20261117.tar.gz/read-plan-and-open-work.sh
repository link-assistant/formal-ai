set -eu
rg --files --hidden -g AGENTS.md -g '!node_modules' -g '!.git' .
cat experiments/issue-1580/work-plan.md
cat /tmp/issue-1580-research/pr-body.md
sed -n '1,260p' docs/case-studies/issue-1580/templates/README.md
rg -n 'check_file_size|readability|fast-pr' scripts/ci-gates.mjs experiments/formal_ai_subagent/local-gates.mjs
