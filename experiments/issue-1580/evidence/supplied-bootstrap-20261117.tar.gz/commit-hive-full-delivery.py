from pathlib import Path
import subprocess,json,hashlib,gzip,re
root=Path.cwd();base=root/'experiments/issue-1580/evidence/checks/hive-full-delivery-validation';r=json.loads((base/'result.json').read_text());assert r['complete']and r['javascriptPassed']==56 and r['existingNativeTestsAdded']==5 and r['toolchainPrerequisiteAssertionsAdded']==1
for name,digest in r['sourceHashes'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for row in r['results']:
 z=(base/row['file']).read_bytes();assert hashlib.sha256(z).hexdigest()==row['archiveSha256']and hashlib.sha256(gzip.decompress(z)).hexdigest()==row['rawSha256'];assert row['exitCode']==0
 if row['name']in ['policy','focused-map','affected-gates']:print(row['name'],gzip.decompress(z).decode()[-800:])
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1';subprocess.run(['git','add','--',*r['sourceHashes']],check=True);subprocess.run(['git','diff','--cached','--check'],check=True);subprocess.run(['git','-c','gc.auto=0','commit','-m','Replay real Git Hive delivery and require its toolchains'],check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();(base/'source-commit.json').write_text(json.dumps({'sourceCommit':head,'published':False,'nativeExecuted':False,'fullIssueComplete':False,'independentAuthorshipCredit':0},indent=2)+'\n');print(head)
