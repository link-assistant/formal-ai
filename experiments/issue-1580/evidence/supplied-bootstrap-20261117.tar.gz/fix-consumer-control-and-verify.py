from pathlib import Path
import subprocess,json,gzip,hashlib,os,time,shutil
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'experiments/issue-1580/picomatch-consumer-probe.mjs'
s=p.read_text()
s=s.replace("const workspace = mkdtempSync", "const baseline = process.argv[2];\nconst workspace = mkdtempSync")
s=s.replace("picomatch:'file:' + join(root, 'packages/picomatch-compat'),","picomatch:'file:' + (baseline || join(root, 'packages/picomatch-compat')),")
s=s.replace("  assert.equal(mm.isMatch('aaaa', '+(*a)'), false);","  if (!baseline) assert.equal(mm.isMatch('aaaa', '+(*a)'), false);")
s=s.replace("['a.js', 'vendor/a.js']);","['.hidden.js', 'a.js', 'vendor/a.js']);")
s=s.replace("  assert.equal(pm.isMatch('[aaa', '+([[]*a)'), false);","  if (!baseline) assert.equal(pm.isMatch('[aaa', '+([[]*a)'), false);")
s=s.replace("assert.equal(entries[0][1].name, '@formal-ai/picomatch-compat');","if (!baseline) assert.equal(entries[0][1].name, '@formal-ai/picomatch-compat');")
s=s.replace("passed:true, assertions:17, consumers:","passed:true, mode:baseline ? 'upstream-control' : 'local-backport', consumers:")
p.write_text(s)
e=r/'experiments/issue-1580/evidence/checks/picomatch-single-branch'
shutil.copy2(e/'consumers.log.gz',e/'consumers-initial-failure.log.gz')
results=json.loads((e/'consumer-audit-checks.json').read_text())
results[0]['name']='consumers-initial-failure'
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=256'
for name,extra in [('consumers-baseline',['/tmp/issue-1580-research/picomatch/package']),('consumers',[])]:
 args=['node','--max-old-space-size=96','experiments/issue-1580/picomatch-consumer-probe.mjs']+extra
 log=Path('/tmp/issue-1580-research')/('picomatch-'+name+'.log')
 start=time.monotonic()
 with log.open('w') as out:cp=subprocess.run(args,cwd=r,stdout=out,stderr=subprocess.STDOUT,env=env)
 raw=log.read_bytes()
 with gzip.open(e/(name+'.log.gz'),'wb') as out:out.write(raw)
 results.append({'name':name,'command':args,'exitCode':cp.returncode,'seconds':round(time.monotonic()-start,3),'rawSha256':hashlib.sha256(raw).hexdigest()})
 print(name,'exit',cp.returncode)
 print(raw.decode())
 if cp.returncode:break
(e/'consumer-audit-checks.json').write_text(json.dumps(results,indent=2)+'\n')
