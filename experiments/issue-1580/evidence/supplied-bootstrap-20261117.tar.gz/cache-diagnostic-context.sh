set -eu
cat scripts/check-sccache-write-health.sh
rg -n 'check-sccache-write-health|SCCACHE_ERROR_LOG|FORMAL_AI_CI_VERBOSE' .github/workflows .github/actions rust/tests/web/sccache-outage-fallback.test.mjs
sed -n '1,260p' rust/tests/web/sccache-outage-fallback.test.mjs
