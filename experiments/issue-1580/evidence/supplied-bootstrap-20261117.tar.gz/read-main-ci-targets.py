import gzip
import pathlib
import re
import subprocess

directory = pathlib.Path("experiments/issue-1580/evidence/ci/main-512ce428")
sections = [("44117975432", 17050, 230), ("44117975432", 17930, 85), ("44117974304", 31690, 88), ("44117974304", 28565, 25)]
for run, start, amount in sections:
    print("LOG", run, "LINES", start, start + amount - 1)
    with gzip.open(directory / (run + ".log.gz"), "rt") as source:
        for number, raw in enumerate(source, 1):
            if number < start:
                continue
            if number >= start + amount:
                break
            text = raw.rstrip().split("\t", 2)[-1]
            text = re.sub(r"^\d{4}-\d\d-\d\dT\S+\s", "", text)
            print(str(number) + ": " + text)
print("CURRENT SOURCE LOCATIONS")
subprocess.run(["rg", "-n", "--glob", "*test*", "a separately supported explicit stdout|a long display placeholder|a direct structured issue record|prepared pull request metadata decodes|original operations and authority remain|a question over a quoted passage", "rust", "experiments"], check=True)
