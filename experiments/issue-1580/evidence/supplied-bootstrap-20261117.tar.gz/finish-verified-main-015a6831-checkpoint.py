from pathlib import Path
import gzip,hashlib,json,os,subprocess
base=Path('experiments/issue-1580/evidence/checks/main-merge-015a6831/final-documentation')
metadata=Path('experiments/issue-1580/evidence/ci/checkpoint-584b5f57-prepush')
renames={'pr-comments.json.gz':'pull-request-comments.json.gz','pr.json.gz':'pull-request.json.gz'}
rows=[]
for before,after in renames.items():
    old=metadata/before;new=metadata/after;raw=old.read_bytes();old.rename(new)
    assert new.read_bytes()==raw
    rows.append({'from':before,'to':after,'compressedSha256':hashlib.sha256(raw).hexdigest(),'rawSha256':hashlib.sha256(gzip.decompress(raw)).hexdigest()})
receipt=json.loads((metadata/'receipt.json').read_text())
for row in receipt['commands']:
    before=row['label']+'.json.gz';row['archive']=renames.get(before,before)
(metadata/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(base/'archive-filename-correction.json').write_text(json.dumps({'renames':rows,'ratchetChanged':False,'independentAuthorshipCredit':0},indent=2)+'\n')
note='\nThe final documentation/evidence check initially catches two abbreviated GitHub archive names (`pr.json.gz` and `pr-comments.json.gz`). Rename only those files to full words, verify identical compressed/raw hashes, and retain the failed aggregate/list before rechecking. The 90-filename ceiling remains unchanged.\n'
p=Path('experiments/issue-1580/work-plan.md');p.write_text(p.read_text()+note)
subprocess.run(['python3','/tmp/issue-1580-research/archive-round-bootstrap.py'],check=True)
subprocess.run(['python3','/tmp/issue-1580-research/archive-evidence.py'],check=True)
command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size-js-twin,check-file-size']
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
result=subprocess.run(command,env=env,capture_output=True);raw=result.stdout+result.stderr
(base/'corrected-documentation-gates.log.gz').write_bytes(gzip.compress(raw,mtime=0))
(base/'corrected-documentation-gates.json').write_text(json.dumps({'command':command,'exitCode':result.returncode,'rawSha256':hashlib.sha256(raw).hexdigest(),'rawBytes':len(raw),'nativeExecuted':False,'independentAuthorshipCredit':0},indent=2)+'\n')
print(raw.decode());assert result.returncode==0
for name in ['check-abbreviations','check-file-size-js-twin','check-file-size']:
    raw=Path('experiments/formal_ai_subagent/sandboxes/gates',name+'.log').read_bytes()
    (base/(name+'.log.gz')).write_bytes(gzip.compress(raw,mtime=0))
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--','docs/case-studies/issue-1580','experiments/issue-1580'],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
with Path('/tmp/issue-1580-research/verified-main-015a6831-evidence-commit.log').open('w') as stream:
    subprocess.run(['git','commit','--quiet','-m','Record merged-source validation and historical compatibility review'],stdout=stream,stderr=subprocess.STDOUT,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
status=subprocess.check_output(['git','status','--short'],text=True)
print(json.dumps({'committedHead':head,'status':status,'pushed':False}))
assert not status.strip()
