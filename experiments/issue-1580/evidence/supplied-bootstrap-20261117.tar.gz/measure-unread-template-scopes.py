from pathlib import Path
import json

base=Path('/tmp/issue-1580-research/templates')
for language in ['js','cpp','php','rust','java','csharp','python']:
    root=base/(language+'-complete')
    if not root.exists():continue
    total=0;active=0;history=0;files=0;binary=0;active_files=0
    for path in sorted(root.rglob('*')):
        if not path.is_file():continue
        raw=path.read_bytes();total+=len(raw);files+=1
        try:lines=len(raw.decode('utf-8').splitlines())
        except UnicodeDecodeError:binary+=1;continue
        relative=path.relative_to(root).as_posix()
        if relative.startswith(('dev/log/','dev/experiments/','.git/')):history+=lines
        else:active+=lines;active_files+=1
    print(json.dumps({'language':language,'files':files,'bytes':total,'activeFiles':active_files,'activeLines':active,'historicalLines':history,'binaryFiles':binary}))
path=Path('/tmp/issue-1580-research/governed-refresh-all-local-gates.log')
print('GATE_PROGRESS','\n'.join(path.read_text().splitlines()[-5:]))
