from pathlib import Path
import gzip,json,subprocess
raw=subprocess.check_output(['gh','run','view','44262999525','--repo','link-assistant/formal-ai','--json','headSha,status,conclusion,jobs'])
data=json.loads(raw)
assert data['headSha']=='9095abcbcccdd5518ce2c9318d3ebc6eb8914fc8'
base=Path('experiments/issue-1580/evidence/ci/executor-status-9095abcb')
(base/'native-job-latest.json.gz').write_bytes(gzip.compress(raw,mtime=0))
print(json.dumps({'status':data['status'],'conclusion':data['conclusion'],'jobs':[{'id':row['databaseId'],'name':row['name'],'status':row['status'],'conclusion':row['conclusion'],'steps':[{'name':step['name'],'status':step['status'],'conclusion':step['conclusion']} for step in row['steps'] if step['status']!='completed' or step['conclusion']=='failure']} for row in data['jobs'] if row['status']!='completed' or row['conclusion']=='failure']},indent=2))
