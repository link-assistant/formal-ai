from pathlib import Path
import base64,datetime,gzip,hashlib,json,re,subprocess
repository='link-foundation/python-ai-driven-development-pipeline-template'
directory=Path('experiments/issue-1580/evidence/checks/python-release-formatting/publication');directory.mkdir(exist_ok=True)
def api(path):
 return subprocess.check_output(['gh','api',path,'--paginate'],text=True)
head=json.loads(api('repos/'+repository+'/git/ref/heads/main'))['object']['sha']
assert head=='c532c173801dfb12e681b0730c4abbf93aefd0ca',head
sources=[]
for name in ['format_release_notes.py','release_naming.py']:
 payload=json.loads(api('repos/'+repository+'/contents/scripts/'+name+'?ref='+head))
 data=base64.b64decode(payload['content'])
 local=Path('experiments/issue-1580/fixtures/python-template/scripts')/name
 assert data==local.read_bytes()
 sources.append({'path':'scripts/'+name,'gitBlob':payload['sha'],'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
raw=subprocess.check_output(['gh','api','repos/'+repository+'/issues?state=all&per_page=100','--paginate','--slurp'],text=True).encode()
pages=json.loads(raw);rows=[row for page in pages for row in page]
(directory/'duplicate-issues.json.gz').write_bytes(gzip.compress(raw,mtime=0))
old=json.loads(gzip.decompress(Path('experiments/issue-1580/evidence/checks/python-release-formatting/duplicate-issues.json.gz').read_bytes()))
if old and isinstance(old[0],list):old=[row for page in old for row in page]
previous={row['id']:row for row in old}
new=[row for row in rows if row['id'] not in previous or row.get('body')!=previous[row['id']].get('body')]
for row in new:
 (directory/('changed-'+str(row['number'])+'.json')).write_text(json.dumps(row,indent=2)+'\n')
matches=[{'number':r['number'],'title':r['title'],'url':r['html_url']} for r in rows if re.search(r'escape|backslash|literal|format.{0,30}release|release.{0,30}format',r['title']+'\n'+(r.get('body') or ''),re.I)]
published='da712fadd3f680668c063a6d7de073ef1d52573b'
for path in ['experiments/issue-1580/template-python-release-formatting.test.mjs','experiments/issue-1580/fixtures/python-template/scripts/format_release_notes.py','experiments/issue-1580/evidence/checks/python-release-formatting/maintained-after.json']:
 remote=json.loads(api('repos/link-assistant/formal-ai/contents/'+path+'?ref='+published))
 data=base64.b64decode(remote['content'])
 local=subprocess.check_output(['git','show',published+':'+path])
 assert data==local
report=Path('experiments/issue-1580/upstream/python-release-formatting-report.md')
draft=json.loads(Path('experiments/issue-1580/evidence/checks/python-release-formatting/report-draft.json').read_text())
assert hashlib.sha256(report.read_bytes()).hexdigest()==draft['reportBodySha256']=='bdd518a220ef48becb19dec2977bb279486d0118635468d5018a454cb149db99'
record={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':repository,'currentMain':head,'sources':sources,'issueAndPullCount':len(rows),'changedIds':[r['number'] for r in new],'keywordMatches':matches,'duplicateInventorySha256':hashlib.sha256(raw).hexdigest(),'publishedEvidenceCommit':published,'reportBodySha256':draft['reportBodySha256'],'filed':False,'upstreamRepairClaimed':False,'independentAuthorshipCredit':0}
(directory/'preflight.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
