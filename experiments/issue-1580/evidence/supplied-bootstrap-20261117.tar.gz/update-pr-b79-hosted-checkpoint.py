from pathlib import Path
import gzip
import hashlib
import json
import subprocess

def run(arguments):
    return subprocess.run(arguments, check=True, text=True, capture_output=True).stdout

repository = 'link-assistant/formal-ai'
head = 'b79dc1e0f147ed57d8e317c1b93bfa6ffc79078d'
directory = Path('experiments/issue-1580/evidence/ci/b79dc1e0f')
runs = json.loads((directory / 'runs.json').read_text())
assert len(runs) == 24
assert all(item['headSha'] == head and item['status'] == 'completed' and item['conclusion'] == 'success' for item in runs)
log = gzip.decompress((directory / '44098347020.log.gz').read_bytes())
assert hashlib.sha256(log).hexdigest() == '84bfed3018b9fdb422d207bc6809ee0dbe60bf25530d7b987defe3460953fbbd'
assert b'the repository holds the abbreviation ratchet' in log.splitlines()[7073]
pull_request = json.loads(run(['gh', 'pr', 'view', '1581', '--repo', repository, '--json', 'body,title,url,isDraft,headRefOid,headRefName']))
assert pull_request['headRefOid'] == head and pull_request['isDraft']
assert pull_request['headRefName'] == 'issue-1580-8d61a32a61e1'
old = 'Published head `b79dc1e0f1` is under verification.'
new = 'All 24 workflows on published head `b79dc1e0f1` completed successfully. The preserved successful [Layered CI run](https://github.com/link-assistant/formal-ai/actions/runs/44098347020) explicitly passes the abbreviation ratchet at full-log line 7074. These scope-gated pull-request checks do not verify the still-open main-only runtime, benchmark, publication, or live-identity criteria.'
body = pull_request['body']
assert old in body
body = body.replace(old, new)
assert body.startswith('Fixes #1580\n')
path = Path('/tmp/issue-1580-research/pr-b79-hosted-checkpoint-body.md')
path.write_text(body)
print(run(['gh', 'pr', 'edit', '1581', '--repo', repository, '--title', pull_request['title'], '--body-file', str(path)]))
after = json.loads(run(['gh', 'pr', 'view', '1581', '--repo', repository, '--json', 'body,title,url,isDraft,headRefOid']))
assert after['body'] == body and after['isDraft'] and after['headRefOid'] == head
Path('/tmp/issue-1580-research/pr-b79-hosted-checkpoint-after.json').write_text(json.dumps(after, indent=2) + '\n')
print(json.dumps({'url': after['url'], 'head': head, 'passingWorkflows': len(runs), 'draft': after['isDraft'], 'bodyVerified': True, 'acceptanceComplete': False}, indent=2))
