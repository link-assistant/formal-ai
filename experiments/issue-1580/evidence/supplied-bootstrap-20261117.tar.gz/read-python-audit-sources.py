from pathlib import Path
for name in ['experiments/issue-1580/template-python-fragment-integrity.test.mjs','experiments/issue-1580/template-shared-git-observation.test.mjs','/tmp/issue-1580-research/templates/python-complete/scripts/audit-npm-locks.sh','scripts/check-javascript-dependencies.sh']:
 p=Path(name); lines=p.read_text().splitlines();print('\nFILE',name,'LINES',len(lines))
 for n,line in enumerate(lines[:350],1):print(f'{n}: {line}')
