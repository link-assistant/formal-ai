from pathlib import Path
import gzip,hashlib,json,sys
base=Path('experiments/issue-1580/evidence/checks/main-merge-058e9bef')
status=json.loads(Path('/tmp/issue-1580-research/final-058e9bef-focused-status.json').read_text())
assert status['state']=='complete' and all(row['exitCode']==0 for row in status['rows'])
first=int(sys.argv[1]);last=int(sys.argv[2])
assert last-first<=5
for row in status['rows'][first:last]:
    raw=gzip.decompress((base/row['log']).read_bytes())
    assert hashlib.sha256(raw).hexdigest()==row['rawSha256']
    print(row['file'],raw.decode(),sep='\n')
print('Completed files',len(status['rows']))
