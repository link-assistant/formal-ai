import gzip
import hashlib
import json
import os
import pathlib
import resource
import subprocess
import time

root=pathlib.Path.cwd()
directory=root/"experiments/issue-1580/evidence/checks/generated-header-memory"
directory.mkdir(parents=True,exist_ok=True)
test=root/"rust/tests/web/generated-files.test.mjs"
source=test.read_text()
old="execFileSync('node', ['scripts/check-generated-files.mjs'], { cwd: REPO_ROOT, encoding: 'utf8' })"
new="execFileSync(process.execPath, ['--max-old-space-size=96', 'scripts/check-generated-files.mjs'], { cwd: REPO_ROOT, encoding: 'utf8', timeout: 30_000 })"
assert source.count(old)==1
test.write_text(source.replace(old,new))
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
command=["timeout","600","node","--max-old-space-size=96","--test","--test-concurrency=1",str(test.relative_to(root))]
started=time.time()
result=subprocess.run(command,capture_output=True,env=dict(os.environ,NODE_OPTIONS="--max-old-space-size=96"))
raw=result.stdout+result.stderr
(directory/"before.log.gz").write_bytes(gzip.compress(raw,mtime=0))
record={"command":command,"status":result.returncode,"durationSeconds":round(time.time()-started,3),"rawSha256":hashlib.sha256(raw).hexdigest(),"rawBytes":len(raw),"log":"before.log.gz","independentAuthorshipCredit":0}
(directory/"before.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record))
text=raw.decode(errors="replace")
assert result.returncode!=0
assert "heap out of memory" in text
assert "# fail 1" in text or "ℹ fail 1" in text
for line in text.splitlines():
    if any(token in line for token in ("heap out of memory","✔","✖","# pass","# fail","ℹ pass","ℹ fail")):
        print(line[:400])
