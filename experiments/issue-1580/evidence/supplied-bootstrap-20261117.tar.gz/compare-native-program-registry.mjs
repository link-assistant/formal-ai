import assert from 'node:assert/strict';
import fs from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
const base='experiments/issue-1580/evidence/checks/native-program-registry-refresh';
const beforeText=gunzipSync(fs.readFileSync(`${base}/before.mjs.gz`)).toString();
const afterText=fs.readFileSync('scripts/lib/generated-native-programs.mjs','utf8');
const read=async text=>(await import(`data:text/javascript;base64,${Buffer.from(text).toString('base64')}`)).GENERATED_NATIVE_PROGRAMS;
const before=await read(beforeText), after=await read(afterText);
assert.equal(before.length,after.length);
const changes=[];let visited=0;
function compare(left,right,path='') {
  visited++;
  if(left&&right&&typeof left==='object'&&typeof right==='object') {
    assert.deepEqual(Object.keys(left),Object.keys(right),path);
    for(const key of Object.keys(left))compare(left[key],right[key],`${path}/${key}`);
  } else if(left!==right) changes.push({path,before:left,after:right});
}
compare(before,after);
assert.ok(changes.length>0);
const hashes=changes.filter(change=>/\/sourceWitnesses\/\d+\/sha256$/.test(change.path));
const spans=changes.filter(change=>/\/sourceSpan\/(start|end)$/.test(change.path));
assert.equal(changes.length,hashes.length+spans.length);
assert.equal(hashes.length,16);
assert.equal(spans.length,2);
for(const change of hashes){
  const [,index,,witness]=change.path.split('/');
  const source=after[Number(index)].sourceWitnesses[Number(witness)];
  assert.match(change.before,/^[a-f0-9]{64}$/);
  assert.equal(change.after,createHash('sha256').update(fs.readFileSync(source.path)).digest('hex'));
}
for(const change of spans){
  const index=Number(change.path.split('/')[1]);
  assert.equal(after[index].path,'formal_ai::memory_sync::LEARNED_CHUNK_KIND');
  assert.equal(change.after-change.before,127);
  const program=after[index];
  const source=fs.readFileSync(program.sourceWitnesses[0].path,'utf8');
  assert.match(source.slice(program.sourceSpan.start,program.sourceSpan.end),/const LEARNED_CHUNK_KIND: &str = "meta_learned_chunk"/);
}
const executable=programs=>programs.map(({sourceSpan,sourceWitnesses,...program})=>program);
assert.deepEqual(executable(before),executable(after));
const receipt={programs:before.length,visited,changes,sourceHashChanges:hashes.length,sourceSpanChanges:spans.length,executableChanges:0};
fs.writeFileSync(`${base}/comparison.json`,JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt,null,2));
