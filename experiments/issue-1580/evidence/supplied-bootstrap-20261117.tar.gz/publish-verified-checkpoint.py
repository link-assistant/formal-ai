from pathlib import Path
import datetime,gzip,hashlib,json,os,subprocess
branch='issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()==branch
assert not subprocess.check_output(['git','status','--porcelain'])
base=Path('/tmp/issue-1580-research')
for state in ['in_progress','queued']:
    raw=subprocess.check_output(['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--status',state,'--json','databaseId,workflowName,headSha'])
    assert not json.loads(raw),(state,raw.decode())
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
for gate in ['check-abbreviations','check-file-size','check-file-size-js-twin']:
    path=base/('checkpoint-'+gate+'.log')
    with path.open('wb') as out:
        result=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate],env=env,stdout=out,stderr=subprocess.STDOUT)
    print(gate,'EXIT',result.returncode,'LOG',str(path));assert result.returncode==0,path.read_text()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='7780c70715df515a8ffcb085bff0902b4489bb94'
assert not subprocess.check_output(['git','status','--porcelain'])
with (base/'checkpoint-push.log').open('wb') as out:
    result=subprocess.run(['git','push','origin',f'HEAD:{branch}'],stdout=out,stderr=subprocess.STDOUT)
assert result.returncode==0,(base/'checkpoint-push.log').read_text()
body=base/'verified-checkpoint-pull-request-description.md'
assert body.exists() and 'Fixes #1580' in body.read_text()
with (base/'checkpoint-pull-request-edit.log').open('wb') as out:
    result=subprocess.run(['gh','pr','edit','1581','--repo','link-assistant/formal-ai','--title','Fix CI evidence, client constraints and startup logging regressions','--body-file',str(body)],stdout=out,stderr=subprocess.STDOUT)
assert result.returncode==0,(base/'checkpoint-pull-request-edit.log').read_text()
state=json.loads(subprocess.check_output(['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','headRefOid,isDraft,title,body,url']))
assert state['headRefOid']==head and state['isDraft'] is True and state['body']==body.read_text()
receipt={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'branch':branch,'url':state['url'],'draft':state['isDraft'],'title':state['title'],'bodySha256':hashlib.sha256(body.read_bytes()).hexdigest(),'scope':'Verified draft checkpoint; wider acceptance remains unfinished.'}
(base/'checkpoint-publication.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
print('STATUS',subprocess.check_output(['git','status','--short'],text=True))
