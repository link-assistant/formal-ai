set -eu
git diff --check
git diff --stat
rg -n 'template-report-identities|five reports|not yet filed' experiments/issue-1580 rust/tests/web/issue-1580-template-observations.test.mjs docs/case-studies/issue-1580/templates/README.md -g '!*.gz' -g '!*.jsonl'
git diff -- experiments/issue-1580/upstream/template-report-identities.json experiments/issue-1580/upstream/go-stale-pin-integrity-report.md
