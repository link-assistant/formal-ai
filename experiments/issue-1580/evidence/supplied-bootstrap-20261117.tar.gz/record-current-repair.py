from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess

research = Path('/tmp/issue-1580-research')
root = Path('experiments/issue-1580/evidence')
ci = root / 'ci/71e1dee44'
ci.mkdir(exist_ok=True)
source = research / 'head-71e1dee44'
for path in source.iterdir():
    if path.name == 'security-44071443716.log':
        (ci / (path.name + '.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
    elif path.suffix == '.json' or path.name.endswith('.log.gz'):
        shutil.copyfile(path, ci / path.name)
(ci / 'sha256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ci.iterdir()) if p.name != 'sha256.json'},indent=2)+'\n')
checks = root / 'checks'
names = ['inventory-cjs-before.log','template-observations-sixth.log','template-reference-graph-sixth.log','file-size-sixth.log','gate-selection-before.log','gate-selection-after.log','working-rules-sixth.log','push-gate-rules-sixth.log']
rows = []
for name in names:
    data = (research / name).read_bytes()
    packed = gzip.compress(data,mtime=0)
    (checks / (name + '.gz')).write_bytes(packed)
    rows.append({'file':name+'.gz','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'compressedSha256':hashlib.sha256(packed).hexdigest()})
(checks / 'ci-repair-sixth.json').write_text(json.dumps({
    'sourceHead':'71e1dee442fd74589df20a1d6f33710b6dec0d18',
    'hostedResults':{'total':24,'success':22,'failure':2},
    'failures':[
        {'run':44071443786,'diagnosticLines':[7931,7934],'cause':'Named ESM export parse is unavailable from the CI CommonJS yaml package'},
        {'run':44071444011,'diagnosticLines':[1136,1143],'cause':'Saved registry responses exceeded the maintained text limit (4005 and 6302 lines)'},
    ],
    'localVerification':{'templateTests':10,'templateSkips':0,'referenceGraphTests':2,'gateRunnerTests':11,'workingRulesTests':5,'pushGateRulesTests':6,'fileSizeGates':2},
    'negativeControls':{'commonJsInventoryBefore':{'pass':2,'fail':1},'gateSelectionBefore':{'pass':9,'fail':2}},
    'nonEvidence':'The initial check_file_size invocation ran zero gates. It has no verification credit; the correctly named check-file-size and check-file-size-js-twin were subsequently executed and passed.',
    'files':rows,
},indent=2)+'\n')

folder = root / 'chrono-upstream'
for name in ['command-stream-registry.json','link-calculator-registry.json']:
    old = subprocess.check_output(['git','show','71e1dee44:'+str(folder/name)])
    current = gzip.decompress((folder/(name+'.gz')).read_bytes())
    assert old == current, name
print('Preserved complete failed CI logs, actual Security audit log, focused before/after logs, and byte-identical compressed registry responses.')

readme = Path('docs/case-studies/issue-1580/README.md')
text = readme.read_text()
needle = '## Full template comparison\n'
section = '''## CommonJS inventory and evidence-size repair

All 24 workflows on `71e1dee442fd74589df20a1d6f33710b6dec0d18` completed: 22 succeeded and two failed. Full logs and metadata are retained under `evidence/ci/71e1dee44/`. Layered CI [44071443786](https://github.com/link-assistant/formal-ai/actions/runs/44071443786), lines 7931–7934, rejects the named ESM `parse` import from CI's CommonJS `yaml` package. The inventory generator now loads that package through `createRequire`, matching existing tooling. A disposable dynamically exported CommonJS fixture reproduces the exact import error before the fix and passes afterward. The maintained template entrypoint now passes ten tests locally without runtime skips.

CI/CD Pipeline [44071444011](https://github.com/link-assistant/formal-ai/actions/runs/44071444011), lines 1136–1143, rejects two saved registry responses at 4,005 and 6,302 lines. They are now compressed evidence with both compressed and original SHA-256 identities; decompression is checked byte-for-byte against the previously committed responses. Both actual file-size gates pass, with global limits unchanged.

The initial size-gate invocation copied a stale documented spelling, `check_file_size`; the runner returned success after selecting zero gates. That invocation receives no verification credit. The runner now rejects unknown gate names, empty selections and unmatched filters before executing any selected gate. Its three new subprocess regressions fail before the fix (two failures, one valid-skip control) and pass afterward; the complete file passes eleven tests. Working-rules and push-gate regressions pass five and six tests. `checks/ci-repair-sixth.json` indexes every full before/after log.

Security [44071443716](https://github.com/link-assistant/formal-ai/actions/runs/44071443716) actually executes the upstream proof and audit: lines 735–741 prove the exact blocked dependencies and scan 555 main-lock dependencies. This verifies the guarded exception, not Chrono removal. The experimental lock still emits its existing allowed unsafe-libyaml unmaintained warning (lines 747–754); that warning remains an unresolved dependency migration rather than a newly hidden result.

'''
assert needle in text
readme.write_text(text.replace(needle, section + needle))

plan = Path('experiments/issue-1580/work-plan.md')
plan.write_text(plan.read_text()+'''
## CommonJS and evidence-size repair round

Collected both failures after all 24 runs on 71e1dee44 completed. Reproduce the CommonJS import error with a dynamic-export fixture, load YAML through createRequire, and preserve full before/after evidence. Compress the two immutable registry responses, retaining exact original bytes/hashes and unchanged size limits. Repair the independently reproduced empty gate-selection false success; run its 11-test file plus working/push-rule controls. The maintained template entrypoint now passes ten tests locally, both actual file-size gates pass, and the lexical reference-graph aid passes two tests without claiming semantic closure. All broader open criteria above remain active. Five additional shared-template issues are filed with evidence URLs. Do not mark the PR ready based on scope-gated success or exception-policy verification.
''')
templates = Path('docs/case-studies/issue-1580/templates/README.md')
text = templates.read_text().replace('Two integrity regressions', 'Three integrity regressions').replace('Its nine local tests all passed','Its ten local tests all passed')
text += '''
## Static reference review aid

`trace-template-ci.mjs` follows literal local actions, reusable workflows, package commands and source/configuration references from all 48 workflow roots. Its compressed per-language graphs retain commands, reference reasons and unresolved paths. The graphs deliberately include conservative directory/package expansions and can contain irrelevant literal/document references. They are lexical inventories, not complete execution closures or semantic verification. Dynamic/glob paths, command working directories and implicit tool configuration still require source review. Every visited file is checked against the pinned Git blob, and two bounded regressions exercise nested helpers and transitive source tampering. Full semantic review remains unfinished.
'''
templates.write_text(text)
changelog = Path('changelog.d/20261117_120000_issue-1580-ci-regressions.md')
changelog.write_text(changelog.read_text()+'\n- Load workflow inventory YAML consistently across CommonJS environments, preserve large immutable evidence as compressed artifacts, and reject empty or unknown local gate selections.\n')
