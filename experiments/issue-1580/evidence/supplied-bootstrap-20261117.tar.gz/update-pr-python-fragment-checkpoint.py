from pathlib import Path
import json, subprocess

def run(args):
    return subprocess.run(args,check=True,capture_output=True,text=True).stdout

repository='link-assistant/formal-ai'
head=Path('/tmp/issue-1580-research/python-fragment-published-head.txt').read_text().strip()
pull=json.loads(run(['gh','pr','view','1581','--repo',repository,'--json','body,title,url,isDraft,headRefOid']))
assert pull['isDraft'] and pull['headRefOid']==head
body=pull['body']
old='The latest batch adds an executable C# changeset-loss reproduction:'
assert old in body
body=body.replace(old,'The latest batch adds a full-entrypoint Python reproduction: two manual changelog entries from the same Git user and branch within one second both report success, while the second silently replaces the earlier category and description. A disposable exclusive-create control rejects the collision and preserves the exact earlier bytes. The preceding batch adds an executable C# changeset-loss reproduction:',1)
old='The seven other complete semantic reviews remain open.'
assert old in body
body=body.replace(old,'Python now has 24 active files fully read and one partially read, including all six workflows and the manual-fragment and version/commit helpers; 178 active files and 126 historical files remain unread. Both generated JavaScript bundles and both lockfiles remain explicitly unreviewed. The seven other complete semantic reviews remain open.',1)
old='The maintained template suite passes twenty-five tests locally (no language-runtime skips),'
assert old in body
body=body.replace(old,'The maintained template suite passes twenty-nine tests locally (no language-runtime skips),',1)
old='the focused C# suite passes four cases.'
assert old in body
body=body.replace(old,'the focused C# and Python suites each pass four cases. The unchanged Python creator loses the earlier entry; its preservation assertion fails before the disposable candidate (three pass, one fail). After the candidate, all four cases pass, including distinct-timestamp success and nonmutating invalid-argument controls. The full entrypoint runs in actual temporary Git repositories with finite Python memory/CPU/wall limits. An initial default-reporter harness mismatch is retained and corrected explicitly.',1)
old='Shared template reports: '
assert old in body
body=body.replace(old,'Shared template reports: [Python fragment collision #157](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/157), ',1)
old='Full remaining repository reviews and C# runtime/publication acceptance stay open.'
assert old in body
body=body.replace(old,f'Published head `{head[:10]}` adds the Python collision fixture, retained negative control, report and command evidence; current-head hosted CI is under verification. Full remaining repository reviews and C#/Python runtime/publication acceptance stay open.',1)
assert body.startswith('Fixes #1580\n')
path=Path('/tmp/issue-1580-research/pr-python-fragment-checkpoint-body.md')
path.write_text(body)
print(run(['gh','pr','edit','1581','--repo',repository,'--title',pull['title'],'--body-file',str(path)]),flush=True)
after=json.loads(run(['gh','pr','view','1581','--repo',repository,'--json','body,title,url,isDraft,headRefOid']))
assert after['body']==body and after['isDraft'] and after['headRefOid']==head
Path('/tmp/issue-1580-research/pr-python-fragment-checkpoint-after.json').write_text(json.dumps(after,indent=2)+'\n')
runs=json.loads(run(['gh','run','list','--repo',repository,'--branch','issue-1580-8d61a32a61e1','--commit',head,'--limit','100','--json','databaseId,workflowName,status,conclusion,createdAt,headSha']))
Path('/tmp/issue-1580-research/python-fragment-initial-runs.json').write_text(json.dumps(runs,indent=2)+'\n')
print(json.dumps({'url':after['url'],'head':head,'draft':True,'runCount':len(runs),'runs':runs},indent=2),flush=True)
