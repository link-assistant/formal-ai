from pathlib import Path

helper=Path('experiments/issue-1580/template-python-runtime.mjs')
assert not helper.exists()
helper.write_text('''// Preserve optional local runtimes, but never count hosted skips as observations.
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';

export function templatePythonAvailable(context){
  const unavailable=detail=>{
    assert.notEqual(process.env.GITHUB_ACTIONS,'true','Python 3.14+ is required for hosted template observations: '+detail);
    context.skip(detail);return false;
  };
  const runtime=spawnSync('python3',['--version'],{encoding:'utf8',timeout:5000,maxBuffer:4096});
  if(runtime.error?.code==='ENOENT')return unavailable('python3 is not installed');
  assert.equal(runtime.error,undefined,String(runtime.error));
  assert.equal(runtime.status,0,runtime.stderr);
  const version=/Python (\\d+)\\.(\\d+)/u.exec(runtime.stdout);
  assert.ok(version,runtime.stdout);
  if(Number(version[1])<3||(Number(version[1])===3&&Number(version[2])<14))
    return unavailable('Pinned upstream syntax requires Python 3.14+');
  return true;
}
''')
p=Path('experiments/issue-1580/template-python-fragment-integrity.test.mjs');s=p.read_text()
marker="import test from 'node:test';\n";assert s.count(marker)==1
s=s.replace(marker,marker+"import {templatePythonAvailable} from './template-python-runtime.mjs';\n")
start=s.index("  const runtime=spawnSync('python3'")
end=s.index("  const cwd=mkdtempSync",start)
s=s[:start]+"  if(!templatePythonAvailable(t))return;\n"+s[end:];p.write_text(s)
p=Path('experiments/issue-1580/template-shared-git-observation.test.mjs');s=p.read_text()
marker="import {spawnSync} from 'node:child_process';\n";assert s.count(marker)==1
s=s.replace(marker,marker+"import {templatePythonAvailable} from './template-python-runtime.mjs';\n")
start=s.index('  const runtime=spawnSync(item.command')
end=s.index('  const fixture=fileURLToPath',start)
s=s[:start]+'''  if(item.language==='python'){
    if(!templatePythonAvailable(context))return;
  }else{
    const runtime=spawnSync(item.command,['--version'],{encoding:'utf8',timeout:5000,maxBuffer:4096});
    if(runtime.error?.code==='ENOENT'){context.skip(item.command+' is not installed');return;}
    assert.equal(runtime.status,0,runtime.stderr);
  }
'''+s[end:];p.write_text(s)
p=Path('.github/workflows/layered-ci.yml');s=p.read_text()
start=s.index('          suites="$RUNNER_TEMP/javascript-suites.txt"')
end=s.index('          scripts/run-with-budget-warning.sh',start)
old=s[start:end]
planning=old.replace('          mapfile -t files < <(', '          ').replace(' < "$suites")',' < "$suites" > "$RUNNER_TEMP/javascript-shard.txt"')
env='''        env:
          SHARD: ${{ matrix.shard }}
          SHARDS: ${{ (github.event_name == 'pull_request' || (github.event_name == 'workflow_dispatch' && github.ref != 'refs/heads/main')) && 2 || 8 }}
          FAST_PR_PROFILE: ${{ (github.event_name == 'pull_request' || (github.event_name == 'workflow_dispatch' && github.ref != 'refs/heads/main')) }}
'''
step='''      - name: Plan this shard of the JavaScript suites
        id: javascript-plan
'''+env+'''        run: |
          set -euo pipefail
'''+planning+'''          if grep -Fxq 'rust/tests/web/issue-1580-template-observations.test.mjs' "$RUNNER_TEMP/javascript-shard.txt"; then
            printf 'python-required=true\\n' >> "$GITHUB_OUTPUT"
          else
            printf 'python-required=false\\n' >> "$GITHUB_OUTPUT"
          fi
      - name: Set up Python for the pinned template observations
        if: steps.javascript-plan.outputs.python-required == 'true'
        uses: actions/setup-python@v7
        with:
          python-version: '3.15.2'
'''
s=s[:start]+'          mapfile -t files < "$RUNNER_TEMP/javascript-shard.txt"\n'+s[end:]
marker='      - name: Run the focused mapped tests first';assert s.count(marker)==1
s=s.replace(marker,step+marker);p.write_text(s)
p=Path('rust/tests/web/fast-pull-request-production-profile.test.mjs');s=p.read_text()
old="  assert.match(step.run,/printf '%s\\\\n' rust\\/tests\\/web\\/\\*\\.test\\.mjs/u);"
new="  const plan=layer.steps.find(s=>s.id==='javascript-plan');\n  assert.match(plan.run,/printf '%s\\\\n' rust\\/tests\\/web\\/\\*\\.test\\.mjs/u);"
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
p=Path('rust/tests/web/issue-1580-template-observations.test.mjs');s=p.read_text()
s+="import '../../../experiments/issue-1580/template-python-runtime.test.mjs';\n";p.write_text(s)
print('Drafted runtime helper, fail-closed fixtures, planned runtime provisioning, and maintained regressions.')
print(planning)
