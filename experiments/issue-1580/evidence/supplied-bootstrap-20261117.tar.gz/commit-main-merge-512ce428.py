from pathlib import Path
import gzip,hashlib,json,re,subprocess
root=Path("/tmp/gh-issue-solver-1794900398048")
directory=root/"experiments/issue-1580/evidence/checks/main-merge-512ce428"
def run(args):
    p=subprocess.run(args,cwd=root,capture_output=True,text=True)
    if p.returncode:
        failure=directory/"latest-bootstrap-command-failure.log.gz"
        failure.write_bytes(gzip.compress((p.stdout+p.stderr).encode(),mtime=0))
        raise RuntimeError(f"{args}: exit {p.returncode}; full output retained in {failure}")
    return p.stdout
assert run(["git","branch","--show-current"]).strip()=="issue-1580-8d61a32a61e1"
assert run(["git","rev-parse","HEAD"]).strip()=="da712fadd3f680668c063a6d7de073ef1d52573b"
assert run(["git","rev-parse","MERGE_HEAD"]).strip()=="512ce428029a92687628b4180309ee5ab660fe08"
completion=json.loads((directory/"focused-completion.json").read_text())
assert completion["status"]==0
for row in completion["checks"]:
    raw=gzip.decompress((directory/row["log"]).read_bytes())
    assert row["status"]==0 and hashlib.sha256(raw).hexdigest()==row["rawSha256"]
    print(row["command"][-1],row["status"],row["durationSeconds"])
    for line in raw.decode(errors="replace").splitlines():
        if re.match(r"^(?:#|ℹ) (?:tests|pass|fail|skipped) ",line):print(line)
manifest=json.loads((root/"data/benchmarks/fast-pull-request-javascript-tests.json").read_text())
for name in ["issue-1588-intent-spans","javascript-audit-inventory"]:
    assert f"rust/tests/web/{name}.test.mjs" in manifest["files"]
assert not run(["git","diff","--name-only","--diff-filter=U"]).strip()
(directory/"README.md").write_text("# Merge main 512ce428\n\nMerge the current main branch while preserving both added fast-test entries, one exact Chrono advisory proof with the maintainer and both dependency-owner reports, and the agreed 488-line worker ceiling. The generated specification witness combines exactly four independently verified fixture digest leaves from main with the existing reviewed witness: total 1185, supported 221, unsupported 964, 131 native source identities. Full case objects, assertions and all unsupported declarations are preserved. The complete normal witness/fixture integrity suites pass alongside profile, intent-span and advisory-proof suites. Changed Rust files pass rustfmt without compilation. Complete before/resolution and focused logs are retained. The complete merged-head JavaScript gate run remains pending. Supplied orchestration receives zero independent authorship credit.\n")
for script in ["archive-round-bootstrap.py","archive-evidence.py"]:print(run(["python3","/tmp/issue-1580-research/"+script]).strip())
print(run(["git","add","--","experiments/issue-1580/evidence"]))
inherited="dev/log/issues/1588/pulls/1596/sessions/ses_e16a7588cffeISx6F2xlD6K08b/solve.log"
whole=subprocess.run(["git","diff","--cached","--check"],cwd=root,text=True,capture_output=True)
raw=(whole.stdout+whole.stderr).encode()
(directory/"inherited-log-whitespace.log.gz").write_bytes(gzip.compress(raw,mtime=0))
paths=re.findall(r"^(.+):\d+: trailing whitespace\.$",whole.stdout,re.M)
assert whole.returncode==2 and paths and set(paths)=={inherited}
incoming=subprocess.run(["git","show","origin/main:"+inherited],cwd=root,capture_output=True,check=True).stdout
assert incoming==(root/inherited).read_bytes(),"Preserve exact inherited log bytes"
scope=["git","diff","--cached","--check","--",".",":(exclude)"+inherited]
(directory/"inherited-log-whitespace.json").write_text(json.dumps({"source":"origin/main","path":inherited,"exactIncomingBytesRetained":True,"sha256":hashlib.sha256(incoming).hexdigest(),"warningCount":len(paths),"log":"inherited-log-whitespace.log.gz","rawSha256":hashlib.sha256(raw).hexdigest(),"reviewScopeCheck":scope},indent=2)+"\n")
run(["git","add","--","experiments/issue-1580/evidence/checks/main-merge-512ce428"])
print("Whitespace warnings all belong to the exact unchanged inherited session log:",len(paths))
print(run(scope))
print(run(["git","diff","--cached","--stat"]).splitlines()[-1])
run(["git","commit","--quiet","-m","Merge main and preserve reviewed specification witnesses"])
assert subprocess.run(["git","merge-base","--is-ancestor","512ce428029a92687628b4180309ee5ab660fe08","HEAD"],cwd=root).returncode==0
print("HEAD",run(["git","rev-parse","HEAD"]).strip())
print("STATUS",run(["git","status","--short"]))
