set -eu
node experiments/formal_ai_subagent/local-gates.mjs > /tmp/issue-1580-research/all-local-gates-fifth.log 2>&1
tail -n 18 /tmp/issue-1580-research/all-local-gates-fifth.log
