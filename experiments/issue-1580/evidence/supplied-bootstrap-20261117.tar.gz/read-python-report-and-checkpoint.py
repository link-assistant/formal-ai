import pathlib, subprocess, json

root = pathlib.Path('/tmp/issue-1580-research')
for name in ['experiments/issue-1580/upstream/python-fragment-collision-report.md', 'experiments/issue-1580/template-report-identities.json']:
    path = pathlib.Path(name)
    print(f'FILE {path}')
    if path.exists():
        print(path.read_text())
for name in ['file-csharp-fragment-report.py', 'read-python-review-page.py', 'update-pr-b79-hosted-checkpoint.py']:
    path = root / name
    if path.exists():
        print(f'FILE {path}')
        print(path.read_text())
result = subprocess.run(['gh', 'pr', 'view', '1581', '--repo', 'link-assistant/formal-ai', '--json', 'body,title,isDraft,headRefOid,url'], capture_output=True, text=True, check=True)
print('PR SNAPSHOT')
print(result.stdout)
