from pathlib import Path
import gzip,json,subprocess
for path in [*Path('experiments/issue-1580').glob('*python*observation*'),Path('experiments/issue-1580/template-observation-fixtures.mjs'),Path('rust/tests/web/issue-1580-template-observations.test.mjs')]:
 if not path.exists(): continue
 lines=path.read_text().splitlines();print('\nFILE',path,'LINES',len(lines))
 for n,line in enumerate(lines,1):print(f'{n}: {line}')
for row in json.loads(gzip.decompress(Path('experiments/issue-1580/evidence/checks/python-fragment-collision/final-duplicate-issues.json.gz').read_bytes())):
 if any(word in ((row.get('title') or '')+' '+(row.get('body') or '')).lower() for word in ['audit-npm-locks','npm audit','mapfile']):
  print('RELATED',json.dumps({k:row.get(k) for k in ['number','title','body','html_url','url']},ensure_ascii=False))
result=subprocess.run(['rg','-n','mapfile.*< <\(|git ls-files.*package-lock|npm audit','scripts','.github/workflows'],capture_output=True,text=True)
print('LOCAL ANALOGUES\n'+result.stdout[:9000])
p=Path('experiments/issue-1580/evidence/ci/e120c05b4/44112040276.log.gz')
lines=gzip.decompress(p.read_bytes()).decode().splitlines()
for start,end in [(4934,4971)]:
 for n in range(start,end+1):print(f'CI:{n}: {lines[n-1]}')
