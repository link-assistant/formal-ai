from pathlib import Path
import json,subprocess

assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],check=True)
subprocess.run(['git','add','docs/case-studies/issue-1580','experiments/issue-1580','rust/tests/web/issue-1580-template-observations.test.mjs'],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
print(subprocess.check_output(['git','diff','--cached','--stat'],text=True))
paths=[
 'experiments/issue-1580/template-csharp-changeset-integrity.test.mjs',
 'experiments/issue-1580/fixtures/csharp-template/source.json',
 'rust/tests/web/issue-1580-template-observations.test.mjs',
 'docs/case-studies/issue-1580/README.md',
 'docs/case-studies/issue-1580/templates/README.md',
 'experiments/issue-1580/work-plan.md',
 'experiments/issue-1580/upstream/csharp-changeset-output-collision-report.md',
]
diff=subprocess.check_output(['git','diff','--cached','--',*paths],text=True)
Path('/tmp/issue-1580-research/csharp-collision-reviewed.diff').write_text(diff)
lines=diff.splitlines();assert len(lines)<=1500
print(diff)
for p in [Path('experiments/issue-1580/evidence/supplied-bootstrap-20261117.json'),Path('docs/case-studies/issue-1580/templates/csharp-partial-semantic-review.json')]:
 print('ARTIFACT LINES',str(p),len(p.read_text().splitlines()))
print('RESOURCE',Path('/sys/fs/cgroup/memory.current').read_text().strip())
