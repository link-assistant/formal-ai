from pathlib import Path
import json,subprocess

subprocess.run(['rustfmt','--edition','2024','rust/src/solver_handlers/calendar_create.rs','rust/tests/unit/solver/issue_869_meeting_scheduling.rs'],check=True)
Path('changelog.d/20261117_174500_preserve_calendar_clock.md').write_text('### Fixed\n\n- Preserve clock punctuation and minutes when recognizing scheduling requests and generating calendar event payloads in JavaScript and Rust.\n')
inventory=json.loads(Path('data/benchmarks/fast-pull-request-javascript-tests.json').read_text())
print('FAST INVENTORY TYPE',type(inventory).__name__)
if isinstance(inventory,dict):
 print('KEYS',list(inventory))
 for key,value in inventory.items():
  if isinstance(value,list): print(key,'length',len(value),'sample',value[:1],value[-1:])
else: print(inventory[:1],inventory[-1:])
print(subprocess.run(['rg','-n','1580|1588|calendar','data/meta/main-only-regressions.lino'],text=True,capture_output=True).stdout)
