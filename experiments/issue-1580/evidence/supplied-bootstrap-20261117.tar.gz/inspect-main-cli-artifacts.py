import json, pathlib, subprocess

root = pathlib.Path('/tmp/issue-1580-research/main-826289fc-cli-artifacts')
root.mkdir(exist_ok=True)
repo = 'link-assistant/formal-ai'
run = '44157124408'
artifacts = json.loads(subprocess.check_output(['gh', 'api', f'repos/{repo}/actions/runs/{run}/artifacts', '--paginate']))
for artifact in artifacts['artifacts']:
    if artifact['name'] in ('transcripts-opencode', 'transcripts-qwen'):
        print(json.dumps({key: artifact[key] for key in ('id', 'name', 'size_in_bytes', 'expired')}), flush=True)
        dest = root / artifact['name']
        if not dest.exists():
            subprocess.run(['gh', 'run', 'download', run, '--repo', repo, '--name', artifact['name'], '--dir', str(dest)], check=True)
        for path in sorted(dest.rglob('*')):
            if path.is_file():
                print(f'{path.relative_to(root)} {path.stat().st_size} bytes')
print(subprocess.check_output(['gh', 'run', 'view', '44157125186', '--repo', repo, '--json', 'status,conclusion,headSha,jobs'], text=True))
