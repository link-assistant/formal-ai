from pathlib import Path
import json
import subprocess

print('PLAN PATHS')
paths=subprocess.check_output(['rg','--files','experiments/issue-1580','docs/case-studies/issue-1580'],text=True).splitlines()
for p in paths:
 if any(s in p for s in ['work-plan','requirements','acceptance','semantic-review']):
  print(p)
issue=json.loads(subprocess.check_output(['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','title,body'],text=True))
print('\nISSUE\n'+issue['title']+'\n'+issue['body'])
for p in ['experiments/issue-1580/work-plan.md','docs/case-studies/issue-1580/templates/README.md']:
 path=Path(p)
 if path.exists():
  lines=path.read_text().splitlines()
  assert len(lines)<=1500
  print('\nFILE '+p+'\n'+'\n'.join(f'{i+1}: {s}' for i,s in enumerate(lines)))
