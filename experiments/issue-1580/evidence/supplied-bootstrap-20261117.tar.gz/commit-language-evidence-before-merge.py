from pathlib import Path
import json,subprocess,gzip,hashlib
base=Path('experiments/issue-1580/evidence/checks/language-source-binding-final')
r=json.loads((base/'outcome.json').read_text());assert len(r['gateLogs'])==86 and next(x for x in r['checks'] if x['name']=='all-local-gates')['exitCode']==1
for row in r['checks']+r['gateLogs']:
 raw=gzip.decompress((base/row['log']).read_bytes());assert hashlib.sha256(raw).hexdigest()==row['sha256']
note='''
The first complete local inventory finishes in 764.618 seconds: 80 executable gates pass, six fail and 52 are explicitly excluded. All six failures trace to placing the new test-only module under `rust/src` (one abbreviation, two literal predicates, four natural-language strings and three test prompts); the tests have moved into the existing test tree without changing any ceiling or allowlist. All 91 aggregate/focused/detailed payload hashes are verified. No merged-tree or new native execution is claimed yet. Main advanced to `30ff2d8a8`; merge and complete revalidation are next.
'''
with (base/'README.md').open('w') as stream:stream.write(note)
with Path('experiments/issue-1580/work-plan.md').open('a') as stream:stream.write(note)
with Path('docs/case-studies/issue-1580/language-source-binding-checkpoint.md').open('a') as stream:stream.write(note)
src=Path('/tmp/issue-1580-research/language-source-commits');dest=Path('experiments/issue-1580/evidence/checks/language-source-commits');dest.mkdir(exist_ok=False)
for p in src.iterdir():
 if p.is_file():(dest/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for argv in [['python3','/tmp/issue-1580-research/archive-round-bootstrap.py'],['python3','experiments/issue-1580/archive-evidence.py']]:
 result=subprocess.run(argv,capture_output=True,text=True,check=True);print(result.stdout.strip()[:1400])
subprocess.run(['git','diff','--check'],check=True)
allowed=['docs/case-studies/issue-1580','experiments/issue-1580']
status=subprocess.check_output(['git','status','--porcelain'],text=True).splitlines();assert all(any(x[3:].startswith(p+'/') for p in allowed) for x in status),status
subprocess.run(['git','add','--',*allowed],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
path=Path('/tmp/issue-1580-research/language-evidence-commit.log')
with path.open('wb') as stream:r=subprocess.run(['git','-c','gc.auto=0','commit','-m','Record language regressions, browser comparison and published CI results'],stdout=stream,stderr=subprocess.STDOUT)
assert r.returncode==0,path.read_text()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
print('COMMIT',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'CLEAN',True,'PUSH',False)
