from pathlib import Path
import gzip,hashlib,json,os,re,subprocess,time
path=Path("rust/tests/web/pull-request-1188-subagent-folder.test.mjs")
text=path.read_text();assert text.count("check_file_size")==2
path.write_text(text.replace("check_file_size","check-file-szie"))
directory=Path("experiments/issue-1580/evidence/checks/python-release-formatting")
command=["timeout","600","node","--max-old-space-size=256","--test","--test-concurrency=1",str(path)]
env=dict(os.environ);env["NODE_OPTIONS"]="--max-old-space-size=256"
available=int(Path("/sys/fs/cgroup/memory.max").read_text())-int(Path("/sys/fs/cgroup/memory.current").read_text())
assert available>512*1024*1024,f"Insufficient measured headroom: {available}"
started=time.time()
result=subprocess.run(command,env=env,capture_output=True)
raw=result.stdout+result.stderr
(directory/"gate-selection-notation-after.log.gz").write_bytes(gzip.compress(raw,mtime=0))
record={"command":command,"status":result.returncode,"durationSeconds":round(time.time()-started,3),"rawSha256":hashlib.sha256(raw).hexdigest(),"log":"gate-selection-notation-after.log.gz","measuredAvailableBytes":available,"nodeHeapMiB":256}
(directory/"gate-selection-notation-after.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record))
for line in raw.decode(errors="replace").splitlines()[-14:]:print(line)
assert result.returncode==0
assert re.search(r"^(?:#|ℹ) skipped 0$",raw.decode(),re.M)
