import subprocess
from pathlib import Path
for args in [['rg','-l','name: CI/CD Pipeline','.github/workflows'],['rg','-n','workflow_dispatch|native-type-check|pull_request|full','\.github/workflows/main.yml']]:
    r=subprocess.run(args,capture_output=True,text=True);print('SEARCH',args,r.stdout,r.stderr)
for path in Path('.github/workflows').glob('*.yml'):
    text=path.read_text()
    if 'name: CI/CD Pipeline' in text:
        rows=text.splitlines();print('WORKFLOW',path,len(rows))
        for n in range(min(145,len(rows))): print(f'{n+1}: {rows[n]}')
