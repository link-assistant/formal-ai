from pathlib import Path
import collections,gzip,hashlib,json
directory=Path('experiments/issue-1580/evidence/checks/audit-inventory-boundary')
upstream=Path('experiments/issue-1580/upstream');upstream.mkdir(exist_ok=True)
body='''The full audit entrypoint can report success when Git fails to enumerate the tracked lockfiles. This also occurs after Git emits a partial list, so a successful audit of that subset can conceal an incomplete inventory.

Affected source: [`scripts/audit-npm-locks.sh` lines 17–29](https://github.com/link-foundation/python-ai-driven-development-pipeline-template/blob/c532c173801dfb12e681b0730c4abbf93aefd0ca/scripts/audit-npm-locks.sh#L17-L29), current `main` rechecked at `c532c173801dfb12e681b0730c4abbf93aefd0ca`. Full 53-line source Git blob: `e4c73c9df844a08e031b786cb8fdb891ce192789`; SHA-256: `40bdae551f88431166778fa4f041a437afcf1ff73bf5b82fb59d5fe586b2a7a2`.

Reproduce without installing dependencies or contacting an advisory registry:

```bash
source_script="$PWD/scripts/audit-npm-locks.sh"
scratch="$(mktemp -d)"
(
  cd "$scratch"
  bash "$source_script"
  printf 'audit exit: %s\\n' "$?"
)
rm -rf -- "$scratch"
```

In an ordinary temporary directory outside a Git repository, Git prints `fatal: not a git repository`, but the script prints `::notice::No package-lock.json is tracked; nothing to audit.` and exits **0**. `--list` likewise succeeds. A controlled Git process that prints one existing lockfile and then exits 128 causes that single lock to be audited and reports `Audited 1 npm lockfile(s)` with exit 0, despite the failed inventory.

The failing producer runs inside `mapfile -t locks < <(git ls-files ...)`. The parent observes `mapfile` success, so `set -euo pipefail` does not propagate the producer's failure. A successful, empty inventory and a failed inventory become indistinguishable.

Suggested minimal repair, keeping the current pathspec, severity, full-audit loop and advisory failures:

```bash
tracked_locks="$(git ls-files -- ':(glob)**/package-lock.json')"
mapfile -t locks < <(printf '%s' "$tracked_locks")
```

The assignment must succeed before either `--list` or any audit runs. `printf '%s'` emits no record for a genuinely empty successful inventory. The disposable candidate propagates Git status 128 and performs no npm call for failed/partial inventories in either mode. Controls retain both tracked locks (including a path with spaces), exclude an untracked lock, retain `NPM_AUDIT_LEVEL=high`, reject an advisory verdict while auditing every selected lock, and accept a genuinely empty repository. Bash/npm child processes have five-second deadlines; npm is an offline stand-in, so no vulnerability or registry-state assertion is made.

Related work reviewed: closed issue #132 and merged PR #134 introduced npm coverage; merged PR #152 updated dependencies. The complete current 157-item issue/PR inventory and relevant conversation, inline-comment and review endpoints were checked before drafting. This report concerns propagation of the inventory failure, rather than adding npm coverage or changing dependency versions.

Found during https://github.com/link-assistant/formal-ai/pull/1581. Formal AI's analogous boundary has a local repair and regression; that does not repair this upstream helper. No upstream implementation change is claimed.
'''
(upstream/'python-audit-inventory-report.md').write_text(body)
path=Path('docs/case-studies/issue-1580/templates/python-partial-semantic-review.json')
record=json.loads(path.read_text());inventory=json.loads(Path('/tmp/issue-1580-research/python-active-source-inventory.json').read_text());root=Path('/tmp/issue-1580-research/templates/python-complete')
deferred={'.github/actions/artifact/dist/835.index.mjs','.github/actions/artifact/dist/index.mjs','.github/actions/artifact/package-lock.json','uv.lock'}
decisions={
 'experiments/issue_98_analysis.md':'Read all 120 lines of the historical release-tag polling analysis, including its old-source/runtime assumptions. No live tag propagation or release provider flow was executed.',
 'experiments/reproduce_actionlint_queue.py':'Read the complete offline actionlint queue/queue-size valid/invalid control probe and its 15-second child bounds. It was not rerun as current evidence.',
 'experiments/reproduce_artifact_buffer.mjs':'Read the bounded two-byte historical unzip-stream deprecation probe. No runtime or dependency installation was executed.',
 'experiments/reproduce_partial_release.py':'Read the full historical 1e929ef release-tag gate reproduction, isolated Git repository and virtual 240-second propagation clock. It was not executed or treated as current source validation.',
 'experiments/reproduce_zizmor_scope.py':'Read the historical workflow-only versus repository-scope Dependabot cooldown audit. Its audit subprocess lacks its own deadline; no audit or dependency installation was run.',
 'lychee.toml':'Read GitHub concurrency two/request interval one second policy. Preserve genuine terminal failures; no live-link scan was executed.',
 'pyproject.toml':'Read all 175 lines of Python >=3.15 runtime, optional dependency/build/test/type/lint configuration and Scriv categories/heading marker. No fresh resolver, dependency audit or whole-project test was executed; do not copy historical pins blindly.',
 'scripts/audit-npm-locks.sh':'Read the complete 53-line helper. Executing unchanged pinned source confirms Git failure/partial output becomes success in audit and list modes. A disposable candidate requires successful inventory first; real tracked/empty and offline advisory controls pass. Formal AI own analogous helper is repaired; the upstream report is drafted, not yet filed.',
 'scripts/audit_dependencies.py':'Read all 164 lines of Python/docs/uv dependency surface checks, locked all-extras export, isolated environments and streamed pip-audit failure handling. No installation or live audit was executed; outer CI owns process/network bounds.',
 'scripts/bump_version.py':'Read all 177 lines of version extraction, bump/update, changelog insertion and CLI handling. Preserve caller-owned changelog collection and error propagation; no release or file-mutation trial was executed.',
 'scripts/check-dependency-graph.sh':'Read all 56 lines of three-attempt graph probing, explicit disabled versus unknown states, debug tracing and PR-advisory/main-failure policy. No live graph probe was executed; individual gh request timeout remains delegated to the provider/outer job.',
 'scripts/check-links.sh':'Read all 43 lines of stale-report removal, scanner exit propagation, nonempty positive-total report validation and malformed/scanner-error refusal. No link scan was executed.',
 'scripts/check-pipeline-status.sh':'Read all 137 lines of needs parsing, failed/cancelled classification, branch identity and explicit supersede-policy proof. Unknown cancellation policy remains terminal; no provider/workflow effect was executed.',
}
previous={r['path']:r for r in record['files']};offset=0;rows=[]
for category in ['active','historical']:
 for item in inventory[category]:
  row=dict(previous[item['path']]);data=(root/item['path']).read_bytes()
  assert hashlib.sha256(data).hexdigest()==item['sha256']
  assert hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()==item['gitBlob']
  if category=='active' and item['path'] not in deferred:
   read=max(0,min(item['lines'],8000-offset));offset+=item['lines'];old=sum(b-a+1 for a,b in row['readRanges']);read=max(read,old)
   if read>old:
    row['readRanges']=[[1,read]]
    if read==item['lines']:
     row['reviewStatus']='active-source-fully-read';row['decision']=decisions[item['path']]
    else:
     assert item['path']=='scripts/check-required-docs.sh' and read==71
     row['reviewStatus']='active-source-partially-read';row['decision']='Read only lines 1-71: required document/heading inventory, exact level-two heading match, list mode and Bash 3.2-compatible failure accumulator. Remaining source is unread; no execution is claimed.'
  rows.append(row)
assert offset==21394
record['files']=rows;record['counts']=dict(collections.Counter(r['reviewStatus'] for r in rows));record['activeReadLines']=sum(b-a+1 for r in rows for a,b in r['readRanges']);assert record['activeReadLines']==8864
record['readMethod']='Corrected ordered active-source pages 1-20 (400 lines each) fully read, plus create_manual_changeset.py 1-249 and version_and_commit.py 1-615. Both generated bundles, both lockfiles and every historical blob remain unread. Truncated previews receive no reading credit. Full Formal AI command transcripts retain source output.'
record['runtimeEvidence']='Hosted head e120c05b4 passes all 24 workflows; full Layered CI log lines 4947-4952 confirm four Python fragment cases and runtime regressions executed, while the shared Python Git observation also passed. Previous head 624812120 skipped five Python cases and is not credited. The npm audit observation executes the full pinned shell entrypoint with offline npm and failed/partial Git controls plus real tracked/empty Git repositories. Candidate changes remain disposable. No full upstream suites/builds/provider effects were executed.'
header={k:v for k,v in record.items() if k!='files'}
path.write_text(json.dumps(header,indent=2)[:-2]+',\n  "files": [\n'+',\n'.join('    '+json.dumps(r,separators=(',',':')) for r in rows)+'\n  ]\n}\n')
print(json.dumps({'counts':record['counts'],'readLines':record['activeReadLines'],'reportSha256':hashlib.sha256(body.encode()).hexdigest()},indent=2))
