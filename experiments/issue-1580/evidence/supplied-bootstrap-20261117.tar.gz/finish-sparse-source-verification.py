from pathlib import Path
import datetime,gzip,hashlib,json,os,shutil,subprocess,time
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research');base=root/'experiments/issue-1580/evidence/checks/fast-source-archive-checkout'
receipt=base/'sparse-source-commands.json';assert not receipt.exists()
work=scratch/'sparse-fast-source-ekoi7dy_';assert (work/'scripts/check-fast-governance.mjs').is_file()
capture=Path('/tmp/formal-ai-shell-capture-Nwm3Ee/stdout.raw').read_bytes();assert hashlib.sha256(capture).hexdigest()=='6e9dd415414208acdbb5021f7a0d3eab298b59e6d8fc6ee52b1ac0f0ea1968f5'
(base/'interrupted-invocation-output.jsonl.gz').write_bytes(gzip.compress(capture,mtime=0));rows=[json.loads(line) for line in capture.splitlines()];assert len(rows)==20
for row in rows:
 raw=gzip.decompress((base/row['log']).read_bytes());assert hashlib.sha256(raw).hexdigest()==row['rawSha256']
assert [r['name'] for r in rows if r['exitCode']] == ['current-debt-ceilings']
raw=gzip.decompress((base/rows[14]['log']).read_bytes());assert b'restricted to hosted Linux GitHub Actions' in raw
script="import fs from 'node:fs';import {parseRatchet,measure,checkMeasured} from './scripts/check-debt-ratchet.mjs';const ratchet=parseRatchet(fs.readFileSync('data/meta/debt-ratchet.lino','utf8'));const failures=checkMeasured(ratchet,measure(process.cwd()));if(failures.length){console.error(failures.join('\\n'));process.exitCode=1;}else console.log('Current debt ceilings match measured source; direct exported functions, no hosted-environment impersonation');"
args=['node','--max-old-space-size=256','--input-type=module','-e',script];started=time.monotonic();run=subprocess.run(args,cwd=work,env=dict(os.environ,GIT_INDEX_FILE=str(scratch/'sparse-fast-source-index')),capture_output=True);raw=run.stdout+run.stderr
log=base/'sparse-current-debt-direct.log.gz';log.write_bytes(gzip.compress(raw,mtime=0));correction={'name':'current-debt-ceilings','argv':args,'exitCode':run.returncode,'seconds':round(time.monotonic()-started,3),'log':log.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'rawBytes':len(raw),'rawLines':len(raw.splitlines())};assert run.returncode==0,raw.decode()
print(json.dumps(correction),flush=True)
files=[p.decode() for p in subprocess.check_output(['git','ls-files','--cached','-z'],cwd=root).split(b'\0') if p]
selected=[];omitted=[];selectedBytes=omittedBytes=0
for name in files:
 p=root/name
 try:n=p.stat().st_size
 except FileNotFoundError:n=0
 if (work/name).exists() or (work/name).is_symlink():selected.append(name);selectedBytes+=n
 else:omitted.append(name);omittedBytes+=n
oldOmitted=lambda name:name.startswith('dev/log/') or (name.startswith('experiments/formal_ai_subagent/evidence/coordinator-1188/') and name.endswith('.gz'))
beforeSelected=[name for name in files if not oldOmitted(name)];beforeBytes=sum((root/name).stat().st_size for name in beforeSelected if (root/name).is_file())
accepted=[correction if row['name']=='current-debt-ceilings' else row for row in rows]
value={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'sourceWorkflowSha256':hashlib.sha256((root/'.github/workflows/release.yml').read_bytes()).hexdigest(),'beforeSelectedFiles':len(beforeSelected),'beforeSelectedBytes':beforeBytes,'selectedFiles':len(selected),'selectedBytes':selectedBytes,'reducedBytes':beforeBytes-selectedBytes,'omittedFiles':len(omitted),'omittedBytes':omittedBytes,'initialInvocation':{'exitStatus':'Formal AI 60000ms shell limit; incomplete outer command; all 20 individual command records retained','commands':rows},'correctedDebtInvocation':correction,'acceptedCommands':accepted,'scope':'Actual fast-source commands in a temporary sparse copy. Governance children run directly; the hosted-only debt CLI refusal is retained and its identical exported calculation is independently invoked. This does not reproduce remote checkout, hosted wrapper timing or native execution.','independentAuthorshipCredit':0}
receipt.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({k:v for k,v in value.items() if k not in ['initialInvocation','correctedDebtInvocation','acceptedCommands']}),flush=True)
shutil.rmtree(work);(scratch/'sparse-fast-source-index').unlink(missing_ok=True)
assert all(row['exitCode']==0 for row in accepted)
