from pathlib import Path

root=Path('/tmp/gh-issue-solver-1794900398048')
target=root/'js/worker/formal_ai_worker_unknown_language.js'
source=target.read_text()
before='''  if (language !== "unknown" || !String(prompt || "").trim()) return null;
  const focus = String(prompt).trim(), folded = normalizePrompt(focus);
'''
after=r'''  const supported = crateModule("crate/seed.mjs").splitPipeList(String(AGENT_INFO.supported_languages || ""));
  if (supported.includes(language)) return null;
  // Match the native whole-prompt focus: outer quotes and terminal punctuation are delimiters.
  const focus = String(prompt || "").trim().replace(/^["'`“”‘’«»]+|["'`“”‘’«»]+$/gu, "")
    .replace(/[?？。.！!,;:]+$/u, "").trim();
  if (!focus) return null;
  const folded = normalizePrompt(focus);
'''
assert source.count(before)==1
source=source.replace(before,after)
before_trace='payload: "language=unknown local_search=complete prompt_state=unmatched_prompt"'
after_trace='payload: "language=" + language + " local_search=complete prompt_state=unmatched_prompt"'
assert source.count(before_trace)==1
source=source.replace(before_trace,after_trace)
target.write_text(source)
print('UPDATED',target.relative_to(root),'lines',len(source.splitlines()),flush=True)
