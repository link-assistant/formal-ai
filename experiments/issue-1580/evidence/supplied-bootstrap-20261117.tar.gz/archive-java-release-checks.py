import gzip
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

root = Path('experiments/issue-1580/evidence')
folder = root / 'checks'
folder.mkdir(exist_ok=True)
records = []
for name in ['focused', 'maintained', 'gates']:
    source = Path('/tmp/issue-1580-research/java-release-checks') / (name + '.log')
    raw = source.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    target = 'java-release-integrity-' + name + '.log.gz'
    (folder / target).write_bytes(packed)
    records.append({'file': target, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'compressedSha256': hashlib.sha256(packed).hexdigest()})
(folder / 'java-release-integrity.json').write_text(json.dumps({
    'observedAt': datetime.now(timezone.utc).isoformat(),
    'sourceRepository': 'link-foundation/java-ai-driven-development-pipeline-template',
    'sourceCommit': 'dd803a2d9fa5b3a992b435acce73162274fb9e8b',
    'commands': [
        'timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-java-release-integrity.test.mjs',
        'timeout 600 node --test --test-concurrency=1 rust/tests/web/issue-1580-template-observations.test.mjs',
        'node experiments/formal_ai_subagent/local-gates.mjs --only check-file-size,check-file-size-js-twin,check-changelog-fragment-js-twin,check-ci-speed',
    ],
    'results': {'focused': {'pass': 5, 'fail': 0, 'skip': 0}, 'maintained': {'pass': 16, 'fail': 0, 'skip': 0}, 'gates': {'pass': 4, 'fail': 0, 'skip': 0}},
    'reproduction': 'The unchanged release helper suppresses a real rejected Git commit, reports released=true and pushes a new-version tag containing the old version to a disposable local bare remote. Both modes reproduce. A one-line candidate repair in disposable copies blocks tags/pushes; four successful release controls retain the correct version.',
    'limits': ['No hosted workflow or Maven build', 'No external network or remote template modification', 'The candidate repair is not applied upstream', 'No native runtime or whole-issue completion claim', 'Supplied scripts and decisions earn zero independent Formal AI reasoning/authorship credit'],
    'files': records,
}, indent=2) + '\n')
head = 'e6627385d3ef58435df22ec61d4dfdc4551c9d28'
raw = Path('/tmp/issue-1580-research/head-e6627385d/runs.json').read_bytes()
runs = json.loads(raw)
assert len(runs) == 24 and all(row['headSha'] == head and row['status'] == 'completed' and row['conclusion'] == 'success' for row in runs)
destination = root / 'ci' / head[:9]
destination.mkdir(parents=True, exist_ok=True)
packed = gzip.compress(raw, mtime=0)
(destination / 'runs.json.gz').write_bytes(packed)
(destination / 'summary.json').write_text(json.dumps({
    'head': head, 'observedAt': datetime.now(timezone.utc).isoformat(),
    'workflowRuns': 24, 'completedSuccess': 24, 'failed': 0, 'active': 0,
    'verificationLimit': 'Includes successful scope gates. Main-only native runtimes, native detector fixtures, benchmark capability and live qualification remain unexecuted on this PR. The subsequent Java changes require their own hosted results.',
    'files': [{'file': 'runs.json.gz', 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'compressedSha256': hashlib.sha256(packed).hexdigest()}],
    'runs': [{'id': row['databaseId'], 'name': row['workflowName'], 'conclusion': row['conclusion'], 'url': 'https://github.com/link-assistant/formal-ai/actions/runs/' + str(row['databaseId'])} for row in runs],
}, indent=2) + '\n')
with Path('docs/case-studies/issue-1580/README.md').open('a') as handle:
    handle.write('\n### Hosted checkpoint after Go/cache changes\n\nAll 24 workflows on `e6627385d3ef58435df22ec61d4dfdc4551c9d28` completed successfully. [Exact-head metadata](../../../experiments/issue-1580/evidence/ci/e6627385d/summary.json) retains every run identity and source-byte hashes. These PR results verify the scoped JavaScript/CI changes; they do not execute the main-only native runtimes or resolve the outstanding benchmark, qualification, live identity, full semantic review and historical backend-cause criteria. The subsequent Java regression/review changes need their own hosted verification.\n')
with Path('experiments/issue-1580/work-plan.md').open('a') as handle:
    handle.write('\n## Go/cache hosted checkpoint\n\nAll 24 workflows on e6627385d completed successfully; no active or queued runs remain for that head. Exact metadata and Java focused/maintained/gate logs are retained. Archive current execution/supplied-input evidence, review the complete Java diff, refresh main and feedback, then push the next batch once. Broader acceptance remains unfinished.\n')
print('Archived 5/16/4 local passing checks and all 24 successful e6627385d workflows')
