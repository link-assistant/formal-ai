from pathlib import Path
import gzip,hashlib,json,subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/checks/unverified-child-status/main-update'
path=base/'merge.json'
report=json.loads(path.read_text())
renamed=[]
for row in report['archives']:
    if 'incoming-incoming-stat.' not in row['archive']:
        continue
    old=base/row['archive']
    new=base/row['archive'].replace('incoming-incoming-stat.','incoming-change-summary.')
    assert old.exists() and not new.exists()
    packed=old.read_bytes()
    old.rename(new)
    assert new.read_bytes()==packed
    renamed.append({'before':row['archive'],'after':new.name,'compressedSha256':hashlib.sha256(packed).hexdigest()})
    row['archive']=new.name
assert len(renamed)==2
path.write_text(json.dumps(report,indent=2)+'\n')
(base/'archive-name-correction.json').write_text(json.dumps({'renamed':renamed,'originalSourcePathsRetained':True,'rawAndCompressedBytesUnchanged':True,'ratchetLimitChanged':False},indent=2)+'\n')
print(json.dumps({'renamedArchives':len(renamed),'contentUnchanged':True}))
