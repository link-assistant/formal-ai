from pathlib import Path
source=Path('/tmp/issue-1580-research/fix-documentation-reporting.py').read_text()
start=source.index("text+='''")+len("text+='''")
end=source.index("'''\nfile.write_text(text)",start)
# Interpret only the literal bootstrap string, never execute the failed patch.
import ast
addition=ast.literal_eval("'''"+source[start:end]+"'''")
file=Path('rust/tests/web/documentation-only-ci-policy.test.mjs')
text=file.read_text()
assert 'assertDocumentationContextSafety' not in text
text=text.replace('filteredWorkflow, lightweightWorkflows}', 'filteredWorkflow, lightweightWorkflows, contextReportingWorkflows}')
text=text.replace("all heavy push and PR triggers carry the generated documentation policy", "heavy triggers are filtered while required PR context reporters remain admitted")
text=text.replace('documentation paths select lightweight checks only:', 'documentation paths select lightweight checks and required context reporters:')
old="for (const path of selected) assert.ok(lightweightWorkflows.has(path.split('/').at(-1)), path);"
new="""for (const path of selected) assert.ok(lightweightWorkflows.has(path.split('/').at(-1))
          || (event === 'pull_request' && contextReportingWorkflows.has(path.split('/').at(-1))), path);
"""
assert old in text
text=text.replace(old,new).replace("assert.ok(!selected.includes('.github/workflows/release.yml'));", "assert.equal(selected.includes('.github/workflows/release.yml'), event === 'pull_request',\n          'the required PR contexts report without selecting heavy build jobs');")
file.write_text(text+addition)
