from pathlib import Path
import gzip
directory=Path('experiments/issue-1580/evidence/checks/python-runtime-provisioning')
for p in directory.glob('*.log'):
 p.with_suffix('.log.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0));p.unlink()
source=Path('experiments/formal_ai_subagent/sandboxes/gates/lint-shell-scripts.log')
(directory/'local-shellcheck-unavailable.log.gz').write_bytes(gzip.compress(source.read_bytes(),mtime=0))
p=Path('/tmp/issue-1580-research/record-python-runtime-evidence.py');s=p.read_text();s=s.replace("'log':'before.log'","'log':'before.log.gz'");p.write_text(s)
print('Retained raw log bytes in deterministic gzip archives, including the missing-shellcheck diagnostic.')
