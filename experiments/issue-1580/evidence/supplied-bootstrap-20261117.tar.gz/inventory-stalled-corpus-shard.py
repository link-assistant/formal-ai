import hashlib
import json
import pathlib

root=pathlib.Path.cwd()
rows=[]
def walk(directory):
    for path in sorted(directory.iterdir(),key=lambda p:p.name):
        if path.is_dir():yield from walk(path)
        elif path.is_file():yield path
for file in walk(root/'data/benchmarks'):
    if file.suffix!='.lino':continue
    for line_number,line in enumerate(file.read_text().splitlines(),1):
        text=line.strip()
        if not text.startswith('prompt '):continue
        raw=text[7:].strip()
        if len(raw)>=2 and raw.startswith('"') and raw.endswith('"'):value=raw[1:-1].replace('""','"')
        elif len(raw)>=2 and raw.startswith("'") and raw.endswith("'"):value=raw[1:-1].replace("''","'")
        else:value=raw
        if value.strip():rows.append({'position':len(rows),'file':str(file.relative_to(root)),'line':line_number,'prompt':value})
selected=[row for row in rows if row['position']%6==2]
base=root/'experiments/issue-1580/evidence/checks/corpus-shard-three-investigation'
base.mkdir(parents=True,exist_ok=True)
receipt={'schema':'issue-1580-corpus-shard-inventory/v1','nativeExecuted':False,'selectionOnly':True,'inputCount':len(rows),'shard':'3/6','selectedCount':len(selected),'rows':selected}
(base/'inventory.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print('all',len(rows),'selected',len(selected))
print('This is selection evidence only, not an execution or timing reproduction.')
for row in selected:
    print(f"{row['position']:4} {row['file']}:{row['line']} {row['prompt'][:160]}")
