from pathlib import Path
import subprocess
for name,end in [('scripts/lib/ci-speed-durations.mjs',85),('scripts/lib/ci-speed-shards.mjs',85),('data/meta/javascript-test-durations.lino',12)]:
 print(name)
 for i,line in enumerate(Path(name).read_text().splitlines()[:end],1):print(f'{i}: {line}')
result=subprocess.run(['ps','-eo','pid,ppid,etime,args'],capture_output=True,text=True)
print('\n'.join(line for line in result.stdout.splitlines() if 'issue-1580-template-observations.test.mjs' in line and 'formal-command' not in line))
