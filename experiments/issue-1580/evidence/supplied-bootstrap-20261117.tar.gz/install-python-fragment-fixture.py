from pathlib import Path
import hashlib
import json

root = Path('/tmp/issue-1580-research/templates/python-complete')
fixture = Path('experiments/issue-1580/fixtures/python-template')
metadata_path = fixture / 'source.json'
metadata = json.loads(metadata_path.read_text())
assert metadata['commit'] == 'c532c173801dfb12e681b0730c4abbf93aefd0ca'
name = 'scripts/create_manual_changeset.py'
assert name not in {item['path'] for item in metadata['files']}
data = (root / name).read_bytes()
inventory = json.loads(Path('/tmp/issue-1580-research/python-active-source-inventory.json').read_text())
entry = next(item for item in inventory['active'] if item['path'] == name)
assert hashlib.sha256(data).hexdigest() == entry['sha256']
assert hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest() == entry['gitBlob']
(fixture / name).write_bytes(data)
metadata['files'].append({key: entry[key] for key in ['path', 'gitBlob', 'sha256']})
metadata_path.write_text(json.dumps(metadata, indent=2) + '\n')
test_path = Path('experiments/issue-1580/template-python-fragment-integrity.test.mjs')
assert not test_path.exists()
test_path.write_bytes(Path('/tmp/issue-1580-research/template-python-fragment-integrity.test.mjs').read_bytes())
print(json.dumps({'fixture': str(fixture / name), 'gitBlob': entry['gitBlob'], 'sha256': entry['sha256'], 'bytes': len(data), 'test': str(test_path), 'sourceChanged': False}, indent=2))
