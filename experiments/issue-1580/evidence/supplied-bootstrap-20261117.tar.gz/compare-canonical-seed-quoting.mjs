import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
import {parseLino} from '/tmp/gh-issue-solver-1794900398048/js/server/lino.mjs';
const base='experiments/issue-1580/evidence/checks/cnl-canonical-data';
const records=JSON.parse(readFileSync(base+'/canonical-quoting.json'));
for(const row of records) assert.deepEqual(parseLino(readFileSync(row.path,'utf8')),parseLino(gunzipSync(readFileSync(base+'/'+row.beforeArchive)).toString()),row.path);
writeFileSync(base+'/canonical-quoting-comparison.json',JSON.stringify({allDecodedTreesIdentical:true,files:records.length,fields:records.reduce((n,r)=>n+r.lines.length,0),independentAuthorshipCredit:0},null,2)+'\n');
