set -eu
rustfmt --edition 2024 --check rust/src/solver.rs
node scripts/documentation-only-ci-policy.mjs
node /tmp/issue-1580-research/review-governed-baseline.mjs
git diff -- rust/tests/unit/specification/debug_session.rs
