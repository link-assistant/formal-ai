from pathlib import Path
for name in ['read-python-review-page.py','read-python-unread-page.py','inspect-python-review-record-format.py']:
    p=Path('/tmp/issue-1580-research')/name
    print('FILE',name)
    for n,line in enumerate(p.read_text().splitlines(),1): print(f'{n}: {line}')
log=Path('/tmp/issue-1580-research/governed-refresh-all-local-gates.log')
print('GATE_PROGRESS')
if log.exists():
    lines=log.read_text().splitlines()
    print('\n'.join(lines[-5:]))
