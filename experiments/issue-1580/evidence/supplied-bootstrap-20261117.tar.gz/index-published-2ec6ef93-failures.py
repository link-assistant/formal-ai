import gzip,json,pathlib,re
base=pathlib.Path('experiments/issue-1580/evidence/ci/published-2ec6ef93')
items=[]
for log in sorted(pathlib.Path('/tmp/issue-1580-research/published-2ec6ef93-failures').glob('*.log')):
 lines=log.read_text().splitlines()
 selected=[]
 for n,line in enumerate(lines,1):
  if re.search(r'not ok |##\[error\]|^.*FAIL [^/]|Error:|error:|AssertionError|Failed tests:|✗|✖|command failed',line,re.I):
   selected.append({'line':n,'text':line})
 items.append({'file':str(log),'lineCount':len(lines),'markers':selected})
 print(log.name,'lines',len(lines),'markers',len(selected))
 for item in selected[:65]:print(item['line'],item['text'][:1500])
 if len(selected)>65:print('remaining markers archived, not displayed')
(base/'targeted-failure-index.json.gz').write_bytes(gzip.compress((json.dumps(items,indent=2)+'\n').encode(),mtime=0))
