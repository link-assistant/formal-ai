from pathlib import Path
import json, subprocess

base = Path('/tmp/issue-1580-research/unverified-child-status')
command = ['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-concurrency=1', '--test-name-pattern=unverified drafts cannot satisfy', 'rust/tests/web/issue-1550-meta-executor.test.mjs']
with (base / 'before.stdout.log').open('wb') as output, (base / 'before.stderr.log').open('wb') as errors:
    result = subprocess.run(command, stdout=output, stderr=errors)
(base / 'before-result.json').write_text(json.dumps({'command': command, 'exitCode': result.returncode, 'expectedFailure': True, 'productionChanged': False}, indent=2) + '\n')
assert result.returncode == 1, result.returncode
text = (base / 'before.stdout.log').read_text()
assert "answered(meta_reasoned_program_unverified)=true" in text
assert len(text.splitlines()) < 1500
print(text)
print((base / 'before.stderr.log').read_text())
print(json.dumps({'exitCode': result.returncode, 'expectedFailureObserved': True, 'log': str(base / 'before.stdout.log')}))
