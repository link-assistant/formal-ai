from pathlib import Path
import hashlib,json,os,subprocess

base=Path('experiments/issue-1580')
evidence=base/'evidence/checks/csharp-changeset-collision'
for label,test,count in [
    ('after',base/'template-csharp-changeset-integrity.test.mjs',4),
    ('maintained',Path('rust/tests/web/issue-1580-template-observations.test.mjs'),25),
]:
    command=['timeout','600','node','--test','--test-reporter=tap','--test-concurrency=1',str(test)]
    env={**os.environ,'NODE_PATH':'/tmp/issue-1580-research/node_modules'}
    run=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (evidence/(label+'.tap')).write_bytes(run.stdout)
    record={'command':command,'exitCode':run.returncode,'testSha256':hashlib.sha256(test.read_bytes()).hexdigest(),'logSha256':hashlib.sha256(run.stdout).hexdigest(),'expectedTests':count,'network':False,'nativeBuild':False}
    (evidence/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    print(label,json.dumps(record))
    print(run.stdout.decode() if run.returncode else '\n'.join(run.stdout.decode().splitlines()[-9:]))
    assert run.returncode==0
    assert f'# pass {count}\n'.encode() in run.stdout
    assert b'# fail 0\n' in run.stdout and b'# skipped 0\n' in run.stdout
