from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
scratch=Path('/tmp/issue-1580-research/main-015a6831-runs')
snapshots=sorted(scratch.glob('*.json.gz'));assert snapshots
rows=json.loads(gzip.decompress(snapshots[-1].read_bytes()))
head='015a683197c89e8f74375b097e8dd06a57dcea8f'
push=[row for row in rows if row['headSha']==head and row['event']=='push']
print('EXACT HEAD PUSH RUNS',len(push),'SUCCESS',sum(row['conclusion']=='success' for row in push),flush=True)
failed=[row for row in push if row['conclusion'] not in ['success','skipped']]
assert {row['databaseId'] for row in failed}=={44188508378,44188508650,44188508228}
base=Path('experiments/issue-1580/evidence/ci/main-015a6831');base.mkdir(exist_ok=False)
(base/'all-run-metadata.json.gz').write_bytes(snapshots[-1].read_bytes())
labels={44188508378:'agentic-client-matrix',44188508650:'pipeline',44188508228:'layered'}
receipts=[]
for row in failed:
    identifier=row['databaseId'];label=labels[identifier]
    command=['gh','run','view',str(identifier),'--repo','link-assistant/formal-ai','--json','databaseId,headSha,createdAt,updatedAt,status,conclusion,jobs,url']
    raw=subprocess.check_output(command);details=json.loads(raw)
    assert details['headSha']==head and details['status']=='completed'
    (base/(label+'-metadata.json.gz')).write_bytes(gzip.compress(raw,mtime=0))
    command=['gh','run','view',str(identifier),'--repo','link-assistant/formal-ai','--log']
    raw_path=scratch/(label+'-'+str(identifier)+'.log')
    with raw_path.open('wb') as stream:
        result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
    content=raw_path.read_bytes();target=label+'-'+str(identifier)+'.log.gz'
    (base/target).write_bytes(gzip.compress(content,mtime=0))
    receipt={'run':row,'url':details['url'],'command':command,'exitCode':result.returncode,'archive':target,'rawSha256':hashlib.sha256(content).hexdigest(),'rawBytes':len(content),'rawLines':len(content.splitlines()),'failedJobs':[{'name':job['name'],'conclusion':job['conclusion'],'steps':[step['name'] for step in job['steps'] if step['conclusion'] not in ['success','skipped']]} for job in details['jobs'] if job['conclusion'] not in ['success','skipped']]}
    receipts.append(receipt)
    print(json.dumps(receipt),flush=True)
(base/'download-receipt.json').write_text(json.dumps({'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'pushRuns':len(push),'successes':sum(row['conclusion']=='success' for row in push),'downloads':receipts,'fullManualLogReview':False,'nativeExecutedLocally':False,'independentAuthorshipCredit':0},indent=2)+'\n')
