set -eu
python3 /tmp/issue-1580-research/current-head-status.py 09021cb30ed98851f59f8b55f2cf71470ec613f4
git branch --show-current
git status --short
git log -3 --format='%H %s'
git diff --stat 09021cb30ed98851f59f8b55f2cf71470ec613f4..HEAD
sed -n '1,220p' /tmp/issue-1580-research/archive-and-commit-sixth.py
sed -n '1,160p' /tmp/issue-1580-research/prepush-sixth.sh
sed -n '1,180p' /tmp/issue-1580-research/archive-round-bootstrap.py
