#!/bin/sh
set -eu
sed -n '1,240p' scripts/documentation-only-ci-policy.mjs
sed -n '1,240p' rust/tests/web/documentation-only-ci-policy.test.mjs
rg -n 'fast-linux|native-type-check|pull_request|documentation|paths-ignore|any-code-changed' .github/workflows/release.yml | head -n 70
