from pathlib import Path
import subprocess
for args in [
 ['rg','-n','with_formal_ai_selects_uniform|with_formal_ai_renders_the_same_argv|with_formal_ai_auto_starts|latest_news|issue_1138_family_behaviour','rust/tests'],
 ['rg','-n','structured_log/tests|source_tests/structured_log','rust/src','rust/tests','rust/Cargo.toml'],
 ['rg','-n','FORMAL_AI_OFFLINE|FORMAL_AI_LIVE_FETCH','scripts/run-unit-shard.sh','rust/tests/unit/mod.rs','rust/tests/unit/specification/external_benchmarks.rs'],
 ['git','diff','--stat']]:
 r=subprocess.run(args,text=True,capture_output=True)
 print('SEARCH',args, 'EXIT',r.returncode)
 print(r.stdout[:9000]);print(r.stderr)
