from pathlib import Path
import gzip,json,hashlib
base=Path('experiments/issue-1580/evidence/checks/native-interface-admission/feedback');old=Path('experiments/issue-1580/evidence/checks/native-repair-feedback');manifest=json.loads((base/'manifest.json').read_text())
for name,prior in [('issue-comments','issue-comments'),('pr-comments','pull-request-conversation'),('inline-comments','inline-comments'),('reviews','reviews')]:
 fresh=json.loads((base/(name+'.json')).read_text());previous=json.loads(gzip.decompress((old/(prior+'.json.gz')).read_bytes()));assert [r.get('body')for r in fresh]==[r.get('body')for r in previous],name
 row=next(r for r in manifest['records']if r['name']==name);row['previousBodiesEqual']=True;row['comparedWith']=str(old/(prior+'.json.gz'));print(name,len(fresh),'unchanged')
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('ISSUE',json.loads((base/'issue.json').read_text())['body']);assert json.loads((base/'sub-issues.json').read_text())==[]
