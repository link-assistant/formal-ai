import gzip
import hashlib
import json
import os
import pathlib
import resource
import subprocess
import sys
import time

directory=pathlib.Path("experiments/issue-1580/evidence/checks/generated-header-memory")
label=sys.argv[1]
target=sys.argv[2]
heap=int(sys.argv[3]) if len(sys.argv)>3 else 96
assert not (directory/(label+".json")).exists()
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
command=["timeout","600","node","--max-old-space-size="+str(heap),"--test","--test-concurrency=1",target]
started=time.time()
result=subprocess.run(command,capture_output=True,env=dict(os.environ,NODE_OPTIONS="--max-old-space-size="+str(heap)))
raw=result.stdout+result.stderr
(directory/(label+".log.gz")).write_bytes(gzip.compress(raw,mtime=0))
record={"command":command,"status":result.returncode,"durationSeconds":round(time.time()-started,3),"nodeHeapMiB":heap,"childrenPeakRssKiB":resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,"rawSha256":hashlib.sha256(raw).hexdigest(),"rawBytes":len(raw),"log":label+".log.gz","independentAuthorshipCredit":0}
(directory/(label+".json")).write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record))
for line in raw.decode(errors="replace").splitlines():
    if any(token in line for token in ("✔","✖","# pass","# fail","# skip","ℹ pass","ℹ fail","ℹ skip","AssertionError","Error:")):
        print(line[:500])
sys.exit(result.returncode)
