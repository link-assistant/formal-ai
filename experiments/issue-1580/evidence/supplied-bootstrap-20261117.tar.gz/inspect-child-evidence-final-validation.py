from pathlib import Path
import gzip,json,subprocess
base=Path('experiments/issue-1580/evidence/checks/child-evidence-provenance')
for relative in ['all-gates/results.json','all-gates/executor.log.gz','all-gates/all-gates.log.gz','resumed-validation.json']:
    p=base/relative
    print('\nFILE',p)
    if not p.exists():
        print('PENDING');continue
    raw=gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes()
    print(raw.decode())
print('LOCAL TOOLS')
for args in [['id'],['which','apt-get'],['apt-cache','policy','shellcheck'],['git','status','--short']]:
    p=subprocess.run(args,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    print(args,p.returncode,p.stdout)
print('LINT SCRIPT')
print(Path('scripts/lint-shell-scripts.sh').read_text())
