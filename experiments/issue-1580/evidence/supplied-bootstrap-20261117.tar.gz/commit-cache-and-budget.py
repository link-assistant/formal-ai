from pathlib import Path
import subprocess
root=Path.cwd()
p=root/'data/meta/worker-line-budget/formal_ai_worker_quantity_constraints.lino'
s=p.read_text()
assert 'ceiling 174' in s
s=s.replace('ceiling 174','ceiling 180').replace('tryArithmetic also delegates ordinary expressions to tryArithmeticExpression.', 'tryArithmetic also delegates ordinary expressions to tryArithmeticExpression. Issue #1580 adds six lines reusing existing prime validation before loose arithmetic, matching solver_dispatch::handle_arithmetic in the default JavaScript runtime; no new primality algorithm or global allowance.')
p.write_text(s)
p=root/'changelog.d/20261117_120000_issue-1580-ci-regressions.md'
s=p.read_text()
s+='- Report compiler-cache write errors without asserting unobserved future cache misses, including valid statistics JSON with whitespace.\n'
p.write_text(s)
subprocess.run(['git','add','scripts/check-sccache-write-health.sh','rust/tests/web/sccache-outage-fallback.test.mjs','rust/tests/web/worker-candidate-validation.test.mjs','data/meta/worker-line-budget/formal_ai_worker_quantity_constraints.lino','changelog.d/20261117_120000_issue-1580-ci-regressions.md'],check=True)
subprocess.run(['git','commit','-m','fix(ci): report cache write evidence without inferring future misses'],check=True)
