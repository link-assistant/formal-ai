from pathlib import Path
p=Path('experiments/issue-1580/template-python-runtime.test.mjs');s=p.read_text()
s=s.replace('mkdtempSync, readFileSync, rmSync, writeFileSync','mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync')
marker="import YAML from 'yaml';\n"
s=s.replace(marker,marker+"import {selectFastTests} from '../../scripts/list-fast-pull-request-tests.mjs';\nimport {readTestDurations} from '../../scripts/lib/ci-speed-durations.mjs';\nimport {durationLookup, planShards} from '../../scripts/lib/ci-speed-shards.mjs';\n")
old="  for(const shards of [2,8]){\n    let owners=0;\n    for(let shard=1;shard<=shards;shard++){"
new="""  const durations=join(root,'data/meta/javascript-test-durations.lino');
  const fallback=Number(readFileSync(durations,'utf8').match(/default-seconds ([0-9.]+)/u)[1]);
  for(const shards of [2,8]){
    const files=shards===2
      ? selectFastTests(JSON.parse(readFileSync(join(root,'data/benchmarks/fast-pull-request-javascript-tests.json'),'utf8')))
      : readdirSync(join(root,'rust/tests/web')).filter(name=>name.endsWith('.test.mjs')).map(name=>'rust/tests/web/'+name);
    const selected=planShards(files,shards,durationLookup(readTestDurations(durations),fallback)).shards;
    const owners=selected.flatMap((files,index)=>files.includes(observed)?[index+1]:[]);
    assert.equal(owners.length,1,`${shards} shards execute the Python observations exactly once`);
    const other=selected.findIndex(files=>!files.includes(observed))+1;
    // Exercise both provisioning branches without launching the entire matrix.
    for(const shard of [owners[0],other]){"""
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('const required=selected.includes(observed);if(required)owners++;','const required=selected.includes(observed);')
s=s.replace('    assert.equal(owners,1,`${shards} shards execute the Python observations exactly once`);\n','')
p.write_text(s)
p=Path('.github/workflows/layered-ci.yml');s=p.read_text()
start=s.index('      # Issue #1486:');end=s.index('      - name: Plan this shard',start)
comment=s[start:end];s=s[:start]+s[end:]
marker='      - name: Run the focused tests for the changed components first';s=s.replace(marker,comment+marker);p.write_text(s)
print('Runtime regression now executes the owning and non-owning shard for both profiles (four shell plans).')
