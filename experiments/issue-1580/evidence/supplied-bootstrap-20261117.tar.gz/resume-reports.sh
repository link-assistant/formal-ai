set -eu
cat /tmp/issue-1580-research/go-manual-release-report.md
cat /tmp/issue-1580-research/go-change-detection-report.md
tail -n 8 /tmp/issue-1580-research/all-local-gates-fifth.log
git diff --stat
rg --files docs/case-studies/issue-1580 experiments/issue-1580 changelog.d | rg 'README|plan|archive|manifest|1580|20261117' | head -n 55
