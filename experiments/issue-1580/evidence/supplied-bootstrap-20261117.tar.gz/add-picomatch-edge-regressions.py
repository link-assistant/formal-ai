from pathlib import Path
import shutil,subprocess,json,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'rust/tests/web/picomatch-security-backport.test.mjs'
s=p.read_text()
s=s.replace("'+(@(*a))'];","'+(@(*a))', '+([[]*a)', '+([*a)', '+([[:alpha:]]*a)'];")
s=s.replace("assert.equal(picomatch.isMatch('aaaa', pattern), false);", """assert.equal(picomatch.isMatch('aaaa', pattern), false);
    assert.equal(picomatch.isMatch('[aaa', pattern), false);
    const literal = pattern.replace(/[|\\\\{}()[\\]^$+*?.]/g, '\\\\$&');
    assert.equal(picomatch.makeRe(pattern).source, '^(?:' + literal + ')$');""")
s=s.replace("assert.equal(picomatch.isMatch('***', '+([*])'), true);", """assert.equal(picomatch.isMatch('***', '+([*])'), true);
  assert.equal(picomatch.isMatch('a*a*', '+("a*")'), true);
  assert.equal(picomatch.isMatch('ab', '+([[:alpha:]])'), true);""")
p.write_text(s)
e=r/'experiments/issue-1580/evidence/checks/picomatch-single-branch'
for suffix in ['json','log.gz']:
    shutil.copy2(e/('after.'+suffix),e/('initial-after.'+suffix))
log=Path('/tmp/issue-1580-research/picomatch-edge-before.log')
with log.open('w') as out:
    cp=subprocess.run(['timeout','600','node','--max-old-space-size=96','--test','--test-concurrency=1',str(p)],stdout=out,stderr=subprocess.STDOUT,cwd=r)
print(log.read_text())
print(json.dumps({'exitCode':cp.returncode,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}))
