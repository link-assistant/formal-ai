from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,os,subprocess,time
root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/checks/data-file-native-replay'
base.mkdir(exist_ok=False)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='4d105df788a398c6c26a9431393622bb4206dbfe'
assert json.loads(Path('/tmp/issue-1580-research/unknown-role-publication-recheck/outcome.json').read_text())['complete']
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
records=[]
def run(name,args):
 started=time.monotonic()
 p=subprocess.run(args,cwd=root,env=env,capture_output=True)
 row={'name':name,'argv':args,'exitCode':p.returncode,'seconds':round(time.monotonic()-started,3)}
 for kind,raw in [('stdout',p.stdout),('stderr',p.stderr)]:
  packed=gzip.compress(raw,mtime=0)
  filename=name+'.'+kind+'.gz'
  (base/filename).write_bytes(packed)
  row[kind]={'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'lines':len(raw.splitlines())}
 records.append(row)
 (base/'draft-results.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps({'name':name,'exitCode':p.returncode,'seconds':row['seconds']}),flush=True)
 return p
policy=root/'rust/tests/web/default-branch-build-policy.test.mjs'
text=policy.read_text()
needle='--test cnl_parity --test unknown_reasoning -- --test-threads=1'
assert text.count(needle)==1
text=text.replace(needle,'--test cnl_parity --test unknown_reasoning --test data_files -- --test-threads=1')
text+='''

test('native data-file regressions select every consumed source and data format', () => {
  for (const path of ['rust/tests/unit/data_files.rs', 'rust/tests/unit/data_files/technical_scalar.rs',
    'data/seed/meanings-calendar.lino', 'data/meta/technical-scalar-contracts.lino',
    'data/cache/wikidata/entity/Q146786.lino', 'data/cache/wikidata/entity/Q146786.json',
    'data/cache/wiktionary/en/example.json', 'data/parity/fixture.lino', 'data/seed/api-cache/fixture.bin'])
    assert.equal(admission([path])['native-type-check'], true, path);
  for (const path of ['data/benchmarks/fixture.json', 'data/meta/fixture.txt',
    'data/cache/fixture.txt', 'rust/tests/unit/unrelated.rs'])
    assert.equal(admission([path])['native-type-check'], false, path);
});
'''
text=text.replace("'data/meta/x.lino', 'experiments/a/b.sh'","'data/meta/x.txt', 'experiments/a/b.sh'")
policy.write_text(text)
command=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',str(policy.relative_to(root))]
before=run('policy-before',command)
assert before.returncode!=0
workflow=root/'.github/workflows/native-type-check.yml'
text=workflow.read_text()
assert text.count(needle)==1
workflow.write_text(text.replace(needle,'--test cnl_parity --test unknown_reasoning --test data_files -- --test-threads=1'))
manifest=root/'rust/Cargo.toml'
text=manifest.read_text()
needle='[[test]]\nname = "unknown_reasoning"\npath = "tests/unit/specification/unknown_reasoning.rs"\n'
assert text.count(needle)==1
text=text.replace(needle,needle+'\n# Replay the unchanged data contracts, including their technical-scalar controls.\n[[test]]\nname = "data_files"\npath = "tests/unit/data_files.rs"\n')
manifest.write_text(text)
admission=root/'scripts/ci-pull-request-admission.mjs'
text=admission.read_text()
needle="  'rust/tests/unit/specification/unknown_reasoning.rs',"
assert text.count(needle)==1
text=text.replace(needle,needle+"\n  'rust/tests/unit/data_files.rs',\n  'rust/tests/unit/data_files/technical_scalar.rs',")
needle="  if (path.startsWith('data/')) return path.startsWith('data/seed/api-cache/');"
assert text.count(needle)==1
text=text.replace(needle,"  // The isolated data-file target parses all LiNo and cached source JSON.\n  if (path.startsWith('data/')) return path.endsWith('.lino')\n    || (path.startsWith('data/cache/') && path.endsWith('.json'))\n    || path.startsWith('data/seed/api-cache/');")
admission.write_text(text)
after=run('policy-after',command)
assert after.returncode==0
formatting=run('unchanged-native-formatting',['rustfmt','--edition','2024','--check',
 'rust/tests/unit/data_files.rs','rust/tests/unit/data_files/technical_scalar.rs'])
assert formatting.returncode==0
unchanged=[]
for name in ['rust/tests/unit/data_files.rs','rust/tests/unit/data_files/technical_scalar.rs']:
 raw=(root/name).read_bytes()
 parent=subprocess.check_output(['git','show','4d105df788a398c6c26a9431393622bb4206dbfe:'+name],cwd=root)
 assert raw==parent
 original=subprocess.check_output(['git','show','015a6831:'+name],cwd=root)
 unchanged.append({'path':name,'publishedSourceSha256':hashlib.sha256(raw).hexdigest(),
 'originalSourceSha256':hashlib.sha256(original).hexdigest(),'unchangedFromPublishedHead':True,'unchangedFromOriginalMain':raw==original})
(root/'changelog.d/issue-1580-data-file-native-replay.md').write_text('Admit the existing native data-file contracts and their consumed Links Notation and cached JSON sources to the focused pull-request check. Replay the original meaning-identity, pipe-list and canonical-notation failures without compiling the full unit target.\n')
raw=gzip.decompress((root/'experiments/issue-1580/evidence/ci/main-015a6831/pipeline-44188508650.log.gz').read_bytes())
lines=raw.decode().splitlines()
spans=[]
for start,end in [(65551,65554),(65580,65585),(65613,65618)]:
 spans.append({'startLine':start,'endLine':end,'lines':lines[start-1:end]})
(base/'original-failure-source-review.json').write_text(json.dumps({'originalLogSha256':hashlib.sha256(raw).hexdigest(),
 'originalLogLines':len(lines),'literalSpansReviewed':spans,'currentSources':unchanged,'existingTargetTests':22,
 'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0,'observedAt':datetime.now(timezone.utc).isoformat()},indent=2)+'\n')
print(json.dumps({'targetTests':22,'sourceBytes':unchanged,'nativeExecutedLocally':False,'governedWitnessRefresh':'pending'}))
