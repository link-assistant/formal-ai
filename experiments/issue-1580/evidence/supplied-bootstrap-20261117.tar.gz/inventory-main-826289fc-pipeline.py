import collections, gzip, hashlib, json, pathlib, re

root = pathlib.Path('experiments/issue-1580/evidence/ci/main-826289fc')
lines = pathlib.Path('/tmp/issue-1580-research/pipeline-44157125186.log').read_text().splitlines()
failures, results, errors = [], [], []
for n, line in enumerate(lines, 1):
    if re.search(r'test .+ \.\.\. FAILED$', line):
        failures.append({'line': n, 'job': line.split('\t')[0], 'test': re.search(r'test (.+) \.\.\.', line)[1]})
    if 'panicked at ' in line:
        print(f'{n}: {line}')
    if 'test result: FAILED' in line or ('##[error]' in line and 'Process completed' not in line):
        print(f'{n}: {line[:900]}')
        results.append({'line': n, 'text': line})
    if re.search(r'(timed out|TIMEOUT|SIGKILL|signal: 9|error: test failed|Command exited with non-zero)', line):
        errors.append({'line': n, 'text': line})
print(f'FAILED TEST IDENTITIES {len(failures)}')
for failure in failures:
    print(json.dumps(failure))
for row in errors:
    print(f'{row["line"]}: {row["text"][:1100]}')
old = json.loads(pathlib.Path('experiments/issue-1580/evidence/ci/main-512ce428/native-failure-inventory.json').read_text())
print('OLD INVENTORY ROOT', type(old).__name__, list(old)[:12] if isinstance(old, dict) else len(old))
(root / 'pipeline-native-failure-inventory.json').write_text(json.dumps({'failures': failures, 'results': results, 'errors': errors}, indent=2) + '\n')
