from pathlib import Path
import gzip,json,re
p=Path('.github/workflows/release.yml');text=p.read_text()
old='''      - {uses: actions/checkout@v7, timeout-minutes: 4,
         env: {GIT_HTTP_LOW_SPEED_LIMIT: '1024', GIT_HTTP_LOW_SPEED_TIME: '20'},
         with: {persist-credentials: false, fetch-depth: 1, filter: blob:none, sparse-checkout: "/*\\n!/dev/log/\\n!/experiments/formal_ai_subagent/evidence/coordinator-1188/**/*.gz\\n", sparse-checkout-cone-mode: false}}
'''
assert text.count(old)==1
patterns=['/*','!/dev/log/']+['!/'+scope+'/**/*.'+ext for scope in ['docs/case-studies','experiments/*/evidence'] for ext in ['gz','log','zip','tgz','diff']]
replacement='''      - uses: actions/checkout@v7
        timeout-minutes: 4
        env: {GIT_HTTP_LOW_SPEED_LIMIT: '1024', GIT_HTTP_LOW_SPEED_TIME: '20'}
        with:
          persist-credentials: false
          fetch-depth: 1
          filter: blob:none
          # Keep every measured source; these historical payloads are not inputs to this job.
          sparse-checkout: |
'''+''.join('            '+pattern+'\n' for pattern in patterns)+'''          sparse-checkout-cone-mode: false
'''
p.write_text(text.replace(old,replacement))
p=Path('rust/tests/web/fast-pull-request-production-profile.test.mjs');text=p.read_text()
old="    assert.match(file,/^experiments\\/formal_ai_subagent\\/evidence\\/coordinator-1188\\/.*[.]gz$/u);"
new="    assert.match(file,/^(?:docs\\/case-studies\\/|experiments\\/[^/]+\\/evidence\\/).*\\.(?:gz|log|zip|tgz|diff)$/u);"
assert text.count(old)==1;p.write_text(text.replace(old,new))
base=Path('experiments/issue-1580/evidence/checks/fast-source-archive-checkout')
receipt=base/'before-profile.json';value=json.loads(receipt.read_text());raw=gzip.decompress((base/'before-profile.log.gz').read_bytes()).decode()
value['counts']={name:int(count) for name,count in re.findall(r'^ℹ (tests|pass|fail|skipped) (\d+)$',raw,re.M)}
assert value['counts']=={'tests':16,'pass':15,'fail':1,'skipped':0};receipt.write_text(json.dumps(value,indent=2)+'\n')
print('Expanded only fast-source historical archive omissions; retained original checkout/network clocks, ref, credentials, measured sources and all job commands.')
