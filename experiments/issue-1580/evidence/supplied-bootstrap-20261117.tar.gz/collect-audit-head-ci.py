from pathlib import Path

source = Path('/tmp/issue-1580-research/collect-python-fragment-head-ci.py').read_text()
source = source.replace('624812120feee0180bf9df8164f87e73326b5cb8', '1cc2d536ac11e26602cc55a40dffb61716233aa6').replace('ci/624812120', 'ci/1cc2d536a')
source = source.replace("'abbreviation ratchet',", "'abbreviation ratchet','audit inventory','npm audit','python git','python runtime',")
exec(compile(source, __file__, 'exec'))
