from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research/seeded-scheduling-refactor-validation')
for name in ['validation-outcome.json','failure.json']:
 p=scratch/name
 if p.exists():print(name,p.read_text())
print(subprocess.run(['ps','-p','1986983','-o','pid,stat,etime,args'],text=True,capture_output=True).stdout)
for cmd in [['git','branch','--show-current'],['git','-c','gc.auto=0','fetch','origin','main'],['git','rev-parse','origin/main'],['git','merge-base','--is-ancestor','origin/main','HEAD']]:
 r=subprocess.run(cmd,cwd=root,text=True,capture_output=True);print(json.dumps({'argv':cmd,'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}));assert r.returncode==0
