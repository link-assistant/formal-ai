from pathlib import Path
import subprocess,json
b=Path('/tmp/issue-1580-research/templates')
for local in ['js-complete','python-complete','cpp-complete']:
 print(local)
 cp=subprocess.run(['rg','--hidden','-n','--glob','!dev/log/**','--glob','!docs/**','--glob','!**/dist/**','--glob','!**/package-lock.json','--glob','!.git/**','audit|npm ci|bun install|secretlint',str(b/local/'.github')],text=True,capture_output=True)
 lines=cp.stdout.splitlines()
 print('\n'.join(lines[:70]))
 print('match lines',len(lines))
for p in sorted(Path('/tmp/issue-1580-research/picomatch-template-research').glob('*-audit.json')):
 d=json.loads(p.read_text())
 advisories={v.get('url') for row in d.get('vulnerabilities',{}).values() for v in row.get('via',[]) if isinstance(v,dict)}
 print(p.name,'unique advisories',sorted(advisories),'vulnerable nodes',list(d.get('vulnerabilities',{})))
r=Path('/tmp/gh-issue-solver-1794900398048')
cp=subprocess.run(['rg','--files','docs/case-studies/issue-1580/templates','experiments/issue-1580/upstream'],cwd=r,text=True,capture_output=True)
print('\n'.join(cp.stdout.splitlines()[:60]))
