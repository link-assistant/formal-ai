from pathlib import Path
import gzip,hashlib,json,subprocess

base=Path('experiments/issue-1580/evidence/checks/csharp-changeset-collision')
receipt=base/'abbreviation-filename-correction.json'; value=json.loads(receipt.read_text())
commands=[('abbreviation-regression',['timeout','600','node','--test','--test-reporter=tap','--test-concurrency=1','rust/tests/web/abbreviations.test.mjs'])]
for gate in ['check-abbreviations','check-file-size','check-file-size-js-twin']:
 commands.append((gate,['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]))
results=[]
for label,command in commands:
 r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log=base/(label+'-after.log.gz'); log.write_bytes(gzip.compress(r.stdout,mtime=0))
 result={'label':label,'command':command,'exitCode':r.returncode,'log':str(log),'rawSha256':hashlib.sha256(r.stdout).hexdigest(),'rawLines':len(r.stdout.splitlines())}
 results.append(result); print(json.dumps(result)); print(r.stdout.decode()[-3500:])
 assert r.returncode==0
value['after']=results; value['claim']='Existing abbreviation regression and touched local gates pass after the byte-preserving rename, with the ratchet baseline unchanged. This does not establish final-head hosted CI or complete issue 1580.'
receipt.write_text(json.dumps(value,indent=2)+'\n')
