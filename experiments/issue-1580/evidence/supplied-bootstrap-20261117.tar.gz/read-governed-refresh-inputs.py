from pathlib import Path
import subprocess

for name in ['scripts/lib/regenerate-governed-specification.mjs','scripts/refresh-release-specification-witness.mjs','experiments/issue-1571/governed-witness-delta.mjs','experiments/issue-1487/governed-witness-delta.mjs']:
    path=Path(name)
    lines=path.read_text().splitlines()
    print('SOURCE',name,'LINES',len(lines))
    assert len(lines)<500
    print(path.read_text())
path=Path('experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8')
print('WITNESS BYTES',path.stat().st_size)
lines=Path('/tmp/issue-1580-research/layered-44156399182.log').read_text().splitlines()
print('REMAINING ERROR DELTA LINES 8251-8447')
for number in range(8251,8448):
    payload=lines[number-1].split('\t',2)[-1]
    if payload.count('[Object]')>2:continue
    print(f'{number}: {payload}')
