from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/calendar-dispatch-registration/final-validation';rows=json.loads((base/'records.json').read_text());assert len(rows)>=12 and all(r['exitCode']==0 for r in rows)
def run(args):return subprocess.check_output(args,cwd=root,text=True).strip()
assert run(['git','branch','--show-current'])=='issue-1580-8d61a32a61e1';assert run(['git','rev-parse','HEAD'])=='86dcf79d3e424b7309361f95a5c967782ff24846';assert not run(['git','diff','--cached','--name-only'])
groups=[('Register calendar creation with shared promotion evidence',[
 'data/seed/browser-handler-precedence.lino','data/seed/handler-promotions.lino','rust/embedded/data/seed/handler-promotions.lino','rust/tests/web/calendar-act-paraphrases.test.mjs','changelog.d/issue-1580-worker-calendar-dispatch.md']),
 ('Replay unchanged shell and download contracts in native CI',[
 '.github/workflows/native-type-check.yml','rust/Cargo.toml','scripts/ci-pull-request-admission.mjs','rust/tests/unit/operational_contracts.rs','rust/tests/web/default-branch-build-policy.test.mjs','changelog.d/issue-1580-operational-native-replay.md','experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8'])]
records=[]
for message,paths in groups:
 hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths};run(['git','add','--',*paths]);assert set(run(['git','diff','--cached','--name-only']).splitlines())==set(paths);run(['git','diff','--cached','--check']);print(run(['git','-c','gc.auto=0','commit','-m',message]));records.append({'head':run(['git','rev-parse','HEAD']),'message':message,'sourceSha256':hashes,'pushExecuted':False,'independentAuthorshipCredit':0})
(base/'source-commits.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records,indent=2))
