from pathlib import Path
import json
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  args=(proc/'cmdline').read_bytes().split(b'\0')
  if b'/tmp/issue-1580-research/check-sparse-fast-source-commands.py' not in args:continue
  details={}
  for line in (proc/'status').read_text().splitlines():
   if line.split(':',1)[0] in ['Name','State','PPid','VmRSS','VmPeak']:k,v=line.split(':',1);details[k]=v.strip()
  print(json.dumps({'pid':int(proc.name),'details':details}))
 except (FileNotFoundError,PermissionError):pass
p=Path('experiments/issue-1580/evidence/checks/fast-source-archive-checkout/sparse-source-commands.json')
print('Receipt exists:',p.exists())
