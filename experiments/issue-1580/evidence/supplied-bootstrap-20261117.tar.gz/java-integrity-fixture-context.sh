set -eu
cat experiments/issue-1580/fixtures/java-template/source.json
cat experiments/issue-1580/template-go-result-integrity.test.mjs
cat rust/tests/web/issue-1580-template-observations.test.mjs
sed -n '900,995p' scripts/version-and-commit.rs
cat /tmp/issue-1580-research/templates/java-complete/scripts/github-actions-log.mjs
sed -n '66,100p' /tmp/issue-1580-research/templates/java-complete/src/main/java/com/linkfoundation/mypackage/MyPackage.java
