from pathlib import Path
import hashlib,json,gzip
root=Path.cwd(); research=Path('/tmp/issue-1580-research')
checks=root/'experiments/issue-1580/evidence/checks'
records=[]
for name in ['go-pin-integrity.log','template-observations-seventh.log']:
 data=(research/name).read_bytes(); compressed=gzip.compress(data,mtime=0)
 destination=checks/(name+'.gz'); destination.write_bytes(compressed)
 records.append({'file':str(destination.relative_to(root)),'sha256':hashlib.sha256(compressed).hexdigest(),'originalSha256':hashlib.sha256(data).hexdigest(),'originalBytes':len(data)})
(checks/'go-pin-integrity.json').write_text(json.dumps({'scope':'Offline source-fixture regression; registry/tag verification boundaries injected, not hosted execution.','goTests':5,'maintainedEntrypointTests':11,'failures':0,'runtimeSkips':0,'logs':records},indent=2)+'\n')
p=root/'docs/case-studies/issue-1580/templates/go-semantic-review.json'
data=json.loads(p.read_text());data['verification']='Pinned blob hashes checked per read page and again for all 42 records; Go regression file passes five cases and the maintained fast-PR entrypoint passes eleven, with zero failures/skips. Current/stale integrity negative controls use injected lookup/verification boundaries. No upstream workflow or complete upstream suite execution is claimed.'
p.write_text(json.dumps(data,indent=2)+'\n')
p=root/'docs/case-studies/issue-1580/templates/README.md';text=p.read_text();assert 'Its ten local tests all passed' in text
text=text.replace('Its ten local tests all passed','Its eleven local tests all passed')
text+='''
## Complete Go source review

[`go-semantic-review.json`](go-semantic-review.json) records every one of the pinned Go tree's 42 blobs, its verified identity, role, corresponding Formal AI paths and transfer decision. All three workflows and their local helpers/tests/configuration were read completely. The review preserves default-branch build restrictions, publication/source receipts, expected optional skips, bounded retries and conservative runner-acquisition classification. Missing Go workflow timeouts already have upstream issue #17. Seven other complete semantic reviews remain unfinished; lexical graphs do not complete them.

The new fifth Go regression executes the unchanged dependency checker and reporter. A current invalid pin invokes verification and fails all four events. A stale invalid pin bypasses verification and passes push/schedule/dispatch, failing only PR freshness policy. Removing just the early `continue` in a disposable copy restores integrity failure for both versions while retaining intended stale-only warnings. Registry/tag results are injected: this proves the control-flow defect, not a real remote tag mismatch or a hosted workflow result. Full logs and hashes are indexed in `experiments/issue-1580/evidence/checks/go-pin-integrity.json`. The upstream report draft is retained under `experiments/issue-1580/upstream/`; it is not yet filed and no upstream repair is claimed.
'''
p.write_text(text)
p=root/'docs/case-studies/issue-1580/README.md';text=p.read_text();needle='## Full template comparison';assert needle in text
text=text.replace(needle,'''## Go source and integrity checkpoint

All 42 pinned Go template files have now been read, compared by role/behavior and recorded in [the per-file review](templates/go-semantic-review.json). Seven complete template semantic reviews remain open. The maintained template entrypoint passes eleven tests without runtime skips. Its added combined stale-version/bad-pin case reproduces an integrity check bypass on non-PR events, with current-pin failure and freshness-only warning controls. A one-line candidate repair is tested only in a disposable fixture copy; no remote template repair or hosted publication is claimed. The report is drafted pending publication of immutable executable evidence. Full regression logs and hashes are retained in `checks/go-pin-integrity.json`.

'''+needle)
p.write_text(text)
p=root/'experiments/issue-1580/work-plan.md';p.write_text(p.read_text()+'''
## Complete Go source review and combined integrity regression

Read and compare all 42 Go blobs, including all three workflows and local CI helpers/tests/configuration; preserve per-file identities and decisions. Seven other complete semantic reviews remain open. Execute the unchanged dependency checker with a stale version and injected bad-pin result, compare its current-version failure, and verify the disposable one-line candidate repair retains freshness-only warning policy. The Go file passes five tests; the maintained fast-PR entrypoint passes eleven, zero failures/skips. Retain complete logs and draft the distinct upstream report; file only after immutable executable evidence is pushed. This does not change production Formal AI dependency policy or complete native/benchmark/live-identity acceptance criteria. Supplied review/probe scripts earn zero independent Formal AI reasoning credit.
''')
p=root/'changelog.d/20261117_120000_issue-1580-ci-regressions.md';p.write_text(p.read_text()+'- Record the complete Go template source comparison and reproduce its combined stale-version/pin-integrity bypass with independent failure and warning controls.\n')
report=root/'experiments/issue-1580/upstream/go-stale-pin-integrity-report.md'
report.write_text('''The dependency checker skips pin integrity verification whenever the declared version is stale. This turns an invalid action pin into a warning-only result on push, schedule and workflow_dispatch.

Source reviewed: `65c686846d7327d8c835a0d30b1a76cc6345cfc6`, `scripts/ci/check-dependencies.mjs` (Git blob `62397dcfdd1b1173b16bcb2e750903066695d4e4`). The latest related merged PR #16 introduced the freshness warning policy; this issue concerns its interaction with integrity checking.

In `checkDependencies`, the version-mismatch branch appends a stale finding and then `continue`s before `verifyPin`. The reporter treats stale-only findings as warnings on non-PR events. Integrity verification must run independently of freshness policy.

Bounded offline reproduction using the actual unchanged source and reporter:

| Lookup result / injected verification result | Verification calls | Push / schedule / dispatch | Pull request |
| --- | ---: | --- | --- |
| Current / invalid pin | 1 | failure | failure |
| Stale / invalid pin | 0 | success | failure (freshness) |

Removing only that `continue` in a disposable source copy invokes verification and fails all four events for invalid pins. Current valid pins remain successful; stale valid pins retain the intended warning-only success outside PRs.

The regression injects lookup and tag-verification results through the checker's existing test seams. It does not claim a real remote tag mismatch, execute hosted workflows, publish anything or modify this repository. It also tests the valid-pin/freshness controls to distinguish an integrity regression from the intended non-PR warning policy.

Executable evidence is in link-assistant/formal-ai PR #1581: `experiments/issue-1580/template-go-result-integrity.test.mjs`, case `Go stale-pin integrity failures become warnings; independent verification preserves failures`. The adjacent fixture retains the original license and source hashes. Run `node --test --test-concurrency=1 experiments/issue-1580/template-go-result-integrity.test.mjs` in that checkout. Its five cases pass locally; the maintained fast-PR entrypoint also passes eleven cases without skips. The complete log/hash index is `experiments/issue-1580/evidence/checks/go-pin-integrity.json`.

Permanent evidence commit/link will be added before filing this report. No upstream fix is claimed.
''')
print(json.dumps({'archivedLogs':len(records),'goFilesReviewed':len(data['files']),'maintainedTests':11,'reportFiled':False}))
