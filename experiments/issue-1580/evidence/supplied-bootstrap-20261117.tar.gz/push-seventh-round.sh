set -eu
test "$(git branch --show-current)" = issue-1580-8d61a32a61e1
test -z "$(git status --porcelain)"
git merge-base --is-ancestor origin/main HEAD
gh run list --repo link-assistant/formal-ai --branch "$(git branch --show-current)" --status in_progress --limit 100 --json databaseId,workflowName > /tmp/issue-1580-research/push-seventh-active.json
gh run list --repo link-assistant/formal-ai --branch "$(git branch --show-current)" --status queued --limit 100 --json databaseId,workflowName > /tmp/issue-1580-research/push-seventh-queued.json
python3 -c 'import json; from pathlib import Path; assert all(not json.loads(Path("/tmp/issue-1580-research/push-seventh-"+s+".json").read_text()) for s in ["active","queued"]); print("Both branch run lists are empty.")'
git push origin HEAD:issue-1580-8d61a32a61e1
git rev-parse HEAD
git status --short
