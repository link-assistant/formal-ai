from pathlib import Path
import json,subprocess
base=Path('/tmp/issue-1580-research/java-context');base.mkdir(exist_ok=True)
repo='link-foundation/java-ai-driven-development-pipeline-template'
for label,path in [('issues',f'repos/{repo}/issues?state=all&per_page=100'),('pulls',f'repos/{repo}/pulls?state=closed&sort=updated&direction=desc&per_page=100')]:
 rows=json.loads(subprocess.check_output(['gh','api',path,'--paginate','--slurp'],text=True));rows=[row for page in rows for row in page]
 (base/(label+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
 if label=='issues':
  for row in rows:
   if 'pull_request' not in row:print(json.dumps({'number':row['number'],'title':row['title'],'body':row['body'],'comments':row['comments']}))
 else:print('latest merged',json.dumps([{'number':row['number'],'title':row['title'],'mergedAt':row['merged_at']} for row in rows if row['merged_at']][:5]))
head=json.loads(subprocess.check_output(['gh','api',f'repos/{repo}/commits/HEAD'],text=True))
print('current HEAD',head['sha'])
