from pathlib import Path
import json,subprocess
base=Path('experiments/issue-1580/evidence/checks/child-evidence-provenance')
result=json.loads((base/'completed-local-validation.json').read_text())
assert result['inventoryEntries']==138 and result['allExecutableEntriesPassingAfterEnvironmentRepair']
checkpoint=Path('docs/case-studies/issue-1580/child-evidence-checkpoint.md')
text=checkpoint.read_text()
start=text.index('The initial focused run passes')
end=text.index('\n## Limits',start)
replacement='''The final focused run passes all 13 executor tests, including explicit evidence
assertions on both the cached candidate and its source. The 15 adjacent factual-QA
tests, both existing shared-fixture checks, specification fixture integrity and
Rust 2024 formatting pass. The original 29 fixture cases and event traces remain
unchanged. Regenerate the stale JavaScript-to-Rust projection with the maintained,
pinned translator; its verification passes. Preserve the original stale-projection
failure and its successful correction separately.

The required full shared-data inventory records 85 passes, 52 explicit native or
CI-context exclusions and one missing local ShellCheck failure. Restore the
official ShellCheck release, verify its archive against GitHub's SHA-256 digest,
then pass the remaining gate over all 70 maintained shell scripts. Thus all 86
executable entries pass. Preserve the original aggregate, every individual gate
log and the focused correction with hashes; literal review covers the aggregate
and failed payload, not all successful individual payloads. Expand abbreviated
archive filenames without changing their bytes and retain alias receipts. No
local native build runs; the fifth native executor test still awaits CI.
'''
checkpoint.write_text(text[:start]+replacement+text[end:])
plan=Path('experiments/issue-1580/work-plan.md')
text=plan.read_text()
print('EXISTING SELECTED CHILD CHECKLIST')
anchor=text.index('Selected-child evidence preservation')
print(text[anchor:anchor+2400])
text=text.replace('- [ ] Refresh the maintained JavaScript-to-Rust projection and run the full shared-data local gate inventory.', '- [x] Refresh the maintained JavaScript-to-Rust projection and run the full shared-data local gate inventory: 85 initial passes, 52 explicit exclusions and one missing ShellCheck failure; after restoring the verified official binary, the final executable gate passes. Preserve all failures and corrections separately.')
plan.write_text(text)
body=Path('experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md')
text=body.read_text()
needle='Latest reproduction and verification:\n\n'
assert needle in text
row='- The selected-child evidence regression records **10 passes / 3 failures before** and **13/13 afterward**, including cached source evidence and exclusion of unused alternatives. All **15 adjacent factual-QA tests**, both shared-fixture currency checks, specification fixture integrity, Rust 2024 formatting and maintained projection verification pass. The complete 138-entry local inventory initially records **85 passes, 52 explicit exclusions and one missing ShellCheck failure**; after installing the official digest-verified tool, the remaining gate passes over all 70 shell scripts. All **86 executable entries** therefore pass. Initial failures and corrections remain separate. The fifth native executor test awaits hosted execution; no local Rust build runs.\n'
text=text.replace(needle,needle+row)
text=text.replace('The proposed JavaScript checkout excludes','The published JavaScript checkout excludes')
link='[selected-child evidence checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/child-evidence-checkpoint.md)'
text=text.replace('The [quotation checkpoint]','The '+link+', [quotation checkpoint]')
assert text.count('Fixes #1580')==1
body.write_text(text)
print('DOCUMENT DIFF')
subprocess.run(['git','diff','--','docs/case-studies/issue-1580/child-evidence-checkpoint.md','experiments/issue-1580/work-plan.md','experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md'],check=True)
print('COMPLETE CHILD CHECKPOINT\n'+checkpoint.read_text())
for name in ['java-historical-forward-review-002.json','java-historical-review-index.json']:
    print(name+'\n'+(Path('docs/case-studies/issue-1580/templates')/name).read_text())
