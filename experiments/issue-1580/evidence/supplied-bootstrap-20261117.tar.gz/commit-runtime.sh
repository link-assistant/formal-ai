#!/bin/sh
set -eu
node scripts/translate-js-rust.mjs --verify
git diff --check
git add changelog.d/20261117_120000_issue-1580-ci-regressions.md data/benchmarks/fast-pull-request-javascript-tests.json data/meta/main-only-regressions.lino data/meta/runtime-feature-coverage.json data/meta/translation-blockers.lino js/agentic/crate/meta_executor.mjs js/server/worker-script-prerequisites.mjs js/worker-script-prerequisites.js js/worker/formal_ai_worker_concept_queries_and_arithmetic.js js/worker/formal_ai_worker_crate_meta_executor.js js/worker/formal_ai_worker_quantity_constraints.js js/worker/formal_ai_worker_solve.js rust/src/concepts.rs rust/src/meta_executor.rs rust/src/meta_executor/production.rs rust/src/solver.rs rust/src/solver_dispatch.rs rust/src/solver_helpers/mod.rs rust/src/solver_synthesis.rs rust/tests/fixtures/js-rust-translation/crate/meta_executor.rs rust/tests/fixtures/synthesis-parent-tests.rs rust/tests/unit/concept_lookup_response_language.rs rust/tests/unit/meta_executor_parity.rs rust/tests/web/issue-1580-production-composition.test.mjs rust/tests/web/worker-candidate-validation.test.mjs ts/agentic/crate/meta_executor.mts ts/server/worker-script-prerequisites.mts ts/worker-script-prerequisites.ts ts/worker/formal_ai_worker_concept_queries_and_arithmetic.ts ts/worker/formal_ai_worker_crate_meta_executor.ts ts/worker/formal_ai_worker_quantity_constraints.ts ts/worker/formal_ai_worker_solve.ts
git diff --cached --stat
git commit -m 'fix(solver): preserve concrete contracts and validated number intents'
git add rust/tests/unit/issue_1133_hive_mind_three_runs.rs rust/tests/unit/issue_1133_hive_mind_three_runs/extended.rs
git commit -m 'test(agent): replay source receipts and canonical workflow ownership'
