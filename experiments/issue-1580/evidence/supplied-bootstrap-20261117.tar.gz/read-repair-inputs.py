from pathlib import Path
import gzip

folder = Path('/tmp/issue-1580-research/head-71e1dee44')
for path in folder.glob('*44071444011*.gz'):
    with gzip.open(path, 'rt') as stream:
        for number, line in enumerate(stream, 1):
            if 1090 <= number <= 1143:
                print(f'{number}: {line}', end='')
for name in [
    'experiments/issue-1580/compare-template-trees.mjs',
    'experiments/issue-1580/template-inventory-integrity.test.mjs',
    'experiments/issue-1580/trace-template-ci.mjs',
]:
    print(f'\nFILE {name}')
    for number, line in enumerate(Path(name).read_text().splitlines(), 1):
        print(f'{number}: {line}')
