set -eu
cat /tmp/issue-1580-research/check-chrono-upstream.py
cat /tmp/issue-1580-research/chrono-dependency-closure.py
cat .github/actions/setup-sccache/action.yml
cat scripts/check-sccache-write-health.sh
