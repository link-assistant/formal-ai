from pathlib import Path
p=Path('rust/tests/web/recipe-resume-policy-notation.test.mjs')
s=p.read_text().replace('decodes one working pattern', 'decodes every supported handoff')
a=s.index(' const patterns=JSON.parse')
b=s.index('\n install();',a)
s=s[:a]+''' const patterns=JSON.parse(childValue(policy,'prepared-pull-request-patterns'));
 const forms=['prepared pull request: '+pull,'Your prepared pull request: '+pull,
  'Update the pull request at '+pull+'.'];
 assert.ok(patterns.length>0);
 for(const form of forms){
  const matches=patterns.map(pattern=>new RegExp(pattern,'iu').exec(form)).filter(Boolean);
  assert.equal(matches.length,1,form);assert.equal(matches[0][1],pull);
 }
 for(const pattern of patterns)assert.ok(forms.some(form=>new RegExp(pattern,'iu').test(form)));
''' .rstrip()+s[b:]
s=s.replace("for(const request of ['prepared pull request: '+pull,'Your prepared pull request: '+pull,", "for(const request of [...forms,")
s=s.replace(" assert.equal(recipeDeliveryReference('Your prepared pull request: '+pull+'\\nYour prepared pull request: https://github.com/o/r/pull/3',issue).kind,'refused');", " assert.equal(recipeDeliveryReference('Your prepared pull request: '+pull+'\\nYour prepared pull request: https://github.com/o/r/pull/3',issue).kind,'refused');\n assert.equal(recipeDeliveryReference('Your prepared pull request: '+pull+'\\nUpdate the pull request at https://github.com/o/r/pull/3.',issue).kind,'refused');")
p.write_text(s)
p=Path('rust/tests/web/connector-work-item-receipts.test.mjs')
s=p.read_text().replace("import {Progress}", "import {recipeSourceCommand} from '../../../js/agentic/recipe_resume.mjs';\nimport {Progress}")
s=s.replace(' const plan=await planChatStepResolved(messages(JSON.stringify(data)),tools);\n assert.equal(plan.kind', ''' const input=messages(JSON.stringify(data));
 const probe=await planChatStepResolved(input,tools);
 assert.equal(probe.kind,'tool_calls');assert.equal(probe.calls.length,1);
 assert.equal(probe.calls[0].tool,'bash');
 assert.equal(JSON.parse(probe.calls[0].arguments).command,recipeSourceCommand('main.rs'));
 const call=probe.calls[0],id='source-probe';
 input.push({role:'assistant',content:'',tool_calls:[{id,type:'function',function:{name:call.tool,arguments:call.arguments}}]},
  {role:'tool',tool_call_id:id,name:call.tool,content:JSON.stringify({schema:'workspace-source-v1',path:'main.rs',success:true,complete:true,absent:true,error_code:'ENOENT'})});
 const plan=await planChatStepResolved(input,tools);
 assert.equal(plan.kind''')
s+='''
for(const [reason,patch] of [['incomplete',{complete:false}],['wrong path',{path:'foreign.rs'}],
 ['unsuccessful',{success:false}],['wrong absence reason',{error_code:'EACCES'}]]){
 test('a prepared delivery cannot write after a '+reason+' source probe',async()=>{
  const input=messages(JSON.stringify(explicit()));
  const probe=await planChatStepResolved(input,tools),call=probe.calls[0],id='invalid-probe';
  input.push({role:'assistant',content:'',tool_calls:[{id,type:'function',function:{name:call.tool,arguments:call.arguments}}]},
   {role:'tool',tool_call_id:id,name:call.tool,content:JSON.stringify({schema:'workspace-source-v1',path:'main.rs',success:true,complete:true,absent:true,error_code:'ENOENT',...patch})});
  const next=await planChatStepResolved(input,tools);
  assert.equal(next.kind,'final');assert.doesNotMatch(next.answer,/Created and verified|Committed and pushed/u);
 });
}
'''
p.write_text(s)
