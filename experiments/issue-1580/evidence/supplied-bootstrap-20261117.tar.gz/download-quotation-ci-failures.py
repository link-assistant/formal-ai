from pathlib import Path
from datetime import datetime, timezone
import subprocess, json, gzip, hashlib, time

base = Path('experiments/issue-1580/evidence/ci/task-quotation-04a468f5')
summary = json.loads((base / 'latest-summary.json').read_text())
assert summary['head'] == '04a468f53549f0825999c1dd9e53210476723106'
assert not summary['active']
stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
target = base / ('failure-download-' + stamp)
target.mkdir()
repo = 'link-assistant/formal-ai'
receipts = []
for failure in summary['nonPassingCompleted']:
    run_id = str(failure['id'])
    metadata_raw = subprocess.check_output(['gh', 'api', 'repos/' + repo + '/actions/runs/' + run_id])
    metadata = json.loads(metadata_raw)
    assert metadata['head_sha'] == summary['head']
    assert metadata['status'] == 'completed'
    (target / (run_id + '-metadata.json')).write_bytes(metadata_raw)
    job_raw = subprocess.check_output(['gh', 'api', 'repos/' + repo + '/actions/runs/' + run_id + '/jobs?per_page=100', '--paginate', '--slurp'])
    pages = json.loads(job_raw)
    jobs = [job for page in pages for job in page['jobs']]
    (target / (run_id + '-jobs.json')).write_text(json.dumps(jobs, indent=2) + '\n')
    failed = [job for job in jobs if job['conclusion'] not in ['success', 'skipped', 'neutral']]
    downloads = []
    for job in [None] + failed:
        name = run_id + ('-workflow.log' if job is None else '-job-' + str(job['id']) + '.log')
        args = ['gh', 'run', 'view', run_id, '--repo', repo, '--log']
        if job is not None:
            args.extend(['--job', str(job['id'])])
        with (target / name).open('wb') as output, (target / (name + '.stderr')).open('wb') as errors:
            result = subprocess.run(args, stdout=output, stderr=errors)
        raw = (target / name).read_bytes()
        (target / (name + '.gz')).write_bytes(gzip.compress(raw, mtime=0))
        downloads.append({'file': name, 'exitCode': result.returncode, 'bytes': len(raw), 'lines': len(raw.splitlines()), 'sha256': hashlib.sha256(raw).hexdigest()})
    receipts.append({'run': run_id, 'workflow': failure['name'], 'createdAt': metadata['created_at'], 'head': metadata['head_sha'], 'failedJobs': [{'id': job['id'], 'name': job['name'], 'conclusion': job['conclusion'], 'failedSteps': [step for step in job.get('steps', []) if step['conclusion'] == 'failure']} for job in failed], 'downloads': downloads})
report = {'observedAt': stamp, 'head': summary['head'], 'receipts': receipts, 'allLogsLiterallyRead': False}
(target / 'manifest.json').write_text(json.dumps(report, indent=2) + '\n')
(base / 'latest-failure-directory.txt').write_text(str(target) + '\n')
print(json.dumps({'directory': str(target), **report}, indent=2))
