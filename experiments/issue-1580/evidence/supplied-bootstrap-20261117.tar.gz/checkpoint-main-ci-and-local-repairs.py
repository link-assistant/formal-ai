from pathlib import Path
import collections
import gzip
import hashlib
import json
import re
import subprocess

root=Path.cwd()
ci=root/"experiments/issue-1580/evidence/ci/main-512ce428"
completion=json.loads((ci/"failure-download-completion.json").read_text())
failures=[]
for run in completion["runs"]:
    raw=gzip.decompress((ci/run["log"]).read_bytes())
    assert len(raw)==run["rawBytes"] and hashlib.sha256(raw).hexdigest()==run["rawSha256"]
    text=raw.decode(errors="replace")
    rows=text.splitlines()
    for number,line in enumerate(rows,1):
        match=re.search(r"thread '([^']+)' .* panicked at ([^:]+):(\d+)",line)
        if match:failures.append({"test":match[1],"source":match[2],"sourceLine":int(match[3]),"logLine":number,"runId":run["runId"]})
assert len(failures)==35
(ci/"native-failure-inventory.json").write_text(json.dumps({
    "mainHead":"512ce428029a92687628b4180309ee5ab660fe08",
    "failedNativeTests":failures,
    "nativeTestsFailedOnMain":35,
    "fullShard5Budget":{"seconds":1080,"logLine":39696,"runId":"44117975432"},
    "branchNativeRerun":False,
    "completionClaimed":False,
    "independentAuthorshipCredit":0,
},indent=2)+"\n")
(ci/"README.md").write_text("""# Fresh default-branch CI failures at 512ce428

The snapshot records 79 runs for main head 512ce428029a92687628b4180309ee5ab660fe08: 19 successes, 58 skipped workflow-run cascades and two failures. Both failed workflow logs were downloaded after completion and are retained in full with job metadata, timestamps, byte/line counts and raw SHA-256 identities.

CI/CD Pipeline 44117975432 (created 2026-11-17 15:45:29 UTC, completed 16:18:37 UTC) contains 82,630 lines. Lint fails because public documentation links two private helpers (lines 17196-17214 and 17991-18009), and one import needs rustfmt wrapping (17255-17262). Those exact source fixes are already in this branch; no new native documentation build is claimed. The native test inventory records all 35 failing test names, source locations and log line numbers. Full shard 5/8 also exhausts its unchanged 1080-second budget at line 39696. Native synthesis/benchmarks, warning inventory, delivery and scheduling failures remain unfinished; this archive does not turn source changes into executed native proof.

Layered CI 44117974304 (created 2026-11-17 15:45:28 UTC, completed 15:53:24 UTC) contains 34,418 lines. Its six JavaScript assertions are the quoted-passage no-network case, three connector-source receipt cases, the old runner-label baseline and the obsolete one-pattern policy assumption. The merged branch now passes the whole four focused suites, respectively 15, 20, 11 and 2 cases, each with zero skips. During that recheck the browser suite exposed an additional local orphan-zombie fixture issue; the retained before/after process observations and unchanged exact-PID assertion are documented with the focused checks.

The broad initial error searches intentionally retain setup shell text and expected negative-test messages; they are discovery indexes, not a claim that every match is an actionable failure. Targeted lint excerpts, actual failed-test names, failed-job metadata and passing focused test logs determine the findings. No Rust compilation, full native replay, hosted execution of this new batch or acceptance-criterion completion is claimed. Supplied orchestration receives zero independent authorship credit.
""")
merged=root/"experiments/issue-1580/evidence/checks/main-merge-512ce428"
record=json.loads((merged/"all-local-gates.json").read_text())
raw=gzip.decompress((merged/record["log"]).read_bytes())
assert hashlib.sha256(raw).hexdigest()==record["rawSha256"]
counts=collections.Counter(re.findall(r"^(PASS|SKIP|FAIL) ",raw.decode(),re.M))
assert counts=={"PASS":85,"SKIP":52,"FAIL":1}
readme=merged/"README.md"
text=readme.read_text().replace("The complete merged-head JavaScript gate run remains pending.","The complete merged-head gate run records 85 passes, 52 explicit native/context exclusions and one generated-file heap-exhaustion failure under a 256 MiB Node cap, in 640.894 seconds. No other gate fails. The checker now streams twelve-line headers; its complete eight-case regression suite passes under a 96 MiB cap. A final full gate run on the committed repairs remains pending.")
readme.write_text(text)
paragraph="\nFresh main head 512ce428 has two failed workflows, fully archived with current timestamps and exact hashes. Its six JavaScript assertions now pass in four complete focused suites (15/20/11/2 cases, no skips). The browser test also gains a cooperative reaper after a bounded probe proves an exited PID-1 zombie; timeout status and exact ESRCH assertions are unchanged. A new generated-file inventory regression fails with the original full-file retention and passes all eight cases after twelve-line, one-file-at-a-time reading under a 96 MiB heap cap. The 35 native failing tests and full-shard-5 1080-second timeout are inventoried and remain unverified on the branch. Final full local gates, single-push preflight and hosted execution of the newly selected audit/formatter observations remain pending. All supplied work has zero independent Formal AI authorship credit.\n"
for name in ["docs/case-studies/issue-1580/README.md","docs/case-studies/issue-1580/templates/README.md","experiments/issue-1580/work-plan.md"]:
    with (root/name).open("a") as stream:stream.write(paragraph)
for script in ["archive-round-bootstrap.py","archive-evidence.py"]:
    result=subprocess.run(["python3","/tmp/issue-1580-research/"+script],capture_output=True,text=True,check=True)
    print(result.stdout.strip())
paths=["docs/case-studies/issue-1580","experiments/issue-1580"]
for command in [["git","diff","--check"],["git","add","--",*paths],["git","diff","--cached","--check"]]:subprocess.run(command,check=True)
stat=subprocess.run(["git","diff","--cached","--stat"],capture_output=True,text=True,check=True).stdout.splitlines()
print(stat[-1])
subprocess.run(["git","commit","-m","docs: preserve current main failures and partial Python review"],check=True,stdout=subprocess.PIPE)
print("HEAD",subprocess.run(["git","rev-parse","HEAD"],capture_output=True,text=True,check=True).stdout.strip())
status=subprocess.run(["git","status","--porcelain"],capture_output=True,text=True,check=True).stdout
print("STATUS",status);assert not status.strip()
