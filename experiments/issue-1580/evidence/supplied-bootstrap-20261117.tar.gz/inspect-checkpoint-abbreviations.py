from pathlib import Path
import gzip,hashlib,json,subprocess
base=Path('experiments/issue-1580/evidence/checks/main-merge-015a6831/final-documentation')
raw=Path('experiments/formal_ai_subagent/sandboxes/gates/check-abbreviations.log').read_bytes()
(base/'initial-abbreviation-failure.log.gz').write_bytes(gzip.compress(raw,mtime=0))
result=subprocess.run(['node','scripts/measure-abbreviations.mjs','--list','file-names'],capture_output=True)
content=result.stdout+result.stderr
(base/'initial-abbreviation-list.log.gz').write_bytes(gzip.compress(content,mtime=0))
assert result.returncode==0
tracked=set(subprocess.check_output(['git','ls-files'],text=True).splitlines())
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
print('NEW FILES MATCHING MEASURED LIST')
for name in untracked:
    matches=[line for line in content.decode().splitlines() if name in line]
    if matches:print('\n'.join(matches))
print('TOTAL LIST LINES',len(content.splitlines()))
