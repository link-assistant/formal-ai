import pathlib
import subprocess

subprocess.run(['python3','/tmp/issue-1580-research/read-ci-payload.py','/tmp/issue-1580-research/checkpoint-7780c707-44180825006.log','9038','9062'],check=True)
subprocess.run(['rg','-n',r'#\[test\]|cfg\(test\)|mod tests|writability_probe', 'rust/src/structured_log.rs'],check=True)
files=subprocess.check_output(['rg','--files','--no-ignore','rust/tests/unit'],text=True).splitlines()
print('\n'.join(path for path in files if any(token in path for token in ['structured','logging','native_log'])))
