from pathlib import Path
import gzip,hashlib,json,re

directory=Path('experiments/issue-1580/evidence/ci/1cc2d536a')
raw=gzip.decompress((directory/'44116797181.log.gz').read_bytes())
lines=raw.decode().splitlines()
results=[]
for name in ['rust/tests/web/javascript-audit-inventory.test.mjs','experiments/issue-1580/template-python-audit-integrity.test.mjs','experiments/issue-1580/template-python-fragment-integrity.test.mjs']:
    text=Path(name).read_text()
    titles=re.findall(r"test\('([^']+)'",text)
    for title in titles:
        hits=[{'line':n,'text':line} for n,line in enumerate(lines,1) if title in line and '✔' in line]
        print(json.dumps({'title':title,'passingLogLines':[row['line'] for row in hits]}))
        results.append({'source':name,'title':title,'passingLogLines':hits,'executed':bool(hits)})
record={'head':'1cc2d536ac11e26602cc55a40dffb61716233aa6','run':44116797181,'rawLogSha256':hashlib.sha256(raw).hexdigest(),'testEvidence':results,'allSelectedExecuted':all(row['executed'] for row in results),'nativeAcceptanceClaimed':False,'authorship':'Supplied verification; zero independent Formal AI reasoning credit.'}
(directory/'audit-and-python-execution.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'selectedTests':len(results),'allSelectedExecuted':record['allSelectedExecuted']}))
