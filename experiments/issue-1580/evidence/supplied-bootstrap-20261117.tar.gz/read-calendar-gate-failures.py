from pathlib import Path
import gzip,hashlib,json
out=Path("experiments/issue-1580/evidence/checks/calendar-clock-preservation")
names=["check-javascript-dependencies","check-minimal-core-boundary-js-twin","check-minimal-core-boundary","check-worker-line-budget-js-twin","check-worker-line-budget","lint-shell-scripts"]
for name in names:
 p=Path("experiments/formal_ai_subagent/sandboxes/gates")/(name+".log")
 raw=p.read_bytes()
 (out/(name+".log.gz")).write_bytes(gzip.compress(raw,mtime=0))
 lines=raw.decode().splitlines()
 print("LOG",name,"TOTAL",len(lines),"SHA256",hashlib.sha256(raw).hexdigest())
 assert len(lines)<=1500
 for i,line in enumerate(lines,1):print(f"{i}: {line}")
