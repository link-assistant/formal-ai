set -eu
git diff --stat
git diff -- experiments/issue-1580/template-go-result-integrity.test.mjs experiments/issue-1580/fixtures/go-template/source.json
cat docs/case-studies/issue-1580/templates/go-semantic-review.json
cat docs/case-studies/issue-1580/templates/README.md
tail -n 110 experiments/issue-1580/work-plan.md
cat experiments/issue-1580/upstream/template-report-identities.json
cat changelog.d/20261117_120000_issue-1580-ci-regressions.md
