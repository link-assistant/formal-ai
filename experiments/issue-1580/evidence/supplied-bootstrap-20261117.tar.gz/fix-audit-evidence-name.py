from pathlib import Path
import gzip,subprocess
directory=Path('experiments/issue-1580/evidence/checks/audit-inventory-boundary')
p=directory/'feedback-pr-comments.json.gz';assert p.exists()
p.rename(directory/'feedback-pull-request-comments.json.gz')
(directory/'initial-abbreviation-details.log.gz').write_bytes(gzip.compress(Path('experiments/formal_ai_subagent/sandboxes/gates/check-abbreviations.log').read_bytes(),mtime=0))
p=Path('/tmp/issue-1580-research/run-audit-gates.py');s=p.read_text();s=s.replace("groups={'basic':", "groups={'abbreviations':'check-abbreviations','basic':")
p.write_text(s)
subprocess.run(['git','add','--',str(directory)],check=True)
print('Renamed the evidence filename to spell pull request in full; abbreviation policy unchanged.')
