from pathlib import Path
exec(Path('/tmp/issue-1580-research/fix-documentation-admission-test.py').read_text())
file=Path('rust/src/solver.rs')
text=file.read_text()
old='''                let intent = language_aware_intent_for(&rule, language);
'''
assert text.count(old)==1
file.write_text(text.replace(old,''))
