from pathlib import Path
import json
out=Path('/tmp/issue-1580-research/canonical-native-publication')
if (out/'outcome.json').exists():
 report=json.loads((out/'outcome.json').read_text());print(json.dumps({k:v for k,v in report.items() if k!='records'},indent=2));print('RECORDS',[(r['name'],r['exitCode'],r['seconds']) for r in report['records']])
else:
 lines=(out/'worker.log').read_text().splitlines();print('PUBLICATION RUNNING',len(lines))
 for line in lines[-8:]:
  try:
   r=json.loads(line);print(json.dumps({k:r[k] for k in ['name','exitCode','seconds'] if k in r}))
  except ValueError:print(line)
