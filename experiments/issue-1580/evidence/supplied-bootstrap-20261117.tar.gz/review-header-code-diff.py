import subprocess
paths=["scripts/check-generated-files.mjs","rust/tests/web/generated-files.test.mjs","rust/tests/web/browser-engine-release-integration.test.mjs","experiments/issue-1580/browser-deadline-descendant.mjs"]
result=subprocess.run(["git","diff","acce56779b8fb7b6c70e5250f53270f862a147d0","HEAD","--",*paths],capture_output=True,text=True,check=True)
lines=result.stdout.splitlines()
print("DIFF LINES",len(lines))
assert len(lines)<=1500
for number,line in enumerate(lines,1):print(str(number)+": "+line)
