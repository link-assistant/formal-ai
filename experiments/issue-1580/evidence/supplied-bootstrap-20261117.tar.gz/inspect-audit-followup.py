from pathlib import Path

for name in (
    "/tmp/issue-1580-research/collect-runtime-head-ci.py",
    "/tmp/issue-1580-research/read-python-review-page.py",
    "docs/case-studies/issue-1580/templates/python-partial-semantic-review.json",
    "experiments/issue-1580/evidence/checks/audit-inventory-boundary/README.md",
):
    lines = Path(name).read_text().splitlines()
    print(f"FILE {name} ({len(lines)} lines)")
    for number, line in enumerate(lines[:160], 1):
        print(f"{number}: {line}")
