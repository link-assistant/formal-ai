from pathlib import Path
import gzip, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/checks/complete-cache-request-binding'
base.mkdir(exist_ok=False)
source = root / 'rust/src/solver_unknown_reasoning.rs'
tests = root / 'rust/tests/unit/solver_unknown_reasoning_captured_sources.rs'
seed = root / 'data/seed/code-task-cues.lino'
before = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in [source, tests, seed]}
text = source.read_text()
old = '''    if let Some(focus) = focus.as_deref()
        && let Some(answer) = answer_from_public_knowledge_cache(prompt, focus, language, log)
    {'''
new = '''    if let Some(answer) = answer_from_public_knowledge_cache(prompt, language, log) {'''
assert text.count(old) == 1
text = text.replace(old, new)
old = '''fn answer_from_public_knowledge_cache(
    prompt: &str,
    focus: &str,
    language: Language,
    log: &mut EventLog,
) -> Option<SymbolicAnswer> {
    for term in public_concept_candidate_terms(focus) {'''
new = '''fn cached_public_request_subject(prompt: &str) -> Option<String> {
    static PREFIXES: OnceLock<Vec<String>> = OnceLock::new();
    let lower = clean_focus(prompt).to_lowercase();
    PREFIXES
        .get_or_init(|| {
            crate::solver_handlers::code_task_cue_phrases("concept_lookup", "cache_request_prefix")
        })
        .iter()
        .find_map(|prefix| lower.strip_prefix(prefix.as_str()).map(str::to_owned))
        .filter(|subject| !subject.trim().is_empty())
}

fn answer_from_public_knowledge_cache(
    prompt: &str,
    language: Language,
    log: &mut EventLog,
) -> Option<SymbolicAnswer> {
    // A research focus can name only part of an operative request. Bind a
    // definition to the complete parsed query or explicit cache instruction;
    // an unparsed request can match only as a whole cached concept surface.
    let requested = if let Some(query) = crate::concepts::extract_concept_query(prompt) {
        if query.context.is_some() {
            return None;
        }
        query.term
    } else {
        cached_public_request_subject(prompt).unwrap_or_else(|| prompt.to_owned())
    };
    for term in public_concept_candidate_terms(&requested) {'''
assert text.count(old) == 1
text = text.replace(old, new)
old = '''    if let Some(about) = tail_after_marker(trimmed, " about ") {
        return Some(clean_focus(about).to_owned());
    }'''
new = '''    if let Some(subject) = cached_public_request_subject(trimmed) {
        return Some(subject);
    }'''
assert text.count(old) == 1
text = text.replace(old, new)
source.write_text(text)
text = seed.read_text()
anchor = '''cues
  intent concept_lookup
    role request_prefix'''
insert = '''# An explicit cache instruction names the whole requested subject. An
# arbitrary request containing "about" does not authorize a definition answer.
cues
  intent concept_lookup
    role cache_request_prefix
    phrase "use cached public knowledge about "
'''
assert text.count(anchor) == 1
seed.write_text(text.replace(anchor, insert + anchor))
addition = r'''

#[test]
fn an_about_clause_cannot_replace_the_complete_operative_request() {
    let mut log = EventLog::new();
    let answer = answer_unknown_prompt(
        "How should a snorflax be calibrated about WebAssembly?",
        Language::English,
        &mut log,
        offline_config(),
        &[],
    );
    assert_eq!(answer.intent, "unknown");
    assert_eq!(
        answer.answer,
        "I could not determine `a snorflax be calibrated about WebAssembly` from local Links Notation memory, cached public knowledge, or the source cache, and cannot infer a verified answer. I recorded the failed gather attempts in the trace.\n\nIf reasoning still cannot resolve this and a shared Links Notation seed fact or links rule is needed, use Report issue with the trace. To keep a dialog-local rule durable, export memory or teach it with `When I say ... answer ...`; inspect routes with `List behavior rules` and `Show behavior rule unknown`.\n\nI detected a failure while working on this request. Would you like me to prepare an issue report with the diagnostic context? Reply `Report issue`."
    );
    assert!(!log.events().iter().any(|event| {
        event.kind == "reasoning:gather_result"
            && event.payload.starts_with("public_knowledge_cache:hit:")
    }));
}

#[test]
fn public_cache_answers_require_the_complete_requested_subject() {
    for prompt in [
        "Calibrate the snorflax about WebAssembly",
        "Calibrate the definitions of WebAssembly",
        "What is WebAssembly in teal silence?",
        "Use cached public knowledge about a snorflax about WebAssembly",
    ] {
        let mut log = EventLog::new();
        assert!(
            answer_from_public_knowledge_cache(prompt, Language::English, &mut log).is_none(),
            "a cached gloss cannot answer {prompt}"
        );
        assert!(!log.events().iter().any(|event| {
            event.kind == "reasoning:gather_result"
                && event.payload.starts_with("public_knowledge_cache:hit:")
        }));
    }
}

#[test]
fn an_about_clause_cannot_replace_a_link_memory_question() {
    let prompt = "Calibrate the snorflax about WebAssembly";
    let mut log = EventLog::new();
    log.append("prior_turn:user", "WebAssembly is a portable instruction format.".to_owned());
    let focus = infer_missing_focus(prompt).expect("the request has a focus");
    assert!(answer_from_link_memory(prompt, &focus, &mut log).is_none());
    assert!(!log.events().iter().any(|event| {
        event.kind == "reasoning:gather_result" && event.payload.starts_with("link_memory:hit:")
    }));
}

#[test]
fn a_bare_cached_concept_keeps_its_complete_attributed_answer() {
    let mut log = EventLog::new();
    let answer = answer_unknown_prompt(
        "WebAssembly",
        Language::English,
        &mut log,
        offline_config(),
        &[],
    );
    assert_eq!(answer.intent, "concept_lookup");
    assert_eq!(
        answer.answer,
        "WebAssembly (runtime): WebAssembly (Wasm) is a binary instruction format for a stack-based virtual machine. It is designed as a portable compilation target for programming languages, enabling deployment on the web for client and server applications.\n\nSource: https://en.wikipedia.org/wiki/WebAssembly (wikipedia)."
    );
    assert!(log.events().iter().any(|event| {
        event.kind == "reasoning:gather_result"
            && event.payload.starts_with("public_knowledge_cache:hit:")
    }));
}
'''
assert 'fn an_about_clause_cannot_replace_the_complete_operative_request' not in tests.read_text()
tests.write_text(tests.read_text() + addition)
subprocess.run(['rustfmt', '--edition', '2024', str(source), str(tests)], cwd=root, check=True)
env = dict(__import__('os').environ)
env['NODE_OPTIONS'] = '--max-old-space-size=256'
result = subprocess.run(['bash', 'scripts/sync-seed.sh'], cwd=root, env=env, capture_output=True)
for label, raw in [('stdout', result.stdout), ('stderr', result.stderr)]:
    (base / ('sync-seed.' + label + '.gz')).write_bytes(gzip.compress(raw, mtime=0))
assert result.returncode == 0, result.stderr.decode()
assert seed.read_bytes() == (root / 'js/seed/code-task-cues.lino').read_bytes()
fragment = root / 'changelog.d/issue-1580-complete-cache-request-binding.md'
fragment.write_text('Fixed native fallback cache lookups treating an arbitrary “about” clause as a definition request. Cached definitions now cover the complete requested subject, and link-memory focus keeps operative requests intact. Explicit cache requests and bare known terms retain their attributed answers.\n')
patch = subprocess.check_output(['git', 'diff', '--', str(source.relative_to(root)), str(tests.relative_to(root)), str(seed.relative_to(root)), 'js/seed/code-task-cues.lino'], cwd=root)
(base / 'source.patch.gz').write_bytes(gzip.compress(patch, mtime=0))
outcome = {'draftComplete': True, 'sourceHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'beforeSha256': before, 'sourcePatchSha256': hashlib.sha256(patch).hexdigest(), 'nativeExecutedLocally': False, 'nativeTestsPending': True, 'independentAuthorshipCredit': 0, 'fullIssueComplete': False}
(base / 'draft.json').write_text(json.dumps(outcome, indent=2) + '\n')
print(json.dumps(outcome))
print(subprocess.check_output(['git', 'diff', '--stat'], cwd=root, text=True))
