set -eu
timeout 600 node --test --test-concurrency=1 rust/tests/web/pull-request-1188-subagent-folder.test.mjs > /tmp/issue-1580-research/gate-selection-after.log 2>&1
timeout 600 node --test --test-concurrency=1 rust/tests/web/pull-request-1188-working-rules.test.mjs > /tmp/issue-1580-research/working-rules-sixth.log 2>&1
timeout 600 node --test --test-concurrency=1 rust/tests/web/push-gate-rules.test.mjs > /tmp/issue-1580-research/push-gate-rules-sixth.log 2>&1
cat /tmp/issue-1580-research/gate-selection-after.log
cat /tmp/issue-1580-research/working-rules-sixth.log
cat /tmp/issue-1580-research/push-gate-rules-sixth.log
