from pathlib import Path
for name in ['run-sealed-picomatch-gates.py','run-merged-main-all-gates.py','archive-picomatch-gate-logs.py']:
    p=Path('/tmp/issue-1580-research')/name
    print('FILE',name)
    for n,line in enumerate(p.read_text().splitlines(),1): print(f'{n}: {line}')
for p in [Path('experiments/issue-1580/work-plan.md'),Path('docs/case-studies/issue-1580/README.md')]:
    print('END',str(p),len(p.read_text().splitlines()))
