from pathlib import Path
import sys
run=sys.argv[1]
lines=Path('/tmp/issue-1580-research/main-444575f2-'+run+'.log').read_text().splitlines()
for arg in sys.argv[2:]:
 a,b=map(int,arg.split(':'))
 assert 0<b-a<100
 print('LOG',run,'LINES',a,b)
 for i in range(a-1,min(b,len(lines))):
  line=lines[i]
  if len(line)>1800: line=line[:1800]+' [remaining bytes omitted; no full-line reading credit]'
  print(str(i+1)+': '+line)
