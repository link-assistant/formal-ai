from pathlib import Path

p=Path('docs/case-studies/issue-1580/runtime-fixture-checkpoint.md')
text=p.read_text().replace('the complete focused regression file remains to be verified.', 'all 25 cases in the complete focused regression file pass without skips.')
text=text.replace('Four main-only ledger entries retain the narrow existing JavaScript replays\nfor the count, registry, passage and private diagnostic failures. Full shared-data gates are being\nverified separately; no native build or runtime is claimed.', 'Four main-only ledger entries retain the narrow existing JavaScript replays\nfor the count, registry, passage and private diagnostic failures. The first\ncomplete local run passes 86 gates with 52 explicit exclusions and zero failures.\nThe subsequent ledger test catches all four replays missing from the fast PR\ninventory. Adding those four existing files grows that inventory from 235 to\n239 files. The corrected ledger/profile checks and final shared-data gates\nremain to be verified; no native build or runtime is claimed.')
p.write_text(text)
p=Path('experiments/issue-1580/work-plan.md');text=p.read_text()
text=text.replace('Add three main-only replay ledger rows and complete the full shared-data gate set before a single batch push.', 'Add four main-only replay ledger rows. The first complete shared-data run passes 86 gates with 52 explicit exclusions; the later focused ledger check catches all four replays missing from the fast PR inventory. Add those four existing files (235 to 239 selected files), then verify the corrected ledger/profile and final shared-data gates before a single batch push. The complete private binding diagnostic file passes all 25 tests without skips.')
p.write_text(text)
p=Path('docs/case-studies/issue-1580/README.md')
text=p.read_text();text+='\n\nThe [runtime fixture checkpoint](runtime-fixture-checkpoint.md) records the inline OpenCode test relocation, controlled Moon lexeme/count correction, official generated-registry refresh, native Claude argv expectations and lazy private binding diagnostic contract. Full local gates initially pass 86 with 52 explicit exclusions; a later ledger regression catches four missing fast-inventory replays, now added for final verification. Native execution, recursive parent proof and wider acceptance remain unfinished.\n'
p.write_text(text)
p=Path('experiments/issue-1580/trace-moon-lexeme.mjs')
p.write_text(p.read_text().replace('Compare one seed lexeme with a local file transport;', 'Compare the two English causal seed lexemes with local file transport;'))
old=Path('/tmp/issue-1580-research/run-runtime-registry-all-gates.py').read_text()
new=old.replace('runtime-registry-all-gates', 'runtime-replay-all-gates').replace('runtime-registry-all-local-gates.log', 'runtime-replay-all-local-gates.log')
Path('/tmp/issue-1580-research/run-runtime-replay-all-gates.py').write_text(new)
print('Updated checkpoint documents and prepared final-source gate worker; no native execution.')
