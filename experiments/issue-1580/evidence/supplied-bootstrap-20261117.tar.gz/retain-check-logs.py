from pathlib import Path
import gzip, hashlib, json, subprocess
root=Path('experiments/issue-1580/evidence/checks')
files=['documentation-reporting.log','rust-specification-fixture-integrity-current.log','rust-specification-unicode-identifiers-current.log','default-branch-build-policy-current.log','stale-pull-request-report-current.log','all-local-gates-fourth.log','all-local-gates-fourth-remainder.log']
records=[]
for filename in files:
    data=(root/filename).read_bytes()
    compressed=gzip.compress(data,mtime=0)
    target=root/(filename+'.gz')
    target.write_bytes(compressed)
    records.append({'file':target.name,'sha256':hashlib.sha256(data).hexdigest(),'compressedSha256':hashlib.sha256(compressed).hexdigest(),'lines':len(data.splitlines())})
summary=root/'all-local-gates-fourth-summary.json'
value=json.loads(summary.read_text())
value['interruptedInvocation']['log']='all-local-gates-fourth.log.gz'
value['completedRemainder']='all-local-gates-fourth-remainder.log.gz'
value['transcripts']=records
summary.write_text(json.dumps(value,indent=2)+'\n')
subprocess.run(['python3','experiments/issue-1580/archive-evidence.py'],check=True)
subprocess.run(['git','add',str(root),'experiments/issue-1580/evidence/commands'],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','docs(ci): retain focused checks and complete gate transcripts'],check=True)
subprocess.run(['git','status','--short'],check=True)
