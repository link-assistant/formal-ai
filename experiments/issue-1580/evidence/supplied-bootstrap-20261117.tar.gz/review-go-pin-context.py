from pathlib import Path
import json
import subprocess

directory = Path('/tmp/issue-1580-research/go-pin-context')
directory.mkdir(exist_ok=True)
repo = 'link-foundation/go-ai-driven-development-pipeline-template'
for name, endpoint in [('issues', f'repos/{repo}/issues?state=all&per_page=100'), ('pulls', f'repos/{repo}/pulls?state=closed&per_page=100')]:
    raw = subprocess.check_output(['gh', 'api', endpoint, '--paginate', '--slurp'])
    (directory / (name+'.json')).write_bytes(raw)
    items = [item for page in json.loads(raw) for item in page]
    if name == 'issues':
        print('ISSUES', json.dumps([{'number':item['number'],'title':item['title'],'pullRequest':'pull_request' in item} for item in items]))
        for item in items:
            if 'pull_request' not in item and any(word in (item['title']+' '+(item['body'] or '')).lower() for word in ['integrity','stale','dependency']):
                print('RELEVANT ISSUE', item['number'], item['body'])
    else:
        print('RECENT MERGED', json.dumps([{'number':item['number'],'title':item['title'],'mergedAt':item['merged_at']} for item in items if item['merged_at']][:5]))
head = subprocess.check_output(['gh', 'api', f'repos/{repo}/commits/HEAD', '--jq', '.sha'], text=True).strip()
print('CURRENT HEAD', head)
assert head == '65c686846d7327d8c835a0d30b1a76cc6345cfc6'
