from pathlib import Path
import gzip,hashlib,json,re
base=Path('experiments/issue-1580/evidence/checks/javascript-archive-checkout')
receipt=json.loads((base/'sparse-regressions.json').read_text());assert len(receipt['commands'])==8 and not receipt['changedOriginalOperands']
totals=[]
for row in receipt['commands']:
    raw=gzip.decompress((base/row['log']).read_bytes());assert hashlib.sha256(raw).hexdigest()==row['rawSha256'];assert row['exitCode']==0
    match=re.search(r'ℹ tests (\d+)',raw.decode());assert match;totals.append(int(match.group(1)))
assert sum(totals)==88
workflow=Path('.github/workflows/layered-ci.yml');source=workflow.read_text();needle='            !/docs/case-studies/**/*.gz\n'
assert source.count(needle)==1
workflow.write_text(source.replace(needle,'            # Historical archives stay out of this test checkout; retain the\n            # consumed client transcripts, session operand and language logs below.\n'+needle))
fragment=Path('changelog.d/20261117_120000_issue-1580-ci-regressions.md');source=fragment.read_text();source+='- Reduce JavaScript test checkout hydration while retaining consumed historical transcript, native-session and language-verification fixtures and the existing test budgets.\n';fragment.write_text(source)
body=Path('experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md');source=body.read_text()
replacements={
'Replay all 29 shared cases and their complete event sequences; native execution on the new head remains pending CI.':'Replay all 29 shared cases and their complete event sequences; all four executor tests actually pass on published head `9095abcb`.',
'No local Rust build runs; the new hosted native target is pending publication.':'No local Rust build runs. The hosted native results on `9095abcb` are recorded below.',
'Hosted CI for this new repair remains pending publication.':'The current hosted native regression executes; Layered CI remains unsuccessful during checkout, as recorded below.',
'Projection verification still refuses 49 modules; native quotation execution remains unverified.':'Projection verification still refuses 49 modules. At this earlier checkpoint native quotation execution was unverified; the current isolated target now replays the shared quotation cases.',
'Execution of all native quotation and held-out grammar fixtures remains unverified; scope-gated success does not establish that coverage.':'Other native held-out reader grammar fixtures remain unverified; scope-gated success does not establish that coverage.'}
for old,new in replacements.items():assert source.count(old)==1,old;source=source.replace(old,new)
needle='Latest reproduction and verification:\n\n';assert source.count(needle)==1
addition='''- Published head `9095abcb` passes **22/23 workflows**. The [native regression job](https://github.com/link-assistant/formal-ai/actions/runs/44262999525/job/134660858273) actually passes **six Rust tests** (four executor tests, calendar/currency and forced functions) plus **two native HTTP tests**. The executor target includes all **29 shared fixture cases and their complete event sequences**. [Layered CI](https://github.com/link-assistant/formal-ai/actions/runs/44262999002) fails in checkout on both groups in attempts 1 and 2; curl 28, bad pack header, promisor fetch and exit 128 appear at lines 124–126 and 155 in each complete retry job log. No JavaScript tests execute in those jobs. All attempts remain preserved separately; no further identical retry is requested.
- The proposed JavaScript checkout excludes historical `.gz`, `.log`, `.zip`, `.tgz` and `.diff` payloads under case studies and experiment evidence while retaining the actually consumed archives. The selection regression records **16/17 before** and **17/17 after**. A materialized temporary selection passes **all 88 tests in eight files**, retains 23,313 files / **301,945,027 working-tree bytes**, and leaves every selected original operand unchanged. Preserve the initial 60-second local-wrapper interruption separately from the completed 80.58-second background verification. Hosted checkout with the new rules remains unverified; the job, checkout and HTTP low-speed limits and 360-second test budget remain intact.
'''
source=source.replace(needle,needle+addition);assert source.count('Fixes #1580')==1;body.write_text(source)
checkpoint=Path('docs/case-studies/issue-1580/checkout-archive-checkpoint.md');source=checkpoint.read_text();assert '## JavaScript test checkout on 9095abcb' not in source
source+='''

## JavaScript test checkout on 9095abcb

All 23 workflows finish on published head
`9095abcbcccdd5518ce2c9318d3ebc6eb8914fc8`: 22 pass. Layered CI run
[44262999002](https://github.com/link-assistant/formal-ai/actions/runs/44262999002)
fails in both JavaScript groups during checkout in attempt 1 and in a single
unchanged-head failed-job retry, attempt 2. The complete 171-line retry job logs
for jobs 134665248683 and 134665249345 are literally read. Lines 124–126 record
curl 28 (1024 bytes/second for 20 seconds), a bad pack header and a missing
promisor fetch; line 155 records exit 128. Tests never start. The two groups run
in AWS us-west-2 and Azure eastus. These observations do not establish the
server-side cause or total missing-blob pack size.

The existing JavaScript selection includes approximately 631.7 MB of tracked
blobs. Extend the fast source job's historical archive policy to the JavaScript
test checkout, with explicit inclusions for the client transcripts, issue-982
native-session log and issue-932 language logs that tests actually consume.
Retain all measured source, every Cargo.lock, JSON session operands and the real
nested-context learning report. The existing event ref, shallow blobless fetch,
credential handling, 5-minute checkout cap, 12-minute job cap, 1024-byte/20-second
low-speed policy and 360-second test budget remain intact.

The new regression fails 16/17 before the workflow selection changes, precisely
because historical archives remain selected, and passes 17/17 afterward.
A temporary selection retains 23,313 files and 301,945,027 current working-tree
bytes. All 88 tests across eight individually run JavaScript files pass in that
selection, including actual compressed client and native-session operands and
all seven language-verification logs. Every selected original file's SHA-256 is
unchanged afterward. Peak child RSS is 390,252 KiB; cgroup OOM counters stay zero.
The temporary hard links and isolated Git index are removed. The first foreground
harness is interrupted by the local Formal AI 60-second command cap after three
files pass; its incomplete records are preserved separately. The complete
background harness finishes in 80.58 seconds. The 178-line combined log view is
literally read in full. No native build or execution runs locally.

All receipts and complete logs are under
`experiments/issue-1580/evidence/checks/javascript-archive-checkout/`; exact-head
workflow, job and failed attempt records are under
`experiments/issue-1580/evidence/ci/executor-status-9095abcb/`.
The smaller selection is locally verified. A new hosted checkout is still
required; working-tree size reduction alone does not prove transport causality.

The current native workflow passes independently: job
[134660858273](https://github.com/link-assistant/formal-ai/actions/runs/44262999525/job/134660858273)
actually executes and passes four executor tests, one calendar/currency test and
one forced-function test, followed by two native HTTP tests. The executor test
replays all 29 shared cases and complete event sequences. Only log lines
1605–1722 are claimed literally reviewed; the complete immutable log is retained.
This verifies those named regressions, not the broad unfinished issue acceptance.
Independent Formal AI reasoning acceptance remains 0/20.
''';checkpoint.write_text(source)
plan=Path('experiments/issue-1580/work-plan.md');source=plan.read_text();source+='''

## JavaScript checkout follow-up after 9095abcb

- [x] Preserve the current 23 workflow results: 22 successful, Layered CI checkout unsuccessful on both groups in both attempts. Literally read both complete retry job logs; request no further identical retry.
- [x] Verify actual hosted native execution: four executor tests covering all 29 shared cases and full events, calendar/currency, forced functions and two HTTP regressions pass on the current head.
- [x] Reproduce archive over-selection before the checkout change (16/17), then pass the selection file (17/17) and all 88 tests in eight files against a real temporary selection. Preserve the local wrapper interruption separately, and verify every selected source digest remains unchanged.
- [ ] Run affected local gates, review and commit this complete checkout/evidence batch, then publish only after checking the latest head's failures, feedback, main ancestry and idle workflow state.
- [ ] Review the new hosted checkout and every workflow result before claiming it passes. Input reduction is verified locally; the transport cause remains unproved.
- [ ] Continue every previously unfinished issue requirement. The PR remains draft and unmerged; independent reasoning acceptance remains 0/20.
''';plan.write_text(source)
summary={'localSparseTests':sum(totals),'testCounts':totals,'allCombinedLogLinesLiterallyRead':True,'combinedLogLines':178,'nativeResultsQualified':True,'remoteCheckoutWithNewRulesVerified':False,'independentAuthorshipCredit':0}
(base/'reviewed-local-results.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
