set -eu
python3 /tmp/issue-1580-research/read-template-ci-page.py java 27
python3 /tmp/issue-1580-research/read-template-ci-page.py java 28
