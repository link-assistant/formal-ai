from pathlib import Path
import gzip,hashlib,json,subprocess,sys,time
label=sys.argv[1];target=sys.argv[2]
directory=Path('experiments/issue-1580/evidence/checks/audit-inventory-boundary');directory.mkdir(exist_ok=True)
start=time.monotonic()
result=subprocess.run(['timeout','600','node','--max-old-space-size=96','--test','--test-concurrency=1',target],capture_output=True)
raw=result.stdout+result.stderr
(directory/f'{label}.log.gz').write_bytes(gzip.compress(raw,mtime=0))
metadata={'command':['timeout','600','node','--max-old-space-size=96','--test','--test-concurrency=1',target],'status':result.returncode,'durationSeconds':round(time.monotonic()-start,3),'log':f'{label}.log.gz','rawSha256':hashlib.sha256(raw).hexdigest()}
(directory/f'{label}.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata));print(raw.decode(errors='replace'))
