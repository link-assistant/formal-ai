from pathlib import Path
import gzip,hashlib,json,os,subprocess
root=Path.cwd();base=root/'experiments/issue-1580/evidence/checks/web-native-replay';base.mkdir(exist_ok=False);env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256');env['PATH']='/home/box/.local/bin:'+env['PATH'];records=[]
def save(name,raw):
 packed=gzip.compress(raw,mtime=0);p=base/(name+'.log.gz');p.write_bytes(packed);return {'file':p.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'lines':len(raw.splitlines())}
def run(name,args,expected=0):
 result=subprocess.run(args,cwd=root,env=env,capture_output=True);row=dict(name=name,argv=args,exitCode=result.returncode,stdout=save(name+'.stdout',result.stdout),stderr=save(name+'.stderr',result.stderr));records.append(row);(base/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True);assert result.returncode==expected,(name,result.stdout[-1000:],result.stderr[-1000:])
paths=['rust/tests/unit/web_requests.rs','rust/tests/unit/web_requests/extended.rs','rust/tests/unit/page_formalization_route.rs'];sources=[]
for path in paths:
 raw=(root/path).read_bytes();item=save('source-'+Path(path).name,raw);item['path']=path;item['cases']=raw.count(b'#[test]');sources.append(item)
(base/'source-identities.json').write_text(json.dumps(sources,indent=2)+'\n')
p=root/'rust/tests/web/default-branch-build-policy.test.mjs';s=p.read_text();assert "web search and fetched-page modules remain executable native inputs" not in s
s+='''\n\ntest('web search and fetched-page modules remain executable native inputs', {timeout:15000}, () => {
  for (const path of ['rust/tests/unit/web_requests.rs', 'rust/tests/unit/web_requests/extended.rs',
    'rust/tests/unit/page_formalization_route.rs', 'data/benchmarks/web-formalization/en.lino'])
    assert.equal(admission([path])['native-type-check'], true, path);
  assert.equal(admission(['rust/tests/unit/unrelated-source.rs'])['native-type-check'], false);
  const source = read('rust/tests/unit/reasoning_contracts.rs');
  for (const path of ['web_requests.rs', 'page_formalization_route.rs'])
    assert(source.includes('#[path = "' + path + '"]'), path);
  assert.match(read('rust/tests/unit/web_requests.rs'), /mod extended;/u);
  assert.match(read('rust/tests/unit/page_formalization_route.rs'), /include_str!\\("\\.\\.\\/\\.\\.\\/\\.\\.\\/data\\/benchmarks\\/web-formalization\\/en\\.lino"\\)/u);
});
''';p.write_text(s)
args=['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/default-branch-build-policy.test.mjs'];run('admission-before',args,1)
p=root/'rust/tests/unit/reasoning_contracts.rs';s=p.read_text();s=s.replace('//! Replay candidate validation, interpretation, contextual follow-ups and debug\n//! sessions without compiling the monolithic unit target. Existing test modules\n//! are included intact.','//! Replay reasoning, contextual follow-ups, debug sessions and sourced web\n//! requests without compiling the monolithic unit target. Existing test modules\n//! are included intact.');s+='\n#[path = "page_formalization_route.rs"]\nmod page_formalization_route;\n#[path = "web_requests.rs"]\nmod web_requests;\n';p.write_text(s)
p=root/'scripts/ci-pull-request-admission.mjs';s=p.read_text();needle="  'rust/tests/unit/specification/event_source_origin.rs',\n";assert s.count(needle)==1;s=s.replace(needle,needle+''.join(f"  '{path}',\n" for path in paths));p.write_text(s)
(root/'changelog.d/issue-1580-web-native-replay.md').write_text('Run the intact web-search, research-follow-up and fetched-page regression modules in the focused native pull-request lane. Admit every included source and preserve the existing fixture contracts.\n')
run('rust-format',['rustfmt','--edition','2024','rust/tests/unit/reasoning_contracts.rs'])
run('rust-format-check',['rustfmt','--edition','2024','--check','rust/tests/unit/reasoning_contracts.rs'])
run('admission-after',args)
for item in sources:assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['rawSha256']
(base/'outcome.json').write_text(json.dumps({'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'completeLocalDraft':True,'includedNativeCases':sum(x['cases'] for x in sources),'nativeExecutionVerified':False,'unchangedSourceModules':True,'pageJavaScriptBaselinePassed':6,'independentAuthorshipCredit':0,'fullIssueComplete':False},indent=2)+'\n')
print('UNMODIFIED NATIVE CASES',sum(x['cases'] for x in sources),'NATIVE EXECUTION PENDING',flush=True)
