from pathlib import Path
import gzip,json,subprocess
root=Path("/tmp/gh-issue-solver-1794900398048")
def git(*args):
    p=subprocess.run(["git",*args],cwd=root,text=True,capture_output=True,check=True)
    print("git",*args,"\n"+p.stdout)
git("log","--oneline","--decorate","HEAD..origin/main")
git("diff","--stat","HEAD...origin/main")
git("diff","--name-status","HEAD...origin/main")
path=root/"experiments/issue-1580/evidence/checks/python-release-formatting/feedback-issue.json.gz"
data=json.loads(gzip.decompress(path.read_bytes()))
print("ISSUE BODY")
for n,line in enumerate(data["body"].splitlines(),1):
    print(f"{n}: {line}")
print("GATE STATUS")
p=subprocess.run(["python3","/tmp/issue-1580-research/review-format-gates-and-diff.py"],cwd=root,text=True,capture_output=True,check=True)
print(p.stdout.split("CURRENT SOURCE DIFF")[0])
