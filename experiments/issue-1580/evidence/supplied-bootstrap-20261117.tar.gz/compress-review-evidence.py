from pathlib import Path
import gzip,hashlib,json,subprocess

root=Path('experiments/issue-1580/evidence/checks/generated-header-memory/pr-review')
source=root/'new-source.diff'
raw=source.read_bytes()
target=source.with_suffix('.diff.gz')
target.write_bytes(gzip.compress(raw,mtime=0))
assert gzip.decompress(target.read_bytes())==raw
source.unlink()
for path in [root/'README.md',root/'summary.json']:
 text=path.read_text()
 path.write_text(text.replace('new-source.diff','new-source.diff.gz'))
subprocess.run(['git','add','--',str(root)],check=True)
print('Compressed exact focused patch',len(raw),'bytes',hashlib.sha256(raw).hexdigest())
subprocess.run(['git','diff','--cached','--check'],check=True)
