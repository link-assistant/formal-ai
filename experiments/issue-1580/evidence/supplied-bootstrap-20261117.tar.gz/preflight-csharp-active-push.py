from pathlib import Path
import json,subprocess
def run(args):return subprocess.run(args,check=True,text=True,capture_output=True).stdout
branch=run(['git','branch','--show-current']).strip(); assert branch=='issue-1580-8d61a32a61e1'
repo='link-assistant/formal-ai'; expected='0f90c0a7a3bdd77b7d31c276a180d5ee297e57f6'
print('FETCH',run(['git','fetch','origin','main']))
assert subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD']).returncode==0
print('MAIN',run(['git','rev-parse','origin/main']).strip())
remote=json.loads(run(['gh','api',f'repos/{repo}/branches/{branch}']))['commit']['sha']; assert remote==expected
for status in ['in_progress','queued']:
 rows=json.loads(run(['gh','run','list','--repo',repo,'--branch',branch,'--status',status,'--limit','100','--json','databaseId,workflowName,headSha,status']))
 print(status,json.dumps(rows)); assert rows==[]
runs=json.loads(run(['gh','run','list','--repo',repo,'--branch',branch,'--commit',expected,'--limit','100','--json','databaseId,workflowName,status,conclusion,headSha,createdAt']))
assert len(runs)==24 and all(r['status']=='completed' for r in runs)
failed=[r for r in runs if r['conclusion']!='success']; assert len(failed)==1 and failed[0]['databaseId']==44095402201
print('CURRENT HEAD',json.dumps({'head':remote,'runs':len(runs),'passing':23,'failing':failed},indent=2))
for endpoint,label,expected_count in [('issues/1580/comments','issue-conversation',1),('issues/1581/comments','pull-conversation',9),('pulls/1581/comments','inline',0),('pulls/1581/reviews','reviews',0)]:
 pages=json.loads(run(['gh','api',f'repos/{repo}/{endpoint}','--paginate','--slurp'])); rows=[row for page in pages for row in page]
 Path(f'/tmp/issue-1580-research/preflight-csharp-active-{label}.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(label,json.dumps([{'id':r['id'],'createdAt':r.get('created_at',r.get('submitted_at')),'updatedAt':r.get('updated_at'),'url':r.get('html_url')} for r in rows]))
 if len(rows)!=expected_count:
  print('NEW FEEDBACK',json.dumps(rows,indent=2)); raise AssertionError('Read newly discovered feedback before continuing')
print('MEMORY',Path('/sys/fs/cgroup/memory.current').read_text().strip())
