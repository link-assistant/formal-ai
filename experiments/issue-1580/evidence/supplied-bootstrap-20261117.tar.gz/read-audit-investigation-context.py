from pathlib import Path
import gzip,json,subprocess
for name in ['AGENTS.md','CONTRIBUTING.md','experiments/issue-1580/formal-command.mjs','experiments/issue-1580/template-python-fragment-observation.test.mjs','experiments/issue-1580/template-observation-fixtures.mjs']:
 p=Path(name)
 if not p.exists():
  print('MISSING',name);continue
 lines=p.read_text().splitlines();print('\nFILE',name,'LINES',len(lines))
 for n,line in enumerate(lines[:350],1):print(f'{n}: {line}')
snapshot=Path('experiments/issue-1580/evidence/checks/python-fragment-collision/final-duplicate-issues.json.gz')
for row in json.loads(gzip.decompress(snapshot.read_bytes())):
 if any(word in ((row.get('title') or '')+' '+(row.get('body') or '')).lower() for word in ['audit-npm-locks','npm audit','mapfile']):
  print('RELATED',json.dumps({k:row.get(k) for k in ['number','title','body','html_url','url']},ensure_ascii=False))
result=subprocess.run(['rg','-n','mapfile.*< <\(|git ls-files.*package-lock|npm audit','scripts','.github/workflows','experiments/issue-1580'],capture_output=True,text=True)
print('LOCAL ANALOGUES\n'+result.stdout[:12000])
