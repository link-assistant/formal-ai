from pathlib import Path
for name,start,count in [
 ("rust/src/solver_synthesis.rs",1,72),
 ("rust/src/solver_synthesis.rs",165,104),
 ("rust/src/solver_synthesis.rs",390,70),
 ("rust/src/solver.rs",365,58),
 ("rust/src/solver.rs",485,65),
]:
 lines=Path(name).read_text().splitlines()
 print("FILE",name,"WINDOW",start,count)
 for i in range(start-1,min(start-1+count,len(lines))):print(f"{i+1}: {lines[i]}")
p=Path("experiments/issue-1580/evidence/checks/calendar-clock-preservation/validation-completion.json")
print("VALIDATION",p.read_text() if p.exists() else "RUNNING")
