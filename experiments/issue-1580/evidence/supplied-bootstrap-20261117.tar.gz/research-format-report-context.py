from pathlib import Path
import base64,gzip,hashlib,json,subprocess

def api(endpoint,*extra):
    return subprocess.run(['gh','api',endpoint,*extra],capture_output=True,check=True).stdout

repository='link-foundation/python-ai-driven-development-pipeline-template'
directory=Path('experiments/issue-1580/evidence/checks/python-release-formatting')
pages=json.loads(api(f'repos/{repository}/issues?state=all&per_page=100','--paginate','--slurp'))
items=[item for page in pages for item in page]
raw=json.dumps(items,indent=2).encode()+b'\n'
(directory/'duplicate-issues.json.gz').write_bytes(gzip.compress(raw,mtime=0))
head=json.loads(api(f'repos/{repository}/commits/main'))
identities=[]
for name in ['scripts/format_release_notes.py','scripts/release_naming.py']:
    remote=json.loads(api(f'repos/{repository}/contents/{name}?ref={head["sha"]}'))
    data=base64.b64decode(remote['content'])
    fixture=Path('experiments/issue-1580/fixtures/python-template')/name
    identities.append({'path':name,'upstreamBlob':remote['sha'],'sha256':hashlib.sha256(data).hexdigest(),'unchangedFromPinnedFixture':data==fixture.read_bytes()})
record={'repository':repository,'head':head['sha'],'issueAndPullRequestCount':len(items),'duplicateSnapshotRawSha256':hashlib.sha256(raw).hexdigest(),'files':identities}
(directory/'current-upstream.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
print('RELATED ISSUE AND PULL REQUEST TITLES')
for item in items:
    title=item['title'].lower()
    if any(word in title for word in ['release note','format','changelog','escape']):
        print(json.dumps({'number':item['number'],'title':item['title'],'updatedAt':item['updated_at'],'url':item['html_url'],'pullRequest':'pull_request' in item}))
