from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048');p=root/'rust/tests/web/default-branch-build-policy.test.mjs';s=p.read_text();s=s.replace('{readFileSync, readdirSync, mkdtempSync, mkdirSync, writeFileSync, rmSync}', '{readFileSync, readdirSync, mkdtempSync, mkdirSync, writeFileSync, rmSync, existsSync}')
s+='''
test('native sparse checkout retains nested shell inputs without experiment payloads', {timeout:15000}, () => {
  const checkout = Object.values(workflow('native-type-check.yml').jobs)[0].steps.find(step => step.uses === 'actions/checkout@v7');
  const directory = mkdtempSync(join(tmpdir(), 'formal-ai-native-shell-inputs-'));
  const paths = ['README.md', 'scripts/install.sh', 'experiments/agentic_cli_matrix/install_client.sh',
    'experiments/issue-1571/osv-cargo-lock.sh', 'experiments/new/nested/download.sh', 'experiments/direct.sh',
    'experiments/new/nested/payload.json', 'experiments/unrelated.mjs', 'dev/log/payload.json'];
  const git = (args, input) => {
    const result = spawnSync('git', args, {cwd:directory, input, encoding:'utf8', timeout:5000, maxBuffer:65536});
    assert.equal(result.status, 0, result.stderr || String(result.error));
  };
  try {
    for (const path of paths) {
      mkdirSync(dirname(join(directory, path)), {recursive:true});
      writeFileSync(join(directory, path), 'finite checkout fixture\\n');
    }
    git(['init', '-q']);
    git(['add', '.']);
    git(['-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.invalid', '-c', 'commit.gpgsign=false',
      'commit', '-qm', 'Finite source inputs']);
    assert.equal(checkout.with['sparse-checkout-cone-mode'], false);
    git(['sparse-checkout', 'set', '--no-cone', '--stdin'], checkout.with['sparse-checkout']);
    for (const path of paths.slice(0, 6)) assert(existsSync(join(directory, path)), path);
    for (const path of paths.slice(6)) assert(!existsSync(join(directory, path)), path);
  } finally { rmSync(directory, {recursive:true, force:true}); }
});
'''
p.write_text(s);print('Added a finite real-Git sparse-checkout regression for required and newly nested shell scripts.')
