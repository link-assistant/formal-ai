from pathlib import Path
import collections, json, subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
paths=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')
sizes=collections.defaultdict(lambda: [0,0]); biggest=[]
for path in paths:
 if not path or path.startswith('dev/log/') or (path.startswith('experiments/formal_ai_subagent/evidence/coordinator-1188/') and path.endswith('.gz')):continue
 p=root/path
 if not p.is_file():continue
 n=p.stat().st_size
 key='/'.join(path.split('/')[:3]) if path.startswith('experiments/') else path.split('/')[0]
 sizes[key][0]+=1;sizes[key][1]+=n;biggest.append((n,path))
print(json.dumps({'selectedFiles':sum(v[0] for v in sizes.values()),'selectedBytes':sum(v[1] for v in sizes.values()),'largestGroups':sorted(sizes.items(),key=lambda pair:pair[1][1],reverse=True)[:14],'largestFiles':sorted(biggest,reverse=True)[:12]},indent=2))
