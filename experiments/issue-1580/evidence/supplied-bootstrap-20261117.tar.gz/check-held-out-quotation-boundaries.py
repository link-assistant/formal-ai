from pathlib import Path
import json, subprocess

source = Path('rust/tests/web/helpers/issue-1550-meta-executor-cases.mjs')
text = source.read_text()
assert text.count('盐和胡椒') == 4
source.write_text(text.replace('盐和胡椒', '盐并且胡椒'))
code = '''
import { grammarVocabulary } from './js/agentic/crate/formalization_grammar.mjs';
import { splitRequest } from './js/agentic/crate/meta_executor.mjs';
import { isAlphanumeric } from './js/agentic/crate/rust_str.mjs';
import { QUOTATION_CASES } from './rust/tests/web/helpers/issue-1550-meta-executor-cases.mjs';
console.log(JSON.stringify({ chineseAggregation: grammarVocabulary('zh', 'connective-aggregation'), cjkAlphanumeric: isAlphanumeric('计') }));
for (const [name, text, relation, parts, language = 'en'] of QUOTATION_CASES.slice(7)) {
  const actual = splitRequest(text, language);
  console.log(JSON.stringify({ name, text, actual, expected: { relation, parts }, pass: JSON.stringify(actual) === JSON.stringify({ relation, parts }) }));
}
'''
root = Path('experiments/issue-1580/evidence/checks/task-quotation-boundaries')
log = root / 'held-out-direct-split-diagnostic.jsonl'
assert not log.exists()
with log.open('wb') as output:
    subprocess.run(['node', '--max-old-space-size=256', '--input-type=module', '-e', code], stdout=output, stderr=subprocess.STDOUT, check=True)
print(log.read_text())
correction = {
  'earlierLog': 'before-held-out-apostrophe-boundaries.log',
  'correction': 'The earlier held-out run failed because three fixture entries had not been generated. It did not demonstrate a CJK split defect. The revised direct diagnostic uses the actual aggregation connective inside each Chinese quotation and compares split output before fixture generation.',
  'nativeExecuted': False,
  'independentAuthorshipCredit': 0,
}
(root / 'held-out-diagnostic-correction.json').write_text(json.dumps(correction, indent=2) + '\n')
for name in ['memory.current', 'memory.max']:
    p = Path('/sys/fs/cgroup') / name
    print(name, p.read_text().strip())
