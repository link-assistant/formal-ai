set -eu
python3 /tmp/issue-1580-research/archive-round-bootstrap.py
python3 experiments/issue-1580/archive-evidence.py
git add -- experiments/issue-1580/evidence/commands experiments/issue-1580/evidence/supplied-bootstrap-20261117.json experiments/issue-1580/evidence/supplied-bootstrap-20261117.tar.gz
git diff --cached --check
git commit -m "docs(ci): retain complete Formal AI repair transcripts"
sh /tmp/issue-1580-research/prepush-sixth.sh
test -z "$(git status --porcelain)"
git push origin HEAD:issue-1580-8d61a32a61e1
git rev-parse HEAD
