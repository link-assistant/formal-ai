import subprocess,json,datetime
from pathlib import Path
out=Path("/tmp/issue-1580-research/calendar-feedback")
out.mkdir(exist_ok=True)
commands={
 "issue":["gh","issue","view","https://github.com/link-assistant/formal-ai/issues/1580","--json","body,title,updatedAt"],
 "issue-comments":["gh","api","repos/link-assistant/formal-ai/issues/1580/comments","--paginate"],
 "pr":["gh","pr","view","1581","--repo","link-assistant/formal-ai","--json","title,body,isDraft,headRefOid,mergeStateStatus,updatedAt"],
 "pr-comments":["gh","api","repos/link-assistant/formal-ai/issues/1581/comments","--paginate"],
 "pr-inline":["gh","api","repos/link-assistant/formal-ai/pulls/1581/comments","--paginate"],
 "pr-reviews":["gh","api","repos/link-assistant/formal-ai/pulls/1581/reviews","--paginate"],
 "runs":["gh","run","list","--repo","link-assistant/formal-ai","--branch","issue-1580-8d61a32a61e1","--limit","5","--json","databaseId,conclusion,createdAt,headSha,status,workflowName"],
}
for name,args in commands.items():
 r=subprocess.run(args,text=True,capture_output=True)
 assert r.returncode==0,(name,r.stderr)
 (out/(name+".json")).write_text(r.stdout)
 data=json.loads(r.stdout)
 if name=="pr":
  print(name,{k:v for k,v in data.items() if k!="body"})
 elif name=="issue":
  print(name,{k:v for k,v in data.items() if k!="body"})
 elif name=="runs": print(name,json.dumps(data))
 else:
  print(name,"COUNT",len(data))
  for item in data:
   print(item.get("html_url"),item.get("updated_at",item.get("submitted_at")),item.get("body"))
print("REFRESHED",datetime.datetime.now(datetime.timezone.utc).isoformat())
