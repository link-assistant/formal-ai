set -eu
git diff --check
git diff -- docs/case-studies/issue-1580/README.md docs/case-studies/issue-1580/templates/README.md experiments/issue-1580/fixtures/java-template/source.json experiments/issue-1580/work-plan.md rust/tests/web/issue-1580-template-observations.test.mjs
git status --short
