from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,sys,tempfile,time
directory=Path("experiments/issue-1580/evidence/ci/main-512ce428")
if len(sys.argv)==1:
    assert not (directory/"failure-download-completion.json").exists()
    with (directory/"failure-download-bootstrap.log").open("wb") as stream:
        child=subprocess.Popen([sys.executable,__file__,"finish"],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({"pid":child.pid,"startedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"completion":str(directory/"failure-download-completion.json")}))
    sys.exit(0)
assert sys.argv==[__file__,"finish"]
summary=json.loads((directory/"summary.json").read_text())
runs=[row for row in summary["runs"] if row["status"]=="completed" and row["conclusion"]=="failure"]
rows=[];started=time.time()
for run in runs:
    number=str(run["databaseId"])
    p=subprocess.run(["gh","run","view",number,"--repo","link-assistant/formal-ai","--json","jobs,conclusion,headSha,createdAt,url,workflowName"],text=True,capture_output=True)
    if p.returncode:
        rows.append({"runId":number,"metadataStatus":p.returncode,"error":p.stderr});continue
    metadata=json.loads(p.stdout);assert metadata["headSha"]==summary["headSha"]
    (directory/(number+".json.gz")).write_bytes(gzip.compress(p.stdout.encode(),mtime=0))
    command=["gh","run","view",number,"--repo","link-assistant/formal-ai","--log"]
    digest=hashlib.sha256();length=0;lines=0;before=time.time()
    with tempfile.TemporaryFile() as errors:
        child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=errors)
        with (directory/(number+".log.gz")).open("wb") as file:
            with gzip.GzipFile(fileobj=file,mode="wb",mtime=0) as compressed:
                while True:
                    chunk=child.stdout.read(65536)
                    if not chunk:break
                    compressed.write(chunk);digest.update(chunk);length+=len(chunk);lines+=chunk.count(b"\n")
        status=child.wait();errors.seek(0);error=errors.read().decode(errors="replace")
    row={"runId":number,"workflowName":run["workflowName"],"headSha":summary["headSha"],"status":status,"rawBytes":length,"rawLines":lines,"rawSha256":digest.hexdigest(),"durationSeconds":round(time.time()-before,3),"log":number+".log.gz","stderr":error,"failedJobs":[{"name":job["name"],"databaseId":job["databaseId"],"conclusion":job["conclusion"],"failedSteps":[step["name"] for step in job["steps"] if step["conclusion"]=="failure"]} for job in metadata["jobs"] if job["conclusion"] not in {"success","skipped"}]}
    rows.append(row);print(json.dumps(row),flush=True)
record={"status":0 if len(rows)==len(runs) and all(row.get("status")==0 for row in rows) else 1,"durationSeconds":round(time.time()-started,3),"runs":rows}
(directory/"failure-download-completion.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({"status":record["status"],"durationSeconds":record["durationSeconds"]}),flush=True)
