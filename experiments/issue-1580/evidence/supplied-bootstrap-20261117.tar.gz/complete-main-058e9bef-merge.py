from pathlib import Path
import gzip,hashlib,json,subprocess
base=Path('experiments/issue-1580/evidence/checks/main-merge-058e9bef')
scratch=Path('/tmp/issue-1580-research')
source=(scratch/'inspect-startup-witness-delta.mjs').read_text().replace('startup-governed-before.v8','merge-058e9bef-before.v8').replace('checks/main-merge-444575f2/startup-witness-delta.json','checks/main-merge-058e9bef/witness-delta.json')
target=scratch/'inspect-058e9bef-witness-delta.mjs';target.write_text(source)
r=subprocess.run(['node',str(target)],capture_output=True,text=True,check=True);print(r.stdout)
delta=json.loads((base/'witness-delta.json').read_text());assert delta['changes']==[]
for name,args in [
 ('translation-verify',['node','scripts/translate-js-rust.mjs','--verify']),
 ('package-mirror-check',['node','scripts/mirror-package-data.mjs','--check']),
 ('native-format',['rustfmt','--edition','2024','--check','rust/src/structured_log.rs','rust/src/agentic_coding/tool_result/source_observation.rs','rust/tests/source/source_tests/structured_log/tests.rs'])]:
 r=subprocess.run(args,capture_output=True);raw=r.stdout+r.stderr;(base/(name+'.log.gz')).write_bytes(gzip.compress(raw,mtime=0))
 print(name,'EXIT',r.returncode,raw.decode());assert r.returncode==0
subprocess.run(['git','add','data/meta/translation-blockers.lino','data/meta/js-rust-translation.lino'],check=True)
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'])
subprocess.run(['git','diff','--check','--cached'],check=True)
log=scratch/'commit-merge-main-058e9bef.log'
with log.open('w') as out:r=subprocess.run(['git','commit','-m','Merge main retention and multilingual summary fixes'],stdout=out,stderr=subprocess.STDOUT)
print('COMMIT',r.returncode,'\n'.join(log.read_text().splitlines()[:4]));assert r.returncode==0
print('HEAD',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
print('UNSTAGED',subprocess.check_output(['git','diff','--name-only'],text=True))
