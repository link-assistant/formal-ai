from pathlib import Path
import subprocess

for args in [
    ['node', '--max-old-space-size=256', 'scripts/measure-abbreviations.mjs', '--list', 'file-names'],
    ['git', 'diff', '--stat'],
]:
    result = subprocess.run(args, capture_output=True, text=True)
    print('COMMAND', args, 'EXIT', result.returncode)
    print(result.stdout)
    print(result.stderr)
