import pathlib, subprocess
root = pathlib.Path('/tmp/gh-issue-solver-1794900398048')
for args in [['git','branch','--show-current'], ['git','status','--short'], ['git','log','-3','--oneline']]:
    p = subprocess.run(args, cwd=root, text=True, capture_output=True, check=True)
    print(p.stdout)
for name in ['AGENTS.md', 'CONTRIBUTING.md', 'experiments/issue-1580/trace-template-ci.mjs', 'experiments/issue-1580/template-reference-graph.test.mjs', 'experiments/issue-1580/work-plan.md', 'docs/case-studies/issue-1580/templates/README.md', 'docs/case-studies/issue-1580/README.md']:
    path = root / name
    lines = path.read_text().splitlines()
    print(f'FILE {name} ({len(lines)} lines)')
    assert len(lines) <= 1500
    for n, line in enumerate(lines, 1): print(f'{n}: {line}')
for name in ['archive-round-bootstrap.py', 'check-eighth-archive-size.sh', 'check-self-references-after.sh']:
    p=pathlib.Path('/tmp/issue-1580-research')/name
    print(f'BOOTSTRAP {name}\n{p.read_text()}')
print('GRAPH DELTA\n'+pathlib.Path('/tmp/issue-1580-research/self-reference-checks/graph-delta.json').read_text())
