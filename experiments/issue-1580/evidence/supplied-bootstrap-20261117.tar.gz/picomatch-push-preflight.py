from pathlib import Path
import datetime, hashlib, json, subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
out=Path('/tmp/issue-1580-research/picomatch-push-preflight')
out.mkdir(exist_ok=True)
repo='link-assistant/formal-ai'
branch='issue-1580-8d61a32a61e1'
def run(args):
    return subprocess.run(args,cwd=root,text=True,capture_output=True,check=True).stdout
assert run(['git','branch','--show-current']).strip()==branch
print(run(['git','fetch','origin','main',branch]))
head=run(['git','rev-parse','HEAD']).strip()
remote=run(['git','rev-parse','origin/'+branch]).strip()
main=run(['git','rev-parse','origin/main']).strip()
ancestor=subprocess.run(['git','merge-base','--is-ancestor',main,'HEAD'],cwd=root).returncode==0
requests={
    'issue':['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','number,title,body,updatedAt,state,url'],
    'issue-comments':['gh','api','repos/'+repo+'/issues/1580/comments','--paginate','--slurp'],
    'pull-request':['gh','pr','view','1581','--repo',repo,'--json','title,body,isDraft,headRefOid,mergeStateStatus,url,updatedAt'],
    'pull-conversation':['gh','api','repos/'+repo+'/issues/1581/comments','--paginate','--slurp'],
    'pull-inline':['gh','api','repos/'+repo+'/pulls/1581/comments','--paginate','--slurp'],
    'pull-reviews':['gh','api','repos/'+repo+'/pulls/1581/reviews','--paginate','--slurp'],
    'recent-runs':['gh','run','list','--repo',repo,'--branch',branch,'--limit','5','--json','databaseId,conclusion,createdAt,headSha'],
    'remote-head-runs':['gh','run','list','--repo',repo,'--branch',branch,'--commit',remote,'--limit','100','--json','databaseId,conclusion,status,createdAt,updatedAt,headSha,workflowName,url'],
    'in-progress':['gh','run','list','--repo',repo,'--branch',branch,'--status','in_progress','--limit','100','--json','databaseId,workflowName,headSha'],
    'queued':['gh','run','list','--repo',repo,'--branch',branch,'--status','queued','--limit','100','--json','databaseId,workflowName,headSha'],
}
values={}
for label,argv in requests.items():
    raw=run(argv)
    (out/(label+'.json')).write_text(raw)
    values[label]=json.loads(raw)
    print(label, 'saved',len(raw),'bytes')
runs=values['remote-head-runs']
ready=ancestor and not values['in-progress'] and not values['queued'] and len(runs)>=24 and all(item['headSha']==remote and item['status']=='completed' and item['conclusion']=='success' for item in runs)
summary={'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'localHead':head,'remoteHead':remote,'mainHead':main,'mainMerged':ancestor,'remoteHeadRunCount':len(runs),'remoteHeadNonPassing':[item for item in runs if item['conclusion']!='success'],'inProgress':values['in-progress'],'queued':values['queued'],'preCommitPushGateSatisfied':ready,'comments':{label:sum(len(page) for page in values[label]) for label in ['issue-comments','pull-conversation','pull-inline','pull-reviews']}}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
assert ready, 'Refresh/fix all exact-head failures and merge current main before pushing.'
