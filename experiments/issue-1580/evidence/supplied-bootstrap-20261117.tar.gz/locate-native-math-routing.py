from pathlib import Path
import subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
commands=[
 ['rg','-n','algebra_substitution|arithmetic_word_problem|calculation_error|solver_synthesis|synthesize|word_problem_relation','rust/src/solver.rs','rust/src/solver_synthesis.rs','rust/src/solver_handlers'],
 ['rg','-n','algebra_substitution|arithmetic_word_problem|calculation_error|word_problem_relation','js/worker'],
 ['rg','-n','14.*18|17|step_6_candidates','rust/tests/unit/specification/reasoning_loop.rs'],
 ['rg','-n','candidate|synthesis|calculate|word_problem','rust/src/solver.rs']
]
for argv in commands:
    result=subprocess.run(argv,cwd=root,text=True,capture_output=True)
    print('\nSEARCH',argv)
    print(result.stdout[:14500])
    print(result.stderr)
print('CURRENT GATE LOG TAIL')
path=Path('/tmp/issue-1580-research/sealed-complete-local-gates.log')
if path.exists(): print('\n'.join(path.read_text().splitlines()[-12:]))
