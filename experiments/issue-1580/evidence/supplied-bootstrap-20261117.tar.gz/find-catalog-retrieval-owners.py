from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
needles=['impl CachedSourceClient','pub struct CachedSourceClient','fn answer_source_search','fn source_search','"source_search"','fn config_from_env','FORMAL_AI_CACHE_DIR']
for p in (root/'rust/src').rglob('*.rs'):
 text=p.read_text()
 matches=[(i+1,s) for i,s in enumerate(text.splitlines()) if any(n in s for n in needles)]
 if matches:
  print('\nFILE',p.relative_to(root))
  for i,s in matches: print(i,s)
print('\nCATALOG TEST/REFERENCE PATHS')
for parent in ['rust/tests','experiments','data/meta']:
 for p in (root/parent).rglob('*google*trends*'):print(p.relative_to(root))
