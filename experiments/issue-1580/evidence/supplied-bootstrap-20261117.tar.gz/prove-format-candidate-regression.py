from pathlib import Path
import gzip,hashlib,json,subprocess,time

path=Path('experiments/issue-1580/template-python-release-formatting.test.mjs')
original=path.read_text()
boundary="if(candidate&&name==='scripts/format_release_notes.py')"
assert original.count(boundary)==1
directory=Path('experiments/issue-1580/evidence/checks/python-release-formatting')
command=['timeout','600','node','--max-old-space-size=96','--test','--test-concurrency=1',str(path)]
started=time.monotonic()
try:
    path.write_text(original.replace(boundary,"if(false&&candidate&&name==='scripts/format_release_notes.py')"))
    result=subprocess.run(command,capture_output=True)
finally:
    path.write_text(original)
raw=result.stdout+result.stderr
assert result.returncode==1,raw.decode(errors='replace')
assert b'pass 3' in raw and b'fail 1' in raw and b'skipped 0' in raw
(directory/'candidate-disabled.log.gz').write_bytes(gzip.compress(raw,mtime=0))
record={'command':command,'status':result.returncode,'expectedFailure':True,'candidateDisabled':True,'durationSeconds':round(time.monotonic()-started,3),'rawSha256':hashlib.sha256(raw).hexdigest(),'log':'candidate-disabled.log.gz','testRestoredSha256':hashlib.sha256(path.read_bytes()).hexdigest()}
(directory/'candidate-disabled.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record));print(raw.decode(errors='replace'))
