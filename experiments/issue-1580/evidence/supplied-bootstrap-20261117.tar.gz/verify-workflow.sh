#!/bin/sh
set -eu
cp /tmp/issue-1580-research/refresh-staged-caller.mjs experiments/issue-1580/refresh-staged-caller.mjs
python3 /tmp/issue-1580-research/finish-workflow.py
node experiments/issue-1580/refresh-staged-caller.mjs
node scripts/generate-staged-release.mjs --check-deployed
timeout 600 node --test --test-concurrency=1 rust/tests/web/default-branch-build-policy.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/stale-pull-request-report.test.mjs
git diff --check
