from pathlib import Path
import gzip,hashlib,json,subprocess
base=Path('experiments/issue-1580/evidence/checks/main-merge-058e9bef/publication')
sha='83882c0ec7c26b28dc8ac274fada2b39d9dc3a67'
raw=subprocess.check_output(['gh','api','--paginate','--slurp',f'repos/link-assistant/formal-ai/actions/runs?head_sha={sha}&per_page=100'])
(base/'remote-head-all-event-runs.json.gz').write_bytes(gzip.compress(raw,mtime=0))
rows=[r for page in json.loads(raw) for r in page['workflow_runs']]
for r in rows:print(r['id'],r['name'],r['event'],r['status'],r['conclusion'],r['created_at'],r['head_sha'])
print('TOTAL',len(rows),'RAW SHA256',hashlib.sha256(raw).hexdigest())
failed=[r for r in rows if r['conclusion'] not in ['success','skipped','cancelled']]
assert all(r['status']=='completed' for r in rows)
for r in failed:
    data=subprocess.check_output(['gh','run','view',str(r['id']),'--repo','link-assistant/formal-ai','--log-failed'])
    (base/(str(r['id'])+'-failed.log.gz')).write_bytes(gzip.compress(data,mtime=0))
    print('FAILED LOG',r['id'],'BYTES',len(data),'SHA256',hashlib.sha256(data).hexdigest())
    lines=data.decode().splitlines()
    for i,line in enumerate(lines,1):
        if any(s in line for s in ['✖ ','test at ','AssertionError','actual:','expected:','##[error]']):print(i,line)
