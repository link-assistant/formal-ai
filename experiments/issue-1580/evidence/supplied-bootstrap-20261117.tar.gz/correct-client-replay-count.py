import pathlib
path = pathlib.Path('rust/tests/web/issue-1580-client-output-constraints.test.mjs')
text = path.read_text()
text = text.replace("assert.equal(requests.length, 2, 'retain the complete real read/final exchange');", "assert.equal(requests.length, client === 'qwen' ? 3 : 2, 'retain the complete real exchange, including Qwen suggestion mode');")
text = text.replace("assert.ok(message.content.includes('alpha'), message.content);", "assert.equal(message.content.trim(), 'ALPHA_MARKER_11111\\nalpha second line');")
path.write_text(text)
print('Corrected Qwen auxiliary suggestion count; require the complete observed two-line file text.')
