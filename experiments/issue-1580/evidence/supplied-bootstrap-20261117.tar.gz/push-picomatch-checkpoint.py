from pathlib import Path
import datetime, json, subprocess

repo='link-assistant/formal-ai'
branch='issue-1580-8d61a32a61e1'
scratch=Path('/tmp/issue-1580-research')
def run(arguments):
    result=subprocess.run(arguments,text=True,capture_output=True,check=True)
    return result.stdout
assert run(['git','branch','--show-current']).strip()==branch
assert not run(['git','status','--porcelain']).strip()
head=run(['git','rev-parse','HEAD']).strip()
assert head!='6611c4903a9dc8c359511f084ac790e9dcd64a83', 'Security commit is missing.'
print('LOCAL HEAD',head)
print(run(['git','log','-3','--format=%h %s']))
run(['git','fetch','origin','main',branch])
main=run(['git','rev-parse','origin/main']).strip()
subprocess.run(['git','merge-base','--is-ancestor',main,'HEAD'],check=True)
remote=run(['git','rev-parse','origin/'+branch]).strip()
assert remote=='d0b8b895661c6b5e809810c4da8a3db9f79138b3', 'Remote head changed; inspect it first.'
for state in ['in_progress','queued']:
    value=json.loads(run(['gh','run','list','--repo',repo,'--branch',branch,'--status',state,'--limit','100','--json','databaseId,workflowName,headSha']))
    assert not value,(state,value)
    print(state,value)
runs=json.loads(run(['gh','run','list','--repo',repo,'--branch',branch,'--commit',remote,'--limit','100','--json','databaseId,headSha,status,conclusion,workflowName']))
assert len(runs)>=24 and all(item['headSha']==remote and item['status']=='completed' and item['conclusion']=='success' for item in runs)
for name in ['sealed-complete-gates.json','sealed-notes-checks.json']:
    assert json.loads(Path('experiments/issue-1580/evidence/checks/picomatch-single-branch',name).read_text())['allPassed']
result=subprocess.run(['git','push','origin','HEAD:refs/heads/'+branch],text=True,capture_output=True)
log=result.stdout+result.stderr
(scratch/'picomatch-push.log').write_text(log)
print('PUSH EXIT',result.returncode)
print(log[-3000:])
assert result.returncode==0
result=subprocess.run(['gh','pr','edit','1581','--repo',repo,'--title','Fix CI evidence integrity, candidate validation and dependency regressions','--body-file',str(scratch/'picomatch-pr-description.md')],text=True,capture_output=True)
print('PR UPDATE',result.returncode,result.stdout,result.stderr)
assert result.returncode==0
value={'publishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'previousRemoteHead':remote,'mainHead':main,'previousHeadPassingWorkflows':len(runs),'pushLog':'picomatch-push.log','pullRequest':'https://github.com/link-assistant/formal-ai/pull/1581','newHeadVerified':False}
(scratch/'picomatch-published-checkpoint.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value,indent=2))
assert not run(['git','status','--porcelain']).strip()
