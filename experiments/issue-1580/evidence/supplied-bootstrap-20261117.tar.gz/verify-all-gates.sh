set -eu
python3 /tmp/issue-1580-research/prepare-evidence.py
python3 experiments/issue-1580/archive-evidence.py
git diff --check
PATH=/tmp/issue-1580-research/shellcheck-v0.11.0:$PATH node experiments/formal_ai_subagent/local-gates.mjs > /tmp/issue-1580-research/all-local-gates-third.log 2>&1
