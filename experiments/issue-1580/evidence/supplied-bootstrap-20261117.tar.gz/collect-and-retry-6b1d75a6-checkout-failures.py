from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,sys
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/ci/published-6b1d75a6'
head='6b1d75a62a610e58914ef594c107f3fa402ded9d';values=[]
for ident,name in [(44207032757,'layered'),(44207033000,'pipeline')]:
 query=['gh','run','view',str(ident),'--repo','link-assistant/formal-ai','--json','databaseId,headSha,status,conclusion,attempt,jobs,url,createdAt,updatedAt']
 value=json.loads(subprocess.check_output(query,cwd=root,text=True));assert value['headSha']==head and value['status']=='completed'
 assert value['attempt']==1,value['attempt'];folder=base/'attempt-1';folder.mkdir(exist_ok=True)
 (folder/f'{name}-{ident}.json').write_text(json.dumps(value,indent=2)+'\n')
 log=folder/f'{name}-{ident}.log.gz'
 if not log.exists():
  run=subprocess.run(['gh','run','view',str(ident),'--repo','link-assistant/formal-ai','--log'],cwd=root,capture_output=True);assert run.returncode==0,run.stderr.decode()
  data=run.stdout;log.write_bytes(gzip.compress(data,mtime=0))
 else:data=gzip.decompress(log.read_bytes())
 receipt={'run':ident,'head':head,'attempt':1,'rawSha256':hashlib.sha256(data).hexdigest(),'rawBytes':len(data),'rawLines':len(data.splitlines()),'log':log.name,'failures':[{key:job[key] for key in ['databaseId','name','conclusion']} for job in value['jobs'] if job['conclusion']=='failure'],'independentAuthorshipCredit':0}
 (folder/f'{name}-{ident}-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');values.append(receipt);print(json.dumps(receipt))
 for number,line in enumerate(data.decode().splitlines(),1):
  if any(marker in line for marker in ['not ok ','##[error]','curl 28','bad pack header','could not fetch']):print(f'{name}:{number}: {line[:600]}')
assert all(len(row['failures'])==(1 if row['run']==44207032757 else 2) for row in values)
marker=base/'attempt-1'/'retry-request.json';assert not marker.exists()
requests=[]
for ident in [44207032757,44207033000]:
 run=subprocess.run(['gh','run','rerun',str(ident),'--repo','link-assistant/formal-ai','--failed'],cwd=root,capture_output=True)
 requests.append({'run':ident,'exitCode':run.returncode,'stdout':run.stdout.decode(),'stderr':run.stderr.decode()})
marker.write_text(json.dumps({'head':head,'requestedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'One unchanged-head retry for collected checkout-only failures; no timeout or checkout policy changed.','requests':requests,'independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps({'retries':requests}))
assert all(item['exitCode']==0 for item in requests)
