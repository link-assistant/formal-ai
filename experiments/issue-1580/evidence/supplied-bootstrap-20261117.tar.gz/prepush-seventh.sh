set -eu
test "$(git branch --show-current)" = issue-1580-8d61a32a61e1
git fetch origin main
git merge-base --is-ancestor origin/main HEAD
git diff --check
gh run list --repo link-assistant/formal-ai --branch "$(git branch --show-current)" --status in_progress --limit 100 --json databaseId,workflowName,headSha > /tmp/issue-1580-research/prepush-seventh-active.json
gh run list --repo link-assistant/formal-ai --branch "$(git branch --show-current)" --status queued --limit 100 --json databaseId,workflowName,headSha > /tmp/issue-1580-research/prepush-seventh-queued.json
python3 -c 'import json; from pathlib import Path; paths=[Path("/tmp/issue-1580-research/prepush-seventh-"+s+".json") for s in ["active","queued"]]; assert all(not json.loads(p.read_text()) for p in paths); print("No active or queued branch workflows.")'
git diff 09021cb30ed98851f59f8b55f2cf71470ec613f4..HEAD -- scripts/check-sccache-write-health.sh rust/tests/web/sccache-outage-fallback.test.mjs .github/actions/setup-sccache/action.yml experiments/issue-1580/template-go-result-integrity.test.mjs
git status --short
