from pathlib import Path
import subprocess
for name in ['rust/src/structured_log.rs','js/server/read-access.mjs','rust/tests/web/issue-1582-defaults.test.mjs','rust/tests/web/issue-1582-permissions.test.mjs']:
    p=Path(name);lines=p.read_text().splitlines()
    print('FILE',name,'LINES',len(lines))
    if len(lines)<220:print('\n'.join(lines))
    else:print('\n'.join(lines[:120]))
r=subprocess.run(['rg','-n','structured_log|open_file|log_file|diagnostic_writer','rust/src','rust/tests/web/structured-diagnostics.test.mjs','--glob','*.rs'],capture_output=True,text=True)
print('REFERENCES',r.stdout[:6000])
