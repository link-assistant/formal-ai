from pathlib import Path
import gzip,sys
root=Path("experiments/issue-1580/evidence/checks/calendar-clock-preservation")
names=sys.argv[1:] or ["complete-local-gates","clock-tests","ledger-tests","fast-profile-tests","projection-currency"]
for name in names:
 lines=gzip.decompress((root/(name+".log.gz")).read_bytes()).decode().splitlines()
 print("LOG",name,"TOTAL",len(lines))
 assert len(lines)<=1500
 for i,line in enumerate(lines,1):print(f"{i}: {line}")
