set -eu
rg -n 'array_(any|all|find)|\|>|function|private\(set\)|public\(set\)' experiments/issue-1580/fixtures/php-template/scripts
sed -n '1,140p' experiments/issue-1580/fixtures/php-template/scripts/src/Process.php
sed -n '1,130p' experiments/issue-1580/fixtures/php-template/scripts/src/ProcessResult.php
sed -n '1,100p' /tmp/issue-1580-research/templates/php-complete/composer.json
