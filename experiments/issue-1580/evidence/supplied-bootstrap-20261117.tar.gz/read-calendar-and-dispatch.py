from pathlib import Path
windows=[
 ("js/worker/formal_ai_worker_calendar_and_proofs.js",400,55),
 ("js/worker/formal_ai_worker_calendar_and_proofs.js",480,65),
 ("rust/src/solver_handlers/calendar_create.rs",305,60),
 ("rust/src/solver_handlers/calendar_create.rs",400,65),
 ("data/seed/handler-precedence.lino",1,80),
 ("rust/src/solver_synthesis.rs",85,80),
 ("rust/src/solver_synthesis.rs",265,110),
 ("js/worker/formal_ai_worker_arithmetic_and_numeric_lists.js",410,10),
]
for name,start,count in windows:
 lines=Path(name).read_text().splitlines()
 print("FILE",name,"WINDOW",start,count,"OF",len(lines))
 for i in range(start-1,min(start-1+count,len(lines))):print(f"{i+1}: {lines[i]}")
p=Path("experiments/issue-1580/evidence/checks/calendar-clock-preservation/validation-completion.json")
print("VALIDATION",p.read_text() if p.exists() else "RUNNING")
