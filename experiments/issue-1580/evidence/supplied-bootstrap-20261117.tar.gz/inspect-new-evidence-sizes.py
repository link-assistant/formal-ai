from pathlib import Path
import subprocess, json

paths = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', 'experiments/issue-1580/evidence']).decode().splitlines()
rows = []
for name in paths:
    path = Path(name)
    if path.suffix in ['.gz', '.png']:
        continue
    raw = path.read_bytes()
    if len(raw.splitlines()) > 1500 or len(raw) > 250000:
        rows.append({'file': name, 'bytes': len(raw), 'lines': len(raw.splitlines())})
print(json.dumps(rows, indent=2))
