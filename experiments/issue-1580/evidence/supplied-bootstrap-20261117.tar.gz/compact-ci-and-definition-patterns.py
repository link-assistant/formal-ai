import gzip,json,pathlib
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
base=pathlib.Path('/tmp/issue-1580-research/ci-logs/summary-governed-7f19154a')
for name in ['outcome.json','latest-runs.json']:
 p=base/name
 if p.exists():
  data=json.loads(p.read_text())
  if name=='latest-runs.json':
   if isinstance(data,list): data=[r for page in data for r in page.get('workflow_runs',[])]
   elif isinstance(data,dict): data=data.get('workflow_runs',[])
   rows=[{key:r.get(key) for key in ['id','name','status','conclusion','head_sha','created_at','updated_at']} for r in data]
   print('CI',{'count':len(rows),'unfinished':[r for r in rows if r.get('status')!='completed'],'failed':[r for r in rows if r.get('conclusion')not in ['success','skipped'] and r.get('status')=='completed']})
  else:print(name,data)
for name in ['data/seed/prompt-patterns.lino','rust/src/concepts.rs','rust/src/language.rs','rust/src/concept_lookup.rs']:
 p=root/name
 lines=p.read_text().splitlines()
 wanted=set()
 for i,line in enumerate(lines):
  if any(x in line for x in ['how does','how-does','fn strip_suffix_pattern','enum SourceTier','struct Language','Spanish','pub const']):wanted.update(range(max(0,i-2),min(len(lines),i+15)))
 print('FILE',name)
 for i in sorted(wanted):print(f'{i+1}: {lines[i]}')
