from pathlib import Path
import datetime,json,subprocess
repo='link-assistant/formal-ai';branch='issue-1580-8d61a32a61e1';published='e120c05b4d8e35d51e4c1efb95e9b0c46c8d42b5'
def run(*args):return subprocess.run(args,capture_output=True,text=True,check=True).stdout.strip()
assert run('git','branch','--show-current')==branch
assert run('git','rev-parse','HEAD')==published
assert run('git','ls-remote','origin','refs/heads/'+branch).split()[0]==published
run('git','fetch','origin','main')
subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD'],check=True)
runs=json.loads(run('gh','run','list','--repo',repo,'--branch',branch,'--commit',published,'--limit','100','--json','databaseId,workflowName,status,conclusion,createdAt,headSha'))
assert len(runs)==24 and all(r['status']=='completed' and r['conclusion']=='success' and r['headSha']==published for r in runs)
for status in ['in_progress','queued']:
 rows=json.loads(run('gh','run','list','--repo',repo,'--branch',branch,'--status',status,'--limit','100','--json','databaseId,workflowName,headSha'))
 assert not rows,(status,rows)
p=Path('experiments/issue-1580/evidence/checks/audit-inventory-boundary/preflight.json');p.write_text(json.dumps({'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'previousHead':published,'branch':branch,'main':run('git','rev-parse','origin/main'),'successfulWorkflows':len(runs),'runningOrQueued':[]},indent=2)+'\n')
print(p.read_text())
