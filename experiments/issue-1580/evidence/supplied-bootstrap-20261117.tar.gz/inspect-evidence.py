import gzip,json,re
from pathlib import Path
p=Path('experiments/issue-1580/evidence/ci')
for name in ['all-cited-and-latest.json','summary.json']:
    rows=json.loads((p/name).read_text())
    print(name, len(rows),type(rows).__name__)
    print(json.dumps(rows[0])[:2000])
print('timing candidates')
for run in ['43815999666','43805800653']:
    lines=gzip.decompress((p/(run+'.log.gz')).read_bytes()).decode(errors='replace').splitlines()
    selected=[(i+1,line) for i,line in enumerate(lines) if re.search(r'(timed out|budget|test result: FAILED|Timeout|exceeded|running for over|##\[error\])',line)]
    for number,line in selected[-65:]: print(run,number,line[:650])
