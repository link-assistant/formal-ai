from pathlib import Path
import subprocess
r=Path('/tmp/gh-issue-solver-1794900398048')
for args in [['rg','-n','--glob','*.mjs','generated-native-programs.mjs','scripts'],['rg','-n','refresh-reviewed|previous-baseline|reader-sha','rust/tests/web/rust-specification-unicode-identifiers.test.mjs'],['rg','-n','FORMAL_AI_META_LANGUAGE|meta-language','experiments/issue-1580/evidence/checks/language-source-binding-final/outcome.json']]:
    p=subprocess.run(args,cwd=r,text=True,capture_output=True); print(p.stdout[:18000]);print(p.stderr)
for name in ['scripts/generate-runtime-feature-inventory.mjs','packages/picomatch-compat/README.md']:
    print('\nFILE',name);print((r/name).read_text())
