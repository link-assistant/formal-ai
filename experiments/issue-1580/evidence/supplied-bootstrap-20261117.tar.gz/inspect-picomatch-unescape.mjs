import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const before=require('/tmp/issue-1580-research/picomatch/package');
const after=require('/tmp/gh-issue-solver-1794900398048/packages/picomatch-compat');
for(const pattern of ['+(a\\*)','+(\\*)','+(\\*a)','+([!]*])']) {
 for(const options of [{},{unescape:true},{posix:true}]) {
  console.log(JSON.stringify({pattern,options,before:before.makeRe(pattern,options).source,
   after:after.makeRe(pattern,options).source}));
 }
}
