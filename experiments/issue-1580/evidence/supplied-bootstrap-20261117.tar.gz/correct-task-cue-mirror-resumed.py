from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import traceback

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research/task-cue-mirror-correction-resumed')
base = root / 'experiments/issue-1580/evidence/checks/quoted-passage-cues/mirror-correction-resumed'
if len(sys.argv) == 1:
    scratch.mkdir(exist_ok=False)
    base.mkdir(exist_ok=False)
    with (scratch / 'worker.log').open('wb') as stream:
        process = subprocess.Popen([sys.executable, __file__, 'finish'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': process.pid, 'scratch': str(scratch)}))
    sys.exit(0)
assert sys.argv[1:] == ['finish']
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
records = []
def run(name, args):
    started = time.monotonic()
    result = subprocess.run(args, cwd=root, env=environment, capture_output=True)
    raw = result.stdout + result.stderr
    packed = gzip.compress(raw, mtime=0)
    (base / (name + '.log.gz')).write_bytes(packed)
    row = {'name': name, 'argv': args, 'exitCode': result.returncode, 'seconds': round(time.monotonic() - started, 3), 'rawLines': len(raw.splitlines()), 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest()}
    records.append(row)
    print(json.dumps(row), flush=True)
    assert result.returncode == 0, (name, raw.decode()[-4000:])
    return raw
complete = False
try:
    prior = root / 'experiments/issue-1580/evidence/checks/quoted-passage-cues/final-gates'
    for attempt in range(20):
        if (prior / 'results.json').exists():
            break
        time.sleep(30)
    assert (prior / 'results.json').exists(), 'Full inventory has not completed; do not mutate its inputs.'
    report = json.loads((prior / 'results.json').read_text())
    assert not report['complete']
    payload = gzip.decompress((prior / 'all-gates.log.gz').read_bytes()).decode()
    failed = re.findall(r'^FAIL (\S+)', payload, re.M)
    assert set(failed) == {'check-notation', 'check-package-self-containment', 'check-status-render'}, failed
    statuses = re.findall(r'^(PASS|FAIL|SKIP) (\S+)', payload, re.M)
    assert len(statuses) == 138, len(statuses)
    (base / 'original-inventory.json').write_text(json.dumps({'pass': sum(state == 'PASS' for state, _ in statuses), 'fail': len(failed), 'excluded': sum(state == 'SKIP' for state, _ in statuses), 'failed': failed, 'sourcePayload': '../final-gates/all-gates.log.gz'}, indent=2) + '\n')
    before = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root).decode().splitlines()
    run('package-mirror-writer', ['node', 'scripts/mirror-package-data.mjs', '--write'])
    run('status-surface-writer', ['node', 'scripts/render-status.mjs', '--write'])
    after = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root).decode().splitlines()
    assert set(after) - set(before) == {'rust/embedded/data/seed/text-formalization.lino', 'docs/status.md'}, set(after) - set(before)
    assert (root / 'rust/embedded/data/seed/text-formalization.lino').read_bytes() == (root / 'data/seed/text-formalization.lino').read_bytes()
    run('corrected-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', ','.join([*failed, 'check-render-status-js-twin'])])
    details = []
    for index, name in enumerate(failed, 1):
        raw = (root / 'experiments/formal_ai_subagent/sandboxes/gates' / (name + '.log')).read_bytes()
        packed = gzip.compress(raw, mtime=0)
        filename = f'gate-{index:03d}.log.gz'
        (base / filename).write_bytes(packed)
        details.append({'name': name, 'log': filename, 'rawLines': len(raw.splitlines()), 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest()})
    (base / 'gate-details.json').write_text(json.dumps(details, indent=2) + '\n')
    run('whitespace', ['git', 'diff', '--check'])
    complete = True
except BaseException:
    traceback.print_exc()
result = {'complete': complete, 'checks': records, 'observedAt': datetime.now(timezone.utc).isoformat(), 'nativeExecuted': False, 'memoryEventsAfter': Path('/sys/fs/cgroup/memory.events').read_text(), 'independentAuthorshipCredit': 0}
(base / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'checks'}), flush=True)
sys.exit(0 if complete else 1)
