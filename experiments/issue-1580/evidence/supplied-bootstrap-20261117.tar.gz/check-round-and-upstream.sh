set -eu
timeout 600 node --test --test-concurrency=1 experiments/issue-1580/template-go-result-integrity.test.mjs > /tmp/issue-1580-research/template-go-result-integrity.log 2>&1
cat /tmp/issue-1580-research/template-go-result-integrity.log
gh run list --repo link-assistant/formal-ai --branch issue-1580-8d61a32a61e1 --limit 50 --json databaseId,workflowName,status,conclusion,createdAt,headSha > /tmp/issue-1580-research/new-head-runs.json
python3 -c 'import json,subprocess; p="/tmp/issue-1580-research/new-head-runs.json"; head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(); runs=[x for x in json.load(open(p)) if x["headSha"]==head]; print("Current head",head,"runs",len(runs)); [print(x["databaseId"],x["workflowName"],x["status"],x["conclusion"]) for x in runs if x["conclusion"]!="success"]'
gh api 'repos/link-foundation/go-ai-driven-development-pipeline-template/issues?state=all&per_page=100' --paginate --slurp > /tmp/issue-1580-research/go-upstream-issues.json
python3 -c 'import json; pages=json.load(open("/tmp/issue-1580-research/go-upstream-issues.json")); [print(x["number"],x["state"],x["title"]) for page in pages for x in page if not x.get("pull_request")]'
