set -eu
python3 /tmp/issue-1580-research/refresh-reviewed-witness.py
for name in rust-specification-fixture-integrity rust-specification-unicode-identifiers default-branch-build-policy stale-pull-request-report; do
  timeout 600 node --test --test-concurrency=1 "rust/tests/web/$name.test.mjs" > "/tmp/issue-1580-research/$name-current.log" 2>&1 || { tail -n 90 "/tmp/issue-1580-research/$name-current.log"; exit 1; }
  tail -n 9 "/tmp/issue-1580-research/$name-current.log"
done
node experiments/formal_ai_subagent/local-gates.mjs --list
rg -n 'documentation|specification.*integrity|governed-baseline|native.*source' experiments/formal_ai_subagent/local-gates.mjs
git diff --check
