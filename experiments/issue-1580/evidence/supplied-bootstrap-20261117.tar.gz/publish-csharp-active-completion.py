from pathlib import Path
import gzip,hashlib,json,subprocess
def run(args):return subprocess.run(args,check=True,text=True,capture_output=True).stdout
branch='issue-1580-8d61a32a61e1'; repo='link-assistant/formal-ai'
assert run(['git','branch','--show-current']).strip()==branch
base=Path('experiments/issue-1580/evidence/checks/csharp-changeset-collision')
records=[]
for gate in ['check-abbreviations','check-file-size','check-file-size-js-twin']:
 command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]
 result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log=base/('active-review-archive-'+gate+'.log.gz'); log.write_bytes(gzip.compress(result.stdout,mtime=0))
 row={'gate':gate,'exitCode':result.returncode,'command':command,'log':str(log),'rawSha256':hashlib.sha256(result.stdout).hexdigest()}
 records.append(row); print(json.dumps(row)); print(result.stdout.decode())
 assert result.returncode==0
(base/'active-review-archive-validation.json').write_text(json.dumps({'claim':'All three touched gates pass after archiving 333 supplied bootstrap scripts and the current Formal AI command evidence. Existing six-case abbreviation regression passed before archival. No Rust or template runtime build performed.','checks':records,'independentFormalAiReasoningCredit':0},indent=2)+'\n')
names=run(['git','diff','--name-only']).splitlines()
assert all(name.startswith(('docs/case-studies/issue-1580/','experiments/issue-1580/')) for name in names)
run(['git','add','--','docs/case-studies/issue-1580','experiments/issue-1580'])
run(['git','diff','--cached','--check'])
review=json.loads(Path('docs/case-studies/issue-1580/templates/csharp-partial-semantic-review.json').read_text())
assert review['counts']=={'activeFullyRead':158,'historicalUnread':179,'activeUnread':0}
print('STAGED',run(['git','diff','--cached','--stat'])[-5000:])
print(run(['git','commit','-m','docs: complete the active C# template source review']))
assert run(['git','status','--porcelain']).strip()==''
assert subprocess.run(['git','merge-base','--is-ancestor','origin/main','HEAD']).returncode==0
for status in ['in_progress','queued']:
 rows=json.loads(run(['gh','run','list','--repo',repo,'--branch',branch,'--status',status,'--limit','100','--json','databaseId,workflowName,headSha']))
 print(status,json.dumps(rows)); assert rows==[]
expected='0f90c0a7a3bdd77b7d31c276a180d5ee297e57f6'
assert json.loads(run(['gh','api',f'repos/{repo}/branches/{branch}']))['commit']['sha']==expected
head=run(['git','rev-parse','HEAD']).strip(); print('PUBLISH HEAD',head)
print(run(['git','log','--oneline',expected+'..HEAD']))
push=subprocess.run(['git','push','origin',f'HEAD:refs/heads/{branch}'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
print(push.stdout); assert push.returncode==0
assert json.loads(run(['gh','api',f'repos/{repo}/branches/{branch}']))['commit']['sha']==head
assert run(['git','status','--porcelain']).strip()==''
print(json.dumps({'head':head,'pushed':True,'clean':True,'pullRequest':'https://github.com/link-assistant/formal-ai/pull/1581','broaderAcceptance':'unfinished; keep draft and unmerged'},indent=2))
