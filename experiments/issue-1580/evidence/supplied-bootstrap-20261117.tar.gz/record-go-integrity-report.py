import json
from pathlib import Path

root = Path.cwd()
upstream = root / 'experiments/issue-1580/upstream'
url = 'https://github.com/link-foundation/go-ai-driven-development-pipeline-template/issues/20'
identity = {
    'repository': 'link-foundation/go-ai-driven-development-pipeline-template',
    'title': 'CI: stale action pins bypass integrity verification on non-PR events',
    'url': url,
    'bodyFile': 'go-stale-pin-integrity-report.md',
    'evidenceCommit': 'a4053def4bd4b921001fdf84a026ae35deebfc39',
}
index = upstream / 'template-report-identities.json'
records = json.loads(index.read_text())
assert not any(row['url'] == url for row in records), 'report already recorded'
records.append(identity)
index.write_text(json.dumps(records, indent=2) + '\n')
filed = upstream / 'filed-issues.txt'
assert url not in filed.read_text()
filed.write_text(filed.read_text().rstrip() + '\n' + url + '\n')
(upstream / identity['bodyFile']).write_text(Path('/tmp/issue-1580-research/go-stale-pin-report-body.md').read_text())
readme = root / 'docs/case-studies/issue-1580/templates/README.md'
old = 'The upstream report draft is retained under `experiments/issue-1580/upstream/`; it is not yet filed and no upstream repair is claimed.'
new = 'The report is filed as [Go #20](' + url + ') with executable evidence at `a4053def4bd4b921001fdf84a026ae35deebfc39`. Its posted body and identity are retained under `experiments/issue-1580/upstream/`. No upstream repair is claimed.'
text = readme.read_text()
assert text.count(old) == 1
readme.write_text(text.replace(old, new))
case = root / 'docs/case-studies/issue-1580/README.md'
old = 'The report is drafted pending publication of immutable executable evidence.'
new = 'The report is filed as [Go template #20](' + url + ') with the published executable regression at `a4053def4bd4b921001fdf84a026ae35deebfc39`; no upstream repair is claimed.'
text = case.read_text()
assert text.count(old) == 1
case.write_text(text.replace(old, new))
plan = root / 'experiments/issue-1580/work-plan.md'
with plan.open('a') as handle:
    handle.write('\n## Go integrity report filed (2026-11-17)\n\nThe pinned-source stale-pin regression is published at `a4053def4bd4b921001fdf84a026ae35deebfc39` and filed as [Go template #20](' + url + '). The posted body and immutable evidence identity are recorded locally. Reporting does not establish an upstream fix or complete the seven other semantic template reviews. Current head `e6627385d3ef58435df22ec61d4dfdc4551c9d28` still awaits all hosted results.\n')
print(json.dumps({'recorded': url, 'templateReports': len(records)}, indent=2))
