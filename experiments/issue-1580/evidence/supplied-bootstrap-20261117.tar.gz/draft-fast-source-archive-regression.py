from pathlib import Path
p=Path('rust/tests/web/fast-pull-request-production-profile.test.mjs')
text=p.read_text()
anchor="test('Cargo security acquisition retains the full crate and audit proofs without unrelated evidence', () => {"
assert anchor in text and "source checkout excludes historical archive formats" not in text
addition="""test('source checkout excludes historical archive formats and retains authored diagnostics', () => {
  const patterns=workflow('release.yml').jobs['fast-pr-lint'].steps[0].with['sparse-checkout'];
  const archives=['docs/case-studies/issue-730/raw-data/ci-logs/branch-29482019343.log',
    ...['gz','log','zip','tgz','diff'].flatMap(extension=>[
      `docs/case-studies/issue-1580/raw-data/archive.${extension}`,
      `experiments/issue-1580/evidence/round/archive.${extension}`])];
  const retained=['docs/requirements/1580.md','docs/case-studies/issue-1580/README.md',
    'experiments/issue-1580/evidence/round/proof.lino',
    'experiments/issue-1580/evidence/round/receipt.json',
    'experiments/issue-1580/evidence/round/reproduce.mjs',
    'rust/tests/fixtures/expected.log','scripts/read-archive.mjs','Cargo.lock'];
  assert.deepEqual(checkoutSelection(patterns,[...retained,...archives]),retained);
  for(const file of archives)assert.equal(fileLimit(file),null,file);
});


"""
p.write_text(text.replace(anchor,addition+anchor))
print('Drafted archive selection regression; production checkout remains unchanged.')
