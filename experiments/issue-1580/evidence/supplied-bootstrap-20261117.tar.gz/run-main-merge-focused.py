from pathlib import Path
import datetime,gzip,hashlib,json,os,resource,subprocess,sys,time,tomllib
root=Path("/tmp/gh-issue-solver-1794900398048")
directory=root/"experiments/issue-1580/evidence/checks/main-merge-512ce428"
if len(sys.argv)==1:
    assert not (directory/"focused-completion.json").exists()
    previous=directory/"focused-bootstrap.log"
    if previous.exists():
        assert "FileNotFoundError" in previous.read_text()
        (directory/"focused-initial-bootstrap-failure.log.gz").write_bytes(gzip.compress(previous.read_bytes(),mtime=0))
    paths=[".cargo/audit.toml","data/meta/worker-line-budget/formal_ai_worker_obligations.lino","experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8"]
    subprocess.run(["git","add","--",*paths],cwd=root,check=True)
    assert not subprocess.run(["git","diff","--name-only","--diff-filter=U"],cwd=root,capture_output=True,text=True,check=True).stdout.strip()
    with (directory/"focused-bootstrap.log").open("wb") as stream:
        child=subprocess.Popen([sys.executable,__file__,"finish"],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({"pid":child.pid,"startedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"completion":str(directory/"focused-completion.json")}))
    sys.exit(0)
assert sys.argv==[__file__,"finish"]
env=dict(os.environ);env["NODE_OPTIONS"]="--max-old-space-size=256"
available=int(Path("/sys/fs/cgroup/memory.max").read_text())-int(Path("/sys/fs/cgroup/memory.current").read_text())
assert available>512*1024*1024,f"Insufficient measured memory headroom: {available}"
files=[
 "rust/tests/web/fast-pull-request-production-profile.test.mjs",
 "rust/tests/web/issue-1588-intent-spans.test.mjs",
 "rust/tests/web/rust-specification-unicode-identifiers.test.mjs",
 "rust/tests/web/rust-specification-fixture-integrity.test.mjs",
 "rust/tests/web/cargo-audit-blocked-proof.test.mjs",
]
changed=subprocess.run(["git","diff","--cached","--name-only","--diff-filter=ACM"],cwd=root,capture_output=True,text=True,check=True).stdout.splitlines()
rust=[name for name in changed if name.endswith(".rs")]
manifest=tomllib.loads((root/"rust/Cargo.toml").read_text())
edition=manifest.get("package",{}).get("edition","2021")
assert isinstance(edition,str)
commands=[["rustfmt","--check","--edition",edition,"--config","skip_children=true",*rust]]
commands += [["timeout","600","node","--max-old-space-size=256","--test","--test-concurrency=1",name] for name in files]
rows=[];started=time.time()
for n,command in enumerate(commands,1):
    before=time.time()
    result=subprocess.run(command,cwd=root,env=env,capture_output=True)
    raw=result.stdout+result.stderr
    log=f"focused-{n}.log.gz"
    (directory/log).write_bytes(gzip.compress(raw,mtime=0))
    row={"command":command,"status":result.returncode,"durationSeconds":round(time.time()-before,3),"rawSha256":hashlib.sha256(raw).hexdigest(),"log":log}
    rows.append(row)
    print(json.dumps(row),flush=True)
completion={"status":0 if all(row["status"]==0 for row in rows) else 1,"durationSeconds":round(time.time()-started,3),"checks":rows,"nodeHeapMiB":256,"measuredAvailableBytes":available,"childrenPeakRssKiB":resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,"rustCompilation":False,"independentAuthorshipCredit":0}
(directory/"focused-completion.json").write_text(json.dumps(completion,indent=2)+"\n")
print(json.dumps({"status":completion["status"],"durationSeconds":completion["durationSeconds"],"childrenPeakRssKiB":completion["childrenPeakRssKiB"]}),flush=True)
