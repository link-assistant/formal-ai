import pathlib, subprocess, hashlib

print(subprocess.check_output(['git','branch','--show-current'],text=True).strip())
print(subprocess.check_output(['git','status','--short'],text=True))
for name in ['rust/tests/web/rust-specification-unicode-identifiers.test.mjs','experiments/issue-1571/governed-witness-delta.mjs']:
    p=pathlib.Path(name)
    lines=p.read_text().splitlines()
    print('FILE',name,'LINES',len(lines))
    for n,line in enumerate(lines[:150],1): print(f'{n}: {line}')
for name in ['scripts/lib/rust-specification-cases.mjs','experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8']:
    p=pathlib.Path(name)
    print('INPUT',name,'BYTES',p.stat().st_size,'SHA256',hashlib.sha256(p.read_bytes()).hexdigest())
