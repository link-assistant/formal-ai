from pathlib import Path
path=Path('/tmp/issue-1580-research/record-java-pages-79-92.py')
print(path.read_text())
path=Path('/tmp/issue-1580-research/child-evidence-all-gates/all-gates.log')
print('GATE PROGRESS')
print('\n'.join(path.read_text().splitlines()[-15:]))
