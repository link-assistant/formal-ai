from pathlib import Path

p = Path('rust/tests/unit/issue_1133_hive_mind_three_runs.rs')
s = p.read_text()
s = s.replace('    let append = append_provider::AppendWorkspace::new();\n', '    let append = append_provider::AppendWorkspace::new();\n    let mut workspace = crate::observed_plan_tools::ToolWorkspace::new("issue-1133-source-probes");\n', 1)
s = s.replace('                let result = match &appended {', '''                // Source observations must describe the actual workspace, including ENOENT.
                // Compiler and network results remain the explicit per-test fixtures.
                let observed = if appended.is_none()
                    && (args["command"].as_str().is_some_and(|command| {
                        command.contains("workspace-source-v1")
                    }) || matches!(call.tool.as_str(), "Write" | "write"))
                {
                    Some(workspace.execute(&format!("c{step}"), &call))
                } else {
                    None
                };
                let result = match &appended {''', 1)
s = s.replace('                    None => results(&call.tool, &call.arguments),', '                    None if observed.is_some() => String::new(),\n                    None => results(&call.tool, &call.arguments),', 1)
s = s.replace('                if let Some(receipt) = appended {', '''                if let Some(observed) = observed {
                    *messages.last_mut().expect("recorded source observation") = observed;
                }
                if let Some(receipt) = appended {''', 1)
p.write_text(s)

p = Path('rust/tests/unit/issue_1133_hive_mind_three_runs/extended.rs')
s = p.read_text()
s = s.replace('fn expected_owned_recipe_commit(planned:', '''// These two fixtures stop at the named-branch commit phase. Prepared-PR delivery,
// feedback and readiness are exercised with real Git in issue_1158/1160/1162.
fn commit_phase_prompt() -> String {
    prompt().replace(&format!("Update the pull request at {PR}.\\n"), "")
}

fn expected_owned_recipe_commit(planned:''', 1)
marker = '    canonical_work_item_steps::fill(\n        "task-scaffold-commit-command",'
addition = '''    let template = canonical_work_item_steps::fill("workflow_template", &[("{path}", &paths[0])]);
    let header = template.lines().next().expect("workflow provenance header");
    let name = template.lines().find(|line| line.starts_with("name: ")).expect("workflow name");
    let workflow = planned.iter().find(|call| {
        let args: serde_json::Value = serde_json::from_str(&call.arguments).unwrap();
        call.tool == "write" && args["path"].as_str().is_some_and(|path| path.starts_with(".github/workflows/"))
    }).expect("recipe workflow write");
    let args: serde_json::Value = serde_json::from_str(&workflow.arguments).unwrap();
    let source = args["content"].as_str().expect("workflow source");
    assert!(source.lines().any(|line| line == header));
    assert!(source.lines().any(|line| line == name));
    let path = path_of(workflow);
    let (directory, _) = path.rsplit_once('/').expect("workflow directory");
    let retire = canonical_work_item_steps::fill("superseded-workflow-retire-command", &[
        ("{dir}", &quote(directory)), ("{workflow}", &quote(&path)),
        ("{header}", &quote(header)), ("{name}", &quote(name)),
    ]);
'''
assert marker in s
s = s.replace(marker, addition + marker, 1)
s = s.replace('            ("{commit}", &inner),', '            ("{retire}", &retire),\n            ("{commit}", &inner),', 1)
for name in ['the_full_claude_code_drive_reads_builds_verifies_and_pushes_kotlin', 'a_verified_work_item_is_committed_and_pushed_to_the_named_branch']:
    start = s.index('fn ' + name + '()')
    end = s.index('\n#[test]', start)
    chunk = s[start:end]
    assert 'ChatMessage::user(prompt())' in chunk
    chunk = chunk.replace('ChatMessage::user(prompt())', 'ChatMessage::user(commit_phase_prompt())', 1)
    if name.startswith('the_full'):
        chunk = chunk.replace(name, 'the_claude_code_commit_phase_reads_builds_verifies_and_pushes_kotlin')
    s = s[:start] + chunk + s[end:]
p.write_text(s)
