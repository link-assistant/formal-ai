from pathlib import Path
import subprocess,json,hashlib,gzip
directory=Path('experiments/issue-1580/evidence/checks/python-runtime-provisioning');directory.mkdir(parents=True,exist_ok=True)
checks=[
 ('runtime-regression',['timeout','600','node','--test','--test-concurrency=1','--test-reporter=tap','experiments/issue-1580/template-python-runtime.test.mjs']),
 ('maintained-observations',['timeout','600','node','--test','--test-concurrency=1','--test-reporter=tap','rust/tests/web/issue-1580-template-observations.test.mjs']),
 ('fast-profile',['timeout','600','node','--test','--test-concurrency=1','--test-reporter=tap','rust/tests/web/fast-pull-request-production-profile.test.mjs']),
 ('default-branch-policy',['timeout','600','node','--test','--test-concurrency=1','--test-reporter=tap','rust/tests/web/default-branch-build-policy.test.mjs']),
]
records=[]
for name,command in checks:
 result=subprocess.run(command,capture_output=True,text=True);content=(result.stdout+result.stderr).encode()
 log=directory/(name+'.log.gz');log.write_bytes(gzip.compress(content,mtime=0))
 record={'name':name,'command':command,'exitCode':result.returncode,'log':str(log),'uncompressedSha256':hashlib.sha256(content).hexdigest()};records.append(record)
 print(json.dumps(record));print(content.decode() if result.returncode else '\n'.join(content.decode().splitlines()[-10:]),flush=True)
 if result.returncode:break
(directory/'checks.json').write_text(json.dumps(records,indent=2)+'\n')
assert len(records)==len(checks) and all(r['exitCode']==0 for r in records)
