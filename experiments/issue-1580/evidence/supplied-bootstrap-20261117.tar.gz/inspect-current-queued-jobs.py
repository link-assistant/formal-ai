from pathlib import Path
import gzip
import json
import subprocess

directory = Path('/tmp/issue-1580-research/head-09021cb30')
for run_id in [44075398138,44075398015,44075397339]:
    raw=subprocess.check_output(['gh','api',f'repos/link-assistant/formal-ai/actions/runs/{run_id}/jobs?filter=latest&per_page=100','--paginate','--slurp'])
    (directory/f'jobs-{run_id}.json.gz').write_bytes(gzip.compress(raw,mtime=0))
    jobs=[job for page in json.loads(raw) for job in page.get('jobs',[])]
    print(json.dumps({'run':run_id,'jobs':len(jobs),'complete':sum(job['status']=='completed' for job in jobs),'pending':[{'id':job['id'],'name':job['name'],'status':job['status'],'startedAt':job['started_at'],'runner':job.get('runner_name'),'labels':job.get('labels')} for job in jobs if job['status']!='completed'],'failed':[{'id':job['id'],'name':job['name'],'conclusion':job['conclusion']} for job in jobs if job['status']=='completed' and job['conclusion'] not in ['success','skipped']]}))
