from pathlib import Path
import datetime,gzip,hashlib,json,subprocess

sha='058e9bef1214f2f1bc25971243cb787703ed64f1'
base=Path('experiments/issue-1580/evidence/ci/main-058e9bef')
base.mkdir(parents=True,exist_ok=True)
args=['gh','api','--paginate','--slurp',f'repos/link-assistant/formal-ai/actions/runs?head_sha={sha}&event=push&per_page=100']
raw=subprocess.check_output(args)
pages=json.loads(raw)
runs=[r for page in pages for r in page['workflow_runs']]
assert all(r['head_sha']==sha and r['event']=='push' for r in runs)
(base/'push-runs.json.gz').write_bytes(gzip.compress(raw,mtime=0))
rows=[]
for r in runs:
    row={k:r[k] for k in ['id','name','status','conclusion','created_at','updated_at','head_sha','html_url']}
    if r['status']=='completed' and r['conclusion'] not in ['success','skipped','cancelled']:
        log=Path(f"/tmp/issue-1580-research/main-058e9bef-{r['id']}.log")
        with log.open('wb') as out:
            subprocess.run(['gh','run','view',str(r['id']),'--repo','link-assistant/formal-ai','--log'],stdout=out,check=True)
        data=log.read_bytes()
        archive=base/(str(r['id'])+'.log.gz')
        archive.write_bytes(gzip.compress(data,mtime=0))
        row.update(rawBytes=len(data),rawLines=len(data.splitlines()),rawSha256=hashlib.sha256(data).hexdigest(),log=archive.name)
    rows.append(row)
receipt={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'headSha':sha,'runs':rows}
(base/'inventory.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
