from pathlib import Path

path=Path('rust/tests/web/calendar-clock-preservation.test.mjs')
path.write_text(path.read_text()+r"""

test('chat API preserves the requested clock and declines a background clock', {timeout:30000}, async () => {
  const {mkdtempSync, rmSync} = await import('node:fs');
  const {tmpdir} = await import('node:os');
  const {join} = await import('node:path');
  const {startServer} = await import('../../../js/server/main.mjs');
  const directory = mkdtempSync(join(tmpdir(), 'formal-ai-calendar-clock-'));
  const env = {...process.env, FORMAL_AI_API_BEARER_TOKEN:'calendar-clock-control',
    FORMAL_AI_MEMORY_PATH:join(directory, 'memory.lino'),
    FORMAL_AI_CACHE_DIR:join(directory, 'cache'),
    FORMAL_AI_DIALOG_LOG_DIR:join(directory, 'dialogs'), FORMAL_AI_RECORD_CHAT:'0',
    FORMAL_AI_LIVE_FETCH:'0', FORMAL_AI_SOURCE_USAGE_RUST_GRAMMAR:'false'};
  let running;
  try {
    running = await startServer({host:'127.0.0.1', port:0, env});
    for (const row of [fixtures.events[0], fixtures.events[1], {prompt:fixtures.documents[1]}]) {
      const response = await fetch(running.url + '/v1/chat/completions', {
        method:'POST', headers:{authorization:'Bearer calendar-clock-control', 'content-type':'application/json'},
        body:JSON.stringify({model:'formal-ai', messages:[{role:'user', content:row.prompt}]}),
        signal:AbortSignal.timeout(10000),
      });
      assert.equal(response.status, 200);
      const body = await response.json();
      const answer = body.choices[0].message.content;
      if (row.time) {
        assert.ok(answer.includes(row.time), answer);
        assert.ok(answer.includes(row.zone), answer);
        assert.ok(answer.toLowerCase().includes(row.participant), answer);
        assert.match(answer, new RegExp('DTSTART[^\\r\\n]*T' + row.time.replace(':', '') + '00'));
      } else {
        assert.doesNotMatch(answer, /BEGIN:VEVENT/);
      }
    }
  } finally {
    if (running) await new Promise(resolve => running.server.close(resolve));
    rmSync(directory, {recursive:true, force:true});
  }
});
""")
ledger=Path('data/meta/main-only-regressions.lino')
ledger.write_text(ledger.read_text().replace(
 'introduced-by "PR #1589 request-span recognition, merged as 512ce428"',
 'introduced-by "clock normalization during request-span recognition (observed on main 512ce428)"'))
print('Added real local HTTP control; no remote network calls or Rust grammar builds.')
