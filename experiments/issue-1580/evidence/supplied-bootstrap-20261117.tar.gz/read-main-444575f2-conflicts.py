import subprocess
from pathlib import Path
for name in subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],text=True).splitlines():
    p=Path(name)
    if p.suffix=='.v8':continue
    lines=p.read_text().splitlines();show=set();active=False
    for i,line in enumerate(lines):
        if line.startswith('<<<<<<<'):active=True;show.update(range(max(0,i-6),i))
        if active:show.add(i)
        if line.startswith('>>>>>>>'):active=False;show.update(range(i+1,min(len(lines),i+7)))
    print('\nFILE',name)
    for i in sorted(show):print(f'{i+1}: {lines[i]}')
