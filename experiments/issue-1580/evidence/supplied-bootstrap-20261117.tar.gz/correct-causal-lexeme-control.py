from pathlib import Path
import subprocess

path=Path('experiments/issue-1580/trace-moon-lexeme.mjs')
source=path.read_text().replace("const withoutBecause = seed.replace('    lexeme en \"because\"\\n', '');", "const withoutCausalLexemes = seed.replace('    lexeme en \"because\"\\n', '').replace('    lexeme en \"because of\"\\n', '');")
source=source.replace('withoutBecause','withoutCausalLexemes')
source=source.replace("removedLine: '    lexeme en \"because\"'", "removedLines: ['    lexeme en \"because\"', '    lexeme en \"because of\"']")
path.write_text(source)
result=subprocess.run(['node','--max-old-space-size=256',str(path)],text=True,capture_output=True)
log=Path('/tmp/issue-1580-research/moon-causal-lexeme-comparison.log')
log.write_text(result.stdout+result.stderr)
print(f'LOG {log} exit={result.returncode}')
print(log.read_text())
raise SystemExit(result.returncode)
