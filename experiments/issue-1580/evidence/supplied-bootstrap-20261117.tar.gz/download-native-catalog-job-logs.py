from pathlib import Path
import gzip,hashlib,json,subprocess
base=Path('experiments/issue-1580/evidence/ci/main-015a6831/individual-native-catalog-jobs');base.mkdir(exist_ok=True)
records=[]
for job in (134419506413,134419506816):
 path=base/f'job-{job}.log.gz'
 if path.exists():raw=gzip.decompress(path.read_bytes())
 else:
  result=subprocess.run(['gh','api',f'repos/link-assistant/formal-ai/actions/jobs/{job}/logs','--allow-escape-sequences'],capture_output=True)
  assert result.returncode==0,result.stderr.decode();raw=result.stdout
  path.write_bytes(gzip.compress(raw,mtime=0))
 lines=raw.decode().splitlines()
 markers=[{'line':i,'characters':len(line),'prefix':line[:240]} for i,line in enumerate(lines,1) if 'google_trends_catalog' in line or 'right:' in line]
 record={'job':job,'rawBytes':len(raw),'rawLines':len(lines),'rawSha256':hashlib.sha256(raw).hexdigest(),'markers':markers}
 records.append(record);print(json.dumps(record,ensure_ascii=False))
(base/'receipts.json').write_text(json.dumps(records,indent=2)+'\n')
