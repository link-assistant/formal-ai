import json
from pathlib import Path

root = Path('/tmp/issue-1580-research/java-context')
for kind in ['issues', 'pulls']:
    rows = json.loads((root / (kind + '.json')).read_text())
    if rows and isinstance(rows[0], list):
        rows = [row for page in rows for row in page]
    print(kind, len(rows))
    for row in rows:
        if kind == 'issues' and 'pull_request' in row:
            continue
        if kind == 'pulls' and not row.get('merged_at'):
            continue
        print(row['number'], row.get('state'), row.get('title'), 'body-lines', len((row.get('body') or '').splitlines()), 'comments', row.get('comments'), 'merged', row.get('merged_at'))
