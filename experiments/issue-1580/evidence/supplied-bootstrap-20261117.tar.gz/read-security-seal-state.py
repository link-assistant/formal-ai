from pathlib import Path
import json

for path in [
    '/tmp/issue-1580-research/run-sealed-picomatch-gates.py',
    'experiments/issue-1580/evidence/checks/picomatch-single-branch/sealed-complete-gates.json',
    'experiments/issue-1580/evidence/checks/picomatch-single-branch/final-verification.json',
    '/tmp/issue-1580-research/sealed-complete-local-gates.log',
]:
    value = Path(path)
    print('FILE', path)
    print(value.read_text() if value.exists() else 'MISSING')
for path in ['docs/case-studies/issue-1580/README.md', 'experiments/issue-1580/work-plan.md']:
    lines=Path(path).read_text().splitlines()
    print('TAIL', path, 'total', len(lines))
    print('\n'.join(f'{index+1}: {lines[index]}' for index in range(max(0,len(lines)-38),len(lines))))
print('BOOTSTRAP CANDIDATES')
print('\n'.join(str(path) for path in Path('/tmp/issue-1580-research').glob('*archiv*')))
print('\n'.join(str(path) for path in Path('/tmp/issue-1580-research').glob('*commit*')))
