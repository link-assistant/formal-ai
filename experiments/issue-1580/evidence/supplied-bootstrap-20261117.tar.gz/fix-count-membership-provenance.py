from pathlib import Path
p=Path('rust/src/solver_handlers/verifiable_task.rs')
source=p.read_text()
before='''        let seeded_sources = (!retrieved_match)
            .then(|| {
                crate::verifiable_task::seeded_membership_sources(
                    &entity.surface,
                    subject,
                    &task.prose_language,
                )
            })
            .flatten();'''
after='''        // A retrieved match and a seed taxonomy proof are independent evidence.
        // Retain both when available: populating the source cache must not
        // erase the grounded membership path from the composition trace.
        let seeded_sources = crate::verifiable_task::seeded_membership_sources(
            &entity.surface,
            subject,
            &task.prose_language,
        );'''
assert source.count(before)==1
p.write_text(source.replace(before,after))
print('Retained independent seed membership evidence alongside retrieved matches; existing count and provenance assertions unchanged.')
