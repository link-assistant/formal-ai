import datetime, gzip, hashlib, json, pathlib, subprocess

repo='link-assistant/formal-ai'
head='2ec6ef93a80c7081a46816d1242bc0f7b843d5ff'
target=pathlib.Path('experiments/issue-1580/evidence/ci/published-2ec6ef93')
scratch=pathlib.Path('/tmp/issue-1580-research/published-2ec6ef93-failures')
target.mkdir(parents=True, exist_ok=True)
scratch.mkdir(parents=True, exist_ok=True)
receipt={'head':head,'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[]}
for label,run_id in [('layered',44197052235),('pipeline',44197053206)]:
    meta=subprocess.run(['gh','run','view',str(run_id),'--repo',repo,'--json','databaseId,headSha,status,conclusion,jobs,createdAt,updatedAt,url,event'],capture_output=True)
    assert meta.returncode==0,meta.stderr.decode()
    parsed=json.loads(meta.stdout)
    assert parsed['headSha']==head and parsed['status']=='completed'
    (target/f'{label}-{run_id}-metadata.json.gz').write_bytes(gzip.compress(meta.stdout,mtime=0))
    log=scratch/f'{label}-{run_id}.log'
    with log.open('wb') as output:
        process=subprocess.run(['gh','run','view',str(run_id),'--repo',repo,'--log'],stdout=output,stderr=subprocess.STDOUT)
    raw=log.read_bytes()
    archive=target/f'{label}-{run_id}.log.gz'
    archive.write_bytes(gzip.compress(raw,mtime=0))
    item={'workflow':label,'runId':run_id,'exitCode':process.returncode,'rawBytes':len(raw),'lines':len(raw.splitlines()),'sha256':hashlib.sha256(raw).hexdigest(),'archive':str(archive),'rawLog':str(log),'failedJobs':[{'id':j['databaseId'],'name':j['name'],'conclusion':j['conclusion']} for j in parsed['jobs'] if j['conclusion']!='success']}
    receipt['runs'].append(item)
    print(json.dumps(item,indent=2),flush=True)
    (target/'download-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
