from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,sys,traceback
root=Path('/tmp/gh-issue-solver-1794900398048')
out=root/'experiments/issue-1580/evidence/ci/native-b367d603/opener-round-preflight'
if len(sys.argv)==1:
    assert not out.exists();out.mkdir()
    with (out/'worker.stdout.log').open('wb') as stdout,(out/'worker.stderr.log').open('wb') as stderr:
        child=subprocess.Popen([sys.executable,__file__,'worker'],cwd=root,stdout=stdout,stderr=stderr,start_new_session=True)
    (out/'worker.json').write_text(json.dumps({'pid':child.pid})+'\n');print('Started preflight',child.pid);sys.exit(0)
def command(argv):
    result=subprocess.run(argv,cwd=root,capture_output=True,text=True)
    assert result.returncode==0,(argv,result.stderr)
    return result.stdout.strip()
def capture(name,argv):
    raw=command(argv).encode();(out/(name+'.json.gz')).write_bytes(gzip.compress(raw,mtime=0))
    print(name,len(raw),hashlib.sha256(raw).hexdigest(),flush=True);return json.loads(raw)
def work():
    assert command(['git','branch','--show-current'])=='issue-1580-8d61a32a61e1'
    assert command(['git','rev-parse','HEAD'])=='b367d603375dd23223861c92875e079a3a90df13'
    command(['git','fetch','origin','main'])
    main=command(['git','rev-parse','origin/main']);print('MAIN',main,flush=True)
    command(['git','merge-base','--is-ancestor','origin/main','HEAD'])
    old=root/'experiments/issue-1580/evidence/ci/checkout-7e89122c/refresh-20261118T014101Z'
    for name,endpoint in [('issue-comments','issues/1580/comments'),('pull-request-comments','issues/1581/comments'),('pull-request-inline-comments','pulls/1581/comments'),('pull-request-reviews','pulls/1581/reviews')]:
        values=capture(name,['gh','api','repos/link-assistant/formal-ai/'+endpoint,'--paginate'])
        previous={row['id']:row for row in json.loads(gzip.decompress((old/(name+'.json.gz')).read_bytes()))}
        current={row['id']:row for row in values}
        changed=[row for identifier,row in current.items() if previous.get(identifier)!=row]
        removed=sorted(set(previous)-set(current))
        print('FEEDBACK',name,'total',len(values),'changed',len(changed),'removed',removed,flush=True)
        for row in changed:print('CHANGED',row.get('html_url'),row.get('body'),flush=True)
        assert not changed and not removed,'Read changed feedback before publication'
    issue=capture('issue',['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','url,title,body,state'])
    print('ISSUE BODY',issue['body'],flush=True)
    subissues=capture('required-sub-issues',['gh','api','repos/link-assistant/formal-ai/issues/1580/sub_issues','--paginate'])
    print('SUBISSUES',json.dumps(subissues),flush=True);assert subissues==[],'Read every required sub-issue'
    published='b367d603375dd23223861c92875e079a3a90df13'
    pages=capture('head-runs',['gh','api','repos/link-assistant/formal-ai/actions/runs?branch=issue-1580-8d61a32a61e1&head_sha='+published+'&per_page=100','--paginate','--slurp'])
    runs=[row for page in pages for row in page['workflow_runs']]
    assert len(runs)==23 and all(row['status']=='completed' and row['head_sha']==published for row in runs)
    failed={row['id']:row['conclusion'] for row in runs if row['conclusion']!='success'}
    assert failed=={44220008975:'failure',44220008509:'failure'},failed
    for state in ['in_progress','queued']:
        values=capture(state,['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--status',state,'--limit','100','--json','databaseId,workflowName,headSha'])
        assert values==[],values
    pr=capture('pull-request',['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','url,isDraft,headRefOid,headRefName,title,body'])
    assert pr['isDraft'] and pr['headRefOid']==published and pr['headRefName']=='issue-1580-8d61a32a61e1'
    value={'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main':main,'publishedHead':published,'passingWorkflows':21,'failedWorkflows':failed,'feedbackUnchanged':True,'requiredSubIssues':0,'noActiveRuns':True,'nativeBehaviorVerified':False,'complete':True}
    (out/'outcome.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(value),flush=True)
try:work()
except BaseException:
    traceback.print_exc();(out/'failure.txt').write_text(traceback.format_exc());sys.exit(1)
