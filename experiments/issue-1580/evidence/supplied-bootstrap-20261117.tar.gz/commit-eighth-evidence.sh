set -eu
test "$(git branch --show-current)" = issue-1580-8d61a32a61e1
git diff --check
git add experiments/issue-1580/evidence/commands experiments/issue-1580/evidence/supplied-bootstrap-20261117.json experiments/issue-1580/evidence/supplied-bootstrap-20261117.tar.gz experiments/issue-1580/upstream/java-release-commit-integrity-report.md
git diff --cached --check
git diff --cached --stat > /tmp/issue-1580-research/eighth-evidence-staged-stat.log
tail -n 6 /tmp/issue-1580-research/eighth-evidence-staged-stat.log
git commit -m 'docs: preserve Java release regression execution and supplied-input evidence'
git status --short
git rev-parse HEAD
