from pathlib import Path
r=Path('/tmp/gh-issue-solver-1794900398048')
for name in ['experiments/issue-1580/native-calendar-probe.mjs','experiments/issue-1580/work-plan.md']:
 p=r/name;lines=p.read_text().splitlines()
 print(name,len(lines))
 if name.endswith('.mjs'):
  print('\n'.join(f'{i+1}: {x}' for i,x in enumerate(lines)))
 else:
  for i,x in enumerate(lines):
   if any(q in x.lower() for q in ['prime','native','bounded','unread','benchmarks','blocked']):
    print(f'{i+1}: {x}')
