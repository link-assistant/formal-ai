from pathlib import Path
import hashlib,json,subprocess
def run(*args):return subprocess.run(args,capture_output=True,text=True,check=True).stdout.strip()
assert run('git','branch','--show-current')=='issue-1580-8d61a32a61e1'
assert run('git','rev-parse','HEAD')=='e120c05b4d8e35d51e4c1efb95e9b0c46c8d42b5'
preflight=json.loads(Path('experiments/issue-1580/evidence/checks/audit-inventory-boundary/preflight.json').read_text());assert preflight['successfulWorkflows']==24
for script in ['archive-round-bootstrap.py','archive-evidence.py']:
 subprocess.run(['python3','/tmp/issue-1580-research/'+script],check=True)
subprocess.run(['git','add','--','scripts/check-javascript-dependencies.sh','rust/tests/web/javascript-audit-inventory.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs','experiments/issue-1580','docs/case-studies/issue-1580','changelog.d/20261117_1580_audit_inventory.md'],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','fix: reject incomplete Git inventories before dependency audits'],check=True)
head=run('git','rev-parse','HEAD');status=run('git','status','--porcelain');assert not status,status
print(json.dumps({'head':head,'clean':True,'branch':run('git','branch','--show-current')}))
