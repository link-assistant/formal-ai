from pathlib import Path
import hashlib,json,gzip,subprocess
root=Path('experiments/issue-1580/evidence/checks/python-runtime-provisioning')
record=json.loads((root/'evidence.json').read_text())
for row in record['logs']:
 path=Path(row['path']);data=path.read_bytes()
 if path.suffix=='.gz':
  assert hashlib.sha256(data).hexdigest()==row['compressedSha256']
  assert hashlib.sha256(gzip.decompress(data)).hexdigest()==row['uncompressedSha256']
 else:assert hashlib.sha256(data).hexdigest()==row['sha256']
for name in ['maintained-observations','fast-profile','default-branch-policy','checkout-policy','gates-final-staged-basic','gates-readable']:
 result=json.loads((root/(name+'.json')).read_text());assert result['exitCode']==0,name
fixture=Path('experiments/issue-1580/fixtures/python-template')
for row in json.loads((fixture/'source.json').read_text())['files']:
 data=(fixture/row['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
review=json.loads(Path('docs/case-studies/issue-1580/templates/python-partial-semantic-review.json').read_text())
assert len(review['files'])==329 and review['counts']['active-source-fully-read']==118
assert review['activeReadLines']==7664
subprocess.run(['git','diff','--cached','--check'],check=True)
print('Verified all indexed evidence hashes, four passing focused test files, final staged gates, unchanged pinned Python source, and explicit partial-review counts.')
