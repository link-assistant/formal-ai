from pathlib import Path
import gzip,json,subprocess
repo='link-foundation/python-ai-driven-development-pipeline-template'
directory=Path('/tmp/issue-1580-research/python-audit');directory.mkdir(exist_ok=True)
rows=json.loads(gzip.decompress(Path('experiments/issue-1580/evidence/checks/python-fragment-collision/final-duplicate-issues.json.gz').read_bytes()))
for row in rows:
 if row['number'] in [132,134]:print(json.dumps(row,ensure_ascii=False))
for n in [132,134,152]:
 for kind in ['comments',*(['reviews','inline'] if n!=132 else [])]:
  endpoint=f'repos/{repo}/issues/{n}/comments' if kind=='comments' else f'repos/{repo}/pulls/{n}/'+('comments' if kind=='inline' else 'reviews')
  p=subprocess.run(['gh','api',endpoint,'--paginate','--slurp'],capture_output=True,check=True)
  (directory/f'{n}-{kind}.json').write_bytes(p.stdout)
  comments=[row for page in json.loads(p.stdout) for row in page]
  print('COMMENT_COUNT',n,kind,len(comments))
  for comment in comments:print(json.dumps({k:comment.get(k) for k in ['id','body','state','html_url']},ensure_ascii=False))
