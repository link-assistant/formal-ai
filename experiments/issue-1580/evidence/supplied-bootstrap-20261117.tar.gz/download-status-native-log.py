from pathlib import Path
import gzip,hashlib,json,re,subprocess
head='9095abcbcccdd5518ce2c9318d3ebc6eb8914fc8'
base=Path('experiments/issue-1580/evidence/ci/executor-status-9095abcb')
scratch=Path('/tmp/issue-1580-research/ci-logs/executor-status-9095abcb')
log=scratch/'native-job-134660858273.log'
assert not log.exists()
with log.open('wb') as stream:
    result=subprocess.run(['gh','run','view','44262999525','--repo','link-assistant/formal-ai','--job','134660858273','--log'],stdout=stream,stderr=subprocess.PIPE)
assert result.returncode==0,result.stderr.decode()
raw=log.read_bytes();packed=gzip.compress(raw,mtime=0)
archive=log.name+'.gz';(base/archive).write_bytes(packed)
lines=raw.decode().splitlines()
markers=[{'line':number,'text':line} for number,line in enumerate(lines,1) if re.search(r'Running tests/|Running unittests|test result:|every_fixture_case|production_composition|validated_prime|meta_executor_parity|test forced_|tests [0-9]|pass [0-9]|fail [0-9]',line)]
report={'head':head,'workflowRun':44262999525,'jobId':134660858273,'archive':archive,'rawBytes':len(raw),'rawLines':len(lines),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'markers':markers,'completeLiteralLogRead':False,'independentAuthorshipCredit':0}
(base/'native-log-inventory.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
