from pathlib import Path
import subprocess
root = Path('/tmp/gh-issue-solver-1794900398048')
def command(argv):
    return subprocess.check_output(argv, cwd=root, text=True).strip()
assert command(['git', 'branch', '--show-current']) == 'issue-1580-8d61a32a61e1'
assert command(['git', 'rev-parse', 'HEAD']) == 'edffcb183a7a7f9d5d17967cfea94071aee57a90'
files = [
    'js/worker/formal_ai_worker_unknown_language.js',
    'rust/tests/web/worker-unknown-language.test.mjs',
    'ts/worker/formal_ai_worker_seed_responses_and_language.ts',
    'ts/worker/formal_ai_worker_unknown_language.ts',
    'changelog.d/20261117_120000_issue-1580-ci-regressions.md',
]
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
subprocess.run(['git', 'add', '--', *files], cwd=root, check=True)
staged = command(['git', 'diff', '--cached', '--name-only']).splitlines()
assert sorted(staged) == sorted(files), staged
subprocess.run(['git', 'commit', '-m', 'Honor declared answer languages and synchronize TypeScript mirrors'], cwd=root, check=True)
print('Code commit', command(['git', 'rev-parse', 'HEAD']))
