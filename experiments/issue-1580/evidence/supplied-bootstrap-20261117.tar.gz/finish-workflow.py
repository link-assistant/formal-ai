from pathlib import Path
f=Path('scripts/check-required-status-checks.mjs')
s=f.read_text()
old='  1. release.yml ignores docs-only paths, and a check that never reports stays pending. Make sure every pull request reports these checks, or keep docs-only pull requests mergeable some other way.'
new='  1. Keep the docs-only PR reporting regression green: release.yml must report all three contexts, while unchanged compile inputs skip the compiler inside its reporting job.'
assert old in s
f.write_text(s.replace(old,new))
f=Path('changelog.d/20261117_120000_issue-1580-ci-regressions.md')
s=f.read_text()
f.write_text(s+'- Report every required pull-request context for docs-only changes while skipping unchanged Rust compilation.\n')
