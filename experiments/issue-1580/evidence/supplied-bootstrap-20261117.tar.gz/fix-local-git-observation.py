from pathlib import Path
path=Path('scripts/detect-code-changes.rs')
source=path.read_text()
begin=source.index('fn exec(')
end=source.index('\nfn usable_before_sha',begin)
source=source[:begin]+'''fn exec_in(repo: &Path, args: &[&str]) -> std::io::Result<String> {
    let output = Command::new("git").args(args).current_dir(repo).output()?;
    if !output.status.success() {
        return Err(std::io::Error::other(format!(
            "git {args:?} failed ({}): {}",
            output.status,
            String::from_utf8_lossy(&output.stderr).trim()
        )));
    }
    String::from_utf8(output.stdout)
        .map_err(|error| std::io::Error::new(std::io::ErrorKind::InvalidData, error))
}

fn set_output(name: &str, value: &str) -> std::io::Result<()> {
    if let Ok(output_file) = env::var("GITHUB_OUTPUT") {
        let mut file = fs::OpenOptions::new().create(true).append(true).open(output_file)?;
        writeln!(file, "{name}={value}")?;
    }
    println!("{name}={value}");
    Ok(())
}
''' +source[end:]
begin=source.index('fn get_changed_files()')
end=source.index('\nfn is_ignored_by_ci',begin)
source=source[:begin]+'''fn get_changed_files() -> std::io::Result<Vec<String>> {
    get_changed_files_in_repo(
        Path::new("."),
        &env::var("GITHUB_EVENT_NAME").unwrap_or_default(),
        env::var("GITHUB_EVENT_BEFORE").ok().as_deref(),
    )
}

fn get_changed_files_in_repo(
    repo: &Path,
    event: &str,
    before: Option<&str>,
) -> std::io::Result<Vec<String>> {
    // Even shallow commits retain their parent headers. Only a genuinely initial
    // commit permits the tree fallback; unknown history must not become an empty diff.
    let commit = exec_in(repo, &["cat-file", "-p", "HEAD"])?;
    let parents = commit.lines().take_while(|line| !line.is_empty())
        .filter(|line| line.starts_with("parent ")).count();
    let (base, head, description) = comparison_for_event(event, parents > 1, before);
    println!("Comparing {base} to {head} ({description})");
    // Preserve removed source paths and literal path bytes (including newlines).
    let output = if parents == 0 && base == "HEAD^" {
        exec_in(repo, &["ls-tree", "--name-only", "-z", "-r", "HEAD"])?
    } else {
        exec_in(repo, &["diff", "--no-renames", "--name-only", "-z", &base, &head])?
    };
    Ok(decode_git_paths(&output))
}
''' +source[end:]
begin=source.index('fn main() {')
end=source.index('\n#[cfg(test)]',begin)
main=source[begin:end]
main=main.replace('fn main() {','fn main() -> std::io::Result<()> {').replace('let changed_files = get_changed_files();','let changed_files = get_changed_files()?;')
# All closing call statements at this indentation are set_output calls, except println.
main=main.replace('    );','    )?;')
main=main.replace('set_output("release-pending", if pending { "true" } else { "false" });','set_output("release-pending", if pending { "true" } else { "false" })?;')
main=main.replace('    println!("\\nChange detection completed.");','    println!("\\nChange detection completed.");\n    Ok(())')
source=source[:begin]+main+source[end:]
# Keep subprocess regressions in the existing embedded CI script suite.
begin=source.index('    #[test]',source.index('mod tests {'))
source=source[:begin]+'''    #[test]
    fn failed_git_is_not_a_negative_observation() {
        use std::{fs, process::Command, time::{SystemTime, UNIX_EPOCH}};
        let repo = std::env::temp_dir().join(format!("formal-ai-git-{}-{}", std::process::id(),
            SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos()));
        struct Cleanup(std::path::PathBuf);
        impl Drop for Cleanup { fn drop(&mut self) { let _ = fs::remove_dir_all(&self.0); } }
        fs::create_dir(&repo).unwrap();
        let _cleanup = Cleanup(repo.clone());
        let git = |args: &[&str]| {
            let output = Command::new("git").args(["-c", "core.hooksPath=/dev/null", "-c", "commit.gpgsign=false"])
                .args(args).current_dir(&repo)
                .env("GIT_CONFIG_NOSYSTEM", "1").env("GIT_CONFIG_GLOBAL", "/dev/null")
                .env("GIT_AUTHOR_NAME", "Fixture").env("GIT_AUTHOR_EMAIL", "fixture@example.invalid")
                .env("GIT_COMMITTER_NAME", "Fixture").env("GIT_COMMITTER_EMAIL", "fixture@example.invalid")
                .output().unwrap();
            assert!(output.status.success(), "{}", String::from_utf8_lossy(&output.stderr));
            String::from_utf8(output.stdout).unwrap().trim().to_string()
        };
        assert!(super::get_changed_files_in_repo(&repo, "push", None).is_err());
        git(&["init", "--quiet"]);
        fs::write(repo.join("source.rs"), "fn main() {}\\n").unwrap();
        git(&["add", "source.rs"]);
        git(&["commit", "--quiet", "-m", "initial"]);
        assert_eq!(super::get_changed_files_in_repo(&repo, "push", None).unwrap(), ["source.rs"]);
        let parent = git(&["rev-parse", "HEAD"]);
        git(&["commit", "--quiet", "--allow-empty", "-m", "empty"]);
        assert!(super::get_changed_files_in_repo(&repo, "push", None).unwrap().is_empty());
        assert!(super::get_changed_files_in_repo(&repo, "push", Some(&"a".repeat(40))).is_err());
        fs::remove_file(repo.join(".git/objects").join(&parent[..2]).join(&parent[2..])).unwrap();
        assert!(super::get_changed_files_in_repo(&repo, "push", None).is_err());
    }

''' +source[begin:]
path.write_text(source)
print('Git observations and output writes now propagate errors; genuine initial commits retain their tree fallback.')
