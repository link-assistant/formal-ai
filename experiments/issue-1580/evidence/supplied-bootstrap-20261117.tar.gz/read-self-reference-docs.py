from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
for name in ['experiments/issue-1580/work-plan.md','docs/case-studies/issue-1580/templates/README.md','docs/case-studies/issue-1580/README.md','experiments/issue-1580/evidence/checks/java-release-integrity.json']:
    p=root/name
    print('FILE '+name)
    for n,line in enumerate(p.read_text().splitlines(),1): print(f'{n}: {line}')
print('Local gate list')
import subprocess
p=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--list'],capture_output=True,text=True,check=True)
print(p.stdout)
