from pathlib import Path
import json,re,subprocess
report=Path('/tmp/issue-1580-research/javascript-archive-readers.txt')
result=subprocess.run(['rg','-n','(?:[.]gz|[.]log|[.]zip|[.]tgz|[.]diff|gunzip|unzip)','rust/tests/web','scripts','--glob','*.mjs'],capture_output=True)
assert result.returncode==0
report.write_bytes(result.stdout)
lines=result.stdout.decode().splitlines()
paths=sorted(set(line.split(':',1)[0] for line in lines))
print(json.dumps({'report':str(report),'lines':len(lines),'sourceFiles':len(paths),'likelyCaseStudyReferences':[line[:600] for line in lines if ('case-studies' in line or '/evidence/' in line) and not any(x in line for x in ['console.log','source.match','assert.match'])]},indent=2))
