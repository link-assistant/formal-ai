from pathlib import Path
import subprocess
for name,first,last in [('/tmp/issue-1580-research/run-main-015a6831-focused-checks.py',1,130),('/tmp/issue-1580-research/refresh-runtime-native-witnesses.py',1,130)]:
 path=Path(name)
 if not path.exists():print('unavailable',name);continue
 lines=path.read_text().splitlines()
 print(f'FILE {name} {len(lines)} lines')
 for n in range(first,min(last,len(lines))+1):print(f'{n}: {lines[n-1]}')
for command in [['rg','--files','scripts','-g','*generat*','-g','*mirror*','-g','*debug*'],['rg','-n','calendar-duration-sum|calendar-duration-addition-cue','data/seed','js/worker/formal_ai_worker_calendar_offset.js','rust/src/solver_handlers/calendar/month.rs']]:
 result=subprocess.run(command,text=True,capture_output=True)
 print('COMMAND',command,'exit',result.returncode)
 print(result.stdout+result.stderr)
