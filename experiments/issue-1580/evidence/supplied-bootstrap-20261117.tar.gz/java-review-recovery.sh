set -eu
sed -n '1,40p' /tmp/issue-1580-research/templates/java-complete/scripts/audit-maven-plugins.mjs
python3 -c 'import json; from pathlib import Path; p=Path("/tmp/issue-1580-research/templates/java-complete-inventory.json"); d=json.loads(p.read_text()); print(type(d).__name__); print(str(d)[:900])'
python3 /tmp/issue-1580-research/inspect-current-queued-jobs.py
