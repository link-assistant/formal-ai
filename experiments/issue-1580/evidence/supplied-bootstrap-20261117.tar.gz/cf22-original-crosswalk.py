from pathlib import Path
import gzip,hashlib,json,re,subprocess
root=Path.cwd(); base=root/'experiments/issue-1580/evidence/ci/offline-catalog-cf22c611'
previous=json.loads((root/'experiments/issue-1580/evidence/ci/native-catalog-3c52b7f5/original-native-replay-union.json').read_text()); analysis=json.loads((base/'analysis.json').read_text()); records=json.loads((base/'records.json').read_text()); record=next(r for r in records if r['name']=='job-135851399936'); raw=gzip.decompress((base/record['stdout']['file']).read_bytes()); assert hashlib.sha256(raw).hexdigest()==record['stdout']['rawSha256'];passes=[]
for i,line in enumerate(raw.decode().splitlines(),1):
 match=re.search(r'\btest ([\w:]+) \.\.\. ok\s*$',line)
 if match: passes.append({'test':match.group(1),'line':i})
assert len(passes)==181,len(passes)
head=analysis['head']; original=previous['originalFailureHead']; by_name={p['test'].split('::')[-1]:p for p in passes}; names={t['originalTest'].split('::')[-1] for t in previous['tests']}; output=subprocess.run(['rg','-l',r'^fn (?:'+'|'.join(re.escape(x) for x in names)+r')\b','rust/tests/unit','rust/tests/integration','-g','*.rs'],capture_output=True,text=True,check=True);paths_by_name={}
for path in output.stdout.splitlines():
 for name in re.findall(r'^fn (\w+)\b',(root/path).read_text(),re.M):
  if name in names:paths_by_name.setdefault(name,[]).append(path)
changed=[];matches=[]
for t in previous['tests']:
 name=t['originalTest'].split('::')[-1];t['currentPublishedReplay']=None
 if name not in by_name:continue
 candidates=paths_by_name.get(name,[])
 if len(candidates)!=1:matches.append({'test':t['originalTest'],'pathCandidates':candidates,'qualifying':False,'reason':'ambiguous or missing path'});continue
 path=candidates[0];a=subprocess.run(['git','show',original+':'+path],capture_output=True);b=subprocess.run(['git','show',head+':'+path],capture_output=True);assert b.returncode==0
 same=a.returncode==0 and a.stdout==b.stdout;prefix=a.returncode==0 and b.stdout.startswith(a.stdout)
 row={'originalTest':t['originalTest'],'executedName':by_name[name]['test'],'path':path,'publishedTestFileSha256':hashlib.sha256(b.stdout).hexdigest(),'originalFileAvailable':a.returncode==0,'entireTestFileUnchangedSinceOriginal':same,'allOriginalTestFileBytesPreservedAsPrefix':prefix,'head':head,'job':135851399936,'run':44606365461,'result':'passed','logLine':by_name[name]['line']}
 t['currentPublishedReplay']=row;matches.append({'test':t['originalTest'],'path':path,'qualifying':prefix})
 if prefix:
  if not t['hasPublishedPassingReplay']:changed.append(t['originalTest'])
  t['hasPublishedPassingReplay']=True
previous.update({'latestPublishedHead':head,'publishedPassingReplayUnion':sum(t['hasPublishedPassingReplay'] for t in previous['tests']),'withoutPublishedPassingReplay':sum(not t['hasPublishedPassingReplay'] for t in previous['tests']),'currentNativeTestsPassed':len(passes),'currentMatchingOriginalNames':len(matches),'currentMatchingEvidence':matches,'newPassingReplaysWithOriginalBytesPreserved':changed,'limits':'All 23 exact-head workflows completed; the pipeline/native job was cancelled at its unchanged 20-minute deadline after one assertion failure. Only actual published native passes preserving every original test-file byte add credit. Incomplete scheduling contributes only its three observed passes, never suite completion. Full issue acceptance, three original budget criteria and independent authorship are not inferred.'})
(base/'original-native-replay-union.json').write_text(json.dumps(previous,indent=2)+'\n');print(json.dumps({k:v for k,v in previous.items() if k not in ['tests','currentMatchingEvidence']},indent=2));print('MATCHING',json.dumps(matches,indent=2))
