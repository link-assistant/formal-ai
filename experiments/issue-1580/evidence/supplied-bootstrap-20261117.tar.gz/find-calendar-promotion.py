from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
for q in [['rg','-n','promotedHandlerOrder|function.*[Rr]out|calendar_create_event|conversation_memory','js/worker/formal_ai_worker_user_intent.js','data/seed/browser-handler-precedence.lino','rust/src/handler_registry.rs'],['rg','-n','function promotedHandlerOrder|calendar_create_event|conversation_memory','js/worker/formal_ai_worker_handler_registry.js','rust/src/solver_handlers/mod.rs'],['rg','-n','function promotedHandlerOrder','js/worker'],['rg','-n','calendar_create_event','rust/src/solver_turn.rs','rust/src/solver_agentic.rs','rust/src/capability_routing.rs']]:
 r=subprocess.run(q,cwd=root,capture_output=True,text=True);print(r.stdout);print(r.stderr)
