from pathlib import Path
import subprocess
print(subprocess.check_output(['git','status','--short'], text=True))
print(subprocess.check_output(['git','branch','--show-current'], text=True))
p=Path('experiments/issue-1580/work-plan.md')
lines=p.read_text().splitlines()
print('WORK PLAN',len(lines),'LINES')
for i,line in enumerate(lines[-230:],max(1,len(lines)-229)):
    print(f'{i}: {line}')
