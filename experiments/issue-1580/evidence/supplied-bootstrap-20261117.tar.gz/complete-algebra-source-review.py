from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess

base = Path('experiments/issue-1580/evidence/checks/algebra-calculation-cues')
path = base / 'manual-review.json'
report = json.loads(path.read_text())
for row in report['sources']:
    assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest() == row['sha256']
report.update(complete=True, handwrittenIncrementalSourceDiffLiterallyRead=True, reviewedAt=datetime.now(timezone.utc).isoformat(), wholePullRequestDiffLiterallyRead=False)
path.write_text(json.dumps(report, indent=2) + '\n')
assert subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip() == 'issue-1580-8d61a32a61e1'
subprocess.run(['git', '-c', 'gc.auto=0', 'fetch', 'origin', 'main'], check=True)
subprocess.run(['git', 'merge-base', '--is-ancestor', 'origin/main', 'HEAD'], check=True)
print('MAIN', subprocess.check_output(['git', 'rev-parse', 'origin/main'], text=True).strip())
print('SOURCE REVIEW COMPLETE', report['sourceFileCount'], 'NATIVE ALGEBRA EXECUTION PENDING')
