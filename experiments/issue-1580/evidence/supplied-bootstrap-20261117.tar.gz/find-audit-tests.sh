set -eu
rg --files rust/tests experiments scripts | rg '(audit|dependencies|security|proof)' | head -n 80
rg -n 'blocked-upstream|check-rust-dependencies.sh' rust/tests/web scripts experiments/formal_ai_subagent | head -n 90
cat CONTRIBUTING.md
