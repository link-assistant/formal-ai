from pathlib import Path
import subprocess,os,gzip,hashlib,json,re
r=Path.cwd();base=r/'experiments/issue-1580/evidence/checks/hive-full-delivery-admission';base.mkdir()
p=r/'rust/tests/web/default-branch-build-policy.test.mjs'
p.write_text(p.read_text()+'''

test('full Hive delivery replay admits its harness and requires real toolchains', {timeout:15000}, () => {
  const modules = ['issue_1157_idempotent_commit.rs', 'issue_1158_pull_request_steps.rs',
    'issue_1160_regular_prompt.rs', 'hive_delivery_prerequisites.rs'];
  const fixtures = ['hive-mind/offline_delivery.rs', 'hive-mind/fake-gh.cjs',
    'hive-mind/formal-ai-prompt.txt', 'hive-mind/regular-prompt.txt',
    'hive-mind/restart-uncommitted-main-jar.txt', 'issue-1162/hello-world-kotlin-issue.md'];
  for (const path of [...modules.map(path => 'rust/tests/unit/' + path),
    ...fixtures.map(path => 'rust/tests/fixtures/' + path)])
    assert.equal(admission([path])['native-type-check'], true, path);
  const source = read('rust/tests/unit/reasoning_contracts.rs');
  for (const path of [...modules, '../fixtures/hive-mind/offline_delivery.rs'])
    assert(source.includes('#[path = "' + path + '"]'), path);
  const prerequisites = read('rust/tests/unit/hive_delivery_prerequisites.rs');
  assert.match(prerequisites, /assert!\\([\\s\\S]*available\\(/u);
  for (const tool of ['git', 'node', 'jq', 'python3', 'rustc', 'timeout', 'kotlinc', 'java'])
    assert(prerequisites.includes('"' + tool + '"'), tool);
});
''')
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
run=subprocess.run(['timeout','600','node','--test','--test-concurrency=1',str(p)],env=env,capture_output=True)
raw=run.stdout+run.stderr;z=gzip.compress(raw,mtime=0);(base/'before.log.gz').write_bytes(z)
assert run.returncode!=0,raw.decode()
t=raw.decode();assert re.search(r'[ℹ#] pass 47',t) and re.search(r'[ℹ#] fail 1',t),t
(base/'before.json').write_text(json.dumps({'exitCode':run.returncode,'passed':47,'failed':1,'file':'before.log.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(z).hexdigest(),'nativeExecuted':False,'fullIssueComplete':False},indent=2)+'\n')
print(t[-4500:])
