from pathlib import Path
p=Path('/tmp/gh-issue-solver-1794900398048/packages/picomatch-compat/lib/parse.js')
lines=p.read_text().splitlines()
for start,end in [(91,170),(400,600),(860,1050)]:
 print(f'\nparse.js {start}-{end}')
 print('\n'.join(f'{i+1}: {lines[i]}' for i in range(start-1,end)))
