from pathlib import Path
import gzip,hashlib,json,re,subprocess
root=Path.cwd();base=root/'experiments/issue-1580/evidence/ci/native-catalog-3c52b7f5';outcome=json.loads((base/'outcome.json').read_text());records=json.loads((base/'records.json').read_text());verified=0
for row in records:
 for label in ['stdout','stderr']:
  v=row[label];z=(base/v['file']).read_bytes();raw=gzip.decompress(z);assert hashlib.sha256(z).hexdigest()==v['archiveSha256'];assert hashlib.sha256(raw).hexdigest()==v['rawSha256'];verified+=1
native=next(r for r in records if r['name']=='job-135813011639');lines=gzip.decompress((base/native['stdout']['file']).read_bytes()).decode(errors='replace').splitlines()
summaries=[];passes=[];failures=[]
for i,s in enumerate(lines,1):
 m=re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',s)
 if m:summaries.append({'line':i,'passed':int(m[1]),'failed':int(m[2]),'text':s.split('Z ',1)[-1]})
 m=re.search(r'\btest ([a-zA-Z_0-9:]+) \.\.\. (ok|FAILED)',s)
 if m:(passes if m[2]=='ok' else failures).append({'line':i,'test':m[1]})
assert sum(x['passed'] for x in summaries)==len(passes)
js=[]
for row in records:
 if row['name'] not in ['job-135812760378','job-135812760431']:continue
 logs=gzip.decompress((base/row['stdout']['file']).read_bytes()).decode(errors='replace').splitlines();tallies=[]
 for i,s in enumerate(logs,1):
  m=re.search(r'(?:ℹ|#) (tests|pass|fail|skipped) (\d+)(?:\s|$)',s)
  if m:tallies.append({'line':i,'field':m[1],'value':int(m[2])})
 js.append({'job':row['name'],'tallies':tallies})
report={'head':outcome['head'],'workflowCount':outcome['workflowCount'],'success':outcome['success'],'failed':outcome['failed'],'verifiedPayloads':verified,'nativeJob':135813011639,'nativeRust':{'passed':sum(x['passed'] for x in summaries),'failed':sum(x['failed'] for x in summaries),'summaries':summaries,'failures':failures,'passes':passes},'javascript':js,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(base/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['nativeRust','javascript']},indent=2));print('NATIVE',report['nativeRust']['passed'],'passed',report['nativeRust']['failed'],'failed');print('FAILURES',failures);print('JS',json.dumps(js));print('native lines',len(lines))
print('Review docs')
for p in (root/'docs/case-studies/issue-1580').iterdir():
 if p.is_file() and any(x in p.name for x in ['original','native','checkpoint']):print(p.name)
