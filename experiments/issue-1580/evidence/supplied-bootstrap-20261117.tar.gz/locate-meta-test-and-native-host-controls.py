from pathlib import Path
import subprocess
for args in [
 ['rg','-n','can_compose|solve_answer|fn draft|root_answer|original_answer','rust/src/meta_executor/production.rs'],
 ['rg','-n','solveAnswer|canCompose|concrete|composition','rust/tests/web/meta-executor.test.mjs'],
 ['rg','--files','rust/tests/web','scripts'],
]:
    r=subprocess.run(args,text=True,capture_output=True);print('COMMAND',args,'EXIT',r.returncode)
    if '--files' in args:print('\n'.join(p for p in r.stdout.splitlines() if any(s in p for s in ['meta-executor','meta_executor','worker-crate','worker_crate'])))
    else:print(r.stdout,r.stderr)
