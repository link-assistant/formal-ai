from pathlib import Path
root=Path.cwd()
p=root/'rust/tests/web/worker-candidate-validation.test.mjs'
s=p.read_text().replace('for (const [language, prompt, expected] of [','for (const { language, prompt, expected } of [')
replacements=[
('["en", "Choose a prime between 8 and 12", "11"]','{ language: "en", prompt: "Choose a prime between 8 and 12", expected: "11" }'),
('["ru", "Выбери простое число от 24 до 30", "29"]','{ language: "ru", prompt: "Выбери простое число от 24 до 30", expected: "29" }'),
('["es", "Elige un número primo entre 32 y 40", "37"]','{ language: "es", prompt: "Elige un número primo entre 32 y 40", expected: "37" }'),
('["zh", "选择8到12之间的质数", "11"]','{ language: "zh", prompt: "选择8到12之间的质数", expected: "11" }'),
('["hi", "0 और 3 के बीच अभाज्य संख्या चुनो", "2"]','{ language: "hi", prompt: "0 और 3 के बीच अभाज्य संख्या चुनो", expected: "2" }'),
]
for old,new in replacements:
    assert old in s,old
    s=s.replace(old,new)
p.write_text(s)
p=root/'scripts/check-sccache-write-health.sh'
s=p.read_text()
s=s.replace('# Report the share of sccache cache writes that the backend rejected.','# Report the share of sccache cache writes that recorded an error.')
s=s.replace('# A write that fails is a crate the next run recompiles, so this is the cheapest\n# available explanation for the budget pressure that issues #1017, #1021 and\n# #1081 all landed on from the other end.','# A write error may leave an artifact unavailable, but it can also mean another\n# writer already stored the same key. These counters alone establish neither\n# future cache misses nor how much compilation time was lost.')
s=s.replace('# Both predict error rates that rise with simultaneity, which is what was\n# measured -- note that the rate does NOT rise with finishing order, so "someone\n# else got there first" in the sequential sense is already refuted. The evidence\n# that separates them is the backend\'s own response, which sccache logs only','# Neither the counts nor job finishing order distinguish these hypotheses.\n# The evidence that separates them is the backend\'s own response, which sccache logs only')
s=s.replace('# The counters are flat integers in a single-line JSON object, so a targeted','# The counters are integers, so a targeted')
old='value="$(printf \'%s\' "$body" | grep -o "\\\"${name}\\\":[0-9]\\+" | head -n 1 | cut -d: -f2)"'
new='value="$(printf \'%s\' "$body" | grep -o "\\\"${name}\\\"[[:space:]]*:[[:space:]]*[0-9]\\+" | head -n 1 | cut -d: -f2 | tr -d \'[:space:]\')"'
assert old in s
s=s.replace(old,new)
s=s.replace('title="Compiler cache rejected ${share}% of its writes"','title="Compiler cache reported errors for ${share}% of its writes"')
old='sccache offered ${attempts} compiled artifacts to the GitHub Actions Cache and ${errors} were refused (${writes} stored). Every refused write is a crate the next run compiles again, so this is build time the cache is not saving.'
new='sccache attempted ${attempts} cache writes: ${errors} recorded errors and ${writes} were stored. These counters do not establish future cache misses; another writer may already have stored the same key.'
assert old in s
s=s.replace(old,new).replace("%s stored, %s refused, %s%% refused.","%s stored, %s write errors, %s%% errors.")
p.write_text(s)
