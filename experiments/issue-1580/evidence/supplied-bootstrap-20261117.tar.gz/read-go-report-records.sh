set -eu
git status --short
git branch --show-current
cat experiments/issue-1580/upstream/template-report-identities.json
cat experiments/issue-1580/upstream/filed-issues.txt
cat experiments/issue-1580/upstream/go-stale-pin-integrity-report.md
cat /tmp/issue-1580-research/go-stale-pin-report-body.md
rg -n 'Go|go-|report|Java|semantic' experiments/issue-1580/work-plan.md docs/case-studies/issue-1580/README.md docs/case-studies/issue-1580/templates/README.md
