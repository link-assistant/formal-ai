from pathlib import Path
import json
r=Path('/tmp/gh-issue-solver-1794900398048')
for directory in ['desktop','vscode','packages/minimatch-compat']:
 p=r/directory/'package.json'
 print('\n'+str(p.relative_to(r)))
 print(p.read_text())
for directory in ['desktop','vscode']:
 p=r/directory/'package-lock.json'
 d=json.loads(p.read_text())
 print('\nLOCK SUMMARY '+directory)
 print(json.dumps(d['packages'][''],indent=2))
 for name,meta in d['packages'].items():
  if any(name.endswith('/'+q) for q in ['picomatch','tinyglobby','fdir','micromatch','minimatch']):
   print(name,json.dumps(meta))
for name in ['data/benchmarks/fast-pull-request-javascript-tests.json','experiments/issue-1580/evidence/checks/picomatch-single-branch/before.json','experiments/issue-1580/evidence/checks/picomatch-single-branch/initial-after.json']:
 p=r/name
 if 'fast-pull' in name:
  d=json.loads(p.read_text())
  print(name,'type',type(d).__name__,'keys',list(d) if isinstance(d,dict) else 'array')
  print(json.dumps(d,indent=2)[-2500:])
 else: print(name,p.read_text())
