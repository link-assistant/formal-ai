from pathlib import Path
import subprocess, json, datetime

def run(command):
    return subprocess.check_output(command,text=True).strip()
assert run(['git','branch','--show-current'])=='issue-1580-8d61a32a61e1'
subprocess.run(['git','fetch','origin','main'],check=True)
main=run(['git','rev-parse','origin/main'])
head=run(['git','rev-parse','HEAD'])
branch='issue-1580-8d61a32a61e1'
recent=json.loads(run(['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--limit','5','--json','databaseId,conclusion,createdAt,headSha']))
all_runs=json.loads(run(['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--commit',head,'--limit','100','--json','databaseId,workflowName,status,conclusion,createdAt,headSha,url']))
active={}
for status in ['in_progress','queued']:
    active[status]=json.loads(run(['gh','run','list','--repo','link-assistant/formal-ai','--branch',branch,'--status',status,'--limit','100','--json','databaseId,workflowName,headSha']))
record={'collectedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mainHead':main,'localHead':head,'recentRuns':recent,'headRuns':all_runs,'activeRuns':active,'mainIsAncestor':subprocess.run(['git','merge-base','--is-ancestor',main,head]).returncode==0}
path=Path('/tmp/issue-1580-research/governed-parent-preflight.json')
path.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({key:value for key,value in record.items() if key!='headRuns'},indent=2))
print('HEAD_RUNS',len(all_runs),'NONPASSING',json.dumps([row for row in all_runs if row['conclusion']!='success']))
log=Path('/tmp/issue-1580-research/governed-refresh-all-local-gates.log')
print('GATE_PROGRESS','\n'.join(log.read_text().splitlines()[-5:]))
