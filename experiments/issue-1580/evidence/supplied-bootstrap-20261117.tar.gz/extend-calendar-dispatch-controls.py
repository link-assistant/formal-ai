from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048');p=root/'rust/tests/web/calendar-act-paraphrases.test.mjs';s=p.read_text();a=s.index('for (const prompt of [\n');b=s.index("]) test('source text cannot schedule an event:",a);s=s[:a]+s[a:b].replace('for (const prompt of [','const sourcePrompts = [',1)+s[b:];s=s.replace("]) test('source text cannot schedule an event: ","];\nfor (const prompt of sourcePrompts) test('source text cannot schedule an event: ",1)
s+='''
for (const prompt of sourcePrompts) test('the full worker keeps source text out of scheduling: ' + prompt, {timeout:15000}, async () => {
  const answer = await worker.solve(prompt, [], {}, {}, [], {});
  assert.notEqual(answer?.intent, 'calendar_create_event', JSON.stringify(answer));
  assert.doesNotMatch(answer.content, /BEGIN:VCALENDAR/u);
});
''';p.write_text(s);print('Added all eight original source and ambiguity cases through the full worker.')
