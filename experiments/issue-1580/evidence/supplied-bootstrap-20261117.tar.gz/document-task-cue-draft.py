from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
path=root/'experiments/issue-1580/work-plan.md';text=path.read_text();assert '## Quoted-passage cue boundary draft' not in text
text+='''
## Quoted-passage cue boundary draft

- [x] Add 12 literal decomposition/tree controls in five languages. Against
  published c8fb9ad1 source, preserve 18 passes / seven failures: four language
  cues, case/spacing, a preceding task and a following task fail. Chinese and
  unquoted/escaped/word-boundary/inside-quotation controls already pass.
- [x] Draft cue masking in JavaScript and Rust using the existing seeded
  prompt-text-question role, with declared separators and actual quote openers.
  Leave genuine surrounding tasks and unquoted instructions independent.
- [x] Wire a third shared fixture into the maintained writer and both replay
  readers. Keep the original 25-case and four-case fixtures unchanged.
- [x] Preserve both worker-generation failures: existing factory ceiling, then
  missing budget for the extracted helper. Add the measured 46-line helper
  budget; all existing module budgets remain unchanged.
- [ ] Complete maintained worker/TypeScript/seed/translation generation, focused
  tests, original fixture byte checks and all 138 local inventory entries.
- [ ] Review and publish the complete batch only after current c8fb9ad1 CI
  finishes; verify actual native cue fixture execution on the new head.
- [ ] Complete general passage binding, parent coverage and multi-passage
  provenance. Cue masking alone does not establish any of those contracts.
  Independent reasoning acceptance remains 0/20; keep PR #1581 draft and unmerged.
''';path.write_text(text)
path=root/'docs/case-studies/issue-1580/quoted-passage-cue-checkpoint.md';assert not path.exists()
path.write_text('''# Quoted-passage cue checkpoint

This is an unfinished checkpoint for [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581).
The wider issue remains open.

## Reproduction and change

`Read this and answer: "Marisol owns pears and plums." Which fruit?` splits into
`Read this` and the remaining answer request. The quotation itself is protected,
but the cue's conjunction is treated as another task. Russian, Hindi and Spanish
cues have the same defect. A preceding or following independent task exposes
the same incorrect extra split.

Add 12 literal splitting/tree controls in five languages. Before the change,
the focused executor file has 18 passes and seven failures; the Chinese control
already passes. Preserve the entire 219-line failing payload and its hashes.
Escaped quote openers, word boundaries, cues inside quotations and genuinely
unquoted commands are negative controls.

The draft masks only seeded cue surfaces that directly introduce an actual
quotation, separated by whitespace or declared colon characters. Both runtimes
reuse the existing prompt-text-question cue vocabulary and the quote mask's
escape/word rules. Genuine tasks before and after the cue remain independent.
The maintained fixture writer adds a separate shared 12-case fixture, read by
both JavaScript and Rust, while preserving the original two fixtures.

The first worker writer rejects the existing executor ceiling. Extract a small
helper instead; the next writer correctly requires its explicit reviewed budget.
Register the measured 46-line factory. Preserve both failures separately. All
existing module budgets remain unchanged. Generation and local verification
remain in progress; native execution is pending a future hosted run.

## Limits

These controls establish task boundaries using a deterministic table host. They
do not validate factual answers, bind passage references to later questions,
establish complete semantic parent coverage, or validate multi-passage evidence.
Those requirements and the wider issue remain unfinished. Supplied scripts,
commands, patches and conclusions receive zero independent authorship credit;
independent acceptance remains 0/20.
''')
print('Documented the concrete reproduction, negative controls and remaining validation.')
