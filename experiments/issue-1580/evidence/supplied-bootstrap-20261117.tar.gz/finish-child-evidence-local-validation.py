from pathlib import Path
import gzip,hashlib,json,os,subprocess,time
base=Path('experiments/issue-1580/evidence/checks/child-evidence-provenance')
aggregate=base/'all-gates/results.json'
assert aggregate.exists(),'Full inventory still running; do not start a second gate process'
report=json.loads(aggregate.read_text())
check=next(row for row in report['checks'] if row['name']=='all-gates')
raw=gzip.decompress((base/'all-gates'/check['log']).read_bytes())
assert hashlib.sha256(raw).hexdigest()==check['rawSha256']
print('FULL GATE INVENTORY\n'+raw.decode())
failures=[line.split()[1] for line in raw.decode().splitlines() if line.startswith('FAIL ')]
assert failures==['lint-shell-scripts'],failures
details=json.loads((base/'all-gates/gate-details.json').read_text())
for row in details:
    data=gzip.decompress((base/'all-gates'/row['log']).read_bytes())
    assert hashlib.sha256(data).hexdigest()==row['rawSha256']
    if row['name'] in failures:print('ORIGINAL FAILURE '+row['name']+'\n'+data.decode())
name='shellcheck-resumed'
args=['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','lint-shell-scripts']
started=time.monotonic()
result=subprocess.run(args,env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
packed=gzip.compress(result.stdout,mtime=0)
(base/(name+'.log.gz')).write_bytes(packed)
gate=Path('experiments/formal_ai_subagent/sandboxes/gates/lint-shell-scripts.log').read_bytes()
(base/'shellcheck-resumed-detail.log.gz').write_bytes(gzip.compress(gate,mtime=0))
print('RESUMED GATE\n'+result.stdout.decode()+'\n'+gate.decode())
row={'argv':args,'exitCode':result.returncode,'seconds':round(time.monotonic()-started,3),'rawSha256':hashlib.sha256(result.stdout).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'log':name+'.log.gz','detailLog':'shellcheck-resumed-detail.log.gz','detailRawSha256':hashlib.sha256(gate).hexdigest()}
(base/'shellcheck-resumed.json').write_text(json.dumps(row,indent=2)+'\n')
assert result.returncode==0
prior=json.loads((base/'resumed-validation.json').read_text())
original=next(r for r in prior['checks'] if r['name']=='check-tests-as-docs')
renamed='resumed-check-tests-as-documentation.log.gz'
data=(base/renamed).read_bytes()
assert hashlib.sha256(data).hexdigest()==original['archiveSha256']
assert hashlib.sha256(gzip.decompress(data)).hexdigest()==original['rawSha256']
alias={'originalReceipt':'resumed-validation.json','originalPath':original['log'],'expandedPath':renamed,'archiveSha256':original['archiveSha256'],'rawSha256':original['rawSha256'],'bytesUnchanged':True,'originalReceiptUnchanged':True}
(base/'expanded-resumed-filename-receipt.json').write_text(json.dumps(alias,indent=2)+'\n')
lines=raw.decode().splitlines()
summary={'originalAggregateResult':'all-gates/results.json','originalFailureRetained':True,'inventoryEntries':sum(line.startswith(('PASS ','FAIL ','SKIP ')) for line in lines),'originalPassed':sum(line.startswith('PASS ') for line in lines),'originalFailed':failures,'excluded':sum(line.startswith('SKIP ') for line in lines),'correctedFailureResult':'shellcheck-resumed.json','allExecutableEntriesPassingAfterEnvironmentRepair':True,'allIndividualLogsHashVerified':len(details),'fullAggregateLiterallyPrinted':True,'allIndividualLogsLiterallyRead':False,'nativeExecuted':False,'independentAuthorshipCredit':0,'memoryEventsAfter':Path('/sys/fs/cgroup/memory.events').read_text()}
(base/'completed-local-validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
