import gzip
from pathlib import Path
file=Path('experiments/issue-1580/audit-ci.py')
text=file.read_text()
old="        (root / f'{run_id}-excerpts-{part//1000+1}.txt').write_text('\\n'.join(excerpts_lines[part:part+1000])+'\\n')"
new="        with gzip.open(root / f'{run_id}-excerpts-{part//1000+1}.txt.gz', 'wt', encoding='utf8') as output:\n            output.write('\\n'.join(excerpts_lines[part:part+1000])+'\\n')"
assert old in text
file.write_text(text.replace(old,new))
files=list(Path('experiments/issue-1580/evidence/ci').glob('*-excerpts-*.txt'))
for file in files:
    file.with_suffix('.txt.gz').write_bytes(gzip.compress(file.read_bytes(),mtime=0))
    file.unlink()
print('Preserved',len(files),'original log excerpts losslessly as gzip, including original whitespace.')
