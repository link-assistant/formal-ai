set -eu
test "$(git branch --show-current)" = issue-1580-8d61a32a61e1
test -z "$(git status --porcelain)"
git fetch origin main issue-1580-8d61a32a61e1
git merge-base --is-ancestor origin/main HEAD
git merge-base --is-ancestor origin/issue-1580-8d61a32a61e1 HEAD
gh run list --repo link-assistant/formal-ai --branch issue-1580-8d61a32a61e1 --status in_progress --json databaseId,workflowName,headSha > /tmp/issue-1580-research/prepush-in-progress.json
gh run list --repo link-assistant/formal-ai --branch issue-1580-8d61a32a61e1 --status queued --json databaseId,workflowName,headSha > /tmp/issue-1580-research/prepush-queued.json
python3 -c 'import json; from pathlib import Path; assert not json.loads(Path("/tmp/issue-1580-research/prepush-in-progress.json").read_text()); assert not json.loads(Path("/tmp/issue-1580-research/prepush-queued.json").read_text())'
git push origin HEAD:refs/heads/issue-1580-8d61a32a61e1
gh pr edit 1581 --repo link-assistant/formal-ai --title 'Fix CI verdicts, candidate validation, and draft workflow accounting' --body-file /tmp/issue-1580-research/pr-body.md
git rev-parse HEAD
git status --short
