from pathlib import Path
import gzip,hashlib,json,subprocess
base=Path('experiments/issue-1580/evidence/checks/main-merge-444575f2')
worker=Path('js/worker/formal_ai_worker_solve.js')
old=hashlib.sha256(subprocess.check_output(['git','show','HEAD:'+str(worker)])).hexdigest()
new=hashlib.sha256(worker.read_bytes()).hexdigest()
matches=subprocess.check_output(['git','ls-files','data/meta/runtime-feature-coverage.json'],text=True).splitlines()
assert len(matches)==1,matches
coverage=Path(matches[0]);text=coverage.read_text()
assert text.count(old)==1
coverage.write_text(text.replace(old,new))
for source,target in [('js/server/worker-script-prerequisites.mjs','ts/server/worker-script-prerequisites.mts'),('js/worker-script-prerequisites.js','ts/worker-script-prerequisites.ts')]:
    old_source=subprocess.check_output(['git','show','HEAD:'+source])
    old_target=subprocess.check_output(['git','show','HEAD:'+target])
    assert old_source==old_target,(source,target)
    Path(target).write_bytes(Path(source).read_bytes())
print(json.dumps({'oldSourceSha256':old,'actualSourceSha256':new,'coverage':str(coverage),'typeScriptProjectionsEqual':True}))
path=base/'all-local-gates.json'
if path.exists():
    data=json.loads(path.read_text())
    print('GATES',json.dumps({k:v for k,v in data.items() if k!='gateLogs'}))
    raw=gzip.decompress((base/'all-local-gates.log.gz').read_bytes()).decode()
    print('FAILURES','\n'.join(line for line in raw.splitlines() if line.startswith('FAIL') or 'gates:' in line or 'total' in line))
else: print('GATES NOT FINISHED')
