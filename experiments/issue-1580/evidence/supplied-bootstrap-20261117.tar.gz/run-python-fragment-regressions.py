from pathlib import Path
import gzip
import hashlib
import json
import subprocess

test_path = Path('experiments/issue-1580/template-python-fragment-integrity.test.mjs')
entrypoint = Path('rust/tests/web/issue-1580-template-observations.test.mjs')
addition = "import '../../../experiments/issue-1580/template-python-fragment-integrity.test.mjs';\n"
entry_text = entrypoint.read_text()
assert entry_text.count(addition) <= 1
if addition not in entry_text:
    entrypoint.write_text(entry_text + addition)
directory = Path('experiments/issue-1580/evidence/checks/python-fragment-collision')
directory.mkdir(parents=True, exist_ok=True)
if (directory / 'before.json').exists() and not (directory / 'initial-reporter.json').exists():
    (directory / 'before.json').rename(directory / 'initial-reporter.json')
    (directory / 'before.log.gz').rename(directory / 'initial-reporter.log.gz')
source = test_path.read_text()
guard_line = '''    writeFileSync(script,source.replace(boundary,'    with fragment_path.open("x") as fragment:\\n        fragment.write(content)'));'''
assert source.count(guard_line) == 1
before = source.replace(guard_line, '    writeFileSync(script,source); // Negative control: keep the original truncating write.')
before_path = test_path.with_name('python-fragment-before-control.test.mjs')
assert not before_path.exists()
before_path.write_text(before)
(directory / 'before-test-source.mjs.gz').write_bytes(gzip.compress(before.encode(), mtime=0))

def run_test(name, path):
    arguments = ['timeout', '600', 'node', '--test', '--test-concurrency=1', '--test-reporter=tap', str(path)]
    completed = subprocess.run(arguments, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    data = completed.stdout
    (directory / f'{name}.log.gz').write_bytes(gzip.compress(data, mtime=0))
    summary = {
        'arguments': arguments,
        'exitCode': completed.returncode,
        'rawBytes': len(data),
        'rawSha256': hashlib.sha256(data).hexdigest(),
        'summary': [line for line in data.decode().splitlines() if line.startswith(('# tests ', '# pass ', '# fail ', '# skipped '))],
    }
    (directory / f'{name}.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2), flush=True)
    return completed.returncode, data.decode()

try:
    status, output = run_test('before', before_path)
    assert status == 1 and '# pass 3' in output and '# fail 1' in output and '# skipped 0' in output, output
    assert 'not ok 2 - Python candidate rejects a same-second collision and preserves the earlier bytes' in output
finally:
    before_path.unlink()
status, output = run_test('after', test_path)
assert status == 0 and '# pass 4' in output and '# fail 0' in output and '# skipped 0' in output, output
status, output = run_test('maintained', entrypoint)
assert status == 0 and '# pass 29' in output and '# fail 0' in output and '# skipped 0' in output, output
print('All four fragment regressions and all 29 maintained cases passed. The original preservation control failed exactly once as expected.', flush=True)
