from pathlib import Path
import subprocess
for phrase in ['render injects the generation-time set','forGeneration reads the host source cache','prepared pull request metadata decodes','original operations and authority remain','default.*read']:
    r=subprocess.run(['rg','-l',phrase,'rust/tests/web','experiments'],text=True,capture_output=True)
    print('SEARCH',phrase,r.stdout)
lines=Path('/tmp/issue-1580-research/main-444575f2-44163377753.log').read_text().splitlines()
for n in [2452,2904,3343,5241,6798]:
    print('CLI',n)
    for k in range(n-24,n+1): print(k,lines[k-1].split('\t',2)[-1][:900])
