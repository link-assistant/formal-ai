import gzip
import json
from pathlib import Path

for name in ['task-cue-final-gates', 'ci-logs/synthesis-c8fb9ad1']:
    directory = Path('/tmp/issue-1580-research') / name
    print('DIRECTORY', name)
    log = directory / 'worker.log'
    if log.exists():
        print('\n'.join(log.read_text(errors='replace').splitlines()[-5:]))
for directory in [Path('experiments/issue-1580/evidence/ci/synthesis-c8fb9ad1'), Path('experiments/issue-1580/evidence/checks/quoted-passage-cues/final-gates')]:
    for path in sorted(directory.iterdir()):
        print('FILE', path.name, path.stat().st_size)
        if 'completed-results' in path.name or path.name == 'results.json':
            payload = gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes()
            value = json.loads(payload)
            print(json.dumps(value, ensure_ascii=False, indent=2)[:13000])
