from pathlib import Path
import json
root=Path('/tmp/gh-issue-solver-1794900398048')
review=json.loads((root/'experiments/issue-1580/evidence/checks/unknown-role-native-validation/review.json').read_text())
assert review['allPassed'] and review['sourceUnchangedDuringValidation']
assert review['gateCounts']=={'PASS':87,'FAIL':0,'SKIP':52}
assert review['focusedCounts']=={'tests':86,'pass':85,'fail':0,'skipped':1}
index=json.loads((root/'docs/case-studies/issue-1580/templates/java-historical-review-index.json').read_text())
assert index['cumulativeSummary']['literalPages']==124 and index['cumulativeSummary']['literalLines']==8069
plan=root/'experiments/issue-1580/work-plan.md'
text=plan.read_text()
old='- [ ] Archive and publish this complete batch after the fresh single-push gate; collect every next-head workflow, execute all 13 captured-source controls and retain the original Spanish sibling and merged native/HTTP checks.'
new='- [x] Publish the complete batch as `f6ecab59` after the single-push gate; retain all 23 completed workflows (21 successful, two failed), all 13 passing captured-source controls, the original Spanish sibling, 33 isolated cases and three HTTP replays. Both actual failure classes are investigated and repaired in the following batch.'
assert text.count(old)==1
text=text.replace(old,new)
text+='''

## Large-diff selection, role registry and original unknown-source replay

- [x] Finish collection for published `f6ecab59`: 21/23 workflows succeed. Layered CI 44359971827 fails because Node's default Git-diff output buffer is too small (`ENOBUFS`, job log line 1175). Pipeline 44359973125 fails only the stale role namespace (fast-lint log lines 774–775). Preserve exact-head timestamps, complete raw logs and hashes; inspect both actual failure spans before any next push.
- [x] Literally review native log lines 1600–1870: all 13 captured-source contracts, original Spanish sibling, 33 isolated native tests and three real HTTP replays pass. This is 47 Rust tests and three HTTP tests on `f6ecab59`; it does not verify the new local unknown-source target or the entire issue. Full raw-log literal review remains unfinished.
- [x] Bound both focused-selector Git calls to 16 MiB and use NUL-separated paths. Both large-diff regressions fail with `ENOBUFS` before the fix and all eight focused-map tests pass afterward, including newline paths and partial-output refusal. Retain the actual complete branch-diff selection. Commit `ae1a9cb1`.
- [x] Repair the original cursor fixture's false unknown assumption while retaining the exact full attributed cursor answer as a positive control. Use existing invented terms and offline execution for the genuine local miss. Admit the nine existing unknown-source contracts as one isolated hosted target; local policy checks reproduce the missing target before the repair and pass 24/24 afterward. Commit `ded70965`; actual native execution of these nine remains pending.
- [x] Refresh the governed witness with the unchanged authoritative reader. Complete object comparison permits five source-hash replacements and exactly one inspected diagnostic change (`answer` to `answer_offline`). All 1,185 records, 221 supported and 964 unsupported cases remain unchanged in count; this earns no additional execution or reasoning credit.
- [x] Give the authored cache cue its hyphenated `request-prefix` role and regenerate all 667 roles. The current-data regression fails before regeneration and passes afterward. Both maintained JavaScript and canonical Python registry checks pass; add the same check to shared local gates. Commit `dc618e45`; no policy ceiling is raised.
- [x] Validate unchanged source `dc618e45`: eight focused files enumerate 86 tests, with 85 passing, zero failures and one explicit local Python-parity skip. TypeScript checks 729 files; Rust 2024 formatting and whitespace pass. All 139 local gates finish: 87 pass, zero fail and 52 explicitly skip native/context work. Retain and verify every payload hash; literally read complete focused and aggregate logs, without claiming every detailed gate payload was read. No native build runs locally.
- [x] Refresh feedback: issue body and all ten issue/PR conversation comments are unchanged; zero inline comments, reviews or required sub-issues. Main `7b7e189d` remains an ancestor. Preserve the previous publication receipt and every payload hash.
- [x] Literally read Java historical pages 123–124 without truncation: continuous 124/254 pages, 8,069 lines, 111 complete files and one partial Node catalog through line 490/884. Pages 125–254 and full semantic applicability remain unfinished.
- [ ] Publish this repaired batch after fresh queue checks and collect every current-head hosted outcome, including the nine unknown-source contracts. Do not equate a passing scoped run with issue completion.
- [ ] Continue the other 45 original native panics, three historical budget terminations and every broader acceptance criterion. The cursor contract remains among the 45 until actual hosted execution is verified. Keep PR #1581 draft and unmerged; supplied work earns zero independent reasoning credit (0/20 accepted), and the 5% target remains reporting only.
'''
plan.write_text(text)
checkpoint=root/'docs/case-studies/issue-1580/language-source-binding-checkpoint.md'
text=checkpoint.read_text()
assert '## Large-diff selection and role-registry follow-through' not in text
text+='''

## Large-diff selection and role-registry follow-through

Published `f6ecab596c331da59c40abd07d69c431beba1066` completes all 23 workflows: 21 pass. [Layered CI 44359971827](https://github.com/link-assistant/formal-ai/actions/runs/44359971827) fails when the complete branch diff exceeds Node's default child-process buffer (`ENOBUFS`, failed job line 1175). [Pipeline 44359973125](https://github.com/link-assistant/formal-ai/actions/runs/44359973125) fails only its role namespace: the new cache cue used an undeclared role (fast-lint lines 774–775). Complete failed workflow/job logs, exact commit identities, timestamps and hashes are retained in `evidence/ci/complete-cache-f6ecab59/`.

That head's [actual native job](https://github.com/link-assistant/formal-ai/actions/runs/44359973125/job/134998807242) passes **all 13 captured-source controls**, the original Spanish sibling and **33 isolated cases**: **47 Rust tests**. Both forced-function HTTP modes and main's structured-output HTTP case also pass, with no HTTP skips. Native lines 1600–1870 were literally read, including all four additional complete-request controls. The entire raw log has not been literally reviewed.

Both focused-selector Git calls now have a finite 16 MiB output allowance and consume NUL-delimited paths. Two bounded 12,002-path regressions reproduce `ENOBUFS` before the repair; all eight selector tests pass afterward, preserving newline paths and refusing partial output from failed Git. Actual complete branch-diff selection also succeeds. The cue's role is now the hyphenated `request-prefix`; generated roles match the runtime's loaded meanings. The new current-data regression fails before regeneration and passes afterward. Both maintained JavaScript and canonical Python checks agree on **667 roles**, and the shared local inventory now contains the same check. No policy ceiling is raised.

The original unknown-source fixture had asked for `cursor`, whose valid attributed definition is already cached. Its local-miss case now uses existing invented terms and offline execution. The positive case retains the **entire exact cursor answer and source attribution**. All nine original unknown-source contracts are admitted as an isolated hosted target; their actual native execution remains pending. The unchanged governed reader refresh permits only five authoritative source-hash replacements and one inspected unsupported-call diagnostic (`answer` to `answer_offline`), preserving **1,185 records, 221 supported and 964 unsupported** without execution-credit gains.

Final source `dc618e45` passes **85 tests across eight focused files**, with zero failures and **one explicit local Python-parity skip**. TypeScript checks **729 files**, Rust 2024 formatting and whitespace pass, and all **139 local gates** finish: **87 pass, zero fail, 52 explicit native/context skips**. Source hashes stay unchanged throughout. Complete aggregate/focused logs are literally read; all detailed gate payload hashes are verified without claiming their full literal review. Evidence is in `evidence/checks/unknown-role-native-validation/`; no native build runs locally.

Main `7b7e189d` remains integrated and refreshed feedback is unchanged. Eight original native failures already have unchanged-source published replays; the other **45**, including the locally repaired cursor fixture until actual hosted verification, and **three historical budget terminations** remain unfinished. Java historical review reaches **124/254 pages**, **8,069 lines**, 111 complete files and one partial Node catalog through line 490/884. Pages 125–254 and complete semantic applicability remain open. Every broader work-plan criterion remains active; PR #1581 stays draft and unmerged. Supplied work earns zero independent reasoning credit (0/20 accepted), and 5% remains a reporting target only.
'''
checkpoint.write_text(text)
readme=root/'docs/case-studies/issue-1580/README.md'
text=readme.read_text()
text+='''

The next [source-binding checkpoint](language-source-binding-checkpoint.md)
records published `f6ecab59`: all 13 captured-source controls, the Spanish sibling,
33 isolated native cases and three HTTP replays pass. Its two workflow failures
are the complete Git-diff buffer and stale generated roles, both reproduced and
repaired locally. The repaired source passes 85 focused tests with one explicit
local skip and 87 executable gates with 52 explicit exclusions. Nine original
unknown-source contracts now have isolated hosted admission; their execution
is pending. Java historical review reaches 124/254 pages and 8,069 lines.
The full issue remains unfinished and the PR remains draft.
'''
readme.write_text(text)
body=root/'experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md'
lines=body.read_text().splitlines()
assert lines[17].startswith('- Main `7b7e189d`') and lines[18].startswith('- Published head `8a74006f`')
lines[17]='- Main `7b7e189d` is integrated. Final source `dc618e45` enumerates **86 tests across eight focused JavaScript files: 85 pass, zero fail, one explicit local Python-parity skip**. TypeScript checks **729 files**, Rust formatting and whitespace pass. All **139 local gates** finish: **87 pass, zero fail, 52 explicit native/context skips**. Candidate source hashes remain unchanged; no native build runs locally. Both selector calls handle a bounded 16 MiB NUL-separated complete diff; both large-diff cases fail before the fix and all eight selector tests pass afterward. The regenerated **667-role** registry passes both maintained JavaScript and canonical Python checks, and its new current-data regression fails before the repair and passes afterward. Shared local gates now include this registry check.'
lines[18]='- Published head `f6ecab59` completes **23 workflows: 21 pass**. [Layered CI](https://github.com/link-assistant/formal-ai/actions/runs/44359971827) fails the default Git output buffer (`ENOBUFS`, job line 1175); [CI/CD Pipeline](https://github.com/link-assistant/formal-ai/actions/runs/44359973125) fails only the undeclared cache-prefix role (fast-lint lines 774–775). Both classes are repaired locally and complete failed logs are retained. Its [actual native job](https://github.com/link-assistant/formal-ai/actions/runs/44359973125/job/134998807242) passes **47 Rust tests: all 13 captured-source controls, the unchanged Spanish sibling and 33 isolated cases**, plus **three real HTTP replays** with no HTTP skips. All four new complete-request controls pass. The nine original unknown-source contracts are newly admitted as an isolated target and await next-head hosted execution. The repaired fixture retains the full exact attributed cursor answer and tests genuine invented-term misses offline. Governed case counts remain **1,185 / 221 supported / 964 unsupported** with the unchanged reader; only five source hashes and one inspected diagnostic change.'
for i,line in enumerate(lines):
 if line.startswith('Unfinished acceptance remains explicit'):
  lines[i]=line.replace('eight replayed on `8a74006f` and 45 still open','eight already replayed with unchanged source and 45 still open, including the cursor contract until hosted verification').replace('**122/254 continuous pages**','**124/254 continuous pages**').replace('8,014 source lines; pages 123–254','8,069 source lines; pages 125–254')
index=lines.index('node --max-old-space-size=256 scripts/translate-es.mjs --check')
lines[index:index]=[
 'timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/focused-test-map.test.mjs',
 'timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/generate-role-registry-js.test.mjs',
 'node --max-old-space-size=256 scripts/generate-role-registry.mjs --check']
text='\n'.join(lines)+'\n'
assert text.count('Fixes #1580')==1
body.write_text(text)
print(json.dumps({'source':review['head'],'focused':review['focusedCounts'],'gates':review['gateCounts'],
 'java':index if False else 124,'fullIssueComplete':False,'independentAuthorshipCredit':0}))
