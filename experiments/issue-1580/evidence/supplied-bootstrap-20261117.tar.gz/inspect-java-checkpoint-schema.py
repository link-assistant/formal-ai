from pathlib import Path
import json
p=Path('docs/case-studies/issue-1580/templates/java-historical-partial-review.json')
review=json.loads(p.read_text())
print('JAVA REVIEW NON-FILE FIELDS',json.dumps({k:v for k,v in review.items() if k!='files'},indent=2))
print('JAVA FIRST FILE',json.dumps(review['files'][0]))
p=Path('docs/case-studies/issue-1580/README.md');lines=p.read_text().splitlines()
print('README TOTAL',len(lines))
for n,line in enumerate(lines[-45:],max(1,len(lines)-44)):print(f'{n}: {line}')
