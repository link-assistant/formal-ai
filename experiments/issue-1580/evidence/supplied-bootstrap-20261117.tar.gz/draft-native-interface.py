from pathlib import Path
import json,re
root=Path.cwd();base=root/'experiments/issue-1580/evidence/checks/native-interface-admission';before=json.loads((base/'before.json').read_text());assert before['exitCode']==1
modules=[('formal_ai_cli','integration/formal_ai_cli.rs'),('http_server','integration/http_server.rs'),('pty','integration/pty.rs'),('structured_stderr','support/structured_stderr.rs'),('with_formal_ai','integration/with_formal_ai.rs'),('with_formal_ai_argv','integration/with_formal_ai_argv.rs'),('issue_819_tui_isolation','integration/issue_819_tui_isolation.rs'),('issue_1138_family_behaviour','integration/issue_1138_family_behaviour.rs'),('seed_and_memory','unit/formal_ai/seed_and_memory.rs'),('handler_migration','unit/seed/issue_699_handler_migration.rs')]
source='//! Replay the complete CLI, terminal, memory and handler-family contracts.\n//! Existing test modules and their shared fixtures are included unchanged.\n\n'
for name,path in modules:source+=f'#[path = "{path}"]\npub mod {name};\n'
(root/'rust/tests/interface_contracts.rs').write_text(source)
p=root/'rust/Cargo.toml';s=p.read_text();anchor='[[test]]\nname = "integration"';assert s.count(anchor)==1;s=s.replace(anchor,'# The focused lane replays CLI/PTY fixtures without the monolithic integration target.\n[[test]]\nname = "interface_contracts"\npath = "tests/interface_contracts.rs"\n\n'+anchor);p.write_text(s)
p=root/'scripts/ci-native-regressions.sh';s=p.read_text();anchor='--test operational_contracts --test reasoning_contracts)';assert s.count(anchor)==1;p.write_text(s.replace(anchor,'--test operational_contracts --test reasoning_contracts --test interface_contracts)'))
p=root/'scripts/ci-pull-request-admission.mjs';s=p.read_text();manifest=json.loads((base/'input-identity.json').read_text());paths=['rust/tests/interface_contracts.rs']+[r['path'] for r in manifest['inputs']];anchor="const NATIVE_REGRESSION_INPUTS = new Set([\n";assert s.count(anchor)==1;s=s.replace(anchor,anchor+''.join('  '+repr(path)+',\n' for path in paths));p.write_text(s)
(root/'changelog.d/issue-1580-native-interfaces.md').write_text('Replay the complete native CLI, PTY isolation, cross-surface memory and retired-handler regression modules in the focused pull-request lane. Changes to every shared harness and captured input now select that lane.\n')
count=0
for _,path in modules:
 p=root/'rust/tests'/path;count+=p.read_text().count('#[test]')
for name in ['fixture_env','issue_1582','model_metadata']:count+=(root/f'rust/tests/integration/with_formal_ai/{name}.rs').read_text().count('#[test]')
print(json.dumps({'includedNativeCases':count,'rootModules':len(modules),'classifiedInputs':len(paths),'existingModuleBytesChanged':False,'nativeExecutionPendingCI':True,'fullIssueComplete':False}))
