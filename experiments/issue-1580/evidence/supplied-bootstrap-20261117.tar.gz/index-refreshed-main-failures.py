import json
import pathlib
import re

base=pathlib.Path('experiments/issue-1580/evidence/ci/main-058e9bef-refresh')
indexes=[]
patterns=[('native-failed', re.compile(r'^test .* \.\.\. FAILED\s*$')),('js-failed',re.compile(r'^(?:not ok |✖ )')),('fatal',re.compile(r'(?:##\[error\]|error: test failed|process completed with exit code|process has been terminated|Error: Process completed)',re.I))]
for run in [44174504103,44174504347]:
    path=pathlib.Path(f'/tmp/issue-1580-research/main-058e9bef-refresh-{run}.log')
    lines=path.read_text().splitlines()
    markers=[]
    for number,line in enumerate(lines,1):
        parts=line.split('\t',2)
        payload=parts[-1]
        payload=re.sub(r'^\d{4}-\d\d-\d\dT\S+\s*','',payload)
        for kind,pattern in patterns:
            if pattern.search(payload):
                markers.append({'line':number,'kind':kind,'payload':payload})
                break
    index={'run':run,'totalLines':len(lines),'scope':'Failure-marker index only; unselected raw lines have not been reviewed.','markers':markers}
    (base/f'{run}-failure-index.json').write_text(json.dumps(index,indent=2)+'\n')
    indexes.append(index)
    print(f'RUN {run} totalLines={len(lines)} markers={len(markers)}')
    for entry in markers:
        print(f'{entry["line"]}: {entry["kind"]}: {entry["payload"][:230]}')
