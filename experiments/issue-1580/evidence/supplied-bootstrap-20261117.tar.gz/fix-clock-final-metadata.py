from pathlib import Path
import gzip,hashlib,json,subprocess,time
r=Path.cwd();b=r/'experiments/issue-1580/evidence/checks/spelled-calendar-clock/final-validation';renames=[]
for folder in [b,b.parent/'validation']:
 p=folder/'gate-check-tests-as-docs.log.gz';q=folder/'gate-check-tests-as-documentation.log.gz';assert p.exists() and not q.exists();p.rename(q)
 m=folder/'detailed-gate-manifest.json';rows=json.loads(m.read_text());selected=[x for x in rows if x['file']==p.name];assert len(selected)==1;selected[0]['file']=q.name;assert hashlib.sha256(q.read_bytes()).hexdigest()==selected[0]['archiveSha256'];m.write_text(json.dumps(rows,indent=2)+'\n');renames.append({'from':str(p.relative_to(r)),'to':str(q.relative_to(r)),'archiveSha256':selected[0]['archiveSha256']})
(b/'evidence-filename-renames.json').write_text(json.dumps(renames,indent=2)+'\n')
for name in ['data/meta/abbreviation-ratchet.lino','docs/status.md']:
 raw=(r/name).read_bytes();(b/(Path(name).name+'.before.gz')).write_bytes(gzip.compress(raw,mtime=0))
steps=[('refresh-status',['node','--max-old-space-size=256','scripts/render-status.mjs','--write']),('lower-abbreviation-ceilings',['node','--max-old-space-size=256','scripts/measure-abbreviations.mjs','--write']),('repaired-metadata-gates',['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-status-render'])]
records=[]
for name,args in steps:
 start=time.monotonic();p=subprocess.run(args,cwd=r,capture_output=True);raw=p.stdout+p.stderr;packed=gzip.compress(raw,mtime=0);filename=name+'.log.gz';(b/filename).write_bytes(packed);row={'name':name,'argv':args,'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3),'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'lines':len(raw.splitlines())};records.append(row);(b/'follow-up-records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode);print(raw.decode());assert p.returncode==0,name
for name in ['check-abbreviations','check-status-render']:
 raw=(r/'experiments/formal_ai_subagent/sandboxes/gates'/(name+'.log')).read_bytes();packed=gzip.compress(raw,mtime=0);filename='repaired-gate-'+name+'.log.gz';(b/filename).write_bytes(packed);print(name+' DETAIL\n'+raw.decode())
print('Preserved the raw 85/2/52 gate run and verified both focused repairs. No filename ceiling increased.')
