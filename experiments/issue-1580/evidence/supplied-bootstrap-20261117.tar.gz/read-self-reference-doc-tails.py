from pathlib import Path
for name,start,end in [('docs/case-studies/issue-1580/templates/README.md',45,120),('docs/case-studies/issue-1580/README.md',1,45)]:
    lines=Path(name).read_text().splitlines()
    print(f'FILE {name} ({len(lines)} lines)')
    for n in range(start,min(end,len(lines))+1):print(f'{n}: {lines[n-1]}')
for name in ['current-head-status.py','prepare-eighth-evidence.py','fresh-feedback-eighth.py','push-eighth-round.py']:
    print('BOOTSTRAP '+name+'\n'+(Path('/tmp/issue-1580-research')/name).read_text())
