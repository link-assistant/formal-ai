#!/bin/sh
set -eu
test "$(git branch --show-current)" = issue-1580-8d61a32a61e1
python3 - <<'PY'
import gzip,hashlib,json
from pathlib import Path
target=Path('experiments/issue-1580/evidence/native-baseline')
target.mkdir(exist_ok=True)
rows=[]
for pattern in ['native-probe-*.json','benchmark-probe-*.json']:
    for file in sorted(Path('/tmp/issue-1580-research').glob(pattern)):
        data=file.read_bytes();json.loads(data)
        name=file.name+'.gz';(target/name).write_bytes(gzip.compress(data,mtime=0))
        rows.append({'file':name,'sha256':hashlib.sha256(data).hexdigest()})
(target/'index.json').write_text(json.dumps({'source':'b68d21647e678cce91ec83d5a28ea86b481064bf','version':'0.355.34','binarySha256':'7edb8999b01d21047faea46546ae84af306e2e97fc8713df180ab21c5c6ce1ec','artifact':14241647158,'run':43899940611,'network':'local failing HTTP endpoint only','afterFixVerification':False,'probes':rows},indent=2)+'\n')
PY
git add data/benchmarks/fast-pull-request-javascript-tests.json
git commit -m 'test(ci): run cache and candidate regressions in the fast lane'
git add experiments/issue-1580/template-download-retry.test.mjs experiments/issue-1580/upstream/cpp-doxygen-download-retry.md experiments/issue-1580/upstream/filed-issues.txt
git commit -m 'test(ci): reproduce truncated template archive downloads'
python3 experiments/issue-1580/archive-evidence.py
git add docs/case-studies/issue-1580 experiments/issue-1580
git diff --cached --check
git commit -m 'docs(ci): preserve issue 1580 evidence and complete template inventories'
git status --short
