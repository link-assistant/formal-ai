from pathlib import Path
import subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
for name,lo,hi in [('rust/src/solver_handlers/statistics/primality.rs',1,250),('rust/src/solver_handlers/statistics.rs',675,755),('rust/tests/web/issue-403-number-constraints-parity.test.mjs',1,190),('rust/src/solver_synthesis.rs',200,267)]:
    lines=(root/name).read_text().splitlines()
    print('\nFILE',name,'LINES',len(lines))
    for n in range(lo-1,min(hi,len(lines))): print(f'{n+1}: {lines[n]}')
result=subprocess.run(['rg','-n','handle_.*constraint|property_interval|has_property|number_constraints','rust/src/solver_handlers/statistics.rs','rust/src/meta_method_dispatch.rs','rust/src/rule_executor.rs'],cwd=root,text=True,capture_output=True)
print('\nDISPATCH REFERENCES',result.stdout,result.stderr)
