from pathlib import Path
import json,hashlib,subprocess,gzip,os,time
target=Path("packages/picomatch-compat")
p=target/"lib/parse.js";text=p.read_text()
marker="const analyzeRepeatedExtglob = (body, options) => {"
assert text.count(marker)==1
helper=r'''// A wildcard inside another unbounded repetition can backtrack exponentially,
// including when the extglob has only one branch (GHSA-fc5q-39xc-vjpf).
// Escaped, quoted and bracket-class stars remain literals.
const hasUnboundedStar = pattern => {
  let bracket = 0;
  let quote = false;
  let escaped = false;
  for (const ch of pattern) {
    if (escaped) {
      escaped = false;
      continue;
    }
    if (ch === '\\') {
      escaped = true;
      continue;
    }
    if (ch === '"' && bracket === 0) {
      quote = !quote;
      continue;
    }
    if (quote) continue;
    if (ch === '[') bracket++;
    else if (ch === ']' && bracket > 0) bracket--;
    else if (ch === '*' && bracket === 0) return true;
  }
  return false;
};

'''
text=text.replace(marker,helper+marker)
old="""  if (sawStarSequence) {
    return combinable
      ? { risky: true, safeOutput: buildCharClassStar([...new Set(safeChars)]) }
      : { risky: true };
  }

  return { risky: false };
"""
new=old.replace("  return { risky: false };","""  // Preserve the safe flattening above, then apply the guard to every branch
  // count, including a single wildcard branch or a wildcard under @(…).
  if (branches.some(hasUnboundedStar)) {
    return { risky: true };
  }

  return { risky: false };""")
assert text.count(old)==1
p.write_text(text.replace(old,new))
d=json.loads((target/"upstream.json").read_text())
d["scope"]="Local security backport: extend the existing repeated-extglob guard to unescaped wildcard stars in every branch count, after preserving its proved-safe character-class flattening. Risky patterns are literalized using the existing fallback. No upstream release or general regex-safety claim."
for row in d["files"]:row["localSha256"]=hashlib.sha256((target/row["path"]).read_bytes()).hexdigest()
(target/"upstream.json").write_text(json.dumps(d,indent=2)+"\n")
(target/"README.md").write_text("""# Picomatch security backport

This private CommonJS package retains picomatch 4.0.7's published source and MIT
license, with one local parser change for
[GHSA-fc5q-39xc-vjpf](https://github.com/advisories/GHSA-fc5q-39xc-vjpf).
The upstream tarball identity and per-file hashes are in upstream.json.
All source files except lib/parse.js are unchanged. This is a local backport,
not an upstream patched release.

The existing repeated-extglob guard skips single branches such as +(*) and
+(*a). A wildcard nested under unbounded repetition can consume exponential
time even for a 42-byte subject. The backport extends that guard to every branch
count, while retaining its safe character-class flattening. Escaped stars,
bracket-class stars, ordinary globs and literal repetitions remain supported.

Risky repeated wildcards now match their literal spelling through the existing
fallback. The upstream maxExtglobRecursion: false option still disables the guard;
callers processing untrusted patterns must retain the default protection.
This does not make arbitrary raw regular-expression features safe.

The focused regression is rust/tests/web/picomatch-security-backport.test.mjs.
Its hostile probes run in separate children with a 64 MiB heap cap, 256 KiB
stack, 1.25-second kill deadline and finite 42-byte subjects.
Remove the local override when an upstream release fixes the advisory and
passes these controls.
""")
root=Path("experiments/issue-1580/evidence/checks/picomatch-single-branch")
env=dict(os.environ);env["NODE_OPTIONS"]="--max-old-space-size=96"
command=["timeout","600","node","--test","--test-concurrency=1","rust/tests/web/picomatch-security-backport.test.mjs"]
started=time.monotonic();r=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(root/"after.log.gz").write_bytes(gzip.compress(r.stdout,mtime=0))
(root/"after.json").write_text(json.dumps({"command":command,"status":r.returncode,"durationSeconds":round(time.monotonic()-started,3),"rawSha256":hashlib.sha256(r.stdout).hexdigest(),"nodeHeapMiB":96,"childHeapMiB":64,"childStackKiB":256,"childTimeoutMilliseconds":1250,"maxSubjectBytes":42,"autonomousAuthorshipCredit":0},indent=2)+"\n")
print(r.stdout.decode())
assert r.returncode==0
