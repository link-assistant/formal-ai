set -eu
cat /tmp/issue-1580-research/inventory-cjs-before.log
rg --files experiments/issue-1580/evidence/chrono-upstream
cat experiments/issue-1580/template-reference-graph.test.mjs
sed -n '1,180p' CONTRIBUTING.md
rg --files -g AGENTS.md -g '*gate*' experiments/formal_ai_subagent scripts
