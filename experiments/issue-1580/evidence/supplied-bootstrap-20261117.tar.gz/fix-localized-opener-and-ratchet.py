from pathlib import Path

root = Path('/tmp/gh-issue-solver-1794900398048')
def replace(file, before, after):
    target = root / file
    source = target.read_text()
    assert source.count(before) == 1, (file,before)
    target.write_text(source.replace(before, after))

replace('js/worker/formal_ai_worker_seed_responses_and_language.js',
'''function selectUnknownOpener(prompt, language) {
  const fromWasm = wasmSelectUnknownOpener(prompt, language);''',
'''function selectUnknownOpener(prompt, language) {
  // Keep the localized seed intact when only a different language's pool exists.
  if (!unknownOpenerRegistry().pools.some((pool) => pool.language === language)) return "";
  const fromWasm = wasmSelectUnknownOpener(prompt, language);''')

replace('rust/src/web_engine_core.rs',
'''/// Pick the deterministic unknown-answer opener for a prompt/language pair.
#[must_use]
pub fn select_unknown_opener(prompt: &str, language: &str) -> &'static str {
    let pool = unknown_openers_for(language);''',
'''/// Pick an opener only when the seed declares a pool in the requested language.
/// An empty result leaves the localized unknown answer intact.
#[must_use]
pub fn select_unknown_opener(prompt: &str, language: &str) -> &'static str {
    if !with_opener_registry(|registry| registry.pools.iter().any(|pool| pool.language == language)) {
        return "";
    }
    let pool = unknown_openers_for(language);''')

replace('rust/src/unknown_opener.rs',
'''    let opener = select_unknown_opener(prompt, language);
    let body = strip_leading_opener(seed_text, &unknown_openers_for(language));''',
'''    let opener = select_unknown_opener(prompt, language);
    if opener.is_empty() {
        return seed_text.to_owned();
    }
    let body = strip_leading_opener(seed_text, &unknown_openers_for(language));''')

file = root / 'rust/src/unknown_opener.rs'
file.write_text(file.read_text() + '''
#[cfg(test)]
mod tests {
    #[test]
    fn a_language_without_an_opener_pool_keeps_its_complete_localized_seed() {
        let seed = crate::seed::response_for("unknown", "es").expect("Spanish unknown seed");
        assert_eq!(
            super::language_aware_unknown_answer(
                "¿Cómo funciona la fotosíntesis submarina de xyzzy?",
                crate::Language::Spanish,
            ),
            seed,
        );
    }
}
''')

replace('data/meta/core-boundary-ledger.lino','  source_lines_max 36519\n','  source_lines_max 36517\n')
replace('data/meta/core-boundary-ledger.lino',
'''  source rust/src/solver_handlers/verifiable_task.rs
    disposition promote
    baseline_lines 795''',
'''  source rust/src/solver_handlers/verifiable_task.rs
    disposition promote
    baseline_lines 793''')
replace('data/meta/core-boundary-ledger.lino',
'  boundary "docs/design/minimal-core-boundary.md"',
'  note "Issue #1580 retains seeded membership evidence alongside retrieved matches. Removing the obsolete conditional and its trailing blank line lowers verifiable_task.rs from 795 to 793 lines and source_lines_max by two; dispositions and migration ceilings are unchanged."\n  boundary "docs/design/minimal-core-boundary.md"')
replace('data/meta/worker-line-budget/formal_ai_worker_seed_responses_and_language.lino',
'  ceiling 920\n', '  ceiling 922\n  note "Issue #1580 adds a seed-pool presence guard before WASM opener selection, preserving the complete localized unknown text when that language has no opener pool. Two measured lines implement the shared native/browser contract."\n')
print('Applied supplied fallback fix and exact measured line-count updates; zero authorship credit.')
