from pathlib import Path
import json, subprocess

scratch=Path('/tmp/issue-1580-research')
for relative in ['picomatch-template-research/js-report.md','picomatch-template-research/python-report.md','picomatch-template-research/cpp-report.md','archive-round-bootstrap.py','archive-evidence.py','review-picomatch-final-diff.py']:
    path=scratch/relative
    print('\nFILE',relative)
    print(path.read_text() if path.exists() else 'MISSING')
root=Path('/tmp/gh-issue-solver-1794900398048')
result=subprocess.run(['rg','-n','npm (ci|install)|desktop/package|vscode/package|COPY.*desktop|COPY.*vscode|picomatch','desktop/Dockerfile','Dockerfile','.github/workflows','scripts/build-desktop.sh','desktop/package.json','vscode/package.json'],cwd=root,text=True,capture_output=True)
print('\nTARGETED INSTALL SEARCH',result.stdout, result.stderr)
