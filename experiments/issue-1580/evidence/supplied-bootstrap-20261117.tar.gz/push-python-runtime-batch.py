from pathlib import Path
source=Path('/tmp/issue-1580-research/push-python-fragment-batch.py').read_text()
source=source.replace('b79dc1e0f147ed57d8e317c1b93bfa6ffc79078d','624812120feee0180bf9df8164f87e73326b5cb8')
source=source.replace('python-fragment-','python-runtime-')
exec(compile(source,'runtime-batch-push','exec'))
