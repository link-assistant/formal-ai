set -eu
git diff --check
set +e
node experiments/formal_ai_subagent/local-gates.mjs --only check-file-size,check-file-size-js-twin,check-changelog-fragment-js-twin,check-ci-speed > /tmp/issue-1580-research/java-release-checks/gates.log 2>&1
result=$?
set -e
cat /tmp/issue-1580-research/java-release-checks/gates.log
exit "$result"
