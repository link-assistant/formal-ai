import gzip,hashlib,json,pathlib,re
path=pathlib.Path('experiments/issue-1580/evidence/ci/main-058e9bef-refresh/44174504347.log.gz')
if not path.exists():
    candidates=[p for p in path.parent.glob('*44174504347*')]
    print('Candidate archives',*[str(p) for p in candidates]);raise SystemExit(0)
raw=gzip.decompress(path.read_bytes());lines=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',raw.decode()).splitlines()
warnings={}
for index,line in enumerate(lines):
    match=re.search(r'(?:^|\s|::)warning(?:\[[^\]]+\])?(?:::|:)\s*(.*)',line)
    if not match:continue
    text=match.group(1)
    if re.search(r'generated \d+ warning|generated .*warnings?',text):continue
    locations=[]
    for next_line in lines[index+1:index+5]:
        site=re.search(r'-->\s+([^\s]+:\d+:\d+)',next_line)
        if site:locations.append(site.group(1))
    key=(text,tuple(locations));warnings.setdefault(key,[]).append(index+1)
rows=[{'warning':text,'locations':list(locations),'logLines':indices} for (text,locations),indices in warnings.items()]
target=pathlib.Path('experiments/issue-1580/evidence/checks/main-native-warning-inventory')
target.mkdir(exist_ok=True)
data={'source':str(path),'rawSha256':hashlib.sha256(raw).hexdigest(),'scope':'Warning marker and nearby source-location inventory only; not full raw-log review or confirmation each warning is current on this branch.','uniqueWarningAndLocationGroups':len(rows),'groups':rows,'nativeExecuted':False}
(target/'inventory.json.gz').write_bytes(gzip.compress((json.dumps(data,indent=2)+'\n').encode(),mtime=0))
print(json.dumps({'source':str(path),'groups':len(rows)}))
for row in rows[:30]:print(json.dumps(row))
