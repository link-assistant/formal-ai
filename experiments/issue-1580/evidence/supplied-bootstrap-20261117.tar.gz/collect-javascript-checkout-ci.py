from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess, sys, traceback

root=Path.cwd()
head='bfe5ac0f3babe512f1bf0a03935bd1d220f9e40f'
base=root/'experiments/issue-1580/evidence/ci/javascript-checkout-bfe5ac0f'
scratch=Path('/tmp/issue-1580-research/ci-logs/javascript-checkout-bfe5ac0f')
if len(sys.argv)==1:
    scratch.mkdir(exist_ok=False)
    with (scratch/'worker.log').open('wb') as stream:
        process=subprocess.Popen([sys.executable,__file__,'finish'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({'pid':process.pid,'scratch':str(scratch)}));sys.exit(0)
assert sys.argv[1:]==['finish']
records=[]
def capture(label,args,parse=False):
    result=subprocess.run(args,capture_output=True)
    (scratch/(label+'.stdout')).write_bytes(result.stdout)
    (scratch/(label+'.stderr')).write_bytes(result.stderr)
    (base/(label+'.stdout.gz')).write_bytes(gzip.compress(result.stdout,mtime=0))
    (base/(label+'.stderr.gz')).write_bytes(gzip.compress(result.stderr,mtime=0))
    records.append({'name':label,'argv':args,'exitCode':result.returncode,'stdoutSha256':hashlib.sha256(result.stdout).hexdigest(),'stderrSha256':hashlib.sha256(result.stderr).hexdigest()})
    assert result.returncode==0,(label,result.stderr.decode())
    return json.loads(result.stdout) if parse else result.stdout

complete=False
try:
    pages=capture('completed-head-runs',['gh','api',f'repos/link-assistant/formal-ai/actions/runs?branch=issue-1580-8d61a32a61e1&head_sha={head}&per_page=100','--paginate','--slurp'],True)
    runs=[row for page in pages for row in page['workflow_runs'] if row['head_sha']==head]
    assert len(runs)==23 and all(row['status']=='completed' for row in runs)
    rows=[]
    for run in runs:
        if run['name']!='Layered CI' and run['conclusion']=='success':continue
        pages=capture('jobs-'+str(run['id']),['gh','api',f"repos/link-assistant/formal-ai/actions/runs/{run['id']}/jobs?per_page=100",'--paginate','--slurp'],True)
        jobs=[row for page in pages for row in page['jobs']]
        if run['conclusion']!='success':capture('failed-workflow-'+str(run['id']),['gh','run','view',str(run['id']),'--repo','link-assistant/formal-ai','--log'])
        for job in jobs:
            if not (job['name'].startswith('js tier') or job['conclusion']=='failure'):continue
            raw=capture('job-'+str(job['id']),['gh','api',f"repos/link-assistant/formal-ai/actions/jobs/{job['id']}/logs"])
            lines=raw.decode().splitlines()
            selected=[{'line':i+1,'text':line} for i,line in enumerate(lines) if any(token in line for token in ['tests ','pass ','fail ','test cases','Test results','TEST_BUDGET_SECONDS=','::error','not ok','error:'])]
            rows.append({'jobId':job['id'],'name':job['name'],'conclusion':job['conclusion'],'steps':job['steps'],'rawLines':len(lines),'rawSha256':hashlib.sha256(raw).hexdigest(),'selectedLines':selected,'wholeLogLiterallyRead':False})
    summary={'observedAt':datetime.now(timezone.utc).isoformat(),'head':head,'workflowCount':len(runs),'success':sum(row['conclusion']=='success' for row in runs),'failed':[{'id':row['id'],'name':row['name'],'conclusion':row['conclusion']} for row in runs if row['conclusion']!='success'],'jobs':rows,'records':records,'independentAuthorshipCredit':0}
    (base/'completed-results.json').write_text(json.dumps(summary,indent=2)+'\n')
    complete=True
except BaseException:traceback.print_exc()
(scratch/'outcome.json').write_text(json.dumps({'complete':complete,'records':records,'independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps({'complete':complete,'scratch':str(scratch)}),flush=True)
sys.exit(0 if complete else 1)
