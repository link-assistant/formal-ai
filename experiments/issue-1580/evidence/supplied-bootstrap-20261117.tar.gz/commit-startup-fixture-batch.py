from pathlib import Path
import json,subprocess
scratch=Path('/tmp/issue-1580-research')
base=Path('experiments/issue-1580/evidence/checks/main-merge-444575f2/final')
receipt=json.loads((base/'all-local-gates.json').read_text());assert receipt['exitCode']==0
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
paragraph='''\nThe final source gate invocation completes with 86 passes, 52 explicit native/context exclusions and zero failures in 624.294 seconds, with a 256 MiB Node heap cap and cumulative child peak of 1,056,532 KiB. All 86 per-gate archives and the complete aggregate match their recorded hashes. Main advances to 058e9bef during verification (PRs #1600/#1602); preserve this atomic draft locally, merge the new default head and revalidate the combined tree before publishing. This is not native execution or final-head hosted success.\n'''
plan=Path('experiments/issue-1580/work-plan.md');plan.write_text(plan.read_text()+paragraph)
doc=Path('docs/case-studies/issue-1580/main-444575f2-regressions.md');doc.write_text(doc.read_text()+paragraph)
for name in ['archive-round-bootstrap.py','archive-evidence.py']:
 r=subprocess.run(['python3',str(scratch/name)],text=True,capture_output=True,check=True);print(r.stdout)
subprocess.run(['git','diff','--check'],check=True)
prefixes=['experiments/issue-1580/','docs/case-studies/issue-1580/','data/meta/runtime-feature-coverage.json','data/seed/client-integrations.lino','js/server/worker-script-prerequisites.mjs','js/worker-script-prerequisites.js','js/worker/formal_ai_worker_solve.js','ts/server/worker-script-prerequisites.mts','ts/worker-script-prerequisites.ts','ts/worker/formal_ai_worker_solve.ts','rust/embedded/data/','rust/src/agentic_coding/tool_result/source_observation.rs','rust/src/structured_log.rs','rust/tests/source/source_tests/structured_log/tests.rs','rust/tests/web/issue-1168-source-cache.test.mjs','rust/tests/web/issue-1168-workflow-render-parity.test.mjs']
changed=subprocess.check_output(['git','ls-files','--modified','--deleted','--others','--exclude-standard'],text=True).splitlines()
assert changed
assert all(any(p.startswith(prefix) for prefix in prefixes) for p in changed),[p for p in changed if not any(p.startswith(prefix) for prefix in prefixes)]
subprocess.run(['git','add','-A','--',*prefixes],check=True)
log=scratch/'commit-startup-fixture-batch.log'
with log.open('w') as out:r=subprocess.run(['git','commit','-m','Fix diagnostic startup artifacts and offline fixture regressions'],stdout=out,stderr=subprocess.STDOUT)
print('COMMIT EXIT',r.returncode,'LOG',str(log));print('\n'.join(log.read_text().splitlines()[:12]));assert r.returncode==0
print('HEAD',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
print('STATUS',subprocess.check_output(['git','status','--short'],text=True))
