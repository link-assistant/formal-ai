from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/spoken-scheduling-paraphrases/after-refactor'
for name in ['validation-outcome.json','review.json']:
 p=base/name
 if p.exists():print(name,p.read_text())
r=subprocess.run(['ps','-eo','pid,ppid,stat,etime,args'],capture_output=True,text=True)
rows=[x for x in r.stdout.splitlines() if any(s in x for s in ['1986983','local-gates.mjs','sandboxes/gates','node --max-old-space-size=256']) and '/tmp/issue-1580-research/check-' not in x]
print('\n'.join(rows))
logs=sorted((root/'experiments/formal_ai_subagent/sandboxes/gates').glob('*.log'),key=lambda p:p.stat().st_mtime,reverse=True)
print('latestGateLogs',json.dumps([{'name':p.name,'bytes':p.stat().st_size} for p in logs[:5]]))
