from pathlib import Path
import gzip,hashlib,json,subprocess

head='9095abcbcccdd5518ce2c9318d3ebc6eb8914fc8'
base=Path('experiments/issue-1580/evidence/ci/executor-status-'+head[:8])
scratch=Path('/tmp/issue-1580-research/ci-logs/executor-status-'+head[:8]);scratch.mkdir(parents=True,exist_ok=True)
summary=json.loads((base/'latest-summary.json').read_text())
assert summary['head']==head
records=[]
for row in summary['nonPassingCompleted']:
    run=str(row['id']);prefix='run-'+run
    details=subprocess.check_output(['gh','run','view',run,'--repo','link-assistant/formal-ai','--json','headSha,status,conclusion,jobs'])
    jobs=json.loads(details)
    assert jobs['headSha']==head and jobs['status']=='completed'
    (scratch/(prefix+'-jobs.json')).write_bytes(details)
    log=scratch/(prefix+'.log')
    if not log.exists():
        with log.open('wb') as stream:
            result=subprocess.run(['gh','run','view',run,'--repo','link-assistant/formal-ai','--log'],stdout=stream,stderr=subprocess.PIPE)
        assert result.returncode==0,result.stderr.decode()
    archives=[]
    for path in [log,scratch/(prefix+'-jobs.json')]:
        raw=path.read_bytes();packed=gzip.compress(raw,mtime=0)
        archive=prefix+('-jobs.json.gz' if path.suffix=='.json' else '.log.gz')
        (base/archive).write_bytes(packed)
        archives.append({'archive':archive,'rawBytes':len(raw),'rawLines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
    records.append({'runId':row['id'],'workflow':row['name'],'head':head,'conclusion':jobs['conclusion'],'failedJobs':[{'id':job['databaseId'],'name':job['name'],'conclusion':job['conclusion']} for job in jobs['jobs'] if job['conclusion'] not in ['success','skipped']],'archives':archives,'logPath':str(log)})
(base/'failed-log-inventory.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
