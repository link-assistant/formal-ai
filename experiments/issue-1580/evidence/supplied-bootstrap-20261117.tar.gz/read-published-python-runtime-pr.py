from pathlib import Path
import subprocess,json,hashlib
def run(args):return subprocess.run(args,capture_output=True,text=True,check=True).stdout
value=json.loads(run(['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','title,body,isDraft,headRefOid,baseRefOid,url']))
Path('/tmp/issue-1580-research/pr-python-runtime-before.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({k:v for k,v in value.items() if k!='body'},indent=2))
prior=json.loads(Path('/tmp/issue-1580-research/pr-python-fragment-checkpoint-after.json').read_text())
print('PR body unchanged since prior edit:',value['body']==prior['body'])
lines=value['body'].splitlines();print('PR body lines',len(lines),'bytes',len(value['body'].encode()))
for i,line in enumerate(lines,1):
 if i==1 or any(w in line.lower() for w in ['python','624812120','under verification','verification','24 fully','29-case']):print(f'{i}: {line}')
recent=json.loads(run(['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','5','--json','databaseId,conclusion,status,createdAt,headSha,workflowName']))
print('Latest runs:');print(json.dumps(recent,indent=2))
