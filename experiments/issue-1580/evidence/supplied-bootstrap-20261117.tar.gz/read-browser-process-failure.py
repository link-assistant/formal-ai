import gzip
import pathlib
import subprocess

directory=pathlib.Path("experiments/issue-1580/evidence/checks/generated-header-memory")
print(gzip.decompress((directory/"browser-release.log.gz").read_bytes()).decode())
path=pathlib.Path("rust/tests/web/browser-engine-release-integration.test.mjs")
lines=path.read_text().splitlines()
print("FILE",path,"LINES",len(lines))
for number,line in enumerate(lines[:1500],1):print(str(number)+": "+line)
print("RELATED IMPLEMENTATIONS",flush=True)
subprocess.run(["rg","-n","timed-out exact descendant|function runWithBudget|export.*runWithBudget|function isAlive|real harmless Node processes","scripts","rust/tests/web","experiments/issue-1580"],check=True)
