from pathlib import Path
import json,subprocess

print('MEMORY',Path('/sys/fs/cgroup/memory.current').read_text().strip())
print('EVENTS',Path('/sys/fs/cgroup/memory.events').read_text())
print(subprocess.run(['ps','-o','pid,ppid,stat,etime,rss,args','--ppid','1229191','-p','1229191'],capture_output=True,text=True).stdout)
base=Path('experiments/issue-1580/evidence/checks/child-evidence-provenance')
path=base/'translation-writer-result.json'
print('TRANSLATION',path.read_text() if path.exists() else 'pending')
print('WORKER',Path('/tmp/issue-1580-research/child-evidence-translation-worker.log').read_text())
print(subprocess.run(['git','diff','--stat'],capture_output=True,text=True).stdout)
