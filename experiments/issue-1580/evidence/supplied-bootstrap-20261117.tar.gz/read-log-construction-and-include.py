from pathlib import Path
import subprocess
for name,needle,padding in [('js/server/structured-log.mjs','createServeLogger',95),('rust/src/agentic_coding/tool_result/source_observation.rs','CARGO_MANIFEST_DIR',8)]:
    rows=Path(name).read_text().splitlines()
    for pos,line in enumerate(rows):
        if needle in line:
            print('FILE',name,pos+1)
            for n in range(max(0,pos-5),min(len(rows),pos+padding)):print(f'{n+1}: {rows[n]}')
print('MIRROR',Path('scripts/mirror-package-data.mjs').read_text()[:4000])
