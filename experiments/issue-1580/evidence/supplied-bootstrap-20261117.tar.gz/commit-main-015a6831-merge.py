import gzip,json,re,subprocess
from pathlib import Path
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],text=True).strip()=='015a683197c89e8f74375b097e8dd06a57dcea8f'
subprocess.run(['git','add','--','docs/ci-cd/default-branch-builds.md','docs/case-studies/issue-1580/runtime-fixture-checkpoint.md','experiments/issue-1580/evidence/checks/main-merge-015a6831'],check=True)
check=subprocess.run(['git','diff','--cached','--check'],capture_output=True,text=True)
log=(check.stdout+check.stderr).encode()
base=Path('experiments/issue-1580/evidence/checks/main-merge-015a6831')
(base/'inherited-whitespace-check.log.gz').write_bytes(gzip.compress(log,mtime=0))
if check.returncode:
 inherited='dev/log/issues/1589/pulls/1597/sessions/ses_e16a6d957ffetAsRPYKj3hlITk/solve.log'
 diagnostics=[line for line in check.stdout.splitlines() if re.match(r'^.+:\d+: ',line)]
 assert diagnostics
 assert all(line.startswith(inherited+':') for line in diagnostics)
 assert subprocess.check_output(['git','show','MERGE_HEAD:'+inherited])==Path(inherited).read_bytes()
 print(json.dumps({'inheritedWhitespaceDiagnostics':len(diagnostics),'file':inherited,'bytesIdenticalToMain':True}))
branch_check=subprocess.run(['git','diff','--cached','--check','MERGE_HEAD'],capture_output=True,text=True)
(base/'branch-parent-whitespace-check.log.gz').write_bytes(gzip.compress((branch_check.stdout+branch_check.stderr).encode(),mtime=0))
if branch_check.returncode:
 inherited='dev/log/issues/1580/pulls/1581/sessions/ses_e1d024c95ffesDpv5Qnl5AKr9J/solve.log'
 diagnostics=[line for line in branch_check.stdout.splitlines() if re.match(r'^.+:\d+: ',line)]
 assert diagnostics and all(line.startswith(inherited+':') for line in diagnostics)
 assert subprocess.check_output(['git','show','HEAD:'+inherited])==Path(inherited).read_bytes()
 print(json.dumps({'branchParentWhitespaceDiagnostics':len(diagnostics),'file':inherited,'bytesIdenticalToPreMergeHead':True}))
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--',str(base)],check=True)
with Path('/tmp/issue-1580-research/main-015a6831-merge-commit.log').open('w') as stream:
 subprocess.run(['git','commit','-m','Merge main calendar and currency changes with reviewed PR checks'],stdout=stream,stderr=subprocess.STDOUT,check=True)
print(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'parents':subprocess.check_output(['git','show','-s','--format=%P','HEAD'],text=True).strip(),'workingTreeClean':not subprocess.check_output(['git','status','--porcelain'],text=True).strip()}))
