import json
import pathlib
import subprocess

p = pathlib.Path('data/benchmarks/fast-pull-request-javascript-tests.json')
lines = p.read_text().splitlines()
print(f'{p}: {len(lines)} lines')
for n, line in enumerate(lines, 1):
    print(f'{n}: {line}')
checks = ['rust/tests/web/page-formalization-route.test.mjs', 'rust/tests/web/rust-specification-generated-programs.test.mjs', 'rust/tests/web/issue-1172-factual-qa-subject-gate.test.mjs', 'rust/tests/web/issue-1328-bounded-retries.test.mjs']
inventory = json.loads(p.read_text())
for check in checks:
    print(json.dumps({'file': check, 'inInventory': check in inventory['files'], 'exists': pathlib.Path(check).exists()}))
for command in [
    ['rg', '-n', 'fast-pull-request-javascript-tests|production-profile|page-formalization-route', 'scripts', 'rust/tests/web/fast-pull-request-production-profile.test.mjs', 'CONTRIBUTING.md'],
    ['git', 'diff', '--', 'data/meta/main-only-regressions.lino'],
]:
    print('COMMAND', json.dumps(command))
    p = subprocess.run(command, capture_output=True, text=True)
    print(p.stdout)
