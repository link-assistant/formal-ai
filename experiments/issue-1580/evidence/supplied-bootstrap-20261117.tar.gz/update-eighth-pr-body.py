from pathlib import Path
import json
import subprocess

pr=json.loads(subprocess.check_output(['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','body,title,headRefOid,isDraft'],text=True))
Path('/tmp/issue-1580-research/pr-before-eighth-update.json').write_text(json.dumps(pr,indent=2)+'\n')
assert pr['headRefOid']=='078849576b539e0e6adf2843306af16981d5c09a'
assert pr['isDraft']
body=pr['body']
changes={
 'The latest batch retains opt-in cache backend diagnostics, completes the Go source comparison, and adds an executed stale-pin integrity regression against unchanged upstream code.':
 'The latest batch adds a real-Git reproduction of Java release tags published after a rejected release commit, with successful-release controls. It also records the complete active Java source review. Earlier batches retain opt-in cache diagnostics, the complete Go source comparison, and the executed stale-pin integrity regression.',
 'All 42 Go source blobs now have per-file semantic decisions; the seven other complete semantic reviews remain open.':
 'All 42 Go source blobs now have per-file semantic decisions. Java has 62 active files semantically reviewed and all 207 blobs hash-verified; 145 historical evidence files remain unreviewed. The seven other complete semantic reviews remain open.',
 'The maintained template suite passes eleven tests locally (no language-runtime skips);':
 'The maintained template suite passes sixteen tests locally (no language-runtime skips), including five Java release-integrity cases with real local Git repositories; the focused Java suite also passes all five cases. The four touched local gates and both archive-size gates pass;',
 'All 24 workflows on published head `09021cb30e` completed successfully. The new Go/cache batch at `e6627385d` is under verification.':
 'All 24 workflows on published heads `09021cb30e` and `e6627385d` completed successfully. The new Java review/regression batch at `078849576b` is under verification.',
 '[Java #30](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/30),':
 '[Java change detection #30](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/30), [Java failed release commits #31](https://github.com/link-foundation/java-ai-driven-development-pipeline-template/issues/31),',
}
for old,new in changes.items():
 assert body.count(old)==1, old
 body=body.replace(old,new)
assert body.startswith('Fixes #1580\n')
dest=Path('/tmp/issue-1580-research/pr-eighth-body.md')
dest.write_text(body)
subprocess.run(['gh','pr','edit','1581','--repo','link-assistant/formal-ai','--title','Fix CI result integrity, change detection, and candidate validation','--body-file',str(dest)],check=True)
print(body)
