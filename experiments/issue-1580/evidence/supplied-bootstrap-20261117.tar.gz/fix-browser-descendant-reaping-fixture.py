from pathlib import Path
path=Path("rust/tests/web/browser-engine-release-integration.test.mjs")
source=path.read_text()
old="""  const parent = 'require("node:child_process").spawn(process.execPath,["-e",' + JSON.stringify(child) + '],{stdio:"inherit"});setInterval(()=>{},100);';"""
new="""  // Reap the child after the process-group TERM. A container's PID 1 may
  // retain an orphan as a zombie indefinitely; kill(pid, 0) still succeeds
  // for that exited process. The parent does not signal the child itself,
  // so the unchanged ESRCH assertion still requires descendant teardown.
  const parent = 'const child=require("node:child_process").spawn(process.execPath,["-e",' + JSON.stringify(child) + '],{stdio:"inherit"});process.on("SIGTERM",()=>{});child.on("exit",()=>process.exit(0));setInterval(()=>{},100);';"""
assert source.count(old)==1
path.write_text(source.replace(old,new))
print("The test parent now reaps its child; the production deadline and exact ESRCH/permission assertions are unchanged.")
