from pathlib import Path
import json,subprocess
print('BRANCH',subprocess.check_output(['git','branch','--show-current'],text=True).strip())
print('HEAD',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
print(subprocess.check_output(['git','status','--short','--untracked-files=normal'],text=True))
for path in Path('.changes').glob('*1580*'):
    print('FRAGMENT',path);print(path.read_text())
base=Path('/tmp/issue-1580-research/shellcheck-user')
for name in ['outcome.json','worker.log','download.log','version.log','shell-gate.log']:
    path=base/name
    if path.exists():print('SHELLCHECK',name);print(path.read_text())
for name in ['CHANGELOG.d','changelog.d','changes']:
    folder=Path(name)
    if folder.exists():
        for path in folder.glob('*1580*'):
            print('FRAGMENT',path);print(path.read_text())
