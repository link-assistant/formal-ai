set -eu
cat docs/ci-cd/default-branch-builds.md
rg -n 'rust-script.*test|script.*unit|Rust.script|tier-changes|detect-code-changes' .github/workflows/layered-ci.yml rust/tests/web/default-branch-build-policy.test.mjs scripts/ci/default-branch-build-policy.mjs
