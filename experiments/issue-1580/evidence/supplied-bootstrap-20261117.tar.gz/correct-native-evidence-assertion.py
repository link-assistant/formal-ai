from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
out = root / 'experiments/issue-1580/evidence/checks/native-php-publication/assertion-correction'
out.mkdir(parents=True, exist_ok=True)
if (out / 'rustfmt.log.gz').exists():
    (out / 'rustfmt.log.gz').rename(out / 'rustfmt-default-edition-cli-error.log.gz')
target = root / 'rust/tests/unit/meta_executor_parity.rs'
old = '''.any(|link| link.starts_with("composition:evaluation:")
                    && link.ends_with(&evaluation)),'''
new = '''.any(|link| link.starts_with("composition:evaluation:")),'''
text = target.read_text()
assert text.count(old) == 1 or text.count(new) == 1
if old in text:
    target.write_text(text.replace(old, new))
results = []
for name, command in [
    ('rustfmt', ['rustfmt', '--edition', '2024', '--check', str(target)]),
    ('whitespace', ['git', 'diff', '--check', '--', str(target)]),
]:
    result = subprocess.run(command, cwd=root, capture_output=True)
    raw = result.stdout + result.stderr
    (out / (name + '.log.gz')).write_bytes(gzip.compress(raw, mtime=0))
    results.append({'name': name, 'command': command, 'exitCode': result.returncode,
                    'rawSha256': hashlib.sha256(raw).hexdigest()})
    print(name, result.returncode, raw.decode())
    assert result.returncode == 0
patch = subprocess.check_output(['git', 'diff', '--', str(target)], cwd=root)
(out / 'correction.patch.gz').write_bytes(gzip.compress(patch, mtime=0))
print(patch.decode())
subprocess.run(['git', 'add', '--', str(target)], cwd=root, check=True)
subprocess.run(['git', '-c', 'gc.auto=0', 'commit', '--only', '-m',
                'Match native evidence event IDs in remainder regression', '--', str(target)], cwd=root, check=True)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
report = {'head': head, 'observedAt': datetime.now(timezone.utc).isoformat(),
          'patchSha256': hashlib.sha256(patch).hexdigest(), 'checks': results,
          'reason': 'Native evidence links use event IDs; exact evaluated expression remains asserted in links_notation.',
          'nativeExecuted': False, 'independentAuthorshipCredit': 0}
(out / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
