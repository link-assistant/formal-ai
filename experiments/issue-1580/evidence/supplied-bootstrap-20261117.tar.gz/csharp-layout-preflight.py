from pathlib import Path
import json
import shutil
import subprocess

out=Path('/tmp/issue-1580-research/csharp-layout-context')
out.mkdir(exist_ok=True)
repo='link-foundation/csharp-ai-driven-development-pipeline-template'
def api(endpoint, is_list=True):
 args=['gh','api','repos/'+repo+'/'+endpoint]
 if is_list: args+=['--paginate','--slurp']
 data=json.loads(subprocess.check_output(args,text=True))
 return [r for page in data for r in page] if is_list else data
head=api('commits/main',False)
print('HEAD',head['sha'])
issues=api('issues?state=all&per_page=100')
(out/'issues.json').write_text(json.dumps(issues,indent=2)+'\n')
for r in issues:
 if 'pull_request' not in r:
  print(json.dumps({k:r[k] for k in ['number','title','state','html_url']}))
pulls=api('pulls?state=closed&sort=updated&direction=desc&per_page=100')
merged=[p for p in pulls if p['merged_at']]
(out/'pulls.json').write_text(json.dumps(pulls,indent=2)+'\n')
for p in merged[:5]:
 print('MERGED',json.dumps({k:p[k] for k in ['number','title','merged_at','html_url','body']}))
print('actionlint path',shutil.which('actionlint'))
print('cached candidates',[str(p) for p in Path('/tmp/issue-1580-research').glob('*actionlint*')])
print('primary production validators')
subprocess.run(['rg','-n',r'''local action|action reference|startsWith\(['"]\./|invalid.*uses|uses.*invalid''','scripts','experiments/formal_ai_subagent'],check=False)
