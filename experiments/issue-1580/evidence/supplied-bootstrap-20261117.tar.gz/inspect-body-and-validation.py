from pathlib import Path
import json
p=Path('experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md')
for i,line in enumerate(p.read_text().splitlines(),1):
 if any(t in line for t in ('113/254','7,760','114–254','Java','7f191','queued','pending')):print(f'{i}: {line}')
base=Path('experiments/issue-1580/evidence/checks/language-main-validation')
for f in sorted(base.glob('*.json')):
 if f.name in ('running.json','outcome.json','results.json'):
  v=json.loads(f.read_text());print(f.name,json.dumps(v)[:12000])
