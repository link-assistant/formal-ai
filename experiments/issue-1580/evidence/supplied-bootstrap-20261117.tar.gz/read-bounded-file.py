from pathlib import Path
import sys
p=Path(sys.argv[1]);a,b=map(int,sys.argv[2:4]);assert 0<=a-1<b and b-a<1500
lines=p.read_text().splitlines()
print(str(p),'TOTAL LINES',len(lines),'RANGE',a,b)
for i in range(a-1,min(b,len(lines))): print(str(i+1)+': '+lines[i])
