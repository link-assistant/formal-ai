from pathlib import Path
import json,subprocess,os,hashlib,datetime
b=Path('/tmp/issue-1580-research'); t=b/'templates'
out=b/'picomatch-template-research';out.mkdir(exist_ok=True)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=256'
rows=[]
for language,local,paths in [
 ('js','js-complete',['package-lock.json','examples/universal-app/package-lock.json']),
 ('python','python-complete',['.github/actions/artifact/package-lock.json']),
 ('cpp','cpp-complete',['package-lock.json']),
]:
 repo='link-foundation/'+{'js':'js','python':'python','cpp':'cpp'}[language]+'-ai-driven-development-pipeline-template'
 issuefile=out/(language+'-all-issues.json')
 cp=subprocess.run(['gh','api','repos/'+repo+'/issues?state=all&per_page=100','--paginate'],text=True,capture_output=True)
 assert cp.returncode==0,cp.stderr
 issuefile.write_text(cp.stdout)
 issues=json.loads(cp.stdout)
 relevant=[{'number':v['number'],'title':v['title'],'url':v['html_url'],'body':v.get('body')} for v in issues if any(q in (v['title']+'\n'+(v.get('body') or '')).lower() for q in ['picomatch','fc5q-39xc-vjpf','112366'])]
 print(repo,'issues inspected',len(issues),'matching reports',json.dumps(relevant),flush=True)
 for path in paths:
  p=t/local/path;data=p.read_bytes();lock=json.loads(data)
  packages={k:v for k,v in lock['packages'].items() if k.endswith('/picomatch')}
  sha=subprocess.run(['gh','api','repos/'+repo+'/contents/'+path,'--jq','.sha'],text=True,capture_output=True)
  assert sha.returncode==0,sha.stderr
  blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  current=sha.stdout.strip()==blob
  log=out/(language+'-'+('root' if path=='package-lock.json' else 'nested-'+p.parent.name)+'-audit.json')
  cp=subprocess.run(['npm','audit','--package-lock-only','--audit-level=moderate','--json'],cwd=p.parent,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  log.write_text(cp.stdout)
  audit=json.loads(cp.stdout)
  relevant_vulns={}
  for key,value in audit.get('vulnerabilities',{}).items():
   if key=='picomatch' or any(isinstance(x,dict) and 'fc5q-39xc-vjpf' in x.get('url','') for x in value.get('via',[])):
    relevant_vulns[key]=value
  row={'repository':repo,'path':path,'sha256':hashlib.sha256(data).hexdigest(),'gitBlob':blob,'latestBlob':sha.stdout.strip(),'matchesCurrentDefaultBranch':current,'picomatch':packages,'auditExitCode':cp.returncode,'auditRawSha256':hashlib.sha256(cp.stdout.encode()).hexdigest(),'metadata':audit.get('metadata'),'advisory':relevant_vulns}
  rows.append(row)
  print(json.dumps(row),flush=True)
(out/'summary.json').write_text(json.dumps({'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'locks':rows},indent=2)+'\n')
