from pathlib import Path
import gzip, hashlib, json, re

root=Path('/tmp/gh-issue-solver-1794900398048')
checks=root/'experiments/issue-1580/evidence/checks/unverified-child-status'
correction=json.loads((checks/'formatting-correction/outcome.json').read_text())
assert correction['complete'] and correction['nativeChangeLayoutOnly']
history=json.loads((checks/'java-history-79-92/review-summary.json').read_text())
assert history['literalPages']==92 and history['nextForwardPage']==93
report=json.loads((checks/'final-validation/validation-outcome.json').read_text())
gates=next(row for row in report['checks'] if row['name']=='all-local-gates')
checkpoint=root/'docs/case-studies/issue-1580/task-quotation-checkpoint.md'
addition=f'''

## Decoded-value hosted verification and further coverage studies

Published head `b26f5eebd3393b145c8693e985c8db24248380ad` passes all 23
hosted workflows after one failed-checkout-job retry. CI/CD run 44245879421
actually executes the native calendar/currency regression: 1/1 passes in
91.13 seconds. That run replays the previously observed grammar assertion;
it does not execute every shared native quotation or held-out grammar fixture.
The first Layered CI attempt fails during checkout with curl 28 before tests.
Its entire failed-job log is read and retained. The single retry keeps the
original checkout, test selection and time budgets. Its final summary records
1,430 passes, 13 skips and zero failures in 278.883 seconds. Retain the initial
and retry logs separately under `evidence/ci/decoded-grammar-b26f5eeb/`.
A successful retry does not identify the cause of the transfer stall.

Three additional finite VM studies retain the earlier rejected candidate:
parent coverage passes 5/9 qualification controls, initial seeded-cue masking
passes 6/10, and normalized seeded-cue masking passes 10/10. The last study
preserves the complete 25-case fixture outputs and event traces, plus two
non-passage structural controls. Each uses three modes for each request, no
actual or mocked transport calls, and pinned pre-status-repair source hashes.
All qualification output is literally read; every nested solver trace is not.
The concrete-output contract is a supplied mock, not end-to-end code generation.
The candidate remains outside production: adoption still retains obsolete root
evidence, and general coverage, aggregated provenance and native parity remain
unverified. The artifacts and complete supplied sources are under
`checks/passage-routing-probe/coverage-followup-qualification/`.

## Nonempty unverified drafts

A separate root cause appears in the actual child traces: the reasoner emits
`meta_reasoned_program_unverified` with nonempty content, while leaf admission
recognizes only the existing unresolved intents and two suffixes. The generic
`answered` check therefore accepts an unverified child and can complete its
all-required parent. The new focused regression fails before the policy repair
with `answered(meta_reasoned_program_unverified)=true` instead of false.

Add `_unverified` to the canonical unresolved suffix policy and regenerate its
embedded mirror. Existing answer/observation owners already classify unverified
program, workspace and plan outcomes as inconclusive or gaps. The emitted-intent
inventory distinguishes those outcomes from similarly named seed response keys.
The policy changes test admission; it grants no new root composition permission.

Four new cases exercise unverified derivation, an unverified required child,
an unverified cached draft and a verified positive control. Their complete traces
are literally read. The original 25-case fixture remains byte-identical,
including every event. Put the four cases in a separate shared fixture and load
both in JavaScript and native readers through the maintained fixture writer.
This preserves the unchanged 1,500-line limit after the first expanded fixture
fails both size gates at 1,577 lines. Retain that first failed validation and the
incorrect factual-QA test-path invocation; neither earns a passing verdict.

After splitting the fixtures, all 10 executor tests and all 15 adjacent
factual-QA tests pass in separate bounded runs. Both fixture currency checks
pass. The complete local inventory passes 86 executable gates with 52 explicit
native/CI-context exclusions and no failures in {gates['durationSeconds']:.3f} seconds.
The aggregate is literally read; compressed successful detail logs are preserved
with hashes, without a claim that each was literally reviewed. Retain the Rust
format-check failure, then apply the Rust 2024 formatter and pass its check.
That correction changes whitespace and one optional trailing argument comma; it does
not change the shared policy or either fixture. No local native build runs.
Native execution of the new status cases remains unverified.

The complete before/after receipts and failed attempts are under
`experiments/issue-1580/evidence/checks/unverified-child-status/`.
All earlier broad unfinished criteria remain open. Supplied scripts, code and
conclusions receive zero independent authorship credit; independent acceptance
stays 0/20. The PR stays draft and unmerged.
'''
assert '## Nonempty unverified drafts' not in checkpoint.read_text()
checkpoint.write_text(checkpoint.read_text()+addition)
plan=root/'experiments/issue-1580/work-plan.md'
text=plan.read_text()
text=text.replace('- [ ] Reproduce the separate status defect', '- [x] Reproduce the separate status defect')
text=text.replace('- [ ] Preserve the failing-before and passing-after checks;', '- [x] Preserve the failing-before and passing-after checks;')
text+='\n- [x] Preserve the first two size-gate failures and wrong-path invocation, split the four new status cases into a second shared fixture, then pass 25 focused tests and all 86 executable gates (52 explicit exclusions). Preserve and correct Rust formatting separately; original 25 fixture entries remain byte-identical. Native status execution and general parent coverage stay unfinished.\n'
plan.write_text(text)

old=root/'experiments/issue-1580/evidence/checks/decoded-grammar-values/pull-request-description.md'
body=old.read_text()
body=body.replace('Compound task parsing also splits conjunctions inside ASCII quotations.', 'Compound task parsing also splits conjunctions inside ASCII quotations and accepts nonempty unverified drafts as completed children.')
body=body.replace('Changes:\n\n', 'Changes:\n\n- Keep nonempty `_unverified` answers unresolved in leaf admission, including cached drafts and all-required parents. Preserve verified answers and the original 25 fixture cases byte-for-byte; add four status controls in a second shared JavaScript/native fixture.\n')
body=body.replace('All **23 hosted workflows pass on current head `b26f5eeb`**', 'All **23 hosted workflows pass on published input `b26f5eeb`**')
body=body.replace('Latest reproduction and verification:\n\n', 'Latest reproduction and verification:\n\n- Before the status repair, `answerValidation(\'meta_reasoned_program_unverified\', \'A nonempty draft\')` incorrectly reports `answered(meta_reasoned_program_unverified)=true`. The new regression fails before the shared-policy change. Afterward, **10 executor tests**, **15 adjacent factual-QA tests**, both shared-fixture currency checks, Rust 2024 formatting and the **86 executable local gates** pass; **52 explicit native/CI-context exclusions** remain. The original 25 cases and every trace remain byte-identical; four separate controls cover derivation, required children, cache and verified answers. Preserve the initial size/path failures and formatting failure. Hosted CI for this new repair remains pending publication.\n')
needle='- Reject the supplied single-passage context candidate:'
start=body.index(needle)
end=body.index('\n',start)
body=body[:start]+'- Retain separate finite VM context studies: the original candidate passes **4/8**, parent coverage **5/9**, initial seeded cues **6/10**, and normalized seeded cues **10/10** qualification controls. The last preserves all 25 fixture outputs and complete event traces plus two structural controls, with zero transport calls. These are pinned pre-status-repair experiments, with a mock concrete-output contract; no production adoption or native execution follows. Aggregated provenance and general parent coverage remain open.'+body[end:]
start=body.index('Java historical literal review covers ')
body=body[:start]+f"Java historical literal review covers **92/254 continuous pages**, {history['completeFiles']} complete files, {history['partialFiles']} partial file and {history['literalLines']:,} literally reviewed source lines; pages 93–254 remain unread. Full semantic applicability for all templates remains unfinished. Source reading, upstream reports and skipped native jobs do not establish acceptance. Independent Formal AI reasoning acceptance remains **0/20**; supplied commands, patches, scripts and conclusions receive zero independent authorship credit.\n"
(checks/'pull-request-description.md').write_text(body)

retry=root/'experiments/issue-1580/evidence/ci/decoded-grammar-b26f5eeb/checkout-retry-attempt-2/receipt.json'
receipt=json.loads(retry.read_text())
receipt['literalReview']={'wholeJobLogLiterallyRead':False,'reviewedRanges':[[2650,2805]],'summaryPass':1430,'summarySkip':13,'summaryFail':0,'summaryDurationMilliseconds':278883.266705}
retry.write_text(json.dumps(receipt,indent=2)+'\n')

inventory=[]
for relative in ['js/worker/formal_ai_worker_meta_composite.js','js/worker/formal_ai_worker_meta_reasoner.js','js/agentic/crate/engine_answer.mjs','js/agentic/evidence_record/record_observation.mjs','js/agentic/code_task.mjs','js/agentic/code_task/target_guard.mjs','js/agentic/general_execution.mjs','data/seed/text-formalization.lino']:
    source=root/relative
    raw=source.read_bytes()
    selected=[{'line':number,'text':line} for number,line in enumerate(raw.decode().splitlines(),1) if '_unverified' in line]
    inventory.append({'path':relative,'sha256':hashlib.sha256(raw).hexdigest(),'matchingLines':selected})
(checks/'unverified-intent-inventory.json').write_text(json.dumps({'sources':inventory,'scope':'Targeted emitted-intent and existing admission-classification inspection; response-key names alone are not emitted intents.','independentAuthorshipCredit':0},indent=2)+'\n')
print(json.dumps({'checkpointLines':len(checkpoint.read_text().splitlines()),'descriptionSha256':hashlib.sha256(body.encode()).hexdigest(),'javaReviewPages':92,'allLocalGateSeconds':gates['durationSeconds'],'nativeStatusExecutionClaimed':False,'independentAuthorshipCredit':0}))
