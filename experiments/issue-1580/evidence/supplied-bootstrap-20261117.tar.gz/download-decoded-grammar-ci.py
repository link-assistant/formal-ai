from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess

base = Path('experiments/issue-1580/evidence/ci/decoded-grammar-b26f5eeb')
summary = json.loads((base / 'latest-summary.json').read_text())
assert summary['head'] == 'b26f5eebd3393b145c8693e985c8db24248380ad'
assert not summary['active']
target = base / ('log-download-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
target.mkdir()
(base / 'latest-log-directory.txt').write_text(str(target) + '\n')
receipts = []
try:
    for run_id in [44245878901, 44245879421]:
        metadata_raw = subprocess.check_output(['gh', 'api', f'repos/link-assistant/formal-ai/actions/runs/{run_id}'])
        metadata = json.loads(metadata_raw)
        assert metadata['head_sha'] == summary['head'] and metadata['status'] == 'completed'
        (target / f'{run_id}-metadata.json.gz').write_bytes(gzip.compress(metadata_raw, mtime=0))
        job_raw = subprocess.check_output(['gh', 'api', f'repos/link-assistant/formal-ai/actions/runs/{run_id}/jobs?per_page=100', '--paginate', '--slurp'])
        jobs = [job for page in json.loads(job_raw) for job in page['jobs']]
        (target / f'{run_id}-jobs.json.gz').write_bytes(gzip.compress(json.dumps(jobs, indent=2).encode(), mtime=0))
        failed = [job for job in jobs if job['conclusion'] not in ['success', 'skipped', 'neutral']]
        selected = failed if failed else [job for job in jobs if 'native' in job['name'].lower()]
        assert selected
        downloads = []
        for job in ([None] if failed else []) + selected:
            name = str(run_id) + ('-workflow.log' if job is None else '-job-' + str(job['id']) + '.log')
            args = ['gh', 'run', 'view', str(run_id), '--repo', 'link-assistant/formal-ai', '--log']
            if job is not None:
                args.extend(['--job', str(job['id'])])
            with (target / name).open('wb') as output, (target / (name + '.stderr')).open('wb') as errors:
                result = subprocess.run(args, stdout=output, stderr=errors)
            raw = (target / name).read_bytes()
            packed = gzip.compress(raw, mtime=0)
            assert gzip.decompress(packed) == raw
            (target / (name + '.gz')).write_bytes(packed)
            (target / name).unlink()
            downloads.append({'file': name + '.gz', 'exitCode': result.returncode, 'bytes': len(raw), 'lines': len(raw.splitlines()), 'sha256': hashlib.sha256(raw).hexdigest()})
            assert result.returncode == 0, (name, result.returncode)
        receipts.append({'run': run_id, 'workflow': metadata['name'], 'head': metadata['head_sha'], 'createdAt': metadata['created_at'], 'completedAt': metadata['updated_at'], 'conclusion': metadata['conclusion'], 'selectedJobs': [{'id': job['id'], 'name': job['name'], 'conclusion': job['conclusion'], 'failedSteps': [step for step in job.get('steps', []) if step['conclusion'] == 'failure']} for job in selected], 'downloads': downloads})
    report = {'complete': True, 'head': summary['head'], 'receipts': receipts, 'allLogsLiterallyRead': False}
except BaseException as error:
    report = {'complete': False, 'head': summary['head'], 'receipts': receipts, 'error': repr(error), 'allLogsLiterallyRead': False}
    raise
finally:
    (target / 'manifest.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'directory': str(target), **report}, indent=2), flush=True)
