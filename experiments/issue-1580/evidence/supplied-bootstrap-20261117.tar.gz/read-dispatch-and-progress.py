from pathlib import Path
import json,subprocess
for name,start,end in [('.github/workflows/ci.yml',1,155),('experiments/issue-1580/work-plan.md',1,70),('/tmp/issue-1580-research/picomatch-pr-description.md',1,115)]:
    file=Path(name)
    if not file.exists():continue
    rows=file.read_text().splitlines();print('FILE',name,'LINES',len(rows))
    for n in range(start,min(end,len(rows))+1):print(f'{n}: {rows[n-1]}')
path=Path('experiments/issue-1580/evidence/checks/main-merge-444575f2/all-local-gates.json')
if path.exists():
    data=json.loads(path.read_text());print('GATE RESULT',json.dumps({k:v for k,v in data.items() if k!='gateLogs'}))
else:print('GATE TAIL',Path('/tmp/issue-1580-research/merged-444575f2-all-local-gates.log').read_text()[-1000:])
