from pathlib import Path
import datetime
import json
import os
import stat

root=Path.cwd()
directory=root/"experiments/issue-1580/evidence/checks/generated-header-memory"
cgroup=Path("/sys/fs/cgroup")
def memory():
    stats=dict(line.split() for line in (cgroup/"memory.stat").read_text().splitlines())
    limit=int((cgroup/"memory.max").read_text());current=int((cgroup/"memory.current").read_text())
    return {"limit":limit,"current":current,"available":limit-current,"anon":int(stats["anon"]),"file":int(stats["file"]),"fileDirty":int(stats["file_dirty"])}
assert hasattr(os,"posix_fadvise") and hasattr(os,"POSIX_FADV_DONTNEED")
before=memory()
count=0;size=0
for base in [root/"experiments",root/"dev/log",root/"docs/case-studies",Path("/tmp/issue-1580-research")]:
    for parent,folders,files in os.walk(base,followlinks=False):
        folders[:]=[name for name in folders if name not in {".git","node_modules","target","__pycache__"}]
        for name in files:
            path=Path(parent)/name
            info=path.lstat()
            if not stat.S_ISREG(info.st_mode) or info.st_size<1024*1024:continue
            descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
            try:os.posix_fadvise(descriptor,0,0,os.POSIX_FADV_DONTNEED)
            finally:os.close(descriptor)
            count+=1;size+=info.st_size
after=memory()
record={"observedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"action":"POSIX_FADV_DONTNEED on clean regular files over 1 MiB in task workspace evidence/research directories","before":before,"after":after,"filesAdvised":count,"fileBytesAdvised":size,"fileContentsChanged":False,"globalCachesChanged":False,"independentAuthorshipCredit":0}
(directory/"clean-file-cache.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record))
