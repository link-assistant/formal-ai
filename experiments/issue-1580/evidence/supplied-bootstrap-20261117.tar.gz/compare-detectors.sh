set -eu
for language in js csharp java go; do
  printf '\n%s\n' "$language"
  cat "/tmp/issue-1580-research/templates/$language-complete/scripts/detect-code-changes.mjs"
done
rg -n -A 7 'detect-changes:|detect-code-changes:|workflow_dispatch|pipeline-status:' /tmp/issue-1580-research/templates/{js,rust,python,php,csharp,java,cpp,go}-complete/.github/workflows/release.yml > /tmp/issue-1580-research/template-detection-context.txt
