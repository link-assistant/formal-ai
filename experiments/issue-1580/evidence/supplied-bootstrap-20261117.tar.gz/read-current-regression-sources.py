from pathlib import Path
import subprocess
paths=['rust/tests/web/issue-1168-workflow-render-parity.test.mjs','rust/tests/web/issue-1168-source-cache.test.mjs','rust/tests/web/recipe-resume-policy-notation.test.mjs']
for name in paths:
    print('FILE',name)
    print(Path(name).read_text())
for phrase in ['serve-','create_dir_all','File::create']:
    r=subprocess.run(['rg','-n',phrase,'rust/src/diagnostics'],capture_output=True,text=True)
    print('SEARCH',phrase,r.stdout[:6000])
