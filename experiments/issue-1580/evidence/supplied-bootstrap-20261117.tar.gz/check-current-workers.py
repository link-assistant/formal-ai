import pathlib

for folder in (
    pathlib.Path('/tmp/issue-1580-research/algebra-calculation-cues-validation'),
    pathlib.Path('/tmp/issue-1580-research/ci-logs/quoted-cues-7152daeb'),
):
    print('DIRECTORY', folder)
    if not folder.exists():
        print('missing')
        continue
    print('FILES', [p.name for p in folder.iterdir()])
    for name in ('worker.log', 'collector.log', 'outcome.json'):
        path = folder / name
        if path.exists():
            print('FILE', path)
            print(path.read_text()[-18000:])
