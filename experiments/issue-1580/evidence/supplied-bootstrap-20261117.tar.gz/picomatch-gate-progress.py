from pathlib import Path
import json,subprocess
b=Path('/tmp/issue-1580-research')
p=b/'picomatch-validation-supervisor.log'
print(p.read_text())
p=b/'picomatch-validation-complete-local-gates.log'
if p.exists():
 lines=p.read_text().splitlines()
 print('aggregate lines',len(lines))
 print('\n'.join(lines[-30:]))
r=Path('/tmp/gh-issue-solver-1794900398048')
cp=subprocess.run(['rg','-n','ls-files|untracked|others','experiments/formal_ai_subagent/local-gates.mjs','scripts/check-file-size.mjs','scripts/lib/checks-rust-compat.mjs'],cwd=r,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
print(cp.stdout)
for name in ['/sys/fs/cgroup/memory.current','/sys/fs/cgroup/memory.events']:
 p=Path(name)
 if p.exists():print(name,p.read_text())
