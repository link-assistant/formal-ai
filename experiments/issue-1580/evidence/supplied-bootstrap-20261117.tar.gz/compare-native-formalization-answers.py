from pathlib import Path
import difflib,gzip,hashlib,json,re
root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/ci/main-015a6831'
path=base/'individual-native-failed-jobs/job-134419506408.log.gz'
lines=gzip.decompress(path.read_bytes()).decode().splitlines()
def fields(value):
 assert value.startswith('SymbolicAnswer { ') and value.endswith(' }')
 value=value[len('SymbolicAnswer { '):-2]
 parts=[];start=0;depth=0;quoted=False;escape=False
 for i,char in enumerate(value):
  if quoted:
   if escape:escape=False
   elif char=='\\':escape=True
   elif char=='"':quoted=False
   continue
  if char=='"':quoted=True
  elif char in '{[(':depth+=1
  elif char in '}])':depth-=1
  elif char==',' and depth==0:parts.append(value[start:i].strip());start=i+1
 assert depth==0 and not quoted
 parts.append(value[start:].strip())
 result={}
 for item in parts:
  key,raw=item.split(': ',1);assert key not in result;result[key]=raw
 return result
left=fields(lines[3077].split('  left: ',1)[1])
right=fields(lines[3078].split(' right: ',1)[1])
assert left.keys()==right.keys()
records=[]
for key in left:
 a,b=left[key],right[key]
 record={'field':key,'equal':a==b,'leftBytes':len(a.encode()),'rightBytes':len(b.encode()),'leftSha256':hashlib.sha256(a.encode()).hexdigest(),'rightSha256':hashlib.sha256(b.encode()).hexdigest()}
 print(json.dumps(record))
 if a!=b:
  if a.startswith('"') and b.startswith('"'):
   def decode(raw):return json.loads(re.sub(r'\\u\{([0-9a-fA-F]+)\}',lambda m:chr(int(m[1],16)),raw))
   before,after=decode(a),decode(b)
   diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='first.'+key,tofile='second.'+key))
   target=base/('formalization-'+key.replace('_','-')+'.diff.gz');target.write_bytes(gzip.compress(diff.encode(),mtime=0))
   record['decodedDifferenceLines']=len(diff.splitlines());record['decodedDifferenceArtifact']=str(target.relative_to(root))
   print('DECODED DIFF FULL' if len(diff)<16000 else 'DECODED DIFF PREFIX',key)
   print(diff[:16000])
  else:
   prefix=0
   while prefix<min(len(a),len(b)) and a[prefix]==b[prefix]:prefix+=1
   suffix=0
   while suffix<min(len(a),len(b))-prefix and a[-suffix-1]==b[-suffix-1]:suffix+=1
   print('FIRST DIFFERENCE',prefix,'LEFT',a[max(0,prefix-200):prefix+1800],'RIGHT',b[max(0,prefix-200):prefix+1800])
   record.update({'commonPrefixChars':prefix,'commonSuffixChars':suffix,'nonStringFieldFullReviewComplete':False})
 records.append(record)
(base/'formalization-answer-comparison.json').write_text(json.dumps({'source':str(path.relative_to(root)),'leftLine':3078,'rightLine':3079,'fields':records,'fullLiteralReviewComplete':False,'nativeBehaviorVerified':False},indent=2)+'\n')
