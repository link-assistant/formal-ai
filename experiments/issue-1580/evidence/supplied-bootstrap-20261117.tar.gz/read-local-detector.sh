set -eu
wc -l scripts/detect-code-changes.rs
sed -n '165,390p' scripts/detect-code-changes.rs
rg -n '\bexec\(|get_changed_files|is_merge_commit|fn main|fn .*test|fn .*git' scripts/detect-code-changes.rs
cat rust/tests/web/rust-audit.test.mjs
cat /tmp/issue-1580-research/templates/php-complete/scripts/src/ChangeDetector.php
cat /tmp/issue-1580-research/templates/php-complete/scripts/bootstrap.php
