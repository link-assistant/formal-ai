from pathlib import Path
import subprocess,json,hashlib
r=Path('/tmp/gh-issue-solver-1794900398048')
assert subprocess.check_output(['git','branch','--show-current'],cwd=r,text=True).strip()=='issue-1580-8d61a32a61e1'
out=r/'experiments/issue-1580/evidence/checks/scheduling-native-replay'
x=json.loads((out/'admission-review.json').read_text())
for row in x['unchangedSourceFiles']:
 assert hashlib.sha256((r/row['path']).read_bytes()).hexdigest()==row['sha256']
files=['.github/workflows/native-type-check.yml','rust/Cargo.toml','rust/tests/unit/scheduling_contracts.rs','rust/tests/web/default-branch-build-policy.test.mjs','scripts/ci-pull-request-admission.mjs','changelog.d/issue-1580-scheduling-native-replay.md','experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8']
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=r,text=True).strip()
subprocess.run(['git','add','--',*files],cwd=r,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=r,check=True)
subprocess.run(['git','-c','gc.auto=0','commit','-m','test: replay original scheduling contracts before merge'],cwd=r,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
print('SOURCE COMMIT',head)
p=Path('/tmp/issue-1580-research')
s=(p/'validate-data-file-native-replay.py').read_text()
s=s.replace('data-file-native-validation','scheduling-native-validation').replace("assert head=='d43bc0386409bb16535451d33dbb1af5e5e83888'",'assert head=='+repr(head)).replace('4d105df788a398c6c26a9431393622bb4206dbfe','0f8c178ca9c4a2c6fd9bf07e67a2babd450436bb')
s=s.replace("run('whitespace'", "run('rustfmt',['rustfmt','--edition','2024','--check','rust/tests/unit/scheduling_contracts.rs'])\n  run('whitespace'")
target=p/'validate-scheduling-native-replay.py';assert not target.exists();target.write_text(s)
subprocess.run(['python3',str(target)],cwd=r,check=True)
