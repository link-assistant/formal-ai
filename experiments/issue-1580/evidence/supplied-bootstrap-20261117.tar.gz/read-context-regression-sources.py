import pathlib

paths = [('data/meta/request-context.json', 1, 1500), ('rust/src/protocol/request_context.rs', 1, 280), ('rust/src/protocol/request_context.rs', 281, 600), ('rust/tests/web/issue-1587-request-context.test.mjs', 1, 1500)]
for name, first, last in paths:
    lines = pathlib.Path(name).read_text().splitlines()
    print(f'FILE {name} {first}-{min(last, len(lines))}')
    for n in range(first - 1, min(last, len(lines))):
        print(f'{n + 1}: {lines[n]}')
