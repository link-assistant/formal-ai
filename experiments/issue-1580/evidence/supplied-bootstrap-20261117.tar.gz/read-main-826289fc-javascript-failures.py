from pathlib import Path
import re

path=Path('/tmp/issue-1580-research/layered-44157124124.log')
lines=path.read_text().splitlines()
for number,line in enumerate(lines,1):
    if 'test at ' in line:print('FAILED_SOURCE',number,line)
for start,end in [(21034,21052),(25945,25984),(34295,34400)]:
    print('LOG_RANGE',start,end)
    for index in range(start-1,min(end,len(lines))):print(f'{index+1}: {lines[index]}')
