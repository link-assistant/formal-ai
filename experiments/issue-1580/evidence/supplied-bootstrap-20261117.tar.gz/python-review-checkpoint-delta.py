from pathlib import Path
import json
inventory=json.loads(Path('/tmp/issue-1580-research/python-active-source-inventory.json').read_text())
prior=json.loads(Path('docs/case-studies/issue-1580/templates/python-partial-semantic-review.json').read_text())
previous={r['path']:r for r in prior['files']}
deferred={'.github/actions/artifact/dist/835.index.mjs','.github/actions/artifact/dist/index.mjs','.github/actions/artifact/package-lock.json','uv.lock'}
offset=0
for row in inventory['active']:
 if row['path'] in deferred:continue
 read=max(0,min(row['lines'],6800-offset));offset+=row['lines']
 old=previous[row['path']]['readRanges'];old_read=sum(b-a+1 for a,b in old)
 if read>old_read:print(row['path'],f'{old_read+1}-{read}/{row["lines"]}')
