from pathlib import Path

template = Path('docs/case-studies/issue-1580/templates/README.md')
with template.open('a') as handle:
    handle.write('''
## Java active source review and failed-commit regression

[`java-active-semantic-review.json`](java-active-semantic-review.json) records per-file decisions for all 62 active Java CI/application/configuration/documentation files, including four workflows and the entire 1872-line POM. All 207 tree blobs are hash verified. The 145 `dev/log` historical reports, registry/API responses, logs and earlier source snapshots remain inventoried with their identities; their full semantic contents are explicitly unreviewed. This active source review does not complete the Java repository review or the seven outstanding complete semantic reviews.

The new five-case Java release regression executes the unchanged pinned `version-and-commit.mjs` and its local helpers against real temporary Git repositories and disposable local bare remotes. A pre-commit hook rejecting the release commit still yields exit 0 and `released=true`, and pushes `v1.2.4` pointing at the old `1.2.3` source. Both changeset and instant modes reproduce it. Removing only the commit-error fallback in a disposable copy stops before tag creation/publication; four successful-release controls preserve the updated version in the local remote. The maintained fast-PR entrypoint now passes sixteen tests with no skips. This is local Git execution, not a hosted release or an upstream repair. Formal AI already exits on a failed release commit and tags only after pushing the release source successfully; those checks are retained.

Java #29 already covers its missing aggregate status and #28 its CRLF wrapper checkout. Its manual lint skip and version-writer parent/comment mismatch remain labeled source observations, without an executed claim. The new failed-commit report draft is retained in `experiments/issue-1580/upstream/` pending publication of immutable executable evidence. Full regression logs and hashes are indexed in `experiments/issue-1580/evidence/checks/java-release-integrity.json`.
''')
case = Path('docs/case-studies/issue-1580/README.md')
with case.open('a') as handle:
    handle.write('''
### Java release commit integrity

The active Java source review now covers 62 files and all four workflows, with per-file transfer decisions. Its 145 historical evidence blobs are inventoried but not fully semantically reviewed, so the complete Java and other remaining repository reviews stay open. Five new bounded regressions use actual local Git and bare remotes: a rejected release commit still produces success and publishes an old-source tag in both Java release modes. Removing only the failure fallback in a disposable copy blocks publication, and successful-release controls retain the correct source/version. The maintained PR entrypoint passes 16 tests without skips. Formal AI already checks the release commit before pushing/tagging; no unnecessary duplicate release implementation is added. No hosted Java execution, upstream fix, main-only native execution or broader issue completion is claimed. Full logs/hashes are in `checks/java-release-integrity.json`.
''')
plan = Path('experiments/issue-1580/work-plan.md')
with plan.open('a') as handle:
    handle.write('''
## Java active review and release integrity (2026-11-17)

All 62 active Java source/configuration/documentation files are reviewed, including the entire POM and four workflows; 145 historical evidence blobs remain inventoried only. The complete Java repository review stays open. Real local Git reproduces a rejected release commit followed by successful publication of a tag on the old version in both modes. The disposable one-line repair propagates commit failure, while successful controls retain correct versions. New regression: 5 pass; maintained entrypoint: 16 pass; no skips. Formal AI's existing fail-on-commit-error and push-before-tag behavior is retained. Draft the distinct upstream report, publish immutable executable evidence before filing, and keep all other acceptance criteria active.
''')
report = Path('experiments/issue-1580/upstream/java-release-commit-integrity-report.md')
report.write_text('''The release helper suppresses a failed `git commit`, creates a new version tag on the previous commit, pushes that tag and reports `released=true`. This affects both changeset and instant release modes.

Source reviewed: `dd803a2d9fa5b3a992b435acce73162274fb9e8b`, `scripts/version-and-commit.mjs` (Git blob `0f6812d46591f3f6615f52d834f8c42f965662fc`). The source uses `git commit -m "${commitMessage}" || echo "Nothing to commit"`, so any commit failure is converted to shell success before unconditional tag/push steps. Related merged PR #13 adds interrupted-release recovery and successful-release controls; latest #25/#26 update dependencies and do not remove this fallback. Existing #12 concerns recovery after a successful tag push, a different boundary.

Bounded offline reproduction:

1. Initialize a temporary checkout with POM and Java source version `1.2.3`, a valid patch changeset, and a disposable local bare remote. Push the baseline locally.
2. Install a local pre-commit hook that exits 23, then run the unchanged helper with `--mode changeset`, or with `--mode instant --bump-type patch`.
3. Both invocations exit 0 and write `released=true`. The working POM changes to `1.2.4`, but no release commit exists. The new `v1.2.4` tag is pushed to the local bare remote and its POM still says `1.2.3`.

Removing only `|| echo "Nothing to commit"` in a disposable source copy makes both modes exit 1 without creating or publishing the tag. Successful commits in both original and candidate sources still push an updated `1.2.4` tag. These four positive controls distinguish the error-propagation repair from disabling releases.

The executable reproduction is `experiments/issue-1580/template-java-release-integrity.test.mjs` in link-assistant/formal-ai PR #1581. It preserves the original license and verifies copied Git blob/SHA256 identities. Run `node --test --test-concurrency=1 experiments/issue-1580/template-java-release-integrity.test.mjs`: five cases pass. The maintained fast-PR entrypoint passes sixteen cases without skips. Full logs/hashes are in `experiments/issue-1580/evidence/checks/java-release-integrity.json`.

Every Git push in this reproduction targets a disposable local bare repository. No Maven build, external network, hosted workflow, GitHub API call or remote template modification is performed. The candidate repair is tested only in disposable copies; no upstream fix is claimed. Publish this evidence before filing the report.
''')
print('Documented active review scope, reproduced commit failure and pending upstream report')
