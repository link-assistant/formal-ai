sed -n '1,280p' scripts/run-prebuilt-tests.sh
rg -n 'RECORD_TEST_TIMES|duration|test-threads|elapsed|spawn|runTests|result' scripts/lib/test-cache-isolation.mjs scripts/collect-test-durations.rs .github/workflows/release.yml
sed -n '1,170p' experiments/issue-1580/compare-template-trees.mjs
