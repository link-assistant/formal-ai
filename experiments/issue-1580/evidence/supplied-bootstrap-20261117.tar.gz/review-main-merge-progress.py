from pathlib import Path
import gzip,json
directory=Path("experiments/issue-1580/evidence/checks/main-merge-512ce428")
for name in ["focused-completion","all-local-gates"]:
    p=directory/(name+".json")
    if p.exists():
        record=json.loads(p.read_text())
        print(name,json.dumps({key:value for key,value in record.items() if key not in {"perGateLogs","checks"}}))
        for row in record.get("checks",[]):print(json.dumps(row))
        if record["status"]:
            for row in record.get("checks",[]):
                if row["status"]:
                    lines=gzip.decompress((directory/row["log"]).read_bytes()).decode(errors="replace").splitlines()
                    print(row["log"],"total lines",len(lines))
                    for n,line in enumerate(lines[:200],1):print(f"{n}: {line}")
        if "log" in record:
            lines=gzip.decompress((directory/record["log"]).read_bytes()).decode(errors="replace").splitlines()
            print("Full gate log total lines",len(lines))
            for n,line in enumerate(lines[-15:],max(1,len(lines)-14)):print(f"{n}: {line}")
    else:
        print(name,"not complete")
        for suffix in [".log","-bootstrap.log"]:
            p=directory/(name.replace("-completion","")+suffix)
            if p.exists():
                for line in p.read_text(errors="replace").splitlines()[-8:]:print(line)
