from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/ci/algebra-acb9fa51/queue-observation'
base.mkdir(exist_ok=True)
commands = [
    ('recent-runs', ['gh', 'run', 'list', '--repo', 'link-assistant/formal-ai', '--branch', 'issue-1580-8d61a32a61e1', '--limit', '5', '--json', 'databaseId,status,conclusion,createdAt,headSha,workflowName']),
    ('pipeline-jobs', ['gh', 'api', 'repos/link-assistant/formal-ai/actions/runs/44295294921/jobs?per_page=100', '--paginate', '--slurp']),
    ('security-jobs', ['gh', 'api', 'repos/link-assistant/formal-ai/actions/runs/44295294376/jobs?per_page=100', '--paginate', '--slurp']),
]
records = []
for name, argv in commands:
    result = subprocess.run(argv, cwd=root, capture_output=True)
    raw = result.stdout + result.stderr
    (base / (name + '.json.gz')).write_bytes(gzip.compress(raw, mtime=0))
    records.append({'name': name, 'exitCode': result.returncode, 'rawSha256': hashlib.sha256(raw).hexdigest()})
    assert result.returncode == 0, result.stderr.decode()
    data = json.loads(result.stdout)
    print(name)
    if name == 'recent-runs':
        for row in data:
            print(json.dumps(row))
    else:
        jobs = [job for page in data for job in page['jobs']]
        for job in jobs:
            print(json.dumps({key: job.get(key) for key in ['id', 'name', 'status', 'conclusion', 'labels', 'created_at', 'started_at', 'runner_name']}))
        print('jobs:', len(jobs))
(base / 'summary.json').write_text(json.dumps({'observedAt': datetime.now(timezone.utc).isoformat(), 'records': records, 'nativeExecutionClaimed': False}, indent=2) + '\n')
