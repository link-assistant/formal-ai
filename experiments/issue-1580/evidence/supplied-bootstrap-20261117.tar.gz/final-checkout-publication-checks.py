from pathlib import Path
import datetime,gzip,hashlib,json,os,subprocess,time,sys
root=Path('/tmp/gh-issue-solver-1794900398048')
corrected='--after-format' in sys.argv
out=root/('experiments/issue-1580/evidence/checks/fast-source-archive-checkout/publication-after-format' if corrected else 'experiments/issue-1580/evidence/checks/fast-source-archive-checkout/publication-checks')
out.mkdir(exist_ok=False)
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=256'
rows=[]
commands=[(gate,['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]) for gate in ['check-ci-speed','check-abbreviations','check-file-size','check-file-size-js-twin','check-changelog-fragment-js-twin','check-reconstructed-changelog','evidence-check#1']]
commands += [('runner-labels',['node','--max-old-space-size=256','scripts/check-runner-labels.mjs']),('deployed-projection',['node','--max-old-space-size=256','scripts/generate-staged-release.mjs','--check-deployed']),('source-profile',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs']),('diff-whitespace',['git','diff','--check'])]
if corrected:
 commands=[row for row in commands if row[0] in {'check-abbreviations','check-file-size','check-file-size-js-twin','deployed-projection','source-profile','diff-whitespace'}]
 commands.append(('stage-transition',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/staged-release-activation-transition.test.mjs']))
for name,argv in commands:
 process_env=env.copy()
 if name=='stage-transition':process_env.pop('NODE_OPTIONS',None)
 start=time.monotonic();r=subprocess.run(argv,cwd=root,env=process_env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);raw=r.stdout
 (out/(name+'.log.gz')).write_bytes(gzip.compress(raw,mtime=0))
 row={'name':name,'argv':argv,'exitCode':r.returncode,'seconds':round(time.monotonic()-start,3),'rawSha256':hashlib.sha256(raw).hexdigest(),'rawBytes':len(raw),'rawLines':len(raw.splitlines())}
 rows.append(row);print(json.dumps(row),flush=True)
 if argv[2:3]==['experiments/formal_ai_subagent/local-gates.mjs']:
  detail=root/('experiments/formal_ai_subagent/sandboxes/gates/'+name+'.log')
  if detail.exists():(out/(name+'.detail.log.gz')).write_bytes(gzip.compress(detail.read_bytes(),mtime=0))
 if r.returncode:print(raw.decode(errors='replace'),flush=True)
sources=['.github/workflows/release.yml','rust/tests/web/fast-pull-request-production-profile.test.mjs','docs/case-studies/issue-1580/checkout-archive-checkpoint.md','docs/case-studies/issue-1580/templates/java-historical-partial-review.json','experiments/issue-1580/work-plan.md','experiments/issue-1580/evidence/supplied-bootstrap-20261117.tar.gz']
result={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':rows,'sources':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sources}}
(out/'outcome.json').write_text(json.dumps(result,indent=2)+'\n')
assert all(row['exitCode']==0 for row in rows)
