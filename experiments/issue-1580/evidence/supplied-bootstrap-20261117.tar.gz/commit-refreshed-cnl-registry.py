from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/spoken-scheduling-paraphrases'
comparison=json.loads((base/'registry-comparison.json').read_text());assert comparison['executableUnchanged'] and comparison['programsAfter']==158 and len(comparison['changes'])==1 and comparison['changes'][0]['source']=='rust/src/cnl_output.rs'
rows=json.loads((base/'validation-results.json').read_text());assert next(row for row in rows if row['name']=='rust-specification-generated-programs')['exitCode']==0
def run(args):
 result=subprocess.run(args,cwd=root,capture_output=True,text=True);print(result.stdout,end='');print(result.stderr,end='');assert result.returncode==0;return result.stdout.strip()
assert run(['git','branch','--show-current'])=='issue-1580-8d61a32a61e1';assert run(['git','diff','--cached','--name-only'])==''
run(['git','add','--','scripts/lib/generated-native-programs.mjs']);assert run(['git','diff','--cached','--name-only'])=='scripts/lib/generated-native-programs.mjs';run(['git','diff','--cached','--check']);run(['git','-c','gc.auto=0','commit','-m','Refresh canonical CNL source witness in native registry']);run(['git','rev-parse','HEAD'])
