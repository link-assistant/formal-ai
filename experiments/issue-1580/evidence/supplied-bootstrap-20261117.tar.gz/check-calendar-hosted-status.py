from pathlib import Path
import json
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/ci/calendar-admission-86dcf79d';p=base/'latest.json'
if not p.exists():print('Waiting for the first exact-head observation.');raise SystemExit(0)
s=json.loads(p.read_text());print(json.dumps({k:v for k,v in s.items() if k!='runs'},indent=2));print(json.dumps([{'name':r['workflowName'],'status':r['status'],'conclusion':r['conclusion'],'url':r['url']} for r in s['runs'] if r['status']!='completed' or r['conclusion']!='success'],indent=2))
