from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
path=root/'rust/tests/unit/docs_requirements/agent_cli_shell.rs'
text=path.read_text()
before='''        &[
            "agent_mode",
            "FORMAL_AI_AGENT_MODE",
            "enable_http_agent_mode_for_current_process",
        ],
    );
}'''
after='''        &[
            "mod cli_local_transport;",
            "Command::Serve(args)",
            "args.agent_mode()",
            "enable_http_agent_mode_for_current_process",
        ],
    );
    // The extracted CLI arguments own --agent-mode; the shared configuration
    // loader owns its environment equivalent. Keep both paths traceable.
    let transport = read(root.join("rust/src/cli_local_transport.rs"));
    assert_contains_all(
        "rust/src/cli_local_transport.rs",
        &transport,
        &["pub struct ServeArgs", "agent_mode: bool", "pub const fn agent_mode"],
    );
    let configuration = read(root.join("rust/src/solver_helpers/mod.rs"));
    assert_contains_all(
        "rust/src/solver_helpers/mod.rs",
        &configuration,
        &["env_truthy(\\"FORMAL_AI_AGENT_MODE\\")", "config.agent_mode = true"],
    );
}'''
assert text.count(before)==1
assert 'FORMAL_AI_AGENT_MODE' not in (root/'rust/src/main.rs').read_text()
assert 'mod cli_local_transport;' in (root/'rust/src/main.rs').read_text()
assert 'env_truthy("FORMAL_AI_AGENT_MODE")' in (root/'rust/src/solver_helpers/mod.rs').read_text()
path.write_text(text.replace(before,after))
result=subprocess.run(['rustfmt','--edition','2024',str(path)],cwd=root,capture_output=True,text=True)
print(result.stdout+result.stderr);assert result.returncode==0
print('Replaced only the stale main.rs environment-location assertion with explicit current CLI/configuration owners. Native test execution remains unverified.')
