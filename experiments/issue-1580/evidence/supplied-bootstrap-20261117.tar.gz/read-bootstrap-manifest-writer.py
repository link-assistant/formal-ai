from pathlib import Path
import json
p=Path('/tmp/issue-1580-research/archive-round-bootstrap.py')
lines=p.read_text().splitlines()
assert len(lines)<=1500
for n,line in enumerate(lines,1):print(f'{n}: {line}')
manifest=Path('experiments/issue-1580/evidence/supplied-bootstrap-20261117.json')
value=json.loads(manifest.read_text())
print('MANIFEST KEYS',list(value))
for key,item in value.items():
 if isinstance(item,list):print('ARRAY',key,len(item),item[0] if item else '')
 else:print('SCALAR',key,item)
p=Path('experiments/formal_ai_subagent/sandboxes/gates/check-file-size.log')
lines=p.read_text().splitlines()
for n,line in enumerate(lines,1):
 if 'exceeds Maintained limit' in line or 'Found files exceeding' in line:print('ERROR',n,line)
