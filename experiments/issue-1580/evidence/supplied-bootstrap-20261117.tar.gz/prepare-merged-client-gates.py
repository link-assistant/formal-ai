from pathlib import Path
import json,subprocess
scratch=Path('/tmp/issue-1580-research')
source=(scratch/'check-client-output-batch.py').read_text()
start=source.index('files=[');end=source.index("\nif sys.argv[-1]",start)
source=source[:start]+'''files=[
 'rust/tests/web/main-only-regression-ledger.test.mjs',
 'rust/tests/web/fast-pull-request-production-profile.test.mjs',
 'rust/tests/web/rust-specification-unicode-identifiers.test.mjs',
 'rust/tests/web/rust-specification-fixture-integrity.test.mjs',
]'''+source[end:]
source=source.replace('client-focused-status','client-final-focused-status').replace('client-focused-runner','client-final-focused-runner').replace('client-focused-tests.json','client-final-focused-tests.json').replace('-client-batch.log','-client-final-batch.log')
(scratch/'check-final-client-output-batch.py').write_text(source)
source=(scratch/'run-governed-refresh-all-gates.py').read_text().replace('picomatch-governed-refresh','main-merge-826289fc').replace('governed-refresh-all','merged-client-all')
(scratch/'run-merged-client-all-gates.py').write_text(source)
stat=dict(line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines())
print(json.dumps(dict(memoryCurrent=int(Path('/sys/fs/cgroup/memory.current').read_text()),memoryMax=int(Path('/sys/fs/cgroup/memory.max').read_text()),anonymous=int(stat['anon']),inactiveFile=int(stat['inactive_file']))))
result=subprocess.run(['python3',str(scratch/'check-final-client-output-batch.py'),'start'],text=True,capture_output=True,check=True);print(result.stdout)
