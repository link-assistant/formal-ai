set -eu
test "$(git branch --show-current)" = issue-1580-8d61a32a61e1
git diff --check
git add docs/case-studies/issue-1580/README.md docs/case-studies/issue-1580/templates/README.md docs/case-studies/issue-1580/templates/java-active-semantic-review.json experiments/issue-1580/fixtures/java-template/source.json experiments/issue-1580/fixtures/java-template/scripts/collect-changelog.mjs experiments/issue-1580/fixtures/java-template/scripts/github-release-state.mjs experiments/issue-1580/fixtures/java-template/scripts/version-and-commit.mjs experiments/issue-1580/template-java-release-integrity.test.mjs experiments/issue-1580/upstream/java-release-commit-integrity-report.md experiments/issue-1580/work-plan.md experiments/issue-1580/evidence/checks/java-release-integrity.json experiments/issue-1580/evidence/checks/java-release-integrity-focused.log.gz experiments/issue-1580/evidence/checks/java-release-integrity-gates.log.gz experiments/issue-1580/evidence/checks/java-release-integrity-maintained.log.gz experiments/issue-1580/evidence/ci/e6627385d/summary.json experiments/issue-1580/evidence/ci/e6627385d/runs.json.gz rust/tests/web/issue-1580-template-observations.test.mjs
git diff --cached --check
git diff --cached --stat
git commit -m 'test: reproduce Java release commit integrity failure with real local Git'
git rev-parse HEAD
git status --short
