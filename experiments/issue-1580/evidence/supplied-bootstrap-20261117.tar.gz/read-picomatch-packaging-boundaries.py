from pathlib import Path
import subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
for name,lo,hi in [('.github/workflows/publish-vscode.yml',225,265),('.github/workflows/publish-engine.yml',150,205),('.github/workflows/verify-release-downloads.yml',155,192),('.github/workflows/layered-ci.yml',365,395)]:
    lines=(root/name).read_text().splitlines()
    print('\nFILE',name)
    for n in range(lo-1,min(hi,len(lines))): print(f'{n+1}: {lines[n]}')
result=subprocess.run(['rg','-n','minimatch-compat|packages/.*compat|picomatch','scripts','desktop','vscode','.github/workflows/desktop-release.yml','.github/workflows/publish-vscode.yml','.github/workflows/publish-engine.yml'],cwd=root,text=True,capture_output=True)
print('\nPACKAGING REFERENCES')
for line in result.stdout.splitlines():
    if 'package-lock.json:' not in line: print(line)
