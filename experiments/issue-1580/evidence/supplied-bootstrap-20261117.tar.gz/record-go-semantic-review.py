from pathlib import Path
import hashlib
import json

root = Path.cwd()
base = Path('/tmp/issue-1580-research/templates')
inventory = json.loads((base/'go-complete-inventory.json').read_text())
commit = '65c686846d7327d8c835a0d30b1a76cc6345cfc6'
groups = [
    (['.changeset/README.md','.changeset/config.json','.changeset/add-changeset-workflow.md','.changeset/fix-ci-workflow-dependencies.md','.changeset/gate-external-state-and-rerun-unacquired.md','.changeset/harden-release-workflow.md','.changeset/recover-releases-and-pin-ci.md','CHANGELOG.md'],
     'release metadata and historical descriptions', ['changelog.d','CONTRIBUTING.md'],
     'Keep the existing changelog.d release trigger. Historical descriptions are context, not proof that a workflow ran. Go package frontmatter is language-specific.'),
    (['.github/dependabot.yml'], 'dependency update proposals', ['.github/workflows/dependencies-latest.yml','scripts/check-dependencies-latest.rs'],
     'The Go template uses weekly grouped Dependabot proposals; Formal AI instead has its own dependency workflow, with publication controls. A freshness warning must never suppress integrity checks; the new offline probe demonstrates the Go early-continue defect. Formal AI retains strict findings/unverifiable receipts.'),
    (['.github/workflows/release.yml'], 'test/build/release admission and serialization', ['.github/workflows/release.yml','.github/workflows/layered-ci.yml','scripts/ci-pull-request-admission.mjs'],
     'Compared all 453 lines: pinned runners, read-first permissions, per-job check cancellation, non-cancelling serialized writers, optional Codecov notice, and verify-before-announcement. Manual skipped dependencies reproduce Go #18. Do not copy PR Go builds into Formal AI: its PR application-build policy remains binding. Missing job timeouts already have upstream #17.'),
    (['.github/workflows/rerun-unacquired.yml','scripts/ci/rerun-unacquired.mjs','scripts/ci/runner-acquisition.mjs','scripts/ci/runner-acquisition.test.mjs'],
     'runner acquisition classification and bounded retry', ['scripts/report-runner-capacity.sh','scripts/check-pipeline-status.sh'],
     'Requires the acquisition annotation plus no runner and no steps; annotation lookup failure remains not-started. Paginated jobs/annotations, two automatic retries, same-repository filter, trusted default-branch checkout, and narrowly scoped write permission are applicable patterns. Do not rerun actual code failures or assert a cache/backend cause from counters. These upstream tests were read, not executed here.'),
    (['.github/workflows/workflows.yml','scripts/workflow-policy.test.mjs'], 'workflow source policy', ['scripts/check-runner-labels.mjs','.github/workflows/layered-ci.yml'],
     'Pinned actionlint/container/tool/runners and scheduled checks are applicable. The Go policy suite mainly matches source text and misses the modeled skip chain. Preserve behavioral negative controls. Its queue compatibility ignore is source-reviewed, with no additional executed defect claimed.'),
    (['.gitignore'], 'workspace exclusions', ['.gitignore'],
     'Go binaries/vendor/coverage exclusions are ecosystem-specific. Preserve Formal AI scratch exclusions and do not commit agent state.'),
    (['.pre-commit-config.yaml','CONTRIBUTING.md','README.md'], 'contributor and consumer workflow', ['CONTRIBUTING.md'],
     'Read complete setup/test/release guidance. Go format/vet/race/build hooks describe that repository. Retain Formal AI focused JavaScript checks, rustfmt-only local validation, and CI native policy rather than importing expensive local hooks.'),
    (['LICENSE'], 'source redistribution', ['LICENSE'],
     'Read the Unlicense; retain the original LICENSE with every copied Go fixture and immutable source hashes.'),
    (['examples/basic_usage.go','go.mod','pkg/mypackage/mypackage.go','pkg/mypackage/mypackage_test.go'],
     'consumer example, module metadata and demonstration application', ['rust/Cargo.toml','rust/examples'],
     'Read all source and tests. Go module minimum 1.21 differs intentionally from pinned CI 1.27.3. Addition/greeting/context-delay examples are demonstration application behavior, not reusable CI logic. No Go application build was run or imported.'),
    (['experiments/issue-14-live-dry-run.sh'], 'live diagnostic example', ['experiments/issue-1580'],
     'Read bounded read-only job/annotation inspection and --dry-run rerun invocation. It does not prove an actual workflow rerun. Preserve distinction between modeled observations and hosted execution.'),
    (['scripts/check-file-size.mjs'], 'size policy', ['scripts/check-file-size.rs','experiments/formal_ai_subagent/local-gates.mjs'],
     'Recursive Go-only size check retains a 1,000-line default. Formal AI keeps its existing language-wide thresholds and real gate selection. Invalid custom numeric input is an unexecuted review concern; no new defect report or fix is claimed for it.'),
    (['scripts/check-release-needed.mjs','scripts/check-release-needed.test.mjs'], 'missing release recovery', ['scripts/check-release-needed.rs','scripts/create-release-with-recovery.mjs'],
     'Distinguishes exact missing-release response from API/auth/network errors and requires a tag. Unknown lookup warns and suppresses recovery. Formal AI preserves richer unknown/failed receipts and immutable source identity; do not reduce these to a successful publication claim. Read real-Git mocked-GitHub recovery tests; not executed here.'),
    (['scripts/ci/check-dependencies.mjs','scripts/ci/check-dependencies.test.mjs'], 'freshness and pin integrity', ['scripts/check-dependencies-latest.rs','scripts/check-dependencies-action-release.rs'],
     'Read discovery, tag/digest verification, bounded tag dereference and event reporting. Executed unmodified checker: stale versions bypass verification and pass push/schedule/dispatch even with a supplied integrity failure; current pins fail. Removing only the early continue in a disposable copy restores integrity failures and retains freshness-only warnings. Existing upstream tests miss this combined case. No production template repair is claimed.'),
    (['scripts/ci/check-pipeline-status.mjs'], 'aggregate result integrity', ['scripts/check-pipeline-status.sh'],
     'Failure/cancelled needs block; skipped needs pass. Actual helper accepts modeled all-skipped manual release prerequisites, as reported in Go #18. Do not claim every skip is a defect: expected optional jobs legitimately skip. API details are diagnostic and cannot turn blocking needs into success.'),
    (['scripts/create-github-release.mjs','scripts/create-github-release.test.mjs'], 'release announcement', ['scripts/create-github-release.rs','scripts/create-release-with-recovery.mjs'],
     'Requires strict numeric version and existing tag, supplies notes through stdin, and treats already-exists as recovery. Retain Formal AI source-freshness and publication observation contracts; the Go helper alone does not establish tag target or consumed-artifact identity. Upstream source/tests read, not executed.'),
    (['scripts/detect-code-changes.mjs'], 'Git comparison and outputs', ['scripts/detect-code-changes.rs','scripts/ci-pull-request-admission.mjs'],
     'Executed failed-Git, code/docs, and real initial-commit controls reproduce Go #19. Formal AI native detector propagates unknown comparisons and output errors and establishes an initial commit before tree fallback; its added native regressions remain unexecuted under pre-merge native policy. Existing JavaScript admission checks run on PRs.'),
    (['scripts/github-actions-log.mjs','scripts/github-actions-log.test.mjs'], 'untrusted log output', ['scripts/check-pipeline-status.sh'],
     'Read random 128-bit stop/resume guard and contributor changeset/filename tests. Keep contributor data out of command interpolation and classify diagnostics without treating printed text as execution. Copied helper remains unchanged in the regression fixture.'),
    (['scripts/merge-changesets.mjs','scripts/validate-changeset.mjs','scripts/version-and-commit.mjs'], 'changeset validation and release writes', ['scripts/check-changelog-fragment.rs','scripts/check-release-needed.rs'],
     'Read every parse/fallback/write/tag/push path. The template uses regex frontmatter, file mtime ordering, PR-diff fallbacks and separate branch/tag pushes; these are not a basis to replace Formal AI fragment validation, publication receipts or source-freshness guards. Unknown diff fallback and broad git add -A deserve care; no unexecuted candidate is claimed fixed. Writers remain serialized by workflow.'),
    (['scripts/verify-module-availability.mjs','scripts/verify-module-availability.test.mjs'], 'consumer publication verification', ['scripts/verify-public-release-downloads.mjs','scripts/release-publication-observation.mjs'],
     'Read exact version polling, proxy module-path escaping, finite attempt count and injected-fetch tests. Apply verify-before-announcement and bounded retry concepts; Go proxy polling is not a Rust/npm publication verifier. Fetch lacks a per-request deadline; source observation only, no new executed defect claimed.'),
]
decisions = {}
for paths, role, analogues, decision in groups:
    for analogue in analogues:
        assert (root/analogue).exists(), analogue
    for path in paths:
        assert path not in decisions, path
        decisions[path] = {'role':role,'formalAiComparison':analogues,'decision':decision}
assert set(decisions) == {item['path'] for item in inventory}, set(decisions).symmetric_difference(item['path'] for item in inventory)
records=[]
for item in inventory:
    data=(base/'go-complete'/item['path']).read_bytes()
    assert hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()==item['gitBlob']
    records.append({**item,'sha256':hashlib.sha256(data).hexdigest(),'completeSourceRead':True,**decisions[item['path']]})
result = {
    'repository':'link-foundation/go-ai-driven-development-pipeline-template','commit':commit,
    'scope':'All 42 repository blobs read and compared by behavior/role, including all three workflows and their local scripts, tests and configuration. This is source review, not a claim that the upstream pipeline or every upstream test ran.',
    'limits':['Seven other complete template reviews remain unfinished.','External action/runtime implementation is outside this repository-source review.','Lexical graph unresolved entries are reviewed as references, not automatically counted as defects.','Native regression execution and broader issue-1580 criteria remain open.','Externally supplied review/reproduction code receives zero independent Formal AI reasoning/authorship credit.'],
    'verification':'Pinned blob hashes checked per read page and again here; executed Go regression file has five passing cases, including current/stale integrity negative controls. Maintained entrypoint recheck follows separately.',
    'files':records,
}
destination=root/'docs/case-studies/issue-1580/templates/go-semantic-review.json'
destination.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'filesReviewed':len(records),'path':str(destination.relative_to(root))}))
