from pathlib import Path
import gzip,hashlib,json,subprocess
base=Path('experiments/issue-1580/evidence/checks/fast-source-archive-checkout');args=['node','--max-old-space-size=256','scripts/generate-staged-release.mjs','--check-deployed'];run=subprocess.run(args,capture_output=True);raw=run.stdout+run.stderr;(base/'staged-after.log.gz').write_bytes(gzip.compress(raw,mtime=0));v={'argv':args,'exitCode':run.returncode,'rawSha256':hashlib.sha256(raw).hexdigest(),'rawBytes':len(raw),'rawLines':len(raw.splitlines())};(base/'staged-after.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v));print(raw.decode());assert run.returncode==0
print('STAGED REGRESSION FILES')
for p in Path('rust/tests/web').glob('*staged*test.mjs'):print(p)
