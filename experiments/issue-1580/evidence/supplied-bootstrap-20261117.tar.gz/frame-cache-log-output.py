from pathlib import Path
p=Path('scripts/check-sccache-write-health.sh');text=p.read_text()
text=text.replace('# Prefix every line so backend text cannot become a workflow command.','# Suspend workflow commands with a fresh 128-bit token while printing backend\n# text. A display prefix alone is not an execution boundary.')
needle='  local backend_log="${SCCACHE_ERROR_LOG:-}"';assert needle in text
text=text.replace(needle,'  local backend_log="${SCCACHE_ERROR_LOG:-}" token')
needle="  echo '[sccache] opt-in backend log tail (at most 64 KiB / 80 lines; URLs redacted):' >&2";assert needle in text
text=text.replace(needle,'''  token="$(od -An -N16 -tx1 /dev/urandom 2> /dev/null | tr -d '[:space:]')" || return 0
  [[ "$token" =~ ^[0-9a-f]{32}$ ]] || return 0
  printf '::stop-commands::%s\\n' "$token" >&2
'''+needle)
needle="    sed -E 's#https?://[^[:space:]]+#<cache-url-redacted>#g; s/^/[sccache] /' >&2 || true\n  return 0"
assert needle in text
text=text.replace(needle,needle.replace('  return 0',"  printf '::%s::\\n' \"$token\" >&2\n  return 0"))
p.write_text(text)
p=Path('rust/tests/web/sccache-outage-fallback.test.mjs');text=p.read_text()
needle="  assert.match(verbose.stderr,/^\\[sccache\\] ::error::untrusted backend annotation$/mu);";assert needle in text
text=text.replace(needle,needle+'''
  const token=verbose.stderr.match(/^::stop-commands::([0-9a-f]{32})$/mu)?.[1];
  assert.ok(token,'fresh workflow-command suspension token');
  assert.ok(verbose.stderr.endsWith(`::${token}::\\n`),'workflow commands resume after the diagnostic');
  const again=cacheWriteReport(t,'',{log:backend,verbose:true});
  assert.notEqual(again.stderr.match(/^::stop-commands::([0-9a-f]{32})$/mu)?.[1],token);
''')
text=text.replace("length<=81,'at most 80 log lines plus the diagnostic heading'","length<=83,'at most 80 log lines plus heading and command-suspension markers'")
p.write_text(text)
print('Use fresh workflow-command suspension tokens around bounded backend output.')
