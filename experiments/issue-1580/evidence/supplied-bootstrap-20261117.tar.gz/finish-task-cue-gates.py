from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,os,re,subprocess,sys,time,traceback
root=Path('/tmp/gh-issue-solver-1794900398048')
scratch=Path('/tmp/issue-1580-research/task-cue-final-gates')
base=root/'experiments/issue-1580/evidence/checks/quoted-passage-cues/final-gates'
if len(sys.argv)==1:
    scratch.mkdir(exist_ok=False);base.mkdir(exist_ok=False)
    with (scratch/'worker.log').open('wb') as stream:
        process=subprocess.Popen([sys.executable,__file__,'finish'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({'pid':process.pid,'scratch':str(scratch)}));sys.exit(0)
assert sys.argv[1:]==['finish']
environment=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256');records=[]
def run(name,args,checked=True):
    started=time.monotonic()
    with (scratch/(name+'.log')).open('wb') as stream:
        result=subprocess.run(args,cwd=root,env=environment,stdout=stream,stderr=subprocess.STDOUT)
    raw=(scratch/(name+'.log')).read_bytes();packed=gzip.compress(raw,mtime=0);(base/(name+'.log.gz')).write_bytes(packed)
    row={'name':name,'argv':args,'exitCode':result.returncode,'seconds':round(time.monotonic()-started,3),'rawLines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()};records.append(row);print(json.dumps(row),flush=True)
    if checked:assert result.returncode==0,(name,raw.decode()[-3500:])
    return result.returncode,raw
complete=False
try:
    files=['data/meta/worker-line-budget/formal_ai_worker_crate_task_decomposition_cues.lino','js/agentic/crate/task_decomposition_cues.mjs','js/worker/formal_ai_worker_crate_task_decomposition_cues.js','rust/src/meta_executor/decomposition.rs','rust/tests/fixtures/meta-executor-cue-parity.json','rust/tests/web/helpers/issue-1580-task-cue-cases.mjs','ts/agentic/crate/task_decomposition_cues.mts','ts/worker/formal_ai_worker_crate_task_decomposition_cues.ts']
    run('register-new-source',['git','add','--intent-to-add','--',*files])
    run('translation-writer',['node','scripts/translate-js-rust.mjs','--write','--fetch','--jobs','1','js/agentic/crate/meta_executor.mjs','js/agentic/crate/task_decomposition_cues.mjs'])
    run('translation-verification',['node','scripts/translate-js-rust.mjs','--verify'])
    preserved=[]
    for name in ['rust/tests/fixtures/meta-executor-parity.json','rust/tests/fixtures/meta-executor-status-parity.json']:
        original=subprocess.check_output(['git','show','c8fb9ad1df655abe89289e229189f3fc41451ec0:'+name],cwd=root)
        assert (root/name).read_bytes()==original,name
        preserved.append({'path':name,'unchanged':True,'sha256':hashlib.sha256(original).hexdigest(),'cases':len(json.loads(original)['cases'])})
    assert len(json.loads((root/'rust/tests/fixtures/meta-executor-cue-parity.json').read_text())['cases'])==12
    (base/'fixture-preservation.json').write_text(json.dumps({'originals':preserved,'newCueCases':12,'independentAuthorshipCredit':0},indent=2)+'\n')
    code,data=run('all-gates',['node','experiments/formal_ai_subagent/local-gates.mjs'],checked=False)
    details=[]
    for index,name in enumerate(re.findall(r'^(?:PASS|FAIL|SKIP) (\S+)',data.decode(),re.M),1):
        path=root/'experiments/formal_ai_subagent/sandboxes/gates'/(name+'.log')
        if not path.exists():continue
        raw=path.read_bytes();filename=f'gate-{index:03d}.log.gz';packed=gzip.compress(raw,mtime=0);(base/filename).write_bytes(packed)
        details.append({'name':name,'log':filename,'rawLines':len(raw.splitlines()),'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
    (base/'gate-details.json').write_text(json.dumps(details,indent=2)+'\n')
    complete=code==0
except BaseException:traceback.print_exc()
report={'complete':complete,'checks':records,'observedAt':datetime.now(timezone.utc).isoformat(),'nativeExecuted':False,'memoryEventsAfter':Path('/sys/fs/cgroup/memory.events').read_text(),'independentAuthorshipCredit':0}
(base/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='checks'}),flush=True)
sys.exit(0 if complete else 1)
