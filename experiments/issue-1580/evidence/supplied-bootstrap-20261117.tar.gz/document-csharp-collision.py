from pathlib import Path
import datetime,gzip,hashlib,json,subprocess

base=Path('experiments/issue-1580')
evidence=base/'evidence/checks/csharp-changeset-collision'
review=Path('docs/case-studies/issue-1580/templates/csharp-partial-semantic-review.json')
assert json.loads(review.read_text())['counts']['activeFullyRead']==120
checks={label:json.loads((evidence/(label+'.json')).read_text()) for label in ['before','after','maintained']}
assert checks['before']['exitCode']==1 and checks['before']['assertionsVerified']
assert checks['after']['exitCode']==0 and checks['maintained']['exitCode']==0
preflight=Path('/tmp/issue-1580-research/csharp-collision-preflight')
api=[]
for p in sorted(preflight.glob('*.json')):
 data=p.read_bytes();target=evidence/('upstream-'+p.name+'.gz')
 target.write_bytes(gzip.compress(data,mtime=0))
 api.append({'path':str(target),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
record={
 'repository':'link-foundation/csharp-ai-driven-development-pipeline-template',
 'commit':'a5b9a1a46686cfe844f9afa2ace030094969e766',
 'fixtureSource':'experiments/issue-1580/fixtures/csharp-template/source.json',
 'regression':'experiments/issue-1580/template-csharp-changeset-integrity.test.mjs',
 'sourceBoundary':'scripts/merge-changesets.mjs:213-225: ordinary write to randomly generated output, then unconditional removal of every parsed input path.',
 'observedBefore':'Two valid inputs, including merged-bright-apple.md, deterministic Math.random=0: exit 0 and zero changesets left. The preservation assertion fails: 3 pass / 1 fail.',
 'candidate':'Change only the disposable copy output write to use {flag: wx}. Existing output yields EEXIST/exit 1 before deleting or modifying either input. Collision recovery/retry is not implemented by this candidate.',
 'observedAfter':'4 pass / 0 fail / 0 skip; noncollision still selects major and preserves both descriptions in mtime order; malformed input still fails without mutation. Maintained entrypoint: 25 pass / 0 fail / 0 skip.',
 'checks':checks,'upstreamPreflight':api,
 'priorReports':'Existing C# 78 and its repair PR 83 concern invalid changeset parsing; 60/62 concern untrusted output. Complete matching bodies and the latest source PR 83 conversation/reviews were read. This valid-input filename collision is distinct; upstream source still matches the pin.',
 'reviewArtifact':str(review),
 'formalAiApplicability':'Formal AI uses Rust changelog fragments rather than this C# merger; no production helper is replaced by this fixture. Reading scripts/create-changelog-fragment.rs exposes a separate unexecuted timestamp/nonexclusive-write collision question. That question remains unfinished; no claim that all Formal AI release writes are safe is made.',
 'limits':['No .NET or Bun suite executed','No template hosted workflow, live publication, registry authentication or network experiment','Partial semantic review remains incomplete','This reporting fixture does not implement an upstream repair or complete issue 1580'],
 'authorship':'Codex supplied all experiments, candidate edits, assertions and conclusions. Zero independently accepted Formal AI reasoning units.',
}
(base/'evidence/checks/csharp-changeset-integrity.json').write_text(json.dumps(record,indent=2)+'\n')
body=base/'upstream/csharp-changeset-output-collision-report.md'
assert not body.exists()
body.write_text('''## Reproduction

At `a5b9a1a46686cfe844f9afa2ace030094969e766`, two valid pending changesets can disappear while `scripts/merge-changesets.mjs` reports success. One input has a name the merger can generate: `merged-bright-apple.md`; the other is `other.md`. Their front matter requests `patch` and `major`, and both have nonempty descriptions.

Force the random name only to make the existing collision deterministic, then execute the unchanged source:

```sh
node --max-old-space-size=64 --import 'data:text/javascript,Math.random%3D()%3D%3E0' scripts/merge-changesets.mjs
```

Observed: exit 0, `Changeset merge completed successfully`, and an empty `.changeset` directory. Both descriptions and the major bump are lost. This requires valid inputs; it is distinct from the invalid-parse loss previously addressed by #78/#83.

## Cause and candidate guard

Lines 213-217 choose a random output name and use ordinary `writeFileSync`. If that name equals a pending input path, the merged output overwrites the input. Lines 222-225 then unlink every parsed input, including that output. No merged file survives for versioning.

The disposable candidate changes only the output write to `writeFileSync(mergedFilePath, mergedContent, {flag: 'wx'})`. A collision then raises `EEXIST` and exits 1 with both original inputs byte-for-byte intact. A full repair could reserve a distinct name with exclusive creation and a finite collision retry; it must never delete any input until a distinct output is safely established. The tested candidate rejects collisions; automatic name recovery is not tested or claimed.

## Executable evidence

- [Content-addressed pinned source and license](https://github.com/link-assistant/formal-ai/tree/EVIDENCE_COMMIT/experiments/issue-1580/fixtures/csharp-template).
- [Four-case regression](https://github.com/link-assistant/formal-ai/blob/EVIDENCE_COMMIT/experiments/issue-1580/template-csharp-changeset-integrity.test.mjs).
- [Before/after log and identity index](https://github.com/link-assistant/formal-ai/blob/EVIDENCE_COMMIT/experiments/issue-1580/evidence/checks/csharp-changeset-integrity.json).

Run `node --test --test-concurrency=1 experiments/issue-1580/template-csharp-changeset-integrity.test.mjs` in that checkout. It executes unchanged pinned helpers in small temporary directories, then applies the candidate only to disposable copies. The preservation assertion fails against the original (3 pass / 1 fail) and all four cases pass after the guard is inserted. Positive controls retain the major bump and both descriptions in chronological order; malformed-input controls retain the existing fatal, nonmutating behavior. The maintained entrypoint also passes all 25 tests, without skips.

No .NET build, Git repository, provider API, package publication or hosted template workflow is involved. All random-source injection, candidate changes and conclusions are supplied by Codex; Formal AI shell execution is not counted as independent reasoning. The C# repository review remains partial.
''')
docs=Path('docs/case-studies/issue-1580/templates/README.md')
text=docs.read_text().replace('the current suite passes twenty-one with reference-graph coverage','the current suite passes twenty-five with reference-graph and C# changeset coverage')
text+='''
## Partial C# review and valid-input changeset loss

[`csharp-partial-semantic-review.json`](csharp-partial-semantic-review.json) verifies all 337 pinned blobs and records exactly 120 fully read active files (11,974 of 18,327 active lines). All six workflows are read; 38 active files, including remaining release/asset/security/runner helpers and application/test source, and 179 historical blobs remain semantically unread. This checkpoint does not complete the C# review or its transitive CI closure.

The unchanged merge helper reproduces a distinct data-loss defect: a randomly chosen output filename can equal a valid pending input. The write overwrites it, and cleanup deletes the output along with the other input, reporting success with no changesets left. The preservation regression fails before a disposable exclusive-create guard and passes afterward. Four tests also preserve noncollision major-bump/description order and malformed-input rejection; the maintained entrypoint passes 25 tests without skips. This is bounded Node execution, without .NET, Bun, provider APIs, publication or upstream hosted execution. Full logs, source hashes, harness-output corrections and upstream duplicate/source checks are indexed in `experiments/issue-1580/evidence/checks/csharp-changeset-integrity.json`.

The distinct upstream report is drafted and must cite immutable published evidence before filing. Existing C# #78/#83 address invalid parsing, while #60/#62 address untrusted log output. The latest source PR #83 and all its conversation comments/reviews were read. Other source observations, including preflight GitHub request deadlines and Formal AI timestamp fragment creation with nonexclusive writes, remain unexecuted questions, without new defect or safety claims. All broad issue acceptance criteria remain active.
'''
docs.write_text(text)
case=Path('docs/case-studies/issue-1580/README.md')
case.write_text(case.read_text()+'''
### C# partial review and changeset collision regression

The [C# partial review](templates/csharp-partial-semantic-review.json) covers all six workflows and 120 active files, with exact verified identities. Its remaining 38 active files and 179 historical blobs stay explicitly unread. A valid-input filename collision in the pinned merger reproduces successful deletion of every pending changeset. The preservation assertion fails before a disposable exclusive-create guard; all four new controls and the maintained 25-test entrypoint pass afterward. The [full evidence index](../../../experiments/issue-1580/evidence/checks/csharp-changeset-integrity.json) retains before/after logs, source identities, positive controls and duplicate/source checks. No .NET/Bun build, hosted template execution, upstream repair or complete C# review is claimed.

All 24 workflows on `e582b270a01443b995d7f36fd2fa685d508fde77` now pass. Layered CI attempt 1 failed before tests during checkout with curl 28, a bad pack header and a missing promisor object (log lines 5634-5636). The same-head failed-job-only rerun passes. Both complete attempt logs and metadata are retained under `experiments/issue-1580/evidence/ci/e582b270a/`; this successful scoped PR result does not qualify the outstanding main-only native, benchmark, publication or live-identity criteria. The new C# checkpoint needs its own hosted verification.
''')
plan=base/'work-plan.md'
plan.write_text(plan.read_text()+'''
## C# collision and checkout retry checkpoint

All 24 workflows on e582b270a completed successfully after preserving the checkout-only failure and rerunning that failed job on the same head; both attempts are archived. The C# review verifies 337 blobs and fully reads 120 active files / 11,974 lines, leaving 38 active files and all 179 historical blobs explicitly unread. Reproduce successful deletion of all valid pending changesets when the merge output collides with an input; retain the failing preservation test, then four passing candidate/control cases and the 25-test maintained entrypoint. Record all harness output-format corrections. Publish immutable evidence before filing the distinct upstream report. Formal AI timestamp/nonexclusive fragment creation is an unexecuted source question, without a safety claim. No native build or upstream runtime/publication acceptance is claimed, and all broad remaining criteria stay active.
''')
repo='link-assistant/formal-ai';head='e582b270a01443b995d7f36fd2fa685d508fde77'
allruns=json.loads(subprocess.check_output(['gh','run','list','--repo',repo,'--branch','issue-1580-8d61a32a61e1','--limit','100','--json','databaseId,conclusion,createdAt,headSha,status,name,workflowName,url,updatedAt'],text=True))
runs=[row for row in allruns if row['headSha']==head]
assert len(runs)==24 and all(row['status']=='completed' and row['conclusion']=='success' for row in runs)
ci=base/'evidence/ci/e582b270a'
(ci/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
summary={'head':head,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':24,'success':24,'failure':0,'active':0,'checkoutRetry':{'run':44089535561,'failedAttempt':1,'successfulAttempt':2,'cause':'checkout transport failure before shard tests','originalErrorLines':[5634,5635,5636]},'limits':'Scoped PR checks; no main-only native, benchmark, template publication or live identity completion.'}
(ci/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'draftReport':str(body),'checks':str(base/'evidence/checks/csharp-changeset-integrity.json'),'review':str(review),'ci':summary},indent=2))
