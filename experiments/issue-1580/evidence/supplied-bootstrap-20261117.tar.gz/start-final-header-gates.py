from pathlib import Path
import subprocess
import sys

source=Path("/tmp/issue-1580-research/run-merged-main-all-gates.py").read_text()
source=source.replace('directory=root/"experiments/issue-1580/evidence/checks/main-merge-512ce428"','directory=root/"experiments/issue-1580/evidence/checks/generated-header-memory/final-gates"\ndirectory.mkdir(parents=True,exist_ok=True)')
source=source.replace('assert json.loads((directory/"focused-completion.json").read_text())["status"]==0','assert json.loads((directory.parent/"generated-streamed.json").read_text())["status"]==0\n    assert json.loads((directory.parent/"browser-reaped.json").read_text())["status"]==0')
target=Path("/tmp/issue-1580-research/run-final-header-gates.py")
target.write_text(source)
subprocess.run([sys.executable,str(target)],check=True)
