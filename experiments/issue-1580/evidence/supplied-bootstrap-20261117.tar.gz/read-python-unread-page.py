from pathlib import Path
import collections
import hashlib
import json
import sys

page=int(sys.argv[1]);assert 1<=page<=54
root=Path("/tmp/issue-1580-research/templates/python-complete")
inventory=json.loads(Path("/tmp/issue-1580-research/python-active-source-inventory.json").read_text())
review=json.loads(Path("docs/case-studies/issue-1580/templates/python-partial-semantic-review.json").read_text())
known=collections.defaultdict(set)
for row in review["files"]:
    for first,last in row["readRanges"]:known[row["path"]].update(range(first,last+1))
deferred={".github/actions/artifact/dist/835.index.mjs",".github/actions/artifact/dist/index.mjs",".github/actions/artifact/package-lock.json","uv.lock"}
selected=[(row["path"],n) for row in inventory["active"] if row["path"] not in deferred for n in range(1,row["lines"]+1)]
rows=selected[(page-1)*400:page*400]
pending=[(name,n) for name,n in rows if n not in known[name]]
print(json.dumps({"page":page,"selectedLines":len(rows),"previouslyFullyRecordedLines":len(rows)-len(pending),"newSourceLines":len(pending),"commit":review.get("commit",review.get("pinnedCommit")),"deferredFilesRemainUnread":True}))
last=None;cache={}
for name,n in pending:
    if name not in cache:
        raw=(root/name).read_bytes()
        expected=next(row["sha256"] for row in review["files"] if row["path"]==name)
        assert hashlib.sha256(raw).hexdigest()==expected
        cache[name]=raw.decode().splitlines()
    if name!=last:print("\nFILE",name);last=name
    print(str(n)+": "+cache[name][n-1])
