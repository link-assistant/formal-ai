from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
commands=[
 ['rg','--files','rust/src'],
 ['rg','-n','--glob','*.rs','--max-columns','240','--max-columns-preview','FORMAL_AI.*CACHE|wordnet.*cache|cache.*wordnet|set_var.*CACHE|with_vars.*CACHE','rust/src','rust/tests/unit','rust/tests/integration'],
 ['rg','-n','--glob','*.mjs','--max-columns','240','--max-columns-preview','unknown_reasoning|seed_backed_bare_terms|snorflax|7135852a','rust/tests/web'],
]
for i,args in enumerate(commands):
 p=subprocess.run(args,cwd=root,capture_output=True,text=True);lines=p.stdout.splitlines()
 if i==0:lines=[x for x in lines if any(k in x for k in ['retriev','source_fetch','concepts'])]
 print('COMMAND',i,'exit',p.returncode,'lines',len(lines))
 assert len(lines)<170
 print('\n'.join(lines));print(p.stderr[:500])
