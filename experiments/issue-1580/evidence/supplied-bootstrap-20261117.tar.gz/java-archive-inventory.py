import json
from collections import Counter
from pathlib import Path

root = Path('/tmp/issue-1580-research/templates/java-complete')
inventory = json.loads(Path('/tmp/issue-1580-research/templates/java-complete-inventory.json').read_text())
for row in inventory:
    name = row['path']
    if name.startswith(('dev/', 'docs/case-studies/')):
        print(name, row['bytes'], len((root / name).read_bytes().splitlines()))
