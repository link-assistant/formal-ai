import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {deserialize,serialize} from 'node:v8';
import {createHash} from 'node:crypto';
import {relative,isAbsolute,resolve} from 'node:path';
const root=process.cwd();
const {specificationCases}=await import(resolve(root,'scripts/lib/rust-specification-cases.mjs'));
const file='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8';
const previous=deserialize(readFileSync(file));
const inventory=specificationCases(root);
const cases=structuredClone(inventory.cases);
for(const item of cases)for(const fixture of item.program?.fixtures??[]){
 if(isAbsolute(fixture.file))fixture.file='repo:'+relative(root,fixture.file);
}
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const sourceManifest=readdirSync('rust/tests/unit/specification',{recursive:true}).map(String)
 .filter(name=>name.endsWith('.rs')).sort().map(name=>{
  const path='rust/tests/unit/specification/'+name;return {path,sha256:hash(readFileSync(path))};
 });
const next={inventory:{...inventory,cases},sourceManifest};
const changes=[];
function compare(before,after,path=[]){
 if(JSON.stringify(before)===JSON.stringify(after))return;
 if(before&&after&&typeof before==='object'&&typeof after==='object'){
  for(const key of new Set([...Object.keys(before),...Object.keys(after)]))compare(before[key],after[key],[...path,key]);
 }else changes.push({path,before,after});
}
compare(previous,next);
writeFileSync('/tmp/issue-1580-research/governed-baseline-review.json',JSON.stringify({beforeSha256:hash(readFileSync(file)),readerSha256:hash(readFileSync('scripts/lib/rust-specification-cases.mjs')),beforeCases:previous.inventory.cases.length,afterCases:cases.length,changes},null,2)+'\n');
console.log(JSON.stringify({beforeCases:previous.inventory.cases.length,afterCases:cases.length,changes},null,2));
