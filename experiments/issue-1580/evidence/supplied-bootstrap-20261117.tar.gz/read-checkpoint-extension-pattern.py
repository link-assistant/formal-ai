from pathlib import Path
for relative in ("/tmp/issue-1580-research/extend-python-review-through-28.py","/tmp/issue-1580-research/finalize-format-local-batch.py"):
    path=Path(relative)
    print("FILE",path)
    for number,line in enumerate(path.read_text().splitlines(),1):
        print(str(number)+": "+line)
