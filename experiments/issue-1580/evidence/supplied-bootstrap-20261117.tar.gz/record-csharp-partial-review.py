from pathlib import Path
import collections,gzip,hashlib,json

root=Path('/tmp/issue-1580-research/templates/csharp-complete')
inventory=json.loads(Path('/tmp/issue-1580-research/templates/csharp-complete-inventory.json').read_text())
sourceCommit='a5b9a1a46686cfe844f9afa2ace030094969e766'
notes={
 '.github/actions/csharp-layout/action.yml':'Resolves root versus nested C# checkout layout and exposes its working directory. Keep Formal AI explicit working directories; no action execution is claimed.',
 '.github/workflows/docs.yml':'Read the complete build/deployment conditions and independent opt-in documentation path. Keep Formal AI default-branch publication restriction and fatal build results.',
 '.github/workflows/links.yml':'Read lychee, bounded recheck, archive lookup and terminal failure ordering. Only explicit successful recovery may suppress a failed link result; unknown lookup stays distinct from absence.',
 '.github/workflows/release.yml':'Read all 922 lines, including change detection, preflight, tests, publication writers, identity checks, artifacts and aggregate verdict. Retain Formal AI default-branch-only application builds. Reading does not establish hosted publication or validate all transitive helpers; 38 active files remain unread.',
 '.github/workflows/rerun-infrastructure-failures.yml':'Read restricted infrastructure rerun workflow and provenance checks. Do not classify arbitrary cancelled tests as infrastructure failures; helper runtime remains unexecuted here.',
 '.github/workflows/security.yml':'Read complete helper/dependency audits, CodeQL/SARIF and terminal gates. Preserve fatal failed scans and explicit unknown results; no C# build or upstream hosted audit was run.',
 '.github/workflows/workflows.yml':'Read complete helper lint/type/test and native linter integration jobs. Scoped actionlint compatibility for valid self-repository syntax is already documented; avoid a duplicate invalid-syntax report.',
 'scripts/audit-dependencies.mjs':'Read full dependency audit; source inspection is distinct from executing package restore or proving current registry vulnerability state.',
 'scripts/audit-javascript.mjs':'Read full Bun dependency/audit handling. Preserve audit failures; no dependency installation or registry audit was executed.',
 'scripts/bump-version.mjs':'Read major/minor/patch version calculation and dry-run mutation boundary. No Formal AI version migration is needed from this helper.',
 'scripts/change-detection-renames.test.mjs':'Read real-Git rename coverage, including moves into excluded paths. Preserve both sides of rename classification; this upstream Bun suite was not executed.',
 'scripts/check-file-size.mjs':'Read full path-component exclusions and warning versus failure thresholds. Keep existing Formal AI global thresholds and unresolved warning inventory.',
 'scripts/check-file-size.test.mjs':'Read 901/1000/1001 boundary and source-extension controls; do not infer execution from source review.',
 'scripts/check-release-needed.mjs':'Read complete finite registry/release probes and normal-bump versus exact-version resume decisions. Preserve failed probes instead of emitting false successful outputs.',
 'scripts/check-release-needed.test.mjs':'Read complete localhost mock-server decision/probe controls. No upstream Bun tests or live NuGet API probes were executed in this review.',
 'scripts/check-web-archive.mjs':'Read complete report validation and archive lookup handling. Keep unknown lookup distinct from confirmed no snapshot; malformed/transport/provider failures remain explicit.',
 'scripts/create-github-release.mjs':'Read all release creation, rerun reconciliation, bounded notes and asset invocation paths. Its transitive release-assets helper is explicitly unread; public release acceptance is unverified.',
 'scripts/create-github-release.test.mjs':'Read injected-gh draft/public state and byte-identity controls. These upstream tests were not executed.',
 'scripts/detect-code-changes.mjs':'Read validated Git object arguments, PR/push paths, output ordering and initial-tree fallback. HEAD-parent versus a multi-commit push base is an unexecuted source question, not a reported defect.',
 'scripts/detect-code-changes.test.mjs':'Read exclusion cases; retain production seed data as source in Formal AI. Upstream test execution is not claimed.',
 'scripts/fetch-with-retries.mjs':'Read complete bounded network/429/5xx retry handling. AbortSignal.timeout remains associated with the response; the earlier possible cleared-at-headers deadline concern is dismissed by source inspection, without claiming a body-stall experiment or body-read retries.',
 'scripts/git-inputs.test.mjs':'Read adversarial Git reference validation controls. Use argv and validated object identities; no upstream Bun execution is claimed.',
 'scripts/git-push.mjs':'Read bounded atomic branch/tag publication, terminal branch-protection rejection and non-fast-forward reconciliation. Formal AI work on this branch retains forward-only history; this review does not authorize rebasing it.',
 'scripts/git-push.test.mjs':'Read real bare-remote races/protection tests. Actual upstream runtime execution is unverified.',
 'scripts/helper-globs.test.mjs':'Read bounded glob-expansion negative control and nested ESLint exclusion control. Do not remove nested runtime files to silence packaging warnings.',
 'scripts/issue-82-regressions.test.mjs':'Read source-size, retry classification, archive unknowns, author identity and invalid-changeset nonmutation controls. Existing issue 78 covers invalid parsing, distinct from the new valid-input output collision.',
 'scripts/link-failures.test.mjs':'Read mixed recovery and malformed/runtime-status controls. Preserve unrecovered failures and reject invalid lychee reports.',
 'scripts/links-workflow-policy.test.mjs':'Read explicit-success recovery guards, retry/archive ordering and helper versus job budgets. Upstream test source review is not executed validation.',
 'scripts/lint-workflows.sh':'Read tool presence checks and negative integration fixtures. Missing native integrations remain fatal; no new local tool installation was required.',
 'scripts/merge-changesets.mjs':'Reproduced: generated output may equal an existing valid input; ordinary write overwrites it and cleanup deletes it, exiting zero with no pending changeset. Four maintained Node controls cover unchanged behavior, disposable exclusive-create repair, noncollision ordering/major bump and invalid-input nonmutation. Evidence is supplied by Codex, not independent Formal AI reasoning.',
 'scripts/nuget-auth.mjs':'Read credential selection, bounded verification and redaction. Authentication is distinct from publishing authorization; token presence is not a verified release.',
 'scripts/nuget-auth.test.mjs':'Read injected credential selection and verification/redaction cases. No real credentials or publication were used.',
 'scripts/parse-changeset.mjs':'Read strict complete-file parsing and description/type requirements. All inputs are validated before merge mutation; malformed parsing is not the newly reproduced root cause.',
 'scripts/pipeline-gate.mjs':'Read expected jobs by event/ref and release mode; failed/missing/unexpected results are rejected. Diagnostics cannot reverse the verdict.',
 'scripts/pipeline-gate.test.mjs':'Read success, allowed-skip, missing/cancelled and unexpected-job controls. These Bun tests were not executed.',
 'scripts/preflight-credentials.mjs':'Read complete report/release decisions and required/advisory states. Repository readability is explicitly not protected-write verification. GitHub fetch has no explicit per-request deadline in source; this is an unexecuted observation, not a reported hang.',
 'scripts/preflight-credentials.test.mjs':'Read all injected API/credential/report-mode controls. Keep unknown required checks fatal while advisory checks remain honest; no live probes were executed.',
 'scripts/print-untrusted.mjs':'Read all 55 lines and use unchanged helper in the collision fixture. Fresh 128-bit stop/resume token and finally preserve untrusted-output boundaries; the source was reviewed, not replaced.',
 'scripts/print-untrusted.test.mjs':'Read all token renewal, same-stream, sink-failure and changeset integration controls. Source review does not establish Bun execution.',
 'scripts/process-types.d.ts':'Read injectable process/network boundary types. Small doubles are test interfaces, not evidence that actual process or provider calls succeeded.',
 'scripts/publish-fallback.test.mjs':'Read mock authentication fallback, immutable-artifact, unrelated-failure and bounded-attempt controls. No package publication occurred.',
 'scripts/publishing-configuration.test.mjs':'Read placeholder refusal and readability-versus-write-capability controls. Do not borrow a downstream package identity for template acceptance.',
 'scripts/push-nuget-package.mjs':'Read all 166 lines: actual auth rejection may trigger one same-artifact fallback after anonymous exact-version check; unknown state and unrelated failures remain fatal. No live publication or credential verification is claimed.',
 'scripts/push-nuget-package.test.mjs':'Read safe argv, missing credentials, redaction and fatal failure controls. No dotnet command was executed.',
 'scripts/recheck-broken-links.mjs':'Read all 537 lines: finite round-robin rechecks, per-request and whole-helper budgets, Retry-After, unchanged permanent failures, default-off verbosity, explicit all_recovered output and fail-safe workflow consumption. Its 593-line test file is still unread; no network experiment was executed.',
}
files=[];remaining=26*450;counts=collections.Counter();reviewedLines=0
for row in inventory:
 name=row['path'];data=(root/name).read_bytes()
 blob=hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()
 assert blob==row['gitBlob'] and len(data)==row['bytes']
 record={**row,'sha256':hashlib.sha256(data).hexdigest()}
 if name.startswith(('dev/log/','ci-logs/')):
  record.update(reviewStatus='inventoried-only-historical',readRanges=[],decision='Historical evidence/source snapshots remain semantically unread. Hash verification is not semantic review.')
  counts['historicalUnread']+=1
 else:
  try:lines=data.decode().splitlines()
  except UnicodeDecodeError:
   record.update(reviewStatus='inventoried-only-binary',readRanges=[],decision='Binary contents remain unread.')
   counts['binaryUnread']+=1;files.append(record);continue
  read=min(remaining,len(lines));remaining-=read
  if name=='scripts/recheck-broken-links.mjs':read=len(lines)
  record['lines']=len(lines);record['readRanges']=[[1,read]] if read else []
  if read==len(lines):
   counts['activeFullyRead']+=1;reviewedLines+=read
   record['reviewStatus']='active-source-fully-read'
   if name in notes:decision=notes[name]
   elif name.endswith('.test.mjs'):decision='Read complete upstream test source and its assertions as review context. This Bun suite was not executed; no production/runtime claim follows from reading it.'
   elif name.startswith('.changeset/'):decision='Read release intent/schema documentation. Preserve pending release data and highest requested bump; no template package was published.'
   elif name.startswith(('docs/','experiments/')):decision='Read complete documentation or diagnostic fixture. Historical claims/probes are context, not newly executed evidence; no direct Formal AI change is established by this file alone.'
   elif name.endswith(('.json','.yml','.yaml','.lock','.props','.csproj','.sln')):decision='Read complete configuration/lock/project source. Respect existing build and dependency policies; no install, native build or hosted execution was performed.'
   else:decision='Read complete source/documentation. Retain its identity for comparison; source reading alone does not justify a Formal AI behavior change or prove runtime acceptance.'
   record['decision']=decision
  else:
   assert read==0
   counts['activeUnread']+=1
   record.update(reviewStatus='inventoried-only-active',decision='Active source is still semantically unread. Transitive CI closure remains unfinished.')
 files.append(record)
assert len(files)==337 and remaining==0
assert counts=={'activeFullyRead':120,'activeUnread':38,'historicalUnread':179},dict(counts)
assert reviewedLines==11974,reviewedLines
document={
 'repository':'link-foundation/csharp-ai-driven-development-pipeline-template','commit':sourceCommit,
 'coverage':'PARTIAL. All 337 blobs are verified; 120 of 158 active text files are fully read (11974/18327 lines). 38 active files and all 179 historical blobs remain semantically unread. No complete C# repository or transitive CI closure is claimed.',
 'counts':dict(counts),'activeReadLines':reviewedLines,'activeTotalLines':18327,
 'readMethod':'Ordered active-source pages 1-26, 450 lines each, excluding dev/log and ci-logs, then scripts/recheck-broken-links.mjs lines 264-537. scripts/print-untrusted.mjs was also read separately. Commands and complete output are retained by the Formal AI driver archives.',
 'runtimeEvidence':'Only the new bounded Node changeset fixture and existing maintained Node entrypoint were executed here. Upstream Bun/.NET suites, publication, archive providers and hosted template runs were not executed.',
 'authorship':'All reasoning, supplied source edits and review decisions are Codex supplied; zero independent Formal AI reasoning credit.',
 'files':files,
}
target=Path('docs/case-studies/issue-1580/templates/csharp-partial-semantic-review.json')
assert not target.exists()
header={k:v for k,v in document.items() if k!='files'}
text=json.dumps(header,indent=2)[:-2]+',\n  "files": [\n'+',\n'.join('    '+json.dumps(row,ensure_ascii=False) for row in files)+'\n  ]\n}\n'
json.loads(text)
target.write_text(text)
print(json.dumps({'artifact':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'counts':dict(counts),'activeReadLines':reviewedLines,'reviewComplete':False},indent=2))
