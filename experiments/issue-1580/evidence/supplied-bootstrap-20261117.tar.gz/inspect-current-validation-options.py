from pathlib import Path
import json
rows=Path('.github/workflows/release.yml').read_text().splitlines()
for n,line in enumerate(rows):
    if line=='  native-type-check:':
        for k in range(n,min(n+100,len(rows))):print(f'{k+1}: {rows[k]}')
base=Path('experiments/issue-1580/evidence/checks/main-merge-444575f2')
path=base/'all-local-gates.json'
if path.exists():
    data=json.loads(path.read_text());print('RESULT',json.dumps({k:v for k,v in data.items() if k!='gateLogs'}))
else:print('PROGRESS',Path('/tmp/issue-1580-research/merged-444575f2-all-local-gates.log').read_text()[-1400:])
for command in ['ci','native','test']:
    print('MANUAL WORKFLOWS',command,[str(p) for p in Path('.github/workflows').glob('*.yml') if 'workflow_dispatch:' in p.read_text() and command in p.name])
