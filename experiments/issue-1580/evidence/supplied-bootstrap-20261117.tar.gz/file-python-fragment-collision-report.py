from pathlib import Path
import datetime,gzip,hashlib,json,subprocess

def run(args):
    return subprocess.run(args,capture_output=True,text=True,check=True).stdout

repository='link-foundation/python-ai-driven-development-pipeline-template'
title='Manual changelog fragment creation silently overwrites an earlier entry in the same second'
body_path=Path('experiments/issue-1580/upstream/python-fragment-collision-report.md')
body=body_path.read_text()
assert hashlib.sha256(body.encode()).hexdigest()=='1b68c364b10a8ecd38140841e303997d71cf606164bc0549e19da3a0e6dc4a1c'
pages=json.loads(run(['gh','api',f'repos/{repository}/issues?state=all&per_page=100','--paginate','--slurp']))
issues=[item for page in pages for item in page]
assert len(issues)==156
assert not any(row['title']==title for row in issues)
url=run(['gh','issue','create','--repo',repository,'--title',title,'--body-file',str(body_path)]).strip()
Path('/tmp/issue-1580-research/python-fragment-filed-url.txt').write_text(url+'\n')
posted=json.loads(run(['gh','issue','view',url,'--json','body,title,url,number,createdAt']))
assert posted['title']==title and posted['body']==body and posted['url']==url
evidence=Path('experiments/issue-1580/evidence/checks/python-fragment-collision')
(evidence/'filed-report.json').write_text(json.dumps({
    **posted,'bodySha256':hashlib.sha256(posted['body'].encode()).hexdigest(),
    'evidenceCommit':'9c018344df2e6b09a0f2496897b14a002dad62f4',
    'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'upstreamRepairClaimed':False,
},indent=2)+'\n')
identities_path=Path('experiments/issue-1580/upstream/template-report-identities.json')
identities=json.loads(identities_path.read_text())
assert len(identities)==8 and not any(row['url']==url for row in identities)
identities.append({'repository':repository,'title':title,'url':url,'bodyFile':body_path.name,'evidenceCommit':'9c018344df2e6b09a0f2496897b14a002dad62f4'})
identities_path.write_text(json.dumps(identities,indent=2)+'\n')
filed_path=Path('experiments/issue-1580/upstream/filed-issues.txt')
filed=filed_path.read_text()
assert url not in filed
filed_path.write_text(filed+url+'\n')
raw=Path('/tmp/issue-1580-research/python-fragment-final-upstream-issues.json').read_bytes()
(evidence/'final-duplicate-issues.json.gz').write_bytes(gzip.compress(raw,mtime=0))
print(json.dumps({'filedReport':url,'bodySha256':hashlib.sha256(body.encode()).hexdigest(),'evidenceAlreadyPublished':True,'upstreamRepairClaimed':False},indent=2),flush=True)
