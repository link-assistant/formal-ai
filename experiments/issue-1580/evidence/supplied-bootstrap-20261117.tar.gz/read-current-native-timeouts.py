from pathlib import Path
import re
p=Path('/tmp/issue-1580-research/main-444575f2-44163378148.log')
for i,line in enumerate(p.read_text().splitlines()):
 if re.search(r'1080|deadline.*(?:expired|reached)|Terminated|timed out|time limit|exit code 124',line,re.I):
  print(str(i+1)+': '+line)
