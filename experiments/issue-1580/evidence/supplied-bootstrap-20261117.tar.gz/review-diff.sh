set -eu
git diff -- scripts/documentation-only-ci-policy.mjs rust/tests/web/documentation-only-ci-policy.test.mjs rust/src/solver.rs > /tmp/issue-1580-research/current-fixes.diff
sed -n '1,220p' /tmp/issue-1580-research/current-fixes.diff
sed -n '1,120p' experiments/issue-1580/archive-evidence.py
rg --files changelog.d | rg 1580
