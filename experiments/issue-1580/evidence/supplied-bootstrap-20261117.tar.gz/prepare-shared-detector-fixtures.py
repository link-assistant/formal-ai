from pathlib import Path
import json,hashlib,shutil
root=Path('/tmp/issue-1580-research/templates')
manifest=json.loads((root/'manifest.json').read_text())
selections={
 'java':['scripts/detect-code-changes.mjs','scripts/github-actions-log.mjs'],
 'python':['scripts/detect_code_changes.py'],
 'php':['scripts/detect-code-changes.php','scripts/bootstrap.php','scripts/src/Actions.php','scripts/src/ChangeDetector.php','scripts/src/Process.php','scripts/src/ProcessResult.php'],
}
for language,files in selections.items():
    repo=next(x for x in manifest if x['repo'].split('/')[1].startswith(language+'-'))
    inventory=json.loads((root/(language+'-complete-inventory.json')).read_text())
    files+= [x['path'] for x in inventory if x['path'].lower().startswith(('license','copying')) and '/' not in x['path']]
    destination=Path('experiments/issue-1580/fixtures')/(language+'-template')
    identities=[]
    for name in files:
        item=next(x for x in inventory if x['path']==name)
        content=(root/(language+'-complete')/name).read_bytes()
        blob=hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()
        assert blob==item['gitBlob'],name
        target=destination/name
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(content)
        identities.append({'path':name,'gitBlob':blob,'sha256':hashlib.sha256(content).hexdigest()})
    (destination/'source.json').write_text(json.dumps({'repository':repo['repo'],'commit':repo['sha'],'files':identities},indent=2)+'\n')
    print(language,repo['sha'],len(identities),'verified unmodified fixture files')
