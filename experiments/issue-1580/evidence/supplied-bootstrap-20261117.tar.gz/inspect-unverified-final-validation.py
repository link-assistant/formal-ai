from pathlib import Path
import json

base = Path('/tmp/issue-1580-research/unverified-child-status-final')
pid = json.loads((base / 'process.json').read_text())['pid']
stat = Path(f'/proc/{pid}/stat')
state = stat.read_text().split()[2] if stat.exists() else 'absent'
print(json.dumps({'pid':pid,'state':state,'finished':(base/'outcome.json').exists(),'memoryBytes':int(Path('/sys/fs/cgroup/memory.current').read_text()),'memoryLimitBytes':int(Path('/sys/fs/cgroup/memory.max').read_text())}))
for row in json.loads((base/'progress.json').read_text()):
    print(json.dumps({key:row[key] for key in ['name','exitCode','durationSeconds','rawLines','rawSha256']}))
gate = base/'all-local-gates.log'
if gate.exists():
    lines=gate.read_text().splitlines()
    print(json.dumps({'gateCounts':{status:sum(line.startswith(status+' ') for line in lines) for status in ['PASS','SKIP','FAIL']},'failures':[line for line in lines if line.startswith('FAIL ')],'tail':lines[-5:]}))
for name in ['parity-fixtures-write','meta-executor-tests','factual-qa-tests','parity-fixtures-check','rustfmt']:
    path=base/(name+'.log')
    if path.exists():
        print('FULL LOG '+name)
        print(path.read_text())
if (base/'outcome.json').exists():
    report=json.loads((base/'outcome.json').read_text())
    print(json.dumps({key:value for key,value in report.items() if key not in ['checks','archives','perGateLogs']},indent=2))
    print('FULL AGGREGATE')
    print(gate.read_text())
