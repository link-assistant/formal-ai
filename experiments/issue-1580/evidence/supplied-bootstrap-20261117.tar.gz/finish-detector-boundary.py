from pathlib import Path
p=Path('scripts/detect-code-changes.rs')
s=p.read_text()
old='''        .filter(|line| line.starts_with("parent "))
        .count();
    let (base, head, description) = comparison_for_event(event, parents > 1, before);'''
new='''        .filter(|line| line.starts_with("parent "))
        .count();
    if event == "pull_request" && parents != 2 {
        return Err(std::io::Error::other(
            "pull_request requires the complete synthetic merge comparison",
        ));
    }
    let (base, head, description) = comparison_for_event(event, parents > 1, before);'''
assert s.count(old)==1
s=s.replace(old,new)
s=s.replace('''            assert!(
                output.status.success(),
                "{}",
                String::from_utf8_lossy(&output.stderr)
            );''','''            assert!(output.status.success(), "{output:?}");''',1)
s=s.replace('git(&["commit", "--quiet", "-m", "initial"]);','git(&["commit", "--quiet", "-m", "initial\\n\\nparent forged header"]);',1)
s=s.replace('''        let parent = git(&["rev-parse", "HEAD"]);
        git(&["commit", "--quiet", "--allow-empty", "-m", "empty"]);''','''        assert!(super::get_changed_files_in_repo(&repo, "pull_request", None).is_err());
        let parent = git(&["rev-parse", "HEAD"]);
        git(&["commit", "--quiet", "--allow-empty", "-m", "empty"]);
        assert!(super::get_changed_files_in_repo(&repo, "pull_request", None).is_err());''',1)
old='''        fs::remove_file(
            repo.join(".git/objects")
                .join(&parent[..2])
                .join(&parent[2..]),
        )
        .unwrap();'''
new='''        let object = format!(".git/objects/{}/{}", &parent[..2], &parent[2..]);
        fs::remove_file(repo.join(object)).unwrap();'''
assert s.count(old)==1
p.write_text(s.replace(old,new))
p=Path('/tmp/issue-1580-research/php-change-detection-report.md')
p.write_text(p.read_text().replace('scripts/lib/ChangeDetector.php','scripts/src/ChangeDetector.php'))
print('Reject incomplete PR observations; add native controls; correct PHP source link.')
