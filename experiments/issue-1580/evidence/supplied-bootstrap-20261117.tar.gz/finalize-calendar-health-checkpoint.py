from pathlib import Path
import json
root=Path('/tmp/gh-issue-solver-1794900398048')
path=root/'docs/case-studies/issue-1580/calendar-seed-checkpoint.md'
text=path.read_text()
text=text.replace('health/cache fixture additions below; final combined-source gates and next-head\nhosted checks remain pending.', 'health/cache fixture additions below. The final combined-source run also passes\n86 checks with 52 explicit exclusions and zero failures in 660.018 seconds, using\na 256 MiB Node heap cap and no native execution. All 86 detailed log hashes and\nall 14 checked source hashes are verified. Next-head hosted checks remain pending.')
text=text.replace('`experiments/issue-1580/evidence/checks/health-cache-fixtures/`. Final full gates\nand hosted checks for this combined batch are tracked separately.', '`experiments/issue-1580/evidence/checks/health-cache-fixtures/`. Final full gate\nevidence is under its `all-gates-final/` directory; hosted checks for the next\nhead remain separate from this local result.')
path.write_text(text)
path=root/'experiments/issue-1580/work-plan.md';text=path.read_text()
text=text.replace('files to the fast PR inventory and record the main-only failures. Final combined\nshared-data gates and next-head hosted checks remain pending.', 'files to the fast PR inventory and record the main-only failures. Final combined\nshared-data gates pass 86 checks with 52 explicit exclusions and zero failures\nin 660.018 seconds. Verify all 86 detailed log hashes and all 14 source hashes;\nno source differs from the tested bytes. Next-head hosted checks remain pending.')
path.write_text(text)
body='''Fixes #1580

CI missed calendar seed integrity failures and retained fixtures that disagreed with the supported health schema and default-on source reads. This draft repairs those failures together with the earlier client and CI regressions, preserving failing-before evidence and exact source identities. The complete issue remains unfinished; keep this PR draft and unmerged.

The latest changes give the calendar addition cue a unique meaning, expand 21 packed alias rows into 55 scalar rows without losing surfaces or order, and update JavaScript/Rust consumers and generated mirrors. They preserve the existing calendar response intent and native calendar/currency CI coverage. Health tests cover both memory access modes; cache fixtures explicitly disable live reads and restore the caller's setting. Three existing health/cache files join the fast inventory, now 243 files. Stale TypeScript mirrors are regenerated with the maintained translator.

Earlier changes retain bounded cache diagnostics, enforce request-local output constraints, decode path-bound OpenCode Read results, preserve calendar clock spans, and avoid empty startup logs during writability checks. They also repair source-test placement, causal-vocabulary expectations, lazy tool-binding diagnostics and generated native-program witnesses. Main `015a683197c89e8f74375b097e8dd06a57dcea8f` is merged; executable witness values and existing test cases are preserved.

Reproduction and verification:

- [Main pipeline 44188508650](https://github.com/link-assistant/formal-ai/actions/runs/44188508650), lines 65552–65583: duplicate calendar meaning and packed aliases. The complete JavaScript calendar/currency file passes 40/42 before repair and **43/43 afterward**, retaining all original cases and adding six alias prompts. Rust formatting passes; native candidate behavior remains unexecuted locally.
- [Main Layered CI 44188508228](https://github.com/link-assistant/formal-ai/actions/runs/44188508228), jobs `134411832462` and `134411832372`: stale health and cache expectations. Each affected file passes 8/9 before repair. Afterward, **24/24 health/cache tests, 15/15 fast-profile tests and 4/4 ledger tests pass**, with zero mock transport calls and no actual network I/O.
- Maintained TypeScript parity verifies **717 sources** and all **12 translator tests** pass. The final combined-source JavaScript gate run passes **86 checks**, with **52 explicit native/CI-context exclusions**, zero failures, a 256 MiB Node heap cap, and all 86 detailed log hashes and 14 checked source hashes verified.
- Earlier merged-source focused verification passes **163 tests across 15 checks**, with zero failures or skips; package mirroring verifies **481 byte-equal demands**. These earlier results are recorded separately from the latest batch.

Focused replay commands (run files individually):

```sh
timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/issue-1589-calendar-currency.test.mjs
timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/server-memory-schema.test.mjs
timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/hive-work-item-consumer.test.mjs
node experiments/formal_ai_subagent/local-gates.mjs
```

The published input `2ec6ef93` has 21 successful workflows and two failures. Both initial failures are checkout curl-28 failures for the six-byte `.bun-version` blob. One failed-job retry leaves [pipeline 44197053206](https://github.com/link-assistant/formal-ai/actions/runs/44197053206) failing checkout; [Layered CI 44197052235](https://github.com/link-assistant/formal-ai/actions/runs/44197052235) proceeds to the stale TypeScript mirror repaired here. All original attempts and hashes are retained. Hosted checks for the next head must be verified separately.

The [calendar/cache checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/calendar-seed-checkpoint.md), [runtime checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/runtime-fixture-checkpoint.md), and [work plan](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/experiments/issue-1580/work-plan.md) retain evidence and unfinished criteria. These include native failures and shard timeouts, benchmark floors, full semantic review/applicability decisions for all eight templates, remaining dependency migrations and warnings, historical cache/Docker and required-context reproduction, and live delivery/model identity. Supplied-passage decomposition still loses parent context. Java historical review reaches pages 1–37/254, 34 complete files and one partial; the remaining review is unfinished. Upstream reports, source reading and skipped build jobs do not establish those criteria. Independent Formal AI reasoning acceptance remains **0/20**; supplied commands, patches and scripts earn zero independent authorship credit.
'''
target=Path('/tmp/issue-1580-research/calendar-health-pull-request-description.md');target.write_text(body)
print(json.dumps({'checkpointLines':len((root/'docs/case-studies/issue-1580/calendar-seed-checkpoint.md').read_text().splitlines()),'pullRequestBody':str(target),'unfinished':True}))
