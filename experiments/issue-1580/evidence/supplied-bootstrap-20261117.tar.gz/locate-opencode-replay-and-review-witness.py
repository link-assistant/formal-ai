import pathlib
import subprocess

subprocess.run(['rg','--no-ignore','-l','issue-1580-opencode-read-envelope','rust/tests/web','scripts'],check=True)
path=pathlib.Path('/tmp/issue-1580-research/refresh-058e9bef-reviewed-witness.py')
lines=path.read_text().splitlines()
print(f'FILE {path} total={len(lines)}')
for index,line in enumerate(lines[:150],1):
    print(f'{index}: {line}')
subprocess.run(['git','diff','--stat'],check=True)
