import gzip
import json
import pathlib
import re
import sys

root = pathlib.Path.cwd()
directory = root / "experiments/issue-1580/evidence/ci/main-512ce428"
ansi = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
pattern = re.compile(r"(^|\s)(?:not ok\b|✖|FAIL\b|FAILED\b|error(?:\[[^]]+\])?:|thread .+panicked at|AssertionError|test result: FAILED)|##\[error\]|::error::|timed out|exceeded.*(?:budget|timeout)", re.I)
for run_id in ("44117975432", "44117974304"):
    target = directory / (run_id + "-failure-contexts.txt.gz")
    lines = []
    matches = []
    with gzip.open(directory / (run_id + ".log.gz"), "rt") as source:
        for number, raw in enumerate(source, 1):
            clean = ansi.sub("", raw.rstrip())
            fields = clean.split("\t", 2)
            if len(fields) < 3:
                lines.append((number, clean))
                continue
            job, step, body = fields
            body = re.sub(r"^\d{4}-\d\d-\d\dT\S+\s", "", body)
            lines.append((number, job + " | " + step + " | " + body))
            if pattern.search(body) and not body.startswith(("shell:", "if ", "echo ", "curl ", "#", "✔")):
                matches.append(len(lines) - 1)
    selected = set()
    for index in matches:
        selected.update(range(max(0, index - 4), min(len(lines), index + 9)))
    chunks = []
    last = -2
    for index in sorted(selected):
        if index != last + 1:
            chunks.append("---")
        number, line = lines[index]
        chunks.append(str(number) + ": " + line)
        last = index
    with gzip.open(target, "wt") as sink:
        sink.write("\n".join(chunks) + "\n")
    print(json.dumps({"run": run_id, "matches": len(matches), "contextLines": len(chunks), "file": str(target.relative_to(root))}))
    if len(sys.argv) > 1 and sys.argv[1] == run_id:
        start = int(sys.argv[2]) if len(sys.argv) > 2 else 1
        size = min(int(sys.argv[3]) if len(sys.argv) > 3 else 180, 1500)
        for number, line in enumerate(chunks[start - 1:start - 1 + size], start):
            print(str(number) + " :: " + line)
    elif len(sys.argv) == 1:
        for index in matches[:18]:
            number, line = lines[index]
            print(str(number) + ": " + line)
