set -eu
timeout 600 node --test --test-concurrency=1 rust/tests/web/sccache-outage-fallback.test.mjs > /tmp/issue-1580-research/cache-log-after.log 2>&1
tail -n 18 /tmp/issue-1580-research/cache-log-after.log
/tmp/issue-1580-research/shellcheck-v0.11.0/shellcheck scripts/check-sccache-write-health.sh > /tmp/issue-1580-research/cache-log-shellcheck.log 2>&1
cat /tmp/issue-1580-research/cache-log-shellcheck.log
