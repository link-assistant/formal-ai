from pathlib import Path
import json, subprocess

root = Path('/tmp/issue-1580-research/templates/python-complete')
inventory = json.loads(Path('/tmp/issue-1580-research/python-active-source-inventory.json').read_text())
print('RELATED UPSTREAM FILES')
for row in inventory['active']:
    if any(s in row['path'] for s in ['release_naming', 'format_release', 'test_file_size']):
        print(row['path'], row.get('lines'), row.get('sha256'))
print('LOCAL FORMATTING SOURCES')
paths = subprocess.run(['rg', '--files', 'scripts', 'rust/tests/web', 'experiments/issue-1580'], capture_output=True, text=True, check=True).stdout.splitlines()
print('\n'.join(path for path in paths if any(s in path for s in ['format-release', 'release-naming', 'template-report-identities', 'semantic-review']))[:4000])
print('UPSTREAM REPORT REGISTRY')
registry = json.loads(Path('experiments/issue-1580/upstream/template-report-identities.json').read_text())
print(json.dumps(registry, indent=2)[:7000])
print('RELEASE NAMING IMPORTS AND FUNCTIONS')
for n,line in enumerate((root/'scripts/release_naming.py').read_text().splitlines(),1):
    if n < 65 or line.startswith('def '):
        print(n,line)
