from pathlib import Path
import base64,hashlib,json,shutil,subprocess
directory=Path('experiments/issue-1580/fixtures/python-template')
metadata=json.loads((directory/'source.json').read_text());relative='scripts/audit-npm-locks.sh'
assert not any(row['path']==relative for row in metadata['files'])
response=subprocess.run(['gh','api',f'repos/{metadata["repository"]}/contents/{relative}?ref={metadata["commit"]}'],capture_output=True,check=True)
remote=json.loads(response.stdout);raw=base64.b64decode(remote['content'])
local=Path('/tmp/issue-1580-research/templates/python-complete')/relative
assert local.read_bytes()==raw
blob=hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest();assert blob==remote['sha']
(directory/relative).write_bytes(raw)
entry={'path':relative,'gitBlob':blob,'sha256':hashlib.sha256(raw).hexdigest()}
metadata['files'].append(entry);(directory/'source.json').write_text(json.dumps(metadata,indent=2)+'\n')
shutil.copyfile('/tmp/issue-1580-research/template-python-audit-integrity.test.mjs','experiments/issue-1580/template-python-audit-integrity.test.mjs')
p=Path('rust/tests/web/issue-1580-template-observations.test.mjs')
p.write_text(p.read_text()+"import '../../../experiments/issue-1580/template-python-audit-integrity.test.mjs';\n")
print(json.dumps({'repository':metadata['repository'],'commit':metadata['commit'],**entry}))
