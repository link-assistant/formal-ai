from pathlib import Path
import base64
import datetime
import gzip
import hashlib
import json
import subprocess

repository = 'link-foundation/python-ai-driven-development-pipeline-template'
directory = Path('experiments/issue-1580/evidence/checks/python-fragment-collision')
temporary = Path('/tmp/issue-1580-research/python-fragment-collision')
for name in ['upstream-issues.json.gz', 'recent-merged-changelog-pulls.json']:
    (directory / name).write_bytes((temporary / name).read_bytes())
pages = json.loads(gzip.decompress((directory / 'upstream-issues.json.gz').read_bytes()))
items = [item for page in pages for item in page]
for number in [100, 101, 148, 152]:
    item = next(item for item in items if item['number'] == number)
    print('\nRELATED', number, item['title'], item['html_url'])
    print(item.get('body') or '(no body)')
    if number in [101, 148, 152]:
        raw = subprocess.run(['gh', 'api', f'repos/{repository}/pulls/{number}/files?per_page=100', '--paginate', '--slurp'], check=True, capture_output=True).stdout
        (directory / f'related-pull-{number}-files.json.gz').write_bytes(gzip.compress(raw, mtime=0))
        files = [item['filename'] for page in json.loads(raw) for item in page]
        print('CHANGED PATHS', files)
        print('CHANGES MANUAL CREATOR', 'scripts/create_manual_changeset.py' in files)
raw = subprocess.run(['gh', 'api', f'repos/{repository}/contents/scripts/create_manual_changeset.py?ref=main'], check=True, capture_output=True).stdout
response = json.loads(raw)
source = base64.b64decode(response['content'])
expected = Path('experiments/issue-1580/fixtures/python-template/scripts/create_manual_changeset.py').read_bytes()
assert source == expected and response['sha'] == '24f4c2b023e08ebb9397c497f2a12f95dd88a93e'
(directory / 'latest-source.json.gz').write_bytes(gzip.compress(raw, mtime=0))
record = {
    'repository': repository,
    'checkedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'pinnedCommit': 'c532c173801dfb12e681b0730c4abbf93aefd0ca',
    'currentMainFileGitBlob': response['sha'],
    'currentMainFileSha256': hashlib.sha256(source).hexdigest(),
    'allIssuesAndPullRequestsSearched': len(items),
    'exactKeywords': ['collision', 'overwrite', 'create_manual_changeset', 'manual fragment'],
    'narrowMatches': [79, 66],
    'conclusion': 'No matching fragment-creation collision report found. Validator replacement handling (#100/#101), release attestation (#148), and dependency locking (#152) concern different boundaries. Current main helper is byte-identical to the tested pin.',
    'upstreamRepairClaimed': False,
}
(directory / 'duplicate-and-source-check.json').write_text(json.dumps(record, indent=2) + '\n')
print('\nCHECK', json.dumps(record, indent=2))
path = Path('docs/case-studies/issue-1580/templates/README.md')
lines = path.read_text().splitlines()
assert len(lines) <= 200
print('\nTEMPLATE REVIEW README', len(lines), 'lines')
for number, line in enumerate(lines, 1):
    print(f'{number}: {line}')
