from pathlib import Path
import subprocess

def show(name, start, end):
    lines = Path(name).read_text().splitlines()
    print(f"{name} ({len(lines)} lines), {start}-{end}")
    for i in range(start - 1, min(end, len(lines))):
        print(f"{i + 1}: {lines[i]}")

print(subprocess.run(['git', 'status', '--short'], capture_output=True, text=True).stdout)
show('.github/workflows/layered-ci.yml', 400, 480)
show('experiments/issue-1580/template-python-fragment-integrity.test.mjs', 1, 140)
show('experiments/issue-1580/template-python-git-observation.test.mjs', 1, 140)
print(subprocess.run(['rg', '-n', 'shard|duration', 'scripts/run-javascript-tests.mjs', 'scripts/run-js-test-suite.mjs', 'rust/tests/web/fast-pull-request-production-profile.test.mjs'], capture_output=True, text=True).stdout)
