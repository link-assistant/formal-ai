set -eu
cat /tmp/issue-1580-research/archive-round-bootstrap.py
sed -n '1,160p' experiments/issue-1580/archive-evidence.py
