from pathlib import Path
import subprocess
paths=subprocess.check_output(['rg','--files','rust/src'],text=True).splitlines()
print('NATIVE SOURCE PATHS')
for p in paths:
    if any(s in p for s in ['with_formal','web_request','client_integration','solver_config']):print(p)
for args in [
 ['rg','-n','temporary server in agent mode|FORMAL_AI_LOG_STDERR','rust/src','rust/tests/integration/with_formal_ai.rs','.github/workflows'],
 ['rg','-n','offline|live_fetch|set_var|Mutex|serial','rust/tests/unit/web_requests.rs','rust/src/solver_config.rs'],
 ['rg','-n','Live fetching is off by default|Live fetching is enabled','js','rust/src','data/seed'],
]:
    r=subprocess.run(args,text=True,capture_output=True)
    print('COMMAND',args,'EXIT',r.returncode)
    print(r.stdout,r.stderr)
