from pathlib import Path
import subprocess,json,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');report=json.loads((root/'experiments/issue-1580/evidence/checks/native-retrieval-contract-validation/result.json').read_text());assert report['complete'];branch=subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip();assert branch=='issue-1580-8d61a32a61e1'
paths=list(report['sourceHashes'])
for p,h in report['sourceHashes'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=root,text=True).splitlines();assert sorted(staged)==sorted(paths),staged
subprocess.run(['git','commit','-m','Preserve external lookup traces and replay offline routing contracts'],cwd=root,check=True)
print(subprocess.check_output(['git','show','--stat','--oneline','HEAD'],cwd=root,text=True))
