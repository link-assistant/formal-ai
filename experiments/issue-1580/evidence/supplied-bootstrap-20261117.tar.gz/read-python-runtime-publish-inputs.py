from pathlib import Path
for name,limit in [('/tmp/issue-1580-research/push-python-fragment-batch.py',140),('/tmp/issue-1580-research/archive-round-bootstrap.py',100),('experiments/issue-1580/template-python-runtime.test.mjs',130)]:
 p=Path(name);print(name)
 for i,line in enumerate(p.read_text().splitlines()[:limit],1):print(f'{i}: {line}')
