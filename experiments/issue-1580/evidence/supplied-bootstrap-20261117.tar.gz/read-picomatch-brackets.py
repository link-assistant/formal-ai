from pathlib import Path
p=Path('/tmp/gh-issue-solver-1794900398048/packages/picomatch-compat/lib/parse.js')
lines=p.read_text().splitlines()
for start,end in [(1,90),(600,860),(1160,1260)]:
    print(f'\nparse.js {start}-{end}')
    for i in range(start-1,end):
        print(f'{i+1}: {lines[i]}')
