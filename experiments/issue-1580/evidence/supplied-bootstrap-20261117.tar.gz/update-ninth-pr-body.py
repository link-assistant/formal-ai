from pathlib import Path
import json,subprocess
repo='link-assistant/formal-ai'
pr=json.loads(subprocess.check_output(['gh','pr','view','1581','--repo',repo,'--json','body,title,isDraft,headRefOid'],text=True))
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert pr['isDraft'] and pr['headRefOid']==head
body=pr['body']
old='The latest batch adds a real-Git reproduction of Java release tags published after a rejected release commit, with successful-release controls. It also records the complete active Java source review.'
new='The latest batch repairs the template review graph\'s omission of GitHub `$/` self-repository references, with nested-action/workflow and negative regressions. The earlier Java batch adds a real-Git reproduction of release tags published after a rejected release commit, with successful-release controls, and records the complete active Java source review.'
assert body.count(old)==1
body=body.replace(old,new)
old='The maintained template suite passes sixteen tests locally (no language-runtime skips), including five Java release-integrity cases with real local Git repositories; the focused Java suite also passes all five cases.'
new='The maintained template suite passes twenty-one tests locally (no language-runtime skips), including five Java release-integrity cases with real local Git repositories and five reference-graph cases. The focused graph and Java suites each pass five cases. Three new self-repository cases fail before the repair. Same-pin graph regeneration adds thirteen explicit C#/Python edges and zero files; the conservative inventories already included those targets.'
assert body.count(old)==1
body=body.replace(old,new)
old='All 24 workflows on published heads `09021cb30e` and `e6627385d` completed successfully. The new Java review/regression batch at `078849576b` is under verification.'
new='All 24 workflows on each published head `09021cb30e`, `e6627385d` and `078849576b` completed successfully. The self-repository reference batch at `'+head[:10]+'` is under verification. C# semantic review is partial; full remaining repository reviews stay open.'
assert body.count(old)==1
body=body.replace(old,new)
assert body.startswith('Fixes #1580\n') and 'Keep this PR draft and unmerged' in body
path=Path('/tmp/issue-1580-research/pr-ninth-body.md')
path.write_text(body)
subprocess.run(['gh','pr','edit','1581','--repo',repo,'--title',pr['title'],'--body-file',str(path)],check=True)
print('Updated draft PR for',head)
