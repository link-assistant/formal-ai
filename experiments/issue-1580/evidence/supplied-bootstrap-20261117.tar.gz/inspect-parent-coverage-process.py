from pathlib import Path
import gzip, json, sys

label = sys.argv[1] if len(sys.argv) > 1 else 'parent-answer-coverage-probe'
assert label in ['parent-answer-coverage-probe', 'parent-answer-coverage-rerun']
base = Path('/tmp/issue-1580-research') / label
pid = json.loads((base / 'process.json').read_text())['pid']
stat_path = Path(f'/proc/{pid}/stat')
fields = stat_path.read_text().split(') ', 1)[1].split() if stat_path.exists() else None
report = {'pid': pid, 'state': fields[0] if fields else 'absent', 'stdoutLines': len((base / 'stdout.log').read_text().splitlines()), 'stderr': (base / 'stderr.log').read_text()[-6000:]}
if fields:
    report['encodedExitCode'] = fields[-1]
    report['status'] = [line for line in Path(f'/proc/{pid}/status').read_text().splitlines() if line.startswith(('VmPeak:', 'VmHWM:', 'VmRSS:', 'Threads:'))]
artifact = Path('experiments/issue-1580/evidence/checks/passage-routing-probe/parent-answer-coverage.json.gz')
if artifact.exists():
    data = json.loads(gzip.decompress(artifact.read_bytes()))
    report['qualification'] = data['qualification']
    report['rowCount'] = len(data['rows'])
    report['coverageEvents'] = [{ 'name': row['name'], 'events': row['outcomes'][2]['coverageEvents']} for row in data['rows']]
print(json.dumps(report, indent=2))
