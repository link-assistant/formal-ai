from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
scratch=Path('/tmp/issue-1580-research')
base=scratch/'push-main-015a6831-preflight';base.mkdir(exist_ok=False)
repo='link-assistant/formal-ai';branch='issue-1580-8d61a32a61e1'
def execute(label,command):
    result=subprocess.run(command,capture_output=True);raw=result.stdout+result.stderr
    (base/(label+'.log.gz')).write_bytes(gzip.compress(raw,mtime=0))
    assert result.returncode==0,(label,result.returncode,raw.decode()[-2000:])
    return result.stdout.decode().strip()
def query(label,command):return json.loads(execute(label,command))
assert execute('branch',['git','branch','--show-current'])==branch
assert not execute('status',['git','status','--porcelain'])
execute('fetch',['git','fetch','--no-tags','origin','main',branch])
head=execute('head',['git','rev-parse','HEAD'])
main=execute('main',['git','rev-parse','origin/main'])
remote=execute('remote',['git','rev-parse','origin/'+branch])
execute('main-is-merged',['git','merge-base','--is-ancestor',main,head])
execute('previous-head-is-ancestor',['git','merge-base','--is-ancestor',remote,head])
assert remote=='7780c70715df515a8ffcb085bff0902b4489bb94',remote
changed=execute('post-validation-paths',['git','diff','--name-only','584b5f57f8d5b1ec6511def65273c78da0caca7b',head]).splitlines()
assert changed and all(path.startswith(('docs/case-studies/issue-1580/','experiments/issue-1580/')) for path in changed)
pr=query('pull-request',['gh','pr','view','1581','--repo',repo,'--json','headRefOid,isDraft,url'])
assert pr['headRefOid']==remote and pr['isDraft']
runs=query('runs',['gh','run','list','--repo',repo,'--branch',branch,'--limit','100','--json','databaseId,workflowName,status,conclusion,createdAt,headSha'])
current=[row for row in runs if row['headSha']==remote]
assert len(current)==23 and all(row['status']=='completed' for row in current),current
failures=[row for row in current if row['conclusion']!='success']
assert len(failures)==1 and failures[0]['databaseId']==44180825006,failures
counts={}
for label,endpoint in [('issue-comments','issues/1580/comments'),('pull-request-comments','issues/1581/comments'),('inline-comments','pulls/1581/comments'),('reviews','pulls/1581/reviews')]:
    entries=query(label,['gh','api','repos/'+repo+'/'+endpoint,'--paginate']);counts[label]=len(entries)
assert counts=={'issue-comments':1,'pull-request-comments':9,'inline-comments':0,'reviews':0},counts
for status in ['in_progress','queued']:
    entries=query(status,['gh','run','list','--repo',repo,'--branch',branch,'--status',status,'--limit','100','--json','databaseId,workflowName,headSha'])
    assert not entries,(status,entries)
execute('push',['git','push','origin','HEAD:refs/heads/'+branch])
assert execute('published',['git','ls-remote','origin','refs/heads/'+branch]).split()[0]==head
assert not execute('final-status',['git','status','--porcelain'])
receipt={'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCheckpoint':'584b5f57f8d5b1ec6511def65273c78da0caca7b','publishedHead':head,'previousRemoteHead':remote,'mergedMain':main,'previousHeadCompletedRuns':len(current),'previousHeadCollectedFailure':failures,'feedbackCounts':counts,'pullRequest':pr['url'],'isDraft':True,'independentAuthorshipCredit':0}
(base/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
