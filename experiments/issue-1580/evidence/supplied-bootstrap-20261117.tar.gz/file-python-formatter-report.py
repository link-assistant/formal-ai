from pathlib import Path
import base64,datetime,hashlib,json,subprocess
repository='link-foundation/python-ai-driven-development-pipeline-template'
title='Release formatter corrupts literal escapes in code examples before updating notes'
directory=Path('experiments/issue-1580/evidence/checks/python-release-formatting/publication')
preflight=json.loads((directory/'preflight.json').read_text())
assert preflight['currentMain']=='c532c173801dfb12e681b0730c4abbf93aefd0ca' and not preflight['changedIds']
elapsed=datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(preflight['observedAt'])
assert elapsed.total_seconds()<900,elapsed
body_path=Path('experiments/issue-1580/upstream/python-release-formatting-report.md')
body=body_path.read_text();digest=hashlib.sha256(body.encode()).hexdigest()
assert digest==preflight['reportBodySha256']=='bdd518a220ef48becb19dec2977bb279486d0118635468d5018a454cb149db99'
url_path=Path('/tmp/issue-1580-research/python-formatter-filed-url.txt')
assert not url_path.exists(),'Report creation already attempted; inspect saved URL instead of posting again.'
published='d0b8b895661c6b5e809810c4da8a3db9f79138b3'
remote=json.loads(subprocess.check_output(['gh','api','repos/link-assistant/formal-ai/contents/'+str(body_path)+'?ref='+published],text=True))
assert base64.b64decode(remote['content'])==body.encode()
url=subprocess.check_output(['gh','issue','create','--repo',repository,'--title',title,'--body-file',str(body_path)],text=True).strip()
url_path.write_text(url+'\n')
posted=json.loads(subprocess.check_output(['gh','issue','view',url,'--json','body,title,url,number,createdAt'],text=True))
assert posted['body']==body and posted['title']==title and posted['url']==url
record={**posted,'bodySha256':digest,'evidenceCommit':preflight['publishedEvidenceCommit'],'reportCommit':published,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'upstreamRepairClaimed':False,'independentAuthorshipCredit':0}
(directory/'filed-report.json').write_text(json.dumps(record,indent=2)+'\n')
path=Path('experiments/issue-1580/upstream/template-report-identities.json');identities=json.loads(path.read_text())
assert len(identities)==10 and not any(row['url']==url for row in identities)
identities.append({'repository':repository,'title':title,'url':url,'bodyFile':body_path.name,'evidenceCommit':preflight['publishedEvidenceCommit'],'reportCommit':published})
path.write_text(json.dumps(identities,indent=2)+'\n')
path=Path('experiments/issue-1580/upstream/filed-issues.txt');text=path.read_text();assert url not in text;path.write_text(text+url+'\n')
path=directory.parent/'report-draft.json';draft=json.loads(path.read_text());draft['filed']=True;draft['url']=url
path.write_text(json.dumps(draft,indent=2)+'\n')
note='\nThe distinct standalone formatter corruption is filed as [Python template #'+str(posted['number'])+']('+url+'), with complete immutable source and four-case regression evidence at da712fadd and the posted report at d0b8b8956. Immediately before filing, all 158 current issue/PR entries are compared with the prior full inventory (zero changed bodies or new items), current main c532c173 source/helper bytes are verified unchanged, and GitHub-hosted evidence bytes are compared with the local published objects. The exact posted body hash and metadata are retained under evidence/checks/python-release-formatting/publication/. This is an upstream report, not an upstream repair or completion of the wider issue.\n'
for name in ['docs/case-studies/issue-1580/README.md','docs/case-studies/issue-1580/templates/README.md','experiments/issue-1580/work-plan.md']:
 with Path(name).open('a') as stream:stream.write(note)
(directory/'README.md').write_text('# Formatter report publication\n\nThe preflight records current source identities, the full 158-item duplicate/history inventory and published regression-byte checks. The immutable downstream test and logs are published before the report is filed. The posted body is verified byte-for-byte and recorded with its SHA-256; the source defect remains unpatched upstream.\n\nThe first fresh-check command incorrectly requested paginated commit objects as a single JSON value. It failed while decoding metadata, before any issue creation. The corrected preflight reads the exact Git reference, paginates only the issue list and succeeds. Both command transcripts are retained; this harness correction is not a product finding.\n')
subprocess.run(['git','diff','--check'],check=True)
print(json.dumps({'filedReport':url,'bodySha256':digest,'evidenceCommit':preflight['publishedEvidenceCommit'],'reportCommit':published,'upstreamRepairClaimed':False},indent=2))
