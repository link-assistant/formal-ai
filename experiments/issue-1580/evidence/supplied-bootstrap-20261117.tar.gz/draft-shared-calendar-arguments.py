from pathlib import Path
import gzip,json,subprocess
root=Path.cwd();base=root/'experiments/issue-1580/evidence/checks/calendar-dispatch-registration'
initial=base/'initial-validation';assert not initial.exists();(base/'final-validation').rename(initial)
p=root/'data/seed/browser-handler-precedence.lino';text=p.read_text();assert text.count('    argument_userContext')==2
text=text.replace('browser-handler-precedence\n','browser-handler-precedence\n  arguments calendar\n    argument_prompt\n    argument_normalized\n    argument_userContext\n',1)
for handler in ['tryCalendarCreateEvent','tryCalendarReasoning']:
 old=f'  handler {handler}\n    argument_prompt\n    argument_normalized\n    argument_userContext\n';assert old in text;text=text.replace(old,f'  handler {handler}\n    arguments calendar\n')
p.write_text(text)
p=root/'rust/tests/web/handler-registry.test.mjs';text=p.read_text();text+='''
test("named argument lists preserve order, context values and inline fields", () => {
  const context = createBrowserContext();
  loadBrowserScript(context, "js/seed_loader.js");
  loadBrowserScript(context, "js/worker/formal_ai_worker_dispatch.js");
  context.firstHandler = (...values) => ({ intent: "first", content: values, evidence: [] });
  const parse = (source) => context.FormalAiSeed.extractBrowserHandlerPrecedence(context.FormalAiSeed.parse(source));
  const source = `browser-handler-precedence
  arguments calendar
    argument_prompt
    argument_normalized
    argument_userContext
  handler firstHandler
    arguments calendar
    result_intent_first
`;
  const before = parse(source.replace("    arguments calendar", "    argument_prompt\\n    argument_normalized\\n    argument_userContext"));
  context.testRegistry = parse(source);
  assert.deepEqual(plain(context.testRegistry), plain(before));
  context.testContext = { prompt: "request", normalized: "normalized", userContext: { timezone: "UTC" } };
  assert.deepEqual(plain(evaluate(context, "synchronousHandlerCandidates(testContext, testRegistry)[0].run().content")),
    ["request", "normalized", { timezone: "UTC" }]);
  assert.throws(() => parse(source.replace("    arguments calendar", "    arguments missing")), /unknown browser handler arguments: missing/);
});
''';p.write_text(text)
args=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/handler-registry.test.mjs']
r=subprocess.run(args,capture_output=True);raw=r.stdout+r.stderr;(base/'shared-arguments-before.log.gz').write_bytes(gzip.compress(raw,mtime=0));print(raw.decode());assert r.returncode!=0
p=root/'js/seed_loader.js';text=p.read_text();needle='      for (var i = 0; i < handler.children.length; i += 1) {\n        var field = handler.children[i].name;'
assert text.count(needle)==1
replacement='''      var reference = findChildValue(handler, "arguments");
      var shared = findChildren(section, "arguments").find(function (list) { return list.id === reference; });
      if (reference && !shared) throw new Error("unknown browser handler arguments: " + reference);
      var fields = handler.children.concat(shared ? shared.children : []);
      for (var i = 0; i < fields.length; i += 1) {
        var field = fields[i].name;'''
text=text.replace(needle,replacement)
# Keep the existing 1500-line source bound by removing redundant empty lines
# between these three adjacent small lookup helpers; no behavior changes.
text=text.replace('  }\n  function findChildValue(node, name) {','  }\n  function findChildValue(node, name) {',1)
text=text.replace('  function findChildValueAlias(node, primary, fallback) {\n    var value = findChildValue(node, primary);\n    return value || findChildValue(node, fallback);\n  }','  function findChildValueAlias(node, primary, fallback) {\n    return findChildValue(node, primary) || findChildValue(node, fallback);\n  }')
text=text.replace('  // Project the ordered, uniform browser-handler bindings from seed data.\n  // Executable symbols are stored as node names (`argument_prompt`,\n  // `context_binding_writeProgram`, …) so the meaning-closure audit does not\n  // mistake JavaScript identifiers for natural-language references. A bare\n  // `rule_set` field marks a row the seed rule interpreter runs by its name.', '  // Project ordered browser bindings and their shared named argument lists.\n  // Executable symbols are node names (`argument_prompt`,\n  // `context_binding_writeProgram`, …), not natural-language references.\n  // A bare `rule-set` field selects the seed rule interpreter.')
assert len(text.splitlines())<=1500,len(text.splitlines());p.write_text(text)
p=root/'data/meta/closure-audit.lino';text=p.read_text();assert '    value 1035\n' in text;text=text.replace('    value 1035\n','    value 1032\n');text=text.replace('    measured_on 2026-10-07','    measured_on 2026-11-18');p.write_text(text)
for args in [['node','--max-old-space-size=256','scripts/generate-runtime-feature-inventory.mjs','--write'],['node','--max-old-space-size=256','scripts/generate-system-diagrams.mjs','--write']]:
 r=subprocess.run(args,capture_output=True);print('GENERATE',args,'EXIT',r.returncode,r.stdout.decode(),r.stderr.decode());assert r.returncode==0
p=root/'changelog.d/issue-1580-worker-calendar-dispatch.md';p.write_text(p.read_text()+ '\nCalendar handlers share one named argument list. Refresh the generated runtime inventory and solver diagram, and record the lower measured closure gap.\n')
print('CHANGES DRAFTED')
