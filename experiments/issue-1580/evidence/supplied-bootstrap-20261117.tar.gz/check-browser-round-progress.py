import json,pathlib
root=pathlib.Path('/tmp/gh-issue-solver-1794900398048')
p=root/'experiments/issue-1580/evidence/checks/browser-meaning-hydration/adjacent/results.json'
if p.exists():
 records=json.loads(p.read_text())
 print('ADJACENT',len(records),[{'command':r['command'][-1],'exitCode':r['exitCode'],'durationSeconds':r['durationSeconds']} for r in records])
base=pathlib.Path('/tmp/issue-1580-research/ci-logs/summary-governed-7f19154a')
for name in ['outcome.json','latest-runs.json']:
 p=base/name
 if not p.exists():continue
 data=json.loads(p.read_text())
 if name=='latest-runs.json':
  if isinstance(data,list):data=[r for page in data for r in page.get('workflow_runs',[])]
  else:data=data.get('workflow_runs',[])
  rows=[{k:r.get(k) for k in ['id','name','status','conclusion']} for r in data]
  print('CI',{'count':len(rows),'completed':sum(r['status']=='completed' for r in rows),'remainingOrFailed':[r for r in rows if r['status']!='completed' or r['conclusion']not in ['success','skipped']]})
 else:print('OUTCOME',data)
print('MEMORY',pathlib.Path('/sys/fs/cgroup/memory.current').read_text().strip())
