from pathlib import Path

root = Path('/tmp/gh-issue-solver-1794900398048')
file = root / 'rust/tests/web/worker-unknown-language.test.mjs'
addition = '''
test("a localized unknown answer keeps its full seed text without an opener pool", async () => {
  const seed = await host.run('answerFor("unknown", "es")');
  assert.ok(seed.startsWith("Todavía no sé"), seed);
  const answer = await host.run('unknownAnswerWithVariation("¿Cómo funciona la fotosíntesis submarina de xyzzy?", "es")');
  assert.equal(answer, seed);
});

test("the fallback pool stays available without injecting it into another language", async () => {
  assert.deepEqual(await host.run('unknownOpenersFor("es")'), await host.run('unknownOpenersFor("en")'));
  assert.equal(await host.run('selectUnknownOpener("¿Qué es xyzzy?", "es")'), "");
  const opener = await host.run('selectUnknownOpener("a held-out unknown prompt", "en")');
  const english = await host.run('unknownOpenersFor("en")');
  assert.ok(english.includes(opener));
});
'''
assert 'a localized unknown answer keeps' not in file.read_text()
file.write_text(file.read_text() + addition)
print('Added two focused regressions; no production source edited.')
