from pathlib import Path
import json, subprocess

for name in ['experiments/issue-1580/template-python-audit-integrity.test.mjs', 'experiments/issue-1580/template-python-fragment-collision.test.mjs', 'experiments/issue-1580/template-python-runtime.mjs', 'experiments/issue-1580/fixtures/python-template/source.json', 'rust/tests/web/issue-1580-template-observations.test.mjs']:
    path=Path(name)
    if not path.exists():
        print('MISSING',name)
        continue
    lines=path.read_text().splitlines()
    print(f'FILE {name} ({len(lines)} lines)')
    print('\n'.join(f'{n}: {line}' for n,line in enumerate(lines[:160],1)))
print('RELATED FORMAL AI REFERENCES')
result=subprocess.run(['rg','-n','--max-count','3','format_release|format-release-notes|cleaned_body','scripts','rust/src','rust/tests/web'],capture_output=True,text=True)
print(result.stdout[:5000])
