from pathlib import Path
import subprocess,gzip,hashlib,json,os
root=Path.cwd();p=root/'rust/tests/web/default-branch-build-policy.test.mjs';old=p.read_text();marker="test('all former heavy PR overrides remain closed, including bot branch dispatch', () => {";assert old.count(marker)==1
addition="""for (const [label, needs, expectedStatus] of [
  ['successful and skipped dependencies', {lint: {result: 'success'}, test: {result: 'skipped'}}, 0],
  ['a failed dependency', {lint: {result: 'failure'}}, 1],
  ['a cancelled dependency', {'native-type-check': {result: 'cancelled'}}, 1],
]) {
  test('pipeline status reports ' + label + ' on every branch', {timeout: 15000}, () => {
    for (const isMain of ['true', 'false']) {
      const result = spawnSync('bash', ['scripts/check-pipeline-status.sh'], {encoding: 'utf8', timeout: 5000,
        env: {...process.env, NEEDS_JSON: JSON.stringify(needs), IS_MAIN: isMain}});
      assert.equal(result.signal, null, result.stderr);
      assert.equal(result.status, expectedStatus, `IS_MAIN=${isMain}: ${result.stdout}${result.stderr}`);
      if (expectedStatus) assert.doesNotMatch(result.stdout, /All required jobs succeeded/u);
    }
  });
}
""";p.write_text(old.replace(marker,addition+marker));out=root/'experiments/issue-1580/evidence/checks/current-run-cancellation-before';out.mkdir(exist_ok=False)
argv=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','--test-name-pattern','pipeline status reports','rust/tests/web/default-branch-build-policy.test.mjs'];r=subprocess.run(argv,cwd=root,capture_output=True);records=[]
for label,raw in [('stdout',r.stdout),('stderr',r.stderr)]:
 name=label+'.log.gz';z=gzip.compress(raw,mtime=0);(out/name).write_bytes(z);records.append({'file':name,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(z).hexdigest(),'lines':len(raw.splitlines())})
assert r.returncode==1;(out/'review.json').write_text(json.dumps({'argv':argv,'exitCode':r.returncode,'pass':2,'fail':1,'records':records,'independentAuthorshipCredit':0},indent=2)+'\n');print(r.stdout.decode());print(r.stderr.decode())
