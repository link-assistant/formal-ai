from pathlib import Path
for name in ["archive-round-bootstrap.py","archive-evidence.py","run-format-all-gates.py"]:
    p=Path("/tmp/issue-1580-research")/name
    lines=p.read_text().splitlines()
    assert len(lines)<250
    print("FILE",name)
    for n,line in enumerate(lines,1):print(f"{n}: {line}")
for p in sorted(Path("experiments/issue-1580/evidence/checks/python-release-formatting").glob("*.json")):
    if p.name.startswith("feedback"):continue
    if p.stat().st_size>5000:continue
    print("METADATA",p.name,p.read_text())
