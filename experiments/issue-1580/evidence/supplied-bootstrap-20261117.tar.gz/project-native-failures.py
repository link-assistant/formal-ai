from pathlib import Path
import gzip,json,re,subprocess,sys

root=Path('experiments/issue-1580/evidence/ci/main-512ce428')
if len(sys.argv)==1:
 print((root/'native-failure-inventory.json').read_text())
 print(subprocess.run(['rg','-l','This request routes to|does not expose the required|calendar_create_event','js/agentic','rust/src'],capture_output=True,text=True).stdout)
else:
 start=int(sys.argv[1]); count=int(sys.argv[2])
 assert count<=80
 with gzip.open(root/'44117975432.log.gz','rt') as stream:
  for number,line in enumerate(stream,1):
   if number<start: continue
   if number>=start+count: break
   text=re.sub(r'^\d{4}-\d\d-\d\dT\S+\s','',line.rstrip().split('\t',2)[-1])
   if len(text)<=1200: print(f'{number}: {text}')
   else:
    print(f'{number}: LARGE {len(text)} characters: {text[:600]}')
    args=re.findall(r'arguments: ("(?:\\.|[^"\\])*")',text)
    for index,arg in enumerate(args):
     value=json.loads(arg)
     try: value=json.loads(value)
     except json.JSONDecodeError: pass
     if isinstance(value,dict):
      print('TOOL',index,'keys',list(value))
      for key,value in value.items():
       if key in ['command','filePath','file_path','url','file','path','content']:
        raw=str(value)
        print(key,raw if len(raw)<=1800 else raw[:1800]+' [projection truncated]')
