from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess

def invoke(args):return subprocess.run(args,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
repo='link-assistant/formal-ai'; branch='issue-1580-8d61a32a61e1';head='b79dc1e0f147ed57d8e317c1b93bfa6ffc79078d'
recent=json.loads(invoke(['gh','run','list','--repo',repo,'--branch',branch,'--limit','5','--json','databaseId,conclusion,createdAt,headSha,status,workflowName']))
print('RECENT',json.dumps(recent,indent=2))
runs=json.loads(invoke(['gh','run','list','--repo',repo,'--branch',branch,'--commit',head,'--limit','100','--json','databaseId,conclusion,createdAt,headSha,status,workflowName']))
assert len(runs)==24 and all(r['headSha']==head for r in runs)
active=[r for r in runs if r['status']!='completed']; failed=[r for r in runs if r['status']=='completed' and r['conclusion']!='success']
if active:
 print('ACTIVE',json.dumps(active,indent=2)); raise SystemExit(0)
base=Path('experiments/issue-1580/evidence/ci/b79dc1e0f');base.mkdir(parents=True,exist_ok=True)
(base/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
collect=failed if failed else [r for r in runs if r['workflowName']=='Layered CI']
logs=[]
for run in collect:
 identity=str(run['databaseId']); log=invoke(['gh','run','view',identity,'--repo',repo,'--log'])
 (base/(identity+'.log.gz')).write_bytes(gzip.compress(log,mtime=0))
 metadata=invoke(['gh','run','view',identity,'--repo',repo,'--json','databaseId,headSha,createdAt,updatedAt,status,conclusion,workflowName,url,jobs'])
 (base/(identity+'.json')).write_bytes(metadata)
 row={'run':run['databaseId'],'head':head,'conclusion':run['conclusion'],'rawLogSha256':hashlib.sha256(log).hexdigest(),'rawLogBytes':len(log),'rawLogLines':len(log.splitlines()),'log':str(base/(identity+'.log.gz'))}
 logs.append(row);print('LOG',json.dumps(row))
 for n,line in enumerate(log.decode().splitlines(),1):
  if 'repository holds the abbreviation ratchet' in line or '##[error]' in line:
   print(f'{n}: {line}')
summary={'checkedAt':datetime.now(timezone.utc).isoformat(),'head':head,'runs':24,'passing':sum(r['conclusion']=='success' for r in runs),'failed':failed,'active':active,'logs':logs,'claim':'All listed workflows ran on this exact published SHA. Successful scoped PR workflows do not execute main-only native behavior, benchmark floors, live identity, upstream publication or work-item qualification.'}
(base/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('SUMMARY',json.dumps(summary,indent=2))
