import json, pathlib
for client in ('opencode', 'qwen'):
    path = pathlib.Path(f'/tmp/issue-1580-research/main-826289fc-cli-artifacts/transcripts-{client}/artifacts/{client}/interactive/proxy.jsonl')
    rows = [json.loads(row) for row in path.read_text().splitlines()]
    requests = [json.loads(row['request_body']) for row in rows if row['method'] == 'POST' and row['request_tools']]
    print(client)
    for message in requests[1]['messages']:
        if message['role'] not in ('system', 'developer', 'user'):
            print(json.dumps(message, ensure_ascii=False))
