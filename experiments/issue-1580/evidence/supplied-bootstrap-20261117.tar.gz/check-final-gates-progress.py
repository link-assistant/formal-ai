import json, pathlib, subprocess
p=pathlib.Path('experiments/issue-1580/evidence/checks/generated-header-memory/final-gates')
f=p/'all-local-gates.json'
if f.exists():
 d=json.loads(f.read_text())
 print(json.dumps({k:v for k,v in d.items() if k not in ('perGateLogs','gateLogs')}, indent=2))
else:
 print('Completion not yet recorded')
 q=p/'all-local-gates.log'
 if q.exists():
  lines=q.read_text(errors='replace').splitlines()
  print('Live log lines:',len(lines))
  print('\n'.join(lines[-18:]))
 print(subprocess.run(['ps','-p','314423','-o','pid,ppid,stat,etime,args'],capture_output=True,text=True).stdout)
