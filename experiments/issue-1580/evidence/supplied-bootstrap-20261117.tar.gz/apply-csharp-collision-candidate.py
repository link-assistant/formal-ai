from pathlib import Path
import hashlib,json

base=Path('experiments/issue-1580')
test=base/'template-csharp-changeset-integrity.test.mjs'
text=test.read_text()
marker='  // Candidate repair is inserted here after the before-fix regression run.\n'
assert text.count(marker)==1
candidate='''  if(repaired){
    const source=readFileSync(script,'utf8');
    const boundary='writeFileSync(mergedFilePath, mergedContent);';
    assert.equal(source.split(boundary).length,2,'one merged output creation boundary');
    writeFileSync(script,source.replace(boundary,"writeFileSync(mergedFilePath, mergedContent, {flag: 'wx'});"));
  }
'''
test.write_text(text.replace(marker,candidate))
entry=Path('rust/tests/web/issue-1580-template-observations.test.mjs')
line="import '../../../experiments/issue-1580/template-csharp-changeset-integrity.test.mjs';\n"
assert line not in entry.read_text()
entry.write_text(entry.read_text()+line)
before=json.loads((base/'evidence/checks/csharp-changeset-collision/before.json').read_text())
assert before['exitCode']==1
print(json.dumps({'test':str(test),'sha256':hashlib.sha256(test.read_bytes()).hexdigest(),'candidate':'Exclusive output creation using flag wx in a disposable copy only. Collision fails before either valid input is removed. Noncolliding behavior is unchanged.','maintainedEntry':str(entry),'credit':'Supplied by Codex; no independent Formal AI reasoning credit.'},indent=2))
