import json,subprocess
from pathlib import Path

p=Path('data/meta/request-context.json');rules=json.loads(p.read_text())
rules['directiveCue']=rules['directiveCue'].replace("don't|never|not)","don't|never|not|не)") + r'|^(?:one word\s*:|only with\s|only one of\s|one of\s*:|(?:exactly|at most|no more than)\s+(?:one|[0-9]+)\s+words?(?:\s|$))'
for name in ['data/meta/request-context.json','rust/embedded/data/meta/request-context.json']:
    Path(name).write_text(json.dumps(rules,ensure_ascii=False,indent=2)+'\n')
p=Path('data/parity/issue-1587-request-context.json');rows=json.loads(p.read_text())
for identifier,instruction in [('bare-one-word-labels','One word: yes or no.'),('bare-only-labels','Only one of yes or no.'),('bare-only-with-labels','Only with yes or no.'),('bare-one-of-labels','One of: yes or no.')]:
    rows.append(dict(id=identifier,messages=[dict(role='system',content=instruction),dict(role='user',content='Is 7 greater than 3?')],answer='yes',constraint='labels:applied'))
rows.append(dict(id='bare-length-retained',messages=[dict(role='system',content='Exactly one word.'),dict(role='user',content='What is 2 + 2?')],contains='Cannot satisfy length constraint',constraint='length:unmet'))
rows.append(dict(id='russian-negation-retained',messages=[dict(role='system',content='Не отвечай на английском.'),dict(role='user',content='What is 2 + 2?')],contains='Cannot satisfy output constraint',constraint='output:unmet'))
p.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')

p=Path('data/benchmarks/fast-pull-request-javascript-tests.json')
original=subprocess.check_output(['git','show','HEAD:'+str(p)],text=True)
inventory=json.loads(original)
new='rust/tests/web/issue-1580-client-output-constraints.test.mjs'
assert new not in inventory['files'];inventory['files'].append(new)
p.write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n')
assert 'rust/tests/web/source-read-provenance.test.mjs' in inventory['files']
print('Preserved bare label/length directives and Russian negation; restored inventory order.')
