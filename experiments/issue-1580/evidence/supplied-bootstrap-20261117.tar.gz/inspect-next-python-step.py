import pathlib, subprocess

def run(args):
    result = subprocess.run(args, text=True, capture_output=True, check=True)
    print('$ ' + ' '.join(args))
    print(result.stdout)

run(['git', 'status', '--short'])
for name in ['push-python-fragment-batch.py', 'check-python-fragment-gates.py']:
    path = pathlib.Path('/tmp/issue-1580-research') / name
    print(f'FILE {path}')
    print(path.read_text())
