from pathlib import Path
import gzip,json
base=Path('experiments/issue-1580/evidence/checks/php-release-guard')
classification=json.loads((base/'ci-input-classification.json').read_text())
graph=json.loads(gzip.decompress(Path('docs/case-studies/issue-1580/templates/php-ci-reference-graph.json.gz').read_bytes()))
covered=set(graph['files'])
result=[]
for job in classification['capturedTreeJobInputs']:
    missing=[file for file in job['paths'] if file not in covered]
    result.append({'language':job['language'],'workingDirectory':job['workingDirectory'],'fileCount':job['fileCount'],'missingCount':len(missing),'missingFiles':missing})
report={'repository':graph['repository'],'commit':graph['commit'],'graphFileCount':len(covered),'jobs':result,'explicitCommandContextUnknowns':len([item for item in graph['unresolved'] if 'working-directory' in item['reason']]),'wholeRepositorySemanticReview':False,'independentAuthorshipCredit':0}
(base/'captured-graph-coverage.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
