from pathlib import Path
import gzip,hashlib,json,subprocess

base=Path('experiments/issue-1580/evidence/checks/csharp-changeset-collision')
for p in sorted([*base.glob('*.tap'),*base.glob('*.log')]):
 data=p.read_bytes();target=Path(str(p)+'.gz')
 assert not target.exists()
 target.write_bytes(gzip.compress(data,mtime=0))
 assert gzip.decompress(target.read_bytes())==data
 p.unlink()
 print('Preserved exact log bytes',str(target),hashlib.sha256(data).hexdigest())
for label in ['before','after','maintained']:
 path=base/(label+'.json');record=json.loads(path.read_text())
 log=base/(label+'.tap.gz')
 assert hashlib.sha256(gzip.decompress(log.read_bytes())).hexdigest()==record['logSha256']
 record['log']=str(log);record['compression']='gzip; hashes refer to original uncompressed bytes'
 path.write_text(json.dumps(record,indent=2)+'\n')
index=base.parent/'csharp-changeset-integrity.json';record=json.loads(index.read_text())
record['checks']={label:json.loads((base/(label+'.json')).read_text()) for label in ['before','after','maintained']}
record['logStorage']='Complete raw TAP/spec output is gzip-compressed without changing any bytes, including whitespace in the expected assertion failure. All log hashes refer to original bytes.'
index.write_text(json.dumps(record,indent=2)+'\n')
subprocess.run(['git','add','-A',str(base),str(index)],check=True)
