from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
base=root/'experiments/issue-1580/evidence/checks/unknown-native-replay'
base.mkdir(exist_ok=False)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='f6ecab596c331da59c40abd07d69c431beba1066'
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
records=[]
def run(name,args,expected=0):
    p=subprocess.run(args,cwd=root,capture_output=True)
    row={'name':name,'argv':args,'exitCode':p.returncode}
    for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:
        filename=name+'.'+label+'.gz'
        packed=gzip.compress(data,mtime=0)
        (base/filename).write_bytes(packed)
        row[label]={'file':filename,'rawSha256':hashlib.sha256(data).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(data),'lines':len(data.splitlines())}
    records.append(row)
    (base/'records.json').write_text(json.dumps(records,indent=2)+'\n')
    assert p.returncode==expected,(name,p.stderr.decode(errors='replace')[-1500:])
    print(json.dumps({'name':name,'exitCode':p.returncode}),flush=True)
    return p.stdout
def replace(file,old,new):
    p=root/file
    text=p.read_text()
    assert text.count(old)==1,(file,old)
    p.write_text(text.replace(old,new))
old='--test cnl_output --test cnl_parity -- --test-threads=1'
new='--test cnl_output --test cnl_parity --test unknown_reasoning -- --test-threads=1'
replace('rust/tests/web/default-branch-build-policy.test.mjs',old,new)
run('policy-before',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/default-branch-build-policy.test.mjs'],1)
replace('.github/workflows/native-type-check.yml',old,new)
replace('rust/Cargo.toml','[[test]]\nname = "integration"', '# Replay the existing unknown-source contracts without compiling the whole unit suite.\n[[test]]\nname = "unknown_reasoning"\npath = "tests/unit/specification/unknown_reasoning.rs"\n\n[[test]]\nname = "integration"')
replace('scripts/ci-pull-request-admission.mjs',"  'rust/tests/unit/specification/synthesis.rs',", "  'rust/tests/unit/specification/synthesis.rs',\n  'rust/tests/unit/specification/unknown_reasoning.rs',")
replace('rust/tests/unit/specification/unknown_reasoning.rs', '''        ("English", "cursor"),
        ("Russian", "курсор"),
        ("Hindi", "कर्सर"),
        ("Chinese", "光标"),''', '''        ("English", "snorflax"),
        ("Russian", "снорфлакс"),
        ("Hindi", "स्नोरफ्लैक्स"),
        ("Chinese", "斯诺弗拉克斯"),''')
replace('rust/tests/unit/specification/unknown_reasoning.rs', '''    for (language, prompt) in cases {
        let response = answer(prompt);''', '''    for (language, prompt) in cases {
        // Test the local miss and handoff without a live provider filling the cache.
        let response = answer_offline(prompt);''')
replace('rust/tests/unit/specification/unknown_reasoning.rs', '''        response.evidence_links,
    );
}

#[test]
fn unknown_reasoning_researches_facts_and_only_asks_for_report_consent()''', '''        response.evidence_links,
    );

    // Cursor is captured public knowledge, so it must retain the complete answer
    // and its attribution rather than being treated as an unresolved term.
    let captured = answer_offline("cursor");
    assert_eq!(captured.intent, "concept_lookup");
    assert_eq!(
        captured.answer,
        concat!(
            "cursor (cursor): (computer science) indicator consisting of a movable spot of light (an icon) on a visual display; moving it allows the user to point to commands or screen positions",
            "\\n\\nSource: https://en-word.net/api/lemma/cursor (sha256 7135852a793acb64; CC BY 4.0)",
        ),
    );
    assert!(!has_evidence(&captured, "web_search:request:"));
}

#[test]
fn unknown_reasoning_researches_facts_and_only_asks_for_report_consent()''')
(root/'changelog.d/issue-1580-unknown-native-replay.md').write_text('Correct the unknown-term regression to use uncaptured terms in four languages, preserve the complete attributed cursor definition as a positive control, and execute all nine unknown-source contracts in the focused native pull-request check.\n')
run('policy-after',['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/default-branch-build-policy.test.mjs'])
run('rustfmt',['rustfmt','--edition','2024','--check','rust/tests/unit/specification/unknown_reasoning.rs'])
run('source-diff',['git','diff','--','.github/workflows/native-type-check.yml','rust/Cargo.toml','scripts/ci-pull-request-admission.mjs','rust/tests/web/default-branch-build-policy.test.mjs','rust/tests/unit/specification/unknown_reasoning.rs'])
old_source=run('original-source',['git','show','015a6831:rust/tests/unit/specification/unknown_reasoning.rs'])
parent_source=run('parent-source',['git','show',head+':rust/tests/unit/specification/unknown_reasoning.rs'])
assert old_source==parent_source,'The original failing fixture changed before this repair'
outcome={'sourceHead':head,'complete':True,'observedAt':datetime.now(timezone.utc).isoformat(),'fixtureUnchangedSinceOriginalFailure':True,'originalFixtureSha256':hashlib.sha256(old_source).hexdigest(),'policyBeforeExitCode':1,'policyAfterExitCode':0,'nativeExecutionVerified':False,'fullIssueComplete':False,'independentAuthorshipCredit':0}
(base/'outcome.json').write_text(json.dumps(outcome,indent=2)+'\n')
print(json.dumps(outcome))
