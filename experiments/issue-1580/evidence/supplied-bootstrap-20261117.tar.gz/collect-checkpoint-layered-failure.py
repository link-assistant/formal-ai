import datetime
import gzip
import hashlib
import json
import pathlib
import re
import subprocess

base=pathlib.Path('experiments/issue-1580/evidence/ci/checkpoint-7780c707')
scratch=pathlib.Path('/tmp/issue-1580-research')
run=44180825006
log=scratch/f'checkpoint-7780c707-{run}.log'
with log.open('w') as stream:
    subprocess.run(['gh','run','view',str(run),'--repo','link-assistant/formal-ai','--log'],stdout=stream,stderr=subprocess.STDOUT,check=True)
raw=log.read_bytes()
(base/f'{run}.log.gz').write_bytes(gzip.compress(raw))
markers=[]
for number,line in enumerate(raw.decode().splitlines(),1):
    payload=line.split('\t',2)[-1]
    payload=re.sub(r'^\d{4}-\d\d-\d\dT\S+\s*','',payload)
    if re.match(r'^(?:not ok |✖ )',payload) or '##[error]' in payload:
        markers.append({'line':number,'payload':payload})
receipt={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':'7780c70715df515a8ffcb085bff0902b4489bb94','run':run,'bytes':len(raw),'lines':raw.count(b'\n'),'sha256':hashlib.sha256(raw).hexdigest(),'scope':'Complete raw log preserved; this index is a targeted failure-marker review.','markers':markers}
(base/f'{run}-failure-index.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({key:value for key,value in receipt.items() if key!='markers'},indent=2))
for entry in markers:
    print(f'{entry["line"]}: {entry["payload"][:450]}')
