from pathlib import Path
import json,hashlib,tarfile,subprocess,os,gzip
base=Path('/tmp/issue-1580-research');archive=base/'shellcheck-v0.11.0.linux.x86_64.tar.xz';binary=base/'shellcheck-v0.11.0/shellcheck'
release=json.loads((base/'shellcheck-release.json').read_text())
asset=next(a for a in release['assets'] if a['name']==archive.name)
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
assert asset['digest']=='sha256:'+digest
with tarfile.open(archive) as value:
 original=value.extractfile('shellcheck-v0.11.0/shellcheck').read()
assert hashlib.sha256(original).hexdigest()==hashlib.sha256(binary.read_bytes()).hexdigest()
command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only','lint-shell-scripts']
result=subprocess.run(command,env={**os.environ,'PATH':str(binary.parent)+os.pathsep+os.environ['PATH']},capture_output=True,text=True)
directory=Path('experiments/issue-1580/evidence/checks/python-runtime-provisioning');raw=(result.stdout+result.stderr).encode();log=directory/'gates-verified-shellcheck.log.gz';log.write_bytes(gzip.compress(raw,mtime=0))
detail=Path('experiments/formal_ai_subagent/sandboxes/gates/lint-shell-scripts.log').read_bytes();(directory/'verified-shellcheck-details.log.gz').write_bytes(gzip.compress(detail,mtime=0))
record={'command':command,'exitCode':result.returncode,'release':release.get('html_url','https://github.com/koalaman/shellcheck/releases/tag/v0.11.0'),'version':'0.11.0','archiveSha256':digest,'binarySha256':hashlib.sha256(original).hexdigest(),'existingVerifiedBinaryReused':True,'log':str(log),'uncompressedSha256':hashlib.sha256(raw).hexdigest(),'originalMissingToolFailureRetained':True}
(directory/'gates-verified-shellcheck.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2));print(raw.decode());print(detail.decode());print('Existing actionlint paths:',[p.name for p in base.iterdir() if 'actionlint' in p.name.lower()])
assert result.returncode==0
