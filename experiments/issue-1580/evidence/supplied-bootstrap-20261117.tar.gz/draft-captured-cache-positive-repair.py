from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='d43bc0386409bb16535451d33dbb1af5e5e83888'
p=root/'rust/tests/unit/specification/unknown_reasoning.rs'
text=p.read_text()
start=text.index('\n    // Cursor is captured public knowledge,')
end=text.index('\n}',start)
assert 'captured.answer' in text[start:end] and '7135852a793acb64' in text[start:end]
p.write_text(text[:start]+text[end:])
p=root/'rust/tests/unit/solver_unknown_reasoning_captured_sources.rs'
text=p.read_text();start=text.index('fn supported_definition_keeps_its_attributed_retrieved_answer() {')
end=text.index('\n}\n',start)+2
old=text[start:end]
assert '"What is an isogram?"' in old and old.count('answer_unknown_prompt(')==1
new='''fn supported_definition_keeps_its_attributed_retrieved_answer() {
    let sense = captured_sense("isogram", "en");
    // Both request forms use the committed capture, independently of runtime cache state.
    for prompt in ["isogram", "What is an isogram?"] {
        let mut log = EventLog::new();
        let answer = answer_unknown_prompt(
            prompt,
            Language::English,
            &mut log,
            offline_config(),
            std::slice::from_ref(&sense),
        );
        assert_eq!(answer.intent, "concept_lookup", "{prompt}");
        assert_eq!(
            answer.answer,
            "isogram (isogram): a line drawn on a map connecting points having the same numerical value of some variable\\n\\nSource: https://en-word.net/api/lemma/isogram (sha256 ae8c98f774fd255a; CC BY 4.0)",
            "{prompt}",
        );
        assert!(answer.answer.contains(&sense.gloss));
        assert!(answer.answer.contains(&sense.source_url));
        assert!(answer.answer.contains(&sense.sha256[..16]));
        assert!(!answer.evidence_links.iter().any(|link| link.starts_with("web_search:request:")));
    }
}'''
p.write_text(text[:start]+new+text[end:])
changelog=root/'changelog.d/issue-1580-captured-cache-positive-replay.md'
assert not changelog.exists()
changelog.write_text('Keep the native unknown-source positive control independent of transient runtime caches. Replay both bare-term and question requests from the existing committed isogram capture, preserving the complete definition, citation and digest checks.\n')
subprocess.run(['rustfmt','--edition','2024','rust/tests/unit/specification/unknown_reasoning.rs','rust/tests/unit/solver_unknown_reasoning_captured_sources.rs'],cwd=root,check=True)
print(subprocess.check_output(['git','diff','--stat'],cwd=root,text=True))
print(subprocess.check_output(['git','diff','--','rust/tests/unit/specification/unknown_reasoning.rs','rust/tests/unit/solver_unknown_reasoning_captured_sources.rs'],cwd=root,text=True))
