from pathlib import Path
import hashlib,json,subprocess

base=Path('experiments/issue-1580/evidence/checks/csharp-changeset-collision')
rows=[]
for gate in ['check-file-size','check-file-size-js-twin','check-changelog-fragment-js-twin','check-ci-speed']:
 command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate]
 result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log=base/(gate+'.log.gz')
 import gzip
 log.write_bytes(gzip.compress(result.stdout,mtime=0))
 record={'gate':gate,'command':command,'exitCode':result.returncode,'log':str(log),'sha256':hashlib.sha256(result.stdout).hexdigest(),'lines':len(result.stdout.splitlines())}
 rows.append(record)
 print(json.dumps(record))
 print('\n'.join(result.stdout.decode().splitlines()[-10:]))
 if result.returncode:
  print(result.stdout.decode())
  break
(base/'gates.json').write_text(json.dumps(rows,indent=2)+'\n')
assert len(rows)==4 and all(row['exitCode']==0 for row in rows)
