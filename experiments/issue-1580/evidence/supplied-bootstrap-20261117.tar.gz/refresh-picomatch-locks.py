from pathlib import Path
import subprocess,json,os,time
r=Path('/tmp/gh-issue-solver-1794900398048'); base=Path('/tmp/issue-1580-research')
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=256'
results=[]
for name in ['desktop','vscode']:
 log=base/('picomatch-update-'+name+'.log')
 with log.open('w') as out:
  cp=subprocess.run(['npm','update','picomatch','--package-lock-only','--ignore-scripts','--no-audit','--no-fund'],cwd=r/name,stdout=out,stderr=subprocess.STDOUT,env=env)
 results.append({'package':name,'exitCode':cp.returncode,'log':str(log)})
 print(name,'exit',cp.returncode,log.read_text()[-4000:])
 if cp.returncode: break
 print(json.dumps({k:v for k,v in json.loads((r/name/'package-lock.json').read_text())['packages'].items() if 'picomatch' in k}))
(base/'picomatch-update-results.json').write_text(json.dumps(results,indent=2)+'\n')
