import datetime
import hashlib
import json
import pathlib

p = pathlib.Path('data/benchmarks/fast-pull-request-javascript-tests.json')
before = p.read_bytes()
inventory = json.loads(before)
added = [
    'rust/tests/web/page-formalization-route.test.mjs',
    'rust/tests/web/rust-specification-generated-programs.test.mjs',
    'rust/tests/web/issue-1172-factual-qa-subject-gate.test.mjs',
    'rust/tests/web/issue-1328-bounded-retries.test.mjs',
]
assert all(pathlib.Path(name).is_file() and name not in inventory['files'] for name in added)
inventory['files'].extend(added)
p.write_text(json.dumps(inventory, indent=2) + '\n')
receipt = {
    'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'path': str(p), 'beforeSha256': hashlib.sha256(before).hexdigest(),
    'afterSha256': hashlib.sha256(p.read_bytes()).hexdigest(),
    'beforeCount': len(inventory['files']) - len(added), 'afterCount': len(inventory['files']),
    'added': added, 'reason': 'All four new production-only regression rows must replay before merge.',
    'independentAuthorshipCredit': 0,
}
target = pathlib.Path('experiments/issue-1580/evidence/checks/final-runtime-ledger-checks/fast-inventory-correction.json')
assert not target.exists()
target.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
