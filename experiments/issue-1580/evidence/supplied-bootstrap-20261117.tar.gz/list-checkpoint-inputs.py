from pathlib import Path
import json
root=Path('/tmp/issue-1580-research')
for path in sorted(root.iterdir()):
    if path.is_file() and any(token in path.name for token in ('current.log','documentation-reporting','gate','rustfmt','pr-body')):
        print(path.name,path.stat().st_size)
ci=root/'current-head-ci'
for path in sorted(ci.iterdir()): print('ci/'+path.name,path.stat().st_size)
print('changelog:\n'+Path('changelog.d/20261117_120000_issue-1580-ci-regressions.md').read_text())
print('pr body:\n'+(root/'pr-body.md').read_text())
