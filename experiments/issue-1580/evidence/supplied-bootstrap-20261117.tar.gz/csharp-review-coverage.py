from pathlib import Path
import collections,hashlib,json,subprocess

rows=json.loads(Path('/tmp/issue-1580-research/templates/csharp-complete-inventory.json').read_text())
root=Path('/tmp/issue-1580-research/templates/csharp-complete')
remaining=26*450
counts=collections.Counter()
for row in rows:
    name=row['path'];data=(root/name).read_bytes()
    assert hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()==row['gitBlob']
    if name.startswith(('dev/log/','ci-logs/')):
        counts['historical']+=1
        continue
    try:lines=data.decode().splitlines()
    except UnicodeDecodeError:
        counts['binary']+=1
        print('BINARY',name)
        continue
    counts['activeText']+=1
    read=min(remaining,len(lines));remaining-=read
    counts['full' if read==len(lines) else 'partial' if read else 'unread']+=1
    print(f'{read}/{len(lines)} {name}')
print('COUNTS',json.dumps(dict(counts)))
names=subprocess.check_output(['rg','--files','scripts','rust/tests'],text=True).splitlines()
print('FORMAL CHANGESET PATHS',*[name for name in names if 'changeset' in name.lower()],sep='\n')
result=subprocess.run(['rg','-n','mergedFileName|mergedFilePath|generateChangesetName|merge-changesets','scripts','rust/src'],text=True,stdout=subprocess.PIPE)
print('FORMAL MERGE REFERENCES',result.stdout)
