from pathlib import Path
import json,re,subprocess,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/spelled-calendar-clock';base.mkdir(exist_ok=False)
fixture=root/'rust/tests/fixtures/issue-1580-calendar-clock.json';original=fixture.read_bytes();(base/'previous-calendar-clock-fixture.json').write_bytes(original)
rows=json.loads(original);corpus=(root/'data/benchmarks/self-use-intent-routing.lino').read_text();family=corpus[corpus.index('  id "schedule_paraphrase"'):corpus.index('self_use_case_spanish_routing_matrix')];prompts=re.findall(r'^    prompt "(.*)"$',family,re.M);assert len(prompts)==5
rows['events'] += [{'prompt':prompt,'time':'14:00' if re.search('[А-Яа-я]',prompt) else '20:00','zone':'Asia/Tbilisi'} for prompt in prompts]
rows['events'] += [{'prompt':prompt,'time':clock,'zone':'UTC'} for prompt,clock in [
 ('Schedule a meeting tomorrow at nine in the morning.','09:00'),
 ('Schedule a meeting tomorrow at nine in the evening.','21:00'),
 ('Запланируй встречу завтра в восемь вечера.','20:00'),
 ('कल सुबह नौ बजे मीटिंग शेड्यूल करें','09:00'),
 ('明天上午九点安排会议','09:00'),
 ('Programa una reunión mañana a las nueve de la mañana.','09:00'),
 ('Schedule a meeting with two people tomorrow at nine.','09:00'),
 ('Schedule a meeting in 2026 tomorrow at nine.','09:00'),
 ('Schedule a meeting tomorrow at 8:05 pm.','20:05'),
 ('Schedule a meeting tomorrow at 12:00 am.','00:00'),
 ('Schedule a meeting tomorrow at 12:00 pm.','12:00'),
 ('Schedule a meeting tomorrow at 1400.','14:00'),
]]
rows['parserControls']=[{'text':text,'time':clock} for text,clock in [
 ('the report counts two people tonight',None),('2026-11-18',None),
 ('somewhere in eight rooms',None),('через 3 часа',None),
 ('the number eight is in the text',None),('at eightish tonight',None),
 ('at 25:00',None),('at 12:90',None),('at 8:5',None),('at 200000',None),
 ('5pm',[17,0]),('at eight pm',[20,0]),('at eight a.m.',[8,0]),
 ('в восемь утра',[8,0]),('at nine in the morning',[9,0]),
 ('八点',[8,0]),('下午5点',[17,0]),('2026 at eight tonight',[20,0]),
]]
fixture.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
test=root/'rust/tests/web/calendar-clock-preservation.test.mjs';old=test.read_text();(base/'previous-calendar-clock-test.mjs').write_text(old)
needle="test('chat API preserves the requested clock and declines a background clock'";assert old.count(needle)==1
new='''for (const row of fixtures.parserControls) {
  test('clock parsing keeps the number attached to its clock phrase: ' + row.text, {timeout:15000}, () => {
    const actual = evaluate(worker, 'extractClockTime(' + JSON.stringify(row.text) + ')');
    assert.deepEqual(actual === null ? null : Array.from(actual), row.time);
  });
}

'''
test.write_text(old.replace(needle,new+needle));(base/'regression-inventory.json').write_text(json.dumps({'eventCount':len(rows['events']),'sourceControls':len(rows['documents']),'parserControls':len(rows['parserControls']),'originalSchedulingForms':5,'originalNativeSourceUnmodified':True,'independentAuthorshipCredit':0},indent=2)+'\n')
print('Drafted',len(rows['events']),'shared event expectations and',len(rows['parserControls']),'clock attachment controls; native test source remains unchanged.')
