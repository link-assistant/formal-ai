import gzip,hashlib,json,pathlib,re,subprocess

evidence=pathlib.Path('experiments/issue-1580/evidence/checks/calendar-seed-integrity')
before_log=gzip.decompress((evidence/'before.log.gz').read_bytes()).decode()
assert 'ℹ pass 40' in before_log and 'ℹ fail 2' in before_log
assert "'meanings-calendar.lino:336'" in before_log and "'year|years'" in before_log
before_receipt=json.loads((evidence/'before.json').read_text())
before_receipt['reviewedFailures']=['calendar meanings stay globally unique across all seed meaning documents','handler table rows carry one surface each without pipe-packed aliases']
before_receipt['reporter']='spec; the initial helper incorrectly expected TAP markers, after the test command finished with the expected two failures'
(evidence/'before-reviewed.json').write_text(json.dumps(before_receipt,indent=2)+'\n')

path=pathlib.Path('data/seed/handler-rules.lino')
source=path.read_text()
(evidence/'handler-rules-before.lino.gz').write_bytes(gzip.compress(source.encode(),mtime=0))
before_rows=[]
after_rows=[]
table=None
rewritten=[]
packed=0
for line in source.splitlines():
 match=re.fullmatch(r'  table (\S+)',line)
 if match:table=match[1]
 row=re.fullmatch(r'    row "([^"]+)" "([^"]*)"',line)
 if row and '|' in row[2]:
  packed+=1
  values=row[2].split('|')
  assert all(values)
  for value in values:
   before_rows.append([table,row[1],value])
   rewritten.append(f'    row "{row[1]}" "{value}"')
   after_rows.append([table,row[1],value])
 else:rewritten.append(line)
assert packed==21,packed
updated='\n'.join(rewritten)+'\n'
assert updated.count('  table calendar-duration-sum\n')==1
updated=updated.replace('  table calendar-duration-sum\n','  table calendar-duration-addition-cue\n')
path.write_text(updated)

meaning=pathlib.Path('data/seed/meanings-calendar.lino')
source=meaning.read_text()
assert source.count('  calendar-duration-sum\n')==1
meaning.write_text(source.replace('  calendar-duration-sum\n','  calendar-duration-addition-cue\n'))

worker=pathlib.Path('js/worker/formal_ai_worker_calendar_offset.js')
source=worker.read_text()
source=source.replace('.flatMap((row) => row[1].split("|"))','.map((row) => row[1])')
assert source.count('calendarDurationWords("calendar-duration-sum")')==1
source=source.replace('calendarDurationWords("calendar-duration-sum")','calendarDurationWords("calendar-duration-addition-cue")')
source=source.replace('? "calendar-duration-sum" : "calendar-full-query"','? "calendar-duration-addition-cue" : "calendar-full-query"')
source=source.replace('.find(row => row[1].split("|").some(word => calendarOffsetStartsWithTerm(text, word)))','.find(row => calendarOffsetStartsWithTerm(text, row[1]))')
worker.write_text(source)

native=pathlib.Path('rust/src/solver_handlers/calendar/month.rs')
source=native.read_text()
source=source.replace(".flat_map(|(_, value)| value.split('|').map(str::to_owned))",'.map(|(_, value)| value.clone())')
source=source.replace('words("calendar-duration-sum")','words("calendar-duration-addition-cue")')
source=source.replace('let role = if request.kind == "calendar-duration-sum" {\n            "calendar-duration-sum"','let role = if request.kind == "calendar-duration-sum" {\n            "calendar-duration-addition-cue"')
source=source.replace(".find(|(_, words)| words.split('|').any(|word| starts(text.trim(), word)))",'.find(|(_, word)| starts(text.trim(), word))')
native.write_text(source)

native=pathlib.Path('rust/src/solver_handlers/calculator_rate.rs')
source=native.read_text()
assert source.count(".any(|(_, words)| words.split('|').any(|word| word == connector))")==1
native.write_text(source.replace(".any(|(_, words)| words.split('|').any(|word| word == connector))",'.any(|(_, word)| word == &connector)'))

test=pathlib.Path('rust/tests/web/issue-1589-calendar-currency.test.mjs')
source=test.read_text()
source+='''
test('separate vocabulary rows retain alternative addition, interval and currency surfaces', {timeout:15000}, async () => {
  for (const [prompt, intent, expected] of [
    ['Sum 12 months + 1 year in years.', 'calendar-duration-sum', '2 years'],
    ['Суммируй 1 год и 2 месяца. В месяцах.', 'calendar-duration-sum', '14 месяцев'],
    ['Сложите 1 год и 2 месяца. Ответ в месяцах.', 'calendar-duration-sum', '14 месяцев'],
    ['How many whole years are from March 2021 until June 2024?', 'calendar-full-periods', '3 years'],
    ['How many complete months are from March 2021 to June 2024?', 'calendar-full-periods', '39 months'],
    ['Convert 1000 RUB as USD', 'calculation', '12.12 USD'],
  ]) {
    const answer = await worker.solve(prompt, [], {}, {}, [], {});
    assert.equal(answer.intent, intent, JSON.stringify(answer));
    assert.ok(answer.content.includes(expected), answer.content);
  }
});
'''
test.write_text(source)

ledger=pathlib.Path('data/meta/main-only-regressions.lino')
source=ledger.read_text()
source+='''main-run 44188508650
  javascript-twin
    regression calendar-meaning-slug-collision
      introduced-by "PR #1590, merged as 015a6831"
      failed "meaning_slugs_are_globally_unique: calendar-duration-sum named a handler cue and a response intent"
      check rust/tests/web/issue-1589-calendar-currency.test.mjs
      marker "calendar meanings stay globally unique"
    regression calendar-pipe-packed-table-values
      introduced-by "PR #1590, merged as 015a6831"
      failed "seed_lino_values_never_pipe_pack_multi_values: handler-rules.lino:1236 year|years"
      check rust/tests/web/issue-1589-calendar-currency.test.mjs
      marker "handler table rows carry one surface each without pipe-packed aliases"
'''
ledger.write_text(source)

receipt={'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'packedRowsExpanded':packed,'expandedSurfaces':len(before_rows),'beforeSurfaceRows':before_rows,'afterSurfaceRows':after_rows,'surfaceSequencePreserved':before_rows==after_rows,'oldHandlerMeaning':'calendar-duration-sum','newHandlerMeaning':'calendar-duration-addition-cue','responseIntentRetained':'calendar-duration-sum','authorshipCredit':0}
(evidence/'migration.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
print('Expanded',packed,'packed rows into',len(before_rows),'individual surfaces, preserving their sequence; split the handler cue from the response intent.')
