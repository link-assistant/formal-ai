from pathlib import Path
for name,start,end in [('/tmp/issue-1580-research/read-python-review-page.py',1,150),('/tmp/issue-1580-research/record-python-fragment-checkpoint.py',1,160)]:
 lines=Path(name).read_text().splitlines();print(name,'lines',len(lines))
 for i in range(start-1,min(end,len(lines))):print(f'{i+1}: {lines[i]}')
