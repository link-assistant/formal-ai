from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/checks/source-operand-replays'
assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=root, text=True).strip() == 'issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == 'acb9fa51085c8ba88ff8fae006b45698d355921e'
assert subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=root, text=True).strip() == ''
path = base / 'manual-review.json'
review = json.loads(path.read_text())
for row in review['sourceFiles']:
    assert hashlib.sha256((root / row['path']).read_bytes()).hexdigest() == row['sha256']
review.update(sourcePatchLiterallyRead=True, sourceFileCount=3, reviewedAt=datetime.now(timezone.utc).isoformat())
path.write_text(json.dumps(review, indent=2) + '\n')
files = ['rust/tests/unit/meta_executor_parity.rs', 'rust/tests/web/issue-1580-production-composition.test.mjs']
subprocess.run(['git', 'add', '--', *files], cwd=root, check=True)
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=root, check=True)
subprocess.run(['git', '-c', 'gc.auto=0', 'commit', '-m', 'Replay native source-operand and membership-count regressions'], cwd=root, check=True)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
(base / 'local-source-commit.json').write_text(json.dumps({'head': head, 'publishedBaseline': 'acb9fa51085c8ba88ff8fae006b45698d355921e', 'pushed': False, 'nativeExecuted': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
print('Local source commit:', head)
print('No push; waiting for all current published-head results while continuing independent work.')
