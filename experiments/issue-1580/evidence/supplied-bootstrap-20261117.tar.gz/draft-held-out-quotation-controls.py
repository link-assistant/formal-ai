from pathlib import Path
import subprocess

source = Path('rust/tests/web/helpers/issue-1550-meta-executor-cases.mjs')
text = source.read_text()
anchor = "\n];\n\n/** Every case of the fixture, in order. */"
assert text.count(anchor) == 1
text = text.replace(anchor, '''
  ['adjacent-cjk-single-quote', "统计'盐和胡椒'并且报告大小", 'aggregation', ["统计'盐和胡椒'", '报告大小'], 'zh'],
  ['adjacent-cjk-double-quote', '统计"盐和胡椒"并且报告大小', 'aggregation', ['统计"盐和胡椒"', '报告大小'], 'zh'],
  ['russian-double-quote', 'Посчитай "соль и перец" и назови размер', 'aggregation', ['Посчитай "соль и перец"', 'назови размер'], 'ru'],
];

/** Every case of the fixture, in order. */''')
text = text.replace('...QUOTATION_CASES.map(([name, text, , parts]) => ({', "...QUOTATION_CASES.map(([name, text, , parts, language = 'en']) => ({")
before = "    name,\n    text,\n    language: 'en',\n    answers: Object.fromEntries"
assert text.count(before) == 1
text = text.replace(before, "    name,\n    text,\n    language,\n    answers: Object.fromEntries")
source.write_text(text)
source = Path('rust/tests/web/issue-1550-meta-executor.test.mjs')
text = source.read_text()
text = text.replace('for (const [name, text, relation, parts] of quotationCases)', "for (const [name, text, relation, parts, language = 'en'] of quotationCases)")
text = text.replace("assert.deepEqual(executor.splitRequest(text, 'en'), { relation, parts }, name);", 'assert.deepEqual(executor.splitRequest(text, language), { relation, parts }, name);')
source.write_text(text)
root = Path('experiments/issue-1580/evidence/checks/task-quotation-boundaries')
with (root / 'before-held-out-apostrophe-boundaries.log').open('wb') as log:
    result = subprocess.run(['timeout', '600', 'node', '--max-old-space-size=256', '--test', '--test-concurrency=1', str(source)], stdout=log, stderr=subprocess.STDOUT)
assert result.returncode == 1
assert 'adjacent-cjk-single-quote' in (root / 'before-held-out-apostrophe-boundaries.log').read_text()
print('Added three held-out multilingual controls; the CJK apostrophe boundary fails before the refinement')
