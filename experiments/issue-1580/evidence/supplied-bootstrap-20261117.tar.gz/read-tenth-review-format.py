from pathlib import Path
import json
for name in ['/tmp/issue-1580-research/read-csharp-page.py','/tmp/issue-1580-research/archive-self-reference.py','/tmp/issue-1580-research/archive-ninth-evidence.py']:
    p=Path(name)
    print('SCRIPT',p)
    print(p.read_text())
for language in ['go','java']:
    candidates=list(Path('docs/case-studies/issue-1580/templates').glob(f'{language}*semantic*'))
    for p in candidates:
        print('REVIEW',p)
        data=json.loads(p.read_text())
        print(json.dumps(data,indent=2)[:12000])
