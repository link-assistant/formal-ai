from pathlib import Path
import gzip,json
data=json.loads(gzip.decompress(Path('/tmp/issue-1580-research/header-round-preflight/feedback-pull-request-comments.json.gz').read_bytes()))
for row in data:
 print('\nCOMMENT',row['id'],row['user']['login'],row['html_url'])
 lines=row['body'].splitlines()
 assert len(lines)<=1500
 print('\n'.join(f'{i}: {line}' for i,line in enumerate(lines,1)))
