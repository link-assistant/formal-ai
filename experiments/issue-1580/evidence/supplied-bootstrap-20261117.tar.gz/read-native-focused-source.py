from pathlib import Path
import subprocess, gzip, re, ast, json
windows = [
 ("rust/tests/unit/specification/synthesis.rs", 240, 110),
 ("rust/tests/unit/specification/synthesis.rs", 420, 65),
 ("rust/tests/unit/specification/reasoning_loop.rs", 175, 60),
 ("rust/tests/unit/specification/spoken_hour_scheduling.rs", 1, 125),
]
for name,start,count in windows:
 lines=Path(name).read_text().splitlines()
 print("FILE",name,"LINES",len(lines),"WINDOW",start,count)
 for i in range(start-1,min(start-1+count,len(lines))): print(f"{i+1}: {lines[i]}")
wanted = {}
with gzip.open("experiments/issue-1580/evidence/ci/main-512ce428/44117975432.log.gz","rt") as stream:
 for number,line in enumerate(stream,1):
  if 82245<=number<=82250:
   value=re.sub(r'^\d{4}-\d\d-\d\dT\S+\s','',line.rstrip().split('\t',2)[-1])
   wanted[number]=value
for number,value in wanted.items():
 if len(value)<1200: print("LOG",number,value)
 elif "left:" in value or "right:" in value:
  label,payload = value.split(":",1)
  parsed=ast.literal_eval(payload.strip())
  print("LOG",number,label,"STRUCTURED",json.dumps(parsed,ensure_ascii=False))
 else: print("LOG",number,"OMITTED",len(value),"characters")
