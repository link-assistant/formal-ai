set -eu
node scripts/generate-runtime-feature-inventory.mjs --write
node experiments/formal_ai_subagent/local-gates.mjs --list > /tmp/issue-1580-research/local-gate-list.txt
PATH="/tmp/issue-1580-research/shellcheck-v0.11.0:$PATH" node experiments/formal_ai_subagent/local-gates.mjs > /tmp/issue-1580-research/all-local-gates-fourth.log 2>&1
tail -n 16 /tmp/issue-1580-research/all-local-gates-fourth.log
git diff --check
