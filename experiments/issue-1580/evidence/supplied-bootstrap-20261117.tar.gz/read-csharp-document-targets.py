from pathlib import Path
for name,first,last in [
 ('experiments/issue-1580/work-plan.md',1,90),
 ('docs/case-studies/issue-1580/templates/README.md',1,100),
 ('docs/case-studies/issue-1580/README.md',-35,0),
 ('experiments/issue-1580/evidence/templates/go-semantic-review.json',1,45),
]:
 p=Path(name)
 if not p.exists():
  print('MISSING',name)
  continue
 lines=p.read_text().splitlines()
 part=lines[first-1:last] if first>0 else lines[first:]
 print('FILE',name,'TOTAL LINES',len(lines))
 for line in part:print(line)
print('STATUS')
import subprocess
print(subprocess.check_output(['git','status','--short'],text=True))
