from pathlib import Path
path = Path('experiments/formal_ai_subagent/local-gates.mjs')
source = path.read_text().replace('--only check_file_size,web-ui-boundary', '--only check-file-size,web-ui-boundary')
needle = """const chosen = gates.filter((gate) =>
  (!only || only.includes(gate.name)) && (!match || gate.name.includes(match)));
mkdirSync(LOGS, { recursive: true });"""
replacement = """const chosen = gates.filter((gate) =>
  (!only || only.includes(gate.name)) && (!match || gate.name.includes(match)));
const known = new Set(gates.map(gate => gate.name));
const unknown = (only ?? []).filter(name => !known.has(name));
if (only?.length === 0 || unknown.length || chosen.length === 0) {
  const message = only?.length === 0 ? '--only requires at least one gate name.'
    : unknown.length ? `Unknown gate name(s): ${unknown.join(', ')}.`
    : 'No gates selected.';
  console.error(`${message} Use --list to inspect available gates.`);
  process.exit(1);
}
mkdirSync(LOGS, { recursive: true });"""
assert needle in source
path.write_text(source.replace(needle, replacement))
