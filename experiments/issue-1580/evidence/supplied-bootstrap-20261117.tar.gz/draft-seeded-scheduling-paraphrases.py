from pathlib import Path
import gzip,hashlib,json,os,re,subprocess,time
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/spoken-scheduling-paraphrases';test=root/'rust/tests/web/calendar-act-paraphrases.test.mjs'
assert not test.exists();test.write_text('''import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import test from 'node:test';
import {createWorkerContext, evaluate} from './support/browser-runtime.mjs';

const worker = createWorkerContext();
await evaluate(worker, 'loadSeed()');
const corpus = readFileSync(new URL('../../../data/benchmarks/self-use-intent-routing.lino', import.meta.url), 'utf8');
const family = corpus.slice(corpus.indexOf('  id "schedule_paraphrase"'), corpus.indexOf('self_use_case_spanish_routing_matrix'));
const prompts = [...family.matchAll(/^    prompt "(.*)"$/gmu)].map(match => match[1]);
assert.equal(prompts.length, 5);
for (const prompt of prompts) test('the calendar handler accepts the original scheduling act: ' + prompt, {timeout:15000}, () => {
  const answer = evaluate(worker, 'tryCalendarCreateEvent(' + JSON.stringify(prompt) + ', normalizePrompt(' + JSON.stringify(prompt) + '))');
  assert.equal(answer?.intent, 'calendar_create_event', JSON.stringify(answer));
  assert.match(answer.content, /BEGIN:VCALENDAR/u);
});
for (const prompt of [
  'I watched a schedule demonstration tonight.',
  'Schedule a meeting. The background mentions tonight.',
  'The document says: put me down at eight tonight.',
  'В тексте написано: запиши меня к команде на 14:00.',
  'पाठ में आज रात आठ बजे दर्ज कीजिए लिखा है।',
  '文档写着今晚八点帮我和亚历山大约一下。',
  'El texto dice: apúntame a las ocho de esta noche.',
  'Put me down tonight. Book another meeting tomorrow at 20:00.',
]) test('source text cannot schedule an event: ' + prompt, {timeout:15000}, () => {
  assert.equal(evaluate(worker, 'calendarCreateRequestSpan(' + JSON.stringify(prompt) + ')'), null);
});
''')
rows=[]
def run(label,expected):
 args=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1',str(test.relative_to(root))];started=time.monotonic();r=subprocess.run(args,cwd=root,env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256'),capture_output=True);raw=r.stdout+r.stderr;packed=gzip.compress(raw,mtime=0);(base/(label+'.log.gz')).write_bytes(packed);counts={key:int(re.search(r'^(?:ℹ|#) '+key+r' (\d+)',raw.decode(),re.M)[1]) for key in ['tests','pass','fail','skipped']};row={'name':label,'argv':args,'exitCode':r.returncode,'counts':counts,'seconds':round(time.monotonic()-started,3),'file':label+'.log.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'lines':len(raw.splitlines())};rows.append(row);(base/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True);print(raw.decode(),flush=True);assert r.returncode==expected
run('before',1)
path=root/'rust/src/solver_handlers/calendar_create.rs';text=path.read_text();old='''    let has_date_signal = has_day_ref || has_clock || has_relative_date || has_weekday;''';new='''    let has_clock_reference = lex.mentions_role("capability_clock_reference", normalized);
    let has_date_signal = has_day_ref || has_clock || has_relative_date || has_weekday || has_clock_reference;''';assert old in text;text=text.replace(old,new).replace('has_clock || has_relative_date || has_weekday || has_bound_day','has_clock || has_relative_date || has_weekday || has_bound_day || has_clock_reference')
old='''            || [ROLE_CALENDAR_RELATIVE_DATE, ROLE_CALENDAR_WEEKDAY]''';new='''            || [ROLE_CALENDAR_RELATIVE_DATE, ROLE_CALENDAR_WEEKDAY, "capability_clock_reference"]''';assert old in text;text=text.replace(old,new)
old='''        if action || elliptical {''';new='''        // The shared act lexicon already carries inflected stems. Keep its
        // evidence within this date-led request or an inflected initial act,
        // rather than copying another per-language imperative list here.
        let seeded_act = lexicon()
            .words_for_role("capability_act_schedule")
            .iter()
            .any(|word| {
                (date_led && request.contains(word.as_str()))
                    || request.strip_prefix(word.as_str()).is_some_and(|tail| {
                        tail.starts_with(is_word_character)
                    })
            });
        if action || elliptical || seeded_act {''';assert old in text;path.write_text(text.replace(old,new))
path=root/'js/worker/formal_ai_worker_calendar_and_proofs.js';text=path.read_text();old='''    const anchor = wordsForRole(ROLE_CALENDAR_RELATIVE_DATE).some(w => containsCalendarTerm(normalized, w)) ||''';new='''    const anchor = wordsForRole("capability_clock_reference").some(w => containsCalendarTerm(normalized, w)) ||
      wordsForRole(ROLE_CALENDAR_RELATIVE_DATE).some(w => containsCalendarTerm(normalized, w)) ||''';assert old in text;text=text.replace(old,new);old='''[ROLE_CALENDAR_RELATIVE_DATE, ROLE_CALENDAR_WEEKDAY]
      .some''';new='''[ROLE_CALENDAR_RELATIVE_DATE, ROLE_CALENDAR_WEEKDAY, "capability_clock_reference"]
      .some''';assert old in text;text=text.replace(old,new)
old='''    return action || (prefix && clock !== null && resolveTimezone(normalized) !== null && extractParticipantTitle(normalized) !== null);''';new='''    const seededAct = wordsForRole("capability_act_schedule").some(word =>
      (dateLed && request.includes(word)) || (request.startsWith(word) &&
        isCalendarWordCharacter(Array.from(request.slice(word.length))[0] || "")));
    return action || seededAct || (prefix && clock !== null && resolveTimezone(normalized) !== null && extractParticipantTitle(normalized) !== null);''';assert old in text;path.write_text(text.replace(old,new))
run('after',0)
(base/'outcome.json').write_text(json.dumps({'complete':True,'allPassedAfterFix':True,'nativeExecutedLocally':False,'originalNativeTestUnchanged':True,'independentAuthorshipCredit':0,'spokenHourValueAccuracyStillOpen':True},indent=2)+'\n')
