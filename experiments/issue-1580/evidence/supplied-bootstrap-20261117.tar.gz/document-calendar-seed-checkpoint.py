from pathlib import Path

checkpoint = '''# Calendar seed integrity checkpoint

Draft work for [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581).
The published input is `2ec6ef93a80c7081a46816d1242bc0f7b843d5ff`, including
main `015a683197c89e8f74375b097e8dd06a57dcea8f` (PR #1597).

## Reproduction and repair

[Main pipeline 44188508650](https://github.com/link-assistant/formal-ai/actions/runs/44188508650)
reports a duplicate `calendar-duration-sum` meaning at log lines 65552–65553
and a pipe-packed `year|years` table value at lines 65581–65583. Existing native
data guards reject both representations. The new JavaScript replays use the
existing fast calendar/currency test file, so they run before merging.
With unchanged seed data, 40 of 42 tests pass and these two replays fail.
A separate negative control detects duplicate meanings within and across files.

The addition cue becomes `calendar-duration-addition-cue`; the existing
`calendar-duration-sum` response intent remains unchanged. Twenty-one packed
rows become 55 separate language/surface pairs in their original order.
The complete migration receipt compares every expanded surface. JavaScript and
Rust consumers read the scalar rows directly; generated package seed mirrors
are refreshed through the maintained writer. All original calendar/currency
cases remain, with six additional English/Russian alias prompts in one case.

After the repair, all 43 calendar/currency tests and all four main-regression
ledger tests pass without skips. Rust formatting passes for both changed files;
the native implementations have not run locally. The ledger records both
main-only failures and selects the existing fast test file for each replay.

## Hosted failures and TypeScript mirrors

All 23 workflows on `2ec6ef93` finish: 21 succeed and two fail. The initial
failures in [Layered CI 44197052235](https://github.com/link-assistant/formal-ai/actions/runs/44197052235)
and [pipeline 44197053206](https://github.com/link-assistant/formal-ai/actions/runs/44197053206)
both occur during checkout: curl error 28, a bad pack header, and an unavailable
promisor blob. The blob is the six-byte `.bun-version`, rather than a large
evidence file. Full original logs and exact hashes are retained.

One failed-job retry leaves the pipeline checkout failure unchanged. The Layered
JavaScript group succeeds, exposing a stale TypeScript calendar/proofs mirror
at retry log lines 9493–9495. Both that mirror and the newly changed duration
mirror are regenerated with `scripts/translate-es.mjs`. The complete parity
check passes for all 717 sources, and all 12 translator tests pass.
Native type/lint CI passed on the published input; this is not proof of native
runtime behavior after the scalar-row change. Next-head hosted checks and the
complete current-source JavaScript gate set remain pending.

## Evidence and unfinished acceptance

Full before/after test logs, expanded surfaces, original seed bytes, generated
projection receipts, and TypeScript before-images are under
`experiments/issue-1580/evidence/checks/calendar-seed-integrity/`.
Hosted logs and metadata are under
`experiments/issue-1580/evidence/ci/{main-015a6831,published-2ec6ef93}/`.
The cancelled main Layered aggregate is partial; unavailable job payloads are
not treated as inspected. Targeted failure-payload review is not full-log review.

The supplied-passage parent still loses context between child requests. The
finite eight-case context-binding probe uses mocked transport and records this
unresolved behavior separately from the already passing transport guards.
General context binding, native/main runtime failures, benchmark and warning
criteria, dependency migration, full template semantic review, historical
evidence and live identity remain unfinished. The PR stays draft and unmerged.
Independent Formal AI reasoning acceptance remains 0/20; supplied scripts,
patches and conclusions receive zero independent authorship credit.
'''
path = Path('docs/case-studies/issue-1580/calendar-seed-checkpoint.md')
assert not path.exists()
path.write_text(checkpoint)
for name, text in [
    ('experiments/issue-1580/work-plan.md', '''

## Calendar seed integrity and TypeScript parity

The 2ec6ef93 published head has 21 successful workflows and two failures.
Both initial failures are checkout curl-28 failures for the six-byte
`.bun-version` blob. After one failed-job retry, Layered JavaScript succeeds
and exposes one stale TypeScript mirror; the pipeline checkout still fails.
Preserve all attempts and fix every actionable source failure before publishing.
The official translator now verifies all 717 sources and passes 12 tests.

Main 015a6831 has two new data integrity failures: a duplicate calendar meaning
and packed handler-table aliases. The existing fast calendar/currency file
reproduces both failures (40/42 pass before), then passes all 43 tests after the
cue rename and lossless 21-to-55 row expansion. All four ledger tests pass;
the maintained mirrors and two-file Rust formatting pass without native execution.
Draft all changes, run the full JavaScript gates, collect every current-head
failure, review the diff and fresh comments/main ancestry, then make one batch
push and inspect every next-head hosted result. Broader acceptance remains
unfinished and reasoning acceptance remains 0/20. See
docs/case-studies/issue-1580/calendar-seed-checkpoint.md.
'''),
    ('docs/case-studies/issue-1580/README.md', '''

The [calendar seed checkpoint](calendar-seed-checkpoint.md) records two
main-only data failures, their failing-before replays and lossless scalar-row
repair (43 passing calendar/currency tests, four ledger tests). The published
2ec6ef93 head has checkout failures and a stale TypeScript mirror exposed by
one retry; the official parity check now passes all 717 sources and 12 tests.
Full current-source gates and next-head hosted checks remain pending. Native
runtime, general recursive context binding and all broader acceptance remain
unfinished; independent reasoning acceptance remains 0/20.
'''),
]:
    file=Path(name)
    assert text.strip() not in file.read_text()
    file.write_text(file.read_text()+text)
print('Recorded exact reproduction, hosted attempts, verification, and unfinished criteria.')
