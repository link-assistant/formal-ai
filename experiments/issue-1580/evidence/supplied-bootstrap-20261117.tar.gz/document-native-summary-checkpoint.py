from pathlib import Path
import datetime, gzip, hashlib, json

root = Path('/tmp/gh-issue-solver-1794900398048')
checks = root / 'experiments/issue-1580/evidence/checks/native-summary-expectation'
results = json.loads((checks / 'results.json').read_text())
assert results['complete']
ci = json.loads(gzip.decompress((root / 'experiments/issue-1580/evidence/ci/native-php-fda677ef/completed-results.json.gz').read_bytes()))
assert ci['workflowCount'] == 23 and ci['success'] == 22 and len(ci['failed']) == 1
assert ci['failed'][0]['id'] == 44309937639
text = '''# Isolated native synthesis checkpoint

PR: https://github.com/link-assistant/formal-ai/pull/1581

Published input `fda677ef9f25692b7b3823556f1349839a71f7a3` completes all 23 workflows: 22 succeed and CI/CD Pipeline fails. The complete failed workflow, both failed job logs, both JavaScript shard logs, API payloads and digest receipts are retained under `experiments/issue-1580/evidence/ci/native-php-fda677ef/`.

The [actual native job](https://github.com/link-assistant/formal-ai/actions/runs/44309937639/job/134821269126) compiles and runs the focused targets. Literal lines 1624–1685 show calendar/currency **1/1**, executor **8/8**, forced functions **1/1**, and synthesis **11/12**. The two new production executor cases actually execute: remainder-sale source operands produce 36 and 72, and the membership-source count produces three. The synthesis target also passes courtesy/question ordering, filtered count, algebra and renumbered word problems. A failure stops the later workflow commands; this checkpoint does not claim a new native HTTP pass.

The sole synthesis failure is `shared_cross_runtime_synthesis_fixture_matches_rust_solver`, at `synthesis.rs:88`. Native log lines 1670–1685 preserve its complete diagnostic:

```
actual: The Halley research station, opened in 1956, is used to study the Antarctic ice shelf. It provides year-round measurements of ozone and sea temperature.
stale expected: The Halley research station opened in 1956 is used to study the Antarctic ice shelf.
```

This is a stale dormant test expectation. Commit `ea67811fd82f38f12ca91e2d6c042d7e0afc8801` made free-text summaries rank complete sentences so governed clauses remain intact. Both existing handler specifications, `rust/tests/unit/web-engine-core/issue_1174_text_transform.rs` and `rust/tests/web/issue-1174-text-transform-parity.test.mjs`, already pin the two complete sentences. Both production implementations use that whole-sentence path and keep two of five substantive sentences under the existing divisor-three budget. No production summarizer, budget, shared prompt or forbidden fragment is changed.

Source commit `e3b50624c1c7f694373cb406fbb2293f49cd05a9` corrects the exact native answer to the already documented contract and identifies the case ID in future assertion failures. Exact equality remains mandatory. All **14 existing text-transform tests**, **four source-payload routing tests**, **six affected gates**, edition-2024 Rust formatting and whitespace checks pass. Complete local logs and hashes are retained in `experiments/issue-1580/evidence/checks/native-summary-expectation/`; all five logs were literally reviewed and hash verified. No local Rust build runs. Hosted execution of the correction remains pending.

The bounded twelve-case browser audit confirms seven of eleven native documented answers exactly, including Halley and all later host-independent cases. It retains four differences rather than changing assertions: algebra and word problems use explanatory browser renderings; membership counting and generated Python remain explicitly unverified at the browser executor boundary. The formalization case is host dependent and is not exact-compared. The audit exits one for those four observations. Its complete responses, expected strings and digests remain preserved; it is not a passing parity claim or independent reasoning credit.

Both Layered CI groups succeed: group 1 reports **1,190 passes / four skips**, group 2 **1,533 passes / 13 skips**, with zero failures and cancellations. Their complete payload hashes are verified; only named result ranges are literally reviewed. The complete 215-line Pipeline Status job is read: native-type-check is its only failed prerequisite, with no cancellation. Native log lines 1570–1686 were read literally; the full native and full workflow payloads are retained without claiming complete literal review.

Fresh feedback at 2026-11-18T13:20:18Z contains one issue comment, nine PR conversation comments, no inline comments, no reviews and no required sub-issues. The entire issue and all comment bodies are read. No acceptance requirement is removed. The prior publication retains all 94 command payloads with hashes; its 895-line API source patch remains retained without a literal-review claim.

Every broader unfinished criterion remains in the work plan, including full template applicability and independent Formal AI reasoning **0/20**. Supplied code, experiments and conclusions receive zero independent credit. Keep PR #1581 draft and unmerged.
'''
(root / 'docs/case-studies/issue-1580/native-synthesis-checkpoint.md').write_text(text)
review = {'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'headWithFailure': ci['head'], 'workflowsComplete': 23, 'workflowsSuccessful': 22, 'allActionableFailures': [{'run': 44309937639, 'job': 134821269126, 'test': 'shared_cross_runtime_synthesis_fixture_matches_rust_solver', 'line': 88, 'rootCause': 'Dormant exact answer predates whole-sentence summary contract', 'sourceCorrection': 'e3b50624c1c7f694373cb406fbb2293f49cd05a9'}], 'pipelineStatusOnlyFailedPrerequisite': 'native-type-check', 'nativeLiteralRanges': [[1570,1686]], 'pipelineStatusLiteralRanges': [[1,215]], 'fullNativeLogLiterallyRead': False, 'fullFailedWorkflowLiterallyRead': False, 'localCheckLogsLiterallyRead': [row['name'] for row in results['checks']], 'allLocalCheckPayloadHashesVerified': True, 'browserAuditExactMatches': 7, 'browserAuditFullAnswerDifferences': 4, 'browserAuditHostDependentNotCompared': 1, 'browserAuditPassingParityClaim': False, 'nativeCorrectionExecutedLocally': False, 'nativeCorrectionHostedVerificationPending': True, 'allIssueAcceptanceComplete': False, 'independentAuthorshipCredit': 0}
(checks / 'review.json').write_text(json.dumps(review, indent=2) + '\n')
work = root / 'experiments/issue-1580/work-plan.md'
source = work.read_text()
old = '- [ ] Collect every fda677ef9 workflow, including new native synthesis/source-operand execution, before the next push.'
assert source.count(old) == 1
source = source.replace(old, '- [x] Collect all 23 fda677ef9 workflows: 22 pass; native synthesis exposes one stale exact summary assertion. The new native source-operand/count tests actually pass. Preserve the failed workflow and both failed jobs, review the actual failure and fix it in the next batch.')
source += '''
## Native summary assertion follow-through (2026-11-18)

- [x] Trace the sole fda native failure to the dormant synthesis assertion: both current handler specifications already require two complete Halley sentences. Correct exact equality without changing production semantics, shared prompts, budgets or forbidden fragments; add the case ID to diagnostics.
- [x] Pass 14 existing text-transform and four routing tests, six affected gates, Rust 2024 formatting and whitespace. Read every local log and hash-verify it. Commit the atomic source correction as e3b50624c.
- [x] Retain the bounded twelve-case browser audit, including four full-answer differences and one host-dependent case. This is an observation with a nonzero audit exit, not a passing parity claim. Preserve browser executor refusals explicitly.
- [x] Retain all 94 prior publication command payloads and actual 22/23 workflow outcomes; read the complete downstream Pipeline Status failure. Refresh/read the entire issue and all feedback: 1 issue / 9 PR conversation / 0 inline / 0 review / 0 sub-issues.
- [ ] Publish the complete PHP/source-assertion batch after staged gates and the single-push gate, then verify actual native execution on that exact head.
- [ ] Fresh-check and file the separate PHP ignored-push-result report using immutable published evidence. Complete every prior broader requirement; independent reasoning remains 0/20, PR #1581 draft and unmerged.
'''
work.write_text(source)
body = '''CI missed native regression inputs and source ownership failures, while compound task parsing lost quoted passages and accepted unverified child drafts. This draft repairs those boundaries, source-derived algebra/counting behavior, request-local constraints and recorded CI fixtures. It also retains executable CI/CD template comparisons and upstream defect reports. The complete issue remains unfinished; keep this PR draft and unmerged.

Fixes #1580

Changes:

- Preserve ASCII and CJK quoted passages and seeded passage cues during JavaScript/Rust decomposition. Keep genuine surrounding tasks, escapes and apostrophes; retain all original shared cases and add bounded controls across five languages.
- Keep nonempty unverified drafts unresolved, including cached children and all-required parents. Retain only selected-child evidence through composition, caching and answer adoption; exclude unused alternatives.
- Reuse calculation parsers for bound algebra questions. Replay source operands for renumbered remainder-sale problems and derive object counts from membership evidence. Preserve existing answer, trace and negative controls.
- Correct decoded native structural values and calendar alias ownership without losing scalar spellings or order. Preserve request-local output constraints, path-bound OpenCode reads, declared response languages, counting proofs and explicit fixture network policy.
- Admit isolated native regression sources and embedded fixtures even when production files do not change. Run the existing synthesis contracts, executor parity, calendar/currency and forced-function targets in hosted CI. Align one dormant synthesis expectation with the already documented whole-sentence summary contract; keep exact equality.
- Repair change detection, required-context reporting, source placement/ownership fixtures and bounded cache diagnostics. Reduce JavaScript checkout inputs while preserving consumed archives and generated workflow operations. Keep current main merged and required native job context present for source-free changes.
- Preserve pinned template files and actual release-path regressions. The PHP release guard can admit unsuccessful quality checks; separately, its release CLI reports success after rejected branch/tag pushes. Candidates are tested in disposable copies; upstream repairs are not claimed. Automatic-release admission is reported in [PHP template #27](https://github.com/link-foundation/php-ai-driven-development-pipeline-template/issues/27).

Latest verification:

- Published head `fda677ef9` completes **23 workflows: 22 pass, one fails**. The [actual native job](https://github.com/link-assistant/formal-ai/actions/runs/44309937639/job/134821269126) passes calendar/currency **1/1**, executor **8/8**, forced functions **1/1**, and synthesis **11/12**. The new native source-operand cases execute and produce **36**, **72** and **3**. Its sole failure is a stale condensed Halley answer in the newly admitted synthesis specification; both existing handler specifications already require the two complete sentences returned by Rust. The correction is committed, with hosted re-execution pending.
- That head's Layered CI groups report **1,190 and 1,533 passes**, **four and 13 skips**, zero failures and cancellations. The full failed workflow, both failed jobs, both JavaScript logs, identities and exact review ranges are retained in the [native synthesis checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/native-synthesis-checkpoint.md).
- The summary correction passes **14 existing text-transform tests**, **four routing tests**, **six affected gates**, Rust 2024 formatting and whitespace. A twelve-case browser audit confirms the Halley answer exactly and retains four other full-answer differences, including two unverified browser executor results. This audit is not a passing parity claim.
- PHP rejected-publication regression: **9/9 focused cases**, **52/52 maintained template-observation tests**, and **six affected gates** pass. Real local bare remotes cover both release modes, branch/tag rejection, failure propagation and successful publication. The original files remain hash verified; PHP subprocesses use a 32 MiB heap and finite deadlines. See the [PHP push checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/php-push-integrity-checkpoint.md). Its distinct upstream report is prepared, pending immutable evidence publication and a fresh duplicate/source check.
- Before the preceding shared-data publication, **all 86 executable local gates pass**, with **52 explicit native/context exclusions and zero failures**, under a 256 MiB Node heap cap. The complete aggregate, detailed payloads and hashes are retained. All **22 native admission-policy**, **two governed fixture-integrity**, and **34 identifier** tests pass. No local Rust build runs.
- Earlier published algebra head `acb9fa51` passes **23/23 workflows**, including actual native algebra, calendar/currency, forced functions and both HTTP modes. Original failure, correction and retry histories remain in the [work plan](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/experiments/issue-1580/work-plan.md) and linked checkpoints; they are separate from current-head verification.

Reproduce focused checks separately:

```sh
timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/issue-1174-text-transform-parity.test.mjs
timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/summary-payload-routing.test.mjs
timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 experiments/issue-1580/template-php-push-integrity.test.mjs
timeout 600 node --max-old-space-size=256 --test --test-concurrency=1 rust/tests/web/issue-1580-template-observations.test.mjs
node --max-old-space-size=256 experiments/formal_ai_subagent/local-gates.mjs
```

Unfinished acceptance remains explicit in the work plan: all original main failures (53 distinct native panic headers and three budget terminations), semantic regressions and benchmark floors, full file comparison/applicability for all eight templates, dependency migrations and warnings, historical cache/Docker and required-context reproduction, live delivery/model identity, and general parent/passage binding and provenance. Complete literal review of retained native payloads is unfinished. Java historical review is **113/254 continuous pages**, with 111 complete files, one partial and 7,760 source lines; pages 114–254 and wider semantic review remain open.

Independent Formal AI reasoning acceptance remains **0/20**. Supplied commands, patches, scripts, source reading and upstream reports receive zero independent authorship credit. Passing CI does not complete those criteria.
'''
assert body.count('Fixes #1580') == 1
(root / 'experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md').write_text(body)
print(json.dumps({'checkpointLines': len(text.splitlines()), 'bodyLines': len(body.splitlines()), 'bodyBytes': len(body.encode()), 'summarySourceCommit': 'e3b50624c1c7f694373cb406fbb2293f49cd05a9', 'fullIssueComplete': False}))
print(text)
print(body)
