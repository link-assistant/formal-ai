from pathlib import Path
import hashlib, json, subprocess, datetime

def run(args):
    return subprocess.run(args, capture_output=True, check=True).stdout

repository = 'link-foundation/python-ai-driven-development-pipeline-template'
pin = '9c018344df2e6b09a0f2496897b14a002dad62f4'
for path in [
    'experiments/issue-1580/template-python-fragment-integrity.test.mjs',
    'experiments/issue-1580/evidence/checks/python-fragment-integrity.json',
]:
    upstream = run(['gh', 'api', '-H', 'Accept: application/vnd.github.raw+json', f'repos/link-assistant/formal-ai/contents/{path}?ref={pin}'])
    assert upstream == Path(path).read_bytes()
    print(json.dumps({'publishedEvidence': path, 'sha256': hashlib.sha256(upstream).hexdigest(), 'commit': pin}))
pages = json.loads(run(['gh', 'api', f'repos/{repository}/issues?state=all&per_page=100', '--paginate', '--slurp']))
issues = [row for page in pages for row in page]
Path('/tmp/issue-1580-research/python-fragment-final-upstream-issues.json').write_text(json.dumps(issues, indent=2) + '\n')
for row in issues:
    title = row['title'].lower()
    if any(word in title for word in ['changelog', 'scriv', 'fragment', 'collision', 'overwrite', 'changeset']):
        print(json.dumps({'number': row['number'], 'title': row['title'], 'url': row['html_url'], 'body': row.get('body', '')}))
latest = run(['gh', 'api', '-H', 'Accept: application/vnd.github.raw+json', f'repos/{repository}/contents/scripts/create_manual_changeset.py'])
assert hashlib.sha256(latest).hexdigest() == '69dff7dae4675f4ae2573761be12b72930c6cdc947d9e7d0aa0ea442fcc5e9f2'
print(json.dumps({'checkedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'issueAndPullRequestCount': len(issues), 'latestSourceByteIdentical': True}))
files = run(['rg', '--files', 'experiments/issue-1580']).decode().splitlines()
print('RECORD PATHS')
print('\n'.join(path for path in files if any(word in path for word in ['identit', 'filed-issues', 'csharp-changeset-report'])))
