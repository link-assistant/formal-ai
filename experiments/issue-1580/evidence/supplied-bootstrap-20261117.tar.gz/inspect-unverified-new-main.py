from pathlib import Path
import gzip,hashlib,json,subprocess

root=Path('/tmp/gh-issue-solver-1794900398048')
base=Path('/tmp/issue-1580-research/unverified-status-main-update')
base.mkdir(exist_ok=False)
def read(label,arguments):
    result=subprocess.run(arguments,cwd=root,capture_output=True)
    (base/(label+'.stdout')).write_bytes(result.stdout)
    (base/(label+'.stderr')).write_bytes(result.stderr)
    assert result.returncode==0,(label,result.stderr.decode())
    return result.stdout.decode()
for label,args in [('main-sha',['git','rev-parse','origin/main']),('head-sha',['git','rev-parse','HEAD']),('incoming-commits',['git','log','--format=%H %cI %s','015a683197c89e8f74375b097e8dd06a57dcea8f..origin/main']),('incoming-stat',['git','diff','--stat','015a683197c89e8f74375b097e8dd06a57dcea8f','origin/main']),('incoming-names',['git','diff','--name-status','015a683197c89e8f74375b097e8dd06a57dcea8f','origin/main']),('fetch-output',['python3','-c',"from pathlib import Path; print(Path('/tmp/issue-1580-research/unverified-status-publication/fetch-main.stderr').read_text())"])]:
    value=read(label,args)
    assert len(value.splitlines())<=1500 and len(value)<=40000
    print(label)
    print(value)
patch=read('incoming-diff',['git','diff','--no-ext-diff','--no-color','015a683197c89e8f74375b097e8dd06a57dcea8f','origin/main'])
print(json.dumps({'fullDiffBytes':len(patch.encode()),'fullDiffLines':len(patch.splitlines()),'location':str(base/'incoming-diff.stdout')}))
if len(patch.splitlines())<=1500 and len(patch.encode())<=40000:
    print('FULL INCOMING PATCH')
    print(patch)
