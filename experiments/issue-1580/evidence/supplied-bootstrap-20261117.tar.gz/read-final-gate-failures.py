from pathlib import Path
import json
base=Path('experiments/issue-1580/evidence/checks/main-merge-444575f2')
print('COMPLETE',(base/'all-local-gates.json').exists())
for name in ['check-worker-line-budget-js-twin','check-worker-line-budget']:
    path=Path('experiments/formal_ai_subagent/sandboxes/gates')/(name+'.log')
    print('GATE',name,path.read_text())
for name in ['js/worker/formal_ai_worker_solve.js','ts/worker/formal_ai_worker_solve.ts']:
    rows=Path(name).read_text().splitlines();print('WORKER',name,len(rows))
    print('\n'.join(f'{n+1}: {row}' for n,row in enumerate(rows[:65])))
for name in ['.github/workflows/provenance-native.yml','.github/workflows/regenerate-native-session-projections.yml']:
    rows=Path(name).read_text().splitlines();print('WORKFLOW',name,len(rows))
    print('\n'.join(f'{n+1}: {row}' for n,row in enumerate(rows[:85])))
