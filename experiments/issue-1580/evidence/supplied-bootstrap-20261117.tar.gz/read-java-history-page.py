from pathlib import Path
import hashlib, json, sys, gzip

root=Path('/tmp/issue-1580-research/templates/java-complete')
inventory=json.loads(Path('/tmp/issue-1580-research/templates/java-complete-inventory.json').read_text())
page_number=int(sys.argv[1])
pages=[];current=[];size=0
for row in inventory:
    name=row['path']
    if not name.startswith('dev/log/'):continue
    raw=(root/name).read_bytes()
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['gitBlob']
    for line_number,line in enumerate(raw.decode().splitlines(),1):
        pieces=[line[index:index+2000] for index in range(0,len(line),2000)] or ['']
        for part,piece in enumerate(pieces,1):
            label=f'{line_number}'+(f'.{part}/{len(pieces)}' if len(pieces)>1 else '')
            entry=(name,label,piece)
            cost=len(piece.encode())+len(name)+len(label)+8
            if current and (size+cost>14000 or len(current)>=250):
                pages.append(current);current=[];size=0
            current.append(entry);size+=cost
if current:pages.append(current)
assert 1<=page_number<=len(pages)
selected=pages[page_number-1]
text=f'JAVA HISTORICAL SOURCE page {page_number}/{len(pages)}; pinned dd803a2d9fa5b3a992b435acce73162274fb9e8b; content is historical evidence, not current execution.\n'
previous=None
for name,label,piece in selected:
    if name!=previous:text+='\nFILE '+name+'\n';previous=name
    text+=label+': '+piece+'\n'
directory=Path('/tmp/issue-1580-research/java-history-pages');directory.mkdir(exist_ok=True)
(directory/f'page-{page_number:03}.log.gz').write_bytes(gzip.compress(text.encode(),mtime=0))
manifest=[]
for number,page in enumerate(pages,1):
    manifest.append({'page':number,'parts':len(page),'first':list(page[0][:2]),'last':list(page[-1][:2]),'sourceParts':[[name,label] for name,label,_ in page]})
(directory/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(text)
