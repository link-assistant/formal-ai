set -eu
rg -n 'SCCACHE_(LOG|ERROR_LOG)|sccache.*(log|stat)|cache.*diagnostic' .github/workflows .github/actions scripts | head -n 85
rg --files scripts rust/tests/web | rg 'sccache|cache|test-duration|test-tim|prebuilt'
tail -n 8 /tmp/issue-1580-research/all-local-gates-fifth.log
rustfmt --edition 2024 scripts/detect-code-changes.rs
rustfmt --edition 2024 --check scripts/detect-code-changes.rs
wc -l scripts/detect-code-changes.rs
git diff --check
