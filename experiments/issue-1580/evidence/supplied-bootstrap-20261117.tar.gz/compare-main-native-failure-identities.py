import json, pathlib

root = pathlib.Path('experiments/issue-1580/evidence/ci')
old = json.loads((root / 'main-512ce428/native-failure-inventory.json').read_text())
new = json.loads((root / 'main-826289fc/pipeline-native-failure-inventory.json').read_text())
old_names = {row['test'] for row in old['failedNativeTests']}
new_names = {row['test'] for row in new['failures']}
print(json.dumps({'old': len(old_names), 'new': len(new_names), 'unchanged': len(old_names & new_names), 'newly_observed': sorted(new_names - old_names), 'not_seen_in_new_run': sorted(old_names - new_names)}, indent=2))
lines = pathlib.Path('/tmp/issue-1580-research/pipeline-44157125186.log').read_text().splitlines()
for first, last in [(47495, 47535), (37450, 37480), (58406, 58437), (26126, 26155)]:
    print(f'LOG RANGE {first}-{last}')
    for n in range(first-1, last):
        line = lines[n]
        if len(line) <= 1800:
            print(f'{n+1}: {line}')
        else:
            print(f'{n+1}: long {len(line)}-character diagnostic retained in complete raw log; omitted here')
