from pathlib import Path
import gzip, hashlib, json, re, shutil, subprocess

root=Path('/tmp/issue-1580-research')
evidence=Path('experiments/issue-1580/evidence')
listed={line.split()[1] for line in (root/'local-gate-list.txt').read_text().splitlines() if line.startswith(('run ', 'skip '))}
outcomes={}
for filename in ['all-local-gates-fourth.log','all-local-gates-fourth-remainder.log']:
    for line in (root/filename).read_text().splitlines():
        match=re.match(r'^(PASS|SKIP|FAIL)\s+(\S+)',line)
        if match:
            assert match[2] not in outcomes,match[2]
            outcomes[match[2]]=match[1]
assert set(outcomes)==listed,{'missing':sorted(listed-set(outcomes)),'extra':sorted(set(outcomes)-listed)}
assert 'FAIL' not in outcomes.values()
counts={status:list(outcomes.values()).count(status) for status in ['PASS','SKIP','FAIL']}
assert counts=={'PASS':86,'SKIP':52,'FAIL':0},counts
checks=evidence/'checks'
for filename in ['documentation-reporting.log','rust-specification-fixture-integrity-current.log','rust-specification-unicode-identifiers-current.log','default-branch-build-policy-current.log','stale-pull-request-report-current.log','all-local-gates-fourth.log','all-local-gates-fourth-remainder.log']:
    shutil.copyfile(root/filename,checks/filename)
(checks/'all-local-gates-fourth-summary.json').write_text(json.dumps({'total':len(listed),'counts':counts,'interruptedInvocation':{'limitMilliseconds':600000,'complete':False,'log':'all-local-gates-fourth.log'},'completedRemainder':'all-local-gates-fourth-remainder.log','outcomes':outcomes},indent=2)+'\n')
target=evidence/'ci'/'dd334ef6a'
target.mkdir(exist_ok=True)
records=[]
for path in sorted((root/'current-head-ci').iterdir()):
    if not (path.name=='runs.json' or path.suffix=='.json' or path.name.endswith('.log.gz')):continue
    destination=target/path.name
    shutil.copyfile(path,destination)
    data=path.read_bytes()
    record={'file':path.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    if path.name.endswith('.log.gz'):
        raw=gzip.decompress(data)
        record.update(uncompressedSha256=hashlib.sha256(raw).hexdigest(),lines=len(raw.splitlines()))
    records.append(record)
(target/'index.json').write_text(json.dumps({'headSha':'dd334ef6a8d5bbef80795b6721cca9b706ad9447','failedRuns':[44059368525,44059369287,44059368522],'files':records},indent=2)+'\n')

case=Path('docs/case-studies/issue-1580/README.md')
text=case.read_text().replace('`recipe-handoff-receipts.test.mjs`','`recipe-resume-policy-notation.test.mjs`')
marker='## Full template comparison\n'
addition='''## Hosted CI follow-up on 17 November

All 24 runs on `dd334ef6a8d5bbef80795b6721cca9b706ad9447` completed. The three failed workflows and their complete logs are retained under `evidence/ci/dd334ef6a/`; the other runs must not be treated as proof that scope-gated heavy paths executed.

- Documentation policy [44059368525](https://github.com/link-assistant/formal-ai/actions/runs/44059368525), lines 202 and 2544–2610: the old policy still required a PR path filter that suppressed required contexts. The policy now exempts only the release workflow's PR trigger; its heavy main push stays filtered. The 32-test regression executes retained job/step conditions and rejects build admission, forced compilation, restored PR filters and an unguarded compiler step.
- CI/CD Pipeline [44059369287](https://github.com/link-assistant/formal-ai/actions/runs/44059369287), lines 8189–8198: clippy rejected an unused `intent` at `rust/src/solver.rs:605`. The redundant binding is removed; the validated candidate still supplies its own intent. Formatting passes; hosted compilation must verify the correction.
- Layered CI [44059368522](https://github.com/link-assistant/formal-ai/actions/runs/44059368522): group 1 repeated the documentation-policy mismatch; group 2 detected stale source fingerprints in the governed Unicode witness (lines 3919, 4170 and 4191). The explicit reviewed-baseline refresh changes 20 hash leaves and preserves all 221 complete cases and assertions; the reader is unchanged. The full object diff is retained in `checks/governed-baseline-review.json`. Fixture integrity (2 tests), Unicode specification (34), build policy (21) and stale-PR reporting (6) pass locally.

The two hosted JavaScript groups consumed 259 and 168 seconds of their unchanged 360-second allowances. These failures were policy/source-witness mismatches, not shard timeouts. This does not verify native shard headroom or the unexecuted external benchmarks.

The latest local gate invocation reached its 600-second command-wrapper limit without a reported gate failure. Its uncompleted remainder was then run separately: all 138 registered gates are accounted for, with 86 passes, 52 explicit skips and zero failures. Both logs and a complete outcome map are retained; the interrupted invocation is recorded as incomplete rather than silently relabelled a pass.

'''
assert marker in text and '## Hosted CI follow-up on 17 November' not in text
case.write_text(text.replace(marker,addition+marker))
plan=Path('experiments/issue-1580/work-plan.md')
plan.write_text(plan.read_text()+'''\n## 17 November hosted-CI repair round

Collected every failed workflow on dd334ef6a after all 24 runs completed, preserving full logs and source identities. Fixed the required-context documentation-policy mismatch, the sole native clippy diagnostic (unused intent), and stale governed-witness fingerprints. The witness review preserves all 221 cases and changes only 20 source hashes. Focused policy/specification regressions pass. The complete 138-gate inventory passes or explicitly skips across the interrupted full invocation and its separately completed remainder; no native execution is claimed. Push this batch once, then inspect all final-head results before claiming verification. The broader unfinished criteria above remain active.
''')
changelog=Path('changelog.d/20261117_120000_issue-1580-ci-regressions.md')
changelog.write_text(changelog.read_text()+'- Keep required PR context reporters admitted by the documentation filter policy, with behavioral checks that documentation changes select no build or publication.\n- Refresh reviewed governed source fingerprints without changing their cases or assertions, and remove the unused native candidate binding rejected by clippy.\n')
body=root/'pr-body.md'
value=body.read_text().replace('Full local JavaScript gates: **86 passed, 52 explicitly skipped, zero failed** (138 total).','Full local JavaScript gates: **86 passed, 52 explicitly skipped, zero failed** (138 total), accounted across an interrupted full invocation and its completed remainder.')
value=value.replace('required-context policy 21 + 6;','required-context policy 32 + 21 + 6; governed Unicode specification 34 and fixture integrity 2;')
value=value.replace('Verification:\n','The first hosted round exposed three actionable failures: the documentation filter policy still rejected required-context reporting, clippy found one unused native binding, and the governed witness contained stale source hashes. This batch fixes all three; the witness refresh preserves all 221 cases and changes only 20 hash leaves. Full logs and the reviewed object diff are retained. Final-head CI is still required.\n\nVerification:\n')
body.write_text(value)
subprocess.run(['git','diff','--check'],check=True)
print('Retained 3 failed hosted runs, 5 focused test logs, and all 138 local gate outcomes:',counts)
