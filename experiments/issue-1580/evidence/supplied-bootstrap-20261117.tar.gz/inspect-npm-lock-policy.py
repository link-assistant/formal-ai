from pathlib import Path
import subprocess,json
r=Path('/tmp/gh-issue-solver-1794900398048')
for args in [['npm','--version'],['git','diff','--stat'],['rg','-n','install-links|package-lock|picomatch|npm audit','scripts','experiments/formal_ai_subagent/local-gates.mjs','desktop/.npmrc','vscode/.npmrc','.npmrc']]:
 cp=subprocess.run(args,cwd=r,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 print(' '.join(args),cp.returncode)
 print(cp.stdout[:14000])
for name in ['desktop','vscode']:
 d=json.loads((r/name/'package-lock.json').read_text())
 print(name,json.dumps(d['packages'][''],indent=2))
