from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,os,subprocess,sys,traceback

root=Path('/tmp/gh-issue-solver-1794900398048')
scratch=Path('/tmp/issue-1580-research/status-native-target-commit')
destination=root/'experiments/issue-1580/evidence/checks/unverified-child-status/native-target-review'
if len(sys.argv)==1:
    scratch.mkdir(exist_ok=False)
    with (scratch/'worker.log').open('wb') as stream:
        process=subprocess.Popen([sys.executable,__file__,'finish'],cwd=root,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    (scratch/'process.json').write_text(json.dumps({'pid':process.pid})+'\n')
    print(json.dumps({'pid':process.pid,'output':str(scratch)}));sys.exit(0)
assert sys.argv[1:]==['finish']
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256')
records=[]
def run(label,command):
    result=subprocess.run(command,cwd=root,env=env,capture_output=True)
    raw=result.stdout+result.stderr
    (scratch/(label+'.log')).write_bytes(raw)
    row={'name':label,'command':command,'exitCode':result.returncode,'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest()}
    records.append(row);print(json.dumps(row),flush=True)
    assert result.returncode==0,(label,raw.decode())
    return result.stdout.decode().strip()
files=['.github/workflows/native-type-check.yml','rust/Cargo.toml','rust/tests/web/default-branch-build-policy.test.mjs','docs/ci-cd/default-branch-builds.md','changelog.d/20261117_120000_issue-1580-ci-regressions.md','experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8']
complete=False
try:
    assert run('branch',['git','branch','--show-current'])=='issue-1580-8d61a32a61e1'
    parent=run('parent',['git','rev-parse','HEAD'])
    assert parent=='510c24983e5bbacb0e5ab21d2de491af56902055'
    assert run('initial-index',['git','diff','--cached','--name-only'])==''
    sourceChecks=json.loads((root/'experiments/issue-1580/evidence/checks/unverified-child-status/main-integration-validation/outcome.json').read_text())
    assert all(row['exitCode']==0 for row in sourceChecks['checks'] if row['name']!='all-local-gates')
    raw=(Path('/tmp/issue-1580-research/status-main-integration')/'all-local-gates.log').read_text()
    assert [line for line in raw.splitlines() if line.startswith('FAIL ')]==['FAIL check-abbreviations 5.0s -> experiments/formal_ai_subagent/sandboxes/gates/check-abbreviations.log']
    run('stage',['git','add','--',*files])
    assert set(run('staged-names',['git','diff','--cached','--name-only']).splitlines())==set(files)
    run('affected-gates',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations,check-file-size-js-twin,check-file-size,check-changelog-fragment-js-twin'])
    run('staged-whitespace',['git','diff','--cached','--check'])
    run('staged-diff',['git','diff','--cached','--',*files])
    witness=json.loads(Path('/tmp/issue-1580-research/unverified-status-main-update/governed-refresh.json').read_text())
    assert witness['completeInventoryUnchangedExceptCargoFixtureIdentity'] and witness['changedFixtureOccurrences']==4
    assert witness['newCargoSha256']==hashlib.sha256((root/'rust/Cargo.toml').read_bytes()).hexdigest()
    assert witness['afterSha256']==hashlib.sha256((root/files[-1]).read_bytes()).hexdigest()
    destination.mkdir(exist_ok=False)
    (destination/'governed-refresh.json').write_text(json.dumps(witness,indent=2)+'\n')
    review={'parent':parent,'files':[{'path':name,'sha256':hashlib.sha256((root/name).read_bytes()).hexdigest()} for name in files],'textDiffFullyRead':True,'existingNativeModuleFullyRead':True,'binaryInventoryComparedAsCompleteObjects':True,'nativeExecuted':False,'hostedCiPendingPublication':True,'independentAuthorshipCredit':0}
    (destination/'review.json').write_text(json.dumps(review,indent=2)+'\n')
    run('commit',['git','-c','gc.auto=0','commit','-m','Replay shared executor regressions in focused native CI'])
    head=run('head',['git','rev-parse','HEAD'])
    assert run('committed-parent',['git','rev-parse','HEAD^'])==parent
    assert run('final-index',['git','diff','--cached','--name-only'])==''
    (destination/'commit.json').write_text(json.dumps({'head':head,'parent':parent,'sourceFiles':files,'observedAt':datetime.now(timezone.utc).isoformat(),'nativeExecuted':False,'independentAuthorshipCredit':0},indent=2)+'\n')
    complete=True
except BaseException:
    traceback.print_exc()
finally:
    destination.mkdir(exist_ok=True)
    archives=[]
    for path in sorted(scratch.glob('*.log')):
        if path.name=='worker.log':continue
        raw=path.read_bytes();packed=gzip.compress(raw,mtime=0)
        (destination/(path.name+'.gz')).write_bytes(packed)
        archives.append({'archive':path.name+'.gz','rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
    report={'complete':complete,'records':records,'archives':archives,'nativeExecuted':False,'independentAuthorshipCredit':0}
    (destination/'outcome.json').write_text(json.dumps(report,indent=2)+'\n')
    (scratch/'outcome.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'complete':complete,'nativeExecuted':False}),flush=True)
sys.exit(0 if complete else 1)
