from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import traceback

root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research/task-cue-whitespace-correction')
base = root / 'experiments/issue-1580/evidence/checks/quoted-passage-cues/whitespace-correction'
if len(sys.argv) == 1:
    scratch.mkdir(exist_ok=False)
    base.mkdir(exist_ok=False)
    with (scratch / 'worker.log').open('wb') as stream:
        process = subprocess.Popen([sys.executable, __file__, 'finish'], cwd=root, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    print(json.dumps({'pid': process.pid, 'scratch': str(scratch)}))
    sys.exit(0)
assert sys.argv[1:] == ['finish']
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=256')
records = []
def run(name, args):
    started = time.monotonic()
    result = subprocess.run(args, cwd=root, env=environment, capture_output=True)
    raw = result.stdout + result.stderr
    packed = gzip.compress(raw, mtime=0)
    (base / (name + '.log.gz')).write_bytes(packed)
    row = {'name': name, 'argv': args, 'exitCode': result.returncode, 'seconds': round(time.monotonic() - started, 3), 'rawLines': len(raw.splitlines()), 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest()}
    records.append(row)
    print(json.dumps(row), flush=True)
    assert result.returncode == 0, (name, raw.decode()[-4000:])
    return raw
complete = False
measurement = None
try:
    prior = json.loads((root / 'experiments/issue-1580/evidence/checks/quoted-passage-cues/mirror-correction-resumed/results.json').read_text())
    assert [check['name'] for check in prior['checks'] if check['exitCode']] == ['whitespace']
    path = root / 'js/agentic/crate/task_decomposition_cues.mjs'
    before = path.read_bytes()
    assert before.endswith(b'\n\n')
    after = before.rstrip(b'\n') + b'\n'
    assert before.rstrip() == after.rstrip()
    path.write_bytes(after)
    (base / 'source-whitespace.json').write_text(json.dumps({'path': str(path.relative_to(root)), 'beforeSha256': hashlib.sha256(before).hexdigest(), 'afterSha256': hashlib.sha256(after).hexdigest(), 'onlyTrailingNewlinesChanged': True, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
    code = "import {readFileSync} from 'node:fs'; import {createHash} from 'node:crypto'; import {factoryOf} from './scripts/generate-worker-crate-modules.mjs'; const value=factoryOf('crate/task_decomposition_cues.mjs',readFileSync('js/agentic/crate/task_decomposition_cues.mjs','utf8')); console.log(JSON.stringify({lines:value.split('\\n').length-Number(value.endsWith('\\n')),sha256:createHash('sha256').update(value).digest('hex')}));"
    measurement = json.loads(run('worker-budget-measurement', ['node', '--input-type=module', '-e', code]))
    assert 20 < measurement['lines'] <= 46
    budget = root / 'data/meta/worker-line-budget/formal_ai_worker_crate_task_decomposition_cues.lino'
    text = budget.read_text()
    assert '  ceiling 46\n' in text
    budget.write_text(text.replace('  ceiling 46\n', '  ceiling ' + str(measurement['lines']) + '\n', 1))
    for name, args in [
        ('worker-writer', ['node', 'scripts/generate-worker-crate-modules.mjs', '--write']),
        ('typescript-writer', ['node', 'scripts/translate-es.mjs', '--write']),
        ('translation-writer', ['node', 'scripts/translate-js-rust.mjs', '--write', '--fetch', '--jobs', '1', 'js/agentic/crate/task_decomposition_cues.mjs']),
        ('translation-verification', ['node', 'scripts/translate-js-rust.mjs', '--verify']),
        ('affected-gates', ['node', 'experiments/formal_ai_subagent/local-gates.mjs', '--only', 'check-generated-files,check_js_rust_translation,check-worker-line-budget,check-status-render,check-render-status-js-twin']),
        ('whitespace', ['git', 'diff', '--check']),
    ]:
        run(name, args)
    details = []
    for index, name in enumerate(['check-generated-files', 'check_js_rust_translation', 'check-worker-line-budget', 'check-status-render', 'check-render-status-js-twin'], 1):
        raw = (root / 'experiments/formal_ai_subagent/sandboxes/gates' / (name + '.log')).read_bytes()
        packed = gzip.compress(raw, mtime=0)
        filename = f'gate-{index:03d}.log.gz'
        (base / filename).write_bytes(packed)
        details.append({'name': name, 'log': filename, 'rawLines': len(raw.splitlines()), 'rawSha256': hashlib.sha256(raw).hexdigest(), 'archiveSha256': hashlib.sha256(packed).hexdigest()})
    (base / 'gate-details.json').write_text(json.dumps(details, indent=2) + '\n')
    complete = True
except BaseException:
    traceback.print_exc()
result = {'complete': complete, 'checks': records, 'workerBudgetMeasurement': measurement, 'observedAt': datetime.now(timezone.utc).isoformat(), 'nativeExecuted': False, 'memoryEventsAfter': Path('/sys/fs/cgroup/memory.events').read_text(), 'independentAuthorshipCredit': 0}
(base / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'checks'}), flush=True)
sys.exit(0 if complete else 1)
