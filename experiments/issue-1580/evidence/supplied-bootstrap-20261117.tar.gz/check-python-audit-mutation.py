from pathlib import Path
import subprocess
p=Path('experiments/issue-1580/template-python-audit-integrity.test.mjs');source=p.read_text()
before='const f=auditFixture(t,{candidate:true,mode});';assert source.count(before)==1
try:
 p.write_text(source.replace(before,'const f=auditFixture(t,{candidate:false,mode});'))
 subprocess.run(['python3','/tmp/issue-1580-research/run-audit-focused.py','python-before','experiments/issue-1580/template-python-audit-integrity.test.mjs'],check=True)
finally:p.write_text(source)
