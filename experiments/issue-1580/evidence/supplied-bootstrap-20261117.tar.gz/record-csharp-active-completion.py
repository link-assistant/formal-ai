from pathlib import Path
import collections,hashlib,json

target=Path('docs/case-studies/issue-1580/templates/csharp-partial-semantic-review.json')
review=json.loads(target.read_text())
assert review['counts']['activeFullyRead']==120 and review['counts']['activeUnread']==38
source=Path('/tmp/issue-1580-research/templates/csharp-complete')
inventory=json.loads(Path('/tmp/issue-1580-research/templates/csharp-complete-inventory.json').read_text())
identities={row['path']:row for row in inventory}
notes={
 'scripts/recheck-broken-links.test.mjs':'Read all 593 lines: permanent/non-HTTP and transport failures stay failures, retry status ranges and user agent are explicit, Retry-After and total budgets bound recovery, duplicate URLs receive one slot, exhausted budgets do not probe, and only complete recovery succeeds. Upstream Bun tests and provider calls were not executed.',
 'scripts/release-assets.mjs':'Read argv-based gh asset reconciliation: validate identities/names/sizes, preserve nonempty public assets, repair draft empty/missing assets, verify downloaded bytes/digests before promotion and reject inconsistent final identity. Keep Formal AI immutable publication receipts; no live release API execution.',
 'scripts/release-assets.test.mjs':'Read injected-gh public/draft, corrupt download, failed upload and final identity controls. These tests were reviewed as source without upstream Bun execution.',
 'scripts/release-naming.mjs':'Read root/nested C# layout discovery with bounded depth and excluded generated directories, v/cs_v tag naming, semver normalization and exact-version package links/badges. Formal AI package identities remain unchanged.',
 'scripts/release-naming.test.mjs':'Read root/nested layout, tag normalization and package-link controls. Upstream runtime execution is unverified.',
 'scripts/release-workflow-policy.test.mjs':'Read locked helper installation, narrow OIDC writers, explicit artifact/auth fallback, serialized writers, skipped-needs guards, change outputs, token notices, NuGet smoke ordering, terminal job coverage and job/helper budgets. Preserve Formal AI default-branch build policy and explicit unknown preflight results.',
 'scripts/rerun-workflow-policy.test.mjs':'Read trusted-default-branch checkout, numeric run identity, minimal permissions, finite timeout and explicit optional macOS rules. Do not admit an untrusted workflow head or classify real test failure as acquisition failure.',
 'scripts/run-with-budget-warning.sh':'Read validated budget/grace/threshold/poll inputs, process-group ownership, warning deadline, TERM/KILL escalation, timeout exit 124, ordinary status propagation and signal forwarding. Retain Formal AI existing wrapper and default-off cache diagnostics; this upstream shell wrapper was not executed.',
 'scripts/runner-acquisition.mjs':'Read runnerless completed-run classification, NOT_ACQUIRED annotation checks, latest branch/event selection, bounded pagination and at most three attempts. Mixed real-failure/acquisition runs are an unexecuted classification question; no additional defect report or hosted rerun is claimed.',
 'scripts/runner-acquisition.test.mjs':'Read acquisition, latest-run, dry-run, terminal/API failure and retry controls. The mixed real-test failure question is not established by these source-only controls.',
 'scripts/sarif-directory.test.mjs':'Read directory aggregation controls that preserve failures despite malformed neighboring files. No real scanner execution is inferred.',
 'scripts/security-gates.mjs':'Read complete SARIF shape/invocation/result validation and fatal findings, dependency audit graph checks, direct/transitive coordinates and the SDK-8 path-only exception. Missing or failed required security results stay fatal; do not substitute helper success for a C# scan.',
 'scripts/security-gates.test.mjs':'Read malformed/incomplete SARIF, findings of every level, multi-file aggregation and audit graph negative controls. Upstream Bun/.NET scans remain unexecuted.',
 'scripts/security-workflow-policy.test.mjs':'Read weekly/push/PR scanning, all language selectors, archive:false artifact naming, immutable source/digest receipts and ZIP validation. Keep failed scans fatal; known C# token issue 110 remains separate.',
 'scripts/smoke-test-nuget-package.mjs':'Read anonymous exact-package byte verification, isolated temporary HOME/cache, credential-free environment allowlist, cleared feeds and argv-based consumer creation/build/run. Workflow wrapper owns the outer deadline; no actual .NET build or public package consumption was performed.',
 'scripts/smoke-test-nuget-package.test.mjs':'Read injected runner/digest, clean-environment, package API and exact-version checks. Source review does not verify a public publication.',
 'scripts/toolchain-policy.test.mjs':'Read Node/Bun/SDK/TFM pins, DocFX restore, Dependabot and CodeQL version coupling. Keep repository-specific pinned toolchains rather than copying a C# SDK requirement.',
 'scripts/validate-changeset.mjs':'Read validated Git object/ref arguments, explicit PR comparison and exactly one new changeset plus validation of all pending entries. Unknown CI comparison does not fall back to every file. Filename quoting remains an unexecuted source question; preserve Formal AI own fail-closed detector.',
 'scripts/validate-nuget-package.mjs':'Read complete ZIP validation before publication, one root nuspec, exact package metadata and bundled license bytes plus required assembly checks. No .NET package validation was executed.',
 'scripts/validate-nuget-package.test.mjs':'Read bounded 30-second fixture compiler/parser controls. Do not compile .NET locally for this review or claim source inspection as execution.',
 'scripts/validate-nuspec.proj':'Read platform XML validation with DTD prohibited and resolver disabled, exact ID/version/license kind/SPDX and required authors/description. This package-specific validation is not applicable to Formal AI Cargo publication.',
 'scripts/version-and-commit.mjs':'Read complete parse-before-mutation changeset handling, highest semantic bump, Git commit/tag/push ordering and release outputs. C# does not contain the Java swallowed-commit root cause. Existing local tags stop release. Error classification questions remain unexecuted.',
 'scripts/version-and-commit.test.mjs':'Read real local bare-Git and injected literal-value controls for release modes and writer races. Upstream Bun tests were not executed; preserve Formal AI existing commit-failure guard.',
 'scripts/wait-for-nuget.mjs':'Read exact lowercase flat-container HEAD-200 availability, finite attempt/delay counts, network-unavailable classification and explicit output. No per-request abort deadline appears in source; the workflow outer budget is distinct from bounded attempts. This remains an unexecuted question.',
 'scripts/wait-for-nuget.test.mjs':'Read localhost 200/404/transient availability and output controls. No upstream Bun or live NuGet probe was executed.',
 'scripts/workflow-git-policy.test.mjs':'Read pre-checkout default-branch Git configuration requirements across environment layers. Preserve Formal AI existing default branch identity.',
 'scripts/workflow-injection-policy.test.mjs':'Read untrusted-context environment transport, quoted output writes, explicit checkout credential persistence, pinned actionlint/ShellCheck container and high/pedantic zizmor rules. Do not weaken security verdicts for tool absence.',
 'scripts/workflow-runner-policy.test.mjs':'Read rejection of floating -latest labels in direct and nested matrix runner values, pinned platform coverage and SDK coupling. Keep Formal AI pinned runner labels.',
 'scripts/zip-archive.mjs':'Read full bounded archive validation: 64 MiB source/expanded limits, 10000 entries, headers/CRC/UTF-8 names, duplicate/path/symlink/special/ancestor rejection before writes, digest verification and exclusive creation. Windows reserved names remain an unexecuted question; no general archive-safety claim.',
 'scripts/zip-archive.test.mjs':'Read positive and malformed/CRC/path/symlink/duplicate archive fixtures. These Node-24/Bun source tests were not executed in this review.',
 'src/MyPackage/Calculator.cs':'Read minimal unchecked long addition/multiplication and cancellable delay. This sample API is not a requested Formal AI production feature.',
 'src/MyPackage/MyPackage.csproj':'Read sample 0.3.16 package identity, net11 target, exact Unlicense/readme packaging and metadata. No package naming or framework migration applies to Formal AI.',
 'src/MyPackage/PackageInfo.cs':'Read assembly informational version metadata normalization. Public package/version acceptance remains unverified.',
 'src/MyPackage/packages.lock.json':'Read net11 empty direct-dependency lock. Do not infer restored dependencies or successful compilation.',
 'tests/MyPackage.Tests/CalculatorTests.cs':'Read arithmetic positive/negative/zero/boundary and delay/cancellation assertions. Wall-clock timing sensitivity is an unexecuted source observation, not a reproduced failure.',
 'tests/MyPackage.Tests/MyPackage.Tests.csproj':'Read xUnit-v3 executable test setup with MTP disabled, VSTest/coverlet pins, locked dependencies and project reference. No test build was run.',
 'tests/MyPackage.Tests/PackageInfoTests.cs':'Read nonempty/basic version-format assertions. These are sample-package tests, without a direct Formal AI feature transfer.',
 'tests/MyPackage.Tests/packages.lock.json':'Read complete pinned test dependency graph. This is identity/source review without package restoration or current vulnerability verification.'
}
unread={row['path'] for row in review['files'] if row['reviewStatus']=='inventoried-only-active'}
assert set(notes)==unread and len(notes)==38
for row in review['files']:
 data=(source/row['path']).read_bytes()
 assert len(data)==row['bytes']==identities[row['path']]['bytes']
 assert hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()==row['gitBlob']==identities[row['path']]['gitBlob']
 assert hashlib.sha256(data).hexdigest()==row['sha256']
 if row['path'] in notes:
  assert len(data.decode().splitlines())==row['lines']
  row.update(reviewStatus='active-source-fully-read',readRanges=[[1,row['lines']]],decision=notes[row['path']])
 if row['path']=='.github/workflows/release.yml':
  row['decision']='Read all 922 lines and every active transitive helper/test. Preserve change detection, explicit preflight states, writer serialization, immutable artifacts and aggregate verdict. Retain Formal AI default-branch-only builds. Source review does not establish hosted publication or runtime acceptance.'
 if row['path']=='scripts/create-github-release.mjs':
  row['decision']='Read complete release creation, bounded notes and draft/public reconciliation plus its release-assets helper/tests. Public release acceptance remains unverified; preserve exact source and asset byte identities.'
 if row['path']=='scripts/recheck-broken-links.mjs':
  row['decision']='Read all 537 lines and its complete 593-line test: finite round-robin recovery, per-request/whole-helper budgets, Retry-After, unchanged permanent failures, default-off verbosity and explicit all_recovered output. No network experiment or upstream Bun execution was performed.'
counts=collections.Counter(row['reviewStatus'] for row in review['files'])
assert counts['active-source-fully-read']==158 and counts['inventoried-only-active']==0
assert sum(row['lines'] for row in review['files'] if row['reviewStatus']=='active-source-fully-read')==18327
review.update(coverage='ACTIVE SOURCE COMPLETE; FULL REPOSITORY REVIEW PARTIAL. All 337 blobs are verified. All 158 active text files (18327/18327 lines), six workflows and active transitive helpers/tests/configuration/application files are fully read. All 179 historical blobs remain semantically unread. Runtime, public publication and full repository acceptance are unverified.',counts={'activeFullyRead':158,'historicalUnread':179,'activeUnread':0},activeReadLines=18327,readMethod='All ordered active-source pages 1-41, at most 450 lines each, excluding dev/log and ci-logs, were fully read. Additional earlier separate reads are retained. Commands and complete page output are preserved by the Formal AI driver archives.')
files=review.pop('files')
prefix=json.dumps(review,indent=2)
target.write_text(prefix[:-2]+',\n  "files": [\n'+',\n'.join('    '+json.dumps(row) for row in files)+'\n  ]\n}\n')
assert len(target.read_text().splitlines())<1500
print(json.dumps({'verifiedBlobs':len(files),'activeFullyRead':158,'activeReadLines':18327,'historicalSemanticallyUnread':179,'nativeRuntimeClaim':False,'independentFormalAiCredit':0},indent=2))

doc=Path('docs/case-studies/issue-1580/templates/README.md'); text=doc.read_text()
old='[`csharp-partial-semantic-review.json`](csharp-partial-semantic-review.json) verifies all 337 pinned blobs and records exactly 120 fully read active files (11,974 of 18,327 active lines). All six workflows are read; 38 active files, including remaining release/asset/security/runner helpers and application/test source, and 179 historical blobs remain semantically unread. This checkpoint does not complete the C# review or its transitive CI closure.'
new='[`csharp-partial-semantic-review.json`](csharp-partial-semantic-review.json) verifies all 337 pinned blobs and records all 158 active files as fully read (18,327 of 18,327 active lines), including six workflows and their active transitive helpers, tests, configuration and application source. Per-file decisions preserve runtime limits and distinguish unexecuted source questions from reproduced defects. All 179 historical blobs remain semantically unread; the complete C# repository review and upstream runtime/publication acceptance remain unfinished.'
assert old in text; doc.write_text(text.replace(old,new).replace('## Partial C# review and valid-input changeset loss','## C# active source review and valid-input changeset loss'))
doc=Path('docs/case-studies/issue-1580/README.md'); text=doc.read_text()
old='The [C# partial review](templates/csharp-partial-semantic-review.json) covers all six workflows and 120 active files, with exact verified identities. Its remaining 38 active files and 179 historical blobs stay explicitly unread.'
new='The [C# active review](templates/csharp-partial-semantic-review.json) covers all six workflows and all 158 active files / 18,327 lines, with exact verified identities and per-file decisions. All 179 historical blobs remain semantically unread; runtime/publication acceptance is unverified.'
assert old in text; doc.write_text(text.replace(old,new))
doc=Path('experiments/issue-1580/work-plan.md')
with doc.open('a') as stream:
 stream.write('\n## C# active source completion and evidence filename correction\n\nRead all remaining C# active source pages: 158 files / 18,327 lines, all six workflows and active transitive helpers/tests/configuration/application source; reverify all 337 blob identities. Preserve per-file decisions and unexecuted questions. All 179 historical blobs and upstream runtime/publication acceptance stay unfinished. On published head `0f90c0a7a`, 23 workflows passed and Layered CI failed the abbreviation ratchet: `initial-spec-reporter.log.gz` raised abbreviated filenames from 90 to 91 (full log lines 7069 and 7965-7968). Preserve the full original failure and rename only that evidence file to `initial-specification-reporter.log.gz`, keeping its exact compressed and raw bytes and the existing baseline. Run the existing abbreviation regression and touched gates before the next single push. All broader issue criteria remain active.\n')
