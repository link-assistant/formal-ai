import json,re
from pathlib import Path
for lang,numbers in [('java',[9,11,25,29]),('python',[18,19,40,41,152]),('php',[13,24])]:
    pages=json.loads(Path('/tmp/issue-1580-research/'+lang+'-upstream-issues.json').read_text())
    items={x['number']:x for page in pages for x in page}
    for number in numbers:
        item=items[number]
        print(json.dumps({'language':lang,'number':number,'title':item['title'],'body':item['body']},ensure_ascii=False))
