import subprocess
from pathlib import Path

body=Path('/tmp/issue-1580-research/go-stale-pin-report-body.md')
text=body.read_text()
text=text.replace(' this report. No upstream fix is claimed.','. No upstream fix is claimed.')
body.write_text(text)
out=Path('/tmp/issue-1580-research/go-pin-report-url.txt')
assert not out.exists(), 'Report URL already retained; do not file twice'
url=subprocess.check_output(['gh','issue','create','--repo','link-foundation/go-ai-driven-development-pipeline-template','--title','CI: stale action pins bypass integrity verification on non-PR events','--body-file',str(body)],text=True).strip()
out.write_text(url+'\n')
print(url)
