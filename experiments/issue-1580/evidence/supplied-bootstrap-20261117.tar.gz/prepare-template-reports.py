from pathlib import Path
root=Path('/tmp/issue-1580-research')
manual=root/'go-manual-release-report.md'
manual.write_text(manual.read_text().replace('executable three-test reproduction','executable four-test reproduction'))
git=root/'go-change-detection-report.md'
text=git.read_text().replace('It behaves the same on push; with a first-commit mock, the available `git ls-tree` result is never consulted.', 'It behaves the same on push; with a first-commit mock, the available `git ls-tree` result is never consulted. A separate test creates a real Git repository containing only an initial `main.go` commit: running the unchanged detector reports `go-changed=false`, while the candidate error-propagation change correctly reports true.')
text=text.replace('For unknown comparisons, failing clearly or conservatively running all affected checks is safer than classifying the change as docs-only.', 'This one-line candidate is not a complete fix: the PR catch path can still narrow an unavailable full-PR comparison to `HEAD^..HEAD`, which can omit earlier code commits. Require the intended complete comparison, establish a genuinely initial commit before using its tree, and propagate any remaining unknown observation. Failing clearly or conservatively running all affected checks avoids classifying an unknown comparison as docs-only.')
git.write_text(text)
cases=[
 ('java','dd803a2d9fa5b3a992b435acce73162274fb9e8b','scripts/detect-code-changes.mjs','node scripts/detect-code-changes.mjs','src/Main.java','The helper catches `execSync` errors and returns an empty string, so the caller never reaches its intended error fallback. A first-commit mock with an available source tree also reports false.','Related: #9/#11 repaired a different Git fallback in the changeset validator. This report concerns the still-current change detector. #29 concerns the missing aggregate pipeline status, not this observation boundary.'),
 ('python','c532c173801dfb12e681b0730c4abbf93aefd0ca','scripts/detect_code_changes.py','python3 scripts/detect_code_changes.py','src/main.py','The helper catches `CalledProcessError` and returns an empty string, so unavailable history is indistinguishable from an empty diff. An available first-commit source tree also reports false. On PRs an empty result can fall back to `HEAD^..HEAD`, which is narrower than the intended full PR.','Related: #40/#41 corrected excluded-path gates and #18/#19 corrected manual-release skip propagation. Neither repairs this failed-Git observation boundary. Reproduction used Python 3.15; the pinned upstream syntax needs Python 3.14 or newer.'),
 ('php','3a034b27a56067971ca74dd4c74c7707056b215d','scripts/lib/ChangeDetector.php','php scripts/detect-code-changes.php','src/Main.php','The detector falls back to listing the tree, but if both commands fail it returns an empty array. Its PR recovery can also compare only `HEAD^..HEAD` after the full PR comparison fails. A legitimate initial tree does work here; the failure is treating unknown repository/history as an empty changed-file set.','Related: the latest merged dependency/CI update is #24. The open Pages configuration report #25 concerns a different failure.'),
]
for lang,sha,path,command,code,reason,related in cases:
 repo=f'link-foundation/{lang}-ai-driven-development-pipeline-template'
 body=f'''Audited source: `{sha}`. The actual unmodified change detector can return success and `any-code-changed=false` when Git cannot establish the changed-file set.

Source: [`{path}`](https://github.com/{repo}/blob/{sha}/{path}).

{reason}

## Bounded reproduction

The retained regression executes `{command}` in a temporary directory, with a small mock Git executable ahead of Git on `PATH`. It runs both `GITHUB_EVENT_NAME=push` and `pull_request`, sets 40-character base/head SHAs, and captures the actual `GITHUB_OUTPUT` file. Git comparisons/tree reads print `fatal: unavailable comparison/repository` and exit 128; PR `cat-file`/fetch probes succeed. The script exits **0** and writes **`any-code-changed=false`** for both events. No credentials, network access, installation, or application build is required.

Controls execute the same unmodified source: a successful diff containing `{code}` reports true; successful docs-only and genuinely empty diffs report false. A separate PR case makes the full comparison fail while `HEAD^` contains only `docs/guide.md`: the detector still reports false. This cannot establish that earlier PR commits contain no code.

Executable test, Git blob/SHA-256 provenance, original licenses, and unmodified fixtures: [formal-ai PR #1581](https://github.com/link-assistant/formal-ai/pull/1581), `experiments/issue-1580/template-shared-git-observation.test.mjs`. Each child is limited to five seconds; Java/PHP memory is capped at 64 MiB. All three language reproductions ran locally, without runtime skips. This is an executed subprocess reproduction, not a claim that a hosted publishing workflow was dispatched.

## Expected behavior and repair direction

Only a successful complete comparison should justify a negative code-change output. Propagate failed observations (or deliberately run checks conservatively), distinguish a genuinely initial commit from missing/shallow/corrupt history, and do not silently narrow an unknown full-PR comparison to its last commit. Preserve successful empty/docs-only cases. A plain diagnostic followed by exit 0 does not make an unknown observation fail closed.

Workaround: require successful complete change detection before using a negative output to skip checks; when comparison history is unavailable, run checks conservatively or fail the observation.

{related}
'''
 (root/f'{lang}-change-detection-report.md').write_text(body)
print('Prepared five reviewable template issue bodies; no issues posted.')
