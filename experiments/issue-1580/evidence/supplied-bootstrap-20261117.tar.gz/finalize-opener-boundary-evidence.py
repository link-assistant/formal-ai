from pathlib import Path
import gzip, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
out = root / 'experiments/issue-1580/evidence/checks/opener-native-boundary'
publication = json.loads((out / 'publication/outcome.json').read_text())
assert publication['complete'] and all(row['exitCode'] == 0 for row in publication['records'])
initial = json.loads((out / 'outcome.json').read_text())
assert initial['complete']
assert [row['name'] for row in initial['checks'] if row['exit'] != 0] == ['core-boundary']
shared = subprocess.check_output(['git', 'diff', '--name-only', '--', 'data/meta'], cwd=root).decode().strip()
assert shared == '', shared
sources = [
    'rust/src/unknown_opener.rs', 'rust/src/web_engine_core.rs',
    'rust/tests/source/unknown_opener_language_tests.rs',
    'js/worker/formal_ai_worker_seed_responses_and_language.js',
    'rust/tests/web/worker-unknown-language.test.mjs',
    'data/meta/wasm-worker-inputs.lino', 'js/formal_ai_worker.wasm',
]
summary = {
    'publishedInput': 'd0b395bb2310e285c89d93818571e4d54ed59c02',
    'focusedJavaScriptCases': {'sourceTestPlacement': 5, 'wasmWorkerInputs': 5, 'localizedWorker': 6},
    'affectedGatesPassed': 12, 'sharedDataChangedThisRound': False,
    'fullGateRunThisRound': False, 'nativeBehaviorVerified': False,
    'autonomousAuthorshipCredit': 0,
    'sourceHashes': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in sources},
}
(out / 'reviewed-round-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
p = root / 'docs/case-studies/issue-1580/opener-native-boundary-checkpoint.md'
text = p.read_text()
old = 'checks. The existing minimal-core boundary gate also passes. Logs are under\n'
assert text.count(old) == 1
text = text.replace(old, 'checks. All 12 affected policy, core, source-size, naming, worker-budget,\nstatus and release gates pass; Rust formatting, projection verification and\nwhitespace checks pass. This round changes no shared `data/meta` input and does\nnot repeat the full gate inventory. Projection verification still reports 49\nrefused modules, so it does not establish full language parity. Logs are under\n')
p.write_text(text)
plan = root / 'experiments/issue-1580/work-plan.md'
plan.write_text(plan.read_text() + '\n- [x] Complete all 12 affected policy/release/core/source-budget gates and final Rust formatting, projection and whitespace checks. No shared `data/meta` input changes this round; the full gate inventory is not repeated. Save final source identities and retain zero native behavior/authorship credit.\n')
for directory in [out / 'publication', root / 'experiments/issue-1580/evidence/ci/localized-opener-d0b395bb/boundary-round-preflight']:
    for name in ['worker.stdout.log', 'worker.stderr.log']:
        p = directory / name
        raw = p.read_bytes()
        p.with_suffix(p.suffix + '.gz').write_bytes(gzip.compress(raw, mtime=0))
        p.unlink()

body = Path('/tmp/issue-1580-research/opener-round-pull-request-description.md').read_text()
intro = 'The latest correction fixes both Layered CI failures on published `d0b395bb`: restore the recorded WASM source input without changing its binary or manifest, and register the native regression outside production source. The native formatter still preserves the full localized seed through the existing Links Notation parser; the shared selector retains its fallback API. The two failing JavaScript files and localized worker file pass separately (**5 + 5 + 6 cases**), and all **12 affected gates**, formatting, projection and whitespace checks pass. The external native regressions remain unexecuted. The [native boundary checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/opener-native-boundary-checkpoint.md) retains both primary failures and exact verification limits. This new head still needs hosted verification.\n\n'
marker = 'The latest batch preserves the complete localized unknown seed'
assert body.count(marker) == 1
body = body.replace(marker, intro + 'The preceding batch preserves the complete localized unknown seed')
body = body.replace('The new native unit regression has not been executed locally.', 'The native regressions have not been executed locally.')
old = 'Both introduced misses are corrected in this batch; the next head still needs hosted verification.'
assert body.count(old) == 1
body = body.replace(old, 'Both bookkeeping misses are corrected on d0b395bb. All 23 workflows on that head complete: 22 pass and Layered CI 44226415780 fails on the WASM input manifest and inline native test. The latest correction above addresses both failures; its next head still needs hosted verification.')
body = body.replace('pages 1–38 and 48–60/254, 63 complete files and two partials', 'pages 1–38 and 48–64/254, 65 complete files and two partials')
Path('/tmp/issue-1580-research/opener-boundary-pull-request-description.md').write_text(body)
print(json.dumps(summary, indent=2))
print('Prepared complete reviewable pull-request description; native and broad acceptance remain unfinished.')
