from pathlib import Path
import shutil
for name in ['trace-template-ci.mjs','template-reference-graph.test.mjs']:
 shutil.copyfile(Path('/tmp/issue-1580-research')/name,Path('experiments/issue-1580')/name)
print('Installed externally authored static review aid; zero independent reasoning credit.')
