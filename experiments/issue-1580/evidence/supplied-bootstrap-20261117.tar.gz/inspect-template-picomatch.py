from pathlib import Path
import subprocess,json
b=Path('/tmp/issue-1580-research/templates')
for name in ['js-complete','rust-complete','python-complete','php-complete','csharp-complete','java-complete','cpp-complete','go-complete']:
 p=b/name
 matches=subprocess.run(['rg','-n','--glob','bun.lock','--glob','package-lock.json','--glob','package.json','"picomatch"|picomatch@',str(p)],text=True,capture_output=True)
 lines=matches.stdout.splitlines()
 active=[line for line in lines if '/dev/log/' not in line and '/docs/case-studies/' not in line]
 print(name,'active matches',len(active),'historical matches',len(lines)-len(active))
 print('\n'.join(line[:1400] for line in active[:15]))
 if matches.returncode not in [0,1]:print(matches.stderr)
for name in ['.github/actions/artifact/package-lock.json','uv.lock']:
 p=b/'python-complete'/name
 print('PYTHON',name,'bytes',p.stat().st_size)
 if name.endswith('.json'):
  d=json.loads(p.read_text())
  for key,value in d.get('packages',{}).items():
   if key.endswith('/picomatch'):print(key,json.dumps(value))
