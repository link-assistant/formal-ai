from pathlib import Path
import gzip
import json

for name in ['/tmp/issue-1580-research/algebra-shared-inventory/worker.log', '/tmp/issue-1580-research/ci-logs/quoted-cues-7152daeb/worker.log']:
    path = Path(name)
    print(name)
    if path.exists():
        print('\n'.join(path.read_text().splitlines()[-4:]))
path = Path('/tmp/issue-1580-research/ci-logs/quoted-cues-7152daeb/latest-runs.json')
if path.exists():
    data = json.loads(path.read_text())
    print('RUN DATA TYPE', type(data).__name__)
    items = [run for page in data for run in page.get('workflow_runs', [])] if isinstance(data, list) else data.get('workflow_runs', [])
    for item in items:
        if item.get('conclusion') != 'success':
            print(json.dumps({key: item.get(key) for key in ['id', 'databaseId', 'name', 'workflowName', 'status', 'conclusion', 'created_at', 'updated_at', 'head_sha']}))
for name in ['memory.current', 'memory.events']:
    path = Path('/sys/fs/cgroup') / name
    if path.exists():
        print(name, path.read_text().strip())
