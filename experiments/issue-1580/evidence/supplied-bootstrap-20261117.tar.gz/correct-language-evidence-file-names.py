from pathlib import Path
import gzip,hashlib,json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/checks/language-main-publication-preflight';changes=[]
for old,new in [('pr','pull-request'),('pr-comments','pull-request-comments')]:
 for suffix in ['stdout.gz','stderr.gz']:
  source=base/(old+'.'+suffix);target=base/(new+'.'+suffix);raw=source.read_bytes();assert not target.exists();source.rename(target);assert target.read_bytes()==raw;changes.append({'before':source.name,'after':target.name,'archiveSha256':hashlib.sha256(raw).hexdigest(),'rawSha256':hashlib.sha256(gzip.decompress(raw)).hexdigest()})
for name in ['outcome.json','results.json']:
 p=base/name
 if not p.exists():continue
 raw=p.read_bytes();(base/(name+'.before-full-names.gz')).write_bytes(gzip.compress(raw,mtime=0));v=json.loads(raw)
 rows=v['records'] if isinstance(v,dict) else v
 for row in rows:
  if row['name'] in ['pr','pr-comments']:row['originalName']=row['name'];row['name']={'pr':'pull-request','pr-comments':'pull-request-comments'}[row['name']]
 p.write_text(json.dumps(v,indent=2)+'\n')
env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=256');p=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations'],cwd=root,env=env,capture_output=True);raw=p.stdout+p.stderr
out=root/'experiments/issue-1580/evidence/checks/language-main-final-validation';(out/'full-file-names-recheck.log.gz').write_bytes(gzip.compress(raw,mtime=0));receipt={'complete':True,'exitCode':p.returncode,'changes':changes,'rawSha256':hashlib.sha256(raw).hexdigest(),'log':'full-file-names-recheck.log.gz','lines':len(raw.splitlines()),'productionChanges':False,'ratchetChanges':False,'independentAuthorshipCredit':0};(out/'full-file-names-recheck.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print(raw.decode());assert p.returncode==0
