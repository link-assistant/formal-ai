from pathlib import Path
import json,subprocess
p=Path('experiments/issue-1580/evidence/ci/hive-profile-53d8212b/latest.json');d=json.loads(p.read_text());print({k:v for k,v in d.items() if k!='runs'})
for row in d['runs']:
 if row['status']!='completed':
  print('RUN',row['workflowName'],row['url']); r=subprocess.run(['gh','run','view',str(row['databaseId']),'--repo','link-assistant/formal-ai','--json','jobs'],capture_output=True,text=True,check=True);j=json.loads(r.stdout)
  for job in j['jobs']:
   if job['status']!='completed': print('JOB',job['name'],job['status'],job['startedAt'],[(s['name'],s['status'],s.get('conclusion')) for s in job['steps'] if s['status']!='queued'])
