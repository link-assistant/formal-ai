set -eu
rg --files /tmp/issue-1580-research/templates/js-complete/scripts /tmp/issue-1580-research/templates/rust-complete/scripts /tmp/issue-1580-research/templates/python-complete/scripts /tmp/issue-1580-research/templates/php-complete/scripts /tmp/issue-1580-research/templates/csharp-complete/scripts /tmp/issue-1580-research/templates/java-complete/scripts /tmp/issue-1580-research/templates/cpp-complete/scripts /tmp/issue-1580-research/templates/go-complete/scripts > /tmp/issue-1580-research/template-script-paths.txt
rg 'detect.*changes|changed.?files' /tmp/issue-1580-research/template-script-paths.txt
rg -n 'detect-code-changes|any-code-changed|compile-inputs-changed' .github/workflows/release.yml scripts/documentation-only-ci-policy.mjs | head -n 28
