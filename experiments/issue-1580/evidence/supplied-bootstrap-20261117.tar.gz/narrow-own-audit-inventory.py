from pathlib import Path
p=Path('scripts/check-javascript-dependencies.sh');s=p.read_text();before='tracked_files="$(git ls-files)"'
assert s.count(before)==1
p.write_text(s.replace(before,'''tracked_files="$(git ls-files -- 'bun.lock' '**/bun.lock' 'package-lock.json' '**/package-lock.json')"'''))
print('Select lockfile names in Git before Bash iteration; retain the complete tracked lockfile inventory.')
