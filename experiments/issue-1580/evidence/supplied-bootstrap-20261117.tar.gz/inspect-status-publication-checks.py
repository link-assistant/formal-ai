from pathlib import Path
import json

base=Path('/tmp/issue-1580-research/unverified-status-publication-checks')
pid=json.loads((base/'process.json').read_text())['pid']
stat=Path(f'/proc/{pid}/stat')
print(json.dumps({'pid':pid,'state':stat.read_text().split()[2] if stat.exists() else 'absent','finished':(base/'outcome.json').exists()}))
rows=json.loads((base/'progress.json').read_text())
for row in rows:
    print(json.dumps({key:row[key] for key in ['name','exitCode','durationSeconds','rawSha256']}))
    print((base/(row['name']+'.log')).read_text())
if (base/'outcome.json').exists():
    report=json.loads((base/'outcome.json').read_text())
    print(json.dumps({key:value for key,value in report.items() if key!='checks'}))
