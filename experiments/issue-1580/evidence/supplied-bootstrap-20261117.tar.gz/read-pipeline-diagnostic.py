from pathlib import Path
import gzip,itertools,re
file=Path('/tmp/issue-1580-research/head-71e1dee44/44071444011.log.gz')
pattern=re.compile(r'##\[error\]|::error|SyntaxError|Error:|^FAIL |✖ failing tests')
number=0;prior=[];remaining=0
with gzip.open(file,'rt') as stream:
 while chunk:=list(itertools.islice(stream,1500)):
  for text in chunk:
   number+=1
   if 'Fast Linux source and requirement checks\t' not in text:continue
   if pattern.search(text):
    for n,line in prior[-2:]:print(f'{n}: {line.rstrip()}')
    print(f'{number}: {text.rstrip()}');remaining=8
   elif remaining:
    print(f'{number}: {text.rstrip()}');remaining-=1
   prior.append((number,text));prior=prior[-2:]
