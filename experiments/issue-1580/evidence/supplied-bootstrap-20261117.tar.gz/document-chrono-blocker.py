from pathlib import Path
p=Path('.cargo/audit.toml')
s=p.read_text()
marker='[advisories]\nignore = ["RUSTSEC-2025-0057"]'
assert s.count(marker)==1
s=s.replace(marker,'''# RUSTSEC-2026-0543 blocked-upstream = "chrono@0.4.45" report = "https://github.com/chronotope/chrono/issues/1768"
#   This is an unmaintained notice, not a claim of a known exploitable defect.
#   The advisory affects every Chrono version and has `patched = []`:
#   https://github.com/RustSec/advisory-db/blob/main/crates/chrono/RUSTSEC-2026-0543.md
#   The current lockfile reaches Chrono through command-stream 1.5.3 and
#   link-calculator 0.22.0. On 2026-11-17 the latest published releases still
#   require it unconditionally: command-stream 1.13.0 requires ^0.4.45;
#   link-calculator 0.24.0 requires ^0.4. Their current default-branch manifests
#   do too, so a lockfile refresh or feature toggle cannot remove this notice.
#   The maintainer's linked deprecation report confirms the upstream state.
#   Retain the existing blocked-upstream policy: CI must prove this exact crate
#   still reaches the build graph, and fails when the proof becomes stale.
#   Removing Chrono from both dependency paths remains unfinished work; this
#   entry records the blocker and does not claim a dependency migration.
[advisories]
ignore = ["RUSTSEC-2025-0057", "RUSTSEC-2026-0543"]''')
p.write_text(s)

Path('rust/tests/web/cargo-audit-blocked-proof.test.mjs').write_text('''// Exercise the production shell boundary without resolving or building Rust.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,mkdtempSync,rmSync,copyFileSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {spawnSync} from 'node:child_process';

const root=new URL('../../../',import.meta.url);
const config=readFileSync(new URL('.cargo/audit.toml',root),'utf8');

function withAudit(run){
  const directory=mkdtempSync(join(tmpdir(),'formal-ai-audit-'));
  try{
    for(const folder of ['bin','.cargo','rust','scripts'])mkdirSync(join(directory,folder));
    copyFileSync(new URL('scripts/check-rust-dependencies.sh',root),join(directory,'scripts/check-rust-dependencies.sh'));
    writeFileSync(join(directory,'rust/Cargo.lock'),'# protocol fixture; no Rust dependency resolution\\n');
    const trace=join(directory,'calls.jsonl');
    writeFileSync(join(directory,'bin/cargo'),`#!${process.execPath}\\n`+String.raw`
const fs=require('node:fs');
const args=process.argv.slice(2);
fs.appendFileSync(process.env.AUDIT_TRACE,JSON.stringify(args)+'\\n');
if(args[0]==='tree'){
  const spec=args[args.indexOf('--invert')+1];
  if(spec===process.env.ABSENT_CRATE)process.exit(0);
  if(!['fxhash@0.2.1','chrono@0.4.45'].includes(spec))process.exit(101);
  process.stdout.write(spec+'\\n└── fixture dependency path\\n');
}else if(args[0]==='audit')process.exit(Number(process.env.AUDIT_FAILURE??0));
else process.exit(99);
`,{mode:0o755});
    writeFileSync(join(directory,'bin/git'),`#!${process.execPath}\\nprocess.stdout.write('rust/Cargo.lock\\\\n');\\n`,{mode:0o755});
    const invoke=({text=config,...env}={})=>{
      writeFileSync(join(directory,'.cargo/audit.toml'),text);
      writeFileSync(trace,'');
      const result=spawnSync('bash',['scripts/check-rust-dependencies.sh'],{
        cwd:directory,encoding:'utf8',timeout:5000,maxBuffer:65536,
        env:{...process.env,PATH:join(directory,'bin')+':'+process.env.PATH,AUDIT_TRACE:trace,...env},
      });
      const calls=readFileSync(trace,'utf8').split('\\n').filter(Boolean).map(line=>JSON.parse(line));
      return {...result,calls};
    };
    run(invoke);
  }finally{rmSync(directory,{recursive:true,force:true});}
}

test('blocked advisory entries require reachable exact versions and retain the strict audit', {timeout:10000},()=>{
  withAudit(invoke=>{
    const result=invoke();
    assert.equal(result.status,0,result.stderr+result.stdout);
    assert.deepEqual(result.calls.filter(args=>args[0]==='tree').map(args=>args.at(-1)),['fxhash@0.2.1','chrono@0.4.45']);
    assert.deepEqual(result.calls.filter(args=>args[0]==='audit'),[['audit','--file','rust/Cargo.lock','--deny','warnings']]);
  });
});

test('removing the blocked Chrono version invalidates the exception before audit', {timeout:10000},()=>{
  withAudit(invoke=>{
    const result=invoke({ABSENT_CRATE:'chrono@0.4.45'});
    assert.equal(result.status,1,result.stderr);
    assert.match(result.stdout,/chrono@0.4.45.*no longer reaches the build graph/u);
    assert.equal(result.calls.some(args=>args[0]==='audit'),false);
  });
});

test('a missing advisory proof is rejected and unrelated audit failures propagate', {timeout:10000},()=>{
  withAudit(invoke=>{
    const withoutProof=config.replace(/^# RUSTSEC-2026-0543 blocked-upstream.*\\n/mu,'');
    const missing=invoke({text:withoutProof});
    assert.equal(missing.status,1,missing.stderr);
    assert.match(missing.stdout,/ignores RUSTSEC-2026-0543 without a proof line/u);
    assert.equal(missing.calls.some(args=>args[0]==='audit'),false);
    const unrelated=invoke({AUDIT_FAILURE:'1'});
    assert.equal(unrelated.status,1,unrelated.stderr);
    assert.ok(unrelated.calls.some(args=>args[0]==='audit'&&args.includes('warnings')));
  });
});
''')
print('Recorded the exact-version upstream blocker under the existing audit policy and added shell-boundary controls.')
