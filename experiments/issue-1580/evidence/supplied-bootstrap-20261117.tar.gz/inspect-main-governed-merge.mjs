import { execFileSync } from 'node:child_process';
import { deserialize } from 'node:v8';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const name='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8';
const before=deserialize(execFileSync('git',['show',':2:'+name],{maxBuffer:8*1024*1024}));
const after=deserialize(readFileSync(name));
const hash=x=>createHash('sha256').update(String(x)).digest('hex');
const differences=[];const seen=new WeakMap();let pairs=0;
function walk(a,b,path='') {
  if(Object.is(a,b))return;
  assert.equal(typeof a,typeof b,path);
  if(a===null||b===null||typeof a!=='object') {differences.push({path,before:a,after:b});return;}
  if(seen.get(a)?.has(b))return;
  if(!seen.has(a))seen.set(a,new WeakSet());seen.get(a).add(b);pairs++;assert.ok(pairs<200000);
  assert.equal(Object.getPrototypeOf(a),Object.getPrototypeOf(b),path);
  assert.deepEqual(Object.keys(a),Object.keys(b),path);
  for(const key of Object.keys(a))walk(a[key],b[key],path+'/'+key);
}
walk(before,after);
const report={pairs,caseCount:after.inventory.cases.length,unsupportedCount:after.inventory.unsupported.length,nativeManifestUnchanged:JSON.stringify(before.sourceManifest)===JSON.stringify(after.sourceManifest),differences};
writeFileSync('/tmp/issue-1580-research/governed-main-merge-differences.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,differences:undefined}));
for(const d of differences.slice(0,50))console.log(JSON.stringify({path:d.path,beforeBytes:String(d.before).length,afterBytes:String(d.after).length,beforeSha256:hash(d.before),afterSha256:hash(d.after),beforePrefix:String(d.before).slice(0,110),afterPrefix:String(d.after).slice(0,110)}));
for(const d of differences) {
  const keys=d.path.split('/').slice(1,-1);
  const parent=keys.reduce((obj,key)=>obj[key],after);
  console.log('SOURCE',JSON.stringify({path:d.path,file:parent.file??parent.path,sha256:parent.sha256}));
}
console.log('totalDifferences',differences.length);
