from pathlib import Path
import json,subprocess,gzip,hashlib
root=Path('/tmp/gh-issue-solver-1794900398048');p=root/'rust/tests/web/default-branch-build-policy.test.mjs'
p.write_text(p.read_text()+'''

test('complete catalog driver and offline reasoning contracts enter the native lane', {timeout:15000}, () => {
  const modules = ['agentic-coding/issue_498_google_trends_catalog.rs',
    'specification/unknown_reasoning.rs'];
  for (const path of modules)
    assert.equal(admission(['rust/tests/unit/' + path])['native-type-check'], true, path);
  assert.equal(admission(['rust/tests/unit/unrelated-offline.rs'])['native-type-check'], false);
  const source = read('rust/tests/unit/reasoning_contracts.rs');
  for (const path of modules) assert(source.includes('#[path = "' + path + '"]'), path);
});
''')
base=root/'experiments/issue-1580/evidence/checks/offline-catalog-admission';base.mkdir(exist_ok=False)
argv=['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/default-branch-build-policy.test.mjs']
p=subprocess.run(argv,cwd=root,capture_output=True,env={**__import__('os').environ,'NODE_OPTIONS':'--max-old-space-size=256'})
raw=p.stdout+p.stderr;packed=gzip.compress(raw,mtime=0);(base/'before.log.gz').write_bytes(packed)
row={'argv':argv,'exitCode':p.returncode,'sha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'nativeExecuted':False,'independentAuthorshipCredit':0}
(base/'before.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row));print('\n'.join(raw.decode().splitlines()[-36:]));assert p.returncode==1
