from pathlib import Path
import gzip,json,hashlib,re
r=Path.cwd();b=r/'experiments/issue-1580/evidence/checks/spelled-calendar-clock/validation';raw=gzip.decompress((b/'complete-local-gates.log.gz').read_bytes()).decode();rows=[]
for line in raw.splitlines():
 m=re.match(r'(PASS|FAIL) (\S+) .*',line)
 if not m:continue
 status,name=m.groups();p=r/'experiments/formal_ai_subagent/sandboxes/gates'/(name+'.log');content=p.read_bytes();packed=gzip.compress(content,mtime=0);filename='gate-'+name+'.log.gz';(b/filename).write_bytes(packed);rows.append({'name':name,'status':status,'file':filename,'rawSha256':hashlib.sha256(content).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'lines':len(content.splitlines())})
 if status=='FAIL':
  print('\nFAILED GATE',name)
  for n,line in enumerate(content.decode().splitlines(),1):print(str(n)+': '+line)
(b/'detailed-gate-manifest.json').write_text(json.dumps(rows,indent=2)+'\n');print('ARCHIVED',len(rows),'detailed gate payloads')
