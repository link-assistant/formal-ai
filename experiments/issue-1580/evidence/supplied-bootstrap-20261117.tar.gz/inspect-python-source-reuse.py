from pathlib import Path
import hashlib,json

checkout=Path('/tmp/issue-1580-research/templates/python-complete')
review=json.loads(Path('docs/case-studies/issue-1580/templates/python-partial-semantic-review.json').read_text())
assert checkout.is_dir()
for row in review['files']:
 source=checkout/row['path']
 assert source.stat().st_size==row['bytes']
 digest=hashlib.sha256()
 blob=hashlib.sha1(('blob '+str(row['bytes'])+'\0').encode())
 with source.open('rb') as stream:
  for chunk in iter(lambda:stream.read(65536),b''):
   digest.update(chunk);blob.update(chunk)
 assert digest.hexdigest()==row['sha256'],row['path']
 assert blob.hexdigest()==row['gitBlob'],row['path']
read={}
for row in review['files']:
 if row['reviewStatus']=='active-source-fully-read':
  read.setdefault(row['sha256'],[]).append(row)
matches=[];unique=[]
for row in review['files']:
 if row['reviewStatus']!='historical-unread': continue
 matches_to=read.get(row['sha256'],[])
 if not matches_to:
  unique.append(row);continue
 source=checkout/row['path']
 digest=hashlib.sha256()
 with source.open('rb') as stream:
  for chunk in iter(lambda:stream.read(65536),b''): digest.update(chunk)
 assert digest.hexdigest()==row['sha256']
 matches.append({'historicalPath':row['path'],'historicalGitBlob':row['gitBlob'],'sha256':row['sha256'],'lines':row['lines'],'matchingFullyReadActivePaths':[entry['path'] for entry in matches_to]})
result={'commit':review['commit'],'sourceKind':'pinned source archive, not a Git checkout','verifiedSourceBlobs':len(review['files']),'historicalFiles':len(matches)+len(unique),'exactActiveContentMatches':matches,'uniqueHistoricalFiles':[row['path'] for row in unique],'directReadCredit':0,'autonomousAuthorshipCredit':0,'contextualApplicabilityReviewed':False}
Path('/tmp/issue-1580-research/python-historical-content-reuse.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print('EXACT ACTIVE CONTENT MATCHES',len(matches),'historical files',sum(row['lines'] for row in matches),'lines')
print('UNIQUE HISTORICAL FILES',len(unique),sum(row['lines'] for row in unique),'lines')
for row in matches: print(row['historicalPath'],'==',','.join(row['matchingFullyReadActivePaths']))
for row in unique: print('UNIQUE',row['path'],row['lines'])
