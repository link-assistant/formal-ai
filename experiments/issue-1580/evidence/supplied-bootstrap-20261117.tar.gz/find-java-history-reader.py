from pathlib import Path
import json
r=Path('/tmp/gh-issue-solver-1794900398048');s=Path('/tmp/issue-1580-research')
print('SCRATCH JAVA READERS');print('\n'.join(p.name for p in sorted(s.glob('*java*'))))
index=json.loads((r/'docs/case-studies/issue-1580/templates/java-historical-review-index.json').read_text());print('INDEX FIELDS',list(index));print(json.dumps({k:v for k,v in index.items() if k not in ['files','pages','forwardParts']},indent=2)[:7500])
for name in ['read-java-historical-page.py','read-java-history-page.py','read-java-history-112-113.py']:
    if (s/name).exists():print('HELPER',name);print((s/name).read_text())
