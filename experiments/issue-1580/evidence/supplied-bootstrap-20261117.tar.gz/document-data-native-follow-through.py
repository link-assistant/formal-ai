from pathlib import Path
import json
root=Path('/tmp/gh-issue-solver-1794900398048')
review=json.loads((root/'experiments/issue-1580/evidence/checks/data-and-captured-native-validation/review.json').read_text())
assert review['allPassed'] and review['sourceUnchangedDuringValidation']
assert review['focusedCounts']=={'tests':75,'pass':75,'fail':0,'skipped':0}
assert review['gateCounts']=={'PASS':11,'FAIL':0,'SKIP':0}
index=json.loads((root/'docs/case-studies/issue-1580/templates/java-historical-review-index.json').read_text())
assert index['cumulativeSummary']['literalPages']==126 and index['cumulativeSummary']['literalLines']==8122
plan=root/'experiments/issue-1580/work-plan.md';text=plan.read_text()
old='- [ ] Publish this repaired batch after fresh queue checks and collect every current-head hosted outcome, including the nine unknown-source contracts. Do not equate a passing scoped run with issue completion.'
new='- [x] Publish the batch as `4d105df7` after fresh queue checks and collect all 23 hosted outcomes: 22 succeed. The sole failure is a new cache-positive fixture assertion, investigated and repaired in the following batch. The four-language original miss contract passes; the full unknown-source target has eight passes and one failure.'
assert text.count(old)==1;text=text.replace(old,new)
text+='''

## Original data contracts and deterministic captured positives

- [x] Collect every published `4d105df7` workflow and archive all failed workflow/job logs with exact head, timestamps and hashes: 22/23 workflows pass. The previous large-diff and role-registry failures are resolved. The sole actionable failure is native `seed_backed_bare_terms_still_use_public_knowledge_cache`, at job lines 1712–1725: an added offline cursor assertion expects `concept_lookup` but receives `web_search`.
- [x] Literally read native lines 1609–1725. Thirty-three isolated Rust cases and eight unknown-source cases pass; one added positive-control assertion fails. The original four-language miss contract passes with its corrected offline invented-term fixture. Later library, Spanish and HTTP steps do not execute after this failure; their prior `f6ecab59` successes remain historical evidence. Retain all 62 archived payload hashes and distinguish targeted literal review from full-log review.
- [x] Find the fixture root cause: no committed cursor capture exists, so a prior live runtime cache answer cannot be assumed in an offline test. Keep the original seeded Rust positive intact, and extend the existing committed isogram control to both the bare term and question. Preserve full exact answer equality, gloss, source URL and digest checks, and forbid a web-search handoff for either form. Commit `b2e84dd0`; actual hosted execution of the revised control remains pending.
- [x] Read all 970 lines of the original data-file contracts and all 593 technical-scalar helper lines, including the initially truncated middle chunk. Both files are byte-identical to original main `015a6831`. Add their 22 existing tests as one isolated native target without changing any assertion, fixture, threshold or helper. Admit both source paths and all consumed `data/**/*.lino`, `data/cache/**/*.json` and existing seed-cache inputs; unrelated data formats remain excluded. Commit `d43bc038`.
- [x] Literally inspect the three original data panics in main run 44188508650: duplicate `calendar-duration-sum` (line 65553), pipe-packed `year|years` (65583), and malformed client integration notation (65615–65616). Preserve the complete original log and hashes. The new hosted target replays these original contracts; actual execution remains pending.
- [x] Reproduce omitted native admission locally: 25 policy tests yield 23 passes and two failures before the change, then 25 passes afterward. Initial data-only validation passes 69 focused tests and 11 affected gates. Final combined source `b2e84dd0` passes 75 tests across five focused files, all 11 affected gates, Rust 2024 formatting and whitespace. Source hashes remain unchanged throughout; all payload hashes are verified and complete focused/aggregate logs are literally read. No native build runs locally.
- [x] Refresh the governed witness with the unchanged reader. Data-target admission changes only four Cargo source identities; the capture-positive correction changes only one unknown-source identity. Complete objects, diagnostics and counts remain equal after those reviewed hash substitutions: 1,185 total, 221 supported and 964 unsupported. No execution or independent reasoning credit is added.
- [x] Archive the successful `4d105df7` publication receipt and all 58 payloads. Refresh the issue body and all ten issue/PR conversation comments: unchanged; zero inline comments, reviews or required sub-issues. The remote PR description matches its published head, and main `7b7e189d` remains an ancestor.
- [x] Literally read Java historical pages 125–126 without truncation: continuous 126/254 pages, 8,122 lines, 111 complete files and the partial Node catalog through line 543/884. Preserve prior review-part hashes. Pages 127–254 and full semantic applicability remain unfinished.
- [ ] Publish this complete repair batch after fresh queue checks. Collect all next-head workflows and verify the 22 unchanged data cases, nine unknown-source cases, 13 captured-source cases, original Spanish sibling, other isolated contracts and HTTP replays without treating them as full issue completion.
- [ ] Continue the other 44 original panic contracts and three historical budget terminations. Eight original panic contracts have unchanged-source hosted passes, and one has a justified corrected local-miss fixture with an actual hosted pass; the remaining 44 include all three data contracts until execution is verified. All broader acceptance criteria remain open. Keep PR #1581 draft and unmerged; accepted independent reasoning remains 0/20, with the 5% target used only for reporting.
'''
plan.write_text(text)
checkpoint=root/'docs/case-studies/issue-1580/language-source-binding-checkpoint.md';text=checkpoint.read_text()
assert '## Original data contracts and deterministic captured positives' not in text
text+='''

## Original data contracts and deterministic captured positives

Published `4d105df788a398c6c26a9431393622bb4206dbfe` finishes **22/23 workflows successfully**, resolving both preceding workflow failure classes. Its sole [pipeline failure](https://github.com/link-assistant/formal-ai/actions/runs/44367130256) is an added cache-positive assertion: [native job 135024168069](https://github.com/link-assistant/formal-ai/actions/runs/44367130256/job/135024168069), lines 1712–1725, receives `web_search` for offline `cursor` instead of `concept_lookup`. No committed cursor capture exists. The prior explanation that this value was committed cached knowledge was incorrect; the original observed answer depended on live runtime state.

That job passes **33 isolated Rust cases and eight unknown-source cases**, including the corrected original four-language local-miss contract. One positive control fails. Subsequent library, Spanish and HTTP steps do not execute on this head; the 47 Rust and three HTTP passes on `f6ecab59` remain historical evidence. Complete failed logs and 62 verified payload hashes are in `evidence/ci/unknown-role-4d105df7/`. Native lines 1609–1725 were literally read; full raw-log literal review remains unfinished.

The repair preserves the seeded Rust positive and supplies both bare `isogram` and `What is an isogram?` directly from the existing committed capture. Both retain **complete exact answer equality**, gloss, source URL, digest and absence of a web-search handoff. No transient cache is presumed and no production lookup behavior changes. Hosted execution of this revised control remains pending.

The next hosted batch also adds **22 unchanged original data-file tests**, including all five nested technical-scalar controls. All 970 source lines and 593 helper lines were read, and both files remain byte-identical to original main `015a6831`. These replay three original failures: duplicate meaning slugs, pipe-packed values, and malformed client integration notation (original main workflow lines 65553, 65583 and 65615–65616). Admission now covers both sources and every data format they actually consume: all data Links Notation files, cached JSON and existing seed-cache inputs. All thresholds and assertions remain intact; actual native execution remains pending.

Final source `b2e84dd0` passes **75 focused JavaScript tests across five files**, **11 affected local gates**, Rust 2024 formatting and whitespace, with no skips or local native compilation. Full focused and aggregate logs were literally read and all payload hashes verified. The unchanged governed reader permits only four Cargo identity updates for data admission and one unknown-source identity update for the positive-control correction; complete case objects, diagnostics and **1,185 / 221 supported / 964 unsupported** counts stay unchanged.

Feedback is unchanged, the preceding publication receipt is archived, and main `7b7e189d` remains integrated. Eight original panic contracts have unchanged-source hosted passes, and one more has its justified corrected local-miss fixture passing; the other **44 original contracts and three historical budget terminations** remain unfinished. Java historical review advances to **126/254 pages and 8,122 lines**, with the Node catalog through line 543/884. Pages 127–254 and complete semantic applicability remain open. All broader issue criteria remain active; PR #1581 stays draft and unmerged. Supplied work earns zero independent reasoning credit (0/20 accepted), and 5% remains reporting only.
'''
checkpoint.write_text(text)
readme=root/'docs/case-studies/issue-1580/README.md';text=readme.read_text()
text+='''

The data-contract follow-through records `4d105df7`: 22 workflows pass and one
native cache-positive assertion fails because it assumes an uncommitted runtime
capture. The repair uses the existing committed isogram capture for both bare
and question forms, retaining the whole attributed answer. The next hosted batch
also admits 22 byte-identical original data-file tests. Combined local validation
passes 75 focused tests and 11 affected gates; actual native execution is pending.
Java historical review reaches 126/254 pages and 8,122 lines. The remaining 44
original panic contracts, three budget terminations and broader issue criteria
remain unfinished; the PR remains draft.
'''
readme.write_text(text)
body=root/'experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md'
lines=body.read_text().splitlines()
assert lines[17].startswith('- Main `7b7e189d`') and lines[18].startswith('- Published head `f6ecab59`')
lines[17]='- Main `7b7e189d` is integrated. Final source `b2e84dd0` passes **75 focused JavaScript tests across five files, zero failures or skips**, **11 affected local gates**, Rust 2024 formatting and whitespace; source hashes remain unchanged. Initial native-admission controls fail twice before the data-target repair and pass 25/25 afterward. The next hosted batch adds **22 byte-identical original data-file tests**, including five technical-scalar controls, without changing assertions or thresholds. Their consumed Links Notation and cached JSON paths now select native execution. Governed complete objects and diagnostics remain equal after four Cargo identities and one unknown-source identity are refreshed by the unchanged reader: **1,185 / 221 supported / 964 unsupported**. No native build runs locally; the previous full inventory remains 139 gates with 87 passes and 52 explicit native/context skips on `dc618e45`.'
lines[18]='- Published `4d105df7` completes **23 workflows: 22 pass**, resolving the previous diff-buffer and role-registry failures. Its sole [pipeline failure](https://github.com/link-assistant/formal-ai/actions/runs/44367130256) is an added offline cursor assertion (native job lines 1712–1725): no committed cursor capture exists. The repair preserves the seeded Rust positive and replays both bare `isogram` and its question from the existing committed capture, retaining the **entire exact answer, attribution, digest and no-search checks**. That head passes 33 isolated Rust cases and eight unknown-source cases, including the corrected original four-language miss; subsequent library, Spanish and HTTP steps do not execute. Prior `f6ecab59` evidence remains **47 Rust and three HTTP passes**. The revised positive and 22 data cases await hosted execution; complete failed logs and exact source identities are retained.'
for i,line in enumerate(lines):
 if line.startswith('Unfinished acceptance remains explicit'):
  lines[i]=line.replace('eight already replayed with unchanged source and 45 still open, including the cursor contract until hosted verification','eight replayed with unchanged source, one corrected local-miss fixture passing in hosted execution, and 44 still open').replace('**124/254 continuous pages**','**126/254 continuous pages**').replace('8,069 source lines; pages 125–254','8,122 source lines; pages 127–254')
text='\n'.join(lines)+'\n';assert text.count('Fixes #1580')==1;body.write_text(text)
print(json.dumps({'source':review['head'],'focused':review['focusedCounts'],'gates':review['gateCounts'],'javaPages':126,'fullIssueComplete':False,'independentAuthorshipCredit':0}))
