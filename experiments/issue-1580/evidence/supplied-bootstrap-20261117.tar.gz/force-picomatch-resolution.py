from pathlib import Path
import json,subprocess,os
r=Path('/tmp/gh-issue-solver-1794900398048')
print((r/'packages/picomatch-compat/package.json').read_text())
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=256'
for name in ['desktop','vscode']:
 p=r/name/'package-lock.json'
 d=json.loads(p.read_text())
 removed=[k for k in d['packages'] if k.endswith('/picomatch')]
 for k in removed: del d['packages'][k]
 p.write_text(json.dumps(d,indent=2)+'\n')
 log=Path('/tmp/issue-1580-research')/('picomatch-resolve-'+name+'.log')
 with log.open('w') as out:
  cp=subprocess.run(['npm','install','--package-lock-only','--ignore-scripts','--no-audit','--no-fund'],cwd=r/name,stdout=out,stderr=subprocess.STDOUT,env=env)
 print(name,'removed stale entries',removed,'exit',cp.returncode)
 print(log.read_text()[-5000:])
 print(json.dumps({k:v for k,v in json.loads(p.read_text())['packages'].items() if 'picomatch' in k}))
 if cp.returncode: raise SystemExit(cp.returncode)
