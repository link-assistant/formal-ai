from pathlib import Path
path = Path('experiments/issue-1580/trace-template-ci.mjs')
text = path.read_text()
before = """    fs.writeFileSync(path.join(output,language+'-ci-reference-graph.json.gz'),gzipSync(JSON.stringify({repository:source.repo,commit:source.sha,...graph},null,2)+'\\n',{mtime:0}));
    summaries.push({language,roots:graph.roots.length,files:graph.files.length,commands:graph.commands.length,unresolved:graph.unresolved.length});
  }
  console.log(JSON.stringify(summaries));"""
after = """    const file=language+'-ci-reference-graph.json.gz';
    const content=Buffer.from(JSON.stringify({repository:source.repo,commit:source.sha,...graph},null,2)+'\\n');
    const packed=gzipSync(content);
    fs.writeFileSync(path.join(output,file),packed);
    const sha256=bytes=>createHash('sha256').update(bytes).digest('hex');
    summaries.push({language,repository:source.repo,commit:source.sha,file,
      sha256:sha256(packed),uncompressedSha256:sha256(content),
      roots:graph.roots.length,files:graph.files.length,commands:graph.commands.length,unresolved:graph.unresolved.length});
  }
  fs.writeFileSync(path.join(output,'ci-reference-graphs.json'),JSON.stringify(summaries,null,2)+'\\n');
  console.log(JSON.stringify(summaries));"""
assert before in text
path.write_text(text.replace(before,after))
