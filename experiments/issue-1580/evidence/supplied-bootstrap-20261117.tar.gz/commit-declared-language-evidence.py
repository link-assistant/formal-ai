from pathlib import Path
import hashlib, json, subprocess
root = Path('/tmp/gh-issue-solver-1794900398048')
scratch = Path('/tmp/issue-1580-research')
base = root / 'experiments/issue-1580/evidence'
out = base / 'checks/declared-language-policy'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == '637a08b745d65d053c116aad961714d107e0fae4'
(out / 'pull-request-description.md').write_bytes((scratch / 'declared-language-final-pr-body.md').read_bytes())
for name in ['archive-round-bootstrap.py', 'archive-evidence.py']:
    subprocess.run(['python3', str(scratch / name)], cwd=root, check=True)
audit_path = out / 'sealed-evidence-audit.json'
audit = json.loads(audit_path.read_text())
manifest = json.loads((base / 'supplied-bootstrap-20261117.json').read_text())
audit['suppliedScripts'] = len(manifest['files'])
audit['compressedScriptBytes'] = (base / 'supplied-bootstrap-20261117.tar.gz').stat().st_size
records = [json.loads(line) for line in (base / 'commands/index.jsonl').read_text().splitlines()]
audit['sealedCommandRecords'] = len(records)
audit['newCommandHashesVerified'] = len(records) - 2393
for row in records[2393:]:
    import gzip
    raw = (base / 'commands' / row['file']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row['compressedSha256']
    assert hashlib.sha256(gzip.decompress(raw)).hexdigest() == row['sha256']
audit_path.write_text(json.dumps(audit, indent=2) + '\n')
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
files = subprocess.check_output(['git', 'ls-files', '-m', '-o', '--exclude-standard'], cwd=root, text=True).splitlines()
exact = {
    'docs/case-studies/issue-1580/declared-language-policy-checkpoint.md',
    'docs/case-studies/issue-1580/templates/java-historical-partial-review.json',
    'experiments/issue-1580/work-plan.md',
    'experiments/issue-1580/evidence/supplied-bootstrap-20261117.json',
    'experiments/issue-1580/evidence/supplied-bootstrap-20261117.tar.gz',
}
prefixes = [
    'experiments/issue-1580/evidence/checks/declared-language-policy/',
    'experiments/issue-1580/evidence/ci/opener-native-boundary-edffcb18/',
    'experiments/issue-1580/evidence/commands/',
]
assert files and all(name in exact or any(name.startswith(prefix) for prefix in prefixes) for name in files), files
subprocess.run(['git', 'add', '--', *files], cwd=root, check=True)
subprocess.run(['git', 'commit', '-m', 'Preserve declared language regressions and both complete CI failures'], cwd=root, check=True)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root).strip()
print('Evidence commit', subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip())
