import json
import re
from pathlib import Path

base = Path('/tmp/issue-1580-research/java-context')
for kind in ['issues', 'pulls']:
    data = json.loads((base / f'{kind}.json').read_text())
    for row in data:
        if kind == 'issues' and 'pull_request' in row:
            continue
        lines = (row.get('body') or '').splitlines()
        matched = [(i, line) for i, line in enumerate(lines, 1) if re.search(r'(commit.{0,80}(?:fail|error|nothing)|(?:fail|error).{0,80}commit|Nothing to commit|collection failed|pre-commit hook)', line, re.I)]
        if matched:
            print(kind, row['number'], row['title'])
            for i, line in matched:
                print(i, line)
    if kind == 'pulls':
        for row in data:
            if row['number'] in [13, 25, 26]:
                print('RELATED PR', row['html_url'], row['title'])
                print(row.get('body') or '')
