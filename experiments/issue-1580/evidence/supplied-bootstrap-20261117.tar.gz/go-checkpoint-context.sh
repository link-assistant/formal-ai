set -eu
rg --files /tmp/issue-1580-research | rg '(issue.*(json|md)$|read-template-page|archive-round-bootstrap|ci-repair-sixth|go-complete-inventory)'
sed -n '1,145p' /tmp/issue-1580-research/record-go-semantic-review.py
sed -n '520,580p' docs/case-studies/issue-1580/templates/go-semantic-review.json
cat /tmp/issue-1580-research/current-head-status.py
