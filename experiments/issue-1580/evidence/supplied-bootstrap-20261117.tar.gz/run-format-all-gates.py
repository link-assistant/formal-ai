from pathlib import Path
import datetime,gzip,hashlib,json,os,subprocess,sys,time

directory=Path('experiments/issue-1580/evidence/checks/python-release-formatting')
if len(sys.argv)==1:
    assert not (directory/'all-local-gates.json').exists()
    with (directory/'all-local-gates-bootstrap.log').open('wb') as stream:
        child=subprocess.Popen([sys.executable,__file__,'finish'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    print(json.dumps({'pid':child.pid,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'completion':str(directory/'all-local-gates.json')}))
    sys.exit(0)
assert sys.argv==[__file__,'finish']
env=dict(os.environ)
env['PATH']='/tmp/issue-1580-research/shellcheck-v0.11.0:'+env['PATH']
env['NODE_OPTIONS']='--max-old-space-size=128'
command=['node','experiments/formal_ai_subagent/local-gates.mjs']
started=time.time()
plain=directory/'all-local-gates.log'
with plain.open('wb') as stream:
    result=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
raw=plain.read_bytes()
(directory/'all-local-gates.log.gz').write_bytes(gzip.compress(raw,mtime=0))
plain.unlink()
logs=[]
for source in sorted(Path('experiments/formal_ai_subagent/sandboxes/gates').glob('*.log')):
    if source.stat().st_mtime<started:continue
    data=source.read_bytes()
    target=directory/'gate-details'/f'{source.name}.gz'
    target.parent.mkdir(exist_ok=True)
    target.write_bytes(gzip.compress(data,mtime=0))
    logs.append({'name':source.name,'rawBytes':len(data),'rawSha256':hashlib.sha256(data).hexdigest(),'log':str(target.relative_to(directory))})
record={'command':command,'status':result.returncode,'durationSeconds':round(time.time()-started,3),'rawSha256':hashlib.sha256(raw).hexdigest(),'log':'all-local-gates.log.gz','perGateLogs':logs,'rustBuildsEnabled':False,'offlineAuditStandIns':False,'independentAuthorshipCredit':0}
(directory/'all-local-gates.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':result.returncode,'durationSeconds':record['durationSeconds'],'perGateLogCount':len(logs)}),flush=True)
