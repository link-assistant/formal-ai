import json
from pathlib import Path
p=Path('/tmp/issue-1580-research')
for name in ['issue-current.json','pr-refreshed.json']:
    data=json.loads((p/name).read_text())
    print(name, data.get('title',''))
    print(data.get('body',''))
