import subprocess
for args in [
 ['rg','-n','metaRunProcedure|metaResolveImpasse|metaReason\(','js/worker/formal_ai_worker_meta*'],
 ['rg','-n','function metaRunProcedure|function metaResolveImpasse|function tryGreetingProceduralCompound|independent|split.*and','js/worker'],
]:
    r=subprocess.run(args,text=True,capture_output=True);print('COMMAND',args,'EXIT',r.returncode);print(r.stdout,r.stderr)
