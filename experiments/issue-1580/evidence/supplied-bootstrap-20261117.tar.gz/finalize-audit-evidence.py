from pathlib import Path
import gzip,hashlib,json,subprocess
directory=Path('experiments/issue-1580/evidence/checks/audit-inventory-boundary')
for name in ['own-final','python-after','maintained-final']:
 r=json.loads((directory/f'{name}.json').read_text());assert r['status']==0
 assert hashlib.sha256(gzip.decompress((directory/r['log']).read_bytes())).hexdigest()==r['rawSha256']
for name in ['workflow','readable','abbreviations','dependency']:
 r=json.loads((directory/f'gates-{name}.json').read_text());assert r['exitCode']==0
 assert hashlib.sha256(gzip.decompress((directory/r['log']).read_bytes())).hexdigest()==r['rawSha256']
record=json.loads((directory/'evidence.json').read_text());record['logs']=[]
for path in sorted(directory.glob('*.log.gz')):
 raw=gzip.decompress(path.read_bytes());record['logs'].append({'file':path.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'compressedSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':len(raw)})
record['verification']='Focused own audit 10/10, pinned Python observation 3/3, maintained observations 34/34 with no skips. Relevant readability, abbreviation, size, runner, CI-speed and shell gates pass. The registered dependency gate passes with offline npm/Bun stand-ins against every real tracked lockfile, not a claim about live vulnerabilities. Initial abbreviation gate failed on feedback-pr-comments.json.gz; it was renamed feedback-pull-request-comments.json.gz without changing the ratchet.'
(directory/'evidence.json').write_text(json.dumps(record,indent=2)+'\n')
p=directory/'README.md';s=p.read_text();s+='\nRelevant local gates pass. The registered dependency gate uses offline npm/Bun stand-ins and verifies all actual tracked lockfiles were invoked; this is execution/inventory verification, not a live advisory result. The first abbreviation gate rejected a new evidence filename; spelling pull request in full repaired it without changing the ratchet. Its initial failure and passing recheck are both retained.\n';p.write_text(s)
subprocess.run(['git','add','--','experiments/issue-1580/evidence/checks/audit-inventory-boundary','experiments/issue-1580/evidence/ci/e120c05b4','docs/case-studies/issue-1580','experiments/issue-1580/work-plan.md'],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
print('Verified',len(record['logs']),'full compressed logs and final focused/gate statuses; whitespace check passed.')
