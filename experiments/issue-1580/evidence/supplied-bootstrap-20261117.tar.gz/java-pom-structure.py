import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path

p = Path('/tmp/issue-1580-research/templates/java-complete/pom.xml')
data = p.read_bytes()
root = ET.fromstring(data)

def local(tag):
    return tag.split('}', 1)[-1]

def represent(node):
    children = list(node)
    if not children:
        return (node.text or '').strip()
    result = {}
    for child in children:
        key = local(child.tag)
        value = represent(child)
        if key in result:
            if not isinstance(result[key], list):
                result[key] = [result[key]]
            result[key].append(value)
        else:
            result[key] = value
    return result

out = represent(root)
target = Path('/tmp/issue-1580-research/java-pom-structure.json')
target.write_text(json.dumps(out, indent=2) + '\n')
print('POM SHA256', hashlib.sha256(data).hexdigest())
print('All XML elements retained below; whitespace/comments excluded. Structured review, not a complete raw-line read.')
for key, value in out.items():
    if key in {'build', 'profiles'}:
        continue
    print(key, json.dumps(value, separators=(',', ':')))
print('BUILD')
for key, value in out.get('build', {}).items():
    if key == 'plugins':
        for plugin in value['plugin']:
            print('plugin', json.dumps(plugin, separators=(',', ':')))
    else:
        print(key, json.dumps(value, separators=(',', ':')))
print('PROFILES', json.dumps(out.get('profiles'), separators=(',', ':')))
