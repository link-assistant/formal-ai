from pathlib import Path
import json

p=Path('experiments/formal_ai_subagent/sandboxes/gates/check-file-size.log')
lines=p.read_text().splitlines()
print('GATE LOG',str(p),'LINES',len(lines))
assert len(lines)<=1500
for n,line in enumerate(lines,1):print(f'{n}: {line}')
for p in [Path('scripts/check-file-size.mjs'),Path('experiments/issue-1580/archive-evidence.py')]:
 lines=p.read_text().splitlines()
 print('SOURCE',str(p),'LINES',len(lines))
 for n,line in enumerate(lines[:180],1):print(f'{n}: {line}')
