from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
base=Path('experiments/issue-1580/evidence/ci/main-444575f2')
cmd=['gh','api','repos/link-assistant/formal-ai/actions/runs?head_sha=444575f2ac28f609c94497865f125f99415ff6d5&event=push&per_page=100','--paginate','--jq','.workflow_runs[] | {id,name,head_sha,status,conclusion,created_at,updated_at,html_url}']
raw=subprocess.check_output(cmd)
(base/'push-run-list.jsonl.gz').write_bytes(gzip.compress(raw,mtime=0))
rows=[json.loads(line) for line in raw.splitlines()]
(base/'push-runs.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
failures=[r for r in rows if r['status']=='completed' and r['conclusion'] not in ['success','skipped','neutral']]
for row in failures:
    path=base/(str(row['id'])+'.log.gz')
    if path.exists(): continue
    rawpath=Path('/tmp/issue-1580-research')/('main-444575f2-'+str(row['id'])+'.log')
    with rawpath.open('wb') as out:
        subprocess.run(['gh','run','view',str(row['id']),'--repo','link-assistant/formal-ai','--log'],stdout=out,check=True)
    data=rawpath.read_bytes()
    path.write_bytes(gzip.compress(data,mtime=0))
    print(json.dumps({'run':row['id'],'rawLog':str(rawpath),'rawBytes':len(data),'rawLines':len(data.splitlines()),'sha256':hashlib.sha256(data).hexdigest()}))
