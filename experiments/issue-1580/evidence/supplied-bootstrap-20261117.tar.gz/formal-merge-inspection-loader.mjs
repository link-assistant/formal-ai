// Externally supplied bootstrap only: load the pre-merge side of conflicted
// generated imports so Formal AI can inspect and resolve the real repository.
import { registerHooks } from 'node:module';
registerHooks({
  load(url, context, nextLoad) {
    const loaded = nextLoad(url, context);
    if (url.endsWith('/js/server/worker-script-prerequisites.mjs')
      || url.endsWith('/js/worker-script-prerequisites.js')) {
      const source = String(loaded.source);
      return { ...loaded, source: source.replace(/^<<<<<<<[^\n]*\n([\s\S]*?)^=======[^\n]*\n[\s\S]*?^>>>>>>>[^\n]*\n/gm, '$1') };
    }
    return loaded;
  },
});
