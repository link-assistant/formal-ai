from pathlib import Path
import subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');p=root/'rust/tests/web/calendar-act-paraphrases.test.mjs';s=p.read_text();assert 'the full worker keeps' not in s
s+='''
for (const prompt of prompts) test('the full worker keeps the original scheduling act: ' + prompt, {timeout:15000}, async () => {
  const answer = await worker.solve(prompt, [], {}, {}, [], {});
  assert.equal(answer?.intent, 'calendar_create_event', JSON.stringify(answer));
  assert.match(answer.content, /BEGIN:VCALENDAR/u);
  assert.equal(answer.memoryOperation, undefined);
});
for (const prompt of [
  'Remember that my favorite color is blue.',
  'Запомни что мой любимый цвет синий.',
  'Remember that the meeting is Friday at 14:00.',
  'Запомни что встреча в пятницу в 14:00.',
]) test('the full worker keeps an explicit memory write: ' + prompt, {timeout:15000}, async () => {
  const answer = await worker.solve(prompt, [], {}, {}, [], {});
  assert.equal(answer?.intent, 'memory_write', JSON.stringify(answer));
  assert.equal(answer.memoryOperation?.action, 'append');
});
''';p.write_text(s)
print('Added five original full-worker scheduling cases and four explicit memory controls; production seed unchanged for before test.')
