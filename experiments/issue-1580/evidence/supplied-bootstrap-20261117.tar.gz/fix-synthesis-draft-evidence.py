from pathlib import Path
import subprocess
path=Path('rust/src/solver_synthesis.rs')
text=path.read_text()
for before,after in [
    ('                confidence: 0.0,\n            };','                confidence: 0.0,\n                evidence: Vec::new(),\n            };'),
    ('        confidence: candidate.confidence,\n    };','        confidence: candidate.confidence,\n        evidence: Vec::new(),\n    };')]:
    assert text.count(before)==1,before
    text=text.replace(before,after)
path.write_text(text)
subprocess.run(['git','diff','--','rust/src/solver_synthesis.rs'],check=True)
for name in ['rust/tests/web/issue-0703-synthesis-pipeline.test.mjs','rust/tests/web/issue-1177-code-synthesis-parity.test.mjs']:
    print('\nTEST SOURCE',name)
    lines=Path(name).read_text().splitlines()
    for number,line in enumerate(lines[:80],1):print(str(number)+': '+line)
