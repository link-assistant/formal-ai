from pathlib import Path
import json
for name in ['experiments/issue-1580/work-plan.md','docs/case-studies/issue-1580/templates/README.md','/tmp/issue-1580-research/run-csharp-collision-before.py','experiments/issue-1580/evidence/ci/0f90c0a7a/attempt-1/summary.json','/tmp/issue-1580-research/archive-round-bootstrap.py']:
 p=Path(name); lines=p.read_text().splitlines(); print('FILE',name,len(lines)); assert len(lines)<=1500
 print('\n'.join(f'{n}: {line}' for n,line in enumerate(lines,1)))
p=Path('docs/case-studies/issue-1580/templates/csharp-partial-semantic-review.json'); v=json.loads(p.read_text()); print('EXISTING DECISIONS', json.dumps([{'path':r['path'],'decision':r['decision']} for r in v['files'] if r['reviewStatus']=='active-source-fully-read' and any(t in r['decision'].lower() for t in ['unread','38 active','11974','120'])],indent=2))
inventory=json.loads(Path('/tmp/issue-1580-research/templates/csharp-complete-inventory.json').read_text()); print('INVENTORY',type(inventory).__name__,len(inventory),json.dumps(inventory[:2] if isinstance(inventory,list) else {k:v for k,v in inventory.items() if k not in ['files','blobs']}))
