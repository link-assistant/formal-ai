from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/checks/php-push-integrity/report-publication'
preflight = json.loads((base / 'preflight.json').read_text())
assert preflight['sourceUnchanged'] and preflight['pullBodiesUnchanged']
assert not preflight['candidateDuplicateFound'] and preflight['allImmutablePayloadsVerified']
bodyfile = base / 'posted-body.md'
oldbody = bodyfile.read_text()
assert hashlib.sha256(oldbody.encode()).hexdigest() == preflight['bodySha256']
assert oldbody.count('#26 (failed local commit result)') == 1
body = oldbody.replace('#26 (failed local commit result)', '#26 (failed Git comparisons and no-code change classification)')
bodyfile.write_text(body)
draftfile = root / 'experiments/issue-1580/upstream/php-push-integrity-report.md'
draft = draftfile.read_text()
assert draft.count('#26 (failed local commit result)') == 1
draftfile.write_text(draft.replace('#26 (failed local commit result)', '#26 (failed Git comparisons and no-code change classification)'))
preflight['previousDraftBodySha256'] = preflight['bodySha256']
preflight['bodySha256'] = hashlib.sha256(body.encode()).hexdigest()
preflight['duplicateReferenceCorrection'] = '#26 concerns failed Git comparisons and no-code change classification; its title was literally reviewed from the fresh issue list.'
(base / 'preflight.json').write_text(json.dumps(preflight, indent=2) + '\n')
urlfile = base / 'url.txt'
assert not urlfile.exists(), 'Report URL already retained; do not publish twice'
print(body, flush=True)
url = subprocess.check_output(['gh', 'issue', 'create', '--repo', 'link-foundation/php-ai-driven-development-pipeline-template', '--title', 'Release CLI reports success after a rejected branch or tag push', '--body-file', str(bodyfile)], cwd=root, text=True).strip()
urlfile.write_text(url + '\n')
number = url.rsplit('/', 1)[-1]
raw = subprocess.check_output(['gh', 'api', 'repos/link-foundation/php-ai-driven-development-pipeline-template/issues/' + number], cwd=root)
(base / 'posted-issue.json.gz').write_bytes(gzip.compress(raw, mtime=0))
issue = json.loads(raw)
assert issue['body'] == body and issue['html_url'] == url
(base / 'receipt.json').write_text(json.dumps({'url': url, 'observedAt': datetime.now(timezone.utc).isoformat(), 'bodySha256': preflight['bodySha256'], 'postedIssueSha256': hashlib.sha256(raw).hexdigest(), 'publishedEvidenceHead': preflight['publishedEvidenceHead'], 'upstreamRepaired': False, 'independentAuthorshipCredit': 0}, indent=2) + '\n')
print(json.dumps({'url': url, 'verifiedPostedBody': True, 'bodySha256': preflight['bodySha256']}), flush=True)
