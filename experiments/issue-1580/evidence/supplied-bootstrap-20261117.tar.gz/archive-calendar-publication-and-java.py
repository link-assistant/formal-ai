from pathlib import Path
import gzip,hashlib,json
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research/calendar-admission-publication');report=json.loads((scratch/'outcome.json').read_text());assert report['complete'] and report['pushExecuted'];base=root/'experiments/issue-1580/evidence/checks/calendar-dispatch-registration/previous-publication';base.mkdir(exist_ok=False);records=[]
for row in report['records']:
 item=dict(row)
 for stream in ['stdout','stderr']:
  raw=(scratch/(row['name']+'.'+stream)).read_bytes();assert hashlib.sha256(raw).hexdigest()==row[stream+'Sha256'];packed=gzip.compress(raw,mtime=0);filename=row['name']+'.'+stream+'.gz';(base/filename).write_bytes(packed);item[stream]={'file':filename,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest(),'bytes':len(raw),'lines':len(raw.splitlines())}
 records.append(item)
(base/'records.json').write_text(json.dumps(records,indent=2)+'\n');(base/'outcome.json').write_text(json.dumps({k:v for k,v in report.items() if k!='records'},indent=2)+'\n');print('Archived previous publication',len(records),'records',len(records)*2,'verified payloads')
directory=root/'docs/case-studies/issue-1580/templates';p=directory/'java-historical-review-index.json';index=json.loads(p.read_text());previous=dict(index['cumulativeSummary']);assert previous['literalPages']==134 and previous['literalLines']==8415
summary=dict(previous,literalPages=136,literalLines=8521,completeFiles=118,partialFiles=1,nextForwardPage=137,remainingPages=118)
changes=[{'path':'dev/log/issues/24/pulls/25/sources/node.json','newReadRange':[837,884],'cumulativeReadRange':[1,884],'totalLines':884,'completeSourceRead':True}]
for name in ['osv-build-issues.json','osv-extractor-code.json','osv-plugin-dependency-issues.json','osv-plugin-issues.json','osv-test-scope-issues.json','plexus-scope-issue.json']:
 changes.append({'path':'dev/log/issues/24/pulls/25/sources/'+name,'cumulativeReadRange':[1,1],'totalLines':1,'completeSourceRead':True})
changes.append({'path':'dev/log/issues/24/pulls/25/sources/pom-original-main.xml','cumulativeReadRange':[1,52],'completeSourceRead':False})
part={'previousIndexSummary':previous,'pagesFullyRead':[135,136],'filesChangedSincePrevious':changes,'cumulativeSummary':summary,'observations':['Both pages were literally read without truncation. Node history is complete through v0.1.14. Five historical OSV issue/code-search records and the complete Plexus duplicate-scope issue with its comments are now read. The latter records a failure caused by Singleton and MojoExecutionScoped on DefaultProgress; these historical upstream claims are not proof of current release behavior. The original-main POM is partial through line 52. Pages 137–254 remain unfinished; supplied review earns zero independent authorship credit.']}
partpath=directory/'java-historical-forward-review-016.json';assert not partpath.exists();partpath.write_text(json.dumps(part,indent=2)+'\n');index['forwardParts'].append({'file':partpath.name,'sha256':hashlib.sha256(partpath.read_bytes()).hexdigest(),'pages':[135,136]});index['cumulativeSummary']=summary;p.write_text(json.dumps(index,indent=2)+'\n')
pages=root/'experiments/issue-1580/evidence/checks/calendar-dispatch-registration/java-history-135-136';pages.mkdir(exist_ok=False);rows=[]
for number in [135,136]:
 packed=(Path('/tmp/issue-1580-research/java-history-pages')/f'page-{number:03}.log.gz').read_bytes();raw=gzip.decompress(packed);filename=f'page-{number:03}.log.gz';(pages/filename).write_bytes(packed);rows.append({'page':number,'file':filename,'fullLiteralRead':True,'rawSha256':hashlib.sha256(raw).hexdigest(),'archiveSha256':hashlib.sha256(packed).hexdigest()})
(pages/'review-summary.json').write_text(json.dumps({'cumulativeSummary':summary,'pages':rows,'independentAuthorshipCredit':0},indent=2)+'\n');print(json.dumps(summary))
