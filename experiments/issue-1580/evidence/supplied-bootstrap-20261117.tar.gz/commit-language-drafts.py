from pathlib import Path
import subprocess,json,hashlib
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='7f19154a21d79f268f48af6b0938f17e6fb32ba3'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],text=True).strip()
base=Path('/tmp/issue-1580-research/language-source-commits');base.mkdir(exist_ok=False)
p=Path('experiments/issue-1580/evidence/checks/browser-meaning-hydration/README.md')
p.write_text('''The valid pre-fix reproduction is `before-normalized`: seven passes and three failures. `before` also contains an initial hyphen/space expectation mistake and is retained as a first draft, not additional production evidence. `after` passes all ten tests. All nine adjacent checks pass. The first foreground adjacent batch hit the shell tool's 60-second limit; only its unfinished specification gate resumed, without repeating the eight completed checks. Browser captures use the real production Worker in diagnostic JS mode, with all external requests blocked; the labeled harness is not production app UI or native/WASM verification. Full observations, screenshots, receipts and bounded server logs are retained. Independent authorship credit: zero. See the language-source-binding checkpoint for exact scopes and pending native/main integration.\n''')
p=Path('experiments/issue-1580/evidence/checks/native-unparsed-source-binding/README.md')
p.write_text('''The initial local static-check batch retains all eight results, including failures in Rust formatting, the exact workflow execution-policy assertion and four Cargo fixture identity references. These are corrected in later checks; no local native execution is claimed. The four captured-source library tests ultimately live in `rust/tests/unit/solver_unknown_reasoning_captured_sources.rs` to keep test literals outside production source. An earlier `rust/src/solver_unknown_reasoning_tests.rs` placement correctly failed the prompt-specialization gate; no ceiling or source-exemption rule is relaxed. The reviewed pre-merge witness delta preserves all complete objects after only four references to one Cargo source hash change. The subsequently advanced default branch and next-head hosted execution still require separate verification. Supplied code earns zero independent authorship credit.\n''')
steps=[('browser','Fix registered meaning seed hydration and invalidate derived search markers',[
 'js/worker/formal_ai_worker_seed_responses_and_language.js','rust/tests/web/worker-unknown-language.test.mjs','experiments/issue-1580/browser-meaning-server.py','experiments/issue-1580/meaning-hydration-browser.html','experiments/issue-1580/capture-meaning-hydration-browser.js','experiments/issue-1580/evidence/checks/browser-meaning-hydration','docs/screenshots/issue-1580/meaning-hydration-before.png','docs/screenshots/issue-1580/meaning-hydration-after.png','changelog.d/issue-1580-meaning-seed-hydration.md']),
 ('native','Preserve unresolved unsupported-language questions when retrieving word glosses',[
 'rust/src/solver_unknown_reasoning.rs','rust/tests/unit/solver_unknown_reasoning_captured_sources.rs','rust/Cargo.toml','.github/workflows/native-type-check.yml','scripts/ci-pull-request-admission.mjs','rust/tests/web/default-branch-build-policy.test.mjs','changelog.d/issue-1580-unparsed-source-binding.md','experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8','experiments/issue-1580/evidence/checks/native-unparsed-source-binding'])]
records=[]
for name,message,paths in steps:
 subprocess.run(['git','add','--',*paths],check=True)
 staged=subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines()
 assert staged and all(any(file==allowed or file.startswith(allowed+'/') for allowed in paths) for file in staged)
 subprocess.run(['git','diff','--cached','--check'],check=True)
 with (base/(name+'.log')).open('wb') as stream:r=subprocess.run(['git','-c','gc.auto=0','commit','-m',message],stdout=stream,stderr=subprocess.STDOUT)
 assert r.returncode==0,(base/(name+'.log')).read_text()
 row={'step':name,'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':len(staged),'message':message,'pushExecuted':False};records.append(row);print(json.dumps(row))
(base/'results.json').write_text(json.dumps(records,indent=2)+'\n')
print('REMAINING',subprocess.check_output(['git','status','--short'],text=True))
