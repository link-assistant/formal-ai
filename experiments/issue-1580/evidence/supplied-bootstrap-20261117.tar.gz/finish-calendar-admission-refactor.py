from pathlib import Path
import json,os,re,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');env=dict(os.environ);env['PATH']='/home/box/.local/bin:'+env['PATH']
result=subprocess.run(['node','--max-old-space-size=256','scripts/translate-es.mjs','js/worker/formal_ai_worker_calendar_and_proofs.js'],cwd=root,env=env,capture_output=True,check=True)
(root/'ts/worker/formal_ai_worker_calendar_and_proofs.ts').write_bytes(result.stdout)
count=len((root/'rust/src/solver_handlers/calendar_create.rs').read_text().splitlines());delta=count-671;assert delta<0,(count,delta)
p=root/'data/meta/core-boundary-ledger.lino';s=p.read_text();pattern=r'(path "rust/src/solver_handlers/calendar_create.rs"\n(?:[^\n]*\n)*?\s+baseline_lines )671\b';s,n=re.subn(pattern,lambda m:m[1]+str(count),s);assert n==1,n
for key,old in [('source_lines_max',36517),('outside_core_lines_max',18854)]:
 oldline=f'  {key} {old}\n';assert s.count(oldline)==1;s=s.replace(oldline,f'  {key} {old+delta}\n')
mark='  source_lines_max ';at=s.index(mark);line=s.rfind('\n',0,at)+1
s=s[:line]+f'  note "Issue #1580 removes duplicate calendar admission checks and shares calendar anchor role matching. The calendar-create source falls from 671 to {count} lines while retaining sentence-local scheduling controls; both measured line ceilings fall by {-delta}."\n'+s[line:];p.write_text(s)
print(json.dumps({'rustLines':count,'rustDeltaFromReviewedBaseline':delta,'workerLines':len((root/'js/worker/formal_ai_worker_calendar_and_proofs.js').read_text().splitlines()),'workerCeilingUnchanged':1146}))
