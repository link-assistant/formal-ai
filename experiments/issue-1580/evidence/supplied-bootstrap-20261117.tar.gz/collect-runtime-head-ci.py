from pathlib import Path
source=Path('/tmp/issue-1580-research/collect-python-fragment-head-ci.py').read_text()
source=source.replace('624812120feee0180bf9df8164f87e73326b5cb8','e120c05b4d8e35d51e4c1efb95e9b0c46c8d42b5').replace('ci/624812120','ci/e120c05b4')
exec(compile(source,__file__,'exec'))
