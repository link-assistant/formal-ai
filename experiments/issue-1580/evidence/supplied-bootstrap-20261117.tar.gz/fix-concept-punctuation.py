from pathlib import Path
p=Path('rust/src/concepts.rs')
s=p.read_text(); old="['?', '。', '.', '!', '!', ',', ',', ';', ':']"
assert s.count(old)==2
p.write_text(s.replace(old,"['?', '？', '。', '.', '!', '！', ',', '，', ';', '；', ':', '：']"))
p=Path('rust/tests/unit/concept_lookup_response_language.rs')
p.write_text(p.read_text()+'''
#[test]
fn concept_query_trims_ascii_and_full_width_terminal_punctuation() {
    for punctuation in ["?", "？", "!", "！", "。", ",", "，", ";", "；", ":", "："] {
        let prompt = format!("Redis是什么{punctuation}");
        let query = formal_ai::concepts::extract_concept_query(&prompt)
            .unwrap_or_else(|| panic!("definition query: {prompt}"));
        assert_eq!(query.term, "redis", "{prompt}");
    }
    let query = formal_ai::concepts::extract_concept_query("What is foo.bar?").unwrap();
    assert_eq!(query.term, "foo.bar", "internal punctuation is part of the subject");
}
''')
p=Path('rust/tests/web/issue-1580-production-composition.test.mjs')
s=p.read_text().replace('let executor;', 'let executor;\nconst host = new WorkerHost();').replace('installNodeHost(new WorkerHost())','installNodeHost(host)')
p.write_text(s+'''
test('concept queries trim terminal punctuation and preserve punctuation inside the subject', async () => {
  for (const punctuation of ['?', '？', '!', '！', '。', ',', '，', ';', '；', ':', '：']) {
    const prompt = `Redis是什么${punctuation}`;
    const query = await host.run('extractConceptQuery(__conceptPrompt)', { __conceptPrompt: prompt });
    assert.equal(query.term, 'redis', prompt);
  }
  const query = await host.run('extractConceptQuery("What is foo.bar?")');
  assert.equal(query.term, 'foo.bar');
});
''')
