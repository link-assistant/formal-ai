set -eu
set +e
timeout 600 node --test --test-concurrency=1 rust/tests/web/issue-1580-template-observations.test.mjs > /tmp/issue-1580-research/java-release-checks/maintained.log 2>&1
result=$?
set -e
tail -n 30 /tmp/issue-1580-research/java-release-checks/maintained.log
exit "$result"
