from pathlib import Path
source=Path('/tmp/issue-1580-research/implement-python-runtime-provisioning.py').read_text()
source=source[source.index("p=Path('.github/workflows/layered-ci.yml')"):]
source=source.replace('      - name: Run the focused mapped tests first','      - name: Run the focused tests for the changed components first')
exec(compile(source,'remaining-runtime-provisioning','exec'))
