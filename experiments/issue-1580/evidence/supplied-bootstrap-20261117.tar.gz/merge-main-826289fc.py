import subprocess, json
from pathlib import Path

assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
result=subprocess.run(['git','merge','--no-commit','--no-ff','826289fc78154dcd894199ed966f366176be0afb'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
path=Path('/tmp/issue-1580-research/main-826289fc-merge.log');path.write_bytes(result.stdout)
print(result.stdout.decode())
print('MERGE_EXIT',result.returncode)
unmerged=subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],text=True).splitlines()
print('CONFLICTS',json.dumps(unmerged))
for name in unmerged:
    lines=Path(name).read_text().splitlines()
    print('FILE',name,'LINES',len(lines))
    markers=[i for i,line in enumerate(lines) if line.startswith(('<<<<<<<','=======','>>>>>>>'))]
    selected=set()
    for index in markers:selected.update(range(max(0,index-4),min(len(lines),index+6)))
    for index in sorted(selected):print(f'{index+1}: {lines[index]}')
