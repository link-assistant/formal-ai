from pathlib import Path
import gzip,hashlib,json,subprocess
base=Path('experiments/issue-1580/evidence/checks/main-merge-444575f2')
commands=[['node','--max-old-space-size=256','scripts/mirror-package-data.mjs','--check'], ['rustfmt','--edition','2024','rust/src/structured_log.rs','rust/tests/source/source_tests/structured_log/tests.rs','rust/src/agentic_coding/tool_result/source_observation.rs']]
for index,command in enumerate(commands):
    result=subprocess.run(command,capture_output=True)
    data=result.stdout+result.stderr
    target=base/('startup-preparation-final-'+str(index)+'.log.gz');target.write_bytes(gzip.compress(data,mtime=0))
    print(json.dumps({'command':command,'exitCode':result.returncode,'output':data.decode(),'sha256':hashlib.sha256(data).hexdigest()}))
    assert result.returncode==0
print(subprocess.check_output(['git','diff','--stat'],text=True))
print(subprocess.check_output(['git','diff','--','rust/src/structured_log.rs','rust/tests/source/source_tests/structured_log/tests.rs','data/seed/client-integrations.lino','rust/tests/web/issue-1168-workflow-render-parity.test.mjs','rust/tests/web/issue-1168-source-cache.test.mjs','rust/src/agentic_coding/tool_result/source_observation.rs'],text=True))
