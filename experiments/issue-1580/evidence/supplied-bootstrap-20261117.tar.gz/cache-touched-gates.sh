set -eu
node experiments/formal_ai_subagent/local-gates.mjs --list > /tmp/issue-1580-research/current-gate-list.txt
rg -n 'shell|sccache|workflow|release-protocol|staged' /tmp/issue-1580-research/current-gate-list.txt
git diff -- scripts/check-sccache-write-health.sh .github/actions/setup-sccache/action.yml rust/tests/web/sccache-outage-fallback.test.mjs
