from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048');p=root/'rust/tests/web/default-branch-build-policy.test.mjs';s=p.read_text();assert 'unchanged shell and download contracts' not in s
s+='''
test('the unchanged shell and download contracts execute in the focused native lane', () => {
  const step = workflow('native-type-check.yml').jobs.check.steps.find(step => step.name === 'Verify isolated native behavior regressions');
  assert.match(step.run, /--test operational_contracts(?: |$)/u);
  const manifest = read('rust/Cargo.toml');
  assert.match(manifest, /name = "operational_contracts"\\npath = "tests\\/unit\\/operational_contracts[.]rs"/u);
  const source = read('rust/tests/unit/operational_contracts.rs');
  assert.match(source, /#\\[path = "docs_requirements\\/agent_cli_shell[.]rs"\\]/u);
  assert.match(source, /#\\[path = "ci-cd\\/network_download_retry[.]rs"\\]/u);
  for (const path of ['rust/tests/unit/operational_contracts.rs', 'rust/tests/unit/docs_requirements/agent_cli_shell.rs',
    'rust/tests/unit/ci-cd/network_download_retry.rs', 'README.md', 'docs/desktop/server-api.md',
    'scripts/install.sh', 'experiments/agentic_cli_matrix/install_client.sh', 'new-download-script.sh'])
    assert.equal(admission([path])['native-type-check'], true, path);
  for (const path of ['docs/unrelated.md', 'experiments/unrelated.mjs'])
    assert.equal(admission([path])['native-type-check'], false, path);
});
''';p.write_text(s);print('Added a policy regression for replaying both existing operational contract modules and their consumed inputs.')
