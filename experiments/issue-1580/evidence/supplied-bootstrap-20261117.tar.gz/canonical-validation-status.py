from pathlib import Path
import json,re,subprocess
p=Path('/tmp/issue-1580-research/canonical-data-validation-reviewed')
for f in ['outcome.json','failure.json']:
 if (p/f).exists():print(f,(p/f).read_text())
text=(p/'all-local-gates.log').read_text();print('GATES',len(re.findall(r'^(?:PASS|FAIL|SKIP) ',text,re.M)));print('\n'.join(text.splitlines()[-5:]))
print('MEMORY',Path('/sys/fs/cgroup/memory.current').read_text().strip())
print(subprocess.run(['ps','-eo','pid,ppid,rss,etime,comm','--sort=-rss'],capture_output=True,text=True).stdout.splitlines()[:7])
