import gzip
import hashlib
import json
import pathlib
base=pathlib.Path('experiments/issue-1580/evidence/checks/corpus-shard-three-investigation')
p=base/'inventory.json'
raw=p.read_bytes()
inventory=json.loads(raw)
(base/'inventory.json.gz').write_bytes(gzip.compress(raw,mtime=0))
receipt={'inputCount':inventory['inputCount'],'selectedCount':inventory['selectedCount'],'shard':inventory['shard'],'selectionOnly':True,'rawSha256':hashlib.sha256(raw).hexdigest(),'rawBytes':len(raw),'nativeExecuted':False,'reviewedPromptCount':0}
(base/'summary.json').write_text(json.dumps(receipt,indent=2)+'\n')
p.unlink()
print(json.dumps(receipt))
