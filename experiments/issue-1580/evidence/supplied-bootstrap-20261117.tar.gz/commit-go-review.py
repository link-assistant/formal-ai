from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd();checks=root/'experiments/issue-1580/evidence/checks'
raw=Path('/tmp/issue-1580-research/go-review-gates.log').read_bytes();payload=gzip.compress(raw,mtime=0)
destination=checks/'go-review-gates.log.gz';destination.write_bytes(payload)
p=checks/'go-pin-integrity.json';data=json.loads(p.read_text());data['touchedGates']={'passed':4,'skipped':0,'failed':0,'file':str(destination.relative_to(root)),'sha256':hashlib.sha256(payload).hexdigest(),'originalSha256':hashlib.sha256(raw).hexdigest()};p.write_text(json.dumps(data,indent=2)+'\n')
paths=['docs/case-studies/issue-1580/templates/go-semantic-review.json','docs/case-studies/issue-1580/templates/README.md','docs/case-studies/issue-1580/README.md','experiments/issue-1580/work-plan.md','changelog.d/20261117_120000_issue-1580-ci-regressions.md','experiments/issue-1580/template-go-result-integrity.test.mjs','experiments/issue-1580/fixtures/go-template/source.json','experiments/issue-1580/fixtures/go-template/scripts/ci/check-dependencies.mjs','experiments/issue-1580/upstream/go-stale-pin-integrity-report.md','experiments/issue-1580/evidence/checks/go-pin-integrity.json','experiments/issue-1580/evidence/checks/go-pin-integrity.log.gz','experiments/issue-1580/evidence/checks/template-observations-seventh.log.gz','experiments/issue-1580/evidence/checks/go-review-gates.log.gz']
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','-f','--',*paths],check=True)
subprocess.run(['git','commit','-m','test: review Go pipeline sources and reproduce stale-pin integrity bypass'],check=True)
