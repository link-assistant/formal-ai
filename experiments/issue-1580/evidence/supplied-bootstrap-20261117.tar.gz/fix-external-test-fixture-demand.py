import datetime
import gzip
import hashlib
import json
import pathlib
import subprocess

root=pathlib.Path.cwd()
base=root/'experiments/issue-1580/evidence/checks/external-opencode-test'
detail=root/'experiments/formal_ai_subagent/sandboxes/gates/check-package-self-containment.log'
(base/'package-mirror-failure-detail.log.gz').write_bytes(gzip.compress(detail.read_bytes()))
test=root/'rust/tests/source/source_tests/agentic_coding/tool_result/source_observation/opencode_tests.rs'
text=test.read_text()
old='../../../../../../embedded/data/parity/issue-1580-opencode-read-envelope.json'
new='../../../../../../../data/parity/issue-1580-opencode-read-envelope.json'
assert text.count(old)==1
canonical=root/'data/parity/issue-1580-opencode-read-envelope.json'
assert (test.parent/new).resolve()==canonical
assert (test.parent/old).read_bytes()==canonical.read_bytes()
test.write_text(text.replace(old,new))
for label,command in [('mirror-write',['node','--max-old-space-size=256','scripts/mirror-package-data.mjs','--write']),('native-registry-check',['node','--max-old-space-size=256','scripts/lib/generate-native-specification-programs.mjs','--check'])]:
    log=root/f'/tmp/issue-1580-research/external-fixture-{label}.log'
    with log.open('w') as stream:
        result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
    raw=log.read_bytes()
    (base/f'{label}.log.gz').write_bytes(gzip.compress(raw))
    print(json.dumps({'command':command,'exitCode':result.returncode,'log':str(log),'sha256':hashlib.sha256(raw).hexdigest()}))
    print(raw.decode())
print(subprocess.run(['git','status','--short'],capture_output=True,text=True).stdout)
