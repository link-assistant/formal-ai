import pathlib,subprocess,sys
group=sys.argv[1]
files={
 'policy':['.github/workflows/native-type-check.yml','rust/tests/web/default-branch-build-policy.test.mjs'],
 'reader':['scripts/check-generated-files.mjs','rust/tests/web/generated-files.test.mjs'],
 'inventory':['data/benchmarks/fast-pull-request-javascript-tests.json'],
}[group]
for name in files:
    p=pathlib.Path(name);lines=p.read_text().splitlines();print(f'FILE {name} ({len(lines)} lines)')
    selected=set()
    for index,line in enumerate(lines):
        if line.startswith('<<<<<<<'):
            end=next(n for n in range(index+1,len(lines)) if lines[n].startswith('>>>>>>>'))
            selected.update(range(max(0,index-6),min(len(lines),end+7)))
    for index in sorted(selected):print(f'{index+1}: {lines[index]}')
