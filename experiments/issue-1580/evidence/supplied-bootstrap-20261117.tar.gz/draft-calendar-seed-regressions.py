from pathlib import Path

path=Path('rust/tests/web/issue-1589-calendar-currency.test.mjs')
text=path.read_text()
assert 'calendar meanings stay globally unique' not in text
text=text.replace('readFileSync, mkdtempSync, rmSync','readFileSync, readdirSync, mkdtempSync, rmSync')
text += '''
// Replays main run 44188508650: calendar-duration-sum was defined as both
// a handler cue and a response intent; alias strings also used in-band pipes.
function duplicateMeaningSlugs(documents) {
  const owners = new Map();
  for (const [name, content] of documents) {
    content.split('\\n').forEach((line, index) => {
      const header = /^ {2}([^\\s#]+)(?:\\s+#.*)?$/u.exec(line.trimEnd());
      if (!header || header[1] === 'meanings') return;
      const locations = owners.get(header[1]) || [];
      locations.push(`${name}:${index + 1}`);
      owners.set(header[1], locations);
    });
  }
  return [...owners].filter(([, locations]) => locations.length > 1);
}

test('calendar meanings stay globally unique across all seed meaning documents', () => {
  const seed = new URL('../../../data/seed/', import.meta.url);
  const documents = readdirSync(seed, {recursive:true})
    .filter(name => /(?:^|\\/)meanings[^/]*\\.lino$/u.test(name))
    .map(name => [name, readFileSync(new URL(name, seed), 'utf8')]);
  assert.ok(documents.length > 0, 'seed meaning documents were inspected');
  assert.deepEqual(duplicateMeaningSlugs(documents), []);
});

test('meaning uniqueness replay detects duplicates within and across documents', () => {
  const first = 'meanings\\n  same\\n    defined-by time\\n  distinct\\n';
  assert.deepEqual(duplicateMeaningSlugs([['first', first]]), []);
  assert.deepEqual(duplicateMeaningSlugs([['first', first + '  same\\n']]),
    [['same', ['first:2', 'first:5']]]);
  assert.deepEqual(duplicateMeaningSlugs([['first', first], ['second', 'meanings\\n  same # second definition\\n']]),
    [['same', ['first:2', 'second:2']]]);
});

test('handler table rows carry one surface each without pipe-packed aliases', () => {
  const tables = evaluate(worker, 'handlerRulesTables()');
  const packed = Object.entries(tables).flatMap(([name, table]) =>
    table.rows.filter(([, value]) => value.includes('|')).map(row => ({name, row})));
  assert.deepEqual(packed, []);
});
'''
path.write_text(text)
print('Added three narrow JavaScript regressions; production sources unchanged.')
