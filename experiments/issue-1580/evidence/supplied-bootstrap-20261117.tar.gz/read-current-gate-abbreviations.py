from pathlib import Path
print(Path('experiments/formal_ai_subagent/sandboxes/gates/check-abbreviations.log').read_text())
