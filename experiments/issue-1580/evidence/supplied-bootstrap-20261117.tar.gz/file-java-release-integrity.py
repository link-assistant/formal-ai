from pathlib import Path
import json
import subprocess

def output(args):
 return subprocess.check_output(args,text=True).strip()

evidence='ff5d883b15aeda06c07e509a73a0a436f10799b7'
repo='link-foundation/java-ai-driven-development-pipeline-template'
title='CI: failed release commits still publish tags on the previous version'
outdir=Path('/tmp/issue-1580-research/java-release-report')
outdir.mkdir(exist_ok=True)
result=outdir/'filed.json'
assert not result.exists(), 'a filed identity already exists; do not create a duplicate'
assert output(['gh','api','repos/link-assistant/formal-ai/commits/'+evidence,'--jq','.sha'])==evidence
assert output(['gh','api','repos/'+repo+'/commits/main','--jq','.sha'])=='dd803a2d9fa5b3a992b435acce73162274fb9e8b'
issues=json.loads(output(['gh','api','repos/'+repo+'/issues?state=all&per_page=100','--paginate']))
assert not any(x['title']==title for x in issues)
(outdir/'preflight-issues.json').write_text(json.dumps(issues,indent=2)+'\n')
body=Path('experiments/issue-1580/upstream/java-release-commit-integrity-report.md').read_text()
pending=' Filing remains pending until this commit is published.'
assert body.count(pending)==1
body=body.replace(pending,'')
bodyfile=outdir/'posted-body.md'
bodyfile.write_text(body)
url=output(['gh','issue','create','--repo',repo,'--title',title,'--body-file',str(bodyfile)])
assert url.startswith('https://github.com/'+repo+'/issues/')
identity={'repository':repo,'title':title,'url':url,'bodyFile':'java-release-commit-integrity-report.md','evidenceCommit':evidence}
result.write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps(identity,indent=2))
