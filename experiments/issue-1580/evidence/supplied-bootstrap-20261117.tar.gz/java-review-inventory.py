from pathlib import Path
import json,hashlib
base=Path('/tmp/issue-1580-research/templates');language='java'
inventory=json.loads((base/(language+'-complete-inventory.json')).read_text());folder=base/(language+'-complete')
totals={}; records=[]
for row in inventory:
 raw=(folder/row['path']).read_bytes();assert hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest()==row['gitBlob']
 lines=len(raw.splitlines());prefix=row['path'].split('/')[0];totals[prefix]=totals.get(prefix,0)+lines
 if row['path'].startswith(('.github/','scripts/')) or '/' not in row['path']:
  records.append({'path':row['path'],'lines':lines,'bytes':len(raw)})
print(json.dumps({'files':len(inventory),'totalLinesByTopLevel':totals,'ciAndRootFiles':records},indent=2))
