from pathlib import Path
import json

base = Path('experiments/issue-1580/evidence/checks/algebra-calculation-cues')
assert json.loads((base / 'validation/results.json').read_text())['complete']
checkpoint = Path('docs/case-studies/issue-1580/algebra-calculation-cue-checkpoint.md')
checkpoint.write_text('''# Algebra calculation-cue checkpoint

This unfinished checkpoint belongs to [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581).
The complete issue remains open.

## Reproduction and root causes

The retained main `015a6831` specification log reports algebra substitution
failures for the original result 11, the renumbered result 17 and the shared
fixture result 17. Source-operand evaluation must not require separately solved
assignment fragments to be answered. The existing parent-validation correction
already distinguishes source operands from consumed child answers, but its real
native algebra path still needs hosted execution.

The retained native baseline also fails `If x = 3 and y = 4, what is x*x + 2*y?`.
Replaying that request through the current JavaScript WorkerHost reproduces a
second defect: specialized algebra extractors recognize evaluation commands and
"value of" while omitting existing calculation-question cues. The focused new
file records six passes and two failures before the change. Both the original
question and its renumbered x=4, y=6 variant return `calculation_error`.

## Change and local evidence

Reuse the existing arithmetic-expression parser as the algebra extractor's
fallback in JavaScript and the explicit calculation-candidate parser in Rust.
Preserve all existing marker paths. Variable binding, substitution and actual
evaluation remain necessary; unsupported prose and unbound variables cannot
claim algebra substitution. Regenerate the TypeScript mirror with the maintained
writer. The worker retains its existing 786-line ceiling.

All eight new WorkerHost cases pass: four positive evaluations and four negative
controls for missing assignments, unbound variables, unrelated prose and bare
assignments. All 12 adjacent calculation-shape cases and 25 executor cases pass.
Rust 2024 formatting, whitespace and six affected generated/translation/size/
budget/abbreviation gates pass. Preserve complete before/after payloads, hashes
and individual gate logs under
`experiments/issue-1580/evidence/checks/algebra-calculation-cues/`.

Register the new JavaScript file in the existing fast PR inventory and record
the main-only algebra regression in its ledger. Append a real UniversalSolver
test to the existing isolated native executor target. It checks all five
original and renumbered requests, exact numeric answers, substitution/evaluation
evidence, child observations and emitted Links Notation. No new native target
or local Rust build is introduced.

## Remaining verification

The shared-data inventory run and hosted native execution remain pending.
JavaScript success does not establish the Rust solver's result. This change
does not complete the other synthesis, parent-coverage, provenance, benchmark,
template, dependency or delivery requirements. Supplied patches, scripts,
commands and conclusions receive zero independent authorship credit;
independent acceptance remains 0/20 and the PR stays draft and unmerged.
''')

fragment = Path('changelog.d/20261117_120000_issue-1580-ci-regressions.md')
text = fragment.read_text()
text += '- Reuse existing calculation-question parsing for algebra substitution and replay original and renumbered source-operand compositions before merge.\n'
fragment.write_text(text)

plan = Path('experiments/issue-1580/work-plan.md')
text = plan.read_text()
text += '''
## Algebra source operands and calculation cues (2026-11-18)

- [x] Read the retained main algebra panic windows and full native baseline;
  trace both runtime extractors and existing arithmetic parsers.
- [x] Reproduce the current JavaScript "what is" defect before the change:
  six controls pass and two bound-assignment questions fail with calculation_error.
- [x] Reuse existing calculation parsers in both runtimes; pass all eight new
  WorkerHost cases, 12 calculation-shape cases, 25 executor cases, maintained
  TypeScript generation, Rust formatting and six affected local gates.
- [x] Register the JavaScript regression in the fast PR inventory and main-only
  ledger, and add five real UniversalSolver cases to the existing hosted target.
- [ ] Verify the ledger/inventory controls and complete shared-data gate run.
- [ ] Publish after the single-push gate and verify actual hosted execution of
  the five native algebra cases. Preserve failures separately from corrections.
- [ ] Complete every earlier unfinished acceptance criterion. Independent
  acceptance remains 0/20; keep PR #1581 draft and unmerged.
'''
plan.write_text(text)

body = Path('experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md')
text = body.read_text()
marker = 'Changes:\n\n'
assert text.count(marker) == 1
text = text.replace(marker, marker + '- Reuse existing calculation-question parsing for algebra substitution in JavaScript and Rust. Reproduce two current "what is" failures, add four negative controls and five real native solver cases, and register the JavaScript check in the fast PR inventory and main-only regression ledger. Native algebra execution remains pending.\n', 1)
marker = 'Latest reproduction and verification:\n\n'
assert text.count(marker) == 1
text = text.replace(marker, marker + '- Algebra: `If x = 3 and y = 4, what is x*x + 2*y?` and its renumbered variant return `calculation_error` before the parser fallback: **6 passes / 2 failures before, 8/8 afterward**. All **12 adjacent calculation-shape and 25 executor tests**, maintained TypeScript generation, Rust formatting, whitespace and six affected gates pass. The original and renumbered main result-11/result-17 source-operand paths are covered by five new real UniversalSolver cases in the existing hosted target; actual native execution and the shared-data inventory run remain pending. Complete payloads and digests are retained in the [algebra checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/algebra-calculation-cue-checkpoint.md).\n', 1)
body.write_text(text)
print(json.dumps({'checkpoint': str(checkpoint), 'independentAuthorshipCredit': 0, 'nativeVerified': False}))
