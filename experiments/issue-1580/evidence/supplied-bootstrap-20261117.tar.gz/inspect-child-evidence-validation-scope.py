from pathlib import Path
import json, subprocess

root=Path.cwd()
for name in ['/sys/fs/cgroup/memory.current','/sys/fs/cgroup/memory.max','/sys/fs/cgroup/memory.events']:
    print(name,Path(name).read_text().strip())
result=subprocess.run(['node','--max-old-space-size=256','experiments/formal_ai_subagent/local-gates.mjs','--list'],capture_output=True,text=True)
Path('/tmp/issue-1580-research/child-evidence-local-gate-inventory.txt').write_text(result.stdout+result.stderr)
print(result.stdout)
print(result.stderr)
assert result.returncode==0
