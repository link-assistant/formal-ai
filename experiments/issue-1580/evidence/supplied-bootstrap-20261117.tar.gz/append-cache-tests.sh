set -eu
cat /tmp/issue-1580-research/cache-reporting-tests.mjs >> rust/tests/web/sccache-outage-fallback.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/sccache-outage-fallback.test.mjs > /tmp/issue-1580-research/cache-write-regression.log 2>&1
timeout 600 node --test --test-concurrency=1 rust/tests/web/worker-candidate-validation.test.mjs > /tmp/issue-1580-research/prime-validation-recheck.log 2>&1
node experiments/formal_ai_subagent/local-gates.mjs --only check-language-test-coverage > /tmp/issue-1580-research/language-coverage-recheck.log 2>&1
/tmp/issue-1580-research/shellcheck-v0.11.0/shellcheck scripts/check-sccache-write-health.sh
git diff --check
