from pathlib import Path
import gzip,hashlib,json,subprocess
directory=Path('experiments/issue-1580/evidence/checks/audit-inventory-boundary')
for path in Path('/tmp/issue-1580-research/python-audit').glob('*.json'):
 (directory/(path.name+'.gz')).write_bytes(gzip.compress(path.read_bytes(),mtime=0))
logs=[]
for path in sorted(directory.glob('*.log.gz')):
 raw=gzip.decompress(path.read_bytes());logs.append({'file':path.name,'rawSha256':hashlib.sha256(raw).hexdigest(),'compressedSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':len(raw)})
own=Path('scripts/check-javascript-dependencies.sh').read_bytes()
record={'upstreamRepository':'link-foundation/python-ai-driven-development-pipeline-template','upstreamCommit':'c532c173801dfb12e681b0730c4abbf93aefd0ca','upstreamGitBlob':'e4c73c9df844a08e031b786cb8fdb891ce192789','upstreamSha256':'40bdae551f88431166778fa4f041a437afcf1ff73bf5b82fb59d5fe586b2a7a2','ownChangedSource':'scripts/check-javascript-dependencies.sh','ownChangedSha256':hashlib.sha256(own).hexdigest(),'logs':logs,'authorship':'Externally supplied bootstrap; zero independent Formal AI authorship. Frozen 20-unit reasoning audit remains 0/20 accepted.','limits':'No dependency installation, registry audit, Rust compilation, app build, Docker build or provider release performed. Upstream source is unchanged; suggested guard only executes in a disposable fixture. Report is drafted and not yet filed.'}
(directory/'evidence.json').write_text(json.dumps(record,indent=2)+'\n')
(directory/'README.md').write_text('''# Git lockfile inventory integrity

The unchanged complete Python template `audit-npm-locks.sh` treats failed or partial Git inventory as a successful empty/subset audit. Its disposable candidate fails before listing/auditing. Three executable cases cover both modes, true tracked/empty Git inventories, a space-containing path, an untracked lock, severity forwarding and advisory refusal. No real advisory registry is contacted.

Formal AI's own `check-javascript-dependencies.sh` had the same process-substitution boundary. New regressions fail against the prior implementation (8 pass/2 fail); the repair passes all 10 tests. It captures and checks one Git inventory before starting any audit. Git selects only lockfile names, avoiding the measured 49-second intermediate full-file Bash scan; final focused execution takes about six seconds. Existing retries, request bounds, thresholds and failure handling remain covered.

`python-before` disables the candidate guard: 2 pass/1 fail. `python-after` restores it: 3 pass. `maintained-final` executes the maintained entrypoint: 34 pass, no skips. Each child has a five-second wall deadline; Node heap is capped at 96 MiB. Complete logs and checksums, including the intermediate passing but slower implementation, are retained. Negative runs are expected regression evidence, not current verification failures.

The current upstream head and complete 157-item duplicate snapshot plus relevant PR #134/#152 and issue #132 comments are retained. The upstream report body is drafted in `upstream/python-audit-inventory-report.md`; no filed issue or upstream repair is claimed yet. Independent reasoning remains 0/20 accepted. All broader issue #1580 criteria remain active.
''')
paragraph='''
## Python review and audit inventory checkpoint

The Python source review covers 131 fully read active files and one partial file (8,864/44,284 active lines), through corrected pages 1-20 plus the separately read release helpers. Seventy-one active files, both generated bundles, both locks and all 126 historical blobs remain unread. Reading historical probes is not fresh execution. The same-second fragment overwrite remains reported at https://github.com/link-foundation/python-ai-driven-development-pipeline-template/issues/157.

All 24 workflows passed on `e120c05b4d8e35d51e4c1efb95e9b0c46c8d42b5`. Retained Layered CI run 44112040276 confirms Python 3.15.2 was provisioned only for the selected shard; log lines 4947-4952 show all four fragment cases and runtime regressions passing, and the shared Python Git observation passed as well. This replaces the prior head's five skips with actual hosted execution. The cached, digest-verified ShellCheck binary also passes the local shell gate; the initial missing-tool attempt remains retained.

The next repair addresses another real false-success boundary: failed/partial Git lockfile inventory in Formal AI's JavaScript dependency audit. New regressions fail before the change and all 10 pass afterward. The command captures one successful, lockfile-only inventory before starting any audit, retaining existing retry, threshold and advisory behavior. The complete pinned Python helper has the same defect; its unchanged entrypoint and disposable candidate pass three focused offline-control tests, and the maintained template entrypoint passes all 34 tests without skips. The distinct upstream report is drafted but not yet filed. See `experiments/issue-1580/evidence/checks/audit-inventory-boundary/` for complete negative/passing logs, source identities and limits. Hosted verification of this new audit repair is still required. No build-policy, benchmark-floor, native-suite or broad-template acceptance gap is presented as resolved; independent Formal AI reasoning remains 0/20 accepted.
'''
for name in ['docs/case-studies/issue-1580/README.md','docs/case-studies/issue-1580/templates/README.md','experiments/issue-1580/work-plan.md']:
 p=Path(name);s=p.read_text();boundary='\n## Python review and hosted runtime checkpoint\n';assert s.count(boundary)==1
 p.write_text(s.split(boundary)[0]+paragraph)
print('RELEASE_FRAGMENTS')
p=subprocess.run(['git','ls-files','changelog.d'],capture_output=True,text=True,check=True)
for name in p.stdout.splitlines():
 if '1580' in name:print(name+'\n'+Path(name).read_text())
print('LOG_RECORDS',len(logs),'OWN_SOURCE_SHA256',record['ownChangedSha256'])
