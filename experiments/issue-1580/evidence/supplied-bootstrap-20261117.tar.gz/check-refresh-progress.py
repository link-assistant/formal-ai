import json, pathlib, subprocess
root = pathlib.Path('/tmp/issue-1580-research/native-summary-governed-refresh')
for name in ['worker.log', 'results.json']:
    p = root / name
    if p.exists():
        s = p.read_text()
        print(name, s[-12000:])
for name in ['all-local-gates.log']:
    p = root / name
    if p.exists():
        lines = p.read_text().splitlines()
        print(name, 'lines', len(lines))
        print('\n'.join(lines[-16:]))
subprocess.run(['ps', '-p', '1454491', '-o', 'pid,etime,stat,args'], check=False)
subprocess.run(['git', 'status', '--short'], check=True)
