from pathlib import Path
import gzip, json

path = Path('experiments/issue-1580/evidence/checks/passage-routing-probe/single-passage-task-context.json.gz')
data = json.loads(gzip.decompress(path.read_bytes()))
rows = []
def semantic(answer):
    projected = {key: value for key, value in answer.items() if key in ['intent', 'content', 'confidence']}
    projected['evidence'] = [value for value in answer.get('evidence', []) if isinstance(value, str) and value.startswith(('prompt_text:', 'calculation:', 'calculation_backend:'))]
    return projected
for row in data['rows']:
    if row['name'] not in ['original', 'independent-arithmetic', 'uncovered-subject', 'two-independent-passages']:
        continue
    outcome = row['outcomes'][1]
    answer = outcome['answer']
    bindings = []
    for binding in outcome['bindings']:
        candidate = binding.get('candidate')
        bindings.append({**{key: value for key, value in binding.items() if key != 'candidate'}, 'candidateKeys': list(candidate) if isinstance(candidate, dict) else None, 'candidateSemanticFields': semantic(candidate or {})})
    rows.append({'name': row['name'], 'prompt': row['prompt'], 'answerKeys': list(answer), 'answerSemanticFields': semantic(answer), 'rootStatus': answer.get('metaExecution', {}).get('status'), 'bindings': bindings})
text = json.dumps({'projectionOnly': True, 'wholeNestedTraceReviewClaimed': False, 'rows': rows}, indent=2, ensure_ascii=False)
assert len(text.encode()) < 18000
assert len(text.splitlines()) < 1500
print(text)
