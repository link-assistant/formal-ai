from pathlib import Path
import json
import subprocess

root=Path.cwd()
workflow=root/'.github/workflows/layered-ci.yml'
text=workflow.read_text()
comments='            # Historical archives stay out of this test checkout; retain the\n            # consumed client transcripts, session operand and language logs below.\n'
assert text.count(comments)==1
text=text.replace(comments,'')
needle='          sparse-checkout: |\n            /*\n            !/experiments/formal_ai_subagent/evidence/coordinator-1188/\n            !/dev/log/\n'
assert text.count(needle)==1
text=text.replace(needle,'          # Keep consumed client transcripts, session operands and language logs\n          # while excluding historical archives from this JavaScript test checkout.\n'+needle)
workflow.write_text(text)
body=root/'experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md'
text=body.read_text().replace('results on `9095abcb` are recorded below.','results on `9095abcb` are recorded above.').replace('during checkout, as recorded below.','during checkout, as recorded above.')
body.write_text(text)
checkpoint=root/'docs/case-studies/issue-1580/checkout-archive-checkpoint.md'
text=checkpoint.read_text().replace('checkout is still required; working-tree size reduction alone does not prove transport causality.','checkout is still required; working-tree size reduction alone does not prove\ntransport causality.')
checkpoint.write_text(text)
base=root/'experiments/issue-1580/evidence/checks/javascript-archive-checkout'
log=base/'selection-final.log'
assert not log.exists()
with log.open('wb') as stream:
    result=subprocess.run(['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/fast-pull-request-production-profile.test.mjs'],stdout=stream,stderr=subprocess.STDOUT)
print(log.read_text())
assert result.returncode==0
for path in [Path('/tmp/issue-1580-research/preflight-status-main-integration.py'),base/'sparse-regressions.json',base/'affected-gates.json',root/'experiments/issue-1580/evidence/ci/executor-status-9095abcb/reviewed-native-and-retry-results.json']:
    print('FILE',path)
    print(path.read_text())
