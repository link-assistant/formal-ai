from pathlib import Path
import gzip,hashlib,json,os,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');os.chdir(root)
base=root/'experiments/issue-1580/evidence/checks/general-source-binding';base.mkdir(exist_ok=True)
matches=subprocess.check_output(['rg','--files','js','ts'],text=True).splitlines();paths=[Path(x) for x in matches if x.endswith('/formal_ai_worker_solve.js') or x.endswith('/formal_ai_worker_solve.ts')]
print('SOLVE SOURCES',[str(p) for p in paths]);assert len(paths)==2
command=['timeout','600','node','--max-old-space-size=256','--test','--test-concurrency=1','--test-name-pattern=the worker entry exits only through the procedure','rust/tests/web/issue-1550-procedure-census.test.mjs']
p=subprocess.run(command,capture_output=True);raw=p.stdout+p.stderr;(base/'shared-draft-before.log.gz').write_bytes(gzip.compress(raw,mtime=0));assert p.returncode!=0,raw.decode();print(raw.decode())
records=[]
for path in paths:
 old=path.read_text();new=old.replace('const draft = (text) => solveImpl(text, history, prefs, userContext, memory, options);','const draft = (text, draftOptions = options) => solveImpl(text, history, prefs, userContext, memory, draftOptions);')
 assert new!=old and old.count('const draft = (text) => solveImpl(text, history, prefs, userContext, memory, options);')==1
 target='await solveImpl(text, history, prefs, userContext, memory, { ...options, metaSubTask: true })'
 assert new.count(target)==1
 new=new.replace(target,'await draft(text, { ...options, metaSubTask: true })');path.write_text(new)
 records.append({'file':str(path),'beforeSha256':hashlib.sha256(old.encode()).hexdigest(),'afterSha256':hashlib.sha256(new.encode()).hexdigest()})
(base/'shared-draft-fix.json').write_text(json.dumps({'before':{'argv':command,'exitCode':p.returncode,'file':'shared-draft-before.log.gz','rawSha256':hashlib.sha256(raw).hexdigest()},'sources':records,'independentAuthorshipCredit':0},indent=2)+'\n');print(json.dumps(records))
