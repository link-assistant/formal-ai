import gzip
import hashlib
import json
from pathlib import Path

base=Path('experiments/issue-1580/evidence/checks/passage-routing-probe')
labels=['candidate-research-negative','candidate-research-guarded','direct-research-positive']
results={label:json.loads(gzip.decompress((base/f'{label}.json.gz').read_bytes())) for label in labels}
negative,guarded,direct=(results[label] for label in labels)
assert negative['calls']
assert guarded['calls']==[]
assert direct['calls']
assert negative['hashes']==guarded['hashes']==direct['hashes']
assert negative['answer']['intent']==guarded['answer']['intent']=='prompt_text_answer'
assert negative['answer']['content']==guarded['answer']['content']
assert 'prompt_text:network:none' in guarded['answer']['evidence']
assert all(result['actualNetworkRequests']==0 for result in results.values())
receipt={'schema':'issue-1580-passage-routing-controls/v1','scope':'Mocked worker transport. Only the negative control disables the existing metaSubTask guard. Actual provider calls are zero in every mode. This is supplied evidence, with zero independent authorship credit.','cases':[{'label':label,'observedTransportCalls':len(result['calls']),'intent':result['answer']['intent'],'archiveSha256':hashlib.sha256((base/f'{label}.json.gz').read_bytes()).hexdigest()} for label,result in results.items()],'sameSources':True,'samePassageAnswer':True,'guardedRequests':0,'directResearchRemainsEnabled':True,'metaExecutionStatus':guarded['answer']['metaExecution']['status']}
(base/'controls.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
