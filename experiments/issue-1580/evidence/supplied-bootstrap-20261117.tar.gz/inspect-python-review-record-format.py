from pathlib import Path
import json

for name in [
    'docs/case-studies/issue-1580/templates/csharp-partial-semantic-review.json',
    '/tmp/issue-1580-research/python-active-source-inventory.json',
    '/tmp/issue-1580-research/templates/python-complete-inventory.json',
]:
    value = json.loads(Path(name).read_text())
    print('\nFILE', name)
    if isinstance(value, dict):
        print('KEYS', list(value))
        for key, item in value.items():
            if isinstance(item, list):
                print(key, 'length', len(item), 'first', item[:1])
            elif isinstance(item, dict):
                print(key, str(item)[:3000])
            else:
                print(key, str(item)[:1000])
    else:
        print('length', len(value), 'first', value[:1])
for name in ['/tmp/issue-1580-research/read-python-review-page.py', 'docs/case-studies/issue-1580/README.md']:
    lines = Path(name).read_text().splitlines()
    print('\nFILE', name, 'lines', len(lines))
    selected = list(enumerate(lines, 1)) if len(lines) < 140 else list(enumerate(lines, 1))[-100:]
    for number, line in selected:
        print(f'{number}: {line}')
