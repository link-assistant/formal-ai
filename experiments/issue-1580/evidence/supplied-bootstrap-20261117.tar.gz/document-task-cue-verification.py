from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path('/tmp/gh-issue-solver-1794900398048')
base = root / 'experiments/issue-1580/evidence/checks/quoted-passage-cues'
correction = json.loads((base / 'mirror-correction-resumed/results.json').read_text())
assert [check['name'] for check in correction['checks'] if check['exitCode']] == ['whitespace']
final = json.loads((base / 'whitespace-correction/results.json').read_text())
assert final['complete']
ceiling = final['workerBudgetMeasurement']['lines']
native = json.loads((root / 'experiments/issue-1580/evidence/ci/synthesis-c8fb9ad1/reviewed-completion.json').read_text())
assert native['success'] == 23 and native['nativeTestPassCount'] == 7 and native['httpTestPassCount'] == 2
for name in ['meta-executor-parity.json', 'meta-executor-status-parity.json']:
    path = 'rust/tests/fixtures/' + name
    assert (root / path).read_bytes() == subprocess.check_output(['git', 'show', native['head'] + ':' + path], cwd=root)

checkpoint = root / 'docs/case-studies/issue-1580/quoted-passage-cue-checkpoint.md'
checkpoint.write_text('''# Quoted-passage cue checkpoint

This is an unfinished checkpoint for [PR #1581](https://github.com/link-assistant/formal-ai/pull/1581).
The wider issue remains open.

## Reproduction and change

`Read this and answer: "Marisol owns pears and plums." Which fruit?` splits into
`Read this` and the remaining answer request. The quotation itself is protected,
but the cue's conjunction is treated as another task. Russian, Hindi and Spanish
cues have the same defect. Genuine preceding or following tasks expose an extra split.

Add 12 literal splitting/tree controls in five languages. Before the change,
the focused executor file has 18 passes and seven failures; the Chinese control
already passes. Preserve the entire 219-line failing payload and its hashes.
Escaped quote openers, word boundaries, cues inside quotations and genuinely
unquoted commands are negative controls.

Mask only seeded cue surfaces that directly introduce an actual quotation,
separated by whitespace or declared colon characters. Both runtimes reuse the
existing prompt-text-question vocabulary and the quote mask's escape/word rules.
Genuine tasks before and after the cue remain independent. A separate shared
12-case fixture records complete result and event parity. The original 25-case
and four-case fixtures remain byte-identical, for 41 replay cases in total.

## Verification and retained failures

All 25 executor tests and 15 adjacent factual-QA tests pass. Read the full failed
before payload, both full passing payloads, the handwritten source diff and all
477 lines of the new shared fixture. Preserve hashes and complete archived logs.
Rust 2024 formatting, fixture currency and maintained worker, TypeScript, seed
and translation generation pass. No local Rust build runs; native cue execution
remains pending the next published head's hosted CI.

The initial worker writer rejects the existing executor ceiling. Extract a small
helper; the next writer correctly requires its explicit budget. Register its
measured 46-line factory without raising any existing module ceiling. The next
translation writer refuses the new untracked helper; register the new sources
with intent-to-add, then run the maintained pinned translator successfully.
Preserve all three failed generation attempts separately from the corrections.
Projection verification reports 337 translated items, 37 workarounds, 2,592 carried
items and 112/162 translating modules (one fully), with 50 refused modules. The
new helper accounts for one additional refusal; this is not complete translation.

The full 138-entry local inventory records 83 passes, 52 explicit native/CI
exclusions and three failures: notation and package checks find the stale embedded
seed copy, while the status check finds a stale generated worker-budget count.
Preserve the aggregate and all 86 executable gate payloads. A correction guard
stops before mutation when the third failure expands its expected failure set.
Regenerate the package mirror and status surfaces with their maintained JavaScript
writers, then pass all three failed gates and the adjacent status twin. The 86
executable inventory entries therefore pass after correction; the original failed
aggregate remains unchanged. Memory events show zero OOMs or OOM kills.

The preceding synthesis correction on `c8fb9ad1` passes all 23 hosted workflows.
Its actual native log passes five executor tests, calendar/currency and forced
functions, plus both HTTP modes. Those executor results replay the previous 29
fixture cases; they do not execute this new 12-case cue fixture.

## Limits

These controls establish task boundaries using a deterministic table host. They
do not validate factual answers, bind passage references to later questions,
establish complete semantic parent coverage, or validate multi-passage evidence.
Those requirements and the wider issue remain unfinished. Supplied scripts,
commands, patches and conclusions receive zero independent authorship credit;
independent acceptance remains 0/20.
''')
text = checkpoint.read_text()
marker = 'The preceding synthesis correction on `c8fb9ad1` passes all 23 hosted workflows.'
text = text.replace(marker, f'The final whitespace check finds an extra EOF blank line in the helper and its\ngenerated TypeScript copy. Preserve that failed receipt, remove only the source\nEOF blank line and refresh maintained projections. The remeasured helper factory\ncontains {ceiling} lines; retain its exact ceiling without raising any existing budget.\nAll five affected generated/translation/budget/status checks and whitespace pass.\n\n' + marker, 1)
checkpoint.write_text(text)

plan = root / 'experiments/issue-1580/work-plan.md'
text = plan.read_text()
old = '- [ ] Publish the synthesis constructor correction after the single-push gate,\n  then verify all hosted results and actual execution of the fifth executor test.'
new = '- [x] Publish the synthesis constructor correction as c8fb9ad1 after the single-push gate. All 23 workflows pass; the actual hosted log passes five executor tests, calendar/currency, forced functions and both HTTP modes. The fifth executor regression executes successfully; complete payloads and literal review ranges remain preserved.'
assert old in text
text = text.replace(old, new, 1)
old = '- [ ] Complete maintained worker/TypeScript/seed/translation generation, focused\n  tests, original fixture byte checks and all 138 local inventory entries.'
new = f'- [x] Complete maintained generation, 25 executor and 15 adjacent factual-QA tests, original fixture byte checks and all 138 local inventory entries. Preserve the third writer failure (untracked new helper), then its successful pinned translation refresh. The full run records 83 passes, 52 exclusions and three stale mirror/status failures. Preserve the stopped correction guard, regenerate both surfaces with maintained writers, and pass all three failed gates plus the adjacent status twin. Preserve the final EOF-whitespace failure, remove only that blank line, refresh projections and pass five affected gates plus whitespace. The exact remeasured new factory ceiling is {ceiling}; all existing ceilings remain unchanged. All 86 executable entries pass after correction; projection reports 50 refused modules, including the new helper.'
assert old in text
text = text.replace(old, new, 1)
plan.write_text(text)

child = root / 'docs/case-studies/issue-1580/child-evidence-checkpoint.md'
text = child.read_text()
for old, new in [
    ('and alternatives; native execution remains pending CI.', 'and alternatives; its first hosted attempt is recorded below.'),
    ('local native build runs; the fifth native executor test still awaits CI.', 'local native build runs; hosted execution is recorded below.'),
    ('and the fifth executor regression remain pending the next hosted run.', 'and the fifth executor regression are verified on the hosted follow-up below.'),
]:
    assert old in text, old
    text = text.replace(old, new, 1)
text += '''
## Hosted synthesis correction follow-up

Published head `c8fb9ad1df655abe89289e229189f3fc41451ec0` passes all 23 workflows.
The [actual native job](https://github.com/link-assistant/formal-ai/actions/runs/44279551659/job/134719666304)
passes five executor tests, including selected-child evidence retention, plus
calendar/currency and forced functions: seven Rust tests and both HTTP modes.
The executor target replays all 29 existing cases and their full event sequences.
JavaScript shards pass 1,440 and 1,256 tests with four and 13 skips and no failures.
Preserve complete downloaded job payloads, digests and literal review ranges under
`experiments/issue-1580/evidence/ci/synthesis-c8fb9ad1/`. This verifies the two
validation-only constructor initializers and the fifth executor regression;
general parent coverage, passage binding and multi-passage validation remain open.
'''
child.write_text(text)

body = root / 'experiments/issue-1580/evidence/checks/unverified-child-status/pull-request-description.md'
text = body.read_text()
text = text.replace('Compound task parsing also splits conjunctions inside ASCII quotations', 'Compound task parsing also splits conjunctions inside ASCII quotations and seeded passage cues', 1)
text = text.replace('the fifth native executor test awaits CI.', 'the fifth native executor test passes on published head `c8fb9ad1`.', 1)
marker = 'Changes:\n\n'
assert marker in text
text = text.replace(marker, marker + '- Preserve seeded quoted-passage cues as one task in JavaScript and Rust while retaining genuine surrounding tasks. Add 12 literal controls across five languages and a third shared 12-case fixture; preserve all original 29 fixture cases byte-for-byte. Native execution of the new fixture awaits its published head.\n', 1)
marker = 'Latest reproduction and verification:\n\n'
assert marker in text
rows = '''- Reproduce the passage-cue bug with `Read this and answer: "Marisol owns pears and plums." Which fruit?`: the conjunction inside the cue incorrectly creates another task. The regression records **18 passes / seven failures before**, then **25/25 executor tests and 15/15 adjacent factual-QA tests pass**. The 12 new cases cover five languages, case/spacing, genuine surrounding tasks and four negative controls. All original 29 fixture cases remain byte-identical; the combined replay contains 41 cases. Preserve three failed generation attempts and the stopped correction guard separately. The full 138-entry inventory records **83 passes, 52 explicit exclusions and three stale embedded-seed/status failures**. After maintained mirror/status writers, all three failed gates and the adjacent status twin pass, so **all 86 executable entries pass after correction**. Rust 2024 formatting, fixture currency and maintained projections pass. Projection verification reports **112/162 translating modules, one fully, 50 refused**; the new helper is one refusal. Native cue execution awaits the next hosted head; no local Rust build runs.
- Published synthesis correction `c8fb9ad1` passes **23/23 workflows**. The [actual native job](https://github.com/link-assistant/formal-ai/actions/runs/44279551659/job/134719666304) passes **seven Rust tests**: five executor tests including selected-child evidence, calendar/currency and forced functions; both HTTP modes also pass. The executor target replays the previous **29 cases and complete events**. JavaScript shards report **1,440 and 1,256 passes**, **4 and 13 skips**, zero failures and zero cancellations. Full downloaded payloads, digests and specific literal-review ranges remain preserved. This run precedes the 12-case cue fixture.
'''
text = text.replace(marker, marker + rows, 1)
text = text.replace('Preserve three failed generation attempts and the stopped correction guard separately.', f'Preserve three failed generation attempts, the stopped correction guard and the later EOF-whitespace failure separately. Remove only the EOF blank line, refresh projections, and pass all five affected checks plus whitespace; the exact remeasured new helper ceiling is {ceiling}.', 1)
text = text.replace('The fifth native executor test awaits hosted execution; no local Rust build runs.', 'The fifth native executor test passes on `c8fb9ad1`, as recorded above; no local Rust build runs.', 1)
text = text.replace('Native verification of this correction remains pending the next hosted run.', 'Native verification of this correction passes on `c8fb9ad1`, as recorded above.', 1)
text = text.replace('The [selected-child evidence checkpoint]', 'The [quoted-passage cue checkpoint](https://github.com/link-assistant/formal-ai/blob/issue-1580-8d61a32a61e1/docs/case-studies/issue-1580/quoted-passage-cue-checkpoint.md), [selected-child evidence checkpoint]', 1)
assert text.count('Fixes #1580') == 1
body.write_text(text)
print('UPDATED cue checkpoint, work plan, child-evidence hosted verification and PR body')
