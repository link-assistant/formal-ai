from pathlib import Path
import subprocess, json
p=Path("experiments/issue-1580/evidence/checks/calendar-clock-preservation")
print("FILES", [(x.name,x.stat().st_size) for x in p.iterdir()])
c=p/"validation-completion.json"
print("COMPLETION",c.read_text() if c.exists() else "RUNNING")
print("SUPERVISOR SOURCE")
print(Path("/tmp/issue-1580-research/calendar-validation-job.py").read_text())
proc=subprocess.run(["ps","-eo","pid,ppid,etime,rss,args"],text=True,capture_output=True,check=True)
for line in proc.stdout.splitlines():
 if "359277" in line or "359709" in line or "measure-dependency" in line: print("PROCESS",line)
for name in ["complete-local-gates.log","complete-local-gates.raw.log"]:
 q=p/name
 if q.exists():
  lines=q.read_text().splitlines()
  print("GATE RAW",name,len(lines),"LINES, LAST 12")
  for i in range(max(0,len(lines)-12),len(lines)):print(f"{i+1}: {lines[i]}")
