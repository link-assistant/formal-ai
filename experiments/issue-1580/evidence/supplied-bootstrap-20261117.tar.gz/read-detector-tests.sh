set -eu
sed -n '1,220p' rust/tests/web/issue-1571-workflow-diagnostics.test.mjs
sed -n '1,250p' rust/tests/web/push-change-admission.test.mjs
rg -n 'detect-code-changes.rs|rust-script.*--test' .github/workflows scripts/check* experiments/formal_ai_subagent/local-gates.mjs rust/tests/web | head -n 100
