from pathlib import Path
import subprocess,json,hashlib,datetime,gzip
base=Path('experiments/issue-1580/evidence/checks/native-test-admission/governed-refresh')
def run(command):
    result=subprocess.run(command,capture_output=True);assert result.returncode==0,result.stderr.decode();return result.stdout.decode().strip()
assert run(['git','branch','--show-current'])=='issue-1580-8d61a32a61e1'
assert run(['git','diff','--cached','--name-only'])==''
parent=run(['git','rev-parse','HEAD']);assert parent=='ec8e609bfe5cd7b9c4111683a02fe08fb5fa3185'
report=json.loads((base/'governed-refresh.json').read_text())
assert report['completeInventoryUnchangedExceptCargoFixtureIdentity'] and report['changedFixtureOccurrences']==4
file='experiments/formal_ai_subagent/evidence/specification-delivery-1188/unicode-identifier-identity/governed-baseline.v8'
assert hashlib.sha256(Path(file).read_bytes()).hexdigest()==report['afterSha256']
assert hashlib.sha256(Path('rust/Cargo.toml').read_bytes()).hexdigest()==report['newCargoSha256']
assert json.loads((base/'results.json').read_text())['complete']
run(['git','add','--',file]);assert run(['git','diff','--cached','--name-only'])==file
print(run(['git','-c','gc.auto=0','commit','-m','Refresh reviewed Cargo fixture after isolated synthesis target']))
head=run(['git','rev-parse','HEAD'])
(base/'reviewed-local-commit.json').write_text(json.dumps({'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'parent':parent,'source':file,'completeObjectsCompared':True,'fullLogsLiterallyRead':True,'pushed':False,'nativeExecution':False,'independentAuthorshipCredit':0},indent=2)+'\n')
doc=Path('docs/case-studies/issue-1580/native-regression-admission-checkpoint.md')
with doc.open('a') as stream:stream.write('\nThe Cargo target addition also invalidates the existing governed manifest witness.\nThe actual fixture-integrity file fails on the changed Cargo SHA before refresh.\nThe official reviewed writer updates exactly four Cargo fixture hashes; complete\ncase objects, unsupported objects and native source manifest are otherwise equal.\nBoth fixture-integrity tests and all 34 identifier tests pass afterward. Complete\nbefore/after logs and the binary predecessor are under `native-test-admission/governed-refresh/`.\nThis source-fixture verification does not execute the native target.\n')
print(json.dumps({'head':head,'pushed':False},indent=2))
