from pathlib import Path
import json,subprocess

scratch=Path('/tmp/issue-1580-research/child-evidence-all-gates')
base=Path('experiments/issue-1580/evidence/checks/child-evidence-provenance/all-gates')
print('MEMORY',Path('/sys/fs/cgroup/memory.current').read_text().strip())
print('EVENTS',Path('/sys/fs/cgroup/memory.events').read_text())
print('WORKER',scratch.joinpath('worker.log').read_text())
result=base/'results.json'
if result.exists():
    print('RESULTS',result.read_text())
    print('FULL AGGREGATE',scratch.joinpath('all-gates.log').read_text())
    details=json.loads(base.joinpath('gate-details.json').read_text()) if base.joinpath('gate-details.json').exists() else []
    print('DETAIL LOGS',len(details),'LINES',sum(row['rawLines'] for row in details))
else:
    print('GATE PROGRESS','\n'.join(scratch.joinpath('all-gates.log').read_text().splitlines()[-24:]))
print(subprocess.run(['ps','-o','pid,ppid,stat,etime,rss,args','--ppid','1229611','-p','1229611'],capture_output=True,text=True).stdout)
