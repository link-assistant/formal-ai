from pathlib import Path
import json,subprocess
pr=json.loads(subprocess.check_output(['gh','pr','view','1581','--repo','link-assistant/formal-ai','--json','title,body,isDraft,headRefOid,url'],text=True))
Path('/tmp/issue-1580-research/pr-before-ninth-update.json').write_text(json.dumps(pr,indent=2)+'\n')
print(json.dumps(pr,indent=2))
print('C# PAGE READER\n'+Path('/tmp/issue-1580-research/read-csharp-page.py').read_text())
