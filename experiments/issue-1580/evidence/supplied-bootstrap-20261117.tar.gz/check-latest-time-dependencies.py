from pathlib import Path
import json, urllib.request
for crate,versions in [('command-stream',['1.5.3','1.13.0']),('link-calculator',['0.22.0','0.24.0'])]:
    for version in versions:
        request=urllib.request.Request(f'https://crates.io/api/v1/crates/{crate}/{version}/dependencies',headers={'User-Agent':'formal-ai-issue-1580-dependency-investigation'})
        with urllib.request.urlopen(request,timeout=30) as response: value=json.load(response)
        Path(f'/tmp/issue-1580-research/{crate}-{version}-dependencies.json').write_text(json.dumps(value,indent=2)+'\n')
        print(crate,version,[(x['crate_id'],x['req'],x['optional'],x['default_features'],x['features'],x['target']) for x in value['dependencies'] if x['crate_id'] in ['chrono','time','jiff']])
