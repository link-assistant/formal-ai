from pathlib import Path
import gzip,json,re
base=Path('experiments/issue-1580/evidence/ci/main-015a6831')
target=base/'targeted-failure-index.json.gz'
rows=json.loads(gzip.decompress(target.read_bytes()))
pattern=r"thread '[^']+'(?: \([0-9]+\))? panicked at"
panic=re.compile(pattern)
scratch=Path('/tmp/issue-1580-research/main-015a6831-runs')
for row in rows:
    path=scratch/row['archive'][:-3]
    new=[]
    with path.open() as stream:
        for number,line in enumerate(stream,1):
            if panic.search(line):new.append({'line':number,'kinds':['panic'],'text':line.rstrip()})
    for marker in row['markers']:
        marker['kinds']=[kind for kind in marker['kinds'] if kind!='panic']
    row['markers']=[m for m in row['markers'] if m['kinds']]+new
    row['markers'].sort(key=lambda marker:marker['line'])
    row['markerCounts']['panic']=len(new)
    row['panicPattern']=pattern
    print(row['archive'],'PANIC MARKERS',len(new))
    for marker in new:
        text=marker['text'].split('Z ',1)[-1]
        print(str(marker['line'])+': '+text[:250])
target.write_bytes(gzip.compress((json.dumps(rows,indent=2)+'\n').encode(),mtime=0))
print('Corrected the initial PID-blind panic regex; the original command record remains preserved. Matched markers are not a complete failure inventory.')
