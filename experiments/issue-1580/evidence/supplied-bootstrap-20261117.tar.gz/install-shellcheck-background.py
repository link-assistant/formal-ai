from pathlib import Path
import datetime,json,os,subprocess,sys
base=Path('/tmp/issue-1580-research/shellcheck-install');base.mkdir(exist_ok=True)
if len(sys.argv)==1:
    assert not (base/'worker.json').exists()
    with (base/'worker.log').open('wb') as log:
        child=subprocess.Popen([sys.executable,__file__,'worker'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    (base/'worker.json').write_text(json.dumps({'pid':child.pid,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
    print('Started background package installation',child.pid)
else:
    env=os.environ.copy();env['DEBIAN_FRONTEND']='noninteractive'
    argv=['sudo','-n','apt-get','install','-y','--no-install-recommends','shellcheck']
    result=subprocess.run(argv,env=env,capture_output=True)
    (base/'apt.log').write_bytes(result.stdout+result.stderr)
    (base/'outcome.json').write_text(json.dumps({'argv':argv,'exitCode':result.returncode})+'\n')
    print('apt exit',result.returncode,flush=True)
