/**
 * Open a Formal AI draft for every new issue (issue #2233).
 *
 * Why this exists
 * ---------------
 * Issue #2233 asks for a draft attempt from Formal AI within minutes of an
 * issue being opened, on a branch nobody depends on, so that a wrong attempt
 * costs nothing and a right one saves the first commit. It asks for three
 * things, and this module is the decidable part of all three:
 *
 *   1. Trigger on `issues: opened`, not on a curated label — so the decision of
 *      *whether* to attempt is made here, from the event payload, rather than
 *      by a human applying a label. `decideDraft()` is that decision.
 *   2. Point the run at Hive Mind's own
 *      `solve --tool agent --model formal-ai --attach-logs --verbose` path
 *      (#2229, #2230, v2.24.0), so the drafts measure the chain Hive Mind
 *      ships. `buildSolveArgv()` is that command, and
 *      `tests/formal-ai-draft-2233.test.mjs` parses it through solve's own
 *      strict yargs configuration, so a flag typo fails in unit tests instead
 *      of forty minutes into a container run.
 *   3. Failure policy: a draft stays open and red until a later run succeeds.
 *      `buildSolveArgv()` therefore never emits `--auto-merge` and never emits
 *      `--auto-close-pull-request-on-fail`, and `keepPullRequestAsDraftArgs()`
 *      puts the pull request back into draft after the session, because solve
 *      converts it to ready-for-review at session end (#2123/#2182).
 *
 * Why the composite action is not installed here
 * ----------------------------------------------
 * Item 1 of #2233 says "install the action once it is published". As of the
 * commit that adds this file it is not published: `link-assistant/formal-ai`
 * has no root `action.yml`, `.github/actions` holds only `cache-cargo-registry`,
 * `download-formal-ai-binary`, `setup-buildx-resilient` and `setup-sccache`,
 * and there is no `.github/workflows/self-authored-pull-request.yml`. The
 * evidence is captured in `docs/case-studies/issue-2233/`. `uses:` does not
 * accept expressions, so there is no declarative seam that could switch to the
 * action the day it appears; the swap is a one-line edit of the workflow, and
 * `docs/FORMAL-AI-DRAFTS.md` records exactly which line.
 *
 * Everything here is a pure function over plain data, on node builtins only, so
 * the workflow's behaviour is testable without GitHub, Docker or a model.
 *
 * @see https://github.com/link-assistant/hive-mind/issues/2233
 * @module formal-ai-draft
 */

import { resolveCiRunUrl } from '../src/ci-run-url.lib.mjs';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';

/** Applied to a draft this workflow opened, so the drafts can be listed and closed as a batch. */
export const FORMAL_AI_DRAFT_LABEL = 'formal-ai-draft';

/** Put this on an issue before opening it (or on the issue template) to suppress the attempt. */
export const FORMAL_AI_DRAFT_OPT_OUT_LABEL = 'no-formal-ai-draft';

/**
 * The published image that bakes formal-ai, the Agent CLI and hive-mind together.
 * The draft workflow pins the tag of the checked-out version instead
 * (`scripts/formal-ai-draft-image.lib.mjs`); this is the fallback.
 */
export const DEFAULT_HIVE_MIND_IMAGE = 'konard/hive-mind:latest';

/** Where the image keeps the `formal-ai` binary; a caller-built binary is mounted over it. */
export const FORMAL_AI_BINARY_CONTAINER_PATH = '/usr/local/bin/formal-ai';

/** Annotation titles the draft job writes and the health check reads back. */
export const DRAFT_DECISION_ANNOTATION_TITLE = 'Formal AI draft decision';
export const DRAFT_FAILURE_ANNOTATION_TITLE = 'Formal AI draft failed';

/**
 * The identity every commit on a draft branch carries.
 *
 * "No human commit on its branch" is a done-when condition of #2233. git takes
 * an identity from `GIT_CONFIG_*` without a config file existing at all, which
 * is what makes this work inside a container whose HOME is not the operator's
 * (verified by `experiments/issue-2233/probe-git-identity.sh`).
 */
export const DRAFT_GIT_IDENTITY = Object.freeze({
  name: 'github-actions[bot]',
  email: '41898282+github-actions[bot]@users.noreply.github.com',
});

/**
 * The flags #2233 names, plus the ones its failure policy implies.
 *
 * `--attach-logs --verbose` is quoted verbatim from the issue: a draft that
 * fails must leave its session log attached, "so the cause is readable after
 * the container is gone".
 *
 * `--attribution formal-ai` forces the trailer/evidence machinery of #2230 on
 * rather than letting `auto` decide, because the four trailers and the evidence
 * bundle are the done-when condition, not a nice-to-have.
 *
 * `--no-auto-restart-until-mergeable` and `--no-auto-restart-on-uncommitted-changes`
 * are not named in the issue. Both default to true. Left on, the first watches
 * the pull request's checks and restarts the model until they are green, for
 * up to `--auto-restart-until-mergeable-timeout-hours` (24); the second
 * restarts it whenever files are left uncommitted, which has meant five more
 * sessions over Formal AI's own derivation files. Both contradict "it
 * stays open and red until a later run succeeds": the later run is the next
 * attempt, not this one looping.
 */
export const DRAFT_SOLVE_FLAGS = Object.freeze(['--tool', 'agent', '--model', 'formal-ai', '--attach-logs', '--development-log', '--verbose', '--attribution', 'formal-ai', '--no-auto-restart-until-mergeable', '--no-auto-restart-on-uncommitted-changes']);

/**
 * Flags that must never appear in a draft run.
 *
 * Each is already off by default; they are listed so the intent survives a
 * future change of default, and so the regression test can assert on it.
 * `--auto-merge` would merge a draft nobody reviewed. `--auto-close-pull-request-on-fail`
 * would delete the evidence the whole exercise exists to collect.
 */
export const FORBIDDEN_DRAFT_SOLVE_FLAGS = Object.freeze(['--auto-merge', '--auto-close-pull-request-on-fail']);

/** Reason codes `decideDraft()` can return. Stable strings: the workflow logs them and the test asserts on them. */
export const DRAFT_DECISION_CODES = Object.freeze({
  run: 'run',
  notOpened: 'not-an-opened-issue',
  pullRequest: 'issue-is-a-pull-request',
  botAuthor: 'issue-author-is-a-bot',
  optOut: 'opt-out-label',
  alreadyDrafted: 'already-drafted',
  missingIssue: 'no-issue-in-event',
});

const labelNames = issue =>
  (Array.isArray(issue?.labels) ? issue.labels : [])
    .map(label => (typeof label === 'string' ? label : label?.name))
    .filter(name => typeof name === 'string')
    .map(name => name.toLowerCase());

/**
 * Read the issue out of a `issues` webhook payload, or out of a manual replay.
 *
 * A `workflow_dispatch` replay carries only a number, so the caller fetches the
 * rest; both shapes normalise to the same object so `decideDraft()` has one
 * input shape to reason about.
 *
 * @param {object} [event] parsed contents of `GITHUB_EVENT_PATH`
 * @returns {{action: (string|null), issue: (object|null)}}
 */
export function readIssueEvent(event) {
  if (!event || typeof event !== 'object') return { action: null, issue: null };
  return { action: typeof event.action === 'string' ? event.action : null, issue: event.issue && typeof event.issue === 'object' ? event.issue : null };
}

/**
 * Decide whether this event should produce a Formal AI draft.
 *
 * Policy is independent of credential configuration. The default workflow
 * token always provides a draft attempt, with checks started through dispatch.
 *
 * @param {object} params
 * @param {string} [params.eventName] `github.event_name`
 * @param {string} [params.action] webhook action (`opened`, `labeled`, …)
 * @param {object} [params.issue] the issue object from the payload
 * @param {string} [params.layer] resolved credential layer
 * @param {string} [params.optOutLabel]
 * @returns {{run: boolean, code: string, reason: string}}
 */
export function decideDraft({ eventName = 'issues', action = null, issue = null, layer = 'default', optOutLabel = FORMAL_AI_DRAFT_OPT_OUT_LABEL } = {}) {
  const deny = (code, reason) => ({ run: false, code, reason });

  if (eventName === 'issues' && action !== 'opened') return deny(DRAFT_DECISION_CODES.notOpened, `the \`issues\` event action was "${action ?? 'missing'}", not "opened"`);
  if (!issue) return deny(DRAFT_DECISION_CODES.missingIssue, 'the event payload carried no issue');
  if (issue.pull_request) return deny(DRAFT_DECISION_CODES.pullRequest, `#${issue.number} is a pull request, not an issue`);
  if (issue.user?.type === 'Bot') return deny(DRAFT_DECISION_CODES.botAuthor, `#${issue.number} was opened by the bot ${issue.user?.login ?? 'unknown'}; drafting a bot's issue would let two automations feed each other`);

  const labels = labelNames(issue);
  if (labels.includes(optOutLabel.toLowerCase())) return deny(DRAFT_DECISION_CODES.optOut, `#${issue.number} carries the \`${optOutLabel}\` label`);
  if (labels.includes(FORMAL_AI_DRAFT_LABEL)) return deny(DRAFT_DECISION_CODES.alreadyDrafted, `#${issue.number} already carries the \`${FORMAL_AI_DRAFT_LABEL}\` label`);

  return { run: true, code: DRAFT_DECISION_CODES.run, reason: `#${issue.number} was just opened by ${issue.user?.login ?? 'a human'}`, checkStrategy: layer === 'default' ? 'dispatch' : 'pull_request' };
}

/**
 * The `solve` arguments for one draft attempt.
 *
 * @param {object} params
 * @param {string} params.issueUrl the full `https://github.com/owner/repo/issues/N` URL
 * @param {string} [params.logDir] directory solve writes its session log into
 * @returns {string[]}
 */
export function buildSolveArgv({ issueUrl, logDir } = {}) {
  if (typeof issueUrl !== 'string' || !/^https:\/\/github\.com\/[^/\s]+\/[^/\s]+\/issues\/\d+$/.test(issueUrl)) {
    throw new Error(`buildSolveArgv needs a github.com issue URL, received ${JSON.stringify(issueUrl)}`);
  }
  const argv = [issueUrl, ...DRAFT_SOLVE_FLAGS];
  if (logDir) argv.push('--log-dir', logDir);
  return argv;
}

/**
 * `GIT_CONFIG_*` variables that give git an identity without writing a config file.
 *
 * `init.defaultBranch` is included for the same reason every other workflow in
 * this repository sets it: `git init` warns without it and the warning ends up
 * in the attached log.
 *
 * @param {{name: string, email: string}} [identity]
 * @returns {Record<string, string>}
 */
export function buildGitIdentityEnv(identity = DRAFT_GIT_IDENTITY) {
  return {
    GIT_CONFIG_COUNT: '3',
    GIT_CONFIG_KEY_0: 'init.defaultBranch',
    GIT_CONFIG_VALUE_0: 'main',
    GIT_CONFIG_KEY_1: 'user.name',
    GIT_CONFIG_VALUE_1: identity.name,
    GIT_CONFIG_KEY_2: 'user.email',
    GIT_CONFIG_VALUE_2: identity.email,
  };
}

/**
 * The full `docker run …` argument list for one draft attempt.
 *
 * Built as an argv array, never as a shell string: the issue URL comes from a
 * webhook payload, and an argv array cannot be made to mean something else by
 * its contents. Environment variables are forwarded by *name* (`-e NAME`), so
 * no secret value is ever written into the argument list — where it would be
 * visible to `ps` and to anything that logs the command.
 *
 * @param {object} params
 * @param {string[]} params.solveArgv from `buildSolveArgv()`
 * @param {string} [params.solveCommand] explicit candidate path when PATH also contains a published solve
 * @param {string} [params.image]
 * @param {string} [params.hostLogDir] host directory bind-mounted for the session log
 * @param {string} [params.containerLogDir] where that directory appears in the container
 * @param {string[]} [params.forwardEnv] names of environment variables to forward
 * @param {Record<string,string>} [params.setEnv] literal, non-secret variables to set
 * @param {string[]} [params.extraMounts] further `-v` mounts, e.g. a caller-built Formal AI binary
 * @returns {string[]}
 */
export function buildDockerArgv({ solveArgv, solveCommand = 'solve', image = DEFAULT_HIVE_MIND_IMAGE, hostLogDir = null, containerLogDir = '/home/box/logs', forwardEnv = ['GH_TOKEN'], setEnv = buildGitIdentityEnv(), extraMounts = [] } = {}) {
  if (!Array.isArray(solveArgv) || solveArgv.length === 0) throw new Error('buildDockerArgv needs the solve argv from buildSolveArgv()');

  const argv = ['run', '--rm', '--user', 'box'];
  for (const name of forwardEnv) argv.push('-e', name);
  for (const [name, value] of Object.entries(setEnv)) argv.push('-e', `${name}=${value}`);
  if (hostLogDir) argv.push('-v', `${hostLogDir}:${containerLogDir}`);
  for (const mount of extraMounts) argv.push('-v', mount);
  argv.push(image, solveCommand, ...solveArgv);
  return argv;
}

/**
 * Variables that tell solve it runs in a `--rm` container, inside GitHub
 * Actions, and which workflow run keeps its log as an artifact. Without them a failed log upload named a
 * path inside a container that no longer existed.
 *
 * @param {Record<string,string|undefined>} [env]
 * @returns {Record<string,string>}
 */
export function buildRunContextEnv(env = process.env) {
  const runUrl = resolveCiRunUrl(env);
  // Issue #3330: solve takes the Actions token identity (`github-actions[bot]`)
  // when `/user` is forbidden, but only if it can tell it runs in Actions.
  return { HIVE_MIND_EPHEMERAL_CONTAINER: '1', ...(runUrl ? { HIVE_MIND_CI_RUN_URL: runUrl } : {}), ...(env.GITHUB_ACTIONS === 'true' ? { GITHUB_ACTIONS: 'true' } : {}) };
}

const LOG_LINE_PREFIX = /^\[[^\]]*\] \[([A-Z]+)\] /;

/**
 * The first error a solve session log reports, without its timestamp, level
 * and ❌ marker: the first `❌` line, else the first `[ERROR]` line.
 *
 * @param {string} text session log contents
 * @returns {string|null}
 */
export function firstErrorLine(text) {
  const lines = String(text || '').split('\n');
  const message = line =>
    line
      .replace(LOG_LINE_PREFIX, '')
      .replace(/^❌\s*/, '')
      .trim() || null;
  const marked = lines.find(line => line.replace(LOG_LINE_PREFIX, '').startsWith('❌'));
  if (marked) return message(marked);
  const errorLine = lines.find(line => LOG_LINE_PREFIX.exec(line)?.[1] === 'ERROR');
  return errorLine ? message(errorLine) : null;
}

/** solve's last word on a run that changed nothing (src/solve.finalize.lib.mjs). */
const FINISHED_WITHOUT_CHANGES = /^⚠️\s+Finished without changes: (.+)$/u;

/**
 * Why a draft run is red, for the `Formal AI draft failed` annotation and the
 * health check that reads it back.
 *
 * Issue #4025: every red draft since #3211 exited 5 ("finished without
 * changes"), yet the annotation said "Failed to fetch authenticated GitHub
 * username ... HTTP 403". That ❌ line is gh-upload-log failing to create a
 * gist with the workflow token, an error solve recovers from by saving the
 * log on the pull request branch. When solve reports it finished without
 * changes, that line and its reason are the outcome; otherwise the first
 * error is.
 *
 * @param {string} text session log contents
 * @returns {string|null}
 */
export function draftFailureReason(text) {
  for (const line of String(text || '').split('\n')) {
    const match = FINISHED_WITHOUT_CHANGES.exec(line.replace(LOG_LINE_PREFIX, '').trim());
    if (match) return `Finished without changes: ${match[1].trim()}`;
  }
  return firstErrorLine(text);
}

/** solve's own run log name (src/solve.validation.lib.mjs: `solve-<timestamp>.log`). */
const SOLVE_LOG_NAME = /^solve-.*\.log$/u;

/**
 * The session log a red draft is explained from, among the files in the log
 * directory.
 *
 * Issue #4065: the newest `*.log` used to win, but the caller owns that
 * directory. formal-ai's command capture files (`attempt.log`,
 * `attempt.stdout.log`) were rewritten on every output chunk, so they were
 * always newer than `solve-*.log`, and the "Finished without changes" line was
 * never read. solve's own log is picked by name, newest first; any other
 * `*.log` is only a fallback when no `solve-*.log` exists (for example the
 * `formal-ai-draft-failure.log` written before solve starts).
 *
 * @param {Array<{name: string, mtimeMs: number}>} entries
 * @returns {string|null} the chosen file name
 */
export function selectSessionLog(entries) {
  const logs = (entries || []).filter(entry => entry.name.endsWith('.log'));
  const solveLogs = logs.filter(entry => SOLVE_LOG_NAME.test(entry.name));
  const [newest] = (solveLogs.length ? solveLogs : logs).slice().sort((a, b) => b.mtimeMs - a.mtimeMs);
  return newest ? newest.name : null;
}

/**
 * The message of the `Formal AI draft failed` annotation for a run that exited
 * `status`, read from the session log in `logDir`.
 *
 * @param {Object} params
 * @param {string} params.logDir host log directory
 * @param {number} params.status docker run exit status
 * @param {Object} [params.fileSystem] `{ readdirSync, statSync, readFileSync }`
 * @returns {string}
 */
export function draftFailureMessage({ logDir, status, fileSystem = { readdirSync, statSync, readFileSync } }) {
  let text = '';
  try {
    const entries = fileSystem
      .readdirSync(logDir)
      .filter(name => name.endsWith('.log'))
      .map(name => ({ name, mtimeMs: fileSystem.statSync(join(logDir, name)).mtimeMs }));
    const name = selectSessionLog(entries);
    if (name) text = fileSystem.readFileSync(join(logDir, name), 'utf8');
  } catch {
    // No log is itself the finding; the fallback message says so.
  }
  return draftFailureReason(text) || `docker run exited ${status} without a session log error`;
}

const escapeAnnotationData = value => String(value).replace(/%/g, '%25').replace(/\r/g, '%0D').replace(/\n/g, '%0A');
const escapeAnnotationProperty = value => escapeAnnotationData(value).replace(/:/g, '%3A').replace(/,/g, '%2C');

/**
 * A `::notice`/`::error` workflow command. Escaped, so a message taken from a
 * session log cannot end the command and start another one.
 *
 * @param {'notice'|'warning'|'error'} level
 * @param {string} title
 * @param {string} message
 * @returns {string}
 */
export function formatWorkflowAnnotation(level, title, message) {
  return `::${level} title=${escapeAnnotationProperty(title)}::${escapeAnnotationData(message)}`;
}

/**
 * Find the pull request a draft attempt opened for `issueNumber`.
 *
 * solve names its branch `issue-<number>-<uuid-suffix>`; matching on that
 * prefix is what lets the workflow put the pull request back into draft and
 * label it without the model having to report anything back. The `-` after the
 * number matters: without it, issue 22 would match the branch of issue 223.
 *
 * @param {Array<{number: number, headRefName: string, isDraft?: boolean}>} pullRequests
 * @param {number|string} issueNumber
 * @returns {object|null} the newest matching pull request
 */
export function selectDraftPullRequest(pullRequests, issueNumber) {
  const prefix = `issue-${String(issueNumber)}-`;
  const matches = (Array.isArray(pullRequests) ? pullRequests : []).filter(pr => typeof pr?.headRefName === 'string' && pr.headRefName.startsWith(prefix));
  if (matches.length === 0) return null;
  return matches.reduce((newest, pr) => (Number(pr.number) > Number(newest.number) ? pr : newest));
}

/**
 * `gh` arguments that convert a pull request back to draft.
 *
 * solve converts the pull request to ready-for-review when the session ends
 * (#2123/#2182). For an ordinary run that is right. For a Formal AI draft it is
 * not: #2233 asks for a *draft* pull request that is never hand-corrected and
 * merged, and GitHub refuses to merge a draft. So the workflow undoes that last
 * transition, which is also why this is a separate step and not a solve flag.
 *
 * @param {{repository: string, number: number|string}} params
 * @returns {string[]}
 */
export function keepPullRequestAsDraftArgs({ repository, number }) {
  return ['pr', 'ready', String(number), '--undo', '--repo', repository];
}

/**
 * `gh` arguments that label a draft so the batch can be found later.
 *
 * @param {{repository: string, number: number|string, label?: string}} params
 * @returns {string[]}
 */
export function labelPullRequestArgs({ repository, number, label = FORMAL_AI_DRAFT_LABEL }) {
  return ['pr', 'edit', String(number), '--add-label', label, '--repo', repository];
}

/**
 * `gh` arguments that create the draft label. No `--force`, so a label a
 * maintainer has already customised is never overwritten.
 *
 * @param {{repository: string, label?: string}} params
 * @returns {string[]}
 */
export function createDraftLabelArgs({ repository, label = FORMAL_AI_DRAFT_LABEL }) {
  return ['label', 'create', label, '--color', 'C5DEF5', '--description', 'Pull request drafted by the Formal AI draft workflow', '--repo', repository];
}

/**
 * Label a draft, creating the label the first time it is missing (#2625:
 * the repository never had it, so `gh pr edit --add-label` failed with
 * "'formal-ai-draft' not found" and no draft was ever labelled).
 *
 * @param {{gh: (args: string[]) => Promise<string>, repository: string, number: number|string}} params
 */
export async function labelDraftPullRequest({ gh, repository, number }) {
  const args = labelPullRequestArgs({ repository, number });
  try {
    await gh(args);
  } catch (error) {
    if (!/label.*not found|not found.*label|formal-ai-draft.*not found/i.test(`${error.message}\n${error.stderr || ''}`)) throw error;
    try {
      await gh(createDraftLabelArgs({ repository }));
    } catch (creationError) {
      // Another issue's simultaneous run may have created it first.
      if (!/already[ _]exists/i.test(`${creationError.message}\n${creationError.stderr || ''}`)) throw creationError;
    }
    await gh(args);
  }
}

/**
 * Render a decision as `key=value` lines for `$GITHUB_OUTPUT`.
 *
 * Newlines are stripped rather than escaped: a reason is one sentence, and a
 * multi-line value would need the heredoc form of the file format, which is one
 * more thing to get wrong for no gain.
 *
 * @param {{run: boolean, code: string, reason: string}} decision
 * @returns {string}
 */
export function formatDecisionOutputs(decision) {
  const oneLine = String(decision.reason ?? '')
    .replace(/\s+/g, ' ')
    .trim();
  return `should_run=${decision.run ? 'true' : 'false'}\ndecision_code=${decision.code}\ndecision_reason=${oneLine}\n`;
}
