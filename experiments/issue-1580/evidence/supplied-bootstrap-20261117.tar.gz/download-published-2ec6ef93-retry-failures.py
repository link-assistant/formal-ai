from pathlib import Path
source=Path('/tmp/issue-1580-research/download-published-2ec6ef93-failures.py').read_text()
source=source.replace('published-2ec6ef93\'','published-2ec6ef93/attempt-2\'')
source=source.replace("published-2ec6ef93-failures'","published-2ec6ef93-failures/attempt-2'")
source=source.replace("'--repo',repo,'--log'","'--repo',repo,'--attempt','2','--log'")
assert "'--attempt','2'" in source
exec(compile(source,__file__,'exec'))
