import subprocess
def run(args):return subprocess.run(args,capture_output=True,text=True,check=True).stdout
assert run(['git','branch','--show-current']).strip()=='issue-1580-8d61a32a61e1'
assert run(['git','rev-parse','HEAD']).strip()=='624812120feee0180bf9df8164f87e73326b5cb8'
run(['git','add','--','.github/workflows/layered-ci.yml','docs/case-studies/issue-1580','experiments/issue-1580','rust/tests/web/fast-pull-request-production-profile.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs'])
run(['git','diff','--cached','--check'])
code=['.github/workflows/layered-ci.yml','experiments/issue-1580/template-python-fragment-integrity.test.mjs','experiments/issue-1580/template-python-runtime.mjs','experiments/issue-1580/template-python-runtime.test.mjs','experiments/issue-1580/template-shared-git-observation.test.mjs','experiments/issue-1580/evidence/checks/python-runtime-provisioning','experiments/issue-1580/evidence/ci/624812120','rust/tests/web/fast-pull-request-production-profile.test.mjs','rust/tests/web/issue-1580-template-observations.test.mjs']
print(run(['git','commit','-m','fix: execute pinned Python observations in their selected CI shard','--',*code]))
print(run(['git','commit','-m','docs: retain Python review progress and filed collision report']))
assert not run(['git','status','--porcelain']).strip()
print(run(['git','rev-parse','HEAD']))
