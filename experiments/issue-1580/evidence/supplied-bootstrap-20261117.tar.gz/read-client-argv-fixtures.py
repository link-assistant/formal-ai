from pathlib import Path

for name,first,last in [('rust/tests/integration/with_formal_ai_argv.rs',1,180),('rust/tests/integration/with_formal_ai.rs',220,350),('rust/tests/integration/with_formal_ai.rs',535,585)]:
    lines=Path(name).read_text().splitlines()
    print(f'FILE {name} total={len(lines)} range={first}-{last}')
    for index in range(first-1,min(last,len(lines))):
        print(f'{index+1}: {lines[index]}')
