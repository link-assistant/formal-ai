from pathlib import Path
import subprocess
for args in [
 ['git','log','--format=%H %cI %s','444575f2ac28f609c94497865f125f99415ff6d5..origin/main'],
 ['git','diff','--stat','444575f2ac28f609c94497865f125f99415ff6d5..origin/main'],
 ['git','diff','--name-only','444575f2ac28f609c94497865f125f99415ff6d5..origin/main'],
 ['gh','run','list','--repo','link-assistant/formal-ai','--branch','main','--commit','058e9bef1214f2f1bc25971243cb787703ed64f1','--event','push','--limit','30','--json','databaseId,workflowName,status,conclusion,createdAt,headSha']]:
 print('COMMAND',args)
 text=subprocess.check_output(args,text=True)
 if args[1:3]==['diff','--name-only']:
  print('\n'.join(p for p in text.splitlines() if not any(x in p for x in ['/evidence/','/raw-data/','dev/log/'])))
 else: print(text)
