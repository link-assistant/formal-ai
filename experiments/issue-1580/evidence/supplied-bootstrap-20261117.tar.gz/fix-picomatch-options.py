from pathlib import Path
import json,hashlib,subprocess,gzip
r=Path('/tmp/gh-issue-solver-1794900398048')
p=r/'packages/picomatch-compat/lib/parse.js';s=p.read_text()
start=s.index('const hasUnboundedStar =');end=s.index('\nconst analyzeRepeatedExtglob',start)
h=s[start:end]
h=h.replace('if (escaped) {\n      escaped = false;', "if (escaped) {\n      if (ch === '*' && options.unescape === true && bracket === -1 && !quote) return true;\n      escaped = false;")
h=h.replace("!(i === bracket + 2 && pattern[bracket + 1] === '^')", "!(i === bracket + 2 && (pattern[bracket + 1] === '^' ||\n            (options.posix === true && pattern[bracket + 1] === '!')))")
p.write_text(s[:start]+h+s[end:])
p=r/'packages/picomatch-compat/upstream.json';d=json.loads(p.read_text())
for item in d['files']:
 item['localSha256']=hashlib.sha256((p.parent/item['path']).read_bytes()).hexdigest()
p.write_text(json.dumps(d,indent=2)+'\n')
p=r/'packages/picomatch-compat/README.md';s=p.read_text()
s=s.replace('bracket-class stars, ordinary globs and literal repetitions remain supported.','bracket-class stars (including POSIX negation), ordinary globs and literal\nrepetitions remain supported. With unescape:true, an escaped star that would\nbecome a raw regex quantifier is treated as risky as well.')
p.write_text(s)
p=r/'experiments/issue-1580/picomatch-parser-probe.mjs'
s=Path('/tmp/issue-1580-research/compare-picomatch-class-options.mjs').read_text()
s=s.replace("const original=require('/tmp/issue-1580-research/picomatch/package');", "if (!process.argv[2]) throw new Error('Supply the integrity-checked upstream package path');\nconst original=require(process.argv[2]);")
s=s.replace("const candidate=require('/tmp/gh-issue-solver-1794900398048/packages/picomatch-compat');","const candidate=require('../../packages/picomatch-compat');")
s=s.replace("const patterns=","// Finite subjects (at most 12 characters) and 1,092 comparisons; no stress input.\nconst patterns=")
p.write_text(s)
e=r/'experiments/issue-1580/evidence/checks/picomatch-single-branch'
args=['timeout','600','node','--max-old-space-size=96','--test','--test-concurrency=1','rust/tests/web/picomatch-security-backport.test.mjs']
cp=subprocess.run(args,cwd=r,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
raw=cp.stdout
with gzip.open(e/'option-after.log.gz','wb') as out:out.write(raw)
(e/'option-after.json').write_text(json.dumps({'command':args,'exitCode':cp.returncode,'rawSha256':hashlib.sha256(raw).hexdigest(),'autonomousAuthorshipCredit':0},indent=2)+'\n')
print(raw.decode())
raise SystemExit(cp.returncode)
