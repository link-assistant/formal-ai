from pathlib import Path
p=Path('experiments/issue-1580/capture-meaning-hydration-browser.js')
s=p.read_text();assert s.endswith('};\n');p.write_text(s[:-2]+'\n')
print('Removed the trailing expression separator required by the Playwright MCP function evaluator.')
