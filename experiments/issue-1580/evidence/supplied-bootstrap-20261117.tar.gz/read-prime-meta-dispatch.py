from pathlib import Path
import subprocess

def read(path, first, last):
    lines = Path(path).read_text().splitlines()
    print(f'FILE {path} lines {first}-{last} total={len(lines)}')
    for number in range(first, min(last, len(lines)) + 1):
        print(f'{number}: {lines[number-1]}')

read('rust/src/meta_executor/production.rs', 170, 310)
for arguments in [
    ['rg', '-n', 'solverPrimeIntervalValidation|primeIntervalValidation', 'js/worker'],
    ['git', 'diff', 'origin/main', '--', 'rust/src/solver.rs', 'rust/src/meta_executor/production.rs'],
    ['git', 'status', '--short'],
]:
    result = subprocess.run(arguments, text=True, capture_output=True)
    print('COMMAND', arguments, 'EXIT', result.returncode)
    print(result.stdout)
    print(result.stderr)
