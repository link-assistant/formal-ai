from pathlib import Path
import subprocess
for name,start,end in [('experiments/issue-1580/template-shared-git-observation.test.mjs',1,150),('scripts/select-focused-tests.mjs',1,160),('rust/tests/web/fast-pull-request-production-profile.test.mjs',1,85),('experiments/formal_ai_subagent/local-gates.mjs',1,110)]:
    lines=Path(name).read_text().splitlines();print(f'{name} ({len(lines)} lines), {start}-{end}')
    for i in range(start-1,min(end,len(lines))):print(f'{i+1}: {lines[i]}')
print(subprocess.run(['rg','-n','issue-1580|template-observations|python','data/benchmarks/fast-pull-request-javascript-tests.json','data/meta/focused-test-map.lino','scripts/select-focused-tests.mjs'],capture_output=True,text=True).stdout)
