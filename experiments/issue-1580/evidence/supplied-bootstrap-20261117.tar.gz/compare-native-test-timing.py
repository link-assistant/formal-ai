from pathlib import Path
import gzip,re
for folder,job in [('native-catalog-3c52b7f5','135813011639'),('offline-catalog-cf22c611','135851399936')]:
 ls=gzip.decompress((Path('experiments/issue-1580/evidence/ci')/folder/('job-'+job+'.stdout.gz')).read_bytes()).decode().splitlines();print(folder)
 for i,l in enumerate(ls,1):
  if any(x in l for x in ['test result:','benchmarks::','Running','Finished','operation was canceled']):print(str(i)+': '+l.split('\t',2)[-1])
