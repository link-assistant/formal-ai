from pathlib import Path
import gzip,hashlib,json,os,resource,subprocess,time
root=Path.cwd()
directory=Path('experiments/issue-1580/evidence/checks/generated-header-memory')
assert json.loads((directory/'final-gates/all-local-gates.json').read_text())['status']==0
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='issue-1580-8d61a32a61e1'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='12aff82c189eab0d2f920b0f233f2d1a868d2815'
for script in ['archive-round-bootstrap.py','archive-evidence.py']:
 print(subprocess.check_output(['python3','/tmp/issue-1580-research/'+script],text=True).strip())
env=dict(os.environ);env['NODE_OPTIONS']='--max-old-space-size=256'
command=['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-file-size,check-abbreviations,check-readable-code']
started=time.time()
p=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
raw=p.stdout;(directory/'final-documentation-gates.log.gz').write_bytes(gzip.compress(raw,mtime=0))
record={'command':command,'status':p.returncode,'durationSeconds':round(time.time()-started,3),'rawSha256':hashlib.sha256(raw).hexdigest(),'log':'final-documentation-gates.log.gz','nodeHeapMiB':256,'rustBuildsEnabled':False,'independentAuthorshipCredit':0}
(directory/'final-documentation-gates.json').write_text(json.dumps(record,indent=2)+'\n')
print(raw.decode());assert p.returncode==0
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--','docs/case-studies/issue-1580','experiments/issue-1580/work-plan.md','experiments/issue-1580/upstream/python-release-formatting-report.md','experiments/issue-1580/evidence'],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','docs: preserve complete merged-source gate results and review evidence'],stdout=subprocess.PIPE,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
print('HEAD',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
print(json.dumps(record))
