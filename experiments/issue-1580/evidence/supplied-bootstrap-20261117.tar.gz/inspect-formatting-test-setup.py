from pathlib import Path
import json

for name in ['/tmp/issue-1580-research/run-audit-focused.py','/tmp/issue-1580-research/run-audit-gates.py','experiments/issue-1580/template-python-fragment-integrity.test.mjs']:
    lines=Path(name).read_text().splitlines()
    print(f'FILE {name} ({len(lines)} lines)')
    assert len(lines)<200
    print('\n'.join(f'{n}: {line}' for n,line in enumerate(lines,1)))
source=Path('/tmp/issue-1580-research/templates/python-complete/scripts/release_naming.py').read_text().splitlines()
print('FILE release_naming.py 65-104')
print('\n'.join(f'{n}: {line}' for n,line in enumerate(source,1) if n>=65))
