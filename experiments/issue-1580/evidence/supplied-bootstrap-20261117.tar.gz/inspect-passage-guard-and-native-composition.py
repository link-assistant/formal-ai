from pathlib import Path
import subprocess
p=Path('js/worker/formal_ai_worker_factual_qa.js');lines=p.read_text().splitlines()
print('SOURCE',str(p),'LINES',len(lines),'RANGE 392-490')
for i in range(391,min(490,len(lines))):print(str(i+1)+': '+lines[i])
for args in [
 ['rg','-n','independent_questions|independent questions|solve_compound|solve_independent|prompt_text_question','rust/src'],
 ['rg','-n','worker_solve|9ee18ccde5','data/meta/runtime-feature-coverage.json'],
]:
    r=subprocess.run(args,text=True,capture_output=True);print('COMMAND',args,'EXIT',r.returncode);print(r.stdout,r.stderr)
