from pathlib import Path
import gzip,subprocess

base=Path('experiments/issue-1580/evidence/checks/child-evidence-provenance')
for name in ['check_js_rust_translation','check-abbreviations']:
    source=Path('experiments/formal_ai_subagent/sandboxes/gates')/(name+'.log')
    raw=source.read_bytes()
    target=base/('gate-detail-'+name.replace('_','-')+'.log.gz')
    assert not target.exists()
    target.write_bytes(gzip.compress(raw,mtime=0))
    print('\nFILE',source,'LINES',len(raw.splitlines()))
    assert len(raw.splitlines())<=1500
    print(raw.decode())
result=subprocess.run(['rg','-n','witness|fingerprint|manifest|refresh|write','scripts/check-js-rust-translation.mjs','experiments/issue-1580/governed-manifest-refresh.mjs'],capture_output=True,text=True)
print(result.stdout);print(result.stderr)
for path in sorted(Path('/tmp/issue-1580-research').glob('*')):
    if path.is_file() and any(word in path.name for word in ['witness','translation','governed']):print('CANDIDATE',path)
