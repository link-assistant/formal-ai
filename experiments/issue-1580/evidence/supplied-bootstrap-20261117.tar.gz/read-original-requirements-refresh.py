from pathlib import Path
import gzip,json
p=Path('/tmp/issue-1580-research/header-round-preflight')
for name in ['feedback-issue','feedback-issue-comments']:
 data=json.loads(gzip.decompress((p/(name+'.json.gz')).read_bytes()))
 for row in data if isinstance(data,list) else [data]:
  body=row['body'];lines=body.splitlines()
  print('\nITEM',row.get('html_url'),len(lines),'lines')
  if len(lines)>1500:raise RuntimeError('chunk required')
  print('\n'.join(f'{i}: {line}' for i,line in enumerate(lines,1)))
