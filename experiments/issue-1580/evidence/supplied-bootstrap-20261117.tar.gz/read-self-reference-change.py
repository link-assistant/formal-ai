from pathlib import Path
root=Path('/tmp/gh-issue-solver-1794900398048')
for name in ['experiments/issue-1580/trace-template-ci.mjs','experiments/issue-1580/template-reference-graph.test.mjs']:
    p=root/name
    print('FILE '+name)
    for n,line in enumerate(p.read_text().splitlines(),1): print(f'{n}: {line}')
for name in ['archive-round-bootstrap.py','check-eighth-archive-size.sh','check-self-references-after.sh']:
    print('BOOTSTRAP '+name+'\n'+(Path('/tmp/issue-1580-research')/name).read_text())
print('GRAPH DELTA\n'+Path('/tmp/issue-1580-research/self-reference-checks/graph-delta.json').read_text())
