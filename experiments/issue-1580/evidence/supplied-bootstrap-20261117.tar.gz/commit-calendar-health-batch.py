from pathlib import Path
import gzip,hashlib,json,subprocess,sys
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
def run(args,**kwargs):return subprocess.run(args,cwd=root,check=True,**kwargs)
assert subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()=='issue-1580-8d61a32a61e1'
path=root/'docs/case-studies/issue-1580/README.md';text=path.read_text()
old='Full current-source gates and next-head hosted checks remain pending. Native\nruntime, general recursive context binding and all broader acceptance remain'
new='The final combined-source gates pass 86 checks with 52 explicit exclusions and\nzero failures; all 86 detailed logs and 14 source hashes are verified. All 24\nhealth/cache fixture tests also pass without transport calls. Next-head hosted\nchecks remain pending. Native runtime, general recursive context binding and\nall broader acceptance remain'
assert old in text;path.write_text(text.replace(old,new))
path=root/'experiments/issue-1580/work-plan.md';text=path.read_text();text+='\nFinal archive/changelog checks pass all six selected gates, with the filename\nabbreviation ceiling unchanged. Preserve the full command and supplied-script\narchives, commit this verified batch, and inspect every hosted result on the new\nhead before another push. The PR remains draft; broad acceptance is unfinished.\n';path.write_text(text)
run([sys.executable,str(scratch/'archive-round-bootstrap.py')])
run([sys.executable,str(scratch/'archive-evidence.py')])
run(['git','diff','--check'])
run(['git','merge-base','--is-ancestor','origin/main','HEAD'])
gate=root/'experiments/issue-1580/evidence/checks/health-cache-fixtures/all-gates-final/all-local-gates.json'
receipt=json.loads(gate.read_text());assert receipt['exitCode']==0
for name,digest in receipt['sourceFiles'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for state in ['in_progress','queued']:
 args=['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--status',state,'--limit','100','--json','databaseId,workflowName,headSha']
 data=subprocess.check_output(args,cwd=root,text=True);(scratch/f'calendar-health-precommit-{state}.json').write_text(data);assert json.loads(data)==[],data
run(['git','add','changelog.d/20261117_120000_issue-1580-ci-regressions.md','data/benchmarks/fast-pull-request-javascript-tests.json','data/meta/main-only-regressions.lino','data/seed/handler-rules.lino','data/seed/meanings-calendar.lino','docs/case-studies/issue-1580','experiments/issue-1580','js/worker/formal_ai_worker_calendar_offset.js','rust/embedded/data/seed/handler-rules.lino','rust/embedded/data/seed/meanings-calendar.lino','rust/src/solver_handlers/calculator_rate.rs','rust/src/solver_handlers/calendar/month.rs','rust/tests/web/fast-pull-request-production-profile.test.mjs','rust/tests/web/hive-work-item-consumer.test.mjs','rust/tests/web/issue-1168-source-cache.test.mjs','rust/tests/web/issue-1589-calendar-currency.test.mjs','rust/tests/web/server-memory-schema.test.mjs','ts/worker/formal_ai_worker_calendar_and_proofs.ts','ts/worker/formal_ai_worker_calendar_offset.ts'])
run(['git','diff','--cached','--check'])
log=scratch/'calendar-health-commit.log'
with log.open('wb') as stream:result=subprocess.run(['git','commit','-m','Fix calendar seed integrity and offline CI regression fixtures'],cwd=root,stdout=stream,stderr=subprocess.STDOUT)
print(json.dumps({'commitExitCode':result.returncode,'commitLog':str(log)}))
if result.returncode:print(log.read_text());raise SystemExit(result.returncode)
print(subprocess.check_output(['git','log','-1','--format=%H %s'],cwd=root,text=True).strip())
status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
print(json.dumps({'remainingWorkingTree':status,'archivedRecordsDoNotClaimIndependentAuthorship':True}))
