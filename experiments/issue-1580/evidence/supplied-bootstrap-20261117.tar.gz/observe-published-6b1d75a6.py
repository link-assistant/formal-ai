from pathlib import Path
import collections,datetime,gzip,hashlib,json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');base=root/'experiments/issue-1580/evidence/ci/published-6b1d75a6';base.mkdir(exist_ok=True)
head='6b1d75a62a610e58914ef594c107f3fa402ded9d'
def query(args):return json.loads(subprocess.check_output(args,cwd=root,text=True))
rows=query(['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1580-8d61a32a61e1','--limit','100','--json','databaseId,workflowName,status,conclusion,createdAt,headSha,updatedAt'])
rows=[row for row in rows if row['headSha']==head];assert len(rows)>=23
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
jobs=[]
for row in rows:
 if row['workflowName'] not in ['Layered CI','CI/CD Pipeline']:continue
  
 value=query(['gh','run','view',str(row['databaseId']),'--repo','link-assistant/formal-ai','--json','databaseId,headSha,status,conclusion,attempt,jobs,url'])
 assert value['headSha']==head;jobs.append(value)
value={'observedAt':stamp,'head':head,'runs':rows,'details':jobs,'independentAuthorshipCredit':0}
raw=(json.dumps(value,indent=2)+'\n').encode();target=base/f'observation-{stamp}.json.gz';target.write_bytes(gzip.compress(raw,mtime=0))
print(json.dumps({'head':head,'runs':len(rows),'states':dict(collections.Counter(row['conclusion'] or row['status'] for row in rows)),'observation':str(target.relative_to(root)),'rawSha256':hashlib.sha256(raw).hexdigest()}))
for value in jobs:
 print(json.dumps({'run':value['databaseId'],'status':value['status'],'conclusion':value['conclusion'],'attempt':value['attempt'],'jobs':dict(collections.Counter(job['conclusion'] or job['status'] for job in value['jobs'])),'nonpassing':[{key:job[key] for key in ['databaseId','name','status','conclusion']} for job in value['jobs'] if job['conclusion'] not in ['success','skipped']]}))
