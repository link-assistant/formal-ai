import gzip
import hashlib
import json
import pathlib
import subprocess
result=subprocess.run(['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1580','--json','title,body,url,updatedAt'],capture_output=True,check=True)
value=json.loads(result.stdout)
base=pathlib.Path('experiments/issue-1580/evidence/ci/checkpoint-7780c707-final')
(base/'issue.json.gz').write_bytes(gzip.compress(result.stdout,mtime=0))
target=pathlib.Path('/tmp/issue-1580-research/current-issue-requirements.md')
target.write_text(value['body'])
print(json.dumps({key:value[key] for key in ['title','url','updatedAt']}))
print('body lines',len(value['body'].splitlines()),'sha256',hashlib.sha256(result.stdout).hexdigest())
for number,line in enumerate(value['body'].splitlines(),1):
    if number<=85: print(f'{number}: {line}')
