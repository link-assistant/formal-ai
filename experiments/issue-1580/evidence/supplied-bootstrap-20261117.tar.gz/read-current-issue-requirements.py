from pathlib import Path
import hashlib, json

base=Path('/tmp/issue-1580-research/picomatch-push-preflight')
issue=json.loads((base/'issue.json').read_text())
print(issue['title'],issue['url'],issue['updatedAt'])
for index,line in enumerate(issue['body'].splitlines(),1): print(f'{index}: {line}')
print('\nFEEDBACK IDENTITIES')
for name in ['issue-comments','pull-conversation','pull-inline','pull-reviews']:
    pages=json.loads((base/(name+'.json')).read_text())
    for item in [item for page in pages for item in page]:
        body=item.get('body','')
        print(name,item.get('id'),item.get('updated_at'),item.get('html_url'),'bodySha256',hashlib.sha256(body.encode()).hexdigest())
print('\nPR BODY')
print(json.loads((base/'pull-request.json').read_text())['body'])
print('\nABBREVIATION FAILURE')
print(Path('/tmp/gh-issue-solver-1794900398048/experiments/formal_ai_subagent/sandboxes/gates/check-abbreviations.log').read_text())
