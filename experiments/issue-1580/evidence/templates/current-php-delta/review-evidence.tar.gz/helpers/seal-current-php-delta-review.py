from pathlib import Path
import json,gzip,hashlib,re,subprocess,io,tarfile,os
root=Path('/tmp/gh-issue-solver-1794900398048');scratch=Path('/tmp/issue-1580-research')
base=scratch/'fresh-template-delta-sources';checks=scratch/'current-php-focused-checks'
inventory=json.loads((base/'inventory.json').read_text());pages=json.loads((base/'pages.json').read_text())
files=[x for x in inventory['files'] if x['language']=='php'];assert len(files)==19
tree=next(x for x in inventory['trees'] if x['language']=='php');assert tree['blobs']==608
assert tree['head']=='b61e334703d93a15e08bf1a278e0df0a9d6e98a8'
decisions={
 '.github/workflows/docs.yml':(['.github/workflows/release.yml'],'Artifact generation is independent of Pages activation; main emits a notice when deployment is not opted in. Formal AI retains strict served-content verification as a separate open acceptance criterion.'),
 '.github/workflows/release.yml':(['.github/workflows/release.yml'],'Every automatic release prerequisite is explicitly successful before publication. This applies the previously reported guard repair; all read-only checkout steps disable persistent credentials and writer checkouts retain their narrow role.'),
 '.github/workflows/security.yml':(['.github/workflows/security.yml'],'Current security tooling pins and read-only checkout handling are reviewed. No upstream CodeQL execution or live registry audit is inferred from this file.'),
 '.github/workflows/templates.yml':(['AGENTS.md'],'All four captured source subtrees remain active upstream CI inputs. Their native builds are not copied into the local JavaScript PR lane, which forbids full local Rust builds.'),
 'CHANGELOG.md':(['changelog.d/20261121_072500_scanner_budget_annotations.md'],'The release history identifies accepted Pages, change-detection, automatic release and publication repairs. Formal AI retains its own fragment-driven release trigger.'),
 'CONTRIBUTING.md':(['CONTRIBUTING.md'],'Use explicit failure propagation, disposable release fixtures and prerequisite status checks. Template statements about an entirely PHP pipeline do not erase the Bash and JavaScript wrappers actually present.'),
 'README.md':(['README.md'],'The current template uses PHP 8.5 and PHPUnit 13; old PHP/PHPStan descriptions are not authority for current tool support. The linked application image was downloaded, verified as PNG and viewed.'),
 'composer.json':(['Cargo.toml','bun.lock'],'The PHP-specific dependency manifest and test commands are reviewed for the focused upstream checks. No PHP dependencies are added to Formal AI.'),
 'composer.lock':(['bun.lock'],'All 4774 lines were read, including exact package references, PHP >=8.5 platform and Composer 2.11 plugin API. A separate scratch lock pins the 26 packages needed only for PHPUnit; the full template dependency suite was not installed.'),
 'docs/BEST-PRACTICES.md':(['AGENTS.md','CONTRIBUTING.md'],'Strict link failures, bounded retries and reusable checks are applicable. Archive suggestions do not satisfy unresolved live links; broad native rebuilds conflict with the local single-push and fast-check rules.'),
 'docs/index.md':(['.github/workflows/release.yml'],'Documentation distinguishes artifact availability from explicit Pages activation. Actual served identity and the fallback publication path remain open locally.'),
 'scripts/detect-code-changes.php':(['scripts/detect-code-changes.rs'],'The CLI catches runtime failures and exits nonzero without successful change outputs. Current malformed-ref and missing-history cases pass with the actual PHP implementation.'),
 'scripts/src/ChangeDetector.php':(['scripts/detect-code-changes.rs'],'40/64-hex refs and checked Git commands distinguish PR triple-dot, push before/after and zero-ref initial trees. Missing shallow ancestry fails; NUL path parsing retains control-character filenames.'),
 'scripts/src/Git.php':(['scripts/version-and-commit.rs'],'Both branch and tag publication now use mustRun, resolving the earlier unchecked Process::run finding at this pin. Real disposable repositories test rejection propagation.'),
 'scripts/src/VersionReleaser.php':(['scripts/version-and-commit.rs'],'Manifest changes refresh an existing Composer lock before staging both files. Both publication modes fail rejected branch/tag pushes. The focused tests use disposable local remotes and do not publish externally.'),
 'scripts/version-and-commit.php':(['scripts/version-and-commit.rs'],'Runtime failures become a nonzero CLI result before version_committed=true. The maintained upstream tests execute the actual entry point in isolated copies.'),
 'tests/Pipeline/ChangeDetectorTest.php':(['rust/tests/web/issue-1580-template-observations.test.mjs'],'Actual current PHP execution passes 8 tests and 45 assertions for ref validation, missing history, initial trees and escaped filenames.'),
 'tests/Pipeline/VersionReleaserTest.php':(['rust/tests/web/issue-1580-template-observations.test.mjs'],'Actual current PHP execution passes 9 tests and 228 assertions, retaining successful releases while rejecting branch and tag pushes and refreshing a lock.'),
 'tests/Pipeline/WorkflowPolicyTest.php':(['rust/tests/web/issue-1580-template-observations.test.mjs'],'Actual current PHP execution passes 26 tests and 378 assertions for automatic prerequisite guards, read-only credentials and independent docs artifacts. These source-policy checks do not prove a live hosted publication.'),
}
rows=[]
for item in files:
 data=Path(item['source']).read_bytes();assert hashlib.sha256(data).hexdigest()==item['sha256']
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+bytes([0])+data).hexdigest()==item['gitBlob']
 targets,decision=decisions[item['path']];existing=[p for p in targets if (root/p).exists()];assert existing,(item['path'],targets)
 rows.append({k:item[k] for k in ['path','gitBlob','sha256','bytes','lines']}|{'completeContentComparison':True,'completeLiteralSourceRead':True,'readPages':[p['page'] for p in pages if p['language']=='php' and p['path']==item['path']],'formalAiComparison':existing,'decision':decision})
counts=[('ChangeDetectorTest.php.log',8,45),('VersionReleaserTest.php.log',9,228),('WorkflowPolicyTest.php.log',26,378)]
for name,tests,assertions in counts:assert f'OK ({tests} tests, {assertions} assertions)' in (checks/name).read_text()
assert json.loads((checks/'outcome.json').read_text())['allPassed']
validation=subprocess.run(['php','-d','memory_limit=128M',str(checks/'tools/composer.phar'),'validate','--strict','--no-check-publish'],cwd=checks/'source',capture_output=True)
(checks/'current-manifest-validation.stdout').write_bytes(validation.stdout);(checks/'current-manifest-validation.stderr').write_bytes(validation.stderr)
ledger={'repository':'link-foundation/php-ai-driven-development-pipeline-template','commit':tree['head'],'currentBlobCount':608,'scope':'Nineteen changed current files only. Unchanged and historical full-template comparison remains open.','completeChangedFileComparison':True,'completeCurrentSourceComparison':False,'completeTemplateAcceptance':False,'files':rows,'removedPaths':[x['path'] for x in inventory['removed'] if x['language']=='php'],'verification':{'focusedTestsPassed':43,'focusedAssertionsPassed':651,'testFiles':3,'runtime':'PHP 8.5.11','phpunit':'13.4.7','composer':'2.11.2','phpMemoryLimitMiB':128,'verifiedFixtureFiles':57,'currentManifestValidationExitCode':validation.returncode,'fullTemplateDependencySuiteInstalled':False,'fullTemplateSuiteExecuted':False,'livePublicationVerified':False,'logs':[{'file':n,'tests':t,'assertions':a} for n,t,a in counts]},'relatedWork':{'pullRequests':[30,24,22,21,19],'allConversationInlineAndReviewCommentsRead':True,'upstreamHostedSuccessStatementsAreAttributed':True,'earlierFindingsResolvedAtCurrentPin':[25,26,27,28],'imageViewed':'https://github.com/link-foundation/php-ai-driven-development-pipeline-template/blob/b61e334703d93a15e08bf1a278e0df0a9d6e98a8/docs/screenshots/example-app.png'},'openObservations':['Process drains stdout before stderr; a bounded concurrent-pipe reproduction is still needed before treating this as a confirmed defect.','Complete 608-file practice adoption and historical coverage remain incomplete.'],'independentAuthorshipCredit':0}
target=root/'experiments/issue-1580/evidence/templates/current-php-delta';assert not target.exists();target.mkdir(parents=True)
sources=[(Path(x['source']),'sources/'+x['path']) for x in files]
sources +=[(p,'checks/'+p.name) for p in checks.iterdir() if p.is_file() and p.suffix in ['.log','.json','.txt','.stdout','.stderr']]
sources +=[(p,'fixture/'+p.relative_to(checks/'source').as_posix()) for p in (checks/'source').rglob('*') if p.is_file()]
sources +=[(checks/'tools/runtime/composer.lock','tools/phpunit-runtime.lock')]
sources +=[(scratch/n,'helpers/'+n) for n in ['prepare-current-php-focused-checks.py','retry-current-php-focused-checks.py','fetch-current-php-related-work.py','seal-current-php-delta-review.py']]
records=[];buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
 for source,name in sources:
  data=source.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data));records.append({'source':str(source),'archiveMember':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(target/'review-evidence.tar.gz').write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
(target/'manifest.json').write_text(json.dumps({'records':records,'literalCurrentChangedFilesRead':19,'fullCurrentTemplateRead':False,'independentAuthorshipCredit':0},indent=2)+'\n')
path=root/'docs/case-studies/issue-1580/templates/php-current-delta-review.json';path.write_text(json.dumps(ledger,indent=2)+'\n')
with (root/'experiments/issue-1580/work-plan.md').open('a') as file:file.write('''

## PHP current-template delta at b61e3347

- [x] Read all 19 changed files in pages 110–143, including all 4774 lock lines,
  and all comment types for five recent merged PRs. Current inventory: 608 blobs.
- [x] Verify current Git blob identities for 57 focused fixture files; execute
  actual PHP 8.5.11/PHPUnit 13.4.7 checks: 43 tests, 651 assertions, sequentially
  with a 128 MiB PHP limit. Retain the initial missing Composer and checksum
  transport failures separately. No remote release or full native build occurs.
- [x] Reconcile the earlier Pages, change-detection, prerequisite and unchecked
  push findings with their applied upstream repairs at the current pin.
- [ ] Complete unchanged/historical files and all applicable practice acceptance;
  investigate the sequential Process pipe reads with a bounded control.
''')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--',str(target.relative_to(root)),str(path.relative_to(root)),'experiments/issue-1580/work-plan.md'],cwd=root,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
subprocess.run(['git','commit','-m','docs: verify current PHP template release repairs'],cwd=root,check=True)
print(json.dumps({'records':len(records),'changedFilesRead':19,'testsPassed':43,'assertionsPassed':651,'manifestValidationExitCode':validation.returncode,'completeTemplateAcceptance':False,'pushExecuted':False}))
