from pathlib import Path
import json,subprocess,textwrap
base=Path('/tmp/issue-1580-research/current-php-focused-checks');base.mkdir(exist_ok=True)
repo='link-foundation/php-ai-driven-development-pipeline-template'
args=['gh','pr','list','--repo',repo,'--state','merged','--limit','5','--json','number,url,title,body,mergedAt,headRefOid']
result=subprocess.run(args,capture_output=True,text=True)
(base/'related-merged-prs.json').write_text(result.stdout);assert result.returncode==0,result.stderr
prs=json.loads(result.stdout);lines=[]
for pr in prs:
    lines+=['PULL REQUEST '+str(pr['number'])+' '+pr['url'],'TITLE '+pr['title'],'MERGED '+pr['mergedAt'],'HEAD '+pr['headRefOid']]
    for line in pr['body'].splitlines():lines.extend(textwrap.wrap(line,width=160) or [''])
    for label,endpoint in [('conversation',f"issues/{pr['number']}/comments"),('inline',f"pulls/{pr['number']}/comments"),('reviews',f"pulls/{pr['number']}/reviews")]:
        response=subprocess.run(['gh','api',f'repos/{repo}/{endpoint}','--paginate'],capture_output=True,text=True)
        (base/f"pr-{pr['number']}-{label}.json").write_text(response.stdout)
        assert response.returncode==0,response.stderr
        rows=json.loads(response.stdout);lines.append(label.upper()+' COUNT '+str(len(rows)))
        for row in rows:
            lines.append(json.dumps({k:row.get(k) for k in ['id','html_url','state','created_at','submitted_at','path','line']}))
            for line in (row.get('body') or '').splitlines():lines.extend(textwrap.wrap(line,width=160) or [''])
(base/'related-work-review.txt').write_text('\n'.join(lines)+'\n')
for command in [['php','--version'],['composer','--version']]:
    result=subprocess.run(command,capture_output=True,text=True)
    print(json.dumps({'argv':command,'exitCode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}))
print(json.dumps({'reviewFile':str(base/'related-work-review.txt'),'lines':len(lines),'pullRequests':[p['number'] for p in prs]}))
