from pathlib import Path
import base64,hashlib,json,os,re,subprocess,urllib.request
base=Path('/tmp/issue-1580-research/current-php-focused-checks');work=base/'source';work.mkdir(exist_ok=True)
repo='link-foundation/php-ai-driven-development-pipeline-template';head='b61e334703d93a15e08bf1a278e0df0a9d6e98a8'
result=subprocess.run(['gh','api',f'repos/{repo}/git/trees/{head}?recursive=1'],capture_output=True)
(base/'current-tree.json').write_bytes(result.stdout);assert result.returncode==0,result.stderr
tree=json.loads(result.stdout);assert not tree['truncated'];rows=[]
for entry in tree['tree']:
    name=entry['path']
    if entry['type']!='blob' or not (name.startswith(('.github/','scripts/')) or name in ['tests/Pipeline/ChangeDetectorTest.php','tests/Pipeline/VersionReleaserTest.php','tests/Pipeline/WorkflowPolicyTest.php','composer.json','composer.lock']):continue
    candidates=[Path('/tmp/issue-1580-research/fresh-template-delta-sources/files/php')/name,Path('/tmp/issue-1580-research/templates/php-complete')/name]
    raw=None
    for candidate in candidates:
        if candidate.is_file():
            data=candidate.read_bytes();identity=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            if identity==entry['sha']:raw=data;break
    if raw is None:
        response=subprocess.run(['gh','api',f"repos/{repo}/git/blobs/{entry['sha']}"],capture_output=True)
        assert response.returncode==0,response.stderr
        raw=base64.b64decode(json.loads(response.stdout)['content'])
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==entry['sha']
    target=work/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    rows.append({'path':name,'gitBlob':entry['sha'],'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
tools=base/'tools';tools.mkdir(exist_ok=True);downloads=[]
for name,url,checksum in [('composer.phar','https://getcomposer.org/download/2.11.2/composer.phar','https://getcomposer.org/download/2.11.2/composer.phar.sha256sum'),('phpunit.phar','https://phar.phpunit.de/phpunit-13.4.7.phar','https://phar.phpunit.de/phpunit-13.4.7.phar.sha256')]:
    with urllib.request.urlopen(checksum) as response:expected=response.read(2049)
    assert len(expected)<=2048
    (tools/(name+'.checksum')).write_bytes(expected)
    match=re.search(rb'\b[0-9a-f]{64}\b',expected);assert match,expected
    with urllib.request.urlopen(url) as response:raw=response.read(16*1024*1024+1)
    assert len(raw)<=16*1024*1024
    assert hashlib.sha256(raw).hexdigest()==match.group().decode()
    (tools/name).write_bytes(raw)
    downloads.append({'name':name,'url':url,'checksumUrl':checksum,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
(tools/'composer').write_text('#!/bin/sh\nexec php -d memory_limit=128M '+str(tools/'composer.phar')+' "$@"\n');(tools/'composer').chmod(0o755)
(base/'fixture-manifest.json').write_text(json.dumps({'head':head,'treeBlobs':sum(e['type']=='blob' for e in tree['tree']),'files':rows,'tools':downloads},indent=2)+'\n')
environment={**os.environ,'PATH':str(tools)+os.pathsep+os.environ['PATH'],'COMPOSER_ALLOW_SUPERUSER':'1','COMPOSER_CACHE_DIR':str(base/'composer-cache'),'COMPOSER_NO_INTERACTION':'1','GIT_TERMINAL_PROMPT':'0'}
results=[]
for filename in ['ChangeDetectorTest.php','VersionReleaserTest.php','WorkflowPolicyTest.php']:
    args=['php','-d','memory_limit=128M',str(tools/'phpunit.phar'),'--no-configuration','--bootstrap','scripts/bootstrap.php','tests/Pipeline/'+filename]
    with (base/(filename+'.log')).open('w') as log:result=subprocess.run(args,cwd=work,env=environment,stdout=log,stderr=subprocess.STDOUT)
    results.append({'argv':args,'exitCode':result.returncode,'log':filename+'.log'})
    print(json.dumps(results[-1]),flush=True)
(base/'outcome.json').write_text(json.dumps({'results':results,'finished':True,'allPassed':all(r['exitCode']==0 for r in results),'fullIssueComplete':False},indent=2)+'\n')
print(json.dumps({'files':len(rows),'tools':downloads,'fullIssueComplete':False}))
