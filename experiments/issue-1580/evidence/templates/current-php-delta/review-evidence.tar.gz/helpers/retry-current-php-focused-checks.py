from pathlib import Path
import hashlib,json,os,subprocess
base=Path('/tmp/issue-1580-research/current-php-focused-checks');tools=base/'tools';work=base/'source'
expected=(base/'composer-checksum-curl.stdout').read_text().split()[0]
url='https://getcomposer.org/download/2.11.2/composer.phar'
args=['curl','--location','--fail-with-body','--silent','--show-error','--max-filesize','16777216','--output',str(tools/'composer.phar'),url]
with (base/'composer-download.log').open('w') as log:result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0
raw=(tools/'composer.phar').read_bytes();assert hashlib.sha256(raw).hexdigest()==expected
(tools/'composer').write_text('#!/bin/sh\nexec php -d memory_limit=128M '+str(tools/'composer.phar')+' "$@"\n');(tools/'composer').chmod(0o755)
environment={**os.environ,'PATH':str(tools)+os.pathsep+os.environ['PATH'],'COMPOSER_ALLOW_SUPERUSER':'1','COMPOSER_MEMORY_LIMIT':'128M','COMPOSER_CACHE_DIR':str(base/'composer-cache'),'COMPOSER_NO_INTERACTION':'1','GIT_TERMINAL_PROMPT':'0'}
runtime=tools/'runtime';runtime.mkdir(exist_ok=True)
(runtime/'composer.json').write_text(json.dumps({'name':'fixture/current-php-checks','require-dev':{'phpunit/phpunit':'13.4.7'}},indent=2)+'\n')
args=['php','-d','memory_limit=128M',str(tools/'composer.phar'),'install','--no-interaction','--prefer-dist','--no-progress','--no-scripts','--no-plugins']
with (base/'phpunit-install.log').open('w') as log:result=subprocess.run(args,cwd=runtime,env=environment,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0
tree=json.loads((base/'current-tree.json').read_text());entries={e['path']:e for e in tree['tree'] if e['type']=='blob'};files=[]
for path in sorted(work.rglob('*')):
    if not path.is_file():continue
    name=path.relative_to(work).as_posix();data=path.read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==entries[name]['sha']
    files.append({'path':name,'gitBlob':entries[name]['sha'],'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
(base/'fixture-manifest.json').write_text(json.dumps({'head':'b61e334703d93a15e08bf1a278e0df0a9d6e98a8','files':files,'composer':{'url':url,'sha256':expected,'bytes':len(raw)},'testDependencyLock':'tools/runtime/composer.lock','installedFullTemplateDependencies':False},indent=2)+'\n')
results=[]
for filename in ['ChangeDetectorTest.php','VersionReleaserTest.php','WorkflowPolicyTest.php']:
    args=['php','-d','memory_limit=128M',str(runtime/'vendor/bin/phpunit'),'--no-configuration','--bootstrap','scripts/bootstrap.php','tests/Pipeline/'+filename]
    with (base/(filename+'.log')).open('w') as log:result=subprocess.run(args,cwd=work,env=environment,stdout=log,stderr=subprocess.STDOUT)
    results.append({'argv':args,'exitCode':result.returncode,'log':filename+'.log'});print(json.dumps(results[-1]),flush=True)
(base/'outcome.json').write_text(json.dumps({'results':results,'finished':True,'allPassed':all(r['exitCode']==0 for r in results),'fullIssueComplete':False},indent=2)+'\n')
print(json.dumps({'files':len(files),'checks':len(results),'allPassed':all(r['exitCode']==0 for r in results),'fullIssueComplete':False}))
