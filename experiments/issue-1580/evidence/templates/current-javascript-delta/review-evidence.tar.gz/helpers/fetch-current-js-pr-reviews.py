from pathlib import Path
import json,subprocess,textwrap
base=Path('/tmp/issue-1580-research/current-js-focused-checks')
prs=json.loads((base/'related-merged-prs.json').read_text())
lines=[]
for pr in prs:
    lines+=['PULL REQUEST '+str(pr['number'])+' '+pr['url'],'TITLE '+pr['title'],'MERGED '+pr['mergedAt'],'HEAD '+pr['headRefOid']]
    for line in pr['body'].splitlines():lines.extend(textwrap.wrap(line,width=160) or [''])
    for label,endpoint in [('conversation',f"issues/{pr['number']}/comments"),('inline',f"pulls/{pr['number']}/comments"),('reviews',f"pulls/{pr['number']}/reviews")]:
        args=['gh','api',f'repos/link-foundation/js-ai-driven-development-pipeline-template/{endpoint}','--paginate']
        result=subprocess.run(args,capture_output=True,text=True)
        (base/f"pr-{pr['number']}-{label}.json").write_text(result.stdout)
        assert result.returncode==0,result.stderr
        rows=json.loads(result.stdout)
        lines.append(label.upper()+' COUNT '+str(len(rows)))
        for row in rows:
            lines.append(json.dumps({k:row.get(k) for k in ['id','html_url','state','created_at','submitted_at','path','line']}))
            for line in (row.get('body') or '').splitlines():lines.extend(textwrap.wrap(line,width=160) or [''])
path=base/'related-work-review.txt'
path.write_text('\n'.join(lines)+'\n')
inventory=json.loads(Path('/tmp/issue-1580-research/fresh-template-delta-sources/inventory.json').read_text())
print(json.dumps({'reviewFile':str(path),'lines':len(lines),'pullRequests':[p['number'] for p in prs],'removed':[r for r in inventory['removed'] if r.get('language')=='js']},indent=2))
