from pathlib import Path
import subprocess,json,time
root=Path('/tmp/gh-issue-solver-1794900398048')
base=Path('/tmp/issue-1580-research/budget-annotation-boundaries')
commands=[['node','--max-old-space-size=256','--test','--test-concurrency=1','experiments/issue-1580/budget-annotation-boundaries.test.mjs'],['node','--max-old-space-size=256','--test','--test-concurrency=1','rust/tests/web/issue-1580-template-observations.test.mjs'],['bash','-n','scripts/run-with-budget-warning.sh']]+[['node','experiments/formal_ai_subagent/local-gates.mjs','--only',gate] for gate in ['check-abbreviations','check-file-size','check-readable-code']]+[['git','diff','--check']]
results=[]
for i,args in enumerate(commands,1):
 start=time.monotonic()
 with (base/f'after-{i:02}.log').open('w') as log:result=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 row={'argv':args,'exitCode':result.returncode,'seconds':round(time.monotonic()-start,3),'log':f'after-{i:02}.log'}
 results.append(row);print(json.dumps(row),flush=True)
 (base/'outcome.json').write_text(json.dumps({'results':results,'finished':len(results)==len(commands),'allChecksPassed':len(results)==len(commands) and all(r['exitCode']==0 for r in results),'fullIssueComplete':False},indent=2)+'\n')
