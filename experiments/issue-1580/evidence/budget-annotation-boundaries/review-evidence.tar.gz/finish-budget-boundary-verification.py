from pathlib import Path
import subprocess,json
root=Path('/tmp/gh-issue-solver-1794900398048');base=Path('/tmp/issue-1580-research/budget-annotation-boundaries')
assert json.loads((base/'outcome.json').read_text())['finished']
path=root/'experiments/issue-1580/budget-annotation-boundaries.test.mjs';source=path.read_text()
old="  const result = run('1', \"process.stderr.write('partial child stderr');setInterval(()=>{},1000)\");\n  assert.equal(result.status, 124, result.stderr);\n  assert.match(result.stderr, /^::warning title=/mu);"
new="  const result = run('1', \"process.stderr.write('partial child stderr');setInterval(()=>{},1000)\",\n    {TEST_WARN_RATIO_PERCENT: '1000'});\n  assert.equal(result.status, 124, result.stderr);\n  assert.doesNotMatch(result.stderr, /::warning/u);"
assert source.count(old)==1;source=source.replace(old,new);path.write_text(source)
baseline=base/'before-wrapper.sh';baseline.write_bytes(subprocess.check_output(['git','show','56a4b86eb338365f98ce6965acf5c582aca22f98:scripts/run-with-budget-warning.sh'],cwd=root))
fixture=base/'before-final.test.mjs';line="const wrapper = fileURLToPath(new URL('../../scripts/run-with-budget-warning.sh', import.meta.url));"
assert source.count(line)==1;fixture.write_text(source.replace(line,'const wrapper = '+json.dumps(str(baseline))+';'))
commands=[('before-final.log',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(fixture)],1),('after-final.log',['node','--max-old-space-size=256','--test','--test-concurrency=1',str(path)],0),('final-abbreviations.log',['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations'],0)]
results=[]
for name,args,expected in commands:
 with (base/name).open('w') as log:result=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 results.append({'argv':args,'exitCode':result.returncode,'expectedExitCode':expected,'log':name});assert result.returncode==expected
(base/'final-outcome.json').write_text(json.dumps({'results':results,'allChecksPassed':True,'maintainedAdapterPreviouslyPassed':116,'finalDeadlineControlIndependentOfWarning':True,'fullIssueComplete':False},indent=2)+'\n')
print(json.dumps(results))
