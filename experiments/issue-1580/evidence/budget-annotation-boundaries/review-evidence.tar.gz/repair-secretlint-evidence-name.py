from pathlib import Path
import json,subprocess
root=Path('/tmp/gh-issue-solver-1794900398048');base=Path('/tmp/issue-1580-research/budget-annotation-boundaries')
directory=root/'experiments/issue-1580/evidence/secretlint14-migration'
old='secretlint-config-loader-14.0.0.json.gz';new='secretlint-configuration-loader-14.0.0.json.gz'
assert (directory/old).is_file();assert not (directory/new).exists()
(directory/old).rename(directory/new)
path=directory/'manifest.json';value=json.loads(path.read_text())
rows=[r for r in value['records'] if r['stored']==old];assert len(rows)==1
rows[0]['stored']=new;path.write_text(json.dumps(value,indent=2)+'\n')
with (base/'after-abbreviation-repair.log').open('w') as log:
 result=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs','--only','check-abbreviations'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
print(json.dumps({'exitCode':result.returncode,'renamedEvidenceOnly':True}));assert result.returncode==0
