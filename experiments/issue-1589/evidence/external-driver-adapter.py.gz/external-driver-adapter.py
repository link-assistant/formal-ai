import subprocess,sys,pathlib
root=pathlib.Path('/tmp/gh-issue-solver-1794937731660')
logdir=root/'experiments/formal_ai_subagent/sandboxes/issue-1589';logdir.mkdir(parents=True,exist_ok=True)
number=__import__('time').time_ns()
prompt=sys.argv[1] if sys.argv[1].startswith(('Read ','Run ','Write ','Fix ','Explain ','Find ','Create ')) else 'Run '+sys.argv[1]
result=subprocess.run(['node','--max-old-space-size=192','experiments/js_dogfood/drive.mjs','--dir','.', '--steps','1','--provenance-dir',str(pathlib.Path('/tmp/formal-ai-1589-evidence')/f'action-{number}'),prompt],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(logdir/f'action-{number}.log').write_text(result.stdout)
print(result.stdout[result.stdout.index('>> '):].split('== answer ==')[0] if '>> ' in result.stdout else result.stdout)
print('Evidence:',logdir/f'action-{number}.log')
sys.exit(result.returncode)
