Configuration previously had no independent output-standard and lexical-density controls. This draft adds shared selectors, localized chat directives, request-local HTTP options, persisted browser/desktop settings, and experimental output projection with explicit missing-check reports. Unknown text remains opaque and byte-preserved.

**Draft: all seven acceptance criteria remain pending.** Strict renderers and official dictionaries, general semantic decomposition, global lexical minimum, complete summarization/protocol coverage, precise candidate clarification, and full native/JS/WASM input-style × output matrix are unfinished. Selecting a standard does not certify compliance.

The declared projection corpus contains one proposition with two realizations in each of five languages. The initial 880-case capture included two E-Prime compliance certificates that are withdrawn: they lacked independent evidence. A regression reproduced a false certificate for “’Tis ready.” Both validators now require an independent E-Prime checker; the new 880-case capture reports zero compliant cases and 880 with violations or missing validators. There is no general zero-drift or standards-compliance claim. Arbitrary top-N includes unsatisfiable limits such as top-1; the policy choice between exact preservation and widening/refusal remains unresolved. Other gaps are implementation work, not external blockers.

## Reproduce and verify

- Run `timeout 600 node --test --test-concurrency=1 rust/tests/web/cnl-output.test.mjs` — 11 passed.
- Run `timeout 600 node --test --test-concurrency=1 experiments/issue-1584/server.test.mjs` — 3 passed.
- Run `timeout 600 node --test --test-concurrency=1 rust/tests/web/server.test.mjs` — 7 passed.
- Run `timeout 600 node --test --test-concurrency=1 rust/tests/web/issue-1550-procedure-census.test.mjs` — 7 passed.
- Run `timeout 600 node --test --test-concurrency=1 rust/tests/web/cargo-audit-proof.test.mjs` — 3 passed.
- Run `timeout 600 node --test --test-concurrency=1 rust/tests/web/module-map-twin.test.mjs` — 8 passed.
- Run `timeout 600 node --test --test-concurrency=1 rust/tests/web/rust-specification-unicode-identifiers.test.mjs` — 34 passed.
- Run `timeout 600 node --test --test-concurrency=1 rust/tests/web/rust-specification-fixture-integrity.test.mjs` — 2 passed.
- Run `timeout 600 node --test --test-concurrency=1 rust/tests/web/runtime-feature-inventory.test.mjs` — 8 passed.
- Run `node experiments/formal_ai_subagent/local-gates.mjs` — 85 passed and 52 CI-only skipped; the ShellCheck PATH failure passed a targeted retry. All 86 runnable gates passed across the full inventory and environment retry. All 83 focused tests passed, including the strengthened HTTP assertion. Failed runs and successful retries are retained.
- `node scripts/translate-es.mjs --check` passes all 720 generated files. `node scripts/translate-js-rust.mjs --verify` passes source currency. Native code is a supplied manual port; generation has carried/refused constructs and does not establish compilation or behavioral parity. Handwritten changed Rust passed rustfmt; generator-owned registry formatting remains generator-controlled.
- Start the maintained JS server and request `output_standard: "e-prime"` or `lexical_density: "max-precision"`; inspect the output report for unchecked constraints. In the browser, open settings, select each control independently, reload, then send `Rewrite in max-precision mode`. This verifies persistence and notice flow; arbitrary text is not compressed by the finite lexicon.

## Browser evidence

Before:

![Settings before](https://github.com/link-assistant/formal-ai/blob/issue-1584-49c73d39af58/docs/screenshots/issue-1584/before.png?raw=true)

After:

![Independent experimental output controls](https://github.com/link-assistant/formal-ai/blob/issue-1584-49c73d39af58/docs/screenshots/issue-1584/after.png?raw=true)

Rewrite turn and dictionary notice:

![Rewrite and notice](https://github.com/link-assistant/formal-ai/blob/issue-1584-49c73d39af58/docs/screenshots/issue-1584/chat.png?raw=true)

## Evidence and delivery status

The [acceptance inventory](https://github.com/link-assistant/formal-ai/blob/issue-1584-49c73d39af58/experiments/issue-1584/acceptance.md) maps 50 prose requirements and all seven acceptance criteria to evidence and missing work. The [issue case study](https://github.com/link-assistant/formal-ai/tree/issue-1584-49c73d39af58/docs/case-studies/issue-1584) preserves a bounded raw archive and SHA-256 manifest, including failed attempts. The [PR case study](https://github.com/link-assistant/formal-ai/tree/issue-1584-49c73d39af58/docs/case-studies/pull-request-1585) records CI history. Supplied edits/scripts earn zero autonomous authorship credit: 8 frozen units, 0 independently accepted. A changelog fragment prepares the release trigger.

The latest completed CI head `778a3a00c` had 23 passing workflows, one skipped and one TypeScript-currency failure. This batch regenerates the stale worker/TypeScript projections and fixes the reproduced E-Prime false certificate. The [complete failed logs and repair evidence](https://github.com/link-assistant/formal-ai/tree/issue-1584-49c73d39af58/docs/case-studies/pull-request-1585/raw-data) are committed. The earlier exact-version chrono advisory acknowledgement uses the existing expiry-checked policy and does not repair chrono. No local Rust build was run. This PR remains unmerged and draft while acceptance is incomplete.

CI for this repair batch has not run at capture time.

Fixes #1584
