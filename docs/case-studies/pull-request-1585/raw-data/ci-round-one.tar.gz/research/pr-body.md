Configuration previously had no independent output-standard and lexical-density controls. This draft adds shared selectors, localized chat directives, request-local HTTP options, persisted browser/desktop settings, and experimental output projection with explicit missing-check reports. Unknown text remains opaque and byte-preserved.

**Draft: all seven acceptance criteria remain pending.** Strict renderers and official dictionaries, general semantic decomposition, global lexical minimum, complete summarization/protocol coverage, precise candidate clarification, and full native/JS/WASM input-style × output matrix are unfinished. Selecting a standard does not certify compliance.

The declared projection corpus contains one proposition with two realizations in each of five languages. Of 880 captured profile/density cases, 2 have all requested checks passing; 878 report violations or missing validators. There is no general zero-drift or standards-compliance claim. Arbitrary top-N includes unsatisfiable limits such as top-1; the policy choice between exact preservation and widening/refusal remains unresolved. Other gaps are implementation work, not external blockers.

## Reproduce and verify

- Run `timeout 600 node --test --test-concurrency=1 rust/tests/web/cnl-output.test.mjs` — 10 passed.
- Run `timeout 600 node --test --test-concurrency=1 experiments/issue-1584/server.test.mjs` — 3 passed.
- Run `timeout 600 node --test --test-concurrency=1 rust/tests/web/server.test.mjs` — 7 passed.
- Run `node experiments/formal_ai_subagent/local-gates.mjs` — 86 passed, 52 CI-only skipped, no failures. The subsequent evidence/helper changes passed file-size, dependency-direction and abbreviation gates.
- `node scripts/translate-js-rust.mjs --verify` passes source currency. Native code is a supplied manual port; generation has carried/refused constructs and does not establish compilation or behavioral parity. Handwritten changed Rust passed rustfmt; generator-owned registry formatting remains generator-controlled.
- Start the maintained JS server and request `output_standard: "e-prime"` or `lexical_density: "max-precision"`; inspect the output report for unchecked constraints. In the browser, open settings, select each control independently, reload, then send `Rewrite in max-precision mode`. This verifies persistence and notice flow; arbitrary text is not compressed by the finite lexicon.

## Browser evidence

Before:

![Settings before](https://github.com/link-assistant/formal-ai/blob/issue-1584-49c73d39af58/docs/screenshots/issue-1584/before.png?raw=true)

After:

![Independent experimental output controls](https://github.com/link-assistant/formal-ai/blob/issue-1584-49c73d39af58/docs/screenshots/issue-1584/after.png?raw=true)

Rewrite turn and dictionary notice:

![Rewrite and notice](https://github.com/link-assistant/formal-ai/blob/issue-1584-49c73d39af58/docs/screenshots/issue-1584/chat.png?raw=true)

## Evidence and delivery status

The [acceptance inventory](https://github.com/link-assistant/formal-ai/blob/issue-1584-49c73d39af58/experiments/issue-1584/README.md) maps all seven requirements to evidence and missing work. The [issue case study](https://github.com/link-assistant/formal-ai/tree/issue-1584-49c73d39af58/docs/case-studies/issue-1584) preserves a bounded raw archive and SHA-256 manifest, including failed attempts. The [PR case study](https://github.com/link-assistant/formal-ai/tree/issue-1584-49c73d39af58/docs/case-studies/pull-request-1585) records CI history. Supplied edits/scripts earn zero autonomous authorship credit: 8 frozen units, 0 independently accepted. A changelog fragment prepares the release trigger.

Current head `4ca5c0b57` is pushed; current-head CI is running. No local Rust build was run. This PR remains unmerged and must remain draft while acceptance is incomplete.

Fixes #1584
