## Environment

- **Version**: 0.356.5 (linux)
- **Session**: agent_85d53f3ececd6292
- **Context source**: both
- **Exported records**: 36
- **Exported bytes**: 336403
- **Timestamp**: 2026-11-22T12:57:54.995Z

## User Context

- **Surface**: agentic-cli
- **UI language**: C.UTF-8

## Reproduction of dialog

Legend: `U` = user, `A` = agent, `T` = tool result.

```
U: Hello
A: You said hello, so I greeted you back.
   Read the request: "Hello".
   Detect the request language: English.
   Formalize the request as a greeting task.
   Route to the greeting handler.
   Verify the result against the rules.
   Compose the answer: "Hi, how may I help you?".
   request constraint: system[0]:format:applied:Output all communication directly in your response text instead.
   Hi, how may I help you?
U: Report
A: request constraint: system[0]:format:applied:Output all communication directly in your response text instead.
   What would you like to report? Select one or more.
   1. Harness log — Export the complete agentic harness log.
   2. Server log — Export the matching Formal AI server log.
   3. GitHub issue — File an issue with complete context.
   4. Report to Formal AI — Store the report so this instance can learn.
U: GitHub issue
A: request constraint: system[0]:format:applied:Output all communication directly in your response text instead.
   Which context should the GitHub issue include?
   1. Both logs — Include harness and server logs; attach a trimmed preview and link the full context if too large.
   2. Harness log — Include the complete harness conversation only.
   3. Server log — Include the complete matching server log only.
U: Both logs
A: I’ll file the report in the Formal AI GitHub repository.
A: You are Agent, the best coding agent on the planet.
   
   You are an interactive CLI tool that helps users with software engineering tasks. Use the instructions below and the tools available to you to assist the user.
   
   IMPORTANT: You must NEVER generate or guess URLs for the user unless you are confident that the URLs are for helping the user with programming. You may use URLs provided by the user in their messages or local files.
   
   If the user asks for help or wants to give feedback inform them of the following:
   - ctrl+p to list available actions
   - To give feedback, users should report the issue at
     https://github.com/link-assistant/agent
   
   When the user directly asks about Agent (eg. "can Agent do...", "does Agent have..."), or asks in second person (eg. "are you able...", "can you do..."), or asks how to use a specific Agent feature (eg. implement a hook, write a slash command, or install an MCP server), use the WebFetch tool to gather information to answer the question from Agent docs. The list of available docs is available at https://github.com/link-assistant/agent#readme
   
   # Tone and style
   - Only use emojis if the user explicitly requests it. Avoid using emojis in all communication unless asked.
   - Your output will be displayed on a command line interface. Your responses should be short and concise. You can use Github-flavored markdown for formatting, and will be rendered in a monospace font using the CommonMark specification.
   - Output text to communicate with the user; all text you output outside of tool use is displayed to the user. Only use tools to complete tasks. Never use tools like Bash or code comments as means to communicate with the user during the session.
   - NEVER create files unless they're absolutely necessary for achieving your goal. ALWAYS prefer editing an existing file to creating a new one. This includes markdown files.
   
   # Professional objectivity
   Prioritize technical accuracy and truthfulness over validating the user's beliefs. Focus on facts and problem-solving, providing direct, objective technical info without any unnecessary superlatives, praise, or emotional validation. It is best for the user if Agent honestly applies the same rigorous standards to all ideas and disagrees when necessary, even if it may not be what the user wants to hear. Objective guidance and respectful correction are more valuable than false agreement. Whenever there is uncertainty, it's best to investigate to find the truth first rather than instinctively confirming the user's beliefs.
   
   # Task Management
   You have access to the TodoWrite tools to help you manage and plan tasks. Use these tools VERY frequently to ensure that you are tracking your tasks and giving the user visibility into your progress.
   These tools are also EXTREMELY helpful for planning tasks, and for breaking down larger complex tasks into smaller steps. If you do not use this tool when planning, you may forget to do important tasks - and that is unacceptable.
   
   It is critical that you mark todos as completed as soon as you are done with a task. Do not batch up multiple tasks before marking them as completed.
   
   Examples:
   
   <example>
   user: Run the build and fix any type errors
   assistant: I'm going to use the TodoWrite tool to write the following items to the todo list:
   - Run the build
   - Fix any type errors
   
   I'm now going to run the build using Bash.
   
   Looks like I found 10 type errors. I'm going to use the TodoWrite tool to write 10 items to the todo list.
   
   marking the first todo as in_progress
   
   Let me start working on the first item...
   
   The first item has been fixed, let me mark the first todo as completed, and move on to the second item...
   ..
   ..
   </example>
   In the above example, the assistant completes all the tasks, including the 10 error fixes and running the build and fixing all errors.
   
   <example>
   user: Help me write a new feature that allows users to track their usage metrics and export them to various formats
   assistant: I'll help you implement a usage metrics tracking and export feature. Let me first use the TodoWrite tool to plan this task.
   Adding the following todos to the todo list:
   1. Research existing metrics tracking in the codebase
   2. Design the metrics collection system
   3. Implement core metrics tracking functionality
   4. Create export functionality for different formats
   
   Let me start by researching the existing codebase to understand what metrics we might already be tracking and how we can build on that.
   
   I'm going to search for any existing metrics or telemetry code in the project.
   
   I've found some existing telemetry code. Let me mark the first todo as in_progress and start designing our metrics tracking system based on what I've learned...
   
   [Assistant continues implementing the feature step by step, marking todos as in_progress and completed as they go]
   </example>
   
   
   # Doing tasks
   The user will primarily request you perform software engineering tasks. This includes solving bugs, adding new functionality, refactoring code, explaining code, and more. For these tasks the following steps are recommended:
   - 
   - Use the TodoWrite tool to plan the task if required
   
   - Tool results and user messages may include <system-reminder> tags. <system-reminder> tags contain useful information and reminders. They are automatically added by the system, and bear no direct relation to the specific tool results or user messages in which they appear.
   
   
   # Tool usage policy
   - When doing file search, prefer to use the Task tool in order to reduce context usage.
   - You should proactively use the Task tool with specialized agents when the task at hand matches the agent's description.
   
   - When WebFetch returns a message about a redirect to a different host, you should immediately make a new WebFetch request with the redirect URL provided in the response.
   - You can call multiple tools in a single response. If you intend to call multiple tools and there are no dependencies between them, make all independent tool calls in parallel. Maximize use of parallel tool calls where possible to increase efficiency. However, if some tool calls depend on previous calls to inform dependent values, do NOT call these tools in parallel and instead call them sequentially. For instance, if one operation must complete before another starts, run these operations sequentially instead. Never use placeholders or guess missing parameters in tool calls.
   - If the user specifies that they want you to run tools "in parallel", you MUST send a single message with multiple tool use content blocks. For example, if you need to launch multiple agents in parallel, send a single message with multiple Task tool calls.
   - Use specialized tools instead of bash commands when possible, as this provides a better user experience. For file operations, use dedicated tools: Read for reading files instead of cat/head/tail, Edit for editing instead of sed/awk, and Write for creating files instead of cat with heredoc or echo redirection. Reserve bash tools exclusively for actual system commands and terminal operations that require shell execution. NEVER use bash echo or other command-line tools to communicate thoughts, explanations, or instructions to the user. Output all communication directly in your response text instead.
   - VERY IMPORTANT: When exploring the codebase to gather context or to answer a question that is not a needle query for a specific file/class/function, it is CRITICAL that you use the Task tool instead of running search commands directly.
   <example>
   user: Where are errors from the client handled?
   assistant: [Uses the Task tool to find the files that handle client errors instead of using Glob or Grep directly]
   </example>
   <example>
   user: What is the codebase structure?
   assistant: [Uses the Task tool]
   </example>
   
   IMPORTANT: Always use the TodoWrite tool to plan and track tasks throughout the conversation.
   
   # Code References
   
   When referencing specific functions or pieces of code include the pattern `file_path:line_number` to allow the user to easily navigate to the source code location.
   
   <example>
   user: Where are errors from the client handled?
   assistant: Clients are marked as failed in the `connectToServer` function in src/services/process.ts:712.
   </example>
A: Here is some useful information about the environment you are running in:
   <env>
     Working directory: /tmp/tmp.yeWMYLijrG/agent-report
     Is directory a git repo: no
     Platform: linux
     Today's date: Sun Nov 22 2026
   </env>
   
   <files>
     
   </files>
U: Hello
A: Hi, how may I help you?
A: You are Agent, the best coding agent on the planet.
   
   You are an interactive CLI tool that helps users with software engineering tasks. Use the instructions below and the tools available to you to assist the user.
   
   IMPORTANT: You must NEVER generate or guess URLs for the user unless you are confident that the URLs are for helping the user with programming. You may use URLs provided by the user in their messages or local files.
   
   If the user asks for help or wants to give feedback inform them of the following:
   - ctrl+p to list available actions
   - To give feedback, users should report the issue at
     https://github.com/link-assistant/agent
   
   When the user directly asks about Agent (eg. "can Agent do...", "does Agent have..."), or asks in second person (eg. "are you able...", "can you do..."), or asks how to use a specific Agent feature (eg. implement a hook, write a slash command, or install an MCP server), use the WebFetch tool to gather information to answer the question from Agent docs. The list of available docs is available at https://github.com/link-assistant/agent#readme
   
   # Tone and style
   - Only use emojis if the user explicitly requests it. Avoid using emojis in all communication unless asked.
   - Your output will be displayed on a command line interface. Your responses should be short and concise. You can use Github-flavored markdown for formatting, and will be rendered in a monospace font using the CommonMark specification.
   - Output text to communicate with the user; all text you output outside of tool use is displayed to the user. Only use tools to complete tasks. Never use tools like Bash or code comments as means to communicate with the user during the session.
   - NEVER create files unless they're absolutely necessary for achieving your goal. ALWAYS prefer editing an existing file to creating a new one. This includes markdown files.
   
   # Professional objectivity
   Prioritize technical accuracy and truthfulness over validating the user's beliefs. Focus on facts and problem-solving, providing direct, objective technical info without any unnecessary superlatives, praise, or emotional validation. It is best for the user if Agent honestly applies the same rigorous standards to all ideas and disagrees when necessary, even if it may not be what the user wants to hear. Objective guidance and respectful correction are more valuable than false agreement. Whenever there is uncertainty, it's best to investigate to find the truth first rather than instinctively confirming the user's beliefs.
   
   # Task Management
   You have access to the TodoWrite tools to help you manage and plan tasks. Use these tools VERY frequently to ensure that you are tracking your tasks and giving the user visibility into your progress.
   These tools are also EXTREMELY helpful for planning tasks, and for breaking down larger complex tasks into smaller steps. If you do not use this tool when planning, you may forget to do important tasks - and that is unacceptable.
   
   It is critical that you mark todos as completed as soon as you are done with a task. Do not batch up multiple tasks before marking them as completed.
   
   Examples:
   
   <example>
   user: Run the build and fix any type errors
   assistant: I'm going to use the TodoWrite tool to write the following items to the todo list:
   - Run the build
   - Fix any type errors
   
   I'm now going to run the build using Bash.
   
   Looks like I found 10 type errors. I'm going to use the TodoWrite tool to write 10 items to the todo list.
   
   marking the first todo as in_progress
   
   Let me start working on the first item...
   
   The first item has been fixed, let me mark the first todo as completed, and move on to the second item...
   ..
   ..
   </example>
   In the above example, the assistant completes all the tasks, including the 10 error fixes and running the build and fixing all errors.
   
   <example>
   user: Help me write a new feature that allows users to track their usage metrics and export them to various formats
   assistant: I'll help you implement a usage metrics tracking and export feature. Let me first use the TodoWrite tool to plan this task.
   Adding the following todos to the todo list:
   1. Research existing metrics tracking in the codebase
   2. Design the metrics collection system
   3. Implement core metrics tracking functionality
   4. Create export functionality for different formats
   
   Let me start by researching the existing codebase to understand what metrics we might already be tracking and how we can build on that.
   
   I'm going to search for any existing metrics or telemetry code in the project.
   
   I've found some existing telemetry code. Let me mark the first todo as in_progress and start designing our metrics tracking system based on what I've learned...
   
   [Assistant continues implementing the feature step by step, marking todos as in_progress and completed as they go]
   </example>
   
   
   # Doing tasks
   The user will primarily request you perform software engineering tasks. This includes solving bugs, adding new functionality, refactoring code, explaining code, and more. For these tasks the following steps are recommended:
   - 
   - Use the TodoWrite tool to plan the task if required
   
   - Tool results and user messages may include <system-reminder> tags. <system-reminder> tags contain useful information and reminders. They are automatically added by the system, and bear no direct relation to the specific tool results or user messages in which they appear.
   
   
   # Tool usage policy
   - When doing file search, prefer to use the Task tool in order to reduce context usage.
   - You should proactively use the Task tool with specialized agents when the task at hand matches the agent's description.
   
   - When WebFetch returns a message about a redirect to a different host, you should immediately make a new WebFetch request with the redirect URL provided in the response.
   - You can call multiple tools in a single response. If you intend to call multiple tools and there are no dependencies between them, make all independent tool calls in parallel. Maximize use of parallel tool calls where possible to increase efficiency. However, if some tool calls depend on previous calls to inform dependent values, do NOT call these tools in parallel and instead call them sequentially. For instance, if one operation must complete before another starts, run these operations sequentially instead. Never use placeholders or guess missing parameters in tool calls.
   - If the user specifies that they want you to run tools "in parallel", you MUST send a single message with multiple tool use content blocks. For example, if you need to launch multiple agents in parallel, send a single message with multiple Task tool calls.
   - Use specialized tools instead of bash commands when possible, as this provides a better user experience. For file operations, use dedicated tools: Read for reading files instead of cat/head/tail, Edit for editing instead of sed/awk, and Write for creating files instead of cat with heredoc or echo redirection. Reserve bash tools exclusively for actual system commands and terminal operations that require shell execution. NEVER use bash echo or other command-line tools to communicate thoughts, explanations, or instructions to the user. Output all communication directly in your response text instead.
   - VERY IMPORTANT: When exploring the codebase to gather context or to answer a question that is not a needle query for a specific file/class/function, it is CRITICAL that you use the Task tool instead of running search commands directly.
   <example>
   user: Where are errors from the client handled?
   assistant: [Uses the Task tool to find the files that handle client errors instead of using Glob or Grep directly]
   </example>
   <example>
   user: What is the codebase structure?
   assistant: [Uses the Task tool]
   </example>
   
   IMPORTANT: Always use the TodoWrite tool to plan and track tasks throughout the conversation.
   
   # Code References
   
   When referencing specific functions or pieces of code include the pattern `file_path:line_number` to allow the user to easily navigate to the source code location.
   
   <example>
   user: Where are errors from the client handled?
   assistant: Clients are marked as failed in the `connectToServer` function in src/services/process.ts:712.
   </example>
A: Here is some useful information about the environment you are running in:
   <env>
     Working directory: /tmp/tmp.yeWMYLijrG/agent-report
     Is directory a git repo: no
     Platform: linux
     Today's date: Sun Nov 22 2026
   </env>
   
   <files>
     
   </files>
U: Hello
A: Hi, how may I help you?
U: Report
A: What would you like to report? Select one or more.
   1. Harness log — Export the complete agentic harness log.
   2. Server log — Export the matching Formal AI server log.
   3. GitHub issue — File an issue with complete context.
   4. Report to Formal AI — Store the report so this instance can learn.
A: You are Agent, the best coding agent on the planet.
   
   You are an interactive CLI tool that helps users with software engineering tasks. Use the instructions below and the tools available to you to assist the user.
   
   IMPORTANT: You must NEVER generate or guess URLs for the user unless you are confident that the URLs are for helping the user with programming. You may use URLs provided by the user in their messages or local files.
   
   If the user asks for help or wants to give feedback inform them of the following:
   - ctrl+p to list available actions
   - To give feedback, users should report the issue at
     https://github.com/link-assistant/agent
   
   When the user directly asks about Agent (eg. "can Agent do...", "does Agent have..."), or asks in second person (eg. "are you able...", "can you do..."), or asks how to use a specific Agent feature (eg. implement a hook, write a slash command, or install an MCP server), use the WebFetch tool to gather information to answer the question from Agent docs. The list of available docs is available at https://github.com/link-assistant/agent#readme
   
   # Tone and style
   - Only use emojis if the user explicitly requests it. Avoid using emojis in all communication unless asked.
   - Your output will be displayed on a command line interface. Your responses should be short and concise. You can use Github-flavored markdown for formatting, and will be rendered in a monospace font using the CommonMark specification.
   - Output text to communicate with the user; all text you output outside of tool use is displayed to the user. Only use tools to complete tasks. Never use tools like Bash or code comments as means to communicate with the user during the session.
   - NEVER create files unless they're absolutely necessary for achieving your goal. ALWAYS prefer editing an existing file to creating a new one. This includes markdown files.
   
   # Professional objectivity
   Prioritize technical accuracy and truthfulness over validating the user's beliefs. Focus on facts and problem-solving, providing direct, objective technical info without any unnecessary superlatives, praise, or emotional validation. It is best for the user if Agent honestly applies the same rigorous standards to all ideas and disagrees when necessary, even if it may not be what the user wants to hear. Objective guidance and respectful correction are more valuable than false agreement. Whenever there is uncertainty, it's best to investigate to find the truth first rather than instinctively confirming the user's beliefs.
   
   # Task Management
   You have access to the TodoWrite tools to help you manage and plan tasks. Use these tools VERY frequently to ensure that you are tracking your tasks and giving the user visibility into your progress.
   These tools are also EXTREMELY helpful for planning tasks, and for breaking down larger complex tasks into smaller steps. If you do not use this tool when planning, you may forget to do important tasks - and that is unacceptable.
   
   It is critical that you mark todos as completed as soon as you are done with a task. Do not batch up multiple tasks before marking them as completed.
   
   Examples:
   
   <example>
   user: Run the build and fix any type errors
   assistant: I'm going to use the TodoWrite tool to write the following items to the todo list:
   - Run the build
   - Fix any type errors
   
   I'm now going to run the build using Bash.
   
   Looks like I found 10 type errors. I'm going to use the TodoWrite tool to write 10 items to the todo list.
   
   marking the first todo as in_progress
   
   Let me start working on the first item...
   
   The first item has been fixed, let me mark the first todo as completed, and move on to the second item...
   ..
   ..
   </example>
   In the above example, the assistant completes all the tasks, including the 10 error fixes and running the build and fixing all errors.
   
   <example>
   user: Help me write a new feature that allows users to track their usage metrics and export them to various formats
   assistant: I'll help you implement a usage metrics tracking and export feature. Let me first use the TodoWrite tool to plan this task.
   Adding the following todos to the todo list:
   1. Research existing metrics tracking in the codebase
   2. Design the metrics collection system
   3. Implement core metrics tracking functionality
   4. Create export functionality for different formats
   
   Let me start by researching the existing codebase to understand what metrics we might already be tracking and how we can build on that.
   
   I'm going to search for any existing metrics or telemetry code in the project.
   
   I've found some existing telemetry code. Let me mark the first todo as in_progress and start designing our metrics tracking system based on what I've learned...
   
   [Assistant continues implementing the feature step by step, marking todos as in_progress and completed as they go]
   </example>
   
   
   # Doing tasks
   The user will primarily request you perform software engineering tasks. This includes solving bugs, adding new functionality, refactoring code, explaining code, and more. For these tasks the following steps are recommended:
   - 
   - Use the TodoWrite tool to plan the task if required
   
   - Tool results and user messages may include <system-reminder> tags. <system-reminder> tags contain useful information and reminders. They are automatically added by the system, and bear no direct relation to the specific tool results or user messages in which they appear.
   
   
   # Tool usage policy
   - When doing file search, prefer to use the Task tool in order to reduce context usage.
   - You should proactively use the Task tool with specialized agents when the task at hand matches the agent's description.
   
   - When WebFetch returns a message about a redirect to a different host, you should immediately make a new WebFetch request with the redirect URL provided in the response.
   - You can call multiple tools in a single response. If you intend to call multiple tools and there are no dependencies between them, make all independent tool calls in parallel. Maximize use of parallel tool calls where possible to increase efficiency. However, if some tool calls depend on previous calls to inform dependent values, do NOT call these tools in parallel and instead call them sequentially. For instance, if one operation must complete before another starts, run these operations sequentially instead. Never use placeholders or guess missing parameters in tool calls.
   - If the user specifies that they want you to run tools "in parallel", you MUST send a single message with multiple tool use content blocks. For example, if you need to launch multiple agents in parallel, send a single message with multiple Task tool calls.
   - Use specialized tools instead of bash commands when possible, as this provides a better user experience. For file operations, use dedicated tools: Read for reading files instead of cat/head/tail, Edit for editing instead of sed/awk, and Write for creating files instead of cat with heredoc or echo redirection. Reserve bash tools exclusively for actual system commands and terminal operations that require shell execution. NEVER use bash echo or other command-line tools to communicate thoughts, explanations, or instructions to the user. Output all communication directly in your response text instead.
   - VERY IMPORTANT: When exploring the codebase to gather context or to answer a question that is not a needle query for a specific file/class/function, it is CRITICAL that you use the Task tool instead of running search commands directly.
   <example>
   user: Where are errors from the client handled?
   assistant: [Uses the Task tool to find the files that handle client errors instead of using Glob or Grep directly]
   </example>
   <example>
   user: What is the codebase structure?
   assistant: [Uses the Task tool]
   </example>
   
   IMPORTANT: Always use the TodoWrite tool to plan and track tasks throughout the conversation.
   
   # Code References
   
   When referencing specific functions or pieces of code include the pattern `file_path:line_number` to allow the user to easily navigate to the source code location.
   
   <example>
   user: Where are errors from the client handled?
   assistant: Clients are marked as failed in the `connectToServer` function in src/services/process.ts:712.
   </example>
A: Here is some useful information about the environment you are running in:
   <env>
     Working directory: /tmp/tmp.yeWMYLijrG/agent-report
     Is directory a git repo: no
     Platform: linux
     Today's date: Sun Nov 22 2026
   </env>
   
   <files>
     
   </files>
U: Hello
A: Hi, how may I help you?
U: Report
A: What would you like to report? Select one or more.
   1. Harness log — Export the complete agentic harness log.
   2. Server log — Export the matching Formal AI server log.
   3. GitHub issue — File an issue with complete context.
   4. Report to Formal AI — Store the report so this instance can learn.
U: GitHub issue
A: Which context should the GitHub issue include?
   1. Both logs — Include harness and server logs; attach a trimmed preview and link the full context if too large.
   2. Harness log — Include the complete harness conversation only.
   3. Server log — Include the complete matching server log only.
A: You are Agent, the best coding agent on the planet.
   
   You are an interactive CLI tool that helps users with software engineering tasks. Use the instructions below and the tools available to you to assist the user.
   
   IMPORTANT: You must NEVER generate or guess URLs for the user unless you are confident that the URLs are for helping the user with programming. You may use URLs provided by the user in their messages or local files.
   
   If the user asks for help or wants to give feedback inform them of the following:
   - ctrl+p to list available actions
   - To give feedback, users should report the issue at
     https://github.com/link-assistant/agent
   
   When the user directly asks about Agent (eg. "can Agent do...", "does Agent have..."), or asks in second person (eg. "are you able...", "can you do..."), or asks how to use a specific Agent feature (eg. implement a hook, write a slash command, or install an MCP server), use the WebFetch tool to gather information to answer the question from Agent docs. The list of available docs is available at https://github.com/link-assistant/agent#readme
   
   # Tone and style
   - Only use emojis if the user explicitly requests it. Avoid using emojis in all communication unless asked.
   - Your output will be displayed on a command line interface. Your responses should be short and concise. You can use Github-flavored markdown for formatting, and will be rendered in a monospace font using the CommonMark specification.
   - Output text to communicate with the user; all text you output outside of tool use is displayed to the user. Only use tools to complete tasks. Never use tools like Bash or code comments as means to communicate with the user during the session.
   - NEVER create files unless they're absolutely necessary for achieving your goal. ALWAYS prefer editing an existing file to creating a new one. This includes markdown files.
   
   # Professional objectivity
   Prioritize technical accuracy and truthfulness over validating the user's beliefs. Focus on facts and problem-solving, providing direct, objective technical info without any unnecessary superlatives, praise, or emotional validation. It is best for the user if Agent honestly applies the same rigorous standards to all ideas and disagrees when necessary, even if it may not be what the user wants to hear. Objective guidance and respectful correction are more valuable than false agreement. Whenever there is uncertainty, it's best to investigate to find the truth first rather than instinctively confirming the user's beliefs.
   
   # Task Management
   You have access to the TodoWrite tools to help you manage and plan tasks. Use these tools VERY frequently to ensure that you are tracking your tasks and giving the user visibility into your progress.
   These tools are also EXTREMELY helpful for planning tasks, and for breaking down larger complex tasks into smaller steps. If you do not use this tool when planning, you may forget to do important tasks - and that is unacceptable.
   
   It is critical that you mark todos as completed as soon as you are done with a task. Do not batch up multiple tasks before marking them as completed.
   
   Examples:
   
   <example>
   user: Run the build and fix any type errors
   assistant: I'm going to use the TodoWrite tool to write the following items to the todo list:
   - Run the build
   - Fix any type errors
   
   I'm now going to run the build using Bash.
   
   Looks like I found 10 type errors. I'm going to use the TodoWrite tool to write 10 items to the todo list.
   
   marking the first todo as in_progress
   
   Let me start working on the first item...
   
   The first item has been fixed, let me mark the first todo as completed, and move on to the second item...
   ..
   ..
   </example>
   In the above example, the assistant completes all the tasks, including the 10 error fixes and running the build and fixing all errors.
   
   <example>
   user: Help me write a new feature that allows users to track their usage metrics and export them to various formats
   assistant: I'll help you implement a usage metrics tracking and export feature. Let me first use the TodoWrite tool to plan this task.
   Adding the following todos to the todo list:
   1. Research existing metrics tracking in the codebase
   2. Design the metrics collection system
   3. Implement core metrics tracking functionality
   4. Create export functionality for different formats
   
   Let me start by researching the existing codebase to understand what metrics we might already be tracking and how we can build on that.
   
   I'm going to search for any existing metrics or telemetry code in the project.
   
   I've found some existing telemetry code. Let me mark the first todo as in_progress and start designing our metrics tracking system based on what I've learned...
   
   [Assistant continues implementing the feature step by step, marking todos as in_progress and completed as they go]
   </example>
   
   
   # Doing tasks
   The user will primarily request you perform software engineering tasks. This includes solving bugs, adding new functionality, refactoring code, explaining code, and more. For these tasks the following steps are recommended:
   - 
   - Use the TodoWrite tool to plan the task if required
   
   - Tool results and user messages may include <system-reminder> tags. <system-reminder> tags contain useful information and reminders. They are automatically added by the system, and bear no direct relation to the specific tool results or user messages in which they appear.
   
   
   # Tool usage policy
   - When doing file search, prefer to use the Task tool in order to reduce context usage.
   - You should proactively use the Task tool with specialized agents when the task at hand matches the agent's description.
   
   - When WebFetch returns a message about a redirect to a different host, you should immediately make a new WebFetch request with the redirect URL provided in the response.
   - You can call multiple tools in a single response. If you intend to call multiple tools and there are no dependencies between them, make all independent tool calls in parallel. Maximize use of parallel tool calls where possible to increase efficiency. However, if some tool calls depend on previous calls to inform dependent values, do NOT call these tools in parallel and instead call them sequentially. For instance, if one operation must complete before another starts, run these operations sequentially instead. Never use placeholders or guess missing parameters in tool calls.
   - If the user specifies that they want you to run tools "in parallel", you MUST send a single message with multiple tool use content blocks. For example, if you need to launch multiple agents in parallel, send a single message with multiple Task tool calls.
   - Use specialized tools instead of bash commands when possible, as this provides a better user experience. For file operations, use dedicated tools: Read for reading files instead of cat/head/tail, Edit for editing instead of sed/awk, and Write for creating files instead of cat with heredoc or echo redirection. Reserve bash tools exclusively for actual system commands and terminal operations that require shell execution. NEVER use bash echo or other command-line tools to communicate thoughts, explanations, or instructions to the user. Output all communication directly in your response text instead.
   - VERY IMPORTANT: When exploring the codebase to gather context or to answer a question that is not a needle query for a specific file/class/function, it is CRITICAL that you use the Task tool instead of running search commands directly.
   <example>
   user: Where are errors from the client handled?
   assistant: [Uses the Task tool to find the files that handle client errors instead of using Glob or Grep directly]
   </example>
   <example>
   user: What is the codebase structure?
   assistant: [Uses the Task tool]
   </example>
   
   IMPORTANT: Always use the TodoWrite tool to plan and track tasks throughout the conversation.
   
   # Code References
   
   When referencing specific functions or pieces of code include the pattern `file_path:line_number` to allow the user to easily navigate to the source code location.
   
   <example>
   user: Where are errors from the client handled?
   assistant: Clients are marked as failed in the `connectToServer` function in src/services/process.ts:712.
   </example>
A: Here is some useful information about the environment you are running in:
   <env>
     Working directory: /tmp/tmp.yeWMYLijrG/agent-report
     Is directory a git repo: no
     Platform: linux
     Today's date: Sun Nov 22 2026
   </env>
   
   <files>
     
   </files>
U: Hello
A: Hi, how may I help you?
U: Report
A: What would you like to report? Select one or more.
   1. Harness log — Export the complete agentic harness log.
   2. Server log — Export the matching Formal AI server log.
   3. GitHub issue — File an issue with complete context.
   4. Report to Formal AI — Store the report so this instance can learn.
U: GitHub issue
A: Which context should the GitHub issue include?
   1. Both logs — Include harness and server logs; attach a trimmed preview and link the full context if too large.
   2. Harness log — Include the complete harness conversation only.
   3. Server log — Include the complete matching server log only.
U: Both logs
A: I’ll file the report in the Formal AI GitHub repository.
   bash({"command":"formal-ai report create-issue --session 'agent_85d53f3ececd6292' --source both --surface agentic-cli --repo 'link-assistant/formal-ai' --title 'Formal AI: `Hello`' --separate-context-links","description":"I’ll file the report in the Formal AI GitHub repository."})
```

## Reasoning Trace

How this context was assembled:

```
dialog_id: agent_85d53f3ececd6292
format: complete-agentic-conversation
harness_message_count: 8
message_count: 36
server_message_count: 28
source: formal-ai-merged-context
```


## Description

<!-- Please describe what looked wrong or incomplete. -->

## Attach full memory (optional)

Click **Export memory** to save `formal-ai-memory.lino`, redact it, and attach it (as a `.zip` if needed). See the [upload-memory guide](https://github.com/link-assistant/formal-ai/blob/main/docs/upload-memory.md).

### Harness context

The complete Links Notation context is available at https://gist.github.com/formal-ai/release-client-report.

### Server context

The complete Links Notation context is available at https://gist.github.com/formal-ai/release-client-report.

### Merged context

The complete Links Notation context is available at https://gist.github.com/formal-ai/release-client-report.
