from pathlib import Path
import re
import subprocess

path = Path('js/app/cnl-settings.jsx')
path.write_text(path.read_text().replace('const DENSITIES =', 'const {createElement: h} = React;\n\nconst DENSITIES ='))
path = Path('js/app/preferences.jsx')
text = path.read_text()
start = text.index('export const PREFERENCE_DEFAULTS = {')
end = text.index('\n};', start) + 3
defaults = text[start:end]
Path('js/app/preference-defaults.js').write_text('// Shared persisted defaults, independent of UI rendering.\n' + defaults + '\n')
text = text[:start] + 'import {PREFERENCE_DEFAULTS} from "./preference-defaults.js";\nexport {PREFERENCE_DEFAULTS} from "./preference-defaults.js";' + text[end:]
start = text.index('export const OUTPUT_STANDARDS = ')
end = text.index('export function normalizeResponseLanguageMode(', start)
Path('js/app/cnl-preferences.js').write_text('import {PREFERENCE_DEFAULTS} from "./preference-defaults.js";\n\n' + text[start:end])
text = text[:start] + 'export {OUTPUT_STANDARDS, normalizeOutputStandard, normalizeLexicalDensity} from "./cnl-preferences.js";\n\n' + text[end:]
path.write_text(text)

for path in Path('rust/src').rglob('*.rs'):
    text = path.read_text()
    changed = text.replace('cnl_output::config::', 'cnl_output::configuration::')
    if changed != text:
        path.write_text(changed)

path = Path('rust/src/cnl_output/configuration.rs')
path.write_text(path.read_text() + '''
/// CLI startup establishes the process defaults once; request overrides are local.
pub fn configure_options(standard: Option<&str>, density: Option<&str>) -> std::io::Result<()> {
    let configuration = output_configuration(standard, density, super::cnl_policy())
        .map_err(std::io::Error::other)?;
    configure_output(configuration).map_err(std::io::Error::other)
}
''')
path = Path('rust/src/main.rs')
text = path.read_text()
start = text.index('    let output = formal_ai::cnl_output::output_configuration(')
end = text.index('\n', text.index('configure_output(output)', start))
text = text[:start] + '''    formal_ai::cnl_output::configuration::configure_options(
        arguments.output_standard.as_deref(), arguments.lexical_density.as_deref(),
    )?;''' + text[end:]
path.write_text(text)

# Keep protocol.rs under its source ceiling by giving the request DTO its own
# existing-style module. The public names and serialized shape are preserved.
path = Path('rust/src/protocol.rs')
text = path.read_text()
start = text.index('#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]\npub struct ChatCompletionRequest')
end = text.index('/// OpenAI-compatible `stream_options` field.', start)
Path('rust/src/protocol/chat_request.rs').write_text('use super::*;\n\n' + text[start:end])
text = text[:start] + text[end:]
text = text.replace('mod content;\n', 'mod chat_request;\npub use chat_request::ChatCompletionRequest;\nmod content;\n')
path.write_text(text)

path = Path('js/server/main.mjs')
text = path.read_text()
text = text.replace('      return {help: false, host, port, model,', '      return {help: false, host, port, model,')
lines = []
for line in text.splitlines(True):
    if len(line.rstrip()) > 300:
        line = line.replace(', outputStandard', ',\n      outputStandard').replace(', lexicalDensity', ',\n      lexicalDensity')
    lines.append(line)
path.write_text(''.join(lines))

# Preserve the failed browser attempt as evidence; replace after.png only after
# the UI assertion succeeds.
shot = Path('docs/screenshots/issue-1584/after.png')
if shot.exists():
    Path('/tmp/issue-1584-research/failed-ui.png').write_bytes(shot.read_bytes())
    shot.unlink()

with open('/tmp/issue-1584-research/ui-rebuild.log','w') as log:
    subprocess.run(['python3','/tmp/issue-1584-research/build-ui.py'],stdout=log,stderr=subprocess.STDOUT,check=True)
print('Restored the JSX factory; extracted UI-independent defaults; corrected native module paths and extracted the request DTO.')
