from pathlib import Path
import subprocess,json
base=Path('/tmp/issue-1584-research')
path=Path('data/meta/seed-registry.lino');text=path.read_text()
if '  seed meanings-controlled-output\n' not in text:text+='  seed meanings-controlled-output\n    bundle true\n    lexicon meaning\n    web true\n'
path.write_text(text)
path=Path('data/seed/meanings-controlled-output.lino')
path.write_text(path.read_text().replace('lexical_identity','lexical-identity').replace('output_constraint','output-constraint'))
# Account for the actual, reviewed browser/native parity additions only.
for name,old,new,explanation in [
 ('formal_ai_worker_solve',1372,1390,'Issue #1584 adds output-only projection at the shared solve boundary and a rewrite return before action planning; the JavaScript root is crate/cnl_output.mjs and the native twin is cnl_output.'),
 ('formal_ai_worker_obligations',478,488,'Corrects the stale ceiling for existing commit ca4426de3 (issue #1166): conditional-introduction parity with the native implementation added ten lines before this PR. This PR does not change that worker module.'),
]:
 path=Path('data/meta/worker-line-budget')/(name+'.lino');text=path.read_text()
 text=text.replace('ceiling '+str(old),'ceiling '+str(new))
 at=text.rfind('"');text=text[:at]+' '+explanation+text[at:];path.write_text(text)
# A reusable, observed background launcher avoids the source host's fixed
# 60-second shell deadline without losing process completion evidence.
Path('experiments/issue-1584/job.mjs').write_text('''// Run through the maintained Formal AI tool host. Supplied commands earn no authorship credit.
import fs from 'node:fs';
import {spawn} from 'node:child_process';
const [mode, filename, ...command] = process.argv.slice(2);
if (mode === 'start') {
  const descriptor = fs.openSync(filename + '.log', 'w');
  const child = spawn(process.execPath, [import.meta.filename, 'run', filename, ...command], {
    detached: true, stdio: ['ignore', descriptor, descriptor],
  });
  fs.writeFileSync(filename + '.pid', String(child.pid));
  child.unref();
  console.log(JSON.stringify({pid: child.pid, log: filename + '.log', exit: filename + '.exit'}));
} else if (mode === 'run') {
  const child = spawn(command[0], command.slice(1), {stdio: 'inherit'});
  child.on('error', error => {fs.writeFileSync(filename + '.exit', '1'); console.error(error.message);});
  child.on('exit', (code, signal) => {
    fs.writeFileSync(filename + '.exit', String(code ?? 1));
    if (signal) console.error('Terminated by ' + signal);
  });
} else throw new Error('Expected start or run');
''')
commands=[
 ('roles',['python3','scripts/generate-role-registry.py']),
 ('seed-registry',['node','scripts/generate-seed-registry.mjs','--write']),
 ('embedded-data',['node','scripts/mirror-package-data.mjs','--write']),
 ('worker-factories',['node','scripts/generate-worker-crate-modules.mjs','--write']),
 ('worker-identities',['node','scripts/generate-worker-prerequisites.mjs','--write']),
 ('typescript',['node','scripts/translate-es.mjs','--write']),
 ('features',['node','scripts/generate-runtime-feature-inventory.mjs','--write']),
 ('status',['node','scripts/render-status.mjs','--write']),
 ('npm-web-search',['node','experiments/issue-1584/job.mjs','start',str(base/'install-web-search'),'npm','install','--prefix',str(base/'ui-tools'),'--ignore-scripts','--no-audit','--no-fund','@link-assistant/web-search@0.11.1']),
 ('specification',['node','experiments/issue-1584/job.mjs','start',str(base/'specification-current'),'node','scripts/check-specification-in-javascript.mjs','--check']),
]
for name,command in commands:
 with (base/(name+'-verify.log')).open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 print(name,result.returncode,flush=True)
 if result.returncode: print((base/(name+'-verify.log')).read_text()[-1600:]);raise SystemExit(result.returncode)
