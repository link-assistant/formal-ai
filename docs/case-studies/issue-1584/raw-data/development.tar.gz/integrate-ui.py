from pathlib import Path

def edit(name, old, new):
    path = Path(name)
    text = path.read_text()
    assert text.count(old) == 1, (name, old[:80], text.count(old))
    path.write_text(text.replace(old, new))

for name in ['js/app/cnl-settings.jsx']:
    Path(name).write_bytes((Path('/tmp/issue-1584-research/files') / name).read_bytes())

edit('js/app/preferences.jsx', '  responseLanguage: "last_message",', '  outputStandard: "cnl-default",\n  lexicalDensity: "standard",\n  responseLanguage: "last_message",')
edit('js/app/preferences.jsx', 'export function normalizeResponseLanguageMode(value) {', '''export const OUTPUT_STANDARDS = ["cnl-default", "asd-ste100", "ace", "gellish", "sbvr", "plain-language", "minimal-english", "e-prime", "basic-english", "special-english", "globish"];

export function normalizeOutputStandard(value) {
  return OUTPUT_STANDARDS.includes(value) ? value : PREFERENCE_DEFAULTS.outputStandard;
}

export function normalizeLexicalDensity(value) {
  if (["standard", "primes", "max-precision"].includes(value)) return value;
  if (typeof value === "string" && /^top-[1-9][0-9]*$/u.test(value) && Number.isSafeInteger(Number(value.slice(4)))) return value;
  return PREFERENCE_DEFAULTS.lexicalDensity;
}

export function normalizeResponseLanguageMode(value) {''')

edit('js/app/application.jsx', 'import { DebuggerView }', 'import { CnlSettings } from "./cnl-settings.jsx";\nimport { DebuggerView }')
edit('js/app/application.jsx', '  normalizeResponseLanguageMode,', '  normalizeOutputStandard, normalizeLexicalDensity, normalizeResponseLanguageMode,')
edit('js/app/application.jsx', '  const [i18nRuntimeTick,', '''  const [outputStandard, setOutputStandard] = useState(normalizeOutputStandard(initialPreferences.current.outputStandard));
  const [lexicalDensity, setLexicalDensity] = useState(normalizeLexicalDensity(initialPreferences.current.lexicalDensity));
  const [i18nRuntimeTick,''')
for name in ['js/app/application.jsx', 'js/app/application-worker-hooks.jsx']:
    path = Path(name)
    text = path.read_text()
    text = text.replace('responseLanguage, preferredLanguage, demoMode', 'responseLanguage, preferredLanguage, outputStandard, lexicalDensity, demoMode')
    text = text.replace('responseLanguageRef, preferredLanguageRef, uiSkinRef', 'responseLanguageRef, preferredLanguageRef, outputStandardRef, lexicalDensityRef, uiSkinRef')
    text = text.replace('preferredLanguageRef, uiSkinRef', 'preferredLanguageRef, outputStandardRef, lexicalDensityRef, uiSkinRef')
    path.write_text(text)

edit('js/app/application.jsx', '    { key: "responseLanguage",', '''    { key: "outputStandard", value: outputStandard, set: setOutputStandard, label: "settings.outputStandard" },
    { key: "lexicalDensity", value: lexicalDensity, set: setLexicalDensity, label: "settings.lexicalDensity" },
    { key: "responseLanguage",''')
edit('js/app/application.jsx', '          </label> : null}<label className="setting-row"><span>{t("settings.theme")}</span>', '''          </label> : null}<CnlSettings {...{t, outputStandard, setOutputStandard, lexicalDensity, setLexicalDensity}} />
          <label className="setting-row"><span>{t("settings.theme")}</span>''')

edit('js/app/application-worker-hooks.jsx', '      preferredLanguage,\n', '      preferredLanguage,\n      outputStandard,\n      lexicalDensity,\n')
edit('js/app/application-worker-hooks.jsx', '\n    preferredLanguage,\n', '\n    preferredLanguage,\n    outputStandard,\n    lexicalDensity,\n')
edit('js/app/application-worker-hooks.jsx', '  const preferredLanguageRef = useRef(preferredLanguage);', '''  const outputStandardRef = useRef(outputStandard);
  React.useEffect(() => { outputStandardRef.current = outputStandard; }, [outputStandard]);
  const lexicalDensityRef = useRef(lexicalDensity);
  React.useEffect(() => { lexicalDensityRef.current = lexicalDensity; }, [lexicalDensity]);
  const preferredLanguageRef = useRef(preferredLanguage);''')
edit('js/app/application-worker-hooks.jsx', '      preferredLanguage: preferredLanguageRef.current,', '      preferredLanguage: preferredLanguageRef.current,\n      outputStandard: outputStandardRef.current,\n      lexicalDensity: lexicalDensityRef.current,')
edit('js/app/desktop-bridge.jsx', '      temperature: normalizeSliderPreference(preferences.temperature, 0),', '''      output_standard: preferences.outputStandard,
      lexical_density: preferences.lexicalDensity,
      temperature: normalizeSliderPreference(preferences.temperature, 0),''')

labels = {
    'en': ['Output standard', 'Vocabulary density', 'Custom top-N', 'Vocabulary size', 'Experimental output controls. Strict compliance with every standard is not yet verified.'],
    'ru': ['Стандарт ответа', 'Плотность словаря', 'Свой top-N', 'Размер словаря', 'Экспериментальные настройки ответа. Строгое соответствие всем стандартам пока не проверено.'],
    'zh': ['输出标准', '词汇密度', '自定义 top-N', '词汇数量', '实验性输出设置。尚未验证对所有标准的严格符合性。'],
    'hi': ['उत्तर का मानक', 'शब्दावली का घनत्व', 'अपना top-N', 'शब्दावली का आकार', 'प्रयोगात्मक उत्तर सेटिंग। सभी मानकों का सख्त अनुपालन अभी सत्यापित नहीं है।'],
}
keys = ['outputStandard', 'lexicalDensity', 'customVocabulary', 'vocabularySize', 'outputVerification']
text = Path('js/i18n-catalog.lino').read_text()
lines = text.splitlines(True)
locale = None
result = []
for line in lines:
    if line.strip() in labels and not line.startswith(' '):
        locale = line.strip()
    result.append(line)
    if line == '  settings\n':
        result.extend('    ' + key + ' "' + value + '"\n' for key, value in zip(keys, labels[locale]))
Path('js/i18n-catalog.lino').write_text(''.join(result))
print('UI controls connected to persisted preferences, worker requests, and desktop HTTP requests.')
