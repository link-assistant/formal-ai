from pathlib import Path
import subprocess

root = Path.cwd()
staged = Path('/tmp/issue-1584-research/files')
for path in sorted(staged.rglob('*')):
    if path.is_file():
        destination = root / path.relative_to(staged)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(path.read_bytes())
