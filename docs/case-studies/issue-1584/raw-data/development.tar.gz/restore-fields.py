from pathlib import Path
import subprocess
path = Path('js/agentic/crate/cnl_output.mjs')
text = path.read_text().replace('.configuration', '.config').replace('{configuration:', '{config:').replace('{configuration, rest:', '{config: configuration, rest:')
path.write_text(text)
for name in ['rust/src/cnl_output/dialogue.rs', 'rust/src/protocol/cnl.rs']:
    path = Path(name)
    text = path.read_text().replace('.configuration', '.config').replace('pub configuration: OutputConfig', 'pub config: OutputConfig')
    text = text.replace('    OutputDirective {\n        configuration,', '    OutputDirective {\n        config: configuration,')
    text = text.replace('        configuration: selected,', '        config: selected,')
    path.write_text(text)
for name, command in [('worker-factories', ['node','scripts/generate-worker-crate-modules.mjs','--write']), ('worker-identities', ['node','scripts/generate-worker-prerequisites.mjs','--write']), ('typescript', ['node','scripts/translate-es.mjs','--write'])]:
    with open('/tmp/issue-1584-research/'+name+'.log','w') as log:
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
print('Kept existing configuration field names on solver and dialogue DTOs.')
