from pathlib import Path
import subprocess
base = Path('/tmp/issue-1584-research/ui-tools')
log = open(base / 'vendor-install.log', 'w')
process = subprocess.Popen(['bash', '-c', 'npm install --ignore-scripts --no-audit --no-fund dompurify@3.4.17 marked@18.1.1 lino-i18n@0.4.0; result=$?; echo "$result" > vendor-install.exit; exit "$result"'], cwd=base, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
(base / 'vendor-install.pid').write_text(str(process.pid))
print(process.pid)
