from pathlib import Path
import subprocess
for name, command in [
    ('cnl-output.test', ['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/cnl-output.test.mjs']),
    ('server.test', ['timeout','600','node','--test','--test-concurrency=1','experiments/issue-1584/server.test.mjs']),
    ('ui-build', ['python3','/tmp/issue-1584-research/build-ui.py']),
]:
    path = Path('/tmp/issue-1584-research') / (name+'.log')
    with path.open('w') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    print(name, result.returncode, path)
    if result.returncode:
        print(path.read_text()[-2400:])
