from pathlib import Path
import subprocess,os
p=Path('/tmp/issue-1584-research')
os.environ['PATH']=str(p/'bin')+':'+os.environ['PATH']
with (p/'gates-final.log').open('w') as output:r=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs'],stdout=output,stderr=subprocess.STDOUT)
print('Full local gates:',r.returncode,flush=True)
raise SystemExit(r.returncode)
