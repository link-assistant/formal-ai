from pathlib import Path
import subprocess
base = Path('/tmp/issue-1584-research/ui-tools')
base.mkdir(exist_ok=True)
(base / 'package.json').write_text('{"private":true,"type":"module"}\n')
log = open(base / 'install.log', 'w')
process = subprocess.Popen(['bash', '-c', 'npm install --ignore-scripts --no-audit --no-fund react@19.3.1 react-dom@19.3.1 @chakra-ui/react@3.37.0 @emotion/react@11.14.0; result=$?; echo "$result" > install.exit; exit "$result"'], cwd=base, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
(base / 'install.pid').write_text(str(process.pid))
print(process.pid, base / 'install.log')
