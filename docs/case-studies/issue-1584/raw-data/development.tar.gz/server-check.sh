#!/usr/bin/env bash
set -e
python3 - <<'PY'
from pathlib import Path
base=Path('/tmp/issue-1584-research/files')
for p in (base/'rust').rglob('*'):
    if p.is_file() and Path(p.relative_to(base)).exists():
        p.write_bytes(Path(p.relative_to(base)).read_bytes())
PY
python3 /tmp/issue-1584-research/stage-files.py
node --test --test-concurrency=1 experiments/issue-1584/server.test.mjs > /tmp/issue-1584-research/server.test.log 2>&1
cat /tmp/issue-1584-research/server.test.log
sed -n '1,80p' rust/src/protocol/content.rs
rg -n 'impl From.*MessageContent|enum MessageContent' rust/src/protocol.rs rust/src/protocol/content.rs
