from pathlib import Path
import subprocess

base=Path('/tmp/issue-1584-research')
path=Path('js/agentic/crate/cnl_output.mjs');text=path.read_text()
old='  const tier = frequencyTier(selected.lexical_density);'
new='''  if (selected.lexical_density === 'max-precision') {
    const result = checkers.lexical_minimum?.(text, language);
    if (result === false) violations.push('lexical_minimum');
    else if (result !== true) unchecked.push('lexical_minimum');
  }
  const tier = frequencyTier(selected.lexical_density);'''
assert old in text;text=text.replace(old,new);path.write_text(text)
path=Path('rust/src/cnl_output/projection.rs');text=path.read_text()
old='    if let OutputDensity::Top(tier) = configuration.density {'
new='''    if configuration.density == OutputDensity::MaxPrecision {
        evidence(
            "lexical_minimum",
            checkers.check("lexical_minimum", text, language),
            &mut violations,
            &mut unchecked,
        );
    }
    if let OutputDensity::Top(tier) = configuration.density {'''
assert old in text;text=text.replace(old,new);path.write_text(text)
path=Path('rust/tests/web/cnl-output.test.mjs');text=path.read_text()
text+='''
test('a finite lexical alternative search does not certify a global minimum', () => {
  const report=validateOutput('I know everything.','en',{
    output_standard:'e-prime',lexical_density:'max-precision'},policy);
  assert.equal(report.compliant,false);
  assert.ok(report.unchecked.includes('lexical_minimum'));
});
'''
path.write_text(text)
commands=[
 ['rustfmt','--edition','2024','rust/src/cnl_output/projection.rs'],
 ['node','scripts/generate-worker-crate-modules.mjs','--write'],
 ['node','scripts/generate-worker-prerequisites.mjs','--write'],
 ['node','scripts/translate-es.mjs','--write'],
 ['node','experiments/issue-1584/job.mjs','start',str(base/'translation-precision'),'node','--max-old-space-size=256','scripts/translate-js-rust.mjs','--write','--meta-language','.meta-language','--jobs','1','js/agentic/crate/cnl_output.mjs'],
]
for index,command in enumerate(commands):
 result=subprocess.run(command,capture_output=True,text=True)
 (base/('precision-repair-'+str(index)+'.log')).write_text(result.stdout+result.stderr)
 print(index,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
