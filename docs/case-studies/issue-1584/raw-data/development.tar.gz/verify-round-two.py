from pathlib import Path
import subprocess
import tarfile
import os

base=Path('/tmp/issue-1584-research')
tools=base/'bin';tools.mkdir(exist_ok=True)
os.environ['PATH']=str(tools)+os.pathsep+os.environ['PATH']
if not (tools/'shellcheck').exists():
    archive=base/'shellcheck.tar.xz'
    download=subprocess.run(['curl','--fail','--location','--max-time','45','--output',str(archive),'https://github.com/koalaman/shellcheck/releases/download/v0.10.0/shellcheck-v0.10.0.linux.x86_64.tar.xz'],capture_output=True,text=True)
    print('shellcheck download',download.returncode,flush=True)
    if download.returncode==0:
        with tarfile.open(archive) as source:
            binary=source.extractfile('shellcheck-v0.10.0/shellcheck').read()
        target=tools/'shellcheck';target.write_bytes(binary);target.chmod(0o755)

commands=[
 ('cnl-tests',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/cnl-output.test.mjs']),
 ('cnl-server-tests',['timeout','600','node','--test','--test-concurrency=1','experiments/issue-1584/server.test.mjs']),
 ('existing-server-tests',['timeout','600','node','--test','--test-concurrency=1','rust/tests/web/server.test.mjs']),
 ('translation-verify',['node','scripts/translate-js-rust.mjs','--verify']),
 ('gates-round-two',['node','experiments/formal_ai_subagent/local-gates.mjs']),
]
failures=[]
for name,command in commands:
    with (base/(name+'.log')).open('w') as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    print(name,result.returncode,flush=True)
    if result.returncode:failures.append(name)
print('Failures:',','.join(failures),flush=True)
raise SystemExit(bool(failures))
