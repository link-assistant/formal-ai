from pathlib import Path
base = Path('/tmp/issue-1584-research/files')
def edit(name, old, new):
    p = base / name
    text = p.read_text()
    assert text.count(old) == 1, (name, old[:80], text.count(old))
    p.write_text(text.replace(old, new))

edit('js/agentic/crate/cnl_output.mjs', "const root = childrenNamed(parse(text), 'cnl_output')[0];", "const parsed = parse(text);\n    const root = parsed.name === 'cnl_output' ? parsed : childrenNamed(parsed, 'cnl_output')[0];")
edit('rust/src/cnl_output.rs', 'let Some(root) = root.children.iter().find(|node| node.name == "cnl_output") else {', 'let Some(root) = (if root.name == "cnl_output" { Some(&root) } else { root.children.iter().find(|node| node.name == "cnl_output") }) else {')
edit('js/agentic/crate/cnl_output.mjs', "export function outputDirective(text, policy = cnlPolicy()) {", "function directiveConfig(mode, policy) {\n  const config = outputConfig({output_standard: mode}, policy);\n  if (config.lexical_density !== 'standard') return {lexical_density: config.lexical_density};\n  if (config.output_standard === 'cnl-default') return config;\n  return {output_standard: config.output_standard};\n}\n\nexport function outputDirective(text, policy = cnlPolicy()) {")
edit('js/agentic/crate/cnl_output.mjs', "config: outputConfig({lexical_density: 'top-' + frequency[1]}, policy)", "config: {lexical_density: 'top-' + frequency[1]}")
edit('js/agentic/crate/cnl_output.mjs', "config: outputConfig({output_standard: item.mode}, policy)", "config: directiveConfig(item.mode, policy)")
edit('js/agentic/crate/cnl_output.mjs', "const config = outputConfig({output_standard: name.trim()}, policy);", "const config = directiveConfig(name.trim(), policy);")
edit('js/agentic/crate/cnl_output.mjs', "if (directive) selected = directive.config;", "if (directive) selected = {...selected, ...directive.config};")
edit('js/agentic/crate/cnl_output.mjs', "return {config: selected, prompt:", "return {config: outputConfig(selected, policy), prompt:")
edit('rust/src/cnl_output/config.rs', 'Top(usize)', 'Top(u64)')
edit('rust/src/cnl_output/config.rs', 'pub fn frequency_tier(value: &str) -> Option<usize>', 'pub fn frequency_tier(value: &str) -> Option<u64>')
edit('rust/src/cnl_output/config.rs', 'usize::try_from(count).ok()', 'Some(count)')
edit('rust/src/cnl_output/projection.rs', '_tier: usize', '_tier: u64')
edit('rust/src/cnl_output/projection.rs', '.then_with(|| left.text.cmp(&right.text))', '.then_with(|| left.text.encode_utf16().cmp(right.text.encode_utf16()))')
edit('rust/src/cnl_output/dialogue.rs', 'pub paraphrase: bool,', 'pub paraphrase: bool,\n    pub density_only: bool,\n    pub reset: bool,')
edit('rust/src/cnl_output/dialogue.rs', 'use super::{output_config, OutputConfig, OutputPolicy};', 'use super::{output_config, OutputConfig, OutputDensity, OutputPolicy, OutputStandard};\n\nfn directive(config: OutputConfig, rest: String, paraphrase: bool) -> OutputDirective {\n    let density_only = config.density != OutputDensity::Standard;\n    let reset = !density_only && config.standard == OutputStandard::CnlDefault;\n    OutputDirective {config, rest, paraphrase, density_only, reset}\n}\n\nfn apply(selected: OutputConfig, directive: &OutputDirective) -> OutputConfig {\n    if directive.reset { return directive.config; }\n    if directive.density_only { OutputConfig {density: directive.config.density, ..selected} }\n    else { OutputConfig {standard: directive.config.standard, ..selected} }\n}')
edit('rust/src/cnl_output/dialogue.rs', 'Some(OutputDirective {config, rest: String::new(), paraphrase: true})', 'Some(directive(config, String::new(), true))')
edit('rust/src/cnl_output/dialogue.rs', 'Some(OutputDirective {config: output_config(Some(mode), None, policy).ok()?, rest: String::new(), paraphrase: true})', 'Some(directive(output_config(Some(mode), None, policy).ok()?, String::new(), true))')
edit('rust/src/cnl_output/dialogue.rs', 'Some(OutputDirective {config, rest: rest.to_owned(), paraphrase: false})', 'Some(directive(config, rest.to_owned(), false))')
edit('rust/src/cnl_output/dialogue.rs', 'if let Some(directive) = output_directive(&turn.content, policy) {selected = directive.config;}', 'if let Some(directive) = output_directive(&turn.content, policy) {selected = apply(selected, &directive);}')
edit('rust/src/cnl_output/dialogue.rs', 'if let Some(directive) = &directive {selected = directive.config;}', 'if let Some(directive) = &directive {selected = apply(selected, directive);}')
p = base / 'js/agentic/cnl-output.test.mjs'
with p.open('a') as f:
    f.write('''
test('density and standard switches preserve the other dimension', () => {
  const history = [{role: 'user', content: 'Use ACE'}, {role: 'assistant', content: 'I know everything.'}];
  assert.deepEqual(outputTurn('Rewrite in max-precision mode', history).config,
    {output_standard: 'ace', lexical_density: 'max-precision'});
  assert.deepEqual(outputTurn('Use ACE', [{role: 'user', content: 'Rewrite using semantic primes only'}]).config,
    {output_standard: 'ace', lexical_density: 'primes'});
  assert.deepEqual(outputTurn('Use simpler words', history, {lexical_density: 'max-precision'}).config,
    {output_standard: 'cnl-default', lexical_density: 'standard'});
  assert.equal(frequencyTier('top-9007199254740991'), 9007199254740991);
});
''')
