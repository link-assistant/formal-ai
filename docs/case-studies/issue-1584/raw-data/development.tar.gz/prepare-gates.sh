#!/usr/bin/env bash
set -e
python3 - <<'PY'
from pathlib import Path
p=Path('rust/src/protocol/cnl.rs')
p.write_text(p.read_text().replace('choice.message.content = rendered.content.clone().into();','choice.message.content = MessageContent::Text(rendered.content.clone());'))
for name in ['experiments/issue-1584/drive.mjs','/tmp/issue-1584-research/files/experiments/issue-1584/drive.mjs']:
    p=Path(name)
    p.write_text(p.read_text().replace("let failed = result.stop === 'steps';", "let failed = result.stop !== 'final' || (mode === 'command' && result.transcript.length === 0);"))
PY
node scripts/translate-es.mjs --write > /tmp/issue-1584-research/translate-es.log 2>&1
node scripts/translate-js-rust.mjs --verify > /tmp/issue-1584-research/translate-js-rust.log 2>&1
rg --files | rg '(^|/)(changelog|changes|CHANGELOG)' | head -25
rg -n 'settings.responseLanguage' data/view/en/translations.lino
rg -n '^import .*from "[^.]' js/app/*.jsx js/app/*.js | head -35
git diff --stat
