from pathlib import Path
import subprocess
root=Path.cwd();base=Path('/tmp/issue-1584-research')
# Model data and validation belong outside the React rendering directory.
(root/'js/preferences').mkdir(exist_ok=True)
for old,new in [('cnl-preferences.js','controlled-output.js'),('preference-defaults.js','defaults.js')]:
 source=root/'js/app'/old
 target=root/'js/preferences'/new
 if source.exists(): source.rename(target)
for path in (root/'js/app').glob('*'):
 if path.suffix not in ['.jsx','.js']: continue
 text=path.read_text().replace('./preference-defaults.js','../preferences/defaults.js').replace('./cnl-preferences.js','../preferences/controlled-output.js')
 text=text.replace('outputStandardRef','outputStandardReference').replace('lexicalDensityRef','lexicalDensityReference')
 path.write_text(text)
path=root/'js/preferences/controlled-output.js'
path.write_text(path.read_text().replace('./preference-defaults.js','./defaults.js'))
# Use the ordinary Rust child-module path; a path attribute is unnecessary.
old=root/'rust/tests/unit/specification/openai_compatibility_output.rs'
new=root/'rust/tests/unit/specification/openai_compatibility/output.rs'
new.parent.mkdir(exist_ok=True)
if old.exists(): old.rename(new)
path=root/'rust/tests/unit/specification/openai_compatibility.rs'
path.write_text(path.read_text().replace('#[path = "openai_compatibility_output.rs"]\nmod output;', 'mod output;'))
# Extract the CLI trace renderer as a cohesive module rather than growing main.
path=root/'rust/src/main.rs';text=path.read_text()
start=text.index('/// Render the solver\'s concrete thinking trace')
end=text.index('\nfn run_chat(',start)
trace=text[start:end].replace('fn print_thinking_trace(', 'pub(crate) fn print_thinking_trace(',1)
(root/'rust/src/cli_thinking.rs').write_text('use formal_ai::{SymbolicAnswer, naturalize_thinking_step_in, thinking_answer_language, thinking_trace_heading};\n\n'+trace+'\n')
text=text[:start]+text[end:]
text=text.replace('mod cli_translate;','mod cli_translate;\nmod cli_thinking;\nuse cli_thinking::print_thinking_trace;')
text=text.replace('    naturalize_thinking_step_in, run_proxy, run_with_formal_ai, thinking_answer_language,\n    thinking_trace_heading,','    run_proxy, run_with_formal_ai,')
path.write_text(text)
# Protocol enum spellings are string data, not abbreviation-bearing key names.
path=root/'data/seed/cnl-output.lino'
lines=path.read_text().splitlines();in_lexeme=False
out=[]
for line in lines:
 if line.startswith('  lexeme '):in_lexeme=True
 if in_lexeme and line.startswith('    frequency '):continue
 out.append(line.replace('mode max-precision', 'mode "max-precision"'))
path.write_text('\n'.join(out)+'\n')
# Share the exact upstream pin already downloaded by the maintained translator.
source=Path('/tmp/formal-ai-meta-language/eb0574d5528babd3b4aadece81590d8e2230b99b')
if not (root/'.meta-language').exists():(root/'.meta-language').symlink_to(source)
# Generate all canonical mirrors after model changes.
for name, command in [
 ('rust-format', ['rustfmt','--edition','2024','--config','skip_children=true','rust/src/main.rs','rust/src/cli_thinking.rs','rust/tests/unit/specification/openai_compatibility.rs','rust/tests/unit/specification/openai_compatibility/output.rs']),
 ('seed-registry',['node','scripts/generate-seed-registry.mjs','--write']),
 ('embedded-data',['python3','scripts/prepare-embedded-data.py']),
 ('worker-factories',['node','scripts/generate-worker-crate-modules.mjs','--write']),
 ('worker-identities',['node','scripts/generate-worker-source-identities.mjs','--write']),
 ('typescript',['node','scripts/translate-es.mjs','--write']),
]:
 with (base/(name+'-repair.log')).open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 print(name,result.returncode)
 if result.returncode:print((base/(name+'-repair.log')).read_text()[-1800:]);raise SystemExit(result.returncode)
# Removed generated models are not active entry points any more.
for name in ['cnl-preferences.ts','preference-defaults.ts']:
 path=root/'ts/app'/name
 if path.exists():path.unlink()
print('Gate repairs generated.')
