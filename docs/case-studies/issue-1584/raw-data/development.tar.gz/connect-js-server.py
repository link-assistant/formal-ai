from pathlib import Path
def edit(name, old, new):
    p=Path(name); text=p.read_text()
    if new in text: return
    assert text.count(old)==1,(name,old[:90],text.count(old))
    p.write_text(text.replace(old,new))

edit('js/server/chat-request.mjs', "import { serverMessage } from './messages.mjs';", "import { serverMessage } from './messages.mjs';\nimport {parseOutputOptions} from './cnl-output.mjs';")
edit('js/server/chat-request.mjs', '  return {\n    model: optionalString(object, \'model\'),', '''  let output;
  try { output = parseOutputOptions(object, optionalString); }
  catch (error) { throw new RequestShapeError(error.message); }
  return {
    ...output,
    model: optionalString(object, 'model'),''')
edit('js/server/main.mjs', "import { pathToFileURL } from 'node:url';", "import { pathToFileURL } from 'node:url';\nimport {serverOutputConfig} from './cnl-output.mjs';")
edit('js/server/main.mjs', '    unsupported: null,', '''    unsupported: null,
    ...(env.FORMAL_AI_OUTPUT_STANDARD ? {outputStandard:env.FORMAL_AI_OUTPUT_STANDARD} : {}),
    ...(env.FORMAL_AI_LEXICAL_DENSITY ? {lexicalDensity:env.FORMAL_AI_LEXICAL_DENSITY} : {}),''')
edit('js/server/main.mjs', "    if (name === '--host') options.host = value();", "    if (name === '--output-standard') {options.outputStandard=value();if(!options.outputStandard)options.unsupported=arg;}\n    else if (name === '--lexical-density') {options.lexicalDensity=value();if(!options.lexicalDensity)options.unsupported=arg;}\n    else if (name === '--host') options.host = value();")
edit('js/server/main.mjs', "logger, prerequisiteGrantJson = env.FORMAL_AI_PREREQUISITE_GRANT_JSON ?? null }", "logger, outputStandard = env.FORMAL_AI_OUTPUT_STANDARD, lexicalDensity = env.FORMAL_AI_LEXICAL_DENSITY, prerequisiteGrantJson = env.FORMAL_AI_PREREQUISITE_GRANT_JSON ?? null }")
edit('js/server/main.mjs', '      prerequisiteGrant,\n      liveMemory,', '''      prerequisiteGrant,
      outputConfig: serverOutputConfig({output_standard:outputStandard,lexical_density:lexicalDensity}),
      liveMemory,''')
edit('js/server/solve.mjs', '    intent: String(result?.intent', '    ...(result?.outputProjection ? {output_projection:result.outputProjection} : {}),\n    intent: String(result?.intent')
edit('js/server/solve.mjs', 'const result = await ctx.worker.solve(prompt, history);', 'const result = await ctx.worker.solve(prompt, history, ctx.outputConfig ?? {});')
edit('js/server/openai.mjs', "import { requestScope, runInRequestScope } from './standing-scope.mjs';", "import { requestScope, runInRequestScope } from './standing-scope.mjs';\nimport {projectServerAnswer, requestOutputTurn} from './cnl-output.mjs';")
edit('js/server/openai.mjs', "    id: stableId('chatcmpl', prompt),", "    ...(symbolic.output_projection ? {output_projection:symbolic.output_projection} : {}),\n    id: stableId('chatcmpl', prompt),")
edit('js/server/openai.mjs', 'export async function createChatCompletion(ctx, request) {', '''export async function createChatCompletion(ctx, request) {
  const original = chatPromptAndHistory(request.messages);
  const turn = requestOutputTurn(original.prompt, original.history, request, ctx.outputConfig);
  const selected = {...ctx, outputConfig:turn.config};
  // A rewrite is resolved before memory lookup, planning or tool permission paths.
  if (turn.rewrite !== null) {
    const symbolic = await projectServerAnswer(selected, {intent:'cnl_paraphrase',answer:turn.rewrite,
      confidence:1,evidence_links:['cnl:paraphrase'],thinking_steps:[],links_notation:''}, turn.config);
    return chatCompletionFromSymbolic(request, original.prompt, symbolic);
  }
  const completion = await createUnprojectedChatCompletion(selected, request);
  const choice = completion.choices[0];
  if (choice && typeof choice.message.content === 'string') {
    const projected = await projectServerAnswer(selected, {answer:choice.message.content,
      output_projection:completion.output_projection}, turn.config);
    choice.message.content = projected.answer;
    completion.output_projection = projected.output_projection;
    completion.usage.completion_tokens = estimateTokens(projected.answer);
    completion.usage.total_tokens = completion.usage.prompt_tokens + completion.usage.completion_tokens;
  }
  return completion;
}

async function createUnprojectedChatCompletion(ctx, request) {''')
edit('js/server/openai.mjs', '  if (completion.learning_trace) out.learning_trace = completion.learning_trace;', '  if (completion.output_projection) out.output_projection = completion.output_projection;\n  if (completion.learning_trace) out.learning_trace = completion.learning_trace;')
edit('js/server/openai.mjs', "body += sseChunk(base, { index: 0, delta: {}, finish_reason:", "body += sseChunk({...base,...(completion.output_projection ? {output_projection:completion.output_projection} : {})}, { index: 0, delta: {}, finish_reason:")
