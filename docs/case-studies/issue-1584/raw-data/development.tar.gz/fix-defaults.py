from pathlib import Path
import subprocess
path = Path('js/app/preferences.jsx')
text = path.read_text()
start = text.index('export const EXTERNAL_TRUSTED_SERVICES = [')
end = text.index('\n];', start) + 3
catalog = text[start:end]
text = text[:start] + text[end:]
text = text.replace('import {PREFERENCE_DEFAULTS}', 'import {PREFERENCE_DEFAULTS, EXTERNAL_TRUSTED_SERVICES}').replace('export {PREFERENCE_DEFAULTS}', 'export {PREFERENCE_DEFAULTS, EXTERNAL_TRUSTED_SERVICES}')
path.write_text(text)
path = Path('js/app/preference-defaults.js')
path.write_text(catalog + '\n\n' + path.read_text())
with open('/tmp/issue-1584-research/ui-rebuild.log','w') as log:
    subprocess.run(['python3','/tmp/issue-1584-research/build-ui.py'],stdout=log,stderr=subprocess.STDOUT,check=True)
print('Moved the shared service catalog with the defaults that use it.')
