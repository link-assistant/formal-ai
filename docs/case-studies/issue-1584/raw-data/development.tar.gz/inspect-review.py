from pathlib import Path
import subprocess,json,os,signal

base=Path('/tmp/issue-1584-research')
commands=[
 ('latest-issue',['gh','issue','view','https://github.com/link-assistant/formal-ai/issues/1584','--json','body,comments,title,state,url']),
 ('latest-conversation',['gh','api','repos/link-assistant/formal-ai/issues/1585/comments','--paginate']),
 ('latest-inline',['gh','api','repos/link-assistant/formal-ai/pulls/1585/comments','--paginate']),
 ('latest-reviews',['gh','api','repos/link-assistant/formal-ai/pulls/1585/reviews','--paginate']),
 ('latest-runs',['gh','run','list','--repo','link-assistant/formal-ai','--branch','issue-1584-49c73d39af58','--limit','10','--json','databaseId,workflowName,conclusion,status,createdAt,headSha']),
 ('fetch-main',['git','fetch','origin','main']),
 ('main-ancestor',['git','merge-base','--is-ancestor','origin/main','HEAD']),
]
for name,command in commands:
 result=subprocess.run(command,capture_output=True,text=True)
 (base/(name+'.json' if name.startswith('latest') else name+'.log')).write_text(result.stdout+result.stderr)
 print(name,result.returncode,flush=True)
 if name=='main-ancestor': print('Main ancestor of HEAD:',result.returncode==0,flush=True)
pidfile=base/'ui-server.pid'
if pidfile.exists():
 try:os.kill(int(pidfile.read_text()),signal.SIGTERM)
 except ProcessLookupError:pass
 pidfile.unlink()
 print('Stopped preview server',flush=True)
