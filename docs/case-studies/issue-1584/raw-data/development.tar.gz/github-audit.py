from pathlib import Path
import subprocess
import json
base = Path('/tmp/issue-1584-research/github-audit')
base.mkdir(exist_ok=True)
repository = 'link-assistant/formal-ai'
def capture(name, args):
    result = subprocess.run(['gh',*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    (base/(name+'.json')).write_text(result.stdout)
    (base/(name+'.stderr')).write_text(result.stderr)
    return json.loads(result.stdout) if result.returncode == 0 and result.stdout.strip() else None
issue = capture('issue',['issue','view','1584','--repo',repository,'--json','title,body,comments,state,url'])
pull = capture('pull',['pr','view','1585','--repo',repository,'--json','title,body,isDraft,headRefOid,baseRefName,statusCheckRollup,url'])
for name, endpoint in [('issue-comments','issues/1584/comments'),('pull-comments','issues/1585/comments'),('inline-comments','pulls/1585/comments'),('reviews','pulls/1585/reviews')]:
    result = capture(name,['api','repos/'+repository+'/'+endpoint,'--paginate'])
    print(name, len(result or []))
    for item in result or []:
        print(item.get('html_url'),item.get('created_at',item.get('submitted_at')),item.get('body',''))
runs = capture('runs',['run','list','--repo',repository,'--branch','issue-1584-49c73d39af58','--limit','10','--json','databaseId,workflowName,status,conclusion,createdAt,headSha'])
print('PR',pull)
print('Runs',runs)
for run in runs or []:
    if run['conclusion'] in ['success','skipped']:
        continue
    path = base/(str(run['databaseId'])+'.log')
    with path.open('w') as log:
        result = subprocess.run(['gh','run','view',str(run['databaseId']),'--repo',repository,'--log'],stdout=log,stderr=subprocess.STDOUT)
    print('Preserved log request',run['databaseId'],result.returncode,path)
print('Branch',subprocess.check_output(['git','branch','--show-current'],text=True).strip())
