from pathlib import Path
import re
import subprocess

for root in [Path('js'), Path('rust/src'), Path('experiments/issue-1584')]:
    for path in root.rglob('*'):
        if not path.is_file() or path.suffix not in ['.mjs', '.js', '.rs'] or 'worker/formal_ai_worker_crate_' in str(path):
            continue
        text = path.read_text()
        changed = text.replace('outputConfig', 'outputConfiguration').replace('directiveConfig', 'directiveConfiguration').replace('serverOutputConfig', 'serverOutputConfiguration').replace('output_config', 'output_configuration')
        if path.name in ['cnl_output.mjs', 'cnl-output.mjs'] or path.parent.name == 'cnl_output' or str(path) == 'rust/src/protocol/cnl.rs':
            changed = re.sub(r'\bconfig\b', 'configuration', changed)
            changed = re.sub(r'\bsolver_config\b', 'solver_configuration', changed)
        if changed != text:
            path.write_text(changed)

Path('rust/src/cnl_output/configuration.rs').write_bytes(Path('rust/src/cnl_output/config.rs').read_bytes())
Path('rust/src/cnl_output/config.rs').unlink()
path = Path('rust/src/cnl_output.rs')
path.write_text(path.read_text().replace('mod config;', 'mod configuration;').replace('pub use config::', 'pub use configuration::'))

source = Path('js/agentic/cnl-output.test.mjs')
test = source.read_text().replace("from './host.mjs'", "from '../../../js/agentic/host.mjs'").replace("from '../server/lino.mjs'", "from '../../../js/server/lino.mjs'").replace("from './crate/cnl_output.mjs'", "from '../../../js/agentic/crate/cnl_output.mjs'")
test += '''
test('ambiguous contractions cannot certify E-Prime', () => {
  for (const text of ["John's tired.", "John's hat fell.", "I ain't ready.", "Y'all're here."]) {
    assert.equal(validateOutput(text, 'en', {output_standard: 'e-prime'}).compliant, false, text);
  }
});
'''
Path('rust/tests/web/cnl-output.test.mjs').write_text(test)
source.unlink()
Path('ts/agentic/cnl-output.test.mts').unlink(missing_ok=True)

path = Path('rust/src/cnl_output/projection.rs')
text = path.read_text()
old = '''            } else if tokens
                .iter()
                .any(|word| profile.forbidden.contains(&word.replace('’', "'")))
            {
                violations.push("forbidden_word".to_owned());
            }'''
new = '''            } else {
                let words: Vec<_> = tokens.iter().map(|word| word.replace('’', "'")).collect();
                if words.iter().any(|word| profile.forbidden.contains(word) || word.ends_with("'m") || word.ends_with("'re")) {
                    violations.push("forbidden_word".to_owned());
                }
                if words.iter().any(|word| word.ends_with("'s") || word == "ain't") {
                    unchecked.push("e_prime_contraction".to_owned());
                }
            }'''
assert old in text
text = text.replace(old,new)
text = text.replace('    pub document: OutputDocument,\n    pub report:', '    pub document: OutputDocument,\n    pub links_notation: String,\n    pub report:')
text = text.replace('        document: document.clone(),\n        report,', '        document: document.clone(),\n        links_notation: output_links_notation(document),\n        report,')
path.write_text(text)

# Keep source identities and maintained projections current before the next boot.
for name, command in [
    ('worker-factories', ['node','scripts/generate-worker-crate-modules.mjs','--write']),
    ('worker-identities', ['node','scripts/generate-worker-prerequisites.mjs','--write']),
    ('typescript', ['node','scripts/translate-es.mjs','--write']),
]:
    with open('/tmp/issue-1584-research/'+name+'.log','w') as log:
        subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
print('Renamed new abbreviations, moved tests behind the host boundary, synchronized E-Prime evidence and graph metadata.')
