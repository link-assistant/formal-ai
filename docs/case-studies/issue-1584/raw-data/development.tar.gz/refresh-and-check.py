from pathlib import Path
import subprocess,json
base=Path('/tmp/issue-1584-research')
commands=[
 ('embedded-data',['node','scripts/mirror-package-data.mjs','--write']),
 ('worker-factories',['node','scripts/generate-worker-crate-modules.mjs','--write']),
 ('worker-identities',['node','scripts/generate-worker-prerequisites.mjs','--write']),
 ('typescript',['node','scripts/translate-es.mjs','--write']),
 ('ui-boundary',['python3','scripts/check-web-ui-boundary.py']),
 ('abbreviations',['node','scripts/measure-abbreviations.mjs','--check']),
 ('notation',['node','scripts/measure-notation.mjs','--check']),
 ('specification',['node','scripts/check-specification-in-javascript.mjs','--check']),
]
for name,command in commands:
 log=base/(name+'-updated.log')
 with log.open('w') as out:result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 print(name,result.returncode,log.read_text()[-500:])
 if result.returncode and name in ['embedded-data','worker-factories','worker-identities','typescript']:raise SystemExit(result.returncode)
for name in ['cnl-preferences.ts','preference-defaults.ts']:
 path=Path('ts/app')/name
 if path.exists():path.unlink()
