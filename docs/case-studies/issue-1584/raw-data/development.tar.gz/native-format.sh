#!/usr/bin/env bash
set -e
cp rust/src/cnl_output/config.rs /tmp/issue-1584-research/files/rust/src/cnl_output/config.rs
cp rust/src/cnl_output.rs /tmp/issue-1584-research/files/rust/src/cnl_output.rs
python3 /tmp/issue-1584-research/stage-files.py
mapfile -t cnl_rust_files < <(git diff --name-only -- '*.rs'; git ls-files --others --exclude-standard -- '*.rs')
rustfmt --edition 2024 --config skip_children=true "${cnl_rust_files[@]}" > /tmp/issue-1584-research/rustfmt.log 2>&1
cat /tmp/issue-1584-research/rustfmt.log
rg -n 'fn detect|From<String> for MessageContent|pub fn plain_text|pub config:|struct SolverConfig' rust/src/language.rs rust/src/protocol/content.rs rust/src/solver.rs
sed -n '1,90p' rust/tests/web/server.test.mjs
cat scripts/run-desktop-lib-tests.sh
