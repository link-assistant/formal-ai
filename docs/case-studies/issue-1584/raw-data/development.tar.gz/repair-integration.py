from pathlib import Path
import subprocess

base = Path('/tmp/issue-1584-research')
path=Path('js/server/openai.mjs');text=path.read_text()
old='  const completion = await createUnprojectedChatCompletion(selected, request);'
new='''  // Strip a recognized output directive only from the latest plain-text user
  // message. Preserve structured content, tool results and command arguments.
  let planningRequest = request;
  const latest = request.messages.findLastIndex(message => message.role.toLowerCase() === 'user');
  const message = request.messages[latest];
  if (turn.prompt !== original.prompt && typeof message?.content === 'string') {
    const start = message.content.indexOf(original.prompt);
    if (start >= 0) {
      const content = message.content.slice(0, start) + turn.prompt + message.content.slice(start + original.prompt.length);
      planningRequest = {...request, messages:request.messages.map((item,index) => index === latest ? {...item,content} : item)};
    }
  }
  const completion = await createUnprojectedChatCompletion(selected, planningRequest);'''
assert old in text;text=text.replace(old,new);path.write_text(text)
path=Path('rust/src/protocol/cnl.rs');text=path.read_text()
old='        create_unprojected_chat_completion(request, &selected, memory_events)'
new='''        let mut planning_request = request.clone();
        if turn.prompt != prompt {
            if let Some(message) = planning_request.messages.iter_mut().rev()
                .find(|message| message.role.eq_ignore_ascii_case("user")) {
                if let MessageContent::Text(content) = &mut message.content {
                    if let Some(start) = content.find(&prompt) {
                        content.replace_range(start..start + prompt.len(), &turn.prompt);
                    }
                }
            }
        }
        create_unprojected_chat_completion(&planning_request, &selected, memory_events)'''
assert old in text;text=text.replace(old,new);path.write_text(text)
path=Path('rust/src/server.rs');text=path.read_text()
old='    body.push_str(&sse_chunk(&base, &final_chunk));'
new='''    let mut final_base = base.clone();
    if let Some(projection) = &completion.output_projection {
        final_base["output_projection"] = projection.clone();
    }
    body.push_str(&sse_chunk(&final_base, &final_chunk));'''
assert old in text;text=text.replace(old,new);path.write_text(text)
path=Path('js/worker/formal_ai_worker_solve.js');text=path.read_text()
old='    content: answer.content,\n    confidence: answer.confidence,'
assert old in text;text=text.replace(old,'    content: answer.content,\n    outputProjection: answer.outputProjection || null,\n    confidence: answer.confidence,');path.write_text(text)
path=Path('experiments/issue-1584/server.test.mjs');text=path.read_text()
text=text.replace("import {parseArgs, startServer}","import {requestOutputTurn} from '../../js/server/cnl-output.mjs';\nimport {parseArgs, startServer}")
text+='''
test('request density aliases preserve the configured named profile', () => {
  for (const alias of ['dense','max-precision','primes','top-237']) {
    const turn=requestOutputTurn('hello',[],{output_standard:alias},{output_standard:'ace'});
    assert.equal(turn.config.output_standard,'ace');
    assert.equal(turn.config.lexical_density,alias === 'dense' ? 'max-precision' : alias);
  }
  const named=requestOutputTurn('hello',[],{output_standard:'e-prime'},{lexical_density:'top-237'});
  assert.deepEqual(named.config,{output_standard:'e-prime',lexical_density:'top-237'});
});
'''
path.write_text(text)
path=Path('data/seed/cnl-output.lino');text=path.read_text()
text=text.replace('  profile plain-language\n    aliases "Plain Language|Plain English|ISO 24495-1"\n    maximum-words 20','  profile plain-language\n    aliases "Plain Language|Plain English|ISO 24495-1"')
path.write_text(text)
commands=[
 ['rustfmt','--edition','2024','rust/src/protocol/cnl.rs','rust/src/server.rs'],
 ['node','scripts/generate-seed-registry.mjs','--write'],
 ['python3','scripts/generate-role-registry.py'],
 ['node','scripts/mirror-package-data.mjs','--write'],
 ['node','scripts/generate-worker-crate-modules.mjs','--write'],
 ['node','scripts/generate-worker-prerequisites.mjs','--write'],
 ['node','scripts/translate-es.mjs','--write'],
 ['node','scripts/lib/generate-native-specification-programs.mjs'],
 ['git','add','data','docs/status.md','docs/screenshots/issue-1584','experiments/issue-1584','js','rust','scripts/generate-worker-crate-modules.mjs','scripts/lib/generated-native-programs.mjs','ts'],
 ['node','experiments/issue-1584/job.mjs','start',str(base/'translation-cnl'),'node','--max-old-space-size=256','scripts/translate-js-rust.mjs','--write','--meta-language','.meta-language','--jobs','1','js/agentic/crate/cnl_output.mjs'],
]
for index,command in enumerate(commands):
  result=subprocess.run(command,capture_output=True,text=True)
  (base/('integration-repair-'+str(index)+'.log')).write_text(result.stdout+result.stderr)
  print(index,result.returncode,(result.stdout+result.stderr)[-700:],flush=True)
  if result.returncode: raise SystemExit(result.returncode)
