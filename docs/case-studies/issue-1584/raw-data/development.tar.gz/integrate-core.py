from pathlib import Path

def edit(name, old, new):
    p = Path(name)
    text = p.read_text()
    if new in text:
        return
    assert text.count(old) == 1, (name, old[:100], text.count(old))
    p.write_text(text.replace(old, new))

edit('data/meta/seed-registry.lino', '  seed code-example-parts\n', '  seed cnl-output\n    bundle true\n    web true\n  seed code-example-parts\n')
edit('scripts/generate-worker-crate-modules.mjs', "  'crate/command_output_contract.mjs',", "  'crate/cnl_output.mjs',\n  'crate/command_output_contract.mjs',")
edit('rust/src/lib.rs', 'pub mod cloud_sync;\n', 'pub mod cloud_sync;\npub mod cnl_output;\n')
edit('rust/src/solver.rs', '    pub forced_response_language: Option<&\'static str>,', '    pub forced_response_language: Option<&\'static str>,\n    /// Output constraints never restrict the accepted input grammar.\n    pub output: crate::cnl_output::OutputConfig,')
edit('rust/src/solver.rs', '            forced_response_language: None,', '            forced_response_language: None,\n            output: crate::cnl_output::OutputConfig::default(),')
edit('rust/src/solver.rs', '        let _turn = crate::server::begin_turn(prompt);\n        let mut log', '''        let output_turn = crate::cnl_output::output_turn(prompt, history, self.config.output, crate::cnl_output::cnl_policy());
        let prompt = output_turn.prompt.as_str();
        let _turn = crate::server::begin_turn(prompt);
        let mut log''')
edit('rust/src/solver.rs', '            log.append("impulse", prompt.to_owned());', '''            if let Some(text) = &output_turn.rewrite {
                return finalize_simple(prompt, &mut log, "cnl_paraphrase", "response:cnl_paraphrase",
                    &crate::cnl_output::output_source(text, detect_language(text).slug(), crate::cnl_output::cnl_policy()), 1.0);
            }
            log.append("impulse", prompt.to_owned());''')
edit('rust/src/solver.rs', '        crate::meta_reasoner::resolve_impasse(prompt, &mut answer, &mut log);', '''        if output_turn.rewrite.is_none() {
            crate::meta_reasoner::resolve_impasse(prompt, &mut answer, &mut log);
        }''')
edit('rust/src/solver.rs', '        self.run_meta_procedure(prompt, history, probability_store, &mut answer, &mut log);', '''        if output_turn.rewrite.is_none() {
            self.run_meta_procedure(prompt, history, probability_store, &mut answer, &mut log);
        }
        let output_language = self.config.forced_response_language.unwrap_or_else(|| detect_language(&answer.answer).slug());
        let rendered = crate::cnl_output::render_output(
            &crate::cnl_output::formalize_output(&answer.answer, output_language, crate::cnl_output::cnl_policy()),
            output_turn.config, crate::cnl_output::cnl_policy(), &());
        if output_turn.config != crate::cnl_output::OutputConfig::default() || rendered.content != answer.answer {
            log.append("cnl_output", serde_json::to_string(&rendered.report).expect("output report"));
            answer.links_notation.push_str(&crate::cnl_output::output_links_notation(&rendered.document));
        }
        answer.answer = rendered.content;''')

edit('js/worker/formal_ai_worker_solve.js', '  // R1188-U1: read the hydrated seed before answering (a no-op once loaded).\n  await loadSeed();\n', '''  // R1188-U1: read the hydrated seed before answering (a no-op once loaded).
  await loadSeed();
  const cnl = crateModule("crate/cnl_output.mjs");
  const turn = cnl.outputTurn(prompt, history || [], {
    output_standard: options.output_standard ?? prefs?.outputStandard,
    lexical_density: options.lexical_density ?? prefs?.lexicalDensity,
  });
  prompt = turn.prompt;
  const project = (answer) => {
    if (!answer || typeof answer.content !== "string") return answer;
    const language = options.forcedResponseLanguage || detectLanguage(answer.content);
    const document = cnl.formalizeOutput(answer.content, language);
    const rendered = cnl.renderOutput(document, turn.config);
    return {...answer, content: rendered.content, outputProjection: rendered};
  };
  if (turn.rewrite !== null) {
    const language = detectLanguage(turn.rewrite);
    return project({intent: "cnl_paraphrase", content: cnl.outputSource(turn.rewrite, language),
      confidence: 1, evidence: ["cnl:paraphrase"], steps: [], events: [], toolCalls: []});
  }
''')
edit('js/worker/formal_ai_worker_solve.js', '    if (diagnostic) return diagnostic;', '    if (diagnostic) return project(diagnostic);')
edit('js/worker/formal_ai_worker_solve.js', '    return metaAttachLearned(await metaRunProcedure(prompt, await metaResolveImpasse(prompt, answer, prefs), subTask));', '    return project(metaAttachLearned(await metaRunProcedure(prompt, await metaResolveImpasse(prompt, answer, prefs), subTask)));')

edit('js/agentic/crate/summarization.mjs', "import { cached } from '../host.mjs';", "import { cached } from '../host.mjs';\nimport { formalizeOutput, renderOutput } from './cnl_output.mjs';")
edit('js/agentic/crate/summarization.mjs', "const CLAMP_TRAILING = new Set(", '''/** Controlled projection applies after statement selection, with its own evidence.
 * Mirrors `fn deformalize_controlled` in rust/src/summarization/mod.rs. */
export function deformalizeControlled(statements, language = 'en', config = {}) {
  return renderOutput(formalizeOutput(deformalize(statements), language), config);
}

const CLAMP_TRAILING = new Set(''')
edit('rust/src/summarization/mod.rs', 'pub mod concise_dependency;', '''/// Controlled rendering keeps the selected statements separate from output constraints.
pub fn deformalize_controlled(statements: &[Statement], language: &str, config: crate::cnl_output::OutputConfig) -> crate::cnl_output::RenderedOutput {
    let policy = crate::cnl_output::cnl_policy();
    crate::cnl_output::render_output(&crate::cnl_output::formalize_output(&deformalize(statements), language, policy), config, policy, &())
}

pub mod concise_dependency;''')
