from pathlib import Path
import subprocess

base=Path('/tmp/issue-1584-research')
commands=[
 ['node','scripts/generate-worker-prerequisites.mjs','--write'],
 ['node','scripts/translate-es.mjs','--write'],
 ['node','scripts/generate-runtime-feature-inventory.mjs','--write'],
 ['node','scripts/check-worker-line-budget.mjs'],
 ['node','scripts/translate-js-rust.mjs','--verify'],
 ['git','add','data','docs/status.md','docs/screenshots/issue-1584','experiments/issue-1584','js','rust','scripts/generate-worker-crate-modules.mjs','scripts/lib/generated-native-programs.mjs','ts','changelog.d/20261117_134000_controlled_output_preview.md'],
]
for index,command in enumerate(commands):
 with (base/f'prepare-final-{index}.log').open('w') as output:r=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
 print(index,r.returncode,flush=True)
 if r.returncode:print((base/f'prepare-final-{index}.log').read_text()[-2000:]);raise SystemExit(r.returncode)
files=subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).splitlines()
files=[f for f in files if f.endswith('.rs') and not f.startswith('rust/tests/fixtures/') and f!='rust/src/seed/embedded_registry.rs']
with (base/'rustfmt-handwritten.log').open('w') as output:r=subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true','--check',*files],stdout=output,stderr=subprocess.STDOUT)
print('rustfmt handwritten',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
(base/'run-final-gates.py').write_text("from pathlib import Path\nimport subprocess,os\np=Path('/tmp/issue-1584-research')\nos.environ['PATH']=str(p/'bin')+':'+os.environ['PATH']\nwith (p/'gates-final.log').open('w') as output:r=subprocess.run(['node','experiments/formal_ai_subagent/local-gates.mjs'],stdout=output,stderr=subprocess.STDOUT)\nprint('Full local gates:',r.returncode,flush=True)\nraise SystemExit(r.returncode)\n")
subprocess.run(['node','experiments/issue-1584/job.mjs','start',str(base/'verification-final'),'python3',str(base/'run-final-gates.py')],check=True)
