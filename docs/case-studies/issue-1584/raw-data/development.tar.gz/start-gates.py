from pathlib import Path
import subprocess

base = Path('/tmp/issue-1584-research')
log = open(base / 'local-gates.log', 'w')
process = subprocess.Popen(['bash', '-c', 'node experiments/formal_ai_subagent/local-gates.mjs; result=$?; echo "$result" > /tmp/issue-1584-research/local-gates.exit; exit "$result"'], stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
(base / 'local-gates.pid').write_text(str(process.pid))
print('Local gates running:', process.pid, 'log:', base / 'local-gates.log')
