from pathlib import Path
import subprocess

# Remove unused summarization entry points: all live solver paths project after
# statement selection. Keeping a second, uncalled entry point adds no behavior.
for name in ['js/agentic/crate/summarization.mjs', 'rust/src/summarization/mod.rs']:
    Path(name).write_bytes(subprocess.check_output(['git', 'show', 'HEAD:' + name]))

for name in ['experiments/issue-1584/drive.mjs', '/tmp/issue-1584-research/files/experiments/issue-1584/drive.mjs']:
    path = Path(name)
    text = path.read_text()
    text = text.replace('\\"', '"')
    path.write_text(text)

for name in ['js/agentic/crate/cnl_output.mjs']:
    path = Path(name)
    text = path.read_text().replace("else if (tokens.some(word => profile.forbidden.includes(word.replaceAll('’', \"'\")))) violations.push('forbidden_word');", """else {
      const words = tokens.map(word => word.replaceAll('’', "'"));
      if (words.some(word => profile.forbidden.includes(word) || /'(?:m|re)$/u.test(word))) violations.push('forbidden_word');
      if (words.some(word => word.endsWith("'s") || word === "ain't")) unchecked.push('e_prime_contraction');
    }""")
    text = text.replace("return {text, notice, content: notice ? notice + '\\n\\n' + text : text, document, report};", "return {text, notice, content: notice ? notice + '\\n\\n' + text : text, document,\n    links_notation: outputLinksNotation(document), report};")
    path.write_text(text)

path = Path('rust/src/cnl_output/projection.rs')
text = path.read_text()
print(text[text.index('    let mut violations'):text.index('    if config.density ==')])
print(text[text.index('pub struct RenderedOutput'):])

# Native adapter was corrected after the last staging pass. Synchronize before
# any further staged-file copies, so its MessageContent fix cannot be lost.
for stage in Path('/tmp/issue-1584-research/files').rglob('*'):
    if stage.is_file():
        actual = Path(stage.relative_to('/tmp/issue-1584-research/files'))
        if actual.exists():
            stage.write_bytes(actual.read_bytes())

for command in [
    ['node', 'scripts/generate-worker-crate-modules.mjs', '--write'],
    ['node', 'scripts/generate-worker-prerequisites.mjs', '--write'],
    ['node', 'scripts/translate-es.mjs', '--write'],
    ['node', 'scripts/translate-js-rust.mjs', '--verify'],
]:
    subprocess.run(command, check=True)
