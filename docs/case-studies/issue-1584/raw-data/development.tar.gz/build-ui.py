from pathlib import Path
import subprocess
import os

root = Path.cwd()
base = Path('/tmp/issue-1584-research')
modules = base / 'ui-tools/node_modules'
target = root / 'node_modules'
for entry in modules.iterdir():
    if entry.name.startswith('.'):
        continue
    if entry.name.startswith('@'):
        (target / entry.name).mkdir(exist_ok=True)
        for child in entry.iterdir():
            destination = target / entry.name / child.name
            if not destination.exists():
                destination.symlink_to(child)
    elif not (target / entry.name).exists():
        (target / entry.name).symlink_to(entry)
site = base / 'ui-site'
site.mkdir(exist_ok=True)
for entry in (root / 'js').iterdir():
    if entry.name in ['app.js', 'vendor.bundle.js']:
        continue
    destination = site / entry.name
    if not destination.exists():
        destination.symlink_to(entry)
for name, source in [('seed', root / 'data/seed'), ('data', root / 'data')]:
    if not (site / name).exists():
        (site / name).symlink_to(source)
with (base / 'ui-build.log').open('w') as log:
    for entry, destination in [('js/app/main.jsx', 'app.js'), ('js/vendor-entry.js', 'vendor.bundle.js')]:
        subprocess.run(['bun', 'build', entry, '--outfile', str(site / destination), '--target', 'browser', '--format', 'iife', '--production', '--minify-whitespace', '--minify-syntax'], stdout=log, stderr=subprocess.STDOUT, check=True)
print((base / 'ui-build.log').read_text())
if not (base / 'ui-server.pid').exists():
    log = (base / 'ui-server.log').open('w')
    process = subprocess.Popen(['python3', '-m', 'http.server', '15840', '--bind', '127.0.0.1', '--directory', str(site)], stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    (base / 'ui-server.pid').write_text(str(process.pid))
    print('Preview server', process.pid)
