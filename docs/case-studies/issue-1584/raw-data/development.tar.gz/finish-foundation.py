from pathlib import Path
import subprocess
base=Path('/tmp/issue-1584-research')
# Each protocol value names an authored, inspectable concept; this does not
# assert that a renderer or an independent standard checker exists.
profiles={
 'cnl-default':'A requested output profile combining controlled-language clarity constraints. Selecting this profile is not evidence that every constraint passed.',
 'asd-ste100':'The ASD Simplified Technical English output standard, including its approved technical vocabulary and writing rules.',
 'ace':'Attempto Controlled English: a controlled English language with a specified grammar and interpretation into logic.',
 'gellish':'A formalized language that expresses typed relations between dictionary concepts identified independently of their natural-language spelling.',
 'sbvr':'Semantics of Business Vocabulary and Business Rules: an OMG standard for business vocabularies and rules.',
 'plain-language':'Communication whose intended readers can find, understand, and use the information they need. Reader evaluation remains required.',
 'minimal-english':'A restricted, cross-translatable explanatory vocabulary based on semantic primes and additional simple semantic molecules.',
 'e-prime':'English that excludes forms of the verb to be. Ambiguous contractions require analysis before compliance can be established.',
 'basic-english':'The named Basic English controlled vocabulary and its grammatical conventions, rather than an arbitrary frequency tier.',
 'special-english':'The named Special English controlled vocabulary, rather than an arbitrary frequency tier.',
 'globish':'The named Globish controlled vocabulary and grammatical conventions, rather than unrestricted simplified English.',
 'primes':'Natural Semantic Metalanguage semantic primes, with language-specific exponents, allolexes, and syntactic frames. A flat list of words is insufficient.',
 'speaker-knows-everything':'The proposition that the utterance speaker knows everything. This lexical identity does not assert that the proposition is true.',
}
rows=['# Authored concepts for the output policy. No conformance is implied.','meanings']
for key,gloss in profiles.items():
 rows += ['  '+key,'    defined-by concept','    role '+('lexical_identity' if key=='speaker-knows-everything' else 'output_constraint'),
          '    precondition "The output policy refers to this concept."',
          '    effect "'+gloss+'"', '    unit "not applicable"',
          '    example "Inspect this concept independently of its selected output spelling."',
          '    grounding "https://github.com/link-assistant/formal-ai/issues/1584"']
Path('data/seed/meanings-controlled-output.lino').write_text('\n'.join(rows)+'\n')
# Request aliases change density without erasing the independently chosen
# global named standard. An explicit lexical_density takes precedence.
path=Path('js/server/cnl-output.mjs');text=path.read_text()
start=text.index('  const configuration = serverOutputConfiguration({',text.index('export function requestOutputTurn'))
end=text.index('  return outputTurn(',start)
text=text[:start]+'''  let configuration = serverOutputConfiguration(defaults);
  if (request.output_standard != null) {
    const named = serverOutputConfiguration({output_standard: request.output_standard});
    configuration = named.lexical_density === 'standard'
      ? {...configuration, output_standard: named.output_standard}
      : {...configuration, lexical_density: named.lexical_density};
  }
  if (request.lexical_density != null) {
    configuration = {...configuration, lexical_density: request.lexical_density};
  }
''' + text[end:]
path.write_text(text)
path=Path('rust/src/protocol/cnl.rs');text=path.read_text()
start=text.index('    let configuration = output_configuration(');end=text.index('    let (prompt, history)',start)
text=text[:start]+'''    let mut configuration = solver.config.output;
    if let Some(named) = &request.output_standard {
        if let Ok(selected) = output_configuration(Some(named), None, cnl_policy()) {
            if selected.density == crate::cnl_output::OutputDensity::Standard {
                configuration.standard = selected.standard;
            } else {
                configuration.density = selected.density;
            }
        }
    }
    if let Some(density) = &request.lexical_density {
        if let Ok(selected) = output_configuration(None, Some(density), cnl_policy()) {
            configuration.density = selected.density;
        }
    }
''' + text[end:]
path.write_text(text)
# Case folding may change UTF-8 byte lengths. Regex match offsets always
# point into the original text, so no case-folded offset can panic on input.
path=Path('rust/src/cnl_output/dialogue.rs');text=path.read_text()
old='''                let density = format!("top-{}", &words[prefix.len()..words.len() - suffix.len()]);'''
new='''                let pattern = format!("(?i)^{}([0-9]+){}$", regex::escape(prefix), regex::escape(suffix));
                let Some(captures) = regex::Regex::new(&pattern).ok()?.captures(words) else { continue; };
                let density = format!("top-{}", &captures[1]);'''
assert old in text;text=text.replace(old,new)
text=text.replace('''            let tail = &trimmed[prefix.len()..];''','''            let pattern = format!("(?i)^{}", regex::escape(&prefix));
            let Some(matched) = regex::Regex::new(&pattern).ok()?.find(trimmed) else { continue; };
            let tail = &trimmed[matched.end()..];''')
path.write_text(text)
# Restore ordinary readability for the added server arguments.
path=Path('js/server/main.mjs');text=path.read_text()
text=text.replace('lexicalDensity = env.FORMAL_AI_LEXICAL_DENSITY, prerequisiteGrantJson = env.FORMAL_AI_PREREQUISITE_GRANT_JSON ?? null } = {}) {',
 'lexicalDensity = env.FORMAL_AI_LEXICAL_DENSITY,\n      prerequisiteGrantJson = env.FORMAL_AI_PREREQUISITE_GRANT_JSON ?? null } = {}) {')
path.write_text(text)
# Ignore only environment checkouts, locally; never commit the dependency tree.
exclude=Path('.git/info/exclude')
if '.meta-language' not in exclude.read_text():exclude.write_text(exclude.read_text()+'\n.meta-language\n')
for name in ['cnl-preferences.ts','preference-defaults.ts']:
 path=Path('ts/app')/name
 if path.exists():path.unlink()
for name,command in [
 ('format',['rustfmt','--edition','2024','--config','skip_children=true','rust/src/protocol/cnl.rs','rust/src/cnl_output/dialogue.rs']),
 ('seed-registry',['node','scripts/generate-seed-registry.mjs','--write']),
 ('embedded-data',['node','scripts/mirror-package-data.mjs','--write']),
 ('worker-factories',['node','scripts/generate-worker-crate-modules.mjs','--write']),
 ('worker-identities',['node','scripts/generate-worker-prerequisites.mjs','--write']),
 ('typescript',['node','scripts/translate-es.mjs','--write']),
]:
 with (base/(name+'-foundation.log')).open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 if result.returncode: print(name,result.returncode);raise SystemExit(result.returncode)
print('Grounded policy terms, preserved independent API settings, and bounded Unicode slicing.')
