from pathlib import Path
import urllib.request,urllib.error,json,hashlib,subprocess,zipfile,xml.etree.ElementTree as ET

base=Path('/tmp/issue-1584-research/standards-local');base.mkdir(exist_ok=True)
sources=[
 ('ste-issue9.pdf','https://www.asd-ste100.org/assets/files/ASD-STE100_ISSUE9.pdf'),
 ('russian-primes.docx','https://nsm-approach.net/wp-content/uploads/2021/10/Russian_Table_Primes.docx'),
 ('chinese-primes.docx','https://nsm-approach.net/wp-content/uploads/2021/10/Chinese_Table_Primes.docx'),
]
records=[]
for name,url in sources:
 record={'filename':name,'url':url}
 try:
  request=urllib.request.Request(url,headers={'User-Agent':'formal-ai issue-1584 standards research'})
  with urllib.request.urlopen(request,timeout=25) as response:
   content=response.read(2*1024*1024+1)
   if len(content)>2*1024*1024:raise ValueError('bounded download size exceeded')
   record.update(status=response.status,content_type=response.headers.get('Content-Type'),bytes=len(content),sha256=hashlib.sha256(content).hexdigest())
  path=base/name;path.write_bytes(content)
  record['file_type']=subprocess.check_output(['file','--brief',str(path)],text=True).strip()
  if name.endswith('.docx') and zipfile.is_zipfile(path):
   with zipfile.ZipFile(path) as archive:
    info=archive.getinfo('word/document.xml')
    if info.file_size>1024*1024:raise ValueError('bounded XML size exceeded')
    root=ET.fromstring(archive.read(info))
   text='\n'.join(node.text for node in root.iter() if node.tag.endswith('}t') and node.text)
   (base/(name+'.txt')).write_text(text)
   record['extracted_characters']=len(text)
 except Exception as error:record['error']=str(error)
 records.append(record);print(json.dumps(record,ensure_ascii=False),flush=True)
Path('/tmp/issue-1584-research/standards-retrieval.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
