from pathlib import Path
import re
def edit(name,old,new):
    p=Path(name);text=p.read_text()
    if new in text:return
    assert text.count(old)==1,(name,old[:90],text.count(old))
    p.write_text(text.replace(old,new))
edit('rust/src/cnl_output/config.rs', 'use serde::{Deserialize, Serialize};', '''use serde::{Deserialize, Serialize};
use std::sync::OnceLock;

static DEFAULT_OUTPUT: OnceLock<OutputConfig> = OnceLock::new();

pub fn configured_output() -> OutputConfig { *DEFAULT_OUTPUT.get_or_init(OutputConfig::default) }

pub fn configure_output(config: OutputConfig) -> Result<(), &'static str> {
    DEFAULT_OUTPUT.set(config).map_err(|_| "cnl_output_already_configured")
}

pub fn deserialize_standard<'de, D: serde::Deserializer<'de>>(input: D) -> Result<Option<String>, D::Error> {
    let value = Option::<String>::deserialize(input)?;
    output_config(value.as_deref(), None, super::cnl_policy()).map_err(serde::de::Error::custom)?;
    Ok(value)
}

pub fn deserialize_density<'de, D: serde::Deserializer<'de>>(input: D) -> Result<Option<String>, D::Error> {
    let value = Option::<String>::deserialize(input)?;
    output_config(None, value.as_deref(), super::cnl_policy()).map_err(serde::de::Error::custom)?;
    Ok(value)
}''')
edit('rust/src/cnl_output.rs','mod config;', 'pub mod config;')
edit('rust/src/solver.rs','output: crate::cnl_output::OutputConfig::default(),', 'output: crate::cnl_output::config::configured_output(),')
edit('rust/src/protocol.rs','pub struct ChatCompletionRequest {', '''pub struct ChatCompletionRequest {
    #[serde(default, skip_serializing_if = "Option::is_none", deserialize_with = "crate::cnl_output::config::deserialize_standard")]
    pub output_standard: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none", deserialize_with = "crate::cnl_output::config::deserialize_density")]
    pub lexical_density: Option<String>,''')
edit('rust/src/protocol.rs','mod tokens;', 'mod tokens;\nmod cnl;\npub use cnl::create_chat_completion_with_solver_and_memory;')
edit('rust/src/protocol.rs','pub fn create_chat_completion_with_solver_and_memory(', 'fn create_unprojected_chat_completion(')
edit('rust/src/protocol.rs','        learning_trace: None,', '        output_projection: None,\n        learning_trace: None,')
edit('rust/src/protocol.rs','        learning_trace,\n', '        output_projection: None,\n        learning_trace,\n')
edit('rust/src/protocol/output.rs','    pub learning_trace: Option<Value>,', '    pub learning_trace: Option<Value>,\n    #[serde(default, skip_serializing_if = "Option::is_none")]\n    pub output_projection: Option<Value>,')
edit('rust/src/main.rs','    #[command(subcommand)]\n    command: Option<Command>,', '''    /// Named output constraints, independent of accepted input phrasing.
    #[arg(long, global = true, env = "FORMAL_AI_OUTPUT_STANDARD")]
    output_standard: Option<String>,
    /// Vocabulary density: standard, primes, top-N, dense or max-precision.
    #[arg(long, global = true, env = "FORMAL_AI_LEXICAL_DENSITY")]
    lexical_density: Option<String>,

    #[command(subcommand)]
    command: Option<Command>,''')
edit('rust/src/main.rs','    formal_ai::structured_tracing::install()', '''    let output = formal_ai::cnl_output::output_config(arguments.output_standard.as_deref(), arguments.lexical_density.as_deref(), formal_ai::cnl_output::cnl_policy()).map_err(std::io::Error::other)?;
    formal_ai::cnl_output::config::configure_output(output).map_err(std::io::Error::other)?;
    formal_ai::structured_tracing::install()''')
# Existing public request initializers retain their previous default behavior.
for root in ['rust/src','rust/tests/unit']:
    for p in Path(root).rglob('*.rs'):
        text = p.read_text()
        if 'stream_options:' not in text:continue
        text = re.sub(r'(?m)^(\s+)stream_options:', r'\1output_standard: None,\n\1lexical_density: None,\n\1stream_options:', text)
        p.write_text(text)
