from pathlib import Path
import subprocess

path = Path('data/seed/cnl-output.lino')
text = path.read_text().replace('cnl_output\n','controlled-output\n').replace('max_words ', 'maximum-words ').replace('speaker_knows_everything','speaker-knows-everything')
frequencies = {'en':'Explain using top {count} words','ru':'Объясни с помощью {count} самых частых слов','hi':'सबसे आम {count} शब्दों का उपयोग करके समझाएँ','zh':'用最常见的 {count} 个词解释','es':'Explica usando las {count} palabras más frecuentes'}
for language, phrase in frequencies.items():
    text = text.replace('  language ' + language + '\n', '  language ' + language + '\n    frequency "' + phrase + '"\n')
path.write_text(text)

path = Path('js/agentic/crate/cnl_output.mjs')
text = path.read_text().replace("'cnl_output'", "'controlled-output'").replace("'max_words'", "'maximum-words'").replace("'output_meaning'", "'output-meaning'")
text = text.replace("id: node.value, notice: childValue(node, 'notice'),", "id: node.value, notice: childValue(node, 'notice'), frequency: childValue(node, 'frequency'),")
start = text.index('  const frequency = /^Explain using top ')
end = text.index('    for (const item of language.switches)', start)
text = text[:start] + '''  for (const language of policy.languages) {
    const [prefix, suffix] = language.frequency.split('{count}');
    const words = trimmed.replace(/[.!。！]+$/u, '');
    if (suffix && words.toLowerCase().startsWith(prefix.toLowerCase()) && words.toLowerCase().endsWith(suffix.toLowerCase())) {
      const density = 'top-' + words.slice(prefix.length, -suffix.length);
      if (frequencyTier(density) !== null) return {config: {lexical_density: density}, rest: '', paraphrase: true};
    }
''' + text[end:]
path.write_text(text)

path = Path('rust/src/cnl_output.rs')
text = path.read_text().replace('"cnl_output"', '"controlled-output"').replace('"max_words"', '"maximum-words"')
text = text.replace('    pub notice: String,', '    pub notice: String,\n    pub frequency: String,')
text = text.replace('                notice: node.find_child_value("notice").to_owned(),', '                notice: node.find_child_value("notice").to_owned(),\n                frequency: node.find_child_value("frequency").to_owned(),')
path.write_text(text)

path = Path('rust/src/cnl_output/dialogue.rs')
text = path.read_text()
start = text.index('    let frequency = regex::Regex::new(')
end = text.index('        for (cue, mode) in &language.switches', start)
text = text[:start] + '''    for language in &policy.languages {
        let words = trimmed.trim_end_matches(['.', '!', '。', '！']);
        if let Some((prefix, suffix)) = language.frequency.split_once("{count}") {
            if !suffix.is_empty() && words.to_lowercase().starts_with(&prefix.to_lowercase())
                && words.to_lowercase().ends_with(&suffix.to_lowercase()) {
                let density = format!("top-{}", &words[prefix.len()..words.len() - suffix.len()]);
                if let Ok(configuration) = output_configuration(None, Some(&density), policy) {
                    return Some(directive(configuration, String::new(), true));
                }
            }
        }
''' + text[end:]
path.write_text(text)

path = Path('rust/src/cnl_output/projection.rs')
text = path.read_text()
old = '''    let mut text = format!(
        "output_meaning\\n  language {}\\n",
        serde_json::to_string(&document.language).expect("string")
    );'''
new = '''    let mut text = String::from("output-meaning");
    text.push('\\n');
    text.push_str("  language ");
    text.push_str(&serde_json::to_string(&document.language).expect("string"));
    text.push('\\n');'''
assert old in text
path.write_text(text.replace(old,new))

Path('rust/tests/unit/cnl_output.rs').write_bytes(Path('/tmp/issue-1584-research/files/rust/tests/unit/cnl_output.rs').read_bytes())
path = Path('rust/tests/unit/mod.rs')
path.write_text(path.read_text().replace('mod cli_paths;', 'mod cli_paths;\nmod cnl_output;'))

# Extract an independent protocol test to keep the existing module below 1000
# lines. Its code and assertions are unchanged.
path = Path('rust/tests/unit/specification/openai_compatibility.rs')
text = path.read_text()
start = text.rfind('\n#[test]')
prefix = text[:text.index('#[test]')]
Path('rust/tests/unit/specification/openai_compatibility_output.rs').write_text(prefix + text[start:])
path.write_text(text[:start] + '\n#[path = "openai_compatibility_output.rs"]\nmod output;\n')

changed = subprocess.check_output(['git','diff','--name-only','--','*.rs'], text=True).splitlines()
changed += subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','*.rs'], text=True).splitlines()
subprocess.run(['rustfmt','--edition','2024','--config','skip_children=true',*changed], check=True)
for name, command in [
    ('seed-registry',['node','scripts/generate-seed-registry.mjs','--write']),
    ('embedded-data',['node','scripts/mirror-package-data.mjs','--write']),
    ('worker-factories',['node','scripts/generate-worker-crate-modules.mjs','--write']),
    ('worker-identities',['node','scripts/generate-worker-prerequisites.mjs','--write']),
    ('typescript',['node','scripts/translate-es.mjs','--write']),
]:
    with open('/tmp/issue-1584-research/'+name+'.log','w') as log:
        subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Localized numeric-tier directives, kept graph labels as protocol tokens, added native corpus checks, and refreshed generated data.')
