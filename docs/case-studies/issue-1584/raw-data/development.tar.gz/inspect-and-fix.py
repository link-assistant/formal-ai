from pathlib import Path
import subprocess
import json
import importlib.util

path = Path('js/app/cnl-settings.jsx')
path.write_text(path.read_text().replace('const {createElement: h} = React;', 'const {createElement: h, Fragment} = React;'))
path = Path('rust/tests/unit/specification/openai_compatibility_output.rs')
text = path.read_text()
path.write_text('use super::*;\n' + text[text.rfind('\n#[test]'):])

base = Path('/tmp/issue-1584-research')
for name, command in [
    ('specification-head', ['head','-c','2400','experiments/formal_ai_subagent/sandboxes/gates/check-specification-in-javascript.log']),
    ('specification-source', ['head','-n','90','scripts/check-specification-in-javascript.mjs']),
    ('prompt-current', ['node','scripts/check-prompt-specialization.mjs','--list']),
    ('notation-current', ['node','scripts/measure-notation.mjs','--check']),
    ('abbreviations-current', ['node','scripts/measure-abbreviations.mjs','--check']),
]:
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (base / (name+'.log')).write_text(result.stdout)
    print(name, result.returncode, result.stdout[:2400])

spec = importlib.util.spec_from_file_location('closure_audit', 'scripts/audit-total-closure.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
current = audit.audit('.')
path = Path('data/seed/cnl-output.lino')
saved = path.read_bytes()
path.unlink()
try:
    previous = audit.audit('.')
finally:
    path.write_bytes(saved)
print('New unresolved policy tokens', sorted(set(current['unresolved']) - set(previous['unresolved'])))
(base/'closure-policy-delta.json').write_text(json.dumps({'current':current,'without_policy':previous},ensure_ascii=False,indent=2))
with open(base/'ui-rebuild.log','w') as log:
    subprocess.run(['python3',str(base/'build-ui.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
print('Browser build refreshed.')
