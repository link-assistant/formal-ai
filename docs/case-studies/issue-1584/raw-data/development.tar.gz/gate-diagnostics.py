from pathlib import Path
import subprocess
base=Path('/tmp/issue-1584-research')
for name,command in [
 ('abbreviation-bindings',['node','scripts/measure-abbreviations.mjs','--list','bindings','js']),
 ('notation-abbreviations',['node','scripts/measure-notation.mjs','--list','abbreviated','data/seed']),
 ('file-counts',['wc','-l','rust/src/main.rs','rust/src/protocol.rs','rust/src/seed/embedded_registry.rs','rust/tests/unit/specification/openai_compatibility.rs']),
 ('specification-extraction',['node','--input-type=module','-e',"import {specificationCases} from './scripts/lib/rust-specification-cases.mjs'; let r=specificationCases(); console.log(JSON.stringify(r,null,2))"]),
 ('web-ui-boundary-current',['node','scripts/check-web-ui-boundary.mjs','--check']),
]:
 result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (base/(name+'.log')).write_text(result.stdout)
 print(name, result.returncode, result.stdout[:300] if name!='specification-extraction' else len(result.stdout))
