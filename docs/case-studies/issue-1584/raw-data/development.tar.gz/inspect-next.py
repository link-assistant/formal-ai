from pathlib import Path
import subprocess
import shutil
import json

base = Path('/tmp/issue-1584-research')
subprocess.run(['python3', str(base / 'build-ui.py')], check=True)
result = subprocess.run(['bun', 'build', 'js/web-search-component-entry.js', '--outfile', str(base / 'ui-site/web-search-component.bundle.js'), '--target', 'browser', '--format', 'iife', '--production', '--minify-whitespace', '--minify-syntax'], capture_output=True, text=True)
print('Web-search bundle:', result.returncode, result.stdout, result.stderr)
baseline = base / 'specification-baseline'
files = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', 'HEAD', 'rust/tests/unit/specification', 'rust/src'], text=True).splitlines()
for name in files:
    destination = baseline / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(subprocess.check_output(['git', 'show', 'HEAD:' + name]))
script = "import {specificationCases} from './scripts/lib/rust-specification-cases.mjs'; import fs from 'node:fs'; const current=specificationCases('.'); const baseline=specificationCases('/tmp/issue-1584-research/specification-baseline'); const ids=new Set(current.cases.map(x=>x.id)); const missing=baseline.cases.filter(x=>!ids.has(x.id)); console.log(JSON.stringify({baseline:baseline.cases.length,current:current.cases.length,missing:missing.map(x=>({id:x.id,reason:current.unsupported.find(y=>y.id===x.id)}))},null,2));"
result = subprocess.run(['node', '--max-old-space-size=256', '--input-type=module', '-e', script], capture_output=True, text=True)
(base / 'specification-comparison.json').write_text(result.stdout + result.stderr)
print(result.stdout, result.stderr)
