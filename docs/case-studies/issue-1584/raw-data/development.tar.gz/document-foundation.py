from pathlib import Path
import subprocess
p=Path('rust/tests/unit/cnl_output.rs');s=p.read_text();s=s.replace('        ("es", "Yo sé todo.", "Soy omnisciente."),','        // Spanish participates in the same realization and profile matrix.\n        ("es", "Yo sé todo.", "Soy omnisciente."),');p.write_text(s)
p=Path('experiments/issue-1584/PLAN.md');s=p.read_text().replace('The issue has no comments or native sub-issues as of the initial\n2026-11-17 inspection. PR conversation, inline comments and reviews were empty.','The complete issue has one automation comment and no required sub-issues as of\nthe 2026-11-17 refresh. PR 1585 has four conversation comments from previous\nattempts, no inline comments, and no reviews. All were read.');s+='\nCurrent pass: configuration, output-only projection, API and browser controls are\ndrafted; strict standard realization, semantic decomposition, candidate CNL\nclarification, and broad native/WASM parity remain unfinished. See README.md.\nAttempted reasoning units: 8; independently accepted: 0/8 (0%). Supplied\nconclusions and supplied commands are not independent reasoning or authorship.\n';p.write_text(s)
Path('changelog.d/20261117_134000_controlled_output_preview.md').write_text('''---
bump: minor
---

### Added
- Experimental independent output-standard and lexical-density settings in the CLI, OpenAI-compatible API, browser worker, and desktop preferences. Projection retains unknown text and reports missing compliance evidence explicitly; named profiles do not yet establish strict standard conformance.
''')
Path('experiments/issue-1584/README.md').write_text('''# Controlled output development evidence — issue 1584

Work in progress for [PR 1585](https://github.com/link-assistant/formal-ai/pull/1585).
None of the issue's seven broad acceptance criteria is marked complete.

The JavaScript root is `js/agentic/crate/cnl_output.mjs`. The shared policy is
`data/seed/cnl-output.lino`; native code is in `rust/src/cnl_output/`.
Configuration selects a named standard independently from vocabulary density.
Explicit user directives can override each dimension. A standalone rewrite
uses the previous assistant response before the agentic planner runs. Tool
arguments, quoted input, and opaque spans retain their original bytes.

## What the current checks demonstrate

- Ten focused JavaScript tests exercise option validation, independent mode
  switching, Unicode word counting, opaque input, and declared equivalence.
- Three HTTP tests cover request-local overrides, invalid configuration, SSE
  metadata, and rewrite handling before tool planning. Seven existing server
  tests provide integration regression coverage.
- One proposition has two declared realizations in each of English, Russian,
  Hindi, Chinese and Spanish. Its finite profile/density matrix preserves the
  declared lexical identity. This is not the solver's complete intent graph
  and is not a corpus across all requested input standards.
- Rust tests mirror the limited corpus and configuration boundaries. They have
  not been compiled locally; repository policy leaves Rust execution to CI.
- Real browser checks cover persisted settings and a rewrite turn. Screenshots
  are in `docs/screenshots/issue-1584/`. The browser and preview server were
  closed after verification. These screenshots do not prove vocabulary limits.

## Acceptance inventory

| Requirement | Implemented evidence | Still unfinished |
| --- | --- | --- |
| Unrestricted input | Unknown text, quotes, polarity and quantifiers remain opaque and unchanged | General equivalence of free-form and every CNL input intent |
| Default intersection | Shared profile and sentence-length constraint | Complete multilingual intersection grammar, vocabulary and semantic validation |
| Named output standards and density | CLI/env, OpenAI fields, UI settings, localized directives | Strict renderers, official vocabularies, NSM decomposition, frequency corpus, all protocol and summarization surfaces |
| Maximum lexical density | Deterministic minimum over declared alternatives; localized dictionary notice | Global minimum proof over existing words; this is explicitly `unchecked` |
| Bidirectional paraphrasing | Declared realization round trips and per-turn settings | General meaning-preserving paraphrases |
| Candidate clarification | Existing solver clarification was inspected | Precise candidate CNL and confirmation before actions across runtimes |
| Cross-standard matrix | Small JS corpus plus unexecuted native tests | Full input-style/output matrix and native/JS/WASM behavioral parity |

A selected profile is metadata, not a compliance certificate. Missing checkers
produce `compliant: false` with named `unchecked` constraints. Opaque retention
is lossless storage, not evidence of understanding. In particular, `primes` and
`top-N` currently retain text without claiming that it satisfies their limits.

Arbitrary positive `top-N` includes `top-1`. A single natural-language word
cannot express every distinct proposition with exact preserved meaning by
ordinary natural-language composition. Encoding arbitrary meanings in counts
or identifiers would not satisfy a natural-language output requirement. The
strict universal output constraint therefore conflicts with unrestricted
meaning preservation for some tiers; the requested policy for an unsatisfiable
tier remains unresolved. Other unfinished work above is implementation work,
not an external blocker.

## Reproduction

Run each file separately, as required by AGENTS.md:

```sh
timeout 600 node --test --test-concurrency=1 rust/tests/web/cnl-output.test.mjs
timeout 600 node --test --test-concurrency=1 experiments/issue-1584/server.test.mjs
timeout 600 node --test --test-concurrency=1 rust/tests/web/server.test.mjs
node scripts/translate-js-rust.mjs --verify
node experiments/formal_ai_subagent/local-gates.mjs
```

The shared policy and seed registries require the full local gate set. Skipped
CI-only Rust gates must not be counted as locally passed. The generated JS-to-
Rust fixture contains carried source and refused constructs: its generation
exits nonzero, while source currency verification passes. The native module is
a supplied manual port; automatic translation and runtime parity are unproven.

## Development provenance

`drive.mjs` is an externally supplied adapter around the maintained JavaScript
Formal AI planner and real tool host. `job.mjs` keeps long checks outside the
host's command deadline and records completion. Supplied requests, patches,
commands and scripts earn **zero autonomous authorship credit**. The frozen
substantive unit inventory is in PLAN.md: 8 attempted, 0 independently accepted
(0%). No claim that Formal AI authored this implementation is made.

Captured records retain exact requests, complete responses/tool traces,
failures, command outputs, runtime identities, tracked diffs and independent
checks. Early runtime records hash tracked diffs but omit untracked source;
that provenance limit is retained explicitly. A bounded evidence archive and
SHA-256 manifest accompany the final verification record. Temporary package
installations, caches and binaries are excluded from the archive.
''')
result=subprocess.run(['node','scripts/generate-runtime-feature-inventory.mjs','--write'],capture_output=True,text=True);print('runtime inventory',result.returncode,result.stdout,result.stderr)
