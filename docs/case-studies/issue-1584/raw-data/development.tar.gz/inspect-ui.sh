#!/usr/bin/env bash
set -e
command -v bun || true
rg --files data | rg 'i18n|ui-.*lino|translations' | head -25
sed -n '1,90p' js/app/main.jsx
sed -n '1,115p' js/app/application.jsx
sed -n '205,225p' js/app/application-worker-hooks.jsx
sed -n '365,440p' js/app/application-worker-hooks.jsx
sed -n '250,285p' js/app/preferences.jsx
sed -n '585,645p' js/app/application.jsx
sed -n '1310,1360p' js/app/application.jsx
rg -n -A 35 'requestDesktopAnswer' js/app/desktop-bridge.jsx
sed -n '1,90p' experiments/formal_ai_subagent/local-gates.mjs
