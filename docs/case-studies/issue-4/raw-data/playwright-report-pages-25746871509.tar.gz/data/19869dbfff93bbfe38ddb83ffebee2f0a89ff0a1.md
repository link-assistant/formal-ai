# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: demo.spec.js >> formal-ai demo UI >> pressing Enter submits the message
- Location: tests/demo.spec.js:99:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.app')
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 15000ms
  - waiting for locator('.app')

```

```yaml
- heading "404" [level=1]
- paragraph:
  - strong: There isn't a GitHub Pages site here.
- paragraph:
  - text: If you're trying to publish one,
  - link "read the full documentation":
    - /url: https://help.github.com/pages/
  - text: to learn how to set up
  - strong: GitHub Pages
  - text: for your repository, organization, or user account.
- link "GitHub Status":
  - /url: https://githubstatus.com
- text: —
- link "@githubstatus":
  - /url: https://twitter.com/githubstatus
- link:
  - /url: /
```

# Test source

```ts
  1   | // @ts-check
  2   | const { test, expect } = require('@playwright/test');
  3   | 
  4   | test.describe('formal-ai demo UI', () => {
  5   |   test.beforeEach(async ({ page }) => {
  6   |     await page.goto('/');
  7   |     // Wait for React to mount and the app shell to be visible
> 8   |     await expect(page.locator('.app')).toBeVisible({ timeout: 15_000 });
      |                                        ^ Error: expect(locator).toBeVisible() failed
  9   |   });
  10  | 
  11  |   test('page title is formal-ai', async ({ page }) => {
  12  |     await expect(page).toHaveTitle('formal-ai');
  13  |   });
  14  | 
  15  |   test('brand header is visible', async ({ page }) => {
  16  |     await expect(page.locator('.brand')).toBeVisible();
  17  |     await expect(page.locator('.brand strong')).toContainText('formal-ai');
  18  |   });
  19  | 
  20  |   test('initial messages show greeting exchange', async ({ page }) => {
  21  |     const messageList = page.locator('[data-testid="message-list"]');
  22  |     await expect(messageList).toBeVisible();
  23  | 
  24  |     const messages = page.locator('[data-testid="chat-message"]');
  25  |     await expect(messages).toHaveCount(2);
  26  | 
  27  |     const userMsg = messages.first();
  28  |     await expect(userMsg).toHaveClass(/user/);
  29  |     await expect(userMsg).toContainText('Hi');
  30  | 
  31  |     const assistantMsg = messages.nth(1);
  32  |     await expect(assistantMsg).toHaveClass(/assistant/);
  33  |     await expect(assistantMsg).toContainText('Hi');
  34  |   });
  35  | 
  36  |   test('quick prompts sidebar is visible with expected prompts', async ({ page }) => {
  37  |     const promptList = page.locator('.prompt-list');
  38  |     await expect(promptList).toBeVisible();
  39  | 
  40  |     const buttons = promptList.locator('button');
  41  |     await expect(buttons.first()).toContainText('Hi');
  42  |     await expect(buttons.nth(1)).toContainText('Rust');
  43  |   });
  44  | 
  45  |   test('chat input and send button are present', async ({ page }) => {
  46  |     const input = page.locator('[data-testid="chat-composer-input"]');
  47  |     await expect(input).toBeVisible();
  48  |     await expect(input).toBeEnabled();
  49  | 
  50  |     const sendBtn = page.locator('[data-testid="chat-composer-submit"]');
  51  |     await expect(sendBtn).toBeVisible();
  52  |   });
  53  | 
  54  |   test('send button is disabled when input is empty', async ({ page }) => {
  55  |     const sendBtn = page.locator('[data-testid="chat-composer-submit"]');
  56  |     await expect(sendBtn).toBeDisabled();
  57  |   });
  58  | 
  59  |   test('clicking a quick prompt populates the input', async ({ page }) => {
  60  |     const hiButton = page.locator('.prompt-list button').first();
  61  |     await hiButton.click();
  62  | 
  63  |     const input = page.locator('[data-testid="chat-composer-input"]');
  64  |     await expect(input).toHaveValue('Hi');
  65  |   });
  66  | 
  67  |   test('sending a greeting produces an assistant reply', async ({ page }) => {
  68  |     const input = page.locator('[data-testid="chat-composer-input"]');
  69  |     await input.fill('Hello');
  70  | 
  71  |     const sendBtn = page.locator('[data-testid="chat-composer-submit"]');
  72  |     await sendBtn.click();
  73  | 
  74  |     // Wait for the assistant response to appear (worker or fallback)
  75  |     const messages = page.locator('[data-testid="chat-message"]');
  76  |     await expect(messages).toHaveCount(4, { timeout: 15_000 });
  77  | 
  78  |     const lastMsg = messages.last();
  79  |     await expect(lastMsg).toHaveClass(/assistant/);
  80  |     await expect(lastMsg).toContainText('Hi');
  81  |   });
  82  | 
  83  |   test('sending a hello world request produces a code block', async ({ page }) => {
  84  |     const input = page.locator('[data-testid="chat-composer-input"]');
  85  |     await input.fill('Write me hello world program in Rust');
  86  | 
  87  |     const sendBtn = page.locator('[data-testid="chat-composer-submit"]');
  88  |     await sendBtn.click();
  89  | 
  90  |     // Wait for assistant message with Rust code
  91  |     const messages = page.locator('[data-testid="chat-message"]');
  92  |     await expect(messages).toHaveCount(4, { timeout: 15_000 });
  93  | 
  94  |     const lastMsg = messages.last();
  95  |     await expect(lastMsg).toHaveClass(/assistant/);
  96  |     await expect(lastMsg).toContainText('rust');
  97  |   });
  98  | 
  99  |   test('pressing Enter submits the message', async ({ page }) => {
  100 |     const input = page.locator('[data-testid="chat-composer-input"]');
  101 |     await input.fill('Hi');
  102 |     await input.press('Enter');
  103 | 
  104 |     const messages = page.locator('[data-testid="chat-message"]');
  105 |     await expect(messages).toHaveCount(4, { timeout: 15_000 });
  106 |   });
  107 | 
  108 |   test('demo mode toggle button is present', async ({ page }) => {
```